package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.exception.MathArithmeticException;

public class ArithmeticUtils_gcd_0_1_Test {

    @Test
    @DisplayName("gcd(0, 0) returns 0 by both operands being zero")
    void TC01() {
        // GIVEN
        long p = 0L;
        long q = 0L;
        
        // WHEN
        long result = ArithmeticUtils.gcd(p, q);
        
        // THEN
        assertEquals(0L, result);
    }
    
    @Test
    @DisplayName("gcd(0, 10) returns 10 when first operand is zero")
    void TC02() {
        // GIVEN
        long p = 0L;
        long q = 10L;
        
        // WHEN
        long result = ArithmeticUtils.gcd(p, q);
        
        // THEN
        assertEquals(10L, result);
    }
    
    @Test
    @DisplayName("gcd(15, 0) returns 15 when second operand is zero")
    void TC03() {
        // GIVEN
        long p = 15L;
        long q = 0L;
        
        // WHEN
        long result = ArithmeticUtils.gcd(p, q);
        
        // THEN
        assertEquals(15L, result);
    }
    
    @Test
    @DisplayName("gcd(Long.MIN_VALUE, 10) throws MathArithmeticException due to overflow")
    void TC04() {
        // GIVEN
        long p = Long.MIN_VALUE;
        long q = 10L;
        
        // WHEN & THEN
        assertThrows(MathArithmeticException.class, () -> {
            ArithmeticUtils.gcd(p, q);
        });
    }
    
    @Test
    @DisplayName("gcd(10, Long.MIN_VALUE) throws MathArithmeticException due to overflow")
    void TC05() {
        // GIVEN
        long p = 10L;
        long q = Long.MIN_VALUE;
        
        // WHEN & THEN
        assertThrows(MathArithmeticException.class, () -> {
            ArithmeticUtils.gcd(p, q);
        });
    }
}