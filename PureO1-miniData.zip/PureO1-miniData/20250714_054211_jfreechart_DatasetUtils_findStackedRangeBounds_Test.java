package org.jfree.data.general;

import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.KeyToGroupMap;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.jupiter.api.Test;

public class DatasetUtilsTest {

    @Test
    public void testFindStackedRangeBounds_NullDataset() {
        KeyToGroupMap map = new KeyToGroupMap("Group");
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.findStackedRangeBounds(null, map);
        });
    }

    @Test
    public void testFindStackedRangeBounds_NullMap() {
        CategoryDataset dataset = new DefaultCategoryDataset();
        assertThrows(NullPointerException.class, () -> {
            DatasetUtils.findStackedRangeBounds(dataset, null);
        });
    }

    @Test
    public void testFindStackedRangeBounds_EmptyDataset() {
        CategoryDataset dataset = new DefaultCategoryDataset();
        KeyToGroupMap map = new KeyToGroupMap("Group");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertNull(range);
    }

    @Test
    public void testFindStackedRangeBounds_NoGroups() {
        CategoryDataset dataset = new DefaultCategoryDataset();
        KeyToGroupMap map = new KeyToGroupMap("Group");
        // Remove all groups
        map.setGroupCount(0);
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertNull(range);
    }

    @Test
    public void testFindStackedRangeBounds_AllValuesNull() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(null, "Series1", "Category1");
        dataset.addValue(null, "Series2", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "B");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertNull(range);
    }

    @Test
    public void testFindStackedRangeBounds_AllPositiveValues_SingleGroup() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Series1", "Category1");
        dataset.addValue(2.0, "Series2", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "A");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(0.0, 3.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_AllNegativeValues_SingleGroup() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(-1.0, "Series1", "Category1");
        dataset.addValue(-2.0, "Series2", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "A");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(-3.0, 0.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_MixedValues_SingleGroup() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(3.0, "Series1", "Category1");
        dataset.addValue(-1.0, "Series2", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "A");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(-1.0, 3.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_MixedValues_MultipleGroups() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(3.0, "Series1", "Category1");
        dataset.addValue(-1.0, "Series2", "Category1");
        dataset.addValue(2.0, "Series3", "Category1");
        dataset.addValue(-2.0, "Series4", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "A");
        map.mapKeyToGroup("Series3", "B");
        map.mapKeyToGroup("Series4", "B");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        // Group A: 3.0 + (-1.0) = 2.0 -> min: -1.0, max: 3.0
        // Group B: 2.0 + (-2.0) = 0.0 -> min: -2.0, max: 2.0
        // Combined Range: min = -2.0, max = 3.0
        assertEquals(new Range(-2.0, 3.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_SingleSeries_SingleGroup() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Series1", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(0.0, 5.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_MultipleCategories_MultipleGroups() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        // Category1
        dataset.addValue(1.0, "Series1", "Category1");
        dataset.addValue(-2.0, "Series2", "Category1");
        dataset.addValue(3.0, "Series3", "Category1");
        dataset.addValue(-1.0, "Series4", "Category1");
        // Category2
        dataset.addValue(2.0, "Series1", "Category2");
        dataset.addValue(-1.0, "Series2", "Category2");
        dataset.addValue(4.0, "Series3", "Category2");
        dataset.addValue(-3.0, "Series4", "Category2");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "A");
        map.mapKeyToGroup("Series3", "B");
        map.mapKeyToGroup("Series4", "B");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        // Category1:
        // Group A: 1.0 + (-2.0) = -1.0
        // Group B: 3.0 + (-1.0) = 2.0
        // Category2:
        // Group A: 2.0 + (-1.0) = 1.0
        // Group B: 4.0 + (-3.0) = 1.0
        // Group A min: -1.0, max: 2.0
        // Group B min: -1.0, max: 4.0
        // Combined Range: min = -1.0, max = 2.0 and (-1.0, 4.0) => Range.combine(null, (-1.0,2.0)) = (-1.0,2.0); then Range.combine((-1.0,2.0), (-1.0,4.0)) = (-1.0,4.0)
        assertEquals(new Range(-1.0, 4.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_WithZeroValues() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(0.0, "Series1", "Category1");
        dataset.addValue(0.0, "Series2", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "A");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(0.0, 0.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_NullGroups() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Series1", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", null);
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        // Assuming map.getGroup(null) returns a default group index
        // Behavior depends on implementation, here we assume it treats null as a valid group
        assertNotNull(range);
    }

    @Test
    public void testFindStackedRangeBounds_DifferentGroupIndices() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(2.0, "Series1", "Category1");
        dataset.addValue(-1.0, "Series2", "Category1");
        dataset.addValue(3.0, "Series3", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.mapKeyToGroup("Series2", "B");
        map.mapKeyToGroup("Series3", "A");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        // Group A: 2.0 + 3.0 = 5.0
        // Group B: -1.0
        // Combined Range: -1.0 to 5.0
        assertEquals(new Range(-1.0, 5.0), range);
    }

    @Test
    public void testFindStackedRangeBounds_MapWithExtraGroups() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Series1", "Category1");
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "A");
        map.addGroup("B");
        map.addGroup("C");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        // Group A: 1.0
        // Group B: 0.0
        // Group C: 0.0
        // Combined Range: 0.0 to 1.0
        assertEquals(new Range(0.0, 1.0), range);
    }
}