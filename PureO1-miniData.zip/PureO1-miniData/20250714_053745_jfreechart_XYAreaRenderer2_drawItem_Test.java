import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYAreaRenderer2;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.urls.XYURLGenerator;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class XYAreaRenderer2Test {

    private XYAreaRenderer2 renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYAreaRenderer2();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = new CrosshairState();
        
        when(state.getInfo()).thenReturn(info);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        renderer = spy(renderer);
        doReturn(false).when(renderer).getItemVisible(anyInt(), anyInt());
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_VerticalOrientation_ShowOutlineTrue() {
        renderer.setOutline(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(Shape.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2).draw(any(Shape.class));
        verify(state).getInfo();
    }

    @Test
    void testDrawItem_VerticalOrientation_ShowOutlineFalse() {
        renderer.setOutline(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_HorizontalOrientation_ShowOutlineTrue() {
        renderer.setOutline(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(Shape.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_HorizontalOrientation_ShowOutlineFalse() {
        renderer.setOutline(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_NaNY1() {
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(eq(0.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(eq(3.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(eq(4.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(40.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);
        
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_NaY0() {
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_NaY2() {
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(eq(0.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(eq(Double.NaN), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(eq(4.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(40.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);
        
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_FirstItem() {
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(domainAxis.valueToJava2D(eq(1.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(eq(2.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        when(dataset.getXValue(0, Math.max(0 - 1, 0))).thenReturn(1.0);
        when(dataset.getYValue(0, Math.max(0 - 1, 0))).thenReturn(2.0);
        when(dataset.getXValue(0, Math.min(0 + 1, 2))).thenReturn(2.0);
        when(dataset.getYValue(0, Math.min(0 + 1, 2))).thenReturn(3.0);
        when(domainAxis.valueToJava2D(eq(1.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(eq(2.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        when(domainAxis.valueToJava2D(eq(2.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(eq(3.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(30.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_LastItem() {
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(dataset.getXValue(0, Math.max(2 - 1, 0))).thenReturn(2.0);
        when(dataset.getYValue(0, Math.max(2 - 1, 0))).thenReturn(3.0);
        when(dataset.getXValue(0, Math.min(2 + 1, 2))).thenReturn(3.0);
        when(dataset.getYValue(0, Math.min(2 + 1, 2))).thenReturn(4.0);
        when(domainAxis.valueToJava2D(eq(2.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(eq(3.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(30.0);
        when(domainAxis.valueToJava2D(eq(3.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(eq(4.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(40.0);
        when(domainAxis.valueToJava2D(eq(0.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(0.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 2, crosshairState, 0);
        
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_SingleItem() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, Math.max(0 - 1, 0))).thenReturn(1.0);
        when(dataset.getYValue(0, Math.max(0 - 1, 0))).thenReturn(2.0);
        when(dataset.getXValue(0, Math.min(0 + 1, 0))).thenReturn(1.0);
        when(dataset.getYValue(0, Math.min(0 + 1, 0))).thenReturn(2.0);
        when(domainAxis.valueToJava2D(eq(1.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(eq(2.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        when(domainAxis.valueToJava2D(eq(0.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(0.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_WithEntityCollectionAndToolTip() {
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(4.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        XYToolTipGenerator generator = mock(XYToolTipGenerator.class);
        when(generator.generateToolTip(dataset, 0, 1)).thenReturn("Tooltip");
        renderer.setDefaultToolTipGenerator(generator);
        XYURLGenerator urlGenerator = mock(XYURLGenerator.class);
        when(urlGenerator.generateURL(dataset, 0, 1)).thenReturn("http://example.com");
        renderer.setURLGenerator(urlGenerator);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        
        ArgumentCaptor<XYItemEntity> captor = ArgumentCaptor.forClass(XYItemEntity.class);
        verify(entities).add(captor.capture());
        XYItemEntity entity = captor.getValue();
        assertEquals("Tooltip", entity.getToolTipText());
        assertEquals("http://example.com", entity.getURLText());
    }

    @Test
    void testDrawItem_NullEntityCollection() {
        when(info.getEntityCollection()).thenReturn(null);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(eq(1.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(eq(2.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(info).getEntityCollection();
        verifyNoMoreInteractions(info);
    }

    @Test
    void testDrawItem_NullToolTipAndURL() {
        when(info.getEntityCollection()).thenReturn(null);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(eq(1.0), eq(dataArea), eq(plot.getDomainAxisEdge()))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(eq(2.0), eq(dataArea), eq(plot.getRangeAxisEdge()))).thenReturn(20.0);
        renderer.setDefaultToolTipGenerator(null);
        renderer.setURLGenerator(null);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(g2).fill(any(Shape.class));
    }
}