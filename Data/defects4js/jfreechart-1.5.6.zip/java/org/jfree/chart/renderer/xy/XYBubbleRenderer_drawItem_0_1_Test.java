package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYBubbleRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem returns early when the item is not visible")
    void TC01_drawItem_item_not_visible() throws Exception {
        // Arrange
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Arrange using direct call to set getItemVisible to return false
        when(renderer.getItemVisible(series, item)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that no drawing methods are called
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any(Ellipse2D.class));
        verify(g2, never()).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawItem returns early when dataset is not an instance of XYZDataset and z is NaN")
    void TC02_drawItem_non_XYZDataset_with_NaN_z() throws Exception {
        // Arrange
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Arrange using direct call to set getItemVisible to return true
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        // Mock dataset to not be an instance of XYZDataset and z to be NaN
        when(dataset instanceof XYZDataset).thenReturn(false);

        // Mock dataset to return NaN when getting Z value
        Method getZValueMethod = XYDataset.class.getDeclaredMethod("getZValue", int.class, int.class);
        getZValueMethod.setAccessible(true);
        when((Double) getZValueMethod.invoke(dataset, series, item)).thenReturn(Double.NaN);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that no drawing methods are called
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any(Ellipse2D.class));
        verify(g2, never()).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawItem processes item with SCALE_ON_DOMAIN_AXIS scaling")
    void TC03_drawItem_with_SCALE_ON_DOMAIN_AXIS() throws Exception {
        // Arrange
        XYBubbleRenderer renderer = new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Arrange using direct call to set getItemVisible to return true
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        // Mock dataset to be an instance of XYZDataset with a valid z value
        when(dataset instanceof XYZDataset).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(10.0);

        // Mock plot orientation to VERTICAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock valueToJava2D for domain and range axes
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(domainAxis.valueToJava2D(0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that setPaint, fill, setStroke, draw are called
        verify(g2).setPaint(any());
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).setStroke(any());
        verify(g2).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawItem processes item with SCALE_ON_RANGE_AXIS scaling")
    void TC04_drawItem_with_SCALE_ON_RANGE_AXIS() throws Exception {
        // Arrange
        XYBubbleRenderer renderer = new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_RANGE_AXIS);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Arrange using direct call to set getItemVisible to return true
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        // Mock dataset to be an instance of XYZDataset with a valid z value
        when(dataset instanceof XYZDataset).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(15.0);

        // Mock plot orientation to VERTICAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock valueToJava2D for domain and range axes
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(75.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, plot.getRangeAxisEdge())).thenReturn(150.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that setPaint, fill, setStroke, draw are called
        verify(g2).setPaint(any());
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).setStroke(any());
        verify(g2).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawItem processes item with default scaling")
    void TC05_drawItem_with_DEFAULT_scaling() throws Exception {
        // Arrange
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Arrange using direct call to set getItemVisible to return true
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        // Mock dataset to be an instance of XYZDataset with a valid z value
        when(dataset instanceof XYZDataset).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(20.0);

        // Mock plot orientation to VERTICAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock valueToJava2D for domain and range axes
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);
        when(domainAxis.valueToJava2D(0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that setPaint, fill, setStroke, draw are called
        verify(g2).setPaint(any());
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).setStroke(any());
        verify(g2).draw(any(Ellipse2D.class));
    }
}