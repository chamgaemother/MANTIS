package com.fasterxml.jackson.databind.deser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
// import com.fasterxml.jackson.databind.PropertyName;
// import com.fasterxml.jackson.databind.BeanDescription;
// 
// import com.fasterxml.jackson.databind.JsonDeserializer;
// import com.fasterxml.jackson.databind.JavaType;
// import com.fasterxml.jackson.databind.MapperFeature;
// import com.fasterxml.jackson.databind.DeserializationConfig;
// import com.fasterxml.jackson.databind.DeserializationContext;
// import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
// import com.fasterxml.jackson.databind.introspect.BeanDescription;
// import com.fasterxml.jackson.databind.introspect.PropertyName;
// import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
// import com.fasterxml.jackson.databind.util.ClassUtil;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.ArgumentCaptor;
// 
// import java.lang.reflect.Field;
// import java.util.*;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
public class BeanDeserializerBuilder_buildBuilderBased_0_2_Test {
// 
//     @Test
//     @DisplayName("_buildMethod is present but return type is incompatible with valueType, reports bad definition")
//     public void TC06_buildMethodPresent_incompatibleReturnType_reportsBadDefinition() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         JavaType mockJavaType = mock(JavaType.class);
//         when(mockBeanDesc.getType()).thenReturn(mockJavaType);
// 
//         DeserializationContext mockContext = mock(DeserializationContext.class);
//         doThrow(new DatabindException("Mocked exception")).when(mockContext).reportBadDefinition(any(), anyString());
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
// 
        // Set _buildMethod using reflection
//         AnnotatedMethod mockBuildMethod = mock(AnnotatedMethod.class);
//         when(mockBuildMethod.getRawReturnType()).thenReturn(UnrelatedType.class);
// 
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, mockBuildMethod);
// 
        // Prepare valueType
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeOtherType.class);
// 
        // WHEN
//         try {
//             builder.buildBuilderBased(valueType, "build");
//             fail("Expected reportBadDefinition to be called");
//         } catch (DatabindException e) {
            // THEN
//             ArgumentCaptor<String> messageCaptor = ArgumentCaptor.forClass(String.class);
//             verify(mockContext).reportBadDefinition(eq(mockBeanDesc.getType()), messageCaptor.capture());
//             String expectedMessage = String.format(
//                     "Build method `%s` has wrong return type (%s), not compatible with POJO type (%s)",
//                     mockBuildMethod.getFullName(),
//                     ClassUtil.getClassDescription(UnrelatedType.class),
//                     ClassUtil.getTypeDescription(valueType)
//             );
//             assertEquals(expectedMessage, messageCaptor.getValue());
//         }
//     }
// 
//     @Test
//     @DisplayName("Properties have no aliases, BeanPropertyMap is constructed without aliases")
//     public void TC07_propertiesNoAliases_propertyMapEmpty() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         DeserializationContext mockContext = mock(DeserializationContext.class);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
// 
        // Set _buildMethod using reflection
//         AnnotatedMethod validBuildMethod = mock(AnnotatedMethod.class);
//         when(validBuildMethod.getRawReturnType()).thenReturn(SomeType.class);
// 
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, validBuildMethod);
// 
        // Mock _collectAliases to return empty map
//         BeanDeserializerBuilder spyBuilder = spy(builder);
//         doReturn(Collections.emptyMap()).when(spyBuilder)._collectAliases(any());
// 
        // Prepare valueType
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
        // WHEN
//         JsonDeserializer<?> deserializer = spyBuilder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//     }
// 
//     @Test
//     @DisplayName("Properties have aliases, BeanPropertyMap is constructed with aliases")
//     public void TC08_propertiesWithAliases_propertyMapNonEmpty() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         DeserializationContext mockContext = mock(DeserializationContext.class);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
// 
        // Set _buildMethod using reflection
//         AnnotatedMethod validBuildMethod = mock(AnnotatedMethod.class);
//         when(validBuildMethod.getRawReturnType()).thenReturn(SomeType.class);
// 
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, validBuildMethod);
// 
        // Mock _collectAliases to return a map with aliases
//         BeanDeserializerBuilder spyBuilder = spy(builder);
//         Map<String, List<PropertyName>> aliases = new HashMap<>();
//         aliases.put("name", Arrays.asList(new PropertyName("alias1"), new PropertyName("alias2")));
//         doReturn(aliases).when(spyBuilder)._collectAliases(any());
// 
        // Prepare valueType
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
        // WHEN
//         JsonDeserializer<?> deserializer = spyBuilder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//     }
// 
//     @Test
//     @DisplayName("Case insensitivity is enabled in configuration")
//     public void TC09_caseInsensitivityEnabled_propertyMapWithCaseInsensitivity() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         DeserializationContext mockContext = mock(DeserializationContext.class);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
// 
        // Set _buildMethod using reflection
//         AnnotatedMethod validBuildMethod = mock(AnnotatedMethod.class);
//         when(validBuildMethod.getRawReturnType()).thenReturn(SomeType.class);
// 
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, validBuildMethod);
// 
        // Mock DeserializationConfig to enable case insensitivity
//         DeserializationConfig mockConfig = mock(DeserializationConfig.class);
//         Field configField = BeanDeserializerBuilder.class.getDeclaredField("_config");
//         configField.setAccessible(true);
//         configField.set(builder, mockConfig);
//         when(mockConfig.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)).thenReturn(true);
// 
        // Mock _findCaseInsensitivity to return true
//         BeanDeserializerBuilder spyBuilder = spy(builder);
//         doReturn(true).when(spyBuilder)._findCaseInsensitivity();
// 
        // Mock _collectAliases to return empty map
//         doReturn(Collections.emptyMap()).when(spyBuilder)._collectAliases(any());
// 
        // Prepare valueType
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
        // WHEN
//         JsonDeserializer<?> deserializer = spyBuilder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//     }
// 
//     @Test
//     @DisplayName("Case insensitivity is disabled in configuration")
//     public void TC10_caseInsensitivityDisabled_propertyMapWithoutCaseInsensitivity() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         DeserializationContext mockContext = mock(DeserializationContext.class);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
// 
        // Set _buildMethod using reflection
//         AnnotatedMethod validBuildMethod = mock(AnnotatedMethod.class);
//         when(validBuildMethod.getRawReturnType()).thenReturn(SomeType.class);
// 
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, validBuildMethod);
// 
        // Mock DeserializationConfig to disable case insensitivity
//         DeserializationConfig mockConfig = mock(DeserializationConfig.class);
//         Field configField = BeanDeserializerBuilder.class.getDeclaredField("_config");
//         configField.setAccessible(true);
//         configField.set(builder, mockConfig);
//         when(mockConfig.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)).thenReturn(false);
// 
        // Mock _findCaseInsensitivity to return false
//         BeanDeserializerBuilder spyBuilder = spy(builder);
//         doReturn(false).when(spyBuilder)._findCaseInsensitivity();
// 
        // Mock _collectAliases to return empty map
//         doReturn(Collections.emptyMap()).when(spyBuilder)._collectAliases(any());
// 
        // Prepare valueType
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
        // WHEN
//         JsonDeserializer<?> deserializer = spyBuilder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//     }
// }
// 
// Supporting classes for testing purposes
// class UnrelatedType {}
// class SomeOtherType {}
// class SomeType {}
}