package org.jfree.data.general;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DatasetUtilsTest {

    @Test
    @DisplayName("Test iterateRangeBounds with null dataset")
    void testIterateRangeBounds_NullDataset() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateRangeBounds(null, true);
        });
        assertEquals("Null 'dataset' argument.", exception.getMessage());
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=false and all Y values NaN")
    void testIterateRangeBounds_NoInterval_AllNaN() {
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(2);
        when(mockDataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, false);
        assertNull(result, "Expected null range when all Y values are NaN");
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=false and some Y values not NaN")
    void testIterateRangeBounds_NoInterval_SomeValid() {
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(2);
        when(mockDataset.getItemCount(0)).thenReturn(2);
        when(mockDataset.getItemCount(1)).thenReturn(2);
        when(mockDataset.getYValue(0, 0)).thenReturn(10.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(mockDataset.getYValue(1, 0)).thenReturn(-5.0);
        when(mockDataset.getYValue(1, 1)).thenReturn(20.0);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, false);
        assertNotNull(result, "Expected non-null range");
        assertEquals(-5.0, result.getLowerBound(), 0.0001);
        assertEquals(20.0, result.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset instanceof IntervalXYDataset with all values NaN")
    void testIterateRangeBounds_WithInterval_AllNaN() {
        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(1);
        when(mockDataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(mockDataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
        when(mockDataset.getEndYValue(0, 0)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNull(result, "Expected null range when all Y values are NaN");
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset instanceof IntervalXYDataset with some valid values")
    void testIterateRangeBounds_WithInterval_SomeValid() {
        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(2);
        when(mockDataset.getYValue(0, 0)).thenReturn(15.0);
        when(mockDataset.getStartYValue(0, 0)).thenReturn(10.0);
        when(mockDataset.getEndYValue(0, 0)).thenReturn(20.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(mockDataset.getStartYValue(0, 1)).thenReturn(5.0);
        when(mockDataset.getEndYValue(0, 1)).thenReturn(25.0);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNotNull(result, "Expected non-null range");
        assertEquals(5.0, result.getLowerBound(), 0.0001);
        assertEquals(25.0, result.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset instanceof IntervalXYDataset with mixed NaN and valid values")
    void testIterateRangeBounds_WithInterval_MixedValid() {
        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(2);
        when(mockDataset.getItemCount(0)).thenReturn(2);
        when(mockDataset.getItemCount(1)).thenReturn(1);
        
        // Series 0, Item 0
        when(mockDataset.getYValue(0, 0)).thenReturn(30.0);
        when(mockDataset.getStartYValue(0, 0)).thenReturn(25.0);
        when(mockDataset.getEndYValue(0, 0)).thenReturn(35.0);
        
        // Series 0, Item 1
        when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(mockDataset.getStartYValue(0, 1)).thenReturn(Double.NaN);
        when(mockDataset.getEndYValue(0, 1)).thenReturn(40.0);
        
        // Series 1, Item 0
        when(mockDataset.getYValue(1, 0)).thenReturn(-10.0);
        when(mockDataset.getStartYValue(1, 0)).thenReturn(-15.0);
        when(mockDataset.getEndYValue(1, 0)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNotNull(result, "Expected non-null range");
        assertEquals(-15.0, result.getLowerBound(), 0.0001);
        assertEquals(40.0, result.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset not instanceof IntervalXYDataset")
    void testIterateRangeBounds_WithInterval_NotInstance() {
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(2);
        when(mockDataset.getYValue(0, 0)).thenReturn(12.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNotNull(result, "Expected non-null range");
        assertEquals(12.0, result.getLowerBound(), 0.0001);
        assertEquals(12.0, result.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset instanceof IntervalXYDataset with no items")
    void testIterateRangeBounds_WithInterval_NoItems() {
        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(0);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNull(result, "Expected null range when there are no items");
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=false and dataset not instanceof IntervalXYDataset with no items")
    void testIterateRangeBounds_NoInterval_NoItems() {
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(0);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, false);
        assertNull(result, "Expected null range when there are no items");
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset instanceof IntervalXYDataset with single non-NaN item")
    void testIterateRangeBounds_WithInterval_SingleValid() {
        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(1);
        when(mockDataset.getYValue(0, 0)).thenReturn(50.0);
        when(mockDataset.getStartYValue(0, 0)).thenReturn(45.0);
        when(mockDataset.getEndYValue(0, 0)).thenReturn(55.0);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNotNull(result, "Expected non-null range");
        assertEquals(45.0, result.getLowerBound(), 0.0001);
        assertEquals(55.0, result.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=false and dataset not instanceof IntervalXYDataset with single NaN item")
    void testIterateRangeBounds_NoInterval_SingleNaN() {
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(1);
        when(mockDataset.getYValue(0, 0)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, false);
        assertNull(result, "Expected null range when the single Y value is NaN");
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset instanceof IntervalXYDataset with mixed series")
    void testIterateRangeBounds_WithInterval_MixedSeries() {
        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(3);
        when(mockDataset.getItemCount(0)).thenReturn(2);
        when(mockDataset.getItemCount(1)).thenReturn(2);
        when(mockDataset.getItemCount(2)).thenReturn(1);
        
        // Series 0, Item 0
        when(mockDataset.getYValue(0, 0)).thenReturn(10.0);
        when(mockDataset.getStartYValue(0, 0)).thenReturn(5.0);
        when(mockDataset.getEndYValue(0, 0)).thenReturn(15.0);
        
        // Series 0, Item 1
        when(mockDataset.getYValue(0, 1)).thenReturn(20.0);
        when(mockDataset.getStartYValue(0, 1)).thenReturn(18.0);
        when(mockDataset.getEndYValue(0, 1)).thenReturn(22.0);
        
        // Series 1, Item 0
        when(mockDataset.getYValue(1, 0)).thenReturn(Double.NaN);
        when(mockDataset.getStartYValue(1, 0)).thenReturn(30.0);
        when(mockDataset.getEndYValue(1, 0)).thenReturn(40.0);
        
        // Series 1, Item 1
        when(mockDataset.getYValue(1, 1)).thenReturn(Double.NaN);
        when(mockDataset.getStartYValue(1, 1)).thenReturn(Double.NaN);
        when(mockDataset.getEndYValue(1, 1)).thenReturn(Double.NaN);
        
        // Series 2, Item 0
        when(mockDataset.getYValue(2, 0)).thenReturn(-10.0);
        when(mockDataset.getStartYValue(2, 0)).thenReturn(-15.0);
        when(mockDataset.getEndYValue(2, 0)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNotNull(result, "Expected non-null range");
        assertEquals(-15.0, result.getLowerBound(), 0.0001);
        assertEquals(40.0, result.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("Test iterateRangeBounds with includeInterval=true and dataset instanceof IntervalXYDataset with no valid Y values")
    void testIterateRangeBounds_WithInterval_NoValidY() {
        IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(2);
        when(mockDataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(mockDataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
        when(mockDataset.getEndYValue(0, 0)).thenReturn(Double.NaN);
        when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(mockDataset.getStartYValue(0, 1)).thenReturn(Double.NaN);
        when(mockDataset.getEndYValue(0, 1)).thenReturn(Double.NaN);

        Range result = DatasetUtils.iterateRangeBounds(mockDataset, true);
        assertNull(result, "Expected null range when all Y, StartY, EndY are NaN");
    }
}