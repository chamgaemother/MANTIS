package org.apache.commons.math3.geometry.euclidean.twod.hull;

import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.Arguments;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class AklToussaintHeuristicTest {

    @Test
    void testReducePointsWithNullInput() {
        assertThrows(NullPointerException.class, () -> AklToussaintHeuristic.reducePoints(null));
    }

    @Test
    void testReducePointsWithEmptyCollection() {
        Collection<Vector2D> input = Collections.emptyList();
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertTrue(result.isEmpty(), "Result should be empty for empty input");
    }

    @Test
    void testReducePointsWithSinglePoint() {
        Vector2D p = new Vector2D(1, 1);
        Collection<Vector2D> input = Collections.singletonList(p);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(1, result.size(), "Result should contain the single input point");
        assertTrue(result.contains(p), "Result should contain the input point");
    }

    @Test
    void testReducePointsWithThreePoints() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(1, 1);
        Vector2D p3 = new Vector2D(2, 0);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(3, result.size(), "Result should contain all input points when size < 4");
        assertTrue(result.containsAll(input), "Result should contain all input points");
    }

    @Test
    void testReducePointsWithFourPointsFormingQuadrilateral() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(0, 2);
        Vector2D p3 = new Vector2D(2, 2);
        Vector2D p4 = new Vector2D(2, 0);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(4, result.size(), "Result should contain all quadrilateral points");
        assertTrue(result.containsAll(input), "Result should contain all quadrilateral points");
    }

    @Test
    void testReducePointsWithPointsInsideQuadrilateral() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(0, 4);
        Vector2D p3 = new Vector2D(4, 4);
        Vector2D p4 = new Vector2D(4, 0);
        Vector2D inside1 = new Vector2D(2, 2);
        Vector2D inside2 = new Vector2D(3, 1);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4, inside1, inside2);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(4, result.size(), "Only quadrilateral points should remain after reduction");
        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4)), "Result should contain all quadrilateral points");
        assertFalse(result.contains(inside1), "Result should not contain points inside the quadrilateral");
        assertFalse(result.contains(inside2), "Result should not contain points inside the quadrilateral");
    }

    @Test
    void testReducePointsWithPointsOnQuadrilateral() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(0, 4);
        Vector2D p3 = new Vector2D(4, 4);
        Vector2D p4 = new Vector2D(4, 0);
        Vector2D onEdge1 = new Vector2D(2, 0);
        Vector2D onEdge2 = new Vector2D(0, 2);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4, onEdge1, onEdge2);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(6, result.size(), "All quadrilateral and edge points should remain");
        assertTrue(result.containsAll(input), "Result should contain all quadrilateral and edge points");
    }

    @Test
    void testReducePointsWithDuplicatePoints() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(0, 0);
        Vector2D p3 = new Vector2D(1, 1);
        Vector2D p4 = new Vector2D(1, 1);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(2, result.size(), "Duplicate points should be removed in quadrilateral");
        assertTrue(result.contains(p1), "Result should contain unique points");
        assertTrue(result.contains(p3), "Result should contain unique points");
    }

    @Test
    void testReducePointsWithDegenerateQuadrilateral() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(0, 0);
        Vector2D p3 = new Vector2D(0, 0);
        Vector2D p4 = new Vector2D(0, 0);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(4, result.size(), "Degenerate quadrilateral should not be reduced");
        assertTrue(result.containsAll(input), "Result should contain all input points");
    }

    @Test
    void testReducePointsWithQuadrilateralSizeLessThanThree() {
        Vector2D p1 = new Vector2D(1, 1);
        Vector2D p2 = new Vector2D(1, 1);
        Vector2D p3 = new Vector2D(1, 1);
        Vector2D p4 = new Vector2D(2, 2);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(4, result.size(), "Quadrilateral with less than three unique points should not be reduced");
        assertTrue(result.containsAll(input), "Result should contain all input points");
    }

    @ParameterizedTest
    @MethodSource("providePointsForMixedCases")
    void testReducePointsWithMixedPoints(List<Vector2D> inputPoints, int expectedSize, List<Vector2D> expectedPoints) {
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(inputPoints);
        assertEquals(expectedSize, result.size(), "Result size mismatch");
        assertTrue(result.containsAll(expectedPoints), "Result does not contain the expected points");
    }

    private static Stream<Arguments> providePointsForMixedCases() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(0, 4);
        Vector2D p3 = new Vector2D(4, 4);
        Vector2D p4 = new Vector2D(4, 0);
        Vector2D inside = new Vector2D(2, 2);
        Vector2D outside = new Vector2D(5, 5);
        Vector2D onEdge = new Vector2D(0, 2);
        Vector2D duplicate = new Vector2D(4, 4);

        return Stream.of(
                Arguments.of(
                        Arrays.asList(p1, p2, p3, p4, inside, outside, onEdge, duplicate),
                        5,
                        Arrays.asList(p1, p2, p3, p4, outside)
                ),
                Arguments.of(
                        Arrays.asList(p1, p2, p3, p4, onEdge),
                        5,
                        Arrays.asList(p1, p2, p3, p4, onEdge)
                ),
                Arguments.of(
                        Arrays.asList(p1, p2, p3, p4, inside, inside),
                        4,
                        Arrays.asList(p1, p2, p3, p4)
                )
        );
    }

    @Test
    void testReducePointsAllPointsInsideQuadrilateral() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(0, 4);
        Vector2D p3 = new Vector2D(4, 4);
        Vector2D p4 = new Vector2D(4, 0);
        Vector2D inside1 = new Vector2D(1, 1);
        Vector2D inside2 = new Vector2D(2, 2);
        Vector2D inside3 = new Vector2D(3, 3);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4, inside1, inside2, inside3);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(4, result.size(), "Only quadrilateral points should remain");
        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4)), "Result should contain all quadrilateral points");
        assertFalse(result.contains(inside1), "Result should not contain points inside the quadrilateral");
        assertFalse(result.contains(inside2), "Result should not contain points inside the quadrilateral");
        assertFalse(result.contains(inside3), "Result should not contain points inside the quadrilateral");
    }

    @Test
    void testReducePointsNoPointsInsideQuadrilateral() {
        Vector2D p1 = new Vector2D(-1, -1);
        Vector2D p2 = new Vector2D(-1, 1);
        Vector2D p3 = new Vector2D(1, 1);
        Vector2D p4 = new Vector2D(1, -1);
        Vector2D outside1 = new Vector2D(-2, -2);
        Vector2D outside2 = new Vector2D(2, 2);
        Collection<Vector2D> input = Arrays.asList(p1, p2, p3, p4, outside1, outside2);
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(input);
        assertEquals(6, result.size(), "All points should remain as no points are inside the quadrilateral");
        assertTrue(result.containsAll(input), "Result should contain all input points");
    }
}