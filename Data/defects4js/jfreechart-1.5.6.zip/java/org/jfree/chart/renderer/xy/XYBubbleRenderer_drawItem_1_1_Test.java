package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.LegendItem;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class XYBubbleRenderer_drawItem_1_1_Test {

//     @Test
//     @DisplayName("drawItem processes item with SCALE_ON_BOTH_AXES scaling and plot orientation VERTICAL")
//     public void TC16_drawItem_with_SCALE_ON_BOTH_AXES_and_VERTICAL_orientation() throws Exception {
        // GIVEN
//         XYBubbleRenderer renderer = new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_BOTH_AXES);
//         XYBubbleRenderer spyRenderer = Mockito.spy(renderer);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYZDataset dataset = mock(XYZDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         when(spyRenderer.getItemVisible(series, item)).thenReturn(true);
//         when(dataset.getZValue(series, item)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
// 
        // Fix based on expected behaviour: setting up mock of info's owner
        // which is required for asserting entity collection in later scenarios.
//         when(info.getOwner()).thenReturn(mock(XYPlot.class));
// 
        // WHEN
//         spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // THEN
//         verify(g2).setPaint(any());
//         verify(g2).fill(any(Ellipse2D.class));
//         verify(g2).setStroke(any());
//         verify(g2).draw(any(Ellipse2D.class));
//         verify(spyRenderer).updateCrosshairValues(eq(crosshairState), anyDouble(), anyDouble(), eq(0), anyDouble(), anyDouble(), eq(PlotOrientation.VERTICAL));
//     }

    @Test
    @DisplayName("drawItem processes item with SCALE_ON_BOTH_AXES scaling and plot orientation HORIZONTAL")
    public void TC17_drawItem_with_SCALE_ON_BOTH_AXES_and_HORIZONTAL_orientation() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_BOTH_AXES);
        XYBubbleRenderer spyRenderer = Mockito.spy(renderer);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(spyRenderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(15.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(75.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(150.0);

        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        verify(g2).setPaint(any());
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).setStroke(any());
        verify(g2).draw(any(Ellipse2D.class));
        verify(spyRenderer).updateCrosshairValues(eq(crosshairState), anyDouble(), anyDouble(), eq(0), anyDouble(), anyDouble(), eq(PlotOrientation.HORIZONTAL));
    }

//     @Test
//     @DisplayName("drawItem adds entity when info and EntityCollection are present and circle intersects dataArea")
//     public void TC18_drawItem_adds_entity_when_circle_intersects_dataArea() throws Exception {
        // GIVEN
//         XYBubbleRenderer renderer = new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS);
//         XYBubbleRenderer spyRenderer = Mockito.spy(renderer);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYZDataset dataset = mock(XYZDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         when(spyRenderer.getItemVisible(series, item)).thenReturn(true);
//         when(dataset.getZValue(series, item)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
//         when(info.getOwner()).thenReturn(mock(XYPlot.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
        // WHEN
//         spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // THEN
//         verify(spyRenderer).addEntity(eq(entities), any(Ellipse2D.class), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }

//     @Test
//     @DisplayName("drawItem does not add entity when info and EntityCollection are present but circle does not intersect dataArea")
//     public void TC19_drawItem_does_not_add_entity_when_circle_does_not_intersect_dataArea() throws Exception {
        // GIVEN
//         XYBubbleRenderer renderer = new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS);
//         XYBubbleRenderer spyRenderer = Mockito.spy(renderer);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYZDataset dataset = mock(XYZDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         when(spyRenderer.getItemVisible(series, item)).thenReturn(true);
//         when(dataset.getZValue(series, item)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
//         when(info.getOwner()).thenReturn(mock(XYPlot.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
        // WHEN
//         spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // THEN
//         verify(spyRenderer, never()).addEntity(any(), any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }

    @Test
    @DisplayName("drawItem processes item with SCALE_ON_DOMAIN_AXIS scaling, plot orientation VERTICAL, and label visible in HORIZONTAL orientation")
    public void TC20_drawItem_setScaleType_VERTICAL_CHANGING_to_HORIZONTAL_orientation_label_view() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS);
        XYBubbleRenderer spyRenderer = Mockito.spy(renderer);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(spyRenderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL, PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);

        // WHEN
        // First draw with label not visible
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        // Second draw with label visible and plot orientation changed to HORIZONTAL
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        verify(g2, times(2)).setPaint(any());
        verify(g2, times(2)).fill(any(Ellipse2D.class));
        verify(g2, times(2)).setStroke(any());
        verify(g2, times(2)).draw(any(Ellipse2D.class));
        verify(spyRenderer, times(1)).drawItemLabel(eq(g2), eq(PlotOrientation.HORIZONTAL), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble(), eq(false));
        verify(spyRenderer).updateCrosshairValues(eq(crosshairState), anyDouble(), anyDouble(), eq(0), anyDouble(), anyDouble(), eq(PlotOrientation.HORIZONTAL));
    }
}