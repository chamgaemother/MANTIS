package org.apache.commons.math3.stat.inference;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import static org.junit.jupiter.api.Assertions.*;

public class KolmogorovSmirnovTest_pelzGood_0_4_Test {

    @Test
    @DisplayName("Input with d=Double.MAX_VALUE and n=Integer.MAX_VALUE to test handling of extreme values")
    void TC16_pelzGood_ExtremeValues() {
        // GIVEN
        double d = Double.MAX_VALUE;
        int n = Integer.MAX_VALUE;

        // WHEN & THEN
        KolmogorovSmirnovTest testInstance = new KolmogorovSmirnovTest();
        assertDoesNotThrow(() -> {
            double result = testInstance.pelzGood(d, n);
            assertTrue(Double.isFinite(result), "Result should be a finite double value without overflow.");
        });
    }

    @Test
    @DisplayName("Input with d=1.0 and n=100000 to verify performance under maximum valid n")
    @Timeout(2) // Ensures the test completes within 2 seconds
    void TC17_pelzGood_MaximumValidN() {
        // GIVEN
        double d = 1.0;
        int n = 100000;

        // WHEN & THEN
        KolmogorovSmirnovTest testInstance = new KolmogorovSmirnovTest();
        assertDoesNotThrow(() -> {
            double result = testInstance.pelzGood(d, n);
            assertTrue(Double.isFinite(result), "Result should be a finite double value computed efficiently.");
        });
    }

    @Test
    @DisplayName("Input with d=1.0 and n=99999 to ensure method does not throw exception prematurely")
    void TC18_pelzGood_NearMaximumN() {
        // GIVEN
        double d = 1.0;
        int n = 99999;

        // WHEN & THEN
        KolmogorovSmirnovTest testInstance = new KolmogorovSmirnovTest();
        assertDoesNotThrow(() -> {
            double result = testInstance.pelzGood(d, n);
            assertTrue(Double.isFinite(result), "Result should be a finite double value without exceptions.");
        });
    }
}