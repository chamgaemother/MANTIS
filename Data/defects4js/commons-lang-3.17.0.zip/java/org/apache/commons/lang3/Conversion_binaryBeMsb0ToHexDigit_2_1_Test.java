package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryBeMsb0ToHexDigit_2_1_Test {

    @Test
    @DisplayName("Returns 'e' when pos >= 3, src[pos-3] is true, src[pos-2] is true, src[pos-1] is true, and src[pos] is false")
    void TC19() {
        boolean[] src = {true, true, true, false};
        int srcPos = 0;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('e', result);
    }

    @Test
    @DisplayName("Returns '2' when pos >= 3, src[pos-3] is false, src[pos-2] is true, src[pos-1] is false, and src[pos] is false")
    void TC20() {
        boolean[] src = {true, false};
        int srcPos = 1;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('2', result);
    }

    @Test
    @DisplayName("Returns '3' when pos >= 3, src[pos-3] is true, src[pos-2] is true, src[pos-1] is false, and src[pos] is true")
    void TC21() {
        boolean[] src = {true, true};
        int srcPos = 1;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('3', result);
    }

    @Test
    @DisplayName("Returns '5' when pos >= 3, src[pos-3] is false, src[pos-2] is true, src[pos-1] is false, and src[pos] is true")
    void TC22() {
        boolean[] src = {false, true, false, true};
        int srcPos = 0;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('5', result);
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when src array is empty and srcPos is 0")
    void TC23() {
        boolean[] src = {};
        int srcPos = 0;
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        });
        assertEquals("Cannot convert an empty array.", exception.getMessage());
    }

}