package org.jsoup.internal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.lang.reflect.Field;
import java.io.IOException;
import java.nio.charset.CharsetDecoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;

public class SimpleStreamReader_read_2_1_Test {

    @Test
    @DisplayName("read is called with multiple bufferUp iterations where each bufferUp returns partial data")
    void TC28_readWithMultiplePartialBufferUpCalls() throws IOException {
        // Arrange - Test setup with input that fills more than the buffer capacity
        char[] buffer = new char[15];
        int off = 0;
        int len = 15;
        InputStream in = new ByteArrayInputStream("HelloWorldPartial".getBytes(StandardCharsets.UTF_8));
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
        
        // Act
        int result = reader.read(buffer, off, len);
        
        // Assert
        assertEquals(15, result, "The number of characters read should be 15");
        assertEquals("HelloWorldParti", new String(buffer, 0, result), "The buffer content should match the partial input string");
    }

    @Test
    @DisplayName("read is called with available bytes exactly filling the buffer, ensuring no bufferUp is called")
    void TC29_readWithExactBufferFill() throws IOException {
        // Arrange
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        byte[] inputBytes = "1234567890".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(inputBytes);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
        
        // Act
        int result = reader.read(buffer, off, len);
        
        // Assert
        assertEquals(10, result, "The number of characters read should be 10");
        assertEquals("1234567890", new String(buffer), "The buffer content should match the input string");
    }

    @Test
    @DisplayName("read is called after decoder has been reset, ensuring decoder state is correct")
    void TC30_readAfterDecoderReset() throws IOException {
        // Arrange
        char[] buffer = new char[5];
        int off = 0;
        int len = 5;
        byte[] inputBytes = "ABCDE".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(inputBytes);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
        // Perform initial read to reset decoder
        reader.read(buffer, off, len);
        
        // Act
        int result = reader.read(buffer, off, len);
        
        // Assert
        assertEquals(-1, result, "The result should be -1 indicating end of stream");
    }

    @Test
    @DisplayName("read is called with byteBuf having remaining data, ensuring no additional bufferUp calls occur")
    void TC31_readWithByteBufRemainingData() throws IOException {
        // Arrange
        char[] buffer = new char[5];
        int off = 0;
        int len = 5;
        byte[] inputBytes = "HelloWorld".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(inputBytes);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
        // Consume part of the stream
        reader.read(buffer, off, len);
        
        // Act
        int result = reader.read(buffer, off, len);
        
        // Assert
        assertEquals(5, result, "The number of characters read should be 5");
        assertEquals("World", new String(buffer, 0, result), "The buffer content should match the remaining input string");
    }

    @Test
    @DisplayName("read encounters multiple overflow conditions in succession, expecting multiple exceptions")
    void TC32_readWithConsecutiveOverflowConditions() throws Exception {
        // Arrange
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        InputStream in = new ByteArrayInputStream(new byte[]{'x', 'y', 'z'});
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
        
        // Mock decoder to always return OVERFLOW
        CharsetDecoder mockDecoder = Mockito.mock(CharsetDecoder.class);
        when(mockDecoder.decode(any(ByteBuffer.class), any(CharBuffer.class), anyBoolean())).thenReturn(java.nio.charset.CoderResult.OVERFLOW);
        
        // Use reflection to set the mock decoder
        Field decoderField = SimpleStreamReader.class.getDeclaredField("decoder");
        decoderField.setAccessible(true);
        decoderField.set(reader, mockDecoder);
        
        // Act & Assert
        assertThrows(IOException.class, () -> {
            reader.read(buffer, off, len);
        }, "An IOException should be thrown due to overflow conditions");
    }
}