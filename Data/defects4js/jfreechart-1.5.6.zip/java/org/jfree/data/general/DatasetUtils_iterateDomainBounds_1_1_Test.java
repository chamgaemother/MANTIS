package org.jfree.data.general;
// 
// import org.jfree.data.Range;
// import org.jfree.data.xy.IntervalXYDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// /**
//  * Test class for DatasetUtils.iterateDomainBounds method.
//  */
public class DatasetUtils_iterateDomainBounds_1_1_Test {
// 
//     /**
//      * Test TC13: iterateDomainBounds with includeInterval=false and multiple series having unordered x-values.
//      */
//     @Test
//     @DisplayName("iterateDomainBounds with includeInterval=false and multiple series having unordered x-values")
//     public void TC13() throws Exception {
        // Arrange
//         XYDataset dataset = new MockXYDataset(
//                 new double[][] { {5.0, 1.0}, {3.0, 4.0} },
//                 new double[][] { {10.0, 20.0}, {30.0, 40.0} }
//         );
//         boolean includeInterval = false;
// 
        // Act
//         Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);
// 
        // Assert
//         assertNotNull(result, "Resulting Range should not be null.");
//         assertEquals(1.0, result.getLowerBound(), 0.0001, "Lower bound should be 1.0.");
//         assertEquals(5.0, result.getUpperBound(), 0.0001, "Upper bound should be 5.0.");
//     }
// 
//     /**
//      * Test TC14: iterateDomainBounds with includeInterval=true and IntervalXYDataset containing overlapping intervals.
//      */
//     @Test
//     @DisplayName("iterateDomainBounds with includeInterval=true and IntervalXYDataset containing overlapping intervals")
//     public void TC14() throws Exception {
        // Arrange
//         IntervalXYDataset dataset = new MockIntervalXYDataset(
//                 new double[][] { {2.0, 4.0}, {3.0, 5.0} },
//                 new double[][] { {1.0, 3.0}, {2.5, 4.5} }, 
//                 new double[][] { {2.5, 4.5}, {3.5, 5.5} }
//         );
//         boolean includeInterval = true;
// 
        // Act
//         Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);
// 
        // Assert
//         assertNotNull(result, "Resulting Range should not be null.");
//         assertEquals(1.0, result.getLowerBound(), 0.0001, "Lower bound should be 1.0.");
//         assertEquals(5.5, result.getUpperBound(), 0.0001, "Upper bound should be 5.5.");
//     }
// 
//     /**
//      * Mock implementation of XYDataset for testing purposes.
//      */
//     private static class MockXYDataset implements XYDataset {
//         private final double[][] xValues;
//         private final double[][] yValues;
// 
//         public MockXYDataset(double[][] xValues, double[][] yValues) {
//             this.xValues = xValues;
//             this.yValues = yValues;
//         }
// 
//         @Override
//         public int getSeriesCount() {
//             return xValues.length;
//         }
// 
//         @Override
//         public Comparable getSeriesKey(int series) {
//             return "Series " + series;
//         }
// 
//         @Override
//         public int indexOf(Comparable seriesKey) {
//             for (int i = 0; i < getSeriesCount(); i++) {
//                 if (getSeriesKey(i).equals(seriesKey)) {
//                     return i;
//                 }
//             }
//             return -1;
//         }
// 
//         @Override
//         public int getItemCount(int series) {
//             return xValues[series].length;
//         }
// 
//         @Override
//         public Number getX(int series, int item) {
//             return xValues[series][item];
//         }
// 
//         @Override
//         public double getXValue(int series, int item) {
//             return xValues[series][item];
//         }
// 
//         @Override
//         public Number getY(int series, int item) {
//             return yValues[series][item];
//         }
// 
//         @Override
//         public double getYValue(int series, int item) {
//             return yValues[series][item];
//         }
// 
//         @Override
//         public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
//             throw new UnsupportedOperationException();
//         }
// 
//         @Override
//         public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
//             throw new UnsupportedOperationException();
//         }
// 
//         @Override
//         public org.jfree.data.DomainOrder getDomainOrder() {
//             return org.jfree.data.DomainOrder.NONE;
//         }
// 
//         @Override
//         public org.jfree.data.Range getDomainBounds(boolean includeInterval) {
//             throw new UnsupportedOperationException();
//         }
// 
//         @Override
//         public org.jfree.data.Range getRangeBounds(boolean includeInterval) {
//             throw new UnsupportedOperationException();
//         }
//     }
// 
//     /**
//      * Mock implementation of IntervalXYDataset for testing purposes.
//      */
//     private static class MockIntervalXYDataset implements IntervalXYDataset {
//         private final double[][] xValues;
//         private final double[][] startXValues;
//         private final double[][] endXValues;
//         private final double[][] yValues;
// 
//         public MockIntervalXYDataset(double[][] xValues, double[][] startXValues, double[][] endXValues) {
//             this.xValues = xValues;
//             this.startXValues = startXValues;
//             this.endXValues = endXValues;
//             this.yValues = new double[xValues.length][];
//             for (int i = 0; i < xValues.length; i++) {
//                 this.yValues[i] = new double[xValues[i].length];
//                 for (int j = 0; j < xValues[i].length; j++) {
//                     this.yValues[i][j] = 0.0;
//                 }
//             }
//         }
// 
//         @Override
//         public int getSeriesCount() {
//             return xValues.length;
//         }
// 
//         @Override
//         public Comparable getSeriesKey(int series) {
//             return "Series " + series;
//         }
// 
//         @Override
//         public int indexOf(Comparable seriesKey) {
//             for (int i = 0; i < getSeriesCount(); i++) {
//                 if (getSeriesKey(i).equals(seriesKey)) {
//                     return i;
//                 }
//             }
//             return -1;
//         }
// 
//         @Override
//         public int getItemCount(int series) {
//             return xValues[series].length;
//         }
// 
//         @Override
//         public Number getX(int series, int item) {
//             return xValues[series][item];
//         }
// 
//         @Override
//         public double getXValue(int series, int item) {
//             return xValues[series][item];
//         }
// 
//         @Override
//         public Number getStartX(int series, int item) {
//             return startXValues[series][item];
//         }
// 
//         @Override
//         public double getStartXValue(int series, int item) {
//             return startXValues[series][item];
//         }
// 
//         @Override
//         public Number getEndX(int series, int item) {
//             return endXValues[series][item];
//         }
// 
//         @Override
//         public double getEndXValue(int series, int item) {
//             return endXValues[series][item];
//         }
// 
//         @Override
//         public Number getY(int series, int item) {
//             return yValues[series][item];
//         }
// 
//         @Override
//         public double getYValue(int series, int item) {
//             return yValues[series][item];
//         }
// 
//         @Override
//         public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
//             throw new UnsupportedOperationException();
//         }
// 
//         @Override
//         public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {
//             throw new UnsupportedOperationException();
//         }
// 
//         @Override
//         public org.jfree.data.DomainOrder getDomainOrder() {
//             return org.jfree.data.DomainOrder.NONE;
//         }
// 
//         @Override
//         public org.jfree.data.Range getDomainBounds(boolean includeInterval) {
//             throw new UnsupportedOperationException();
//         }
// 
//         @Override
//         public org.jfree.data.Range getRangeBounds(boolean includeInterval) {
//             throw new UnsupportedOperationException();
//         }
//     }
// }
}