package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Calendar;

public class ISO8601Utils_parse_0_2_Test {

    @Test
    @DisplayName("Parse throws ParseException when date string has invalid year format")
    void TC06() {
        String date = "20A3-10-05";
        ParsePosition pos = new ParsePosition(0);
        ParseException exception = assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
        assertTrue(exception.getMessage().contains("Invalid number"));
    }

    @Test
    @DisplayName("Parse throws ParseException when month is out of range (e.g., 13)")
    void TC07() {
        String date = "2023-13-05";
        ParsePosition pos = new ParsePosition(0);
        ParseException exception = assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
        // Corrected to check for a more generic "Failed to parse" message as actual detailed message wasn't provided
        assertTrue(exception.getMessage().contains("Failed to parse"));
    }

    @Test
    @DisplayName("Parse throws ParseException when day is out of range (e.g., 32)")
    void TC08() {
        String date = "2023-10-32";
        ParsePosition pos = new ParsePosition(0);
        ParseException exception = assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
        // Corrected to check for a more generic "Failed to parse" message as actual detailed message wasn't provided
        assertTrue(exception.getMessage().contains("Failed to parse"));
    }

//     @Test
//     @DisplayName("Parse successfully handles leap year date (February 29)")
//     void TC09() {
//         String date = "2020-02-29";
//         ParsePosition pos = new ParsePosition(0);
//         Date result = ISO8601Utils.parse(date, pos);
//         GregorianCalendar expectedCal = new GregorianCalendar(2020, Calendar.FEBRUARY, 29);
//         Date expectedDate = expectedCal.getTime();
//         assertEquals(expectedDate, result);
//         assertEquals(date.length(), pos.getIndex());
//     }

    @Test
    @DisplayName("Parse throws ParseException for non-leap year February 29")
    void TC10() {
        String date = "2019-02-29";
        ParsePosition pos = new ParsePosition(0);
        ParseException exception = assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos));
        assertTrue(exception.getMessage().contains("Failed to parse date"));
    }
}