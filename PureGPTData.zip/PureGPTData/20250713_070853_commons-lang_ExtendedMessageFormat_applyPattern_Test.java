import org.apache.commons.lang3.text.ExtendedMessageFormat;
import org.junit.jupiter.api.Test;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ExtendedMessageFormatTest {

    private static class DummyFormatFactory implements ExtendedMessageFormat.FormatFactory {
        @Override
        public Format getFormat(String name, String args, Locale locale) {
            return "dummy".equals(name) ? new SimpleDateFormat("yyyy-MM-dd") : null;
        }
    }

    @Test
    void applyPatternWithNullRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        emf.applyPattern("{0}");
        assertEquals("{0}", emf.toPattern());
    }

    @Test
    void applyPatternWithValidFormat() {
        Map<String, ExtendedMessageFormat.FormatFactory> registry = new HashMap<>();
        registry.put("dummy", new DummyFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,dummy}", Locale.getDefault(), registry);
        emf.applyPattern("{0,dummy}");
        assertEquals("{0,dummy}", emf.toPattern());
    }

    @Test
    void applyPatternWithEmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.getDefault(), null);
        emf.applyPattern("");
        assertEquals("", emf.toPattern());
    }

    @Test
    void applyPatternWithInvalidFormat() {
        Map<String, ExtendedMessageFormat.FormatFactory> registry = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,unknown}", Locale.getDefault(), registry);
        assertDoesNotThrow(() -> emf.applyPattern("{0,unknown}"));
        assertEquals("{0,unknown}", emf.toPattern());
    }

    @Test
    void applyPatternWithNestedFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,choice,0#foo {1,number,integer}|1#bar}", Locale.getDefault());
        assertDoesNotThrow(() -> emf.applyPattern("{0,choice,0#foo {1,number,integer}|1#bar}"));
    }

    @Test
    void applyPatternWithUnterminatedQuotedStringThrows() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'");
        assertThrows(IllegalArgumentException.class, () -> emf.applyPattern("'"));
    }

    @Test
    void applyPatternWithUnterminatedFormatElementThrows() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0");
        assertThrows(IllegalArgumentException.class, () -> emf.applyPattern("{0"));
    }

    @Test
    void applyPatternWithWhitespace() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}  {1}", Locale.getDefault());
        emf.applyPattern("{0}  {1}");
        assertEquals("{0}  {1}", emf.toPattern());
    }

    @Test
    void applyPatternWithInvalidArgumentIndex() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{invalid");
        assertThrows(IllegalArgumentException.class, () -> emf.applyPattern("{invalid"));
    }

    @Test
    void applyPatternOnlyWhitespace() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("   ");
        emf.applyPattern("   ");
        assertEquals("   ", emf.toPattern());
    }
}