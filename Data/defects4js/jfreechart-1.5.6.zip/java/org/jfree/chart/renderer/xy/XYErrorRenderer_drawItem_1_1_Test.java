package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.RectangleEdge;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;

public class XYErrorRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem with drawXError=true, drawYError=false, errorPaint not null, errorStroke null, orientation HORIZONTAL")
    public void testDrawItem_TC14() throws Exception {
        // Arrange
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(true);
        renderer.setDrawYError(false);
        Paint customErrorPaint = mock(Paint.class);
        renderer.setErrorPaint(customErrorPaint);
        renderer.setErrorStroke(null);
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(10.0);
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(200.0);
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = new CrosshairState();
        Rectangle2D dataArea = mock(Rectangle2D.class);
        int series = 0;
        int item = 0;
        int pass = 0;
        XYItemRendererState state = mock(XYItemRendererState.class);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        verify(g2).setPaint(customErrorPaint);
        verify(g2).setStroke(renderer.getItemStroke(series, item));
        verify(g2, times(3)).draw(any(Line2D.class));
        // Y-error bars are not drawn; no additional draw calls expected
    }

    @Test
    @DisplayName("drawItem with drawXError=true, drawYError=false, errorPaint null, errorStroke null, orientation VERTICAL")
    public void testDrawItem_TC15() throws Exception {
        // Arrange
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(true);
        renderer.setDrawYError(false);
        renderer.setErrorPaint(null);
        renderer.setErrorStroke(null);
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(10.0);
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(200.0);
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = new CrosshairState();
        Rectangle2D dataArea = mock(Rectangle2D.class);
        int series = 0;
        int item = 0;
        int pass = 0;
        XYItemRendererState state = mock(XYItemRendererState.class);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        verify(g2).setPaint(renderer.getItemPaint(series, item));
        verify(g2).setStroke(renderer.getItemStroke(series, item));
        verify(g2, times(3)).draw(any(Line2D.class));
        // Y-error bars are not drawn; no additional draw calls expected
    }

    @Test
    @DisplayName("drawItem with drawYError=true, drawXError=false, errorPaint not null, errorStroke not null, orientation VERTICAL")
    public void testDrawItem_TC16() throws Exception {
        // Arrange
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawYError(true);
        renderer.setDrawXError(false);
        Paint customErrorPaint = mock(Paint.class);
        renderer.setErrorPaint(customErrorPaint);
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorStroke(customErrorStroke);
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(15.0);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(10.0);
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(200.0);
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = new CrosshairState();
        Rectangle2D dataArea = mock(Rectangle2D.class);
        int series = 0;
        int item = 0;
        int pass = 0;
        XYItemRendererState state = mock(XYItemRendererState.class);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        verify(g2).setPaint(customErrorPaint);
        verify(g2).setStroke(customErrorStroke);
        verify(g2, times(3)).draw(any(Line2D.class));
        // X-error bars are not drawn; no additional draw calls expected
    }

    @Test
    @DisplayName("drawItem with drawYError=true, drawXError=false, errorPaint null, errorStroke not null, orientation HORIZONTAL")
    public void testDrawItem_TC17() throws Exception {
        // Arrange
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawYError(true);
        renderer.setDrawXError(false);
        renderer.setErrorPaint(null);
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorStroke(customErrorStroke);
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(15.0);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(10.0);
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(200.0);
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = new CrosshairState();
        Rectangle2D dataArea = mock(Rectangle2D.class);
        int series = 0;
        int item = 0;
        int pass = 0;
        XYItemRendererState state = mock(XYItemRendererState.class);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        verify(g2).setPaint(renderer.getItemPaint(series, item));
        verify(g2).setStroke(customErrorStroke);
        verify(g2, times(3)).draw(any(Line2D.class));
        // X-error bars are not drawn; no additional draw calls expected
    }
}