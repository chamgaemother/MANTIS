package org.apache.commons.collections4.iterators;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class PermutationIteratorTest {

    @Test
    @DisplayName("Constructor throws NullPointerException when input collection is null")
    void testConstructorWithNullInput() {
        assertThrows(NullPointerException.class, () -> new PermutationIterator<>(null));
    }

    @Test
    @DisplayName("Next returns the only permutation for an empty collection")
    void testNextWithEmptyCollection() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(Collections.emptyList());
        assertTrue(iterator.hasNext());
        List<Integer> permutation = iterator.next();
        assertTrue(permutation.isEmpty());
        assertFalse(iterator.hasNext());
    }

    @Test
    @DisplayName("Next returns the only permutation for a single-element collection")
    void testNextWithSingleElement() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(Collections.singletonList(1));
        assertTrue(iterator.hasNext());
        List<Integer> permutation = iterator.next();
        assertEquals(Collections.singletonList(1), permutation);
        assertFalse(iterator.hasNext());
    }

    @Test
    @DisplayName("Next returns all permutations for a two-element collection")
    void testNextWithTwoElements() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(Arrays.asList(1, 2));
        assertTrue(iterator.hasNext());
        List<Integer> first = iterator.next();
        assertEquals(Arrays.asList(1, 2), first);
        assertTrue(iterator.hasNext());
        List<Integer> second = iterator.next();
        assertEquals(Arrays.asList(2, 1), second);
        assertFalse(iterator.hasNext());
    }

    @Test
    @DisplayName("Next returns all permutations for a three-element collection")
    void testNextWithThreeElements() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(Arrays.asList(1, 2, 3));
        assertTrue(iterator.hasNext());
        List<Integer> first = iterator.next();
        assertEquals(Arrays.asList(1, 2, 3), first);
        assertTrue(iterator.hasNext());
        List<Integer> second = iterator.next();
        assertEquals(Arrays.asList(1, 3, 2), second);
        assertTrue(iterator.hasNext());
        List<Integer> third = iterator.next();
        assertEquals(Arrays.asList(3, 1, 2), third);
        assertTrue(iterator.hasNext());
        List<Integer> fourth = iterator.next();
        assertEquals(Arrays.asList(3, 2, 1), fourth);
        assertTrue(iterator.hasNext());
        List<Integer> fifth = iterator.next();
        assertEquals(Arrays.asList(2, 3, 1), fifth);
        assertTrue(iterator.hasNext());
        List<Integer> sixth = iterator.next();
        assertEquals(Arrays.asList(2, 1, 3), sixth);
        assertFalse(iterator.hasNext());
    }

    @Test
    @DisplayName("Next throws NoSuchElementException when no more permutations")
    void testNextThrowsNoSuchElementException() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(Arrays.asList(1, 2));
        iterator.next();
        iterator.next();
        assertThrows(NoSuchElementException.class, iterator::next);
    }

    @Test
    @DisplayName("Next handles multiple calls and correctly updates internal state")
    void testNextMultipleCalls() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(Arrays.asList(1, 2, 3));
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, iterator.next());
        expected = Arrays.asList(1, 3, 2);
        assertEquals(expected, iterator.next());
        expected = Arrays.asList(3, 1, 2);
        assertEquals(expected, iterator.next());
        expected = Arrays.asList(3, 2, 1);
        assertEquals(expected, iterator.next());
        expected = Arrays.asList(2, 3, 1);
        assertEquals(expected, iterator.next());
        expected = Arrays.asList(2, 1, 3);
        assertEquals(expected, iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    @DisplayName("Next does not support remove operation")
    void testRemoveUnsupported() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(Arrays.asList(1, 2));
        assertThrows(UnsupportedOperationException.class, iterator::remove);
    }

}