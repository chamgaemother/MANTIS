package org.jfree.chart.plot.dial;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

public class StandardDialScale_draw_0_1_Test {

    @Test
    @DisplayName("draw with minorTickCount <= 0 and minorTickLength <= 0, resulting in no minor tick rectangles being created")
    void TC01_drawWithNoMinorTicks() {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(0, 100, 0, 360, 10, 2);
        scale.setMinorTickCount(0);
        scale.setMinorTickLength(0.0);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // Verify that no minor ticks are drawn
        verify(g2, never()).draw(ArgumentMatchers.any());
    }

    @Test
    @DisplayName("draw with minorTickCount > 0 and minorTickLength > 0, resulting in minor tick rectangles being created")
    void TC02_drawWithMinorTicks() {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(0, 100, 0, 360, 10, 2);
        scale.setMinorTickCount(2);
        scale.setMinorTickLength(5.0);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // Verify that minor ticks are drawn
        verify(g2, atLeastOnce()).draw(ArgumentMatchers.any());
    }

    @Test
    @DisplayName("draw with minorTickCount > 0 but minorTickLength <= 0, resulting in no minor ticks being drawn")
    void TC03_drawWithMinorTicksDisabled() {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(0, 100, 0, 360, 10, 2);
        scale.setMinorTickCount(3);
        scale.setMinorTickLength(0.0);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // Verify that no minor ticks are drawn
        verify(g2, never()).draw(ArgumentMatchers.any());
    }

    @Test
    @DisplayName("draw with upperBound < lowerBound, resulting in zero loop iterations")
    void TC04_drawWithUpperBoundLessThanLowerBound() {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(100, 50, 0, 360, 10, 2);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // Verify that no tick marks are drawn
        verify(g2, never()).draw(ArgumentMatchers.any());
    }

    @Test
    @DisplayName("draw with upperBound equal to lowerBound, resulting in one major tick mark being drawn")
    void TC05_drawWithUpperBoundEqualToLowerBound() {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(100, 100, 0, 360, 10, 2);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // Verify that one major tick mark is drawn
        verify(g2, times(1)).draw(ArgumentMatchers.any());
    }
}