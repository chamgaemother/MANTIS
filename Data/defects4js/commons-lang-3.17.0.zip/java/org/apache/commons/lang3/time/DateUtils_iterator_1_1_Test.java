package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.Iterator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DateUtils_iterator_1_1_Test {
    
    @Test
    @DisplayName("iterator with RANGE_WEEK_CENTER and calendar on Thursday requiring both start and end cutoff adjustments")
    void TC21() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.AUGUST);
        calendar.set(Calendar.DAY_OF_MONTH, 10); // Thursday
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;
        
        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have dates");
        Calendar start = iterator.next();
        assertEquals(Calendar.MONDAY, start.get(Calendar.DAY_OF_WEEK), "Start should be Monday");
        
        // Iterate to the end and verify the last date is Sunday
        Calendar last = start;
        while (iterator.hasNext()) {
            last = iterator.next();
        }
        assertEquals(Calendar.SUNDAY, last.get(Calendar.DAY_OF_WEEK), "End should be Sunday");
    }
    
    @Test
    @DisplayName("iterator with RANGE_WEEK_RELATIVE and calendar on Monday requiring end cutoff adjustment")
    void TC22() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.SEPTEMBER);
        calendar.set(Calendar.DAY_OF_MONTH, 4); // Monday
        int rangeStyle = DateUtils.RANGE_WEEK_RELATIVE;
        
        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have dates");
        Calendar start = iterator.next();
        
        // Assuming RANGE_WEEK_RELATIVE centers the week around the given day
        // Adjusting expected start and end based on implementation details
        // For this example, we'll assume it starts on Monday and ends on Sunday
        assertEquals(Calendar.MONDAY, start.get(Calendar.DAY_OF_WEEK), "Start should be Monday");
        
        // Iterate to the end and verify the last date is Sunday
        Calendar last = start;
        while (iterator.hasNext()) {
            last = iterator.next();
        }
        assertEquals(Calendar.SUNDAY, last.get(Calendar.DAY_OF_WEEK), "End should be Sunday");
    }
    
    @Test
    @DisplayName("iterator with RANGE_WEEK_CENTER and calendar on Sunday requiring full week coverage")
    void TC23() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.OCTOBER);
        calendar.set(Calendar.DAY_OF_MONTH, 1); // Sunday
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;
        
        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have dates");
        Calendar start = iterator.next();
        assertEquals(Calendar.MONDAY, start.get(Calendar.DAY_OF_WEEK), "Start should be Monday");
        
        // Iterate to the end and verify the last date is Sunday
        Calendar last = start;
        while (iterator.hasNext()) {
            last = iterator.next();
        }
        assertEquals(Calendar.SUNDAY, last.get(Calendar.DAY_OF_WEEK), "End should be Sunday");
    }
    
    @Test
    @DisplayName("iterator with RANGE_MONTH_SUNDAY and calendar on last day of month requiring end cutoff adjustment")
    void TC24() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
        calendar.set(Calendar.DAY_OF_MONTH, 28); // Non-leap year, non-Saturday
        int rangeStyle = DateUtils.RANGE_MONTH_SUNDAY;
        
        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have dates");
        Calendar start = iterator.next();
        
        // Assert start is the first day of the month
        Calendar expectedStart = Calendar.getInstance();
        expectedStart.set(Calendar.YEAR, 2023);
        expectedStart.set(Calendar.MONTH, Calendar.FEBRUARY);
        expectedStart.set(Calendar.DAY_OF_MONTH, 1);
        expectedStart.set(Calendar.HOUR_OF_DAY, 0);
        expectedStart.set(Calendar.MINUTE, 0);
        expectedStart.set(Calendar.SECOND, 0);
        expectedStart.set(Calendar.MILLISECOND, 0);
        
        assertEquals(expectedStart.getTime(), start.getTime(), "Start date should be the first of the month");
        
        // Iterate to the end and verify the last date is Saturday
        Calendar last = start;
        while (iterator.hasNext()) {
            last = iterator.next();
        }
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK), "End should be Saturday");
    }
}