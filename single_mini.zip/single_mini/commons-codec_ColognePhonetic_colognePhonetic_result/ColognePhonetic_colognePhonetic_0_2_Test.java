package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_2_Test {

    @Test
    @DisplayName("colognePhonetic handles 'B' correctly when not followed by 'H'")
    void TC06_colognePhonetic_handles_B_correctly_when_not_followed_by_H() throws Exception {
        // Given
        String input = "BACH";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("1", result, "Expected 'B' to be mapped to '1'");
    }

    @Test
    @DisplayName("colognePhonetic handles 'P' followed by 'H' correctly")
    void TC07_colognePhonetic_handles_P_before_H_correctly() throws Exception {
        // Given
        String input = "PHASE";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("3", result, "Expected 'P' before 'H' to be mapped to '3'");
    }

    @Test
    @DisplayName("colognePhonetic collapses multiple consecutive codes correctly")
    void TC08_colognePhonetic_collapses_multiple_consecutive_codes_correctly() throws Exception {
        // Given
        String input = "SSS";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("8", result, "Expected multiple consecutive codes to be collapsed into a single '8'");
    }

    @Test
    @DisplayName("colognePhonetic removes '0's except at the beginning")
    void TC09_colognePhonetic_removes_zeros_except_at_beginning() throws Exception {
        // Given
        String input = "AEIOUY0AEIOUY";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("00", result, "Expected all '0's except at the start to be removed");
    }

    @Test
    @DisplayName("colognePhonetic processes string with 'C' in various contexts correctly")
    void TC10_colognePhonetic_processes_C_in_various_contexts_correctly() throws Exception {
        // Given
        String input = "CAKE";
        ColognePhonetic colognePhonetic = new ColognePhonetic();

        // When
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertEquals("4", result, "Expected 'C' in various contexts to be mapped correctly to '4'");
    }
}