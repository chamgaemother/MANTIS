package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.never;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class DeviationRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem throws ClassCastException when dataset is not an IntervalXYDataset")
    public void TC13_drawItem_WithNonIntervalXYDataset_ThrowsClassCastException() {
        // Arrange
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class); // Not IntervalXYDataset
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Act & Assert
        assertThrows(ClassCastException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("drawItem proceeds without adding coordinates when orientation is neither HORIZONTAL nor VERTICAL")
    public void TC14_drawItem_WithUnknownOrientation_DoesNotAddCoordinates() {
        // Arrange
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        DeviationRenderer.State state = spy(new DeviationRenderer.State(info));
        Rectangle2D dataArea = mock(Rectangle2D.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Mock getItemVisible to return true
        DeviationRenderer rendererSpy = spy(renderer);
        when(rendererSpy.getItemVisible(series, item)).thenReturn(true);

        // Mock plot orientation as UNKNOWN (null)
        when(plot.getOrientation()).thenReturn(null);

        // Act
        rendererSpy.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(state.lowerCoordinates, never()).add(any());
        verify(state.upperCoordinates, never()).add(any());
    }
}