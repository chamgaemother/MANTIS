package org.apache.commons.collections4.map;

import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConcurrentReferenceHashMap_size_0_1_Test {

    private static class MockSegment<K, V> extends ConcurrentReferenceHashMap.Segment<K, V> {
        private int count;
        private int modCount;

        MockSegment(int count, int modCount) {
            super(1.0f);
            this.count = count;
            this.modCount = modCount;
        }

        @Override
        public synchronized void lock() {
            // no lock
        }

        @Override
        public synchronized void unlock() {
            // no unlock
        }

        @Override
        public int count() {
            return this.count;
        }

        public int modCount() {
            return this.modCount;
        }
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() returns 0 when segments have no entries and no concurrent modifications occur")
    public void testSizeReturnsZeroWhenSegmentsAreEmptyWithNoModifications() throws Exception {
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);

        MockSegment<Object, Object>[] segments = new MockSegment[] {
            new MockSegment<>(0, 0),
            new MockSegment<>(0, 0)
        };
        segmentsField.set(map, segments);

        int result = map.size();
        assertEquals(0, result);
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() returns the correct size when segments have some entries with no concurrent modifications")
    public void testSizeReturnsCorrectWhenSegmentsPopulatedAndNoModifications() throws Exception {
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);

        MockSegment<Object, Object>[] segments = new MockSegment[] {
            new MockSegment<>(3, 0),
            new MockSegment<>(2, 0)
        };
        segmentsField.set(map, segments);

        int result = map.size();
        assertEquals(5, result);
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() retries counting due to segment modCounts changing and eventually returns correct size")
    public void testSizeRetriesDueToModCountChanges() throws Exception {
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);

        MockSegment<Object, Object>[] segments = new MockSegment[] {
            new MockSegment<>(3, 1),
            new MockSegment<>(2, 1)
        };
        segmentsField.set(map, segments);

        int result = map.size();
        assertEquals(5, result);
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() locks all segments and computes size when retries exceed RETRIES_BEFORE_LOCK")
    public void testSizeLocksSegmentsWhenRetriesExceed() throws Exception {
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);

        MockSegment<Object, Object>[] segments = new MockSegment[] {
            new MockSegment<>(3, 1),
            new MockSegment<>(2, 1)
        };
        segmentsField.set(map, segments);

        int result = map.size();
        assertEquals(5, result);
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() returns capped Integer.MAX_VALUE on large sums")
    public void testSizeReturnsMaxValueOnLargeSum() throws Exception {
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);

        MockSegment<Object, Object>[] segments = new MockSegment[] {
            new MockSegment<>(Integer.MAX_VALUE, 0),
            new MockSegment<>(Integer.MAX_VALUE, 0)
        };
        segmentsField.set(map, segments);

        int result = map.size();
        assertEquals(Integer.MAX_VALUE, result);
    }
}