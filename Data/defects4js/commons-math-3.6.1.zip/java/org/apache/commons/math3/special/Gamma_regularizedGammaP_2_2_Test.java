package org.apache.commons.math3.special;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Gamma_regularizedGammaP_2_2_Test {

    @Test
    @DisplayName("regularizedGammaP with a = 1.0 and x approaching a + 1 from below tests boundary condition")
    void testTC22() {
        // GIVEN
        double a = 1.0;
        double x = 1.9999999;
        double epsilon = 1e-10;
        int maxIterations = 1000;
        
        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        double expected = 1.0 - Gamma.regularizedGammaQ(a, x, epsilon, maxIterations);
        
        // THEN
        assertEquals(expected, result, 1e-10, "The result should approach 1.0 - regularizedGammaQ(a, x, epsilon, maxIterations)");
    }

    @Test
    @DisplayName("regularizedGammaP with a = 5.0 and x = 5.0 tests behavior when x equals a")
    void testTC23() {
        // GIVEN
        double a = 5.0;
        double x = 5.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;
        
        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        
        // THEN
        assertEquals(0.559506429, result, 1e-9, "The result should approximately equal 0.559506429");
    }

    @Test
    @DisplayName("regularizedGammaP with a = 7.5 and x = 3.5 verifies computation for larger a and x < a + 1")
    void testTC24() {
        // GIVEN
        double a = 7.5;
        double x = 3.5;
        double epsilon = 1e-10;
        int maxIterations = 1000;
        
        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        
        // THEN
        assertEquals(0.0022, result, 1e-7, "The result should approximately equal 0.0022 based on known computation");
    }

    @Test
    @DisplayName("regularizedGammaP with a = 1.5 and x = 2.5 tests intermediate boundary values")
    void testTC25() {
        // GIVEN
        double a = 1.5;
        double x = 2.5;
        double epsilon = 1e-10;
        int maxIterations = 1000;
        
        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        
        // THEN
        assertEquals(0.829340387, result, 1e-9, "The result should approximately equal 0.829340387");
    }
}