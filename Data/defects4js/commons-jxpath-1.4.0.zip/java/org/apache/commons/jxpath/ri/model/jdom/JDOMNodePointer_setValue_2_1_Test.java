package org.apache.commons.jxpath.ri.model.jdom;

import org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jdom.CDATA;
import org.jdom.ProcessingInstruction;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class JDOMNodePointer_setValue_2_1_Test {

    @Test
    @DisplayName("setValue called on a CDATA node throws ClassCastException")
    public void TC16_setValue_With_CDATA_Node_Throws_ClassCastException() {
        // Arrange
        CDATA cdataNode = new CDATA("Sample CDATA");
        JDOMNodePointer pointer = new JDOMNodePointer(cdataNode, null);

        // Act & Assert
        assertThrows(ClassCastException.class, () -> {
            pointer.setValue("New Value");
        });
    }

    @Test
    @DisplayName("setValue called on a ProcessingInstruction node throws ClassCastException")
    public void TC17_setValue_With_ProcessingInstruction_Node_Throws_ClassCastException() {
        // Arrange
        ProcessingInstruction piNode = new ProcessingInstruction("target", "data");
        JDOMNodePointer pointer = new JDOMNodePointer(piNode, null);

        // Act & Assert
        assertThrows(ClassCastException.class, () -> {
            pointer.setValue("New Data");
        });
    }
}