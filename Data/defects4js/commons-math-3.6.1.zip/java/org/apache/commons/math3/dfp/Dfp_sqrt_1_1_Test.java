package org.apache.commons.math3.dfp;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/**
 * JUnit 5 test class for the Dfp.sqrt() method.
 */
public class Dfp_sqrt_1_1_Test {

    /**
     * Test TC17: sqrt() leads to underflow when the result exponent is below MIN_EXP.
     * Expected Result: Underflow flag is set and result is zero.
     */
    @Test
    @DisplayName("sqrt() leads to underflow when the result exponent is below MIN_EXP")
    public void TC17_sqrt_underflow() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);

        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class);
        constructor.setAccessible(true);
        Dfp input = constructor.newInstance(field);

        // Set 'exp' to -32768 to ensure sqrt(input).exp < MIN_EXP
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, -32768);

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0);

        // Set 'mant[mant.length - 1]' to a normalized value
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = (int[]) mantField.get(input);
        mantissa[mantissa.length - 1] = 1000;

        // Set 'sign' to positive
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Access 'field' from result to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField dfpField = (DfpField) fieldField.get(result);

        // Access 'ieeeFlags' from DfpField
        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlags");
        ieeeFlagsField.setAccessible(true);
        int ieeeFlags = ieeeFlagsField.getInt(dfpField);

        // Assert
        assertTrue((ieeeFlags & DfpField.FLAG_UNDERFLOW) != 0, "Underflow flag should be set");
        assertTrue(result.isZero(), "Result should be zero due to underflow");
    }

    /**
     * Test TC18: sqrt() leads to overflow when the result exponent exceeds MAX_EXP.
     * Expected Result: Overflow flag is set and result is infinite.
     */
    @Test
    @DisplayName("sqrt() leads to overflow when the result exponent exceeds MAX_EXP")
    public void TC18_sqrt_overflow() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);

        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class);
        constructor.setAccessible(true);
        Dfp input = constructor.newInstance(field);

        // Set 'exp' to 32769 to ensure sqrt(input).exp > MAX_EXP
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 32769);

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0);

        // Set 'mant[mant.length - 1]' to a normalized value
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = (int[]) mantField.get(input);
        mantissa[mantissa.length - 1] = 1000;

        // Set 'sign' to positive
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Access 'field' from result to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField dfpField = (DfpField) fieldField.get(result);

        // Access 'ieeeFlags' from DfpField
        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlags");
        ieeeFlagsField.setAccessible(true);
        int ieeeFlags = ieeeFlagsField.getInt(dfpField);

        // Assert
        assertTrue((ieeeFlags & DfpField.FLAG_OVERFLOW) != 0, "Overflow flag should be set");
        assertTrue(result.isInfinite(), "Result should be infinite due to overflow");
    }
}