package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TokenQueue_escapeCssIdentifier_0_3_Test {

    @Test
    @DisplayName("Input with only digits, all digits are escaped as codepoints")
    void TC11_escapeCssIdentifier_allDigits() throws Exception {
        String input = "12345";
        String result = org.jsoup.parser.TokenQueue.escapeCssIdentifier(input);
        assertEquals("\\31\\32\\33\\34\\35 ", result);
    }

    @Test
    @DisplayName("Input ends with NULL character, replaces with replacement character")
    void TC12_escapeCssIdentifier_endingNull() throws Exception {
        String input = "abcdef\0";
        String result = org.jsoup.parser.TokenQueue.escapeCssIdentifier(input);
        assertEquals("abcdefï¿½", result);
    }

    @Test
    @DisplayName("Input with hyphen not followed by digit, appends hyphen as is")
    void TC13_escapeCssIdentifier_hyphenNoDigit() throws Exception {
        String input = "-a";
        String result = org.jsoup.parser.TokenQueue.escapeCssIdentifier(input);
        assertEquals("-a", result);
    }
}