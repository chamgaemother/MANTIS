package org.jfree.chart.plot;
// 
// import org.jfree.chart.util.Rotation;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import java.awt.Font;
// import java.lang.reflect.Field;
// import java.util.HashMap;
// import java.util.Objects;
// 
// import static org.junit.jupiter.api.Assertions.assertEquals;
// 
public class PiePlot_hashCode_2_1_Test {
// 
//     /**
//      * Helper method to compute hashCode based on PiePlot's hashCode implementation.
//      *
//      * @param plot The PiePlot instance.
//      * @return The computed hash code.
//      */
//     private int computeExpectedHashCode(PiePlot<?> plot) throws IllegalAccessException {
//         int hash = 7;
//         hash = 73 * hash + plot.hashCode();
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.interiorGap) ^ (Double.doubleToLongBits(plot.interiorGap) >>> 32)));
//         hash = 73 * hash + (plot.circular ? 1 : 0);
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.startAngle) ^ (Double.doubleToLongBits(plot.startAngle) >>> 32)));
//         hash = 73 * hash + Objects.hashCode(plot.direction);
//         hash = 73 * hash + Objects.hashCode(plot.sectionPaintMap);
//         hash = 73 * hash + Objects.hashCode(plot.defaultSectionPaint);
//         hash = 73 * hash + (plot.autoPopulateSectionPaint ? 1 : 0);
//         hash = 73 * hash + (plot.sectionOutlinesVisible ? 1 : 0);
//         hash = 73 * hash + Objects.hashCode(plot.sectionOutlinePaintMap);
//         hash = 73 * hash + Objects.hashCode(plot.defaultSectionOutlinePaint);
//         hash = 73 * hash + (plot.autoPopulateSectionOutlinePaint ? 1 : 0);
//         hash = 73 * hash + Objects.hashCode(plot.sectionOutlineStrokeMap);
//         hash = 73 * hash + Objects.hashCode(plot.defaultSectionOutlineStroke);
//         hash = 73 * hash + (plot.autoPopulateSectionOutlineStroke ? 1 : 0);
//         hash = 73 * hash + Objects.hashCode(plot.shadowPaint);
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.shadowXOffset) ^ (Double.doubleToLongBits(plot.shadowXOffset) >>> 32)));
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.shadowYOffset) ^ (Double.doubleToLongBits(plot.shadowYOffset) >>> 32)));
//         hash = 73 * hash + Objects.hashCode(plot.explodePercentages);
//         hash = 73 * hash + Objects.hashCode(plot.labelGenerator);
//         hash = 73 * hash + Objects.hashCode(plot.labelFont);
//         hash = 73 * hash + Objects.hashCode(plot.labelPaint);
//         hash = 73 * hash + Objects.hashCode(plot.labelBackgroundPaint);
//         hash = 73 * hash + Objects.hashCode(plot.labelOutlinePaint);
//         hash = 73 * hash + Objects.hashCode(plot.labelOutlineStroke);
//         hash = 73 * hash + Objects.hashCode(plot.labelShadowPaint);
//         hash = 73 * hash + (plot.simpleLabels ? 1 : 0);
//         hash = 73 * hash + Objects.hashCode(plot.labelPadding);
//         hash = 73 * hash + Objects.hashCode(plot.simpleLabelOffset);
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.maximumLabelWidth) ^ (Double.doubleToLongBits(plot.maximumLabelWidth) >>> 32)));
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.labelGap) ^ (Double.doubleToLongBits(plot.labelGap) >>> 32)));
//         hash = 73 * hash + (plot.labelLinksVisible ? 1 : 0);
//         hash = 73 * hash + Objects.hashCode(plot.labelLinkStyle);
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.labelLinkMargin) ^ (Double.doubleToLongBits(plot.labelLinkMargin) >>> 32)));
//         hash = 73 * hash + Objects.hashCode(plot.labelLinkPaint);
//         hash = 73 * hash + Objects.hashCode(plot.labelLinkStroke);
//         hash = 73 * hash + Objects.hashCode(plot.toolTipGenerator);
//         hash = 73 * hash + Objects.hashCode(plot.urlGenerator);
//         hash = 73 * hash + Objects.hashCode(plot.legendLabelGenerator);
//         hash = 73 * hash + Objects.hashCode(plot.legendLabelToolTipGenerator);
//         hash = 73 * hash + Objects.hashCode(plot.legendLabelURLGenerator);
//         hash = 73 * hash + (plot.ignoreNullValues ? 1 : 0);
//         hash = 73 * hash + (plot.ignoreZeroValues ? 1 : 0);
//         hash = 73 * hash + Objects.hashCode(plot.legendItemShape);
//         hash = 73 * hash + ((int) (Double.doubleToLongBits(plot.minimumArcAngleToDraw) ^ (Double.doubleToLongBits(plot.minimumArcAngleToDraw) >>> 32)));
//         hash = 73 * hash + Objects.hashCode(plot.shadowGenerator);
//         return hash;
//     }
// 
//     /**
//      * Test TC12: hashCode with sectionPaintMap as null and other boolean fields true
//      */
//     @Test
//     @DisplayName("hashCode with sectionPaintMap as null and other boolean fields true")
//     void test_TC12_hashCode_sectionPaintMap_null() throws Exception {
        // GIVEN
//         PiePlot<String> plot = new PiePlot<>();
// 
        // Using reflection to set sectionPaintMap to null
//         Field sectionPaintMapField = PiePlot.class.getDeclaredField("sectionPaintMap");
//         sectionPaintMapField.setAccessible(true);
//         sectionPaintMapField.set(plot, null);
// 
        // Setting other boolean fields to true
//         plot.setAutoPopulateSectionPaint(true);
//         plot.setSectionOutlinesVisible(true);
//         plot.setAutoPopulateSectionOutlinePaint(true);
//         plot.setAutoPopulateSectionOutlineStroke(true);
//         plot.setCircular(true);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(true);
//         plot.setSimpleLabels(true);
//         plot.setLabelLinksVisible(true);
// 
        // Setting other necessary fields to default values
//         plot.setLabelFont(PiePlot.DEFAULT_LABEL_FONT);
//         plot.setLabelPaint(PiePlot.DEFAULT_LABEL_PAINT);
//         plot.setLabelBackgroundPaint(PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT);
//         plot.setLabelOutlinePaint(PiePlot.DEFAULT_LABEL_OUTLINE_PAINT);
//         plot.setLabelOutlineStroke(PiePlot.DEFAULT_LABEL_OUTLINE_STROKE);
//         plot.setLabelShadowPaint(PiePlot.DEFAULT_LABEL_SHADOW_PAINT);
//         plot.setLegendItemShape(PiePlot.DEFAULT_LEGEND_ITEM_CIRCLE);
//         plot.setMinimumArcAngleToDraw(PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW);
// 
        // Initialize other fields if necessary
//         Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
//         explodePercentagesField.setAccessible(true);
//         explodePercentagesField.set(plot, new HashMap<>());
// 
        // WHEN
//         int computedHashCode = plot.hashCode();
//         int expectedHashCode = computeExpectedHashCode(plot);
// 
        // THEN
//         assertEquals(expectedHashCode, computedHashCode, "hashCode should be correctly computed without sectionPaintMap");
//     }
// 
//     /**
//      * Test TC13: hashCode with sectionOutlinePaintMap as null and other boolean fields true
//      */
//     @Test
//     @DisplayName("hashCode with sectionOutlinePaintMap as null and other boolean fields true")
//     void test_TC13_hashCode_sectionOutlinePaintMap_null() throws Exception {
        // GIVEN
//         PiePlot<String> plot = new PiePlot<>();
// 
        // Using reflection to set sectionOutlinePaintMap to null
//         Field sectionOutlinePaintMapField = PiePlot.class.getDeclaredField("sectionOutlinePaintMap");
//         sectionOutlinePaintMapField.setAccessible(true);
//         sectionOutlinePaintMapField.set(plot, null);
// 
        // Setting other boolean fields to true
//         plot.setAutoPopulateSectionOutlinePaint(true);
//         plot.setSectionOutlinesVisible(true);
//         plot.setAutoPopulateSectionPaint(true);
//         plot.setAutoPopulateSectionOutlineStroke(true);
//         plot.setCircular(true);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(true);
//         plot.setSimpleLabels(true);
//         plot.setLabelLinksVisible(true);
// 
        // Setting other necessary fields to default values
//         plot.setLabelFont(PiePlot.DEFAULT_LABEL_FONT);
//         plot.setLabelPaint(PiePlot.DEFAULT_LABEL_PAINT);
//         plot.setLabelBackgroundPaint(PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT);
//         plot.setLabelOutlinePaint(PiePlot.DEFAULT_LABEL_OUTLINE_PAINT);
//         plot.setLabelOutlineStroke(PiePlot.DEFAULT_LABEL_OUTLINE_STROKE);
//         plot.setLabelShadowPaint(PiePlot.DEFAULT_LABEL_SHADOW_PAINT);
//         plot.setLegendItemShape(PiePlot.DEFAULT_LEGEND_ITEM_CIRCLE);
//         plot.setMinimumArcAngleToDraw(PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW);
// 
        // Initialize other fields if necessary
//         Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
//         explodePercentagesField.setAccessible(true);
//         explodePercentagesField.set(plot, new HashMap<>());
// 
        // WHEN
//         int computedHashCode = plot.hashCode();
//         int expectedHashCode = computeExpectedHashCode(plot);
// 
        // THEN
//         assertEquals(expectedHashCode, computedHashCode, "hashCode should be correctly computed without sectionOutlinePaintMap");
//     }
// 
//     /**
//      * Test TC14: hashCode with sectionOutlineStrokeMap as null and other boolean fields true
//      */
//     @Test
//     @DisplayName("hashCode with sectionOutlineStrokeMap as null and other boolean fields true")
//     void test_TC14_hashCode_sectionOutlineStrokeMap_null() throws Exception {
        // GIVEN
//         PiePlot<String> plot = new PiePlot<>();
// 
        // Using reflection to set sectionOutlineStrokeMap to null
//         Field sectionOutlineStrokeMapField = PiePlot.class.getDeclaredField("sectionOutlineStrokeMap");
//         sectionOutlineStrokeMapField.setAccessible(true);
//         sectionOutlineStrokeMapField.set(plot, null);
// 
        // Setting other boolean fields to true
//         plot.setAutoPopulateSectionOutlineStroke(true);
//         plot.setSectionOutlinesVisible(true);
//         plot.setAutoPopulateSectionPaint(true);
//         plot.setAutoPopulateSectionOutlinePaint(true);
//         plot.setCircular(true);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(true);
//         plot.setSimpleLabels(true);
//         plot.setLabelLinksVisible(true);
// 
        // Setting other necessary fields to default values
//         plot.setLabelFont(PiePlot.DEFAULT_LABEL_FONT);
//         plot.setLabelPaint(PiePlot.DEFAULT_LABEL_PAINT);
//         plot.setLabelBackgroundPaint(PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT);
//         plot.setLabelOutlinePaint(PiePlot.DEFAULT_LABEL_OUTLINE_PAINT);
//         plot.setLabelOutlineStroke(PiePlot.DEFAULT_LABEL_OUTLINE_STROKE);
//         plot.setLabelShadowPaint(PiePlot.DEFAULT_LABEL_SHADOW_PAINT);
//         plot.setLegendItemShape(PiePlot.DEFAULT_LEGEND_ITEM_CIRCLE);
//         plot.setMinimumArcAngleToDraw(PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW);
// 
        // Initialize other fields if necessary
//         Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
//         explodePercentagesField.setAccessible(true);
//         explodePercentagesField.set(plot, new HashMap<>());
// 
        // WHEN
//         int computedHashCode = plot.hashCode();
//         int expectedHashCode = computeExpectedHashCode(plot);
// 
        // THEN
//         assertEquals(expectedHashCode, computedHashCode, "hashCode should be correctly computed without sectionOutlineStrokeMap");
//     }
// 
//     /**
//      * Test TC15: hashCode with simpleLabels=false and all boolean fields true
//      */
//     @Test
//     @DisplayName("hashCode with simpleLabels=false and all boolean fields true")
//     void test_TC15_hashCode_simpleLabels_false() throws Exception {
        // GIVEN
//         PiePlot<String> plot = new PiePlot<>();
// 
        // Setting simpleLabels to false
//         plot.setSimpleLabels(false);
// 
        // Setting all boolean fields to true
//         plot.setAutoPopulateSectionPaint(true);
//         plot.setSectionOutlinesVisible(true);
//         plot.setAutoPopulateSectionOutlinePaint(true);
//         plot.setAutoPopulateSectionOutlineStroke(true);
//         plot.setCircular(true);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(true);
//         plot.setLabelLinksVisible(true);
// 
        // Setting other necessary fields to default values
//         plot.setLabelFont(PiePlot.DEFAULT_LABEL_FONT);
//         plot.setLabelPaint(PiePlot.DEFAULT_LABEL_PAINT);
//         plot.setLabelBackgroundPaint(PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT);
//         plot.setLabelOutlinePaint(PiePlot.DEFAULT_LABEL_OUTLINE_PAINT);
//         plot.setLabelOutlineStroke(PiePlot.DEFAULT_LABEL_OUTLINE_STROKE);
//         plot.setLabelShadowPaint(PiePlot.DEFAULT_LABEL_SHADOW_PAINT);
//         plot.setLegendItemShape(PiePlot.DEFAULT_LEGEND_ITEM_CIRCLE);
//         plot.setMinimumArcAngleToDraw(PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW);
// 
        // Initialize other fields if necessary
//         Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
//         explodePercentagesField.setAccessible(true);
//         explodePercentagesField.set(plot, new HashMap<>());
// 
        // WHEN
//         int computedHashCode = plot.hashCode();
//         int expectedHashCode = computeExpectedHashCode(plot);
// 
        // THEN
//         assertEquals(expectedHashCode, computedHashCode, "hashCode should be correctly computed with simpleLabels=false");
//     }
// 
//     /**
//      * Test TC16: hashCode with labelLinkPaint as null and other fields true
//      */
//     @Test
//     @DisplayName("hashCode with labelLinkPaint as null and other fields true")
//     void test_TC16_hashCode_labelLinkPaint_null() throws Exception {
        // GIVEN
//         PiePlot<String> plot = new PiePlot<>();
// 
        // Using reflection to set labelLinkPaint to null
//         Field labelLinkPaintField = PiePlot.class.getDeclaredField("labelLinkPaint");
//         labelLinkPaintField.setAccessible(true);
//         labelLinkPaintField.set(plot, null);
// 
        // Setting all boolean fields to true
//         plot.setAutoPopulateSectionPaint(true);
//         plot.setSectionOutlinesVisible(true);
//         plot.setAutoPopulateSectionOutlinePaint(true);
//         plot.setAutoPopulateSectionOutlineStroke(true);
//         plot.setLabelLinksVisible(true);
//         plot.setCircular(true);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(true);
//         plot.setSimpleLabels(true);
// 
        // Setting other necessary fields to default values
//         plot.setLabelFont(PiePlot.DEFAULT_LABEL_FONT);
//         plot.setLabelPaint(PiePlot.DEFAULT_LABEL_PAINT);
//         plot.setLabelBackgroundPaint(PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT);
//         plot.setLabelOutlinePaint(PiePlot.DEFAULT_LABEL_OUTLINE_PAINT);
//         plot.setLabelOutlineStroke(PiePlot.DEFAULT_LABEL_OUTLINE_STROKE);
//         plot.setLabelShadowPaint(PiePlot.DEFAULT_LABEL_SHADOW_PAINT);
//         plot.setLegendItemShape(PiePlot.DEFAULT_LEGEND_ITEM_CIRCLE);
//         plot.setMinimumArcAngleToDraw(PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW);
// 
        // Initialize other fields if necessary
//         Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
//         explodePercentagesField.setAccessible(true);
//         explodePercentagesField.set(plot, new HashMap<>());
// 
        // WHEN
//         int computedHashCode = plot.hashCode();
//         int expectedHashCode = computeExpectedHashCode(plot);
// 
        // THEN
//         assertEquals(expectedHashCode, computedHashCode, "hashCode should be correctly computed with labelLinkPaint as null");
//     }
// 
// }
}