package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class Flat3Map_put_0_4_Test {

    @Test
    @DisplayName("put with key having same hashCode as key2 but different equals does not update key2")
    public void TC16_putKeyCollisionDoesNotUpdateKey2() throws Exception {
        // GIVEN
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("Key1", "Value1");
        map.put("Key2", "Value2");
        String key = "KeyCollision2"; // Same hashCode as "Key2"
        String value = "ValueCollision2";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        assertNull(result);
        assertEquals(3, map.size());

        // Using reflection to access key3
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object key3 = key3Field.get(map);
        assertEquals(key, key3);
    }

    @Test
    @DisplayName("put with key having same hashCode and equals to key2 updates value2")
    public void TC17_putKeyCollisionUpdatesValue2() throws Exception {
        // GIVEN
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("Key1", "Value1");
        map.put("Key2", "Value2");
        String key = new String("Key2"); // Same hashCode and equals to "Key2"
        String value = "Value2Updated";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        assertEquals("Value2", result);
        assertEquals(2, map.size());

        // Using reflection to access value2
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = value2Field.get(map);
        assertEquals("Value2Updated", value2);
    }

    @Test
    @DisplayName("put when delegateMap is not null and delegateMap.put returns a value")
    public void TC18_putWithDelegateMap() throws Exception {
        // GIVEN
        AbstractHashedMap<String, String> delegate = new AbstractHashedMap<>();
        delegate.put("Key1", "Value1");
        Flat3Map<String, String> map = new Flat3Map<>(delegate);
        String key = "Key1";
        String value = "Value1Updated";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        assertEquals("Value1", result);
        assertEquals("Value1Updated", delegate.get("Key1"));
    }
}