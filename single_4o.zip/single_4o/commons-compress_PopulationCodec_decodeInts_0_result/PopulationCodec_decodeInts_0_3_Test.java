package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class PopulationCodec_decodeInts_0_3_Test {

    @Test
    @DisplayName("Tests when all loop iterations are completed without exceptions or breaks")
    void testCompleteLoop() throws Exception {
        // Arrange
        Codec favouredCodec = new Codec() {
            public int decode(final InputStream in, final long last) throws IOException {
                return 1; // simple stub implementation
            }

            public int decode(final InputStream in) throws IOException, Pack200Exception {
                return 1;
            }

            public int[] decodeInts(final int n, final InputStream in) {
                return new int[n]; // stub implementation for testing
            }

            public byte[] encode(final int[] values) {
                return new byte[values.length]; // stub for testing
            }
        };

        Codec unfavouredCodec = favouredCodec; // using the same codec for simplicity
        PopulationCodec populationCodec = new PopulationCodec(favouredCodec, 1, unfavouredCodec);
        int n = 10;
        InputStream in = new ByteArrayInputStream(new byte[]{1, 2, 3, 4, 5}); // simplified byte data

        // Act
        int[] result = populationCodec.decodeInts(n, in);

        // Assert
        assertNotNull(result, "Result should not be null");  
    }

    @Test
    @DisplayName("Verifies tokenCodec is reused when non-null in subsequent calls")
    void testTokenCodecReuse() throws Exception {
        // Arrange
        Codec favouredCodec = new Codec() {
            public int decode(final InputStream in, final long last) throws IOException {
                return 1; // simple stub implementation
            }

            public int decode(final InputStream in) throws IOException, Pack200Exception {
                return 1;
            }

            public int[] decodeInts(final int n, final InputStream in) {
                return new int[n]; // stub implementation for testing
            }

            public byte[] encode(final int[] values) {
                return new byte[values.length]; // stub for testing
            }
        };

        Codec unfavouredCodec = favouredCodec; // using the same codec for simplicity
        PopulationCodec populationCodec = new PopulationCodec(favouredCodec, 1, unfavouredCodec);

        // First call to establish tokenCodec
        int n = 10;
        InputStream in1 = new ByteArrayInputStream(new byte[]{1, 2, 3, 4, 5});
        populationCodec.decodeInts(n, in1);

        // Reflection to access the private field 'tokenCodec'
        Field tokenCodecField = PopulationCodec.class.getDeclaredField("tokenCodec");
        tokenCodecField.setAccessible(true);

        Codec initialTokenCodec = (Codec) tokenCodecField.get(populationCodec);
        assertNotNull(initialTokenCodec, "tokenCodec must be set after first decodeInts call");

        // Second call to reuse tokenCodec
        InputStream in2 = new ByteArrayInputStream(new byte[]{1, 2, 3, 4, 5});
        int[] result = populationCodec.decodeInts(n, in2);

        // Check for reuse of the same tokenCodec
        Codec reusedTokenCodec = (Codec) tokenCodecField.get(populationCodec);

        // Assert
        assertSame(initialTokenCodec, reusedTokenCodec, "tokenCodec should be reused, not recomputed");
        assertNotNull(result, "Result should not be null");
    }
}
