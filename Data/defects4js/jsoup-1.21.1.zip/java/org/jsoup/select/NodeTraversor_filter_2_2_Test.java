package org.jsoup.select;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeFilter;
import org.jsoup.select.NodeTraversor;
import org.jsoup.select.NodeFilter.FilterResult;

public class NodeTraversor_filter_2_2_Test {

    @Test
    @DisplayName("filter throws exception when filter is null")
    void TC28_filterThrowsExceptionWhenFilterIsNull() {
        // GIVEN
        Node root = new Element("root");
        NodeFilter filter = null;

        // WHEN & THEN
        Assertions.assertThrows(NullPointerException.class, () -> {
            NodeTraversor.filter(filter, root);
        });
    }

    @Test
    @DisplayName("filter handles nested children with varying filter results")
    void TC29_filterHandlesNestedChildrenWithVaryingFilterResults() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element grandchild1 = new Element("grandchild1");
        child2.appendChild(grandchild1);
        root.appendChild(child1);
        root.appendChild(child2);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                if (node.equals(child1)) {
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        Assertions.assertFalse(root.children().contains(child1), "child1 should be removed");
        Assertions.assertTrue(root.children().contains(child2), "child2 should remain");
        Assertions.assertTrue(child2.children().contains(grandchild1), "grandchild1 should remain");
        Assertions.assertEquals(FilterResult.CONTINUE, result, "Traversal should complete with CONTINUE");
    }

    @Test
    @DisplayName("filter handles multiple REMOVEs in succession during traversal")
    void TC30_filterHandlesMultipleRemovesInSuccessionDuringTraversal() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element child3 = new Element("child3");
        root.appendChild(child1);
        root.appendChild(child2);
        root.appendChild(child3);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.REMOVE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        Assertions.assertEquals(0, root.childNodeSize(), "All children should be removed from root");
        Assertions.assertEquals(FilterResult.CONTINUE, result, "Traversal should exit with CONTINUE");
    }

    @Test
    @DisplayName("filter handles tail processing after all children are processed")
    void TC31_filterHandlesTailProcessingAfterAllChildrenAreProcessed() {
        // GIVEN
        Element root = new Element("root"); // No children and no siblings

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        // Since there are no children, tail should be processed correctly
        Assertions.assertEquals(FilterResult.CONTINUE, result, "Traversal should return CONTINUE");
    }
}