import org.jfree.chart.plot.CompassPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.mock;

public class CompassPlotTest {

    private CompassPlot compassPlot;
    private Graphics2D graphics;
    private Rectangle2D area;
    private PlotState plotState;
    private PlotRenderingInfo plotRenderingInfo;

    @BeforeEach
    public void setUp() {
        compassPlot = new CompassPlot(new DefaultValueDataset(45.0));
        graphics = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 800, 600); // typical size for a chart area
        plotState = new PlotState();
        plotRenderingInfo = new PlotRenderingInfo(null);
    }

    @Test
    public void testDrawWithNullDataset() {
        CompassPlot plotWithNullDataset = new CompassPlot(null);
        plotWithNullDataset.draw(graphics, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithNonNullDataset() {
        compassPlot.draw(graphics, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithDrawBorderTrue() {
        compassPlot.setDrawBorder(true);
        compassPlot.draw(graphics, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithMultipleDatasets() {
        ValueDataset dataset1 = new DefaultValueDataset(45.0);
        ValueDataset dataset2 = new DefaultValueDataset(90.0);
        compassPlot = new CompassPlot(dataset1);
        compassPlot.addDataset(dataset2);
        compassPlot.draw(graphics, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithEmptyArea() {
        Rectangle2D emptyArea = new Rectangle2D.Double(0, 0, 0, 0);
        compassPlot.draw(graphics, emptyArea, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithNegativeValues() {
        ValueDataset dataset = new DefaultValueDataset(-45.0);
        compassPlot = new CompassPlot(dataset);
        compassPlot.draw(graphics, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithZeroValues() {
        ValueDataset dataset = new DefaultValueDataset(0.0);
        compassPlot = new CompassPlot(dataset);
        compassPlot.draw(graphics, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithNullGraphics() {
        compassPlot.draw(null, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithRevolutionDistance() {
        ValueDataset dataset = new DefaultValueDataset(90.0);
        compassPlot = new CompassPlot(dataset);
        compassPlot.setRevolutionDistance(90.0);
        compassPlot.draw(graphics, area, null, plotState, plotRenderingInfo);
    }

    @Test
    public void testDrawWithNullRenderingInfo() {
        compassPlot.draw(graphics, area, null, plotState, null);
    }
}