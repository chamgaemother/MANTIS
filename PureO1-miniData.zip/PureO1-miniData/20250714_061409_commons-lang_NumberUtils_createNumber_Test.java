package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Objects;

import org.junit.jupiter.api.Test;

public class NumberUtilsTest {

    @Test
    void testCreateNumber_NullInput_ReturnsNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumber_BlankInput_ThrowsException() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("   "));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("\t\n"));
    }

    @Test
    void testCreateNumber_EmptyString_ThrowsException() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(""));
    }

    @Test
    void testCreateNumber_Integer_ReturnsInteger() {
        Number result = NumberUtils.createNumber("123");
        assertTrue(result instanceof Integer);
        assertEquals(123, result.intValue());
    }

    @Test
    void testCreateNumber_NegativeInteger_ReturnsInteger() {
        Number result = NumberUtils.createNumber("-456");
        assertTrue(result instanceof Integer);
        assertEquals(-456, result.intValue());
    }

    @Test
    void testCreateNumber_HexadecimalInteger_ReturnsInteger() {
        Number result = NumberUtils.createNumber("0x1A");
        assertTrue(result instanceof Integer);
        assertEquals(26, result.intValue());
    }

    @Test
    void testCreateNumber_HexadecimalLong_ReturnsLong() {
        String hexLong = "0x123456789";
        Number result = NumberUtils.createNumber(hexLong);
        assertTrue(result instanceof Long);
        assertEquals(0x123456789L, result.longValue());
    }

    @Test
    void testCreateNumber_HexadecimalBigInteger_ReturnsBigInteger() {
        String hexBig = "0x123456789ABCDEF123456789ABCDEF";
        Number result = NumberUtils.createNumber(hexBig);
        assertTrue(result instanceof BigInteger);
        assertEquals(new BigInteger("123456789ABCDEF123456789ABCDEF", 16), result);
    }

    @Test
    void testCreateNumber_TooLargeForIntegerButFitsLong_ReturnsLong() {
        String longStr = "2147483648"; // Integer.MAX_VALUE + 1
        Number result = NumberUtils.createNumber(longStr);
        assertTrue(result instanceof Long);
        assertEquals(2147483648L, result.longValue());
    }

    @Test
    void testCreateNumber_TooLargeForLong_ReturnsBigInteger() {
        String bigIntStr = "9223372036854775808"; // Long.MAX_VALUE + 1
        Number result = NumberUtils.createNumber(bigIntStr);
        assertTrue(result instanceof BigInteger);
        assertEquals(new BigInteger("9223372036854775808"), result);
    }

    @Test
    void testCreateNumber_OctalValid_ReturnsInteger() {
        Number result = NumberUtils.createNumber("0777");
        assertTrue(result instanceof Integer);
        assertEquals(511, result.intValue());
    }

    @Test
    void testCreateNumber_OctalInvalid_ThrowsException() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("09"));
    }

    @Test
    void testCreateNumber_FloatingPoint_ReturnsDouble() {
        Number result = NumberUtils.createNumber("123.45");
        assertTrue(result instanceof Double);
        assertEquals(123.45, result.doubleValue());
    }

    @Test
    void testCreateNumber_DoubleSuffix_ReturnsDouble() {
        Number result = NumberUtils.createNumber("123.45d");
        assertTrue(result instanceof Double);
        assertEquals(123.45, result.doubleValue());
    }

    @Test
    void testCreateNumber_FloatSuffix_ReturnsFloat() {
        Number result = NumberUtils.createNumber("123.45f");
        assertTrue(result instanceof Float);
        assertEquals(123.45f, result.floatValue());
    }

    @Test
    void testCreateNumber_LongSuffix_ReturnsLong() {
        Number result = NumberUtils.createNumber("123L");
        assertTrue(result instanceof Long);
        assertEquals(123L, result.longValue());
    }

    @Test
    void testCreateNumber_InvalidNumber_ThrowsException() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("abc"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1a2"));
    }

    @Test
    void testCreateNumber_DoubleWithExponent_ReturnsDouble() {
        Number result = NumberUtils.createNumber("1.23e4");
        assertTrue(result instanceof Double);
        assertEquals(12300.0, result.doubleValue());
    }

    @Test
    void testCreateNumber_MultipleDecimalPoints_ThrowsException() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.2.3"));
    }

    @Test
    void testCreateNumber_SingleZero_ReturnsInteger() {
        Number result = NumberUtils.createNumber("0");
        assertTrue(result instanceof Integer);
        assertEquals(0, result.intValue());
    }

    @Test
    void testCreateNumber_SingleNegativeZero_ReturnsInteger() {
        Number result = NumberUtils.createNumber("-0");
        assertTrue(result instanceof Integer);
        assertEquals(0, result.intValue());
    }

    @Test
    void testCreateNumber_HexadecimalZero_ReturnsInteger() {
        Number result = NumberUtils.createNumber("0x0");
        assertTrue(result instanceof Integer);
        assertEquals(0, result.intValue());
    }

    @Test
    void testCreateNumber_FloatingPointWithSuffix_ReturnsFloat() {
        Number result = NumberUtils.createNumber("123.45F");
        assertTrue(result instanceof Float);
        assertEquals(123.45f, result.floatValue());
    }

    @Test
    void testCreateNumber_HexadecimalWithLeadingZeros_ReturnsInteger() {
        Number result = NumberUtils.createNumber("0x0001A");
        assertTrue(result instanceof Integer);
        assertEquals(26, result.intValue());
    }

    @Test
    void testCreateNumber_FloatInfinity_ReturnsFloat() {
        Number result = NumberUtils.createNumber("Infinityf");
        assertTrue(result instanceof Float);
        assertTrue(Float.isInfinite(result.floatValue()));
    }

    @Test
    void testCreateNumber_DoubleInfinity_ReturnsDouble() {
        Number result = NumberUtils.createNumber("-InfinityD");
        assertTrue(result instanceof Double);
        assertTrue(Double.isInfinite(result.doubleValue()));
        assertTrue(result.doubleValue() < 0);
    }

    @Test
    void testCreateNumber_EOnly_ThrowsException() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1e"));
    }

    @Test
    void testCreateNumber_EWithSign_ReturnsDouble() {
        Number result = NumberUtils.createNumber("1e-10");
        assertTrue(result instanceof Double);
        assertEquals(1e-10, result.doubleValue());
    }

    @Test
    void testCreateNumber_DecimalPointAtEnd_ReturnsDouble() {
        Number result = NumberUtils.createNumber("123.");
        assertTrue(result instanceof Double);
        assertEquals(123.0, result.doubleValue());
    }

    @Test
    void testCreateNumber_DecimalPointAtStart_ReturnsDouble() {
        Number result = NumberUtils.createNumber(".123");
        assertTrue(result instanceof Double);
        assertEquals(0.123, result.doubleValue());
    }

    @Test
    void testCreateNumber_LargeFloatSuffix_ReturnsFloat() {
        Number result = NumberUtils.createNumber("3.4028235e38f"); // Float.MAX_VALUE
        assertTrue(result instanceof Float);
        assertEquals(Float.MAX_VALUE, result.floatValue());
    }

    @Test
    void testCreateNumber_LargeDoubleSuffix_ReturnsDouble() {
        Number result = NumberUtils.createNumber("1.7976931348623157e308D"); // Double.MAX_VALUE
        assertTrue(result instanceof Double);
        assertEquals(Double.MAX_VALUE, result.doubleValue());
    }

    @Test
    void testCreateNumber_BigDecimalRepresentable_ReturnsBigDecimal() {
        Number result = NumberUtils.createNumber("123.45678901234567890123456789");
        assertTrue(result instanceof BigDecimal);
        assertEquals(new BigDecimal("123.45678901234567890123456789"), result);
    }

    @Test
    void testCreateNumber_BigDecimalWithSuffix_ReturnsBigDecimal() {
        Number result = NumberUtils.createNumber("123.45678901234567890123456789D");
        assertTrue(result instanceof BigDecimal);
        assertEquals(new BigDecimal("123.45678901234567890123456789"), result);
    }

    @Test
    void testCreateNumber_PositiveInfinity_ReturnsDouble() {
        Number result = NumberUtils.createNumber("Infinity");
        assertTrue(result instanceof Double);
        assertTrue(Double.isInfinite(result.doubleValue()));
        assertTrue(result.doubleValue() > 0);
    }

    @Test
    void testCreateNumber_NegativeInfinity_ReturnsDouble() {
        Number result = NumberUtils.createNumber("-Infinity");
        assertTrue(result instanceof Double);
        assertTrue(Double.isInfinite(result.doubleValue()));
        assertTrue(result.doubleValue() < 0);
    }

    @Test
    void testCreateNumber_NaN_ReturnsDouble() {
        Number result = NumberUtils.createNumber("NaN");
        assertTrue(result instanceof Double);
        assertTrue(Double.isNaN(result.doubleValue()));
    }
}