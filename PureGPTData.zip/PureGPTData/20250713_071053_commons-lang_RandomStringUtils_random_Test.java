import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class RandomStringUtilsTest {

    private static final Random RANDOM = new Random();

    @Test
    void testRandomEmptyResult() {
        assertEquals("", RandomStringUtils.random(0, 0, 0, false, false, null, RANDOM));
    }

    @Test
    void testRandomNegativeCountThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            RandomStringUtils.random(-1, 0, 0, false, false, null, RANDOM)
        );
    }

    @Test
    void testRandomEmptyCharSetThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            RandomStringUtils.random(5, 0, 0, false, false, new char[0], RANDOM)
        );
    }

    @Test
    void testRandomInvalidStartEndThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            RandomStringUtils.random(5, 5, 4, false, false, null, RANDOM)
        );
    }

    @Test
    void testRandomBelowZeroStartEndThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            RandomStringUtils.random(5, -1, 0, false, false, null, RANDOM)
        );
    }

    @Test
    void testRandomEndExceedsMaxCodePoint() {
        String result = RandomStringUtils.random(5, 0, Character.MAX_CODE_POINT + 2, false, false, null, RANDOM);
        assertEquals(5, result.codePointCount(0, result.length()));
    }

    @ParameterizedTest
    @CsvSource({
        "5, 0, 0, false, true",  // Only numbers
        "5, 0, 0, true, false",  // Only letters
        "5, 0, 0, true, true",   // Letters and numbers
        "5, 'a', 'z'+1, false, false" // Custom char range
    })
    void testRandomValidInput(int count, int start, int end, boolean letters, boolean numbers) {
        String result = RandomStringUtils.random(count, start, end, letters, numbers, null, RANDOM);
        assertEquals(count, result.length());
    }

    @Test
    void testRandomValidWithCustomChars() {
        char[] customChars = { 'A', 'B', 'C' };
        String result = RandomStringUtils.random(5, 0, 0, false, false, customChars, RANDOM);
        assertEquals(5, result.length());
    }

    @Test
    void testRandomWithStartEndAndAlphanumeric() {
        String result = RandomStringUtils.random(5, 0, 'z' + 1, true, true, null, RANDOM);
        assertEquals(5, result.length());
    }

    @ParameterizedTest
    @ValueSource(ints = { '0' + 1, 'A' - 1 })
    void testRandomNumbersBeyondCustomRangeThrowsException(int end) {
        assertThrows(IllegalArgumentException.class, () -> 
            RandomStringUtils.random(5, 0, end, false, true, null, RANDOM)
        );
    }

    @Test
    void testRandomLettersBeyondCustomRangeThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            RandomStringUtils.random(5, 0, 'A', true, false, null, RANDOM)
        );
    }
}