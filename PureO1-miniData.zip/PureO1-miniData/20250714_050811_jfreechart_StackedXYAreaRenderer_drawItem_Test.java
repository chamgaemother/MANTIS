import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.io.IOException;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYAreaRenderer;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.geom.Point2D;
import java.awt.geom.Line2D;
import java.awt.Shape;

import static org.junit.jupiter.api.Assertions.*;

public class StackedXYAreaRendererTest {

    private StackedXYAreaRenderer renderer;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private TableXYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    public void setUp() {
        renderer = new StackedXYAreaRenderer();
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(TableXYDataset.class);
        crosshairState = new CrosshairState();
    }

    @Test
    public void testDrawItem_VerticalPass0_Item0_PlotLines_PlotArea() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(dataset.getItemCount()).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(renderer.getPlotLines()).thenReturn(true);
        when(renderer.getPlotArea()).thenReturn(true);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemFillPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));

        StackedXYAreaRenderer.StackedXYAreaRendererState state = 
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, times(0)).draw(any(Line2D.class));
    }

    @Test
    public void testDrawItem_VerticalPass0_ItemLast_PlotArea() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount()).thenReturn(2);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(renderer.getPlotArea()).thenReturn(true);
        when(renderer.getItemPaint(0, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemFillPaint(0, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 1)).thenReturn(mock(Stroke.class));

        StackedXYAreaRenderer.StackedXYAreaRendererState state = 
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
    }

    @Test
    public void testDrawItem_VerticalPass1_PlotShapes() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        when(renderer.getItemShape(0, 0)).thenReturn(mock(Shape.class));
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);

        StackedXYAreaRenderer.StackedXYAreaRendererState state = 
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_HorizontalPass0_Item0_NoPlotLines_NoPlotArea() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(renderer.getPlotLines()).thenReturn(false);
        when(renderer.getPlotArea()).thenReturn(false);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemFillPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, times(0)).draw(any(Line2D.class));
    }

    @Test
    public void testDrawItem_NullGraphics() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(null, null, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        });
    }

    @Test
    public void testDrawItem_NullDataset() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, null, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, crosshairState, 0);
        });
    }

    @Test
    public void testDrawItem_Pass1_NoPlotShapes() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(false);
        when(renderer.getPlotArea()).thenReturn(false);
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(null);
        when(info.getEntityCollection()).thenReturn(entities);
        when(renderer.getURLGenerator()).thenReturn(null);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(entities, times(1)).add(any(XYItemEntity.class));
    }

    @Test
    public void testDrawItem_NullItem_YValueNaN() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(renderer.getPlotShapes()).thenReturn(true);
        when(renderer.getItemShape(0, 0)).thenReturn(mock(Shape.class));

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, times(0)).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_Pass0_ItemGreaterThan0_PlotLines() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount()).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(renderer.getPlotLines()).thenReturn(true);
        when(renderer.getPlotArea()).thenReturn(false);
        when(renderer.getItemPaint(0, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemFillPaint(0, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 1)).thenReturn(mock(Stroke.class));

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2, times(1)).draw(any(Line2D.class));
    }

    @Test
    public void testDrawItem_Pass1_WithEntityAndShape() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);
        when(renderer.getToolTipGenerator(0, 0)).thenReturn(null);
        when(renderer.getURLGenerator()).thenReturn(null);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, times(1)).draw(any(Shape.class));
        verify(entities, times(1)).add(any(XYItemEntity.class));
    }

    @Test
    public void testDrawItem_Pass1_NoEntities() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(info.getEntityCollection()).thenReturn(null);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, times(1)).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_Pass0_ItemWithNaNYValue() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount()).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(renderer.getPlotLines()).thenReturn(false);
        when(renderer.getPlotArea()).thenReturn(false);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemFillPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        });
    }

    @Test
    public void testDrawItem_InvalidPass() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 2);
        });
    }

    @Test
    public void testDrawItem_Pass1_NullShape() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        when(renderer.getItemShape(0, 0)).thenReturn(null);
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, times(0)).draw(any(Shape.class));
        verify(entities, times(0)).add(any(XYItemEntity.class));
    }

    @Test
    public void testDrawItem_Pass1_NullCrosshairState() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        when(renderer.getItemShape(0, 0)).thenReturn(mock(Shape.class));
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 1);
        });
    }

    @Test
    public void testDrawItem_ShapePaintAndStroke() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        Shape shape = mock(Shape.class);
        Paint shapePaint = mock(Paint.class);
        Stroke shapeStroke = mock(Stroke.class);
        renderer.setShapePaint(shapePaint);
        renderer.setShapeStroke(shapeStroke);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2).setPaint(shapePaint);
        verify(g2).setStroke(shapeStroke);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_ShapePaintNull_UseSeriesPaint() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        renderer.setShapePaint(null);
        Shape shape = mock(Shape.class);
        Paint seriesPaint = mock(Paint.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getItemPaint(0, 0)).thenReturn(seriesPaint);
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2).setPaint(seriesPaint);
    }

    @Test
    public void testDrawItem_ShapeStrokeNull_UseSeriesStroke() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        renderer.setShapeStroke(null);
        Shape shape = mock(Shape.class);
        Stroke seriesStroke = mock(Stroke.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(seriesStroke);
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2).setStroke(seriesStroke);
    }

    @Test
    public void testDrawItem_Pass1_WithToolTipAndURL() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotShapes()).thenReturn(true);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getToolTipGenerator(0, 0)).thenReturn(mock(XYToolTipGenerator.class));
        when(renderer.getURLGenerator()).thenReturn(mock(org.jfree.chart.urls.XYURLGenerator.class));
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(dataset.getItemCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(50.0);

        org.jfree.chart.urls.XYURLGenerator urlGenerator = mock(org.jfree.chart.urls.XYURLGenerator.class);
        when(renderer.getURLGenerator()).thenReturn(urlGenerator);
        when(urlGenerator.generateURL(any(), anyInt(), anyInt())).thenReturn("http://example.com");

        XYToolTipGenerator toolTipGenerator = mock(XYToolTipGenerator.class);
        when(renderer.getToolTipGenerator(0, 0)).thenReturn(toolTipGenerator);
        when(toolTipGenerator.generateToolTip(any(), anyInt(), anyInt())).thenReturn("Tooltip");

        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        StackedXYAreaRenderer.StackedXYAreaRendererState state =
                (StackedXYAreaRenderer.StackedXYAreaRendererState) renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        ArgumentCaptor<XYItemEntity> entityCaptor = ArgumentCaptor.forClass(XYItemEntity.class);
        verify(entities).add(entityCaptor.capture());
        XYItemEntity entity = entityCaptor.getValue();
        assertEquals("Tooltip", entity.getToolTipText());
        assertEquals("http://example.com", entity.getURL());
    }

    @Test
    public void testDrawItem_Serialization() throws IOException, ClassNotFoundException {
        renderer.setShapePaint(mock(Paint.class));
        renderer.setShapeStroke(mock(Stroke.class));

        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(baos);
        oos.writeObject(renderer);
        oos.close();

        java.io.ObjectInputStream ois = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(baos.toByteArray()));
        StackedXYAreaRenderer deserialized = (StackedXYAreaRenderer) ois.readObject();

        assertEquals(renderer, deserialized);
    }

    @Test
    public void testDrawItem_Equals() {
        StackedXYAreaRenderer renderer2 = new StackedXYAreaRenderer();
        assertEquals(renderer, renderer2);

        renderer.setShapePaint(mock(Paint.class));
        assertNotEquals(renderer, renderer2);

        renderer2.setShapePaint(renderer.getShapePaint());
        assertEquals(renderer, renderer2);

        renderer.setShapeStroke(mock(Stroke.class));
        assertNotEquals(renderer, renderer2);

        renderer2.setShapeStroke(renderer.getShapeStroke());
        assertEquals(renderer, renderer2);
    }

    @Test
    public void testDrawItem_Clone() throws CloneNotSupportedException {
        renderer.setShapePaint(mock(Paint.class));
        renderer.setShapeStroke(mock(Stroke.class));

        StackedXYAreaRenderer clone = (StackedXYAreaRenderer) renderer.clone();
        assertEquals(renderer, clone);
    }

}