import org.apache.commons.compress.harmony.pack200.Codec;
import org.apache.commons.compress.harmony.pack200.BHSDCodec;
import org.apache.commons.compress.harmony.pack200.RunCodec;
import org.apache.commons.compress.harmony.pack200.PopulationCodec;
import org.apache.commons.compress.harmony.pack200.CodecEncoding;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CodecEncodingTest {

    @Test
    void testGetSpecifierForCanonicalCodec() {
        // Test with a known canonical codec
        BHSDCodec codec = CodecEncoding.getCanonicalCodec(1);
        int[] specifier = CodecEncoding.getSpecifier(codec, null);
        assertArrayEquals(new int[]{1}, specifier);
    }

    @Test
    void testGetSpecifierForNonCanonicalBHSDCodec() {
        // Test with a BHSDCodec that is not canonical
        BHSDCodec codec = new BHSDCodec(2, 100, 1, 1);
        int[] specifier = CodecEncoding.getSpecifier(codec, null);
        assertArrayEquals(new int[]{116, 10, 99}, specifier);
    }

    @Test
    void testGetSpecifierForRunCodec() {
        // Test with a RunCodec
        BHSDCodec aCodec = CodecEncoding.getCanonicalCodec(1);
        BHSDCodec bCodec = CodecEncoding.getCanonicalCodec(2);
        RunCodec codec = new RunCodec(16, aCodec, bCodec);
        int[] specifier = CodecEncoding.getSpecifier(codec, null);
        assertEquals(3, specifier.length); // Ensure correct length considering default behaviour
    }

    @Test
    void testGetSpecifierForRunCodecWithDefaultA() {
        // Test with RunCodec where aCodec is default
        BHSDCodec aCodec = CodecEncoding.getCanonicalCodec(1);
        BHSDCodec bCodec = CodecEncoding.getCanonicalCodec(2);
        RunCodec codec = new RunCodec(16, aCodec, bCodec);
        int[] specifier = CodecEncoding.getSpecifier(codec, aCodec);
        assertEquals(2, specifier.length); // aCodec treated as default, reduces length
    }

    @Test
    void testGetSpecifierForPopulationCodec() {
        // Test with PopulationCodec
        BHSDCodec fCodec = CodecEncoding.getCanonicalCodec(1);
        BHSDCodec tCodec = CodecEncoding.getCanonicalCodec(2);
        BHSDCodec uCodec = CodecEncoding.getCanonicalCodec(3);
        PopulationCodec codec = new PopulationCodec(fCodec, tCodec, uCodec);
        int[] specifier = CodecEncoding.getSpecifier(codec, null);
        assertEquals(4, specifier.length); // Check whether codec parsing is correct
    }

    @Test
    void testGetSpecifierForNullCodec() {
        // Test with null codec
        int[] specifier = CodecEncoding.getSpecifier(null, null);
        assertNull(specifier);
    }
}