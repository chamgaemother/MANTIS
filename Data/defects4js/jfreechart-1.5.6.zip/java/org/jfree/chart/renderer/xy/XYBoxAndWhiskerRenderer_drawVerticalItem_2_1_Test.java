package org.jfree.chart.renderer.xy;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Collections;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_2_1_Test {

//     @Test
//     @DisplayName("drawVerticalItem with yAverage above dataArea bounds, average ellipse is not drawn")
//     public void TC26_drawVerticalItem_yAverageAboveBounds_AverageEllipseNotDrawn() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotOwner.class));
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
// 
//         when(dataset.getMeanValue(0, 0)).thenReturn(150.0); // yAverage > dataArea upper bound
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(70.0);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(30.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
//         when(dataset.getQ1Value(0, 0)).thenReturn(40.0);
//         when(dataset.getQ3Value(0, 0)).thenReturn(60.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
// 
//         when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge()))
//                 .thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge())))
//                 .thenReturn(50.0);
// 
        // Act
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
        // Assert
//         verify(g2, never()).fill(any(Ellipse2D.Double.class));
//     }

//     @Test
//     @DisplayName("drawVerticalItem with yAverage below dataArea bounds, average ellipse is not drawn")
//     public void TC27_drawVerticalItem_yAverageBelowBounds_AverageEllipseNotDrawn() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotOwner.class));
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
// 
//         when(dataset.getMeanValue(0, 0)).thenReturn(-20.0); // yAverage < dataArea lower bound
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(70.0);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(30.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
//         when(dataset.getQ1Value(0, 0)).thenReturn(40.0);
//         when(dataset.getQ3Value(0, 0)).thenReturn(60.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
// 
//         when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge()))
//                 .thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge())))
//                 .thenReturn(50.0);
// 
        // Act
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
        // Assert
//         verify(g2, never()).fill(any(Ellipse2D.Double.class));
//     }

//     @Test
//     @DisplayName("drawVerticalItem with outliers exactly at maxOutlier boundary")
//     public void TC28_drawVerticalItem_OutlierAtMaxOutlierBoundary_HighFarOutMarkerDrawn() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotOwner.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
// 
//         when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(80.0)); // Exactly at maxOutlier boundary
//         when(dataset.getMaxOutlier(0, 0)).thenReturn(80.0);
//         when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(20.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
//         when(dataset.getMeanValue(0, 0)).thenReturn(50.0);
//         when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
//         when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
// 
//         when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge()))
//                 .thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(80.0, dataArea, plot.getRangeAxisEdge()))
//                 .thenReturn(100.0);
// 
        // Act
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
        // Assert
//         verify(renderer, times(1)).drawHighFarOut(anyDouble(), eq(g2), eq(100.0), anyDouble());
//     }

//     @Test
//     @DisplayName("drawVerticalItem with outliers exactly at minOutlier boundary")
//     public void TC29_drawVerticalItem_OutlierAtMinOutlierBoundary_LowFarOutMarkerDrawn() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotOwner.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
// 
//         when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(20.0)); // Exactly at minOutlier boundary
//         when(dataset.getMaxOutlier(0, 0)).thenReturn(80.0);
//         when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(20.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
//         when(dataset.getMeanValue(0, 0)).thenReturn(50.0);
//         when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
//         when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
// 
//         when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge()))
//                 .thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge()))
//                 .thenReturn(0.0);
// 
        // Act
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
        // Assert
//         verify(renderer, times(1)).drawLowFarOut(anyDouble(), eq(g2), eq(100.0), anyDouble());
//     }

//     @Test
//     @DisplayName("drawVerticalItem with both high and low far out flags set")
//     public void TC30_drawVerticalItem_BothHighAndLowFarOutMarkersDrawn() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotOwner.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
// 
//         when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(85.0, 15.0)); // Above and below boundaries
//         when(dataset.getMaxOutlier(0, 0)).thenReturn(80.0);
//         when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(20.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
//         when(dataset.getMeanValue(0, 0)).thenReturn(50.0);
//         when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
//         when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
// 
//         when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge()))
//                 .thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(85.0, dataArea, plot.getRangeAxisEdge()))
//                 .thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(15.0, dataArea, plot.getRangeAxisEdge()))
//                 .thenReturn(-50.0);
// 
        // Act
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
        // Assert
//         verify(renderer, times(1)).drawHighFarOut(anyDouble(), eq(g2), eq(100.0), anyDouble());
//         verify(renderer, times(1)).drawLowFarOut(anyDouble(), eq(g2), eq(100.0), anyDouble());
//     }

}