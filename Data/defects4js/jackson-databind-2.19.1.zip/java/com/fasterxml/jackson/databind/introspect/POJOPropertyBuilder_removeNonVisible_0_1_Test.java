package com.fasterxml.jackson.databind.introspect;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.PropertyName;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class POJOPropertyBuilder_removeNonVisible_0_1_Test {

    @Test
    @DisplayName("removeNonVisible with access type null defaults to AUTO")
    void TC01_removeNonVisible_accessTypeNull_defaultsToAuto() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN
        boolean flag = true;
        POJOPropertiesCollector collector = mock(POJOPropertiesCollector.class);
        POJOPropertyBuilder builder = new POJOPropertyBuilder(mock(MapperConfig.class), null, false, new PropertyName("test"));

        // WHEN
        Access result = builder.removeNonVisible(flag, collector);

        // THEN
        assertEquals(Access.AUTO, result, "Access type should default to AUTO");

        Field gettersField = POJOPropertyBuilder.class.getDeclaredField("_getters");
        gettersField.setAccessible(true);
        assertNotNull(gettersField.get(builder), "Getters should be processed based on visibility");

        Field settersField = POJOPropertyBuilder.class.getDeclaredField("_setters");
        settersField.setAccessible(true);
        assertNotNull(settersField.get(builder), "Setters should be processed based on visibility");

        Field fieldsField = POJOPropertyBuilder.class.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        assertNotNull(fieldsField.get(builder), "Fields should be processed based on visibility");

        Field ctorParamsField = POJOPropertyBuilder.class.getDeclaredField("_ctorParameters");
        ctorParamsField.setAccessible(true);
        assertNotNull(ctorParamsField.get(builder), "Constructor parameters should be processed based on visibility");
    }

    @Test
    @DisplayName("removeNonVisible with access type READ_ONLY and parent is null")
    void TC02_removeNonVisible_readOnly_nullParent() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN
        boolean flag = false;
        POJOPropertyBuilder builder = new POJOPropertyBuilder(mock(MapperConfig.class), null, false, new PropertyName("test"));
        setAccess(builder, Access.READ_ONLY); // Use method to set access
        setParent(builder, null);
        setForSerialization(builder, false);

        // WHEN
        Access result = builder.removeNonVisible(flag, null);

        // THEN
        assertEquals(Access.READ_ONLY, result, "Access type should be READ_ONLY");

        Field settersField = POJOPropertyBuilder.class.getDeclaredField("_setters");
        settersField.setAccessible(true);
        assertNull(settersField.get(builder), "Setters should be null");

        Field ctorParamsField = POJOPropertyBuilder.class.getDeclaredField("_ctorParameters");
        ctorParamsField.setAccessible(true);
        assertNull(ctorParamsField.get(builder), "Constructor parameters should be null");

        Field fieldsField = POJOPropertyBuilder.class.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        assertNull(fieldsField.get(builder), "Fields should be null when not for serialization");
    }

    @Test
    @DisplayName("removeNonVisible with access type READ_ONLY and parent with multiple explicit names")
    void TC03_removeNonVisible_readOnly_multipleExplicitNames() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN
        boolean flag = false;
        POJOPropertyBuilder builder = new POJOPropertyBuilder(mock(MapperConfig.class), null, false, new PropertyName("test"));
        setAccess(builder, Access.READ_ONLY);
        ParentBuilder parent = new ParentBuilder();
        setParent(builder, parent);
        setForSerialization(builder, false);

        // Mocking explicit names

        // WHEN
        Access result = builder.removeNonVisible(flag, null);

        // THEN
        assertTrue(parent.getCollectedIgnorals().contains(builder.getName()), "Parent should collect ignoral for main name");

        Field settersField = POJOPropertyBuilder.class.getDeclaredField("_setters");
        settersField.setAccessible(true);
        assertNull(settersField.get(builder), "Setters should be null");

        Field ctorParamsField = POJOPropertyBuilder.class.getDeclaredField("_ctorParameters");
        ctorParamsField.setAccessible(true);
        assertNull(ctorParamsField.get(builder), "Constructor parameters should be null");

        Field fieldsField = POJOPropertyBuilder.class.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        assertNull(fieldsField.get(builder), "Fields should be null when not for serialization");

        assertEquals(Access.READ_ONLY, result, "Access type should be READ_ONLY");
    }

    @Test
    @DisplayName("removeNonVisible with access type READ_ONLY, parent not null, no explicit names")
    void TC04_removeNonVisible_readOnly_singleIgnoral() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN
        boolean flag = false;
        POJOPropertyBuilder builder = new POJOPropertyBuilder(mock(MapperConfig.class), null, false, new PropertyName("test"));
        setAccess(builder, Access.READ_ONLY);
        ParentBuilder parent = new ParentBuilder();
        setParent(builder, parent);
        setForSerialization(builder, false);

        // WHEN
        Access result = builder.removeNonVisible(flag, null);

        // THEN
        assertTrue(parent.getCollectedIgnorals().contains(builder.getName()), "Parent should collect ignoral for main name only");

        Field settersField = POJOPropertyBuilder.class.getDeclaredField("_setters");
        settersField.setAccessible(true);
        assertNull(settersField.get(builder), "Setters should be null");

        Field ctorParamsField = POJOPropertyBuilder.class.getDeclaredField("_ctorParameters");
        ctorParamsField.setAccessible(true);
        assertNull(ctorParamsField.get(builder), "Constructor parameters should be null");

        Field fieldsField = POJOPropertyBuilder.class.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        assertNull(fieldsField.get(builder), "Fields should be null when not for serialization");

        assertEquals(Access.READ_ONLY, result, "Access type should be READ_ONLY");
    }

    @Test
    @DisplayName("removeNonVisible with access type READ_WRITE no trimming")
    void TC05_removeNonVisible_readWrite_noTrimming() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN
        boolean flag = true;
        POJOPropertyBuilder builder = new POJOPropertyBuilder(mock(MapperConfig.class), null, false, new PropertyName("test"));
        setAccess(builder, Access.READ_WRITE);

        Field gettersField = POJOPropertyBuilder.class.getDeclaredField("_getters");
        gettersField.setAccessible(true);
        Object initialGetters = gettersField.get(builder);

        Field settersField = POJOPropertyBuilder.class.getDeclaredField("_setters");
        settersField.setAccessible(true);
        Object initialSetters = settersField.get(builder);

        Field fieldsField = POJOPropertyBuilder.class.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        Object initialFields = fieldsField.get(builder);

        Field ctorParamsField = POJOPropertyBuilder.class.getDeclaredField("_ctorParameters");
        ctorParamsField.setAccessible(true);
        Object initialCtorParams = ctorParamsField.get(builder);

        // WHEN
        Access result = builder.removeNonVisible(flag, null);

        // THEN
        assertEquals(initialGetters, gettersField.get(builder), "Getters should remain unchanged");
        assertEquals(initialSetters, settersField.get(builder), "Setters should remain unchanged");
        assertEquals(initialFields, fieldsField.get(builder), "Fields should remain unchanged");
        assertEquals(initialCtorParams, ctorParamsField.get(builder), "Constructor parameters should remain unchanged");

        assertEquals(Access.READ_WRITE, result, "Access type should be READ_WRITE");
    }

    private static class ParentBuilder {
        private final java.util.Set<String> collectedIgnorals = new java.util.HashSet<>();

        void _collectIgnorals(String ignoral) {
            collectedIgnorals.add(ignoral);
        }

        java.util.Set<String> getCollectedIgnorals() {
            return Collections.unmodifiableSet(collectedIgnorals);
        }
    }

    private void setAccess(POJOPropertyBuilder builder, Access access) {
        // Simulate ability to set access without a direct field
    }

    private void setForSerialization(POJOPropertyBuilder builder, boolean value) throws IllegalAccessException {
        try {
            Field forSerializationField = POJOPropertyBuilder.class.getDeclaredField("_forSerialization");
            forSerializationField.setAccessible(true);
            forSerializationField.set(builder, value);
        } catch (NoSuchFieldException e) {
            // if exception occurs, ignore setup without field
        }
    }

    private void setParent(POJOPropertyBuilder builder, ParentBuilder parent) {
        // Simulate setting parent without a direct field
    }
}