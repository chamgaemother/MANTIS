package org.apache.commons.collections4;

import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.HashMap;
import java.util.IllegalArgumentException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class MapUtils_putAll_0_1_Test {

    @Test
    @DisplayName("Verify map unchanged when array is null")
    public void testPutAll_ArrayIsNull() {
        Map<Object, Object> map = new HashMap<>();
        Map<Object, Object> result = MapUtils.putAll(map, null);
        assertEquals(map, result, "Map should remain unchanged when array is null");
    }

    @Test
    @DisplayName("Verify map unchanged when array is empty")
    public void testPutAll_ArrayIsEmpty() {
        Map<Object, Object> map = new HashMap<>();
        Object[] array = new Object[]{};
        Map<Object, Object> result = MapUtils.putAll(map, array);
        assertEquals(map, result, "Map should remain unchanged when array is empty");
    }

    @Test
    @DisplayName("Verify map updated with Map.Entry elements")
    public void testPutAll_ArrayWithMapEntryElements() {
        Map<Object, Object> map = new HashMap<>();
        Map.Entry<Object, Object> entry1 = Map.entry("key1", "value1");
        Map.Entry<Object, Object> entry2 = Map.entry("key2", "value2");
        Object[] array = new Object[]{entry1, entry2};
        Map<Object, Object> result = MapUtils.putAll(map, array);
        assertAll(
            () -> assertEquals("value1", result.get("key1"), "Map should include the provided entry key-value pairs"),
            () -> assertEquals("value2", result.get("key2"), "Map should include the provided entry key-value pairs")
        );
    }

    @Test
    @DisplayName("Verify map updated with KeyValue elements")
    public void testPutAll_ArrayWithKeyValueElements() {
        Map<Object, Object> map = new HashMap<>();
        KeyValue<Object, Object> kv1 = new KeyValue<>("key1", "value1");
        KeyValue<Object, Object> kv2 = new KeyValue<>("key2", "value2");
        Object[] array = new Object[]{kv1, kv2};
        Map<Object, Object> result = MapUtils.putAll(map, array);
        assertAll(
            () -> assertEquals("value1", result.get("key1"), "Map should include key-value pairs from KeyValue"),
            () -> assertEquals("value2", result.get("key2"), "Map should include key-value pairs from KeyValue")
        );
    }

    @Test
    @DisplayName("Verify map updated from Object[] with valid subarrays")
    public void testPutAll_ArrayWithObjectSubarrays() {
        Map<Object, Object> map = new HashMap<>();
        Object[] subArray1 = new Object[]{"key1", "value1"};
        Object[] subArray2 = new Object[]{"key2", "value2"};
        Object[] array = new Object[]{subArray1, subArray2};
        Map<Object, Object> result = MapUtils.putAll(map, array);
        assertAll(
            () -> assertEquals("value1", result.get("key1"), "Map should be updated from valid subarrays"),
            () -> assertEquals("value2", result.get("key2"), "Map should be updated from valid subarrays")
        );
    }
    
    // KeyValue inner class for test purposes
    class KeyValue<K, V> implements Map.Entry<K, V> {
        private final K key;
        private V value;

        public KeyValue(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public K getKey() {
            return key;
        }

        @Override
        public V getValue() {
            return value;
        }

        @Override
        public V setValue(V value) {
            V old = this.value;
            this.value = value;
            return old;
        }
    }
}