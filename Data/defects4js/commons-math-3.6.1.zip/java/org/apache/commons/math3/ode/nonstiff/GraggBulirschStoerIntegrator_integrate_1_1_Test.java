package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class GraggBulirschStoerIntegrator_integrate_1_1_Test {

    /**
     * Scenario TC11:
     * Integration throws IllegalArgumentException when minStep is greater than maxStep
     */
    @Test
    @DisplayName("Integration throws IllegalArgumentException when minStep is greater than maxStep")
    void TC11_integrateThrowsExceptionWhenMinStepGreaterThanMaxStep() {
        // Arrange
        double minStep = 10.0;
        double maxStep = 1.0;
        double scalAbsoluteTolerance = 1.0e-8;
        double scalRelativeTolerance = 1.0e-10;
        GraggBulirschStoerIntegrator integrator =
            new GraggBulirschStoerIntegrator(minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyEquations());
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());
        double targetTime = 10.0;

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            integrator.integrate(equations, targetTime);
        }, "Expected integrate() to throw IllegalArgumentException when minStep > maxStep");
    }

    /**
     * Scenario TC12:
     * Integration completes without progressing when target time equals current time
     */
    @Test
    @DisplayName("Integration completes immediately when target time equals current time")
    void TC12_integrateCompletesImmediatelyWhenTargetTimeEqualsCurrentTime() throws Exception {
        // Arrange
        double minStep = 0.1;
        double maxStep = 100.0;
        double scalAbsoluteTolerance = 1.0e-8;
        double scalRelativeTolerance = 1.0e-10;
        GraggBulirschStoerIntegrator integrator =
            new GraggBulirschStoerIntegrator(minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyEquations());
        equations.setTime(5.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());
        double targetTime = 5.0;

        // Act
        integrator.integrate(equations, targetTime);

        // Assert
        assertEquals(5.0, equations.getTime(), 1.0e-10, "Time should remain unchanged.");
        assertArrayEquals(initialState, equations.getCompleteState(), 1.0e-10, "State should remain unchanged.");
    }

    /**
     * Scenario TC13:
     * Integration handles multiple consecutive step rejections due to high error, triggering step size reductions
     */
    @Test
    @DisplayName("Integration handles multiple step rejections due to high error")
    void TC13_integrateHandlesMultipleStepRejections() throws Exception {
        // Arrange
        double minStep = 0.1;
        double maxStep = 100.0;
        double scalAbsoluteTolerance = 1.0e-2;
        double scalRelativeTolerance = 1.0e-3;
        GraggBulirschStoerIntegrator integrator =
            new GraggBulirschStoerIntegrator(minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new HighErrorEquations());
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());
        double targetTime = 10.0;

        // Act
        assertDoesNotThrow(() -> {
            integrator.integrate(equations, targetTime);
        }, "Integration should complete after handling multiple step rejections.");

        // Assert
        assertEquals(targetTime, equations.getTime(), 1.0e-10, "Time after integration should match target time.");
        assertNotNull(equations.getCompleteState(), "State should be updated correctly.");
        // Additional assertions may be added based on the behavior of HighErrorEquations
    }

    /**
     * Dummy implementation of FirstOrderDifferentialEquations for testing purposes.
     */
    private static class DummyEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 2;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = y[1];
            yDot[1] = -y[0];
        }
    }

    /**
     * HighErrorEquations simulates high error during integration to trigger step rejections.
     */
    private static class HighErrorEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 2;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            // Introduce artificial high error by returning large derivatives
            yDot[0] = 1.0e6 * y[1];
            yDot[1] = -1.0e6 * y[0];
        }
    }

}