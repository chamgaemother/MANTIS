package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.StringWriter;
import java.io.Writer;

import static org.junit.jupiter.api.Assertions.*;

public class NumericEntityUnescaper_translate_0_4_Test {

//     @Test
//     @DisplayName("Decimal entity value exactly 0xFFFF, writes single character")
//     void TC16() {
        // GIVEN
//         CharSequence input = "&#65535;";
//         int index = 0;
//         Writer out = new StringWriter();
// 
        // WHEN
//         NumericEntityUnescaper unescaper = new NumericEntityUnescaper(); // Instantiating the NumericEntityUnescaper
//         int result = unescaper.translate(input, index, out);
// 
        // THEN
//         assertEquals("\uFFFF", out.toString());
//         assertEquals(7, result);
//     }

//     @Test
//     @DisplayName("Input contains multiple numeric entities, multiple iterations")
//     void TC17() {
        // GIVEN
//         CharSequence input = "&#65;&#66;&#67;";
//         int index = 0;
//         Writer out = new StringWriter();
// 
        // WHEN
//         NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
//         int result1 = unescaper.translate(input, index, out);
//         int result2 = unescaper.translate(input, index + result1, out);
//         int result3 = unescaper.translate(input, index + result1 + result2, out);
// 
        // THEN
//         assertEquals("ABC", out.toString());
//         assertEquals(4, result1);
//         assertEquals(4, result2);
//         assertEquals(4, result3);
//     }

//     @Test
//     @DisplayName("Input entity without hexadecimal digits after 'x', returns 0")
//     void TC18() {
        // GIVEN
//         CharSequence input = "&#x;";
//         int index = 0;
//         Writer out = new StringWriter();
// 
        // WHEN
//         NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
//         int result = unescaper.translate(input, index, out);
// 
        // THEN
//         assertEquals(0, result);
//     }

//     @Test
//     @DisplayName("Input entity with non-hexadecimal characters in hex digits, returns 0")
//     void TC19() {
        // GIVEN
//         CharSequence input = "&#x4G;";
//         int index = 0;
//         Writer out = new StringWriter();
// 
        // WHEN
//         NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
//         int result = unescaper.translate(input, index, out);
// 
        // THEN
//         assertEquals(0, result);
//     }

//     @Test
//     @DisplayName("Input entity with missing digits after '&#', returns 0")
//     void TC20() {
        // GIVEN
//         CharSequence input = "&#;";
//         int index = 0;
//         Writer out = new StringWriter();
// 
        // WHEN
//         NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
//         int result = unescaper.translate(input, index, out);
// 
        // THEN
//         assertEquals(0, result);
//     }
}