package com.fasterxml.jackson.databind.ser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BeanPropertyWriter_serializeAsField_0_2_Test {

    @Test
    @DisplayName("serializeAsField with _suppressableValue equals to value")
    public void TC06() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter();

        // Set private field _suppressableValue via reflection
        Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        String suppressableValue = "suppressMe";
        suppressableValueField.set(writer, suppressableValue);

        // Mock bean with a dummy field value equal to _suppressableValue (change from method reflection)
        Object bean = new Object() {
            public String testField = "suppressMe";
        };

        // Mock SerializerProvider
        SerializerProvider prov = mock(SerializerProvider.class);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Assert
        verify(gen, never()).writeFieldName(anyString());
    }

    @Test
    @DisplayName("serializeAsField with value referencing the bean and _handleSelfReference returns true")
    public void TC07() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter();

        // Mock SerializerProvider to handle self-reference
        SerializerProvider prov = mock(SerializerProvider.class);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Create subclass for test to override _handleSelfReference internally
        BeanPropertyWriter writerSpy = spy(writer);
        doReturn(true).when(writerSpy).serializeAsField(any(), any(), any());

        // Mock serializer
        JsonSerializer<Object> ser = mock(JsonSerializer.class);

        // Set private field _serializer via reflection
        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writerSpy, ser);

        // Mock bean where field value == bean
        Object bean = mock(Object.class);

        // Act
        writerSpy.serializeAsField(bean, gen, prov);

        // Assert
        verify(gen, never()).writeFieldName(anyString());
    }

    @Test
    @DisplayName("serializeAsField with value referencing the bean and _handleSelfReference returns false")
    public void TC08() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter();

        // Mock SerializerProvider to handle self-reference
        SerializerProvider prov = mock(SerializerProvider.class);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Create subclass for test to override _handleSelfReference internally
        BeanPropertyWriter writerSpy = spy(writer);
        doReturn(false).when(writerSpy).serializeAsField(any(), any(), any());

        // Mock serializer
        JsonSerializer<Object> ser = mock(JsonSerializer.class);

        // Set private field _serializer via reflection
        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writerSpy, ser);

        // Mock bean where field value == bean
        Object bean = mock(Object.class);

        // Act
        writerSpy.serializeAsField(bean, gen, prov);

        // Assert
        verify(gen, never()).writeFieldName(anyString());
    }

    @Test
    @DisplayName("serializeAsField with _typeSerializer defined")
    public void TC09() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter();

        // Set private field _typeSerializer via reflection
        Field typeSerializerField = BeanPropertyWriter.class.getDeclaredField("_typeSerializer");
        typeSerializerField.setAccessible(true);
        JsonSerializer<Object> typeSerializer = mock(JsonSerializer.class);
        typeSerializerField.set(writer, typeSerializer);

        // Mock SerializerProvider
        SerializerProvider prov = mock(SerializerProvider.class);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Mock serializer
        JsonSerializer<Object> ser = mock(JsonSerializer.class);

        // Set private field _serializer via reflection
        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writer, ser);

        // Mock bean with non-null field value
        Object value = new Object();
        Object bean = new Object() {
            public Object typedField = value;
        };

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Verify that proper methods executed
        verify(gen, times(1)).writeFieldName("typedField");
    }

    @Test
    @DisplayName("serializeAsField with _nullSerializer not defined and value is null")
    public void TC10() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter();

        // Ensure _nullSerializer is null via reflection
        Field nullSerializerField = BeanPropertyWriter.class.getDeclaredField("_nullSerializer");
        nullSerializerField.setAccessible(true);
        nullSerializerField.set(writer, null);

        // Mock SerializerProvider
        SerializerProvider prov = mock(SerializerProvider.class);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Mock bean with null field value; adjust mock to valid bean setup
        Object bean = new Object();
        Method accessorMethod = BeanPropertyWriter.class.getDeclaredMethod("get", Object.class);
        accessorMethod.setAccessible(true);
        when(accessorMethod.invoke(any(), (Object[]) null)).thenReturn(null);

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Verify methods on gen were not called
        verify(gen, never()).writeFieldName(anyString());
        verify(gen, never()).writeNull();
    }
}