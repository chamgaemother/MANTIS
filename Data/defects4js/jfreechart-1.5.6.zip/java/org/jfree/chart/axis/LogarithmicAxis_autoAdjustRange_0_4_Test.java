package org.jfree.chart.axis;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class LogarithmicAxis_autoAdjustRange_0_4_Test {

    private void setPrivateField(Object target, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
        java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    @DisplayName("autoAdjustRange rounds upper bound to nearest integer when autoRangeNextLogFlag is false and allowNegativesFlag is false")
    void TC16_autoAdjustRange_roundsUpperBoundWithoutLogFlag() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");

        axis.setAutoRangeNextLogFlag(false);
        axis.setAllowNegativesFlag(false);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        setPrivateField(axis, "plot", mockPlot);  // use reflection to set private 'plot'

        Range mockRange = new Range(2.3, 9.7);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(2.3, adjustedRange.getLowerBound());
        assertEquals(10.0, adjustedRange.getUpperBound());
    }

    @Test
    @DisplayName("autoAdjustRange maintains lower bound when it is above minimum range after adjustment")
    void TC17_autoAdjustRange_maintainsLowerBoundAboveMinRange() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");

        setPrivateField(axis, "autoRangeMinimumSize", 5.0);
        setPrivateField(axis, "lowerMargin", 0.2);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        setPrivateField(axis, "plot", mockPlot);

        Range mockRange = new Range(6.0, 20.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(6.0, adjustedRange.getLowerBound());
        assertEquals(20.0, adjustedRange.getUpperBound());
    }

    @Test
    @DisplayName("autoAdjustRange adjusts range by 1% when minRange is still not met after initial adjustment")
    void TC18_autoAdjustRange_adjustsRangeByOnePercent() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");

        setPrivateField(axis, "autoRangeMinimumSize", 10.0);
        setPrivateField(axis, "lowerMargin", 0.1);
        setPrivateField(axis, "upperMargin", 0.1);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        setPrivateField(axis, "plot", mockPlot);

        Range mockRange = new Range(20.0, 25.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        double expectedLower = 20.0;
        double expectedUpper = 25.0;
        double minRange = 10.0;
        double adjustedRangeSize = expectedUpper - expectedLower;
        if (adjustedRangeSize < minRange) {
            expectedUpper = (expectedUpper + expectedLower + minRange) / 2;
            expectedLower = (expectedUpper + expectedLower - minRange) / 2;
        }
        assertEquals(expectedLower, adjustedRange.getLowerBound());
        assertEquals(expectedUpper, adjustedRange.getUpperBound());
    }

    @Test
    @DisplayName("autoAdjustRange processes when lower bound is exactly zero and allowNegativesFlag is false")
    void TC19_autoAdjustRange_lowerBoundZeroNoNegatives() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");

        axis.setAllowNegativesFlag(false);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        setPrivateField(axis, "plot", mockPlot);

        Range mockRange = new Range(0.0, 10.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(0.0, adjustedRange.getLowerBound());
        assertEquals(10.0, adjustedRange.getUpperBound());
    }

    @Test
    @DisplayName("autoAdjustRange sets range correctly when both lower and upper bounds require log adjustments")
    void TC20_autoAdjustRange_adjustsBothBoundsUsingLogMethods() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");

        axis.setAutoRangeNextLogFlag(true);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        setPrivateField(axis, "plot", mockPlot);

        Range mockRange = new Range(5.0, 50.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        // Assuming computeLogFloor and computeLogCeil adjust to nearest 10^n
        assertEquals(axis.computeLogFloor(mockRange.getLowerBound()), adjustedRange.getLowerBound());
        assertEquals(axis.computeLogCeil(mockRange.getUpperBound()), adjustedRange.getUpperBound());
    }
}
