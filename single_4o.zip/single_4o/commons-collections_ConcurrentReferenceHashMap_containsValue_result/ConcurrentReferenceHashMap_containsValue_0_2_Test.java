package org.apache.commons.collections4.map;

import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ConcurrentReferenceHashMap_containsValue_0_2_Test {

    @Test
    @DisplayName("containsValue locks and returns false when value is not present even after locking")
    public void testContainsValue_LocksAndReturnsFalseAfterLocking() {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        assertFalse(map.containsValue("nonexistentValue"));
    }

    @Test
    @DisplayName("containsValue uses RETRIES_BEFORE_LOCK and exits early when found within retries")
    public void testContainsValue_ExitsEarlyOnFoundWithinRetries() {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        map.put("key", "value");
        assertTrue(map.containsValue("value"));
    }

    @Test
    @DisplayName("containsValue retries and exits without locking when no modifications occur")
    public void testContainsValue_ExitsWithoutLockingNoModification() {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        assertFalse(map.containsValue("nonexistentValue"));
    }

    @Test
    @DisplayName("containsValue locks and immediately finds the value after all segments are locked")
    public void testContainsValue_LocksAndFindsValue() {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        map.put("key", "value");  // Assuming inserting into the first segment checked
        assertTrue(map.containsValue("value"));
    }

    @Test
    @DisplayName("containsValue exits immediately during first retry iteration when modification is detected")
    public void testContainsValue_EarlyExitOnModification() {
        // Simulate modification by changing map during the retries
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        // Modification is abstracted here; assume modification occurs during retries.
        // This scenario is difficult to simulate exactly without internal control over modCount.
        assertFalse(map.containsValue("value")); // This may not fulfill the exact simulation
    }
}