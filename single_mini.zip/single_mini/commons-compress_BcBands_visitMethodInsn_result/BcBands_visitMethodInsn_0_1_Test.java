package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BcBands_visitMethodInsn_0_1_Test {

    private BcBands bcBands;
    private CpBands cpBandsMock;
    private Segment segmentMock;

    @BeforeEach
    public void setUp() {
        // Mock dependencies
        cpBandsMock = mock(CpBands.class);
        segmentMock = mock(Segment.class);

        // Initialize BcBands with mocked dependencies and effort value
        bcBands = new BcBands(cpBandsMock, segmentMock, 0);

        // Set currentClass and superClass to ensure proper behavior in tests
        bcBands.setCurrentClass("currentClass", "superClass");
    }

    @Test
    @DisplayName("Handle opcode 182 (invokevirtual) with empty bcCodes and owner equals currentClass")
    public void TC01() throws Exception {
        // Arrange
        int opcode = 182; // invokevirtual
        String owner = "currentClass";
        String name = "someMethod";
        String desc = "(I)V";

        // Mock behavior of cpBands
        CPMethodOrField cpMethodMock = mock(CPMethodOrField.class);
        when(cpBandsMock.getCPMethod(owner, name, desc)).thenReturn(cpMethodMock);

        // Act
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assert
        // Verify that opcode is increased by 24 -> 206
        List<Integer> bcCodes = getPrivateFieldList(bcBands, "bcCodes");
        assertFalse(bcCodes.isEmpty());
        assertEquals(Integer.valueOf(206), bcCodes.get(bcCodes.size() - 1));

        // Verify that bcThisMethod is updated with CPMethod
        List<CPMethodOrField> bcThisMethod = getPrivateFieldList(bcBands, "bcThisMethod");
        assertFalse(bcThisMethod.isEmpty());
        assertEquals(cpMethodMock, bcThisMethod.get(bcThisMethod.size() - 1));
    }

    @Test
    @DisplayName("Handle opcode 183 (invokespecial) with non-empty bcCodes ending with ALOAD_0 and owner equals currentClass")
    public void TC02() throws Exception {
        // Arrange
        int opcode = 183; // invokespecial
        String owner = "currentClass";
        String name = "<init>";
        String desc = "()V";

        // Mock behavior of cpBands
        CPMethodOrField cpMethodMock = mock(CPMethodOrField.class);
        when(cpBandsMock.getCPMethod(owner, name, desc)).thenReturn(cpMethodMock);

        // Initialize bcCodes with ALOAD_0 (42)
        List<Integer> bcCodes = getPrivateFieldList(bcBands, "bcCodes");
        bcCodes.add(42); // ALOAD_0

        // Act
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assert
        // Verify that ALOAD_0 is removed and opcode is set to 230
        assertEquals(1, bcCodes.size());
        assertEquals(Integer.valueOf(230), bcCodes.get(0));

        // Verify that bcInitRef is updated
        List<CPMethodOrField> bcInitRef = getPrivateFieldList(bcBands, "bcInitRef");
        assertFalse(bcInitRef.isEmpty());
        assertEquals(cpMethodMock, bcInitRef.get(bcInitRef.size() - 1));
    }

    @Test
    @DisplayName("Handle opcode 184 (invokestatic) with owner equals superClass and name not <init>")
    public void TC03() throws Exception {
        // Arrange
        int opcode = 184; // invokestatic
        String owner = "superClass";
        String name = "doSomething";
        String desc = "()V";

        // Mock behavior of cpBands
        CPMethodOrField cpMethodMock = mock(CPMethodOrField.class);
        when(cpBandsMock.getCPMethod(owner, name, desc)).thenReturn(cpMethodMock);

        // Act
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assert
        // Verify that opcode is increased by 38 -> 222
        List<Integer> bcCodes = getPrivateFieldList(bcBands, "bcCodes");
        assertFalse(bcCodes.isEmpty());
        assertEquals(Integer.valueOf(222), bcCodes.get(bcCodes.size() - 1));

        // Verify that bcSuperMethod is updated
        List<CPMethodOrField> bcSuperMethod = getPrivateFieldList(bcBands, "bcSuperMethod");
        assertFalse(bcSuperMethod.isEmpty());
        assertEquals(cpMethodMock, bcSuperMethod.get(bcSuperMethod.size() - 1));
    }

    @Test
    @DisplayName("Handle opcode 185 (invokeinterface) with typical inputs")
    public void TC04() throws Exception {
        // Arrange
        int opcode = 185; // invokeinterface
        String owner = "interfaceOwner";
        String name = "interfaceMethod";
        String desc = "()V";

        // Mock behavior of cpBands
        CPMethodOrField cpIMethodMock = mock(CPMethodOrField.class);
        when(cpBandsMock.getCPIMethod(owner, name, desc)).thenReturn(cpIMethodMock);

        // Act
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assert
        // Verify that opcode remains 185
        List<Integer> bcCodes = getPrivateFieldList(bcBands, "bcCodes");
        assertFalse(bcCodes.isEmpty());
        assertEquals(Integer.valueOf(185), bcCodes.get(bcCodes.size() - 1));

        // Verify that bcIMethodRef is updated
        List<CPMethodOrField> bcIMethodRef = getPrivateFieldList(bcBands, "bcIMethodRef");
        assertFalse(bcIMethodRef.isEmpty());
        assertEquals(cpIMethodMock, bcIMethodRef.get(bcIMethodRef.size() - 1));
    }

    @Test
    @DisplayName("Handle opcode 182 (invokevirtual) with non-empty bcCodes not ending with ALOAD_0 and owner equals currentClass")
    public void TC05() throws Exception {
        // Arrange
        int opcode = 182; // invokevirtual
        String owner = "currentClass";
        String name = "execute";
        String desc = "()V";

        // Mock behavior of cpBands
        CPMethodOrField cpMethodMock = mock(CPMethodOrField.class);
        when(cpBandsMock.getCPMethod(owner, name, desc)).thenReturn(cpMethodMock);

        // Initialize bcCodes with a non-ALOAD_0 opcode
        List<Integer> bcCodes = getPrivateFieldList(bcBands, "bcCodes");
        bcCodes.add(10); // Some opcode other than ALOAD_0

        // Act
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assert
        // Verify that opcode is increased by 24 -> 206
        assertEquals(2, bcCodes.size());
        assertEquals(Integer.valueOf(10), bcCodes.get(0));
        assertEquals(Integer.valueOf(206), bcCodes.get(1));

        // Verify that bcThisMethod is updated with CPMethod
        List<CPMethodOrField> bcThisMethod = getPrivateFieldList(bcBands, "bcThisMethod");
        assertFalse(bcThisMethod.isEmpty());
        assertEquals(cpMethodMock, bcThisMethod.get(bcThisMethod.size() - 1));
    }

    /**
     * Helper method to access private List fields using reflection.
     *
     * @param obj       The object containing the private field.
     * @param fieldName The name of the private field.
     * @param <T>       The type of the list.
     * @return The List instance.
     * @throws Exception If reflection fails.
     */
    @SuppressWarnings("unchecked")
    private <T> List<T> getPrivateFieldList(Object obj, String fieldName) throws Exception {
        Field field = BcBands.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return (List<T>) field.get(obj);
    }
}