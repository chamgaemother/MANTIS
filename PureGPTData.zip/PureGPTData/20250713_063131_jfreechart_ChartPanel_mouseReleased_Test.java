import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.Zoomable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

class ChartPanelTest {

    private ChartPanel chartPanel;
    private JFreeChart mockChart;
    private Plot mockPlot;
    private Zoomable mockZoomablePlot;
    private MouseEvent mockMouseEvent;

    @BeforeEach
    void setUp() {
        mockChart = mock(JFreeChart.class);
        mockPlot = mock(Plot.class);
        mockZoomablePlot = mock(Zoomable.class);
        
        when(mockChart.getPlot()).thenReturn(mockZoomablePlot);
        
        chartPanel = new ChartPanel(mockChart);
        mockMouseEvent = mock(MouseEvent.class);
    }

    @Test
    void testPanEndResetsCursor() {
        // Testing pan ending resets the panLast and cursor
        chartPanel.panLast = new java.awt.Point(10, 10);
        chartPanel.mouseReleased(mockMouseEvent);
        assert chartPanel.panLast == null;
    }

    @Test
    void testZoomingWithRectangleTriggersAutoBounds() {
        // Setup a situation for trigger zoom restore with invalid zoom rectangle
        Rectangle invalidZoomRect = new Rectangle(-1, -1);
        chartPanel.zoomRectangle = invalidZoomRect;
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(0, 0);
        when(mockMouseEvent.getX()).thenReturn(5);
        when(mockMouseEvent.getY()).thenReturn(5);
        when(mockZoomablePlot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(mockZoomablePlot.isDomainZoomable()).thenReturn(true);
        when(mockZoomablePlot.isRangeZoomable()).thenReturn(true);

        // Execute the event
        chartPanel.mouseReleased(mockMouseEvent);

        // Check if restoreAutoBounds has been triggered
        verify(mockZoomablePlot).zoomDomainAxes(0.0, null, new java.awt.geom.Point2D.Double(0, 0));
    }

    @Test
    void testZoomInDirection() {
        // Setup with zooming scenario
        Rectangle rect = new Rectangle(0, 0, 10, 10);
        chartPanel.zoomRectangle = rect;
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(rect.x, rect.y);
        when(mockMouseEvent.getX()).thenReturn(20);
        when(mockMouseEvent.getY()).thenReturn(20);
        when(mockZoomablePlot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(mockZoomablePlot.isDomainZoomable()).thenReturn(true);
        when(mockZoomablePlot.isRangeZoomable()).thenReturn(true);

        // Execute the event
        chartPanel.mouseReleased(mockMouseEvent);

        // Check if the zoom method was triggered correctly
        verify(mockZoomablePlot).zoomDomainAxes(anyDouble(), eq(null), any(), eq(false));
        verify(mockZoomablePlot).zoomRangeAxes(anyDouble(), eq(null), any(), eq(false));
    }

    @Test
    void testPopupTrigger() {
        // Arrange
        chartPanel.popup = mock(javax.swing.JPopupMenu.class);
        when(mockMouseEvent.isPopupTrigger()).thenReturn(true);

        // Act
        chartPanel.mouseReleased(mockMouseEvent);

        // Assert that the popup menu was shown
        verify(chartPanel.popup).show(chartPanel, mockMouseEvent.getX(), mockMouseEvent.getY());
    }

    @Test
    void testNoPlot() {
        // Setting up no plot scenario
        when(mockChart.getPlot()).thenReturn(null);

        // Act
        chartPanel.mouseReleased(mockMouseEvent);

        // Verify no interactions with plot as it is null
        verifyNoInteractions(mockPlot);
    }

    @Test
    void testNoZoomPointNoAction() {
        // Setting up absence of zoom point
        chartPanel.zoomPoint = null;

        // Act
        chartPanel.mouseReleased(mockMouseEvent);

        // Verify that the rectangle was not drawn
        verifyNoInteractions(mockZoomablePlot);
    }
}