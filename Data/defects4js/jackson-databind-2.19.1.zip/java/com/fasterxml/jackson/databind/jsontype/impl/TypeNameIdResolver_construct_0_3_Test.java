package com.fasterxml.jackson.databind.jsontype.impl;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.fasterxml.jackson.databind.MapperFeature;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TypeNameIdResolver_construct_0_3_Test {

    @Test
    @DisplayName("Construct with forSer=false, forDeser=true and multiple subtypes with mixed hasName and caseInsensitive=true")
    void TC11_construct_with_forSer_false_forDeser_true_multiple_subtypes_mixed_hasName_caseInsensitive_true() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        when(config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES)).thenReturn(true);
        JavaType baseType = mock(JavaType.class);
        
        JavaType firstClassType = mock(JavaType.class);
        JavaType secondClassType = mock(JavaType.class);
        JavaType thirdClassType = mock(JavaType.class);

        NamedType subtype1 = new NamedType(FirstClass.class, "FirstType");
        NamedType subtype2 = new NamedType(SecondClass.class);
        NamedType subtype3 = new NamedType(ThirdClass.class, "thirdtype");

        Collection<NamedType> subtypes = Arrays.asList(subtype1, subtype2, subtype3);
        boolean forSer = false;
        boolean forDeser = true;

        // Mock the construction of JavaTypes
        when(config.constructType(FirstClass.class)).thenReturn(firstClassType);
        when(config.constructType(SecondClass.class)).thenReturn(secondClassType);
        when(config.constructType(ThirdClass.class)).thenReturn(thirdClassType);

        // WHEN
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // THEN
        // Accessing idToType using reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        @SuppressWarnings("unchecked")
        HashMap<String, JavaType> idToType = (HashMap<String, JavaType>) idToTypeField.get(resolver);

        assertNotNull(idToType, "idToType should not be null");
        assertEquals(3, idToType.size(), "idToType should contain three entries");
        assertTrue(idToType.containsKey("firsttype"), "idToType should contain key 'firsttype'");
        assertTrue(idToType.containsKey("secondclass"), "idToType should contain key 'secondclass'");
        assertTrue(idToType.containsKey("thirdtype"), "idToType should contain key 'thirdtype'");
        assertEquals(firstClassType, idToType.get("firsttype"), "idToType for 'firsttype' should match JavaType for FirstClass");
        assertEquals(secondClassType, idToType.get("secondclass"), "idToType for 'secondclass' should match JavaType for SecondClass");
        assertEquals(thirdClassType, idToType.get("thirdtype"), "idToType for 'thirdtype' should match JavaType for ThirdClass");

        // Accessing typeToId using reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        @SuppressWarnings("unchecked")
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        assertNotNull(typeToId, "typeToId should not be null");
        // Since ConcurrentHashMap does not expose capacity, we assume it's initialized with at least the expected entries
        assertTrue(typeToId.isEmpty(), "typeToId should be empty for forSer=false");
    }

    @Test
    @DisplayName("Construct with forSer=false, forDeser=true and subtype without name using reflection")
    void TC12_construct_with_forSer_false_forDeser_true_subtype_without_name_using_reflection() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        when(config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES)).thenReturn(false);
        JavaType baseType = mock(JavaType.class);
        
        JavaType defaultClassType = mock(JavaType.class);

        NamedType subtype = new NamedType(PackageName.DefaultClass.class);
        Collection<NamedType> subtypes = Arrays.asList(subtype);
        boolean forSer = false;
        boolean forDeser = true;

        // Mock the construction of JavaType
        when(config.constructType(PackageName.DefaultClass.class)).thenReturn(defaultClassType);

        // WHEN
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // THEN
        // Accessing idToType using reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        @SuppressWarnings("unchecked")
        HashMap<String, JavaType> idToType = (HashMap<String, JavaType>) idToTypeField.get(resolver);

        assertNotNull(idToType, "idToType should not be null");
        assertEquals(1, idToType.size(), "idToType should contain one entry");
        String expectedDefaultId = PackageName.DefaultClass.class.getName();
        int lastDotIndex = expectedDefaultId.lastIndexOf('.');
        expectedDefaultId = (lastDotIndex < 0) ? expectedDefaultId : expectedDefaultId.substring(lastDotIndex + 1).toLowerCase();
        assertTrue(idToType.containsKey(expectedDefaultId), "idToType should contain the default type ID");
        assertEquals(defaultClassType, idToType.get(expectedDefaultId), "idToType for default ID should match JavaType for DefaultClass");

        // Accessing typeToId using reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        @SuppressWarnings("unchecked")
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        assertNotNull(typeToId, "typeToId should not be null");
        assertTrue(typeToId.isEmpty(), "typeToId should be empty for forSer=false");
    }

    // Mock classes for testing purposes
    private static class FirstClass {}
    private static class SecondClass {}
    private static class ThirdClass {}
    private static class PackageName {
        static class DefaultClass {}
    }
}