import org.apache.commons.compress.archivers.cpio.CpioArchiveEntry;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class CpioArchiveInputStreamTest {

    private static final byte[] MAGIC_OLD_BINARY = new byte[] {(byte) 0x71, (byte) 0xC7};
    private static final byte[] MAGIC_NEW = ArchiveUtils.toAsciiString("070701").getBytes();
    private static final byte[] MAGIC_NEW_CRC = ArchiveUtils.toAsciiString("070702").getBytes();
    private static final byte[] MAGIC_OLD_ASCII = ArchiveUtils.toAsciiString("070707").getBytes();

    private static final byte[] TRAILER_ENTRY = "TRAILER!!!".getBytes();

    private ByteArrayInputStream inputStream;

    @BeforeEach
    void setUp() throws IOException {
        this.inputStream = new ByteArrayInputStream(new byte[0]);
    }

    private static Stream<byte[]> provideMagicBytes() {
        return Stream.of(MAGIC_OLD_BINARY, MAGIC_NEW, MAGIC_NEW_CRC, MAGIC_OLD_ASCII);
    }

    @ParameterizedTest
    @MethodSource("provideMagicBytes")
    void testValidMagicBytes(final byte[] magicBytes) throws IOException {
        ByteArrayInputStream testStream = new ByteArrayInputStream(concat(magicBytes, TRAILER_ENTRY));
        CpioArchiveInputStream cpioStream = new CpioArchiveInputStream(testStream);
        CpioArchiveEntry entry = cpioStream.getNextCPIOEntry();
        
        while (entry != null) {
            assertNotNull(entry);
            entry = cpioStream.getNextCPIOEntry();
        }
    }

    @Test
    void testInvalidMagicThrowsException() {
        byte[] invalidMagicBytes = ArchiveUtils.toAsciiString("XXXXX").getBytes();
        ByteArrayInputStream testStream = new ByteArrayInputStream(concat(invalidMagicBytes, TRAILER_ENTRY));
        CpioArchiveInputStream cpioStream = new CpioArchiveInputStream(testStream);
        IOException exception = assertThrows(IOException.class, cpioStream::getNextCPIOEntry);
        assertTrue(exception.getMessage().contains("Unknown magic"));
    }

    @Test
    void testMagicLessThanSixBytesReturnsNull() throws IOException {
        ByteArrayInputStream testStream = new ByteArrayInputStream(new byte[5]);
        CpioArchiveInputStream cpioStream = new CpioArchiveInputStream(testStream);
        assertNull(cpioStream.getNextCPIOEntry());
    }

    @Test
    void testClosedStreamThrowsIOException() throws IOException {
        CpioArchiveInputStream cpioStream = new CpioArchiveInputStream(inputStream);
        cpioStream.close();
        assertThrows(IOException.class, cpioStream::getNextCPIOEntry);
    }

    @Test
    void testTrailerCorrectlyHandled() throws IOException {
        ByteArrayInputStream testStream = new ByteArrayInputStream(concat(MAGIC_NEW, TRAILER_ENTRY));
        CpioArchiveInputStream cpioStream = new CpioArchiveInputStream(testStream);
        CpioArchiveEntry entry = cpioStream.getNextCPIOEntry();
        assertNull(entry);
    }

    @Test
    void testEOFExceptionOnShortReadHeader() {
        ByteArrayInputStream testStream = new ByteArrayInputStream(new byte[4]); // Too short for a valid header
        CpioArchiveInputStream cpioStream = new CpioArchiveInputStream(testStream);
        assertThrows(EOFException.class, cpioStream::getNextCPIOEntry);
    }

    private byte[] concat(byte[] a, byte[] b) {
        byte[] result = new byte[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }
}