package org.apache.commons.math3.dfp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Dfp_multiply_0_3_Test {

    private static Method getIEEEFlagsBits;

    @BeforeAll
    public static void init() throws NoSuchMethodException {
        // Initializes the method to be used for checking IEEE flags before running the tests
        getIEEEFlagsBits = DfpField.class.getDeclaredMethod("getIEEEFlagsBits");
        getIEEEFlagsBits.setAccessible(true);
    }

    @Test
    @DisplayName("Multiplying two finite Dfp numbers causing underflow")
    public void TC11_multiply_causing_underflow() throws Exception {
        // GIVEN
        DfpField field = new DfpField(20); // Example precision
        Dfp a = new Dfp(field, 1e-50);
        Dfp b = new Dfp(field, 1e-50);
        
        // WHEN
        Dfp result = a.multiply(b);
        
        // THEN
        assertTrue(result.isZero() || result.equals(field.getZero()), "Result should be zero or gradual underflow");
        
        // Accessing private field 'field' via reflection to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);
        
        int flags = (int) getIEEEFlagsBits.invoke(resultField);
        
        assertTrue((flags & DfpField.FLAG_UNDERFLOW) != 0, "FLAG_UNDERFLOW should be set");
    }

    @Test
    @DisplayName("Multiplying two finite Dfp numbers with maximum mantissa digits")
    public void TC12_multiply_with_maximum_mantissa_digits() {
        // GIVEN
        DfpField field = new DfpField(50); // Maximum mantissa digits
        Dfp a = new Dfp(field, Long.MAX_VALUE);
        Dfp b = new Dfp(field, Long.MAX_VALUE);
        
        // WHEN
        Dfp result = a.multiply(b);
        
        // THEN
        assertEquals(field.getRadixDigits(), result.getRadixDigits(), "Radix digits should match the field");
        assertEquals(a.log10K() + b.log10K() + 2, result.log10K(), "Logarithmic estimation of exponents should match");
    }

    @Test
    @DisplayName("Multiplying finite Dfp numbers with rounding but no exception")
    public void TC13_multiply_with_rounding_without_exception() throws Exception {
        // GIVEN
        DfpField field = new DfpField(30);
        Dfp a = new Dfp(field, 1.2345);
        Dfp b = new Dfp(field, 6.7890);
        
        // WHEN
        Dfp result = a.multiply(b);
        
        // THEN
        Dfp expected = new Dfp(field, 1.2345 * 6.7890); // Expected rounded product
        // Using assertTrue due to potential floating point precision issues
        assertTrue(expected.unequal(result), "Product should be correctly rounded");
        
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);
        
        int flags = (int) getIEEEFlagsBits.invoke(resultField);
        
        assertEquals(0, flags, "No IEEE flags should be set");
    }

    @Test
    @DisplayName("Multiplying finite Dfp numbers with rounding and triggering a trap")
    public void TC14_multiply_with_rounding_and_trap() throws Exception {
        // GIVEN
        DfpField field = new DfpField(20);
        Dfp a = new Dfp(field, 1e292);
        Dfp b = new Dfp(field, 1e292);
        
        // WHEN
        Dfp result = a.multiply(b);
        
        Dfp expected = new Dfp(field, Double.POSITIVE_INFINITY);
        
        // THEN
        assertEquals(expected, result, "Product should be correctly rounded with trap");
        
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);
        
        int flags = (int) getIEEEFlagsBits.invoke(resultField);
        
        assertTrue((flags & DfpField.FLAG_OVERFLOW) != 0, "OVERFLOW flag should be set");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where the result mantissa has leading zeros")
    public void TC15_multiply_resulting_in_mantissa_with_leading_zeros() throws Exception {
        // GIVEN
        DfpField field = new DfpField(25);
        Dfp a = new Dfp(field, 1e-10);
        Dfp b = new Dfp(field, 1e-10);
        
        // WHEN
        Dfp result = a.multiply(b);
        
        // THEN
        assertFalse(result.toString().startsWith("0"), "Mantissa should not start with leading zeros");
        assertTrue(result.isZero(), "Result should still be considered zero");
    }
}
