import org.junit.jupiter.api.Test;
import java.nio.file.attribute.FileTime;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;

public class SevenZArchiveEntryTest {

    @Test
    public void testEqualsSameObject() {
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        assertTrue(entry.equals(entry));
    }

    @Test
    public void testEqualsNullObject() {
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        assertFalse(entry.equals(null));
    }

    @Test
    public void testEqualsDifferentClass() {
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        assertFalse(entry.equals("Some String"));
    }

    @Test
    public void testEqualsDifferentNames() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName("Entry1");
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName("Entry2");
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentHasStream() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasStream(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasStream(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentIsDirectory() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setDirectory(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setDirectory(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentIsAntiItem() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setAntiItem(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setAntiItem(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentFileTimes() {
        FileTime time1 = FileTime.fromMillis(1000);
        FileTime time2 = FileTime.fromMillis(2000);

        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCreationTime(time1);

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCreationTime(time2);

        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentWindowsAttributes() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setWindowsAttributes(1);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setWindowsAttributes(2);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentCrc() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCrcValue(123);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCrcValue(456);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentCompressedCrc() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCompressedCrcValue(123);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCompressedCrcValue(456);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentSize() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setSize(123);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setSize(456);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentCompressedSize() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCompressedSize(123);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCompressedSize(456);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsDifferentContentMethods() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setContentMethods(Collections.emptyList());

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setContentMethods(Arrays.asList(new SevenZMethodConfiguration()));

        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEqualsAllFieldsEqual() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        
        entry1.setName("Entry");
        entry2.setName("Entry");
        
        // Set other fields to identical values
        entry1.setHasStream(true);
        entry2.setHasStream(true);

        entry1.setDirectory(true);
        entry2.setDirectory(true);

        entry1.setAntiItem(true);
        entry2.setAntiItem(true);

        entry1.setCreationTime(FileTime.fromMillis(0));
        entry2.setCreationTime(FileTime.fromMillis(0));

        entry1.setWindowsAttributes(1);
        entry2.setWindowsAttributes(1);

        entry1.setCrcValue(123);
        entry2.setCrcValue(123);

        entry1.setCompressedCrcValue(123);
        entry2.setCompressedCrcValue(123);

        entry1.setSize(123);
        entry2.setSize(123);

        entry1.setCompressedSize(123);
        entry2.setCompressedSize(123);

        entry1.setContentMethods(Collections.emptyList());
        entry2.setContentMethods(Collections.emptyList());

        assertTrue(entry1.equals(entry2));
    }
}