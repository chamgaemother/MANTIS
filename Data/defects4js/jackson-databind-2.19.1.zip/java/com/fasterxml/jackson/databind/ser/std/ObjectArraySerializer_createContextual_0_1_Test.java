package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ObjectArraySerializer_createContextual_0_1_Test {

//     @Test
//     @DisplayName("vts is null and property is null, resulting in default serializer")
//     public void TC01() throws Exception {
        // Arrange
//         SerializerProvider serializers = mock(SerializerProvider.class);
//         BeanProperty property = null;
//         ObjectArraySerializer serializer = mock(ObjectArraySerializer.class);
// 
        // Mock dependencies
//         when(serializer.findFormatOverrides(any(), any(), any())).thenReturn(null);
//         when(serializer.handledType()).thenCallRealMethod();
//         when(serializer.withResolved(any(), any(), any(), any())).thenReturn(serializer);
// 
        // Mock _elementSerializer
//         JsonSerializer<Object> defaultSerializer = mock(JsonSerializer.class);
//         when(serializer.getContentSerializer()).thenReturn(defaultSerializer);
// 
        // Act
//         JsonSerializer<?> result = serializer.createContextual(serializers, property);
// 
        // Assert
//         assertEquals(defaultSerializer, result);
//     }

    @Test
    @DisplayName("vts is not null and property is not null, configuring vts for property")
    public void TC02() throws Exception {
        // Arrange
        SerializerProvider serializers = mock(SerializerProvider.class);
        BeanProperty property = mock(BeanProperty.class);
        TypeSerializer vts = mock(TypeSerializer.class);
        ObjectArraySerializer serializer = new ObjectArraySerializer(null, true, vts, null);

        // Mock dependencies
        when(serializers.getAnnotationIntrospector()).thenReturn(mock(AnnotationIntrospector.class));
        when(vts.forProperty(property)).thenReturn(vts);
        when(serializer.findFormatOverrides(any(), any(), any())).thenReturn(null);

        // Act
        JsonSerializer<?> result = serializer.createContextual(serializers, property);

        // Assert
        assertNotNull(result);
    }

//     @Test
//     @DisplayName("property is not null but its member is null, default serializer is used")
//     public void TC03() throws Exception {
        // Arrange
//         SerializerProvider serializers = mock(SerializerProvider.class);
//         BeanProperty property = mock(BeanProperty.class);
//         AnnotatedMember member = null;
//         when(property.getMember()).thenReturn(member);
//         AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
//         when(serializers.getAnnotationIntrospector()).thenReturn(intr);
//         when(intr.findContentSerializer(member)).thenReturn(null);
// 
//         ObjectArraySerializer serializer = mock(ObjectArraySerializer.class);
//         when(serializer.handledType()).thenCallRealMethod();
//         when(serializer.findFormatOverrides(serializers, property, serializer.handledType())).thenReturn(null);
//         when(serializer.withResolved(any(), any(), any(), any())).thenReturn(serializer);
// 
        // Mock _elementSerializer
//         JsonSerializer<Object> defaultSerializer = mock(JsonSerializer.class);
//         when(serializer.getContentSerializer()).thenReturn(defaultSerializer);
// 
        // Act
//         JsonSerializer<?> result = serializer.createContextual(serializers, property);
// 
        // Assert
//         assertEquals(defaultSerializer, result);
//     }

//     @Test
//     @DisplayName("property is not null and member has a content serializer defined")
//     public void TC04() throws Exception {
        // Arrange
//         SerializerProvider serializers = mock(SerializerProvider.class);
//         BeanProperty property = mock(BeanProperty.class);
//         AnnotatedMember member = mock(AnnotatedMember.class);
//         Object serDef = new Object();
//         JsonSerializer<Object> customSerializer = mock(JsonSerializer.class);
// 
//         when(property.getMember()).thenReturn(member);
//         AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
//         when(serializers.getAnnotationIntrospector()).thenReturn(intr);
//         when(intr.findContentSerializer(member)).thenReturn(serDef);
//         when(serializers.serializerInstance(member, serDef)).thenReturn(customSerializer);
// 
//         ObjectArraySerializer serializer = mock(ObjectArraySerializer.class);
//         when(serializer.handledType()).thenCallRealMethod();
//         when(serializer.findContextualConvertingSerializer(serializers, property, customSerializer)).thenReturn(customSerializer);
//         when(serializer.withResolved(any(), any(), any(), any())).thenReturn(serializer);
// 
        // Act
//         JsonSerializer<?> result = serializer.createContextual(serializers, property);
// 
        // Assert
//         assertEquals(customSerializer, result);
//     }

    @Test
    @DisplayName("format overrides are present, unwrapSingle is true")
    public void TC05() throws Exception {
        // Arrange
        SerializerProvider serializers = mock(SerializerProvider.class);
        BeanProperty property = mock(BeanProperty.class);
        JsonFormat.Value format = JsonFormat.Value.empty().withFeature(JsonFormat.Feature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED);

        ObjectArraySerializer serializer = mock(ObjectArraySerializer.class);
        when(serializer.handledType()).thenCallRealMethod();
        when(serializer.findFormatOverrides(serializers, property, serializer.handledType())).thenReturn(format);
        when(serializer.withResolved(any(), any(), any(), any())).thenReturn(serializer);

        // Mock unwrapSingle field
        // Correct error by using a direct mock return on behavior not present in the original file
        when(format.getFeature(JsonFormat.Feature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED)).thenReturn(true);
        
        // Act
        JsonSerializer<?> result = serializer.createContextual(serializers, property);

        // Assert
        assertNotNull(result);
    }
}