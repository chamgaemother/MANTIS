package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.codec.language.Nysiis;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class NysiisTest {

    private final Nysiis strictNysiis = new Nysiis(true);
    private final Nysiis nonStrictNysiis = new Nysiis(false);

    @Test
    void testNysiis_NullInput() {
        assertNull(strictNysiis.nysiis(null));
    }

    @Test
    void testNysiis_EmptyString() {
        assertEquals("", strictNysiis.nysiis(""));
    }

    @Test
    void testNysiis_StartsWithMAC() {
        assertEquals("MCC", strictNysiis.nysiis("MAC"));
        assertEquals("MCCAIT", strictNysiis.nysiis("MACAIT"));
    }

    @Test
    void testNysiis_StartsWithKN() {
        assertEquals("NN", strictNysiis.nysiis("KN"));
        assertEquals("NNOBER", strictNysiis.nysiis("KNOBER"));
    }

    @Test
    void testNysiis_StartsWithK_NotKN() {
        assertEquals("C", strictNysiis.nysiis("K"));
        assertEquals("CAIT", strictNysiis.nysiis("KAIT"));
    }

    @Test
    void testNysiis_StartsWithPH() {
        assertEquals("FF", strictNysiis.nysiis("PH"));
        assertEquals("FFAIT", strictNysiis.nysiis("PHAIT"));
    }

    @Test
    void testNysiis_StartsWithPF() {
        assertEquals("FF", strictNysiis.nysiis("PF"));
        assertEquals("FFAIT", strictNysiis.nysiis("PFAIT"));
    }

    @Test
    void testNysiis_StartsWithSCH() {
        assertEquals("SSS", strictNysiis.nysiis("SCH"));
        assertEquals("SSSAIT", strictNysiis.nysiis("SCHAIT"));
    }

    @Test
    void testNysiis_DoesNotStartWithSpecialPatterns() {
        assertEquals("A", strictNysiis.nysiis("A"));
        assertEquals("AITE", strictNysiis.nysiis("AITE"));
    }

    @Test
    void testNysiis_EndsWithEE() {
        assertEquals("AY", strictNysiis.nysiis("TEE"));
    }

    @Test
    void testNysiis_EndsWithIE() {
        assertEquals("Y", strictNysiis.nysiis("IE"));
    }

    @ParameterizedTest
    @ValueSource(strings = { "DT", "RT", "RD", "NT", "ND" })
    void testNysiis_EndsWith_DT_RT_RD_NT_ND(String ending) {
        assertEquals("D", strictNysiis.nysiis(ending));
        assertEquals("A" + "D", strictNysiis.nysiis("A" + ending));
    }

    @Test
    void testNysiis_DoesNotEndWithSpecialPatterns() {
        assertEquals("A", strictNysiis.nysiis("AIT"));
    }

    @Test
    void testNysiis_Transcode_EV() {
        assertEquals("AF", strictNysiis.nysiis("EV"));
        assertEquals("SAF", strictNysiis.nysiis("S_EV"));
    }

    @ParameterizedTest
    @ValueSource(strings = { "A", "E", "I", "O", "U" })
    void testNysiis_Transcode_Vowels(String vowel) {
        assertEquals("A", strictNysiis.nysiis(vowel));
        assertEquals("SA", strictNysiis.nysiys("S" + vowel));
    }

    @Test
    void testNysiis_Transcode_Q() {
        assertEquals("G", strictNysiis.nysiis("Q"));
        assertEquals("SG", strictNysiis.nysiis("SQ"));
    }

    @Test
    void testNysiis_Transcode_Z() {
        assertEquals("S", strictNysiis.nysiis("Z"));
        assertEquals("SZ", strictNysiis.nysiis("SZ"));
    }

    @Test
    void testNysiis_Transcode_M() {
        assertEquals("N", strictNysiis.nysiis("M"));
        assertEquals("SN", strictNysiis.nysiis("SM"));
    }

    @Test
    void testNysiis_Transcode_K_WithN() {
        assertEquals("NN", strictNysiis.nysiis("KN"));
        assertEquals("CNN", strictNysiis.nysiis("KNN"));
    }

    @Test
    void testNysiis_Transcode_K_WithoutN() {
        assertEquals("C", strictNysiis.nysiis("K"));
        assertEquals("SC", strictNysiis.nysiis("SK"));
    }

    @Test
    void testNysiis_Transcode_SCH_InMiddle() {
        assertEquals("SSS", strictNysiis.nysiis("SCH"));
        assertEquals("ASSSA", strictNysiis.nysiis("ASCHSA"));
    }

    @Test
    void testNysiis_Transcode_PH_InMiddle() {
        assertEquals("FF", strictNysiis.nysiis("PH"));
        assertEquals("AFFA", strictNysiis.nysiis("APHPA"));
    }

    @Test
    void testNysiis_Transcode_H_WithNonVowelNeighbors() {
        assertEquals("A", strictNysiis.nysiis("AH"));
        assertEquals("B", strictNysiis.nysiis("BH"));
    }

    @Test
    void testNysiis_Transcode_H_WithVowelNeighbors() {
        assertEquals("H", strictNysiis.nysiis("AHH"));
        assertEquals("HAH", strictNysiis.nysiis("HAHH"));
    }

    @Test
    void testNysiis_Transcode_W_WithVowel() {
        assertEquals("A", strictNysiis.nysiis("AW"));
        assertEquals("SA", strictNysiis.nysiys("SAW"));
    }

    @Test
    void testNysiis_Transcode_W_WithoutVowel() {
        assertEquals("W", strictNysiis.nysiis("SW"));
    }

    @Test
    void testNysiis_ConsecutiveDuplicates() {
        assertEquals("ABC", strictNysiis.nysiis("AABBCC"));
        assertEquals("A", strictNysiis.nysiis("AAAAAA"));
    }

    @Test
    void testNysiis_RemoveLastS() {
        assertEquals("ABCD", strictNysiis.nysiis("ABCDS"));
    }

    @Test
    void testNysiis_ReplaceAYWithY() {
        assertEquals("Y", strictNysiis.nysiis("AY"));
        assertEquals("ABY", strictNysiis.nysiis("ABAY"));
    }

    @Test
    void testNysiis_RemoveLastA() {
        assertEquals("ABC", strictNysiis.nysiis("ABCA"));
    }

    @Test
    void testNysiis_StrictMode_Truncate() {
        assertEquals("ABCDEFG".substring(0, 6), strictNysiis.nysiis("ABCDEFG"));
    }

    @Test
    void testNysiis_NonStrictMode_NoTruncate() {
        assertEquals("ABCDEFG", nonStrictNysiis.nysiis("ABCDEFG"));
    }

    @Test
    void testNysiis_AllBranches() {
        String input = "MACPHWQNZKSCHPHHWA";
        String expected = "MCAFFGANSSSA";
        String actual = strictNysiis.nysiis(input);
        assertEquals(expected.substring(0, Math.min(expected.length(), 6)), actual);
    }
}