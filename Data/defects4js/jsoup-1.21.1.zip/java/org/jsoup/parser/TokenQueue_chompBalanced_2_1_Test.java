package org.jsoup.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TokenQueue_chompBalanced_2_1_Test {

    @Test
    @DisplayName("ChompBalanced with identical open and close characters (quotes) handles balanced input correctly")
    void TC35_ChompBalanced_WithIdenticalOpenAndCloseCharacters() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\"Hello World\"");
        
        // WHEN
        String result = queue.chompBalanced('"', '"');
        
        // THEN
        assertEquals("Hello World", result);
    }

    @Test
    @DisplayName("ChompBalanced with multiple consecutive escape characters before 'Q' toggles regex mode")
    void TC36_ChompBalanced_WithMultipleConsecutiveEscapeCharacters() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\\\\Qexample\\E");
        
        // WHEN
        String result = queue.chompBalanced('(', ')');
        
        // THEN
        assertEquals("\\Qexample\\E", result);
    }

    @Test
    @DisplayName("ChompBalanced with unmatched open character after regex mode toggling throws exception")
    void TC37_ChompBalanced_WithUnmatchedOpenCharacter_ThrowsException() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\\Qexample(\\E");
        
        // WHEN & THEN
        Exception exception = assertThrows(IllegalStateException.class, () -> {
            queue.chompBalanced('(', ')');
        });
        assertTrue(exception.getMessage().contains("Did not find balanced marker"));
    }

    @Test
    @DisplayName("ChompBalanced with mixed escape sequences and nested quotes handles input correctly")
    void TC38_ChompBalanced_WithMixedEscapeSequencesAndNestedQuotes() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\\'He\\\"llo\\' World\\\"");
        
        // WHEN
        String result = queue.chompBalanced('(', ')');
        
        // THEN
        assertEquals("'He\"llo' World\"", result);
    }
}