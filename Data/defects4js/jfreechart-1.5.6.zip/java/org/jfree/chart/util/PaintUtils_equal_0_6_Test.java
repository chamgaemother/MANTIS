package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.Paint;
import java.awt.GradientPaint;
import java.awt.RadialGradientPaint;
import java.awt.Color;
import java.awt.LinearGradientPaint;
import java.awt.geom.Point2D;

public class PaintUtils_equal_0_6_Test {

    @Test
    @DisplayName("p1 and p2 are non-paint instances with p1.equals(p2) true, expect true")
    void TC26() {
        // Given
        Object s1 = "test";
        Object s2 = new String("test"); // s1.equals(s2) is true

        // When
        boolean result = PaintUtils.equal((Paint) s1, (Paint) s2);

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("p1 and p2 are non-paint instances with p1.equals(p2) false, expect false")
    void TC27() {
        // Given
        Object s1 = "test";
        Object s2 = "different";

        // When
        boolean result = PaintUtils.equal((Paint) s1, (Paint) s2);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("p1 and p2 are different Paint subclasses, expect false")
    void TC28() {
        // Given
        GradientPaint gp = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.BLUE);
        RadialGradientPaint rgp = new RadialGradientPaint(
                new Point2D.Float(0,0), 
                1f, 
                new float[]{0f,1f}, 
                new Color[]{Color.RED, Color.BLUE}
        );

        // When
        boolean result = PaintUtils.equal(gp, rgp);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("p1 is an instance of Paint and p2 is of a different unrelated class, expect false")
    void TC29() {
        // Given
        Paint p = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.BLUE);
        Object obj = new Object();

        // When
        boolean result = PaintUtils.equal(p, (Paint) obj);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are instances of different non-equal Paint subclasses, expect false")
    void TC30() {
        // Given
        GradientPaint gp = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.BLUE);
        RadialGradientPaint rgp = new RadialGradientPaint(
                new Point2D.Float(1,1),
                2f, 
                new float[]{0f,1f}, 
                new Color[]{Color.GREEN, Color.YELLOW}
        );

        // When
        boolean result = PaintUtils.equal(gp, rgp);

        // Then
        assertFalse(result);
    }
}