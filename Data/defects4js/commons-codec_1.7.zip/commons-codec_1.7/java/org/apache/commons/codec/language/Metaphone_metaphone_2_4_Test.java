package org.apache.commons.codec.language;

import org.apache.commons.codec.language.Metaphone;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Metaphone_metaphone_2_4_Test {

    @Test
    @DisplayName("metaphone word with 'P' followed by 'H' converts to 'F'")
    public void testTC68() {
        String txt = "phone";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        assertEquals("F", result);
    }
}