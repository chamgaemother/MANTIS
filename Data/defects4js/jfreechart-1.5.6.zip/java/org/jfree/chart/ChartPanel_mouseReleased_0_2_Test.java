package org.jfree.chart;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseReleased_0_2_Test {

//     @Test
//     @DisplayName("mouseReleased with zoomRectangle present, both zoomTrigger1 and zoomTrigger2 true, zoom direction right and vertical")
//     public void TC06() throws Exception {
        // Arrange
//         ChartPanel panel = new ChartPanel(null);
// 
        // Set private fields via reflection
//         Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
//         zoomRectangleField.setAccessible(true);
//         zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         Point2D zoomPoint = new Point2D.Double(50, 50);
//         zoomPointField.set(panel, zoomPoint);
// 
//         Field orientationField = ChartPanel.class.getDeclaredField("orientation");
//         orientationField.setAccessible(true);
//         orientationField.set(panel, PlotOrientation.HORIZONTAL);
// 
//         Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
//         rangeZoomableField.setAccessible(true);
//         rangeZoomableField.setBoolean(panel, true);
// 
//         Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
//         domainZoomableField.setAccessible(true);
//         domainZoomableField.setBoolean(panel, true);
// 
//         Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
//         zoomTriggerDistanceField.setAccessible(true);
//         zoomTriggerDistanceField.setInt(panel, 5);
// 
        // Mock MouseEvent
//         MouseEvent event = mock(MouseEvent.class);
//         when(event.getX()).thenReturn(60); // 60 - 50 >= 5 -> zoomTrigger1 = true
//         when(event.getY()).thenReturn(60); // 60 - 50 >= 5 -> zoomTrigger2 = true
// 
        // Spy on the panel to capture invocation
//         ChartPanel spyPanel = Mockito.spy(panel);
// 
        // Act
//         spyPanel.mouseReleased(event);
// 
        // Assert
//         Mockito.verify(spyPanel).zoom(any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("mouseReleased with zoomRectangle present, orientation VERTICAL, only rangeZoomable true, zoomTrigger2 true")
//     public void TC07() throws Exception {
        // Arrange
//         ChartPanel panel = new ChartPanel(null);
// 
        // Set private fields via reflection
//         Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
//         zoomRectangleField.setAccessible(true);
//         zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         Point2D zoomPoint = new Point2D.Double(50, 50);
//         zoomPointField.set(panel, zoomPoint);
// 
//         Field orientationField = ChartPanel.class.getDeclaredField("orientation");
//         orientationField.setAccessible(true);
//         orientationField.set(panel, PlotOrientation.VERTICAL);
// 
//         Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
//         rangeZoomableField.setAccessible(true);
//         rangeZoomableField.setBoolean(panel, true);
// 
//         Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
//         domainZoomableField.setAccessible(true);
//         domainZoomableField.setBoolean(panel, false);
// 
//         Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
//         zoomTriggerDistanceField.setAccessible(true);
//         zoomTriggerDistanceField.setInt(panel, 5);
// 
        // Mock MouseEvent
//         MouseEvent event = mock(MouseEvent.class);
//         when(event.getX()).thenReturn(50); // 50 - 50 = 0 < 5 -> zoomTrigger1 = false
//         when(event.getY()).thenReturn(60); // 60 - 50 >= 5 -> zoomTrigger2 = true
// 
        // Spy on the panel to capture invocation
//         ChartPanel spyPanel = Mockito.spy(panel);
// 
        // Act
//         spyPanel.mouseReleased(event);
// 
        // Assert
//         Mockito.verify(spyPanel).zoom(any(Rectangle2D.class));
//     }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, no zoom triggers met, verify zoomRectangle is erased using buffer")
    public void TC08() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);

        // Set private fields via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));

        Field useBufferField = ChartPanel.class.getDeclaredField("useBuffer");
        useBufferField.setAccessible(true);
        useBufferField.setBoolean(panel, true);

        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(panel, new Point2D.Double(50, 50));

        // Mock MouseEvent
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(52);
        when(event.getY()).thenReturn(52);

        // Spy on the panel to verify repaint
        ChartPanel spyPanel = Mockito.spy(panel);

        // Act
        spyPanel.mouseReleased(event);

        // Assert
        verify(spyPanel, times(1)).repaint(); // Ensure repaint was called

        // Verify that zoomPoint and zoomRectangle are null
        assertNull(getPrivateField(panel, "zoomPoint"));
        assertNull(getPrivateField(panel, "zoomRectangle"));
    }

//     @Test
//     @DisplayName("mouseReleased with zoomRectangle present, no zoom triggers met, verify zoomRectangle is erased without buffer")
//     public void TC09() throws Exception {
        // Arrange
//         ChartPanel panel = new ChartPanel(null);
// 
        // Set private fields via reflection
//         Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
//         zoomRectangleField.setAccessible(true);
//         zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));
// 
//         Field useBufferField = ChartPanel.class.getDeclaredField("useBuffer");
//         useBufferField.setAccessible(true);
//         useBufferField.setBoolean(panel, false);
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(panel, new Point2D.Double(50, 50));
// 
        // Mock MouseEvent
//         MouseEvent event = mock(MouseEvent.class);
//         when(event.getX()).thenReturn(52);
//         when(event.getY()).thenReturn(52);
// 
        // Spy on the panel to verify drawing
//         ChartPanel spyPanel = Mockito.spy(panel);
// 
        // Mock Graphics
//         Graphics2D graphics = mock(Graphics2D.class);
//         when(spyPanel.getGraphics()).thenReturn(graphics);
// 
        // Act
//         spyPanel.mouseReleased(event);
// 
        // Assert
//         verify(spyPanel, times(1)).drawZoomRectangle(graphics, true);
// 
        // Verify that zoomPoint and zoomRectangle are null
//         assertNull(getPrivateField(panel, "zoomPoint"));
//         assertNull(getPrivateField(panel, "zoomRectangle"));
//     }

//     @Test
//     @DisplayName("mouseReleased with popup trigger activated and popup menu is not null")
//     public void TC10() throws Exception {
        // Arrange
//         ChartPanel panel = new ChartPanel(null);
// 
        // Set private fields via reflection
//         Field panLastField = ChartPanel.class.getDeclaredField("panLast");
//         panLastField.setAccessible(true);
//         panLastField.set(panel, null);
// 
//         Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
//         zoomRectangleField.setAccessible(true);
//         zoomRectangleField.set(panel, null);
// 
//         Field popupField = ChartPanel.class.getDeclaredField("popup");
//         popupField.setAccessible(true);
//         JPopupMenu popupMenu = mock(JPopupMenu.class);
//         popupField.set(panel, popupMenu);
// 
        // Mock MouseEvent
//         MouseEvent event = mock(MouseEvent.class);
//         when(event.isPopupTrigger()).thenReturn(true);
//         when(event.getX()).thenReturn(100);
//         when(event.getY()).thenReturn(100);
// 
        // Spy on the panel to capture invocation
//         ChartPanel spyPanel = Mockito.spy(panel);
// 
        // Act
//         spyPanel.mouseReleased(event);
// 
        // Assert
//         verify(spyPanel, times(1)).displayPopupMenu(100, 100);
//     }

    /**
     * Utility method to get the value of a private field.
     */
    private Object getPrivateField(Object instance, String fieldName) throws Exception {
        Field field = ChartPanel.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(instance);
    }
}