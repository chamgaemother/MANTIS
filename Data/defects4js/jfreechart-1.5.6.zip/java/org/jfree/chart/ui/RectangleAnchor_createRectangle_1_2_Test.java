package org.jfree.chart.ui;

import static org.junit.jupiter.api.Assertions.*;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Test class for RectangleAnchor.createRectangle method.
 */
public class RectangleAnchor_createRectangle_1_2_Test {

    @Test
    @DisplayName("createRectangle with negative width and height sets rectangle with negative dimensions")
    public void testTC18() {
        // Given
        Size2D dimensions = new Size2D(-100.0, -200.0);
        double anchorX = 350.0;
        double anchorY = 450.0;
        RectangleAnchor anchor = RectangleAnchor.BOTTOM_RIGHT;

        // When
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // Then
        assertEquals(-100.0, result.getWidth(), "Width should be -100.0");
        assertEquals(-200.0, result.getHeight(), "Height should be -200.0");
    }

    @Test
    @DisplayName("createRectangle with extreme anchorX and anchorY values")
    public void testTC19() {
        // Given
        Size2D dimensions = new Size2D(1000.0, 2000.0);
        double anchorX = Double.MAX_VALUE;
        double anchorY = Double.MIN_VALUE;
        RectangleAnchor anchor = RectangleAnchor.BOTTOM_LEFT;

        // When
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // Then
        assertEquals(anchorX, result.getX(), "X should be anchorX");
        assertEquals(anchorY - dimensions.getHeight(), result.getY(), "Y should be anchorY minus height");
    }

    @Test
    @DisplayName("createRectangle with dimensions as Size2D subclass")
    public void testTC20() {
        // Given
        class CustomSize2D extends Size2D {
            public CustomSize2D(double width, double height) {
                super(width, height);
            }
        }
        Size2D dimensions = new CustomSize2D(150.0, 250.0);
        double anchorX = 400.0;
        double anchorY = 500.0;
        RectangleAnchor anchor = RectangleAnchor.TOP_RIGHT;

        // When
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // Then
        assertEquals(anchorX - dimensions.getWidth(), result.getX(), "X should be anchorX minus width");
        assertEquals(anchorY, result.getY(), "Y should be anchorY");
        assertEquals(150.0, result.getWidth(), "Width should be 150.0");
        assertEquals(250.0, result.getHeight(), "Height should be 250.0");
    }

}