package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.data.xy.XYDataset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBubbleRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class XYBubbleRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem throws IllegalStateException for invalid plot orientation")
    void TC06_drawItem_throwsIllegalStateException_for_invalid_plot_orientation() {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Configure mocks
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(null); // Invalid orientation

        // WHEN & THEN
        assertThrows(IllegalStateException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("drawItem handles VERTICAL plot orientation")
    void TC07_drawItem_handles_VERTICAL_plot_orientation() {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Configure mocks
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(15.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(series, item)).thenReturn(mock(Stroke.class));
        when(renderer.getItemOutlinePaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that Ellipse2D was created with correct coordinates for VERTICAL orientation
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawItem handles HORIZONTAL plot orientation")
    void TC08_drawItem_handles_HORIZONTAL_plot_orientation() {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 2;
        int item = 2;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 2;

        // Configure mocks
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(series, item)).thenReturn(mock(Stroke.class));
        when(renderer.getItemOutlinePaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that Ellipse2D was created with correct coordinates for HORIZONTAL orientation
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawItem does not draw item label when label visibility is false")
    void TC09_drawItem_does_not_draw_item_label_when_label_visibility_is_false() {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 3;
        int item = 3;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 3;

        // Configure mocks
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(25.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(series, item)).thenReturn(mock(Stroke.class));
        when(renderer.getItemOutlinePaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Since drawItemLabel is likely a protected method, create a spy
        XYBubbleRenderer spyRenderer = Mockito.spy(renderer);
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        verify(spyRenderer, never()).drawItemLabel(any(Graphics2D.class), any(PlotOrientation.class), any(XYDataset.class), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("drawItem draws item label in VERTICAL orientation when label is visible")
    void TC10_drawItem_draws_item_label_in_VERTICAL_orientation_when_label_is_visible() {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 4;
        int item = 4;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 4;

        // Configure mocks
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(30.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(series, item)).thenReturn(mock(Stroke.class));
        when(renderer.getItemOutlinePaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that drawItemLabel is called with correct parameters
        XYBubbleRenderer spyRenderer = Mockito.spy(renderer);
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        verify(spyRenderer).drawItemLabel(eq(g2), eq(PlotOrientation.VERTICAL), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble(), eq(false));
    }

}