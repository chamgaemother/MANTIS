package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class GraggBulirschStoerIntegrator_integrate_0_1_Test {

    @Test
    @DisplayName("Integrate forward when target time t is greater than current time")
    public void TC01_integrateForwardSuccessfully() throws Exception {
        // Initialize the integrator with appropriate parameters
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 100.0, 1.0e-8, 1.0e-10);

        // Initialize ExpandableStatefulODE with dummy equations and initial state
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyEquations());
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());

        double targetTime = 10.0;

        // Perform integration
        integrator.integrate(equations, targetTime);

        // Assertions
        assertEquals(targetTime, equations.getTime(), 1.0e-10, "Time after integration should match target time.");
        // Note: initial state shouldn't be compared here; this may require simulation-dependent values
    }

    @Test
    @DisplayName("Integrate backward when target time t is less than or equal to current time")
    public void TC02_integrateBackwardSuccessfully() throws Exception {
        // Initialize the integrator with appropriate parameters
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 100.0, 1.0e-8, 1.0e-10);

        // Initialize ExpandableStatefulODE with dummy equations and initial state
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyEquations());
        equations.setTime(10.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());

        double targetTime = 0.0;

        // Perform integration
        integrator.integrate(equations, targetTime);

        // Assertions
        assertEquals(targetTime, equations.getTime(), 1.0e-10, "Time after integration should match target time.");
        // Note: initial state shouldn't be compared here; this may require simulation-dependent values
    }

    @Test
    @DisplayName("Initialize integration with sequence length of one (boundary case)")
    public void TC03_integrateWithSequenceLengthOne() throws Exception {
        // Initialize the integrator with a sequence array of length one
        int[] sequence = {2};
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 100.0, 1.0e-8, 1.0e-10);
        setPrivateField(integrator, "sequence", sequence);

        // Initialize ExpandableStatefulODE with dummy equations and initial state
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyEquations());
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());

        double targetTime = 1.0;

        // Perform integration
        integrator.integrate(equations, targetTime);

        // Assertions
        assertEquals(targetTime, equations.getTime(), 1.0e-10, "Time after integration should match target time.");
    }

    @Test
    @DisplayName("Initialize integration with sequence length greater than expected (multiple iterations)")
    public void TC04_integrateWithMultipleSequenceIterations() throws Exception {
        // Initialize the integrator with a sequence array of length greater than one
        int[] sequence = {2, 4, 6};
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 100.0, 1.0e-8, 1.0e-10);
        setPrivateField(integrator, "sequence", sequence);

        // Initialize ExpandableStatefulODE with dummy equations and initial state
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyEquations());
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());

        double targetTime = 10.0;

        // Perform integration
        integrator.integrate(equations, targetTime);

        // Assertions
        assertEquals(targetTime, equations.getTime(), 1.0e-10, "Time after integration should match target time.");
    }

    @Test
    @DisplayName("Integration step is rejected due to high error, triggering step size reduction")
    public void TC05_integrateWithHighErrorTriggeringStepRejection() throws Exception {
        // Initialize the integrator with parameters that will cause high error
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 100.0, 1.0e-2, 1.0e-3);

        // Initialize ExpandableStatefulODE with dummy equations that produce high error
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new HighErrorEquations());
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState.clone());

        double targetTime = 10.0;

        // Perform integration and expect it to handle step rejection internally
        integrator.integrate(equations, targetTime);

        // Assertions
        assertEquals(targetTime, equations.getTime(), 1.0e-10, "Time after integration should match target time.");
        // Note: Adapted tolerance for high error case
    }

    /**
     * Utility method to set private fields via reflection.
     */
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    /**
     * DummyEquations class for testing purposes.
     */
    private static class DummyEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 2;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = -y[1];
            yDot[1] = y[0];
        }
    }

    /**
     * HighErrorEquations class to simulate high error conditions.
     */
    private static class HighErrorEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 2;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = 1e10; // Introduce high derivative values to cause high error
            yDot[1] = -1e10;
        }
    }
}
