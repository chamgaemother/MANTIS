package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class TarArchiveOutputStream_putArchiveEntry_0_5_Test {

    @Test
    @DisplayName("putArchiveEntry with symbolic link and bigNumberMode STAR")
    void TC21_putArchiveEntry_with_symbolic_link_and_bigNumberMode_STAR() throws Exception {
        // GIVEN
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());
        // Using reflection to set private field bigNumberMode to BIGNUMBER_STAR (assuming value 1)
        Field bigNumberModeField = TarArchiveOutputStream.class.getDeclaredField("bigNumberMode");
        bigNumberModeField.setAccessible(true);
        bigNumberModeField.setInt(outputStream, 1);

        TarArchiveEntry entry = new TarArchiveEntry("dummy");
        entry.setLinkName("symbolic_link_long_name");

        // WHEN
        outputStream.putArchiveEntry(entry);

        // THEN
        // Verify haveUnclosedEntry is true using reflection
        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
        haveUnclosedEntryField.setAccessible(true);
        assertTrue(haveUnclosedEntryField.getBoolean(outputStream), "haveUnclosedEntry should be true");
    }

//     @Test
//     @DisplayName("putArchiveEntry with multiple PAX headers and non-global entry")
//     void TC22_putArchiveEntry_with_multiple_PAX_headers_and_non_global_entry() throws Exception {
        // GIVEN
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());
//         Map<String, String> extraHeaders = new HashMap<>();
//         extraHeaders.put("key1", "value1");
//         extraHeaders.put("key2", "value2");
//         TarArchiveEntry entry = new TarArchiveEntry("dummy");
//         entry.setExtraPaxHeaders(extraHeaders);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
        // Use reflection to access the written PAX headers
//         Map<String, String> writtenHeaders = entry.getExtraPaxHeaders();
//         assertEquals(2, writtenHeaders.size(), "There should be two extra PAX headers");
//         assertEquals("value1", writtenHeaders.get("key1"));
//         assertEquals("value2", writtenHeaders.get("key2"));
//     }

    @Test
    @DisplayName("putArchiveEntry with entry size exactly at the boundary limit")
    void TC23_putArchiveEntry_with_entry_size_at_boundary_limit() throws Exception {
        // GIVEN
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());
        TarArchiveEntry entry = new TarArchiveEntry("dummy");
        entry.setSize(TarConstants.MAXSIZE);

        // WHEN
        outputStream.putArchiveEntry(entry);

        // THEN
        // Verify that currSize is set correctly using reflection
        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
        currSizeField.setAccessible(true);
        long currSize = currSizeField.getLong(outputStream);
        assertEquals(TarConstants.MAXSIZE, currSize, "currSize should be set to MAXSIZE");
    }

//     @Test
//     @DisplayName("putArchiveEntry with empty extra PAX headers")
//     void TC24_putArchiveEntry_with_empty_extra_PAX_headers() throws Exception {
        // GIVEN
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());
//         Map<String, String> extraHeaders = new HashMap<>();
//         TarArchiveEntry entry = new TarArchiveEntry("dummy");
//         entry.setExtraPaxHeaders(extraHeaders);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
        // Use reflection to verify no additional PAX headers are added
//         Map<String, String> writtenHeaders = entry.getExtraPaxHeaders();
//         assertTrue(writtenHeaders.isEmpty(), "No additional PAX headers should be added");
//     }

    @Test
    @DisplayName("putArchiveEntry with null link name when entry is symbolic link")
    void TC25_putArchiveEntry_with_null_link_name_when_entry_is_symbolic_link() {
        // GIVEN
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());
        TarArchiveEntry entry = new TarArchiveEntry("dummy");
        entry.setLinkName(null);  // Assuming setLinkName should be allowed to set to null

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> outputStream.putArchiveEntry(entry), "Expected putArchiveEntry to throw IllegalArgumentException due to null link name");
    }
}