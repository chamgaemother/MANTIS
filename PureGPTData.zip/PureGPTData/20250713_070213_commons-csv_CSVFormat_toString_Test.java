import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVFormat.Predefined;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CSVFormatTest {

    @Test
    void testDefaultFormatToString() {
        CSVFormat format = CSVFormat.DEFAULT;
        String expected = "Delimiter=<,> Escape=<null> QuoteChar=<\"> QuoteMode=<null> CommentStart=<null> " +
                          "NullString=<null> RecordSeparator=<\r\n> EmptyLines:ignored SkipHeaderRecord:false ";
        assertEquals(expected, format.toString());
    }
    
    @Test
    void testCustomFormatWithEscapeAndQuotes() {
        CSVFormat format = CSVFormat.newFormat(';')
                .withQuote('"')
                .withEscape('\\')
                .withCommentMarker('#')
                .withNullString("NULL")
                .withRecordSeparator("\n")
                .withIgnoreEmptyLines(false)
                .withHeader("Col1", "Col2")
                .withHeaderComments("Header Comment")
                .withQuoteMode(CSVFormat.QuoteMode.ALL)
                .withIgnoreSurroundingSpaces()
                .withSkipHeaderRecord()
                .withIgnoreHeaderCase();
        
        String expected = "Delimiter=<;> Escape=<\\> QuoteChar=<\"> QuoteMode=<ALL> CommentStart=<#> " +
                          "NullString=<NULL> RecordSeparator=<\n> IgnoreHeaderCase:ignored " +
                          "SkipHeaderRecord:true HeaderComments:[Header Comment] Header:[Col1, Col2]";
        assertEquals(expected, format.toString());
    }

    @Test
    void testFormatWithNoEscapeNoQuote() {
        CSVFormat format = CSVFormat.newFormat(';')
                .withIgnoreEmptyLines()
                .withTrailingDelimiter()
                .withTrim();
        
        String expected = "Delimiter=<;> EmptyLines:ignored SurroundingSpaces:ignored " +
                          "SkipHeaderRecord:false TrailingDelimiter:true";
        assertEquals(expected, format.toString());
    }
    
    @Test
    void testFormatWithNullRecordSeparator() {
        CSVFormat format = CSVFormat.newFormat(';')
                .withQuote('"')
                .withEscape('\\')
                .withNullString("NULL");
        
        String expected = "Delimiter=<;> Escape=<\\> QuoteChar=<\"> NullString=<NULL> SkipHeaderRecord:false ";
        assertEquals(expected, format.toString());
    }
    
    @Test
    void testFormatWithMinimalBranchPaths() {
        CSVFormat format = CSVFormat.newFormat(',')
                .withQuote('"')
                .withRecordSeparator("\r")
                .withIgnoreEmptyLines(false);
        
        String expected = "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r> SkipHeaderRecord:false ";
        assertEquals(expected, format.toString());
    }
    
    @Test
    void testRFC4180Format() {
        CSVFormat format = CSVFormat.RFC4180;
        String expected = "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> SkipHeaderRecord:false ";
        assertEquals(expected, format.toString());
    }
    
    @Test
    void testFormatWithEmptyHeaderAndComments() {
        CSVFormat format = CSVFormat.newFormat(',')
                .withQuote('"')
                .withRecordSeparator("\r\n")
                .withHeader()
                .withHeaderComments((Object[]) null);

        String expected = "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> SkipHeaderRecord:false ";
        assertEquals(expected, format.toString());
    }
    
    @Test
    void testMysqlFormatWithCustomDelimiter() {
        CSVFormat format = CSVFormat.MYSQL.withDelimiter('|');
        String expected = "Delimiter=<|> Escape=<\\> RecordSeparator=<\n> NullString=\\N QuoteMode=ALL_NON_NULL";
        assertEquals(expected, format.toString());
    }
}