package com.fasterxml.jackson.dataformat.xml.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class StaxUtil_sanitizeXmlTypeName_0_1_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName(null) returns null")
    void TC01_sanitizeXmlTypeName_null_input() {
        String name = null;
        String result = StaxUtil.sanitizeXmlTypeName(name);
        assertNull(result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with no trailing '[]' and no disallowed characters returns original name")
    void TC02_sanitizeXmlTypeName_no_modifications() {
        String name = "ValidName";
        String result = StaxUtil.sanitizeXmlTypeName(name);
        assertEquals("ValidName", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with single trailing '[]' and name ends with 's', appends 'es'")
    void TC03_sanitizeXmlTypeName_single_array_trailing_and_ends_with_s() {
        String name = "Classes[]";
        String result = StaxUtil.sanitizeXmlTypeName(name);
        assertEquals("Classeses", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with multiple trailing '[]' and name does not end with 's', appends 's'")
    void TC04_sanitizeXmlTypeName_multiple_array_trailing_and_does_not_end_with_s() {
        String name = "Item[][]";
        String result = StaxUtil.sanitizeXmlTypeName(name);
        assertEquals("Items", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with disallowed character '$' is replaced with '.'")
    void TC05_sanitizeXmlTypeName_replaces_dollar_with_dot() {
        String name = "Price$Value";
        String result = StaxUtil.sanitizeXmlTypeName(name);
        assertEquals("Price.Value", result);
    }

}