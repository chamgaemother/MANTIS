import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.general.DatasetUtils;
import org.jfree.data.Range;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DatasetUtilsTest {

    private DefaultCategoryDataset dataset;
    private KeyToGroupMap map;

    @BeforeEach
    void setUp() {
        dataset = new DefaultCategoryDataset();
        map = new KeyToGroupMap("Group 1");
    }

    @Test
    void testNullDataset() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.findStackedRangeBounds(null, map);
        });
    }

    @Test
    void testEmptyDataset() {
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertNull(range);
    }

    @Test
    void testSingleGroupSingleSeriesPositiveValues() {
        dataset.addValue(1.0, "Series 1", "Category 1");
        map.mapKeyToGroup("Series 1", "Group 1");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(0.0, 1.0), range);
    }

    @Test
    void testSingleGroupSingleSeriesNegativeValues() {
        dataset.addValue(-2.0, "Series 1", "Category 1");
        map.mapKeyToGroup("Series 1", "Group 1");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(-2.0, 0.0), range);
    }

    @Test
    void testSingleGroupMultipleSeries() {
        dataset.addValue(2.0, "Series 1", "Category 1");
        dataset.addValue(-3.0, "Series 2", "Category 1");
        map.mapKeyToGroup("Series 1", "Group 1");
        map.mapKeyToGroup("Series 2", "Group 1");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(-3.0, 2.0), range);
    }

    @Test
    void testMultipleGroups() {
        dataset.addValue(4.0, "Series 1", "Category 1");
        dataset.addValue(-1.0, "Series 2", "Category 1");
        dataset.addValue(3.0, "Series 3", "Category 1");
        map.mapKeyToGroup("Series 1", "Group 1");
        map.mapKeyToGroup("Series 2", "Group 2");
        map.mapKeyToGroup("Series 3", "Group 2");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertEquals(new Range(-1.0, 7.0), range);
    }

    @Test
    void testNullValuesInDataset() {
        dataset.addValue(null, "Series 1", "Category 1");
        map.mapKeyToGroup("Series 1", "Group 1");
        Range range = DatasetUtils.findStackedRangeBounds(dataset, map);
        assertNull(range);
    }
}