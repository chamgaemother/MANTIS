import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.GradientBarPainter;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GradientBarPainterTest {

    @Test
    void testPaintBarWithBasicVerticalBar() {
        GradientBarPainter painter = new GradientBarPainter(0.1, 0.2, 0.8);
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.RED);
        when(renderer.isDrawBarOutline()).thenReturn(false);
        
        RectangularShape bar = new Rectangle2D.Double(0, 0, 100, 200);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        
        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, never()).draw(bar);
    }

    @Test
    void testPaintBarWithBrighterVerticalBarColor() {
        GradientBarPainter painter = new GradientBarPainter(0.1, 0.2, 0.8);
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.BLUE);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(anyInt(), anyInt())).thenReturn(new BasicStroke(1.0f));
        when(renderer.getItemOutlinePaint(anyInt(), anyInt())).thenReturn(Color.BLACK);
        
        RectangularShape bar = new Rectangle2D.Double(0, 0, 100, 200);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        
        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, atLeastOnce()).draw(bar);
    }

    @Test
    void testPaintBarWithNullItemPaint() {
        GradientBarPainter painter = new GradientBarPainter(0.1, 0.2, 0.8);
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(null);
        
        RectangularShape bar = new Rectangle2D.Double(0, 0, 100, 200);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);

        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    void testPaintBarWithAlphaZeroColorVertical() {
        GradientBarPainter painter = new GradientBarPainter(0.1, 0.2, 0.8);
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(new Color(0, 0, 0, 0));
        
        RectangularShape bar = new Rectangle2D.Double(0, 0, 100, 200);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);

        verify(g2, never()).fill(any());
    }

    @Test
    void testPaintBarWithAlphaZeroColorHorizontal() {
        GradientBarPainter painter = new GradientBarPainter(0.1, 0.2, 0.8);
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(new Color(0, 0, 0, 0));
        
        RectangularShape bar = new Rectangle2D.Double(0, 0, 200, 100);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.LEFT);

        verify(g2, never()).fill(any());
    }
    
    @Test
    void testPaintBarWithBasicHorizontalBar() {
        GradientBarPainter painter = new GradientBarPainter(0.1, 0.2, 0.8);
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.GREEN);
        when(renderer.isDrawBarOutline()).thenReturn(false);
        
        RectangularShape bar = new Rectangle2D.Double(0, 0, 200, 100);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.LEFT);
        
        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, never()).draw(bar);
    }

    @Test
    void testPaintBarWithGradientPaint() {
        GradientBarPainter painter = new GradientBarPainter(0.1, 0.2, 0.8);
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        GradientPaint gp = new GradientPaint(0, 0, Color.RED, 1, 1, Color.YELLOW);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(gp);
        
        RectangularShape bar = new Rectangle2D.Double(0, 0, 100, 200);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        
        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).fill(any());
    }
}