package org.joda.time.tz;

import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.util.Set;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ZoneInfoCompiler_parseDataFile_2_1_Test {

    @Test
    @DisplayName("parseDataFile processes RULE_LOOKUP line with insufficient tokens, expecting IllegalArgumentException")
    void TC28_parseDataFile_ruleLookup_insufficientTokens() throws Exception {
        // Arrange
        String input = "rule summer 1980"; // Missing tokens
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean backward = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Reflectively add 'summer' to RULE_LOOKUP
        Field ruleLookupField = ZoneInfoCompiler.class.getDeclaredField("RULE_LOOKUP");
        ruleLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> ruleLookup = (Set<String>) ruleLookupField.get(null);
        ruleLookup.add("summer");

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            compiler.parseDataFile(in, backward);
        });
    }

    @Test
    @DisplayName("parseDataFile processes ZONE_LOOKUP with invalid time token, expecting IllegalArgumentException")
    void TC29_parseDataFile_zoneLookup_invalidTimeToken() throws Exception {
        // Arrange
        String input = "Europe/London GMXX"; // Invalid time token
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean backward = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Reflectively add 'europe/london' to ZONE_LOOKUP
        Field zoneLookupField = ZoneInfoCompiler.class.getDeclaredField("ZONE_LOOKUP");
        zoneLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> zoneLookup = (Set<String>) zoneLookupField.get(null);
        zoneLookup.add("europe/london");

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            compiler.parseDataFile(in, backward);
        });
    }

    @Test
    @DisplayName("parseDataFile processes RULE_LOOKUP line with non-integer years, expecting NumberFormatException")
    void TC30_parseDataFile_ruleLookup_nonIntegerYears() throws Exception {
        // Arrange
        String input = "rule summer abcd efgh - Mar 21 2:00 1:00 S"; // Non-integer years
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean backward = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Reflectively add 'summer' to RULE_LOOKUP
        Field ruleLookupField = ZoneInfoCompiler.class.getDeclaredField("RULE_LOOKUP");
        ruleLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> ruleLookup = (Set<String>) ruleLookupField.get(null);
        ruleLookup.add("summer");

        // Act & Assert
        assertThrows(NumberFormatException.class, () -> {
            compiler.parseDataFile(in, backward);
        });
    }

    @Test
    @DisplayName("parseDataFile processes ZONE_LOOKUP line with excessive tokens, expecting proper parsing without exception")
    void TC31_parseDataFile_zoneLookup_excessiveTokens() throws Exception {
        // Arrange
        String input = "Europe/London GMT0 ExtraToken1 ExtraToken2"; // Excessive tokens
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean backward = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Reflectively add 'europe/london' to ZONE_LOOKUP
        Field zoneLookupField = ZoneInfoCompiler.class.getDeclaredField("ZONE_LOOKUP");
        zoneLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> zoneLookup = (Set<String>) zoneLookupField.get(null);
        zoneLookup.add("europe/london");

        // Act
        compiler.parseDataFile(in, backward);

        // Assert
        // Reflectively access iZones to verify 'Europe/London' was added
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Object> iZones = (List<Object>) iZonesField.get(compiler);
        boolean found = false;
        for (Object zone : iZones) {
            Field nameField = zone.getClass().getDeclaredField("iName");
            nameField.setAccessible(true);
            String zoneName = (String) nameField.get(zone);
            if ("Europe/London".equals(zoneName)) {
                found = true;
                break;
            }
        }
        assertTrue(found, "Zone 'Europe/London' was not added to iZones");
    }

    @Test
    @DisplayName("parseDataFile processes RULE_LOOKUP line with missing saveMillis, expecting IllegalArgumentException")
    void TC32_parseDataFile_ruleLookup_missingSaveMillis() throws Exception {
        // Arrange
        String input = "rule summer 1980 2000 - Mar 21 2:00"; // Missing saveMillis and letterS
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean backward = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Reflectively add 'summer' to RULE_LOOKUP
        Field ruleLookupField = ZoneInfoCompiler.class.getDeclaredField("RULE_LOOKUP");
        ruleLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> ruleLookup = (Set<String>) ruleLookupField.get(null);
        ruleLookup.add("summer");

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            compiler.parseDataFile(in, backward);
        });
    }
}