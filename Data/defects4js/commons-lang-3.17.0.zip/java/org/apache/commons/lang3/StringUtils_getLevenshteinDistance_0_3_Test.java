package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.StringUtils;

public class StringUtils_getLevenshteinDistance_0_3_Test {

    @Test
    @DisplayName("getLevenshteinDistance(\"distance\", \"difference\", 5) returns correct distance within threshold")
    void TC11_correct_distance_within_threshold() {
        // GIVEN
        CharSequence s = "distance";
        CharSequence t = "difference";
        int threshold = 5;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(5, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"abcdef\", \"abcxyz\", 3) returns -1 when computed distance exceeds threshold after iterations")
    void TC12_distance_exceeds_threshold_after_iterations() {
        // GIVEN
        CharSequence s = "abcdef";
        CharSequence t = "abcxyz";
        int threshold = 3;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(-1, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"example\", \"samples\", 4) returns correct distance exactly at threshold")
    void TC13_distance_exactly_at_threshold() {
        // GIVEN
        CharSequence s = "example";
        CharSequence t = "samples";
        int threshold = 4;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(4, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"a\", \"b\", 1) returns 1 for single-character substitution within threshold")
    void TC14_single_character_substitution_within_threshold() {
        // GIVEN
        CharSequence s = "a";
        CharSequence t = "b";
        int threshold = 1;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(1, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"insert\", \"insertion\", 3) returns -1 when distance exceeds threshold due to insertions")
    void TC15_insertions_exceed_threshold() {
        // GIVEN
        CharSequence s = "insert";
        CharSequence t = "insertion";
        int threshold = 3;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(-1, result);
    }

}