import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.reflect.Method;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class MethodLookupUtilsTest {

    // Helper class with various static methods for testing
    public static class TestClass {
        public static void noParams() {}
        public static void withParams(String s) {}
        public static void withParams(Number n) {}
        public static void withParams(String s, Integer i) {}
        public static void withParams(Object o) {}
        public static void ambiguous(String s) {}
        public static void ambiguous(Integer i) {}
        public static void varArgsMethod(String... args) {}
        public static void nullParamMethod(String s, Integer i) {}
        public static void nonStaticMethod() {}
    }

    @Test
    void testLookupStaticMethod_NullTargetClass() {
        assertThrows(NullPointerException.class, () ->
                MethodLookupUtils.lookupStaticMethod(null, "anyMethod", new Object[]{})
        );
    }

    @Test
    void testLookupStaticMethod_NullMethodName() {
        assertThrows(NullPointerException.class, () ->
                MethodLookupUtils.lookupStaticMethod(TestClass.class, null, new Object[]{})
        );
    }

    @Test
    void testLookupStaticMethod_NullParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "noParams", null);
        assertNotNull(method);
        assertEquals("noParams", method.getName());
        assertEquals(0, method.getParameterCount());
    }

    @Test
    void testLookupStaticMethod_EmptyParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "noParams", new Object[]{});
        assertNotNull(method);
        assertEquals("noParams", method.getName());
        assertEquals(0, method.getParameterCount());
    }

    @Test
    void testLookupStaticMethod_ExactMatch() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "withParams", new Object[]{"test"});
        assertNotNull(method);
        assertEquals("withParams", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethod_TypeConversionMatch() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "withParams", new Object[]{Integer.valueOf(10)});
        assertNotNull(method);
        assertEquals("withParams", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(Number.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethod_AmbiguousMethods() {
        Exception exception = assertThrows(JXPathException.class, () ->
                MethodLookupUtils.lookupStaticMethod(TestClass.class, "ambiguous", new Object[]{"test"})
        );
        assertTrue(exception.getMessage().contains("Ambiguous method call"));
    }

    @Test
    void testLookupStaticMethod_MethodNotFound() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "nonExistentMethod", new Object[]{});
        assertNull(method);
    }

    @Test
    void testLookupStaticMethod_MethodNotStatic() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "nonStaticMethod", new Object[]{});
        assertNull(method);
    }

    @Test
    void testLookupStaticMethod_WithMultipleParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "withParams", new Object[]{"test", 5});
        assertNotNull(method);
        assertEquals("withParams", method.getName());
        assertEquals(2, method.getParameterCount());
        assertEquals(String.class, method.getParameterTypes()[0]);
        assertEquals(Integer.class, method.getParameterTypes()[1]);
    }

    @Test
    void testLookupStaticMethod_WithNullParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "nullParamMethod", new Object[]{null, 10});
        assertNotNull(method);
        assertEquals("nullParamMethod", method.getName());
        assertEquals(2, method.getParameterCount());
        assertEquals(String.class, method.getParameterTypes()[0]);
        assertEquals(Integer.class, method.getParameterTypes()[1]);
    }

    @Test
    void testLookupStaticMethod_WithAllNullParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "nullParamMethod", new Object[]{null, null});
        assertNull(method);
    }

    @Test
    void testLookupStaticMethod_WithVarArgs() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "varArgsMethod", new Object[]{"a", "b"});
        assertNotNull(method);
        assertEquals("varArgsMethod", method.getName());
        assertEquals(1, method.getParameterCount());
        assertTrue(method.isVarArgs());
    }

    @Test
    void testLookupStaticMethod_InheritedStaticMethod() throws NoSuchMethodException {
        class SubClass extends TestClass {}
        Method expected = TestClass.class.getMethod("withParams", String.class);
        Method actual = MethodLookupUtils.lookupStaticMethod(SubClass.class, "withParams", new Object[]{"test"});
        assertNotNull(actual);
        assertEquals(expected, actual);
    }

    @Test
    void testLookupStaticMethod_PrimitiveTypeMatch() {
        class PrimitiveTest {
            public static void primitiveMethod(int num) {}
        }
        Method method = MethodLookupUtils.lookupStaticMethod(PrimitiveTest.class, "primitiveMethod", new Object[]{Integer.valueOf(5)});
        assertNotNull(method);
        assertEquals("primitiveMethod", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(int.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethod_BoxedTypeMatch() {
        class BoxedTest {
            public static void boxedMethod(Integer num) {}
        }
        Method method = MethodLookupUtils.lookupStaticMethod(BoxedTest.class, "boxedMethod", new Object[]{5});
        assertNotNull(method);
        assertEquals("boxedMethod", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(Integer.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethod_SuperclassParameter() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "withParams", new Object[]{new Object()});
        assertNotNull(method);
        assertEquals("withParams", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(Object.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethod_InterfaceParameter() {
        class InterfaceTest {
            public static void interfaceMethod(Runnable r) {}
        }
        Method method = MethodLookupUtils.lookupStaticMethod(InterfaceTest.class, "interfaceMethod", new Object[]{(Runnable) () -> {}});
        assertNotNull(method);
        assertEquals("interfaceMethod", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(Runnable.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethod_MultiplePotentialMatches() {
        class MultipleMatches {
            public static void match(Number n) {}
            public static void match(Integer i) {}
        }
        Method method = MethodLookupUtils.lookupStaticMethod(MultipleMatches.class, "match", new Object[]{10});
        assertNotNull(method);
        // Should prefer exact match with Integer
        assertEquals("match", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(Integer.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethod_NoParametersButMethodExpectsSome() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "withParams", new Object[]{});
        assertNull(method);
    }

    @Test
    void testLookupStaticMethod_ExtraParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "noParams", new Object[]{"extra"});
        assertNull(method);
    }

    @Test
    void testLookupStaticMethod_FewerParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "withParams", new Object[]{});
        assertNull(method);
    }
}