package com.fasterxml.jackson.core.io;

import static org.junit.jupiter.api.Assertions.*;

import java.net.URI;
import java.net.URL;

import org.junit.jupiter.api.Test;

class ContentReferenceTest {

    @Test
    void appendSourceDescription_nullSrcRef_redacted() {
        ContentReference redacted = ContentReference.redacted();
        StringBuilder sb = new StringBuilder();
        redacted.appendSourceDescription(sb);
        assertEquals("REDACTED (`StreamReadFeature.INCLUDE_SOURCE_IN_LOCATION` disabled)", sb.toString());
    }

    @Test
    void appendSourceDescription_nullSrcRef_unknown() {
        ContentReference unknown = ContentReference.unknown();
        StringBuilder sb = new StringBuilder();
        unknown.appendSourceDescription(sb);
        assertEquals("UNKNOWN", sb.toString());
    }

    @Test
    void appendSourceDescription_javaClass_withTextualContent_charSequence() {
        ContentReference ref = ContentReference.construct(true, "Sample text");
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(String)\"Sample text\"", sb.toString());
    }

    @Test
    void appendSourceDescription_javaClass_withTextualContent_charSequence_truncated() {
        ContentReference ref = ContentReference.construct(true, "A".repeat(600));
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        String expected = "(String)\"" + "A".repeat(500) + "[truncated 100 chars]";
        assertTrue(sb.toString().startsWith("(String)\""));
        assertTrue(sb.toString().contains("[truncated 100 chars]"));
    }

    @Test
    void appendSourceDescription_javaClass_withTextualContent_charArray() {
        char[] chars = "Character array content".toCharArray();
        ContentReference ref = ContentReference.construct(true, chars, 0, chars.length, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(char[])\"Character array content\"", sb.toString());
    }

    @Test
    void appendSourceDescription_javaClass_withTextualContent_byteArray_truncated() {
        byte[] bytes = new byte[600];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = 'A';
        }
        ContentReference ref = ContentReference.construct(true, bytes, 0, bytes.length, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertTrue(sb.toString().startsWith("(byte[])\""));
        assertTrue(sb.toString().contains("[truncated 100 bytes]"));
    }

    @Test
    void appendSourceDescription_javaClass_noTextualContent_byteArray_length_negative() {
        byte[] bytes = new byte[300];
        ContentReference ref = ContentReference.construct(false, bytes, 0, -1, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(byte[])[300 bytes]", sb.toString());
    }

    @Test
    void appendSourceDescription_javaClass_noTextualContent_byteArray_length_positive() {
        byte[] bytes = new byte[300];
        ContentReference ref = ContentReference.construct(false, bytes, 50, 100, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(byte[])[100 bytes]", sb.toString());
    }

    @Test
    void appendSourceDescription_nonJavaClass_withTextualContent_nonSupportedType() {
        URI uri = URI.create("http://example.com");
        ContentReference ref = ContentReference.construct(true, uri, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(java.net.URI)", sb.toString());
    }

    @Test
    void appendSourceDescription_nonJavaClass_withTextualContent_byteArray_truncated() {
        byte[] bytes = new byte[600];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = 'B';
        }
        ContentReference ref = ContentReference.construct(true, bytes, 0, bytes.length, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertTrue(sb.toString().startsWith("(byte[])\""));
        assertTrue(sb.toString().contains("[truncated 100 bytes]"));
    }

    @Test
    void appendSourceDescription_classStartsWithJavaSimpleName() {
        URL url = ContentReference.class.getResource("/dummy");
        ContentReference ref = ContentReference.construct(true, url, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertTrue(sb.toString().startsWith("(URL)"));
    }

    @Test
    void appendSourceDescription_charArray_truncated() {
        char[] chars = new char[600];
        for (int i = 0; i < chars.length; i++) {
            chars[i] = 'C';
        }
        ContentReference ref = ContentReference.construct(true, chars, 0, chars.length, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertTrue(sb.toString().startsWith("(char[])\""));
        assertTrue(sb.toString().contains("[truncated 100 chars]"));
    }

    @Test
    void appendSourceDescription_nonTextualContent_nonByteArray() {
        Object obj = new Object();
        ContentReference ref = ContentReference.construct(false, obj, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(java.lang.Object)", sb.toString());
    }

    @Test
    void appendSourceDescription_charSequence_withControlChars() {
        ContentReference ref = ContentReference.construct(true, "Hello\nWorld\rTest\t");
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertTrue(sb.toString().contains("\\u000A"));
        assertTrue(sb.toString().contains("\\u000D"));
        assertFalse(sb.toString().contains("\\u0009"));
    }

    @Test
    void appendSourceDescription_byteArray_withOffsetAndLength() {
        byte[] bytes = "HelloByteArray".getBytes();
        ContentReference ref = ContentReference.construct(true, bytes, 5, 4, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(byte[])\"Byte\"", sb.toString());
    }

    @Test
    void appendSourceDescription_charArray_withOffsetAndLength() {
        char[] chars = "HelloCharArray".toCharArray();
        ContentReference ref = ContentReference.construct(true, chars, 5, 4, ErrorReportConfiguration.defaults());
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(char[])\"Char\"", sb.toString());
    }

    @Test
    void appendSourceDescription_withNonPrintableCharacters() {
        String str = "Hello\u0001World";
        ContentReference ref = ContentReference.construct(true, str);
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(String)\"Hello\\u0001World\"", sb.toString());
    }

    @Test
    void appendSourceDescription_classNotJava_notArray() {
        URI uri = URI.create("http://example.com/resource");
        ContentReference ref = ContentReference.construct(false, uri);
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(java.net.URI)", sb.toString());
    }

    @Test
    void appendSourceDescription_classIsArray_notTextual() {
        int[] intArray = {1, 2, 3};
        ContentReference ref = ContentReference.construct(false, intArray);
        StringBuilder sb = new StringBuilder();
        ref.appendSourceDescription(sb);
        assertEquals("(int[])", sb.toString());
    }

}