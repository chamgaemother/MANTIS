package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.charset.StandardCharsets;
import com.fasterxml.jackson.core.io.JsonStringEncoder;

public class JsonStringEncoder_encodeAsUTF8_0_3_Test {

    @Test
    @DisplayName("encodeAsUTF8 with mixed ASCII and multi-byte characters encodes correctly")
    public void test_TC11() {
        String text = "Hello Ã© World à¥";
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.encodeAsUTF8(text);
        byte[] expected = "Hello Ã© World à¥".getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }

    @Test
    @DisplayName("encodeAsUTF8 with string that exactly fills initial buffer")
    public void test_TC12() {
        String text = "1234567890ABCDEF";
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.encodeAsUTF8(text);
        byte[] expected = "1234567890ABCDEF".getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }

    @Test
    @DisplayName("encodeAsUTF8 with repeated surrogate pairs")
    public void test_TC13() {
        String text = "\uD83D\uDE00\uD83D\uDE01";
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.encodeAsUTF8(text);
        byte[] expected = "\uD83D\uDE00\uD83D\uDE01".getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }

    @Test
    @DisplayName("encodeAsUTF8 triggers _illegal for first block of surrogate pair being out of range")
    public void test_TC14() {
        String text = "\uDFFF\uDE00";
        JsonStringEncoder encoder = new JsonStringEncoder();
        assertThrows(IllegalArgumentException.class, () -> {
            encoder.encodeAsUTF8(text);
        });
    }

    @Test
    @DisplayName("encodeAsUTF8 with multi-byte characters exceeding buffer multiple times")
    public void test_TC15() {
        String text = "Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©Ã©";
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.encodeAsUTF8(text);
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result);
    }
}