package org.apache.commons.compress.archivers.cpio;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;

public class CpioArchiveInputStream_getNextCPIOEntry_2_1_Test {

    @Test
    @DisplayName("Throws IOException when magic string is unknown")
    public void TC23_throwsIOExceptionForUnknownMagic() throws Exception {
        // Given
        byte[] unknownMagic = "UNKNOWN".getBytes();
        InputStream inputStream = new ByteArrayInputStream(unknownMagic);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);
        
        // When & Then
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        }, "Expected IOException for unknown magic string");
        assertTrue(exception.getMessage().contains("Unknown magic"), "Exception message should indicate unknown magic");
    }
    
    @Test
    @DisplayName("Throws IOException when entry has mode=0 but name is not CPIO_TRAILER")
    public void TC24_throwsIOExceptionForInvalidModeEntry() throws Exception {
        // Given
        byte[] invalidModeEntry = "07070100000000000000000000000000000000000000000000000000000000test\0".getBytes();
        InputStream inputStream = new ByteArrayInputStream(invalidModeEntry);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);
        
        // When & Then
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        }, "Expected IOException for entry with mode=0 and non-trailer name");
        assertTrue(exception.getMessage().contains("Mode 0 only allowed in the trailer"), "Exception message should indicate invalid mode for entry name");
    }
}