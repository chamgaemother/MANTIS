package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class RandomStringUtils_random_0_7_Test {

    @Test
    @DisplayName("random(count, start=48, end=58, letters=false, numbers=true, chars=null, random) handles boundary condition start='0', end='9'+1")
    public void TC31() {
        // GIVEN
        int count = 3;
        int start = 48;
        int end = 58;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(3, result.length(), "Result length should be 3");
        assertTrue(result.chars().allMatch(c -> c >= '0' && c <= '9'), "All characters should be digits between '0' and '9'");
    }

    @Test
    @DisplayName("random(count, start=-10, end=50, letters=false, numbers=true, chars=null, random) throws IllegalArgumentException for negative end")
    public void TC32() {
        // GIVEN
        int count = 4;
        int start = -10;
        int end = 50;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        }, "Expected IllegalArgumentException for negative start or end");
        assertTrue(exception.getMessage().contains("Character positions MUST be >= 0"), "Exception message should indicate invalid character positions");
    }

    @Test
    @DisplayName("random(count=10, start=32, end=123, letters=true, numbers=true, chars=null, random) handles loop with multiple iterations and character acceptance")
    public void TC33() {
        // GIVEN
        int count = 10;
        int start = 32;
        int end = 123;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(10, result.length(), "Result length should be 10");
        assertTrue(result.chars().allMatch(c -> (Character.isLetter(c) || Character.isDigit(c)) && c >= start && c < end), "All characters should be letters or digits within the specified range");
    }

    @Test
    @DisplayName("random(count=10, start=32, end=123, letters=true, numbers=true, chars=null, random) handles loop with rejection sampling")
    public void TC34() {
        // GIVEN
        int count = 10;
        int start = 32;
        int end = 123;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random() {
            private int[] sequence = {35, 36, 37, 38, 39, 40, 41, 42, 43, 44};
            private int index = 0;

            @Override
            public int next(int bits) {
                return sequence[index++ % sequence.length];
            }
        };

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(10, result.length(), "Result length should be 10");
        assertTrue(result.chars().allMatch(c -> (Character.isLetter(c) || Character.isDigit(c)) && c >= start && c < end), "All characters should be letters or digits within the specified range");
    }

    @Test
    @DisplayName("random(count=7, start=65, end=91, letters=true, numbers=false, chars=null, random) throws exception when end <= start after adjustment")
    public void TC35() {
        // GIVEN
        int count = 7;
        int start = 90;
        int end = 65;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        }, "Expected IllegalArgumentException when end <= start after adjustment");
        assertTrue(exception.getMessage().contains("Parameter end ("), "Exception message should indicate that end must be greater than start");
    }
}