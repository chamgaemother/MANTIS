package com.google.gson.stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.StringReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class JsonReader_skipValue_0_4_Test {

    @Test
    @DisplayName("skipValue() with count greater than zero continuing the loop")
    void TC16_skipValue_loopContinuesWithCountGreaterThanZero() throws Exception {
        // Initialize JsonReader with empty input
        JsonReader reader = new JsonReader(new StringReader("[]"));

        // Reflection to set internal fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 1); // PEEKED_BEGIN_ARRAY assumed as 1

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        stackSizeField.setInt(reader, 2); // count = 2

        // Invoke skipValue()
        reader.skipValue();

        // Verify that the loop continues by checking if peeked is reset to PEEKED_NONE
        int peeked = peekedField.getInt(reader);
        assertEquals(0, peeked, "Peeked should be reset to PEEKED_NONE");
    }

    @Test
    @DisplayName("skipValue() with pathNames updated to '<skipped>' when count is zero")
    void TC17_skipValue_pathNamesUpdatedWhenCountIsZero() throws Exception {
        // Initialize JsonReader with empty input
        JsonReader reader = new JsonReader(new StringReader("{}"));

        // Reflection to set internal fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 5); // PEEKED_UNQUOTED_NAME assumed as 5

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        stackSizeField.setInt(reader, 1); // count = 0

        Field pathNamesField = JsonReader.class.getDeclaredField("pathNames");
        pathNamesField.setAccessible(true);
        String[] pathNames = new String[]{"name"};
        pathNamesField.set(reader, pathNames);

        // Invoke skipValue()
        reader.skipValue();

        // Verify that pathNames[stackSize - 1] is set to '<skipped>'
        String[] updatedPathNames = (String[]) pathNamesField.get(reader);
        assertEquals("<skipped>", updatedPathNames[0], "pathNames[stackSize - 1] should be '<skipped>'");
    }

    @Test
    @DisplayName("skipValue() with stackSize decremented properly")
    void TC18_skipValue_stackSizeDecrementedProperly() throws Exception {
        // Initialize JsonReader with empty input
        JsonReader reader = new JsonReader(new StringReader("]"));

        // Reflection to set internal fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 3); // PEEKED_END_ARRAY assumed as 3

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        stackSizeField.setInt(reader, 2); // stackSize = 2, count = 1

        // Invoke skipValue()
        reader.skipValue();

        // Verify that stackSize is decremented
        int stackSize = stackSizeField.getInt(reader);
        assertEquals(1, stackSize, "stackSize should be decremented correctly");
    }

    @Test
    @DisplayName("skipValue() encountering PEEKED_EOF inside loop")
    void TC19_skipValue_encounteringPEEKED_EOFInsideLoop() throws Exception {
        // Initialize JsonReader with empty input
        JsonReader reader = new JsonReader(new StringReader(""));

        // Reflection to set internal fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, -1); // PEEKED_EOF assumed as -1

        // Invoke skipValue()
        reader.skipValue();

        // Verify that the method returns immediately by checking peeked is still PEEKED_EOF
        int peeked = peekedField.getInt(reader);
        assertEquals(-1, peeked, "Method should return immediately upon encountering EOF");
    }
}