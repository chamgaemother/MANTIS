package org.apache.commons.math3.geometry.euclidean.twod.hull;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AklToussaintHeuristic_reducePoints_0_3_Test {

    @Test
    @DisplayName("reducePoints with points having both negative and positive coordinates")
    void TC11_reducePoints_mixedNegativePositiveCoordinates() {
        // GIVEN
        Vector2D p1 = new Vector2D(-1, -1);
        Vector2D p2 = new Vector2D(1, -1);
        Vector2D p3 = new Vector2D(1, 1);
        Vector2D p4 = new Vector2D(-1, 1);
        Vector2D p5 = new Vector2D(0, 0); // Inside point
        Vector2D p6 = new Vector2D(2, 2); // Outside point
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4, p5, p6);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertAll("Check if the reduced points contain the expected points inside and outside the quadrilateral",
            () -> assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4))),
            () -> assertTrue(result.contains(p6)),
            () -> assertTrue(!result.contains(p5))
        );
    }

    @Test
    @DisplayName("reducePoints with multiple iterations in the initial loop to find min/max points")
    void TC12_reducePoints_multipleIterationsFindingMinMax() {
        // GIVEN
        Vector2D minX = new Vector2D(-5, 0);
        Vector2D maxX = new Vector2D(5, 0);
        Vector2D minY = new Vector2D(0, -5);
        Vector2D maxY = new Vector2D(0, 5);
        List<Vector2D> points = new ArrayList<>();
        points.add(new Vector2D(-5, 0));
        points.add(new Vector2D(5, 0));
        points.add(new Vector2D(0, -5));
        points.add(new Vector2D(0, 5));
        // Adding more points to require multiple iterations
        points.add(new Vector2D(1, 1));
        points.add(new Vector2D(-1, -1));
        points.add(new Vector2D(2, 2));
        points.add(new Vector2D(-2, -2));

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertAll("Check if the reduced points contain all min and max points",
            () -> assertTrue(result.containsAll(Arrays.asList(minX, maxX, minY, maxY)))
        );
    }

    @Test
    @DisplayName("reducePoints with a large number of points to test performance and scalability")
    void TC13_reducePoints_largeNumberOfPoints() {
        // GIVEN
        Collection<Vector2D> points = generateVeryLargeCollection();

        // WHEN
        long startTime = System.nanoTime();
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);
        long endTime = System.nanoTime();
        long durationInMillis = (endTime - startTime) / 1_000_000;

        // THEN
        assertAll("Check if the method completes within acceptable time and returns a reduced collection",
            () -> assertTrue(result.size() < points.size(), "Reduced collection should be smaller than the original collection"),
            () -> assertTrue(durationInMillis < 1000, "Method should complete within 1000 milliseconds")
        );
    }

    /**
     * Generates a very large collection of Vector2D points for performance testing.
     */
    private Collection<Vector2D> generateVeryLargeCollection() {
        List<Vector2D> largeCollection = new ArrayList<>();
        for (int i = -500; i <= 500; i++) {
            largeCollection.add(new Vector2D(i, i));
            largeCollection.add(new Vector2D(i, -i));
        }
        return largeCollection;
    }
}