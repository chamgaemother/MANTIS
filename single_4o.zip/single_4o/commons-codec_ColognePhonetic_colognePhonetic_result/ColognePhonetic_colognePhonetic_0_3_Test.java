package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_3_Test {

    @Test
    @DisplayName("colognePhonetic correctly maintains zeros only at the beginning")
    public void testColognePhoneticLeadingZeros() {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String text = "Abc";

        // Act
        String result = colognePhonetic.colognePhonetic(text);

        // Assert
        assertEquals("01", result, "The colognePhonetic encoding should maintain leading zeros.");
    }

}