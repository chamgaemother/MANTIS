// package org.jfree.chart.plot;
// // 
// // import static org.junit.jupiter.api.Assertions.assertThrows;
// // import static org.mockito.Mockito.any;
// // import static org.mockito.Mockito.anyDouble;
// // import static org.mockito.Mockito.anyInt;
// // import static org.mockito.Mockito.doThrow;
// // import static org.mockito.Mockito.eq;
// // import static org.mockito.Mockito.mock;
// // import static org.mockito.Mockito.never;
// // import static org.mockito.Mockito.verify;
// // 
// // import java.awt.Graphics2D;
// // import java.awt.geom.Point2D;
// // import java.awt.geom.Rectangle2D;
// // 
// // import org.jfree.chart.annotations.CategoryAnnotation;
// // import org.jfree.chart.axis.ValueAxis;
// // import org.jfree.chart.renderer.category.CategoryItemRenderer;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// public class CategoryPlot_draw_2_1_Test {
// // 
// //     @Test
// //     @DisplayName("Draw method handles domain crosshair visible but columnKey is null")
// //     void TC26_drawDomainCrosshairVisible_ColumnKeyNull() throws Exception {
// //         CategoryPlot plot = new CategoryPlot();
// //         plot.setDomainCrosshairVisible(true);
// //         plot.setDomainCrosshairRowKey("RowKey");
// //         plot.setDomainCrosshairColumnKey(null);
// //         CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
// //         plot.setRenderer(renderer);
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
// //         Point2D anchor = new Point2D.Double(250, 250);
// //         PlotState state = null;
// //         PlotRenderingInfo info = new PlotRenderingInfo(null);
// // 
// //         plot.draw(g2, area, anchor, state, info);
// //         verify(renderer, never()).drawDomainCrosshair(any(), any(), any(), anyInt(), any(), eq(null), any(), any());
// //     }
// // 
// //     @Test
// //     @DisplayName("Draw method handles range crosshair not visible")
// //     void TC27_drawRangeCrosshairNotVisible() throws Exception {
// //         CategoryPlot plot = new CategoryPlot();
// //         plot.setRangeCrosshairVisible(false);
// //         CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
// //         plot.setRenderer(renderer);
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
// //         Point2D anchor = new Point2D.Double(250, 250);
// //         PlotState state = null;
// //         PlotRenderingInfo info = new PlotRenderingInfo(null);
// // 
// //         plot.draw(g2, area, anchor, state, info);
// //         verify(renderer, never()).drawRangeCrosshair(any(), any(), any(), anyDouble(), any(), any(), any());
// //     }
// // 
// //     @Test
// //     @DisplayName("Draw method throws exception when range axis is null but crosshair is visible")
// //     void TC28_drawThrowsException_RangeAxisNull_CrosshairVisible() throws Exception {
// //         CategoryPlot plot = new CategoryPlot();
// //         plot.setRangeCrosshairVisible(true);
// //         plot.setRangeAxis((ValueAxis) null);
// //         CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
// //         plot.setRenderer(renderer);
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
// //         Point2D anchor = new Point2D.Double(250, 250);
// //         PlotState state = null;
// //         PlotRenderingInfo info = new PlotRenderingInfo(null);
// // 
// //         assertThrows(NullPointerException.class, () -> {
// //             plot.draw(g2, area, anchor, state, info);
// //         });
// //     }
// // 
// //     @Test
// //     @DisplayName("Draw method handles exception during renderer.drawBackground gracefully")
// //     void TC29_drawHandlesRendererDrawBackgroundException() throws Exception {
// //         CategoryPlot plot = new CategoryPlot();
// //         CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
// //         doThrow(new RuntimeException("Renderer failure")).when(renderer).drawBackground(any(Graphics2D.class), eq(plot), any(Rectangle2D.class));
// //         plot.setRenderer(renderer);
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
// //         Point2D anchor = new Point2D.Double(250, 250);
// //         PlotState state = null;
// //         PlotRenderingInfo info = new PlotRenderingInfo(null);
// // 
// //         assertThrows(RuntimeException.class, () -> {
// //             plot.draw(g2, area, anchor, state, info);
// //         });
// //     }
// // 
// //     @Test
// //     @DisplayName("Draw method handles multiple annotations rendering")
// //     void TC30_drawHandlesMultipleAnnotations() throws Exception {
// //         CategoryPlot plot = new CategoryPlot();
// //         CategoryAnnotation annotation1 = mock(CategoryAnnotation.class);
// //         CategoryAnnotation annotation2 = mock(CategoryAnnotation.class);
// //         plot.addAnnotation(annotation1);
// //         plot.addAnnotation(annotation2);
// //         CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
// //         plot.setRenderer(renderer);
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
// //         Point2D anchor = new Point2D.Double(250, 250);
// //         PlotState state = null;
// //         PlotRenderingInfo info = new PlotRenderingInfo(null);
// // 
// //         plot.draw(g2, area, anchor, state, info);
// //         verify(annotation1).draw(eq(g2), eq(plot), eq(area), any(), any());
// //         verify(annotation2).draw(eq(g2), eq(plot), eq(area), any(), any());
// //     }
// // }
// }