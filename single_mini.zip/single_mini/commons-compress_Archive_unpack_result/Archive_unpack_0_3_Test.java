package org.apache.commons.compress.harmony.unpack200;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.jar.JarOutputStream;

import org.apache.commons.compress.utils.IOUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class Archive_unpack_0_3_Test {

    @Test
    @DisplayName("Unpack throws IOException during unpacking segments with closeStreams=true")
    void TC11_UnpackThrowsIOExceptionDuringUnpackingSegmentsWithCloseStreamsTrue() throws Exception {
        // Arrange
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.markSupported()).thenReturn(true);
        // Mock read to return non-GZIP_MAGIC bytes
        when(mockInputStream.read()).thenReturn(0x00, 0x00); // Not GZIP_MAGIC
        // Mock available to throw IOException
        Archive archive = new Archive(mockInputStream, new JarOutputStream(new ByteArrayOutputStream()));
        Archive spyArchive = Mockito.spy(archive);
        doThrow(new IOException("Test IOException")).when(spyArchive).available(any(InputStream.class));

        // Mock outputStream
        OutputStream mockOutputStream = mock(OutputStream.class);
        setField(spyArchive, "outputStream", mockOutputStream);
        setField(spyArchive, "closeStreams", true);
        setField(spyArchive, "removePackFile", true);
        Path tempInputPath = Files.createTempFile("test", ".pack");
        setField(spyArchive, "inputPath", tempInputPath);

        // Act & Assert
        IOException exception = assertThrows(IOException.class, () -> {
            spyArchive.unpack();
        });
        assertEquals("Test IOException", exception.getMessage());

        // Verify streams are closed
        verify(mockInputStream, times(1)).close();
        verify(mockOutputStream, times(1)).close();

        // Verify inputPath is deleted
        assertFalse(Files.exists(tempInputPath));
    }

    @Test
    @DisplayName("Unpack with overrideDeflateHint set to true")
    void TC12_UnpackWithOverrideDeflateHintTrue() throws Exception {
        // Arrange
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.markSupported()).thenReturn(true);
        // Mock read to return non-GZIP_MAGIC bytes
        when(mockInputStream.read()).thenReturn(0x00, 0x00); // Not GZIP_MAGIC
        // Mock available to return true once, then false
        Archive archive = new Archive(mockInputStream, new JarOutputStream(new ByteArrayOutputStream()));
        Archive spyArchive = Mockito.spy(archive);
        when(spyArchive.available(any(InputStream.class))).thenReturn(true, false);

        // Mock outputStream
        OutputStream mockOutputStream = mock(OutputStream.class);
        setField(spyArchive, "outputStream", mockOutputStream);
        setField(spyArchive, "overrideDeflateHint", true);
        setField(spyArchive, "deflateHint", true);
        setField(spyArchive, "closeStreams", true);
        setField(spyArchive, "removePackFile", true);
        Path tempInputPath = Files.createTempFile("test", ".pack");
        setField(spyArchive, "inputPath", tempInputPath);

        // Act
        spyArchive.unpack();

        // Assert
        // Verify deflate hint is overridden
        boolean overrideDeflateHint = (boolean) getField(spyArchive, "overrideDeflateHint");
        assertTrue(overrideDeflateHint);

        // Verify streams are flushed and closed
        verify(mockOutputStream, times(1)).flush();
        verify(mockInputStream, times(1)).close();
        verify(mockOutputStream, times(1)).close();

        // Verify inputPath is deleted
        assertFalse(Files.exists(tempInputPath));
    }

    @Test
    @DisplayName("Unpack with available(inputStream) returning true continuously leading to multiple segment processing")
    void TC13_UnpackWithContinuousAvailableSegments() throws Exception {
        // Arrange
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.markSupported()).thenReturn(true);
        // Mock read to return non-GZIP_MAGIC bytes
        when(mockInputStream.read()).thenReturn(0x00, 0x00); // Not GZIP_MAGIC
        // Mock available to always return true until stopped
        Archive archive = new Archive(mockInputStream, new JarOutputStream(new ByteArrayOutputStream()));
        Archive spyArchive = Mockito.spy(archive);
        when(spyArchive.available(any(InputStream.class))).thenReturn(true, true, false);

        // Mock outputStream
        OutputStream mockOutputStream = mock(OutputStream.class);
        setField(spyArchive, "outputStream", mockOutputStream);
        setField(spyArchive, "closeStreams", true);
        setField(spyArchive, "removePackFile", true);
        Path tempInputPath = Files.createTempFile("test", ".pack");
        setField(spyArchive, "inputPath", tempInputPath);

        // Act
        spyArchive.unpack();

        // Assert
        // Since available returns true twice, unpack should process two segments
        // Verify streams are flushed and closed twice
        verify(mockOutputStream, times(2)).flush();
        verify(mockInputStream, times(1)).close();
        verify(mockOutputStream, times(1)).close();

        // Verify inputPath is deleted
        assertFalse(Files.exists(tempInputPath));
    }

    @Test
    @DisplayName("Unpack with compressedWithE0 set to true due to magic mismatch")
    void TC14_UnpackWithCompressedWithE0TrueDueToMagicMismatch() throws Exception {
        // Arrange
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.markSupported()).thenReturn(true);
        // Mock read to return MAGIC mismatch
        when(mockInputStream.read()).thenReturn(0x58, 0x59); // 'X', 'Y' assuming MAGIC does not match

        // Mock outputStream
        OutputStream mockOutputStream = mock(OutputStream.class);
        Archive archive = new Archive(mockInputStream, new JarOutputStream(new ByteArrayOutputStream()));
        Archive spyArchive = Mockito.spy(archive);
        setField(spyArchive, "outputStream", mockOutputStream);
        setField(spyArchive, "closeStreams", true);
        setField(spyArchive, "removePackFile", true);
        Path tempInputPath = Files.createTempFile("test", ".pack");
        setField(spyArchive, "inputPath", tempInputPath);

        // Act
        spyArchive.unpack();

        // Assert
        // Verify original Jar is copied (no segments processed)
        // This would require verifying interactions with outputStream
        verify(mockOutputStream, never()).flush(); // Assuming no segments

        // Verify streams are closed
        verify(mockInputStream, times(1)).close();
        verify(mockOutputStream, times(1)).close();

        // Verify inputPath is deleted
        assertFalse(Files.exists(tempInputPath));
    }

    @Test
    @DisplayName("Unpack with exception handling when closeStreams is false during exception")
    void TC15_UnpackThrowsIOExceptionWithCloseStreamsFalse() throws Exception {
        // Arrange
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.markSupported()).thenReturn(true);
        // Mock read to return non-GZIP_MAGIC bytes
        when(mockInputStream.read()).thenReturn(0x00, 0x00); // Not GZIP_MAGIC
        // Mock available to throw IOException
        Archive archive = new Archive(mockInputStream, new JarOutputStream(new ByteArrayOutputStream()));
        Archive spyArchive = Mockito.spy(archive);
        doThrow(new IOException("Test IOException")).when(spyArchive).available(any(InputStream.class));

        // Mock outputStream
        OutputStream mockOutputStream = mock(OutputStream.class);
        setField(spyArchive, "outputStream", mockOutputStream);
        setField(spyArchive, "closeStreams", false);
        setField(spyArchive, "removePackFile", true);
        Path tempInputPath = Files.createTempFile("test", ".pack");
        setField(spyArchive, "inputPath", tempInputPath);

        // Act & Assert
        IOException exception = assertThrows(IOException.class, () -> {
            spyArchive.unpack();
        });
        assertEquals("Test IOException", exception.getMessage());

        // Verify streams are not closed
        verify(mockInputStream, never()).close();
        verify(mockOutputStream, never()).close();

        // Verify inputPath is deleted
        assertFalse(Files.exists(tempInputPath));
    }

    // Helper methods for reflection
    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = null;
        Class<?> clazz = target.getClass();
        while (clazz != null) {
            try {
                field = clazz.getDeclaredField(fieldName);
                break;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        if (field == null) {
            throw new NoSuchFieldException("Field '" + fieldName + "' not found in class hierarchy.");
        }
        field.setAccessible(true);
        field.set(target, value);
    }

    private Object getField(Object target, String fieldName) throws Exception {
        Field field = null;
        Class<?> clazz = target.getClass();
        while (clazz != null) {
            try {
                field = clazz.getDeclaredField(fieldName);
                break;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        if (field == null) {
            throw new NoSuchFieldException("Field '" + fieldName + "' not found in class hierarchy.");
        }
        field.setAccessible(true);
        return field.get(target);
    }
}