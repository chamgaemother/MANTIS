package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.Metaphone;

public class Metaphone_metaphone_2_2_Test {

    @Test
    @DisplayName("metaphone word with 'C' followed by 'H' and a vowel converts to 'X'")
    public void testTC58() {
        // Given
        String txt = "chase";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("XSS", result);
    }
    
    @Test
    @DisplayName("metaphone word with 'C' followed by 'H' and a consonant converts to 'K'")
    public void testTC59() {
        // Given
        String txt = "church";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("KRS", result);
    }
    
    @Test
    @DisplayName("metaphone word with 'G' before front vowel converts 'G' to 'J'")
    public void testTC60() {
        // Given
        String txt = "get";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("JT", result);
    }
    
    @Test
    @DisplayName("metaphone word with 'G' before non-front vowel converts 'G' to 'K'")
    public void testTC61() {
        // Given
        String txt = "goat";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("KT", result);
    }
    
    @Test
    @DisplayName("metaphone word with 'WH' followed by a vowel retains 'W'")
    public void testTC62() {
        // Given
        String txt = "whale";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("WL", result);
    }
}