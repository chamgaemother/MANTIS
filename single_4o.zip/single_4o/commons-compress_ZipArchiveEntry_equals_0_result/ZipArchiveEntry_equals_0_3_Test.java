package org.apache.commons.compress.archivers.zip;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import java.lang.reflect.Method;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class ZipArchiveEntry_equals_0_3_Test {

    @Test
    @DisplayName("Different CRC values with otherwise matching entries")
    void testDifferentCrcValues() throws Exception {
        // Create two instances of ZipArchiveEntry
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry1");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry1");

        // Use reflection to set CRC values
        Method setCrcMethod = ZipArchiveEntry.class.getDeclaredMethod("setCrc", long.class);
        setCrcMethod.setAccessible(true);
        setCrcMethod.invoke(entry1, 1234567890L);
        setCrcMethod.invoke(entry2, 9876543210L);

        // Assert that entries are not equal
        assertFalse(entry1.equals(entry2));
    }

    @Test
    @DisplayName("Fail equality due to different local file data extras")
    void testDifferentLocalFileDataExtras() throws Exception {
        // Create two instances of ZipArchiveEntry
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry2");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry2");

        // Set local file data extra
        byte[] extra1 = {1, 2, 3};
        byte[] extra2 = {4, 5, 6};
        entry1.setExtra(extra1);
        entry2.setExtra(extra2);

        // Assert that entries are not equal
        assertFalse(entry1.equals(entry2));
    }
}