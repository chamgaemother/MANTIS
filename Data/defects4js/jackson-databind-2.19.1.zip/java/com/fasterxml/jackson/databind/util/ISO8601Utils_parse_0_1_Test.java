package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601Utils_parse_0_1_Test {

    @Test
    @DisplayName("Successfully parse a date string without time component and default timezone")
    public void TC01() throws Exception {
        // GIVEN
        String date = "2023-10-05";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCal = new GregorianCalendar(2023, Calendar.OCTOBER, 5);
        expectedCal.setTimeZone(TimeZone.getDefault());
        Date expectedDate = expectedCal.getTime();
        assertEquals(expectedDate, result, "Parsed date does not match expected date");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index not updated correctly");
    }

    @Test
    @DisplayName("Successfully parse a date string with full time and 'Z' timezone")
    public void TC02() throws Exception {
        // GIVEN
        String date = "2023-10-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        expectedCal.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCal.getTime();
        assertEquals(expectedDate, result, "Parsed date with 'Z' timezone does not match expected date");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index not updated correctly");
    }

    @Test
    @DisplayName("Successfully parse a date string with full time and positive timezone offset")
    public void TC03() throws Exception {
        // GIVEN
        String date = "2023-10-05T14:30:00+02:00";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCal = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"));
        expectedCal.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCal.getTime();
        assertEquals(expectedDate, result, "Parsed date with positive timezone offset does not match expected date");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index not updated correctly");
    }

    @Test
    @DisplayName("Successfully parse a date string with full time and negative timezone offset")
    public void TC04() throws Exception {
        // GIVEN
        String date = "2023-10-05T14:30:00-05:00";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCal = new GregorianCalendar(TimeZone.getTimeZone("GMT-05:00"));
        expectedCal.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCal.getTime();
        assertEquals(expectedDate, result, "Parsed date with negative timezone offset does not match expected date");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index not updated correctly");
    }

    @Test
    @DisplayName("Parse throws ParseException when date string is null")
    public void TC05() {
        // GIVEN
        String date = null;
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "Expected parse to throw ParseException for null date string");
        assertTrue(exception.getMessage().contains("Failed to parse date null"), "Exception message does not contain expected text");
    }
}