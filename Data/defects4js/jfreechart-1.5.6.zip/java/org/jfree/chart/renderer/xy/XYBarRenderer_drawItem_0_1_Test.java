package org.jfree.chart.renderer.xy;
// 
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.category.BarPainter;
// import org.jfree.data.xy.IntervalXYDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
public class XYBarRenderer_drawItem_0_1_Test {
// 
//     @Test
//     @DisplayName("drawItem returns early when getItemVisible(series, item) is false")
//     void TC01_drawItem_ItemNotVisible() throws Exception {
        // Arrange
//         XYBarRenderer renderer = spy(new XYBarRenderer());
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         doReturn(false).when(renderer).getItemVisible(series, item);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(renderer, times(1)).getItemVisible(series, item);
//         verifyNoMoreInteractions(renderer);
//     }
// 
//     @Test
//     @DisplayName("drawItem proceeds when getItemVisible(series, item) is true")
//     void TC02_drawItem_ItemVisible() throws Exception {
        // Arrange
//         XYBarRenderer renderer = spy(new XYBarRenderer());
// 
//         XYPlot plot = mock(XYPlot.class);
//         doReturn(plot).when(renderer).getPlot(); // Mock added
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 1;
// 
//         doReturn(true).when(renderer).getItemVisible(series, item);
//         doReturn(false).when(renderer).getUseYInterval();
//         doReturn(0.0).when(renderer).getBase();
//         when(dataset.getYValue(series, item)).thenReturn(10.0);
//         doReturn(100.0).when(rangeAxis).valueToJava2D(anyDouble(), any(), any());
//         doReturn(50.0).when(domainAxis).valueToJava2D(anyDouble(), any(), any());
//         doReturn(0.1).when(renderer).getMargin();
//         doReturn(true).when(renderer).getShadowsVisible();
//         doReturn(mock(BarPainter.class)).when(renderer).getBarPainter();
//         doReturn(false).when(renderer).isItemLabelVisible(series, item);
//         mockEntityCollection(info);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(renderer, times(1)).getItemVisible(series, item);
//         verify(renderer, times(1)).getUseYInterval();
//         verify(renderer, times(1)).getBase();
//         verify(dataset, times(1)).getYValue(series, item);
//         verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), any(), any());
//         verify(domainAxis, times(2)).valueToJava2D(anyDouble(), any(), any());
//         verify(renderer, times(1)).getMargin();
//         verify(renderer, times(1)).getShadowsVisible();
//         verify(renderer, times(1)).getBarPainter();
//         verify(renderer, times(1)).isItemLabelVisible(series, item);
//     }
// 
//     @Test
//     @DisplayName("drawItem uses Y interval when getUseYInterval() is true")
//     void TC03_drawItem_UseYInterval() throws Exception {
        // Arrange
//         XYBarRenderer renderer = spy(new XYBarRenderer());
// 
//         XYPlot plot = mock(XYPlot.class);
//         doReturn(plot).when(renderer).getPlot();
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 1;
//         int item = 2;
//         int pass = 1;
// 
//         doReturn(true).when(renderer).getItemVisible(series, item);
//         doReturn(true).when(renderer).getUseYInterval();
//         when(dataset.getStartYValue(series, item)).thenReturn(5.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(15.0);
//         doReturn(50.0).when(rangeAxis).valueToJava2D(5.0, dataArea, plot.getRangeAxisEdge());
//         doReturn(150.0).when(rangeAxis).valueToJava2D(15.0, dataArea, plot.getRangeAxisEdge());
//         when(dataset.getStartXValue(series, item)).thenReturn(1.0);
//         when(dataset.getEndXValue(series, item)).thenReturn(2.0);
//         doReturn(10.0).when(domainAxis).valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge());
//         doReturn(20.0).when(domainAxis).valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge());
//         doReturn(0.2).when(renderer).getMargin();
//         doReturn(true).when(renderer).getShadowsVisible();
//         doReturn(mock(BarPainter.class)).when(renderer).getBarPainter();
//         doReturn(false).when(renderer).isItemLabelVisible(series, item);
//         mockEntityCollection(info);
// 
        // Removed line that incorrectly attempted orientation, instead rely on drawItem method to set correctly
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(renderer, times(1)).getUseYInterval();
//         verify(dataset, times(1)).getStartYValue(series, item);
//         verify(dataset, times(1)).getEndYValue(series, item);
//         verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()));
//         verify(dataset, times(1)).getStartXValue(series, item);
//         verify(dataset, times(1)).getEndXValue(series, item);
//         verify(domainAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()));
//         verify(renderer, times(1)).getMargin();
//         verify(renderer, times(1)).getShadowsVisible();
//         verify(renderer, times(1)).getBarPainter();
//         verify(renderer, times(1)).isItemLabelVisible(series, item);
//     }
// 
//     @Test
//     @DisplayName("drawItem uses base and Y value when getUseYInterval() is false")
//     void TC04_drawItem_UseBaseYValue() throws Exception {
        // Arrange
//         XYBarRenderer renderer = spy(new XYBarRenderer());
// 
//         XYPlot plot = mock(XYPlot.class);
//         doReturn(plot).when(renderer).getPlot();
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 1;
//         int item = 2;
//         int pass = 1;
// 
//         doReturn(true).when(renderer).getItemVisible(series, item);
//         doReturn(false).when(renderer).getUseYInterval();
//         doReturn(0.0).when(renderer).getBase();
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
//         doReturn(0.0).when(rangeAxis).valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge());
//         doReturn(200.0).when(rangeAxis).valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge());
//         when(dataset.getStartXValue(series, item)).thenReturn(3.0);
//         when(dataset.getEndXValue(series, item)).thenReturn(4.0);
//         doReturn(30.0).when(domainAxis).valueToJava2D(3.0, dataArea, plot.getDomainAxisEdge());
//         doReturn(40.0).when(domainAxis).valueToJava2D(4.0, dataArea, plot.getDomainAxisEdge());
//         doReturn(0.15).when(renderer).getMargin();
//         doReturn(true).when(renderer).getShadowsVisible();
//         doReturn(mock(BarPainter.class)).when(renderer).getBarPainter();
//         doReturn(false).when(renderer).isItemLabelVisible(series, item);
//         mockEntityCollection(info);
// 
        // Removed line that attempted an incorrect orientation setting, let drawItem handle it
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(renderer, times(1)).getUseYInterval();
//         verify(renderer, times(1)).getBase();
//         verify(dataset, times(1)).getYValue(series, item);
//         verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getRangeAxisEdge()));
//         verify(dataset, times(1)).getStartXValue(series, item);
//         verify(dataset, times(1)).getEndXValue(series, item);
//         verify(domainAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), eq(plot.getDomainAxisEdge()));
//         verify(renderer, times(1)).getMargin();
//         verify(renderer, times(1)).getShadowsVisible();
//         verify(renderer, times(1)).getBarPainter();
//         verify(renderer, times(1)).isItemLabelVisible(series, item);
//     }
// 
//     @Test
//     @DisplayName("drawItem returns early when Y0 is NaN")
//     void TC05_drawItem_Y0IsNaN() throws Exception {
        // Arrange
//         XYBarRenderer renderer = spy(new XYBarRenderer());
// 
//         XYPlot plot = mock(XYPlot.class);
//         doReturn(plot).when(renderer).getPlot();
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         doReturn(true).when(renderer).getItemVisible(series, item);
//         doReturn(false).when(renderer).getUseYInterval();
//         doReturn(0.0).when(renderer).getBase();
//         when(dataset.getYValue(series, item)).thenReturn(Double.NaN);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(renderer, times(1)).getItemVisible(series, item);
//         verify(renderer, times(1)).getUseYInterval();
//         verify(renderer, times(1)).getBase();
//         verify(dataset, times(1)).getYValue(series, item);
//         verifyNoMoreInteractions(renderer);
//     }
// 
    // Helper method to mock the EntityCollection in PlotRenderingInfo
//     private void mockEntityCollection(PlotRenderingInfo info) {
//         org.jfree.chart.plot.Plot plot = mock(org.jfree.chart.plot.Plot.class);
//         doReturn(plot).when(info).getOwner();
//         doReturn(mock(EntityCollection.class)).when(plot).getEntityCollection();
//     }
// }
}