package org.apache.commons.lang3.text;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class WordUtils_wrap_1_2_Test {

    @Test
    @DisplayName("wrap with wrapOn pattern matching non-space delimiters and wrapLongWords=true to ensure proper wrapping")
    void TC26() {
        // GIVEN
        String str = "word1-word2_word3.word4";
        int wrapLength = 6;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "[-_.]";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "word1-\nword2_\nword3.\nword4";
        assertEquals(expected, result, "Wrapping should occur correctly at non-space delimiters and wrap long words.");
    }

    @Test
    @DisplayName("wrap with multiple special characters in wrapOn pattern and wrapLongWords=true for complex delimiter scenarios")
    void TC27() {
        // GIVEN
        String str = "line1;line2.line3,line4";
        int wrapLength = 6;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "[;.,]";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "line1;\nline2.\nline3,\nline4";
        assertEquals(expected, result, "Wrapping should occur correctly at multiple special delimiters.");
    }

    @Test
    @DisplayName("wrap with wrapOn pattern that matches every character and wrapLongWords=true to test maximum wrapping")
    void TC28() {
        // GIVEN
        String str = "abc";
        int wrapLength = 1;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ".*";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "a\nb\nc";
        assertEquals(expected, result, "Each character should be wrapped individually with newlines.");
    }

    @Test
    @DisplayName("wrap with wrapOn pattern never matches and wrapLongWords=true to ensure the entire string is broken into wrapLength segments")
    void TC29() {
        // GIVEN
        String str = "abcdefghijk";
        int wrapLength = 3;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "[XYZ]";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "abc\ndef\nghi\njk";
        assertEquals(expected, result, "The string should be wrapped into segments of 3 characters each.");
    }
}