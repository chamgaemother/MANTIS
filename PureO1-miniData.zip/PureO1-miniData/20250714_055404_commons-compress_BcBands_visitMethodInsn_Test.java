package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.OutputStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.objectweb.asm.Label;

class BcBandsTest {

    private CpBands cpBands;
    private Segment segment;
    private BcBands bcBands;
    
    @BeforeEach
    void setUp() {
        cpBands = mock(CpBands.class);
        segment = mock(Segment.class);
        when(segment.getSegmentHeader()).thenReturn(mock(SegmentHeader.class));
        bcBands = new BcBands(cpBands, segment, 0);
        bcBands.setCurrentClass("com/example/CurrentClass", "com/example/SuperClass");
    }

    @Test
    void testVisitMethodInsn_InvokeVirtual_CurrentClass_NonInit() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/CurrentClass", "doSomething", "()V")).thenReturn(method);
        
        bcBands.visitMethodInsn(182, "com/example/CurrentClass", "doSomething", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(182, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcThisMethod.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_CurrentClass_NonInit() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/CurrentClass", "specialMethod", "()V")).thenReturn(method);
        
        bcBands.visitMethodInsn(183, "com/example/CurrentClass", "specialMethod", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(183 + 24, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcThisMethod.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_CurrentClass_Init() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/CurrentClass", "<init>", "()V")).thenReturn(method);
        
        bcBands.visitMethodInsn(183, "com/example/CurrentClass", "<init>", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(207, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcInitRef.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeVirtual_SuperClass() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/SuperClass", "superMethod", "()V")).thenReturn(method);
        
        bcBands.visitMethodInsn(182, "com/example/SuperClass", "superMethod", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(182 + 38, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcSuperMethod.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_SuperClass_Init() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/SuperClass", "<init>", "()V")).thenReturn(method);
        
        bcBands.visitMethodInsn(183, "com/example/SuperClass", "<init>", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(221, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcInitRef.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeStatic_OtherClass() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/OtherClass", "staticMethod", "()V")).thenReturn(method);
        
        bcBands.visitMethodInsn(184, "com/example/OtherClass", "staticMethod", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(184, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcMethodRef.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_NewClass_Init() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/NewClass", "<init>", "()V")).thenReturn(method);
        bcBands.currentNewClass = "com/example/NewClass";
        
        bcBands.visitMethodInsn(183, "com/example/NewClass", "<init>", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(232, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcInitRef.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_NewClass_NonInit() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/NewClass", "newMethod", "()V")).thenReturn(method);
        bcBands.currentNewClass = "com/example/NewClass";
        
        bcBands.visitMethodInsn(183, "com/example/NewClass", "newMethod", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(183 + 38, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcSuperMethod.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeInterface() {
        CPMethodOrField imethod = mock(CPMethodOrField.class);
        when(cpBands.getCPIMethod("com/example/InterfaceClass", "interfaceMethod", "()V")).thenReturn(imethod);
        
        bcBands.visitMethodInsn(185, "com/example/InterfaceClass", "interfaceMethod", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(185, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcIMethodRef.contains(imethod));
        assertEquals(2, bcBands.byteCodeOffset); // opcode 185 adds 2 to byteCodeOffset
    }
    
    @Test
    void testVisitMethodInsn_WithAload0_PreviousOpcode() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/CurrentClass", "doSomething", "()V")).thenReturn(method);
        
        // Add ALOAD_0
        bcBands.bcCodes.add(42);
        bcBands.byteCodeOffset = 1;
        
        bcBands.visitMethodInsn(182, "com/example/CurrentClass", "doSomething", "()V");
        
        // ALOAD_0 should be removed and opcode should be adjusted
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(182 + 7 + 24, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcThisMethod.contains(method));
        assertEquals(2, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_NoAload0_PreviousOpcode() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/OtherClass", "method", "()V")).thenReturn(method);
        
        bcBands.visitMethodInsn(182, "com/example/OtherClass", "method", "()V");
        
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(182, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcMethodRef.contains(method));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_WithAload0_NotSpecialCase() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/OtherClass", "method", "()V")).thenReturn(method);
        
        // Add ALOAD_0
        bcBands.bcCodes.add(42);
        bcBands.byteCodeOffset = 1;
        
        bcBands.visitMethodInsn(184, "com/example/OtherClass", "method", "()V");
        
        // ALOAD_0 should not be removed because opcode is 184
        assertEquals(2, bcBands.bcCodes.size());
        assertEquals(42, bcBands.bcCodes.get(0));
        assertEquals(184, bcBands.bcCodes.get(1));
        assertTrue(bcBands.bcMethodRef.contains(method));
        assertEquals(2, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_NullOwner() {
        assertThrows(NullPointerException.class, () -> {
            bcBands.visitMethodInsn(182, null, "method", "()V");
        });
    }
    
    @Test
    void testVisitMethodInsn_NullName() {
        assertThrows(NullPointerException.class, () -> {
            bcBands.visitMethodInsn(182, "com/example/Class", null, "()V");
        });
    }
    
    @Test
    void testVisitMethodInsn_NullDesc() {
        assertThrows(NullPointerException.class, () -> {
            bcBands.visitMethodInsn(182, "com/example/Class", "method", null);
        });
    }
    
    @Test
    void testVisitMethodInsn_InvalidOpcode() {
        // Using an opcode that is not handled explicitly
        bcBands.visitMethodInsn(190, "com/example/Class", "method", "()V");
        
        // Since there's no case for opcode 190, it should just add it to bcCodes
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(190, bcBands.bcCodes.get(0));
        assertEquals(1, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeVirtual_WithMultipleAload0() {
        CPMethodOrField method1 = mock(CPMethodOrField.class);
        CPMethodOrField method2 = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/CurrentClass", "doFirst", "()V")).thenReturn(method1);
        when(cpBands.getCPMethod("com/example/CurrentClass", "doSecond", "()V")).thenReturn(method2);
        
        // Add first ALOAD_0
        bcBands.bcCodes.add(42);
        bcBands.byteCodeOffset = 1;
        bcBands.visitMethodInsn(182, "com/example/CurrentClass", "doFirst", "()V");
        
        // Add second ALOAD_0
        bcBands.bcCodes.add(42);
        bcBands.byteCodeOffset = 2;
        bcBands.visitMethodInsn(182, "com/example/CurrentClass", "doSecond", "()V");
        
        // Check both methods are added correctly
        assertEquals(2, bcBands.bcCodes.size());
        assertEquals(182 + 7 + 24, bcBands.bcCodes.get(0));
        assertEquals(182 + 7 + 24, bcBands.bcCodes.get(1));
        assertTrue(bcBands.bcThisMethod.contains(method1));
        assertTrue(bcBands.bcThisMethod.contains(method2));
        assertEquals(4, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_NewClass_NonInit_WithAload0() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/NewClass", "newMethod", "()V")).thenReturn(method);
        bcBands.currentNewClass = "com/example/NewClass";
        
        // Add ALOAD_0
        bcBands.bcCodes.add(42);
        bcBands.byteCodeOffset = 1;
        
        bcBands.visitMethodInsn(183, "com/example/NewClass", "newMethod", "()V");
        
        // ALOAD_0 should be removed and opcode adjusted
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(183 + 38, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcSuperMethod.contains(method));
        assertEquals(2, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeSpecial_NewClass_Init_WithAload0() {
        CPMethodOrField method = mock(CPMethodOrField.class);
        when(cpBands.getCPMethod("com/example/NewClass", "<init>", "()V")).thenReturn(method);
        bcBands.currentNewClass = "com/example/NewClass";
        
        // Add ALOAD_0
        bcBands.bcCodes.add(42);
        bcBands.byteCodeOffset = 1;
        
        bcBands.visitMethodInsn(183, "com/example/NewClass", "<init>", "()V");
        
        // ALOAD_0 should be removed and opcode adjusted
        assertEquals(1, bcBands.bcCodes.size());
        assertEquals(232, bcBands.bcCodes.get(0));
        assertTrue(bcBands.bcInitRef.contains(method));
        assertEquals(2, bcBands.byteCodeOffset);
    }
    
    @Test
    void testVisitMethodInsn_InvokeInterface_WithAload0() {
        CPMethodOrField imethod = mock(CPMethodOrField.class);
        when(cpBands.getCPIMethod("com/example/InterfaceClass", "interfaceMethod", "()V")).thenReturn(imethod);
        
        // Add ALOAD_0
        bcBands.bcCodes.add(42);
        bcBands.byteCodeOffset = 1;
        
        bcBands.visitMethodInsn(185, "com/example/InterfaceClass", "interfaceMethod", "()V");
        
        // ALOAD_0 should not be removed for invokeinterface
        assertEquals(2, bcBands.bcCodes.size());
        assertEquals(42, bcBands.bcCodes.get(0));
        assertEquals(185, bcBands.bcCodes.get(1));
        assertTrue(bcBands.bcIMethodRef.contains(imethod));
        assertEquals(3, bcBands.byteCodeOffset);
    }
}