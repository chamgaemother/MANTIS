import org.apache.commons.lang3.text.translate.NumericEntityUnescaper;
import org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.StringWriter;
import java.io.Writer;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class NumericEntityUnescaperTest {

    private static Stream<Object[]> validScenarios() {
        return Stream.of(
            new Object[]{"&#65;", "A", OPTION.semiColonRequired},
            new Object[]{"&#x41;", "A", OPTION.semiColonRequired},
            new Object[]{"&#65", "A", OPTION.semiColonOptional},
            new Object[]{"&#x41", "A", OPTION.semiColonOptional},
            new Object[]{"&#x1F600;", new String(Character.toChars(0x1F600)), OPTION.semiColonRequired},
            new Object[]{"&#x1F600", new String(Character.toChars(0x1F600)), OPTION.semiColonOptional}
        );
    }

    private static Stream<Object[]> invalidScenarios() {
        return Stream.of(
            new Object[]{"&#;", OPTION.errorIfNoSemiColon},
            new Object[]{"&#x;", OPTION.errorIfNoSemiColon},
            new Object[]{"&#", OPTION.errorIfNoSemiColon},
            new Object[]{"&", OPTION.errorIfNoSemiColon},
            new Object[]{"&#x1F600", OPTION.semiColonRequired},
            new Object[]{"&#65A;", OPTION.errorIfNoSemiColon},
            new Object[]{"&#x41G;", OPTION.errorIfNoSemiColon}
        );
    }

    @ParameterizedTest
    @MethodSource("validScenarios")
    public void testValidScenarios(String input, String expectedOutput, OPTION option) throws Exception {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(option);
        Writer writer = new StringWriter();
        int translated = unescaper.translate(input, 0, writer);
        assertEquals(expectedOutput, writer.toString());
        assertEquals(input.length(), translated);
    }

    @ParameterizedTest
    @MethodSource("invalidScenarios")
    public void testInvalidScenarios(String input, OPTION option) {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(option);
        Writer writer = new StringWriter();
        assertThrows(IllegalArgumentException.class, () -> unescaper.translate(input, 0, writer));
    }

    @Test
    public void testNonEntityInput() throws Exception {
        String input = "Hello World";
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(OPTION.semiColonRequired);
        Writer writer = new StringWriter();
        int translated = unescaper.translate(input, 0, writer);
        assertEquals(0, translated);
        assertEquals("", writer.toString());
    }

    @Test
    public void testIncompleteEntity() throws Exception {
        String input = "&#";
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(OPTION.semiColonOptional);
        Writer writer = new StringWriter();
        int translated = unescaper.translate(input, 0, writer);
        assertEquals(0, translated);
        assertEquals("", writer.toString());
    }

    @Test
    public void testInvalidCharacter() throws Exception {
        String input = "&#abc;";
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(OPTION.semiColonOptional);
        Writer writer = new StringWriter();
        int translated = unescaper.translate(input, 0, writer);
        assertEquals(0, translated);
        assertEquals("", writer.toString());
    }

    @Test
    public void testHighCodePointEntity() throws Exception {
        String input = "&#x1F601;";
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(OPTION.semiColonRequired);
        Writer writer = new StringWriter();
        int translated = unescaper.translate(input, 0, writer);
        assertEquals(new String(Character.toChars(0x1F601)), writer.toString());
        assertEquals(input.length(), translated);
    }

    @Test
    public void testZeroCodePointEntity() throws Exception {
        String input = "&#0;";
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(OPTION.semiColonRequired);
        Writer writer = new StringWriter();
        int translated = unescaper.translate(input, 0, writer);
        assertEquals("\u0000", writer.toString());
        assertEquals(input.length(), translated);
    }
}