import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.FormElement;
import org.jsoup.nodes.Node;
import org.jsoup.parser.Tag;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FormElementTest {

    private FormElement form;

    @BeforeEach
    void setUp() {
        form = new FormElement(Tag.valueOf("form"), "http://example.com", new Attributes());
    }

    @Test
    void testFormData_WithNonSubmittableElement() {
        Element div = new Element(Tag.valueOf("div"), "");
        form.addElement(div);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithDisabledElement() {
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("type", "text");
        input.attr("name", "username");
        input.attr("disabled", "");
        form.addElement(input);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithEmptyName() {
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("type", "text");
        form.addElement(input);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithButtonType() {
        Element button = new Element(Tag.valueOf("input"), "");
        button.attr("type", "button");
        button.attr("name", "submitBtn");
        button.val("Click");
        form.addElement(button);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithImageType() {
        Element image = new Element(Tag.valueOf("input"), "");
        image.attr("type", "image");
        image.attr("name", "imageBtn");
        image.val("Image");
        form.addElement(image);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithSelectSelectedOptions() {
        Element select = new Element(Tag.valueOf("select"), "");
        select.attr("name", "country");

        Element option1 = new Element(Tag.valueOf("option"), "");
        option1.attr("value", "US");
        option1.attr("selected", "");
        select.appendChild(option1);

        Element option2 = new Element(Tag.valueOf("option"), "");
        option2.attr("value", "CA");
        select.appendChild(option2);

        form.addElement(select);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        Object kv = data.get(0);
        assertTrue(kv instanceof org.jsoup.Connection.KeyVal);
        org.jsoup.Connection.KeyVal keyVal = (org.jsoup.Connection.KeyVal) kv;
        assertEquals("country", keyVal.key());
        assertEquals("US", keyVal.value());
    }

    @Test
    void testFormData_WithSelectNoSelectedOptions() {
        Element select = new Element(Tag.valueOf("select"), "");
        select.attr("name", "country");

        Element option1 = new Element(Tag.valueOf("option"), "");
        option1.attr("value", "US");
        select.appendChild(option1);

        Element option2 = new Element(Tag.valueOf("option"), "");
        option2.attr("value", "CA");
        select.appendChild(option2);

        form.addElement(select);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        Object kv = data.get(0);
        assertTrue(kv instanceof org.jsoup.Connection.KeyVal);
        org.jsoup.Connection.KeyVal keyVal = (org.jsoup.Connection.KeyVal) kv;
        assertEquals("country", keyVal.key());
        assertEquals("US", keyVal.value());
    }

    @Test
    void testFormData_WithSelectNoOptions() {
        Element select = new Element(Tag.valueOf("select"), "");
        select.attr("name", "country");
        form.addElement(select);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithCheckboxCheckedAndVal() {
        Element checkbox = new Element(Tag.valueOf("input"), "");
        checkbox.attr("type", "checkbox");
        checkbox.attr("name", "subscribe");
        checkbox.attr("value", "yes");
        checkbox.attr("checked", "");
        form.addElement(checkbox);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        org.jsoup.Connection.KeyVal kv = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("subscribe", kv.key());
        assertEquals("yes", kv.value());
    }

    @Test
    void testFormData_WithCheckboxCheckedNoVal() {
        Element checkbox = new Element(Tag.valueOf("input"), "");
        checkbox.attr("type", "checkbox");
        checkbox.attr("name", "subscribe");
        checkbox.attr("checked", "");
        form.addElement(checkbox);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        org.jsoup.Connection.KeyVal kv = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("subscribe", kv.key());
        assertEquals("on", kv.value());
    }

    @Test
    void testFormData_WithCheckboxNotChecked() {
        Element checkbox = new Element(Tag.valueOf("input"), "");
        checkbox.attr("type", "checkbox");
        checkbox.attr("name", "subscribe");
        checkbox.attr("value", "yes");
        form.addElement(checkbox);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithRadioCheckedAndVal() {
        Element radio = new Element(Tag.valueOf("input"), "");
        radio.attr("type", "radio");
        radio.attr("name", "gender");
        radio.attr("value", "male");
        radio.attr("checked", "");
        form.addElement(radio);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        org.jsoup.Connection.KeyVal kv = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("gender", kv.key());
        assertEquals("male", kv.value());
    }

    @Test
    void testFormData_WithRadioCheckedNoVal() {
        Element radio = new Element(Tag.valueOf("input"), "");
        radio.attr("type", "radio");
        radio.attr("name", "gender");
        radio.attr("checked", "");
        form.addElement(radio);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        org.jsoup.Connection.KeyVal kv = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("gender", kv.key());
        assertEquals("on", kv.value());
    }

    @Test
    void testFormData_WithRadioNotChecked() {
        Element radio = new Element(Tag.valueOf("input"), "");
        radio.attr("type", "radio");
        radio.attr("name", "gender");
        radio.attr("value", "male");
        form.addElement(radio);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithTextInput() {
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("type", "text");
        input.attr("name", "username");
        input.val("john");
        form.addElement(input);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        org.jsoup.Connection.KeyVal kv = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("username", kv.key());
        assertEquals("john", kv.value());
    }

    @Test
    void testFormData_WithEmptyTextInput() {
        Element input = new Element(Tag.valueOf("input"), "");
        input.attr("type", "text");
        input.attr("name", "username");
        input.val("");
        form.addElement(input);
        List<?> data = form.formData();
        assertEquals(1, data.size());
        org.jsoup.Connection.KeyVal kv = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("username", kv.key());
        assertEquals("", kv.value());
    }

    @Test
    void testFormData_WithMultipleElements() {
        // Disabled input
        Element disabledInput = new Element(Tag.valueOf("input"), "");
        disabledInput.attr("type", "text");
        disabledInput.attr("name", "disabledField");
        disabledInput.attr("disabled", "");
        form.addElement(disabledInput);

        // Text input
        Element textInput = new Element(Tag.valueOf("input"), "");
        textInput.attr("type", "text");
        textInput.attr("name", "username");
        textInput.val("john");
        form.addElement(textInput);

        // Checkbox checked
        Element checkbox = new Element(Tag.valueOf("input"), "");
        checkbox.attr("type", "checkbox");
        checkbox.attr("name", "subscribe");
        checkbox.attr("value", "yes");
        checkbox.attr("checked", "");
        form.addElement(checkbox);

        // Checkbox not checked
        Element checkbox2 = new Element(Tag.valueOf("input"), "");
        checkbox2.attr("type", "checkbox");
        checkbox2.attr("name", "offers");
        checkbox2.attr("value", "newsletter");
        form.addElement(checkbox2);

        // Select with selected option
        Element select = new Element(Tag.valueOf("select"), "");
        select.attr("name", "country");
        Element option1 = new Element(Tag.valueOf("option"), "");
        option1.attr("value", "US");
        option1.attr("selected", "");
        select.appendChild(option1);
        Element option2 = new Element(Tag.valueOf("option"), "");
        option2.attr("value", "CA");
        select.appendChild(option2);
        form.addElement(select);

        List<?> data = form.formData();
        assertEquals(3, data.size());

        // Verify username
        org.jsoup.Connection.KeyVal kv1 = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("username", kv1.key());
        assertEquals("john", kv1.value());

        // Verify subscribe
        org.jsoup.Connection.KeyVal kv2 = (org.jsoup.Connection.KeyVal) data.get(1);
        assertEquals("subscribe", kv2.key());
        assertEquals("yes", kv2.value());

        // Verify country
        org.jsoup.Connection.KeyVal kv3 = (org.jsoup.Connection.KeyVal) data.get(2);
        assertEquals("country", kv3.key());
        assertEquals("US", kv3.value());
    }

    @Test
    void testFormData_WithNoElements() {
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithSelectFirstOptionNull() {
        Element select = new Element(Tag.valueOf("select"), "");
        select.attr("name", "country");
        form.addElement(select);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }

    @Test
    void testFormData_WithMultipleSelectedOptions() {
        Element select = new Element(Tag.valueOf("select"), "");
        select.attr("name", "colors");
        select.attr("multiple", "");

        Element option1 = new Element(Tag.valueOf("option"), "");
        option1.attr("value", "red");
        option1.attr("selected", "");
        select.appendChild(option1);

        Element option2 = new Element(Tag.valueOf("option"), "");
        option2.attr("value", "green");
        option2.attr("selected", "");
        select.appendChild(option2);

        form.addElement(select);
        List<?> data = form.formData();
        assertEquals(2, data.size());

        org.jsoup.Connection.KeyVal kv1 = (org.jsoup.Connection.KeyVal) data.get(0);
        assertEquals("colors", kv1.key());
        assertEquals("red", kv1.value());

        org.jsoup.Connection.KeyVal kv2 = (org.jsoup.Connection.KeyVal) data.get(1);
        assertEquals("colors", kv2.key());
        assertEquals("green", kv2.value());
    }

    @Test
    void testFormData_WithNonFormSubmittableTag() {
        Element span = new Element(Tag.valueOf("span"), "");
        span.attr("name", "spanField");
        span.val("value");
        form.addElement(span);
        List<?> data = form.formData();
        assertTrue(data.isEmpty());
    }
}