package org.apache.commons.collections4.iterators;

import org.apache.commons.collections4.iterators.PermutationIterator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

public class PermutationIterator_next_0_1_Test {

    @Test
    @DisplayName("next() throws NoSuchElementException when 'nextPermutation' is null")
    void testNextThrowsExceptionWhenNextPermutationIsNull() throws Exception {
        // GIVEN
        List<Integer> emptyList = Collections.emptyList();
        PermutationIterator<Integer> iterator = new PermutationIterator<>(emptyList);
        // Reflection to set nextPermutation to null
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, null);

        // WHEN & THEN
        Executable executable = iterator::next;
        assertThrows(NoSuchElementException.class, executable);
    }

    @Test
    @DisplayName("next() processes normally with a valid permutation and multiple mobile integers")
    void testNextProcessesNormallyWithValidPermutation() throws Exception {
        // GIVEN
        List<Integer> initialList = Arrays.asList(1, 2, 3);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);

        // WHEN
        List<Integer> result = iterator.next();

        // THEN
        assertEquals(Arrays.asList(1, 2, 3), result);

        // Verify 'nextPermutation' reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = (List<Integer>) nextPermutationField.get(iterator);
        assertEquals(Arrays.asList(1, 3, 2), nextPermutation);
    }

    @Test
    @DisplayName("next() computes next permutation when last mobile integer is found")
    void testNextComputesWhenLastMobileIntegerIsFound() throws Exception {
        // GIVEN
        List<Integer> initialList = Arrays.asList(2, 1);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);

        // WHEN
        List<Integer> result = iterator.next();

        // THEN
        assertEquals(Arrays.asList(2, 1), result);

        // Verify 'nextPermutation' is null when no more permutations
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        Object nextPermutation = nextPermutationField.get(iterator);
        assertNull(nextPermutation);
    }

    @Test
    @DisplayName("next() behaves correctly when swapping elements and reversing direction")
    void testNextSwapsElementsAndReversesDirection() throws Exception {
        // GIVEN
        List<Integer> initialList = Arrays.asList(3, 1, 2);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);

        // WHEN
        List<Integer> result = iterator.next();

        // THEN
        assertEquals(Arrays.asList(3, 1, 2), result);

        // Verify 'nextPermutation' reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = (List<Integer>) nextPermutationField.get(iterator);
        assertEquals(Arrays.asList(3, 2, 1), nextPermutation);
    }

    @Test
    @DisplayName("next() correctly processes single element list")
    void testNextProcessesSingleElementList() throws Exception {
        // GIVEN
        List<Integer> initialList = Collections.singletonList(42);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);

        // WHEN
        List<Integer> result = iterator.next();

        // THEN
        assertEquals(Collections.singletonList(42), result);

        // Verify 'nextPermutation' is null since no further permutations exist
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        Object nextPermutation = nextPermutationField.get(iterator);
        assertNull(nextPermutation);
    }
}