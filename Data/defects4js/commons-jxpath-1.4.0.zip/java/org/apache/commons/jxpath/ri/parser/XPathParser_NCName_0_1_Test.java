package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class XPathParser_NCName_0_1_Test {

    private final String OR_IMAGE = "OR_IMAGE";
    private final String AND_IMAGE = "AND_IMAGE";
    private final String MOD_IMAGE = "MOD_IMAGE";
    private final String DIV_IMAGE = "DIV_IMAGE";
    private final String NCNAME_IMAGE = "NCNAME_IMAGE";

    @Test
    @DisplayName("NCName() processes kind OR and returns token image")
    void TC01() throws Exception {
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);

        Class<?> tokenClass = Class.forName("org.apache.commons.jxpath.ri.parser.Token");
        Object token = tokenClass.getDeclaredConstructor().newInstance();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, 3); // Assuming OR maps to 3

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, OR_IMAGE);

        jj_ntField.set(parser, token);

        String result = parser.NCName();
        String image = (String) imageField.get(token);

        assertEquals(image, result);
    }

    @Test
    @DisplayName("NCName() processes kind AND and returns token image")
    void TC02() throws Exception {
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);

        Class<?> tokenClass = Class.forName("org.apache.commons.jxpath.ri.parser.Token");
        Object token = tokenClass.getDeclaredConstructor().newInstance();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, 4); // Assuming AND maps to 4

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, AND_IMAGE);

        jj_ntField.set(parser, token);

        String result = parser.NCName();
        String image = (String) imageField.get(token);

        assertEquals(image, result);
    }

    @Test
    @DisplayName("NCName() processes kind MOD and returns token image")
    void TC03() throws Exception {
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);

        Class<?> tokenClass = Class.forName("org.apache.commons.jxpath.ri.parser.Token");
        Object token = tokenClass.getDeclaredConstructor().newInstance();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, 5); // Assuming MOD maps to 5

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, MOD_IMAGE);

        jj_ntField.set(parser, token);

        String result = parser.NCName();
        String image = (String) imageField.get(token);

        assertEquals(image, result);
    }

    @Test
    @DisplayName("NCName() processes kind DIV and returns token image")
    void TC04() throws Exception {
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);

        Class<?> tokenClass = Class.forName("org.apache.commons.jxpath.ri.parser.Token");
        Object token = tokenClass.getDeclaredConstructor().newInstance();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, 6); // Assuming DIV maps to 6

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, DIV_IMAGE);

        jj_ntField.set(parser, token);

        String result = parser.NCName();
        String image = (String) imageField.get(token);

        assertEquals(image, result);
    }

    @Test
    @DisplayName("NCName() processes kind NCName and returns token image")
    void TC05() throws Exception {
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);

        Class<?> tokenClass = Class.forName("org.apache.commons.jxpath.ri.parser.Token");
        Object token = tokenClass.getDeclaredConstructor().newInstance();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, 1); // Assuming NCName maps to 1

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, NCNAME_IMAGE);

        jj_ntField.set(parser, token);

        String result = parser.NCName();
        String image = (String) imageField.get(token);

        assertEquals(image, result);
    }
}