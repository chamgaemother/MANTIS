package org.jfree.chart.plot;
// 
// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// 
// import java.awt.BasicStroke;
// import java.awt.Color;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.util.Objects;
// 
// import org.jfree.chart.ui.RectangleInsets;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
public class CategoryPlot_hashCode_0_1_Test {
// 
//     @Test
//     @DisplayName("hashCode with all boolean flags set to false")
//     public void TC01_hashCode_all_booleans_false() {
        // GIVEN
//         CategoryPlot plot = new CategoryPlot();
//         plot.setDrawSharedDomainAxis(false);
//         plot.setDomainGridlinesVisible(false);
//         plot.setRangeZeroBaselineVisible(false);
//         plot.setRangeGridlinesVisible(false);
//         plot.setRangeMinorGridlinesVisible(false);
//         plot.setDomainCrosshairVisible(false);
//         plot.setRangeCrosshairVisible(false);
//         plot.setRangeCrosshairLockedOnData(false);
//         plot.setRangePannable(false);
// 
        // WHEN
//         int actualHash = plot.hashCode();
// 
        // THEN
//         assertNotNull(actualHash, "hashCode should not be null");
        // Ensure computeExpectedHash works
//         int expectedHash = computeExpectedHash(plot);
//         assertEquals(expectedHash, actualHash, "hashCode should be correctly computed with all boolean flags set to false");
//     }
// 
//     @Test
//     @DisplayName("hashCode with all boolean flags set to true")
//     public void TC02_hashCode_all_booleans_true() {
        // GIVEN
//         CategoryPlot plot = new CategoryPlot();
//         plot.setDrawSharedDomainAxis(true);
//         plot.setDomainGridlinesVisible(true);
//         plot.setRangeZeroBaselineVisible(true);
//         plot.setRangeGridlinesVisible(true);
//         plot.setRangeMinorGridlinesVisible(true);
//         plot.setDomainCrosshairVisible(true);
//         plot.setRangeCrosshairVisible(true);
//         plot.setRangeCrosshairLockedOnData(true);
//         plot.setRangePannable(true);
// 
        // WHEN
//         int actualHash = plot.hashCode();
// 
        // THEN
//         assertNotNull(actualHash, "hashCode should not be null");
//         int expectedHash = computeExpectedHash(plot);
//         assertEquals(expectedHash, actualHash, "hashCode should be correctly computed with all boolean flags set to true");
//     }
// 
//     @Test
//     @DisplayName("hashCode with drawSharedDomainAxis=true and others=false")
//     public void TC03_hashCode_drawSharedDomainAxis_true_others_false() {
        // GIVEN
//         CategoryPlot plot = new CategoryPlot();
//         plot.setDrawSharedDomainAxis(true);
//         plot.setDomainGridlinesVisible(false);
//         plot.setRangeZeroBaselineVisible(false);
//         plot.setRangeGridlinesVisible(false);
//         plot.setRangeMinorGridlinesVisible(false);
//         plot.setDomainCrosshairVisible(false);
//         plot.setRangeCrosshairVisible(false);
//         plot.setRangeCrosshairLockedOnData(false);
//         plot.setRangePannable(false);
// 
        // WHEN
//         int actualHash = plot.hashCode();
// 
        // THEN
//         assertNotNull(actualHash, "hashCode should not be null");
//         int expectedHash = computeExpectedHash(plot);
//         assertEquals(expectedHash, actualHash, "hashCode should be correctly computed with drawSharedDomainAxis=true and others=false");
//     }
// 
//     @Test
//     @DisplayName("hashCode with domainGridlinesVisible=true and others=false")
//     public void TC04_hashCode_domainGridlinesVisible_true_others_false() {
        // GIVEN
//         CategoryPlot plot = new CategoryPlot();
//         plot.setDrawSharedDomainAxis(false);
//         plot.setDomainGridlinesVisible(true);
//         plot.setRangeZeroBaselineVisible(false);
//         plot.setRangeGridlinesVisible(false);
//         plot.setRangeMinorGridlinesVisible(false);
//         plot.setDomainCrosshairVisible(false);
//         plot.setRangeCrosshairVisible(false);
//         plot.setRangeCrosshairLockedOnData(false);
//         plot.setRangePannable(false);
// 
        // WHEN
//         int actualHash = plot.hashCode();
// 
        // THEN
//         assertNotNull(actualHash, "hashCode should not be null");
//         int expectedHash = computeExpectedHash(plot);
//         assertEquals(expectedHash, actualHash, "hashCode should be correctly computed with domainGridlinesVisible=true and others=false");
//     }
// 
//     @Test
//     @DisplayName("hashCode with rangeGridlinesVisible=true and others=false")
//     public void TC05_hashCode_rangeGridlinesVisible_true_others_false() {
        // GIVEN
//         CategoryPlot plot = new CategoryPlot();
//         plot.setDrawSharedDomainAxis(false);
//         plot.setDomainGridlinesVisible(false);
//         plot.setRangeZeroBaselineVisible(false);
//         plot.setRangeGridlinesVisible(true);
//         plot.setRangeMinorGridlinesVisible(false);
//         plot.setDomainCrosshairVisible(false);
//         plot.setRangeCrosshairVisible(false);
//         plot.setRangeCrosshairLockedOnData(false);
//         plot.setRangePannable(false);
// 
        // WHEN
//         int actualHash = plot.hashCode();
// 
        // THEN
//         assertNotNull(actualHash, "hashCode should not be null");
//         int expectedHash = computeExpectedHash(plot);
//         assertEquals(expectedHash, actualHash, "hashCode should be correctly computed with rangeGridlinesVisible=true and others=false");
//     }
// 
//     /**
//      * Computes the expected hash code based on the current state of the plot.
//      * This replicates the hashCode() method of CategoryPlot.
//      * 
//      * @param plot The CategoryPlot instance.
//      * @return The expected hash code.
//      */
//     private int computeExpectedHash(CategoryPlot plot) {
//         int hash = 7; // A prime number to start
//         hash = 71 * hash + Objects.hashCode(plot.getOrientation());
//         hash = 71 * hash + Objects.hashCode(plot.getAxisOffset());
//         hash = 71 * hash + Objects.hashCode(plot.getDomainAxes());
//         hash = 71 * hash + Objects.hashCode(plot.getDomainAxisLocations());
//         hash = 71 * hash + (plot.getDrawSharedDomainAxis() ? 1 : 0);
//         hash = 71 * hash + Objects.hashCode(plot.getRangeAxes());
//         hash = 71 * hash + Objects.hashCode(plot.getRangeAxisLocations());
//         hash = 71 * hash + Objects.hashCode(plot.getDatasets());
//         hash = 71 * hash + Objects.hashCode(plot.getDatasetToDomainAxesMap());
//         hash = 71 * hash + Objects.hashCode(plot.getDatasetToRangeAxesMap());
//         hash = 71 * hash + Objects.hashCode(plot.getRenderers());
//         hash = 71 * hash + Objects.hashCode(plot.getRenderingOrder());
//         hash = 71 * hash + Objects.hashCode(plot.getColumnRenderingOrder());
//         hash = 71 * hash + Objects.hashCode(plot.getRowRenderingOrder());
//         hash = 71 * hash + (plot.isDomainGridlinesVisible() ? 1 : 0);
//         hash = 71 * hash + Objects.hashCode(plot.getDomainGridlinePosition());
//         hash = 71 * hash + Objects.hashCode(plot.getDomainGridlineStroke());
//         hash = 71 * hash + Objects.hashCode(plot.getDomainGridlinePaint());
//         hash = 71 * hash + (plot.isRangeZeroBaselineVisible() ? 1 : 0);
//         hash = 71 * hash + Objects.hashCode(plot.getRangeZeroBaselineStroke());
//         hash = 71 * hash + Objects.hashCode(plot.getRangeZeroBaselinePaint());
//         hash = 71 * hash + (plot.isRangeGridlinesVisible() ? 1 : 0);
//         hash = 71 * hash + Objects.hashCode(plot.getRangeGridlineStroke());
//         hash = 71 * hash + Objects.hashCode(plot.getRangeGridlinePaint());
//         hash = 71 * hash + (plot.isRangeMinorGridlinesVisible() ? 1 : 0);
//         hash = 71 * hash + Objects.hashCode(plot.getRangeMinorGridlineStroke());
//         hash = 71 * hash + Objects.hashCode(plot.getRangeMinorGridlinePaint());
//         hash = 71 * hash + (int) (Double.doubleToLongBits(plot.getAnchorValue()) ^ (Double.doubleToLongBits(plot.getAnchorValue()) >>> 32));
//         hash = 71 * hash + plot.getCrosshairDatasetIndex();
//         hash = 71 * hash + (plot.isDomainCrosshairVisible() ? 1 : 0);
//         hash = 71 * hash + Objects.hashCode(plot.getDomainCrosshairRowKey());
//         hash = 71 * hash + Objects.hashCode(plot.getDomainCrosshairColumnKey());
//         hash = 71 * hash + Objects.hashCode(plot.getDomainCrosshairStroke());
//         hash = 71 * hash + Objects.hashCode(plot.getDomainCrosshairPaint());
//         hash = 71 * hash + (plot.isRangeCrosshairVisible() ? 1 : 0);
//         hash = 71 * hash + (int) (Double.doubleToLongBits(plot.getRangeCrosshairValue()) ^ (Double.doubleToLongBits(plot.getRangeCrosshairValue()) >>> 32));
//         hash = 71 * hash + Objects.hashCode(plot.getRangeCrosshairStroke());
//         hash = 71 * hash + Objects.hashCode(plot.getRangeCrosshairPaint());
//         hash = 71 * hash + (plot.isRangeCrosshairLockedOnData() ? 1 : 0);
//         hash = 71 * hash + Objects.hashCode(plot.getFixedDomainAxisSpace());
//         hash = 71 * hash + Objects.hashCode(plot.getFixedRangeAxisSpace());
//         hash = 71 * hash + Objects.hashCode(plot.getShadowGenerator());
//         return hash;
//     }
// 
// }
}