package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BcBands_visitMethodInsn_0_1_Test {

    @Test
    @DisplayName("visitMethodInsn with opcode invokevirtual (182) and bcCodes is empty")
    void TC01() throws Exception {
        // GIVEN
        int opcode = 182;
        String owner = "currentClass";
        String name = "someMethod";
        String desc = "(Ljava/lang/String;)V";
        Segment segment = new Segment(); // Mocked addition to satisfy BcBands constructor
        CpBands cpBands = new CpBands(segment); // Mocked addition to satisfy BcBands constructor
        BcBands bcBands = new BcBands(cpBands, segment, 1);
        bcBands.setCurrentClass(owner, "superClass");

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Access private fields via reflection
        Field opcodeField = BcBands.class.getDeclaredField("byteCodeOffset");
        opcodeField.setAccessible(true);
        int modifiedOpcode = (int) opcodeField.get(bcBands);
        assertEquals(3, modifiedOpcode, "byteCodeOffset should be updated correctly");

        Field bcThisMethodField = BcBands.class.getDeclaredField("bcThisMethod");
        bcThisMethodField.setAccessible(true);
        List<?> bcThisMethod = (List<?>) bcThisMethodField.get(bcBands);
        assertFalse(bcThisMethod.isEmpty(), "bcThisMethod should contain the method reference");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183) and owner is superClass with <init> method")
    void TC02() throws Exception {
        // GIVEN
        int opcode = 183;
        String owner = "superClass";
        String name = "<init>";
        String desc = "()V";
        Segment segment = new Segment(); // Mocked addition to satisfy BcBands constructor
        CpBands cpBands = new CpBands(segment); // Mocked addition to satisfy BcBands constructor
        BcBands bcBands = new BcBands(cpBands, segment, 1);
        bcBands.setCurrentClass("currentClass", owner);

        // Access and modify bcCodes to have ALOAD_0 at the end
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        bcCodes.add(42); // Assuming ALOAD_0 is represented by 42

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
        assertEquals(3, byteCodeOffset, "byteCodeOffset should be updated correctly");

        // Verify bcInitRef contains the method reference
        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        List<?> bcInitRef = (List<?>) bcInitRefField.get(bcBands);
        assertFalse(bcInitRef.isEmpty(), "bcInitRef should contain the method reference");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokestatic (184) and owner is neither currentClass nor superClass")
    void TC03() throws Exception {
        // GIVEN
        int opcode = 184;
        String owner = "externalClass";
        String name = "externalMethod";
        String desc = "(I)V";
        Segment segment = new Segment(); // Mocked addition to satisfy BcBands constructor
        CpBands cpBands = new CpBands(segment); // Mocked addition to satisfy BcBands constructor
        BcBands bcBands = new BcBands(cpBands, segment, 1);

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Verify bcMethodRef contains the method reference
        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        List<?> bcMethodRef = (List<?>) bcMethodRefField.get(bcBands);
        assertFalse(bcMethodRef.isEmpty(), "bcMethodRef should contain the method reference");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokeinterface (185)")
    void TC04() throws Exception {
        // GIVEN
        int opcode = 185;
        String owner = "interfaceClass";
        String name = "interfaceMethod";
        String desc = "(Ljava/lang/Object;)V";
        Segment segment = new Segment(); // Mocked addition to satisfy BcBands constructor
        CpBands cpBands = new CpBands(segment); // Mocked addition to satisfy BcBands constructor
        BcBands bcBands = new BcBands(cpBands, segment, 1);

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Verify cpIMethod is added to bcIMethodRef
        Field bcIMethodRefField = BcBands.class.getDeclaredField("bcIMethodRef");
        bcIMethodRefField.setAccessible(true);
        List<?> bcIMethodRef = (List<?>) bcIMethodRefField.get(bcBands);
        assertFalse(bcIMethodRef.isEmpty(), "bcIMethodRef should contain the CPIMethod reference");

        // Verify INVOKEINTERFACE is added to bcCodes
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(185), "bcCodes should contain INVOKEINTERFACE opcode");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), owner is currentClass, and method is not <init>")
    void TC05() throws Exception {
        // GIVEN
        int opcode = 183;
        String owner = "currentClass";
        String name = "someMethod";
        String desc = "(Ljava/lang/String;)V";
        Segment segment = new Segment(); // Mocked addition to satisfy BcBands constructor
        CpBands cpBands = new CpBands(segment); // Mocked addition to satisfy BcBands constructor
        BcBands bcBands = new BcBands(cpBands, segment, 1);
        bcBands.setCurrentClass(owner, "superClass");

        // Access and modify bcCodes to have ALOAD_0 at the end
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        bcCodes.add(42); // Assuming ALOAD_0 is represented by 42

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Verify bcThisMethod contains the method reference
        Field bcThisMethodField = BcBands.class.getDeclaredField("bcThisMethod");
        bcThisMethodField.setAccessible(true);
        List<?> bcThisMethod = (List<?>) bcThisMethodField.get(bcBands);
        assertFalse(bcThisMethod.isEmpty(), "bcThisMethod should contain the method reference");
    }
}
