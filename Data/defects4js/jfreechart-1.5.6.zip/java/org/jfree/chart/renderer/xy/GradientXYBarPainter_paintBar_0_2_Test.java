package org.jfree.chart.renderer.xy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.GradientPaint;
import java.awt.Stroke;
import java.awt.geom.RectangularShape;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleEdge;

import java.lang.reflect.Field;

public class GradientXYBarPainter_paintBar_0_2_Test {

    @Test
    @DisplayName("paintBar with non-Color and non-GradientPaint having non-zero alpha and RectangleEdge.BOTTOM without outline")
    void TC06_paintBar_DefaultPaint_NonZeroAlpha_BottomEdge_NoOutline() throws Exception {
        // Arrange
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientXYBarPainter.class.getDeclaredField("g1");
        Field g2Field = GradientXYBarPainter.class.getDeclaredField("g2");
        Field g3Field = GradientXYBarPainter.class.getDeclaredField("g3");
        g1Field.setAccessible(true);
        g2Field.setAccessible(true);
        g3Field.setAccessible(true);
        g1Field.setDouble(painter, 0.25);
        g2Field.setDouble(painter, 0.5);
        g3Field.setDouble(painter, 0.75);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        int row = 0;
        int column = 0;
        RectangularShape bar = new Rectangle2D.Double(10, 10, 50, 100);
        RectangleEdge base = RectangleEdge.BOTTOM;

        // Renderer returns a non-Color, non-GradientPaint Paint with alpha != 0
        Paint customPaint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(customPaint);
        // Assume customPaint has alpha != 0
        // Since Paint doesn't have getAlpha, we simulate behavior by ensuring the painter doesn't return early
        when(customPaint instanceof Color).thenReturn(false);
        when(customPaint instanceof GradientPaint).thenReturn(false);

        when(renderer.isDrawBarOutline()).thenReturn(false);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that default blue gradients are used
        GradientPaint gp1 = new GradientPaint((float) bar.getMinX(), 0.0f, Color.BLUE, (float) bar.getMinX() + (float)(bar.getWidth() * 0.25), 0.0f, Color.BLUE.brighter());
        GradientPaint gp2 = new GradientPaint((float) bar.getMinX() + (float)(bar.getWidth() * 0.25), 0.0f, Color.WHITE, (float) bar.getMinX() + (float)(bar.getWidth() * 0.5), 0.0f, Color.BLUE);
        GradientPaint gp3 = new GradientPaint((float) bar.getMinX() + (float)(bar.getWidth() * 0.5), 0.0f, Color.BLUE, (float) bar.getMinX() + (float)(bar.getWidth() * 0.75), 0.0f, Color.BLUE.brighter());
        GradientPaint gp4 = new GradientPaint((float) bar.getMinX() + (float)(bar.getWidth() * 0.75), 0.0f, Color.BLUE.brighter(), (float) bar.getMaxX(), 0.0f, Color.BLUE);

        verify(g2).setPaint(gp1);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp2);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp3);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp4);
        verify(g2).fill(any(Rectangle2D.class));

        // Verify no outline is drawn
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("paintBar with non-Color and non-GradientPaint having non-zero alpha and RectangleEdge.BOTTOM with outline")
    void TC07_paintBar_DefaultPaint_NonZeroAlpha_BottomEdge_WithOutline() throws Exception {
        // Arrange
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientXYBarPainter.class.getDeclaredField("g1");
        Field g2Field = GradientXYBarPainter.class.getDeclaredField("g2");
        Field g3Field = GradientXYBarPainter.class.getDeclaredField("g3");
        g1Field.setAccessible(true);
        g2Field.setAccessible(true);
        g3Field.setAccessible(true);
        g1Field.setDouble(painter, 0.25);
        g2Field.setDouble(painter, 0.5);
        g3Field.setDouble(painter, 0.75);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        int row = 1;
        int column = 1;
        RectangularShape bar = new Rectangle2D.Double(20, 20, 60, 120);
        RectangleEdge base = RectangleEdge.BOTTOM;

        // Renderer returns a non-Color, non-GradientPaint Paint with alpha != 0
        Paint customPaint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(customPaint);
        when(customPaint instanceof Color).thenReturn(false);
        when(customPaint instanceof GradientPaint).thenReturn(false);

        when(renderer.isDrawBarOutline()).thenReturn(true);
        Stroke outlineStroke = mock(Stroke.class);
        Paint outlinePaint = mock(Paint.class);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(outlineStroke);
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(outlinePaint);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify that default blue gradients are used
        GradientPaint gp1 = new GradientPaint((float) bar.getMinX(), 0.0f, Color.BLUE, (float) bar.getMinX() + (float)(bar.getWidth() * 0.25), 0.0f, Color.BLUE.brighter());
        GradientPaint gp2 = new GradientPaint((float) bar.getMinX() + (float)(bar.getWidth() * 0.25), 0.0f, Color.WHITE, (float) bar.getMinX() + (float)(bar.getWidth() * 0.5), 0.0f, Color.BLUE);
        GradientPaint gp3 = new GradientPaint((float) bar.getMinX() + (float)(bar.getWidth() * 0.5), 0.0f, Color.BLUE, (float) bar.getMinX() + (float)(bar.getWidth() * 0.75), 0.0f, Color.BLUE.brighter());
        GradientPaint gp4 = new GradientPaint((float) bar.getMinX() + (float)(bar.getWidth() * 0.75), 0.0f, Color.BLUE.brighter(), (float) bar.getMaxX(), 0.0f, Color.BLUE);

        verify(g2).setPaint(gp1);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp2);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp3);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp4);
        verify(g2).fill(any(Rectangle2D.class));

        // Verify outline is drawn
        verify(g2).setStroke(outlineStroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(bar);
    }

    @Test
    @DisplayName("paintBar with Color paint having non-zero alpha and RectangleEdge.LEFT without outline")
    void TC08_paintBar_ColorPaint_NonZeroAlpha_LeftEdge_NoOutline() throws Exception {
        // Arrange
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientXYBarPainter.class.getDeclaredField("g1");
        Field g2Field = GradientXYBarPainter.class.getDeclaredField("g2");
        Field g3Field = GradientXYBarPainter.class.getDeclaredField("g3");
        g1Field.setAccessible(true);
        g2Field.setAccessible(true);
        g3Field.setAccessible(true);
        g1Field.setDouble(painter, 0.3);
        g2Field.setDouble(painter, 0.6);
        g3Field.setDouble(painter, 0.9);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        int row = 2;
        int column = 2;
        RectangularShape bar = new Rectangle2D.Double(30, 30, 70, 140);
        RectangleEdge base = RectangleEdge.LEFT;

        // Renderer returns Color with alpha != 0
        Color colorPaint = new Color(0, 0, 255, 128); // Semi-transparent blue
        when(renderer.getItemPaint(row, column)).thenReturn(colorPaint);

        when(renderer.isDrawBarOutline()).thenReturn(false);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify horizontal gradients are used
        GradientPaint gp1 = new GradientPaint(0.0f, (float) bar.getMinY(), colorPaint, 0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.3), Color.WHITE);
        GradientPaint gp2 = new GradientPaint(0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.3), Color.WHITE, 0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.6), colorPaint);
        GradientPaint gp3 = new GradientPaint(0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.6), colorPaint, 0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.9), colorPaint.brighter());
        GradientPaint gp4 = new GradientPaint(0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.9), colorPaint.brighter(), 0.0f, (float) bar.getMaxY(), colorPaint);

        verify(g2).setPaint(gp1);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp2);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp3);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp4);
        verify(g2).fill(any(Rectangle2D.class));

        // Verify no outline is drawn
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("paintBar with non-Color and non-GradientPaint having non-zero alpha and RectangleEdge.RIGHT with null outline paint")
    void TC09_paintBar_DefaultPaint_NonZeroAlpha_RightEdge_NullOutlinePaint() throws Exception {
        // Arrange
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientXYBarPainter.class.getDeclaredField("g1");
        Field g2Field = GradientXYBarPainter.class.getDeclaredField("g2");
        Field g3Field = GradientXYBarPainter.class.getDeclaredField("g3");
        g1Field.setAccessible(true);
        g2Field.setAccessible(true);
        g3Field.setAccessible(true);
        g1Field.setDouble(painter, 0.2);
        g2Field.setDouble(painter, 0.4);
        g3Field.setDouble(painter, 0.6);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        int row = 3;
        int column = 3;
        RectangularShape bar = new Rectangle2D.Double(40, 40, 80, 160);
        RectangleEdge base = RectangleEdge.RIGHT;

        // Renderer returns a non-Color, non-GradientPaint Paint with alpha != 0
        Paint customPaint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(customPaint);
        when(customPaint instanceof Color).thenReturn(false);
        when(customPaint instanceof GradientPaint).thenReturn(false);

        when(renderer.isDrawBarOutline()).thenReturn(true);
        Stroke outlineStroke = mock(Stroke.class);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(outlineStroke);
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(null);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify horizontal gradients are used
        GradientPaint gp1 = new GradientPaint(0.0f, (float) bar.getMinY(), Color.BLUE, 0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.2), Color.WHITE);
        GradientPaint gp2 = new GradientPaint(0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.2), Color.WHITE, 0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.4), Color.BLUE);
        GradientPaint gp3 = new GradientPaint(0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.4), Color.BLUE, 0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.6), Color.BLUE.brighter());
        GradientPaint gp4 = new GradientPaint(0.0f, (float) (bar.getMinY() + bar.getHeight() * 0.6), Color.BLUE.brighter(), 0.0f, (float) bar.getMaxY(), Color.BLUE);

        verify(g2).setPaint(gp1);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp2);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp3);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp4);
        verify(g2).fill(any(Rectangle2D.class));

        // Verify outline is not drawn due to null outline paint
        verify(renderer).getItemOutlinePaint(row, column);
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("paintBar with GradientPaint and non-zero alpha on RectangleEdge.BOTTOM with outline stroke null")
    void TC10_paintBar_GradientPaint_NonZeroAlpha_BottomEdge_NullOutlineStroke() throws Exception {
        // Arrange
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientXYBarPainter.class.getDeclaredField("g1");
        Field g2Field = GradientXYBarPainter.class.getDeclaredField("g2");
        Field g3Field = GradientXYBarPainter.class.getDeclaredField("g3");
        g1Field.setAccessible(true);
        g2Field.setAccessible(true);
        g3Field.setAccessible(true);
        g1Field.setDouble(painter, 0.3);
        g2Field.setDouble(painter, 0.6);
        g3Field.setDouble(painter, 0.9);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        int row = 4;
        int column = 4;
        RectangularShape bar = new Rectangle2D.Double(50, 50, 90, 180);
        RectangleEdge base = RectangleEdge.BOTTOM;

        // Renderer returns GradientPaint with alpha != 0
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.GREEN);
        when(renderer.getItemPaint(row, column)).thenReturn(gradientPaint);

        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(null);
        Paint outlinePaint = mock(Paint.class);
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(outlinePaint);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        // Verify horizontal gradients are used
        GradientPaint gp1 = new GradientPaint((float) bar.getMinX(), 0.0f, Color.RED, (float) (bar.getMinX() + bar.getWidth() * 0.3), 0.0f, Color.WHITE);
        GradientPaint gp2 = new GradientPaint((float) (bar.getMinX() + bar.getWidth() * 0.3), 0.0f, Color.WHITE, (float) (bar.getMinX() + bar.getWidth() * 0.6), 0.0f, Color.RED);
        GradientPaint gp3 = new GradientPaint((float) (bar.getMinX() + bar.getWidth() * 0.6), 0.0f, Color.RED, (float) (bar.getMinX() + bar.getWidth() * 0.9), 0.0f, Color.GREEN);
        GradientPaint gp4 = new GradientPaint((float) (bar.getMinX() + bar.getWidth() * 0.9), 0.0f, Color.GREEN, (float) bar.getMaxX(), 0.0f, Color.RED);

        verify(g2).setPaint(gp1);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp2);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp3);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(gp4);
        verify(g2).fill(any(Rectangle2D.class));

        // Verify outline is not drawn due to null outline stroke
        verify(renderer).getItemOutlineStroke(row, column);
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }
}