import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.apache.commons.math3.ode.nonstiff.GraggBulirschStoerIntegrator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GraggBulirschStoerIntegratorTest {

    private static class SimpleProblem implements FirstOrderDifferentialEquations {
        public int getDimension() {
            return 1;
        }

        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = y[0];
        }
    }
    
    private static class ComplexProblem implements FirstOrderDifferentialEquations {
        public int getDimension() {
            return 2;
        }

        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = y[1];
            yDot[1] = -1000 * y[0];
        }
    }

    @Test
    void testIntegrateSimpleProblem() {
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.01, 1.0, 1.0e-8, 1.0e-8);
        double[] y = { 1.0 };
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new SimpleProblem());
        ode.setTime(0.0);
        ode.setCompleteState(y);

        try {
            integrator.integrate(ode, 2.0);
        } catch (Exception e) {
            fail("Integration should not throw an exception for a simple problem.");
        }

        double expected = Math.exp(2.0);
        assertEquals(expected, ode.getCompleteState()[0], 1.0e-8);
    }

    @Test
    void testIntegrateComplexProblem() {
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(1.0e-8, 1.0, 1.0e-10, 1.0e-10);
        double[] y = { 0.0, 1.0 };
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new ComplexProblem());
        ode.setTime(0.0);
        ode.setCompleteState(y);

        try {
            integrator.integrate(ode, 0.1);
        } catch (Exception e) {
            fail("Integration should not throw an exception for a complex problem.");
        }

        double expected = Math.sin(100 * Math.sqrt(10));
        assertEquals(expected, ode.getCompleteState()[0], 1.0e-2);
    }

    @Test
    void testIntegrateNegativeTime() {
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.01, 1.0, 1.0e-8, 1.0e-8);
        double[] y = { 1.0 };
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new SimpleProblem());
        ode.setTime(2.0);
        ode.setCompleteState(y);

        try {
            integrator.integrate(ode, 0.0);
        } catch (Exception e) {
            fail("Integration should not throw an exception for negative time.");
        }

        double expected = 1.0;
        assertEquals(expected, ode.getCompleteState()[0], 1.0e-8);
    }

    @Test
    void testNullODEThrowsException() {
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.01, 1.0, 1.0e-8, 1.0e-8);

        assertThrows(NullPointerException.class, () -> integrator.integrate(null, 1.0));
    }

    @Test
    void testZeroStepSizeThrowsException() {
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.0, 0.0, 1.0e-8, 1.0e-8);
        double[] y = { 1.0 };
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new SimpleProblem());
        ode.setTime(0.0);
        ode.setCompleteState(y);

        assertThrows(NumberIsTooSmallException.class, () -> integrator.integrate(ode, 1.0));
    }

    @Test
    void testInvalidDimensionThrowsException() {
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.01, 1.0, 1.0e-8, 1.0e-8);
        double[] y = { 1.0, 2.0 };
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new SimpleProblem());
        ode.setTime(0.0);
        ode.setCompleteState(y);

        assertThrows(DimensionMismatchException.class, () -> integrator.integrate(ode, 1.0));
    }
}