package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Dfp_sqrt_0_2_Test {

    @Test
    @DisplayName("sqrt() with negative finite input sets QNaN and traps invalid flag")
    void test_TC06() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field);

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0); // Assuming FINITE is represented by 0

        // Set 'mant' to a valid mantissa
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = new int[input.mant.length]; // Fixed the mantissa length by using direct access
        mantissa[mantissa.length - 1] = 1000;
        mantField.set(input, mantissa);

        // Set 'sign' to -1 (negative)
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)-1);

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Verify that the invalid flag is set
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlags");
        ieeeFlagsField.setAccessible(true);
        int ieeeFlags = ieeeFlagsField.getInt(resultField);
        assertTrue((ieeeFlags & DfpField.FLAG_INVALID) != 0, "Invalid flag should be set");

        // Verify that 'nans' is set to QNAN
        byte nans = nansField.getByte(result);
        assertEquals(Dfp.QNAN, nans, "nans should be QNAN");
    }

    @Test
    @DisplayName("sqrt() with x.exp less than -1 adjusts exponent accordingly")
    void test_TC07() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field);

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0);

        // Set 'mant' to a valid mantissa
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = new int[input.mant.length]; // Adjusting mantissa length
        mantissa[mantissa.length - 1] = 1000;
        mantField.set(input, mantissa);

        // Set 'sign' to 1 (positive)
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Set 'exp' to -2
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, -2);

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Verify that 'exp' is adjusted to exp / 2
        int exp = expField.getInt(result);
        assertEquals(-1, exp, "Exponent should be adjusted to exp / 2");
    }

    @Test
    @DisplayName("sqrt() with x.exp greater than 1 adjusts exponent accordingly")
    void test_TC08() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field);

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0);

        // Set 'mant' to a valid mantissa
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = new int[input.mant.length];
        mantissa[mantissa.length - 1] = 1000;
        mantField.set(input, mantissa);

        // Set 'sign' to 1 (positive)
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Set 'exp' to 2
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 2);

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Verify that 'exp' is adjusted to exp / 2
        int exp = expField.getInt(result);
        assertEquals(1, exp, "Exponent should be adjusted to exp / 2");
    }

    @Test
    @DisplayName("sqrt() with mantissa last digit divided by 2000 equals 0 applies case 0 in switch")
    void test_TC09() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field);

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0);

        // Set 'mant' so that mant[last] / 2000 == 0
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = new int[input.mant.length];
        mantissa[mantissa.length - 1] = 1000; // 1000 / 2000 == 0
        mantField.set(input, mantissa);

        // Set 'sign' to 1 (positive)
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Verify that mant[last] is set to mant[last]/2 + 1
        int[] resultMant = (int[]) mantField.get(result);
        assertEquals(501, resultMant[resultMant.length - 1], "Mantissa last digit should be mant[last]/2 + 1");
    }

    @Test
    @DisplayName("sqrt() with mantissa last digit divided by 2000 equals 2 applies case 2 in switch")
    void test_TC10() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field);

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0);

        // Set 'mant' so that mant[last] / 2000 == 2
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = new int[input.mant.length];
        mantissa[mantissa.length - 1] = 4000; // 4000 / 2000 == 2
        mantField.set(input, mantissa);

        // Set 'sign' to 1 (positive)
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Verify that mant[last] is set to 1500
        int[] resultMant = (int[]) mantField.get(result);
        assertEquals(1500, resultMant[resultMant.length - 1], "Mantissa last digit should be set to 1500");
    }
}