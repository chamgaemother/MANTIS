package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ConversionTest {

    @Test
    void testBinaryToHexDigit_NullSrc() {
        assertThrows(NullPointerException.class, () -> {
            Conversion.binaryToHexDigit(null, 0);
        });
    }

    @Test
    void testBinaryToHexDigit_EmptySrc() {
        boolean[] src = {};
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            Conversion.binaryToHexDigit(src, 0);
        });
        assertEquals("Cannot convert an empty array.", exception.getMessage());
    }

    @Test
    void testBinaryToHexDigit_SrcPosNegative() {
        boolean[] src = {true, false, true, false};
        assertThrows(IndexOutOfBoundsException.class, () -> {
            Conversion.binaryToHexDigit(src, -1);
        });
    }

    @Test
    void testBinaryToHexDigit_SrcPosTooLarge() {
        boolean[] src = {true, false, true, false};
        assertThrows(IndexOutOfBoundsException.class, () -> {
            Conversion.binaryToHexDigit(src, 4);
        });
    }

    @Test
    void testBinaryToHexDigit_FullLength_F_Case_f() {
        boolean[] src = {true, true, true, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('f', result);
    }

    @Test
    void testBinaryToHexDigit_FullLength_FalseLastBit_e() {
        boolean[] src = {false, true, true, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('e', result);
    }

    @Test
    void testBinaryToHexDigit_FullLength_D() {
        boolean[] src = {true, false, true, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('d', result);
    }

    @Test
    void testBinaryToHexDigit_FullLength_C() {
        boolean[] src = {false, false, true, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('c', result);
    }

    @Test
    void testBinaryToHexDigit_FullLength_B() {
        boolean[] src = {true, true, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('b', result);
    }

    @Test
    void testBinaryToHexDigit_FullLength_A() {
        boolean[] src = {false, true, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('a', result);
    }

    @Test
    void testBinaryToHexDigit_FullLength_9() {
        boolean[] src = {true, false, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('9', result);
    }

    @Test
    void testBinaryToHexDigit_FullLength_8() {
        boolean[] src = {false, false, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('8', result);
    }

    @Test
    void testBinaryToHexDigit_LengthGreaterThan3_SrcPos0_7() {
        boolean[] src = {true, true, true, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('7', result);
    }

    @Test
    void testBinaryToHexDigit_LengthGreaterThan3_SrcPos0_6() {
        boolean[] src = {false, true, true, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('6', result);
    }

    @Test
    void testBinaryToHexDigit_LengthGreaterThan3_SrcPos0_5() {
        boolean[] src = {true, false, true, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('5', result);
    }

    @Test
    void testBinaryToHexDigit_LengthGreaterThan3_SrcPos0_4() {
        boolean[] src = {false, false, true, false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('4', result);
    }

    @Test
    void testBinaryToHexDigit_LengthGreaterThan1_SrcPos0_3() {
        boolean[] src = {true, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('3', result);
    }

    @Test
    void testBinaryToHexDigit_LengthGreaterThan1_SrcPos0_2() {
        boolean[] src = {false, true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('2', result);
    }

    @Test
    void testBinaryToHexDigit_SingleBit_1() {
        boolean[] src = {true};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('1', result);
    }

    @Test
    void testBinaryToHexDigit_SingleBit_0() {
        boolean[] src = {false};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('0', result);
    }

    @Test
    void testBinaryToHexDigit_MixedBits_f() {
        boolean[] src = {true, true, true, true, true};
        char result = Conversion.binaryToHexDigit(src, 1);
        assertEquals('f', result);
    }

    @Test
    void testBinaryToHexDigit_MixedBits_e() {
        boolean[] src = {false, true, true, true, true};
        char result = Conversion.binaryToHexDigit(src, 1);
        assertEquals('e', result);
    }

    @Test
    void testBinaryToHexDigit_MixedBits_c() {
        boolean[] src = {false, false, true, true, true};
        char result = Conversion.binaryToHexDigit(src, 1);
        assertEquals('c', result);
    }

    @Test
    void testBinaryToHexDigit_MixedBits_b() {
        boolean[] src = {true, true, false, true, true};
        char result = Conversion.binaryToHexDigit(src, 1);
        assertEquals('b', result);
    }

    @Test
    void testBinaryToHexDigit_MixedBits_7() {
        boolean[] src = {true, true, true, false, true, false};
        char result = Conversion.binaryToHexDigit(src, 0);
        assertEquals('7', result);
    }

    @Test
    void testBinaryToHexDigit_MixedBits_1() {
        boolean[] src = {true, false, false, false, false};
        char result = Conversion.binaryToHexDigit(src, 1);
        assertEquals('1', result);
    }

}