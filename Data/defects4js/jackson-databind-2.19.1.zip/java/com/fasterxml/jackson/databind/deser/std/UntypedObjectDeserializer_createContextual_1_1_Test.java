package com.fasterxml.jackson.databind.deser.std;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.KeyDeserializer;

public class UntypedObjectDeserializer_createContextual_1_1_Test {

    @Test
    @DisplayName("createContextual with property not null, defaultMergeable false, and standard customKeyDeserializer")
    void TC14_createContextual_withPropertyNotNull_defaultMergeableFalse_standardCustomKeyDeserializer() throws Exception {
        // GIVEN
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);

        // Mocking ctxt.getConfig().getDefaultMergeable(Object.class) to return false
        when(ctxt.getConfig()).thenReturn(mock(com.fasterxml.jackson.databind.DeserializationConfig.class));
        when(ctxt.getConfig().getDefaultMergeable(Object.class)).thenReturn(false);

        // Mocking ctxt.findKeyDeserializer(...) to return a standard KeyDeserializer
        KeyDeserializer standardKeyDeserializer = mock(KeyDeserializer.class);
        when(ctxt.constructType(Object.class)).thenReturn(mock(com.fasterxml.jackson.databind.JavaType.class));
        when(ctxt.findKeyDeserializer(any(com.fasterxml.jackson.databind.JavaType.class), eq(property))).thenReturn(standardKeyDeserializer);

        // Mocking ClassUtil.isJacksonStdImpl to return true for the standardKeyDeserializer
        // Since ClassUtil.isJacksonStdImpl is a static method, we cannot mock it directly without a framework like PowerMockito.
        // Therefore, we assume that standardKeyDeserializer is a Jackson standard implementation.

        // Instantiate UntypedObjectDeserializer
        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer();

        // WHEN
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        // THEN
        assertNotNull(result);
        assertNotSame(deserializer, result, "A new UntypedObjectDeserializer instance should be returned");

        // Use reflection to verify preventMerge is true
        Field nonMergingField = UntypedObjectDeserializer.class.getDeclaredField("_nonMerging");
        nonMergingField.setAccessible(true);
        boolean preventMerge = (boolean) nonMergingField.get(result);
        assertTrue(preventMerge, "preventMerge should be true");
    }

    @Test
    @DisplayName("createContextual with property not null, defaultMergeable true, and multiple non-null deserializers")
    void TC15_createContextual_withPropertyNotNull_defaultMergeableTrue_multipleNonNullDeserializers() throws Exception {
        // GIVEN
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);

        // Mocking ctxt.getConfig().getDefaultMergeable(Object.class) to return true
        when(ctxt.getConfig()).thenReturn(mock(com.fasterxml.jackson.databind.DeserializationConfig.class));
        when(ctxt.getConfig().getDefaultMergeable(Object.class)).thenReturn(true);

        // Mocking ctxt.findKeyDeserializer(...) to return a non-standard KeyDeserializer
        KeyDeserializer customKeyDeserializer = mock(KeyDeserializer.class);
        when(ctxt.constructType(Object.class)).thenReturn(mock(com.fasterxml.jackson.databind.JavaType.class));
        when(ctxt.findKeyDeserializer(any(com.fasterxml.jackson.databind.JavaType.class), eq(property))).thenReturn(customKeyDeserializer);

        // Mocking ClassUtil.isJacksonStdImpl to return false for the customKeyDeserializer
        // Since ClassUtil.isJacksonStdImpl is a static method, we cannot mock it directly without a framework like PowerMockito.
        // Therefore, we assume that customKeyDeserializer is a non-standard implementation.

        // Instantiate UntypedObjectDeserializer with non-null deserializers using reflection
        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer();
        setPrivateField(deserializer, "_stringDeserializer", mock(JsonDeserializer.class));
        setPrivateField(deserializer, "_numberDeserializer", mock(JsonDeserializer.class));
        setPrivateField(deserializer, "_mapDeserializer", mock(JsonDeserializer.class));
        setPrivateField(deserializer, "_listDeserializer", mock(JsonDeserializer.class));

        // WHEN
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        // THEN
        assertNotNull(result);
        assertSame(deserializer, result, "The same UntypedObjectDeserializer instance should be returned");

        // Use reflection to verify preventMerge remains consistent (should be false)
        Field nonMergingField = UntypedObjectDeserializer.class.getDeclaredField("_nonMerging");
        nonMergingField.setAccessible(true);
        boolean preventMerge = (boolean) nonMergingField.get(result);
        assertFalse(preventMerge, "preventMerge should remain false");
    }

    /**
     * Helper method to set a private field via reflection.
     *
     * @param target The object whose field should be modified.
     * @param fieldName The name of the field to modify.
     * @param value The value to set.
     * @throws Exception If reflection access fails.
     */
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = UntypedObjectDeserializer.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}