package org.apache.commons.math3.ode.events;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.solvers.BracketedRealFieldUnivariateSolver;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.apache.commons.math3.ode.sampling.FieldStepInterpolator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FieldEventState_evaluateStep_2_1_Test {

//     @Test
//     @DisplayName("evaluateStep detects an event at the end of the step, triggering a pending event")
//     void TC23_evaluateStep_EventAtStepEnd() throws Exception {
//         FieldEventHandler<RealFieldElement<?>> handler = mock(FieldEventHandler.class);
//         BracketedRealFieldUnivariateSolver<RealFieldElement<?>> solver = mock(BracketedRealFieldUnivariateSolver.class);
//         RealFieldElement<?> convergence = mock(RealFieldElement.class);
//         when(convergence.abs()).thenReturn(convergence);
//         when(convergence.getReal()).thenReturn(1e-6);
//         FieldEventState<RealFieldElement<?>> eventState = new FieldEventState<>(handler, 1.0, convergence, 100, solver);
// 
//         setFieldValue(eventState, "t0", mock(RealFieldElement.class));
// 
//         RealFieldElement<?> g0 = mock(RealFieldElement.class);
//         when(g0.getReal()).thenReturn(1.0);
//         setFieldValue(eventState, "g0", g0);
// 
//         setFieldValue(eventState, "g0Positive", true);
//         setFieldValue(eventState, "previousEventTime", null);
// 
//         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
//         when(interpolator.isForward()).thenReturn(true);
//         FieldODEStateAndDerivative<RealFieldElement<?>> currentState = mock(FieldODEStateAndDerivative.class);
//         RealFieldElement<?> t1 = mock(RealFieldElement.class);
//         when(t1.subtract(any(RealFieldElement.class)).getReal()).thenReturn(1.0);
//         when(currentState.getTime()).thenReturn(t1);
//         when(interpolator.getCurrentState()).thenReturn(currentState);
//         when(interpolator.getPreviousState()).thenReturn(mock(FieldODEStateAndDerivative.class));
//         when(handler.g(any())).thenReturn(mock(RealFieldElement.class));
// 
//         boolean result = eventState.evaluateStep(interpolator);
// 
//         assertTrue(result);
//         assertTrue(getFieldValue(eventState, "pendingEvent", Boolean.class));
//         assertNotNull(getFieldValue(eventState, "pendingEventTime", RealFieldElement.class));
//     }

//     @Test
//     @DisplayName("evaluateStep detects an event at the very start of the step when g0 is zero")
//     void TC24_evaluateStep_G0ZeroNoEvent() throws Exception {
//         FieldEventHandler<RealFieldElement<?>> handler = mock(FieldEventHandler.class);
//         BracketedRealFieldUnivariateSolver<RealFieldElement<?>> solver = mock(BracketedRealFieldUnivariateSolver.class);
//         RealFieldElement<?> convergence = mock(RealFieldElement.class);
//         when(convergence.abs()).thenReturn(convergence);
//         when(convergence.getReal()).thenReturn(1e-6);
//         FieldEventState<RealFieldElement<?>> eventState = new FieldEventState<>(handler, 1.0, convergence, 100, solver);
// 
//         setFieldValue(eventState, "t0", mock(RealFieldElement.class));
// 
//         RealFieldElement<?> g0 = mock(RealFieldElement.class);
//         when(g0.getReal()).thenReturn(0.0);
//         when(handler.g(any())).thenReturn(g0);
//         setFieldValue(eventState, "g0", g0);
// 
//         setFieldValue(eventState, "g0Positive", true);
// 
//         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
//         when(interpolator.isForward()).thenReturn(true);
//         FieldODEStateAndDerivative<RealFieldElement<?>> previousState = mock(FieldODEStateAndDerivative.class);
//         RealFieldElement<?> t = mock(RealFieldElement.class);
//         when(t.subtract(any(RealFieldElement.class)).getReal()).thenReturn(1.0);
//         when(previousState.getTime()).thenReturn(t);
//         when(interpolator.getPreviousState()).thenReturn(previousState);
//         when(interpolator.getCurrentState()).thenReturn(previousState);
// 
//         boolean result = eventState.evaluateStep(interpolator);
// 
//         assertFalse(result);
//         assertFalse(getFieldValue(eventState, "pendingEvent", Boolean.class));
//         assertNull(getFieldValue(eventState, "pendingEventTime", RealFieldElement.class));
//     }

//     @Test
//     @DisplayName("evaluateStep detects multiple events within a single step, setting pendingEvent for the first")
//     void TC25_evaluateStep_MultipleEventsInOneStep() throws Exception {
//         FieldEventHandler<RealFieldElement<?>> handler = mock(FieldEventHandler.class);
//         BracketedRealFieldUnivariateSolver<RealFieldElement<?>> solver = mock(BracketedRealFieldUnivariateSolver.class);
//         RealFieldElement<?> convergence = mock(RealFieldElement.class);
//         when(convergence.abs()).thenReturn(convergence);
//         when(convergence.getReal()).thenReturn(1e-6);
//         FieldEventState<RealFieldElement<?>> eventState = new FieldEventState<>(handler, 1.0, convergence, 100, solver);
// 
//         setFieldValue(eventState, "t0", mock(RealFieldElement.class));
// 
//         RealFieldElement<?> g0 = mock(RealFieldElement.class);
//         when(g0.getReal()).thenReturn(1.0);
//         setFieldValue(eventState, "g0", g0);
// 
//         setFieldValue(eventState, "g0Positive", true);
// 
//         RealFieldElement<?> g1 = mock(RealFieldElement.class);
//         RealFieldElement<?> g2 = mock(RealFieldElement.class);
//         RealFieldElement<?> g3 = mock(RealFieldElement.class);
//         when(g1.getReal()).thenReturn(-1.0);
//         when(g2.getReal()).thenReturn(1.0);
//         when(g3.getReal()).thenReturn(-1.0);
//         when(handler.g(any())).thenReturn(g1, g2, g3);
// 
//         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
//         when(interpolator.isForward()).thenReturn(true);
//         FieldODEStateAndDerivative<RealFieldElement<?>> currentState = mock(FieldODEStateAndDerivative.class);
//         when(currentState.getTime()).thenReturn(mock(RealFieldElement.class));
//         when(interpolator.getCurrentState()).thenReturn(currentState);
//         when(interpolator.getPreviousState()).thenReturn(mock(FieldODEStateAndDerivative.class));
// 
//         boolean result = eventState.evaluateStep(interpolator);
// 
//         assertTrue(result);
//         assertTrue(getFieldValue(eventState, "pendingEvent", Boolean.class));
//         assertNotNull(getFieldValue(eventState, "pendingEventTime", RealFieldElement.class));
//     }

//     @Test
//     @DisplayName("evaluateStep detects an event during backward integration, correctly setting event properties")
//     void TC26_evaluateStep_EventDuringBackwardIntegration() throws Exception {
//         FieldEventHandler<RealFieldElement<?>> handler = mock(FieldEventHandler.class);
//         BracketedRealFieldUnivariateSolver<RealFieldElement<?>> solver = mock(BracketedRealFieldUnivariateSolver.class);
//         RealFieldElement<?> convergence = mock(RealFieldElement.class);
//         when(convergence.abs()).thenReturn(convergence);
//         when(convergence.getReal()).thenReturn(1e-6);
//         FieldEventState<RealFieldElement<?>> eventState = new FieldEventState<>(handler, 1.0, convergence, 100, solver);
// 
//         setFieldValue(eventState, "t0", mock(RealFieldElement.class));
// 
//         RealFieldElement<?> g0 = mock(RealFieldElement.class);
//         when(g0.getReal()).thenReturn(-1.0);
//         setFieldValue(eventState, "g0", g0);
// 
//         setFieldValue(eventState, "g0Positive", false);
// 
//         setFieldValue(eventState, "forward", false);
// 
//         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
//         when(interpolator.isForward()).thenReturn(false);
//         FieldODEStateAndDerivative<RealFieldElement<?>> currentState = mock(FieldODEStateAndDerivative.class);
//         RealFieldElement<?> t = mock(RealFieldElement.class);
//         when(t.subtract(any(RealFieldElement.class)).getReal()).thenReturn(1.0);
//         when(currentState.getTime()).thenReturn(t);
//         when(interpolator.getCurrentState()).thenReturn(currentState);
//         when(interpolator.getPreviousState()).thenReturn(mock(FieldODEStateAndDerivative.class));
//         when(handler.g(any())).thenReturn(mock(RealFieldElement.class));
// 
//         boolean result = eventState.evaluateStep(interpolator);
// 
//         assertTrue(result);
//         assertTrue(getFieldValue(eventState, "pendingEvent", Boolean.class));
//         assertNotNull(getFieldValue(eventState, "pendingEventTime", RealFieldElement.class));
//     }

//     @Test
//     @DisplayName("evaluateStep throws NoBracketingException when solver cannot bracket the event")
//     void TC27_evaluateStep_NoBracketingExceptionHandled() throws Exception {
//         FieldEventHandler<RealFieldElement<?>> handler = mock(FieldEventHandler.class);
//         BracketedRealFieldUnivariateSolver<RealFieldElement<?>> solver = mock(BracketedRealFieldUnivariateSolver.class);
//         RealFieldElement<?> convergence = mock(RealFieldElement.class);
//         when(convergence.abs()).thenReturn(convergence);
//         when(convergence.getReal()).thenReturn(1e-6);
//         FieldEventState<RealFieldElement<?>> eventState = new FieldEventState<>(handler, 1.0, convergence, 100, solver);
// 
//         setFieldValue(eventState, "t0", mock(RealFieldElement.class));
// 
//         RealFieldElement<?> g0 = mock(RealFieldElement.class);
//         when(g0.getReal()).thenReturn(1.0);
//         setFieldValue(eventState, "g0", g0);
// 
//         setFieldValue(eventState, "g0Positive", true);
// 
//         when(solver.solve(anyInt(), any(), any(), any(), any())).thenThrow(new NoBracketingException(1.0, mock(RealFieldElement.class)));
// 
//         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
//         when(interpolator.isForward()).thenReturn(true);
//         FieldODEStateAndDerivative<RealFieldElement<?>> currentState = mock(FieldODEStateAndDerivative.class);
//         RealFieldElement<?> t = mock(RealFieldElement.class);
//         when(t.subtract(any(RealFieldElement.class)).getReal()).thenReturn(1.0);
//         when(currentState.getTime()).thenReturn(t);
//         when(interpolator.getCurrentState()).thenReturn(currentState);
//         when(interpolator.getPreviousState()).thenReturn(mock(FieldODEStateAndDerivative.class));
//         when(handler.g(any())).thenReturn(mock(RealFieldElement.class));
// 
//         boolean result = false;
//         try {
//             result = eventState.evaluateStep(interpolator);
//         } catch (NoBracketingException e) {
//             fail("NoBracketingException should be handled within evaluateStep");
//         }
// 
//         assertFalse(result);
//         assertFalse(getFieldValue(eventState, "pendingEvent", Boolean.class));
//         assertNull(getFieldValue(eventState, "pendingEventTime", RealFieldElement.class));
//     }

    private <T> void setFieldValue(Object instance, String fieldName, T value) throws NoSuchFieldException, IllegalAccessException {
        Field field = instance.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(instance, value);
    }

    private <T> T getFieldValue(Object instance, String fieldName, Class<T> fieldType) throws NoSuchFieldException, IllegalAccessException {
        Field field = instance.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return fieldType.cast(field.get(instance));
    }
}