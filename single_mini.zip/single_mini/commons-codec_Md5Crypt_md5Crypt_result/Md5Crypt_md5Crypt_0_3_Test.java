package org.apache.commons.codec.digest;

import org.apache.commons.codec.Charsets;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Md5Crypt_md5Crypt_0_3_Test {

    @Test
    @DisplayName("md5Crypt processes salt with maximum allowed characters")
    void TC11_md5Crypt_maximum_length_salt() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$abcdefgh";
        String prefix = "$1$";
        
        // WHEN
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertTrue(result.startsWith("$1$abcdefgh$"), "Hash should start with the correct prefix and salt");
        assertEquals(34, result.length(), "Hash length should be 34 characters"); // Expected length for MD5-crypt with prefix and 8-char salt
    }
    
    @Test
    @DisplayName("md5Crypt with non-ASCII characters in keyBytes")
    void TC12_md5Crypt_non_ASCII_keyBytes() {
        // GIVEN
        byte[] keyBytes = "pÃÂ¤sswÃÂ¶rd".getBytes(Charsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertTrue(result.startsWith("$1$salt1234$"), "Hash should start with the correct prefix and salt");
        assertEquals(34, result.length(), "Hash length should be 34 characters"); // Expected length for MD5-crypt with prefix and 8-char salt
    }
    
    @Test
    @DisplayName("md5Crypt processes maximum number of rounds without interruption")
    void TC13_md5Crypt_completing_all_1000_rounds() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertTrue(result.startsWith("$1$salt1234$"), "Hash should start with the correct prefix and salt");
        assertEquals(34, result.length(), "Hash length should be 34 characters"); // Expected length for MD5-crypt with prefix and 8-char salt
    }
}