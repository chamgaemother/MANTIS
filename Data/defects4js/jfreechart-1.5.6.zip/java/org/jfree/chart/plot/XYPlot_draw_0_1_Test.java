package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class XYPlot_draw_0_1_Test {

    @Test
    @DisplayName("Draw method with info as null and parentState as null, no subplots")
    public void TC01_draw_with_null_info_and_no_subplots() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        PlotState parentState = null;
        PlotRenderingInfo info = null;
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();

        // WHEN
        plot.draw(g2, area, anchor, parentState, info);

        // THEN
        // Since info is null, we cannot verify interactions with it.
        // Verify that no subplots are drawn
        assertTrue(plot.getSubplots().isEmpty(), "No subplots should be present.");
    }

    @Test
    @DisplayName("Draw method with info as non-null and parentState as null, single subplot")
    public void TC02_draw_with_info_and_single_subplot() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        PlotState parentState = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        XYPlot subplot = mock(XYPlot.class);
        plot.add(subplot);

        // WHEN
        plot.draw(g2, area, anchor, parentState, info);

        // THEN
        // Verify that setPlotArea was called if applicable
        // Since internal methods are not accessible, we verify interactions
        verify(info, atLeastOnce()).setPlotArea(any(Rectangle2D.class));
        verify(info, atLeastOnce()).addSubplotInfo(any(PlotRenderingInfo.class));
        // Verify that subplot.draw was called
        verify(subplot, atLeastOnce()).draw(eq(g2), any(Rectangle2D.class), eq(anchor), any(PlotState.class), any(PlotRenderingInfo.class));
    }

    @Test
    @DisplayName("Draw method with info as non-null and parentState as non-null, multiple subplots")
    public void TC03_draw_with_info_and_parentState_and_multiple_subplots() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        PlotState parentState = new PlotState();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        XYPlot subplot1 = mock(XYPlot.class);
        XYPlot subplot2 = mock(XYPlot.class);
        plot.add(subplot1);
        plot.add(subplot2);

        // WHEN
        plot.draw(g2, area, anchor, parentState, info);

        // THEN
        // Verify that shared axis states are updated
        // Since shared axis states are internal, we can verify interactions with info
        verify(info, atLeast(2)).addSubplotInfo(any(PlotRenderingInfo.class));
        // Verify that each subplot's draw method was called
        verify(subplot1, atLeastOnce()).draw(eq(g2), any(Rectangle2D.class), eq(anchor), eq(parentState), any(PlotRenderingInfo.class));
        verify(subplot2, atLeastOnce()).draw(eq(g2), any(Rectangle2D.class), eq(anchor), eq(parentState), any(PlotRenderingInfo.class));
    }

    @Test
    @DisplayName("Draw method with info as null and multiple subplots")
    public void TC04_draw_with_null_info_and_multiple_subplots() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        PlotState parentState = null;
        PlotRenderingInfo info = null;
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        XYPlot subplot1 = mock(XYPlot.class);
        XYPlot subplot2 = mock(XYPlot.class);
        plot.add(subplot1);
        plot.add(subplot2);

        // WHEN
        plot.draw(g2, area, anchor, parentState, info);

        // THEN
        // Since info is null, verify that subplots are drawn without plot info
        verify(subplot1, atLeastOnce()).draw(eq(g2), any(Rectangle2D.class), eq(anchor), any(PlotState.class), isNull());
        verify(subplot2, atLeastOnce()).draw(eq(g2), any(Rectangle2D.class), eq(anchor), any(PlotState.class), isNull());
    }

    @Test
    @DisplayName("Draw method with info as non-null, parentState as null, no subplots")
    public void TC05_draw_with_info_and_no_subplots() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        PlotState parentState = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();

        // WHEN
        plot.draw(g2, area, anchor, parentState, info);

        // THEN
        // Verify that dataArea is set correctly
        ArgumentCaptor<Rectangle2D> dataAreaCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(info, atLeastOnce()).setDataArea(dataAreaCaptor.capture());
        Rectangle2D capturedDataArea = dataAreaCaptor.getValue();
        assertNotNull(capturedDataArea, "Data area should be set.");
        // Additional assertions can be added based on the expected trimming of the area
    }
}