import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class ISO8601UtilsTest {

    @Test
    void testParseValidDateWithTimezone() throws ParseException {
        String dateStr = "2023-10-13T15:23:01+01:00";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }

    @Test
    void testParseValidDateWithUTCTimezone() throws ParseException {
        String dateStr = "2023-10-13T15:23:01Z";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }

    @Test
    void testParseValidDateWithoutTimezone() throws ParseException {
        String dateStr = "2023-10-13";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }

    @Test
    void testParseValidDateWithLeapSecond() throws ParseException {
        String dateStr = "2023-10-13T15:23:60Z";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "20231013T152301+01:00", // Compact format with timezone
        "20231013T152301Z", // Compact format with Z
        "20231013", // Date without time
        "2023-10-13T15:23:01.123Z", // Date with milliseconds
        "2023-10-13T15:23:01.123+01:00" // Date with milliseconds and timezone
    })
    void testParseValidCompactAndFullDates(String dateStr) throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
    }

    @Test
    void testParseInvalidDateWithBadTimezone() {
        String dateStr = "2023-10-13T15:23:01+25:00";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(dateStr, pos));
    }

    @Test
    void testParseNullDateString() {
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(null, pos));
    }

    @Test
    void testParseEmptyDateString() {
        String dateStr = "";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(dateStr, pos));
    }

    @Test
    void testParseIncompleteDateString() {
        String dateStr = "2023-10-13T15";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(dateStr, pos));
    }

    @Test
    void testParseInvalidNumberThrows() {
        String dateStr = "202x-10-13";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(dateStr, pos));
    }

    @Test
    void testParseInvalidDateBadSeparator() {
        String dateStr = "2023/10/13T15:23:01+01:00";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(dateStr, pos));
    }

    @Test
    void testParseInvalidDateExtraCharacters() {
        String dateStr = "2023-10-13T15:23:01+01:00abc";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(dateStr, pos));
    }
}