package org.jfree.chart.renderer.category;

import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.awt.geom.Point2D;

@ExtendWith(MockitoExtension.class)
public class BarRendererTest {

    @Mock
    private Graphics2D g2;

    @Mock
    private CategoryItemRendererState state;

    @Mock
    private Rectangle2D dataArea;

    @Mock
    private CategoryPlot plot;

    @Mock
    private CategoryAxis domainAxis;

    @Mock
    private ValueAxis rangeAxis;

    @Mock
    private CategoryDataset dataset;

    @Mock
    private CategoryItemLabelGenerator labelGenerator;

    @Mock
    private EntityCollection entities;

    @InjectMocks
    private BarRenderer renderer;

    @Captor
    private ArgumentCaptor<Rectangle2D> barCaptor;

    @BeforeEach
    public void setUp() {
        renderer.setBase(0.0);
        renderer.setIncludeBaseInRange(true);
        renderer.setItemMargin(0.2);
        renderer.setDrawBarOutline(false);
        renderer.setMaximumBarWidth(1.0);
        renderer.setMinimumBarLength(0.0);
        renderer.setBarPainter(new GradientBarPainter());
        renderer.setShadowsVisible(true);
        renderer.setShadowPaint(java.awt.Color.GRAY);
        renderer.setShadowXOffset(4.0);
        renderer.setShadowYOffset(4.0);
    }

    @Test
    public void testDrawItem_VisibleRowNegative() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(-1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItem_DataValueNull() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItem_BarNotVisible_LowClip() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(-10.0);
        when(renderer.getBase()).thenReturn(0.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(1.0, 20.0));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItem_BarNotVisible_HighClip() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(30.0);
        when(renderer.getBase()).thenReturn(0.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(1.0, 20.0));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItem_HorizontalPositiveWithShadow() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(15.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(state.getBarWidth()).thenReturn(10.0);
        when(state.getElementHinting()).thenReturn(false);
        when(plot.indexOf(dataset)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).fill(barCaptor.capture());
    }

    @Test
    public void testDrawItem_VerticalNegativeWithoutShadow() {
        renderer.setShadowsVisible(false);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(-5.0);
        when(renderer.getBase()).thenReturn(0.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(-10.0, 10.0));
        when(rangeAxis.isInverted()).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(8.0);
        when(state.getElementHinting()).thenReturn(false);
        when(plot.indexOf(dataset)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, never()).setPaint(eq(renderer.getShadowPaint()));
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).fill(barCaptor.capture());
    }

    @Test
    public void testDrawItem_LabelGeneratorNull() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(renderer.getItemLabelGenerator(0, 0)).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, never()).setFont(any());
        verify(g2, never()).setPaint(any());
    }

    @Test
    public void testDrawItem_ItemLabelVisibleFalse() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(renderer.getItemLabelGenerator(0, 0)).thenReturn(labelGenerator);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(labelGenerator, never()).generateLabel(any(), anyInt(), anyInt());
    }

    @Test
    public void testDrawItem_ItemLabelVisibleTrue_WithFallback() {
        renderer.setPositiveItemLabelPositionFallback(null);
        renderer.setNegativeItemLabelPositionFallback(null);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(renderer.getItemLabelGenerator(0, 0)).thenReturn(labelGenerator);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(labelGenerator.generateLabel(dataset, 0, 0)).thenReturn("Label");
        when(renderer.getItemLabelPaint(0, 0)).thenReturn(java.awt.Color.BLACK);
        when(renderer.getItemLabelFont(0, 0)).thenReturn(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 12));

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2).setFont(any());
        verify(g2).setPaint(any());
    }

    @Test
    public void testDrawItem_ItemLabelVisibleTrue_WithFallbackPosition() {
        ItemLabelPosition fallback = mock(ItemLabelPosition.class);
        renderer.setPositiveItemLabelPositionFallback(fallback);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(1.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 1.5));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(renderer.getItemLabelGenerator(0, 0)).thenReturn(labelGenerator);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(labelGenerator.generateLabel(dataset, 0, 0)).thenReturn("Label");
        when(renderer.getItemLabelPaint(0, 0)).thenReturn(java.awt.Color.BLACK);
        when(renderer.getItemLabelFont(0, 0)).thenReturn(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 12));

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(fallback).getItemLabelAnchor();
    }

    @Test
    public void testDrawItem_InvertedAxis() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 10.0));
        when(rangeAxis.isInverted()).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getElementHinting()).thenReturn(false);
        when(plot.indexOf(dataset)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).fill(barCaptor.capture());
    }

    @Test
    public void testDrawItem_MinimumBarLength() {
        renderer.setMinimumBarLength(10.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(1.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 10.0));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getElementHinting()).thenReturn(false);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(1.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).fill(barCaptor.capture());
    }

    @Test
    public void testDrawItem_AddEntity() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getElementHinting()).thenReturn(true);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_ShadowsDisabled() {
        renderer.setShadowsVisible(false);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 10.0));
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(state.getBarWidth()).thenReturn(10.0);
        when(state.getElementHinting()).thenReturn(false);
        when(plot.indexOf(dataset)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, never()).setPaint(eq(renderer.getShadowPaint()));
    }

    @Test
    public void testDrawItem_NullEntities() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getElementHinting()).thenReturn(true);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Should not throw and not interact with entities
    }

    @Test
    public void testDrawItem_ZeroBarLength() {
        renderer.setMinimumBarLength(0.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(0.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(-10.0, 10.0));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getElementHinting()).thenReturn(false);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(5.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).fill(barCaptor.capture());
    }

    @Test
    public void testDrawItem_FullyVisibleBar() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 10.0));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getBarWidth()).thenReturn(8.0);
        when(state.getElementHinting()).thenReturn(false);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(5.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).fill(barCaptor.capture());
    }
}