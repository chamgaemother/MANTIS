import org.apache.commons.math3.geometry.euclidean.threed.FieldVector3D;
import org.apache.commons.math3.geometry.euclidean.threed.FieldRotation;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.exception.CardanEulerSingularityException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.util.Decimal64;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FieldRotationTest {

    @Test
    void testGetAngles_XYZ_VectorOperator_NoSingularity() {
        Decimal64 angle1 = new Decimal64(Math.toRadians(90));
        FieldVector3D<Decimal64> axis1 = new FieldVector3D<>(Decimal64.ONE, 0, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis1, angle1, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_XYZ_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_XZY_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(90));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.XZY, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_XZY_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XZY, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_YXZ_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(45));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.YXZ, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_YXZ_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YXZ, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_YZX_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(60));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.YZX, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_YZX_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YZX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_ZXY_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(30));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 1, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.ZXY, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_ZXY_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 1, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZXY, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_ZYX_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(75));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0.5);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_ZYX_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0.5);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_XYX_VectorOperator_NoSingularity() {
        Decimal64 angle1 = new Decimal64(Math.toRadians(45));
        FieldVector3D<Decimal64> axis1 = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis1, angle1, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.XYX, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_XYX_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_XZX_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(60));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0.5, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.XZX, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_XZX_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0.5, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XZX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_YXY_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(30));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.YXY, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_YXY_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YXY, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_YZY_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(90));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.YZY, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_YZY_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YZY, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_ZXZ_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(45));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.ZXZ, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_ZXZ_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZXZ, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_ZYZ_VectorOperator_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(30));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        Decimal64[] angles = rotation.getAngles(RotationOrder.ZYZ, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_ZYZ_VectorOperator_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZYZ, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_XYZ_FrameTransform_NoSingularity() {
        Decimal64 angle1 = new Decimal64(Math.toRadians(90));
        FieldVector3D<Decimal64> axis1 = new FieldVector3D<>(Decimal64.ONE, 0, 0, 1);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis1, angle1, RotationConvention.FRAME_TRANSFORM);

        Decimal64[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_XYZ_FrameTransform_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    void testGetAngles_XZY_FrameTransform_NoSingularity() {
        Decimal64 angle = new Decimal64(Math.toRadians(90));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);

        Decimal64[] angles = rotation.getAngles(RotationOrder.XZY, RotationConvention.FRAME_TRANSFORM);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAngles_XZY_FrameTransform_Singularity() {
        Decimal64 angle = new Decimal64(Math.PI);
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 0, 1, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.FRAME_TRANSFORM);

        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XZY, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    void testGetAngles_nullOrder() {
        Decimal64 angle = new Decimal64(Math.toRadians(45));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(NullArgumentException.class, () -> {
            rotation.getAngles(null, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    void testGetAngles_nullConvention() {
        Decimal64 angle = new Decimal64(Math.toRadians(45));
        FieldVector3D<Decimal64> axis = new FieldVector3D<>(Decimal64.ONE, 1, 0, 0);
        FieldRotation<Decimal64> rotation = new FieldRotation<>(axis, angle, RotationConvention.VECTOR_OPERATOR);

        assertThrows(NullArgumentException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, null);
        });
    }
}