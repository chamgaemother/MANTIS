package org.apache.commons.jxpath.ri.model.dom;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.apache.commons.jxpath.ri.model.NodePointer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

public class DOMNodePointer_setValue_0_3_Test {

    @Test
    @DisplayName("setValue with non-text node removes all existing children")
    void TC11() throws Exception {
        // GIVEN
        Node node = mock(Node.class);
        NodeList children = mock(NodeList.class);
        when(node.getNodeType()).thenReturn((short) 5); // Assuming node type 5 is not TEXT_NODE or CDATA_SECTION_NODE
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(3);
        Node child1 = mock(Node.class);
        Node child2 = mock(Node.class);
        Node child3 = mock(Node.class);
        when(children.item(0)).thenReturn(child1);
        when(children.item(1)).thenReturn(child2);
        when(children.item(2)).thenReturn(child3);
        String value = "New Value";
        // Mock TypeUtils.convert - Assume it returns the value directly
        Document ownerDocument = mock(Document.class);
        when(node.getOwnerDocument()).thenReturn(ownerDocument);
        Text newText = mock(Text.class);
        when(ownerDocument.createTextNode("New Value")).thenReturn(newText);

        // Instantiate DOMNodePointer and set the private 'node' field via reflection
        NodePointer parentPointer = mock(NodePointer.class); // Added because of DOMNodePointer constructor
        DOMNodePointer domNodePointer = new DOMNodePointer(parentPointer, node);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        verify(node).removeChild(child3);
        verify(node).removeChild(child2);
        verify(node).removeChild(child1);
        verify(node).appendChild(newText);
    }

    @Test
    @DisplayName("setValue with non-text node and value as Element node with no children")
    void TC12() throws Exception {
        // GIVEN
        Node node = mock(Node.class);
        NodeList children = mock(NodeList.class);
        when(node.getNodeType()).thenReturn((short) 5);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(0);
        Element valueElement = mock(Element.class);
        NodeList valueChildren = mock(NodeList.class);
        when(valueElement.getChildNodes()).thenReturn(valueChildren);
        when(valueChildren.getLength()).thenReturn(0);
        Object value = valueElement;

        // Instantiate DOMNodePointer and set the private 'node' field via reflection
        NodePointer parentPointer = mock(NodePointer.class); // Added because of DOMNodePointer constructor
        DOMNodePointer domNodePointer = new DOMNodePointer(parentPointer, node);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        // No appendChild calls should occur
        verify(node, never()).appendChild(any());
    }

    @Test
    @DisplayName("setValue with non-text node and value as null does not append")
    void TC13() throws Exception {
        // GIVEN
        Node node = mock(Node.class);
        NodeList children = mock(NodeList.class);
        when(node.getNodeType()).thenReturn((short) 5);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(0);
        String value = null;

        // Instantiate DOMNodePointer and set the private 'node' field via reflection
        NodePointer parentPointer = mock(NodePointer.class); // Added because of DOMNodePointer constructor
        DOMNodePointer domNodePointer = new DOMNodePointer(parentPointer, node);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        // No append operation should occur
        verify(node, never()).appendChild(any());
    }

    @Test
    @DisplayName("setValue with loop removing children iterates multiple times")
    void TC14() throws Exception {
        // GIVEN
        Node node = mock(Node.class);
        NodeList children = mock(NodeList.class);
        when(node.getNodeType()).thenReturn((short) 5);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(4);
        Node child1 = mock(Node.class);
        Node child2 = mock(Node.class);
        Node child3 = mock(Node.class);
        Node child4 = mock(Node.class);
        when(children.item(3)).thenReturn(child4);
        when(children.item(2)).thenReturn(child3);
        when(children.item(1)).thenReturn(child2);
        when(children.item(0)).thenReturn(child1);
        String value = "New Value";
        // Mock TypeUtils.convert
        Document ownerDocument = mock(Document.class);
        when(node.getOwnerDocument()).thenReturn(ownerDocument);
        Text newText = mock(Text.class);
        when(ownerDocument.createTextNode("New Value")).thenReturn(newText);

        // Instantiate DOMNodePointer and set the private 'node' field via reflection
        NodePointer parentPointer = mock(NodePointer.class); // Added because of DOMNodePointer constructor
        DOMNodePointer domNodePointer = new DOMNodePointer(parentPointer, node);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        verify(node).removeChild(child4);
        verify(node).removeChild(child3);
        verify(node).removeChild(child2);
        verify(node).removeChild(child1);
        verify(node).appendChild(newText);
    }

    @Test
    @DisplayName("setValue with loop removing children iterates zero times")
    void TC15() throws Exception {
        // GIVEN
        Node node = mock(Node.class);
        NodeList children = mock(NodeList.class);
        when(node.getNodeType()).thenReturn((short) 5);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(0);
        String value = "New Value";
        // Mock TypeUtils.convert
        Document ownerDocument = mock(Document.class);
        when(node.getOwnerDocument()).thenReturn(ownerDocument);
        Text newText = mock(Text.class);
        when(ownerDocument.createTextNode("New Value")).thenReturn(newText);

        // Instantiate DOMNodePointer and set the private 'node' field via reflection
        NodePointer parentPointer = mock(NodePointer.class); // Added because of DOMNodePointer constructor
        DOMNodePointer domNodePointer = new DOMNodePointer(parentPointer, node);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        // No removeChild calls should occur
        verify(node, never()).removeChild(any());
        verify(node).appendChild(newText);
    }
}