package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.AreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.ui.RectangleEdge;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AreaRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem processes with HORIZONTAL orientation")
    void TC11_drawItem_with_HORIZONTAL_orientation() {
        // Arrange
        AreaRenderer renderer = spy(new AreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entityCollection = mock(EntityCollection.class);

        int row = 0;
        int column = 1;

        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(10);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entityCollection);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(GeneralPath.class));
        verify(renderer).drawItemLabel(
                any(Graphics2D.class), eq(PlotOrientation.HORIZONTAL), eq(dataset), eq(row), eq(column), anyDouble(), anyDouble(), anyBoolean()
        );
    }

    @Test
    @DisplayName("drawItem does not draw item label when it is not visible")
    void TC12_drawItem_without_item_label_visibility() {
        // Arrange
        AreaRenderer renderer = spy(new AreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entityCollection = mock(EntityCollection.class);

        int row = 0;
        int column = 1;

        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(20);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entityCollection);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(GeneralPath.class));
        verify(renderer, never()).drawItemLabel(any(Graphics2D.class), any(PlotOrientation.class), any(CategoryDataset.class), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("drawItem draws item label when item label is visible")
    void TC13_drawItem_with_item_label_visible() {
        // Arrange
        AreaRenderer renderer = spy(new AreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entityCollection = mock(EntityCollection.class);

        int row = 0;
        int column = 1;

        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(30);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entityCollection);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(GeneralPath.class));
        verify(renderer).drawItemLabel(
                any(Graphics2D.class), any(PlotOrientation.class), eq(dataset), eq(row), eq(column), anyDouble(), anyDouble(), anyBoolean()
        );
    }

//     @Test
//     @DisplayName("drawItem updates crosshair values correctly")
//     void TC14_drawItem_updates_crosshair_correctly() {
        // Arrange
//         AreaRenderer renderer = spy(new AreaRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
// 
//         int row = 0;
//         int column = 1;
// 
//         when(renderer.getItemVisible(row, column)).thenReturn(true);
//         when(dataset.getValue(row, column)).thenReturn(40);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.indexOf(dataset)).thenReturn(0);
//         when(state.getCrosshairState()).thenReturn(mock(org.jfree.chart.plot.CrosshairState.class));
//         when(state.getEntityCollection()).thenReturn(entityCollection);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// 
        // Assert
//         verify(renderer).updateCrosshairValues(any(), any(), any(), anyDouble(), anyInt(), anyDouble(), anyDouble(), any(PlotOrientation.class));
//     }

    @Test
    @DisplayName("drawItem adds item entity when entity collection is available")
    void TC15_drawItem_adds_item_entity() {
        // Arrange
        AreaRenderer renderer = spy(new AreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entityCollection = mock(EntityCollection.class);

        int row = 0;
        int column = 1;

        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(50);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entityCollection);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // Assert
        verify(renderer).addItemEntity(eq(entityCollection), eq(dataset), eq(row), eq(column), any(GeneralPath.class));
    }
}