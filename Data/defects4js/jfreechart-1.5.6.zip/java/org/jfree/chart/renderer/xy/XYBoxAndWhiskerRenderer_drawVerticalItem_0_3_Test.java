package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.ArgumentMatcher;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_0_3_Test {

    private static ArgumentMatcher<Object> instanceOf(final Class<?> clazz) {
        return arg -> clazz.isInstance(arg);
    }

    @Test
    @DisplayName("drawVerticalItem where yQ1Median > yQ3Median")
    public void TC11_drawVerticalItem_yQ1MedianGreaterThanYQ3Median() {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 10, 10);
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;

        // Mock dataset behavior
        when(boxDataset.getX(series, item)).thenReturn(5.0);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(2.0);
        when(boxDataset.getMedianValue(series, item)).thenReturn(4.0);
        when(boxDataset.getMeanValue(series, item)).thenReturn(3.0);
        when(boxDataset.getQ1Value(series, item)).thenReturn(10.0);
        when(boxDataset.getQ3Value(series, item)).thenReturn(5.0);
        when(boxDataset.getOutliers(series, item)).thenReturn(new ArrayList<>());

        // WHEN
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);

        // THEN
        verify(g2, atLeastOnce()).draw(any(Line2D.Double.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.Double.class));
    }

    @Test
    @DisplayName("drawVerticalItem where yQ1Median <= yQ3Median")
    public void TC12_drawVerticalItem_yQ1MedianLessThanOrEqualToYQ3Median() {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 10, 10);
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;

        // Mock dataset behavior
        when(boxDataset.getX(series, item)).thenReturn(5.0);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(2.0);
        when(boxDataset.getMedianValue(series, item)).thenReturn(4.0);
        when(boxDataset.getMeanValue(series, item)).thenReturn(3.0);
        when(boxDataset.getQ1Value(series, item)).thenReturn(5.0);
        when(boxDataset.getQ3Value(series, item)).thenReturn(10.0);
        when(boxDataset.getOutliers(series, item)).thenReturn(new ArrayList<>());

        // WHEN
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);

        // THEN
        verify(g2, atLeastOnce()).draw(any(Line2D.Double.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.Double.class));
    }

//     @Test
//     @DisplayName("drawVerticalItem with no outliers in yOutliers")
//     public void TC13_drawVerticalItem_noOutliers() {
        // GIVEN
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 10, 10);
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
// 
        // Mock dataset behavior
//         when(boxDataset.getX(series, item)).thenReturn(5.0);
//         when(boxDataset.getMaxRegularValue(series, item)).thenReturn(10.0);
//         when(boxDataset.getMinRegularValue(series, item)).thenReturn(2.0);
//         when(boxDataset.getMedianValue(series, item)).thenReturn(4.0);
//         when(boxDataset.getMeanValue(series, item)).thenReturn(3.0);
//         when(boxDataset.getQ1Value(series, item)).thenReturn(5.0);
//         when(boxDataset.getQ3Value(series, item)).thenReturn(10.0);
//         when(boxDataset.getOutliers(series, item)).thenReturn(new ArrayList<>());
// 
        // WHEN
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
// 
        // THEN
        // Verify that no outliers are drawn
//         verify(g2, times(0)).draw(argThat(instanceOf(Ellipse2D.Double.class)));
//     }

//     @Test
//     @DisplayName("drawVerticalItem with a single outlier in yOutliers")
//     public void TC14_drawVerticalItem_singleOutlier() {
        // GIVEN
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 10, 10);
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
// 
        // Mock dataset behavior
//         when(boxDataset.getX(series, item)).thenReturn(5.0);
//         when(boxDataset.getMaxRegularValue(series, item)).thenReturn(10.0);
//         when(boxDataset.getMinRegularValue(series, item)).thenReturn(2.0);
//         when(boxDataset.getMedianValue(series, item)).thenReturn(4.0);
//         when(boxDataset.getMeanValue(series, item)).thenReturn(3.0);
//         when(boxDataset.getQ1Value(series, item)).thenReturn(5.0);
//         when(boxDataset.getQ3Value(series, item)).thenReturn(10.0);
//         when(boxDataset.getOutliers(series, item)).thenReturn(Arrays.asList(15.0));
// 
        // WHEN
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
// 
        // THEN
        // Verify that one outlier is drawn
//         verify(g2, times(1)).draw(argThat(instanceOf(Ellipse2D.Double.class)));
//     }

//     @Test
//     @DisplayName("drawVerticalItem with multiple outliers in yOutliers")
//     public void TC15_drawVerticalItem_multipleOutliers() {
        // GIVEN
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 10, 10);
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
// 
        // Mock dataset behavior
//         when(boxDataset.getX(series, item)).thenReturn(5.0);
//         when(boxDataset.getMaxRegularValue(series, item)).thenReturn(10.0);
//         when(boxDataset.getMinRegularValue(series, item)).thenReturn(2.0);
//         when(boxDataset.getMedianValue(series, item)).thenReturn(4.0);
//         when(boxDataset.getMeanValue(series, item)).thenReturn(3.0);
//         when(boxDataset.getQ1Value(series, item)).thenReturn(5.0);
//         when(boxDataset.getQ3Value(series, item)).thenReturn(10.0);
//         when(boxDataset.getOutliers(series, item)).thenReturn(Arrays.asList(15.0, 20.0, 25.0));
// 
        // WHEN
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
// 
        // THEN
        // Verify that multiple outliers are drawn
//         verify(g2, times(3)).draw(argThat(instanceOf(Ellipse2D.Double.class)));
//     }
}