package com.fasterxml.jackson.core.io;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.io.UTF32Reader;
import java.lang.reflect.Field;
import java.io.CharConversionException;

public class UTF32Reader_read_0_1_Test {

    @Test
    @DisplayName("read method with _buffer as null should return -1")
    public void testTC01() throws Exception {
        // Arrange
        UTF32Reader reader = new UTF32Reader(null, null, null, 0, 0, true);
        Field bufferField = UTF32Reader.class.getDeclaredField("_buffer");
        bufferField.setAccessible(true);
        bufferField.set(reader, null);
        char[] cbuf = new char[10];
        int start = 0;
        int len = 5;

        // Act
        int result = reader.read(cbuf, start, len);

        // Assert
        assertEquals(-1, result);
    }

    @Test
    @DisplayName("read method with len less than 1 should return len")
    public void testTC02() throws Exception {
        // Arrange
        byte[] buffer = new byte[8];
        UTF32Reader reader = new UTF32Reader(null, null, buffer, 0, buffer.length, true);
        Field bufferField = UTF32Reader.class.getDeclaredField("_buffer");
        bufferField.setAccessible(true);
        bufferField.set(reader, buffer);
        char[] cbuf = new char[10];
        int start = 5;
        int len = 0;

        // Act
        int result = reader.read(cbuf, start, len);

        // Assert
        assertEquals(len, result);
    }

    @Test
    @DisplayName("read method with negative start throws ArrayIndexOutOfBoundsException")
    public void testTC03() throws Exception {
        // Arrange
        byte[] buffer = new byte[8];
        UTF32Reader reader = new UTF32Reader(null, null, buffer, 0, buffer.length, true);
        Field bufferField = UTF32Reader.class.getDeclaredField("_buffer");
        bufferField.setAccessible(true);
        bufferField.set(reader, buffer);
        char[] cbuf = new char[10];
        int start = -1;
        int len = 5;

        // Act & Assert
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            reader.read(cbuf, start, len);
        });
    }

    @Test
    @DisplayName("read method with start + len > cbuf.length throws ArrayIndexOutOfBoundsException")
    public void testTC04() throws Exception {
        // Arrange
        byte[] buffer = new byte[8];
        UTF32Reader reader = new UTF32Reader(null, null, buffer, 0, buffer.length, true);
        Field bufferField = UTF32Reader.class.getDeclaredField("_buffer");
        bufferField.setAccessible(true);
        bufferField.set(reader, buffer);
        char[] cbuf = new char[10];
        int start = 8;
        int len = 5;

        // Act & Assert
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            reader.read(cbuf, start, len);
        });
    }

    @Test
    @DisplayName("read method with existing surrogate sets surrogate and returns 1")
    public void testTC05() throws Exception {
        // Arrange
        byte[] buffer = new byte[8];
        UTF32Reader reader = new UTF32Reader(null, null, buffer, 0, buffer.length, true);
        Field bufferField = UTF32Reader.class.getDeclaredField("_buffer");
        bufferField.setAccessible(true);
        bufferField.set(reader, buffer);

        Field surrogateField = UTF32Reader.class.getDeclaredField("_surrogate");
        surrogateField.setAccessible(true);
        surrogateField.set(reader, '\uD800');

        char[] cbuf = new char[10];
        int start = 2;
        int len = 3;

        // Act
        int result = reader.read(cbuf, start, len);

        // Assert
        assertEquals('\uD800', cbuf[start]);
        assertEquals(UTF32Reader.NC, surrogateField.get(reader));
        assertEquals(1, result);
    }
}