package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ClassUtilsTest {

    @Test
    @DisplayName("isAssignable: toClass is null should return false")
    void testIsAssignable_ToClassNull() {
        assertFalse(ClassUtils.isAssignable(String.class, null, true));
    }

    @Test
    @DisplayName("isAssignable: cls is null and toClass is primitive should return false")
    void testIsAssignable_ClsNull_ToClassPrimitive() {
        assertFalse(ClassUtils.isAssignable(null, int.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is null and toClass is non-primitive should return true")
    void testIsAssignable_ClsNull_ToClassNonPrimitive() {
        assertTrue(ClassUtils.isAssignable(null, String.class, true));
    }

    @Test
    @DisplayName("isAssignable: autoboxing true, cls primitive toClass wrapper should return true")
    void testIsAssignable_AutoboxingTrue_PrimitiveToWrapper() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class, true));
    }

    @Test
    @DisplayName("isAssignable: autoboxing true, cls primitive toClass wrapper null conversion should return false")
    void testIsAssignable_AutoboxingTrue_PrimitiveToWrapperNull() {
        assertFalse(ClassUtils.isAssignable(void.class, Void.class, true));
    }

    @Test
    @DisplayName("isAssignable: autoboxing true, cls wrapper toClass primitive should return true")
    void testIsAssignable_AutoboxingTrue_WrapperToPrimitive() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
    }

    @Test
    @DisplayName("isAssignable: autoboxing true, cls wrapper toClass primitive null conversion should return false")
    void testIsAssignable_AutoboxingTrue_WrapperToPrimitiveNull() {
        assertFalse(ClassUtils.isAssignable(Void.class, void.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls equals toClass should return true")
    void testIsAssignable_ClsEqualsToClass() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is primitive and toClass is not primitive should return false")
    void testIsAssignable_PrimitiveToNonPrimitive() {
        assertFalse(ClassUtils.isAssignable(int.class, String.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Integer primitive and toClass is Long primitive should return true")
    void testIsAssignable_IntegerToLong() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Integer primitive and toClass is Float primitive should return true")
    void testIsAssignable_IntegerToFloat() {
        assertTrue(ClassUtils.isAssignable(int.class, float.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Integer primitive and toClass is Double primitive should return true")
    void testIsAssignable_IntegerToDouble() {
        assertTrue(ClassUtils.isAssignable(int.class, double.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Long primitive and toClass is Float primitive should return true")
    void testIsAssignable_LongToFloat() {
        assertTrue(ClassUtils.isAssignable(long.class, float.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Long primitive and toClass is Double primitive should return true")
    void testIsAssignable_LongToDouble() {
        assertTrue(ClassUtils.isAssignable(long.class, double.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Boolean primitive should return false for any toClass")
    void testIsAssignable_BooleanToAny() {
        assertFalse(ClassUtils.isAssignable(boolean.class, boolean.class, false));
        assertFalse(ClassUtils.isAssignable(boolean.class, Object.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Double primitive should return false for any toClass")
    void testIsAssignable_DoubleToAny() {
        assertFalse(ClassUtils.isAssignable(double.class, double.class, false));
        assertFalse(ClassUtils.isAssignable(double.class, Object.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Float primitive and toClass is Double primitive should return true")
    void testIsAssignable_FloatToDouble() {
        assertTrue(ClassUtils.isAssignable(float.class, double.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Character primitive and toClass is Integer primitive should return true")
    void testIsAssignable_CharacterToInteger() {
        assertTrue(ClassUtils.isAssignable(char.class, int.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Short primitive and toClass is Integer primitive should return true")
    void testIsAssignable_ShortToInteger() {
        assertTrue(ClassUtils.isAssignable(short.class, int.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Short primitive and toClass is Long primitive should return true")
    void testIsAssignable_ShortToLong() {
        assertTrue(ClassUtils.isAssignable(short.class, long.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Short primitive and toClass is Float primitive should return true")
    void testIsAssignable_ShortToFloat() {
        assertTrue(ClassUtils.isAssignable(short.class, float.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Short primitive and toClass is Double primitive should return true")
    void testIsAssignable_ShortToDouble() {
        assertTrue(ClassUtils.isAssignable(short.class, double.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Byte primitive and toClass is Short primitive should return true")
    void testIsAssignable_ByteToShort() {
        assertTrue(ClassUtils.isAssignable(byte.class, short.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Byte primitive and toClass is Integer primitive should return true")
    void testIsAssignable_ByteToInteger() {
        assertTrue(ClassUtils.isAssignable(byte.class, int.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Byte primitive and toClass is Long primitive should return true")
    void testIsAssignable_ByteToLong() {
        assertTrue(ClassUtils.isAssignable(byte.class, long.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Byte primitive and toClass is Float primitive should return true")
    void testIsAssignable_ByteToFloat() {
        assertTrue(ClassUtils.isAssignable(byte.class, float.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls is Byte primitive and toClass is Double primitive should return true")
    void testIsAssignable_ByteToDouble() {
        assertTrue(ClassUtils.isAssignable(byte.class, double.class, false));
    }

    @Test
    @DisplayName("isAssignable: non-primitive classes assignable should return true")
    void testIsAssignable_NonPrimitiveAssignable() {
        assertTrue(ClassUtils.isAssignable(ArrayList.class, List.class, true));
    }

    @Test
    @DisplayName("isAssignable: non-primitive classes not assignable should return false")
    void testIsAssignable_NonPrimitiveNotAssignable() {
        assertFalse(ClassUtils.isAssignable(String.class, Integer.class, true));
    }

    @Test
    @DisplayName("isAssignable: autoboxing false, cls primitive toClass wrapper should return false")
    void testIsAssignable_AutoboxingFalse_PrimitiveToWrapper() {
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    @DisplayName("isAssignable: autoboxing false, cls wrapper toClass primitive should return false")
    void testIsAssignable_AutoboxingFalse_WrapperToPrimitive() {
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
    }

    @Test
    @DisplayName("isAssignable: autoboxing false, non-primitive assignable with autoboxing off")
    void testIsAssignable_AutoboxingFalse_NonPrimitiveAssignable() {
        assertTrue(ClassUtils.isAssignable(ArrayList.class, List.class, false));
    }

    @Test
    @DisplayName("isAssignable: autoboxing false, non-primitive not assignable with autoboxing off")
    void testIsAssignable_AutoboxingFalse_NonPrimitiveNotAssignable() {
        assertFalse(ClassUtils.isAssignable(String.class, Integer.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls and toClass are both primitive and same")
    void testIsAssignable_PrimitiveSame() {
        assertTrue(ClassUtils.isAssignable(int.class, int.class, false));
    }

    @Test
    @DisplayName("isAssignable: cls and toClass are both wrapper and same")
    void testIsAssignable_WrapperSame() {
        assertTrue(ClassUtils.isAssignable(Integer.class, Integer.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is subclass of toClass")
    void testIsAssignable_SubclassAssignable() {
        assertTrue(ClassUtils.isAssignable(java.util.ArrayList.class, java.util.Collection.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is not subclass of toClass")
    void testIsAssignable_NotSubclassAssignable() {
        assertFalse(ClassUtils.isAssignable(java.util.HashMap.class, java.util.List.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is interface and toClass is Object")
    void testIsAssignable_InterfaceToObject() {
        assertTrue(ClassUtils.isAssignable(java.util.List.class, Object.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is Object and toClass is interface")
    void testIsAssignable_ObjectToInterface() {
        assertFalse(ClassUtils.isAssignable(Object.class, java.util.List.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is primitive and toClass is itself wrapper with autoboxing")
    void testIsAssignable_PrimitiveToWrapperSelfAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is wrapper and toClass is itself primitive with autoboxing")
    void testIsAssignable_WrapperToPrimitiveSelfAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is non-primitive and toClass is superclass")
    void testIsAssignable_NonPrimitiveToSuperclass() {
        assertTrue(ClassUtils.isAssignable(String.class, Object.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls implements interface and toClass is interface")
    void testIsAssignable_ClsImplementsInterface_ToClassInterface() {
        assertTrue(ClassUtils.isAssignable(java.util.ArrayList.class, java.util.List.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls does not implement interface and toClass is interface")
    void testIsAssignable_ClsDoesNotImplementInterface_ToClassInterface() {
        assertFalse(ClassUtils.isAssignable(String.class, java.util.List.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is array and toClass is Object")
    void testIsAssignable_ArrayToObject() {
        assertTrue(ClassUtils.isAssignable(String[].class, Object.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is array and toClass is Cloneable")
    void testIsAssignable_ArrayToCloneable() {
        assertTrue(ClassUtils.isAssignable(String[].class, Cloneable.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is array and toClass is Serializable")
    void testIsAssignable_ArrayToSerializable() {
        assertTrue(ClassUtils.isAssignable(String[].class, java.io.Serializable.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is array and toClass is array of its component")
    void testIsAssignable_ArrayToArrayOfComponent() {
        assertTrue(ClassUtils.isAssignable(String[].class, Object[].class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is array and toClass is array of superclass component")
    void testIsAssignable_ArrayToArrayOfSuperclassComponent() {
        assertTrue(ClassUtils.isAssignable(Integer[].class, Number[].class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is primitive array and toClass is Object")
    void testIsAssignable_PrimitiveArrayToObject() {
        assertTrue(ClassUtils.isAssignable(int[].class, Object.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is primitive array and toClass is Cloneable")
    void testIsAssignable_PrimitiveArrayToCloneable() {
        assertTrue(ClassUtils.isAssignable(int[].class, Cloneable.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is primitive array and toClass is Serializable")
    void testIsAssignable_PrimitiveArrayToSerializable() {
        assertTrue(ClassUtils.isAssignable(int[].class, java.io.Serializable.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is undefined wrapper and toClass is primitive")
    void testIsAssignable_UndefinedWrapperToPrimitive() {
        assertFalse(ClassUtils.isAssignable(Void.class, void.class, true));
    }

    @Test
    @DisplayName("isAssignable: cls is undefined primitive and toClass is wrapper")
    void testIsAssignable_UndefinedPrimitiveToWrapper() {
        assertFalse(ClassUtils.isAssignable(void.class, Void.class, true));
    }
}