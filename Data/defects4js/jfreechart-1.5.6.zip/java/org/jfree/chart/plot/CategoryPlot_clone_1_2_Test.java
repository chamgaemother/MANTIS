// package org.jfree.chart.plot;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// import org.jfree.data.category.DefaultCategoryDataset;
// import org.jfree.data.category.CategoryDataset;
// import org.jfree.chart.axis.AxisSpace;
// import org.jfree.chart.ui.RectangleInsets;
// 
// import org.jfree.chart.util.ObjectUtils;
// import org.jfree.chart.util.CloneUtils;
// import org.jfree.chart.util.RectangleInsets;
// import org.jfree.chart.util.AxisSpace;
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import static org.junit.jupiter.api.Assertions.*;
// 
// import java.lang.reflect.Field;
// import java.util.HashMap;
// import java.util.List;
// 
// public class CategoryPlot_clone_1_2_Test {
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with non-null fixedDomainAxisSpace")
//     public void TC06_cloneWithNonNullFixedDomainAxisSpace() throws Exception {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         AxisSpace fixedSpace = new AxisSpace();
//         fixedSpace.add(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
//         original.setFixedDomainAxisSpace(fixedSpace);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         Field fixedDomainAxisSpaceField = CategoryPlot.class.getDeclaredField("fixedDomainAxisSpace");
//         fixedDomainAxisSpaceField.setAccessible(true);
//         AxisSpace cloneFixedDomainAxisSpace = (AxisSpace) fixedDomainAxisSpaceField.get(clone);
//         AxisSpace originalFixedDomainAxisSpace = (AxisSpace) fixedDomainAxisSpaceField.get(original);
// 
//         assertNotNull(cloneFixedDomainAxisSpace, "Cloned fixedDomainAxisSpace should not be null");
//         assertNotSame(originalFixedDomainAxisSpace, cloneFixedDomainAxisSpace, "Cloned fixedDomainAxisSpace should be a different instance");
//         assertEquals(originalFixedDomainAxisSpace, cloneFixedDomainAxisSpace, "Cloned fixedDomainAxisSpace should be equal to original");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot when fixedRangeAxisSpace is null")
//     public void TC07_cloneWithNullFixedRangeAxisSpace() throws Exception {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         original.setFixedRangeAxisSpace(null);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         Field fixedRangeAxisSpaceField = CategoryPlot.class.getDeclaredField("fixedRangeAxisSpace");
//         fixedRangeAxisSpaceField.setAccessible(true);
//         AxisSpace cloneFixedRangeAxisSpace = (AxisSpace) fixedRangeAxisSpaceField.get(clone);
// 
//         assertNull(cloneFixedRangeAxisSpace, "Cloned fixedRangeAxisSpace should be null");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with non-null fixedRangeAxisSpace")
//     public void TC08_cloneWithNonNullFixedRangeAxisSpace() throws Exception {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         AxisSpace fixedSpace = new AxisSpace();
//         fixedSpace.add(new RectangleInsets(10.0, 10.0, 10.0, 10.0));
//         original.setFixedRangeAxisSpace(fixedSpace);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         Field fixedRangeAxisSpaceField = CategoryPlot.class.getDeclaredField("fixedRangeAxisSpace");
//         fixedRangeAxisSpaceField.setAccessible(true);
//         AxisSpace cloneFixedRangeAxisSpace = (AxisSpace) fixedRangeAxisSpaceField.get(clone);
//         AxisSpace originalFixedRangeAxisSpace = (AxisSpace) fixedRangeAxisSpaceField.get(original);
// 
//         assertNotNull(cloneFixedRangeAxisSpace, "Cloned fixedRangeAxisSpace should not be null");
//         assertNotSame(originalFixedRangeAxisSpace, cloneFixedRangeAxisSpace, "Cloned fixedRangeAxisSpace should be a different instance");
//         assertEquals(originalFixedRangeAxisSpace, cloneFixedRangeAxisSpace, "Cloned fixedRangeAxisSpace should be equal to original");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with empty datasets")
//     public void TC09_cloneWithEmptyDatasets() throws Exception {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         original.clearDomainAxes();
//         original.clearRangeAxes();
//         original.clearAnnotations();
//         // Ensure no datasets are present
//         while (original.getDatasetCount() > 0) {
//             original.setDataset(original.getDatasetCount() - 1, null);
//         }
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         Field datasetsField = CategoryPlot.class.getDeclaredField("datasets");
//         datasetsField.setAccessible(true);
//         HashMap<Integer, CategoryDataset> cloneDatasets = (HashMap<Integer, CategoryDataset>) datasetsField.get(clone);
// 
//         assertTrue(cloneDatasets.isEmpty(), "Cloned datasets should be empty");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with partially null datasets")
//     public void TC10_cloneWithPartiallyNullDatasets() throws Exception {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         CategoryDataset dataset1 = new DefaultCategoryDataset();
//         CategoryDataset dataset2 = null;
//         original.setDataset(0, dataset1);
//         original.setDataset(1, dataset2);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         Field datasetsField = CategoryPlot.class.getDeclaredField("datasets");
//         datasetsField.setAccessible(true);
//         HashMap<Integer, CategoryDataset> cloneDatasets = (HashMap<Integer, CategoryDataset>) datasetsField.get(clone);
// 
//         assertNotNull(cloneDatasets.get(0), "Cloned dataset at index 0 should not be null");
//         assertNull(cloneDatasets.get(1), "Cloned dataset at index 1 should be null");
//         assertNotSame(original.getDataset(0), clone.getDataset(0), "Cloned dataset1 should be a different instance");
//         assertEquals(original.getDataset(0), clone.getDataset(0), "Cloned dataset1 should be equal to original");
//     }
// }