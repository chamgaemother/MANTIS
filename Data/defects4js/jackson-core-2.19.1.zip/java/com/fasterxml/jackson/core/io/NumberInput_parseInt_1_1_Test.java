package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class NumberInput_parseInt_1_1_Test {

    @Test
    @DisplayName("parseInt with '+' sign and single digit results in correct parsing")
    public void TC18_parseInt_with_plus_sign_and_single_digit() {
        // GIVEN
        char[] input = new char[] {'+', '7'};
        int off = 0;
        int len = 2;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(7, result);
    }

    @Test
    @DisplayName("parseInt with '+' sign and multiple digits parses correctly")
    public void TC19_parseInt_with_plus_sign_and_multiple_digits() {
        // GIVEN
        char[] input = new char[] {'+', '1', '2', '3', '4', '5'};
        int off = 0;
        int len = 6;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(12345, result);
    }

    @Test
    @DisplayName("parseInt with '+' sign and zero digits throws exception")
    public void TC20_parseInt_with_plus_sign_and_no_digits() {
        // GIVEN
        char[] input = new char[] {'+'};
        int off = 0;
        int len = 1;

        // WHEN & THEN
        assertThrows(NumberFormatException.class, () -> {
            NumberInput.parseInt(input, off, len);
        });
    }

    @Test
    @DisplayName("parseInt with two digits without sign")
    public void TC21_parseInt_with_two_digits_without_sign() {
        // GIVEN
        char[] input = new char[] {'4', '2'};
        int off = 0;
        int len = 2;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(42, result);
    }

    @Test
    @DisplayName("parseInt with three digits without sign")
    public void TC22_parseInt_with_three_digits_without_sign() {
        // GIVEN
        char[] input = new char[] {'1', '2', '3'};
        int off = 0;
        int len = 3;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(123, result);
    }
}