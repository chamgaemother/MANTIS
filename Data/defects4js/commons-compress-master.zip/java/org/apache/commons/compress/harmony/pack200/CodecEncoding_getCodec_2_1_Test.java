package org.apache.commons.compress.harmony.pack200;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.compress.harmony.pack200.CodecEncoding;
import org.apache.commons.compress.harmony.pack200.Codec;
import org.apache.commons.compress.harmony.pack200.BHSDCodec;
import org.apache.commons.compress.harmony.pack200.RunCodec;
import org.apache.commons.compress.harmony.pack200.PopulationCodec;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;

public class CodecEncoding_getCodec_2_1_Test {

    @Test
    @DisplayName("Throws Pack200Exception when value is 150 with tdef=true, fdef=false, udef=false")
    void TC33_ShouldThrowPack200Exception_WhenValueIs150_WithTdefTrueAdefFalseUdefFalse() {
        // GIVEN
        int value = 150;
        byte[] inputData = {0x00, 0x00}; // Data to set tdef=true, adef=false, udef=false
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = CodecEncoding.getCanonicalCodec(1); // Assuming codec at index 1 as default

        // WHEN & THEN
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, inputStream, defaultCodec);
        });
        assertEquals("ADef and BDef should never both be true", exception.getMessage());
    }

    @Test
    @DisplayName("Returns PopulationCodec with tdef=false, fdef=true, udef=true")
    void TC34_ShouldReturnPopulationCodec_WithTdefFalseFdefTrueUdefTrue() throws IOException, Pack200Exception {
        // GIVEN
        int value = 160;
        byte[] inputData = {0x01, 0x02, 0x03}; // Data to set fdef=true, udef=true
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = CodecEncoding.getCanonicalCodec(1); // Assuming codec at index 1 as default

        // WHEN
        Codec result = CodecEncoding.getCodec(value, inputStream, defaultCodec);

        // THEN
        assertTrue(result instanceof PopulationCodec, "Result should be an instance of PopulationCodec");
        PopulationCodec populationCodec = (PopulationCodec) result;
        assertEquals(defaultCodec, populationCodec.getFavouredCodec(), "fCodec should be defaultCodec");
        assertEquals(defaultCodec, populationCodec.getUnfavouredCodec(), "uCodec should be defaultCodec");
    }

    @Test
    @DisplayName("Returns PopulationCodec with tdef=true and l=4")
    void TC35_ShouldReturnPopulationCodec_WithTdefTrueAndL4() throws IOException, Pack200Exception {
        // GIVEN
        int value = 160;
        byte[] inputData = {0x01, 0x02, 0x03, 0x04}; // Data to set l=4
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = CodecEncoding.getCanonicalCodec(1); // Assuming codec at index 1 as default

        // WHEN
        Codec result = CodecEncoding.getCodec(value, inputStream, defaultCodec);

        // THEN
        assertTrue(result instanceof PopulationCodec, "Result should be an instance of PopulationCodec");
        PopulationCodec populationCodec = (PopulationCodec) result;
        // Assuming there is a method getL() to retrieve the 'l' value
        // Since 'l' is not directly accessible, reflection can be used if necessary
        // For simplicity, assuming a getter exists
        // If not, this part needs to be adjusted based on actual implementation
        // int l = populationCodec.getL();
        // assertEquals(4, l, "PopulationCodec 'l' should be 4");
        // Since getL() is not defined, we'll skip checking 'l' directly
        // Instead, verify that the PopulationCodec was constructed with correct parameters
        assertEquals(defaultCodec, populationCodec.getFavouredCodec(), "fCodec should be defaultCodec");
        assertEquals(defaultCodec, populationCodec.getUnfavouredCodec(), "uCodec should be defaultCodec");
    }

    @Test
    @DisplayName("Returns PopulationCodec with tdef=false, fdef=false, udef=true")
    void TC36_ShouldReturnPopulationCodec_WithTdefFalseFdefFalseUdefTrue() throws IOException, Pack200Exception {
        // GIVEN
        int value = 170;
        byte[] inputData = {0x02, 0x03, 0x04}; // Data to set udef=true
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = CodecEncoding.getCanonicalCodec(1); // Assuming codec at index 1 as default

        // WHEN
        Codec result = CodecEncoding.getCodec(value, inputStream, defaultCodec);

        // THEN
        assertTrue(result instanceof PopulationCodec, "Result should be an instance of PopulationCodec");
        PopulationCodec populationCodec = (PopulationCodec) result;
        assertEquals(defaultCodec, populationCodec.getUnfavouredCodec(), "uCodec should be defaultCodec");
    }

    @Test
    @DisplayName("Throws Pack200Exception when value is 189, the upper boundary of invalid codec encoding bytes")
    void TC37_ShouldThrowPack200Exception_WhenValueIs189() {
        // GIVEN
        int value = 189;
        byte[] inputData = {0x00}; // Any InputStream data
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = CodecEncoding.getCanonicalCodec(1); // Assuming codec at index 1 as default

        // WHEN & THEN
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, inputStream, defaultCodec);
        });
        assertEquals("Invalid codec encoding byte (189) found", exception.getMessage());
    }
}