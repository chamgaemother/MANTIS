package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class StringUtils_indexOfDifference_0_3_Test {

    @Test
    @DisplayName("Strings differ after all characters of the shortest string")
    public void TC11() {
        CharSequence[] css = {"test", "test", "testing"};
        int result = StringUtils.indexOfDifference(css);
        assertEquals(-1, result, "Expected INDEX_NOT_FOUND (-1)");
    }

    @Test
    @DisplayName("Empty input array returns INDEX_NOT_FOUND")
    public void TC12() {
        CharSequence[] css = {};
        int result = StringUtils.indexOfDifference(css);
        assertEquals(-1, result, "Expected INDEX_NOT_FOUND (-1)");
    }

    @Test
    @DisplayName("First string is null with other non-null strings")
    public void TC13() {
        CharSequence[] css = {null, "test", "testing"};
        int result = StringUtils.indexOfDifference(css);
        assertEquals(0, result, "Expected first differing index is 0");
    }

    @Test
    @DisplayName("All strings empty with one string null returns 0")
    public void TC14() {
        CharSequence[] css = {"", "", null};
        int result = StringUtils.indexOfDifference(css);
        assertEquals(0, result, "Expected first differing index is 0");
    }

    @Test
    @DisplayName("Multiple differences at various positions")
    public void TC15() {
        CharSequence[] css = {"abcdefgh", "abcxefgh", "abcdefzh"};
        int result = StringUtils.indexOfDifference(css);
        assertEquals(3, result, "Expected first differing index is 3");
    }
}