package org.apache.commons.jxpath.ri.parser;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class TokenMgrError_addEscapes_0_2_Test {

    @Test
    @DisplayName("addEscapes with single tab character")
    void TC06_addEscapes_single_tab() {
        // GIVEN
        String input = "\t";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\t", result);
    }

    @Test
    @DisplayName("addEscapes with single newline character")
    void TC07_addEscapes_single_newline() {
        // GIVEN
        String input = "\n";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\n", result);
    }

    @Test
    @DisplayName("addEscapes with single form feed character")
    void TC08_addEscapes_single_formfeed() {
        // GIVEN
        String input = "\f";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\f", result);
    }

    @Test
    @DisplayName("addEscapes with single carriage return character")
    void TC09_addEscapes_single_carriagereturn() {
        // GIVEN
        String input = "\r";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\r", result);
    }

    @Test
    @DisplayName("addEscapes with single double quote character")
    void TC10_addEscapes_single_double_quote() {
        // GIVEN
        String input = "\"";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\\"", result);
    }

}