package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * JUnit 5 test class for XPathParser's AxisName method.
 */
public class XPathParser_AxisName_2_2_Test {

    @Test
    @DisplayName("TC22: AxisName throws ParseException when jj_nt.kind=AXIS_PARENT but token.kind=AXIS_SELF")
    void testTC22_AxisName_ThrowsParseException_jj_nt_AXIS_PARENT_token_AXIS_SELF() throws Exception {
        // Initialize parser with dummy input
        XPathParser parser = new XPathParser(new java.io.StringReader(""));


        // Set jj_nt.kind = AXIS_PARENT
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_PARENT;
        jj_ntField.set(parser, jj_nt);

        // Set token.kind = AXIS_SELF
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_SELF;
        tokenField.set(parser, token);

        // Expect ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("TC23: AxisName throws ParseException when jj_nt.kind=AXIS_ANCESTOR but token.kind=AXIS_CHILD")
    void testTC23_AxisName_ThrowsParseException_jj_nt_AXIS_ANCESTOR_token_AXIS_CHILD() throws Exception {
        // Initialize parser with dummy input
        XPathParser parser = new XPathParser(new java.io.StringReader(""));


        // Set jj_nt.kind = AXIS_ANCESTOR
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_ANCESTOR;
        jj_ntField.set(parser, jj_nt);

        // Set token.kind = AXIS_CHILD
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_CHILD;
        tokenField.set(parser, token);

        // Expect ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("TC24: AxisName throws ParseException when jj_nt.kind=AXIS_ANCESTOR but token.kind=AXIS_PRECEDING")
    void testTC24_AxisName_ThrowsParseException_jj_nt_AXIS_ANCESTOR_token_AXIS_PRECEDING() throws Exception {
        // Initialize parser with dummy input
        XPathParser parser = new XPathParser(new java.io.StringReader(""));


        // Set jj_nt.kind = AXIS_ANCESTOR
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_ANCESTOR;
        jj_ntField.set(parser, jj_nt);

        // Set token.kind = AXIS_PRECEDING
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_PRECEDING;
        tokenField.set(parser, token);

        // Expect ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("TC25: AxisName throws ParseException when jj_nt.kind=AXIS_ATTRIBUTE but token.kind=AXIS_CHILD")
    void testTC25_AxisName_ThrowsParseException_jj_nt_AXIS_ATTRIBUTE_token_AXIS_CHILD() throws Exception {
        // Initialize parser with dummy input
        XPathParser parser = new XPathParser(new java.io.StringReader(""));


        // Set jj_nt.kind = AXIS_ATTRIBUTE
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_ATTRIBUTE;
        jj_ntField.set(parser, jj_nt);

        // Set token.kind = AXIS_CHILD
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_CHILD;
        tokenField.set(parser, token);

        // Expect ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("TC26: AxisName throws ParseException when jj_nt.kind=AXIS_ATTRIBUTE but token.kind=AXIS_SELF")
    void testTC26_AxisName_ThrowsParseException_jj_nt_AXIS_ATTRIBUTE_token_AXIS_SELF() throws Exception {
        // Initialize parser with dummy input
        XPathParser parser = new XPathParser(new java.io.StringReader(""));


        // Set jj_nt.kind = AXIS_ATTRIBUTE
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_ATTRIBUTE;
        jj_ntField.set(parser, jj_nt);

        // Set token.kind = AXIS_SELF
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_SELF;
        tokenField.set(parser, token);

        // Expect ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }
}