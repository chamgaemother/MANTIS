package org.apache.commons.compress.archivers.zip;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.attribute.FileTime;
import java.util.Arrays;
import java.util.Date;

import org.junit.jupiter.api.Test;

public class ZipArchiveEntryTest {

    @Test
    public void testEquals_SameObject() {
        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
        assertTrue(entry.equals(entry));
    }

    @Test
    public void testEquals_NullObject() {
        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
        assertFalse(entry.equals(null));
    }

    @Test
    public void testEquals_DifferentClass() {
        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
        String notAnEntry = "Not a ZipArchiveEntry";
        assertFalse(entry.equals(notAnEntry));
    }

    @Test
    public void testEquals_DifferentName() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry1");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry2");
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_SameNameDifferentComments_BothNull() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry1.setComment(null);
        entry2.setComment(null);
        assertTrue(entry1.equals(entry2));
    }

    @Test
    public void testEquals_SameNameDifferentComments_OneNull() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry1.setComment(null);
        entry2.setComment("Comment");
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_SameNameDifferentComments_BothEmpty() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry1.setComment("");
        entry2.setComment("");
        assertTrue(entry1.equals(entry2));
    }

    @Test
    public void testEquals_SameNameDifferentComments_Different() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry1.setComment("Comment1");
        entry2.setComment("Comment2");
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_AllFieldsEqual() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        assertTrue(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentLastModifiedTime() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setLastModifiedTime(FileTime.fromMillis(entry1.getLastModifiedTime().toMillis() + 1000));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentLastAccessTime() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setLastAccessTime(FileTime.fromMillis(entry1.getLastAccessTime().toMillis() + 1000));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentCreationTime() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setCreationTime(FileTime.fromMillis(entry1.getCreationTime().toMillis() + 1000));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentInternalAttributes() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setInternalAttributes(entry1.getInternalAttributes() + 1);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentPlatform() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setPlatform(entry1.getPlatform() == ZipArchiveEntry.PLATFORM_FAT ? ZipArchiveEntry.PLATFORM_UNIX : ZipArchiveEntry.PLATFORM_FAT);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentExternalAttributes() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setExternalAttributes(entry1.getExternalAttributes() + 1);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentMethod() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setMethod(entry1.getMethod() == ZipMethod.STORED.getCode() ? ZipMethod.DEFLATED.getCode() : ZipMethod.STORED.getCode());
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentSize() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setSize(entry1.getSize() + 1);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentCrc() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setCrc(entry1.getCrc() + 1);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentCompressedSize() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setCompressedSize(entry1.getCompressedSize() + 1);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentCentralDirectoryExtra() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry1.setCentralDirectoryExtra(new byte[] {1, 2, 3});
        entry2.setCentralDirectoryExtra(new byte[] {4, 5, 6});
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentLocalFileDataExtra() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry1.setExtraFields(new ZipExtraField[] { new UnrecognizedExtraFieldData() });
        entry2.setExtraFields(new ZipExtraField[] { new X000A_NTFS() });
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentLocalHeaderOffset() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setLocalHeaderOffset(entry1.getLocalHeaderOffset() + 100);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentDataOffset() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        entry2.setDataOffset(entry1.getDataOffset() + 100);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    public void testEquals_DifferentGeneralPurposeBit() throws IOException {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        setCommonFields(entry1);
        setCommonFields(entry2);
        GeneralPurposeBit gpb1 = new GeneralPurposeBit();
        gpb1.setEncrypted(true);
        entry1.setGeneralPurposeBit(gpb1);
        GeneralPurposeBit gpb2 = new GeneralPurposeBit();
        gpb2.setEncrypted(false);
        entry2.setGeneralPurposeBit(gpb2);
        assertFalse(entry1.equals(entry2));
    }

    private void setCommonFields(ZipArchiveEntry entry) throws IOException {
        entry.setComment("Test Comment");
        entry.setInternalAttributes(123);
        entry.setPlatform(ZipArchiveEntry.PLATFORM_UNIX);
        entry.setExternalAttributes(456L);
        entry.setMethod(ZipMethod.DEFLATED.getCode());
        entry.setSize(789L);
        entry.setCrc(101112L);
        entry.setCompressedSize(131415L);
        entry.setCentralDirectoryExtra(new byte[] {1, 2, 3});
        entry.setExtraFields(new ZipExtraField[] { new X000A_NTFS() });
        entry.setLocalHeaderOffset(161718L);
        entry.setDataOffset(192021L);
        GeneralPurposeBit gpb = new GeneralPurposeBit();
        gpb.setEncrypted(false);
        entry.setGeneralPurposeBit(gpb);
        entry.setLastModifiedTime(FileTime.fromMillis(1000000L));
        entry.setLastAccessTime(FileTime.fromMillis(1000000L));
        entry.setCreationTime(FileTime.fromMillis(1000000L));
    }
}