package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.*;

import java.io.StringReader;

import org.apache.commons.jxpath.ri.compiler.ParseException;
import org.junit.jupiter.api.Test;

class XPathParserTest {

    @Test
    void testNCName_ValidNCName() throws ParseException {
        String input = "name123";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("name123", result);
    }

    @Test
    void testNCName_ValidOr() throws ParseException {
        String input = "or";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("or", result);
    }

    @Test
    void testNCName_ValidAnd() throws ParseException {
        String input = "and";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("and", result);
    }

    @Test
    void testNCName_ValidMod() throws ParseException {
        String input = "mod";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("mod", result);
    }

    @Test
    void testNCName_ValidDiv() throws ParseException {
        String input = "div";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("div", result);
    }

    @Test
    void testNCName_ValidNode() throws ParseException {
        String input = "node";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("node", result);
    }

    @Test
    void testNCName_ValidText() throws ParseException {
        String input = "text";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("text", result);
    }

    @Test
    void testNCName_ValidComment() throws ParseException {
        String input = "comment";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("comment", result);
    }

    @Test
    void testNCName_ValidPI() throws ParseException {
        String input = "processing-instruction";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("processing-instruction", result);
    }

    @Test
    void testNCName_ValidFunctionLast() throws ParseException {
        String input = "last";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("last", result);
    }

    @Test
    void testNCName_ValidFunctionPosition() throws ParseException {
        String input = "position";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("position", result);
    }

    @Test
    void testNCName_ValidFunctionCount() throws ParseException {
        String input = "count";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("count", result);
    }

    @Test
    void testNCName_ValidFunctionId() throws ParseException {
        String input = "id";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("id", result);
    }

    @Test
    void testNCName_ValidFunctionKey() throws ParseException {
        String input = "key";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("key", result);
    }

    @Test
    void testNCName_ValidFunctionLocalName() throws ParseException {
        String input = "local-name";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("local-name", result);
    }

    @Test
    void testNCName_ValidFunctionNamespaceURI() throws ParseException {
        String input = "namespace-uri";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("namespace-uri", result);
    }

    @Test
    void testNCName_ValidFunctionName() throws ParseException {
        String input = "name";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("name", result);
    }

    @Test
    void testNCName_ValidFunctionString() throws ParseException {
        String input = "string";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("string", result);
    }

    @Test
    void testNCName_ValidFunctionConcat() throws ParseException {
        String input = "concat";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("concat", result);
    }

    @Test
    void testNCName_ValidFunctionStartsWith() throws ParseException {
        String input = "starts-with";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("starts-with", result);
    }

    @Test
    void testNCName_ValidFunctionEndsWith() throws ParseException {
        String input = "ends-with";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("ends-with", result);
    }

    @Test
    void testNCName_ValidFunctionContains() throws ParseException {
        String input = "contains";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("contains", result);
    }

    @Test
    void testNCName_ValidFunctionSubstringBefore() throws ParseException {
        String input = "substring-before";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("substring-before", result);
    }

    @Test
    void testNCName_ValidFunctionSubstringAfter() throws ParseException {
        String input = "substring-after";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("substring-after", result);
    }

    @Test
    void testNCName_ValidFunctionSubstring() throws ParseException {
        String input = "substring";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("substring", result);
    }

    @Test
    void testNCName_ValidFunctionStringLength() throws ParseException {
        String input = "string-length";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("string-length", result);
    }

    @Test
    void testNCName_ValidFunctionNormalizeSpace() throws ParseException {
        String input = "normalize-space";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("normalize-space", result);
    }

    @Test
    void testNCName_ValidFunctionTranslate() throws ParseException {
        String input = "translate";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("translate", result);
    }

    @Test
    void testNCName_ValidFunctionBoolean() throws ParseException {
        String input = "boolean";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("boolean", result);
    }

    @Test
    void testNCName_ValidFunctionNot() throws ParseException {
        String input = "not";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("not", result);
    }

    @Test
    void testNCName_ValidFunctionTrue() throws ParseException {
        String input = "true";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("true", result);
    }

    @Test
    void testNCName_ValidFunctionFalse() throws ParseException {
        String input = "false";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("false", result);
    }

    @Test
    void testNCName_ValidFunctionNull() throws ParseException {
        String input = "null";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("null", result);
    }

    @Test
    void testNCName_ValidFunctionLang() throws ParseException {
        String input = "lang";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("lang", result);
    }

    @Test
    void testNCName_ValidFunctionNumber() throws ParseException {
        String input = "number";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("number", result);
    }

    @Test
    void testNCName_ValidFunctionSum() throws ParseException {
        String input = "sum";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("sum", result);
    }

    @Test
    void testNCName_ValidFunctionFloor() throws ParseException {
        String input = "floor";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("floor", result);
    }

    @Test
    void testNCName_ValidFunctionCeiling() throws ParseException {
        String input = "ceiling";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("ceiling", result);
    }

    @Test
    void testNCName_ValidFunctionRound() throws ParseException {
        String input = "round";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("round", result);
    }

    @Test
    void testNCName_ValidFunctionKey() throws ParseException {
        String input = "key";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("key", result);
    }

    @Test
    void testNCName_ValidFunctionFormatNumber() throws ParseException {
        String input = "format-number";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("format-number", result);
    }

    @Test
    void testNCName_InvalidInput() {
        String input = "@invalid";
        XPathParser parser = new XPathParser(new StringReader(input));
        assertThrows(ParseException.class, () -> parser.NCName());
    }

    @Test
    void testNCName_EmptyInput() {
        String input = "";
        XPathParser parser = new XPathParser(new StringReader(input));
        assertThrows(ParseException.class, () -> parser.NCName());
    }

    @Test
    void testNCName_InvalidToken() {
        String input = "#invalid";
        XPathParser parser = new XPathParser(new StringReader(input));
        assertThrows(ParseException.class, () -> parser.NCName());
    }

    @Test
    void testNCName_ValidNCNameWithUnderscore() throws ParseException {
        String input = "name_123";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("name_123", result);
    }

    @Test
    void testNCName_ValidNCNameWithHyphen() throws ParseException {
        String input = "name-123";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("name-123", result);
    }

    @Test
    void testNCName_InvalidStartingCharacter() {
        String input = "1name";
        XPathParser parser = new XPathParser(new StringReader(input));
        assertThrows(ParseException.class, () -> parser.NCName());
    }

    @Test
    void testNCName_ValidSingleCharacter() throws ParseException {
        String input = "a";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("a", result);
    }

    @Test
    void testNCName_ValidFunctionWithCapitalLetters() throws ParseException {
        String input = "Sum";
        XPathParser parser = new XPathParser(new StringReader(input));
        String result = parser.NCName();
        assertEquals("Sum", result);
    }
}