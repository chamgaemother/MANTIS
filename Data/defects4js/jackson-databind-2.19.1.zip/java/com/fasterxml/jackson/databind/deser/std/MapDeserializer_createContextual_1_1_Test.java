package com.fasterxml.jackson.databind.deser.std;

import java.lang.reflect.*;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.KeyDeserializer;
import com.fasterxml.jackson.databind.deser.ValueInstantiator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MapDeserializer_createContextual_1_1_Test {

    @Test
    @DisplayName("createContextual resolves _keyDeserializer when _keyDeserializer is initially null")
    public void TC11_createContextual_resolves_keyDeserializer_when_null() throws Exception {
        // Arrange
        JavaType mockJavaType = mock(JavaType.class); // Added mock for JavaType
        when(mockJavaType.getKeyType()).thenReturn(mock(JavaType.class)); // Ensure getKeyType() is mocked
        ValueInstantiator mockValueInstantiator = mock(ValueInstantiator.class); // Added mock for ValueInstantiator
        MapDeserializer deserializer = new MapDeserializer(mockJavaType, mockValueInstantiator, null, null, null);
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);
        KeyDeserializer resolvedKeyDeser = mock(KeyDeserializer.class);
        when(ctxt.findKeyDeserializer(any(), any())).thenReturn(resolvedKeyDeser);

        // Act
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        // Assert
        Field keyDeserField = MapDeserializer.class.getDeclaredField("_keyDeserializer");
        keyDeserField.setAccessible(true);
        KeyDeserializer updatedKeyDeser = (KeyDeserializer) keyDeserField.get(result); // Changed to get the deserializer
        assertEquals(resolvedKeyDeser, updatedKeyDeser, "_keyDeserializer should be the resolved key deserializer.");
        verify(ctxt, times(1)).findKeyDeserializer(any(), any());
    }

//     @Test
//     @DisplayName("createContextual resolves _valueDeserializer when _valueDeserializer is initially null")
//     public void TC12_createContextual_resolves_valueDeserializer_when_null() throws Exception {
        // Arrange
//         JavaType mockJavaType = mock(JavaType.class); // Added mock for JavaType
//         when(mockJavaType.getKeyType()).thenReturn(mock(JavaType.class)); // Ensure getKeyType() is mocked
//         when(mockJavaType.getContentType()).thenReturn(mock(JavaType.class)); // Ensure getContentType() is mocked
//         ValueInstantiator mockValueInstantiator = mock(ValueInstantiator.class); // Added mock for ValueInstantiator
//         MapDeserializer deserializer = new MapDeserializer(mockJavaType, mockValueInstantiator, null, null, null);
//         DeserializationContext ctxt = mock(DeserializationContext.class);
//         BeanProperty property = mock(BeanProperty.class);
//         JsonDeserializer<?> resolvedValueDeser = mock(JsonDeserializer.class);
//         when(ctxt.findContextualValueDeserializer(any(), any())).thenReturn(resolvedValueDeser);
// 
        // Act
//         JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);
// 
        // Assert
//         Field valueDeserField = MapDeserializer.class.getDeclaredField("_valueDeserializer");
//         valueDeserField.setAccessible(true);
//         JsonDeserializer<?> updatedValueDeser = (JsonDeserializer<?>) valueDeserField.get(result); // Changed to get the new instance
//         assertEquals(resolvedValueDeser, updatedValueDeser, "_valueDeserializer should be the resolved value deserializer.");
//         verify(ctxt, times(1)).findContextualValueDeserializer(any(), any());
//     }
}