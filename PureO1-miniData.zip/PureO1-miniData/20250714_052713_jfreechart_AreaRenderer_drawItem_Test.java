import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.LegendItem;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.AreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class AreaRendererTest {

    private AreaRenderer renderer;

    @Mock
    private Graphics2D g2;
    @Mock
    private CategoryItemRendererState state;
    @Mock
    private Rectangle2D dataArea;
    @Mock
    private CategoryPlot plot;
    @Mock
    private CategoryAxis domainAxis;
    @Mock
    private ValueAxis rangeAxis;
    @Mock
    private CategoryDataset dataset;
    @Mock
    private EntityCollection entities;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        renderer = new AreaRenderer();
        when(state.getEntityCollection()).thenReturn(entities);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
    }

    @Test
    void drawItem_ItemNotVisible_NoDrawing() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_ValueIsNull_NoDrawing() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_EndTypeTruncate_FirstColumn_TruncateStart() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.TRUNCATE);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getCategoryStart(0, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).setPaint(any());
        verify(g2).fill(any());
    }

    @Test
    void drawItem_EndTypeTruncate_LastColumn_TruncateEnd() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.TRUNCATE);
        when(renderer.getItemVisible(0, 2)).thenReturn(true);
        when(dataset.getValue(0, 2)).thenReturn(15.0);
        when(domainAxis.getCategoryStart(2, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(2, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(25.0);
        when(domainAxis.getCategoryEnd(2, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2, 0);
        verify(g2).setPaint(any());
        verify(g2).fill(any());
    }

    @Test
    void drawItem_EndTypeLevel_WithPreviousColumn() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.LEVEL);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getValue(0, 1)).thenReturn(20.0);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, 2)).thenReturn(30.0);
        when(domainAxis.getCategoryStart(1, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(1, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(15.0);
        when(domainAxis.getCategoryEnd(1, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(120.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(220.0);
        when(rangeAxis.valueToJava2D((10.0 + 20.0) / 2.0, dataArea, RectangleEdge.LEFT)).thenReturn(110.0);
        when(rangeAxis.valueToJava2D((30.0 + 20.0) / 2.0, dataArea, RectangleEdge.LEFT)).thenReturn(130.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        verify(g2).setPaint(any());
        verify(g2).fill(any());
    }

    @Test
    void drawItem_OrientationHorizontal() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.TAPER);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(domainAxis.getCategoryStart(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).setPaint(any());
        verify(g2).fill(any());
    }

    @Test
    void drawItem_NoPreviousNextValues_LevelEndType() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.LEVEL);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(0.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryStart(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).setPaint(any());
        verify(g2).fill(any());
    }

    @Test
    void drawItem_ItemLabelVisible_DrawLabel() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.TAPER);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getCategoryStart(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(renderer).drawItemLabel(g2, PlotOrientation.VERTICAL, dataset, 0, 0, 5.0, 100.0, false);
    }

    @Test
    void drawItem_ItemLabelNotVisible_NoLabel() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.TAPER);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getCategoryStart(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(renderer, never()).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    void drawItem_NullGraphics_ThrowsException() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(null, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    void drawItem_NullState_ThrowsException() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, null, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    void drawItem_NullDataArea_ThrowsException() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, null, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    void drawItem_NullPlot_ThrowsException() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(renderer.getPlot()).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, null, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Depending on implementation, it might do nothing or throw. If nothing, verify no interactions
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_FirstColumn_TruncateStart() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.TRUNCATE);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getColumnCount()).thenReturn(3);
        when(domainAxis.getCategoryStart(0, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).fill(any());
    }

    @Test
    void drawItem_LastColumn_TruncateEnd() {
        renderer.setEndType(AreaRenderer.AreaRendererEndType.TRUNCATE);
        when(renderer.getItemVisible(0, 2)).thenReturn(true);
        when(dataset.getValue(0, 2)).thenReturn(15.0);
        when(dataset.getColumnCount()).thenReturn(3);
        when(domainAxis.getCategoryStart(2, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(2, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(25.0);
        when(domainAxis.getCategoryEnd(2, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2, 0);
        verify(g2).fill(any());
    }

    @Test
    void drawItem_SeriesNotVisible_NoDrawing() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_SeriesVisible_DrawArea() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getCategoryStart(0, 2, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 2, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(domainAxis.getCategoryEnd(0, 2, dataArea, RectangleEdge.BOTTOM)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(25.0, dataArea, RectangleEdge.LEFT)).thenReturn(75.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(175.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).fill(any());
    }

    @Test
    void drawItem_UpdateCrosshairValues() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(30.0);
        when(domainAxis.getCategoryStart(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(30.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(400.0);
        when(state.getCrosshairState()).thenReturn(null); // Assuming crosshair state is handled internally
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Since crosshairState is null, no update should occur, just verify interactions
        verify(state).getCrosshairState();
    }

    @Test
    void drawItem_AddItemEntity() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.getCategoryStart(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.getCategoryMiddle(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(5.0);
        when(domainAxis.getCategoryEnd(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(entities).add(any());
    }

    @Test
    void drawItem_NullDataset_ThrowsException() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, 0, 0, 0);
        });
    }

    @Test
    void drawItem_ZeroColumnCount_NoDrawing() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getColumnCount()).thenReturn(0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }
}