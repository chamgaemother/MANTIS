package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonFactory;

import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReaderBasedJsonParser_nextToken_0_4_Test {

    @Test
    @DisplayName("nextToken() returns VALUE_NULL when encountering 'null'")
    void TC16_returns_VALUE_NULL_when_encountering_null() throws Exception {
        String jsonInput = "null";
        JsonFactory factory = new JsonFactory();
        // Obtain ReaderBasedJsonParser class
        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> constructor = parserClass.getDeclaredConstructor(JsonFactory.class, String.class, StringReader.class);
        constructor.setAccessible(true);
        Object parserInstance = constructor.newInstance(factory, "null", new StringReader(jsonInput));
        // Invoke nextToken
        Method nextTokenMethod = parserClass.getMethod("nextToken");
        JsonToken result = (JsonToken) nextTokenMethod.invoke(parserInstance);
        // Assert
        assertEquals(JsonToken.VALUE_NULL, result);
    }

    @Test
    @DisplayName("nextToken() parses signed number with '-' sign")
    void TC17_parses_signed_number_with_negative_sign() throws Exception {
        String jsonInput = "-123";
        JsonFactory factory = new JsonFactory();
        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> constructor = parserClass.getDeclaredConstructor(JsonFactory.class, String.class, StringReader.class);
        constructor.setAccessible(true);
        Object parserInstance = constructor.newInstance(factory, "-123", new StringReader(jsonInput));
        Method nextTokenMethod = parserClass.getMethod("nextToken");
        JsonToken result = (JsonToken) nextTokenMethod.invoke(parserInstance);
        assertEquals(JsonToken.VALUE_NUMBER_INT, result);
        // To assert the actual value, need to call getIntValue
        Method getIntValueMethod = parserClass.getMethod("getIntValue");
        int value = (int) getIntValueMethod.invoke(parserInstance);
        assertEquals(-123, value);
    }

    @Test
    @DisplayName("nextToken() handles '+' sign when ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS is enabled")
    void TC18_handles_plus_sign_with_feature_enabled() throws Exception {
        String jsonInput = "+456";
        JsonFactory factory = new JsonFactory();
        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> constructor = parserClass.getDeclaredConstructor(JsonFactory.class, String.class, StringReader.class);
        constructor.setAccessible(true);
        Object parserInstance = constructor.newInstance(factory, "+456", new StringReader(jsonInput));
        // Enable ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS
        Field featuresField = parserClass.getDeclaredField("_features");
        featuresField.setAccessible(true);
        int FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS = 1 << 0; // Assuming flag is bit 0
        int currentFeatures = featuresField.getInt(parserInstance);
        featuresField.setInt(parserInstance, currentFeatures | FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS);
        // Invoke nextToken
        Method nextTokenMethod = parserClass.getMethod("nextToken");
        JsonToken result = (JsonToken) nextTokenMethod.invoke(parserInstance);
        assertEquals(JsonToken.VALUE_NUMBER_INT, result);
        // Get value
        Method getIntValueMethod = parserClass.getMethod("getIntValue");
        int value = (int) getIntValueMethod.invoke(parserInstance);
        assertEquals(456, value);
    }

    @Test
    @DisplayName("nextToken() handles '+' sign when ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS is disabled")
    void TC19_handles_plus_sign_with_feature_disabled() throws Exception {
        String jsonInput = "+789";
        JsonFactory factory = new JsonFactory();
        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> constructor = parserClass.getDeclaredConstructor(JsonFactory.class, String.class, StringReader.class);
        constructor.setAccessible(true);
        Object parserInstance = constructor.newInstance(factory, "+789", new StringReader(jsonInput));
        // Disable ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS
        Field featuresField = parserClass.getDeclaredField("_features");
        featuresField.setAccessible(true);
        int FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS = 1 << 0; // Assuming flag is bit 0
        int currentFeatures = featuresField.getInt(parserInstance);
        featuresField.setInt(parserInstance, currentFeatures & ~FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS);
        // Invoke nextToken and expect exception
        Method nextTokenMethod = parserClass.getMethod("nextToken");
        assertThrows(Exception.class, () -> {
            nextTokenMethod.invoke(parserInstance);
        });
    }

    @Test
    @DisplayName("nextToken() parses floating number starting with '.' when ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS is enabled")
    void TC20_parses_floating_number_starting_with_decimal_point_enabled() throws Exception {
        String jsonInput = ".5";
        JsonFactory factory = new JsonFactory();
        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> constructor = parserClass.getDeclaredConstructor(JsonFactory.class, String.class, StringReader.class);
        constructor.setAccessible(true);
        Object parserInstance = constructor.newInstance(factory, ".5", new StringReader(jsonInput));
        // Enable ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS
        Field featuresField = parserClass.getDeclaredField("_features");
        featuresField.setAccessible(true);
        int FEAT_MASK_ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS = 1 << 1; // Assuming flag is bit 1
        int currentFeatures = featuresField.getInt(parserInstance);
        featuresField.setInt(parserInstance, currentFeatures | FEAT_MASK_ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS);
        // Invoke nextToken
        Method nextTokenMethod = parserClass.getMethod("nextToken");
        JsonToken result = (JsonToken) nextTokenMethod.invoke(parserInstance);
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, result);
        // Get value as double
        Method getDoubleValueMethod = parserClass.getMethod("getDoubleValue");
        double value = (double) getDoubleValueMethod.invoke(parserInstance);
        assertEquals(0.5, value);
    }
}