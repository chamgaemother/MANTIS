package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.HashMap;

import org.apache.commons.collections4.map.Flat3Map;

public class Flat3Map_get_0_1_Test {

    @Test
    @DisplayName("get with delegateMap not null returns delegateMap.get(key)")
    public void TC01() throws Exception {
        // Initialize Flat3Map
        Flat3Map map = new Flat3Map();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        HashMap<String, Object> delegateMap = new HashMap<>();
        delegateMap.put("testKey", "delegateValue");
        delegateMapField.set(map, delegateMap);

        // Define key
        Object key = "testKey";

        // Invoke get method
        Object result = map.get(key);

        // Assert the result
        Object expected = delegateMap.get(key);
        assertEquals(expected, result, "The result should be equal to delegateMap.get(key)");
    }

    @Test
    @DisplayName("get with delegateMap null and key is null, size is 3, key3 is null")
    public void TC02() throws Exception {
        // Initialize Flat3Map
        Flat3Map map = new Flat3Map();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key3 to null
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);

        // Define key as null
        Object key = null;

        // Invoke get method
        Object result = map.get(key);

        // Get value3 via reflection
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object expected = value3Field.get(map);

        // Assert the result
        assertEquals(expected, result, "The result should be value3");
    }

    @Test
    @DisplayName("get with delegateMap null and key is null, size is 3, key3 not null")
    public void TC03() throws Exception {
        // Initialize Flat3Map
        Flat3Map map = new Flat3Map();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key3 to "existingKey3"
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "existingKey3");

        // Set key2 to null
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        // Define key as null
        Object key = null;

        // Invoke get method
        Object result = map.get(key);

        // Get value2 via reflection
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object expected = value2Field.get(map);

        // Assert the result
        assertEquals(expected, result, "The result should be value2");
    }

    @Test
    @DisplayName("get with delegateMap null and key is null, size is 3, key3 and key2 not null, key1 is null")
    public void TC04() throws Exception {
        // Initialize Flat3Map
        Flat3Map map = new Flat3Map();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key3 to "existingKey3"
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "existingKey3");

        // Set key2 to "existingKey2"
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "existingKey2");

        // Set key1 to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // Define key as null
        Object key = null;

        // Invoke get method
        Object result = map.get(key);

        // Get value1 via reflection
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object expected = value1Field.get(map);

        // Assert the result
        assertEquals(expected, result, "The result should be value1");
    }

    @Test
    @DisplayName("get with delegateMap null and key is null, size is 3, all keys not null")
    public void TC05() throws Exception {
        // Initialize Flat3Map
        Flat3Map map = new Flat3Map();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key3 to "existingKey3"
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "existingKey3");

        // Set key2 to "existingKey2"
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "existingKey2");

        // Set key1 to "existingKey1"
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "existingKey1");

        // Define key as null
        Object key = null;

        // Invoke get method
        Object result = map.get(key);

        // Assert the result is null
        assertNull(result, "The result should be null");
    }
}