package org.apache.commons.compress.harmony.pack200;

import org.apache.commons.compress.harmony.pack200.IntList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class IntList_add_0_2_Test {

    @Test
    @DisplayName("Throw exception for location index greater than list size")
    void testThrowExceptionForIndexGreaterThanSize() {
        IntList list = new IntList();
        // Set up the list to be non-empty
        list.add(0, 1);
        list.add(1, 2);

        assertThrows(IndexOutOfBoundsException.class, () -> {
            // Attempt to add an element at an index greater than list size
            list.add(3, 3);
        });
    }

    @Test
    @DisplayName("Add an element at the start of the list, using space at the front")
    void testAddElementAtStartWithSpaceAtFront() throws NoSuchFieldException, IllegalAccessException {
        IntList list = new IntList();
        // Internal setup to simulate a list that has been left shifted
        list.add(0, 2);
        list.add(1, 3);

        // Simulate a shift to create space at the front
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 1);

        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 2);

        list.add(0, 1);

        // Verify the correct insertion at the front
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = (int[]) arrayField.get(list);

        assertEquals(1, array[(Integer) firstIndexField.get(list)]);
    }

    @Test
    @DisplayName("Insert in middle with even division, causing a shift in array")
    void testInsertInMiddleWithEvenDivision() throws NoSuchFieldException, IllegalAccessException {
        IntList list = new IntList();

        list.add(0, 1);
        list.add(1, 3);

        list.add(1, 2);

        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = (int[]) arrayField.get(list);

        assertAll(
            () -> assertEquals(1, array[0]),
            () -> assertEquals(2, array[1]),
            () -> assertEquals(3, array[2])
        );
    }

    @Test
    @DisplayName("Add at end without needing to grow at end")
    void testAddAtEndWithoutGrowing() throws NoSuchFieldException, IllegalAccessException {
        IntList list = new IntList();
        list.add(0, 1);
        list.add(1, 2);

        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 2);

        list.add(2, 3);

        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = (int[]) arrayField.get(list);

        assertEquals(3, array[2]);
    }

    @Test
    @DisplayName("Incrementally fills the list up to first array expansion")
    void testIncrementalFillUntilArrayExpansion() throws NoSuchFieldException, IllegalAccessException {
        IntList list = new IntList();

        for (int i = 0; i < 10; i++) {
            list.add(i, i);
        }

        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = (int[]) arrayField.get(list);

        for (int i = 0; i < 10; i++) {
            assertEquals(i, array[i]);
        }
    }
}