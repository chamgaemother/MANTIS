package org.apache.commons.math3.geometry.euclidean.twod.hull;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collection;

import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;

public class AklToussaintHeuristic_reducePoints_1_1_Test {

    @Test
    @DisplayName("reducePoints with quadrilateral size exactly 3 after buildQuadrilateral")
    public void TC14() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(1, 1);
        Vector2D p3 = new Vector2D(2, 2);
        Vector2D p4 = new Vector2D(1, 1); // Duplicate point
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4);

        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        assertEquals(points, result, "The result should be equal to the original points when quadrilateral size is less than 3");
    }

    @Test
    @DisplayName("reducePoints with mix of points inside and outside the quadrilateral")
    public void TC15() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(4, 4);
        Vector2D p3 = new Vector2D(4, 0);
        Vector2D p4 = new Vector2D(0, 4);
        Vector2D p5 = new Vector2D(2, 2); // Inside point
        Vector2D p6 = new Vector2D(5, 5); // Outside point
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4, p5, p6);

        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4, p6)), "Result should contain all quadrilateral and outside points");
        assertFalse(result.contains(p5), "Result should not contain the inside point");
    }

    @Test
    @DisplayName("reducePoints with points lying on different quadrilateral edges")
    public void TC16() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(4, 0);
        Vector2D p3 = new Vector2D(4, 4);
        Vector2D p4 = new Vector2D(0, 4);
        Vector2D pEdge1 = new Vector2D(2, 0); // On edge p1-p2
        Vector2D pEdge2 = new Vector2D(4, 2); // On edge p2-p3
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4, pEdge1, pEdge2);

        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4, pEdge1, pEdge2)), "Result should contain all quadrilateral and edge points");
    }

    @Test
    @DisplayName("reducePoints with no points inside the quadrilateral but some on edges")
    public void TC17() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(5, 0);
        Vector2D p3 = new Vector2D(5, 5);
        Vector2D p4 = new Vector2D(0, 5);
        Vector2D pEdge1 = new Vector2D(2, 0); // On edge p1-p2
        Vector2D pEdge2 = new Vector2D(5, 2); // On edge p2-p3
        Vector2D pEdge3 = new Vector2D(3, 5); // On edge p3-p4
        Vector2D pEdge4 = new Vector2D(0, 3); // On edge p4-p1
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4, pEdge1, pEdge2, pEdge3, pEdge4);

        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4, pEdge1, pEdge2, pEdge3, pEdge4)), "Result should contain all quadrilateral and edge points");
    }

    @Test
    @DisplayName("reducePoints with quadrilateral size exactly 4 but overlapping points")
    public void TC18() {
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(4, 0);
        Vector2D p3 = new Vector2D(4, 4);
        Vector2D p4 = new Vector2D(2, 2); // Overlapping point
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4);

        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3)), "Result should contain all valid quadrilateral points");
        assertFalse(result.contains(p4), "Result should not contain the overlapping point");
    }

}