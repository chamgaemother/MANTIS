package org.apache.commons.collections4;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class MapUtils_putAll_0_1_Test {

    @Test
    @DisplayName("putAll throws NullPointerException when map is null")
    public void TC01() {
        Map<String, Integer> map = null;
        Object[] array = null;

        NullPointerException exception = assertThrows(NullPointerException.class, () -> {
            MapUtils.putAll(map, array);
        });

        assertEquals("map", exception.getMessage());
    }

    @Test
    @DisplayName("putAll returns the original map when array is null")
    public void TC02() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = null;

        Map<String, Integer> result = MapUtils.putAll(map, array);

        assertSame(map, result, "The returned map should be the same as the original map.");
    }

    @Test
    @DisplayName("putAll returns the original map when array is empty")
    public void TC03() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[0];

        Map<String, Integer> result = MapUtils.putAll(map, array);

        assertSame(map, result, "The returned map should be the same as the original map when array is empty.");
    }

    @Test
    @DisplayName("putAll adds a single Map.Entry to the map")
    public void TC04() {
        Map<String, Integer> map = new HashMap<>();
        Map.Entry<String, Integer> entry = new AbstractMap.SimpleEntry<>("key1", 1);
        Object[] array = new Object[] { entry };

        Map<String, Integer> result = MapUtils.putAll(map, array);

        assertEquals(1, result.size(), "Map should contain one entry.");
        assertEquals(Integer.valueOf(1), result.get("key1"), "Map should contain the entry with key 'key1' and value 1.");
    }

    @Test
    @DisplayName("putAll adds multiple Map.Entry objects to the map")
    public void TC05() {
        Map<String, Integer> map = new HashMap<>();
        Map.Entry<String, Integer> entry1 = new AbstractMap.SimpleEntry<>("key1", 1);
        Map.Entry<String, Integer> entry2 = new AbstractMap.SimpleEntry<>("key2", 2);
        Object[] array = new Object[] { entry1, entry2 };

        Map<String, Integer> result = MapUtils.putAll(map, array);

        assertEquals(2, result.size(), "Map should contain two entries.");
        assertEquals(Integer.valueOf(1), result.get("key1"), "Map should contain the entry with key 'key1' and value 1.");
        assertEquals(Integer.valueOf(2), result.get("key2"), "Map should contain the entry with key 'key2' and value 2.");
    }
}