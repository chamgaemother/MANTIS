package org.apache.commons.math3.stat.descriptive;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MultivariateSummaryStatistics_equals_2_1_Test {

    @Test
    @DisplayName("TC15: equals returns false when comparing objects with different dimensions")
    void testEqualsDifferentDimensions() {
        // Arrange
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(3, true);

        // Act
        boolean result = stats1.equals(stats2);

        // Assert
        assertFalse(result, "Expected equals to return false when dimensions differ");
    }

    @Test
    @DisplayName("TC16: equals returns false when comparing with a subclass instance")
    void testEqualsSubclassInstance() {
        // Arrange
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        SubMultivariateSummaryStatistics statsSub = new SubMultivariateSummaryStatistics(2, true);

        // Add identical data to both instances
        double[] data = {1.0, 2.0};
        stats1.addValue(data);
        statsSub.addValue(data);

        // Act
        boolean result = stats1.equals(statsSub);

        // Assert
        assertFalse(result, "Expected equals to return false when comparing with subclass instance");
    }

    // Subclass for TC16
    private static class SubMultivariateSummaryStatistics extends MultivariateSummaryStatistics {
        public SubMultivariateSummaryStatistics(int k, boolean isCovarianceBiasCorrected) {
            super(k, isCovarianceBiasCorrected);
        }
    }
}