package org.jfree.chart.plot;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.general.DefaultPieDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class PiePlot3D_draw_2_1_Test {

    @Test
    @DisplayName("When depthFactor is set to zero, the pie chart is rendered without any depth effect")
    void TC06_draw_with_zero_DepthFactor() throws Exception {
        // Arrange
        PiePlot3D piePlot3D = new PiePlot3D();
        piePlot3D.setDepthFactor(0.0);
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Category 1", 100);
        dataset.setValue("Category 2", 200);
        piePlot3D.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        Point2D anchor = new Point2D.Double(200, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // Act
        piePlot3D.draw(g2, plotArea, anchor, state, info);

        // Assert
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
        Assertions.assertEquals(0.0, piePlot3D.getDepthFactor(), 0.0001);
    }

    @Test
    @DisplayName("When dataset contains only one valid section, the pie chart is rendered correctly with a single slice")
    void TC07_draw_singleValidSection() throws Exception {
        // Arrange
        PiePlot3D piePlot3D = new PiePlot3D();
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Only Category", 100);
        piePlot3D.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        Point2D anchor = new Point2D.Double(200, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // Act
        piePlot3D.draw(g2, plotArea, anchor, state, info);

        // Assert
        verify(g2, times(1)).fill(any());
        verify(g2, times(1)).draw(any());
        Assertions.assertEquals(1, dataset.getKeys().size(), "Dataset should contain only one key");
    }

    @Test
    @DisplayName("When dataset contains all sections with zero or negative values, no slices are drawn and a no-data message is displayed")
    void TC08_draw_allSectionsZeroOrNegative() throws Exception {
        // Arrange
        PiePlot3D piePlot3D = new PiePlot3D();
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Category 1", 0);
        dataset.setValue("Category 2", -10);
        piePlot3D.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        Point2D anchor = new Point2D.Double(200, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // Act
        piePlot3D.draw(g2, plotArea, anchor, state, info);

        // Assert
        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
        verify(g2, times(1)).drawString(any(String.class), anyInt(), anyInt());
    }

    @Test
    @DisplayName("When dataset contains sections with null values, these sections are skipped and only valid sections are drawn")
    void TC09_draw_sectionsWithNullValues() throws Exception {
        // Arrange
        PiePlot3D piePlot3D = new PiePlot3D();
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Category 1", null);
        dataset.setValue("Category 2", 150);
        dataset.setValue("Category 3", null);
        piePlot3D.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        Point2D anchor = new Point2D.Double(200, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // Act
        piePlot3D.draw(g2, plotArea, anchor, state, info);

        // Assert
        verify(g2, times(1)).fill(any());
        verify(g2, times(1)).draw(any());
    }

    @Test
    @DisplayName("When minimum arc angle to draw is set to a high value, small sections are not drawn")
    void TC10_draw_with_high_minimumArcAngleToDraw() throws Exception {
        // Arrange
        PiePlot3D piePlot3D = new PiePlot3D();
        piePlot3D.setMinimumArcAngleToDraw(90.0);
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Category 1", 30);
        dataset.setValue("Category 2", 60);
        dataset.setValue("Category 3", 10);
        piePlot3D.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        Point2D anchor = new Point2D.Double(200, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // Act
        piePlot3D.draw(g2, plotArea, anchor, state, info);

        // Assert
        verify(g2, times(2)).fill(any());
        verify(g2, times(2)).draw(any());
    }
}