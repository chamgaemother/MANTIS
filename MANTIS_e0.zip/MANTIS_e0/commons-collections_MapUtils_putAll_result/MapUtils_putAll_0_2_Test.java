package org.apache.commons.collections4;

import org.apache.commons.collections4.keyvalue.DefaultKeyValue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class MapUtils_putAll_0_2_Test {

    @Test
    @DisplayName("putAll processes a single KeyValue element correctly")
    void TC06_putAll_singleKeyValue() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        // Use DefaultKeyValue instead of undefined KeyValue
        DefaultKeyValue<String, String> keyValue = new DefaultKeyValue<>("key1", "value1");
        Object[] array = new Object[] { keyValue };

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        assertTrue(result.containsKey("key1"));
        assertEquals("value1", result.get("key1"));
    }

    @Test
    @DisplayName("putAll processes multiple KeyValue elements correctly")
    void TC07_putAll_multipleKeyValues() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        // Use DefaultKeyValue instead of undefined KeyValue
        DefaultKeyValue<String, String> keyValue1 = new DefaultKeyValue<>("key1", "value1");
        DefaultKeyValue<String, String> keyValue2 = new DefaultKeyValue<>("key2", "value2");
        Object[] array = new Object[] { keyValue1, keyValue2 };

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        assertTrue(result.containsKey("key1"));
        assertEquals("value1", result.get("key1"));
        assertTrue(result.containsKey("key2"));
        assertEquals("value2", result.get("key2"));
    }

    @Test
    @DisplayName("putAll processes a single Object[] element with valid key-value pair")
    void TC08_putAll_singleObjectArray() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        Object[] subArray = new Object[] { "key1", "value1" };
        Object[] array = new Object[] { subArray };

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        assertTrue(result.containsKey("key1"));
        assertEquals("value1", result.get("key1"));
    }

    @Test
    @DisplayName("putAll processes multiple Object[] elements correctly")
    void TC09_putAll_multipleObjectArrays() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        Object[] subArray1 = new Object[] { "key1", "value1" };
        Object[] subArray2 = new Object[] { "key2", "value2" };
        Object[] array = new Object[] { subArray1, subArray2 };

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        assertTrue(result.containsKey("key1"));
        assertEquals("value1", result.get("key1"));
        assertTrue(result.containsKey("key2"));
        assertEquals("value2", result.get("key2"));
    }

    @Test
    @DisplayName("putAll throws IllegalArgumentException when an Object[] element is null")
    void TC10_putAll_nullSubArray() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[] { null };

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            MapUtils.putAll(map, array);
        });
        assertTrue(exception.getMessage().contains("Invalid array element: 0"));
    }
}
