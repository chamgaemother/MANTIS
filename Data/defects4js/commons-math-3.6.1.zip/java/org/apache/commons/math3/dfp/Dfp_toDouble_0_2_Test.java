package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_toDouble_0_2_Test {

    @Test
    @DisplayName("toDouble returns 0.0 when Dfp is subnormal with exponent less than -1074")
    public void TC06_toDouble_SubnormalExponent_LessOrEqualThanMinus1074() throws Exception {
        // Arrange
        Dfp dfp = createDfpInstance((byte) 1, /* nans */ 0, /* exp */ -1075, /* mantissa */ new int[]{0});

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(0.0, result, "Expected toDouble to return 0.0 for subnormal Dfp with exponent <= -1074");
    }

    @Test
    @DisplayName("toDouble returns Double.POSITIVE_INFINITY when exponent exceeds 1023")
    public void TC07_toDouble_ExponentExceeds1023_PositiveInfinity() throws Exception {
        // Arrange
        Dfp dfp = createDfpInstance((byte) 1, /* nans */ 0, /* exp */ 1024, /* mantissa */ new int[]{Integer.MAX_VALUE});

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(Double.POSITIVE_INFINITY, result, "Expected toDouble to return Double.POSITIVE_INFINITY when exponent > 1023");
    }

    @Test
    @DisplayName("toDouble correctly converts a normal positive Dfp number to double")
    public void TC08_toDouble_NormalPositiveNumber() throws Exception {
        // Arrange
        Dfp dfp = createDfpInstance((byte) 1, /* nans */ 0, /* exp */ 10, /* mantissa */ new int[]{1234});

        // Act
        double result = dfp.toDouble();

        // Assert
        double expected = 1.234E10;
        assertEquals(expected, result, "Expected toDouble to correctly convert a normal positive Dfp number");
    }

    @Test
    @DisplayName("toDouble correctly converts a normal negative Dfp number to double")
    public void TC09_toDouble_NormalNegativeNumber() throws Exception {
        // Arrange
        Dfp dfp = createDfpInstance((byte) -1, /* nans */ 0, /* exp */ 10, /* mantissa */ new int[]{1234});

        // Act
        double result = dfp.toDouble();

        // Assert
        double expected = -1.234E10;
        assertEquals(expected, result, "Expected toDouble to correctly convert a normal negative Dfp number");
    }

    @Test
    @DisplayName("toDouble handles loop with zero iterations during exponent calculation")
    public void TC10_toDouble_ZeroLoopIterations() throws Exception {
        // Arrange
        Dfp dfp = createDfpInstance((byte) 1, /* nans */ 0, /* exp */ 0, /* mantissa */ new int[]{(int) 4503599627370496L});

        // Act
        double result = dfp.toDouble();

        // Assert
        double expected = 4503599627370496.0;
        assertEquals(expected, result, "Expected toDouble to correctly convert without entering the loop");
    }

    /**
     * Utility method to create a Dfp instance with specified parameters using reflection.
     *
     * @param sign      The sign of the Dfp number.
     * @param nans      The NaN status of the Dfp number.
     * @param exp       The exponent of the Dfp number.
     * @param mantissa  The mantissa of the Dfp number.
     * @return          A Dfp instance configured with the provided parameters.
     * @throws Exception If reflection operations fail.
     */
    private Dfp createDfpInstance(byte sign, int nans, int exp, int[] mantissa) throws Exception {
        // Obtain the Dfp class
        Class<Dfp> dfpClass = Dfp.class;

        // Access the constructor (assuming a field argument constructor exists)
        Constructor<Dfp> constructor = dfpClass.getDeclaredConstructor(DfpField.class);
        constructor.setAccessible(true);
        Dfp dfp = constructor.newInstance(new DfpField(mantissa.length));

        // Set the 'sign' field
        Field signField = dfpClass.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(dfp, sign);

        // Set the 'nans' field
        Field nansField = dfpClass.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setInt(dfp, nans);

        // Set the 'exp' field
        Field expField = dfpClass.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(dfp, exp);

        // Set the 'mant' field
        Field mantField = dfpClass.getDeclaredField("mant");
        mantField.setAccessible(true);
        mantField.set(dfp, mantissa);

        return dfp;
    }
}