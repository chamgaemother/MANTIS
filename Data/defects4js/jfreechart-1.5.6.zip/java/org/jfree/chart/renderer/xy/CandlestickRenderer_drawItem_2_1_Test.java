package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CandlestickRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("TC21: drawItem throws ClassCastException when dataset is not an instance of OHLCDataset")
    void TC21_drawItem_NonOHLCDataset_ShouldThrowClassCastException() {
        // Arrange
        CandlestickRenderer renderer = new CandlestickRenderer();
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        XYDataset dataset = mock(XYDataset.class); // Non-OHLCDataset
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Act & Assert
        assertThrows(ClassCastException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        });
    }

    @Test
    @DisplayName("TC22: drawItem handles autoWidthFactor set to 0.0 correctly, resulting in minimal candle width")
    void TC22_drawItem_AutoWidthFactorZero_ShouldMinimizeCandleWidth() throws Exception {
        // Arrange
        CandlestickRenderer renderer = new CandlestickRenderer();
        renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_AVERAGE);
        renderer.setAutoWidthFactor(0.0);
        renderer.setDrawVolume(false);
        
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        OHLCDataset dataset = mock(OHLCDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(5);
        for(int i = 0; i < 5; i++) {
            when(dataset.getVolumeValue(0, i)).thenReturn(100.0 + i * 10);
            when(dataset.getXValue(0, i)).thenReturn((double) i);
            when(dataset.getHighValue(0, i)).thenReturn(10.0 + i);
            when(dataset.getLowValue(0, i)).thenReturn(5.0 + i);
            when(dataset.getOpenValue(0, i)).thenReturn(6.0 + i);
            when(dataset.getCloseValue(0, i)).thenReturn(9.0 + i);
        }
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        ChartRenderingInfo chartInfo = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(chartInfo);
        when(chartInfo.getEntityCollection()).thenReturn(entities);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        when(dataArea.getWidth()).thenReturn(800.0);
        when(dataArea.getHeight()).thenReturn(600.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.getLowerBound()).thenReturn(0.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(400.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Act
        renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        // Assert
        Field candleWidthField = CandlestickRenderer.class.getDeclaredField("candleWidth");
        candleWidthField.setAccessible(true);
        double candleWidth = candleWidthField.getDouble(renderer);
        assertEquals(0.0, candleWidth, 0.001, "Candle width should be minimized when autoWidthFactor is 0.0");
    }

    @Test
    @DisplayName("TC23: drawItem handles autoWidthFactor set to 1.0 correctly, resulting in maximum candle width")
    void TC23_drawItem_AutoWidthFactorOne_ShouldMaximizeCandleWidth() throws Exception {
        // Arrange
        CandlestickRenderer renderer = new CandlestickRenderer();
        renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_AVERAGE);
        renderer.setAutoWidthFactor(1.0);
        renderer.setAutoWidthGap(0.0);
        renderer.setDrawVolume(false);
        
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        OHLCDataset dataset = mock(OHLCDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(5);
        for(int i = 0; i < 5; i++) {
            when(dataset.getVolumeValue(0, i)).thenReturn(100.0 + i * 10);
            when(dataset.getXValue(0, i)).thenReturn((double) i);
            when(dataset.getHighValue(0, i)).thenReturn(10.0 + i);
            when(dataset.getLowValue(0, i)).thenReturn(5.0 + i);
            when(dataset.getOpenValue(0, i)).thenReturn(6.0 + i);
            when(dataset.getCloseValue(0, i)).thenReturn(9.0 + i);
        }
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        ChartRenderingInfo chartInfo = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(chartInfo);
        when(chartInfo.getEntityCollection()).thenReturn(entities);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        when(dataArea.getWidth()).thenReturn(800.0);
        when(dataArea.getHeight()).thenReturn(600.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.getLowerBound()).thenReturn(0.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(400.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Act
        renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        // Assert
        Field candleWidthField = CandlestickRenderer.class.getDeclaredField("candleWidth");
        candleWidthField.setAccessible(true);
        double candleWidth = candleWidthField.getDouble(renderer);
        double expectedWidth = (800.0 / 5) * (4.5 / 7);
        assertEquals(expectedWidth, candleWidth, 0.001, "Candle width should be maximized when autoWidthFactor is 1.0");
    }

    @Test
    @DisplayName("TC24: drawItem handles autoWidthGap causing candle width to reach zero")
    void TC24_drawItem_AutoWidthGapExcessive_ShouldSetMinimalCandleWidth() throws Exception {
        // Arrange
        CandlestickRenderer renderer = new CandlestickRenderer();
        renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_SMALLEST);
        renderer.setAutoWidthGap(1000.0); // excessively large gap
        renderer.setAutoWidthFactor(1.0);
        renderer.setDrawVolume(false);
        
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        OHLCDataset dataset = mock(OHLCDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(5);
        for(int i = 0; i < 5; i++) {
            when(dataset.getVolumeValue(0, i)).thenReturn(100.0 + i * 10);
            when(dataset.getXValue(0, i)).thenReturn((double) i);
            when(dataset.getHighValue(0, i)).thenReturn(10.0 + i);
            when(dataset.getLowValue(0, i)).thenReturn(5.0 + i);
            when(dataset.getOpenValue(0, i)).thenReturn(6.0 + i);
            when(dataset.getCloseValue(0, i)).thenReturn(9.0 + i);
        }
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        ChartRenderingInfo chartInfo = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(chartInfo);
        when(chartInfo.getEntityCollection()).thenReturn(entities);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        when(dataArea.getWidth()).thenReturn(800.0);
        when(dataArea.getHeight()).thenReturn(600.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.getLowerBound()).thenReturn(0.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(400.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Act
        renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        // Assert
        Field candleWidthField = CandlestickRenderer.class.getDeclaredField("candleWidth");
        candleWidthField.setAccessible(true);
        double candleWidth = candleWidthField.getDouble(renderer);
        assertTrue(candleWidth > 0, "Candle width should be positive even if autoWidthGap causes width to reach zero");
    }

    @Test
    @DisplayName("TC25: drawItem uses item paint when upPaint is null and yClose > yOpen")
    void TC25_drawItem_UpPaintNull_YCloseGreaterThanYOpen_ShouldUseItemPaint() {
        // Arrange
        CandlestickRenderer renderer = new CandlestickRenderer();
        renderer.setUseOutlinePaint(false);
        renderer.setUpPaint(null); // upPaint is null
        renderer.setDrawVolume(false);
        
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        OHLCDataset dataset = mock(OHLCDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getHighValue(0, 0)).thenReturn(2.0);
        when(dataset.getLowValue(0, 0)).thenReturn(0.5);
        when(dataset.getOpenValue(0, 0)).thenReturn(1.0);
        when(dataset.getCloseValue(0, 0)).thenReturn(2.0); // yClose > yOpen
        when(dataset.getVolumeValue(0, 0)).thenReturn(1000.0);
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        ChartRenderingInfo chartInfo = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(chartInfo);
        when(chartInfo.getEntityCollection()).thenReturn(entities);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        when(dataArea.getWidth()).thenReturn(800.0);
        when(dataArea.getHeight()).thenReturn(600.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(400.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(300.0);
        
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        // Assert
        // Verify that item paint is used instead of upPaint
        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).fill(any(Rectangle2D.class));
    }
}