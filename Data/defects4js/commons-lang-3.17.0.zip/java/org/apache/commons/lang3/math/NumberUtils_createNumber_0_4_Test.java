package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_createNumber_0_4_Test {

    @Test
    @DisplayName("Input string with invalid characters, should throw NumberFormatException")
    public void TC16_createNumber_invalid_characters() {
        // GIVEN
        String input = "123a45";
        
        // WHEN & THEN
        NumberFormatException exception = assertThrows(NumberFormatException.class, () -> {
            NumberUtils.createNumber(input);
        });
        
        // Optional: You can assert the exception message if needed
        // assertEquals("<expected message>", exception.getMessage());
    }

    @Test
    @DisplayName("Input string with hexadecimal prefix and leading zeros, should return appropriate Number type")
    public void TC17_createNumber_hex_leading_zeros() {
        // GIVEN
        String input = "0x0000ABCD";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertInstanceOf(Integer.class, result, "Result should be an instance of Integer");
        assertEquals(43981, result.intValue(), "Integer value should be 43981");
    }

    @Test
    @DisplayName("Input string without decimal or exponent, invalid Integer and Long, should return BigInteger")
    public void TC18_createNumber_integer_overflow() {
        // GIVEN
        String input = "2147483648";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertInstanceOf(Long.class, result, "Result should be an instance of Long");
        assertEquals(2147483648L, result.longValue(), "Long value should be 2147483648L");
    }

    @Test
    @DisplayName("Input string with decimal point resulting in zero mantissa, should return Float")
    public void TC19_createNumber_decimal_zero_float() {
        // GIVEN
        String input = "0.0F";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertInstanceOf(Float.class, result, "Result should be an instance of Float");
        assertEquals(0.0F, result.floatValue(), "Float value should be 0.0F");
    }

    @Test
    @DisplayName("Input string with invalid type suffix, should throw NumberFormatException")
    public void TC20_createNumber_invalid_suffix() {
        // GIVEN
        String input = "123.45X";
        
        // WHEN & THEN
        NumberFormatException exception = assertThrows(NumberFormatException.class, () -> {
            NumberUtils.createNumber(input);
        });
        
        assertEquals("123.45X is not a valid number.", exception.getMessage(), "Exception message should match the expected message");
    }
}