import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ZipArchiveEntryTest {

    @Test
    void testEqualsSameObject() {
        ZipArchiveEntry entry = new ZipArchiveEntry("entry");
        assertTrue(entry.equals(entry), "Entry should be equal to itself.");
    }

    @Test
    void testEqualsNull() {
        ZipArchiveEntry entry = new ZipArchiveEntry("entry");
        assertFalse(entry.equals(null), "Entry should not be equal to null.");
    }

    @Test
    void testEqualsDifferentClass() {
        ZipArchiveEntry entry = new ZipArchiveEntry("entry");
        Object obj = new Object();
        assertFalse(entry.equals(obj), "Entry should not be equal to an object of a different class.");
    }

    @Test
    void testEqualsDifferentName() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry1");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry2");
        assertFalse(entry1.equals(entry2), "Entries with different names should not be equal.");
    }

    @Test
    void testEqualsSameNameDifferentOtherAttributes() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry1.setComment("comment1");
        entry2.setComment("comment2");
        assertFalse(entry1.equals(entry2), "Entries with the same name but different attributes should not be equal.");
    }

    @Test
    void testEqualsSameNameAndComment() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        entry1.setComment("comment");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry2.setComment("comment");
        assertTrue(entry1.equals(entry2), "Entries with the same name and comment should be equal.");
    }

    @Test
    void testEqualsAllAttributes() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        entry1.setComment("comment");
        entry1.setMethod(ZipArchiveEntry.DEFLATED);
        entry1.setSize(100);
        entry1.setCompressedSize(50);
        entry1.setCrc(12345);
        entry1.setTime(System.currentTimeMillis());

        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry2.setComment("comment");
        entry2.setMethod(ZipArchiveEntry.DEFLATED);
        entry2.setSize(100);
        entry2.setCompressedSize(50);
        entry2.setCrc(12345);
        entry2.setTime(System.currentTimeMillis());

        assertTrue(entry1.equals(entry2), "Entries with identical attributes should be equal.");
    }

    @Test
    void testEqualsNameWithNullAndEmptyComment() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry2.setComment("");
        assertFalse(entry1.equals(entry2), "Entries with the same name but one with null comment and the other with empty comment should not be equal.");
    }

    @Test
    void testEqualsNullAndNonNullExtraFields() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");
        entry2.addExtraField(new ZipExtraField() {
            @Override
            public ZipShort getHeaderId() {
                return new ZipShort(1);
            }

            @Override
            public ZipShort getLocalFileDataLength() {
                return new ZipShort(0);
            }

            @Override
            public ZipShort getCentralDirectoryLength() {
                return new ZipShort(0);
            }

            @Override
            public byte[] getLocalFileDataData() {
                return new byte[0];
            }

            @Override
            public byte[] getCentralDirectoryData() {
                return new byte[0];
            }
        });
        assertFalse(entry1.equals(entry2), "Entries with null and non-null extra fields should not be equal.");
    }
}