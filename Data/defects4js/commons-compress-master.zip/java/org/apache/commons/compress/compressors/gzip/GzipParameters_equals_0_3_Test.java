package org.apache.commons.compress.compressors.gzip;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.time.Instant;

public class GzipParameters_equals_0_3_Test {

    @Test
    @DisplayName("equals returns false when headerCrc differs")
    public void TC11_equalsDifferentHeaderCrc() {
        // GIVEN
        GzipParameters params1 = new GzipParameters();
        params1.setHeaderCRC(true);  // Fixed: Method name was incorrect
        GzipParameters params2 = new GzipParameters();
        params2.setHeaderCRC(false);  // Fixed: Method name was incorrect
        
        // WHEN
        boolean result = params1.equals(params2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when modificationInstant differs")
    public void TC12_equalsDifferentModificationInstant() {
        // GIVEN
        GzipParameters params1 = new GzipParameters();
        params1.setModificationInstant(Instant.now());
        GzipParameters params2 = new GzipParameters();
        params2.setModificationInstant(Instant.EPOCH);
        
        // WHEN
        boolean result = params1.equals(params2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when operatingSystem differs")
    public void TC13_equalsDifferentOperatingSystem() {
        // GIVEN
        GzipParameters params1 = new GzipParameters();
        params1.setOS(GzipParameters.OS.UNKNOWN);  // Fixed: Corrected method name
        GzipParameters params2 = new GzipParameters();
        params2.setOS(GzipParameters.OS.UNIX);  // Fixed: Corrected method name
        
        // WHEN
        boolean result = params1.equals(params2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when trailerCrc differs")
    public void TC14_equalsDifferentTrailerCrc() {
        // GIVEN
        GzipParameters params1 = new GzipParameters();
        params1.setTrailerCrc(123456789L);
        GzipParameters params2 = new GzipParameters();
        params2.setTrailerCrc(987654321L);
        
        // WHEN
        boolean result = params1.equals(params2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when trailerISize differs")
    public void TC15_equalsDifferentTrailerISize() {
        // GIVEN
        GzipParameters params1 = new GzipParameters();
        params1.setTrailerISize(1024L);
        GzipParameters params2 = new GzipParameters();
        params2.setTrailerISize(2048L);
        
        // WHEN
        boolean result = params1.equals(params2);
        
        // THEN
        assertFalse(result);
    }
}