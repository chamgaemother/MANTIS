package org.jfree.chart.renderer.category;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class GradientBarPainter_paintBar_0_1_Test {
    
    @Test
    @DisplayName("itemPaint is Color, alpha != 0, base is TOP, isDrawBarOutline is true, outline stroke and paint are not null")
    public void TC01() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(0, 0)).thenReturn(Color.BLUE);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(0, 0)).thenReturn(new BasicStroke(1.0f));
        when(renderer.getItemOutlinePaint(0, 0)).thenReturn(Color.BLACK);
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 20);
        RectangleEdge base = RectangleEdge.TOP;
        GradientBarPainter painter = new GradientBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientBarPainter.class.getDeclaredField("g1");
        g1Field.setAccessible(true);
        g1Field.setDouble(painter, 0.25);

        Field g2Field = GradientBarPainter.class.getDeclaredField("g2");
        g2Field.setAccessible(true);
        g2Field.setDouble(painter, 0.5);

        Field g3Field = GradientBarPainter.class.getDeclaredField("g3");
        g3Field.setAccessible(true);
        g3Field.setDouble(painter, 0.75);

        // WHEN
        painter.paintBar(g2, renderer, 0, 0, bar, base);

        // THEN
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2, times(4)).setPaint(paintCaptor.capture());
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2).setStroke(any(BasicStroke.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2).draw(bar);
    }

    @Test
    @DisplayName("itemPaint is Color, alpha != 0, base is TOP, isDrawBarOutline is true, outline stroke is null")
    public void TC02() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(0, 0)).thenReturn(Color.BLUE);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(0, 0)).thenReturn(null);
        when(renderer.getItemOutlinePaint(0, 0)).thenReturn(Color.BLACK);
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 20);
        RectangleEdge base = RectangleEdge.TOP;
        GradientBarPainter painter = new GradientBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientBarPainter.class.getDeclaredField("g1");
        g1Field.setAccessible(true);
        g1Field.setDouble(painter, 0.25);

        Field g2Field = GradientBarPainter.class.getDeclaredField("g2");
        g2Field.setAccessible(true);
        g2Field.setDouble(painter, 0.5);

        Field g3Field = GradientBarPainter.class.getDeclaredField("g3");
        g3Field.setAccessible(true);
        g3Field.setDouble(painter, 0.75);

        // WHEN
        painter.paintBar(g2, renderer, 0, 0, bar, base);

        // THEN
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2, times(4)).setPaint(paintCaptor.capture());
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(BasicStroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("itemPaint is Color, alpha != 0, base is TOP, isDrawBarOutline is true, outline paint is null")
    public void TC03() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(0, 0)).thenReturn(Color.BLUE);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(0, 0)).thenReturn(new BasicStroke(1.0f));
        when(renderer.getItemOutlinePaint(0, 0)).thenReturn(null);
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 20);
        RectangleEdge base = RectangleEdge.TOP;
        GradientBarPainter painter = new GradientBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientBarPainter.class.getDeclaredField("g1");
        g1Field.setAccessible(true);
        g1Field.setDouble(painter, 0.25);

        Field g2Field = GradientBarPainter.class.getDeclaredField("g2");
        g2Field.setAccessible(true);
        g2Field.setDouble(painter, 0.5);

        Field g3Field = GradientBarPainter.class.getDeclaredField("g3");
        g3Field.setAccessible(true);
        g3Field.setDouble(painter, 0.75);

        // WHEN
        painter.paintBar(g2, renderer, 0, 0, bar, base);

        // THEN
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2, times(4)).setPaint(paintCaptor.capture());
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(BasicStroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("itemPaint is Color, alpha != 0, base is TOP, isDrawBarOutline is false")
    public void TC04() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(0, 0)).thenReturn(Color.BLUE);
        when(renderer.isDrawBarOutline()).thenReturn(false);
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 20);
        RectangleEdge base = RectangleEdge.TOP;
        GradientBarPainter painter = new GradientBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientBarPainter.class.getDeclaredField("g1");
        g1Field.setAccessible(true);
        g1Field.setDouble(painter, 0.25);

        Field g2Field = GradientBarPainter.class.getDeclaredField("g2");
        g2Field.setAccessible(true);
        g2Field.setDouble(painter, 0.5);

        Field g3Field = GradientBarPainter.class.getDeclaredField("g3");
        g3Field.setAccessible(true);
        g3Field.setDouble(painter, 0.75);

        // WHEN
        painter.paintBar(g2, renderer, 0, 0, bar, base);

        // THEN
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2, times(4)).setPaint(paintCaptor.capture());
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(BasicStroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("itemPaint is Color, alpha == 0")
    public void TC05() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(0, 0)).thenReturn(new Color(0, 0, 255, 0));
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 20);
        RectangleEdge base = RectangleEdge.TOP;
        GradientBarPainter painter = new GradientBarPainter();

        // Set private fields g1, g2, g3 via reflection
        Field g1Field = GradientBarPainter.class.getDeclaredField("g1");
        g1Field.setAccessible(true);
        g1Field.setDouble(painter, 0.25);

        Field g2Field = GradientBarPainter.class.getDeclaredField("g2");
        g2Field.setAccessible(true);
        g2Field.setDouble(painter, 0.5);

        Field g3Field = GradientBarPainter.class.getDeclaredField("g3");
        g3Field.setAccessible(true);
        g3Field.setDouble(painter, 0.75);

        // WHEN
        painter.paintBar(g2, renderer, 0, 0, bar, base);

        // THEN
        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(BasicStroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }
}