package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class StackedBarRenderer_drawItem_1_2_Test {

    @Test
    @DisplayName("Draw item with renderAsPercentages=true and loop has one iteration with mixed positive and negative values")
    public void TC28_drawItem_renderAsPercentages_true_one_loop_iteration_mixedValues() throws Exception {
        // Arrange
        StackedBarRenderer renderer = new StackedBarRenderer(true);
        
        // Prepare dataset with one prior row containing mixed positive and negative values
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Series1", "Category1"); // Positive value
        dataset.addValue(-3.0, "Series2", "Category1"); // Negative value
        dataset.addValue(2.0, "Series3", "Category1"); // Current row to test
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        // Configure mocks
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisForDataset(anyInt())).thenReturn(domainAxis);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any())).thenReturn(50.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM)))
            .thenAnswer(invocation -> {
                double value = invocation.getArgument(0);
                return value * 10; // Simple linear transformation for testing
            });
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 0, 1);
        
        // Assert
        // Verify that the bar was drawn with correct accumulated positive and negative percentages
        verify(g2, times(1)).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("Draw item with renderAsPercentages=true and dataset contains both positive and negative values")
    public void TC29_drawItem_renderAsPercentages_true_positiveNegativeValues() throws Exception {
        // Arrange
        StackedBarRenderer renderer = new StackedBarRenderer(true);
        
        // Prepare dataset with multiple rows containing both positive and negative values
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(4.0, "Series1", "Category1");
        dataset.addValue(-2.0, "Series2", "Category1");
        dataset.addValue(3.0, "Series3", "Category1");
        dataset.addValue(-1.0, "Series4", "Category1");
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        // Configure mocks
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisForDataset(anyInt())).thenReturn(domainAxis);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any())).thenReturn(50.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM)))
            .thenAnswer(invocation -> {
                double value = invocation.getArgument(0);
                return value * 10; // Simple linear transformation for testing
            });
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 3, 0, 1);
        
        // Assert
        // Verify that the bar was drawn with correct stacked positive and negative percentages
        verify(g2, times(1)).fill(any(Rectangle2D.class));
    }
}