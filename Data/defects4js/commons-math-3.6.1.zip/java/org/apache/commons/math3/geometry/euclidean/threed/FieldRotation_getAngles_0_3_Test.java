package org.apache.commons.math3.geometry.euclidean.threed;

import org.apache.commons.math3.util.Decimal64;
import org.apache.commons.math3.RealFieldElement;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class FieldRotation_getAngles_0_3_Test {

    @Test
    @DisplayName("getAngles called with RotationOrder.ZYX and RotationConvention.VECTOR_OPERATOR, v2.getX() within bounds")
    public void TC11() throws Exception {
        // Given
        Decimal64 q0 = new Decimal64(1.0);
        Decimal64 q1 = new Decimal64(0.0);
        Decimal64 q2 = new Decimal64(0.0);
        Decimal64 q3 = new Decimal64(0.0);
        FieldRotation<Decimal64> fieldRotation = new FieldRotation<>(q0, q1, q2, q3, false);
        RotationOrder order = RotationOrder.ZYX;
        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;

        // When
        RealFieldElement<?>[] angles = fieldRotation.getAngles(order, convention);

        // Then
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
    }

    @Test
    @DisplayName("getAngles called with RotationOrder.ZYX and RotationConvention.VECTOR_OPERATOR, v2.getX() out of bounds triggering exception")
    public void TC12() throws Exception {
        // Given
        Decimal64 q0 = new Decimal64(1.0);
        Decimal64 q1 = new Decimal64(0.0);
        Decimal64 q2 = new Decimal64(0.0);
        Decimal64 q3 = new Decimal64(0.0);
        FieldRotation<Decimal64> fieldRotation = new FieldRotation<>(q0, q1, q2, q3, false);
        RotationOrder order = RotationOrder.ZYX;
        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;

        // When & Then
        assertThrows(CardanEulerSingularityException.class, () -> {
            fieldRotation.getAngles(order, convention);
        }, "Expected CardanEulerSingularityException to be thrown");
    }

    @Test
    @DisplayName("getAngles called with RotationOrder.XYX and RotationConvention.VECTOR_OPERATOR, v2.getX() within bounds")
    public void TC13() throws Exception {
        // Given
        Decimal64 q0 = new Decimal64(0.7071);
        Decimal64 q1 = new Decimal64(0.7071);
        Decimal64 q2 = new Decimal64(0.0);
        Decimal64 q3 = new Decimal64(0.0);
        FieldRotation<Decimal64> fieldRotation = new FieldRotation<>(q0, q1, q2, q3, false);
        RotationOrder order = RotationOrder.XYX;
        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;

        // When
        RealFieldElement<?>[] angles = fieldRotation.getAngles(order, convention);

        // Then
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
    }

    @Test
    @DisplayName("getAngles called with RotationOrder.XYX and RotationConvention.VECTOR_OPERATOR, v2.getX() out of bounds triggering exception")
    public void TC14() throws Exception {
        // Given
        Decimal64 q0 = new Decimal64(0.0);
        Decimal64 q1 = new Decimal64(1.0);
        Decimal64 q2 = new Decimal64(0.0);
        Decimal64 q3 = new Decimal64(0.0);
        FieldRotation<Decimal64> fieldRotation = new FieldRotation<>(q0, q1, q2, q3, false);
        RotationOrder order = RotationOrder.XYX;
        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;

        // When & Then
        assertThrows(CardanEulerSingularityException.class, () -> {
            fieldRotation.getAngles(order, convention);
        }, "Expected CardanEulerSingularityException to be thrown");
    }

    @Test
    @DisplayName("getAngles called with RotationOrder.XZX and RotationConvention.VECTOR_OPERATOR, v2.getX() within bounds")
    public void TC15() throws Exception {
        // Given
        Decimal64 q0 = new Decimal64(0.8660);
        Decimal64 q1 = new Decimal64(0.5);
        Decimal64 q2 = new Decimal64(0.0);
        Decimal64 q3 = new Decimal64(0.0);
        FieldRotation<Decimal64> fieldRotation = new FieldRotation<>(q0, q1, q2, q3, false);
        RotationOrder order = RotationOrder.XZX;
        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;

        // When
        RealFieldElement<?>[] angles = fieldRotation.getAngles(order, convention);

        // Then
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
    }
}