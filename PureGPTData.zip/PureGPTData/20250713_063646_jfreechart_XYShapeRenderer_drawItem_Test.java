import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

public class XYShapeRendererTest {
    
    private XYShapeRenderer renderer;
    private Graphics2D g2;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private PlotRenderingInfo info;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYShapeRenderer();
        g2 = mock(Graphics2D.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        info = mock(PlotRenderingInfo.class);
        crosshairState = mock(CrosshairState.class);
        
        XYSeries series = new XYSeries(1);
        series.add(1.0, 2.0);
        series.add(Double.NaN, 3.0);
        series.add(3.0, Double.NaN);
        series.add(3.0, 4.0);
        dataset = new XYSeriesCollection(series);
    }
    
    @Test
    void testDrawItemWithValidInputsForPass0WithGuideLinesVisible() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, Rectangle2D.Double.class.cast(null), plot.getDomainAxisEdge())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, Rectangle2D.Double.class.cast(null), plot.getRangeAxisEdge())).thenReturn(200.0);
        renderer.setGuideLinesVisible(true);

        assertDoesNotThrow(() -> renderer.drawItem(g2, null, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
        verify(g2, times(2)).draw(any(Shape.class));
    }

    @Test
    void testDrawItemWithValidInputsForPass1DrawOutlines() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(3.0, Rectangle2D.Double.class.cast(null), plot.getDomainAxisEdge())).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(4.0, Rectangle2D.Double.class.cast(null), plot.getRangeAxisEdge())).thenReturn(400.0);
        renderer.setDrawOutlines(true);

        assertDoesNotThrow(() -> renderer.drawItem(g2, null, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, 3, crosshairState, 1));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItemWithNaNCoordinates() {
        assertDoesNotThrow(() -> renderer.drawItem(g2, null, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0));
        assertDoesNotThrow(() -> renderer.drawItem(g2, null, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, 2, crosshairState, 0));
    }

    @Test
    void testDrawItemWithOrientationHorizontal() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(domainAxis.valueToJava2D(3.0, Rectangle2D.Double.class.cast(null), plot.getDomainAxisEdge())).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(4.0, Rectangle2D.Double.class.cast(null), plot.getRangeAxisEdge())).thenReturn(400.0);

        assertDoesNotThrow(() -> renderer.drawItem(g2, null, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, 3, crosshairState, 1));
        verify(g2, atLeastOnce()).fill(any(Shape.class));
    }

    @Test
    void testDrawItemWithNullInfoShouldNotAddEntity() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(3.0, Rectangle2D.Double.class.cast(null), plot.getDomainAxisEdge())).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(4.0, Rectangle2D.Double.class.cast(null), plot.getRangeAxisEdge())).thenReturn(400.0);

        assertDoesNotThrow(() -> renderer.drawItem(g2, null, new Rectangle2D.Double(), null, plot, domainAxis, rangeAxis, dataset, 0, 3, crosshairState, 1));
    }
}