package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.analysis.polynomials.PolynomialFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer;
import org.apache.commons.math3.fitting.PolynomialFitter;
import org.apache.commons.math3.optim.SimpleVectorValueChecker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SmoothingPolynomialBicubicSplineInterpolatorTest {

    private SmoothingPolynomialBicubicSplineInterpolator interpolator;

    @BeforeEach
    void setUp() {
        interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
    }

    @Test
    void testInterpolate_NullXval_ThrowsNullArgumentException() {
        double[] yval = {1.0, 2.0};
        double[][] fval = {{1.0, 2.0}, {3.0, 4.0}};
        assertThrows(NullArgumentException.class, () -> 
            interpolator.interpolate(null, yval, fval)
        );
    }

    @Test
    void testInterpolate_NullYval_ThrowsNullArgumentException() {
        double[] xval = {1.0, 2.0};
        double[][] fval = {{1.0, 2.0}, {3.0, 4.0}};
        assertThrows(NullArgumentException.class, () -> 
            interpolator.interpolate(xval, null, fval)
        );
    }

    @Test
    void testInterpolate_NullFval_ThrowsNullArgumentException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        assertThrows(NullArgumentException.class, () -> 
            interpolator.interpolate(xval, yval, null)
        );
    }

    @Test
    void testInterpolate_EmptyXval_ThrowsNoDataException() {
        double[] xval = {};
        double[] yval = {1.0, 2.0};
        double[][] fval = {};
        assertThrows(NoDataException.class, () -> 
            interpolator.interpolate(xval, yval, fval)
        );
    }

    @Test
    void testInterpolate_EmptyYval_ThrowsNoDataException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {};
        double[][] fval = {{}};
        assertThrows(NoDataException.class, () -> 
            interpolator.interpolate(xval, yval, fval)
        );
    }

    @Test
    void testInterpolate_EmptyFval_ThrowsNoDataException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {};
        assertThrows(NoDataException.class, () -> 
            interpolator.interpolate(xval, yval, fval)
        );
    }

    @Test
    void testInterpolate_FvalLengthMismatch_ThrowsDimensionMismatchException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0},
            {5.0, 6.0}
        };
        assertThrows(DimensionMismatchException.class, () -> 
            interpolator.interpolate(xval, yval, fval)
        );
    }

    @Test
    void testInterpolate_FvalRowLengthMismatch_ThrowsDimensionMismatchException() {
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0},
            {5.0}
        };
        assertThrows(DimensionMismatchException.class, () -> 
            interpolator.interpolate(xval, yval, fval)
        );
    }

    @Test
    void testInterpolate_XvalNotOrdered_ThrowsNonMonotonicSequenceException() {
        double[] xval = {2.0, 1.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0}
        };
        assertThrows(NonMonotonicSequenceException.class, () -> 
            interpolator.interpolate(xval, yval, fval)
        );
    }

    @Test
    void testInterpolate_YvalNotOrdered_ThrowsNonMonotonicSequenceException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {2.0, 1.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0}
        };
        assertThrows(NonMonotonicSequenceException.class, () -> 
            interpolator.interpolate(xval, yval, fval)
        );
    }

    @Test
    void testInterpolate_ValidInput_ReturnsInterpolatingFunction() {
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[][] fval = {
            {1.0, 2.0, 3.0},
            {2.0, 3.0, 4.0},
            {3.0, 4.0, 5.0}
        };
        assertDoesNotThrow(() -> {
            BicubicSplineInterpolatingFunction function = interpolator.interpolate(xval, yval, fval);
            assertNotNull(function);
            double result = function.value(2.0, 2.0);
            assertEquals(3.0, result, 1e-6);
        });
    }

    @Test
    void testInterpolate_SinglePoint_ReturnsValidFunction() {
        double[] xval = {1.0};
        double[] yval = {1.0};
        double[][] fval = {
            {5.0}
        };
        assertDoesNotThrow(() -> {
            BicubicSplineInterpolatingFunction function = interpolator.interpolate(xval, yval, fval);
            assertNotNull(function);
            double result = function.value(1.0, 1.0);
            assertEquals(5.0, result, 1e-6);
        });
    }

    @Test
    void testInterpolate_TwoPoints_ReturnsValidFunction() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {2.0, 3.0}
        };
        assertDoesNotThrow(() -> {
            BicubicSplineInterpolatingFunction function = interpolator.interpolate(xval, yval, fval);
            assertNotNull(function);
            double result1 = function.value(1.0, 1.0);
            double result2 = function.value(2.0, 2.0);
            assertEquals(1.0, result1, 1e-6);
            assertEquals(3.0, result2, 1e-6);
        });
    }
}