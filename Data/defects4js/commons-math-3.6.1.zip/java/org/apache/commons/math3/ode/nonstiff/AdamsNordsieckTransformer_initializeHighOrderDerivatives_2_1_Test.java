package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AdamsNordsieckTransformer_initializeHighOrderDerivatives_2_1_Test {

    @Test
    @DisplayName("Initialize with h=0, expecting ArithmeticException due to division by zero")
    void testTC24() {
        // Given
        double h = 0.0;
        double[] t = {0.0, 1.0};
        double[][] y = { {1.0, 2.0}, {1.1, 2.1} };
        double[][] yDot = { {0.5, 1.0}, {0.55, 1.05} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(2);

        // When & Then
        assertThrows(ArithmeticException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected ArithmeticException due to division by zero when h is zero");
    }

    @Test
    @DisplayName("Initialize with h=NaN, expecting result matrix with NaN entries")
    void testTC25() {
        // Given
        double h = Double.NaN;
        double[] t = {0.0, 1.0, 2.0};
        double[][] y = { {1.0, 2.0}, {1.1, 2.1}, {1.2, 2.2} };
        double[][] yDot = { {0.5, 1.0}, {0.55, 1.05}, {0.6, 1.1} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(3);

        // When
        Array2DRowRealMatrix result = transformer.initializeHighOrderDerivatives(h, t, y, yDot);

        // Then
        double[][] data = result.getData();
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                assertTrue(Double.isNaN(data[i][j]), "Expected NaN entry at position (" + i + "," + j + ")");
            }
        }
    }
}