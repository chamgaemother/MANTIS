package org.jsoup.select;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeFilter.FilterResult;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NodeTraversor_filter_0_3_Test {

    @Test
    @DisplayName("filter handles SKIP_CHILDREN during tail processing")
    void TC11_filter_handles_SKIP_CHILDREN_during_tail_processing() throws Exception {
        // GIVEN
        Node root = createNodeWithSkipChildrenTail();
        NodeFilter filter = new SkipChildrenDuringTailFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(FilterResult.CONTINUE, result);
    }

    @Test
    @DisplayName("filter handles REMOVE during tail processing with multiple siblings")
    void TC12_filter_handles_REMOVE_during_tail_processing_with_multiple_siblings() throws Exception {
        // GIVEN
        Node root = createNodeWithMultipleSiblings();
        NodeFilter filter = new RemoveSiblingDuringTailFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertNull(root.nextSibling(), "Node should be removed and have no next sibling.");
        assertEquals(FilterResult.CONTINUE, result);
    }

    @Test
    @DisplayName("filter continues processing when no more nodes to traverse")
    void TC13_filter_continues_processing_when_no_more_nodes_to_traverse() throws Exception {
        // GIVEN
        Node root = createCompleteTraversalNode();
        NodeFilter filter = new ContinueUntilEndFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(FilterResult.CONTINUE, result);
    }

    @Test
    @DisplayName("filter handles REMOVE when root has no siblings")
    void TC14_filter_handles_REMOVE_when_root_has_no_siblings() throws Exception {
        // GIVEN
        Node root = createRootWithNoSiblings();
        NodeFilter filter = new RemoveRootFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertNull(root.parentNode(), "Root node should have no parent and thus removed.");
        assertEquals(FilterResult.CONTINUE, result);
    }

    // Helper methods to create Nodes and Filters for tests
    private Node createNodeWithSkipChildrenTail() {
        Element root = new Element("div");
        root.appendChild(new Element("span"));
        return root;
    }

    private Node createNodeWithMultipleSiblings() {
        Element root = new Element("div");
        root.appendChild(new Element("span"));
        root.appendChild(new Element("p"));
        return root.childNode(0);
    }

    private Node createCompleteTraversalNode() {
        Element root = new Element("ul");
        root.appendChild(new Element("li"));
        root.appendChild(new Element("li"));
        return root;
    }

    private Node createRootWithNoSiblings() {
        return new Element("section");
    }

    private static class SkipChildrenDuringTailFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.CONTINUE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.SKIP_CHILDREN;
        }
    }

    private static class RemoveSiblingDuringTailFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.CONTINUE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.REMOVE;
        }
    }

    private static class ContinueUntilEndFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.CONTINUE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.CONTINUE;
        }
    }

    private static class RemoveRootFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.REMOVE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.CONTINUE;
        }
    }
}