package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.awt.image.ImageObserver;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer.State;
import org.jfree.chart.plot.CrosshairState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class StandardXYItemRenderer_drawItem_0_4_Test {
    
    @Test
    @DisplayName("drawItem with getImage returning null")
    public void testTC16_drawItem_withGetImageReturningNull() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = new CrosshairState();
        int series = 0;
        int item = 0;
        int pass = 0;
        
        // Mock behaviors
        when(renderer.getImage(eq(plot), eq(series), eq(item), anyDouble(), anyDouble())).thenReturn(null);
        when(renderer.getPlotImages()).thenReturn(true);
        when(renderer.getItemVisible(eq(series), eq(item))).thenReturn(true);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        // Verify that no image is drawn since getImage returns null
        verify(g2, never()).drawImage(any(), anyInt(), anyInt(), any(ImageObserver.class));
        // Additional assertions can be added here to verify fallback behavior
    }
    
    @Test
    @DisplayName("drawItem with CrosshairState updates correctly")
    public void testTC17_drawItem_withCrosshairStateUpdatesCorrectly() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = new CrosshairState();
        int series = 0;
        int item = 1;
        int pass = 0;
        
        // Mock behaviors
        when(renderer.getItemVisible(eq(series), eq(item))).thenReturn(true);
        when(dataset.getXValue(eq(series), eq(item))).thenReturn(10.0);
        when(dataset.getYValue(eq(series), eq(item))).thenReturn(20.0);
        when(domainAxis.valueToJava2D(eq(10.0), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(eq(20.0), eq(dataArea), any())).thenReturn(200.0);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        // Verify that CrosshairState is updated correctly
        assertEquals(10.0, crosshairState.getCrosshairX(), 0.001);
        assertEquals(20.0, crosshairState.getCrosshairY(), 0.001);
    }
    
    @Test
    @DisplayName("drawItem with Shape not intersecting dataArea")
    public void testTC18_drawItem_withShapeNotIntersectingDataArea() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = new CrosshairState();
        int series = 0;
        int item = 2;
        int pass = 0;
        
        // Mock behaviors
        when(renderer.getItemVisible(eq(series), eq(item))).thenReturn(true);
        when(dataset.getXValue(eq(series), eq(item))).thenReturn(30.0);
        when(dataset.getYValue(eq(series), eq(item))).thenReturn(40.0);
        when(domainAxis.valueToJava2D(eq(30.0), eq(dataArea), any())).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(eq(40.0), eq(dataArea), any())).thenReturn(400.0);
        when(renderer.getItemShape(eq(series), eq(item))).thenReturn(mock(Shape.class));
        
        // Assume the shape does not intersect dataArea
        Shape shape = mock(Shape.class);
        when(shape.intersects(eq(dataArea))).thenReturn(false);
        when(renderer.getItemShape(eq(series), eq(item))).thenReturn(shape);
        when(renderer.getBaseShapesVisible()).thenReturn(true);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        // Verify that the shape is not drawn
        verify(g2, never()).draw(any(Shape.class));
        verify(g2, never()).fill(any(Shape.class));
    }
}