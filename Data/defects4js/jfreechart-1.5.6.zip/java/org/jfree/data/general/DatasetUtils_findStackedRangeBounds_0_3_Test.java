package org.jfree.data.general;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.Range;

public class DatasetUtils_findStackedRangeBounds_0_3_Test {

    @Test
    @DisplayName("Handles dataset with maximum integer values to test boundary conditions")
    public void testTC11() {
        // Given
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Integer.MAX_VALUE, "Row1", "Column1");
        dataset.addValue(Integer.MIN_VALUE, "Row1", "Column2");
        dataset.addValue(Integer.MAX_VALUE, "Row2", "Column1");
        dataset.addValue(Integer.MIN_VALUE, "Row2", "Column2");

        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Row1", "Group1");
        map.mapKeyToGroup("Row2", "Group2");

        // When
        Range result = DatasetUtils.findStackedRangeBounds(dataset, map);

        // Then
        Range expected = new Range((double) Integer.MIN_VALUE, (double) Integer.MAX_VALUE);
        Assertions.assertEquals(expected, result, "Range should correctly calculate without overflow.");
    }

    @Test
    @DisplayName("Handles dataset with varying group assignments")
    public void testTC12() {
        // Given
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10.0, "Row1", "Column1");
        dataset.addValue(20.0, "Row1", "Column2");
        dataset.addValue(30.0, "Row2", "Column1");
        dataset.addValue(40.0, "Row2", "Column2");
        dataset.addValue(50.0, "Row3", "Column1");
        dataset.addValue(60.0, "Row3", "Column2");
        dataset.addValue(70.0, "Row4", "Column1");
        dataset.addValue(80.0, "Row4", "Column2");

        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Row1", "GroupA");
        map.mapKeyToGroup("Row2", "GroupB");
        map.mapKeyToGroup("Row3", "GroupA");
        map.mapKeyToGroup("Row4", "GroupB");

        // When
        Range result = DatasetUtils.findStackedRangeBounds(dataset, map);

        // Then
        // Calculate expected min and max based on group assignments
        // GroupA: Row1 (10.0) + Row3 (50.0) = 60.0
        // GroupB: Row2 (30.0) + Row4 (70.0) = 100.0
        Range expected = new Range(60.0, 100.0);
        Assertions.assertEquals(expected, result, "Range should correctly aggregate based on dynamic group assignments.");
    }
}