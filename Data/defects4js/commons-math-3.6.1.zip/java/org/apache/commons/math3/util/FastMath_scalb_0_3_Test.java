package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FastMath_scalb_0_3_Test {

    @Test
    @DisplayName("scalb with n causing scaledExponent to be positive after scaling and d is a normal number")
    void TC11_scalb_scaledExponentRemainsPositive() throws Exception {
        // GIVEN
        double d = 2.0;
        int n = 500;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        // Calculate expected value using Math.scalb for verification
        double expected = Math.scalb(d, n);
        assertEquals(expected, result, "The scaled value should match the expected result.");
    }

    @Test
    @DisplayName("scalb with n causing scaledExponent to result in a subnormal number and d is a normal number")
    void TC12_scalb_scaledExponentLeadsToSubnormal() throws Exception {
        // GIVEN
        double d = 1.0;
        int n = -1000;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "Result should be a finite subnormal number.");
        assertTrue(Double.doubleToRawLongBits(result) < Double.MIN_NORMAL, "Result should be a subnormal number.");
    }

    @Test
    @DisplayName("scalb with d as a subnormal number and n normalizes it")
    void TC13_scalb_normalizeSubnormalToInfinity() throws Exception {
        // GIVEN
        double d = Double.longBitsToDouble(0x0008000000000000L); // smallest subnormal
        int n = 2047;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be normalized to positive infinity.");
    }

    @Test
    @DisplayName("scalb with d as a subnormal number and n does not normalize it")
    void TC14_scalb_normalizeSubnormalWithoutOverflow() throws Exception {
        // GIVEN
        double d = Double.longBitsToDouble(0x0008000000000000L); // smallest subnormal
        int n = 100;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "Result should still be a finite subnormal number.");
        assertTrue(Double.doubleToRawLongBits(result) < Double.MIN_NORMAL, "Result should remain a subnormal number.");
    }

    @Test
    @DisplayName("scalb with d as a normal number and n causing scaledExponent to overflow to Infinity")
    void TC15_scalb_exponentOverflowToInfinity() throws Exception {
        // GIVEN
        double d = 5.0;
        int n = 3000;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be positive infinity due to exponent overflow.");
    }

}