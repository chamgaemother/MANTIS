package org.apache.commons.compress.compressors.gzip;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.charset.Charset;
import java.time.Instant;

import org.apache.commons.compress.compressors.gzip.GzipParameters.OS;
import org.junit.jupiter.api.Test;

class GzipParametersTest {

    @Test
    void testEquals_SameObject() {
        GzipParameters params = new GzipParameters();
        assertTrue(params.equals(params));
    }

    @Test
    void testEquals_NullObject() {
        GzipParameters params = new GzipParameters();
        assertFalse(params.equals(null));
    }

    @Test
    void testEquals_DifferentClass() {
        GzipParameters params = new GzipParameters();
        String other = "Not a GzipParameters instance";
        assertFalse(params.equals(other));
    }

    @Test
    void testEquals_AllFieldsEqual() {
        GzipParameters params1 = new GzipParameters();
        params1.setBufferSize(1024);
        params1.setComment("Test Comment");
        params1.setCompressionLevel(5);
        params1.setDeflateStrategy(Deflater.DEFAULT_STRATEGY);
        params1.setExtraField(new ExtraField());
        params1.setFileName("test.txt");
        params1.setFileNameCharset(Charset.forName("UTF-8"));
        params1.setHeaderCRC(true);
        params1.setModificationInstant(Instant.now());
        params1.setOS(OS.UNIX);
        params1.setTrailerCrc(123456789L);
        params1.setTrailerISize(987654321L);

        GzipParameters params2 = new GzipParameters();
        params2.setBufferSize(1024);
        params2.setComment("Test Comment");
        params2.setCompressionLevel(5);
        params2.setDeflateStrategy(Deflater.DEFAULT_STRATEGY);
        params2.setExtraField(new ExtraField());
        params2.setFileName("test.txt");
        params2.setFileNameCharset(Charset.forName("UTF-8"));
        params2.setHeaderCRC(true);
        params2.setModificationInstant(params1.getModificationInstant());
        params2.setOS(OS.UNIX);
        params2.setTrailerCrc(123456789L);
        params2.setTrailerISize(987654321L);

        assertTrue(params1.equals(params2));
        assertTrue(params2.equals(params1));
    }

    @Test
    void testEquals_DifferentBufferSize() {
        GzipParameters params1 = new GzipParameters();
        params1.setBufferSize(1024);

        GzipParameters params2 = new GzipParameters();
        params2.setBufferSize(2048);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentComment_BothNonNull() {
        GzipParameters params1 = new GzipParameters();
        params1.setComment("Comment1");

        GzipParameters params2 = new GzipParameters();
        params2.setComment("Comment2");

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentComment_OneNull() {
        GzipParameters params1 = new GzipParameters();
        params1.setComment(null);

        GzipParameters params2 = new GzipParameters();
        params2.setComment("Comment");

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentCompressionLevel() {
        GzipParameters params1 = new GzipParameters();
        params1.setCompressionLevel(5);

        GzipParameters params2 = new GzipParameters();
        params2.setCompressionLevel(6);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentDeflateStrategy() {
        GzipParameters params1 = new GzipParameters();
        params1.setDeflateStrategy(Deflater.DEFAULT_STRATEGY);

        GzipParameters params2 = new GzipParameters();
        params2.setDeflateStrategy(Deflater.FULL_FLUSH);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentExtraField_BothNonNull() {
        GzipParameters params1 = new GzipParameters();
        params1.setExtraField(new ExtraField());

        GzipParameters params2 = new GzipParameters();
        params2.setExtraField(new ExtraField());

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentExtraField_OneNull() {
        GzipParameters params1 = new GzipParameters();
        params1.setExtraField(null);

        GzipParameters params2 = new GzipParameters();
        params2.setExtraField(new ExtraField());

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentFileName_BothNonNull() {
        GzipParameters params1 = new GzipParameters();
        params1.setFileName("file1.txt");

        GzipParameters params2 = new GzipParameters();
        params2.setFileName("file2.txt");

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentFileName_OneNull() {
        GzipParameters params1 = new GzipParameters();
        params1.setFileName(null);

        GzipParameters params2 = new GzipParameters();
        params2.setFileName("file.txt");

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentFileNameCharset() {
        GzipParameters params1 = new GzipParameters();
        params1.setFileNameCharset(Charset.forName("UTF-8"));

        GzipParameters params2 = new GzipParameters();
        params2.setFileNameCharset(Charset.forName("ISO-8859-1"));

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentHeaderCrc() {
        GzipParameters params1 = new GzipParameters();
        params1.setHeaderCRC(true);

        GzipParameters params2 = new GzipParameters();
        params2.setHeaderCRC(false);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentModificationInstant() {
        GzipParameters params1 = new GzipParameters();
        params1.setModificationInstant(Instant.now());

        GzipParameters params2 = new GzipParameters();
        params2.setModificationInstant(Instant.EPOCH);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentOperatingSystem() {
        GzipParameters params1 = new GzipParameters();
        params1.setOS(OS.UNIX);

        GzipParameters params2 = new GzipParameters();
        params2.setOS(OS.WINDOWS);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentTrailerCrc() {
        GzipParameters params1 = new GzipParameters();
        params1.setTrailerCrc(123456789L);

        GzipParameters params2 = new GzipParameters();
        params2.setTrailerCrc(987654321L);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_DifferentTrailerISize() {
        GzipParameters params1 = new GzipParameters();
        params1.setTrailerISize(123456789L);

        GzipParameters params2 = new GzipParameters();
        params2.setTrailerISize(987654321L);

        assertFalse(params1.equals(params2));
    }

    @Test
    void testEquals_AllFieldsEqualWithNulls() {
        GzipParameters params1 = new GzipParameters();
        params1.setComment(null);
        params1.setExtraField(null);
        params1.setFileName(null);
        params1.setFileNameCharset(null);
        params1.setModificationInstant(null);

        GzipParameters params2 = new GzipParameters();
        params2.setComment(null);
        params2.setExtraField(null);
        params2.setFileName(null);
        params2.setFileNameCharset(null);
        params2.setModificationInstant(null);

        assertTrue(params1.equals(params2));
    }

    @Test
    void testEquals_OtherIsGzipParametersButFieldsAreDifferentDueToSubclass() {
        GzipParameters params1 = new GzipParameters();
        GzipParameters params2 = new GzipParameters() {
            // Anonymous subclass
        };
        assertFalse(params1.equals(params2));
    }
}