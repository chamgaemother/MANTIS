package org.apache.commons.lang3.math;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;
import java.math.BigInteger;

public class NumberUtils_createNumber_0_1_Test {

    @Test
    @DisplayName("Input string is null, should return null")
    void TC01_createNumber_nullInput() {
        String input = null;
        Number result = NumberUtils.createNumber(input);
        assertNull(result);
    }

    @Test
    @DisplayName("Input string is blank, should throw NumberFormatException")
    void TC02_createNumber_blankInput() {
        String input = "   ";
        NumberFormatException exception = assertThrows(NumberFormatException.class, () -> {
            NumberUtils.createNumber(input);
        });
        assertEquals("A blank string is not a valid number", exception.getMessage());
    }

    @Test
    @DisplayName("Hexadecimal input with prefix '0x' and hexDigits > 16, should return BigInteger")
    void TC03_createNumber_hexPrefix0xLarge() {
        String input = "0x123456789ABCDEF123456789ABCDEF";
        Number result = NumberUtils.createNumber(input);
        assertTrue(result instanceof BigInteger);
    }

    @Test
    @DisplayName("Hexadecimal input with prefix '0X' and hexDigits == 16 with firstSigDigit > '7', should return BigInteger")
    void TC04_createNumber_hexPrefix0X16Digits() {
        String input = "0X8000000000000000";
        Number result = NumberUtils.createNumber(input);
        assertTrue(result instanceof BigInteger);
    }

    @Test
    @DisplayName("Hexadecimal input with prefix '#', hexDigits > 8, should return Long")
    void TC05_createNumber_hexPrefixHashLong() {
        String input = "#123456789";
        Number result = NumberUtils.createNumber(input);
        assertTrue(result instanceof Long);
    }

}