package org.apache.commons.collections4.functors;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.collections4.functors.ComparatorPredicate;
import org.apache.commons.collections4.functors.ComparatorPredicate.Criterion;
import org.mockito.Mockito;

public class ComparatorPredicate_test_0_1_Test {

    @Test
    @DisplayName("Criterion EQUAL with comparison result zero")
    void TC01() throws Exception {
        // GIVEN
        Criterion criterion = Criterion.EQUAL;
        Comparator<Object> comparator = Mockito.mock(Comparator.class);
        Object object = new Object();
        Object target = new Object();
        when(comparator.compare(object, target)).thenReturn(0);
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(object, comparator, criterion);

        // WHEN
        boolean result = predicate.test(target);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("Criterion EQUAL with comparison result non-zero")
    void TC02() throws Exception {
        // GIVEN
        Criterion criterion = Criterion.EQUAL;
        Comparator<Object> comparator = Mockito.mock(Comparator.class);
        Object object = new Object();
        Object target = new Object();
        when(comparator.compare(object, target)).thenReturn(1);
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(object, comparator, criterion);

        // WHEN
        boolean result = predicate.test(target);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Criterion GREATER with comparison result positive")
    void TC03() throws Exception {
        // GIVEN
        Criterion criterion = Criterion.GREATER;
        Comparator<Object> comparator = Mockito.mock(Comparator.class);
        Object object = new Object();
        Object target = new Object();
        when(comparator.compare(object, target)).thenReturn(1);
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(object, comparator, criterion);

        // WHEN
        boolean result = predicate.test(target);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("Criterion GREATER with comparison result non-positive")
    void TC04() throws Exception {
        // GIVEN
        Criterion criterion = Criterion.GREATER;
        Comparator<Object> comparator = Mockito.mock(Comparator.class);
        Object object = new Object();
        Object target = new Object();
        when(comparator.compare(object, target)).thenReturn(0);
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(object, comparator, criterion);

        // WHEN
        boolean result = predicate.test(target);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Criterion LESS with comparison result negative")
    void TC05() throws Exception {
        // GIVEN
        Criterion criterion = Criterion.LESS;
        Comparator<Object> comparator = Mockito.mock(Comparator.class);
        Object object = new Object();
        Object target = new Object();
        when(comparator.compare(object, target)).thenReturn(-1);
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(object, comparator, criterion);

        // WHEN
        boolean result = predicate.test(target);

        // THEN
        assertTrue(result);
    }
}