package com.fasterxml.jackson.dataformat.xml.deser;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import javax.xml.stream.XMLStreamReader;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

public class FromXmlParser_nextToken_0_1_Test {

    private FromXmlParser createParser(JsonToken initialToken) throws Exception {
        IOContext ioContext = mock(IOContext.class);
        ObjectCodec codec = null;
        XMLStreamReader xmlReader = null;
        com.fasterxml.jackson.dataformat.xml.XmlNameProcessor tagProcessor = null;

        FromXmlParser parser = new FromXmlParser(ioContext, 0, 0, codec, xmlReader, tagProcessor);
        // Set private field _nextToken to the initialToken
        Field nextTokenField = FromXmlParser.class.getDeclaredField("_nextToken");
        nextTokenField.setAccessible(true);
        nextTokenField.set(parser, initialToken);
        return parser;
    }

    @Test
    @DisplayName("nextToken returns START_OBJECT when _nextToken is not null and token is START_OBJECT")
    void TC01_nextToken_Returns_START_OBJECT() throws Exception {
        // Arrange
        FromXmlParser parser = createParser(JsonToken.START_OBJECT);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.START_OBJECT, result);
    }

    @Test
    @DisplayName("nextToken returns START_ARRAY when _nextToken is not null and token is START_ARRAY")
    void TC02_nextToken_Returns_START_ARRAY() throws Exception {
        // Arrange
        FromXmlParser parser = createParser(JsonToken.START_ARRAY);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.START_ARRAY, result);
    }

    @Test
    @DisplayName("nextToken returns END_OBJECT when _nextToken is END_OBJECT")
    void TC03_nextToken_Returns_END_OBJECT() throws Exception {
        // Arrange
        FromXmlParser parser = createParser(JsonToken.END_OBJECT);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.END_OBJECT, result);
    }

    @Test
    @DisplayName("nextToken handles FIELD_NAME without leading mixed content")
    void TC04_nextToken_FieldName_NoLeadingMixed() throws Exception {
        // Arrange
        FromXmlParser parser = createParser(JsonToken.FIELD_NAME);

        // Set private field _nextIsLeadingMixed to false
        Field nextIsLeadingMixedField = FromXmlParser.class.getDeclaredField("_nextIsLeadingMixed");
        nextIsLeadingMixedField.setAccessible(true);
        nextIsLeadingMixedField.setBoolean(parser, false);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.VALUE_STRING, result);

        // Verify that current name is set
        Field parsingContextField = FromXmlParser.class.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        Object parsingContext = parsingContextField.get(parser);

        Field currentNameField = parsingContext.getClass().getDeclaredField("_currentName");
        currentNameField.setAccessible(true);
        String currentName = (String) currentNameField.get(parsingContext);

        assertNotNull(currentName, "Current name should be set");
    }

    @Test
    @DisplayName("nextToken handles FIELD_NAME with leading mixed content")
    void TC05_nextToken_FieldName_WithLeadingMixed() throws Exception {
        // Arrange
        FromXmlParser parser = createParser(JsonToken.FIELD_NAME);

        // Set private field _nextIsLeadingMixed to true
        Field nextIsLeadingMixedField = FromXmlParser.class.getDeclaredField("_nextIsLeadingMixed");
        nextIsLeadingMixedField.setAccessible(true);
        nextIsLeadingMixedField.setBoolean(parser, true);

        // Act
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.VALUE_STRING, result);

        // Verify that _nextIsLeadingMixed is set to false
        boolean isNextIsLeadingMixed = nextIsLeadingMixedField.getBoolean(parser);
        assertFalse(isNextIsLeadingMixed, "_nextIsLeadingMixed should be false after handling mixed content");
    }
}