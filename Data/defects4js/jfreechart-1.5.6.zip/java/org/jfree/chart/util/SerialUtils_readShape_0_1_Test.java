package org.jfree.chart.util;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.awt.Shape;
import java.awt.geom.*;

public class SerialUtils_readShape_0_1_Test {

    @Test
    @DisplayName("readShape throws IllegalArgumentException when stream is null")
    void TC01() {
        // Arrange
        ObjectInputStream stream = null;

        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            SerialUtils.readShape(stream);
        });

        assertEquals("Null 'stream' argument.", exception.getMessage());
    }

    @Test
    @DisplayName("readShape returns null when isNull is true")
    void TC02() throws Exception {
        // Arrange
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(true);

        // Act
        Shape result = SerialUtils.readShape(stream);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("readShape successfully reads and returns Line2D object")
    void TC03() throws Exception {
        // Arrange
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(false);
        when(stream.readObject()).thenReturn(Line2D.class);
        when(stream.readDouble()).thenReturn(10.0, 20.0, 30.0, 40.0);

        // Act
        Shape result = SerialUtils.readShape(stream);

        // Assert
        assertTrue(result instanceof Line2D.Double);
        Line2D line = (Line2D) result;
        assertEquals(10.0, line.getX1());
        assertEquals(20.0, line.getY1());
        assertEquals(30.0, line.getX2());
        assertEquals(40.0, line.getY2());
    }

    @Test
    @DisplayName("readShape successfully reads and returns Rectangle2D object")
    void TC04() throws Exception {
        // Arrange
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(false);
        when(stream.readObject()).thenReturn(Rectangle2D.class);
        when(stream.readDouble()).thenReturn(10.0, 20.0, 30.0, 40.0);

        // Act
        Shape result = SerialUtils.readShape(stream);

        // Assert
        assertTrue(result instanceof Rectangle2D.Double);
        Rectangle2D rect = (Rectangle2D) result;
        assertEquals(10.0, rect.getX());
        assertEquals(20.0, rect.getY());
        assertEquals(30.0, rect.getWidth());
        assertEquals(40.0, rect.getHeight());
    }

    @Test
    @DisplayName("readShape successfully reads and returns Ellipse2D object")
    void TC05() throws Exception {
        // Arrange
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(false);
        when(stream.readObject()).thenReturn(Ellipse2D.class);
        when(stream.readDouble()).thenReturn(15.0, 25.0, 35.0, 45.0);

        // Act
        Shape result = SerialUtils.readShape(stream);

        // Assert
        assertTrue(result instanceof Ellipse2D.Double);
        Ellipse2D ellipse = (Ellipse2D) result;
        assertEquals(15.0, ellipse.getX());
        assertEquals(25.0, ellipse.getY());
        assertEquals(35.0, ellipse.getWidth());
        assertEquals(45.0, ellipse.getHeight());
    }
}