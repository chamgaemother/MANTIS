package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FastMathTest {

    @Test
    public void testAtan2_NaNInputs() {
        assertTrue(Double.isNaN(FastMath.atan2(Double.NaN, 1.0)));
        assertTrue(Double.isNaN(FastMath.atan2(1.0, Double.NaN)));
        assertTrue(Double.isNaN(FastMath.atan2(Double.NaN, Double.NaN)));
    }

    @Test
    public void testAtan2_InfiniteY_PositiveX() {
        assertEquals(Math.PI / 4, FastMath.atan2(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteY_NegativeX() {
        assertEquals(3 * Math.PI / 4, FastMath.atan2(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteY_FiniteX_Positive() {
        assertEquals(Math.PI / 2, FastMath.atan2(Double.POSITIVE_INFINITY, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteY_FiniteX_Negative() {
        assertEquals(Math.PI / 2, FastMath.atan2(Double.POSITIVE_INFINITY, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteY_XZero_Positive() {
        assertEquals(Math.PI / 2, FastMath.atan2(Double.POSITIVE_INFINITY, 0.0), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteY_XZero_Negative() {
        assertEquals(Math.PI / 2, FastMath.atan2(Double.POSITIVE_INFINITY, -0.0), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteNegativeY_PositiveX() {
        assertEquals(-Math.PI / 4, FastMath.atan2(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteNegativeY_NegativeX() {
        assertEquals(-3 * Math.PI / 4, FastMath.atan2(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteNegativeY_FiniteX_Positive() {
        assertEquals(-Math.PI / 2, FastMath.atan2(Double.NEGATIVE_INFINITY, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteNegativeY_FiniteX_Negative() {
        assertEquals(-Math.PI / 2, FastMath.atan2(Double.NEGATIVE_INFINITY, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteNegativeY_XZero_Positive() {
        assertEquals(-Math.PI / 2, FastMath.atan2(Double.NEGATIVE_INFINITY, 0.0), 1e-15);
    }

    @Test
    public void testAtan2_InfiniteNegativeY_XZero_Negative() {
        assertEquals(-Math.PI / 2, FastMath.atan2(Double.NEGATIVE_INFINITY, -0.0), 1e-15);
    }

    @Test
    public void testAtan2_YZero_PositiveX() {
        assertEquals(0.0, FastMath.atan2(0.0, 1.0), 1e-15);
        assertEquals(-0.0, FastMath.atan2(-0.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_YZero_NegativeX() {
        assertEquals(Math.PI, FastMath.atan2(0.0, -1.0), 1e-15);
        assertEquals(-Math.PI, FastMath.atan2(-0.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_YZero_XZero() {
        assertTrue(Double.isNaN(FastMath.atan2(0.0, 0.0)));
        assertTrue(Double.isNaN(FastMath.atan2(-0.0, 0.0)));
    }

    @Test
    public void testAtan2_YNegative_PositiveX() {
        assertEquals(-Math.atan(1.0), FastMath.atan2(-1.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_YNegative_NegativeX() {
        assertEquals(-3 * Math.PI / 4, FastMath.atan2(-1.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_YPositive_PositiveX() {
        assertEquals(Math.atan(1.0), FastMath.atan2(1.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_YPositive_NegativeX() {
        assertEquals(3 * Math.PI / 4, FastMath.atan2(1.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_FiniteY_Positive() {
        assertEquals(Math.atan(2.0), FastMath.atan2(2.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_FiniteY_Negative() {
        assertEquals(-Math.atan(2.0), FastMath.atan2(-2.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_PositiveSmallY() {
        assertEquals(Math.atan(1e-10), FastMath.atan2(1e-10, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_NegativeSmallY() {
        assertEquals(-Math.atan(1e-10), FastMath.atan2(-1e-10, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_YEqualsX() {
        double expected = Math.PI / 4;
        assertEquals(expected, FastMath.atan2(1.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_YEqualsMinusX() {
        double expected = -Math.PI / 4;
        assertEquals(expected, FastMath.atan2(-1.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_YGreaterThanX() {
        double y = 2.0;
        double x = 1.0;
        assertEquals(Math.atan(y / x), FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_YLessThanX() {
        double y = 0.5;
        double x = 1.0;
        assertEquals(Math.atan(y / x), FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_YZero_Positive() {
        assertEquals(0.0, FastMath.atan2(0.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_YZero_Negative() {
        assertEquals(Math.PI, FastMath.atan2(0.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_YInfinite() {
        assertEquals(Math.PI / 2, FastMath.atan2(Double.POSITIVE_INFINITY, 1.0), 1e-15);
        assertEquals(-Math.PI / 2, FastMath.atan2(Double.NEGATIVE_INFINITY, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteX_XInfinite() {
        assertEquals(0.0, FastMath.atan2(1.0, Double.POSITIVE_INFINITY), 1e-15);
        assertEquals(Double.NaN, FastMath.atan2(1.0, Double.NaN), 1e-15);
    }

    @Test
    public void testAtan2_YNegative_XInfinite() {
        assertEquals(-Math.PI / 4, FastMath.atan2(-1.0, Double.POSITIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_YPositive_XInfinite() {
        assertEquals(Math.PI / 4, FastMath.atan2(1.0, Double.POSITIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_BothNegativeInfinite() {
        assertEquals(-3 * Math.PI / 4, FastMath.atan2(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_BothPositiveInfinite() {
        assertEquals(Math.PI / 4, FastMath.atan2(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2_YLessThanX_Positive() {
        double y = 1.0;
        double x = 2.0;
        assertEquals(Math.atan(y / x), FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_YGreaterThanX_Negative() {
        double y = -2.0;
        double x = -1.0;
        assertEquals(-Math.atan(y / x) + Math.PI, FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_YEqualsX_Positive() {
        double y = 1.0;
        double x = 1.0;
        assertEquals(Math.PI / 4, FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_YEqualsNegativeX_Negative() {
        double y = -1.0;
        double x = 1.0;
        assertEquals(-Math.PI / 4, FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_YZero_PositiveX() {
        assertEquals(0.0, FastMath.atan2(0.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2_YZero_NegativeX_PositiveZero() {
        assertEquals(Math.PI, FastMath.atan2(0.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_YZero_NegativeX_NegativeZero() {
        assertEquals(-Math.PI, FastMath.atan2(-0.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_FiniteNumbers() {
        assertEquals(Math.atan2(1.0, 1.0), FastMath.atan2(1.0, 1.0), 1e-15);
        assertEquals(Math.atan2(-1.0, 1.0), FastMath.atan2(-1.0, 1.0), 1e-15);
        assertEquals(Math.atan2(1.0, -1.0), FastMath.atan2(1.0, -1.0), 1e-15);
        assertEquals(Math.atan2(-1.0, -1.0), FastMath.atan2(-1.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_NormalCases() {
        assertEquals(Math.atan2(2.0, 1.0), FastMath.atan2(2.0, 1.0), 1e-15);
        assertEquals(Math.atan2(-2.0, 1.0), FastMath.atan2(-2.0, 1.0), 1e-15);
        assertEquals(Math.atan2(2.0, -1.0), FastMath.atan2(2.0, -1.0), 1e-15);
        assertEquals(Math.atan2(-2.0, -1.0), FastMath.atan2(-2.0, -1.0), 1e-15);
    }

    @Test
    public void testAtan2_SmallY_FiniteX() {
        double y = 1e-10;
        double x = 1.0;
        assertEquals(Math.atan(y / x), FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_LargeY_FiniteX() {
        double y = 1e308;
        double x = 1.0;
        assertEquals(Math.PI / 2, FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_SmallX_LargeY() {
        double y = 1.0;
        double x = 1e-10;
        assertEquals(Math.PI / 2, FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_RatioOne() {
        double y = 1.0;
        double x = 1.0;
        assertEquals(Math.PI / 4, FastMath.atan2(y, x), 1e-15);
    }

    @Test
    public void testAtan2_RatioMinusOne() {
        double y = -1.0;
        double x = 1.0;
        assertEquals(-Math.PI / 4, FastMath.atan2(y, x), 1e-15);
    }
}