package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Generated JUnit 5 test class for Flat3Map.put method.
 */
public class Flat3Map_put_0_3_Test {

    // Helper method to set private fields via reflection
    private void setField(Flat3Map map, String fieldName, Object value) throws Exception {
        Field field = Flat3Map.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(map, value);
    }

    // Helper method to get private fields via reflection
    private Object getField(Flat3Map map, String fieldName) throws Exception {
        Field field = Flat3Map.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(map);
    }

    @Test
    @DisplayName("put when delegateMap is null and key is null with size 3 and key3 is not null adds new mapping")
    public void TC11_put_nullKey_size3_key3NotNull_addsNewMapping() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        setField(map, "size", 3);
        setField(map, "key1", "key1");
        setField(map, "key2", "key2");
        setField(map, "key3", "key3");
        setField(map, "delegateMap", null);
        Object key = null;
        Object value = "valueNull";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Since Flat3Map only supports 3 entries, adding a fourth should convert to delegateMap
        // Therefore, key4 and value4 do not exist. Instead, delegateMap should be used.
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        AbstractHashedMap delegateMap = (AbstractHashedMap) delegateMapField.get(map);
        assertNotNull(delegateMap, "delegateMap should not be null after adding beyond capacity");
        assertEquals(null, result, "Result should be null when adding a new key to delegateMap");
        assertEquals(4, getField(map, "size"), "Size should be incremented to 4");
        assertTrue(delegateMap.containsKey(key), "delegateMap should contain the new null key");
        assertEquals(value, delegateMap.get(key), "delegateMap should contain the new value");
    }

    @Test
    @DisplayName("put with null key when size exceeds maximum triggers delegateMap conversion")
    public void TC12_put_nullKey_sizeExceeds_maximum_triggersDelegateMap() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        setField(map, "size", 3);
        setField(map, "key1", "key1");
        setField(map, "key2", "key2");
        setField(map, "key3", "key3");
        setField(map, "delegateMap", null);
        Object key = null;
        Object value = "valueNullNew";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        Field convertToMapMethod = Flat3Map.class.getDeclaredField("delegateMap");
        convertToMapMethod.setAccessible(true);
        AbstractHashedMap delegateMap = (AbstractHashedMap) convertToMapMethod.get(map);
        assertNotNull(delegateMap, "delegateMap should be initialized after conversion");
        assertTrue(delegateMap.containsKey(key), "delegateMap should contain the new null key");
        assertEquals(value, delegateMap.get(key), "delegateMap should contain the new value");
        assertEquals(4, getField(map, "size"), "Size should be incremented to 4");
        assertNull(result, "Result should be null as per method contract");
    }

    @Test
    @DisplayName("put key matching key3 updates value3")
    public void TC13_put_keyMatchesKey3_updatesValue3() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        setField(map, "size", 3);
        setField(map, "key3", "key3");
        setField(map, "hash3", "key3".hashCode());
        setField(map, "value3", "oldValue3");
        setField(map, "delegateMap", null);
        Object key = "key3";
        Object value = "newValue3";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        Object updatedValue3 = getField(map, "value3");
        assertEquals("newValue3", updatedValue3, "value3 should be updated to newValue3");
        assertEquals("oldValue3", result, "put should return the old value3");
    }

    @Test
    @DisplayName("put key with same hashCode as key1 but not equal updates value1")
    public void TC14_put_keySameHashCodeNotEqual_updatesValue1() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        setField(map, "size", 1);
        setField(map, "key1", "key1");
        setField(map, "hash1", "key1".hashCode());
        setField(map, "value1", "oldValue1");
        setField(map, "delegateMap", null);
        Object key = "keyDifferent"; // Assume hashCode same as key1
        setField(map, "hash1", key.hashCode()); // Force same hashCode
        Object value = "newValue1";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        Object updatedValue1 = getField(map, "value1");
        assertEquals("newValue1", updatedValue1, "value1 should be updated to newValue1");
        assertEquals("oldValue1", result, "put should return the old value1");
    }

    @Test
    @DisplayName("put key with different hashCode and not equal adds new key")
    public void TC15_put_keyDifferentHashCodeNotEqual_addsNewKey() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        setField(map, "size", 2);
        setField(map, "key1", "key1");
        setField(map, "key2", "key2");
        setField(map, "delegateMap", null);
        Object key = "uniqueKey";
        Object value = "uniqueValue"; 

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Since size was 2, and adding one more, it should go to key3
        Object key3 = getField(map, "key3");
        Object value3 = getField(map, "value3");
        assertEquals("uniqueKey", key3, "key3 should be set to uniqueKey");
        assertEquals("uniqueValue", value3, "value3 should be set to uniqueValue");
        assertEquals(null, result, "Result should be null as per method contract");
        assertEquals(3, getField(map, "size"), "Size should be incremented to 3");
    }
}