package org.apache.commons.compress.harmony.pack200;

import org.apache.commons.compress.harmony.pack200.BcBands;
import org.apache.commons.compress.harmony.pack200.CpBands;
import org.apache.commons.compress.harmony.pack200.Segment;
import org.apache.commons.compress.harmony.pack200.CPMethodOrField;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.List;

public class BcBands_visitMethodInsn_1_2_Test {

    @Test
    @DisplayName("TC26: visitMethodInsn with opcode invokespecial (183), owner is neither currentClass nor superClass nor currentNewClass and name is not <init>")
    void testTC26() throws Exception {
        // Mock dependencies
        CpBands cpBands = Mockito.mock(CpBands.class);
        Segment segment = Mockito.mock(Segment.class);
        CPMethodOrField mockedMethod = Mockito.mock(CPMethodOrField.class);
        
        // Define behavior for cpBands.getCPMethod
        String owner = "externalOtherClass";
        String name = "externalMethod";
        String desc = "(I)V";
        Mockito.when(cpBands.getCPMethod(owner, name, desc)).thenReturn(mockedMethod);
        
        // Instantiate BcBands
        BcBands bcBands = new BcBands(cpBands, segment, 1);
        bcBands.setCurrentClass("currentClass", "superClass");
        
        // Access private fields using reflection
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        
        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        List<CPMethodOrField> bcMethodRef = (List<CPMethodOrField>) bcMethodRefField.get(bcBands);
        
        // Precondition: bcCodes does not contain ALOAD_0 (42)
        assertFalse(bcCodes.contains(42), "Precondition failed: bcCodes should not contain ALOAD_0");
        
        // Action: Call visitMethodInsn with opcode=183
        int opcode = 183; // invokespecial
        bcBands.visitMethodInsn(opcode, owner, name, desc);
        
        // Assertions
        // Verify bcMethodRef contains the mocked method
        assertTrue(bcMethodRef.contains(mockedMethod), "bcMethodRef should contain the method reference");
        
        // Verify bcCodes contains 232
        assertTrue(bcCodes.contains(232), "bcCodes should contain opcode 232 (invokespecial_new_init)");
    }

    @Test
    @DisplayName("TC27: visitMethodInsn with opcode invokespecial (183), bcCodes contains ALOAD_0 and owner is neither currentClass nor superClass nor currentNewClass")
    void testTC27() throws Exception {
        // Mock dependencies
        CpBands cpBands = Mockito.mock(CpBands.class);
        Segment segment = Mockito.mock(Segment.class);
        CPMethodOrField mockedMethod = Mockito.mock(CPMethodOrField.class);
        
        // Define behavior for cpBands.getCPMethod
        String owner = "externalOtherClass";
        String name = "<init>";
        String desc = "()V";
        Mockito.when(cpBands.getCPMethod(owner, name, desc)).thenReturn(mockedMethod);
        
        // Instantiate BcBands
        BcBands bcBands = new BcBands(cpBands, segment, 1);
        bcBands.setCurrentClass("currentClass", "superClass");
        
        // Access private fields using reflection
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        
        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        List<CPMethodOrField> bcInitRef = (List<CPMethodOrField>) bcInitRefField.get(bcBands);
        
        // Precondition: bcCodes contains ALOAD_0 (42)
        bcCodes.add(42);
        assertTrue(bcCodes.contains(42), "Precondition failed: bcCodes should contain ALOAD_0");
        
        // Action: Call visitMethodInsn with opcode=183
        int opcode = 183; // invokespecial
        bcBands.visitMethodInsn(opcode, owner, name, desc);
        
        // Assertions
        // Verify ALOAD_0 is removed from bcCodes
        assertFalse(bcCodes.contains(42), "ALOAD_0 should be removed from bcCodes");
        
        // Verify bcInitRef contains the mocked method
        assertTrue(bcInitRef.contains(mockedMethod), "bcInitRef should contain the method reference");
        
        // Verify bcCodes contains opcode 232
        assertTrue(bcCodes.contains(232), "bcCodes should contain opcode 232 (invokespecial_new_init)");
    }

    @Test
    @DisplayName("TC28: visitMethodInsn with opcode invokespecial (183), bcCodes contains ALOAD_0 and owner is neither currentClass nor superClass nor currentNewClass")
    void testTC28() throws Exception {
        // Mock dependencies
        CpBands cpBands = Mockito.mock(CpBands.class);
        Segment segment = Mockito.mock(Segment.class);
        CPMethodOrField mockedMethod = Mockito.mock(CPMethodOrField.class);
        
        // Define behavior for cpBands.getCPMethod
        String owner = "externalOtherClass";
        String name = "externalMethod";
        String desc = "(I)V";
        Mockito.when(cpBands.getCPMethod(owner, name, desc)).thenReturn(mockedMethod);
        
        // Instantiate BcBands
        BcBands bcBands = new BcBands(cpBands, segment, 1);
        bcBands.setCurrentClass("currentClass", "superClass");
        
        // Access private fields using reflection
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        
        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        List<CPMethodOrField> bcMethodRef = (List<CPMethodOrField>) bcMethodRefField.get(bcBands);
        
        // Precondition: bcCodes contains ALOAD_0 (42)
        bcCodes.add(42);
        assertTrue(bcCodes.contains(42), "Precondition failed: bcCodes should contain ALOAD_0");
        
        // Action: Call visitMethodInsn with opcode=183
        int opcode = 183; // invokespecial
        bcBands.visitMethodInsn(opcode, owner, name, desc);
        
        // Assertions
        // Verify ALOAD_0 is removed from bcCodes
        assertFalse(bcCodes.contains(42), "ALOAD_0 should be removed from bcCodes");
        
        // Verify bcMethodRef contains the mocked method
        assertTrue(bcMethodRef.contains(mockedMethod), "bcMethodRef should contain the method reference");
        
        // Verify bcCodes contains opcode 232
        assertTrue(bcCodes.contains(232), "bcCodes should contain opcode 232 (invokespecial_new_init)");
    }
}