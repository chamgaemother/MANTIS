package org.jfree.chart.renderer.category;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import javax.swing.Icon;

import java.lang.reflect.Field;

public class MinMaxCategoryRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem is called with plotLines=true and first column, ensuring no connecting line is drawn")
    void TC21_drawItem_plotLinesTrue_firstColumn_noConnection() {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        try {
            Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
            plotLinesField.setAccessible(true);
            plotLinesField.set(renderer, true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getRowCount()).thenReturn(1);

        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        when(domainAxis.getCategoryMiddle(0, 1, null, null)).thenReturn(50.0);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(10.0, null, null)).thenReturn(100.0);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
        
        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });

        // Verify that lastCategory is set correctly and min/max are updated
        try {
            Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
            lastCategoryField.setAccessible(true);
            int lastCategory = lastCategoryField.getInt(renderer);
            assertEquals(0, lastCategory);

            Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
            minField.setAccessible(true);
            double min = minField.getDouble(renderer);
            assertEquals(10.0, min);

            Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
            maxField.setAccessible(true);
            double max = maxField.getDouble(renderer);
            assertEquals(10.0, max);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    @DisplayName("drawItem is called with plotLines=true, column >0, previous dataset value=null, ensuring no connecting line is drawn")
    void TC22_drawItem_plotLinesTrue_columnGreaterThan0_prevValueNull_noConnection() {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        try {
            Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
            plotLinesField.setAccessible(true);
            plotLinesField.set(renderer, true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(1, 1)).thenReturn(20.0);
        when(dataset.getValue(1, 0)).thenReturn(null);
        when(dataset.getRowCount()).thenReturn(2);

        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        when(domainAxis.getCategoryMiddle(1, 2, null, null)).thenReturn(150.0);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(20.0, null, null)).thenReturn(200.0);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 300, 300);
        
        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        });

        // Verify that lastCategory is set correctly and min/max are updated
        try {
            Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
            lastCategoryField.setAccessible(true);
            int lastCategory = lastCategoryField.getInt(renderer);
            assertEquals(1, lastCategory);

            Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
            minField.setAccessible(true);
            double min = minField.getDouble(renderer);
            assertEquals(20.0, min);

            Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
            maxField.setAccessible(true);
            double max = maxField.getDouble(renderer);
            assertEquals(20.0, max);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}