package org.jfree.chart.renderer.xy;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYBoxAndWhiskerRenderer_drawHorizontalItem_0_4_Test {

    @Test
    @DisplayName("TC16: yMedian is null, ensuring median line is not drawn")
    void TC16_drawHorizontalItem_yMedianNull() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        // Setup dataset
        when(dataset.getX(series, item)).thenReturn(5.0);
        when(dataset.getMedianValue(series, item)).thenReturn(null);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(10);
        when(dataset.getMinRegularValue(series, item)).thenReturn(5);
        when(dataset.getMeanValue(series, item)).thenReturn(7.5);
        when(dataset.getQ1Value(series, item)).thenReturn(6);
        when(dataset.getQ3Value(series, item)).thenReturn(8);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2, never()).draw(argThat((Line2D line) -> line.getY1() == line.getY2()));
    }

    @Test
    @DisplayName("TC17: yQ1Median equals yQ3Median resulting in zero-height box")
    void TC17_drawHorizontalItem_yQ1MedianEqualsYQ3Median() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        // Setup dataset
        when(dataset.getX(series, item)).thenReturn(5.0);
        when(dataset.getMedianValue(series, item)).thenReturn(7);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(10);
        when(dataset.getMinRegularValue(series, item)).thenReturn(5);
        when(dataset.getMeanValue(series, item)).thenReturn(7.5);
        when(dataset.getQ1Value(series, item)).thenReturn(7);
        when(dataset.getQ3Value(series, item)).thenReturn(7);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2).draw(argThat((Rectangle2D rect) -> rect.getWidth() == 0));
    }

//     @Test
//     @DisplayName("TC18: Entities are present and multiple items intersect dataArea")
//     void TC18_drawHorizontalItem_multipleEntitiesIntersect() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int rendererIndex = 0;
// 
        // Setup dataset
//         when(dataset.getX(series, item)).thenReturn(5.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(7);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(10);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(5);
//         when(dataset.getMeanValue(series, item)).thenReturn(7.5);
//         when(dataset.getQ1Value(series, item)).thenReturn(6);
//         when(dataset.getQ3Value(series, item)).thenReturn(8);
//         when(dataset.getItemCount(series)).thenReturn(2);
// 
        // Act
//         renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
//         renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
// 
        // Assert
//         verify(entities, times(2)).addEntity(any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }

    @Test
    @DisplayName("TC19: yAverage is at the center of dataArea ensuring average marker is prominently visible")
    void TC19_drawHorizontalItem_yAverageAtCenter() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        // Setup dataset
        when(dataset.getX(series, item)).thenReturn(50.0);
        when(dataset.getMedianValue(series, item)).thenReturn(50);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(60);
        when(dataset.getMinRegularValue(series, item)).thenReturn(40);
        when(dataset.getMeanValue(series, item)).thenReturn(50.0);
        when(dataset.getQ1Value(series, item)).thenReturn(45);
        when(dataset.getQ3Value(series, item)).thenReturn(55);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2).fill(argThat((Ellipse2D ellipse) ->
            Math.abs(ellipse.getX() - 47.5) < 0.1 &&
            Math.abs(ellipse.getY() - 47.5) < 0.1));
    }

//     @Test
//     @DisplayName("TC20: CrosshairState has active crosshairs affecting rendering")
//     void TC20_drawHorizontalItem_activeCrosshairs() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int rendererIndex = 0;
// 
        // Setup crosshairState with active crosshairs
//         when(crosshairState.getCrosshairCount()).thenReturn(1);
//         when(crosshairState.getCrosshairX(0)).thenReturn(50.0);
//         when(crosshairState.getCrosshairY(0)).thenReturn(50.0);
// 
        // Setup dataset
//         when(dataset.getX(series, item)).thenReturn(50.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(50);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(60);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(40);
//         when(dataset.getMeanValue(series, item)).thenReturn(50.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(45);
//         when(dataset.getQ3Value(series, item)).thenReturn(55);
// 
        // Act
//         renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
// 
        // Assert
//         verify(g2, atLeastOnce()).draw(any(Line2D.class));
//     }
}