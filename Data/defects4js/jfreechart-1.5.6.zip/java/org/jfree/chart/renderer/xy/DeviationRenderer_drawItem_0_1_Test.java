package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer.State;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DeviationRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("Item is not visible, method returns early without drawing")
    void TC01_ItemNotVisible_ReturnsEarly() throws Exception {
        // Arrange
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 0;
        int pass = 0;

        // Mock getItemVisible to return false using reflection
        Method getItemVisible = DeviationRenderer.class.getDeclaredMethod("getItemVisible", int.class, int.class);
        getItemVisible.setAccessible(true);
        when(getItemVisible.invoke(renderer, series, item)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Since item is not visible, verify that no drawing operations are performed
        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("Pass is 0 and orientation is HORIZONTAL, item is not last in series")
    void TC02_Pass0_HorizontalOrientation_PartialSeries() throws Exception {
        // Arrange
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 1;
        int item = 2;
        int pass = 0;

        // Mock getItemVisible to return true using reflection
        Method getItemVisible = DeviationRenderer.class.getDeclaredMethod("getItemVisible", int.class, int.class);
        getItemVisible.setAccessible(true);
        when(getItemVisible.invoke(renderer, series, item)).thenReturn(true);

        // Mock dataset with multiple items
        when(dataset.getItemCount(series)).thenReturn(5);

        // Mock orientation as HORIZONTAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that shading is drawn horizontally without filling the area
        // This could involve verifying interactions with state or plot
        // For example, verify that coordinates are added
        State drState = (State) state;
        assertFalse(drState.lowerCoordinates.isEmpty(), "Lower coordinates should be populated");
        assertFalse(drState.upperCoordinates.isEmpty(), "Upper coordinates should be populated");
        verify(g2, never()).fill(any());
    }

    @Test
    @DisplayName("Pass is 0 and orientation is VERTICAL, item is the last in series")
    void TC03_Pass0_VerticalOrientation_LastItemFillsArea() throws Exception {
        // Arrange
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 1;
        int item = 4; // Assuming dataset.getItemCount(series) returns 5
        int pass = 0;

        // Mock getItemVisible to return true using reflection
        Method getItemVisible = DeviationRenderer.class.getDeclaredMethod("getItemVisible", int.class, int.class);
        getItemVisible.setAccessible(true);
        when(getItemVisible.invoke(renderer, series, item)).thenReturn(true);

        // Mock dataset with multiple items
        when(dataset.getItemCount(series)).thenReturn(5);

        // Mock orientation as VERTICAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that shading is drawn vertically and area is filled
        verify(g2).fill(any());
    }

    @Test
    @DisplayName("Pass is not 0, and it is a line pass with item line visible")
    void TC04_LinePass_WithLineVisible() throws Exception {
        // Arrange
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 1;
        int pass = 1;

        // Mock getItemVisible to return true using reflection
        Method getItemVisible = DeviationRenderer.class.getDeclaredMethod("getItemVisible", int.class, int.class);
        getItemVisible.setAccessible(true);
        when(getItemVisible.invoke(renderer, series, item)).thenReturn(true);

        // Mock isLinePass to return true using reflection
        Method isLinePass = DeviationRenderer.class.getDeclaredMethod("isLinePass", int.class);
        isLinePass.setAccessible(true);
        when(isLinePass.invoke(renderer, pass)).thenReturn(true);

        // Mock getItemLineVisible to return true using reflection
        Method getItemLineVisible = DeviationRenderer.class.getDeclaredMethod("getItemLineVisible", int.class, int.class);
        getItemLineVisible.setAccessible(true);
        when(getItemLineVisible.invoke(renderer, series, item)).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that primary line is drawn as path
        verify(renderer).drawPrimaryLineAsPath(state, g2, plot, dataset, pass, series, item, domainAxis, rangeAxis, dataArea);
    }

    @Test
    @DisplayName("Pass is not 0, it is a line pass but item line is not visible")
    void TC05_LinePass_WithLineNotVisible() throws Exception {
        // Arrange
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int series = 0;
        int item = 1;
        int pass = 1;

        // Mock getItemVisible to return true using reflection
        Method getItemVisible = DeviationRenderer.class.getDeclaredMethod("getItemVisible", int.class, int.class);
        getItemVisible.setAccessible(true);
        when(getItemVisible.invoke(renderer, series, item)).thenReturn(true);

        // Mock isLinePass to return true using reflection
        Method isLinePass = DeviationRenderer.class.getDeclaredMethod("isLinePass", int.class);
        isLinePass.setAccessible(true);
        when(isLinePass.invoke(renderer, pass)).thenReturn(true);

        // Mock getItemLineVisible to return false using reflection
        Method getItemLineVisible = DeviationRenderer.class.getDeclaredMethod("getItemLineVisible", int.class, int.class);
        getItemLineVisible.setAccessible(true);
        when(getItemLineVisible.invoke(renderer, series, item)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that primary line is not drawn
        verify(renderer, never()).drawPrimaryLineAsPath(any(), any(), any(), any(), anyInt(), anyInt(), anyInt(), any(), any(), any());
    }
}