package org.jfree.chart.plot;

import org.jfree.chart.needle.MeterNeedle;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * JUnit 5 test class for CompassPlot.draw method.
 */
public class CompassPlot_draw_1_1_Test {

    /**
     * Test case TC21:
     * draw method with non-null dataset entries but getValue() returns null.
     * Expected: Needle drawing is skipped for datasets with null values; method completes without exceptions.
     */
    @Test
    @DisplayName("draw method with non-null dataset entries but getValue() returns null")
    void TC21_draw_with_non_null_datasets_but_getValue_null() throws Exception {
        // GIVEN
        CompassPlot plot = new CompassPlot();
        ValueDataset dataset = new DefaultValueDataset((Number) null); // Specify type to avoid ambiguity with constructors
        plot.addDataset(dataset);

        // Replace the seriesNeedle with a mock to verify interactions
        MeterNeedle mockNeedle = mock(MeterNeedle.class);
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] needles = (MeterNeedle[]) seriesNeedleField.get(plot);
        needles[0] = mockNeedle;

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D centerPoint = new Point2D.Double(100, 100);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, info);

        // THEN
        // Verify that needle.draw() is never called since getValue() is null
        verify(mockNeedle, never()).draw(any(Graphics2D.class), any(Rectangle2D.class), anyDouble());

        // Verify that Graphics2D's fill and draw methods are still called for drawing the compass
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, atLeastOnce()).draw(any());

        // Ensure no exceptions are thrown (implicit by test passing)
    }

    /**
     * Test case TC22:
     * draw method with revolutionDistance set to 2ÃÂ radians and valid dataset values.
     * Expected: Compass is rendered correctly with dataset values interpreted as radians; needles point accurately.
     */
    @Test
    @DisplayName("draw method with revolutionDistance set to 2ÃÂ radians and valid dataset values")
    void TC22_draw_with_revolutionDistance_radians() throws Exception {
        // GIVEN
        CompassPlot plot = new CompassPlot();
        ValueDataset dataset = new DefaultValueDataset(Math.PI); // 180 degrees
        plot.addDataset(dataset);

        // Set revolutionDistance to 2ÃÂ using reflection
        Field revolutionDistanceField = CompassPlot.class.getDeclaredField("revolutionDistance");
        revolutionDistanceField.setAccessible(true);
        revolutionDistanceField.setDouble(plot, 2 * Math.PI);

        // Replace the seriesNeedle with a mock to verify interactions
        MeterNeedle mockNeedle = mock(MeterNeedle.class);
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] needles = (MeterNeedle[]) seriesNeedleField.get(plot);
        needles[0] = mockNeedle;

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D centerPoint = new Point2D.Double(100, 100);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, info);

        // THEN
        // Verify that needle.draw() is called with 180 degrees
        verify(mockNeedle, times(1)).draw(eq(g2), any(Rectangle2D.class), eq(180.0));

        // Verify that Graphics2D's fill and draw methods are called for drawing the compass
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, atLeastOnce()).draw(any());

        // Ensure no exceptions are thrown (implicit by test passing)
    }

}