package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.axis.NumberAxis;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class XYPlot_clone_0_1_Test {

    @Test
    @DisplayName("Cloning an XYPlot with domain and range axes set")
    public void testClone_XYPlot() throws CloneNotSupportedException {
        // GIVEN
        XYPlot plot = new XYPlot();
        ValueAxis domainAxis = new NumberAxis("X");
        ValueAxis rangeAxis = new NumberAxis("Y");
        plot.setDomainAxis(domainAxis);  // Ensuring domain axis is set
        plot.setRangeAxis(rangeAxis);    // Ensuring range axis is set

        // WHEN
        XYPlot clonedPlot = (XYPlot) plot.clone();

        // THEN
        assertNotSame(clonedPlot, plot, "Cloned plot should be a different instance");
        assertNotSame(clonedPlot.getDomainAxis(), plot.getDomainAxis(), "Cloned plot's domainAxis should be a different instance");
        assertNotSame(clonedPlot.getRangeAxis(), plot.getRangeAxis(), "Cloned plot's rangeAxis should be a different instance");
    }

    @Test
    @DisplayName("Cloning an XYPlot without domain or range axes set")
    public void testClone_XYPlot_noAxes() throws CloneNotSupportedException {
        // GIVEN
        XYPlot plot = new XYPlot();

        // WHEN
        XYPlot clonedPlot = (XYPlot) plot.clone();

        // THEN
        assertNotSame(clonedPlot, plot, "Cloned plot should be a different instance");
        assertNull(clonedPlot.getDomainAxis(), "Cloned plot's domainAxis should be null");
        assertNull(clonedPlot.getRangeAxis(), "Cloned plot's rangeAxis should be null");
    }
}