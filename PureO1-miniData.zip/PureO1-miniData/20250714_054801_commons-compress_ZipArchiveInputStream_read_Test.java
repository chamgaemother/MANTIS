import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.CRC32;

import org.apache.commons.compress.archivers.zip.UnsupportedZipFeatureException;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ZipArchiveInputStreamTest {

    private ZipArchiveInputStream zipInputStream;
    private InputStream mockInputStream;
    private byte[] buffer;

    @BeforeEach
    void setUp() {
        mockInputStream = mock(InputStream.class);
        zipInputStream = new ZipArchiveInputStream(mockInputStream);
        buffer = new byte[1024];
    }

    @Test
    void testRead_ZeroLength() throws IOException {
        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
        int result = zis.read(new byte[10], 0, 0);
        assertEquals(0, result);
    }

    @Test
    void testRead_WhenClosed() throws IOException {
        zipInputStream.close();
        IOException exception = assertThrows(IOException.class, () -> {
            zipInputStream.read(buffer, 0, 10);
        });
        assertEquals("The stream is closed", exception.getMessage());
    }

    @Test
    void testRead_WithNullCurrent() throws IOException {
        // current is initially null
        int result = zipInputStream.read(buffer, 0, 10);
        assertEquals(-1, result);
    }

    @Test
    void testRead_InvalidOffset() throws IOException {
        byte[] buf = new byte[5];
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            zipInputStream.read(buf, 10, 1);
        });
    }

    @Test
    void testRead_NegativeLength() throws IOException {
        byte[] buf = new byte[5];
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            zipInputStream.read(buf, 0, -1);
        });
    }

    @Test
    void testRead_OffsetNegative() throws IOException {
        byte[] buf = new byte[5];
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            zipInputStream.read(buf, -1, 1);
        });
    }

    @Test
    void testRead_BufferTooSmall() throws IOException {
        byte[] buf = new byte[5];
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            zipInputStream.read(buf, 3, 3);
        });
    }

    @Test
    void testRead_StoredWithoutDataDescriptor() throws IOException {
        byte[] zipBytes = createStoredZipEntry("test.txt", "Hello World");
        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zipBytes));
        ZipArchiveEntry entry = zis.getNextEntry();
        assertNotNull(entry);
        assertEquals("test.txt", entry.getName());
        int read = zis.read(buffer, 0, buffer.length);
        assertEquals(11, read);
        String content = new String(buffer, 0, read);
        assertEquals("Hello World", content);
        assertEquals(-1, zis.read(buffer, 0, buffer.length));
    }

    @Test
    void testRead_StoredWithDataDescriptor() throws IOException {
        byte[] zipBytes = createStoredZipEntryWithDataDescriptor("test.txt", "Hello World");
        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zipBytes), "UTF-8", true, true);
        ZipArchiveEntry entry = zis.getNextEntry();
        assertNotNull(entry);
        assertEquals("test.txt", entry.getName());
        int read = zis.read(buffer, 0, buffer.length);
        assertEquals(11, read);
        String content = new String(buffer, 0, read);
        assertEquals("Hello World", content);
        assertEquals(-1, zis.read(buffer, 0, buffer.length));
    }

    @Test
    void testRead_Deflated() throws IOException {
        byte[] zipBytes = createDeflatedZipEntry("test.txt", "Compressed Content");
        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zipBytes));
        ZipArchiveEntry entry = zis.getNextEntry();
        assertNotNull(entry);
        assertEquals("test.txt", entry.getName());
        int read = zis.read(buffer, 0, buffer.length);
        assertEquals("Compressed Content".length(), read);
        String content = new String(buffer, 0, read);
        assertEquals("Compressed Content", content);
        assertEquals(-1, zis.read(buffer, 0, buffer.length));
    }

    @Test
    void testRead_UnsupportedMethod() throws IOException {
        byte[] zipBytes = createZipEntryWithMethod("test.txt", "Data", ZipArchiveOutputStream.DEFLATED + 1);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zipBytes));
        ZipArchiveEntry entry = zis.getNextEntry();
        assertNotNull(entry);
        assertThrows(UnsupportedZipFeatureException.class, () -> {
            zis.read(buffer, 0, buffer.length);
        });
    }

    @Test
    void testRead_AfterInflaterFinished() throws IOException {
        byte[] zipBytes = createDeflatedZipEntry("test.txt", "End");
        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zipBytes));
        ZipArchiveEntry entry = zis.getNextEntry();
        assertNotNull(entry);
        int read1 = zis.read(buffer, 0, buffer.length);
        assertEquals(3, read1);
        int read2 = zis.read(buffer, 0, buffer.length);
        assertEquals(-1, read2);
    }

    @Test
    void testRead_CRCUpdate() throws IOException {
        byte[] zipBytes = createStoredZipEntry("test.txt", "CRC Test");
        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zipBytes));
        ZipArchiveEntry entry = zis.getNextEntry();
        assertNotNull(entry);
        CRC32 crc = new CRC32();
        crc.update("CRC Test".getBytes());
        byte[] readBuffer = new byte[9];
        int read = zis.read(readBuffer, 0, readBuffer.length);
        assertEquals(9, read);
        assertEquals(crc.getValue(), entry.getCrc());
    }

    @Test
    void testRead_NullBuffer() {
        assertThrows(NullPointerException.class, () -> {
            zipInputStream.read(null, 0, 10);
        });
    }

    // Helper methods to create zip bytes for tests

    private byte[] createStoredZipEntry(String name, String content) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos)) {
            ZipArchiveEntry entry = new ZipArchiveEntry(name);
            byte[] data = content.getBytes();
            entry.setMethod(ZipArchiveOutputStream.STORED);
            entry.setSize(data.length);
            entry.setCompressedSize(data.length);
            CRC32 crc = new CRC32();
            crc.update(data);
            entry.setCrc(crc.getValue());
            zos.putArchiveEntry(entry);
            zos.write(data);
            zos.closeArchiveEntry();
        }
        return bos.toByteArray();
    }

    private byte[] createStoredZipEntryWithDataDescriptor(String name, String content) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos)) {
            zos.setUseZip64(ZipArchiveOutputStream.Zip64Mode.AsNeeded);
            ZipArchiveEntry entry = new ZipArchiveEntry(name);
            byte[] data = content.getBytes();
            entry.setMethod(ZipArchiveOutputStream.STORED);
            entry.setSize(data.length);
            entry.setCompressedSize(data.length);
            zos.setUseDataDescriptor(true);
            zos.putArchiveEntry(entry);
            zos.write(data);
            zos.closeArchiveEntry();
        }
        return bos.toByteArray();
    }

    private byte[] createDeflatedZipEntry(String name, String content) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos)) {
            ZipArchiveEntry entry = new ZipArchiveEntry(name);
            byte[] data = content.getBytes();
            zos.putArchiveEntry(entry);
            zos.write(data);
            zos.closeArchiveEntry();
        }
        return bos.toByteArray();
    }

    private byte[] createZipEntryWithMethod(String name, String content, int method) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos)) {
            ZipArchiveEntry entry = new ZipArchiveEntry(name);
            byte[] data = content.getBytes();
            entry.setMethod(method);
            if (method == ZipArchiveOutputStream.STORED) {
                entry.setSize(data.length);
                entry.setCompressedSize(data.length);
                CRC32 crc = new CRC32();
                crc.update(data);
                entry.setCrc(crc.getValue());
            }
            zos.putArchiveEntry(entry);
            zos.write(data);
            zos.closeArchiveEntry();
        }
        return bos.toByteArray();
    }

}