package org.apache.commons.math3.stat.regression;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MillerUpdatingRegression_regress_0_1_Test {

    private MillerUpdatingRegression regression;

    @BeforeEach
    void setUp() throws ModelSpecificationException {
        // Initialize the regression object with dummy parameters; actual numbers will be set in each test
        regression = new MillerUpdatingRegression(5, false);
    }

    @Test
    @DisplayName("regress throws ModelSpecificationException when nobs is less than or equal to numberOfRegressors")
    void TC01_regress_throwsExceptionWhenNobsLessThanOrEqualToRegressors() {
        // GIVEN
        regression = new MillerUpdatingRegression(5, false);
        int[] regressors = {1, 2, 3, 4, 5};

        // WHEN & THEN
        ModelSpecificationException exception = assertThrows(ModelSpecificationException.class, () -> {
            regression.regress(regressors);
        });
        assertEquals("NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS", exception.getMessage());
    }

    @Test
    @DisplayName("regress throws ModelSpecificationException when numberOfRegressors exceeds nvars")
    void TC02_regress_throwsExceptionWhenRegressorsExceedNvars() {
        // GIVEN
        regression = new MillerUpdatingRegression(3, false);
        int[] regressors = {1, 2, 3, 4, 5};

        // WHEN & THEN
        ModelSpecificationException exception = assertThrows(ModelSpecificationException.class, () -> {
            regression.regress(regressors);
        });
        assertEquals("TOO_MANY_REGRESSORS", exception.getMessage());
    }

    @Test
    @DisplayName("regress executes without reordering when vorder matches indices")
    void TC03_regress_executesWithoutReordering() throws ModelSpecificationException {
        // GIVEN
        regression.clear(); // Ensure a clean state between tests
        regression = new MillerUpdatingRegression(5, false);
        regression.addObservation(new double[]{1, 2, 3, 4, 5}, 1);
        regression.addObservation(new double[]{2, 3, 4, 5, 6}, 2);
        int[] regressors = {0, 1, 2, 3, 4};

        // WHEN
        RegressionResults results = regression.regress(regressors);

        // THEN
        assertNotNull(results, "RegressionResults should not be null");
    }

    @Test
    @DisplayName("regress executes with reordering when vorder does not match indices")
    void TC04_regress_executesWithReordering() throws ModelSpecificationException {
        // GIVEN
        regression.clear(); // Ensure a clean state between tests
        regression = new MillerUpdatingRegression(5, false);
        regression.addObservation(new double[]{1, 2, 3, 4, 5}, 1);
        regression.addObservation(new double[]{2, 3, 4, 5, 6}, 2);
        int[] regressors = {4, 3, 2, 1, 0};

        // WHEN
        RegressionResults results = regression.regress(regressors);

        // THEN
        assertNotNull(results, "RegressionResults should not be null");
    }

    @Test
    @DisplayName("regress handles zero iterations in lindep loop")
    void TC05_regress_handlesZeroIterationsInLindepLoop() throws Exception {
        // GIVEN
        regression.clear(); // Ensure a clean state between tests
        regression = new MillerUpdatingRegression(5, false);
        regression.addObservation(new double[]{1, 2, 3, 4, 5}, 1);
        regression.addObservation(new double[]{2, 3, 4, 5, 6}, 2);
        int[] regressors = {0, 1, 2, 3, 4};

        // WHEN
        RegressionResults results = regression.regress(regressors);

        // THEN
        assertNotNull(results, "RegressionResults should not be null");
    }
}