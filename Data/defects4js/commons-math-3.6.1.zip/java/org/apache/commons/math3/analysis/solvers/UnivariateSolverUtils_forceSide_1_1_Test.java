package org.apache.commons.math3.analysis.solvers;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UnivariateSolverUtils_forceSide_1_1_Test {

    @Test
    @DisplayName("allowedSolution is null, method throws NullPointerException when invoking bracketing.solve")
    void TC13_allowedSolutionNull_throwsNullPointerException() {
        // Given
        AllowedSolution allowedSolution = null;
        int maxEval = 10;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        });
    }

    @Test
    @DisplayName("UnivariateFunction is null, method throws NullPointerException when calling f.value")
    void TC14_UnivariateFunctionNull_throwsNullPointerException() {
        // Given
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 10;
        UnivariateFunction f = null;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        });
    }

    @Test
    @DisplayName("BracketedUnivariateSolver is null, method throws NullPointerException when accessing bracketing")
    void TC15_bracketingNull_throwsNullPointerException() {
        // Given
        AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
        int maxEval = 10;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = null;
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        });
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, fLo equals zero, method returns bracketing.solve")
    void TC16_fLoZero_callsBracketingSolve() throws NoBracketingException {
        // Given
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 10;
        UnivariateFunction f = x -> (x == 2.0) ? 0.0 : x - 3.0;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        when(bracketing.solve(eq(maxEval - 2), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution))).thenReturn(2.0);

        // When
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // Then
        assertEquals(2.0, result);
        verify(bracketing).solve(eq(maxEval - 2), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }
}