package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class SmoothingPolynomialBicubicSplineInterpolator_interpolate_0_1_Test {

    @Test
    @DisplayName("Input arrays are empty (xval.length == 0), expecting NoDataException")
    void testTC01() {
        // GIVEN
        double[] xval = {};
        double[] yval = {1.0, 2.0};
        double[][] fval = {{1.0, 2.0}};
        
        // WHEN & THEN
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    @DisplayName("Input arrays are empty (yval.length == 0), expecting NoDataException")
    void testTC02() {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {};
        double[][] fval = {{1.0, 2.0}};
        
        // WHEN & THEN
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    @DisplayName("Input arrays are empty (fval.length == 0), expecting NoDataException")
    void testTC03() {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {};
        
        // WHEN & THEN
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    @DisplayName("xval and fval lengths mismatch (xval.length != fval.length), expecting DimensionMismatchException")
    void testTC04() {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = { {1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0} };
        
        // WHEN & THEN
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    @DisplayName("fval has at least one row where fval[i].length != yval.length, expecting DimensionMismatchException")
    void testTC05() {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = { {1.0, 2.0}, {3.0} };
        
        // WHEN & THEN
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, fval));
    }
}