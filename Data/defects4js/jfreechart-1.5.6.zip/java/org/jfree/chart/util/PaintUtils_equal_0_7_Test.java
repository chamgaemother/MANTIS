package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.LinearGradientPaint;
import java.awt.RadialGradientPaint;
import java.awt.geom.Point2D;
import java.awt.geom.AffineTransform;
import java.awt.MultipleGradientPaint.CycleMethod;
import java.awt.MultipleGradientPaint.ColorSpaceType;

public class PaintUtils_equal_0_7_Test {

//     @Test
//     @DisplayName("p1 is LinearGradientPaint and p2 is RadialGradientPaint with identical properties, expect false")
//     void TC31() {
        // GIVEN
//         Point2D start = new Point2D.Double(0, 0);
//         Point2D end = new Point2D.Double(100, 100);
//         float[] fractions = {0.0f, 1.0f};
//         Color[] colors = {Color.RED, Color.BLUE};
//         CycleMethod cycleMethod = CycleMethod.NO_CYCLE;
//         AffineTransform transform = new AffineTransform();
//         LinearGradientPaint lgp = new LinearGradientPaint(start, end, fractions, colors, cycleMethod, ColorSpaceType.SRGB, transform);
// 
//         Point2D center = new Point2D.Double(50, 50);
//         float radius = 100.0f;
//         RadialGradientPaint rgp = new RadialGradientPaint(center, radius, fractions, colors, cycleMethod, ColorSpaceType.SRGB, transform);
// 
        // WHEN
//         boolean result = PaintUtils.equal(lgp, rgp);
// 
        // THEN
//         assertFalse(result);
//     }

    @Test
    @DisplayName("p1 and p2 are GradientPaint instances with different isCyclic values, expect false")
    void TC32() {
        // GIVEN
        GradientPaint gp1 = new GradientPaint(0f, 0f, Color.RED, 100f, 100f, Color.BLUE, true);
        GradientPaint gp2 = new GradientPaint(0f, 0f, Color.RED, 100f, 100f, Color.BLUE, false);

        // WHEN
        boolean result = PaintUtils.equal(gp1, gp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with different cycle methods, expect false")
    void TC33() {
        // GIVEN
        Point2D start = new Point2D.Double(0, 0);
        Point2D end = new Point2D.Double(100, 100);
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        CycleMethod cycleMethod1 = CycleMethod.NO_CYCLE;
        CycleMethod cycleMethod2 = CycleMethod.REFLECT;
        AffineTransform transform = new AffineTransform();
        LinearGradientPaint lgp1 = new LinearGradientPaint(start, end, fractions, colors, cycleMethod1, ColorSpaceType.SRGB, transform);
        LinearGradientPaint lgp2 = new LinearGradientPaint(start, end, fractions, colors, cycleMethod2, ColorSpaceType.SRGB, transform);

        // WHEN
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with different color spaces, expect false")
    void TC34() {
        // GIVEN
        Point2D start = new Point2D.Double(0, 0);
        Point2D end = new Point2D.Double(100, 100);
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        CycleMethod cycleMethod = CycleMethod.NO_CYCLE;
        AffineTransform transform = new AffineTransform();
        LinearGradientPaint lgp1 = new LinearGradientPaint(start, end, fractions, colors, cycleMethod, ColorSpaceType.SRGB, transform);
        LinearGradientPaint lgp2 = new LinearGradientPaint(start, end, fractions, colors, cycleMethod, ColorSpaceType.LINEAR_RGB, transform);

        // WHEN
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with different transforms, expect false")
    void TC35() {
        // GIVEN
        Point2D start = new Point2D.Double(0, 0);
        Point2D end = new Point2D.Double(100, 100);
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        CycleMethod cycleMethod = CycleMethod.NO_CYCLE;
        AffineTransform at1 = new AffineTransform();
        AffineTransform at2 = new AffineTransform();
        at2.scale(2, 2);
        LinearGradientPaint lgp1 = new LinearGradientPaint(start, end, fractions, colors, cycleMethod, ColorSpaceType.SRGB, at1);
        LinearGradientPaint lgp2 = new LinearGradientPaint(start, end, fractions, colors, cycleMethod, ColorSpaceType.SRGB, at2);

        // WHEN
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // THEN
        assertFalse(result);
    }
}