package org.apache.commons.collections4.iterators;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class PermutationIterator_next_0_3_Test {

    @Test
    @DisplayName("Handles keys array with mixed direction flags")
    void TC11() throws Exception {
        // Initialize PermutationIterator instance with an initial collection
        List<Integer> initialCollection = Arrays.asList(1, 2, 3);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Use reflection to set private fields
        Class<?> clazz = iterator.getClass();

        // Set 'keys' array
        Field keysField = clazz.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] keys = {3, 1, 2};
        keysField.set(iterator, keys);

        // Set 'direction' array (true for right, false for left)
        Field directionField = clazz.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] direction = {true, false, true};
        directionField.set(iterator, direction);

        // Set 'nextPermutation'
        Field nextPermutationField = clazz.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = Arrays.asList(3, 1, 2);
        nextPermutationField.set(iterator, new ArrayList<>(nextPermutation));

        // Set 'objectMap'
        Field objectMapField = clazz.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        for (int key : keys) {
            objectMap.put(key, key);
        }
        objectMapField.set(iterator, objectMap);

        // Call 'next()'
        List<Integer> result = iterator.next();

        // Expected result after swapping based on direction flags
        // Here, key '3' has direction right (true) and can swap with '1'
        // Key '1' has direction left (false) and cannot swap
        // Key '2' has direction right (true) and no element to the right
        // So, only '3' swaps with '1' resulting in [1, 3, 2]
        List<Integer> expected = Arrays.asList(1, 3, 2);
        assertEquals(expected, result);

        // Additionally, verify that the directions have been updated correctly
        // After swapping, directions of keys larger than '3' should be toggled
        // Since there are no keys larger than '3', directions remain the same
        boolean[] expectedDirections = {true, false, true};
        boolean[] actualDirections = (boolean[]) directionField.get(iterator);
        assertArrayEquals(expectedDirections, actualDirections);
    }

    @Test
    @DisplayName("Handles keys array in descending order")
    void TC12() throws Exception {
        // Initialize PermutationIterator instance with an initial collection
        List<Integer> initialCollection = Arrays.asList(3, 2, 1);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Use reflection to set private fields
        Class<?> clazz = iterator.getClass();

        // Set 'keys' array in descending order
        Field keysField = clazz.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] keys = {3, 2, 1};
        keysField.set(iterator, keys);

        // Set 'direction' array all true
        Field directionField = clazz.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] direction = {true, true, true};
        directionField.set(iterator, direction);

        // Set 'nextPermutation'
        Field nextPermutationField = clazz.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = Arrays.asList(3, 2, 1);
        nextPermutationField.set(iterator, new ArrayList<>(nextPermutation));

        // Set 'objectMap'
        Field objectMapField = clazz.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        for (int key : keys) {
            objectMap.put(key, key);
        }
        objectMapField.set(iterator, objectMap);

        // Call 'next()'
        List<Integer> result = iterator.next();

        // Expected result: no mobile integer found, return nextPermutation and set nextPermutation to null
        List<Integer> expected = Arrays.asList(3, 2, 1);
        assertEquals(expected, result);

        // Verify that nextPermutation is now null
        assertNull(nextPermutationField.get(iterator));
    }

    @Test
    @DisplayName("Handles keys array with all keys equal")
    void TC13() throws Exception {
        // Initialize PermutationIterator instance with an initial collection
        List<Integer> initialCollection = Arrays.asList(2, 2, 2);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Use reflection to set private fields
        Class<?> clazz = iterator.getClass();

        // Set 'keys' array with all keys equal
        Field keysField = clazz.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] keys = {2, 2, 2};
        keysField.set(iterator, keys);

        // Set 'direction' array all true
        Field directionField = clazz.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] direction = {true, true, true};
        directionField.set(iterator, direction);

        // Set 'nextPermutation'
        Field nextPermutationField = clazz.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = Arrays.asList(2, 2, 2);
        nextPermutationField.set(iterator, new ArrayList<>(nextPermutation));

        // Set 'objectMap'
        Field objectMapField = clazz.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        for (int key : keys) {
            objectMap.put(key, key);
        }
        objectMapField.set(iterator, objectMap);

        // Call 'next()'
        List<Integer> result = iterator.next();

        // Expected result: no mobile integer found, return nextPermutation and set nextPermutation to null
        List<Integer> expected = Arrays.asList(2, 2, 2);
        assertEquals(expected, result);

        // Verify that nextPermutation is now null
        assertNull(nextPermutationField.get(iterator));
    }

    @Test
    @DisplayName("Handles empty keys array")
    void TC14() throws Exception {
        // Initialize PermutationIterator instance with an empty collection
        List<Integer> initialCollection = new ArrayList<>();
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Use reflection to set private fields
        Class<?> clazz = iterator.getClass();

        // Set 'keys' array empty
        Field keysField = clazz.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] keys = {};
        keysField.set(iterator, keys);

        // Set 'direction' array empty
        Field directionField = clazz.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] direction = {};
        directionField.set(iterator, direction);

        // Set 'nextPermutation'
        Field nextPermutationField = clazz.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = new ArrayList<>();
        nextPermutationField.set(iterator, nextPermutation);

        // Set 'objectMap'
        Field objectMapField = clazz.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMapField.set(iterator, objectMap);

        // Call 'next()'
        List<Integer> result = iterator.next();

        // Expected result: no mobile integer found, return nextPermutation (empty list) and set nextPermutation to null
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, result);

        // Verify that nextPermutation is now null
        assertNull(nextPermutationField.get(iterator));
    }

    @Test
    @DisplayName("Handles multiple swaps in a single call")
    void TC15() throws Exception {
        // Initialize PermutationIterator instance with an initial collection
        List<Integer> initialCollection = Arrays.asList(1, 3, 2, 4);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Use reflection to set private fields
        Class<?> clazz = iterator.getClass();

        // Set 'keys' array with multiple mobile integers
        Field keysField = clazz.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] keys = {1, 3, 2, 4};
        keysField.set(iterator, keys);

        // Set 'direction' array
        Field directionField = clazz.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] direction = {true, true, false, true};
        directionField.set(iterator, direction);

        // Set 'nextPermutation'
        Field nextPermutationField = clazz.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = Arrays.asList(1, 3, 2, 4);
        nextPermutationField.set(iterator, new ArrayList<>(nextPermutation));

        // Set 'objectMap'
        Field objectMapField = clazz.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        for (int key : keys) {
            objectMap.put(key, key);
        }
        objectMapField.set(iterator, objectMap);

        // Call 'next()'
        List<Integer> result = iterator.next();

        // Expected result after multiple swaps:
        // First, identify mobile integers:
        // 1 (dir=true) can swap with 3 -> no (1 < 3)
        // 3 (dir=true) can swap with 2 -> yes (3 > 2)
        // 2 (dir=false) can swap with 3 -> no (2 < 3)
        // 4 (dir=true) can swap with nothing
        // So, only 3 swaps with 2 -> [1, 2, 3, 4]
        List<Integer> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, result);

        // Verify that directions have been updated correctly
        // Directions of keys greater than '3' should be toggled
        // In this case, keys >3 is 4, so direction[3] should toggle from true to false
        boolean[] expectedDirections = {true, true, false, false};
        boolean[] actualDirections = (boolean[]) directionField.get(iterator);
        assertArrayEquals(expectedDirections, actualDirections);

        // Verify that nextPermutation is updated correctly
        List<Integer> expectedNextPermutation = Arrays.asList(1, 2, 3, 4);
        assertEquals(expectedNextPermutation, nextPermutationField.get(iterator));
    }

    @Test
    @DisplayName("Throws NoSuchElementException when no next permutation is available")
    void TC16() throws Exception {
        // Initialize PermutationIterator instance with an initial collection
        List<Integer> initialCollection = Arrays.asList(1, 2, 3);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Use reflection to set private fields
        Class<?> clazz = iterator.getClass();

        // Set 'keys' array
        Field keysField = clazz.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] keys = {1, 2, 3};
        keysField.set(iterator, keys);

        // Set 'direction' array all true
        Field directionField = clazz.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] direction = {true, true, true};
        directionField.set(iterator, direction);

        // Set 'nextPermutation' to null to simulate no next permutation
        Field nextPermutationField = clazz.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, null);

        // Set 'objectMap'
        Field objectMapField = clazz.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        for (int key : keys) {
            objectMap.put(key, key);
        }
        objectMapField.set(iterator, objectMap);

        // Expect NoSuchElementException when 'next()' is called
        assertThrows(NoSuchElementException.class, () -> {
            iterator.next();
        });
    }
}