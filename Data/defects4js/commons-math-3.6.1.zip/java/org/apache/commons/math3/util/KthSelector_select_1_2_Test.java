package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Test class for KthSelector.select method covering scenario TC18.
 */
public class KthSelector_select_1_2_Test {

    @Test
    @DisplayName("select method with pivot index equal to k, triggering immediate return")
    public void TC18() {
        // Initialize work array with elements where pivot index equals k
        double[] work = {1.0, 2.0, 3.0};
        // Initialize pivotsHeap with the first pivot index set to k
        int[] pivotsHeap = {1};
        // Set k to the pivot index
        int k = 1;

        // Create an instance of KthSelector
        KthSelector selector = new KthSelector();

        // Invoke the select method
        double result = selector.select(work, pivotsHeap, k);

        // Assert that the returned value is equal to work[k]
        assertEquals(work[k], result, "The select method should return work[k] when pivot index equals k.");
    }
}