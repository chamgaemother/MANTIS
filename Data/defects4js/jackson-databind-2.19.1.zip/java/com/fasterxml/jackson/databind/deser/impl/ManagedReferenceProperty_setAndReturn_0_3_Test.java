package com.fasterxml.jackson.databind.deser.impl;
import java.lang.reflect.*;

import java.io.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.lang.reflect.Field;

public class ManagedReferenceProperty_setAndReturn_0_3_Test {

    @Test
    @DisplayName("TC11: value is a Map with zero entries, no _backProperty.set calls")
    void test_TC11() throws Exception {
        // Arrange
        SettableBeanProperty backPropertyMock = mock(SettableBeanProperty.class);
        SettableBeanProperty delegateMock = mock(SettableBeanProperty.class);
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegateMock, "testRef", backPropertyMock, true);
        Object instance = new Object();
        Map<Object, Object> value = new HashMap<>();

        // Mock delegate behavior
        Object expectedResult = new Object();
        when(delegateMock.setAndReturn(instance, value)).thenReturn(expectedResult);

        // Act
        Object result = property.setAndReturn(instance, value);

        // Assert
        verify(backPropertyMock, never()).set(any(), any());
        verify(delegateMock, times(1)).setAndReturn(instance, value);
        assertEquals(expectedResult, result);
    }

    @Test
    @DisplayName("TC12: value is a Map with entries having null values, _backProperty.set is not called")
    void test_TC12() throws Exception {
        // Arrange
        SettableBeanProperty backPropertyMock = mock(SettableBeanProperty.class);
        SettableBeanProperty delegateMock = mock(SettableBeanProperty.class);
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegateMock, "testRef", backPropertyMock, true);
        Object instance = new Object();
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", null);
        value.put("key2", null);

        // Mock delegate behavior
        Object expectedResult = new Object();
        when(delegateMock.setAndReturn(instance, value)).thenReturn(expectedResult);

        // Act
        Object result = property.setAndReturn(instance, value);

        // Assert
        verify(backPropertyMock, never()).set(any(), any());
        verify(delegateMock, times(1)).setAndReturn(instance, value);
        assertEquals(expectedResult, result);
    }

    @Test
    @DisplayName("TC13: value is a Map with entries having non-null values, _backProperty.set is called for each")
    void test_TC13() throws Exception {
        // Arrange
        SettableBeanProperty backPropertyMock = mock(SettableBeanProperty.class);
        SettableBeanProperty delegateMock = mock(SettableBeanProperty.class);
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegateMock, "testRef", backPropertyMock, true);
        Object instance = new Object();
        Object value1 = new Object();
        Object value2 = new Object();
        Map<Object, Object> map = new HashMap<>();
        map.put("key1", value1);
        map.put("key2", value2);

        // Mock delegate behavior
        Object expectedResult = new Object();
        when(delegateMock.setAndReturn(instance, map)).thenReturn(expectedResult);

        // Act
        Object result = property.setAndReturn(instance, map);

        // Assert
        verify(backPropertyMock, times(1)).set(value1, instance);
        verify(backPropertyMock, times(1)).set(value2, instance);
        verify(delegateMock, times(1)).setAndReturn(instance, map);
        assertEquals(expectedResult, result);
    }

    @Test
    @DisplayName("TC14: value is of unsupported container type, IllegalStateException is thrown")
    void test_TC14() throws Exception {
        // Arrange
        SettableBeanProperty backPropertyMock = mock(SettableBeanProperty.class);
        SettableBeanProperty delegateMock = mock(SettableBeanProperty.class);
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegateMock, "testRef", backPropertyMock, false);
        Object instance = new Object();
        String unsupportedValue = "unsupported";

        // Act & Assert
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            property.setAndReturn(instance, unsupportedValue);
        });

        assertTrue(exception.getMessage().contains("Unsupported container type"));
        verify(backPropertyMock, never()).set(any(), any());
        verify(delegateMock, never()).setAndReturn(any(), any());
    }
}