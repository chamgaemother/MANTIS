import org.apache.commons.math3.geometry.euclidean.threed.Rotation;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import org.apache.commons.math3.exception.CardanEulerSingularityException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.*;

public class RotationTest {

    @Test
    void testGetAngles_VectorOperator_XYZ_NonSingular() {
        Vector3D axis = new Vector3D(1, 0, 0);
        double angle = Math.PI / 4;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);
        assertEquals(Math.PI / 4, angles[0], 1e-10);
        assertEquals(0.0, angles[1], 1e-10);
        assertEquals(0.0, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_VectorOperator_XYZ_Singular() {
        Vector3D axis = new Vector3D(0, 1, 0);
        double angle = Math.PI / 2;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR));
    }

    @Test
    void testGetAngles_VectorOperator_XZY_NonSingular() {
        Vector3D axis = new Vector3D(0, 0, 1);
        double angle = Math.PI / 6;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        double[] angles = rotation.getAngles(RotationOrder.XZY, RotationConvention.VECTOR_OPERATOR);
        assertEquals(0.0, angles[0], 1e-10);
        assertEquals(angle, angles[1], 1e-10);
        assertEquals(0.0, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_VectorOperator_XZY_Singular() {
        Vector3D axis = new Vector3D(1, 1, 0).normalize();
        double angle = Math.PI / 2;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.XZY, RotationConvention.VECTOR_OPERATOR));
    }

    @Test
    void testGetAngles_FrameTransform_ZYZ_NonSingular() {
        Vector3D axis = new Vector3D(0, 0, 1);
        double angle = Math.PI / 3;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        double[] angles = rotation.getAngles(RotationOrder.ZYZ, RotationConvention.FRAME_TRANSFORM);
        assertEquals(angle, angles[0], 1e-10);
        assertEquals(0.0, angles[1], 1e-10);
        assertEquals(0.0, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_FrameTransform_ZYZ_Singular() {
        Vector3D axis = new Vector3D(1, 0, 0).normalize();
        double angle = 0.0;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.ZYZ, RotationConvention.FRAME_TRANSFORM));
    }

    @ParameterizedTest
    @EnumSource(RotationConvention.class)
    void testGetAngles_NullOrder(RotationConvention convention) {
        Vector3D axis = new Vector3D(1, 0, 0);
        double angle = Math.PI / 4;
        Rotation rotation = new Rotation(axis, angle, convention);
        assertThrows(NullPointerException.class, () ->
                rotation.getAngles(null, convention));
    }

    @ParameterizedTest
    @EnumSource(RotationOrder.class)
    void testGetAngles_NullConvention(RotationOrder order) {
        Vector3D axis = new Vector3D(1, 0, 0);
        double angle = Math.PI / 4;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        assertThrows(NullPointerException.class, () ->
                rotation.getAngles(order, null));
    }

    @Test
    void testGetAngles_VectorOperator_YXZ_NonSingular() {
        Vector3D axis = new Vector3D(0, 1, 0);
        double angle = Math.PI / 3;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        double[] angles = rotation.getAngles(RotationOrder.YXZ, RotationConvention.VECTOR_OPERATOR);
        assertEquals(0.0, angles[0], 1e-10);
        assertEquals(angle, angles[1], 1e-10);
        assertEquals(0.0, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_VectorOperator_YXZ_Singular() {
        Vector3D axis = new Vector3D(0, 1, 1).normalize();
        double angle = Math.PI / 2;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.YXZ, RotationConvention.VECTOR_OPERATOR));
    }

    @Test
    void testGetAngles_FrameTransform_XYX_NonSingular() {
        Vector3D axis = new Vector3D(1, 1, 1).normalize();
        double angle = Math.PI / 4;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        double[] angles = rotation.getAngles(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM);
        assertEquals(angle, angles[0], 1e-10);
        assertEquals(0.0, angles[1], 1e-10);
        assertEquals(0.0, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_FrameTransform_XYX_Singular() {
        Vector3D axis = new Vector3D(0, 1, 0).normalize();
        double angle = 0.0;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM));
    }

    @Test
    void testGetAngles_VectorOperator_ZYX_NonSingular() {
        Vector3D axis = new Vector3D(0, 0, 1);
        double angle = Math.PI / 6;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        double[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
        assertEquals(0.0, angles[0], 1e-10);
        assertEquals(0.0, angles[1], 1e-10);
        assertEquals(angle, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_VectorOperator_ZYX_Singular() {
        Vector3D axis = new Vector3D(1, 1, 0).normalize();
        double angle = Math.PI / 2;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR));
    }

    @Test
    void testGetAngles_FrameTransform_YZY_NonSingular() {
        Vector3D axis = new Vector3D(0, 1, 0);
        double angle = Math.PI / 3;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        double[] angles = rotation.getAngles(RotationOrder.YZY, RotationConvention.FRAME_TRANSFORM);
        assertEquals(angle, angles[0], 1e-10);
        assertEquals(0.0, angles[1], 1e-10);
        assertEquals(0.0, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_FrameTransform_YZY_Singular() {
        Vector3D axis = new Vector3D(1, 0, 1).normalize();
        double angle = 0.0;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.YZY, RotationConvention.FRAME_TRANSFORM));
    }

    @Test
    void testGetAngles_VectorOperator_InvalidOrder() {
        Vector3D axis = new Vector3D(1, 0, 0);
        double angle = Math.PI / 4;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
        // Assuming RotationOrder has no invalid orders, this test is redundant.
        // If RotationOrder were to have an invalid value, it would require a different approach.
        // Skipping as it's not applicable.
    }

    @Test
    void testGetAngles_FrameTransform_ZXZ_NonSingular() {
        Vector3D axis = new Vector3D(1, 0, 1).normalize();
        double angle = Math.PI / 5;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        double[] angles = rotation.getAngles(RotationOrder.ZXZ, RotationConvention.FRAME_TRANSFORM);
        assertEquals(angle, angles[0], 1e-10);
        assertEquals(0.0, angles[1], 1e-10);
        assertEquals(0.0, angles[2], 1e-10);
    }

    @Test
    void testGetAngles_FrameTransform_ZXZ_Singular() {
        Vector3D axis = new Vector3D(0, 1, 0).normalize();
        double angle = Math.PI;
        Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
        assertThrows(CardanEulerSingularityException.class, () ->
                rotation.getAngles(RotationOrder.ZXZ, RotationConvention.FRAME_TRANSFORM));
    }

    @Test
    void testGetAngles_VectorOperator_AllOrders_NonSingular() {
        RotationOrder[] orders = RotationOrder.values();
        for (RotationOrder order : orders) {
            Vector3D axis = new Vector3D(1, 1, 1).normalize();
            double angle = Math.PI / 4;
            Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
            assertDoesNotThrow(() -> {
                double[] angles = rotation.getAngles(order, RotationConvention.VECTOR_OPERATOR);
                assertNotNull(angles);
                assertEquals(3, angles.length);
            }, "Failed for order: " + order);
        }
    }

    @Test
    void testGetAngles_FrameTransform_AllOrders_NonSingular() {
        RotationOrder[] orders = RotationOrder.values();
        for (RotationOrder order : orders) {
            Vector3D axis = new Vector3D(1, 0, 1).normalize();
            double angle = Math.PI / 6;
            Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
            assertDoesNotThrow(() -> {
                double[] angles = rotation.getAngles(order, RotationConvention.FRAME_TRANSFORM);
                assertNotNull(angles);
                assertEquals(3, angles.length);
            }, "Failed for order: " + order);
        }
    }

    @Test
    void testGetAngles_VectorOperator_AllOrders_Singular() {
        RotationOrder[] orders = RotationOrder.values();
        for (RotationOrder order : orders) {
            Vector3D axis = new Vector3D(1, 0, 0).normalize();
            double angle = Math.PI / 2;
            Rotation rotation = new Rotation(axis, angle, RotationConvention.VECTOR_OPERATOR);
            assertThrows(CardanEulerSingularityException.class, () -> {
                rotation.getAngles(order, RotationConvention.VECTOR_OPERATOR);
            }, "Expected singularity for order: " + order);
        }
    }

    @Test
    void testGetAngles_FrameTransform_AllOrders_Singular() {
        RotationOrder[] orders = RotationOrder.values();
        for (RotationOrder order : orders) {
            Vector3D axis = new Vector3D(0, 1, 0).normalize();
            double angle = 0.0;
            Rotation rotation = new Rotation(axis, angle, RotationConvention.FRAME_TRANSFORM);
            assertThrows(CardanEulerSingularityException.class, () -> {
                rotation.getAngles(order, RotationConvention.FRAME_TRANSFORM);
            }, "Expected singularity for order: " + order);
        }
    }
}