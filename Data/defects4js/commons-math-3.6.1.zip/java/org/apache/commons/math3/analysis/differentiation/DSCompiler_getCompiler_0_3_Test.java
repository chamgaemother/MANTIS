package org.apache.commons.math3.analysis.differentiation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.NumberIsTooLargeException;

public class DSCompiler_getCompiler_0_3_Test {

    @Test
    @DisplayName("getCompiler handles DSCompiler creation with existing value compiler and null derivative compiler")
    public void TC11() throws Exception {
        // Arrange
        int parameters = 2;
        int order = 2;
        DSCompiler existingValueCompiler = DSCompiler.getCompiler(1, 2);
        DSCompiler[][] cache = new DSCompiler[3][3];
        cache[1][2] = existingValueCompiler;
        cache[2][2] = null;

        // Set the 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, new AtomicReference<>(cache));

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertNotNull(result);
    }

    @Test
    @DisplayName("getCompiler handles DSCompiler creation with existing derivative compiler and null value compiler")
    public void TC12() throws Exception {
        // Arrange
        int parameters = 2;
        int order = 2;
        DSCompiler existingDerivativeCompiler = DSCompiler.getCompiler(2, 1);
        DSCompiler[][] cache = new DSCompiler[3][3];
        cache[2][1] = existingDerivativeCompiler;
        cache[2][2] = null;

        // Set the 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, new AtomicReference<>(cache));

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertNotNull(result);
    }

    @Test
    @DisplayName("getCompiler handles invalid negative parameters by throwing exception")
    public void TC13() throws Exception {
        // Arrange
        int parameters = -1;
        int order = 2;
        DSCompiler[][] cache = null;

        // Set the 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, new AtomicReference<>(cache));

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            try {
                DSCompiler.getCompiler(parameters, order);
            } catch (NumberIsTooLargeException e) {
                throw new IllegalArgumentException(e);
            }
        });
    }

    @Test
    @DisplayName("getCompiler handles invalid negative order by throwing exception")
    public void TC14() throws Exception {
        // Arrange
        int parameters = 2;
        int order = -1;
        DSCompiler[][] cache = null;

        // Set the 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, new AtomicReference<>(cache));

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            try {
                DSCompiler.getCompiler(parameters, order);
            } catch (NumberIsTooLargeException e) {
                throw new IllegalArgumentException(e);
            }
        });
    }

    @Test
    @DisplayName("getCompiler handles maximum integer values for parameters and order")
    public void TC15() throws Exception {
        // Arrange
        int parameters = Integer.MAX_VALUE;
        int order = Integer.MAX_VALUE;
        DSCompiler[][] cache = null;

        // Set the 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, new AtomicReference<>(cache));

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertNotNull(result);
    }
}