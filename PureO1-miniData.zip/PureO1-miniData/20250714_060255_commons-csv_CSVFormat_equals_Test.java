package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.ResultSetMetaData;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CSVFormatTest {

    @Test
    void testEqualsSameInstance() {
        CSVFormat format = CSVFormat.DEFAULT;
        assertTrue(format.equals(format));
    }

    @Test
    void testEqualsNull() {
        CSVFormat format = CSVFormat.DEFAULT;
        assertFalse(format.equals(null));
    }

    @Test
    void testEqualsDifferentClass() {
        CSVFormat format = CSVFormat.DEFAULT;
        String differentClass = "I am not a CSVFormat";
        assertFalse(format.equals(differentClass));
    }

    @Test
    void testEqualsEqualCSVFormat() {
        CSVFormat format1 = CSVFormat.DEFAULT;
        CSVFormat format2 = CSVFormat.DEFAULT.builder().build();
        assertTrue(format1.equals(format2));
        assertTrue(format2.equals(format1));
    }

    @Test
    void testEqualsDifferentDuplicateHeaderMode() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(CSVFormat.DuplicateHeaderMode.ALLOW_ALL).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(CSVFormat.DuplicateHeaderMode.ALLOW_EMPTY).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentAllowMissingColumnNames() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentAutoFlush() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setAutoFlush(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setAutoFlush(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentCommentMarker() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setCommentMarker(null).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentDelimiter() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setDelimiter(';').build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setDelimiter(',').build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentEscapeCharacter() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setEscape('\\').build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setEscape(null).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentHeaders() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader("A", "B", "C").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader("A", "B", "D").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentHeaderComments() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeaderComments("Comment1").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeaderComments("Comment2").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentIgnoreEmptyLines() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentIgnoreHeaderCase() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setIgnoreHeaderCase(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setIgnoreHeaderCase(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentIgnoreSurroundingSpaces() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentNullString() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setNullString("NULL").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setNullString("N/A").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentQuoteCharacter() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setQuote('\'').build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setQuote('"').build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentQuoteMode() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.MINIMAL).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentQuotedNullString() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setNullString("NULL").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setNullString("N/A").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentRecordSeparator() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setRecordSeparator("\n").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setRecordSeparator("\r\n").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentSkipHeaderRecord() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setSkipHeaderRecord(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setSkipHeaderRecord(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentTrailingDelimiter() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setTrailingDelimiter(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentTrim() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setTrim(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setTrim(false).build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsAllFieldsDifferent() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(CSVFormat.DuplicateHeaderMode.ALLOW_ALL)
                .setAllowMissingColumnNames(false)
                .setAutoFlush(true)
                .setCommentMarker('#')
                .setDelimiter(';')
                .setEscape('\\')
                .setHeader("X", "Y", "Z")
                .setHeaderComments("Header Comment")
                .setIgnoreEmptyLines(true)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setNullString("NULL")
                .setQuote('\'')
                .setQuoteMode(QuoteMode.ALL)
                .setRecordSeparator("\n")
                .setSkipHeaderRecord(true)
                .setTrailingDelimiter(true)
                .setTrim(true)
                .build();
        
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(CSVFormat.DuplicateHeaderMode.ALLOW_EMPTY)
                .setAllowMissingColumnNames(true)
                .setAutoFlush(false)
                .setCommentMarker('*')
                .setDelimiter(',')
                .setEscape(null)
                .setHeader("A", "B", "C")
                .setHeaderComments("Different Comment")
                .setIgnoreEmptyLines(false)
                .setIgnoreHeaderCase(false)
                .setIgnoreSurroundingSpaces(false)
                .setNullString("N/A")
                .setQuote('"')
                .setQuoteMode(QuoteMode.MINIMAL)
                .setRecordSeparator("\r\n")
                .setSkipHeaderRecord(false)
                .setTrailingDelimiter(false)
                .setTrim(false)
                .build();
        
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsHeadersBothNull() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader((String[]) null).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader((String[]) null).build();
        assertTrue(format1.equals(format2));
    }

    @Test
    void testEqualsHeadersOneNullOneNot() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader((String[]) null).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader("A", "B").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsHeadersBothEmpty() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader(new String[] {}).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader(new String[] {}).build();
        assertTrue(format1.equals(format2));
    }

    @Test
    void testEqualsHeadersDifferentOrder() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader("A", "B", "C").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader("A", "C", "B").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsHeaderCommentsBothNull() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeaderComments((String[]) null).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeaderComments((String[]) null).build();
        assertTrue(format1.equals(format2));
    }

    @Test
    void testEqualsHeaderCommentsOneNullOneNot() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeaderComments((String[]) null).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeaderComments("Comment").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsHeaderCommentsBothEmpty() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeaderComments(new String[] {}).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeaderComments(new String[] {}).build();
        assertTrue(format1.equals(format2));
    }

    @Test
    void testEqualsHeaderCommentsDifferent() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeaderComments("Comment1").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeaderComments("Comment2").build();
        assertFalse(format1.equals(format2));
    }

    @Test
    void testEqualsWithMockitoResultSetMetaData() throws Exception {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader("A", "B").build();
        
        ResultSetMetaData metaData = Mockito.mock(ResultSetMetaData.class);
        Mockito.when(metaData.getColumnCount()).thenReturn(2);
        Mockito.when(metaData.getColumnLabel(1)).thenReturn("A");
        Mockito.when(metaData.getColumnLabel(2)).thenReturn("B");
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader(metaData).build();
        
        assertTrue(format1.equals(format2));
    }

    @Test
    void testEqualsWithNullFields() {
        CSVFormat format1 = new CSVFormat(null, null, null, null, null, false, false, null, null, null, null, false, false, false, false, false, false, CSVFormat.DuplicateHeaderMode.ALLOW_ALL);
        CSVFormat format2 = new CSVFormat(null, null, null, null, null, false, false, null, null, null, null, false, false, false, false, false, false, CSVFormat.DuplicateHeaderMode.ALLOW_ALL);
        assertTrue(format1.equals(format2));
    }

    @Test
    void testEqualsDifferentDuplicateHeaderModeNull() {
        CSVFormat format1 = new CSVFormat(null, null, null, null, null, false, false, null, null, null, null, false, false, false, false, false, false, CSVFormat.DuplicateHeaderMode.ALLOW_EMPTY);
        CSVFormat format2 = new CSVFormat(null, null, null, null, null, false, false, null, null, null, null, false, false, false, false, false, false, CSVFormat.DuplicateHeaderMode.ALLOW_ALL);
        assertFalse(format1.equals(format2));
    }
}