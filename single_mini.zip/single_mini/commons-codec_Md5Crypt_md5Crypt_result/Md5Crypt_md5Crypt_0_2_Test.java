package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.codec.Charsets;

public class Md5Crypt_md5Crypt_0_2_Test {

    @Test
    @DisplayName("md5Crypt with empty keyBytes array")
    void TC06() {
        byte[] keyBytes = new byte[0];
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        assertTrue(result.startsWith("$1$salt1234$"));
        int expectedLength = prefix.length() + "salt1234".length() + 1 + 22;
        assertEquals(expectedLength, result.length());
    }

    @Test
    @DisplayName("md5Crypt with keyBytes length less than 16 bytes")
    void TC07() {
        byte[] keyBytes = "pass1234".getBytes(Charsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        assertTrue(result.startsWith("$1$salt1234$"));
        int expectedLength = prefix.length() + "salt1234".length() + 1 + 22;
        assertEquals(expectedLength, result.length());
    }

    @Test
    @DisplayName("md5Crypt with keyBytes length exactly 16 bytes")
    void TC08() {
        byte[] keyBytes = "password12345678".getBytes(Charsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        assertTrue(result.startsWith("$1$salt1234$"));
        int expectedLength = prefix.length() + "salt1234".length() + 1 + 22;
        assertEquals(expectedLength, result.length());
    }

    @Test
    @DisplayName("md5Crypt with keyBytes length greater than 16 bytes")
    void TC09() {
        byte[] keyBytes = "passwordpasswordpasswordpass".getBytes(Charsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        assertTrue(result.startsWith("$1$salt1234$"));
        int expectedLength = prefix.length() + "salt1234".length() + 1 + 22;
        assertEquals(expectedLength, result.length());
    }

    @Test
    @DisplayName("md5Crypt processes salt with minimum allowed characters")
    void TC10() {
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$s";
        String prefix = "$1$";
        
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        assertTrue(result.startsWith("$1$s$"));
        int expectedLength = prefix.length() + "s".length() + 1 + 22;
        assertEquals(expectedLength, result.length());
    }
}