package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.GradientPaintTransformer;
import org.jfree.data.category.CategoryDataset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class WaterfallBarRenderer_drawItem_1_2_Test {

    @Test
    @DisplayName("drawItem with column index equal to last column and dataset value is null")
    void TC21_drawItem_withLastColumn_andNullValue() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 2)).thenReturn(null);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setLastBarPaint(Color.ORANGE);
        when(state.getSeriesRunningTotal()).thenReturn(20.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 2, 0);

        // Assert
        verify(g2).setPaint(Color.ORANGE);
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(0.0);
    }

    @Test
    @DisplayName("drawItem with getGradientPaintTransformer returning null despite seriesPaint being GradientPaint")
    void TC22_drawItem_withGradientPaintTransformer_present_but_seriesPaint_not_GradientPaint() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        GradientPaintTransformer transformer = mock(GradientPaintTransformer.class);
        renderer.setGradientPaintTransformer(transformer);
        Paint nonGradientPaint = Color.PINK;
        renderer.setPositiveBarPaint(nonGradientPaint);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // Assert
        verify(g2).setPaint(nonGradientPaint);
        verify(g2).fill(any(Rectangle2D.class));
        verify(transformer, never()).transform(any(), any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem with orientation neither HORIZONTAL nor VERTICAL")
    void TC23_drawItem_withInvalidOrientation() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(null); // Invalid orientation
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setPositiveBarPaint(Color.GREEN);

        // Act & Assert
        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0));
        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
        // Ensure method completes gracefully without exceptions
    }

    @Test
    @DisplayName("drawItem with entityCollection as null")
    void TC24_drawItem_withEntityCollection_null() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getEntityCollection()).thenReturn(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setPositiveBarPaint(Color.GREEN);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // Assert
        verify(renderer, never()).addItemEntity(any(), any(), anyInt(), anyInt(), any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem with dataset having single column and null value")
    void TC25_drawItem_singleColumn_withNullValue() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getSeriesRunningTotal()).thenReturn(15.0);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getValue(0, 0)).thenReturn(null);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setLastBarPaint(Color.ORANGE);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        verify(g2).setPaint(Color.ORANGE);
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(0.0);
    }
}