import org.apache.commons.lang3.time.DurationFormatUtils;
import org.junit.jupiter.api.Test;

import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

class DurationFormatUtilsTest {

    @Test
    void testFormatPeriodWithNormalValues() {
        String result = DurationFormatUtils.formatPeriod(0, 1000, "s's'", true, TimeZone.getDefault());
        assertEquals("1s", result);

        result = DurationFormatUtils.formatPeriod(0, 1000, "ss's'", true, TimeZone.getDefault());
        assertEquals("01s", result);
    }

    @Test
    void testFormatPeriodWithoutPadding() {
        String result = DurationFormatUtils.formatPeriod(0, 3600000, "H'h'm'm's's'", false, TimeZone.getDefault());
        assertEquals("1h0m0s", result);

        result = DurationFormatUtils.formatPeriod(0, 3661000, "H'h'm'm's's'S'S'", false, TimeZone.getDefault());
        assertEquals("1h1m1s1", result);
    }

    @Test
    void testFormatPeriodNegativeValues() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            DurationFormatUtils.formatPeriod(1000, 0, "s's'", true, TimeZone.getDefault());
        });
        assertEquals("startMillis must not be greater than endMillis", exception.getMessage());
    }

    @Test
    void testFormatPeriodZeroDuration() {
        String result = DurationFormatUtils.formatPeriod(0, 0, "s's'", true, TimeZone.getDefault());
        assertEquals("0s", result);
    }

    @Test
    void testFormatPeriodWithOptionalBlocks() {
        String result = DurationFormatUtils.formatPeriod(0, 1000, "d'd'[H'h'm'm']s's'", true, TimeZone.getDefault());
        assertEquals("0s", result);

        result = DurationFormatUtils.formatPeriod(0, 3661000, "[d'd'[H'h'm'm']s's']S'S'", true, TimeZone.getDefault());
        assertEquals("1h1m1s1", result);
    }

    @Test
    void testFormatPeriodWithEdgeCases() {
        // Test with near-boundary values
        String result = DurationFormatUtils.formatPeriod(0, Long.MAX_VALUE, "y'Y'M'M'd'D'H'h'm'm's's'S'S'", true, TimeZone.getDefault());
        assertNotNull(result); // Check for no exception and not null result

        result = DurationFormatUtils.formatPeriod(0, Long.MAX_VALUE, "y'M'd'H'm's'S'", false, TimeZone.getDefault());
        assertNotNull(result);
    }

    @Test
    void testFormatPeriodComplexFormat() {
        String result = DurationFormatUtils.formatPeriod(0, 1234567890123L, 
                "y' years 'M' months 'd' days 'H' hours 'm' minutes 's' seconds 'S' milliseconds'", false, 
                TimeZone.getDefault());
        assertNotNull(result);
    }

    @Test
    void testFormatPeriodSpecificTimezone() {
        TimeZone tz = TimeZone.getTimeZone("GMT+5");
        String result = DurationFormatUtils.formatPeriod(0, 3600000, "H'h'", true, tz);
        assertEquals("0h", result); // Test to ensure time zone does not affect hour calculation improperly
    }
}