package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.ui.RectangleEdge;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BarRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem adjusts bar length when below minimumBarLength")
    public void TC06_drawItem_adjustsBarLengthBelowMinimum() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenReturn(1); // Small value below minimumBarLength
        doReturn(10.0).when(renderer).getMinimumBarLength(); // Use doReturn for spy object
        when(rangeAxis.isInverted()).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(5.0).thenReturn(15.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        ArgumentCaptor<Rectangle2D> barCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(renderer.getBarPainter(), times(1)).paintBar(eq(g2), eq(renderer), eq(row), eq(column), barCaptor.capture(), any());
        Rectangle2D bar = barCaptor.getValue();
        assertEquals(10.0, bar.getHeight(), 0.001, "Bar length should be adjusted to minimumBarLength");
    }

    @Test
    @DisplayName("drawItem handles horizontal orientation with minimumBarLength adjustment")
    public void TC07_drawItem_horizontalOrientation_withMinimumBarLengthAdjustment() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 1;
        int column = 1;
        int pass = 0;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenReturn(2); // Small positive value
        doReturn(8.0).when(renderer).getMinimumBarLength(); // Use doReturn for spy object
        when(rangeAxis.isInverted()).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(3.0).thenReturn(10.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        ArgumentCaptor<Rectangle2D> barCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        ArgumentCaptor<RectangleEdge> edgeCaptor = ArgumentCaptor.forClass(RectangleEdge.class);
        verify(renderer.getBarPainter(), times(1)).paintBarShadow(eq(g2), eq(renderer), eq(row), eq(column), any(), edgeCaptor.capture(), anyBoolean());
        verify(renderer.getBarPainter(), times(1)).paintBar(eq(g2), eq(renderer), eq(row), eq(column), barCaptor.capture(), edgeCaptor.capture());
        Rectangle2D bar = barCaptor.getValue();
        assertEquals(8.0, bar.getWidth(), 0.001, "Bar length should be adjusted to minimumBarLength");
        assertEquals(RectangleEdge.RIGHT, edgeCaptor.getAllValues().get(1), "Bar should be drawn with RectangleEdge.RIGHT");
    }

    @Test
    @DisplayName("drawItem processes item label when generator is present and label is visible")
    public void TC08_drawItem_withItemLabelVisible() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        CategoryItemLabelGenerator labelGenerator = mock(CategoryItemLabelGenerator.class);

        int row = 2;
        int column = 2;
        int pass = 0;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenReturn(15); // Valid value
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(labelGenerator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(labelGenerator.generateLabel(dataset, row, column)).thenReturn("Label");
        when(rangeAxis.isInverted()).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(7.0).thenReturn(20.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(labelGenerator, times(1)).generateLabel(dataset, row, column);
        // Additional verifications can be added to ensure label drawing logic
    }

    @Test
    @DisplayName("drawItem skips label drawing when generator returns null")
    public void TC09_drawItem_labelGeneratorReturnsNull() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        CategoryItemLabelGenerator labelGenerator = mock(CategoryItemLabelGenerator.class);

        int row = 3;
        int column = 3;
        int pass = 0;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenReturn(20); // Valid value
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(labelGenerator);
        when(labelGenerator.generateLabel(dataset, row, column)).thenReturn(null);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0).thenReturn(25.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(labelGenerator, times(1)).generateLabel(dataset, row, column);
        // Verify that drawing methods for labels are not called
    }

    @Test
    @DisplayName("drawItem skips label drawing when label visibility is false")
    public void TC10_drawItem_labelVisibilityFalse() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        CategoryItemLabelGenerator labelGenerator = mock(CategoryItemLabelGenerator.class);

        int row = 4;
        int column = 4;
        int pass = 0;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenReturn(25); // Valid value
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(labelGenerator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(12.0).thenReturn(30.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(labelGenerator, never()).generateLabel(any(), anyInt(), anyInt());
        // Verify that drawing methods for labels are not called
    }
}