import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Point2D;
import java.util.HashMap;
import java.util.Map;

import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;

public class XYPlotTest {

    @Test
    void testCloneDefaultXYPlot() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertEquals(original.getOrientation(), clone.getOrientation());
        assertEquals(original.getAxisOffset(), clone.getAxisOffset());
        assertEquals(original.getDomainAxes(), clone.getDomainAxes());
        assertEquals(original.getRangeAxes(), clone.getRangeAxes());
        assertEquals(original.getRenderers(), clone.getRenderers());
        assertEquals(original.getDatasetRenderingOrder(), clone.getDatasetRenderingOrder());
        assertEquals(original.getSeriesRenderingOrder(), clone.getSeriesRenderingOrder());
        assertEquals(original.getWeight(), clone.getWeight());
        assertEquals(original.getFixedLegendItems(), clone.getFixedLegendItems());
        assertEquals(original.isDomainPannable(), clone.isDomainPannable());
        assertEquals(original.isRangePannable(), clone.isRangePannable());
        assertEquals(original.getShadowGenerator(), clone.getShadowGenerator());
    }

    @Test
    void testCloneWithNonNullDomainAndRangeAxes() throws CloneNotSupportedException {
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYPlot original = new XYPlot();
        original.setDomainAxis(domainAxis);
        original.setRangeAxis(rangeAxis);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getDomainAxis(), clone.getDomainAxis());
        assertNotSame(original.getRangeAxis(), clone.getRangeAxis());
        verify(domainAxis, times(2)).setPlot(clone);
        verify(domainAxis, times(2)).addChangeListener(clone);
        verify(rangeAxis, times(2)).setPlot(clone);
        verify(rangeAxis, times(2)).addChangeListener(clone);
    }

    @Test
    void testCloneWithNullDomainAndRangeAxes() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.setDomainAxis(1, null);
        original.setRangeAxis(1, null);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getDomainAxis(1));
        assertNull(clone.getRangeAxis(1));
    }

    @Test
    void testCloneWithNullDatasets() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.setDataset(1, null);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getDataset(1));
    }

    @Test
    void testCloneWithNonNullDatasets() throws CloneNotSupportedException {
        XYDataset dataset = mock(XYDataset.class);
        XYPlot original = new XYPlot();
        original.setDataset(1, dataset);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertSame(dataset, clone.getDataset(1));
        verify(dataset).addChangeListener(clone);
    }

    @Test
    void testCloneWithNullRenderers() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.setRenderer(1, null);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getRenderer(1));
    }

    @Test
    void testCloneWithNonNullRenderers() throws CloneNotSupportedException {
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        XYPlot original = new XYPlot();
        original.setRenderer(1, renderer);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getRenderer(1), clone.getRenderer(1));
        verify(renderer).setPlot(clone);
        verify(renderer).addChangeListener(clone);
    }

    @Test
    void testCloneWithFixedDomainAxisSpace() throws CloneNotSupportedException {
        AxisSpace axisSpace = mock(AxisSpace.class);
        XYPlot original = new XYPlot();
        original.setFixedDomainAxisSpace(axisSpace);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getFixedDomainAxisSpace(), clone.getFixedDomainAxisSpace());
    }

    @Test
    void testCloneWithNullFixedDomainAxisSpace() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.setFixedDomainAxisSpace(null);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getFixedDomainAxisSpace());
    }

    @Test
    void testCloneWithFixedRangeAxisSpace() throws CloneNotSupportedException {
        AxisSpace axisSpace = mock(AxisSpace.class);
        XYPlot original = new XYPlot();
        original.setFixedRangeAxisSpace(axisSpace);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getFixedRangeAxisSpace(), clone.getFixedRangeAxisSpace());
    }

    @Test
    void testCloneWithNullFixedRangeAxisSpace() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.setFixedRangeAxisSpace(null);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getFixedRangeAxisSpace());
    }

    @Test
    void testCloneWithFixedLegendItems() throws CloneNotSupportedException {
        LegendItemCollection legendItems = new LegendItemCollection();
        XYPlot original = new XYPlot();
        original.setFixedLegendItems(legendItems);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getFixedLegendItems(), clone.getFixedLegendItems());
        assertEquals(original.getFixedLegendItems(), clone.getFixedLegendItems());
    }

    @Test
    void testCloneWithNullFixedLegendItems() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.setFixedLegendItems(null);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getFixedLegendItems());
    }

    @Test
    void testCloneWithAnnotations() throws CloneNotSupportedException {
        XYAnnotation annotation = mock(XYAnnotation.class);
        AxisSpace axisSpace = mock(AxisSpace.class);
        LegendItemCollection legendItems = new LegendItemCollection();
        XYPlot original = new XYPlot();
        original.addAnnotation(annotation);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getAnnotations(), clone.getAnnotations());
        assertEquals(original.getAnnotations(), clone.getAnnotations());
    }

    @Test
    void testCloneWithQuadrantPaint() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        Paint paint0 = mock(Paint.class);
        Paint paint1 = mock(Paint.class);
        original.setQuadrantPaint(0, paint0);
        original.setQuadrantPaint(1, paint1);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getQuadrantPaint(0), clone.getQuadrantPaint(0));
        assertNotSame(original.getQuadrantPaint(1), clone.getQuadrantPaint(1));
        assertEquals(original.getQuadrantPaint(0), clone.getQuadrantPaint(0));
        assertEquals(original.getQuadrantPaint(1), clone.getQuadrantPaint(1));
    }

    @Test
    void testCloneWithNullQuadrantPaint() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.setQuadrantPaint(0, null);
        original.setQuadrantPaint(1, null);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getQuadrantPaint(0));
        assertNull(clone.getQuadrantPaint(1));
    }

    @Test
    void testCloneWithShadowGenerator() throws CloneNotSupportedException {
        ShadowGenerator shadowGenerator = mock(ShadowGenerator.class);
        XYPlot original = new XYPlot();
        original.setShadowGenerator(shadowGenerator);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getShadowGenerator()); // ShadowGenerator is transient and not cloned
    }

    @Test
    void testCloneWithNullAnnotations() throws CloneNotSupportedException {
        XYPlot original = new XYPlot();
        original.clearAnnotations();
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertTrue(clone.getAnnotations().isEmpty());
    }

    @Test
    void testCloneWithMultipleAxesDatasetsAndRenderers() throws CloneNotSupportedException {
        ValueAxis domainAxis1 = mock(ValueAxis.class);
        ValueAxis domainAxis2 = mock(ValueAxis.class);
        ValueAxis rangeAxis1 = mock(ValueAxis.class);
        ValueAxis rangeAxis2 = mock(ValueAxis.class);
        XYDataset dataset1 = mock(XYDataset.class);
        XYDataset dataset2 = mock(XYDataset.class);
        XYItemRenderer renderer1 = mock(XYItemRenderer.class);
        XYItemRenderer renderer2 = mock(XYItemRenderer.class);
        
        XYPlot original = new XYPlot();
        original.setDomainAxis(1, domainAxis1);
        original.setDomainAxis(2, domainAxis2);
        original.setRangeAxis(1, rangeAxis1);
        original.setRangeAxis(2, rangeAxis2);
        original.setDataset(1, dataset1);
        original.setDataset(2, dataset2);
        original.setRenderer(1, renderer1);
        original.setRenderer(2, renderer2);
        original.mapDatasetToDomainAxis(1, 1);
        original.mapDatasetToRangeAxis(1, 1);
        original.mapDatasetToDomainAxis(2, 2);
        original.mapDatasetToRangeAxis(2, 2);
        
        XYPlot clone = (XYPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getDomainAxis(1), clone.getDomainAxis(1));
        assertNotSame(original.getDomainAxis(2), clone.getDomainAxis(2));
        assertNotSame(original.getRangeAxis(1), clone.getRangeAxis(1));
        assertNotSame(original.getRangeAxis(2), clone.getRangeAxis(2));
        assertNotSame(original.getDataset(1), clone.getDataset(1));
        assertNotSame(original.getDataset(2), clone.getDataset(2));
        assertNotSame(original.getRenderer(1), clone.getRenderer(1));
        assertNotSame(original.getRenderer(2), clone.getRenderer(2));
        
        verify(domainAxis1).setPlot(clone);
        verify(domainAxis1).addChangeListener(clone);
        verify(domainAxis2).setPlot(clone);
        verify(domainAxis2).addChangeListener(clone);
        verify(rangeAxis1).setPlot(clone);
        verify(rangeAxis1).addChangeListener(clone);
        verify(rangeAxis2).setPlot(clone);
        verify(rangeAxis2).addChangeListener(clone);
        verify(dataset1).addChangeListener(clone);
        verify(dataset2).addChangeListener(clone);
        verify(renderer1).setPlot(clone);
        verify(renderer1).addChangeListener(clone);
        verify(renderer2).setPlot(clone);
        verify(renderer2).addChangeListener(clone);
    }
}