import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DfpTest {

    private final DfpField field = new DfpField(20);

    @Test
    public void testToDoublePositiveInfinity() {
        Dfp dfp = new Dfp(field, Dfp.INFINITE);
        dfp.sign = 1;
        assertEquals(Double.POSITIVE_INFINITY, dfp.toDouble());
    }

    @Test
    public void testToDoubleNegativeInfinity() {
        Dfp dfp = new Dfp(field, Dfp.INFINITE);
        dfp.sign = -1;
        assertEquals(Double.NEGATIVE_INFINITY, dfp.toDouble());
    }

    @Test
    public void testToDoubleNaN() {
        Dfp dfp = new Dfp(field, Dfp.QNAN);
        assertTrue(Double.isNaN(dfp.toDouble()));
    }

    @Test
    public void testToDoubleZero() {
        Dfp dfp = field.getZero();
        dfp.sign = 1;
        assertEquals(+0.0, dfp.toDouble());

        dfp.sign = -1;
        assertEquals(-0.0, dfp.toDouble());
    }

    @Test
    public void testToDoublePositiveNormalNumber() {
        Dfp dfp = new Dfp(field, 1.5);
        assertEquals(1.5, dfp.toDouble(), 1e-10);
    }

    @Test
    public void testToDoubleNegativeNormalNumber() {
        Dfp dfp = new Dfp(field, -2.5);
        assertEquals(-2.5, dfp.toDouble(), 1e-10);
    }

    @Test
    public void testToDoublePositiveSubnormalNumber() {
        Dfp dfp = field.newDfp((double) Math.pow(2, -1074));
        assertEquals(Math.pow(2, -1074), dfp.toDouble(), 1e-317);
    }

    @Test
    public void testToDoubleNegativeSubnormalNumber() {
        Dfp dfp = field.newDfp(-(double) Math.pow(2, -1074));
        assertEquals(-(double) Math.pow(2, -1074), dfp.toDouble(), 1e-317);
    }

    @Test
    public void testToDoubleMaxNormalNumber() {
        Dfp dfp = field.newDfp((double) Math.pow(2, 1023) * (2 - Math.pow(2, -52)));
        assertEquals(Double.MAX_VALUE, dfp.toDouble(), 1e-292);
    }

    @Test
    public void testToDoubleMinNormalNumber() {
        Dfp dfp = field.newDfp((double) Math.pow(2, -1022));
        assertEquals(Math.pow(2, -1022), dfp.toDouble(), 1e-307);
    }

    @Test
    public void testToDoubleRoundToEven() {
        Dfp dfp = new Dfp(field, 0.1);
        dfp.mant[0] = 450000000;
        dfp.exp = -1;
        assertEquals(0.1, dfp.toDouble(), 1e-10);
    }
}