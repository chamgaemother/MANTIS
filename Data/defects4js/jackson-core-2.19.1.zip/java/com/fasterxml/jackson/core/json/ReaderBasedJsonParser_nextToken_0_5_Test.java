package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

public class ReaderBasedJsonParser_nextToken_0_5_Test {

    @Test
    @DisplayName("nextToken() throws exception when encountering invalid character")
    void TC21() throws IOException {
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser("@");
        
        Exception exception = assertThrows(IOException.class, () -> {
            parser.nextToken();
        });
        
        String expectedMessage = "Unexpected character '@'";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    @DisplayName("nextToken() parses unsigned number correctly")
    void TC22() throws IOException {
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser("123");
        
        JsonToken token = parser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token, "Token should be VALUE_NUMBER_INT");
        assertEquals(123, parser.getIntValue(), "Parsed integer value should be 123");
    }

    @Test
    @DisplayName("nextToken() handles incomplete number at buffer end")
    void TC23() throws IOException {
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser("-");
        
        Exception exception = assertThrows(IOException.class, () -> {
            parser.nextToken();
        });
        
        String expectedMessage = "Unexpected end-of-input";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    @DisplayName("nextToken() parses floating number with exponent")
    void TC24() throws IOException {
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser("1.23e4");
        
        JsonToken token = parser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token, "Token should be VALUE_NUMBER_FLOAT");
        assertEquals(12300.0, parser.getDoubleValue(), 0.0001, "Parsed floating value should be 12300.0");
    }

    @Test
    @DisplayName("nextToken() handles invalid number format and throws exception")
    void TC25() throws IOException {
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser("1.2.3");
        
        Exception exception = assertThrows(IOException.class, () -> {
            parser.nextToken();
        });
        
        String expectedMessage = "Invalid number format";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }
}