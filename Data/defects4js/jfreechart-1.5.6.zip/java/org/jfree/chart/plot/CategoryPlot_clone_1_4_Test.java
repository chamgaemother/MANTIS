// package org.jfree.chart.plot;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// import org.jfree.chart.LegendItemCollection;
// import org.jfree.chart.plot.CategoryMarker;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.renderer.category.DefaultCategoryItemRenderer;
// import org.jfree.chart.renderer.category.CategoryItemRenderer;
// import org.jfree.chart.util.ObjectUtils;
// import org.jfree.chart.annotations.CategoryAnnotation;
// import org.jfree.chart.annotations.CategoryMarker;
// import org.jfree.chart.util.PaintUtils;
// import org.jfree.legend.LegendItemCollection;
// import org.jfree.chart.LegendItem;
// import java.lang.reflect.Field;
// import java.util.Arrays;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
// import java.util.Collection;
// import java.io.IOException;
// 
// public class CategoryPlot_clone_1_4_Test {
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with all non-null renderers")
//     public void TC16_cloneWithAllNonNullRenderers() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         CategoryItemRenderer renderer1 = new DefaultCategoryItemRenderer();
//         CategoryItemRenderer renderer2 = new DefaultCategoryItemRenderer();
//         original.setRenderer(0, renderer1);
//         original.setRenderer(1, renderer2);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         // Verify that renderers are not null
//         assertNotNull(clone.getRenderer(0), "Renderer at index 0 should not be null");
//         assertNotNull(clone.getRenderer(1), "Renderer at index 1 should not be null");
// 
//         // Verify that renderers are cloned and not the same instances
//         assertNotSame(original.getRenderer(0), clone.getRenderer(0), "Renderer at index 0 should be a cloned instance");
//         assertNotSame(original.getRenderer(1), clone.getRenderer(1), "Renderer at index 1 should be a cloned instance");
// 
//         // Verify that renderers are linked to the cloned plot
//         Field plotField = CategoryItemRenderer.class.getDeclaredField("plot");
//         plotField.setAccessible(true);
//         assertEquals(clone, plotField.get(clone.getRenderer(0)), "Renderer 0 should be linked to the cloned plot");
//         assertEquals(clone, plotField.get(clone.getRenderer(1)), "Renderer 1 should be linked to the cloned plot");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with some null renderers")
//     public void TC17_cloneWithSomeNullRenderers() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         CategoryItemRenderer renderer1 = new DefaultCategoryItemRenderer();
//         CategoryItemRenderer renderer2 = null;
//         original.setRenderer(0, renderer1);
//         original.setRenderer(1, renderer2);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         // Verify that primary renderer is cloned and non-null
//         assertNotNull(clone.getRenderer(0), "Renderer at index 0 should not be null");
//         // Verify that secondary renderer remains null
//         assertNull(clone.getRenderer(1), "Renderer at index 1 should be null");
// 
//         // Verify that renderer 0 is a cloned instance
//         assertNotSame(original.getRenderer(0), clone.getRenderer(0), "Renderer at index 0 should be a cloned instance");
// 
//         // Verify that renderer 0 is linked to the cloned plot
//         Field plotField = CategoryItemRenderer.class.getDeclaredField("plot");
//         plotField.setAccessible(true);
//         assertEquals(clone, plotField.get(clone.getRenderer(0)), "Renderer 0 should be linked to the cloned plot");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with some null markers in foregroundDomainMarkers")
//     public void TC18_cloneWithSomeNullMarkersInForegroundDomainMarkers() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         CategoryMarker marker1 = new CategoryMarker("Category1");
//         CategoryMarker marker2 = null;
//         Map<Integer, Collection<CategoryMarker>> markers = new HashMap<>();
//         markers.put(0, Arrays.asList(marker1, marker2));
//         original.foregroundDomainMarkers = markers;
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         // Access private field foregroundDomainMarkers via reflection
//         Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
//         foregroundMarkersField.setAccessible(true);
//         Map<Integer, Collection<CategoryMarker>> cloneMarkers = (Map<Integer, Collection<CategoryMarker>>) foregroundMarkersField.get(clone);
// 
//         assertNotNull(cloneMarkers.get(0), "ForegroundDomainMarkers for index 0 should not be null");
//         assertEquals(1, cloneMarkers.get(0).size(), "ForegroundDomainMarkers for index 0 should contain only non-null markers");
//         assertTrue(cloneMarkers.get(0).contains(marker1), "Cloned markers should contain marker1");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with all markers non-null in backgroundRangeMarkers")
//     public void TC19_cloneWithAllMarkersNonNullInBackgroundRangeMarkers() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         Marker marker1 = new CategoryMarker("Category1");
//         Marker marker2 = new CategoryMarker("Category2");
//         Map<Integer, Collection<Marker>> markers = new HashMap<>();
//         markers.put(0, Arrays.asList(marker1, marker2));
//         original.backgroundRangeMarkers = markers;
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         // Access private field backgroundRangeMarkers via reflection
//         Field backgroundMarkersField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
//         backgroundMarkersField.setAccessible(true);
//         Map<Integer, Collection<Marker>> cloneMarkers = (Map<Integer, Collection<Marker>>) backgroundMarkersField.get(clone);
// 
//         assertNotNull(cloneMarkers.get(0), "BackgroundRangeMarkers for index 0 should not be null");
//         assertEquals(2, cloneMarkers.get(0).size(), "BackgroundRangeMarkers for index 0 should contain both markers");
//         assertTrue(cloneMarkers.get(0).contains(marker1), "Cloned markers should contain marker1");
//         assertTrue(cloneMarkers.get(0).contains(marker2), "Cloned markers should contain marker2");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with non-empty fixedLegendItems")
//     public void TC20_cloneWithNonEmptyFixedLegendItems() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         LegendItemCollection legendItems = new LegendItemCollection();
//         LegendItem item1 = new LegendItem("Series 1");
//         LegendItem item2 = new LegendItem("Series 2");
//         legendItems.add(item1);
//         legendItems.add(item2);
//         original.setFixedLegendItems(legendItems);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         // Access private field fixedLegendItems via reflection
//         Field fixedLegendItemsField = CategoryPlot.class.getDeclaredField("fixedLegendItems");
//         fixedLegendItemsField.setAccessible(true);
//         LegendItemCollection cloneLegendItems = (LegendItemCollection) fixedLegendItemsField.get(clone);
// 
//         assertNotNull(cloneLegendItems, "FixedLegendItems should not be null");
//         assertEquals(2, cloneLegendItems.getItemCount(), "FixedLegendItems should contain two items");
//         assertTrue(cloneLegendItems.get(0).equals(item1), "First LegendItem should match");
//         assertTrue(cloneLegendItems.get(1).equals(item2), "Second LegendItem should match");
//     }
// 
// }