package org.joda.time;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class PeriodType_forFields_0_2_Test {

    @Test
    @DisplayName("Returns cached PeriodType when cache contains a valid PeriodType")
    void TC06_forFields_cacheValidHit() throws Exception {
        // Reflection to access the private static cTypes field
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);

        // Ensure cTypes is not null (fix potential null pointer)
        assertNotNull(cTypes, "cTypes map should not be null");

        // Clear and set up the cache
        cTypes.clear();
        DurationFieldType[] types = { DurationFieldType.years(), DurationFieldType.months(), DurationFieldType.days() };
        PeriodType cachedType = PeriodType.yearMonthDay();
        PeriodType key = new PeriodType(null, types, null);
        cTypes.put(key, cachedType);

        // Invoke the method under test
        PeriodType result = PeriodType.forFields(types);

        // Assert the result is the cached type
        assertSame(cachedType, result);
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when cache contains unsupported fields")
    void TC07_forFields_cacheUnsupportedFields() throws Exception {
        // Reflection to access the private static cTypes field
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);

        // Ensure cTypes is not null (fix potential null pointer)
        assertNotNull(cTypes, "cTypes map should not be null");

        // Clear and set up the cache with unsupported fields
        cTypes.clear();
        DurationFieldType[] types = { DurationFieldType.years(), DurationFieldType.days() };
        List<DurationFieldType> unsupportedFields = Arrays.asList(DurationFieldType.millis()); // Correctly setting invalid fields
        PeriodType key = new PeriodType(null, types, null);
        cTypes.put(key, unsupportedFields);

        // Invoke the method under test and assert exception
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            PeriodType.forFields(types);
        });
        assertTrue(exception.getMessage().contains("PeriodType does not support fields"), "Exception message should describe unsupported fields");
    }

    @Test
    @DisplayName("Removes years from PeriodType when years field is not present")
    void TC08_forFields_removeYears() throws Exception {
        // Reflection to access the private static cTypes field
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);

        // Ensure cTypes is not null (fix potential null pointer)
        assertNotNull(cTypes, "cTypes map should not be null");

        // Clear the cache
        cTypes.clear();
        DurationFieldType[] types = { DurationFieldType.months(), DurationFieldType.days() };

        // Invoke the method under test
        PeriodType result = PeriodType.forFields(types);

        // Assert that years are not supported
        assertFalse(result.isSupported(DurationFieldType.years()), "Years field should be removed");
    }

    @Test
    @DisplayName("Removes months from PeriodType when months field is not present")
    void TC09_forFields_removeMonths() throws Exception {
        // Reflection to access the private static cTypes field
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);

        // Ensure cTypes is not null (fix potential null pointer)
        assertNotNull(cTypes, "cTypes map should not be null");

        // Clear the cache
        cTypes.clear();
        DurationFieldType[] types = { DurationFieldType.years(), DurationFieldType.days() };

        // Invoke the method under test
        PeriodType result = PeriodType.forFields(types);

        // Assert that months are not supported
        assertFalse(result.isSupported(DurationFieldType.months()), "Months field should be removed");
    }

    @Test
    @DisplayName("Handles multiple field removals (weeks, days, hours)")
    void TC10_forFields_removeWeeksDaysHours() throws Exception {
        // Reflection to access the private static cTypes field
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);

        // Ensure cTypes is not null (fix potential null pointer)
        assertNotNull(cTypes, "cTypes map should not be null");

        // Clear the cache
        cTypes.clear();
        DurationFieldType[] types = { DurationFieldType.years(), DurationFieldType.months(), DurationFieldType.minutes(), DurationFieldType.seconds() };

        // Invoke the method under test
        PeriodType result = PeriodType.forFields(types);

        // Assert that weeks, days, and hours are not supported
        assertFalse(result.isSupported(DurationFieldType.weeks()), "Weeks field should be removed");
        assertFalse(result.isSupported(DurationFieldType.days()), "Days field should be removed");
        assertFalse(result.isSupported(DurationFieldType.hours()), "Hours field should be removed");
    }
}