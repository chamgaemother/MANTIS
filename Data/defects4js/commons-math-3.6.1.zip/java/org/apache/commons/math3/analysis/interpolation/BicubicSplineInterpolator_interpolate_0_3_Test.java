package org.apache.commons.math3.analysis.interpolation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolator;
import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;

public class BicubicSplineInterpolator_interpolate_0_3_Test {

    @Test
    @DisplayName("Interpolate with null xval array, expecting NullPointerException")
    void test_TC11() {
        // GIVEN
        double[] xval = null;
        double[] yval = {1.0};
        double[][] fval = {{2.0}};

        // WHEN & THEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    @DisplayName("Interpolate with null yval array, expecting NullPointerException")
    void test_TC12() {
        // GIVEN
        double[] xval = {1.0};
        double[] yval = null;
        double[][] fval = {{2.0}};

        // WHEN & THEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    @DisplayName("Interpolate with null fval array, expecting NullPointerException")
    void test_TC13() {
        // GIVEN
        double[] xval = {1.0};
        double[] yval = {2.0};
        double[][] fval = null;

        // WHEN & THEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    @DisplayName("Interpolate with initializeDerivatives set to true, verifying derivative calculations")
    void test_TC14() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {4.0, 5.0, 6.0};
        double[][] fval = {
            {7.0, 8.0, 9.0},
            {10.0, 11.0, 12.0},
            {13.0, 14.0, 15.0}
        };
        boolean initializeDerivatives = true;

        // WHEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator(initializeDerivatives);
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "Interpolating function should not be null");
        // Since the method initializes derivatives, we can perform basic checks
        // For example, evaluate derivatives at a point and ensure they do not throw exceptions
        assertDoesNotThrow(() -> {
            double partialX = result.partialDerivativeX(2.0, 5.0);
            double partialY = result.partialDerivativeY(2.0, 5.0);
            // Further assertions can be added based on expected derivative values
        }, "Derivatives should be correctly initialized and accessible");
    }
}