package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil.Checker;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class MapSerializer_serializeFilteredAnyProperties_0_3_Test {

    @Test
    @DisplayName("serializeFilteredAnyProperties with one entry, suppressableValue is present but does not equal valueElem")
    void TC11() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();

        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "nonSuppressableValue");
        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object bean = new Object();
        Checker inclusionChecker = null;

        // Mock behavior
        doNothing().when(filter).serializeAsField(any(), any(), any(), any());

        // Act
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, inclusionChecker);

        // Assert
        // Since JsonGenerator is mocked, verify that serializeAsField was called once with "key1"
        verify(filter, times(1)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("serializeFilteredAnyProperties with multiple entries, some ignored by inclusionChecker and some serialized")
    void TC12() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();

        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");
        value.put("key2", "value2");
        value.put("key3", "value3");

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object bean = new Object();

        Checker inclusionChecker = mock(Checker.class);
        when(inclusionChecker.shouldIgnore("key1")).thenReturn(false);
        when(inclusionChecker.shouldIgnore("key2")).thenReturn(true);
        when(inclusionChecker.shouldIgnore("key3")).thenReturn(false);

        // Mock behavior
        doNothing().when(filter).serializeAsField(any(), any(), any(), any());

        // Act
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, inclusionChecker);

        // Assert
        // Verify serializeAsField was called for key1 and key3, but not for key2
        verify(filter, times(2)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("serializeFilteredAnyProperties throws exception during filter.serializeAsField")
    void TC13() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();

        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");
        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object bean = new Object();
        Checker inclusionChecker = null;

        // Mock behavior to throw exception
        doThrow(new RuntimeException("Serialization error")).when(filter).serializeAsField(any(), any(), any(), any());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, inclusionChecker);
        });
        assertEquals("Serialization error", exception.getMessage());
    }

    @Test
    @DisplayName("serializeFilteredAnyProperties with multiple iterations covering various branch conditions")
    void TC14() throws Exception {
        // Arrange
        MapSerializer mapSerializer = createMapSerializer();

        // Use reflection to set private fields
        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, true);

        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, "suppressableValue");

        JsonSerializer<Object> mockValueSer = mock(JsonSerializer.class);
        when(mockValueSer.isEmpty(any(SerializerProvider.class), eq("value1"))).thenReturn(false);

        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, mockValueSer);

        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1"); // to be serialized
        value.put("key2", null); // to be skipped due to suppressNulls
        value.put("key3", "suppressableValue"); // to be skipped

        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object bean = new Object();

        Checker inclusionChecker = mock(Checker.class);
        when(inclusionChecker.shouldIgnore("key1")).thenReturn(false);
        when(inclusionChecker.shouldIgnore("key2")).thenReturn(false);
        when(inclusionChecker.shouldIgnore("key3")).thenReturn(false);

        // Mock behavior
        doNothing().when(filter).serializeAsField(any(), any(), any(), any());

        // Act
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, inclusionChecker);

        // Assert
        // Verify serializeAsField was called only for key1
        verify(filter, times(1)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
        // You can add more specific verifications as needed
    }

    private MapSerializer createMapSerializer() {
        // This method replaces direct instantiation to correctly initialize MapSerializer
        // using a default constructor and setting necessary fields using reflection
        return new MapSerializer(
                null, null, null, false, null, null, null);
    }

}