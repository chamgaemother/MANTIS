package com.fasterxml.jackson.databind.ser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BeanPropertyWriter_serializeAsField_0_1_Test {

    @Test
    @DisplayName("serializeAsField with _accessorMethod != null and value is null, _suppressableValue is null, _nullSerializer is defined")
    void TC01_serializeAsField_with_accessorMethod_and_null_value() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter(null, null, null, null, null, null, null, false, null);
        
        // Set _accessorMethod
        Method accessorMethod = BeanPropertyWriter.class.getDeclaredMethod("get", Object.class);
        accessorMethod.setAccessible(true);
        Field accessorField = BeanPropertyWriter.class.getDeclaredField("_accessorMethod");
        accessorField.setAccessible(true);
        accessorField.set(writer, accessorMethod);

        // Set _nullSerializer
        JsonSerializer<Object> nullSerializer = mock(JsonSerializer.class);
        Field nullSerializerField = BeanPropertyWriter.class.getDeclaredField("_nullSerializer");
        nullSerializerField.setAccessible(true);
        nullSerializerField.set(writer, nullSerializer);

        // Set _suppressableValue to null
        Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(writer, null);

        // Mock bean with field value null
        Object bean = mock(Object.class);
        when(accessorMethod.invoke(bean, (Object[]) null)).thenReturn(null);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Mock SerializerProvider
        SerializerProvider prov = mock(SerializerProvider.class);

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Assert
        verify(gen).writeFieldName(anyString());
        verify(nullSerializer).serialize(isNull(), eq(gen), eq(prov));
    }

    @Test
    @DisplayName("serializeAsField with _accessorMethod == null and value is null, _suppressableValue includes nulls")
    void TC02_serializeAsField_with_null_accessorMethod_and_suppressed_nulls() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter(null, null, null, null, null, null, null, false, null);
        
        // Set _accessorMethod to null
        Field accessorField = BeanPropertyWriter.class.getDeclaredField("_accessorMethod");
        accessorField.setAccessible(true);
        accessorField.set(writer, null);

        // Set _suppressableValue to suppress nulls
        Object suppressableValue = new Object(); // Represents a value that suppresses nulls
        Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(writer, suppressableValue);

        // Mock SerializerProvider to include filter suppress nulls
        SerializerProvider prov = mock(SerializerProvider.class);
        when(prov.includeFilterSuppressNulls(suppressableValue)).thenReturn(true);

        // Mock bean with field value null
        Object bean = mock(Object.class);
        Field field = BeanPropertyWriter.class.getDeclaredField("_field");
        field.setAccessible(true);
        when(field.get(bean)).thenReturn(null);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Assert
        verify(prov).includeFilterSuppressNulls(suppressableValue);
        verify(gen, never()).writeFieldName(anyString());
        verifyNoInteractions(gen);  // Updated from deprecated verifyZeroInteractions
    }

    @Test
    @DisplayName("serializeAsField with _accessorMethod defined and value is non-null, serializer is predefined")
    void TC03_serializeAsField_with_predefined_serializer_and_non_null_value() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter(null, null, null, null, null, null, null, false, null);
        
        // Set _accessorMethod
        Method accessorMethod = BeanPropertyWriter.class.getDeclaredMethod("get", Object.class);
        accessorMethod.setAccessible(true);
        Field accessorField = BeanPropertyWriter.class.getDeclaredField("_accessorMethod");
        accessorField.setAccessible(true);
        accessorField.set(writer, accessorMethod);

        // Set _serializer
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writer, serializer);

        // Set _suppressableValue to null
        Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(writer, null);

        // Mock bean with field value non-null
        Object bean = mock(Object.class);
        Object fieldValue = new Object();
        when(accessorMethod.invoke(bean, (Object[]) null)).thenReturn(fieldValue);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Mock SerializerProvider
        SerializerProvider prov = mock(SerializerProvider.class);

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Assert
        verify(prov, never()).includeFilterSuppressNulls(any());
        verify(gen).writeFieldName(anyString());
        verify(serializer).serialize(fieldValue, gen, prov);
    }

    @Test
    @DisplayName("serializeAsField with _accessorMethod null and value is non-null, dynamic serializer found")
    void TC04_serializeAsField_with_dynamic_serializer_and_non_null_value() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter(null, null, null, null, null, null, null, false, null);
        
        // Set _accessorMethod to null
        Field accessorField = BeanPropertyWriter.class.getDeclaredField("_accessorMethod");
        accessorField.setAccessible(true);
        accessorField.set(writer, null);

        // Set _serializer to null
        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writer, null);

        // Set _dynamicSerializers with a serializer for the value's class
        PropertySerializerMap dynamicSerializers = mock(PropertySerializerMap.class);
        JsonSerializer<Object> dynamicSerializer = mock(JsonSerializer.class);
        when(dynamicSerializers.serializerFor(any())).thenReturn(dynamicSerializer);

        Field dynamicSerializersField = BeanPropertyWriter.class.getDeclaredField("_dynamicSerializers");
        dynamicSerializersField.setAccessible(true);
        dynamicSerializersField.set(writer, dynamicSerializers);

        // Mock bean with field value non-null
        Object bean = mock(Object.class);
        Field field = BeanPropertyWriter.class.getDeclaredField("_field");
        field.setAccessible(true);
        Object fieldValue = new Object();
        when(field.get(bean)).thenReturn(fieldValue);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Mock SerializerProvider
        SerializerProvider prov = mock(SerializerProvider.class);
        when(prov.constructSpecializedType(any(), any())).thenReturn(mock(com.fasterxml.jackson.databind.JavaType.class));

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Assert
        verify(dynamicSerializers).serializerFor(fieldValue.getClass());
        verify(gen).writeFieldName(anyString());
        verify(dynamicSerializer).serialize(fieldValue, gen, prov);
    }

    @Test
    @DisplayName("serializeAsField with _suppressableValue as MARKER_FOR_EMPTY and serializer.isEmpty returns true")
    void TC05_serializeAsField_with_suppressableValue_MARKER_FOR_EMPTY_and_empty_serializer() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter(null, null, null, null, null, null, null, false, BeanPropertyWriter.MARKER_FOR_EMPTY);
        
        // Set _serializer with isEmpty returning true
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        when(serializer.isEmpty(any(SerializerProvider.class), any())).thenReturn(true);
        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writer, serializer);

        // Mock bean with field value non-null
        Object bean = mock(Object.class);
        Field field = BeanPropertyWriter.class.getDeclaredField("_field");
        field.setAccessible(true);
        Object fieldValue = new Object();
        when(field.get(bean)).thenReturn(fieldValue);

        // Mock JsonGenerator
        JsonGenerator gen = mock(JsonGenerator.class);

        // Mock SerializerProvider
        SerializerProvider prov = mock(SerializerProvider.class);

        // Act
        writer.serializeAsField(bean, gen, prov);

        // Assert
        verify(serializer).isEmpty(prov, fieldValue);
        verify(gen, never()).writeFieldName(anyString());
        verify(serializer, never()).serialize(any(), any(), any());
    }
}