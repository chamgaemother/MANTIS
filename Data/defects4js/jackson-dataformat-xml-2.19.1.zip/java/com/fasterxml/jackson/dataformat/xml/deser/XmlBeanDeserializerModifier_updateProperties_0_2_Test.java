package com.fasterxml.jackson.dataformat.xml.deser;
import java.lang.reflect.*;
import java.io.*;

import java.util.*;

import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XmlBeanDeserializerModifier_updateProperties_0_2_Test {

    @Test
    @DisplayName("Single property with acc not null, b is false, and property name is the same, no renaming occurs")
    void TC06() throws Exception {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);

        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(prop.withSimpleName(anyString())).thenReturn(prop);
        when(prop.getName()).thenReturn("propertyName");

        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(prop);

        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.FALSE);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        assertEquals(1, result.size());
        assertEquals("propertyName", result.get(0).getName());
    }

    @Test
    @DisplayName("Single property with acc not null, b is false, and property name differs, property is renamed")
    void TC07() throws Exception {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);

        BeanPropertyDefinition originalProp = mock(BeanPropertyDefinition.class);
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(originalProp.getPrimaryMember()).thenReturn(acc);
        BeanPropertyDefinition newProp = mock(BeanPropertyDefinition.class);
        when(newProp.getName()).thenReturn("newName");
        when(originalProp.withSimpleName("newName")).thenReturn(newProp);
        when(originalProp.getName()).thenReturn("originalName");

        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(originalProp);

        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.FALSE);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("newName");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        assertEquals(1, result.size());
        assertEquals("newName", result.get(0).getName());
    }

    @Test
    @DisplayName("Single property with wrapperName not null and different, property is renamed")
    void TC08() throws Exception {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);

        PropertyName wrapperName = new PropertyName("wrapperName");
        BeanPropertyDefinition originalProp = mock(BeanPropertyDefinition.class);
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(originalProp.getPrimaryMember()).thenReturn(acc);
        when(originalProp.getWrapperName()).thenReturn(wrapperName);
        when(originalProp.getName()).thenReturn("originalName");
        when(originalProp.withSimpleName("wrapperName")).thenReturn(originalProp);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(originalProp);

        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.FALSE);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        assertEquals(1, result.size());
        assertEquals("wrapperName", result.get(0).getName());
    }

    @Test
    @DisplayName("Single property with wrapperName as NO_NAME, property is unwrapped and handled later")
    void TC09() throws Exception {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);

        PropertyName noName = PropertyName.NO_NAME;
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(prop.getWrapperName()).thenReturn(noName);
        when(prop.getName()).thenReturn("propertyName");

        List<BeanPropertyDefinition> propDefs = Arrays.asList(prop);

        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.FALSE);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        assertEquals(1, result.size());
        assertEquals("propertyName", result.get(0).getName());
    }

    @Test
    @DisplayName("Single property with wrapperName having empty local name, property is unwrapped and handled later")
    void TC10() throws Exception {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);

        PropertyName emptyWrapper = new PropertyName("");
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(prop.getName()).thenReturn("propertyName");

        List<BeanPropertyDefinition> propDefs = Arrays.asList(prop);

        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.FALSE);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        assertEquals(1, result.size());
        assertEquals("propertyName", result.get(0).getName());
    }
}