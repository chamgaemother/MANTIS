package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.lang.reflect.Field;

public class XPathParser_CoreFunctionName_0_6_Test {

    public static final int FUNCTION_SUM = 17;  // Add correct constant
    public static final int FUNCTION_FLOOR = 18;  // Add correct constant
    public static final int FUNCTION_CEILING = 19;  // Add correct constant
    public static final int FUNCTION_ROUND = 20;  // Add correct constant
    public static final int FUNCTION_KEY = 21;  // Add correct constant

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_SUM returns Compiler.FUNCTION_SUM")
    public void TC26() throws Exception {
        // Instantiate XPathParser with a dummy token source for initialization
        XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(null));

        // Access and set jj_nt.kind to FUNCTION_SUM using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(xpathParser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, FUNCTION_SUM);

        // Invoke CoreFunctionName and assert the result
        int result = xpathParser.CoreFunctionName();
        Assertions.assertEquals(FUNCTION_SUM, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_FLOOR returns Compiler.FUNCTION_FLOOR")
    public void TC27() throws Exception {
        // Instantiate XPathParser with a dummy token source for initialization
        XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(null));

        // Access and set jj_nt.kind to FUNCTION_FLOOR using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(xpathParser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, FUNCTION_FLOOR);

        // Invoke CoreFunctionName and assert the result
        int result = xpathParser.CoreFunctionName();
        Assertions.assertEquals(FUNCTION_FLOOR, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_CEILING returns Compiler.FUNCTION_CEILING")
    public void TC28() throws Exception {
        // Instantiate XPathParser with a dummy token source for initialization
        XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(null));

        // Access and set jj_nt.kind to FUNCTION_CEILING using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(xpathParser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, FUNCTION_CEILING);

        // Invoke CoreFunctionName and assert the result
        int result = xpathParser.CoreFunctionName();
        Assertions.assertEquals(FUNCTION_CEILING, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_ROUND returns Compiler.FUNCTION_ROUND")
    public void TC29() throws Exception {
        // Instantiate XPathParser with a dummy token source for initialization
        XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(null));

        // Access and set jj_nt.kind to FUNCTION_ROUND using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(xpathParser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, FUNCTION_ROUND);

        // Invoke CoreFunctionName and assert the result
        int result = xpathParser.CoreFunctionName();
        Assertions.assertEquals(FUNCTION_ROUND, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_KEY returns Compiler.FUNCTION_KEY")
    public void TC30() throws Exception {
        // Instantiate XPathParser with a dummy token source for initialization
        XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(null));

        // Access and set jj_nt.kind to FUNCTION_KEY using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(xpathParser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, FUNCTION_KEY);

        // Invoke CoreFunctionName and assert the result
        int result = xpathParser.CoreFunctionName();
        Assertions.assertEquals(FUNCTION_KEY, result);
    }

}