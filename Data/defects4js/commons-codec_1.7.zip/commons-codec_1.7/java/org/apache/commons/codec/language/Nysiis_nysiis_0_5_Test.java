package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_5_Test {

    @Test
    @DisplayName("nysiis handles string with H surrounded by consonants")
    void TC21_nysiis_handles_H_surrounded_by_consonants() {
        // Given
        Nysiis nysiis = new Nysiis();
        String input = "BIRTH";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertTrue(result.contains("BRT"), "Result should contain 'BRT'");
    }

    @Test
    @DisplayName("nysiis handles string with W following a vowel")
    void TC22_nysiis_handles_W_following_a_vowel() {
        // Given
        Nysiis nysiis = new Nysiis();
        String input = "LAW";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertTrue(result.contains("LA"), "Result should contain 'LA'");
    }

}