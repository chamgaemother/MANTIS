package com.fasterxml.jackson.databind.type;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JavaType;

public class TypeFactory_constructSpecializedType_1_1_Test {

    @Test
    @DisplayName("Creates specialized type for EnumMap when baseType is Map-like and subclass is EnumMap")
    void TC06_constructSpecializedType_with_EnumMap_subclass() {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructMapType(Map.class, Enum.class, Object.class);  // Fixed incorrect type usage
        Class<?> subclass = EnumMap.class;
        boolean relaxedCompatibilityCheck = true;

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        assertNotNull(result, "The specialized JavaType should not be null.");
        assertEquals(EnumMap.class, result.getRawClass(), "The specialized type should have a raw class of EnumMap.");
    }

    @Test
    @DisplayName("Creates specialized type for TreeMap when baseType is Map-like and subclass is TreeMap")
    void TC07_constructSpecializedType_with_TreeMap_subclass() {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructMapType(Map.class, String.class, Object.class);
        Class<?> subclass = TreeMap.class;
        boolean relaxedCompatibilityCheck = true;

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        assertNotNull(result, "The specialized JavaType should not be null.");
        assertEquals(TreeMap.class, result.getRawClass(), "The specialized type should have a raw class of TreeMap.");
    }

    @Test
    @DisplayName("Creates specialized type for ArrayList when baseType is Collection-like and subclass is ArrayList")
    void TC08_constructSpecializedType_with_ArrayList_subclass() {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructCollectionType(Collection.class, String.class);
        Class<?> subclass = ArrayList.class;
        boolean relaxedCompatibilityCheck = true;

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        assertNotNull(result, "The specialized JavaType should not be null.");
        assertEquals(ArrayList.class, result.getRawClass(), "The specialized type should have a raw class of ArrayList.");
    }

    @Test
    @DisplayName("Creates specialized type for LinkedList when baseType is Collection-like and subclass is LinkedList")
    void TC09_constructSpecializedType_with_LinkedList_subclass() {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructCollectionType(Collection.class, Integer.class);
        Class<?> subclass = LinkedList.class;
        boolean relaxedCompatibilityCheck = true;

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        assertNotNull(result, "The specialized JavaType should not be null.");
        assertEquals(LinkedList.class, result.getRawClass(), "The specialized type should have a raw class of LinkedList.");
    }

    @Test
    @DisplayName("Creates specialized type for HashSet when baseType is Collection-like and subclass is HashSet")
    void TC10_constructSpecializedType_with_HashSet_subclass() {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructCollectionType(Collection.class, Double.class);
        Class<?> subclass = HashSet.class;
        boolean relaxedCompatibilityCheck = true;

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        assertNotNull(result, "The specialized JavaType should not be null.");
        assertEquals(HashSet.class, result.getRawClass(), "The specialized type should have a raw class of HashSet.");
    }
}
