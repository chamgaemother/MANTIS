import org.apache.commons.math3.util.MathArrays;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MathArraysTest {

    @Test
    void testSafeNormRegularValues() {
        double[] vector = {3.0, 4.0};
        assertEquals(5.0, MathArrays.safeNorm(vector), 1e-12);
    }

    @Test
    void testSafeNormZeroVector() {
        double[] vector = {0.0, 0.0, 0.0};
        assertEquals(0.0, MathArrays.safeNorm(vector), 1e-12);
    }

    @Test
    void testSafeNormTinyValues() {
        double[] vector = {1.0e-40, 2.0e-40};
        assertEquals(2.23606797749979e-40, MathArrays.safeNorm(vector), 1e-52);
    }

    @Test
    void testSafeNormHugeValues() {
        double[] vector = {1.0e+20, 2.0e+20};
        assertEquals(2.23606797749979e+20, MathArrays.safeNorm(vector), 1e6);
    }

    @Test
    void testSafeNormMixTinyAndRegularValues() {
        double[] vector = {1.0, 1.0e-40};
        assertEquals(1.0, MathArrays.safeNorm(vector), 1e-12);
    }

    @Test
    void testSafeNormMixHugeAndRegularValues() {
        double[] vector = {1.0e+20, 1.0};
        assertEquals(1.0e+20, MathArrays.safeNorm(vector), 1e8);
    }

    @Test
    void testSafeNormNaNValues() {
        double[] vector = {Double.NaN, 0.0};
        assertTrue(Double.isNaN(MathArrays.safeNorm(vector)));
    }

    @Test
    void testSafeNormInfiniteValues() {
        double[] vector = {Double.POSITIVE_INFINITY, 1.0};
        assertEquals(Double.POSITIVE_INFINITY, MathArrays.safeNorm(vector), 1e-12);
    }

    @Test
    void testSafeNormNegativeInfiniteValues() {
        double[] vector = {Double.NEGATIVE_INFINITY, 1.0};
        assertEquals(Double.POSITIVE_INFINITY, MathArrays.safeNorm(vector), 1e-12);
    }

    @Test
    void testSafeNormMixedSizeAndMagnitude() {
        double[] vector = {1.0, Double.MIN_VALUE};
        assertEquals(1.0, MathArrays.safeNorm(vector), 1e-12);
    }

    @Test
    void testSafeNormSingleElementTiny() {
        double[] vector = {1.0e-40};
        assertEquals(1.0e-40, MathArrays.safeNorm(vector), 1e-52);
    }

    @Test
    void testSafeNormSingleElementHuge() {
        double[] vector = {1.0e+20};
        assertEquals(1.0e+20, MathArrays.safeNorm(vector), 1e8);
    }

    @Test
    void testSafeNormEmptyVector() {
        double[] vector = {};
        assertEquals(0.0, MathArrays.safeNorm(vector), 1e-12);
    }
}