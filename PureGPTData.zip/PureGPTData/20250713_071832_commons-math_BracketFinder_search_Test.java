import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.univariate.BracketFinder;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BracketFinderTest {

    @Test
    public void testBracketFinderSearchForMaximization() {
        BracketFinder finder = new BracketFinder(100, 500);
        UnivariateFunction func = x -> -1 * (x - 2) * (x - 4);
        
        finder.search(func, GoalType.MAXIMIZE, 0, 1);
        
        assertTrue(finder.getLo() < finder.getHi());
        assertTrue(finder.getFMid() > finder.getFLo());
        assertTrue(finder.getFMid() > finder.getFHi());
    }

    @Test
    public void testBracketFinderSearchForMinimization() {
        BracketFinder finder = new BracketFinder(100, 500);
        UnivariateFunction func = x -> (x - 2) * (x - 4);

        finder.search(func, GoalType.MINIMIZE, 0, 1);
        
        assertTrue(finder.getLo() < finder.getHi());
        assertTrue(finder.getFMid() < finder.getFLo());
        assertTrue(finder.getFMid() < finder.getFHi());
    }

    @Test
    public void testMaximumEvaluationsExceeded() {
        BracketFinder finder = new BracketFinder(100, 1);
        UnivariateFunction constantFunc = x -> 2.0;

        assertThrows(TooManyEvaluationsException.class, () -> {
            finder.search(constantFunc, GoalType.MINIMIZE, 0, 1);
        });
    }

    @Test
    public void testSearchWithEqualInitialPoints() {
        BracketFinder finder = new BracketFinder(100, 50);
        UnivariateFunction func = x -> (x - 2) * (x - 4);

        finder.search(func, GoalType.MINIMIZE, 1, 1);

        assertTrue(finder.getLo() == finder.getHi());
        assertTrue(finder.getFMid() < finder.getFLo());
        assertTrue(finder.getFMid() < finder.getFHi());
    }

    @Test
    public void testSearchWithGrowLimitBoundary() {
        BracketFinder finder = new BracketFinder(0.00001, 500);
        UnivariateFunction func = x -> (x - 2) * (x - 4);
        
        assertDoesNotThrow(() -> finder.search(func, GoalType.MINIMIZE, 0, 1));
        
        assertTrue(finder.getLo() < finder.getHi());
        assertTrue(finder.getFMid() < finder.getFLo());
        assertTrue(finder.getFMid() < finder.getFHi());
    }

    @Test
    public void testMaxEvaluationsBoundary() {
        assertThrows(IllegalArgumentException.class, () -> {
            new BracketFinder(100, -1);
        });
    }

    @Test
    public void testGrowLimitBoundary() {
        assertThrows(IllegalArgumentException.class, () -> {
            new BracketFinder(-100, 50);
        });
    }
}