import org.apache.commons.codec.language.ColognePhonetic;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ColognePhoneticTest {

    private final ColognePhonetic colognePhonetic = new ColognePhonetic();

    @Test
    void testNullInput() {
        assertNull(colognePhonetic.colognePhonetic(null));
    }

    @ParameterizedTest
    @NullSource
    @ValueSource(strings = {"", "A", "B", "H", "X", "S", "C", "K", 
                            "SCH", "Müller", "Dampfmaschine", "Stephan",
                            "Köln", "Tisch", "Quarz", "exkluziv", "zzazz", 
                            "!@#$%^&*", "123456", "AÄÖÜà"})
    void testVariousInputs(String input) {
        switch (input) {
            case "":
                assertEquals("", colognePhonetic.colognePhonetic(input));
                break;
            case "A":
                assertEquals("0", colognePhonetic.colognePhonetic(input));
                break;
            case "B":
                assertEquals("1", colognePhonetic.colognePhonetic(input));
                break;
            case "H":
                assertEquals("", colognePhonetic.colognePhonetic(input));
                break;
            case "X":
                assertEquals("48", colognePhonetic.colognePhonetic(input));
                break;
            case "S":
                assertEquals("8", colognePhonetic.colognePhonetic(input));
                break;
            case "C":
                assertEquals("8", colognePhonetic.colognePhonetic(input));
                break;
            case "K":
                assertEquals("4", colognePhonetic.colognePhonetic(input));
                break;
            case "SCH":
                assertEquals("48", colognePhonetic.colognePhonetic(input));
                break;
            case "Müller":
                assertEquals("657", colognePhonetic.colognePhonetic(input));
                break;
            case "Dampfmaschine":
                assertEquals("261685", colognePhonetic.colognePhonetic(input));
                break;
            case "Stephan":
                assertEquals("7826", colognePhonetic.colognePhonetic(input));
                break;
            case "Köln":
                assertEquals("46", colognePhonetic.colognePhonetic(input));
                break;
            case "Tisch":
                assertEquals("282", colognePhonetic.colognePhonetic(input));
                break;
            case "Quarz":
                assertEquals("4728", colognePhonetic.colognePhonetic(input));
                break;
            case "exkluziv":
                assertEquals("4858", colognePhonetic.colognePhonetic(input));
                break;
            case "zzazz":
                assertEquals("88", colognePhonetic.colognePhonetic(input));
                break;
            case "!@#$%^&*":
            case "123456":
                assertEquals("", colognePhonetic.colognePhonetic(input));
                break;
            case "AÄÖÜà":
                assertEquals("0", colognePhonetic.colognePhonetic(input));
                break;
        }
    }

    @Test
    void testUmlautHandling() {
        assertEquals("0", colognePhonetic.colognePhonetic("ä"));
        assertEquals("0", colognePhonetic.colognePhonetic("ö"));
        assertEquals("0", colognePhonetic.colognePhonetic("ü"));
    }
}