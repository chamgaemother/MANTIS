package org.apache.commons.math3.analysis.function;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.apache.commons.math3.analysis.function.Sinc;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Sinc_value_1_1_Test {

    @Test
    @DisplayName("value(0.0) with normalized=false evaluates the Taylor series branch")
    void TC13_valueAtZero_NormalizedFalse_TaylorSeries() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        
        // WHEN
        double result = sinc.value(0.0);
        
        // THEN
        assertEquals(1.0, result, 1e-10, "Expected sinc(0.0) to be 1.0 when normalized is false");
    }

    @Test
    @DisplayName("value(1e-4) with normalized=false and |x| < SHORTCUT evaluates the Taylor series branch")
    void TC14_valueAt1eMinus4_NormalizedFalse_TaylorSeries() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = 1e-4;
        
        // WHEN
        double result = sinc.value(x);
        
        // THEN
        double scaledX = x;
        double expectedValue = ((scaledX * scaledX - 20) * scaledX * scaledX + 120) / 120;
        assertEquals(expectedValue, result, 1e-10, "Expected sinc(1e-4) to match Taylor series approximation when normalized is false");
    }

    @Test
    @DisplayName("value(6.0e-3) with normalized=false and |x| equals SHORTCUT evaluates the Taylor series branch")
    void TC15_valueAt6eMinus3_NormalizedFalse_TaylorSeriesBoundary() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = 6.0e-3;
        
        // WHEN
        double result = sinc.value(x);
        
        // THEN
        double scaledX = x;
        double expectedValue = ((scaledX * scaledX - 20) * scaledX * scaledX + 120) / 120;
        assertEquals(expectedValue, result, 1e-10, "Expected sinc(6.0e-3) to match Taylor series approximation at boundary when normalized is false");
    }

    @Test
    @DisplayName("value(1.0e-2) with normalized=false and |x| > SHORTCUT evaluates the sine definition expression branch")
    void TC16_valueAt1eMinus2_NormalizedFalse_SineDefinition() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = 1.0e-2;
        
        // WHEN
        double result = sinc.value(x);
        
        // THEN
        double expected = FastMath.sin(x) / x;
        assertEquals(expected, result, 1e-10, "Expected sinc(1.0e-2) to match sin(x)/x when normalized is false");
    }

    @Test
    @DisplayName("value(0.0) with normalized=true evaluates the Taylor series branch")
    void TC17_valueAtZero_NormalizedTrue_TaylorSeries() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        
        // WHEN
        double result = sinc.value(0.0);
        
        // THEN
        assertEquals(1.0, result, 1e-10, "Expected sinc(0.0) to be 1.0 when normalized is true");
    }
}