package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NumberInput_parseInt_2_1_Test {

    @Test
    @DisplayName("parseInt with length=0 throws ArrayIndexOutOfBoundsException")
    void TC29_parseInt_LengthZero_ThrowsArrayIndexOutOfBoundsException() {
        // GIVEN
        char[] input = new char[] {};
        int off = 0;
        int len = 0;

        // WHEN & THEN
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            NumberInput.parseInt(input, off, len);
        });
    }

    @Test
    @DisplayName("parseInt with negative length throws ArrayIndexOutOfBoundsException")
    void TC30_parseInt_NegativeLength_ThrowsArrayIndexOutOfBoundsException() {
        // GIVEN
        char[] input = new char[] {'1', '2', '3'};
        int off = 0;
        int len = -1;

        // WHEN & THEN
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            NumberInput.parseInt(input, off, len);
        });
    }

    @Test
    @DisplayName("parseInt with length=1 and no '+' sign parses correctly")
    void TC31_parseInt_LengthOne_NoPlusSign_ReturnsCorrectValue() {
        // GIVEN
        char[] input = new char[] {'7'};
        int off = 0;
        int len = 1;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(7, result, "Expected parseInt to return 7");
    }

    @Test
    @DisplayName("parseInt with length=1 and '+' sign returns -5")
    void TC32_parseInt_LengthOne_PlusSign_ReturnsNegativeFive() {
        // GIVEN
        char[] input = new char[] {'+'};
        int off = 0;
        int len = 1;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(-5, result, "Expected parseInt to return -5 when input is '+' with length=1");
    }

    @Test
    @DisplayName("parseInt with length=5 and '+' sign parses correctly")
    void TC33_parseInt_LengthFive_PlusSign_ReturnsCorrectValue() {
        // GIVEN
        char[] input = new char[] {'+', '1', '2', '3', '4', '5'};
        int off = 0;
        int len = 5;

        // WHEN
        int result = NumberInput.parseInt(input, off, len);

        // THEN
        assertEquals(1234, result, "Expected parseInt to return 1234 with input '+12345' and length=5");
    }
}