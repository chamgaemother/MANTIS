package org.jfree.chart.axis;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class LogarithmicAxis_autoAdjustRange_0_2_Test {

    @Test
    @DisplayName("autoAdjustRange applies computeLogFloor when autoRangeNextLogFlag is true")
    void TC06_autoAdjustRange_applies_computeLogFloor_with_flag() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAutoRangeNextLogFlag(true);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        // Use reflection to set private plot field if required
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(5.0, 50.0));

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(1.0, adjustedRange.getLowerBound(), 0.0001, "Lower bound should be set to computeLogFloor of 5.0");
    }

    @Test
    @DisplayName("autoAdjustRange does not adjust lower bound when lower margin is zero")
    void TC07_autoAdjustRange_with_zero_lower_margin() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setLowerMargin(0.0);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(3.0, 30.0));

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(3.0, adjustedRange.getLowerBound(), 0.0001, "Lower bound should remain unchanged when lower margin is zero");
    }

    @Test
    @DisplayName("autoAdjustRange correctly adjusts upper bound with positive upper margin")
    void TC08_autoAdjustRange_adjusts_upper_bound_with_positive_margin() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setUpperMargin(0.2);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(2.0, 10.0));

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        double expectedUpper = 10.0 + (10.0 * 0.2); // Assuming upper margin is applied multiplicatively
        assertEquals(expectedUpper, adjustedRange.getUpperBound(), 0.0001, "Upper bound should be increased correctly by margin");
    }

    @Test
    @DisplayName("autoAdjustRange applies computeLogCeil when autoRangeNextLogFlag is false")
    void TC09_autoAdjustRange_applies_computeLogCeil_without_flag() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAutoRangeNextLogFlag(false);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(1.0, 100.0));

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(100.0, adjustedRange.getUpperBound(), 0.0001, "Upper bound should be set to computeLogCeil of 100.0");
    }

    @Test
    @DisplayName("autoAdjustRange throws RuntimeException when upper bound requires rounding and constraints are met")
    void TC10_autoAdjustRange_rounds_upper_bound_between_0_and_1() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(false);

        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(0.5, 0.8));

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range adjustedRange = axis.getRange();
        double expectedUpper = Math.ceil(0.8 * 10) / 10; // Example of rounding to nearest significant digit
        assertEquals(expectedUpper, adjustedRange.getUpperBound(), 0.0001, "Upper bound should be rounded up to nearest significant digit");
    }
}