package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ClassBands_removeCurrentClass_0_2_Test {

    @Test
    @DisplayName("FieldFlags iteration with no elements keeps field lists unchanged")
    void testFieldFlagsIterationNoChange() throws Exception {
        // Create an instance of ClassBands with necessary dependencies
        ClassBands classBands = createClassBands();

        List<Long> tempFieldFlags = (List<Long>) getField(classBands, "tempFieldFlags");
        List<Object> fieldSignature = (List<Object>) getField(classBands, "fieldSignature");
        List<Object> fieldConstantValueKQ = (List<Object>) getField(classBands, "fieldConstantValueKQ");
        MetadataBandGroup field_RVA_bands = (MetadataBandGroup) getField(classBands, "field_RVA_bands");
        MetadataBandGroup field_RIA_bands = (MetadataBandGroup) getField(classBands, "field_RIA_bands");

        tempFieldFlags.clear(); // Ensure tempFieldFlags is empty

        invokeRemoveCurrentClass(classBands);

        assertAll(
            () -> assertTrue(fieldSignature.isEmpty(), "Field signatures should be empty"),
            () -> assertTrue(fieldConstantValueKQ.isEmpty(), "Field constant values should be empty"),
            () -> assertFalse(field_RVA_bands.hasContent(), "Field RVA bands should not have elements"),
            () -> assertFalse(field_RIA_bands.hasContent(), "Field RIA bands should not have elements")
        );
    }

    @Test
    @DisplayName("FieldFlags with one iteration and specific flag values removes items from lists")
    void testFieldFlagsSpecificRemovals() throws Exception {
        // Create an instance of ClassBands with necessary dependencies
        ClassBands classBands = createClassBands();

        List<Long> tempFieldFlags = (List<Long>) getField(classBands, "tempFieldFlags");
        List<Object> fieldSignature = (List<Object>) getField(classBands, "fieldSignature");
        List<Object> fieldConstantValueKQ = (List<Object>) getField(classBands, "fieldConstantValueKQ");
        MetadataBandGroup field_RVA_bands = (MetadataBandGroup) getField(classBands, "field_RVA_bands");
        MetadataBandGroup field_RIA_bands = (MetadataBandGroup) getField(classBands, "field_RIA_bands");

        tempFieldFlags.clear();
        tempFieldFlags.add((1L << 19) | (1L << 17) | (1L << 21) | (1L << 22));

        fieldSignature.add(new Object());
        fieldConstantValueKQ.add(new Object());
        field_RVA_bands.addElement(new Object());
        field_RIA_bands.addElement(new Object());

        invokeRemoveCurrentClass(classBands);

        assertAll(
            () -> assertTrue(fieldSignature.isEmpty(), "Field signatures should be empty"),
            () -> assertTrue(fieldConstantValueKQ.isEmpty(), "Field constant values should be empty"),
            () -> assertFalse(field_RVA_bands.hasContent(), "Field RVA bands should not have elements"),
            () -> assertFalse(field_RIA_bands.hasContent(), "Field RIA bands should not have elements")
        );
    }

    @Test
    @DisplayName("MethodFlags with multiple iterations and bits set performs all removals")
    void testMethodFlagsWithMultipleIterations() throws Exception {
        // Create an instance of ClassBands with necessary dependencies
        ClassBands classBands = createClassBands();

        List<Long> tempMethodFlags = (List<Long>) getField(classBands, "tempMethodFlags");
        tempMethodFlags.clear();
        tempMethodFlags.add((1L << 19) | (1L << 18));
        tempMethodFlags.add((1L << 17) | (1L << 21));

        prepareMethodFlagsCollections(classBands);

        invokeRemoveCurrentClass(classBands);

        assertMethodFlagsCollectionsEmpty(classBands);
    }

    @Test
    @DisplayName("MethodFlags where stripDebug is false and line number table removal branch is executed")
    void testStripDebugFalseLineNumberRemoval() throws Exception {
        // Create an instance of ClassBands with necessary dependencies
        ClassBands classBands = createClassBands();

        List<Long> tempMethodFlags = (List<Long>) getField(classBands, "tempMethodFlags");
        tempMethodFlags.clear();
        tempMethodFlags.add((1L << 17)); // has code attribute

        setField(classBands, "stripDebug", false);
        prepareMethodFlagsCollections(classBands);
        setLineNumberTableData(classBands);

        invokeRemoveCurrentClass(classBands);

        assertTrue(getList(classBands, "codeLineNumberTableBciP").isEmpty(), "Line number table BCI should be empty");
    }

    @Test
    @DisplayName("ClassFlags and tempMethodFlags combination leading to full traversal and maximum removals")
    void testClassFlagsWithTempMethodFlags() throws Exception {
        // Create an instance of ClassBands with necessary dependencies
        ClassBands classBands = createClassBands();
        long[] classFlags = new long[1];
        classFlags[0] = (1L << 17) | (1L << 18) | (1L << 19);
        setField(classBands, "class_flags", classFlags);
        setField(classBands, "index", 0);

        List<Long> tempFieldFlags = (List<Long>) getField(classBands, "tempFieldFlags");
        tempFieldFlags.add((1L << 19) | (1L << 17));
        List<Long> tempMethodFlags = (List<Long>) getField(classBands, "tempMethodFlags");
        tempMethodFlags.add((1L << 21) | (1L << 22));

        prepareMethodFlagsCollections(classBands);

        invokeRemoveCurrentClass(classBands);

        assertMethodFlagsCollectionsEmpty(classBands);
    }

    private ClassBands createClassBands() throws Exception {
        // Create an instance of ClassBands with mocked dependencies
        Segment segment = new Segment();
        return new ClassBands(segment, 0, 0, false);
    }

    private void prepareMethodFlagsCollections(ClassBands classBands) throws Exception {
        getList(classBands, "methodSignature").add(new Object());
        getList(classBands, "codeMaxLocals").add(1);
        getList(classBands, "codeMaxStack").add(1);
        getList(classBands, "methodExceptionNumber").add(1);
        getList(classBands, "codeHandlerCount").add(1);
    }

    private void setLineNumberTableData(ClassBands classBands) throws Exception {
        getList(classBands, "codeLineNumberTableBciP").add(1);
        getList(classBands, "codeLineNumberTableLine").add(1);
    }

    private void assertMethodFlagsCollectionsEmpty(ClassBands classBands) throws Exception {
        assertAll(
            () -> assertTrue(getList(classBands, "methodSignature").isEmpty(), "Method signatures should be empty"),
            () -> assertTrue(getList(classBands, "codeMaxLocals").isEmpty(), "Code max locals should be empty"),
            () -> assertTrue(getList(classBands, "codeMaxStack").isEmpty(), "Code max stack should be empty"),
            () -> assertTrue(getList(classBands, "methodExceptionNumber").isEmpty(), "Method exception number should be empty"),
            () -> assertTrue(getList(classBands, "codeHandlerCount").isEmpty(), "Code handler count should be empty")
        );
    }

    private List<Object> getList(ClassBands classBands, String fieldName) throws Exception {
        return (List<Object>) getField(classBands, fieldName);
    }

    private Object getField(Object target, String fieldName) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(target);
    }

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private void invokeRemoveCurrentClass(ClassBands classBands) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        Method method = ClassBands.class.getDeclaredMethod("removeCurrentClass");
        method.setAccessible(true);
        method.invoke(classBands);
    }
}