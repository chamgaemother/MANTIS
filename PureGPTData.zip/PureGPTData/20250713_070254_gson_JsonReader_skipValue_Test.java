import static org.junit.jupiter.api.Assertions.*;

import com.google.gson.stream.JsonReader;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.io.StringReader;

class JsonReaderTest {
    
    @Test
    void skipValue_handlesBeginArrayProperly() throws IOException {
        String json = "[\"value\", 1, true]";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.beginArray();
        reader.skipValue(); // Skips "value"
        assertEquals(1, reader.nextInt());
    }

    @Test
    void skipValue_handlesBeginObjectProperly() throws IOException {
        String json = "{\"key\": \"value\", \"key2\": 2}";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.beginObject();
        reader.skipValue(); // Skips "key": "value"
        assertEquals("key2", reader.nextName());
    }

    @Test
    void skipValue_handlesEndArrayProperly() throws IOException {
        String json = "[]";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.beginArray();
        reader.skipValue();
        assertTrue(reader.hasNext() == false); // End of empty array
    }

    @Test
    void skipValue_handlesEndObjectProperly() throws IOException {
        String json = "{}";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.beginObject();
        reader.skipValue();
        assertTrue(reader.hasNext() == false); // End of empty object
    }

    @Test
    void skipValue_handlesUnquotedStringsProperly() throws IOException {
        String json = "unquoted";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.skipValue();
        assertTrue(reader.peek() == JsonReader.JsonToken.END_DOCUMENT);
    }

    @Test
    void skipValue_handlesSingleQuotedStringsProperly() throws IOException {
        String json = "'single quoted'";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.setLenient(true);

        reader.skipValue();
        assertTrue(reader.peek() == JsonReader.JsonToken.END_DOCUMENT);
    }

    @Test
    void skipValue_handlesDoubleQuotedStringsProperly() throws IOException {
        String json = "\"double quoted\"";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.skipValue();
        assertTrue(reader.peek() == JsonReader.JsonToken.END_DOCUMENT);
    }

    @Test
    void skipValue_handlesUnquotedNamesProperly() throws IOException {
        String json = "{unquoted: 1}";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.setLenient(true);

        reader.beginObject();
        reader.skipValue(); // Skips the unquoted name "unquoted"
        assertEquals(1, reader.nextInt());
    }

    @Test
    void skipValue_handlesSingleQuotedNamesProperly() throws IOException {
        String json = "{'single quoted': 1}";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.setLenient(true);

        reader.beginObject();
        reader.skipValue(); // Skips the single quoted name
        assertEquals(1, reader.nextInt());
    }

    @Test
    void skipValue_handlesDoubleQuotedNamesProperly() throws IOException {
        String json = "{\"double quoted\": 1}";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.beginObject();
        reader.skipValue(); // Skips the double quoted name
        assertEquals(1, reader.nextInt());
    }

    @Test
    void skipValue_handlesNumbersProperly() throws IOException {
        String json = "42";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.skipValue(); // Skips the number 42
        assertTrue(reader.peek() == JsonReader.JsonToken.END_DOCUMENT);
    }

    @Test
    void skipValue_handlesEOFProperly() throws IOException {
        String json = "";
        JsonReader reader = new JsonReader(new StringReader(json));

        reader.skipValue(); // EOF should do nothing
        assertTrue(reader.peek() == JsonReader.JsonToken.END_DOCUMENT);
    }
}