package org.apache.commons.jxpath.ri.model.dom;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DOMNodePointer_testNode_0_3_Test {
    
    @Test
    @DisplayName("testNode returns true when NodeTypeTest specifies PI and node type is PROCESSING_INSTRUCTION_NODE")
    public void testTC11() throws Exception {
        // GIVEN
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.newDocument();
        ProcessingInstruction pi = doc.createProcessingInstruction("target", "data");
        Node node = pi;
        NodeTest test = new NodeTypeTest(Compiler.NODE_TYPE_PI);

        // WHEN
        boolean result = DOMNodePointer.testNode(node, test);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("testNode returns false when NodeTypeTest specifies unsupported node type")
    public void testTC12() throws Exception {
        // GIVEN
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.newDocument();
        // Assuming Compiler.NODE_TYPE_ENTITY is an unsupported type
        // Since DOM does not support ENTITY_NODE directly, we simulate with a comment node for the sake of the test
        Comment comment = doc.createComment("This is a comment");
        Node node = comment;
        NodeTest test = new NodeTypeTest(99); // Changed to an unsupported, arbitrary value that's not ENUM of NodeTypeTest

        // WHEN
        boolean result = DOMNodePointer.testNode(node, test);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("testNode returns true when ProcessingInstructionTest target matches node's PI target")
    public void testTC13() throws Exception {
        // GIVEN
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.newDocument();
        ProcessingInstruction pi = doc.createProcessingInstruction("target", "data");
        Node node = pi;
        NodeTest test = new ProcessingInstructionTest("target");

        // WHEN
        boolean result = DOMNodePointer.testNode(node, test);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("testNode returns false when ProcessingInstructionTest target does not match node's PI target")
    public void testTC14() throws Exception {
        // GIVEN
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.newDocument();
        ProcessingInstruction pi = doc.createProcessingInstruction("nodeTarget", "data");
        Node node = pi;
        NodeTest test = new ProcessingInstructionTest("testTarget");

        // WHEN
        boolean result = DOMNodePointer.testNode(node, test);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("testNode returns false when node is not PROCESSING_INSTRUCTION_NODE and test is ProcessingInstructionTest")
    public void testTC15() throws Exception {
        // GIVEN
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.newDocument();
        Comment comment = doc.createComment("This is a comment");
        Node node = comment;
        NodeTest test = new ProcessingInstructionTest("target");

        // WHEN
        boolean result = DOMNodePointer.testNode(node, test);

        // THEN
        assertFalse(result);
    }
}