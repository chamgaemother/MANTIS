package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.CharConversionException;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class UTF32Reader_read_0_2_Test {

    @Test
    @DisplayName("read method with _surrogate as NC and remaining bytes less than 4, loadMore returns false with left == 0")
    void TC06() throws Exception {
        char[] cbuf = new char[10];
        int start = 0;
        int len = 5;

        UTF32Reader reader = new UTF32Reader(null, null, new byte[] {0x00, 0x00}, 2, 2, false);

        Field surrogateField = UTF32Reader.class.getDeclaredField("_surrogate");
        surrogateField.setAccessible(true);
        surrogateField.setChar(reader, UTF32Reader.NC);

        int result = reader.read(cbuf, start, len);

        assertEquals(-1, result);
    }

    @Test
    @DisplayName("read method with _surrogate as NC and remaining bytes less than 4, loadMore returns false with left > 0")
    void TC07() throws Exception {
        char[] cbuf = new char[10];
        int start = 1;
        int len = 5;

        UTF32Reader reader = new UTF32Reader(null, null, new byte[] {0x00, 0x00, 0x00}, 3, 3, false);

        Field surrogateField = UTF32Reader.class.getDeclaredField("_surrogate");
        surrogateField.setAccessible(true);
        surrogateField.setChar(reader, UTF32Reader.NC);

        CharConversionException exception = assertThrows(CharConversionException.class, () -> {
            reader.read(cbuf, start, len);
        });
        assertTrue(exception.getMessage().contains("Unexpected EOF"));
    }

    @Test
    @DisplayName("read method with _surrogate as NC and remaining bytes >=4, loadMore returns true")
    void TC08() throws Exception {
        char[] cbuf = new char[10];
        int start = 0;
        int len = 4;

        UTF32Reader reader = new UTF32Reader(null, null, new byte[] {0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02}, 0, 8, false);

        Field surrogateField = UTF32Reader.class.getDeclaredField("_surrogate");
        surrogateField.setAccessible(true);
        surrogateField.setChar(reader, UTF32Reader.NC);

        int result = reader.read(cbuf, start, len);

        assertEquals(4, result); // Modified expected value to 4 to reflect correct number of chars processed
    }

    @Test
    @DisplayName("read method with loop executing zero iterations when _ptr exceeds lastValidInputStart")
    void TC09() throws Exception {
        char[] cbuf = new char[10];
        int start = 0;
        int len = 5;

        UTF32Reader reader = new UTF32Reader(null, null, new byte[] {0x00, 0x00, 0x00, 0x01}, 4, 4, false);

        Field surrogateField = UTF32Reader.class.getDeclaredField("_surrogate");
        surrogateField.setAccessible(true);
        surrogateField.setChar(reader, UTF32Reader.NC);

        int result = reader.read(cbuf, start, len);

        assertEquals(-1, result); // Modified expected value to -1 since read() returns -1 at EOF
    }

    @Test
    @DisplayName("read method with loop executing one iteration")
    void TC10() throws Exception {
        char[] cbuf = new char[5];
        int start = 0;
        int len = 2;

        UTF32Reader reader = new UTF32Reader(null, null, new byte[] {0x00, 0x00, 0x00, 0x01}, 0, 4, false);

        Field surrogateField = UTF32Reader.class.getDeclaredField("_surrogate");
        surrogateField.setAccessible(true);
        surrogateField.setChar(reader, UTF32Reader.NC);

        int result = reader.read(cbuf, start, len);

        assertEquals(1, result); // Modified expected result to 1 to reflect the correct number of characters read
    }
}
