package org.apache.commons.math3.linear;

import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealMatrixFormat;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.text.ParsePosition;

import static org.junit.jupiter.api.Assertions.*;

public class RealMatrixFormat_parse_0_2_Test {

    @Test
    @DisplayName("parse with missing column separator")
    void TC06_parse_missing_column_separator() {
        // GIVEN
        String source = "[1.0 2.0]";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        RealMatrix result = new RealMatrixFormat().parse(source, pos);

        // THEN
        assertNull(result);
        assertEquals(5, pos.getIndex());
    }

    @Test
    @DisplayName("parse with single row and multiple elements")
    void TC07_parse_single_row_multiple_elements() {
        // GIVEN
        String source = "[1.0,2.0,3.0]";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        RealMatrix result = new RealMatrixFormat().parse(source, pos);

        // THEN
        assertNotNull(result);
        assertEquals(1, result.getRowDimension());
        assertEquals(3, result.getColumnDimension());
        assertEquals(1.0, result.getEntry(0, 0), 1e-10);
        assertEquals(2.0, result.getEntry(0, 1), 1e-10);
        assertEquals(3.0, result.getEntry(0, 2), 1e-10);
    }

    @Test
    @DisplayName("parse with multiple rows, varying number of elements")
    void TC08_parse_multiple_rows_varying_columns() {
        // GIVEN
        String source = "[[1.0,2.0],[3.0,4.0,5.0]]";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        RealMatrix result = new RealMatrixFormat().parse(source, pos);

        // THEN
        assertNotNull(result);
        assertEquals(2, result.getRowDimension());
        assertEquals(3, result.getColumnDimension());
        assertEquals(1.0, result.getEntry(0, 0), 1e-10);
        assertEquals(2.0, result.getEntry(0, 1), 1e-10);
        assertEquals(3.0, result.getEntry(1, 0), 1e-10);
        assertEquals(4.0, result.getEntry(1, 1), 1e-10);
        assertEquals(5.0, result.getEntry(1, 2), 1e-10);
    }

    @Test
    @DisplayName("parse with whitespace variations")
    void TC09_parse_with_whitespace() {
        // GIVEN
        String source = "[ 1.0 , 2.0 ]";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        RealMatrix result = new RealMatrixFormat().parse(source, pos);

        // THEN
        assertNotNull(result);
        assertEquals(1, result.getRowDimension());
        assertEquals(2, result.getColumnDimension());
        assertEquals(1.0, result.getEntry(0, 0), 1e-10);
        assertEquals(2.0, result.getEntry(0, 1), 1e-10);
    }

    @Test
    @DisplayName("parse with invalid number format")
    void TC10_parse_invalid_number_format() {
        // GIVEN
        String source = "[1.0, abc]";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        RealMatrix result = new RealMatrixFormat().parse(source, pos);

        // THEN
        assertNull(result);
        assertEquals(5, pos.getIndex());
    }
}