package org.apache.commons.jxpath.ri.model.jdom;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jdom.CDATA;
import org.jdom.Comment;
import org.jdom.Element;
import org.jdom.Namespace;

import java.util.Locale;

public class JDOMNodePointer_getValue_1_1_Test {

//     @Test
//     @DisplayName("getValue correctly skips non-Element and non-Text child nodes like Comment in Element node")
//     public void TC13() throws Exception {
        // Arrange
//         Element parent = new Element("parent");
//         parent.addContent(new Element("child1"));
//         parent.addContent(new Comment("This is a comment"));
//         parent.addContent(new Text("childText"));
//         JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.getDefault());
// 
        // Act
//         Object result = pointer.getValue();
// 
        // Assert
//         assertEquals("child1childText", result);
//     }

    @Test
    @DisplayName("getValue returns untrimmed text for CDATA node when space attribute is 'preserve'")
    public void TC14() throws Exception {
        // Arrange
        Element parent = new Element("parent");
        parent.setAttribute("space", "preserve", Namespace.XML_NAMESPACE);
        CDATA cdata = new CDATA("  sample cdata  ");
        parent.addContent(cdata);
        JDOMNodePointer pointer = new JDOMNodePointer(cdata, Locale.getDefault());

        // Act
        Object result = pointer.getValue();

        // Assert
        assertEquals("  sample cdata  ", result);
    }
}