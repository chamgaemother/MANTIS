import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.plot.MeterPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.data.Range;
import org.junit.jupiter.api.Test;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;

public class MeterPlotTest {

    @Test
    public void testDrawWithNullDataset() {
        MeterPlot plot = new MeterPlot(null);
        plot.setRange(new Range(0.0, 100.0));
        plot.setDialBackgroundPaint(Color.LIGHT_GRAY);
        plot.setDrawBorder(true);

        // Use a BufferedImage to simulate drawing
        BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);

        PlotRenderingInfo info = new PlotRenderingInfo(null);

        plot.draw(g2, area, null, null, info);

        g2.dispose();
    }

    @Test
    public void testDrawWithNonNullDatasetWithinRange() {
        ValueDataset dataset = new DefaultValueDataset(50.0);
        MeterPlot plot = new MeterPlot(dataset);
        plot.setRange(new Range(0.0, 100.0));
        plot.setDialBackgroundPaint(Color.LIGHT_GRAY);

        // Use a BufferedImage to simulate drawing
        BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);

        plot.draw(g2, area, null, null, null);

        g2.dispose();
    }

    @Test
    public void testDrawWithNonNullDatasetOutsideRange() {
        ValueDataset dataset = new DefaultValueDataset(150.0);  // out of range
        MeterPlot plot = new MeterPlot(dataset);
        plot.setRange(new Range(0.0, 100.0));
        plot.setDialBackgroundPaint(Color.LIGHT_GRAY);

        BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);

        plot.draw(g2, area, null, null, null);

        g2.dispose();
    }

    @Test
    public void testDrawWithNegativeMeterAngle() {
        ValueDataset dataset = new DefaultValueDataset(50.0);
        MeterPlot plot = new MeterPlot(dataset);
        plot.setRange(new Range(0.0, 100.0));
        plot.setMeterAngle(90);

        // Use a BufferedImage to simulate drawing
        BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);

        plot.draw(g2, area, new Point2D.Double(50, 50), null, null);

        g2.dispose();
    }

    @Test
    public void testDrawWithPlotRenderingInfo() {
        ValueDataset dataset = new DefaultValueDataset(30.0);
        MeterPlot plot = new MeterPlot(dataset);
        plot.setRange(new Range(0.0, 100.0));

        BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);

        PlotRenderingInfo info = new PlotRenderingInfo(null);

        plot.draw(g2, area, null, null, info);

        assertNotNull(info.getPlotArea());
        g2.dispose();
    }

    @Test
    public void testDrawWithDifferentShapes() {
        ValueDataset dataset = new DefaultValueDataset(50.0);
        MeterPlot plot = new MeterPlot(dataset);
        plot.setRange(new Range(0.0, 100.0));
        
        plot.setMeterAngle(270);  // Test with default meter angle

        BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);

        plot.draw(g2, area, null, null, null);

        g2.dispose();
    }
}