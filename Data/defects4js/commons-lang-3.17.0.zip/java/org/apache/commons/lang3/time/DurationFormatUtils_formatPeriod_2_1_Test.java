package org.apache.commons.lang3.time;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.TimeZone;

public class DurationFormatUtils_formatPeriod_2_1_Test {

    @Test
    @DisplayName("Passing a null format string, expecting NullPointerException")
    void TC30_formatPeriod_nullFormat_shouldThrowNullPointerException() {
        // Given
        long startMillis = 1609459200000L; // Jan 1, 2021 00:00 GMT
        long endMillis = 1609462800000L;   // Jan 1, 2021 01:00 GMT
        String format = null;
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // When & Then
        Assertions.assertThrows(NullPointerException.class, () -> {
            DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        });
    }

    @Test
    @DisplayName("Duration requiring multiple loop iterations to adjust negative milliseconds and seconds")
    void TC31_formatPeriod_multipleLoopIterations_shouldFormatCorrectly() {
        // Given
        long startMillis = 1609459200000L; // Jan 1, 2021 00:00:00 GMT
        long endMillis = 1609545600000L;   // Jan 2, 2021 00:00:00 GMT
        String format = "d'H'm'm's's'";  // Example format
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // When
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // Then
        Assertions.assertEquals("1H0m0s", result);
    }
}