package org.apache.commons.math3.dfp;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_nextAfter_1_2_Test {

    @Test
    @DisplayName("nextAfter with this as finite and x as negative infinity decrements towards negative infinity")
    void TC19_nextAfter_FiniteToNegativeInfinity() {
        // GIVEN
        DfpField field = new DfpField(32);
        Dfp a = new Dfp(field, 1.0);
        Dfp b = new Dfp(field, "-Infinity");

        // WHEN
        Dfp result = a.nextAfter(b);

        // THEN
        assertTrue(result.lessThan(a), "Result should be less than a");
        assertFalse(result.lessThan(b), "Result should be greater than or equal to b");
    }

    @Test
    @DisplayName("nextAfter with this as negative infinity and x finite increments towards x")
    void TC20_nextAfter_NegativeInfinityToFinite() {
        // GIVEN
        DfpField field = new DfpField(32);
        Dfp a = new Dfp(field, "-Infinity");
        Dfp b = new Dfp(field, -1.0);

        // WHEN
        Dfp result = a.nextAfter(b);

        // THEN
        assertTrue(result.greaterThan(a), "Result should be greater than a");
        assertTrue(result.lessThan(b), "Result should be less than b");
    }
}