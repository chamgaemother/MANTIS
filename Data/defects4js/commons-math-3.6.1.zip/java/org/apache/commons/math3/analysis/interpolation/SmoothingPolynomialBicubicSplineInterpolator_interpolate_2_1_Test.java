package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.exception.NullArgumentException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class SmoothingPolynomialBicubicSplineInterpolator_interpolate_2_1_Test {

    @Test
    @DisplayName("interpolate with null xval, expecting NullArgumentException")
    void TC16_interpolate_with_null_xval_throws_NullArgumentException() {
        // Arrange
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        double[] xval = null;
        double[] yval = {1.0, 2.0};
        double[][] fval = {{1.0, 2.0}};

        // Act & Assert
        assertThrows(NullArgumentException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

    @Test
    @DisplayName("interpolate with null yval, expecting NullArgumentException")
    void TC17_interpolate_with_null_yval_throws_NullArgumentException() {
        // Arrange
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        double[] xval = {1.0, 2.0};
        double[] yval = null;
        double[][] fval = {{1.0, 2.0}};

        // Act & Assert
        assertThrows(NullArgumentException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

    @Test
    @DisplayName("interpolate with null fval, expecting NullArgumentException")
    void TC18_interpolate_with_null_fval_throws_NullArgumentException() {
        // Arrange
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = null;

        // Act & Assert
        assertThrows(NullArgumentException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

    @Test
    @DisplayName("interpolate with fval containing a null row, expecting NullArgumentException")
    void TC19_interpolate_with_null_row_in_fval_throws_NullArgumentException() {
        // Arrange
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {{1.0, 2.0}, null};

        // Act & Assert
        assertThrows(NullArgumentException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }
}