package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.io.JsonStringEncoder;

public class JsonStringEncoder_quoteAsUTF8_0_2_Test {

    @Test
    @DisplayName("quoteAsUTF8 with surrogate pair forming a valid Unicode code point")
    public void test_TC06_validSurrogatePair() {
        // GIVEN
        String text = "\uD83D\uDE00"; // ð emoji
        JsonStringEncoder encoder = JsonStringEncoder.getInstance();
        
        // WHEN
        byte[] result = encoder.quoteAsUTF8(text);
        
        // THEN
        byte[] expected = {(byte)0xF0, (byte)0x9F, (byte)0x98, (byte)0x80};
        assertArrayEquals(expected, result);
    }

    @Test
    @DisplayName("quoteAsUTF8 with lone high surrogate throws IllegalArgumentException")
    public void test_TC07_loneHighSurrogate() {
        // GIVEN
        String text = "\uD83D";
        JsonStringEncoder encoder = JsonStringEncoder.getInstance();
        
        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            encoder.quoteAsUTF8(text);
        });
    }

    @Test
    @DisplayName("quoteAsUTF8 with high surrogate not followed by low surrogate throws IllegalArgumentException")
    public void test_TC08_invalidSurrogatePair() {
        // GIVEN
        String text = "\uD83D\u0041"; // \uD83D (high surrogate) followed by 'A'
        JsonStringEncoder encoder = JsonStringEncoder.getInstance();
        
        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            encoder.quoteAsUTF8(text);
        });
    }

    @Test
    @DisplayName("quoteAsUTF8 with non-ASCII characters causing buffer to resize")
    public void test_TC09_bufferResize() {
        // GIVEN
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            sb.append("a"); // You can use non-ASCII characters if needed
        }
        String text = sb.toString();
        JsonStringEncoder encoder = JsonStringEncoder.getInstance();
        
        // WHEN
        byte[] result = encoder.quoteAsUTF8(text);
        
        // THEN
        // Assuming each 'a' is 1 byte in UTF-8
        assertEquals(1000, result.length);
    }

    @Test
    @DisplayName("quoteAsUTF8 with multiple surrogate pairs and escapes in a single string")
    public void test_TC10_multipleSurrogatesAndEscapes() {
        // GIVEN
        String text = "Hello\n\uD83D\uDE00World";
        JsonStringEncoder encoder = JsonStringEncoder.getInstance();
        
        // WHEN
        byte[] result = encoder.quoteAsUTF8(text);
        
        // THEN
        byte[] expected = {72, 101, 108, 108, 111, 92, 110, (byte)0xF0, (byte)0x9F, (byte)0x98, (byte)0x80, 87, 111, 114, 108, 100};
        assertArrayEquals(expected, result);
    }
}