package org.apache.commons.math3.special;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Beta_regularizedBeta_1_5_Test {

    @Test
    @DisplayName("Input with maximum iterations causing incomplete computation, expecting approximate result")
    void testRegularizedBeta_MaxIterationsLimit_IncompleteComputation() {
        double x = 0.6;
        double a = 5.0;
        double b = 5.0;
        double epsilon = 1e-12;
        int maxIterations = 10;

        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0 even with limited iterations");
    }
}