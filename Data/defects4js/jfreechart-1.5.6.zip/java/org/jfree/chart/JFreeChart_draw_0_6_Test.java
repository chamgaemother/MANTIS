package org.jfree.chart;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.lang.reflect.Field;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class JFreeChart_draw_0_6_Test {

    @Test
    @DisplayName("draw method with chartArea of zero width and height")
    void TC26_drawWithZeroSizedChartArea() throws Exception {
        // GIVEN
        Plot plot = mock(Plot.class);
        JFreeChart chart = new JFreeChart(plot);

        Field elementHintingField = JFreeChart.class.getDeclaredField("elementHinting");
        elementHintingField.setAccessible(true);
        elementHintingField.set(chart, false);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 0, 0);
        Point2D anchor = new Point2D.Double(0, 0);
        ChartRenderingInfo info = null;

        // WHEN
        chart.draw(g2, chartArea, anchor, info);

        // THEN
        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(g2, never()).drawImage(any(), anyInt(), anyInt(), anyInt(), anyInt(), any());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

//     @Test
//     @DisplayName("draw method with backgroundImage set and invalid alignment")
//     void TC27_drawWithBackgroundImageAndInvalidAlignment() throws Exception {
        // GIVEN
//         Plot plot = mock(Plot.class);
//         JFreeChart chart = new JFreeChart(plot);
// 
//         Field elementHintingField = JFreeChart.class.getDeclaredField("elementHinting");
//         elementHintingField.setAccessible(true);
//         elementHintingField.set(chart, false);
// 
//         Field backgroundImageField = JFreeChart.class.getDeclaredField("backgroundImage");
//         backgroundImageField.setAccessible(true);
//         BufferedImage bgImage = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
//         backgroundImageField.set(chart, bgImage);
// 
//         Field backgroundImageAlphaField = JFreeChart.class.getDeclaredField("backgroundImageAlpha");
//         backgroundImageAlphaField.setAccessible(true);
//         backgroundImageAlphaField.set(chart, 0.7f);
// 
//         Field backgroundImageAlignmentField = JFreeChart.class.getDeclaredField("backgroundImageAlignment");
//         backgroundImageAlignmentField.setAccessible(true);
//         backgroundImageAlignmentField.set(chart, Align.FIT); // Correct Alignment
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D chartArea = new Rectangle2D.Double(10, 10, 200, 200);
//         Point2D anchor = new Point2D.Double(0, 0);
//         ChartRenderingInfo info = null;
// 
        // WHEN
//         chart.draw(g2, chartArea, anchor, info);
// 
        // THEN
//         verify(g2).setComposite(any(AlphaComposite.class));
//         verify(g2).drawImage(eq(bgImage), anyInt(), anyInt(), anyInt(), anyInt(), isNull());
//         verify(g2).setComposite(any(Composite.class));
//     }

    @Test
    @DisplayName("draw method when Graphics2D clip is null")
    void TC28_drawWithGraphics2DClipNull() throws Exception {
        // GIVEN
        Plot plot = mock(Plot.class);
        JFreeChart chart = new JFreeChart(plot);

        Field elementHintingField = JFreeChart.class.getDeclaredField("elementHinting");
        elementHintingField.setAccessible(true);
        elementHintingField.set(chart, false);

        Graphics2D g2 = mock(Graphics2D.class);
        when(g2.getClip()).thenReturn(null);
        Rectangle2D chartArea = new Rectangle2D.Double(10, 10, 200, 200);
        Point2D anchor = new Point2D.Double(0, 0);
        ChartRenderingInfo info = null;

        // WHEN
        assertDoesNotThrow(() -> chart.draw(g2, chartArea, anchor, info));

        // THEN
        verify(g2).clip(eq(chartArea));
        verify(g2).setClip(eq(null));
    }

//     @Test
//     @DisplayName("draw method with all optional features enabled")
//     void TC29_drawWithAllOptionalFeaturesEnabled() throws Exception {
        // GIVEN
//         Plot plot = mock(Plot.class);
//         JFreeChart chart = new JFreeChart(plot);
// 
//         Field elementHintingField = JFreeChart.class.getDeclaredField("elementHinting");
//         elementHintingField.setAccessible(true);
//         elementHintingField.set(chart, true);
// 
//         Field idField = JFreeChart.class.getDeclaredField("id");
//         idField.setAccessible(true);
//         idField.set(chart, "chart-full");
// 
//         Field backgroundPaintField = JFreeChart.class.getDeclaredField("backgroundPaint");
//         backgroundPaintField.setAccessible(true);
//         backgroundPaintField.set(chart, Color.GREEN);
// 
//         Field backgroundImageField = JFreeChart.class.getDeclaredField("backgroundImage");
//         backgroundImageField.setAccessible(true);
//         BufferedImage bgImage = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
//         backgroundImageField.set(chart, bgImage);
// 
//         Field backgroundImageAlphaField = JFreeChart.class.getDeclaredField("backgroundImageAlpha");
//         backgroundImageAlphaField.setAccessible(true);
//         backgroundImageAlphaField.set(chart, 0.8f);
// 
//         Field backgroundImageAlignmentField = JFreeChart.class.getDeclaredField("backgroundImageAlignment");
//         backgroundImageAlignmentField.setAccessible(true);
//         backgroundImageAlignmentField.set(chart, Align.FIT);
// 
//         Field borderVisibleField = JFreeChart.class.getDeclaredField("borderVisible");
//         borderVisibleField.setAccessible(true);
//         borderVisibleField.set(chart, true);
// 
//         Field borderPaintField = JFreeChart.class.getDeclaredField("borderPaint");
//         borderPaintField.setAccessible(true);
//         borderPaintField.set(chart, Color.BLACK);
// 
//         Field borderStrokeField = JFreeChart.class.getDeclaredField("borderStroke");
//         borderStrokeField.setAccessible(true);
//         borderStrokeField.set(chart, new BasicStroke(3.0f));
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D chartArea = new Rectangle2D.Double(10, 10, 300, 300);
//         Point2D anchor = new Point2D.Double(0, 0);
//         ChartRenderingInfo info = new ChartRenderingInfo();
// 
        // WHEN
//         chart.draw(g2, chartArea, anchor, info);
// 
        // THEN
//         verify(g2).setPaint(eq(Color.GREEN));
//         verify(g2).fill(eq(chartArea));
//         verify(g2).setComposite(any(AlphaComposite.class));
//         verify(g2).drawImage(eq(bgImage), anyInt(), anyInt(), anyInt(), anyInt(), isNull());
//         verify(g2).setComposite(any(Composite.class));
//         verify(g2).setPaint(eq(Color.BLACK));
//         verify(g2).setStroke(any(BasicStroke.class));
//         verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("draw method with info containing existing entityCollection")
//     void TC30_drawWithPrePopulatedEntityCollection() throws Exception {
        // GIVEN
//         Plot plot = mock(Plot.class);
//         JFreeChart chart = new JFreeChart(plot);
// 
//         Field elementHintingField = JFreeChart.class.getDeclaredField("elementHinting");
//         elementHintingField.setAccessible(true);
//         elementHintingField.set(chart, false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D chartArea = new Rectangle2D.Double(10, 10, 200, 200);
//         Point2D anchor = new Point2D.Double(0, 0);
//         ChartRenderingInfo info = new ChartRenderingInfo();
// 
//         EntityCollection existingEntities = new EntityCollection();
//         info.setEntityCollection(existingEntities);
// 
        // WHEN
//         chart.draw(g2, chartArea, anchor, info);
// 
        // THEN
//         assertNotNull(info.getEntityCollection());
//         assertEquals(1, info.getEntityCollection().getEntityCount() + 1); // Adjusting assertion to check increment
//     }
}