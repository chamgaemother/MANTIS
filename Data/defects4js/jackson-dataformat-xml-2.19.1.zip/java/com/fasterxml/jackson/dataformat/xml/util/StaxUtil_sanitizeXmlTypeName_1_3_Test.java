package com.fasterxml.jackson.dataformat.xml.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class StaxUtil_sanitizeXmlTypeName_1_3_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName with name ending with '[]' and containing special characters")
    public void TC11() {
        String name = "Data$Type@[]";
        String result = StaxUtil.sanitizeXmlTypeName(name);
        assertEquals("Data.Type_s", result);
    }
}