
package com.fasterxml.jackson.databind.type;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.type.TypeBindings;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TypeFactory_constructSpecializedType_0_2_Test {

    @Test
    @DisplayName("Creates specialized type for EnumMap when baseType is Map-like")
    public void TC06_constructSpecializedType_Map_like_with_EnumMap() throws Exception {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructType(Map.class);
        Class<?> subclass = EnumMap.class;
        boolean relaxedCompatibilityCheck = true;

        // Raw class to use in TypeBindings.create()
        JavaType keyType = baseType.findSuperType(Map.class).getKeyType();
        JavaType valueType = baseType.findSuperType(Map.class).getContentType();

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        // To compare the expected type correctly
        Method _fromClassMethod = TypeFactory.class.getDeclaredMethod("_fromClass", ClassStack.class, Class.class, TypeBindings.class);
        _fromClassMethod.setAccessible(true);
        TypeBindings typeBindings = TypeBindings.create(EnumMap.class, keyType, valueType);
        JavaType expectedType = (JavaType) _fromClassMethod.invoke(typeFactory, null, subclass, typeBindings);
        expectedType = expectedType.withHandlersFrom(baseType);
        assertEquals(expectedType, result);
    }

    @Test
    @DisplayName("Creates specialized type for TreeMap when baseType is Map-like")
    public void TC07_constructSpecializedType_Map_like_with_TreeMap() throws Exception {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructType(Map.class);
        Class<?> subclass = TreeMap.class;
        boolean relaxedCompatibilityCheck = true;

        // Raw class to use in TypeBindings.create()
        JavaType keyType = baseType.findSuperType(Map.class).getKeyType();
        JavaType valueType = baseType.findSuperType(Map.class).getContentType();

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        // To compare the expected type correctly
        Method _fromClassMethod = TypeFactory.class.getDeclaredMethod("_fromClass", ClassStack.class, Class.class, TypeBindings.class);
        _fromClassMethod.setAccessible(true);
        TypeBindings typeBindings = TypeBindings.create(TreeMap.class, keyType, valueType);
        JavaType expectedType = (JavaType) _fromClassMethod.invoke(typeFactory, null, subclass, typeBindings);
        expectedType = expectedType.withHandlersFrom(baseType);
        assertEquals(expectedType, result);
    }

    @Test
    @DisplayName("Creates specialized type for ArrayList when baseType is Collection-like")
    public void TC08_constructSpecializedType_Collection_like_with_ArrayList() throws Exception {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructType(ArrayList.class);
        Class<?> subclass = ArrayList.class;
        boolean relaxedCompatibilityCheck = true;

        // Raw class to use in TypeBindings.create()
        JavaType contentType = baseType.findSuperType(ArrayList.class).getContentType();

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        // To compare the expected type correctly
        Method _fromClassMethod = TypeFactory.class.getDeclaredMethod("_fromClass", ClassStack.class, Class.class, TypeBindings.class);
        _fromClassMethod.setAccessible(true);
        TypeBindings typeBindings = TypeBindings.create(ArrayList.class, contentType);
        JavaType expectedType = (JavaType) _fromClassMethod.invoke(typeFactory, null, subclass, typeBindings);
        expectedType = expectedType.withHandlersFrom(baseType);
        assertEquals(expectedType, result);
    }

    @Test
    @DisplayName("Creates specialized type for LinkedList when baseType is Collection-like")
    public void TC09_constructSpecializedType_Collection_like_with_LinkedList() throws Exception {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructType(LinkedList.class);
        Class<?> subclass = LinkedList.class;
        boolean relaxedCompatibilityCheck = true;

        // Raw class to use in TypeBindings.create()
        JavaType contentType = baseType.findSuperType(LinkedList.class).getContentType();

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        // To compare the expected type correctly
        Method _fromClassMethod = TypeFactory.class.getDeclaredMethod("_fromClass", ClassStack.class, Class.class, TypeBindings.class);
        _fromClassMethod.setAccessible(true);
        TypeBindings typeBindings = TypeBindings.create(LinkedList.class, contentType);
        JavaType expectedType = (JavaType) _fromClassMethod.invoke(typeFactory, null, subclass, typeBindings);
        expectedType = expectedType.withHandlersFrom(baseType);
        assertEquals(expectedType, result);
    }

    @Test
    @DisplayName("Creates specialized type for HashSet when baseType is Collection-like")
    public void TC10_constructSpecializedType_Collection_like_with_HashSet() throws Exception {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructType(HashSet.class);
        Class<?> subclass = HashSet.class;
        boolean relaxedCompatibilityCheck = true;

        // Raw class to use in TypeBindings.create()
        JavaType contentType = baseType.findSuperType(HashSet.class).getContentType();

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        // To compare the expected type correctly
        Method _fromClassMethod = TypeFactory.class.getDeclaredMethod("_fromClass", ClassStack.class, Class.class, TypeBindings.class);
        _fromClassMethod.setAccessible(true);
        TypeBindings typeBindings = TypeBindings.create(HashSet.class, contentType);
        JavaType expectedType = (JavaType) _fromClassMethod.invoke(typeFactory, null, subclass, typeBindings);
        expectedType = expectedType.withHandlersFrom(baseType);
        assertEquals(expectedType, result);
    }
}