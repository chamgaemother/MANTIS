// package org.apache.commons.math3.ode.sampling;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // 
// // import org.apache.commons.math3.RealFieldElement;
// // import org.apache.commons.math3.exception.MaxCountExceededException;
// // import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
// // import org.apache.commons.math3.ode.sampling.FieldFixedStepHandler;
// // import org.apache.commons.math3.ode.sampling.FieldStepInterpolator;
// // import org.apache.commons.math3.ode.sampling.FieldStepNormalizer;
// // import org.apache.commons.math3.util.FastMath;
// // import org.apache.commons.math3.util.Precision;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import static org.junit.jupiter.api.Assertions.assertThrows;
// // import static org.mockito.Mockito.any;
// // import static org.mockito.Mockito.anyBoolean;
// // import static org.mockito.Mockito.atLeast;
// // import static org.mockito.Mockito.eq;
// // import static org.mockito.Mockito.mock;
// // import static org.mockito.Mockito.never;
// // import static org.mockito.Mockito.times;
// // import static org.mockito.Mockito.verify;
// // import static org.mockito.Mockito.when;
// // 
// public class FieldStepNormalizer_handleStep_1_1_Test {
// // 
// //     @Test
// //     @DisplayName("handleStep propagates MaxCountExceededException when interpolator throws it")
// //     void TC16_handleStep_throws_MaxCountExceededException() {
//         // Arrange
// //         FieldFixedStepHandler<RealFieldElement<?>> handler = mock(FieldFixedStepHandler.class);
// //         FieldStepNormalizer<RealFieldElement<?>> normalizer = new FieldStepNormalizer<>(1.0, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);
// //         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
// //         FieldODEStateAndDerivative<RealFieldElement<?>> previousState = mock(FieldODEStateAndDerivative.class);
// // 
// //         when(interpolator.getPreviousState()).thenReturn(previousState);
// //         when(interpolator.isForward()).thenReturn(true);
// //         when(interpolator.getInterpolatedState(any())).thenThrow(new MaxCountExceededException(1));
// // 
//         // Act & Assert
// //         assertThrows(MaxCountExceededException.class, () -> normalizer.handleStep(interpolator, false));
// //     }
// // 
// //     @Test
// //     @DisplayName("handleStep does not call handler when bounds.firstIncluded() is false and first time equals last time")
// //     void TC17_handleStep_skips_doNormalizedStep_when_boundsFirstNotIncluded_and_firstTimeEqualsLastTime() throws Exception {
//         // Arrange
// //         FieldFixedStepHandler<RealFieldElement<?>> handler = mock(FieldFixedStepHandler.class);
// //         FieldStepNormalizer<RealFieldElement<?>> normalizer = new FieldStepNormalizer<>(1.0, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);
// //         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
// //         FieldODEStateAndDerivative<RealFieldElement<?>> firstState = mock(FieldODEStateAndDerivative.class);
// //         FieldODEStateAndDerivative<RealFieldElement<?>> lastState = mock(FieldODEStateAndDerivative.class);
// //         RealFieldElement<?> timeMock = mock(RealFieldElement.class);
// // 
// //         when(interpolator.getPreviousState()).thenReturn(firstState);
// //         when(interpolator.isForward()).thenReturn(true);
// //         when(firstState.getTime()).thenReturn(timeMock);
// //         when(lastState.getTime()).thenReturn(timeMock);
// //         when(timeMock.getReal()).thenReturn(0.0);
// // 
//         // Use reflection to set the private 'last' field
// //         java.lang.reflect.Field lastField = FieldStepNormalizer.class.getDeclaredField("last");
// //         lastField.setAccessible(true);
// //         lastField.set(normalizer, lastState);
// // 
//         // Act
// //         normalizer.handleStep(interpolator, false);
// // 
//         // Assert
// //         verify(handler, never()).handleStep(any(), anyBoolean());
// //     }
// // 
// //     @Test
// //     @DisplayName("handleStep handles multiple loop iterations with mode INCREMENT and forward direction")
// //     void TC18_handleStep_handles_multiple_loop_iterations_with_increment_mode_and_forward() throws Exception {
//         // Arrange
// //         FieldFixedStepHandler<RealFieldElement<?>> handler = mock(FieldFixedStepHandler.class);
// //         FieldStepNormalizer<RealFieldElement<?>> normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);
// //         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
// //         FieldODEStateAndDerivative<RealFieldElement<?>> firstState = mock(FieldODEStateAndDerivative.class);
// //         FieldODEStateAndDerivative<RealFieldElement<?>> lastState = mock(FieldODEStateAndDerivative.class);
// //         RealFieldElement<?> timeMock1 = mock(RealFieldElement.class);
// //         RealFieldElement<?> timeMock2 = mock(RealFieldElement.class);
// // 
// //         when(interpolator.getPreviousState()).thenReturn(firstState);
// //         when(interpolator.isForward()).thenReturn(true);
// //         when(firstState.getTime()).thenReturn(timeMock1);
// //         when(timeMock1.getReal()).thenReturn(0.0);
// //         when(lastState.getTime()).thenReturn(timeMock2);
// //         when(interpolator.getInterpolatedState(any())).thenReturn(lastState, (FieldODEStateAndDerivative<RealFieldElement<?>>[]) null);
// // 
//         // Use reflection to set the private 'last' field
// //         java.lang.reflect.Field lastField = FieldStepNormalizer.class.getDeclaredField("last");
// //         lastField.setAccessible(true);
// //         lastField.set(normalizer, lastState);
// // 
//         // Act
// //         normalizer.handleStep(interpolator, false);
// // 
//         // Assert
// //         verify(handler, atLeast(2)).handleStep(any(), eq(false));
// //     }
// // 
// //     @Test
// //     @DisplayName("handleStep includes first and last bounds when bounds are BOTH and isLast is true")
// //     void TC19_handleStep_includes_first_and_last_bounds_when_boundsBOTH_and_isLastTrue() throws Exception {
//         // Arrange
// //         FieldFixedStepHandler<RealFieldElement<?>> handler = mock(FieldFixedStepHandler.class);
// //         FieldStepNormalizer<RealFieldElement<?>> normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);
// //         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
// //         FieldODEStateAndDerivative<RealFieldElement<?>> firstState = mock(FieldODEStateAndDerivative.class);
// //         FieldODEStateAndDerivative<RealFieldElement<?>> lastState = mock(FieldODEStateAndDerivative.class);
// //         RealFieldElement<?> timeMock = mock(RealFieldElement.class);
// // 
// //         when(interpolator.getPreviousState()).thenReturn(firstState);
// //         when(interpolator.isForward()).thenReturn(true);
// //         when(firstState.getTime()).thenReturn(timeMock);
// //         when(timeMock.getReal()).thenReturn(0.0);
// //         when(lastState.getTime()).thenReturn(timeMock);
// //         when(interpolator.getInterpolatedState(any())).thenReturn(lastState);
// // 
//         // Use reflection to set the private 'last' field
// //         java.lang.reflect.Field lastField = FieldStepNormalizer.class.getDeclaredField("last");
// //         lastField.setAccessible(true);
// //         lastField.set(normalizer, lastState);
// // 
//         // Act
// //         normalizer.handleStep(interpolator, true);
// // 
//         // Assert
// //         verify(handler, times(2)).handleStep(any(), anyBoolean());
// //     }
// // }
// }