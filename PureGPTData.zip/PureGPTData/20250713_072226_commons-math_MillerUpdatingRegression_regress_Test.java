import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.stat.regression.MillerUpdatingRegression;
import org.apache.commons.math3.stat.regression.RegressionResults;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

class MillerUpdatingRegressionTest {
    @Test
    void testRegressWithNoObservations() {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, true);
        int[] emptyVariables = new int[]{0};

        assertThrows(MathIllegalArgumentException.class, () -> regression.regress(emptyVariables));
    }

    @Test
    void testTooManyRegressors() {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, true);
        double[] x1 = {1.0, 2.0};
        double y1 = 3.0;
        regression.addObservation(x1, y1);

        int[] tooManyVars = {0, 1, 2};
        assertThrows(MathIllegalArgumentException.class, () -> regression.regress(tooManyVars));
    }

    @Test
    void testRegressWithDuplicateRegressors() throws Exception {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, true);
        double[] x1 = {1.0, 2.0};
        double y1 = 3.0;
        regression.addObservation(x1, y1);
        double[] x2 = {2.0, 1.0};
        double y2 = 2.0;
        regression.addObservation(x2, y2);

        int[] variablesWithDuplicates = {0, 0, 1};
        assertDoesNotThrow(() -> regression.regress(variablesWithDuplicates));
    }

    @Test
    void testRegressBasic() throws Exception {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, true);
        double[] x1 = {1.0, 2.0};
        double y1 = 3.0;
        regression.addObservation(x1, y1);
        double[] x2 = {2.0, 1.0};
        double y2 = 2.0;
        regression.addObservation(x2, y2);

        int[] variablesToInclude = {0, 1};
        RegressionResults results = regression.regress(variablesToInclude);
        assertNotNull(results);
    }

    @Test
    void testRegressWithNonExistingIndex() {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, true);
        double[] x1 = {1.0, 2.0};
        double y1 = 3.0;
        regression.addObservation(x1, y1);

        int[] nonExistingVars = {0, 5};
        assertThrows(MathIllegalArgumentException.class, () -> regression.regress(nonExistingVars));
    }

    @Test
    void testRegressWhenReorderIsNotNeeded() throws Exception {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, false);
        double[] x1 = {1.0, 2.0};
        double y1 = 3.0;
        regression.addObservation(x1, y1);

        int[] noReorderNeeded = {0, 1};
        assertNotNull(regression.regress(noReorderNeeded));
    }

    @Test
    void testRegressWhenReorderIsNeeded() throws Exception {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, false);
        double[] x1 = {1.0, 2.0};
        double y1 = 3.0;
        regression.addObservation(x1, y1);
        double[] x2 = {3.0, 4.0};
        double y2 = 5.0;
        regression.addObservation(x2, y2);

        int[] reorderNeeded = {1, 0};
        assertNotNull(regression.regress(reorderNeeded));
    }

    @Test
    void testHandlingOfInsufficientData() {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(3, false);
        double[] x1 = {1.0, 2.0, 3.0};
        double y1 = 1.0;
        regression.addObservation(x1, y1);

        int[] variables = {0, 1, 2};
        assertThrows(MathIllegalArgumentException.class, () -> regression.regress(variables));
    }

    @ParameterizedTest
    @CsvSource({
            "1, 1, Variable index out of bounds",
            "0, 5, Too many variables"
    })
    void testInvalidVariableIndex(int a, int b, String message) {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(3, true);
        double[] x1 = {1.0, 2.0, 3.0};
        double y1 = 1.0;
        regression.addObservation(x1, y1);

        int[] variables = {a, b};

        assertThrows(MathIllegalArgumentException.class, () -> regression.regress(variables), message);
    }
}