package org.apache.commons.jxpath.functions;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.lang.reflect.Method;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.functions.MethodFunction;

public class MethodFunction_invoke_0_1_Test {

    // Helper class with static and non-static methods for testing
    public static class TestTargetClass {
        public static Object staticMethod() {
            return "static method called";
        }

        public static Object staticMethodWithContext(ExpressionContext context, String param1) {
            return "static method with context: " + param1;
        }

        public Object nonStaticMethod(Object targetObject) {
            return "non-static method called on " + targetObject;
        }

        public Object nonStaticMethodWithContext(ExpressionContext context, Object targetObject, String param1) {
            return "non-static method with context: " + param1 + " on " + targetObject;
        }
    }

    @Test
    @DisplayName("Static method with null parameters uses EMPTY_ARRAY")
    public void TC01_StaticMethodWithNullParametersUsesEMPTY_ARRAY() throws Exception {
        // GIVEN
        Method method = TestTargetClass.class.getMethod("staticMethod");
        MethodFunction function = new MethodFunction(method);
        ExpressionContext context = createMockExpressionContext();
        Object[] parameters = null;

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
        assertEquals("static method called", result, "Unexpected result from static method call");
    }

    @Test
    @DisplayName("Static method with non-null parameters without ExpressionContext")
    public void TC02_StaticMethodWithNonNullParametersWithoutExpressionContext() throws Exception {
        // GIVEN
        Method method = TestTargetClass.class.getMethod("staticMethodWithContext", ExpressionContext.class, String.class);
        MethodFunction function = new MethodFunction(method);
        ExpressionContext context = createMockExpressionContext();
        Object[] parameters = { "param1" };

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
        assertEquals("static method with context: param1", result, "Unexpected result from method call");
    }

    @Test
    @DisplayName("Static method with non-null parameters including ExpressionContext")
    public void TC03_StaticMethodWithNonNullParametersIncludingExpressionContext() throws Exception {
        // GIVEN
        Method method = TestTargetClass.class.getMethod("staticMethodWithContext", ExpressionContext.class, String.class);
        MethodFunction function = new MethodFunction(method);
        ExpressionContext context = createMockExpressionContext();
        Object[] parameters = { context, "param1" };

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
        assertEquals("static method with context: param1", result, "Unexpected result from method call");
    }

    @Test
    @DisplayName("Non-static method with single parameter without ExpressionContext")
    public void TC04_NonStaticMethodWithSingleParameterWithoutExpressionContext() throws Exception {
        // GIVEN
        Method method = TestTargetClass.class.getMethod("nonStaticMethod", Object.class);
        MethodFunction function = new MethodFunction(method);
        ExpressionContext context = createMockExpressionContext();
        Object[] parameters = { new TestTargetClass(), "targetObject" };

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
        assertEquals("non-static method called on targetObject", result, "Unexpected result from non-static method call");
    }

    @Test
    @DisplayName("Non-static method with parameters including ExpressionContext")
    public void TC05_NonStaticMethodWithParametersIncludingExpressionContext() throws Exception {
        // GIVEN
        Method method = TestTargetClass.class.getMethod("nonStaticMethodWithContext", ExpressionContext.class, Object.class, String.class);
        MethodFunction function = new MethodFunction(method);
        ExpressionContext context = createMockExpressionContext();
        Object[] parameters = { context, new TestTargetClass(), "param1" };

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
        assertEquals("non-static method with context: param1 on targetObject", result, "Unexpected result from non-static method call");
    }

    // Helper method to create a mock ExpressionContext
    private ExpressionContext createMockExpressionContext() {
        return mock(ExpressionContext.class);
    }
}