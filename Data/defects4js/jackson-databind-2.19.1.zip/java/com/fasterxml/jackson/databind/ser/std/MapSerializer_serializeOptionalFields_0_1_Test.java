package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class MapSerializer_serializeOptionalFields_0_1_Test {

    private static final Object MARKER_FOR_EMPTY = new Object();
    private static final Object OTHER_VALUE = new Object();

    @Test
    @DisplayName("TC01: _valueTypeSerializer is null, triggering serializeTypedFields")
    void TC01_serializeOptionalFields_valueTypeSerializerNull() throws Exception {
        // Arrange
        MapSerializer serializer = new MapSerializer(null, null, null, false);

        // Mock dependencies
        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        // Spy on serializer to verify method calls
        MapSerializer spySerializer = spy(serializer);

        Map<Object, Object> map = new HashMap<>();

        // Act
        spySerializer.serializeOptionalFields(map, jsonGenerator, serializerProvider, null);

        // Assert
        verify(spySerializer, times(1)).serializeTypedFields(map, jsonGenerator, serializerProvider, null);
    }

    @Test
    @DisplayName("TC02: _valueTypeSerializer is not null and suppressableValue equals MARKER_FOR_EMPTY with empty map")
    void TC02_serializeOptionalFields_suppressableValueIsMarkerAndEmptyMap() throws Exception {
        // Arrange
        TypeSerializer valueTypeSerializer = mock(TypeSerializer.class);
        MapSerializer serializer = new MapSerializer(null, null, null, null, true, valueTypeSerializer, null, null);

        // Set _suppressableValue to MARKER_FOR_EMPTY via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(serializer, MARKER_FOR_EMPTY);

        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        Map<Object, Object> map = new HashMap<>();

        // Act
        serializer.serializeOptionalFields(map, jsonGenerator, serializerProvider, MARKER_FOR_EMPTY);

        // Assert
        verifyNoInteractions(jsonGenerator);
    }

    @Test
    @DisplayName("TC03: _valueTypeSerializer is not null and suppressableValue does not equal MARKER_FOR_EMPTY with empty map")
    void TC03_serializeOptionalFields_suppressableValueNotMarkerAndEmptyMap() throws Exception {
        // Arrange
        TypeSerializer valueTypeSerializer = mock(TypeSerializer.class);
        MapSerializer serializer = new MapSerializer(null, null, null, null, true, valueTypeSerializer, null, null);

        // Set _suppressableValue to OTHER_VALUE via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(serializer, OTHER_VALUE);

        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        Map<Object, Object> map = new HashMap<>();

        // Act
        serializer.serializeOptionalFields(map, jsonGenerator, serializerProvider, OTHER_VALUE);

        // Assert
        verifyNoInteractions(jsonGenerator);
    }

    @Test
    @DisplayName("TC04: _valueTypeSerializer is not null, suppressableValue equals MARKER_FOR_EMPTY, map with one entry")
    void TC04_serializeOptionalFields_suppressableValueIsMarkerAndSingleEntry() throws Exception {
        // Arrange
        TypeSerializer valueTypeSerializer = mock(TypeSerializer.class);
        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);

        MapSerializer serializer = new MapSerializer(null, null, null, null, true, valueTypeSerializer, keySerializer, valueSerializer);

        // Set _suppressableValue to MARKER_FOR_EMPTY via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(serializer, MARKER_FOR_EMPTY);

        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        Map<Object, Object> map = new HashMap<>();
        map.put("key1", "value1");

        // Act
        serializer.serializeOptionalFields(map, jsonGenerator, serializerProvider, MARKER_FOR_EMPTY);

        // Assert
        verify(keySerializer, times(1)).serialize("key1", jsonGenerator, serializerProvider);
        verify(valueSerializer, times(1)).serialize("value1", jsonGenerator, serializerProvider);
    }

    @Test
    @DisplayName("TC05: _valueTypeSerializer is not null, suppressableValue does not equal MARKER_FOR_EMPTY, map with one entry")
    void TC05_serializeOptionalFields_suppressableValueNotMarkerAndSingleEntry() throws Exception {
        // Arrange
        TypeSerializer valueTypeSerializer = mock(TypeSerializer.class);
        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);

        MapSerializer serializer = new MapSerializer(null, null, null, null, true, valueTypeSerializer, keySerializer, valueSerializer);

        // Set _suppressableValue to OTHER_VALUE via reflection
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(serializer, OTHER_VALUE);

        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        Map<Object, Object> map = new HashMap<>();
        map.put("key1", "value1");

        // Act
        serializer.serializeOptionalFields(map, jsonGenerator, serializerProvider, OTHER_VALUE);

        // Assert
        verify(keySerializer, times(1)).serialize("key1", jsonGenerator, serializerProvider);
        verify(valueSerializer, times(1)).serialize("value1", jsonGenerator, serializerProvider);
    }
}