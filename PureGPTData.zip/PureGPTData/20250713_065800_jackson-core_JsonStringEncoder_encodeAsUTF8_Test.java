import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class JsonStringEncoderTest {

    JsonStringEncoder encoder = new JsonStringEncoder();

    @Test
    void testEncodeAsUTF8WithBasicAscii() {
        String input = "hello";
        byte[] expected = {104, 101, 108, 108, 111};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithNonAsciiCharacters() {
        String input = "café"; // é is non-ASCII
        byte[] expected = {99, 97, 102, (byte) 0xc3, (byte) 0xa9};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithSurrogatePairs() {
        String input = new String(Character.toChars(0x1F60A)); // Smile emoji
        byte[] expected = {(byte) 0xF0, (byte) 0x9F, (byte) 0x98, (byte) 0x8A};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithIllegalSurrogate() {
        String input = "\uD800";
        assertThrows(IllegalArgumentException.class, () -> encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithEmptyString() {
        String input = "";
        byte[] expected = {};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithBoundaryAscii() {
        String input = "\u007F"; // DEL ASCII character
        byte[] expected = {127};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithTwoByteCharacter() {
        String input = "¢"; // Cent character
        byte[] expected = {(byte) 0xC2, (byte) 0xA2};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithThreeByteCharacter() {
        String input = "€"; // Euro character
        byte[] expected = {(byte) 0xE2, (byte) 0x82, (byte) 0xAC};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithFourByteUnicode() {
        String input = "\uDBFF\uDFFF"; // Maximum UTF-16 surrogate pair
        byte[] expected = {(byte) 0xF4, (byte) 0x8F, (byte) 0xBF, (byte) 0xBF};
        assertArrayEquals(expected, encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8WithIllegalSecondSurrogate() {
        String input = "\uD800\u0020";
        assertThrows(IllegalArgumentException.class, () -> encoder.encodeAsUTF8(input));
    }
}