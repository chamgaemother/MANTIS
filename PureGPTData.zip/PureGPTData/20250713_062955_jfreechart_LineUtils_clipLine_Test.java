import static org.junit.jupiter.api.Assertions.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.Test;
import org.jfree.chart.util.LineUtils;

public class LineUtilsTest {

    @Test
    void testClipLine_NullLine() {
        assertThrows(NullPointerException.class, () -> LineUtils.clipLine(null, new Rectangle2D.Double(0, 0, 10, 10)));
    }

    @Test
    void testClipLine_NullRectangle() {
        assertThrows(NullPointerException.class, () -> LineUtils.clipLine(new Line2D.Double(1, 1, 5, 5), null));
    }

    @Test
    void testClipLine_NonFiniteCoordinates() {
        assertFalse(LineUtils.clipLine(new Line2D.Double(Double.POSITIVE_INFINITY, 1, 5, 5), new Rectangle2D.Double(0, 0, 10, 10)));
        assertFalse(LineUtils.clipLine(new Line2D.Double(1, Double.NaN, 5, 5), new Rectangle2D.Double(0, 0, 10, 10)));
    }

    @Test
    void testClipLine_LineOutsideRectangle() {
        Line2D line = new Line2D.Double(-5, -5, -2, -2);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        assertFalse(LineUtils.clipLine(line, rect));
    }

    @Test
    void testClipLine_LineIntersectingRectangle() {
        Line2D line = new Line2D.Double(-5, -5, 5, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        assertTrue(LineUtils.clipLine(line, rect));
        assertEquals(new Line2D.Double(0, 0, 5, 5), line);
    }

    @Test
    void testClipLine_LineCompletelyInsideRectangle() {
        Line2D line = new Line2D.Double(1, 1, 9, 9);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        assertTrue(LineUtils.clipLine(line, rect));
        assertEquals(new Line2D.Double(1, 1, 9, 9), line);
    }

    @Test
    void testClipLine_LineCoincidingWithBoundary() {
        Line2D line = new Line2D.Double(0, 0, 10, 0);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        assertTrue(LineUtils.clipLine(line, rect));
        assertEquals(new Line2D.Double(0, 0, 10, 0), line);
    }

    @Test
    void testClipLine_LineVerticalIntersection() {
        Line2D line = new Line2D.Double(5, -5, 5, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        assertTrue(LineUtils.clipLine(line, rect));
        assertEquals(new Line2D.Double(5, 0, 5, 5), line);
    }

    @Test
    void testClipLine_LineHorizontalIntersection() {
        Line2D line = new Line2D.Double(-5, 5, 5, 5);
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        assertTrue(LineUtils.clipLine(line, rect));
        assertEquals(new Line2D.Double(0, 5, 5, 5), line);
    }
}