package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_containsKey_0_2_Test {

    @Test
    @DisplayName("Return false when map size > 0, key is not null but keys don't match any stored key.")
    void testContainsKey_TC06() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN a Flat3Map with size greater than 0 with different stored keys
        Flat3Map<Object, Integer> map = new Flat3Map<>();

        // Reflectively set private fields
        setPrivateField(map, "size", 3);
        setPrivateField(map, "key1", "A");
        setPrivateField(map, "key2", "B");
        setPrivateField(map, "key3", "C");

        // WHEN containsKey is called with a key that doesn't match any stored key
        Object inputKey = "D";
        boolean result = map.containsKey(inputKey);

        // THEN assert the result is false
        assertFalse(result);
    }

    @Test
    @DisplayName("Test when key matches key3 in un-delegated map with matching hash codes.")
    void testContainsKey_TC07() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN a Flat3Map with size 3 and a stored key3 matching the input key
        Flat3Map<Object, Integer> map = new Flat3Map<>();

        // Reflectively set private fields
        setPrivateField(map, "size", 3);
        setPrivateField(map, "key3", "C");
        setPrivateField(map, "hash3", Objects.hashCode("C"));

        // WHEN containsKey is called with the matching key
        boolean result = map.containsKey("C");

        // THEN assert the result is true
        assertTrue(result);
    }

    @Test
    @DisplayName("Test when key matches key2 in un-delegated map with matching hash codes.")
    void testContainsKey_TC08() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN a Flat3Map with size 2 and a stored key2 matching the input key
        Flat3Map<Object, Integer> map = new Flat3Map<>();

        // Reflectively set private fields
        setPrivateField(map, "size", 2);
        setPrivateField(map, "key2", "B");
        setPrivateField(map, "hash2", Objects.hashCode("B"));

        // WHEN containsKey is called with the matching key
        boolean result = map.containsKey("B");

        // THEN assert the result is true
        assertTrue(result);
    }

    @Test
    @DisplayName("Test when key matches key1 in un-delegated map with matching hash codes.")
    void testContainsKey_TC09() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN a Flat3Map with size 1 and a stored key1 matching the input key
        Flat3Map<Object, Integer> map = new Flat3Map<>();

        // Reflectively set private fields
        setPrivateField(map, "size", 1);
        setPrivateField(map, "key1", "A");
        setPrivateField(map, "hash1", Objects.hashCode("A"));

        // WHEN containsKey is called with the matching key
        boolean result = map.containsKey("A");

        // THEN assert the result is true
        assertTrue(result);
    }

    @Test
    @DisplayName("Return false when map size is 0 and delegateMap is null.")
    void testContainsKey_TC10() {
        // GIVEN a Flat3Map with size 0 and null delegate map
        Flat3Map<Object, Integer> map = new Flat3Map<>();

        // WHEN containsKey is called with any key
        boolean result = map.containsKey("AnyKey");

        // THEN assert the result is false
        assertFalse(result);
    }

    private void setPrivateField(Object object, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(object, value);
    }
}