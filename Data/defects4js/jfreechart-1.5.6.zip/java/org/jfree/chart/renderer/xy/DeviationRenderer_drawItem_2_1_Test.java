package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class DeviationRenderer_drawItem_2_1_Test {

//     @Test
//     @DisplayName("Pass is 0 with orientation VERTICAL, ensuring coordinates are added correctly")
//     public void TC06_drawItem_with_vertical_orientation() throws Exception {
        // Arrange
//         DeviationRenderer renderer = new DeviationRenderer();
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         PlotRenderingInfo plotRenderingInfo = Mockito.mock(PlotRenderingInfo.class);
//         DeviationRenderer.State state = renderer.new State(plotRenderingInfo);
//         Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = Mockito.mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 1; // Not the last item
//         int pass = 0;
// 
        // Mocking behavior
//         Mockito.when(renderer.getItemVisible(series, item)).thenReturn(true);
//         Mockito.when(dataset.getItemCount(series)).thenReturn(3);
//         Mockito.when(dataset.getXValue(series, item)).thenReturn(10.0);
//         Mockito.when(dataset.getStartYValue(series, item)).thenReturn(5.0);
//         Mockito.when(dataset.getEndYValue(series, item)).thenReturn(15.0);
//         Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL); // Assuming UNKNOWN is not available
//         Mockito.when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         Mockito.when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         Mockito.when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
//         Mockito.when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
//         Mockito.when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plotRenderingInfo, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         Assertions.assertEquals(1, state.lowerCoordinates.size(), "lowerCoordinates should have one entry");
//         Assertions.assertEquals(1, state.upperCoordinates.size(), "upperCoordinates should have one entry");
// 
//         double[] lowerCoord = (double[]) state.lowerCoordinates.get(0);
//         Assertions.assertArrayEquals(new double[] {100.0, 50.0}, lowerCoord, "Lower coordinates should match expected values");
// 
//         double[] upperCoord = (double[]) state.upperCoordinates.get(0);
//         Assertions.assertArrayEquals(new double[] {100.0, 150.0}, upperCoord, "Upper coordinates should match expected values");
// 
        // Verify that g2.fill() is not called since it's not the last item
//         Mockito.verify(g2, Mockito.never()).fill(Mockito.any());
//     }

//     @Test
//     @DisplayName("Pass is not 0, is item pass, and EntityCollection is null")
//     public void TC07_drawItem_with_item_pass_and_null_entityCollection() throws Exception {
        // Arrange
//         DeviationRenderer renderer = Mockito.mock(DeviationRenderer.class);
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         PlotRenderingInfo plotRenderingInfo = Mockito.mock(PlotRenderingInfo.class);
//         DeviationRenderer.State state = renderer.new State(plotRenderingInfo);
//         Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = Mockito.mock(CrosshairState.class);
// 
//         int series = 1;
//         int item = 4;
//         int pass = 2; // Indicates item pass
// 
        // Mocking behavior
//         Mockito.when(renderer.getItemVisible(series, item)).thenReturn(true);
//         Mockito.when(renderer.isItemPass(pass)).thenReturn(true);
//         Mockito.when(dataset.getItemCount(series)).thenReturn(5);
//         ChartRenderingInfo chartInfo = Mockito.mock(ChartRenderingInfo.class);
//         Mockito.when(plotRenderingInfo.getOwner()).thenReturn(chartInfo);
//         Mockito.when(chartInfo.getEntityCollection()).thenReturn(null);
// 
        // Act & Assert
//         Assertions.assertDoesNotThrow(() -> {
//             renderer.drawItem(g2, state, dataArea, plotRenderingInfo, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
//         }, "drawItem should handle null EntityCollection without throwing exceptions");
// 
        // Verify that drawSecondaryPass is invoked with null EntityCollection
//         Mockito.verify(renderer).drawSecondaryPass(g2, plot, dataset, pass, series, item, domainAxis, dataArea, rangeAxis, crosshairState, (EntityCollection) null);
//     }
}