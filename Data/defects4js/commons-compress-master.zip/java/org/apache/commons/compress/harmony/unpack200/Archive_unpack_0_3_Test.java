package org.apache.commons.compress.harmony.unpack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.jar.JarOutputStream;

import static org.junit.jupiter.api.Assertions.*;

public class Archive_unpack_0_3_Test {

    @Test
    @DisplayName("compressedWithE0 is false with one segment to process")
    void TC11_compressedWithE0_false_one_segment() throws Exception {
        // Arrange
        InputStream inputStream = new ByteArrayInputStream(new byte[] {
            (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D
        });
        JarOutputStream outputStream = new JarOutputStream(System.out);
        Archive archive = new Archive(inputStream, outputStream);

        // Act
        archive.unpack();

        // Verify: Ensure no exception occurred, method ran completely.
        assertDoesNotThrow(() -> archive.unpack());
    }

    @Test
    @DisplayName("compressedWithE0 is false with multiple segments to process")
    void TC12_compressedWithE0_false_multiple_segments() throws Exception {
        // Arrange
        InputStream inputStream = new ByteArrayInputStream(new byte[] {
            (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D
        });
        JarOutputStream outputStream = new JarOutputStream(System.out);
        Archive archive = new Archive(inputStream, outputStream);

        // Act
        archive.unpack();

        // Verify: Ensure no exception occurred, method ran completely.
        assertDoesNotThrow(() -> archive.unpack());
    }

    @Test
    @DisplayName("Override deflate hint is true during segment processing")
    void TC13_overrideDeflateHint_true() throws Exception {
        // Arrange
        InputStream inputStream = new ByteArrayInputStream(new byte[] {
            (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D
        });
        JarOutputStream outputStream = new JarOutputStream(System.out);
        Archive archive = new Archive(inputStream, outputStream);
        archive.setDeflateHint(true);

        // Act
        archive.unpack();

        // Verify: Ensure no exception occurred, method ran completely.
        assertDoesNotThrow(() -> archive.unpack());
    }

    @Test
    @DisplayName("Override deflate hint is false during segment processing")
    void TC14_overrideDeflateHint_false() throws Exception {
        // Arrange
        InputStream inputStream = new ByteArrayInputStream(new byte[] {
            (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D
        });
        JarOutputStream outputStream = new JarOutputStream(System.out);
        Archive archive = new Archive(inputStream, outputStream);

        // Act
        archive.unpack();

        // Verify: Ensure no exception occurred, method ran completely.
        assertDoesNotThrow(() -> archive.unpack());
    }

    @Test
    @DisplayName("closeStreams is true, all streams are closed after unpacking")
    void TC15_closeStreams_true() throws Exception {
        // Arrange
        byte[] data = new byte[] {
            (byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D
        };
        InputStream inputStream = new ByteArrayInputStream(data);
        JarOutputStream outputStream = new JarOutputStream(System.out);
        Archive archive = new Archive(inputStream, outputStream);

        // Act
        archive.unpack();

        // Verify: Ensure no exception occurred, method ran completely.
        assertDoesNotThrow(() -> archive.unpack());
    }
}