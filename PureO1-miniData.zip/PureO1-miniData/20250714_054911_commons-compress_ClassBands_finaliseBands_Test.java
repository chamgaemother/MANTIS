package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

import org.apache.commons.compress.harmony.pack200.AttributeDefinitionBands.AttributeDefinition;
import org.apache.commons.compress.harmony.pack200.Segment.SegmentMethodVisitor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.objectweb.asm.Label;
import org.objectweb.asm.Opcodes;

class ClassBandsTest {

    private Segment mockSegment;
    private SegmentHeader mockSegmentHeader;
    private CpBands mockCpBands;
    private AttributeDefinitionBands mockAttrBands;
    private ClassBands classBands;

    @BeforeEach
    void setUp() throws IOException {
        mockSegment = mock(Segment.class);
        mockSegmentHeader = mock(SegmentHeader.class);
        mockCpBands = mock(CpBands.class);
        mockAttrBands = mock(AttributeDefinitionBands.class);

        when(mockSegment.getSegmentHeader()).thenReturn(mockSegmentHeader);
        when(mockSegment.getCpBands()).thenReturn(mockCpBands);
        when(mockSegment.getAttrBands()).thenReturn(mockAttrBands);

        when(mockSegmentHeader.getDefaultMajorVersion()).thenReturn(52);

        when(mockCpBands.getCPClass(anyString())).thenAnswer(invocation -> {
            String className = invocation.getArgument(0);
            return new CPClass(className, 1);
        });

        when(mockCpBands.getCPNameAndType(anyString(), anyString())).thenAnswer(invocation -> {
            String name = invocation.getArgument(0);
            String desc = invocation.getArgument(1);
            return new CPNameAndType(name, desc, 1);
        });

        when(mockCpBands.getCPSignature(anyString())).thenAnswer(invocation -> {
            String signature = invocation.getArgument(0);
            return new CPSignature(signature, 1);
        });

        when(mockCpBands.getConstant(any())).thenAnswer(invocation -> {
            Object value = invocation.getArgument(0);
            return new CPConstant<>(value, 1);
        });

        classBands = new ClassBands(mockSegment, 2, 0, false);
    }

    @Test
    void testFinaliseBands_MajorVersionDifferent() throws Exception {
        // Set up major_versions different from default
        setPrivateField(classBands, "major_versions", new int[] {60, 52});
        setPrivateField(classBands, "class_flags", new long[] {0L, 0L});
        setPrivateField(classBands, "classFileVersionMajor", new ArrayList<Integer>());
        setPrivateField(classBands, "classFileVersionMinor", new ArrayList<Integer>());

        classBands.finaliseBands();

        long[] classFlags = (long[]) getPrivateField(classBands, "class_flags");
        List<Integer> classFileVersionMajor = (List<Integer>) getPrivateField(classBands, "classFileVersionMajor");
        List<Integer> classFileVersionMinor = (List<Integer>) getPrivateField(classBands, "classFileVersionMinor");

        assertEquals(2, classFlags.length);
        assertEquals(1 << 24, classFlags[0]);
        assertEquals(0L, classFlags[1]);

        assertEquals(1, classFileVersionMajor.size());
        assertEquals(60, classFileVersionMajor.get(0));
        assertEquals(1, classFileVersionMinor.size());
        assertEquals(0, classFileVersionMinor.get(0));
    }

    @Test
    void testFinaliseBands_NumHandlers0_HeaderWithin() throws Exception {
        // Set up codeHandlerCount = 0, maxLocals *12 + maxStack +1 <145, maxStack <12
        setPrivateField(classBands, "codeHandlerCount", new IntList(Arrays.asList(0)));
        setPrivateField(classBands, "codeMaxLocals", new IntList(Arrays.asList(10)));
        setPrivateField(classBands, "codeMaxStack", new IntList(Arrays.asList(10)));
        setPrivateField(classBands, "codeFlags", new ArrayList<Long>());

        classBands.finaliseBands();

        int[] codeHeaders = (int[]) getPrivateField(classBands, "codeHeaders");
        assertEquals(1, codeHeaders.length);
        assertEquals(10 * 12 + 10 + 1, codeHeaders[0]);

        IntList codeHandlerCount = (IntList) getPrivateField(classBands, "codeHandlerCount");
        assertEquals(0, codeHandlerCount.size());
    }

    @Test
    void testFinaliseBands_NumHandlers0_HeaderExceeds() throws Exception {
        // Set up codeHandlerCount = 0, maxLocals *12 + maxStack +1 >=145 or maxStack >=12
        setPrivateField(classBands, "codeHandlerCount", new IntList(Arrays.asList(0)));
        setPrivateField(classBands, "codeMaxLocals", new IntList(Arrays.asList(12)));
        setPrivateField(classBands, "codeMaxStack", new IntList(Arrays.asList(13)));
        when(mockSegmentHeader.have_all_code_flags()).thenReturn(false);
        setPrivateField(classBands, "codeFlags", new ArrayList<Long>());

        classBands.finaliseBands();

        int[] codeHeaders = (int[]) getPrivateField(classBands, "codeHeaders");
        assertEquals(1, codeHeaders.length);
        assertEquals(0, codeHeaders[0]);

        IntList codeHandlerCount = (IntList) getPrivateField(classBands, "codeHandlerCount");
        assertEquals(1, codeHandlerCount.size());

        ArrayList<Long> codeFlags = (ArrayList<Long>) getPrivateField(classBands, "codeFlags");
        assertEquals(1, codeFlags.size());
        assertEquals(0L, codeFlags.get(0).longValue());
    }

    @Test
    void testFinaliseBands_NumHandlers1_HeaderWithin() throws Exception {
        // Set up codeHandlerCount =1, maxLocals *8 + maxStack +145 <209, maxStack <8
        setPrivateField(classBands, "codeHandlerCount", new IntList(Arrays.asList(1)));
        setPrivateField(classBands, "codeMaxLocals", new IntList(Arrays.asList(10)));
        setPrivateField(classBands, "codeMaxStack", new IntList(Arrays.asList(5)));
        setPrivateField(classBands, "codeFlags", new ArrayList<Long>());

        classBands.finaliseBands();

        int[] codeHeaders = (int[]) getPrivateField(classBands, "codeHeaders");
        assertEquals(1, codeHeaders.length);
        assertEquals(10 * 8 + 5 + 145, codeHeaders[0]);

        IntList codeHandlerCount = (IntList) getPrivateField(classBands, "codeHandlerCount");
        assertEquals(0, codeHandlerCount.size());
    }

    @Test
    void testFinaliseBands_NumHandlers2_HeaderWithin() throws Exception {
        // Set up codeHandlerCount =2, maxLocals *7 + maxStack +209 <256, maxStack <7
        setPrivateField(classBands, "codeHandlerCount", new IntList(Arrays.asList(2)));
        setPrivateField(classBands, "codeMaxLocals", new IntList(Arrays.asList(20)));
        setPrivateField(classBands, "codeMaxStack", new IntList(Arrays.asList(30)));
        setPrivateField(classBands, "codeFlags", new ArrayList<Long>());

        classBands.finaliseBands();

        int[] codeHeaders = (int[]) getPrivateField(classBands, "codeHeaders");
        assertEquals(1, codeHeaders.length);
        assertEquals(20 * 7 + 30 + 209, codeHeaders[0]);

        IntList codeHandlerCount = (IntList) getPrivateField(classBands, "codeHandlerCount");
        assertEquals(0, codeHandlerCount.size());
    }

    @Test
    void testFinaliseBands_NumHandlersDefault() throws Exception {
        // Set up codeHandlerCount >2
        setPrivateField(classBands, "codeHandlerCount", new IntList(Arrays.asList(3)));
        setPrivateField(classBands, "codeMaxLocals", new IntList(Arrays.asList(5)));
        setPrivateField(classBands, "codeMaxStack", new IntList(Arrays.asList(5)));
        when(mockSegmentHeader.have_all_code_flags()).thenReturn(true);
        setPrivateField(classBands, "codeFlags", new ArrayList<Long>());

        classBands.finaliseBands();

        int[] codeHeaders = (int[]) getPrivateField(classBands, "codeHeaders");
        assertEquals(1, codeHeaders.length);
        assertEquals(0, codeHeaders[0]);

        IntList codeHandlerCount = (IntList) getPrivateField(classBands, "codeHandlerCount");
        assertEquals(1, codeHandlerCount.size());

        ArrayList<Long> codeFlags = (ArrayList<Long>) getPrivateField(classBands, "codeFlags");
        assertEquals(0, codeFlags.size());
    }

    @Test
    void testFinaliseBands_InnerClassesProcessing() throws Exception {
        // Set up class_this and classReferencesInnerClass
        CPClass outerClass = new CPClass("com/example/Outer", 1);
        CPClass innerClass = new CPClass("com/example/Outer$Inner", 2);
        setPrivateField(classBands, "class_this", new CPClass[] { outerClass, innerClass });
        Set<CPClass> referenced = new HashSet<>();
        referenced.add(innerClass);
        when(mockSegment.getIcBands()).thenReturn(mock(IcBands.class));
        when(mockSegment.getIcBands().getInnerClassesForOuter("com/example/Outer")).thenReturn(Collections.emptyList());
        when(mockSegment.getIcBands().getIcTuple(innerClass)).thenReturn(new IcBands.IcTuple(innerClass, null, null, 0));

        setPrivateField(classBands, "classReferencesInnerClass", new HashMap<CPClass, Set<CPClass>>() {{
            put(outerClass, referenced);
        }});
        setPrivateField(classBands, "class_flags", new long[] {0L, 0L});
        setPrivateField(classBands, "class_InnerClasses_N", new int[0]);
        setPrivateField(classBands, "class_InnerClasses_RC", new CPClass[0]);
        setPrivateField(classBands, "class_InnerClasses_F", new int[0]);
        setPrivateField(classBands, "classInnerClassesOuterRCN", new ArrayList<CPClass>());
        setPrivateField(classBands, "classInnerClassesNameRUN", new ArrayList<CPUTF8>());

        classBands.finaliseBands();

        long[] classFlags = (long[]) getPrivateField(classBands, "class_flags");
        assertEquals(1 << 23, classFlags[0]);
        assertEquals(0L, classFlags[1]);

        int[] innerClassesN = (int[]) getPrivateField(classBands, "class_InnerClasses_N");
        assertEquals(1, innerClassesN.length);
        assertEquals(1, innerClassesN[0]);

        CPClass[] classInnerClassesRC = (CPClass[]) getPrivateField(classBands, "class_InnerClasses_RC");
        assertEquals(1, classInnerClassesRC.length);
        assertEquals(innerClass, classInnerClassesRC[0]);

        int[] classInnerClassesF = (int[]) getPrivateField(classBands, "class_InnerClasses_F");
        assertEquals(1, classInnerClassesF.length);
        assertEquals(0, classInnerClassesF[0]);

        List<CPClass> outerRCN = (List<CPClass>) getPrivateField(classBands, "classInnerClassesOuterRCN");
        List<CPUTF8> nameRUN = (List<CPUTF8>) getPrivateField(classBands, "classInnerClassesNameRUN");
        assertTrue(outerRCN.isEmpty());
        assertTrue(nameRUN.isEmpty());
    }

    @Test
    void testFinaliseBands_BandsHaveContent() throws Exception {
        // Set up bands to have content
        NewAttributeBands mockClassRVA = mock(NewAttributeBands.class);
        when(mockClassRVA.hasContent()).thenReturn(true);
        when(mockClassRVA.numBackwardsCalls()).thenReturn(Arrays.asList(1, 2));
        when(mockClassRVA.isUsedAtLeastOnce()).thenReturn(true);
        when(mockClassRVA.numBackwardsCalls()).thenReturn(Arrays.asList(1, 2));
        when(mockClassRVA.getFlagIndex()).thenReturn(1);

        NewAttributeBands mockMethodRVA = mock(NewAttributeBands.class);
        when(mockMethodRVA.hasContent()).thenReturn(true);
        when(mockMethodRVA.numBackwardsCalls()).thenReturn(Arrays.asList(3));
        when(mockMethodRVA.isUsedAtLeastOnce()).thenReturn(true);
        when(mockMethodRVA.getFlagIndex()).thenReturn(2);

        setPrivateField(classBands, "classAttributeBands", Arrays.asList(mockClassRVA));
        setPrivateField(classBands, "methodAttributeBands", Arrays.asList(mockMethodRVA));
        setPrivateField(classBands, "fieldAttributeBands", new ArrayList<NewAttributeBands>());
        setPrivateField(classBands, "codeAttributeBands", new ArrayList<NewAttributeBands>());

        classBands.finaliseBands();

        int[] classAttrCalls = (int[]) getPrivateField(classBands, "class_attr_calls");
        int[] methodAttrCalls = (int[]) getPrivateField(classBands, "method_attr_calls");

        assertArrayEquals(new int[] {1, 2}, classAttrCalls);
        assertArrayEquals(new int[] {3}, methodAttrCalls);
    }

    @Test
    void testFinaliseBands_BandsDoNotHaveContent() throws Exception {
        // Set up bands to not have content
        NewAttributeBands mockClassRVA = mock(NewAttributeBands.class);
        when(mockClassRVA.hasContent()).thenReturn(false);
        when(mockClassRVA.isUsedAtLeastOnce()).thenReturn(false);

        NewAttributeBands mockMethodRVA = mock(NewAttributeBands.class);
        when(mockMethodRVA.hasContent()).thenReturn(false);
        when(mockMethodRVA.isUsedAtLeastOnce()).thenReturn(false);

        setPrivateField(classBands, "classAttributeBands", Arrays.asList(mockClassRVA));
        setPrivateField(classBands, "methodAttributeBands", Arrays.asList(mockMethodRVA));
        setPrivateField(classBands, "fieldAttributeBands", new ArrayList<NewAttributeBands>());
        setPrivateField(classBands, "codeAttributeBands", new ArrayList<NewAttributeBands>());

        classBands.finaliseBands();

        int[] classAttrCalls = (int[]) getPrivateField(classBands, "class_attr_calls");
        int[] methodAttrCalls = (int[]) getPrivateField(classBands, "method_attr_calls");

        assertEquals(0, classAttrCalls.length);
        assertEquals(0, methodAttrCalls.length);
    }

    // Helper methods to set and get private fields using reflection
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = getField(target.getClass(), fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private Object getPrivateField(Object target, String fieldName) throws Exception {
        Field field = getField(target.getClass(), fieldName);
        field.setAccessible(true);
        return field.get(target);
    }

    private Field getField(Class<?> clazz, String fieldName) throws NoSuchFieldException {
        Class<?> current = clazz;
        while (current != null) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException e) {
                current = current.getSuperclass();
            }
        }
        throw new NoSuchFieldException(fieldName);
    }
}

// Mock classes to represent dependencies

class Segment {
    SegmentHeader getSegmentHeader() {
        return null;
    }

    CpBands getCpBands() {
        return null;
    }

    AttributeDefinitionBands getAttrBands() {
        return null;
    }

    IcBands getIcBands() {
        return null;
    }
}

class SegmentHeader {
    int getDefaultMajorVersion() {
        return 0;
    }

    boolean have_all_code_flags() {
        return false;
    }
}

class CpBands {
    CPClass getCPClass(String name) {
        return new CPClass(name, 0);
    }

    CPNameAndType getCPNameAndType(String name, String desc) {
        return new CPNameAndType(name, desc, 0);
    }

    CPSignature getCPSignature(String signature) {
        return new CPSignature(signature, 0);
    }

    CPConstant<?> getConstant(Object value) {
        return new CPConstant<>(value, 0);
    }

    CPUTF8 getCPUtf8(String str) {
        return new CPUTF8(str, 0);
    }

    ConstantPoolEntry[] getCpEntryList(List<?> list) {
        return new ConstantPoolEntry[list.size()];
    }

    ConstantPoolEntry[] getCpEntryOrNullList(List<?> list) {
        return new ConstantPoolEntry[list.size()];
    }
}

class AttributeDefinitionBands {
    static class AttributeDefinition {}
    List<AttributeDefinition> getClassAttributeLayouts() {
        return new ArrayList<>();
    }
    List<AttributeDefinition> getMethodAttributeLayouts() {
        return new ArrayList<>();
    }
    List<AttributeDefinition> getFieldAttributeLayouts() {
        return new ArrayList<>();
    }
    List<AttributeDefinition> getCodeAttributeLayouts() {
        return new ArrayList<>();
    }
}

class IcBands {
    static class IcTuple {
        CPClass C;
        CPClass C2;
        String N;
        int F;

        IcTuple(CPClass c, CPClass c2, String n, int f) {
            this.C = c;
            this.C2 = c2;
            this.N = n;
            this.F = f;
        }

        boolean isAnonymous() {
            return false;
        }
    }

    List<IcTuple> getInnerClassesForOuter(String outer) {
        return new ArrayList<>();
    }

    IcTuple getIcTuple(CPClass inner) {
        return new IcTuple(inner, null, null, 0);
    }
}

class ConstantPoolEntry {}

class CPClass extends ConstantPoolEntry {
    private final String name;
    private final int index;

    CPClass(String name, int index) {
        this.name = name;
        this.index = index;
    }

    @Override
    public String toString() {
        return name;
    }

    int getIndex() {
        return index;
    }
}

class CPNameAndType extends ConstantPoolEntry {
    private final String name;
    private final String desc;
    private final int index;

    CPNameAndType(String name, String desc, int index) {
        this.name = name;
        this.desc = desc;
        this.index = index;
    }

    int getIndex() {
        return index;
    }
}

class CPSignature extends ConstantPoolEntry {
    private final String signature;
    private final int index;

    CPSignature(String signature, int index) {
        this.signature = signature;
        this.index = index;
    }
}

class CPConstant<T> extends ConstantPoolEntry {
    private final T value;
    private final int index;

    CPConstant(T value, int index) {
        this.value = value;
        this.index = index;
    }
}

class CPUTF8 extends ConstantPoolEntry {
    private final String str;
    private final int index;

    CPUTF8(String str, int index) {
        this.str = str;
        this.index = index;
    }
}

class MetadataBandGroup {
    static final int CONTEXT_CLASS = 0;
    static final int CONTEXT_FIELD = 1;
    static final int CONTEXT_METHOD = 2;

    void pack(OutputStream out) throws IOException, Pack200Exception {}
    boolean hasContent() { return false; }
    int numBackwardsCalls() { return 0; }
}

class NewAttributeBands {
    boolean isUsedAtLeastOnce() { return false; }
    List<Integer> numBackwardsCalls() { return new ArrayList<>(); }
    void pack(OutputStream out) throws IOException, Pack200Exception {}
    String getAttributeName() { return ""; }
    int getFlagIndex() { return 0; }
}

class Pack200Exception extends Exception {
    public Pack200Exception() {}
    public Pack200Exception(String message) {
        super(message);
    }
}