package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.util.Arrays;

// Begin test class
public class EqualsBuilder_reflectionAppend_2_1_Test {

    // Define the @EqualsExclude annotation
    public @interface EqualsExclude {
    }

    // Define SubClass for TC21
    public static class SubClass extends SuperClass {
        private String subValue;

        public SubClass(String superValue, String subValue) {
            super(superValue);
            this.subValue = subValue;
        }
    }

    // Define SuperClass for TC21
    public static class SuperClass {
        private String superValue;

        public SuperClass(String superValue) {
            this.superValue = superValue;
        }
    }

    // Define CustomClass for TC22
    public static class CustomClass {
        private String value1;
        private String value2;

        public CustomClass(String value1, String value2) {
            this.value1 = value1;
            this.value2 = value2;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            CustomClass that = (CustomClass) obj;
            return value1.equals(that.value1) && value2.equals(that.value2);
        }
    }

    // Define ExcludedFieldClass for TC23
    public static class ExcludedFieldClass {
        private String includedField;
        @EqualsExclude
        private String excludedField;

        public ExcludedFieldClass(String includedField, String excludedField) {
            this.includedField = includedField;
            this.excludedField = excludedField;
        }
    }

    // Define SimpleClass for TC24
    public static class SimpleClass {
        private String value;

        public SimpleClass(String value) {
            this.value = value;
        }
    }

    @Test
    @DisplayName("Sets isEquals to false when classes of lhs and rhs are related but reflectionAppend processes superclass fields resulting in unequal fields")
    public void TC21_reflectionAppend_superclassFieldsUnequal() {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        SubClass lhs = new SubClass("superValue1", "subValue");
        SubClass rhs = new SubClass("superValue2", "subValue");

        // WHEN
        builder.reflectionAppend(lhs, rhs);

        // THEN
        Assertions.assertFalse(builder.isEquals(), "isEquals should be false due to unequal superclass fields");
    }

    @Test
    @DisplayName("Sets isEquals based on equals method when bypassReflectionClasses contains lhs class")
    public void TC22_reflectionAppend_bypassReflectionUsesEquals() {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        builder.setBypassReflectionClasses(Arrays.asList(CustomClass.class));
        CustomClass lhs = new CustomClass("value1", "value2");
        CustomClass rhs = new CustomClass("value1", "value2");

        // WHEN
        builder.reflectionAppend(lhs, rhs);

        // THEN
        Assertions.assertTrue(builder.isEquals(), "isEquals should be true based on equals method");
    }

    @Test
    @DisplayName("Sets isEquals to false when reflectionAppend processes fields with @EqualsExclude annotation resulting in unequal compared fields")
    public void TC23_reflectionAppend_excludedFieldsUnequal() {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        ExcludedFieldClass lhs = new ExcludedFieldClass("value1", "excludedValue1");
        ExcludedFieldClass rhs = new ExcludedFieldClass("value2", "excludedValue2");

        // WHEN
        builder.reflectionAppend(lhs, rhs);

        // THEN
        Assertions.assertFalse(builder.isEquals(), "isEquals should be false due to unequal non-excluded fields");
    }

    @Test
    @DisplayName("Handles reflectionAppend when testClass is null, ensuring no reflection is performed and isEquals remains true")
    public void TC24_reflectionAppend_reflectUpToObjectClass() {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        builder.setReflectUpToClass(Object.class);
        SimpleClass lhs = new SimpleClass("value1");
        SimpleClass rhs = new SimpleClass("value1");

        // WHEN
        builder.reflectionAppend(lhs, rhs);

        // THEN
        Assertions.assertTrue(builder.isEquals(), "isEquals should remain true as no reflection is performed");
    }

}