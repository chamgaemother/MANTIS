package org.jfree.chart.plot;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.util.ObjectUtils;
import org.jfree.chart.util.SerialUtils;

import java.lang.reflect.Field;
import java.util.List;

/**
 * JUnit 5 test class for testing the clone() method of CombinedDomainXYPlot.
 */
public class XYPlot_clone_2_1_Test {

    /**
     * Test cloning of CombinedDomainXYPlot with subplots having their own domain axes set.
     * Ensures that cloned subplots are deep copies with separate domain axes configured independently.
     */
    @Test
    @DisplayName("Cloning CombinedDomainXYPlot with subplots having their own domain axes set")
    public void testCloningWithSubplotsHavingOwnDomainAxes() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
        // GIVEN: Original CombinedDomainXYPlot with multiple subplots, each having their own domain axis
        CombinedDomainXYPlot originalPlot = new CombinedDomainXYPlot();

        // Create first subplot with its own domain axis
        XYPlot subplot1 = new XYPlot();
        ValueAxis subplot1DomainAxis = new NumberAxis("Subplot1 Domain");
        subplot1.setDomainAxis(subplot1DomainAxis);
        originalPlot.add(subplot1);

        // Create second subplot with its own domain axis
        XYPlot subplot2 = new XYPlot();
        ValueAxis subplot2DomainAxis = new NumberAxis("Subplot2 Domain");
        subplot2.setDomainAxis(subplot2DomainAxis);
        originalPlot.add(subplot2);

        // Set the original plot's domain axis
        ValueAxis originalDomainAxis = new NumberAxis("Original Domain");
        originalPlot.setDomainAxis(originalDomainAxis);

        // WHEN: Cloning the original plot
        CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) originalPlot.clone();

        // THEN: Verify that the cloned plot is a different instance
        assertNotSame(clonedPlot, originalPlot, "Cloned plot should be a different instance");

        // Access the 'subplots' field of the cloned plot via reflection
        Field subplotsField = CombinedDomainXYPlot.class.getDeclaredField("subplots");
        subplotsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<XYPlot> clonedSubplots = (List<XYPlot>) subplotsField.get(clonedPlot);

        // Verify that the cloned plot has the same number of subplots
        assertEquals(2, clonedSubplots.size(), "Cloned plot should have two subplots");

        // Retrieve cloned subplots
        XYPlot clonedSubplot1 = clonedSubplots.get(0);
        XYPlot clonedSubplot2 = clonedSubplots.get(1);

        // Verify that cloned subplots are different instances from the original subplots
        assertNotSame(clonedSubplot1, subplot1, "Cloned subplot1 should be a different instance");
        assertNotSame(clonedSubplot2, subplot2, "Cloned subplot2 should be a different instance");

        // Access the 'domainAxes' field of the cloned plot via reflection
        Field domainAxesField = CombinedDomainXYPlot.class.getDeclaredField("domainAxes");
        domainAxesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        java.util.Map<Integer, ValueAxis> clonedDomainAxes = (java.util.Map<Integer, ValueAxis>) domainAxesField.get(clonedPlot);

        // Assuming subplots are mapped to indices 1 and 2 respectively
        ValueAxis clonedSubplot1DomainAxis = clonedDomainAxes.get(1);
        ValueAxis clonedSubplot2DomainAxis = clonedDomainAxes.get(2);

        // Verify that the domain axes of the cloned subplots are different instances
        assertNotSame(clonedSubplot1DomainAxis, subplot1DomainAxis, "Cloned subplot1's domainAxis should be a different instance");
        assertNotSame(clonedSubplot2DomainAxis, subplot2DomainAxis, "Cloned subplot2's domainAxis should be a different instance");

        // Verify that the domain axes of the cloned subplots are configured
        assertTrue(clonedSubplot1DomainAxis.isAutoRange(), "Cloned subplot1's domainAxis should be configured");
        assertTrue(clonedSubplot2DomainAxis.isAutoRange(), "Cloned subplot2's domainAxis should be configured");

        // Verify that the parent of cloned subplots is the cloned plot
        assertEquals(clonedPlot, clonedSubplot1.getParent(), "Cloned subplot1's parent should be the cloned plot");
        assertEquals(clonedPlot, clonedSubplot2.getParent(), "Cloned subplot2's parent should be the cloned plot");
    }

    /**
     * Test cloning of CombinedDomainXYPlot with a large number of subplots to ensure proper loop handling.
     * Ensures that all subplots are cloned correctly without performance degradation.
     */
    @Test
    @DisplayName("Cloning CombinedDomainXYPlot with a large number of subplots to test loop handling")
    public void testCloningWithLargeNumberOfSubplots() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
        // GIVEN: Original CombinedDomainXYPlot with 100 subplots
        CombinedDomainXYPlot originalPlot = new CombinedDomainXYPlot();

        int numberOfSubplots = 100;
        for (int i = 0; i < numberOfSubplots; i++) {
            XYPlot subplot = new XYPlot();
            ValueAxis subplotDomainAxis = new NumberAxis("Subplot" + i + " Domain");
            subplot.setDomainAxis(subplotDomainAxis);
            originalPlot.add(subplot);
        }

        // Set the original plot's domain axis
        ValueAxis originalDomainAxis = new NumberAxis("Original Domain");
        originalPlot.setDomainAxis(originalDomainAxis);

        // WHEN: Cloning the original plot
        CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) originalPlot.clone();

        // THEN: Verify that the cloned plot is a different instance
        assertNotSame(clonedPlot, originalPlot, "Cloned plot should be a different instance");

        // Access the 'subplots' field of the cloned plot via reflection
        Field subplotsField = CombinedDomainXYPlot.class.getDeclaredField("subplots");
        subplotsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<XYPlot> clonedSubplots = (List<XYPlot>) subplotsField.get(clonedPlot);

        // Verify that the cloned plot has the same number of subplots
        assertEquals(numberOfSubplots, clonedSubplots.size(), "Cloned plot should have the same number of subplots");

        // Iterate through each subplot to verify deep cloning
        for (int i = 0; i < numberOfSubplots; i++) {
            XYPlot originalSubplot = originalPlot.getSubplots().get(i);
            XYPlot clonedSubplot = clonedSubplots.get(i);

            // Verify that each cloned subplot is a different instance
            assertNotSame(clonedSubplot, originalSubplot, "Each cloned subplot should be a different instance");

            // Access the 'domainAxes' field of the cloned plot via reflection
            Field domainAxesField = CombinedDomainXYPlot.class.getDeclaredField("domainAxes");
            domainAxesField.setAccessible(true);
            @SuppressWarnings("unchecked")
            java.util.Map<Integer, ValueAxis> clonedDomainAxes = (java.util.Map<Integer, ValueAxis>) domainAxesField.get(clonedPlot);

            // Assuming subplots are mapped to indices 1 to 100
            ValueAxis clonedSubplotDomainAxis = clonedDomainAxes.get(i + 1);

            // Verify that the domain axis of the cloned subplot is a different instance
            assertNotSame(clonedSubplotDomainAxis, originalSubplot.getDomainAxis(), "Cloned subplot's domainAxis should be a different instance");

            // Verify that the domain axis of the cloned subplot is configured
            assertTrue(clonedSubplotDomainAxis.isAutoRange(), "Cloned subplot's domainAxis should be configured");

            // Verify that the parent of the cloned subplot is the cloned plot
            assertEquals(clonedPlot, clonedSubplot.getParent(), "Cloned subplot's parent should be the cloned plot");
        }

        // Additionally, verify that the original plot has subplots with correct parent
        for (int i = 0; i < numberOfSubplots; i++) {
            XYPlot originalSubplot = originalPlot.getSubplots().get(i);
            assertEquals(originalPlot, originalSubplot.getParent(), "Original subplot's parent should be the original plot");
        }
    }
}