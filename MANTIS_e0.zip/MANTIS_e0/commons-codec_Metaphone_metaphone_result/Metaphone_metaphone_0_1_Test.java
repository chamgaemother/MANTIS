package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_1_Test {

    @Test
    @DisplayName("metaphone(null) returns empty string")
    void TC01_metaphone_null_input() {
        // Given
        String txt = null;
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("", result);
    }

    @Test
    @DisplayName("metaphone(\"\") returns empty string")
    void TC02_metaphone_empty_string() {
        // Given
        String txt = "";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("", result);
    }

    @Test
    @DisplayName("metaphone single vowel character returns uppercase vowel")
    void TC03_metaphone_single_vowel() {
        // Given
        String txt = "a";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("A", result);
    }

    @Test
    @DisplayName("metaphone single consonant character returns uppercase consonant")
    void TC04_metaphone_single_consonant() {
        // Given
        String txt = "b";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("B", result);
    }

    @Test
    @DisplayName("metaphone word starting with 'KN' removes initial 'K'")
    void TC05_metaphone_KN_prefix() {
        // Given
        String txt = "knight";
        Metaphone metaphone = new Metaphone();
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("NT", result);
    }
}
