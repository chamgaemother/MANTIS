import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class ClassBandsTest {

    private ClassBands classBands;
    private List<ConstantPoolEntry> mockClassSourceFile;
    private List<ConstantPoolEntry> mockClassEnclosingMethodClass;
    private List<ConstantPoolEntry> mockClassEnclosingMethodDesc;
    private List<CPSignature> mockClassSignature;
    private List<CPClass> mockClassThis;
    private List<CPClass[]> mockClassInterface;
    private List<Integer> mockMajorVersions;
    private List<Long> mockClassFlags;
    private List<CPNameAndType> mockTempFieldDesc;
    private List<Long> mockTempFieldFlags;
    private List<CPNameAndType> mockTempMethodDesc;
    private List<Long> mockTempMethodFlags;
    private Segment mockSegment;
    private CpBands mockCpBands;
    private Segment.SegmentMethodVisitor mockSegmentMethodVisitor;
    private AttributeDefinitionBands mockAttrBands;

    @BeforeEach
    void setup() throws IOException {
        mockSegment = Mockito.mock(Segment.class);
        mockCpBands = Mockito.mock(CpBands.class);
        mockAttrBands = Mockito.mock(AttributeDefinitionBands.class);
        mockSegmentMethodVisitor = Mockito.mock(Segment.SegmentMethodVisitor.class);
        
        when(mockSegment.getCpBands()).thenReturn(mockCpBands);
        when(mockSegment.getAttrBands()).thenReturn(mockAttrBands);
        classBands = new ClassBands(mockSegment, 1, 5, false);

        mockClassSourceFile = Mockito.spy(new ArrayList<>());
        mockClassEnclosingMethodClass = Mockito.spy(new ArrayList<>());
        mockClassEnclosingMethodDesc = Mockito.spy(new ArrayList<>());
        mockClassSignature = Mockito.spy(new ArrayList<>());
        mockClassThis = Mockito.spy(new ArrayList<>());
        mockClassInterface = Mockito.spy(new ArrayList<>());
        mockMajorVersions = Mockito.spy(new ArrayList<>());
        mockClassFlags = Mockito.spy(new ArrayList<>());
        mockTempFieldDesc = Mockito.spy(new ArrayList<>());
        mockTempFieldFlags = Mockito.spy(new ArrayList<>());
        mockTempMethodDesc = Mockito.spy(new ArrayList<>());
        mockTempMethodFlags = Mockito.spy(new ArrayList<>());

        classBands.classSourceFile = mockClassSourceFile;
        classBands.classEnclosingMethodClass = mockClassEnclosingMethodClass;
        classBands.classEnclosingMethodDesc = mockClassEnclosingMethodDesc;
        classBands.classSignature = mockClassSignature;
        classBands.class_this = new CPClass[1];
        classBands.class_interface_count = new int[1];
        classBands.class_interface = new CPClass[1][];
        classBands.major_versions = new int[1];
        classBands.class_flags = new long[1];
        classBands.tempFieldDesc = mockTempFieldDesc;
        classBands.tempFieldFlags = mockTempFieldFlags;
        classBands.tempMethodDesc = mockTempMethodDesc;
        classBands.tempMethodFlags = mockTempMethodFlags;

        classBands.index = 0;
    }
    
    @Test
    void testRemoveCurrentClassWithoutFlagsSet() {
        classBands.class_flags[0] = 0;
        classBands.removeCurrentClass();

        assertEquals(0, classBands.index);
        assertEquals(0, classBands.classSourceFile.size());
        assertEquals(0, classBands.classEnclosingMethodClass.size());
        assertEquals(0, classBands.classEnclosingMethodDesc.size());
        assertEquals(0, classBands.classSignature.size());
        assertEquals(0, classBands.tempFieldDesc.size());
        assertEquals(0, classBands.tempFieldFlags.size());
        assertEquals(0, classBands.tempMethodDesc.size());
        assertEquals(0, classBands.tempMethodFlags.size());
    }
    
    @Test
    void testRemoveCurrentClassWithSourceFileFlag() {
        classBands.class_flags[0] = 1 << 17;
        classBands.classSourceFile.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.removeCurrentClass();
        
        assertEquals(0, classBands.classSourceFile.size());
    }
    
    @Test
    void testRemoveCurrentClassWithEnclosingMethodFlag() {
        classBands.class_flags[0] = 1 << 18;
        classBands.classEnclosingMethodClass.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.classEnclosingMethodDesc.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.removeCurrentClass();
        
        assertEquals(0, classBands.classEnclosingMethodClass.size());
        assertEquals(0, classBands.classEnclosingMethodDesc.size());
    }
    
    @Test
    void testRemoveCurrentClassWithSignatureFlag() {
        classBands.class_flags[0] = 1 << 19;
        classBands.classSignature.add(Mockito.mock(CPSignature.class));
        classBands.removeCurrentClass();
        
        assertEquals(0, classBands.classSignature.size());
    }
    
    @Test
    void testRemoveCurrentClassWithFieldAnnotations() {
        classBands.tempFieldFlags.add(1L << 19 | 1L << 17 | 1L << 21 | 1L << 22);
        classBands.fieldSignature.add(Mockito.mock(CPSignature.class));
        classBands.fieldConstantValueKQ.add(Mockito.mock(CPConstant.class));
        classBands.field_RVA_bands.addAnnotation("", new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
        classBands.field_RIA_bands.addAnnotation("", new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
        classBands.removeCurrentClass();
        
        assertEquals(0, classBands.fieldSignature.size());
        assertEquals(0, classBands.fieldConstantValueKQ.size());
        assertFalse(classBands.field_RVA_bands.hasContent());
        assertFalse(classBands.field_RIA_bands.hasContent());
    }

    @Test
    void testRemoveCurrentClassWithMethodAnnotations() {
        classBands.tempMethodFlags.add(1L << 19 | 1L << 18 | 1L << 17 | 1L << 21 | 1L << 22 | 1L << 23 | 1L << 24 | 1L << 25);
        classBands.methodSignature.add(Mockito.mock(CPSignature.class));
        classBands.methodExceptionNumber.add(1);
        classBands.methodExceptionClasses.add(Mockito.mock(CPClass.class));
        classBands.codeFlags.add(1L << 2 | 1L << 3 | 1L);
        classBands.codeMaxLocals.add(1);
        classBands.codeMaxStack.add(1);
        classBands.codeHandlerCount.add(1);
        classBands.codeHandlerStartP.add(1);
        classBands.codeHandlerEndPO.add(1);
        classBands.codeHandlerCatchPO.add(1);
        classBands.codeHandlerClass.add(Mockito.mock(CPClass.class));
        classBands.removeCurrentClass();
        
        assertEquals(0, classBands.methodSignature.size());
        assertEquals(0, classBands.methodExceptionNumber.size());
        assertEquals(0, classBands.methodExceptionClasses.size());
        assertEquals(0, classBands.codeFlags.size());
        assertEquals(0, classBands.codeMaxLocals.size());
        assertEquals(0, classBands.codeMaxStack.size());
        assertEquals(0, classBands.codeHandlerCount.size());
        assertEquals(0, classBands.codeHandlerStartP.size());
        assertEquals(0, classBands.codeHandlerEndPO.size());
        assertEquals(0, classBands.codeHandlerCatchPO.size());
        assertEquals(0, classBands.codeHandlerClass.size());
    }
}