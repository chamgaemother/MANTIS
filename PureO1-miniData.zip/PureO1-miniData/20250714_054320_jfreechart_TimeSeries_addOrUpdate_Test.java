import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesDataItem;
import org.jfree.data.general.SeriesException;

public class TimeSeriesTest {

    private TimeSeries timeSeries;

    @BeforeEach
    public void setUp() {
        timeSeries = new TimeSeries("Test Series");
    }

    @Test
    public void testAddOrUpdate_NullItem() {
        assertThrows(IllegalArgumentException.class, () -> {
            timeSeries.addOrUpdate(null);
        });
    }

    @Test
    public void testAddOrUpdate_FirstItem() {
        RegularTimePeriod period = new Day(1, 1, 2020);
        TimeSeriesDataItem item = new TimeSeriesDataItem(period, 100.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(item);
        
        assertNull(overwritten);
        assertEquals(1, timeSeries.getItemCount());
        assertEquals(100.0, timeSeries.getMinY());
        assertEquals(100.0, timeSeries.getMaxY());
        assertEquals(Day.class, timeSeries.getTimePeriodClass());
    }

    @Test
    public void testAddOrUpdate_DifferentPeriodClass() {
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        RegularTimePeriod period2 = new org.jfree.data.time.Month(1, 2020);
        TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 200.0);
        
        assertThrows(SeriesException.class, () -> {
            timeSeries.addOrUpdate(item2);
        });
    }

    @Test
    public void testAddOrUpdate_UpdateExistingItem_ValueNull() {
        RegularTimePeriod period = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period, 100.0);
        timeSeries.addOrUpdate(item1);
        
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period, null);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertNull(timeSeries.getValue(0));
        assertTrue(Double.isNaN(timeSeries.getMinY()));
        assertTrue(Double.isNaN(timeSeries.getMaxY()));
    }

    @Test
    public void testAddOrUpdate_UpdateExistingItem_OldYNaN() {
        RegularTimePeriod period = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period, Double.NaN);
        timeSeries.addOrUpdate(item1);
        
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period, 150.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertEquals(150.0, timeSeries.getValue(0).doubleValue());
        assertEquals(150.0, timeSeries.getMinY());
        assertEquals(150.0, timeSeries.getMaxY());
    }

    @Test
    public void testAddOrUpdate_UpdateExistingItem_IterateTrue_MinY() {
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        RegularTimePeriod period2 = new Day(2, 1, 2020);
        TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 200.0);
        timeSeries.addOrUpdate(item2);
        
        // minY is 100.0, maxY is 200.0
        // Update period1's value to 300.0 which is >= maxY, should trigger iterate
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period1, 300.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertEquals(300.0, timeSeries.getValue(0).doubleValue());
        assertEquals(200.0, timeSeries.getMaxY());
        assertEquals(200.0, timeSeries.getMinY());
    }

    @Test
    public void testAddOrUpdate_UpdateExistingItem_IterateTrue_MaxY() {
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        RegularTimePeriod period2 = new Day(2, 1, 2020);
        TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 200.0);
        timeSeries.addOrUpdate(item2);
        
        // Update period2's value to 50.0 which is <= minY, should trigger iterate
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period2, 50.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertEquals(50.0, timeSeries.getValue(1).doubleValue());
        assertEquals(100.0, timeSeries.getMaxY());
        assertEquals(50.0, timeSeries.getMinY());
    }

    @Test
    public void testAddOrUpdate_UpdateExistingItem_IterateFalse_ValueNull() {
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period1, null);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertNull(timeSeries.getValue(0));
        assertTrue(Double.isNaN(timeSeries.getMinY()));
        assertTrue(Double.isNaN(timeSeries.getMaxY()));
    }

    @Test
    public void testAddOrUpdate_UpdateExistingItem_IterateFalse_ValueNotNull() {
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period1, 150.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertEquals(150.0, timeSeries.getValue(0).doubleValue());
        assertEquals(150.0, timeSeries.getMinY());
        assertEquals(150.0, timeSeries.getMaxY());
    }

    @Test
    public void testAddOrUpdate_AddNewItem_NoRemoval() {
        timeSeries.setMaximumItemCount(5);
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        RegularTimePeriod period2 = new Day(2, 1, 2020);
        TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 200.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(item2);
        
        assertNull(overwritten);
        assertEquals(2, timeSeries.getItemCount());
        assertEquals(100.0, timeSeries.getMinY());
        assertEquals(200.0, timeSeries.getMaxY());
    }

    @Test
    public void testAddOrUpdate_AddNewItem_WithRemoval() {
        timeSeries.setMaximumItemCount(2);
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        RegularTimePeriod period2 = new Day(2, 1, 2020);
        TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 200.0);
        timeSeries.addOrUpdate(item2);
        
        RegularTimePeriod period3 = new Day(3, 1, 2020);
        TimeSeriesDataItem item3 = new TimeSeriesDataItem(period3, 300.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(item3);
        
        assertNull(overwritten);
        assertEquals(2, timeSeries.getItemCount());
        assertEquals(200.0, timeSeries.getMinY());
        assertEquals(300.0, timeSeries.getMaxY());
        assertNull(timeSeries.getValue(0)); // period1 was removed
    }

    @Test
    public void testAddOrUpdate_AddNewItem_FirstInsertion() {
        RegularTimePeriod period = new Day(15, 3, 2021);
        TimeSeriesDataItem item = new TimeSeriesDataItem(period, 250.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(item);
        
        assertNull(overwritten);
        assertEquals(1, timeSeries.getItemCount());
        assertEquals(250.0, timeSeries.getMinY());
        assertEquals(250.0, timeSeries.getMaxY());
        assertEquals(period, timeSeries.getTimePeriod(0));
    }

    @Test
    public void testAddOrUpdate_AddOrUpdateMultipleItems() {
        timeSeries.setMaximumItemCount(3);
        RegularTimePeriod period1 = new Day(1, 1, 2021);
        RegularTimePeriod period2 = new Day(2, 1, 2021);
        RegularTimePeriod period3 = new Day(3, 1, 2021);
        RegularTimePeriod period4 = new Day(4, 1, 2021);
        
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 200.0);
        TimeSeriesDataItem item3 = new TimeSeriesDataItem(period3, 300.0);
        
        timeSeries.addOrUpdate(item1);
        timeSeries.addOrUpdate(item2);
        timeSeries.addOrUpdate(item3);
        
        assertEquals(3, timeSeries.getItemCount());
        assertEquals(100.0, timeSeries.getMinY());
        assertEquals(300.0, timeSeries.getMaxY());
        
        TimeSeriesDataItem item4 = new TimeSeriesDataItem(period4, 400.0);
        timeSeries.addOrUpdate(item4);
        
        assertEquals(3, timeSeries.getItemCount());
        assertEquals(200.0, timeSeries.getMinY());
        assertEquals(400.0, timeSeries.getMaxY());
        assertNull(timeSeries.getValue(0)); // period1 removed
    }

    @Test
    public void testAddOrUpdate_UpdateWithSameValue() {
        RegularTimePeriod period = new Day(10, 5, 2020);
        TimeSeriesDataItem item = new TimeSeriesDataItem(period, 500.0);
        timeSeries.addOrUpdate(item);
        
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period, 500.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertEquals(500.0, timeSeries.getValue(0).doubleValue());
        assertEquals(500.0, timeSeries.getMinY());
        assertEquals(500.0, timeSeries.getMaxY());
    }

    @Test
    public void testAddOrUpdate_UpdateExistingItem_OldValueEqualsMinMax() {
        RegularTimePeriod period1 = new Day(1, 1, 2020);
        TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 100.0);
        timeSeries.addOrUpdate(item1);
        
        RegularTimePeriod period2 = new Day(2, 1, 2020);
        TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 200.0);
        timeSeries.addOrUpdate(item2);
        
        // Update period1's value to 200.0 which is equal to current maxY
        TimeSeriesDataItem updateItem = new TimeSeriesDataItem(period1, 200.0);
        TimeSeriesDataItem overwritten = timeSeries.addOrUpdate(updateItem);
        
        assertNotNull(overwritten);
        assertEquals(200.0, timeSeries.getValue(0).doubleValue());
        assertEquals(200.0, timeSeries.getMinY());
        assertEquals(200.0, timeSeries.getMaxY());
    }

}