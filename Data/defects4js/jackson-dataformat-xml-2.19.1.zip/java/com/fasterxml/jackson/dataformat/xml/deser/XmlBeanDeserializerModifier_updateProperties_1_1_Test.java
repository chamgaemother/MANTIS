package com.fasterxml.jackson.dataformat.xml.deser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil;

public class XmlBeanDeserializerModifier_updateProperties_1_1_Test {
    
    @Test
    @DisplayName("Handles property where r5 is not null and z1 is false, leading to property renaming")
    void TC11_propertyRenamingWhenZ1False() throws Exception {
        // GIVEN
        // Mock DeserializationConfig and AnnotationIntrospector
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector introspector = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(introspector);
        
        // Mock BeanDescription
        BeanDescription beanDesc = mock(BeanDescription.class);
        
        // Create BeanPropertyDefinition with non-null primary member and isText annotation false
        BeanPropertyDefinition propDef = mock(BeanPropertyDefinition.class);
        AnnotatedMember primaryMember = mock(AnnotatedMember.class);
        when(propDef.getPrimaryMember()).thenReturn(primaryMember);
        when(AnnotationUtil.findIsTextAnnotation(config, introspector, primaryMember)).thenReturn(Boolean.FALSE);
        
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(propDef);
        
        // Instantiate XmlBeanDeserializerModifier with _cfgNameForTextValue
        String cfgNameForTextValue = "renamedProperty";
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier(cfgNameForTextValue);
        
        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);
        
        // THEN
        // Verify that the property is renamed using _cfgNameForTextValue
        BeanPropertyDefinition renamedPropDef = result.get(0);
        verify(propDef).withSimpleName(cfgNameForTextValue);
    }
    
    @Test
    @DisplayName("Handles property where r5 is not null and z1 is true, skipping property renaming")
    void TC12_propertyRenamingWhenZ1True() throws Exception {
        // GIVEN
        // Mock DeserializationConfig and AnnotationIntrospector
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector introspector = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(introspector);
        
        // Mock BeanDescription
        BeanDescription beanDesc = mock(BeanDescription.class);
        
        // Create BeanPropertyDefinition with non-null primary member, isText annotation false, and z1 true
        BeanPropertyDefinition propDef = mock(BeanPropertyDefinition.class);
        AnnotatedMember primaryMember = mock(AnnotatedMember.class);
        when(propDef.getPrimaryMember()).thenReturn(primaryMember);
        when(AnnotationUtil.findIsTextAnnotation(config, introspector, primaryMember)).thenReturn(Boolean.TRUE);
        
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(propDef);
        
        // Instantiate XmlBeanDeserializerModifier with _cfgNameForTextValue
        String cfgNameForTextValue = "renamedProperty";
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier(cfgNameForTextValue);
        
        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);
        
        // THEN
        // Verify that the property name remains unchanged
        verify(propDef, never()).withSimpleName(anyString());
    }
    
    @Test
    @DisplayName("Handles property where r11 is null, proceeding to check simple name")
    void TC13_propertyWithNullWrapperName() throws Exception {
        // GIVEN
        // Mock DeserializationConfig and AnnotationIntrospector
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector introspector = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(introspector);
        
        // Mock BeanDescription
        BeanDescription beanDesc = mock(BeanDescription.class);
        
        // Create BeanPropertyDefinition with wrapperName null
        BeanPropertyDefinition propDef = mock(BeanPropertyDefinition.class);
        AnnotatedMember primaryMember = mock(AnnotatedMember.class);
        when(propDef.getPrimaryMember()).thenReturn(primaryMember);
        when(AnnotationUtil.findIsTextAnnotation(config, introspector, primaryMember)).thenReturn(null);
        when(propDef.getWrapperName()).thenReturn(null);
        
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(propDef);
        
        // Instantiate XmlBeanDeserializerModifier with _cfgNameForTextValue
        String cfgNameForTextValue = "renamedProperty";
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier(cfgNameForTextValue);
        
        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);
        
        // THEN
        // Verify that no renaming occurs
        verify(propDef, never()).withSimpleName(anyString());
    }
    
    @Test
    @DisplayName("Handles property where wrapperName simple name equals property name, without renaming")
    void TC14_wrapperNameEqualsPropertyName() throws Exception {
        // GIVEN
        // Mock DeserializationConfig and AnnotationIntrospector
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector introspector = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(introspector);
        
        // Mock BeanDescription
        BeanDescription beanDesc = mock(BeanDescription.class);
        
        // Create BeanPropertyDefinition with wrapperName's simple name equal to property name
        BeanPropertyDefinition propDef = mock(BeanPropertyDefinition.class);
        AnnotatedMember primaryMember = mock(AnnotatedMember.class);
        when(propDef.getPrimaryMember()).thenReturn(primaryMember);
        when(AnnotationUtil.findIsTextAnnotation(config, introspector, primaryMember)).thenReturn(null);
        PropertyName wrapperName = mock(PropertyName.class);
        when(wrapperName.getSimpleName()).thenReturn("propertyName");
        when(propDef.getWrapperName()).thenReturn(wrapperName);
        when(propDef.getName()).thenReturn("propertyName");
        
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(propDef);
        
        // Instantiate XmlBeanDeserializerModifier with _cfgNameForTextValue
        String cfgNameForTextValue = "renamedProperty";
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier(cfgNameForTextValue);
        
        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);
        
        // THEN
        // Verify that no renaming occurs
        verify(propDef, never()).withSimpleName(anyString());
    }
    
    @Test
    @DisplayName("Handles property where wrapperName simple name differs from property name, triggering renaming")
    void TC15_wrapperNameDifferentFromPropertyName() throws Exception {
        // GIVEN
        // Mock DeserializationConfig and AnnotationIntrospector
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector introspector = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(introspector);
        
        // Mock BeanDescription
        BeanDescription beanDesc = mock(BeanDescription.class);
        
        // Create BeanPropertyDefinition with wrapperName's simple name different from property name
        BeanPropertyDefinition propDef = mock(BeanPropertyDefinition.class);
        AnnotatedMember primaryMember = mock(AnnotatedMember.class);
        when(propDef.getPrimaryMember()).thenReturn(primaryMember);
        when(AnnotationUtil.findIsTextAnnotation(config, introspector, primaryMember)).thenReturn(null);
        PropertyName wrapperName = mock(PropertyName.class);
        when(wrapperName.getSimpleName()).thenReturn("differentName");
        when(propDef.getWrapperName()).thenReturn(wrapperName);
        when(propDef.getName()).thenReturn("originalName");
        
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        propDefs.add(propDef);
        
        // Instantiate XmlBeanDeserializerModifier with _cfgNameForTextValue
        String cfgNameForTextValue = "renamedProperty";
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier(cfgNameForTextValue);
        
        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);
        
        // THEN
        // Verify that the property is renamed to wrapperName's simple name
        verify(propDef).withSimpleName("differentName");
    }
}