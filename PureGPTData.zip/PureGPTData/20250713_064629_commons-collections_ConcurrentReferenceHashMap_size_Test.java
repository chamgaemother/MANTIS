import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConcurrentReferenceHashMapTest {

    private ConcurrentReferenceHashMap<String, String> map;

    @BeforeEach
    public void setUp() {
        map = new ConcurrentReferenceHashMap<>();
    }

    @Test
    public void testSizeEmptyMap() {
        assertEquals(0, map.size());
    }

    @Test
    public void testSizeSingleElement() {
        map.put("key1", "value1");
        assertEquals(1, map.size());
    }

    @Test
    public void testSizeMultipleElements() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertEquals(3, map.size());
    }

    @Test
    public void testSizeAfterRemovingElement() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.remove("key1");
        assertEquals(1, map.size());
    }

    @Test
    public void testSizeAfterClearingMap() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.clear();
        assertEquals(0, map.size());
    }

    @Test
    public void testSizeWithConcurrentModifications() {
        // Prepare segments by adding elements
        for (int i = 0; i < 100; i++) {
            map.put("key" + i, "value" + i);
        }
        // Concurrent modification simulation by removing elements
        for (int i = 0; i < 50; i++) {
            map.remove("key" + i);
        }
        assertEquals(50, map.size());
    }

    @Test
    public void testBoundaryLargeElements() {
        for (int i = 0; i < Integer.MAX_VALUE / 1000; i++) {
            map.put("key" + i, "value" + i);
        }
        // Map cannot really reach Integer.MAX_VALUE in size due to memory constraints
        assertEquals(Integer.MAX_VALUE, map.size());
    }
}