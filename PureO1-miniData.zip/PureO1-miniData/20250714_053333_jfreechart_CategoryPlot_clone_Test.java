import static org.junit.jupiter.api.Assertions.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Stroke;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryMarker;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.util.ObjectUtils;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.Test;

public class CategoryPlotTest {

    @Test
    public void testCloneDefault() throws CloneNotSupportedException {
        CategoryPlot original = new CategoryPlot();
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertEquals(original.getOrientation(), clone.getOrientation());
        assertEquals(original.getAxisOffset(), clone.getAxisOffset());
        assertEquals(original.getDomainAxes(), clone.getDomainAxes());
        assertEquals(original.getRangeAxes(), clone.getRangeAxes());
        assertEquals(original.getDatasetRenderingOrder(), clone.getDatasetRenderingOrder());
        assertEquals(original.getColumnRenderingOrder(), clone.getColumnRenderingOrder());
        assertEquals(original.getRowRenderingOrder(), clone.getRowRenderingOrder());
        assertEquals(original.isDomainGridlinesVisible(), clone.isDomainGridlinesVisible());
        assertEquals(original.isRangeGridlinesVisible(), clone.isRangeGridlinesVisible());
        assertFalse(clone.isRangeZeroBaselineVisible());
        assertFalse(clone.isRangeMinorGridlinesVisible());
        assertEquals(original.getAnchorValue(), clone.getAnchorValue());
        assertFalse(clone.isRangeCrosshairVisible());
        assertFalse(clone.isDomainCrosshairVisible());
        assertFalse(clone.isRangeCrosshairLockedOnData());
        assertEquals(original.getWeight(), clone.getWeight());
        assertNull(clone.getFixedDomainAxisSpace());
        assertNull(clone.getFixedRangeAxisSpace());
        assertNull(clone.getFixedLegendItems());
        assertFalse(clone.isRangePannable());
        assertNull(clone.getShadowGenerator());
        assertTrue(clone.getAnnotations().isEmpty());
        assertTrue(clone.getForegroundDomainMarkers().isEmpty());
        assertTrue(clone.getBackgroundDomainMarkers().isEmpty());
        assertTrue(clone.getForegroundRangeMarkers().isEmpty());
        assertTrue(clone.getBackgroundRangeMarkers().isEmpty());
    }

    @Test
    public void testCloneWithNonNullAxes() throws CloneNotSupportedException {
        CategoryAxis domainAxis = new CategoryAxis("Domain");
        ValueAxis rangeAxis = new org.jfree.chart.axis.NumberAxis("Range");
        CategoryPlot original = new CategoryPlot(null, domainAxis, rangeAxis, null);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getDomainAxis(), clone.getDomainAxis());
        assertNotSame(original.getRangeAxis(), clone.getRangeAxis());
        assertEquals(original.getDomainAxis().getLabel(), clone.getDomainAxis().getLabel());
        assertEquals(original.getRangeAxis().getLabel(), clone.getRangeAxis().getLabel());
    }

    @Test
    public void testCloneWithMultipleAxes() throws CloneNotSupportedException {
        CategoryAxis domainAxis1 = new CategoryAxis("Domain1");
        CategoryAxis domainAxis2 = new CategoryAxis("Domain2");
        ValueAxis rangeAxis1 = new org.jfree.chart.axis.NumberAxis("Range1");
        ValueAxis rangeAxis2 = new org.jfree.chart.axis.NumberAxis("Range2");
        CategoryPlot original = new CategoryPlot();
        original.setDomainAxis(0, domainAxis1);
        original.setDomainAxis(1, domainAxis2);
        original.setRangeAxis(0, rangeAxis1);
        original.setRangeAxis(1, rangeAxis2);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getDomainAxis(0), clone.getDomainAxis(0));
        assertNotSame(original.getDomainAxis(1), clone.getDomainAxis(1));
        assertNotSame(original.getRangeAxis(0), clone.getRangeAxis(0));
        assertNotSame(original.getRangeAxis(1), clone.getRangeAxis(1));
        assertEquals(original.getDomainAxis(0).getLabel(), clone.getDomainAxis(0).getLabel());
        assertEquals(original.getDomainAxis(1).getLabel(), clone.getDomainAxis(1).getLabel());
        assertEquals(original.getRangeAxis(0).getLabel(), clone.getRangeAxis(0).getLabel());
        assertEquals(original.getRangeAxis(1).getLabel(), clone.getRangeAxis(1).getLabel());
    }

    @Test
    public void testCloneWithFixedDomainAxisSpace() throws CloneNotSupportedException {
        org.jfree.chart.axis.AxisSpace domainSpace = new org.jfree.chart.axis.AxisSpace();
        CategoryPlot original = new CategoryPlot();
        original.setFixedDomainAxisSpace(domainSpace);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getFixedDomainAxisSpace(), clone.getFixedDomainAxisSpace());
        assertEquals(original.getFixedDomainAxisSpace(), clone.getFixedDomainAxisSpace());
    }

    @Test
    public void testCloneWithFixedRangeAxisSpace() throws CloneNotSupportedException {
        org.jfree.chart.axis.AxisSpace rangeSpace = new org.jfree.chart.axis.AxisSpace();
        CategoryPlot original = new CategoryPlot();
        original.setFixedRangeAxisSpace(rangeSpace);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getFixedRangeAxisSpace(), clone.getFixedRangeAxisSpace());
        assertEquals(original.getFixedRangeAxisSpace(), clone.getFixedRangeAxisSpace());
    }

    @Test
    public void testCloneWithFixedLegendItems() throws CloneNotSupportedException {
        LegendItemCollection legendItems = new LegendItemCollection();
        legendItems.add(new org.jfree.chart.LegendItem("Series1", "Series1"));
        CategoryPlot original = new CategoryPlot();
        original.setFixedLegendItems(legendItems);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getFixedLegendItems(), clone.getFixedLegendItems());
        assertEquals(original.getFixedLegendItems(), clone.getFixedLegendItems());
    }

    @Test
    public void testCloneWithAnnotations() throws CloneNotSupportedException {
        CategoryAnnotation annotation = new org.jfree.chart.annotations.CategoryLineAnnotation(
                "Category1", 1.0, "Category1", 2.0, new BasicStroke(1.0f), Color.RED);
        CategoryPlot original = new CategoryPlot();
        original.addAnnotation(annotation);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getAnnotations(), clone.getAnnotations());
        assertEquals(original.getAnnotations().size(), clone.getAnnotations().size());
        assertEquals(original.getAnnotations().get(0).getClass(), clone.getAnnotations().get(0).getClass());
    }

    @Test
    public void testCloneWithMarkers() throws CloneNotSupportedException {
        CategoryMarker marker = new CategoryMarker("Category1", Color.BLUE, new BasicStroke(1.0f));
        CategoryPlot original = new CategoryPlot();
        original.addDomainMarker(marker, org.jfree.chart.ui.Layer.FOREGROUND);
        original.addRangeMarker(new org.jfree.chart.plot.Marker(1.0, Color.GREEN, new BasicStroke(1.0f)),
                                 org.jfree.chart.ui.Layer.BACKGROUND);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNotSame(original.getForegroundDomainMarkers(), clone.getForegroundDomainMarkers());
        assertNotSame(original.getBackgroundRangeMarkers(), clone.getBackgroundRangeMarkers());
        assertEquals(original.getForegroundDomainMarkers().size(), clone.getForegroundDomainMarkers().size());
        assertEquals(original.getBackgroundRangeMarkers().size(), clone.getBackgroundRangeMarkers().size());
    }

    @Test
    public void testCloneWithNullFields() throws CloneNotSupportedException {
        CategoryPlot original = new CategoryPlot();
        original.setDomainAxis(1, null);
        original.setRangeAxis(1, null);
        original.setRenderer(1, null);
        original.setDataset(1, null);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertNull(clone.getDomainAxis(1));
        assertNull(clone.getRangeAxis(1));
        assertNull(clone.getRenderer(1));
        assertNull(clone.getDataset(1));
    }

    @Test
    public void testCloneWithShadowGenerator() throws CloneNotSupportedException {
        org.jfree.chart.util.ShadowGenerator shadow = new org.jfree.chart.util.ShadowGenerator();
        CategoryPlot original = new CategoryPlot();
        original.setShadowGenerator(shadow);
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        assertNotSame(original, clone);
        assertSame(original.getShadowGenerator(), clone.getShadowGenerator());
    }

}