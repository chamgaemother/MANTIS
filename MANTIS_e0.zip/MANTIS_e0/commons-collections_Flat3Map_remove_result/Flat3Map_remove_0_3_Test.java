package org.apache.commons.collections4.map;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class Flat3Map_remove_0_3_Test {

    @Test
    @DisplayName("remove non-null key with size=2 and key does not match any key")
    public void TC11() throws Exception {
        // Create Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);

        // Set key1 and hash1
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, "key1".hashCode());

        // Set key2 and hash2
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, "key2".hashCode());

        // Define non-matching key
        Object nonMatchingKey = "nonMatchingKey";

        // Invoke remove
        Object result = map.remove(nonMatchingKey);

        // Assertions
        assertNull(result, "remove should return null");
        
        // Verify size remains 2
        int size = (int) sizeField.get(map);
        assertEquals(2, size, "size should remain 2");
    }

    @Test
    @DisplayName("remove non-null key with size=1 and key does not match key1")
    public void TC12() throws Exception {
        // Create Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 1);

        // Set key1 and hash1
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, "key1".hashCode());

        // Define non-matching key
        Object nonMatchingKey = "nonMatchingKey";

        // Invoke remove
        Object result = map.remove(nonMatchingKey);

        // Assertions
        assertNull(result, "remove should return null");
        
        // Verify size remains 1
        int size = (int) sizeField.get(map);
        assertEquals(1, size, "size should remain 1");
    }
}