// package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// // 
// // import org.apache.commons.math3.util.Decimal64;
// // import org.apache.commons.math3.exception.CardanEulerSingularityException;
// // import org.junit.jupiter.api.Assertions;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // /**
// //  * JUnit 5 tests for the getAngles method of FieldRotation.
// //  */
// public class FieldRotation_getAngles_2_5_Test {
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.ZYX and RotationConvention.FRAME_TRANSFORM, v2.getX() within bounds")
// //     public void test_TC26_getAngles_ZYX_FRAME_TRANSFORM_within_bounds() throws Exception {
//         // Given
// //         Decimal64 q0 = new Decimal64(Math.cos(Math.toRadians(30))); // Rotation less than 60 degrees
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(Math.sin(Math.toRadians(30)));
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         RotationOrder order = RotationOrder.ZYX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// // 
//         // When
// //         Decimal64[] angles = rotation.getAngles(order, convention);
// // 
//         // Then
// //         Assertions.assertNotNull(angles, "Angles array should not be null");
// //         Assertions.assertEquals(3, angles.length, "Angles array should have three elements");
//         // Additional assertions can be added based on expected angle values
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.ZYX and RotationConvention.FRAME_TRANSFORM, v2.getX() out of bounds triggering exception")
// //     public void test_TC27_getAngles_ZYX_FRAME_TRANSFORM_out_of_bounds_exception() throws Exception {
//         // Given
// //         Decimal64 q0 = new Decimal64(1.0); // Identity rotation, v2.getX() = 1.0
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(0.0);
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         RotationOrder order = RotationOrder.ZYX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// // 
//         // When & Then
// //         Assertions.assertThrows(CardanEulerSingularityException.class, () -> {
// //             rotation.getAngles(order, convention);
// //         }, "Expected CardanEulerSingularityException to be thrown");
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.XYZ and RotationConvention.FRAME_TRANSFORM, v2.getZ() within bounds")
// //     public void test_TC28_getAngles_XYZ_FRAME_TRANSFORM_within_bounds() throws Exception {
//         // Given
// //         Decimal64 q0 = new Decimal64(Math.cos(Math.toRadians(45))); // Rotation of 90 degrees
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(Math.sin(Math.toRadians(45)));
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         RotationOrder order = RotationOrder.XYZ;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// // 
//         // When
// //         Decimal64[] angles = rotation.getAngles(order, convention);
// // 
//         // Then
// //         Assertions.assertNotNull(angles, "Angles array should not be null");
// //         Assertions.assertEquals(3, angles.length, "Angles array should have three elements");
//         // Additional assertions can be added based on expected angle values
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.XYZ and RotationConvention.FRAME_TRANSFORM, v2.getZ() out of bounds triggering exception")
// //     public void test_TC29_getAngles_XYZ_FRAME_TRANSFORM_out_of_bounds_exception() throws Exception {
//         // Given
// //         Decimal64 q0 = new Decimal64(1.0); // Identity rotation, v2.getZ() = 1.0
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(0.0);
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         RotationOrder order = RotationOrder.XYZ;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// // 
//         // When & Then
// //         Assertions.assertThrows(CardanEulerSingularityException.class, () -> {
// //             rotation.getAngles(order, convention);
// //         }, "Expected CardanEulerSingularityException to be thrown");
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with RotationOrder.ZYZ and RotationConvention.FRAME_TRANSFORM, v2.getZ() within bounds")
// //     public void test_TC30_getAngles_ZYZ_FRAME_TRANSFORM_within_bounds() throws Exception {
//         // Given
// //         Decimal64 q0 = new Decimal64(Math.cos(Math.toRadians(60))); // Rotation of 120 degrees
// //         Decimal64 q1 = new Decimal64(0.0);
// //         Decimal64 q2 = new Decimal64(Math.sin(Math.toRadians(60)));
// //         Decimal64 q3 = new Decimal64(0.0);
// //         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         RotationOrder order = RotationOrder.ZYZ;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// // 
//         // When
// //         Decimal64[] angles = rotation.getAngles(order, convention);
// // 
//         // Then
// //         Assertions.assertNotNull(angles, "Angles array should not be null");
// //         Assertions.assertEquals(3, angles.length, "Angles array should have three elements");
//         // Additional assertions can be added based on expected angle values
// //     }
// // }
// }