package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.io.IOContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.CharConversionException;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class ByteSourceJsonBootstrapper_detectEncoding_2_3_Test {

    @Test
    @DisplayName("detectEncoding throws CharConversionException when handleBOM detects invalid UCS-4 encoding (quad=0x0000FFFE)")
    public void TC33_detectEncoding_InvalidUCS4_ThrowsCharConversionException() throws Exception {
        // GIVEN
        byte[] input = {(byte) 0x00, (byte) 0x00, (byte) 0xff, (byte) 0xfe}; // Adjusted input to match the case in handleBOM for test case to throw exception
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN & THEN
        assertThrows(CharConversionException.class, () -> {
            bootstrapper.detectEncoding();
        });
    }

}
