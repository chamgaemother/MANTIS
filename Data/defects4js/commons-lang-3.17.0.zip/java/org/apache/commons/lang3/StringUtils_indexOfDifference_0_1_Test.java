package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.StringUtils;

public class StringUtils_indexOfDifference_0_1_Test {

    @Test
    @DisplayName("Input array length <= 1 returns INDEX_NOT_FOUND")
    public void testTC01() {
        // GIVEN
        CharSequence[] css = {"test"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(StringUtils.INDEX_NOT_FOUND, result);
    }

    @Test
    @DisplayName("All strings are null returns INDEX_NOT_FOUND")
    public void testTC02() {
        // GIVEN
        CharSequence[] css = {null, null, null};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(StringUtils.INDEX_NOT_FOUND, result);
    }

    @Test
    @DisplayName("All strings empty and none are null returns INDEX_NOT_FOUND")
    public void testTC03() {
        // GIVEN
        CharSequence[] css = {"", "", ""};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(StringUtils.INDEX_NOT_FOUND, result);
    }

    @Test
    @DisplayName("Some strings are null returns 0")
    public void testTC04() {
        // GIVEN
        CharSequence[] css = {"test", null, "test"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("Strings with minimum length 0 returns 0")
    public void testTC05() {
        // GIVEN
        CharSequence[] css = {"", "test", "testing"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(0, result);
    }
}