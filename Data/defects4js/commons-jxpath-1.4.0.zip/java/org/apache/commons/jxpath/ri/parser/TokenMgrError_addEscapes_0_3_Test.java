package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TokenMgrError_addEscapes_0_3_Test {

    @Test
    @DisplayName("addEscapes with single single quote character")
    void test_TC11_addEscapes_single_single_quote_character() {
        // GIVEN
        String input = "\\'";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("\\\\'", result);
    }

    @Test
    @DisplayName("addEscapes with single backslash character")
    void test_TC12_addEscapes_single_backslash_character() {
        // GIVEN
        String input = "\\\\";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("\\\\\\\\", result);
    }

    @Test
    @DisplayName("addEscapes with single non-printable character (char 31)")
    void test_TC13_addEscapes_single_non_printable_char() {
        // GIVEN
        String input = "\u001F";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("\\u001f", result);
    }

    @Test
    @DisplayName("addEscapes with single high-ASCII character (char 128)")
    void test_TC14_addEscapes_single_high_ASCII_char() {
        // GIVEN
        String input = "\u0080";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("\\u0080", result);
    }

    @Test
    @DisplayName("addEscapes with multiple mixed special and normal characters")
    void test_TC15_addEscapes_multiple_mixed_characters() {
        // GIVEN
        String input = "A\bT\n";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("A\\bT\\n", result);
    }
}