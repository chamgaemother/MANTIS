package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field; // needed for direct field manipulation
import java.lang.reflect.AccessibleObject; // needed for reflection
import java.lang.reflect.Modifier; // needed for reflection

/**
 * JUnit 5 Test Class for EqualsBuilder.reflectionAppend method.
 */
public class EqualsBuilder_reflectionAppend_1_2_Test {

    /**
     * Custom class used for testing exception handling in reflectionAppend.
     */
    private static class CustomClass {
        private String field1;

        public CustomClass() {
            this.field1 = "value1";
        }
    }

    /**
     * Superclass for testing inheritance in reflectionAppend.
     */
    private static class SuperClass {
        protected String superField;

        public SuperClass(String superField) {
            this.superField = superField;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null || getClass() != obj.getClass())
                return false;
            SuperClass that = (SuperClass) obj;
            return superField.equals(that.superField);
        }
    }

    /**
     * Subclass for testing multiple superclass levels in reflectionAppend.
     */
    private static class SubClass extends SuperClass {
        private String subField;

        public SubClass(String superField, String subField) {
            super(superField);
            this.subField = subField;
        }

        @Override
        public boolean equals(Object obj) {
            if (!super.equals(obj))
                return false;
            if (this == obj)
                return true;
            SubClass that = (SubClass) obj;
            return subField.equals(that.subField);
        }
    }

    /**
     * TC19: Sets isEquals to false when reflectionAppend encounters an IllegalArgumentException
     */
    @Test
    @DisplayName("Sets isEquals to false when reflectionAppend encounters an IllegalArgumentException")
    void TC19_reflectionAppend_throws_IllegalArgumentException_sets_isEquals_false() throws Exception {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        Object lhs = new CustomClass();
        Object rhs = new CustomClass();

        // Access the method via reflection
        Method reflectionAppendMethod = EqualsBuilder.class.getDeclaredMethod("reflectionAppend", Object.class, Object.class, Class.class);
        reflectionAppendMethod.setAccessible(true);

        // Preparing a scenario to trigger exception
        Field[] fields = CustomClass.class.getDeclaredFields();
        AccessibleObject.setAccessible(fields, false);  // Force inaccessible

        try {
            // WHEN
            reflectionAppendMethod.invoke(builder, lhs, rhs, CustomClass.class);
        } catch (IllegalArgumentException e) {
            builder.setEquals(false);
        }

        // THEN
        assertFalse(builder.isEquals(), "isEquals should be set to false after IllegalArgumentException is thrown");
    }

    /**
     * TC20: Appends objects with multiple superclass levels without exceptions
     */
    @Test
    @DisplayName("Appends objects with multiple superclass levels without exceptions")
    void TC20_reflectionAppend_superclass_hierarchy_keeps_isEquals_true() {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        SubClass lhs = new SubClass("superValue", "subValue");
        SubClass rhs = new SubClass("superValue", "subValue");

        builder.setReflectUpToClass(Object.class);

        // Access the method via reflection
        Method reflectionAppendMethod;
        try {
            reflectionAppendMethod = EqualsBuilder.class.getDeclaredMethod("reflectionAppend", Object.class, Object.class, Class.class);
            reflectionAppendMethod.setAccessible(true);
            // WHEN
            reflectionAppendMethod.invoke(builder, lhs, rhs, lhs.getClass());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // THEN
        assertTrue(builder.isEquals(), "isEquals should remain true after reflection append through superclass hierarchy");
    }
}