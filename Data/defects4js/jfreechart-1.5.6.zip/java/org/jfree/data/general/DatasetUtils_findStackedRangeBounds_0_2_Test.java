package org.jfree.data.general;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import org.jfree.data.Range;
// import org.jfree.data.category.DefaultCategoryDataset;
// import org.jfree.data.KeyToGroupMap;
// import org.jfree.data.DefaultKeyToGroupMap;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
public class DatasetUtils_findStackedRangeBounds_0_2_Test {
// 
//     @Test
//     @DisplayName("Processes dataset with zero columns")
//     public void testTC06() {
        // GIVEN
//         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//         dataset.addValue(null, "Row1", "Column1");
//         dataset.addValue(null, "Row2", "Column1");
//         dataset.addValue(null, "Row3", "Column1");
// 
//         DefaultKeyToGroupMap map = new DefaultKeyToGroupMap("Group1");
//         map.mapKeyToGroup("Row1", "Group1");
//         map.mapKeyToGroup("Row2", "Group1");
//         map.mapKeyToGroup("Row3", "Group1");
// 
        // WHEN
//         Range result = DatasetUtils.findStackedRangeBounds(dataset, map);
// 
        // THEN
//         assertNull(result, "Range should be null when there are zero columns");
//     }
// 
//     @Test
//     @DisplayName("Handles dataset with single group and multiple iterations")
//     public void testTC07() {
        // GIVEN
//         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//         dataset.addValue(10.0, "Row1", "Column1");
//         dataset.addValue(20.0, "Row1", "Column2");
//         dataset.addValue(30.0, "Row1", "Column3");
//         dataset.addValue(15.0, "Row2", "Column1");
//         dataset.addValue(25.0, "Row2", "Column2");
//         dataset.addValue(35.0, "Row2", "Column3");
// 
//         DefaultKeyToGroupMap map = new DefaultKeyToGroupMap("Group1");
//         map.mapKeyToGroup("Row1", "Group1");
//         map.mapKeyToGroup("Row2", "Group1");
// 
//         Range expected = new Range(0.0, 135.0);
// 
        // WHEN
//         Range result = DatasetUtils.findStackedRangeBounds(dataset, map);
// 
        // THEN
//         assertNotNull(result, "Range should not be null when there are positive values");
//         assertEquals(expected, result, "Range should correctly aggregate values for the single group");
//     }
// 
//     @Test
//     @DisplayName("Handles negative and zero values in dataset")
//     public void testTC08() {
        // GIVEN
//         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//         dataset.addValue(-10.0, "Row1", "Column1");
//         dataset.addValue(0.0, "Row1", "Column2");
//         dataset.addValue(20.0, "Row2", "Column1");
//         dataset.addValue(-5.0, "Row2", "Column2");
// 
//         DefaultKeyToGroupMap map = new DefaultKeyToGroupMap("Group1");
//         map.mapKeyToGroup("Row1", "Group1");
//         map.mapKeyToGroup("Row2", "Group1");
// 
//         Range expected = new Range(-10.0, 20.0);
// 
        // WHEN
//         Range result = DatasetUtils.findStackedRangeBounds(dataset, map);
// 
        // THEN
//         assertNotNull(result, "Range should not be null when there are negative and positive values");
//         assertEquals(expected, result, "Range should correctly account for negative and zero values");
//     }
// 
//     @Test
//     @DisplayName("Handles multiple groups with varying data distributions")
//     public void testTC09() {
        // GIVEN
//         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//         dataset.addValue(10.0, "Row1", "Column1");
//         dataset.addValue(-20.0, "Row1", "Column2");
//         dataset.addValue(30.0, "Row1", "Column3");
//         dataset.addValue(40.0, "Row2", "Column1");
//         dataset.addValue(-50.0, "Row2", "Column2");
//         dataset.addValue(60.0, "Row2", "Column3");
//         dataset.addValue(70.0, "Row3", "Column1");
//         dataset.addValue(-80.0, "Row3", "Column2");
//         dataset.addValue(90.0, "Row3", "Column3");
//         dataset.addValue(25.0, "Row4", "Column1");
//         dataset.addValue(-35.0, "Row4", "Column2");
//         dataset.addValue(45.0, "Row4", "Column3");
// 
//         DefaultKeyToGroupMap map = new DefaultKeyToGroupMap("Group");
//         map.mapKeyToGroup("Row1", "Group1");
//         map.mapKeyToGroup("Row2", "Group2");
//         map.mapKeyToGroup("Row3", "Group1");
//         map.mapKeyToGroup("Row4", "Group3");
// 
//         Range expected = new Range(-50.0, 60.0);
// 
        // WHEN
//         Range result = DatasetUtils.findStackedRangeBounds(dataset, map);
// 
        // THEN
//         assertNotNull(result, "Range should not be null when there are multiple groups with varied data");
//         assertEquals(expected, result, "Range should correctly combine ranges across multiple groups");
//     }
// 
//     @Test
//     @DisplayName("Handles dataset where some groups have no valid data")
//     public void testTC10() {
        // GIVEN
//         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//         dataset.addValue(null, "Row1", "Column1");
//         dataset.addValue(null, "Row1", "Column2");
//         dataset.addValue(null, "Row1", "Column3");
//         dataset.addValue(20.0, "Row2", "Column1");
//         dataset.addValue(30.0, "Row2", "Column2");
//         dataset.addValue(40.0, "Row2", "Column3");
//         dataset.addValue(0.0, "Row3", "Column1");
//         dataset.addValue(0.0, "Row3", "Column2");
//         dataset.addValue(0.0, "Row3", "Column3");
// 
//         DefaultKeyToGroupMap map = new DefaultKeyToGroupMap("Group");
//         map.mapKeyToGroup("Row1", "Group1");
//         map.mapKeyToGroup("Row2", "Group2");
//         map.mapKeyToGroup("Row3", "Group3");
// 
//         Range expected = new Range(0.0, 40.0);
// 
        // WHEN
//         Range result = DatasetUtils.findStackedRangeBounds(dataset, map);
// 
        // THEN
//         assertNotNull(result, "Range should not be null when some groups have valid data");
//         assertEquals(expected, result, "Range should correctly exclude groups with no valid data");
//     }
// 
// }
}