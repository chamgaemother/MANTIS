package org.apache.commons.math3.ode.sampling;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.apache.commons.math3.ode.sampling.FieldStepInterpolator;
import org.apache.commons.math3.ode.sampling.FieldFixedStepHandler;
import org.apache.commons.math3.ode.sampling.FieldStepNormalizer;
import org.apache.commons.math3.ode.sampling.StepNormalizerBounds;
import org.apache.commons.math3.ode.sampling.StepNormalizerMode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

public class FieldStepNormalizer_handleStep_2_1_Test {

//     @Test
//     @DisplayName("handleStep with isLast true and bounds.lastIncluded false, ensuring the last step is not included")
//     public void TC20_handleStep_isLast_true_bounds_lastIncluded_false() throws Exception {
        // GIVEN
//         @SuppressWarnings("unchecked")
//         FieldFixedStepHandler<RealFieldElement<?>> handler = mock(FieldFixedStepHandler.class);
//         FieldStepNormalizer<RealFieldElement<?>> normalizer = new FieldStepNormalizer<>(
//                 1.0,
//                 handler,
//                 StepNormalizerMode.INCREMENT,
//                 StepNormalizerBounds.NEITHER
//         );
//         
//         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
//         FieldODEStateAndDerivative<RealFieldElement<?>> initialState = mock(FieldODEStateAndDerivative.class);
//         when(interpolator.getPreviousState()).thenReturn(initialState);
//         when(interpolator.isForward()).thenReturn(true);
//         
//         FieldODEStateAndDerivative<RealFieldElement<?>> existingLastState = mock(FieldODEStateAndDerivative.class);
//         RealFieldElement<?> lastTimeReal = mock(RealFieldElement.class);
//         when(existingLastState.getTime()).thenReturn(lastTimeReal);
//         when(lastTimeReal.getReal()).thenReturn(2.0);
//         
        // Use reflection to set the private 'last' field
//         Field lastField = FieldStepNormalizer.class.getDeclaredField("last");
//         lastField.setAccessible(true);
//         lastField.set(normalizer, existingLastState);
//         
//         FieldODEStateAndDerivative<RealFieldElement<?>> currentState = mock(FieldODEStateAndDerivative.class);
//         RealFieldElement<?> currentTimeReal = mock(RealFieldElement.class);
//         when(interpolator.getCurrentState()).thenReturn(currentState);
//         when(currentState.getTime()).thenReturn(currentTimeReal);
//         when(currentTimeReal.getReal()).thenReturn(3.0);
//         
        // WHEN
//         normalizer.handleStep(interpolator, true);
//         
        // THEN
//         verify(handler, never()).handleStep(any(), eq(false));
//         verify(handler, never()).handleStep(any(), eq(true));
//     }

//     @Test
//     @DisplayName("handleStep with bounds.firstIncluded false and first time equals last time, skipping the first step")
//     public void TC21_handleStep_bounds_firstIncluded_false_firstTime_equals_lastTime() throws Exception {
        // GIVEN
//         @SuppressWarnings("unchecked")
//         FieldFixedStepHandler<RealFieldElement<?>> handler = mock(FieldFixedStepHandler.class);
//         FieldStepNormalizer<RealFieldElement<?>> normalizer = new FieldStepNormalizer<>(
//                 1.0,
//                 handler,
//                 StepNormalizerMode.INCREMENT,
//                 StepNormalizerBounds.NEITHER
//         );
//         
//         FieldStepInterpolator<RealFieldElement<?>> interpolator = mock(FieldStepInterpolator.class);
//         FieldODEStateAndDerivative<RealFieldElement<?>> firstState = mock(FieldODEStateAndDerivative.class);
//         when(interpolator.getPreviousState()).thenReturn(firstState);
//         when(interpolator.isForward()).thenReturn(true);
//         
//         RealFieldElement<?> firstTimeReal = mock(RealFieldElement.class);
//         when(firstState.getTime()).thenReturn(firstTimeReal);
//         when(firstTimeReal.getReal()).thenReturn(2.0);
//         
//         FieldODEStateAndDerivative<RealFieldElement<?>> lastState = mock(FieldODEStateAndDerivative.class);
//         RealFieldElement<?> lastTimeReal = mock(RealFieldElement.class);
//         when(lastState.getTime()).thenReturn(lastTimeReal);
//         when(lastTimeReal.getReal()).thenReturn(2.0);
//         
        // Use reflection to set the private 'last' field
//         Field lastField = FieldStepNormalizer.class.getDeclaredField("last");
//         lastField.setAccessible(true);
//         lastField.set(normalizer, lastState);
//         
        // WHEN
//         normalizer.handleStep(interpolator, false);
//         
        // THEN
//         verify(handler, never()).handleStep(any(), anyBoolean());
//     }
}