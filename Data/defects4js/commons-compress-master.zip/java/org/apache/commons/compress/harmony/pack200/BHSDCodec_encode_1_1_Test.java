package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.compress.harmony.pack200.BHSDCodec;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import static org.junit.jupiter.api.Assertions.*;

public class BHSDCodec_encode_1_1_Test {

    @Test
    @DisplayName("encode successfully encodes the smallest encodable value when isSigned and not delta")
    public void TC15_encodeSmallestValue_SignedNonDelta() throws Pack200Exception {
        // GIVEN
        int b = 2;
        int h = 10;
        int s = 1;
        int d = 0;
        BHSDCodec codec = new BHSDCodec(b, h, s, d);
        int value = (int) codec.smallest();
        int last = 0;

        // WHEN
        byte[] result = codec.encode(value, last);

        // THEN
        byte[] expected = {(byte)255, (byte)255};
        assertArrayEquals(expected, result, "Encoded bytes do not match the expected smallest value encoding.");
    }

    @Test
    @DisplayName("encode successfully encodes the largest encodable value when isSigned and not delta")
    public void TC16_encodeLargestValue_SignedNonDelta() throws Pack200Exception {
        // GIVEN
        int b = 2;
        int h = 10;
        int s = 1;
        int d = 0;
        BHSDCodec codec = new BHSDCodec(b, h, s, d);
        int value = (int) codec.largest();
        int last = 0;

        // WHEN
        byte[] result = codec.encode(value, last);

        // THEN
        byte[] expected = {(byte)254, (byte)255};
        assertArrayEquals(expected, result, "Encoded bytes do not match the expected largest value encoding.");
    }

    @Test
    @DisplayName("encode successfully encodes zero when isSigned and not delta")
    public void TC17_encodeZero_SignedNonDelta() throws Pack200Exception {
        // GIVEN
        int b = 2;
        int h = 10;
        int s = 1;
        int d = 0;
        BHSDCodec codec = new BHSDCodec(b, h, s, d);
        int value = 0;
        int last = 0;

        // WHEN
        byte[] result = codec.encode(value, last);

        // THEN
        byte[] expected = {0};
        assertArrayEquals(expected, result, "Encoded bytes do not match the expected zero value encoding.");
    }

    @Test
    @DisplayName("encode throws Pack200Exception when encoding value exceeds largest and isSigned")
    public void TC18_encodeValueExceedsLargest_Signed() {
        // GIVEN
        int b = 2;
        int h = 10;
        int s = 1;
        int d = 0;
        BHSDCodec codec = new BHSDCodec(b, h, s, d);
        int value = (int) codec.largest() + 1;
        int last = 0;

        // WHEN & THEN
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            codec.encode(value, last);
        }, "Expected encode to throw Pack200Exception when value exceeds largest encodable.");
        assertEquals("The codec (2,10,1,0) does not encode the value 1403", exception.getMessage(), "Exception message does not match expected.");
    }

    @Test
    @DisplayName("encode successfully encodes value with multiple loop iterations")
    public void TC19_encodeMultipleLoopIterations() throws Pack200Exception {
        // GIVEN
        int b = 3;
        int h = 10;
        int s = 0;
        int d = 0;
        BHSDCodec codec = new BHSDCodec(b, h, s, d);
        int value = 1234;
        int last = 0;

        // WHEN
        byte[] result = codec.encode(value, last);

        // THEN
        byte[] expected = {(byte)254, (byte)98};
        assertArrayEquals(expected, result, "Encoded bytes do not match the expected multiple loop iterations encoding.");
    }
}