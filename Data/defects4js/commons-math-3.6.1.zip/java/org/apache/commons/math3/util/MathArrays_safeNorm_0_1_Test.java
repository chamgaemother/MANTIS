package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.util.MathArrays;

public class MathArrays_safeNorm_0_1_Test {

    @Test
    @DisplayName("safeNorm(null) throws NullPointerException when input array is null")
    void testTC01() {
        // GIVEN
        double[] v = null;
        
        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            MathArrays.safeNorm(v);
        });
    }

    @Test
    @DisplayName("safeNorm with empty array returns 0.0")
    void testTC02() {
        // GIVEN
        double[] v = new double[]{};
        
        // WHEN
        double result = MathArrays.safeNorm(v);
        
        // THEN
        assertEquals(0.0, result, "Expected norm of empty array to be 0.0");
    }

    @Test
    @DisplayName("safeNorm with single element where xabs is within rdwarf and agiant")
    void testTC03() {
        // GIVEN
        double[] v = new double[]{5.0};
        
        // WHEN
        double result = MathArrays.safeNorm(v);
        
        // THEN
        assertEquals(5.0, result, "Expected norm to be the absolute value of the single element");
    }

    @Test
    @DisplayName("safeNorm with single element where xabs exceeds agiant")
    void testTC04() {
        // GIVEN
        double[] v = new double[]{2.0e+19};
        
        // WHEN
        double result = MathArrays.safeNorm(v);
        
        // THEN
        assertEquals(2.0e+19, result, "Expected norm to account for large xabs");
    }

    @Test
    @DisplayName("safeNorm with single element where xabs is greater than rdwarf but less than or equal to x1max")
    void testTC05() {
        // GIVEN
        double[] v = new double[]{1.0e+18};
        
        // WHEN
        double result = MathArrays.safeNorm(v);
        
        // THEN
        assertEquals(1.0e+18, result, "Expected s1 to be updated correctly and norm computed");
    }
}