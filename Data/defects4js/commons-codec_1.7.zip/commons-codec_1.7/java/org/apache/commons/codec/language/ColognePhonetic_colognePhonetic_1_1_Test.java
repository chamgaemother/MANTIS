package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ColognePhonetic_colognePhonetic_1_1_Test {

    @Test
    @DisplayName("Input with 'C' after 'G', should assign code '8'")
    void test_TC37_C_after_G_assigns_code_8() throws Exception {
        // Arrange
        String input = "Goc";
        
        // Act
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        
        // Assert
        assertTrue(result.contains("8"));
    }

    @Test
    @DisplayName("Input with 'C' after 'Q', should assign code '8'")
    void test_TC38_C_after_Q_assigns_code_8() throws Exception {
        // Arrange
        String input = "Quc";
        
        // Act
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        
        // Assert
        assertTrue(result.contains("8"));
    }

    @Test
    @DisplayName("Input ending with 'C', should assign appropriate code based on context")
    void test_TC39_Ending_with_C_assigns_correct_code() throws Exception {
        // Arrange
        String input = "Magic";
        
        // Act
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        
        // Assert
        assertTrue(result.contains("8"));
    }

    @Test
    @DisplayName("Input with 'T' before 'Z', should assign code '2'")
    void test_TC40_T_before_Z_assigns_code_2() throws Exception {
        // Arrange
        String input = "Texas";
        
        // Act
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        
        // Assert
        assertTrue(result.contains("2"));
    }

    @Test
    @DisplayName("Input with 'C' followed by non-specified letter, should assign code '8'")
    void test_TC41_C_followed_by_non_specified_assigns_code_8() throws Exception {
        // Arrange
        String input = "Czarevsky";
        
        // Act
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        
        // Assert
        assertTrue(result.contains("8"));
    }
}