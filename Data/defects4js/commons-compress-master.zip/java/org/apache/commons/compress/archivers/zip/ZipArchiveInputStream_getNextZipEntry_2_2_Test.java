package org.apache.commons.compress.archivers.zip;

import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipArchiveInputStream_getNextZipEntry_2_2_Test {

    @Test
    @DisplayName("Handles readFirstLocalFileHeader loop by correctly skipping preamble garbage data and locating the first local file header")
    public void TC09_skip_preamble_garbage_data_and_locate_first_entry() throws Exception {
        // Arrange: create a ZIP byte array with preamble garbage data
        byte[] garbage = new byte[] {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos.write(garbage);

        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            ZipEntry entry = new ZipEntry("firstEntryName");
            zos.putNextEntry(entry);
            String fileContent = "file content";
            zos.write(fileContent.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
        }

        InputStream inputStream = new ByteArrayInputStream(baos.toByteArray());
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);

        // Act: invoke getNextZipEntry
        ZipArchiveEntry zipEntry = zipInputStream.getNextZipEntry();

        // Assert: check entry is correctly read
        assertNotNull(zipEntry, "Expected ZipArchiveEntry to be not null");
        assertEquals("firstEntryName", zipEntry.getName(), "Entry name does not match");
    }
}