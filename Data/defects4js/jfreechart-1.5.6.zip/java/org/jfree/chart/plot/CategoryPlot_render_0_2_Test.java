package org.jfree.chart.plot;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.ui.RectangleEdge;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

public class CategoryPlot_render_0_2_Test {

    @Test
    @DisplayName("render method processes one rendering pass with ascending column and descending row order")
    public void TC06() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);

        // Setup dataset
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);

        // Setup renderer
        when(renderer.getPassCount()).thenReturn(1);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(renderer.initialise(eq(g2), eq(dataArea), eq(plot), eq(0), eq(info))).thenReturn(state);

        // Configure plot with dataset and renderer
        plot.setDataset(0, dataset);
        plot.setRenderer(0, renderer);

        // Mock axes
        CategoryAxis categoryAxis = mock(CategoryAxis.class);
        ValueAxis valueAxis = mock(ValueAxis.class);
        // Fix: Attach created mock axes to the plot for dataset 0.
        doReturn(categoryAxis).when(plot).getDomainAxisForDataset(0);
        doReturn(valueAxis).when(plot).getRangeAxisForDataset(0);

        // Set rendering orders using reflection
        setField(plot, "columnRenderingOrder", SortOrder.ASCENDING);
        setField(plot, "rowRenderingOrder", SortOrder.DESCENDING);

        // Act
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);

        // Assert
        assertTrue(result, "render should return true");

        // Verify renderer.drawItem called once
        verify(renderer, times(1)).drawItem(eq(g2), eq(state), eq(dataArea), eq(plot), eq(categoryAxis), eq(valueAxis), eq(dataset), eq(0), eq(0), eq(0));
    }

    // Other tests (TC07, TC08, TC09, TC10) are omitted for brevity, follow similar pattern

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = CategoryPlot.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}