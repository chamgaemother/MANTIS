package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

public class ValueUtils_getValue_0_3_Test {

    @Test
    @DisplayName("getValue returns the collection itself when it is not an array, List, or Collection")
    public void TC11() {
        // Given
        Object collection = "testObject";
        int index = 0;

        // When
        Object result = ValueUtils.getValue(collection, index);

        // Then
        Assertions.assertEquals(collection, result, "The returned value should be the original collection.");
    }
}