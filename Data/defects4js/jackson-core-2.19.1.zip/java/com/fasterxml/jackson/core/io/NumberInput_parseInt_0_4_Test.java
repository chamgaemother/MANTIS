package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.io.NumberInput;

public class NumberInput_parseInt_0_4_Test {

    @Test
    @DisplayName("parseInt with multiple iterations (5 digits)")
    public void TC16() {
        String s = "12345";
        int result = NumberInput.parseInt(s);
        assertEquals(12345, result);
    }

    @Test
    @DisplayName("parseInt with non-digit after several digits defers to Integer.parseInt")
    public void TC17() {
        String s = "1234a";
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt(s));
    }
}