package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.analysis.interpolating.BicubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BicubicSplineInterpolatorTest {

    @Test
    public void testInterpolateWithEmptyXval() {
        double[] xval = new double[0];
        double[] yval = {1.0, 2.0};
        double[][] fval = {{1.0, 2.0}};
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithEmptyYval() {
        double[] xval = {1.0, 2.0};
        double[] yval = new double[0];
        double[][] fval = {{}};
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithEmptyFval() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = new double[0][0];
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithMismatchedFvalLength() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0},
            {5.0, 6.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithNonMonotonicXval() {
        double[] xval = {1.0, 3.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0},
            {5.0, 6.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NonMonotonicSequenceException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithNonMonotonicYval() {
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {2.0, 1.0};
        double[][] fval = {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NonMonotonicSequenceException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithMismatchedFvalRowLength() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithTooSmallXval() {
        double[] xval = {1.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NumberIsTooSmallException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithTooSmallYval() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0};
        double[][] fval = {
            {1.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NumberIsTooSmallException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithNullXval() {
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(null, yval, fval));
    }

    @Test
    public void testInterpolateWithNullYval() {
        double[] xval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            {3.0, 4.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, null, fval));
    }

    @Test
    public void testInterpolateWithNullFval() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, null));
    }

    @Test
    public void testInterpolateWithNullFvalRow() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[][] fval = {
            {1.0, 2.0},
            null
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    public void testInterpolateWithValidInputs() {
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[][] fval = {
            {1.0, 2.0, 3.0},
            {2.0, 3.0, 4.0},
            {3.0, 4.0, 5.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertDoesNotThrow(() -> {
            BicubicSplineInterpolatingFunction func = interpolator.interpolate(xval, yval, fval);
            assertNotNull(func);
            double result = func.value(2.0, 2.0);
            assertEquals(3.0, result, 1e-10);
        });
    }

    @Test
    public void testInterpolateWithInitializeDerivativesTrue() {
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[][] fval = {
            {1.0, 2.0, 3.0},
            {2.0, 3.0, 4.0},
            {3.0, 4.0, 5.0}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator(true);
        assertDoesNotThrow(() -> {
            BicubicSplineInterpolatingFunction func = interpolator.interpolate(xval, yval, fval);
            assertNotNull(func);
            // Assuming the BicubicSplineInterpolatingFunction exposes a method to check initializeDerivatives
            // If not, this part can be omitted or checked via reflection
        });
    }
}