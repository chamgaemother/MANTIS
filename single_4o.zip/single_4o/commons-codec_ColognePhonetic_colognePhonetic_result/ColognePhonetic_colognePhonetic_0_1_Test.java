package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.codec.language.ColognePhonetic;

import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_1_Test {

    @Test
    @DisplayName("colognePhonetic(null) should return null indicating the input was null")
    void testNullInput() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = null;
        String result = colognePhonetic.colognePhonetic(input);
        assertNull(result, "Expected null result when input is null.");
    }

    @Test
    @DisplayName("colognePhonetic('') returns an empty string after preprocessing and encoding")
    void testEmptyInput() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "";
        String result = colognePhonetic.colognePhonetic(input);
        assertEquals("", result, "Expected empty string when input is empty.");
    }

    @Test
    @DisplayName("colognePhonetic('Muller') converts \"MULLER\" to \"605\"")
    void testTypicalGermanChars() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Muller";
        String result = colognePhonetic.colognePhonetic(input);
        assertEquals("605", result, "Expected encoding of 'Muller' to be '605'.");
    }

    @Test
    @DisplayName("colognePhonetic('ph') evaluates replacement according to special rules for 'P' and 'H'")
    void testPHSpecialRule() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "ph";
        String result = colognePhonetic.colognePhonetic(input);
        assertEquals("3", result, "Expected encoding of 'ph' to be '3'.");
    }

    @Test
    @DisplayName("colognePhonetic('FischersFritze') handles repeated S's and 'C' special case")
    void testRepeatedSC() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "FischersFritze";
        String result = colognePhonetic.colognePhonetic(input);
        assertEquals("843848", result, "Expected encoding of 'FischersFritze' to be '843848'.");
    }
}