package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.apache.commons.math3.ode.sampling.StepHandler;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class AdamsBashforthIntegratorTest {

    @Test
    void testIntegrateWithNullEquations() {
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6);
        assertThrows(NullPointerException.class, () -> integrator.integrate(null, 1.0));
    }

    @Test
    void testIntegrateWithSameInitialAndFinalTime() throws Exception {
        FirstOrderDifferentialEquations equations = new DummyEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6);
        integrator.integrate(expandable, 0.0);
        assertEquals(0.0, expandable.getTime());
        assertArrayEquals(new double[]{1.0}, expandable.getCompleteState());
    }

    @Test
    void testIntegrateForward() throws Exception {
        FirstOrderDifferentialEquations equations = new DummyEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6);
        integrator.integrate(expandable, 1.0);
        assertEquals(1.0, expandable.getTime(), 1e-10);
        assertArrayEquals(new double[]{1.0}, expandable.getCompleteState(), 1e-10);
    }

    @Test
    void testIntegrateBackward() throws Exception {
        FirstOrderDifferentialEquations equations = new DummyEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(1.0);
        expandable.setPrimaryState(new double[]{1.0});
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6);
        integrator.integrate(expandable, 0.0);
        assertEquals(0.0, expandable.getTime(), 1e-10);
        assertArrayEquals(new double[]{1.0}, expandable.getCompleteState(), 1e-10);
    }

    @Test
    void testIntegrateWithNumberIsTooSmallException() {
        Executable executable = () -> new AdamsBashforthIntegrator(0, 0.1, 1.0, 1e-6, 1e-6);
        assertThrows(NumberIsTooSmallException.class, executable);
    }

    @Test
    void testIntegrateWithDimensionMismatchException() throws Exception {
        FirstOrderDifferentialEquations equations = new DifferentialEquationsWithWrongDimension();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0, 2.0});
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6);
        assertThrows(DimensionMismatchException.class, () -> integrator.integrate(expandable, 1.0));
    }

    @Test
    void testIntegrateWithMaxCountExceededException() throws Exception {
        FirstOrderDifferentialEquations equations = new UnstableEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6);
        integrator.setMaxEvaluations(10);
        assertThrows(MaxCountExceededException.class, () -> integrator.integrate(expandable, 10.0));
    }

    @Test
    void testIntegrateWithNoBracketingException() throws Exception {
        FirstOrderDifferentialEquations equations = new DummyEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        AdamsBashforthIntegrator integrator = Mockito.spy(new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6));
        Mockito.doThrow(new NoBracketingException(0.0, 1.0)).when(integrator).integrate(expandable, 1.0);
        assertThrows(NoBracketingException.class, () -> integrator.integrate(expandable, 1.0));
    }

    @Test
    void testIntegrateWithNullState() throws Exception {
        FirstOrderDifferentialEquations equations = new DummyEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(null);
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.1, 1.0, 1e-6, 1e-6);
        assertThrows(NullPointerException.class, () -> integrator.integrate(expandable, 1.0));
    }

    @Test
    void testIntegrateWithZeroStep() throws Exception {
        FirstOrderDifferentialEquations equations = new ZeroStepEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{0.0});
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.0, 1.0, 1e-6, 1e-6);
        integrator.integrate(expandable, 1.0);
        assertEquals(1.0, expandable.getTime(), 1e-10);
        assertArrayEquals(new double[]{0.0}, expandable.getCompleteState(), 1e-10);
    }

    @Test
    void testIntegrateWithNegativeStepSizes() throws Exception {
        FirstOrderDifferentialEquations equations = new DummyEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, -1.0, -0.1, 1e-6, 1e-6);
        integrator.integrate(expandable, -1.0);
        assertEquals(-1.0, expandable.getTime(), 1e-10);
        assertArrayEquals(new double[]{1.0}, expandable.getCompleteState(), 1e-10);
    }

    @Test
    void testIntegrateWithBoundaryStepSize() throws Exception {
        FirstOrderDifferentialEquations equations = new BoundaryStepEquations();
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        double minStep = 0.1;
        double maxStep = 0.1;
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, minStep, maxStep, 1e-6, 1e-6);
        integrator.integrate(expandable, 0.3);
        assertEquals(0.3, expandable.getTime(), 1e-10);
        assertArrayEquals(new double[]{1.0}, expandable.getCompleteState(), 1e-10);
    }

    // Dummy equations for testing purposes
    static class DummyEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 1;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = 0.0;
        }
    }

    // Equations that have wrong dimension
    static class DifferentialEquationsWithWrongDimension implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 2;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = 1.0;
            yDot[1] = 1.0;
        }
    }

    // Unstable equations to trigger MaxCountExceededException
    static class UnstableEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 1;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = y[0];
        }
    }

    // Equations that maintain zero step
    static class ZeroStepEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 1;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = 0.0;
        }
    }

    // Equations used for boundary step size test
    static class BoundaryStepEquations implements FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 1;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = 0.0;
        }
    }
}