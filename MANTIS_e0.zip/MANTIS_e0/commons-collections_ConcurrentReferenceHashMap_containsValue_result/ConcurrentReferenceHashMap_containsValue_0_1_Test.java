package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.concurrent.ConcurrentMap;

public class ConcurrentReferenceHashMap_containsValue_0_1_Test {

    @Test
    @DisplayName("Pass null value and expect NullPointerException")
    void TC01() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = null;

        // WHEN & THEN
        NullPointerException exception = assertThrows(NullPointerException.class, () -> {
            map.containsValue(value);
        });
        assertEquals("value", exception.getMessage());
    }

    @Test
    @DisplayName("Value exists in the first segment without requiring retries")
    void TC02() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "testValue";
        map.put("key1", value);

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result, "The map should contain the value 'testValue'");
    }

    @Test
    @DisplayName("Value does not exist and clean sweep returns false")
    void TC03() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "nonExistentValue";

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertFalse(result, "The map should not contain the value 'nonExistentValue'");
    }

    @Test
    @DisplayName("Value exists after one retry due to modCount change")
    void TC04() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "testValue";
        map.put("key1", value);
        // Simulate modCount change by adding another entry
        map.put("key2", "anotherValue");

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result, "The map should contain the value 'testValue' after one retry due to modCount change");
    }

    @Test
    @DisplayName("Value does not exist after maximum retries and locking, clean sweep")
    void TC05() throws NoSuchFieldException, IllegalAccessException {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "nonExistentValue";

        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        for (Object segment : segments) {
            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            int currentModCount = modCountField.getInt(segment);
            modCountField.setInt(segment, currentModCount + 1); // Increment modCount to simulate change
        }

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertFalse(result, "The map should not contain the value 'nonExistentValue' after retries and locking");
    }
}
