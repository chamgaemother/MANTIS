package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYErrorRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem with drawXError=true, errorPaint null, errorStroke not null, orientation HORIZONTAL")
    public void TC06() throws Exception {
        int pass = 0;
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(true);
        renderer.setDrawYError(false);
        renderer.setErrorPaint(null);
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorStroke(customErrorStroke);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;

        when(dataset.getItemCount(series)).thenReturn(1);
        when(dataset.getYValue(series, item)).thenReturn(10.0);
        when(dataset.getStartXValue(series, item)).thenReturn(5.0);
        when(dataset.getEndXValue(series, item)).thenReturn(15.0);
        when(dataset.getStartYValue(series, item)).thenReturn(8.0);
        when(dataset.getEndYValue(series, item)).thenReturn(12.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);

        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);

        CrosshairState crosshairState = mock(CrosshairState.class);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(customErrorStroke);

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(3)).draw(lineCaptor.capture());
        assertEquals(3, lineCaptor.getAllValues().size());

        // Remove the unnecessary spy verification which was causing compilation errors
    }

    @Test
    @DisplayName("drawItem with drawYError=true, errorPaint and errorStroke not null, orientation VERTICAL")
    public void TC07() throws Exception {
        int pass = 0;
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(false);
        renderer.setDrawYError(true);
        Paint customErrorPaint = mock(Paint.class);
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorPaint(customErrorPaint);
        renderer.setErrorStroke(customErrorStroke);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;

        when(dataset.getItemCount(series)).thenReturn(1);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(dataset.getStartYValue(series, item)).thenReturn(18.0);
        when(dataset.getEndYValue(series, item)).thenReturn(22.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);

        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);

        CrosshairState crosshairState = mock(CrosshairState.class);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2).setPaint(customErrorPaint);
        verify(g2).setStroke(customErrorStroke);

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(3)).draw(lineCaptor.capture());
        assertEquals(3, lineCaptor.getAllValues().size());

        // Removed spy verification method calls which lacked proper context in original test
    }

    @Test
    @DisplayName("drawItem with drawYError=true, errorPaint not null, errorStroke null, orientation HORIZONTAL")
    public void TC08() throws Exception {
        int pass = 0;
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(false);
        renderer.setDrawYError(true);
        Paint customErrorPaint = mock(Paint.class);
        renderer.setErrorPaint(customErrorPaint);
        renderer.setErrorStroke(null);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;

        when(dataset.getItemCount(series)).thenReturn(1);
        when(dataset.getYValue(series, item)).thenReturn(30.0);
        when(dataset.getStartYValue(series, item)).thenReturn(28.0);
        when(dataset.getEndYValue(series, item)).thenReturn(32.0);
        when(dataset.getXValue(series, item)).thenReturn(15.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);

        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(30.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);

        CrosshairState crosshairState = mock(CrosshairState.class);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2).setPaint(customErrorPaint);

        // Corrected the use of getItemStroke. It should not mock the default stroke
        Stroke stroke = renderer.getItemStroke(series, item);
        verify(g2).setStroke(stroke);

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(3)).draw(lineCaptor.capture());
        assertEquals(3, lineCaptor.getAllValues().size());

        // Remove unnecessary repetition
    }

    @Test
    @DisplayName("drawItem with drawXError=true and drawYError=true, orientation VERTICAL, errorPaint and errorStroke not null")
    public void TC09() throws Exception {
        int pass = 0;
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(true);
        renderer.setDrawYError(true);
        Paint customErrorPaint = mock(Paint.class);
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorPaint(customErrorPaint);
        renderer.setErrorStroke(customErrorStroke);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;

        when(dataset.getItemCount(series)).thenReturn(1);
        when(dataset.getYValue(series, item)).thenReturn(40.0);
        when(dataset.getStartXValue(series, item)).thenReturn(20.0);
        when(dataset.getEndXValue(series, item)).thenReturn(25.0);
        when(dataset.getStartYValue(series, item)).thenReturn(38.0);
        when(dataset.getEndYValue(series, item)).thenReturn(42.0);
        when(dataset.getXValue(series, item)).thenReturn(20.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(25.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(250.0);

        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(40.0, dataArea, RectangleEdge.LEFT)).thenReturn(400.0);
        when(rangeAxis.valueToJava2D(38.0, dataArea, RectangleEdge.LEFT)).thenReturn(380.0);
        when(rangeAxis.valueToJava2D(42.0, dataArea, RectangleEdge.LEFT)).thenReturn(420.0);

        CrosshairState crosshairState = mock(CrosshairState.class);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, times(2)).setPaint(customErrorPaint);
        verify(g2, times(2)).setStroke(customErrorStroke);

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(6)).draw(lineCaptor.capture());
        assertEquals(6, lineCaptor.getAllValues().size());

        // Removed ineffective spy verifications
    }

    @Test
    @DisplayName("drawItem with drawXError=true and drawYError=true, orientation HORIZONTAL, errorPaint and errorStroke null")
    public void TC10() throws Exception {
        int pass = 0;
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(true);
        renderer.setDrawYError(true);
        renderer.setErrorPaint(null);
        renderer.setErrorStroke(null);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;

        when(dataset.getItemCount(series)).thenReturn(1);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        when(dataset.getStartXValue(series, item)).thenReturn(30.0);
        when(dataset.getEndXValue(series, item)).thenReturn(35.0);
        when(dataset.getStartYValue(series, item)).thenReturn(48.0);
        when(dataset.getEndYValue(series, item)).thenReturn(52.0);
        when(dataset.getXValue(series, item)).thenReturn(30.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(30.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(300.0);
        when(domainAxis.valueToJava2D(35.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(350.0);

        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(500.0);
        when(rangeAxis.valueToJava2D(48.0, dataArea, RectangleEdge.LEFT)).thenReturn(480.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(520.0);

        CrosshairState crosshairState = mock(CrosshairState.class);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, times(2)).setPaint(any(Paint.class));
        verify(g2, times(2)).setStroke(any(Stroke.class));

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(6)).draw(lineCaptor.capture());
        assertEquals(6, lineCaptor.getAllValues().size());

        // Removed unnecessary verification and made appropriate fixes for unknown methods
    }
}