package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_1_3_Test {

    @Test
    @DisplayName("metaphone word with 'SCE' sequence converts correctly")
    public void TC41() {
        String txt = "scene";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        assertEquals("SNS", result, "'SCE' sequence should be converted correctly");
    }

    @Test
    @DisplayName("metaphone word with 'SCS' sequence converts correctly")
    public void TC42() {
        String txt = "scsious";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        assertEquals("SS", result, "'SCS' sequence should be converted correctly");
    }

    @Test
    @DisplayName("metaphone word with 'C' followed by 'H' and a vowel converts to 'X'")
    public void TC43() {
        String txt = "chandelier";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        assertEquals("XND", result, "'CH' followed by a vowel should be converted to 'X'");
    }

    @Test
    @DisplayName("metaphone word with 'C' preceded by 'S' not followed by front vowel does not convert to 'S'")
    public void TC44() {
        String txt = "sculpt";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        assertEquals("SKLPT", result, "'C' should not be converted to 'S' when not followed by front vowel");
    }

    @Test
    @DisplayName("metaphone word with multiple 'C's converts correctly")
    public void TC45() {
        String txt = "success";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        assertEquals("SKS", result, "Multiple 'C's should be handled without duplication");
    }

}