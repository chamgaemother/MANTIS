package org.apache.commons.compress.archivers.zip;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ZipArchiveEntry_equals_0_4_Test {

    @Test
    @DisplayName("equals() returns false when size differs")
    public void TC16() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry1.setSize(512L); // Correct usage with setSize
        entry2.setSize(1024L); // Correct usage with setSize

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals() returns false when central directory extra data differs")
    public void TC17() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        byte[] centralExtra1 = {1, 2, 3};
        byte[] centralExtra2 = {4, 5, 6};
        entry1.setCentralDirectoryExtra(centralExtra1);
        entry2.setCentralDirectoryExtra(centralExtra2);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

//     @Test
//     @DisplayName("equals() returns false when local file data extra differs")
//     public void TC18() {
        // GIVEN
//         ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
//         ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
//         byte[] localExtra1 = {7, 8, 9};
//         byte[] localExtra2 = {10, 11, 12};
//         entry1.setExtra(localExtra1); // Correct usage with setExtra
//         entry2.setExtra(localExtra2); // Correct usage with setExtra
// 
        // WHEN
//         boolean result = entry1.equals(entry2);
// 
        // THEN
//         assertFalse(result);
//     }

    @Test
    @DisplayName("equals() returns false when local header offset differs")
    public void TC19() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry1.setLocalHeaderOffset(100L);
        entry2.setLocalHeaderOffset(200L);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals() returns false when data offset differs")
    public void TC20() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry1.setDataOffset(300L);
        entry2.setDataOffset(400L);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }
}