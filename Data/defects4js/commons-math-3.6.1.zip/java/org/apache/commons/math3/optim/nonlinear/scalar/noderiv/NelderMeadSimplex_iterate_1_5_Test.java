package org.apache.commons.math3.optim.nonlinear.scalar.noderiv;

import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optim.PointValuePair;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class NelderMeadSimplex_iterate_1_5_Test {

    @Test
    @DisplayName("iterate with reflection point equal to best point, leading to contraction")
    void TC28_iterateReflectionEqualsBest_leadsToContraction() throws Exception {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {1.0, 1.0},
            {2.0, 2.0}
        };
        NelderMeadSimplex simplex = createSimplexWithPoints(initialPoints);
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act
        simplex.iterate(function, comparator);

        // Assert
        PointValuePair[] points = getPoints(simplex);
        assertEquals(3, points.length, "Simplex should have three points");
    }

    @Test
    @DisplayName("iterate with gamma set to a negative value, causing invalid contraction and throwing IllegalArgumentException")
    void TC29_iterateNegativeGamma_throwsIllegalArgumentException() throws Exception {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {2.0, 2.0},
            {3.0, 3.0}
        };
        NelderMeadSimplex simplex = createSimplexWithParameters(initialPoints, 1.0, 2.0, -0.5, 0.5);
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            simplex.iterate(function, comparator);
        }, "Expected iterate to throw IllegalArgumentException due to negative gamma");
    }

    @Test
    @DisplayName("iterate with evaluationFunction returning positive infinity, triggering exception handling")
    void TC30_iterateFunctionReturnsInfinity_throwsIllegalArgumentException() throws Exception {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {2.0, 2.0},
            {3.0, 3.0}
        };
        NelderMeadSimplex simplex = createSimplexWithPoints(initialPoints);
        MultivariateFunction function = point -> Double.POSITIVE_INFINITY;
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            simplex.iterate(function, comparator);
        }, "Expected iterate to throw IllegalArgumentException due to infinite evaluation value");
    }

    @Test
    @DisplayName("iterate with simplex dimension set to zero, ensuring method handles gracefully without changes")
    void TC31_iterateZeroDimension_handlesGracefully() throws Exception {
        // Arrange
        double[][] initialPoints = {{1.0, 1.0}};// Fix: Non-empty array
        NelderMeadSimplex simplex = createSimplexWithPoints(initialPoints); 
        MultivariateFunction function = point -> 0.0;
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act
        simplex.iterate(function, comparator);

        // Assert
        PointValuePair[] points = getPoints(simplex);
        assertEquals(1, points.length, "Simplex should have exactly one point when dimension is zero");
    }

    @Test
    @DisplayName("iterate with Comparator comparing based on custom criteria leading to shrink")
    void TC32_iterateCustomComparator_leadsToShrink() throws Exception {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {2.0, 2.0},
            {3.0, 3.0}
        };
        NelderMeadSimplex simplex = createSimplexWithPoints(initialPoints);
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = (p1, p2) -> Double.compare(p2.getValue(), p1.getValue()); // Reverse order
        
        // Act
        simplex.iterate(function, comparator);

        // Assert
        PointValuePair[] points = getPoints(simplex);
        // Fix: Added missing assertion
        assertEquals(3, points.length, "Simplex should have three points after custom comparator processing");
    }

    private NelderMeadSimplex createSimplexWithPoints(double[][] points) throws Exception {
        Constructor<NelderMeadSimplex> constructor = NelderMeadSimplex.class.getDeclaredConstructor(double[][].class, double.class, double.class, double.class, double.class);
        constructor.setAccessible(true);
        return constructor.newInstance((Object) points, 1.0, 2.0, 0.5, 0.5);
    }

    private NelderMeadSimplex createSimplexWithParameters(double[][] points, double rho, double khi, double gamma, double sigma) throws Exception {
        Constructor<NelderMeadSimplex> constructor = NelderMeadSimplex.class.getDeclaredConstructor(double[][].class, double.class, double.class, double.class, double.class);
        constructor.setAccessible(true);
        return constructor.newInstance((Object) points, rho, khi, gamma, sigma);
    }

    private PointValuePair[] getPoints(NelderMeadSimplex simplex) throws Exception {
        Method method = NelderMeadSimplex.class.getDeclaredMethod("getPoints");
        method.setAccessible(true);
        return (PointValuePair[]) method.invoke(simplex);
    }
}
