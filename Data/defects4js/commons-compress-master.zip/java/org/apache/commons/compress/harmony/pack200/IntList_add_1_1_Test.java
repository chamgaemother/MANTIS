package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class IntList_add_1_1_Test {

    @Test
    @DisplayName("Add an object when the internal array has available space without triggering a growth")
    void TC15_addWithoutGrowing() throws Exception {
        // Initialize IntList with capacity 10 and add 5 elements
        IntList list = new IntList(10);
        for(int i = 0; i < 5; i++) {
            list.add(i);
        }

        // Add object
        boolean result = list.add(100);

        // Assertions
        assertTrue(result, "Method should return true");
        assertEquals(6, list.size(), "Size should be incremented to 6");
        assertEquals(100, list.get(5), "Object should be added at index 5");
    }

    @Test
    @DisplayName("Add an object when the internal array has available space without triggering a growth (second scenario)")
    void TC16_addMultipleWithoutGrowing() throws Exception {
        // Initialize IntList with capacity 10 and add 3 elements
        IntList list = new IntList(10);
        for(int i = 0; i < 3; i++) {
            list.add(i);
        }

        // Add objects
        boolean result1 = list.add(200);
        boolean result2 = list.add(300);

        // Assertions
        assertTrue(result1, "First add should return true");
        assertTrue(result2, "Second add should return true");
        assertEquals(5, list.size(), "Size should be incremented to 5");
        assertEquals(200, list.get(3), "First object should be added at index 3");
        assertEquals(300, list.get(4), "Second object should be added at index 4");
    }

    @Test
    @DisplayName("Add an object when the internal array is full, triggering a growth of the array")
    void TC17_addWithGrowing() throws Exception {
        // Initialize IntList with capacity 2 and add 2 elements to fill it
        IntList list = new IntList(2);
        list.add(1);
        list.add(2);

        // Add object
        boolean result = list.add(300);

        // Assertions
        assertTrue(result, "Method should return true");
        assertEquals(3, list.size(), "Size should be incremented to 3");
        assertEquals(300, list.get(2), "Object should be added at index 2");

        // Verify internal array has grown using reflection
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] internalArray = (int[]) arrayField.get(list);
        assertTrue(internalArray.length > 2, "Array should have grown");
    }

    @Test
    @DisplayName("Add an object when the internal array is full, triggering a growth of the array (second scenario)")
    void TC18_addWithGrowingMultipleElements() throws Exception {
        // Initialize IntList with capacity 3 and add 3 elements to fill it
        IntList list = new IntList(3);
        list.add(10);
        list.add(20);
        list.add(30);

        // Add objects
        boolean result1 = list.add(40);
        boolean result2 = list.add(50);

        // Assertions
        assertTrue(result1, "First add should return true");
        assertTrue(result2, "Second add should return true");
        assertEquals(5, list.size(), "Size should be incremented to 5");
        assertEquals(40, list.get(3), "First object should be added at index 3");
        assertEquals(50, list.get(4), "Second object should be added at index 4");

        // Verify internal array has grown using reflection
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] internalArray = (int[]) arrayField.get(list);
        assertTrue(internalArray.length > 3, "Array should have grown appropriately");
    }
}