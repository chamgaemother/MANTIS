package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Field;

import org.apache.commons.jxpath.ri.Compiler;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XPathParser_CoreFunctionName_0_4_Test {

    private static XPathParser createXPathParser() {
        // Create a dummy Reader to instantiate XPathParser
        Reader reader = new StringReader("");
        return new XPathParser(reader);
    }

    private static void setJj_ntKind(Object xpathParser, int kindValue) throws Exception {
        // Access and modify the private jj_nt field using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(xpathParser);

        // Access and modify the private 'kind' field of jj_nt
        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, kindValue);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_STRING_LENGTH returns Compiler.FUNCTION_STRING_LENGTH")
    public void TC16() throws Exception {
        XPathParser xpathParser = createXPathParser();

        setJj_ntKind(xpathParser, Compiler.FUNCTION_STRING_LENGTH);

        int result = xpathParser.CoreFunctionName();

        assertEquals(Compiler.FUNCTION_STRING_LENGTH, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_NORMALIZE_SPACE returns Compiler.FUNCTION_NORMALIZE_SPACE")
    public void TC17() throws Exception {
        XPathParser xpathParser = createXPathParser();

        setJj_ntKind(xpathParser, Compiler.FUNCTION_NORMALIZE_SPACE);

        int result = xpathParser.CoreFunctionName();

        assertEquals(Compiler.FUNCTION_NORMALIZE_SPACE, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_TRANSLATE returns Compiler.FUNCTION_TRANSLATE")
    public void TC18() throws Exception {
        XPathParser xpathParser = createXPathParser();

        setJj_ntKind(xpathParser, Compiler.FUNCTION_TRANSLATE);

        int result = xpathParser.CoreFunctionName();

        assertEquals(Compiler.FUNCTION_TRANSLATE, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_BOOLEAN returns Compiler.FUNCTION_BOOLEAN")
    public void TC19() throws Exception {
        XPathParser xpathParser = createXPathParser();

        setJj_ntKind(xpathParser, Compiler.FUNCTION_BOOLEAN);

        int result = xpathParser.CoreFunctionName();

        assertEquals(Compiler.FUNCTION_BOOLEAN, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_NOT returns Compiler.FUNCTION_NOT")
    public void TC20() throws Exception {
        XPathParser xpathParser = createXPathParser();

        setJj_ntKind(xpathParser, Compiler.FUNCTION_NOT);

        int result = xpathParser.CoreFunctionName();

        assertEquals(Compiler.FUNCTION_NOT, result);
    }
}