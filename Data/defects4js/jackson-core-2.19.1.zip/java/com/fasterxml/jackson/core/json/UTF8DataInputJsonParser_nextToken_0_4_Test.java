package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

public class UTF8DataInputJsonParser_nextToken_0_4_Test {
    
    @Test
    @DisplayName("nextToken() returns VALUE_TRUE when 'true' is encountered")
    public void TC16_nextToken_returns_VALUE_TRUE_for_true_input() throws IOException {
        // Arrange
        String json = "true";
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(json);
        
        // Act
        JsonToken result = parser.nextToken();
        
        // Assert
        assertEquals(JsonToken.VALUE_TRUE, result, "The parser should return VALUE_TRUE when 'true' is encountered");
    }
}