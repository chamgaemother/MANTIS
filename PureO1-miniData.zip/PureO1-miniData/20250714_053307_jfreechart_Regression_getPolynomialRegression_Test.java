package org.jfree.data.statistics;

import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class RegressionTest {

    @Test
    @DisplayName("getPolynomialRegression should throw NullPointerException for null dataset")
    void testGetPolynomialRegression_NullDataset() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            Regression.getPolynomialRegression(null, 0, 1);
        });
        assertEquals("dataset", exception.getMessage());
    }

    @Test
    @DisplayName("getPolynomialRegression should throw IllegalArgumentException for insufficient data")
    void testGetPolynomialRegression_InsufficientData() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(2);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Regression.getPolynomialRegression(dataset, 0, 2);
        });
        assertEquals("Not enough data.", exception.getMessage());
    }

    @Test
    @DisplayName("getPolynomialRegression should throw IllegalArgumentException when valid items less than order+1")
    void testGetPolynomialRegression_ValidItemsInsufficient() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(3);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(2.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(3.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(3.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(Double.NaN);
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Regression.getPolynomialRegression(dataset, 0, 2);
        });
        assertEquals("Not enough data.", exception.getMessage());
    }

    @Test
    @DisplayName("getPolynomialRegression should return correct coefficients for linear regression")
    void testGetPolynomialRegression_Linear() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(3);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(2.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(2.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(3.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(3.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(5.0);
        
        double[] result = Regression.getPolynomialRegression(dataset, 0, 1);
        assertEquals(2, result.length);
        assertEquals(1.0, result[0], 1e-6);
        assertEquals(1.5, result[1], 1e-6);
    }

    @Test
    @DisplayName("getPolynomialRegression should return correct coefficients for quadratic regression")
    void testGetPolynomialRegression_Quadratic() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(3);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(2.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(2.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(5.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(3.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(10.0);
        
        double[] result = Regression.getPolynomialRegression(dataset, 0, 2);
        assertEquals(3, result.length);
        assertEquals(1.0, result[0], 1e-6);
        assertEquals(0.5, result[1], 1e-6);
        assertEquals(1.0, result[2], 1e-6);
        assertTrue(result[3] >= 0 && result[3] <= 1);
    }

    @Test
    @DisplayName("getPolynomialRegression should handle zero pivot by swapping rows")
    void testGetPolynomialRegression_ZeroPivot() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(3);
        // Create a scenario that causes a zero pivot in the first step
        // For simplicity, use identical x values which will make sxx zero
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(2.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(3.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(2.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(5.0);
        
        // This should throw due to sxx = 0 for x=1.0 duplicated
        Exception exception = assertThrows(ArithmeticException.class, () -> {
            Regression.getPolynomialRegression(dataset, 0, 1);
        });
        // The actual method might return NaN or throw, depending on implementation
    }

    @Test
    @DisplayName("getPolynomialRegression should throw IllegalArgumentException for negative order")
    void testGetPolynomialRegression_NegativeOrder() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(3);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(2.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(2.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(3.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(3.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(5.0);
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Regression.getPolynomialRegression(dataset, 0, -1);
        });
        // The method does not explicitly check for negative order, may proceed or fail differently
    }

    @Test
    @DisplayName("getPolynomialRegression should handle order zero (constant function)")
    void testGetPolynomialRegression_OrderZero() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(3);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(4.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(2.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(4.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(3.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(4.0);
        
        double[] result = Regression.getPolynomialRegression(dataset, 0, 0);
        assertEquals(1, result.length);
        assertEquals(4.0, result[0], 1e-6);
        assertTrue(result[1] >= 0 && result[1] <= 1); // R2
    }

    @Test
    @DisplayName("getPolynomialRegression should handle dataset with exactly order+1 valid data points")
    void testGetPolynomialRegression_ExactDataPoints() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        int order = 2;
        int items = order + 1;
        Mockito.when(dataset.getItemCount(0)).thenReturn(items);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(0.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(3.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(2.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(7.0);
        
        double[] result = Regression.getPolynomialRegression(dataset, 0, order);
        assertEquals(order + 2, result.length);
        assertEquals(1.0, result[0], 1e-6);
        assertEquals(1.0, result[1], 1e-6);
        assertEquals(2.0, result[2], 1e-6);
        assertTrue(result[3] >= 0 && result[3] <= 1);
    }

    @Test
    @DisplayName("getPolynomialRegression should calculate correct R2")
    void testGetPolynomialRegression_R2Calculation() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(4);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(2.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(4.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(3.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(9.0);
        Mockito.when(dataset.getXValue(0, 3)).thenReturn(4.0);
        Mockito.when(dataset.getYValue(0, 3)).thenReturn(16.0);
        
        double[] result = Regression.getPolynomialRegression(dataset, 0, 2);
        assertEquals(3, result.length);
        // y = a + b*x + c*x^2, expected a=0, b=0, c=1
        assertEquals(0.0, result[0], 1e-6);
        assertEquals(0.0, result[1], 1e-6);
        assertEquals(1.0, result[2], 1e-6);
        assertEquals(1.0, result[3], 1e-6); // Perfect fit
    }

    @Test
    @DisplayName("getPolynomialRegression should ignore NaN values and compute correctly")
    void testGetPolynomialRegression_IgnoresNaN() {
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getItemCount(0)).thenReturn(5);
        Mockito.when(dataset.getXValue(0, 0)).thenReturn(1.0);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(2.0);
        Mockito.when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(3.0);
        Mockito.when(dataset.getXValue(0, 2)).thenReturn(3.0);
        Mockito.when(dataset.getYValue(0, 2)).thenReturn(6.0);
        Mockito.when(dataset.getXValue(0, 3)).thenReturn(4.0);
        Mockito.when(dataset.getYValue(0, 3)).thenReturn(Double.NaN);
        Mockito.when(dataset.getXValue(0, 4)).thenReturn(5.0);
        Mockito.when(dataset.getYValue(0, 4)).thenReturn(10.0);
        
        double[] result = Regression.getPolynomialRegression(dataset, 0, 1);
        assertEquals(2, result.length);
        // The valid points are (1,2), (3,6), (5,10)
        // Linear regression should be y = 0 + 2x
        assertEquals(0.0, result[0], 1e-6);
        assertEquals(2.0, result[1], 1e-6);
    }
}