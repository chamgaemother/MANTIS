package org.joda.time.format;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Locale;

import org.joda.time.Chronology;
import org.joda.time.DateTimeFieldType;
import org.joda.time.DateTimeZone;
import org.joda.time.IllegalInstantException;
import org.joda.time.chrono.ISOChronology;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.joda.time.format.DateTimeParserBucket;

public class DateTimeParserBucket_computeMillis_2_1_Test {

    @Test
    @DisplayName("computeMillis with iSavedFieldsShared=false, iSavedFieldsCount >0, $i7 <0, $i8 <=0, no offset and zone set")
    public void TC18_computeMillis_Scenario() throws Exception {
        // GIVEN
        long initialMillis = 1609459200000L; // 2021-01-01T00:00:00Z
        Chronology chrono = ISOChronology.getInstanceUTC();
        Locale locale = Locale.US;
        int defaultYear = 2000;
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, defaultYear);

        // Using Reflection to set iSavedFieldsShared=false and iSavedFieldsCount=5
        Field sharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
        sharedField.setAccessible(true);
        sharedField.setBoolean(bucket, false);

        Field countField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
        countField.setAccessible(true);
        countField.setInt(bucket, 5);

        // Saving 5 fields
        bucket.saveField(DateTimeFieldType.year(), 2021);
        bucket.saveField(DateTimeFieldType.monthOfYear(), 3);
        bucket.saveField(DateTimeFieldType.dayOfMonth(), 14);
        bucket.saveField(DateTimeFieldType.hourOfDay(), 15);
        bucket.saveField(DateTimeFieldType.minuteOfHour(), 30);

        // WHEN
        long millis = bucket.computeMillis(false, null);

        // THEN
        // Expected millis corresponds to 2021-03-14T15:30:00Z
        Chronology expectedChrono = ISOChronology.getInstanceUTC();
        long expectedMillis = expectedChrono.year().set(chrono.monthOfYear().set(
                chrono.dayOfMonth().set(chrono.hourOfDay().set(
                        chrono.minuteOfHour().set(initialMillis, 30), 15), 14), 3), 2021);
        assertEquals(expectedMillis, millis, "Millis should be correctly set after applying all saved fields.");
    }

    @Test
    @DisplayName("computeMillis with z1=true and iZone causing IllegalInstantException due to time zone transition")
    public void TC19_computeMillis_ExceptionScenario() throws Exception {
        // GIVEN
        long initialMillis = 1615708800000L; // 2021-03-14T02:00:00Z
        Chronology chrono = ISOChronology.getInstanceUTC();
        Locale locale = Locale.US;
        int defaultYear = 2000;
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, defaultYear);

        // Set iOffset to null using reflection
        Field offsetField = DateTimeParserBucket.class.getDeclaredField("iOffset");
        offsetField.setAccessible(true);
        offsetField.set(bucket, null);

        // Set iZone to a timezone with DST transition, e.g., America/New_York
        DateTimeZone timeZoneWithTransition = DateTimeZone.forID("America/New_York");
        bucket.setZone(timeZoneWithTransition);

        // Using Reflection to set iSavedFieldsShared=false and iSavedFieldsCount=3
        Field sharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
        sharedField.setAccessible(true);
        sharedField.setBoolean(bucket, false);

        Field countField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
        countField.setAccessible(true);
        countField.setInt(bucket, 3);

        // Saving 3 fields
        bucket.saveField(DateTimeFieldType.year(), 2021);
        bucket.saveField(DateTimeFieldType.monthOfYear(), 3);
        bucket.saveField(DateTimeFieldType.dayOfMonth(), 14);

        // WHEN & THEN
        IllegalInstantException exception = assertThrows(IllegalInstantException.class, () -> {
            bucket.computeMillis(false, "2021-03-14");
        }, "Expected computeMillis to throw IllegalInstantException due to time zone offset transition.");

        assertTrue(exception.getMessage().contains("Illegal instant due to time zone offset transition"), "Exception message should indicate time zone offset transition.");
    }

    @Test
    @DisplayName("computeMillis with multiple iterations in setting millis (iSavedFieldsCount=5)")
    public void TC20_computeMillis_MultipleIterations() throws Exception {
        // GIVEN
        long initialMillis = 1609459200000L; // 2021-01-01T00:00:00Z
        Chronology chrono = ISOChronology.getInstance();
        Locale locale = Locale.UK;
        int defaultYear = 2000;
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, defaultYear);

        // Using Reflection to set iSavedFieldsShared=false and iSavedFieldsCount=5
        Field sharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
        sharedField.setAccessible(true);
        sharedField.setBoolean(bucket, false);

        Field countField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
        countField.setAccessible(true);
        countField.setInt(bucket, 5);

        // Saving 5 distinct fields
        bucket.saveField(DateTimeFieldType.year(), 2022);
        bucket.saveField(DateTimeFieldType.monthOfYear(), 12);
        bucket.saveField(DateTimeFieldType.dayOfMonth(), 25);
        bucket.saveField(DateTimeFieldType.hourOfDay(), 10);
        bucket.saveField(DateTimeFieldType.minuteOfHour(), 45);

        // WHEN
        long millis = bucket.computeMillis(false, null);

        // THEN
        // Expected millis corresponds to 2022-12-25T10:45:00Z
        Chronology expectedChrono = ISOChronology.getInstance();
        long expectedMillis = expectedChrono.year().set(chrono.monthOfYear().set(
                chrono.dayOfMonth().set(chrono.hourOfDay().set(
                        chrono.minuteOfHour().set(initialMillis, 45), 10), 25), 12), 2022);
        assertEquals(expectedMillis, millis, "Millis should be correctly set after applying all fields.");
    }

    @Test
    @DisplayName("computeMillis with iSavedFieldsCount >0 but no fields set, leading to default year application")
    public void TC21_computeMillis_DefaultYearApplication() throws Exception {
        // GIVEN
        long initialMillis = 1609459200000L; // 2021-01-01T00:00:00Z
        Chronology chrono = ISOChronology.getInstanceUTC();
        Locale locale = Locale.CANADA;
        int defaultYear = 1999;
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, defaultYear);

        // Using Reflection to set iSavedFieldsShared=false and iSavedFieldsCount=1
        Field sharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
        sharedField.setAccessible(true);
        sharedField.setBoolean(bucket, false);

        Field countField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
        countField.setAccessible(true);
        countField.setInt(bucket, 1);

        // No meaningful fields set

        // WHEN
        long millis = bucket.computeMillis(false, null);

        // THEN
        // Since no meaningful fields are set, default year should be applied
        Chronology expectedChrono = ISOChronology.getInstanceUTC();
        long expectedMillis = expectedChrono.year().set(initialMillis, defaultYear);
        assertEquals(expectedMillis, millis, "Millis should be adjusted by default year.");
    }

    @Test
    @DisplayName("computeMillis with iSavedFieldsShared=true and iSavedFieldsCount=0, expecting immediate return of iMillis")
    public void TC22_computeMillis_ImmediateReturn() throws Exception {
        // GIVEN
        long initialMillis = 1609459200000L; // 2021-01-01T00:00:00Z
        Chronology chrono = ISOChronology.getInstanceUTC();
        Locale locale = Locale.GERMANY;
        int defaultYear = 2000;
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, defaultYear);

        // Using Reflection to set iSavedFieldsShared=true and iSavedFieldsCount=0
        Field sharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
        sharedField.setAccessible(true);
        sharedField.setBoolean(bucket, true);

        Field countField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
        countField.setAccessible(true);
        countField.setInt(bucket, 0);

        // WHEN
        long millis = bucket.computeMillis(false, null);

        // THEN
        assertEquals(initialMillis, millis, "Millis should equal iMillis without modification.");
    }
}