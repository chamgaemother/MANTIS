package org.jfree.chart.plot;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.util.ShadowGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class CategoryPlot_draw_1_2_Test {

    private CategoryPlot plot;
    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotState state;
    private PlotRenderingInfo info;

    @BeforeEach
    void setUp() {
        plot = new CategoryPlot();
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(); // Ensuring area is not null
        anchor = new Point2D.Double(); // Ensuring anchor is not null
        state = new PlotState();
        info = new PlotRenderingInfo(null);
    }

    @Test
    @DisplayName("Draw method handles presence of annotations by rendering them")
    void TC21_draw_handlesAnnotations() throws Exception {
        // GIVEN
        CategoryAnnotation annotation = mock(CategoryAnnotation.class);
        plot.addAnnotation(annotation);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(annotation, times(1)).draw(eq(g2), eq(plot), eq(area), any(), any());
    }

//     @Test
//     @DisplayName("Draw method creates and draws drop shadow when shadowGenerator is present and not suppressed")
//     void TC22_draw_createsAndDrawsShadow() throws Exception {
        // GIVEN
//         ShadowGenerator shadowGenerator = mock(ShadowGenerator.class);
//         plot.setShadowGenerator(shadowGenerator);
// 
        // Setting up the suppression rendering key properly
//         when(g2.getRenderingHint(JFreeChart.KEY_SUPPRESS_SHADOW_GENERATION)).thenReturn(null);
// 
//         BufferedImage shadowImage = mock(BufferedImage.class);
//         when(shadowGenerator.createDropShadow(any(BufferedImage.class))).thenReturn(shadowImage);
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
//         verify(shadowGenerator, times(1)).createDropShadow(any(BufferedImage.class));
//         verify(g2, times(1)).drawImage(eq(shadowImage), anyInt(), anyInt(), any());
//     }

    @Test
    @DisplayName("Draw method skips drop shadow when shadowGenerator is null")
    void TC23_draw_skipsShadowWhenShadowGeneratorIsNull() throws Exception {
        // GIVEN
        plot.setShadowGenerator(null);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(g2, never()).drawImage(any(), anyInt(), anyInt(), any());
    }

    @Test
    @DisplayName("Draw method handles outline visibility being enabled by drawing outline")
    void TC24_draw_drawsOutlineWhenEnabled() throws Exception {
        // GIVEN
        plot.setOutlineVisible(true);
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        plot.setRenderer(renderer);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(renderer, times(1)).drawOutline(eq(g2), eq(plot), eq(area));
    }

    @Test
    @DisplayName("Draw method handles outline visibility being disabled by skipping outline")
    void TC25_draw_skipsOutlineWhenDisabled() throws Exception {
        // GIVEN
        plot.setOutlineVisible(false);
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        plot.setRenderer(renderer);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(renderer, never()).drawOutline(any(Graphics2D.class), any(CategoryPlot.class), any(Rectangle2D.class));
    }
}