package org.jfree.chart.title;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PaintScaleLegend_draw_0_2_Test {

    @Mock
    private Graphics2D g2;

    @Mock
    private Rectangle2D area;

    @Mock
    private Object param;

    @Mock
    private PaintScale scale;

    @Mock
    private ValueAxis axis;

    @InjectMocks
    private PaintScaleLegend legend = new PaintScaleLegend(scale, axis);

    @Test
    @DisplayName("draw method where axis is mocked")
    public void TC06_draw_with_position_Right() {
        // GIVEN
        legend.setBackgroundPaint(null);
        legend.setSubdivisionCount(5);
        legend.setStripOutlineVisible(false);
        legend.setScale(scale);  // Ensure scale is initialized
        legend.setAxis(axis);  // Ensure axis is initialized

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        // Verify that background is not filled
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any(Rectangle2D.class));
    }

//     @Test
//     @DisplayName("draw method with isStripOutlineVisible true, drawing strip outlines")
//     public void TC07_draw_with_stripOutlineVisible_true() {
        // GIVEN
//         legend.setStripOutlineVisible(true);
//         legend.setBackgroundPaint(null);
//         legend.setSubdivisions(5);
// 
        // WHEN
//         Object result = legend.draw(g2, area, param);
// 
        // THEN
//         assertNull(result);
        // Verify that strip outlines are drawn
//         verify(g2, times(1)).setPaint(any());
//         verify(g2, times(1)).draw(any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("draw method with isStripOutlineVisible false, skipping strip outlines")
//     public void TC08_draw_with_stripOutlineVisible_false() {
        // GIVEN
//         legend.setStripOutlineVisible(false);
//         legend.setBackgroundPaint(null);
//         legend.setSubdivisions(5);
// 
        // WHEN
//         Object result = legend.draw(g2, area, param);
// 
        // THEN
//         assertNull(result);
        // Verify that strip outlines are not drawn
//         verify(g2, never()).draw(any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("draw method with zero subdivisions, no strips drawn")
//     public void TC09_draw_with_zero_subdivisions() {
        // GIVEN
//         legend.setSubdivisions(0);
//         legend.setBackgroundPaint(null);
//         legend.setStripOutlineVisible(false);
// 
        // WHEN
//         Object result = legend.draw(g2, area, param);
// 
        // THEN
//         assertNull(result);
        // Verify that no strips are drawn
//         verify(g2, never()).fill(any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("draw method with one subdivision, single strip drawn")
//     public void TC10_draw_with_one_subdivision() {
        // GIVEN
//         legend.setSubdivisions(1);
//         legend.setBackgroundPaint(null);
//         legend.setStripOutlineVisible(false);
// 
        // WHEN
//         Object result = legend.draw(g2, area, param);
// 
        // THEN
//         assertNull(result);
        // Verify that one strip is drawn
//         verify(g2, times(1)).fill(any(Rectangle2D.class));
//     }
}