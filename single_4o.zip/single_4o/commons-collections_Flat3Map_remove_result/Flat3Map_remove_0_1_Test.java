package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_remove_0_1_Test {
    
    @Test
    @DisplayName("Remove key when delegateMap is not null")
    public void testRemoveWhenDelegateMapIsNotNull() throws Exception {
        // Setup initial Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set a non-null delegateMap with an entry
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        java.util.HashMap<Object, Object> delegateMap = new java.util.HashMap<>();
        Object key = new Object();
        Object value = new Object();
        delegateMap.put(key, value);
        delegateMapField.set(map, delegateMap);

        // Call the remove method and assert the expected result
        Object result = map.remove(key);
        assertEquals(value, result);
    }

    @Test
    @DisplayName("Remove when size is zero")
    public void testRemoveWhenSizeIsZero() throws Exception {
        // Setup initial Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();
        
        // Ensure the size is zero
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);
        
        // Call the remove method and assert the expected result
        Object result = map.remove(new Object());
        assertNull(result);
    }

    @Test
    @DisplayName("Remove with null key when size is greater than zero, key matches at position 3")
    public void testRemoveWithNullKeyMatchesPosition3() throws Exception {
        // Setup initial Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set 3 elements, last key is null
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        sizeField.setAccessible(true);
        key3Field.setAccessible(true);
        value3Field.setAccessible(true);

        sizeField.setInt(map, 3);
        key3Field.set(map, null);
        Object value = new Object();
        value3Field.set(map, value);

        // Call the remove method and assert the expected result
        Object result = map.remove(null);
        assertEquals(value, result);
    }

    @Test
    @DisplayName("Remove with null key when size is greater than zero, no matching key")
    public void testRemoveWithNullKeyNoMatch() throws Exception {
        // Setup initial Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set 3 elements, none match null key
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        sizeField.setAccessible(true);
        key1Field.setAccessible(true);
        key2Field.setAccessible(true);
        key3Field.setAccessible(true);

        sizeField.setInt(map, 3);
        key1Field.set(map, new Object());
        key2Field.set(map, new Object());
        key3Field.set(map, new Object());

        // Call the remove method and assert the expected result
        Object result = map.remove(null);
        assertNull(result);
    }

    @Test
    @DisplayName("Remove with non-null key when size is greater than zero, key matches hash at position 2")
    public void testRemoveWithNonNullKeyMatchesHashAtPosition2() throws Exception {
        // Setup initial Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set 2 elements, matching key placed at position 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        sizeField.setAccessible(true);
        key2Field.setAccessible(true);
        value2Field.setAccessible(true);
        hash2Field.setAccessible(true);

        sizeField.setInt(map, 2);
        Object key = new Object();
        Object value = new Object();
        key2Field.set(map, key);
        value2Field.set(map, value);
        hash2Field.setInt(map, key.hashCode());

        // Call the remove method and assert the expected result
        Object result = map.remove(key);
        assertEquals(value, result);
    }
}