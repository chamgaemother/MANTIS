package org.apache.commons.collections4.functors;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

public class ComparatorPredicate_test_0_3_Test {

    @Test
    @DisplayName("Criterion is invalid, expect IllegalStateException to be thrown")
    void testInvalidCriterion() throws NoSuchFieldException, IllegalAccessException {
        // Set up a ComparatorPredicate with invalid criterion via reflection
        ComparatorPredicate<Object> comparatorPredicate = new ComparatorPredicate<>((a, b) -> 0, new Object(), null);

        Field criterionField = ComparatorPredicate.class.getDeclaredField("criterion");
        criterionField.setAccessible(true);
        criterionField.set(comparatorPredicate, null); // Set to an invalid enum value (null in this case)

        // Expect IllegalStateException
        assertThrows(IllegalStateException.class, () -> comparatorPredicate.test(new Object()));
    }
}