package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.type.SimpleType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ObjectArraySerializer_createContextual_0_3_Test {

    @Test
    @DisplayName("_staticTyping is true but elementType is JavaLangObject")
    public void TC11() throws Exception {
        // GIVEN
        SerializerProvider serializers = mock(SerializerProvider.class);
        BeanProperty property = mock(BeanProperty.class);
        JavaType elementType = SimpleType.constructUnsafe(Object.class);

        ObjectArraySerializer serializer = new ObjectArraySerializer(elementType, true, null, null);

        // Accessing private field _elementSerializer using reflection
        Field elementSerializerField = ObjectArraySerializer.class.getDeclaredField("_elementSerializer");
        elementSerializerField.setAccessible(true);
        JsonSerializer<?> defaultElementSerializer = (JsonSerializer<?>) elementSerializerField.get(serializer);

        // WHEN
        JsonSerializer<?> result = serializer.createContextual(serializers, property);

        // THEN
        Field resultElementSerializerField = ObjectArraySerializer.class.getDeclaredField("_elementSerializer");
        resultElementSerializerField.setAccessible(true);
        JsonSerializer<?> resultElementSerializer = (JsonSerializer<?>) resultElementSerializerField.get(result);

        assertEquals(defaultElementSerializer, resultElementSerializer, "Default element serializer is used");
    }

//     @Test
//     @DisplayName("findContextualConvertingSerializer returns null, _staticTyping=false, and elementType is JavaLangObject")
//     public void TC12() throws Exception {
        // GIVEN
//         SerializerProvider serializers = mock(SerializerProvider.class);
//         BeanProperty property = mock(BeanProperty.class);
//         JavaType elementType = SimpleType.constructUnsafe(Object.class);
//         ObjectArraySerializer serializer = new ObjectArraySerializer(elementType, false, null, null);
// 
//         when(serializers.findContextualConvertingSerializer(eq(property), any())).thenReturn(null);
// 
        // Accessing private field _elementSerializer using reflection
//         Field elementSerializerField = ObjectArraySerializer.class.getDeclaredField("_elementSerializer");
//         elementSerializerField.setAccessible(true);
//         JsonSerializer<?> defaultElementSerializer = (JsonSerializer<?>) elementSerializerField.get(serializer);
// 
        // WHEN
//         JsonSerializer<?> result = serializer.createContextual(serializers, property);
// 
        // THEN
//         Field resultElementSerializerField = ObjectArraySerializer.class.getDeclaredField("_elementSerializer");
//         resultElementSerializerField.setAccessible(true);
//         JsonSerializer<?> resultElementSerializer = (JsonSerializer<?>) resultElementSerializerField.get(result);
// 
//         assertEquals(defaultElementSerializer, resultElementSerializer, "Default element serializer is used without finding content serializer");
//     }

//     @Test
//     @DisplayName("findContextualConvertingSerializer returns null, _staticTyping=false, and elementType is not JavaLangObject")
//     public void TC13() throws Exception {
        // GIVEN
//         SerializerProvider serializers = mock(SerializerProvider.class);
//         BeanProperty property = mock(BeanProperty.class);
//         JavaType elementType = SimpleType.constructUnsafe(Integer.class);
//         ObjectArraySerializer serializer = new ObjectArraySerializer(elementType, false, null, null);
// 
//         when(serializers.findContextualConvertingSerializer(eq(property), any())).thenReturn(null);
//         JsonSerializer<?> contentSerializer = mock(JsonSerializer.class);
//         when(serializers.findContentValueSerializer(eq(elementType), eq(property))).thenReturn(contentSerializer);
// 
        // WHEN
//         JsonSerializer<?> result = serializer.createContextual(serializers, property);
// 
        // THEN
//         Field resultElementSerializerField = ObjectArraySerializer.class.getDeclaredField("_elementSerializer");
//         resultElementSerializerField.setAccessible(true);
//         JsonSerializer<?> resultElementSerializer = (JsonSerializer<?>) resultElementSerializerField.get(result);
// 
//         assertEquals(contentSerializer, resultElementSerializer, "Content value serializer based on elementType is used");
//     }

//     @Test
//     @DisplayName("findContextualConvertingSerializer returns null, _staticTyping=true, and elementType is not JavaLangObject")
//     public void TC14() throws Exception {
        // GIVEN
//         SerializerProvider serializers = mock(SerializerProvider.class);
//         BeanProperty property = mock(BeanProperty.class);
//         JavaType elementType = SimpleType.constructUnsafe(Integer.class);
//         ObjectArraySerializer serializer = new ObjectArraySerializer(elementType, true, null, null);
// 
//         when(serializers.findContextualConvertingSerializer(eq(property), any())).thenReturn(null);
// 
        // Accessing private field _elementSerializer using reflection
//         Field elementSerializerField = ObjectArraySerializer.class.getDeclaredField("_elementSerializer");
//         elementSerializerField.setAccessible(true);
//         JsonSerializer<?> defaultElementSerializer = (JsonSerializer<?>) elementSerializerField.get(serializer);
// 
        // WHEN
//         JsonSerializer<?> result = serializer.createContextual(serializers, property);
// 
        // THEN
//         Field resultElementSerializerField = ObjectArraySerializer.class.getDeclaredField("_elementSerializer");
//         resultElementSerializerField.setAccessible(true);
//         JsonSerializer<?> resultElementSerializer = (JsonSerializer<?>) resultElementSerializerField.get(result);
// 
//         assertEquals(defaultElementSerializer, resultElementSerializer, "Default element serializer is used despite specific elementType");
//     }
}