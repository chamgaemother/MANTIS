package org.apache.commons.math3.stat.inference;

import org.apache.commons.math3.exception.TooManyIterationsException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class KolmogorovSmirnovTest_pelzGood_0_1_Test {

    @Test
    @DisplayName("Valid input with d=1.0 and n=10 where all loops converge before maximum iterations")
    public void TC01_pelzGood_normal_execution() {
        // Given
        double d = 1.0;
        int n = 10;

        // When
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(d, n);

        // Then
        assertTrue(result > 0, "Result should be a positive double value.");
    }

    @Test
    @DisplayName("Input with d=0.0 and n=1 to test handling of zero distance")
    public void TC02_pelzGood_zero_distance() {
        // Given
        double d = 0.0;
        int n = 1;

        // When
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(d, n);

        // Then
        assertEquals(0.0, result, "Result should be zero when d is zero.");
    }

    @Test
    @DisplayName("Input with n=0 to verify handling of zero sample size")
    public void TC03_pelzGood_zero_sample_size() {
        // Given
        double d = 1.0;
        int n = 0;

        // When & Then
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        assertThrows(TooManyIterationsException.class, () -> {
            ksTest.pelzGood(d, n);
        }, "Should throw TooManyIterationsException when n is zero.");
    }

    @Test
    @DisplayName("Input causing i11 loop to reach maximum iterations, triggering TooManyIterationsException")
    public void TC04_pelzGood_i11_max_iterations() {
        // Given
        double d = Double.MAX_VALUE; // Large value to prevent loop convergence
        int n = Integer.MAX_VALUE;  // Large sample size to prevent loop convergence

        // When & Then
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        assertThrows(TooManyIterationsException.class, () -> {
            ksTest.pelzGood(d, n);
        }, "Should throw TooManyIterationsException due to i11 loop reaching maximum iterations.");
    }

    @Test
    @DisplayName("Input causing i12 loop to reach maximum iterations, triggering TooManyIterationsException")
    public void TC05_pelzGood_i12_max_iterations() {
        // Given
        double d = 1.0; // Specific value that causes i12 loop to not converge (assumed)
        int n = Integer.MAX_VALUE; // Specific value to prevent loop convergence

        // When & Then
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        assertThrows(TooManyIterationsException.class, () -> {
            ksTest.pelzGood(d, n);
        }, "Should throw TooManyIterationsException due to i12 loop reaching maximum iterations.");
    }
}