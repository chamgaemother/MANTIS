package com.fasterxml.jackson.databind.deser;
// import com.fasterxml.jackson.databind.PropertyName;
// 
// import com.fasterxml.jackson.databind.*;
// import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
// import com.fasterxml.jackson.databind.util.PropertyName;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// import java.lang.reflect.Field;
// import java.lang.reflect.Method;
// import java.util.List;
// import java.util.Map;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// /**
//  * Generated JUnit 5 tests for BeanDeserializerBuilder#buildBuilderBased
//  */
public class BeanDeserializerBuilder_buildBuilderBased_2_1_Test {
// 
//     @Test
//     @DisplayName("buildBuilderBased reports bad definition when _buildMethod is present with incompatible return type and expBuildMethodName is not empty")
//     void TC20_buildBuilderBased_with_incompatible_build_method_return_type_and_non_empty_build_method_name() throws Exception {
        // Arrange
//         DeserializationContext mockContext = Mockito.mock(DeserializationContext.class);
//         DeserializationConfig mockConfig = Mockito.mock(DeserializationConfig.class);
//         Mockito.when(mockContext.getConfig()).thenReturn(mockConfig);
// 
//         BeanDescription mockBeanDesc = Mockito.mock(BeanDescription.class);
//         JavaType mockBeanType = Mockito.mock(JavaType.class);
//         Mockito.when(mockBeanDesc.getType()).thenReturn(mockBeanType);
// 
        // Stub reportBadDefinition to throw JsonMappingException
//         Mockito.doThrow(new JsonMappingException(mockContext, "Builder class ... does not have build method...")).when(mockContext).reportBadDefinition(Mockito.any(JavaType.class), Mockito.anyString());
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
// 
        // Mock AnnotatedMethod with incompatible return type
//         AnnotatedMethod mockAnnotatedMethod = Mockito.mock(AnnotatedMethod.class);
//         Mockito.when(mockAnnotatedMethod.getRawReturnType()).thenReturn(String.class); // Incompatible return type
// 
        // Use reflection to set _buildMethod
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, mockAnnotatedMethod);
// 
//         JavaType incompatibleType = Mockito.mock(JavaType.class);
//         Mockito.when(incompatibleType.getRawClass()).thenReturn(Integer.class); // Expected return type
// 
        // Act & Assert
//         JsonMappingException exception = assertThrows(JsonMappingException.class, () -> {
//             builder.buildBuilderBased(incompatibleType, "build");
//         });
// 
//         assertTrue(exception.getMessage().contains("Builder class ... does not have build method"), "Exception message should indicate bad definition due to incompatible build method.");
//     }
// 
//     @Test
//     @DisplayName("buildBuilderBased correctly handles multiple property aliases with case insensitivity enabled")
//     void TC21_buildBuilderBased_with_multiple_property_aliases_and_case_insensitivity_enabled() throws Exception {
        // Arrange
//         DeserializationContext mockContext = Mockito.mock(DeserializationContext.class);
//         DeserializationConfig mockConfig = Mockito.mock(DeserializationConfig.class);
//         Mockito.when(mockContext.getConfig()).thenReturn(mockConfig);
//         Mockito.when(mockConfig.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)).thenReturn(true);
// 
//         BeanDescription mockBeanDesc = Mockito.mock(BeanDescription.class);
//         JavaType mockBeanType = Mockito.mock(JavaType.class);
//         Mockito.when(mockBeanDesc.getType()).thenReturn(mockBeanType);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
// 
        // Create mock properties and set aliases
//         SettableBeanProperty mockProperty1 = Mockito.mock(SettableBeanProperty.class);
//         Mockito.when(mockProperty1.getName()).thenReturn("propertyOne");
//         List<PropertyName> aliases1 = List.of(new PropertyName("propOne"), new PropertyName("PROP_ONE"));
//         Mockito.when(mockProperty1.findAliases(mockConfig)).thenReturn(aliases1);
// 
//         SettableBeanProperty mockProperty2 = Mockito.mock(SettableBeanProperty.class);
//         Mockito.when(mockProperty2.getName()).thenReturn("propertyTwo");
//         List<PropertyName> aliases2 = List.of(new PropertyName("propTwo"), new PropertyName("PROP_TWO"));
//         Mockito.when(mockProperty2.findAliases(mockConfig)).thenReturn(aliases2);
// 
//         builder.addProperty(mockProperty1);
//         builder.addProperty(mockProperty2);
// 
        // Act
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(Mockito.mock(JavaType.class), "build");
// 
        // Access internal BeanPropertyMap using reflection
//         Method getPropertyMap = deserializer.getClass().getDeclaredMethod("getPropertyMap");
//         getPropertyMap.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Map<String, SettableBeanProperty> propertyMap = (Map<String, SettableBeanProperty>) getPropertyMap.invoke(deserializer);
// 
        // Assert
//         assertNotNull(propertyMap, "BeanPropertyMap should not be null.");
//         assertTrue(propertyMap.containsKey("propertyOne"), "propertyOne should be present in the property map.");
//         assertTrue(propertyMap.containsKey("propertyTwo"), "propertyTwo should be present in the property map.");
// 
        // Verify alias handling with case insensitivity
//         SettableBeanProperty retrievedProperty1 = propertyMap.get("propone");
//         SettableBeanProperty retrievedProperty2 = propertyMap.get("proptwo");
// 
//         assertNotNull(retrievedProperty1, "Retrieved property for 'propone' should not be null.");
//         assertNotNull(retrievedProperty2, "Retrieved property for 'proptwo' should not be null.");
// 
//         assertEquals(mockProperty1, retrievedProperty1, "Retrieved property should match the original propertyOne.");
//         assertEquals(mockProperty2, retrievedProperty2, "Retrieved property should match the original propertyTwo.");
//     }
// }
}