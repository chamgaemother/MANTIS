import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;
import org.jsoup.nodes.Document;
import org.jsoup.select.NodeFilter;
import org.jsoup.select.NodeFilter.FilterResult;
import org.jsoup.select.NodeTraversor;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class NodeTraversorTest {
    
    @Test
    void testFilterWithNullFilter() {
        Document doc = new Document("");
        NullPointerException exception = assertThrows(NullPointerException.class, () -> {
            NodeTraversor.filter(null, doc);
        });
        assertEquals("Filter must not be null", exception.getMessage());
    }

    @Test
    void testFilterWithNullRoot() {
        NodeFilter filter = (node, depth) -> FilterResult.CONTINUE;
        NullPointerException exception = assertThrows(NullPointerException.class, () -> {
            NodeTraversor.filter(filter, (Node) null);
        });
        assertEquals("Root node must not be null", exception.getMessage());
    }
    
    @Test
    void testFilterWithStopAtHead() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        TestNodeFilter filter = new TestNodeFilter(FilterResult.STOP, FilterResult.CONTINUE);
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.STOP, result);
    }

    @Test
    void testFilterWithStopAtTail() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        TestNodeFilter filter = new TestNodeFilter(FilterResult.CONTINUE, FilterResult.STOP);
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.STOP, result);
    }
    
    @Test
    void testFilterWithRemove() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        Element child = root.appendElement("child");
        TestNodeFilter filter = new RemovalFilter();
        NodeTraversor.filter(filter, root);
        assertEquals(0, root.childNodeSize());
    }

    @Test
    void testFilterWithSkipChildren() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        Element child = root.appendElement("child");
        child.appendElement("grandchild");
        TestNodeFilter filter = new TestNodeFilter(FilterResult.SKIP_CHILDREN, FilterResult.CONTINUE);
        NodeTraversor.filter(filter, root);
        assertEquals(1, child.childNodeSize());
    }
    
    @Test
    void testFilterWithContinue() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        TextNode textNode = new TextNode("text", "");
        root.appendChild(textNode);
        TestNodeFilter filter = new TestNodeFilter(FilterResult.CONTINUE, FilterResult.CONTINUE);
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(1, root.childNodeSize());
    }

    private static class TestNodeFilter implements NodeFilter {
        private final FilterResult headResult;
        private final FilterResult tailResult;
        
        TestNodeFilter(FilterResult headResult, FilterResult tailResult) {
            this.headResult = headResult;
            this.tailResult = tailResult;
        }
        
        @Override
        public FilterResult head(Node node, int depth) {
            return headResult;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return tailResult;
        }
    }

    private static class RemovalFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.REMOVE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.CONTINUE;
        }
    }
}