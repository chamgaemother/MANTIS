package org.jfree.chart.renderer;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.util.ShapeUtils;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PolarPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

public class DefaultPolarItemRenderer_drawSeries_2_1_Test {
    
    @Test
    @DisplayName("drawSeries with useFillPaint=true and isSeriesFilled=true to verify fill paint usage")
    void TC06_drawSeries_useFillPaint_true_isSeriesFilled_true() throws Exception {
        // Arrange
        DefaultPolarItemRenderer renderer = new DefaultPolarItemRenderer();
        renderer.setUseFillPaint(true);
        renderer.setSeriesFilled(0, true);
        renderer.setDrawOutlineWhenFilled(true);
        renderer.setShapesVisible(true);
        
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(3);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        // Access private methods via reflection
        Method lookupSeriesFillPaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesFillPaint", int.class);
        lookupSeriesFillPaintMethod.setAccessible(true);
        Paint fillPaint = (Paint) lookupSeriesFillPaintMethod.invoke(renderer, 0);
        
        Method lookupSeriesOutlinePaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesOutlinePaint", int.class);
        lookupSeriesOutlinePaintMethod.setAccessible(true);
        Paint outlinePaint = (Paint) lookupSeriesOutlinePaintMethod.invoke(renderer, 0);
        
        // Act
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
        
        // Assert
        verify(g2).fill(any());
        verify(g2).setPaint(fillPaint);
        verify(g2).draw(any());
        verify(entities).add(any(XYItemEntity.class));
    }
    
    @Test
    @DisplayName("drawSeries with useFillPaint=false and isSeriesFilled=true to verify standard paint usage")
    void TC07_drawSeries_useFillPaint_false_isSeriesFilled_true() throws Exception {
        // Arrange
        DefaultPolarItemRenderer renderer = new DefaultPolarItemRenderer();
        renderer.setUseFillPaint(false);
        renderer.setSeriesFilled(0, true);
        renderer.setDrawOutlineWhenFilled(true);
        renderer.setShapesVisible(true);
        
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(3);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        // Access private methods via reflection
        Method lookupSeriesPaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesPaint", int.class);
        lookupSeriesPaintMethod.setAccessible(true);
        Paint seriesPaint = (Paint) lookupSeriesPaintMethod.invoke(renderer, 0);
        
        Method lookupSeriesOutlinePaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesOutlinePaint", int.class);
        lookupSeriesOutlinePaintMethod.setAccessible(true);
        Paint outlinePaint = (Paint) lookupSeriesOutlinePaintMethod.invoke(renderer, 0);
        
        // Act
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
        
        // Assert
        verify(g2).fill(any());
        verify(g2).setPaint(seriesPaint);
        verify(g2).draw(any());
        verify(entities).add(any(XYItemEntity.class));
    }
    
    @Test
    @DisplayName("drawSeries with drawOutlineWhenFilled=false and isSeriesFilled=true to verify no outline is drawn")
    void TC08_drawSeries_drawOutlineWhenFilled_false_isSeriesFilled_true() throws Exception {
        // Arrange
        DefaultPolarItemRenderer renderer = new DefaultPolarItemRenderer();
        renderer.setDrawOutlineWhenFilled(false);
        renderer.setSeriesFilled(0, true);
        renderer.setShapesVisible(true);
        
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(3);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        // Access private methods via reflection
        Method lookupSeriesFillPaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesFillPaint", int.class);
        lookupSeriesFillPaintMethod.setAccessible(true);
        Paint fillPaint = (Paint) lookupSeriesFillPaintMethod.invoke(renderer, 0);
        
        Method lookupSeriesOutlinePaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesOutlinePaint", int.class);
        lookupSeriesOutlinePaintMethod.setAccessible(true);
        Paint outlinePaint = (Paint) lookupSeriesOutlinePaintMethod.invoke(renderer, 0);
        
        // Act
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
        
        // Assert
        verify(g2).fill(any());
        verify(g2).setPaint(fillPaint);
        verify(g2, never()).setPaint(outlinePaint);
        verify(g2, never()).draw(any());
        verify(entities).add(any(XYItemEntity.class));
    }
    
    @Test
    @DisplayName("drawSeries with addEntity=true and shapes within dataArea")
    void TC09_drawSeries_addEntity_true_shapesWithinDataArea() throws Exception {
        // Arrange
        DefaultPolarItemRenderer renderer = new DefaultPolarItemRenderer();
        renderer.setShapesVisible(true);
        renderer.setSeriesFilled(0, true);
        
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(2);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        // Mock ShapeUtils to return true for isPointInRect
        try (MockedStatic<ShapeUtils> mockedShapeUtils = Mockito.mockStatic(ShapeUtils.class)) {
            mockedShapeUtils.when(() -> ShapeUtils.isPointInRect(any(Rectangle2D.class), anyDouble(), anyDouble())).thenReturn(true);
            
            // Mock getItemCreateEntity to return true via reflection
            Method getItemCreateEntityMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("getItemCreateEntity", int.class, int.class);
            getItemCreateEntityMethod.setAccessible(true);
            when(getItemCreateEntityMethod.invoke(renderer, 0, anyInt())).thenReturn(true);
            
            // Access private methods via reflection
            Method lookupSeriesFillPaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesFillPaint", int.class);
            lookupSeriesFillPaintMethod.setAccessible(true);
            Paint fillPaint = (Paint) lookupSeriesFillPaintMethod.invoke(renderer, 0);
            
            Method lookupSeriesOutlinePaintMethod = DefaultPolarItemRenderer.class.getDeclaredMethod("lookupSeriesOutlinePaint", int.class);
            lookupSeriesOutlinePaintMethod.setAccessible(true);
            Paint outlinePaint = (Paint) lookupSeriesOutlinePaintMethod.invoke(renderer, 0);
            
            // Act
            renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
            
            // Assert
            verify(entities, times(2)).add(any(XYItemEntity.class));
        }
    }
    
    @Test
    @DisplayName("drawSeries with ShapeUtils.isPointInRect=false to verify entities are not added")
    void TC10_drawSeries_shapesOutsideDataArea_noEntitiesAdded() throws Exception {
        // Arrange
        DefaultPolarItemRenderer renderer = new DefaultPolarItemRenderer();
        renderer.setShapesVisible(true);
        renderer.setSeriesFilled(0, true);
        
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(2);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        // Mock ShapeUtils to return false for isPointInRect
        try (MockedStatic<ShapeUtils> mockedShapeUtils = Mockito.mockStatic(ShapeUtils.class)) {
            mockedShapeUtils.when(() -> ShapeUtils.isPointInRect(any(Rectangle2D.class), anyDouble(), anyDouble())).thenReturn(false);
            
            // Act
            renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
            
            // Assert
            verify(entities, never()).add(any(XYItemEntity.class));
        }
    }
}