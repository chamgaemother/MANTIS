package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.List;

public class BcBands_visitMethodInsn_0_1_Test {

    @Test
    @DisplayName("Test with opcode 182, owner equals currentClass, name not <init>")
    void test_TC01() throws NoSuchFieldException, IllegalAccessException, InstantiationException {
        BcBands bcBands = createBcBands();
        int opcode = 182;
        String owner = "currentClass";
        String name = "methodName";
        String desc = "methodDesc";

        // Setup initial state
        CpBands cpBands = getCpBands(bcBands);
        setupCurrentClass(bcBands, owner);

        // Prepare expected cpMethod results
        Object expectedCpMethod = cpBands.getCPMethod(owner, name, desc);

        // Invoke target method
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Verify
        List<Object> bcThisMethod = getBcThisMethod(bcBands);
        List<Integer> bcCodes = getBcCodes(bcBands);

        assertTrue(bcThisMethod.contains(expectedCpMethod));
        assertTrue(bcCodes.contains(opcode + 24));
    }

    @Test
    @DisplayName("Test with opcode 183, owner equals superClass, name <init>")
    void test_TC02() throws NoSuchFieldException, IllegalAccessException, InstantiationException {
        BcBands bcBands = createBcBands();
        int opcode = 183;
        String owner = "superClass";
        String name = "<init>";
        String desc = "initDesc";

        // Setup initial state
        CpBands cpBands = getCpBands(bcBands);
        setupSuperClass(bcBands, owner);

        // Prepare expected cpMethod results
        Object expectedCpMethod = cpBands.getCPMethod(owner, name, desc);

        // Invoke target method
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Verify
        List<Object> bcInitRef = getBcInitRef(bcBands);
        List<Integer> bcCodes = getBcCodes(bcBands);

        assertTrue(bcInitRef.contains(expectedCpMethod));
        assertTrue(bcCodes.contains(231));
    }

    @Test
    @DisplayName("Test with opcode 184, owner neither currentClass nor superClass, name <init>")
    void test_TC03() throws NoSuchFieldException, IllegalAccessException, InstantiationException {
        BcBands bcBands = createBcBands();
        int opcode = 184;
        String owner = "otherClass";
        String name = "<init>";
        String desc = "initDesc";

        // Setup initial state
        CpBands cpBands = getCpBands(bcBands);
        setupCurrentNewClass(bcBands, owner);

        // Prepare expected cpMethod results
        Object expectedCpMethod = cpBands.getCPMethod(owner, name, desc);

        // Invoke target method
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Verify
        List<Object> bcInitRef = getBcInitRef(bcBands);
        List<Integer> bcCodes = getBcCodes(bcBands);

        assertTrue(bcInitRef.contains(expectedCpMethod));
        assertTrue(bcCodes.contains(232));
    }

    @Test
    @DisplayName("Test with opcode 185 (invokeinterface)")
    void test_TC04() throws NoSuchFieldException, IllegalAccessException, InstantiationException {
        BcBands bcBands = createBcBands();
        int opcode = 185;
        String owner = "interfaceOwner";
        String name = "interfaceMethod";
        String desc = "interfaceDesc";

        // Setup initial state
        CpBands cpBands = getCpBands(bcBands);

        // Prepare expected cpMethod results
        Object expectedCpMethod = cpBands.getCPIMethod(owner, name, desc);

        // Invoke target method
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Verify
        List<Object> bcIMethodRef = getBcIMethodRef(bcBands);
        List<Integer> bcCodes = getBcCodes(bcBands);

        assertTrue(bcIMethodRef.contains(expectedCpMethod));
        assertTrue(bcCodes.contains(185));
    }

    @Test
    @DisplayName("Test with opcode 182, owner equals currentClass, name <init>")
    void test_TC05() throws NoSuchFieldException, IllegalAccessException, InstantiationException {
        BcBands bcBands = createBcBands();
        int opcode = 182;
        String owner = "currentClass";
        String name = "<init>";
        String desc = "initDesc";

        // Setup initial state
        CpBands cpBands = getCpBands(bcBands);
        setupCurrentClass(bcBands, owner);

        // Prepare expected cpMethod results
        Object expectedCpMethod = cpBands.getCPMethod(owner, name, desc);

        // Invoke target method
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Verify
        List<Object> bcInitRef = getBcInitRef(bcBands);
        List<Integer> bcCodes = getBcCodes(bcBands);

        assertTrue(bcInitRef.contains(expectedCpMethod));
        assertTrue(bcCodes.contains(230));
    }

    // Helper method to create an instance of BcBands with mock dependencies
    private BcBands createBcBands() throws InstantiationException, IllegalAccessException, NoSuchFieldException {
        CpBands cpBands = mock(CpBands.class);
        Segment segment = mock(Segment.class);
        when(segment.getSegmentHeader()).thenReturn(mock(SegmentHeader.class));
        return new BcBands(cpBands, segment, 0);
    }

    // Reflection helpers
    private CpBands getCpBands(BcBands bcBands) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("cpBands");
        field.setAccessible(true);
        return (CpBands) field.get(bcBands);
    }

    private void setupCurrentClass(BcBands bcBands, String currentClass) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("currentClass");
        field.setAccessible(true);
        field.set(bcBands, currentClass);
    }

    private void setupSuperClass(BcBands bcBands, String superClass) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("superClass");
        field.setAccessible(true);
        field.set(bcBands, superClass);
    }

    private void setupCurrentNewClass(BcBands bcBands, String currentNewClass) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("currentNewClass");
        field.setAccessible(true);
        field.set(bcBands, currentNewClass);
    }

    private List<Object> getBcThisMethod(BcBands bcBands) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("bcThisMethod");
        field.setAccessible(true);
        return (List<Object>) field.get(bcBands);
    }

    private List<Object> getBcInitRef(BcBands bcBands) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("bcInitRef");
        field.setAccessible(true);
        return (List<Object>) field.get(bcBands);
    }

    private List<Object> getBcIMethodRef(BcBands bcBands) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("bcIMethodRef");
        field.setAccessible(true);
        return (List<Object>) field.get(bcBands);
    }

    private List<Integer> getBcCodes(BcBands bcBands) throws NoSuchFieldException, IllegalAccessException {
        Field field = BcBands.class.getDeclaredField("bcCodes");
        field.setAccessible(true);
        return (List<Integer>) field.get(bcBands);
    }

}