import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import com.fasterxml.jackson.dataformat.xml.deser.XmlBeanDeserializerModifier;
import com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class XmlBeanDeserializerModifierTest {

    @Mock
    DeserializationConfig mockConfig;

    @Mock
    BeanDescription mockBeanDesc;

    @Mock
    AnnotationIntrospector mockIntrospector;

    @Mock
    AnnotatedMember mockAnnotatedMember;

    XmlBeanDeserializerModifier deserializerModifier;

    @BeforeEach
    void setUp() {
        deserializerModifier = new XmlBeanDeserializerModifier("textValue");
    }

    @Test
    void testUpdatePropertiesWithEmptyList() {
        List<BeanPropertyDefinition> result = deserializerModifier.updateProperties(mockConfig, mockBeanDesc, Collections.emptyList());
        assertEquals(0, result.size());
    }

    @Test
    void testUpdatePropertiesWithNullPrimaryMember() {
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(null);

        List<BeanPropertyDefinition> result = deserializerModifier.updateProperties(mockConfig, mockBeanDesc, Collections.singletonList(prop));
        assertEquals(1, result.size());
        assertEquals(prop, result.get(0));
    }

    @Test
    void testUpdatePropertiesWithTextAnnotationFound() {
        when(mockConfig.getAnnotationIntrospector()).thenReturn(mockIntrospector);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(mockAnnotatedMember);
        when(AnnotationUtil.findIsTextAnnotation(mockConfig, mockIntrospector, mockAnnotatedMember)).thenReturn(true);
        when(prop.withSimpleName("textValue")).thenReturn(prop);

        List<BeanPropertyDefinition> result = deserializerModifier.updateProperties(mockConfig, mockBeanDesc, new ArrayList<>(Collections.singletonList(prop)));
        assertEquals(1, result.size());
        assertEquals(prop, result.get(0));
    }

    @Test
    void testUpdatePropertiesWithWrapperName() {
        when(mockConfig.getAnnotationIntrospector()).thenReturn(mockIntrospector);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(mockAnnotatedMember);

        PropertyName wrapperName = new PropertyName("wrapper");
        when(prop.getWrapperName()).thenReturn(wrapperName);
        when(prop.getName()).thenReturn("originalName");
        when(prop.withSimpleName("wrapper")).thenReturn(prop);

        List<BeanPropertyDefinition> originalList = new ArrayList<>(Collections.singletonList(prop));
        List<BeanPropertyDefinition> result = deserializerModifier.updateProperties(mockConfig, mockBeanDesc, originalList);
        assertEquals(1, result.size());
        assertEquals(wrapperName.getSimpleName(), result.get(0).getName());
    }

    @Test
    void testUpdatePropertiesWithNoNameWrapper() {
        when(mockConfig.getAnnotationIntrospector()).thenReturn(mockIntrospector);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(mockAnnotatedMember);

        PropertyName wrapperName = PropertyName.NO_NAME;
        when(prop.getWrapperName()).thenReturn(wrapperName);
        when(prop.getName()).thenReturn("originalName");

        List<BeanPropertyDefinition> result = deserializerModifier.updateProperties(mockConfig, mockBeanDesc, Collections.singletonList(prop));
        assertEquals(1, result.size());
        assertEquals("originalName", result.get(0).getName());
    }

    @Test
    void testUpdatePropertiesWithNonMatchingLocalAndPropName() {
        when(mockConfig.getAnnotationIntrospector()).thenReturn(mockIntrospector);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(mockAnnotatedMember);

        PropertyName wrapperName = new PropertyName("differentName");
        when(prop.getWrapperName()).thenReturn(wrapperName);
        when(prop.getName()).thenReturn("originalName");
        when(prop.withSimpleName("differentName")).thenReturn(prop);

        List<BeanPropertyDefinition> originalList = new ArrayList<>(Collections.singletonList(prop));
        List<BeanPropertyDefinition> result = deserializerModifier.updateProperties(mockConfig, mockBeanDesc, originalList);
        assertEquals(1, result.size());
        assertEquals("differentName", result.get(0).getName());
    }
}