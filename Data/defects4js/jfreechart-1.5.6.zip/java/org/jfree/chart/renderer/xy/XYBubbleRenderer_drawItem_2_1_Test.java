package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

/**
 * Test class for XYBubbleRenderer's drawItem method.
 */
public class XYBubbleRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("drawItem processes item with z=0 to verify handling of zero scaling")
    void TC03() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = Mockito.spy(new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_BOTH_AXES));
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Mock behaviors
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(50.0);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        ArgumentCaptor<Ellipse2D> ellipseCaptorFill = ArgumentCaptor.forClass(Ellipse2D.class);
        ArgumentCaptor<Ellipse2D> ellipseCaptorDraw = ArgumentCaptor.forClass(Ellipse2D.class);
        verify(g2).fill(ellipseCaptorFill.capture());
        verify(g2).draw(ellipseCaptorDraw.capture());

        Ellipse2D filledEllipse = ellipseCaptorFill.getValue();
        Ellipse2D drawnEllipse = ellipseCaptorDraw.getValue();

        assertEquals(0.0, filledEllipse.getWidth());
        assertEquals(0.0, filledEllipse.getHeight());
        assertEquals(0.0, drawnEllipse.getWidth());
        assertEquals(0.0, drawnEllipse.getHeight());
    }

    @Test
    @DisplayName("drawItem processes item with extremely large z-value to test handling of large scaling")
    void TC04() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = Mockito.spy(new XYBubbleRenderer(XYBubbleRenderer.SCALE_ON_BOTH_AXES));
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Mock behaviors
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getZValue(series, item)).thenReturn(1e6);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);
        when(domainAxis.valueToJava2D(1e6, dataArea, plot.getDomainAxisEdge())).thenReturn(1e6);
        when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(1e6, dataArea, plot.getRangeAxisEdge())).thenReturn(1e6);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        ArgumentCaptor<Ellipse2D> ellipseCaptorFill = ArgumentCaptor.forClass(Ellipse2D.class);
        ArgumentCaptor<Ellipse2D> ellipseCaptorDraw = ArgumentCaptor.forClass(Ellipse2D.class);
        verify(g2).fill(ellipseCaptorFill.capture());
        verify(g2).draw(ellipseCaptorDraw.capture());

        Ellipse2D filledEllipse = ellipseCaptorFill.getValue();
        Ellipse2D drawnEllipse = ellipseCaptorDraw.getValue();

        assertEquals(1e6, filledEllipse.getWidth());
        assertEquals(1e6, filledEllipse.getHeight());
        assertEquals(1e6, drawnEllipse.getWidth());
        assertEquals(1e6, drawnEllipse.getHeight());
    }
}