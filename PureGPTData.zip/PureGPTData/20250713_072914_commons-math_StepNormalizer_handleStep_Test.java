import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.sampling.FixedStepHandler;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class StepNormalizerTest {

    private FixedStepHandler mockHandler;
    private StepInterpolator mockInterpolator;

    @BeforeEach
    void setUp() {
        mockHandler = mock(FixedStepHandler.class);
        mockInterpolator = mock(StepInterpolator.class);
    }

    @Test
    void testHandleStepWithLastIncluded() throws MaxCountExceededException {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);

        // Mock behavior for the interpolator
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, times(3)).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    void testHandleStepWithFirstExcluded() throws MaxCountExceededException {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);

        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, times(2)).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    void testHandleStepBackwardDirection() throws MaxCountExceededException {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        when(mockInterpolator.getPreviousTime()).thenReturn(1.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    void testHandleStepMultiplesMode() throws MaxCountExceededException {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.FIRST);

        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(2.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @ParameterizedTest
    @CsvSource({
        "INCREMENT, FIRST",
        "INCREMENT, LAST",
        "MULTIPLES, NEITHER",
        "MULTIPLES, BOTH"
    })
    void testHandleStepWithDifferentBoundsAndModes(StepNormalizerMode mode, StepNormalizerBounds bounds) throws MaxCountExceededException {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, mode, bounds);

        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(2.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    void testHandleStepWithEdgeConditions() throws MaxCountExceededException {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.0);

        normalizer.handleStep(mockInterpolator, false);

        verify(mockHandler, never()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    void testHandleStepMaxCountExceededException() throws Exception {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.FIRST);

        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(2.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});
        doThrow(MaxCountExceededException.class).when(mockInterpolator).setInterpolatedTime(anyDouble());

        assertThrows(MaxCountExceededException.class, () -> normalizer.handleStep(mockInterpolator, true));
    }
}