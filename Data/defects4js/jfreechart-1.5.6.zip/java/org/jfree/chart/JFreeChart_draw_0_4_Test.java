package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.JFreeChartEntity;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.chart.plot.Plot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class JFreeChart_draw_0_4_Test {

    @Test
    @DisplayName("draw method with backgroundImageAlpha at boundary value 0.0f")
    public void TC16() throws Exception {
        // GIVEN
        Image bgImage = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
        Plot plot = mock(Plot.class); // Ensure plot is not null during chart creation
        JFreeChart chart = new JFreeChart("Test Chart", plot);
        chart.setBackgroundImage(bgImage);
        chart.setBackgroundImageAlpha(0.0f);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 500, 400);
        Point2D anchor = new Point2D.Double(250, 200);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        // WHEN
        chart.draw(g2, chartArea, anchor, info);

        // THEN
        ArgumentCaptor<Composite> compositeCaptor = ArgumentCaptor.forClass(Composite.class);
        verify(g2).setComposite(compositeCaptor.capture());
        Composite composite = compositeCaptor.getValue();
        assertTrue(composite instanceof AlphaComposite);
        AlphaComposite alphaComposite = (AlphaComposite) composite;
        assertEquals(0.0f, alphaComposite.getAlpha(), 0.0001f);
    }

    @Test
    @DisplayName("draw method with backgroundImageAlpha at boundary value 1.0f")
    public void TC17() throws Exception {
        // GIVEN
        Image bgImage = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB);
        Plot plot = mock(Plot.class);
        JFreeChart chart = new JFreeChart("Test Chart", plot);
        chart.setBackgroundImage(bgImage);
        chart.setBackgroundImageAlpha(1.0f);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 500, 400);
        Point2D anchor = new Point2D.Double(250, 200);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        // WHEN
        chart.draw(g2, chartArea, anchor, info);

        // THEN
        ArgumentCaptor<Composite> compositeCaptor = ArgumentCaptor.forClass(Composite.class);
        verify(g2).setComposite(compositeCaptor.capture());
        Composite composite = compositeCaptor.getValue();
        assertTrue(composite instanceof AlphaComposite);
        AlphaComposite alphaComposite = (AlphaComposite) composite;
        assertEquals(1.0f, alphaComposite.getAlpha(), 0.0001f);
    }

    @Test
    @DisplayName("draw method with renderingHints as empty")
    public void TC18() throws Exception {
        // GIVEN
        RenderingHints hints = new RenderingHints(new HashMap<>());
        Plot plot = mock(Plot.class);
        JFreeChart chart = new JFreeChart("Test Chart", plot);
        chart.setRenderingHints(hints);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 500, 400);
        Point2D anchor = new Point2D.Double(250, 200);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        // WHEN
        chart.draw(g2, chartArea, anchor, info);

        // THEN
        verify(g2).addRenderingHints(hints);
    }

    @Test
    @DisplayName("draw method with plotInfo as null")
    public void TC19() throws Exception {
        // GIVEN
        Plot plot = mock(Plot.class);
        JFreeChart chart = new JFreeChart("Test Chart", plot);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 500, 400);
        Point2D anchor = new Point2D.Double(250, 200);

        // WHEN
        chart.draw(g2, chartArea, anchor, null);

        // THEN
        verify(plot).draw(eq(g2), eq(chartArea), eq(anchor), isNull(), isNull());
    }

    @Test
    @DisplayName("draw method with multiple iterations in subtitles loop")
    public void TC20() throws Exception {
        // GIVEN
        TextTitle subtitle1 = new TextTitle("Subtitle 1");
        TextTitle subtitle2 = new TextTitle("Subtitle 2");
        TextTitle subtitle3 = new TextTitle("Subtitle 3");
        subtitle1.setVisible(true);
        subtitle2.setVisible(true);
        subtitle3.setVisible(true);
        List<Title> subtitles = Arrays.asList(subtitle1, subtitle2, subtitle3);
        Plot plot = mock(Plot.class);
        JFreeChart chart = new JFreeChart("Test Chart", plot);
        chart.setSubtitles(subtitles);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 500, 400);
        Point2D anchor = new Point2D.Double(250, 200);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        EntityCollection entityCollection = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entityCollection);

        // WHEN
        chart.draw(g2, chartArea, anchor, info);

        // THEN
        verify(chart, times(1)).drawTitle(eq(subtitle1), eq(g2), any(Rectangle2D.class), eq(true));
        verify(chart, times(1)).drawTitle(eq(subtitle2), eq(g2), any(Rectangle2D.class), eq(true));
        verify(chart, times(1)).drawTitle(eq(subtitle3), eq(g2), any(Rectangle2D.class), eq(true));
        verify(entityCollection, times(3)).add(any(JFreeChartEntity.class));
    }
}