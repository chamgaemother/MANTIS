import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.statistics.DefaultStatisticalCategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DefaultStatisticalCategoryDatasetTest {

    private DefaultStatisticalCategoryDataset dataset;
    private Comparable<String> rowKey1;
    private Comparable<String> rowKey2;
    private Comparable<String> columnKey1;
    private Comparable<String> columnKey2;

    @BeforeEach
    public void setUp() {
        dataset = new DefaultStatisticalCategoryDataset();
        rowKey1 = "Row1";
        rowKey2 = "Row2";
        columnKey1 = "Column1";
        columnKey2 = "Column2";
    }

    @Test
    public void testAddValidValues() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        assertEquals(10.0, dataset.getMeanValue(rowKey1, columnKey1));
        assertEquals(2.0, dataset.getStdDevValue(rowKey1, columnKey1));
        assertEquals(10.0, dataset.getRangeLowerBound(false));
        assertEquals(10.0, dataset.getRangeUpperBound(false));
        assertEquals(8.0, dataset.getRangeLowerBound(true));
        assertEquals(12.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddNullMean() {
        dataset.add(null, 2.0, rowKey1, columnKey1);
        assertNull(dataset.getMeanValue(rowKey1, columnKey1));
        assertEquals(2.0, dataset.getStdDevValue(rowKey1, columnKey1));
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
        assertEquals(-2.0, dataset.getRangeLowerBound(true));
        assertEquals(2.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddNullStdDev() {
        dataset.add(10.0, null, rowKey1, columnKey1);
        assertEquals(10.0, dataset.getMeanValue(rowKey1, columnKey1));
        assertNull(dataset.getStdDevValue(rowKey1, columnKey1));
        assertEquals(10.0, dataset.getRangeLowerBound(false));
        assertEquals(10.0, dataset.getRangeUpperBound(false));
        assertEquals(10.0, dataset.getRangeLowerBound(true));
        assertEquals(10.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddNullMeanAndStdDev() {
        dataset.add(null, null, rowKey1, columnKey1);
        assertNull(dataset.getMeanValue(rowKey1, columnKey1));
        assertNull(dataset.getStdDevValue(rowKey1, columnKey1));
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(true)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(true)));
    }

    @Test
    public void testAddToEmptyDataset() {
        dataset.add(5.0, 1.0, rowKey1, columnKey1);
        assertEquals(5.0, dataset.getMeanValue(rowKey1, columnKey1));
        assertEquals(1.0, dataset.getStdDevValue(rowKey1, columnKey1));
        assertEquals(4.0, dataset.getRangeLowerBound(true));
        assertEquals(6.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddMultipleValuesUpdateMax() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(15.0, 3.0, rowKey2, columnKey2);
        assertEquals(10.0, dataset.getRangeLowerBound(false));
        assertEquals(15.0, dataset.getRangeUpperBound(false));
        assertEquals(8.0, dataset.getRangeLowerBound(true));
        assertEquals(18.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddMultipleValuesUpdateMin() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(5.0, 1.0, rowKey2, columnKey2);
        assertEquals(5.0, dataset.getRangeLowerBound(false));
        assertEquals(10.0, dataset.getRangeUpperBound(false));
        assertEquals(4.0, dataset.getRangeLowerBound(true));
        assertEquals(12.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddMultipleValuesUpdateMaxIncStdDev() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(12.0, 5.0, rowKey2, columnKey2);
        assertEquals(10.0, dataset.getRangeLowerBound(false));
        assertEquals(12.0, dataset.getRangeUpperBound(false));
        assertEquals(10.0 - 2.0, dataset.getRangeLowerBound(true));
        assertEquals(12.0 + 5.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddMultipleValuesUpdateMinIncStdDev() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(8.0, 5.0, rowKey2, columnKey2);
        assertEquals(8.0, dataset.getRangeLowerBound(false));
        assertEquals(10.0, dataset.getRangeUpperBound(false));
        assertEquals(8.0 - 5.0, dataset.getRangeLowerBound(true));
        assertEquals(10.0 + 2.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddExistingMaxTriggersUpdateBounds() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(15.0, 3.0, rowKey2, columnKey2);
        dataset.add(15.0, 3.0, rowKey1, columnKey1); // Existing max cell
        assertEquals(15.0, dataset.getRangeUpperBound(false));
        assertEquals(18.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddExistingMinTriggersUpdateBounds() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(5.0, 1.0, rowKey2, columnKey2);
        dataset.add(5.0, 1.0, rowKey1, columnKey1); // Existing min cell
        assertEquals(5.0, dataset.getRangeLowerBound(false));
        assertEquals(4.0, dataset.getRangeLowerBound(true));
    }

    @Test
    public void testAddWithNaNMean() {
        dataset.add(Double.NaN, 2.0, rowKey1, columnKey1);
        assertTrue(Double.isNaN(dataset.getMeanValue(rowKey1, columnKey1).doubleValue()));
        assertEquals(2.0, dataset.getStdDevValue(rowKey1, columnKey1));
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false));
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(true)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(true)));
    }

    @Test
    public void testAddWithNaNStdDev() {
        dataset.add(10.0, Double.NaN, rowKey1, columnKey1);
        assertEquals(10.0, dataset.getMeanValue(rowKey1, columnKey1));
        assertTrue(Double.isNaN(dataset.getStdDevValue(rowKey1, columnKey1).doubleValue()));
        assertEquals(10.0, dataset.getRangeLowerBound(false));
        assertEquals(10.0, dataset.getRangeUpperBound(false));
        assertEquals(10.0, dataset.getRangeLowerBound(true));
        assertEquals(10.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddWithNegativeValues() {
        dataset.add(-10.0, 5.0, rowKey1, columnKey1);
        assertEquals(-10.0, dataset.getMeanValue(rowKey1, columnKey1));
        assertEquals(5.0, dataset.getStdDevValue(rowKey1, columnKey1));
        assertEquals(-10.0, dataset.getRangeLowerBound(false));
        assertEquals(-10.0, dataset.getRangeUpperBound(false));
        assertEquals(-15.0, dataset.getRangeLowerBound(true));
        assertEquals(-5.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddWithPositiveAndNegativeValues() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(-5.0, 1.0, rowKey2, columnKey2);
        assertEquals(-5.0, dataset.getRangeLowerBound(false));
        assertEquals(10.0, dataset.getRangeUpperBound(false));
        assertEquals(-6.0, dataset.getRangeLowerBound(true));
        assertEquals(12.0, dataset.getRangeUpperBound(true));
    }

    @Test
    public void testAddNullRowKey() {
        assertThrows(NullPointerException.class, () -> {
            dataset.add(10.0, 2.0, null, columnKey1);
        });
    }

    @Test
    public void testAddNullColumnKey() {
        assertThrows(NullPointerException.class, () -> {
            dataset.add(10.0, 2.0, rowKey1, null);
        });
    }

    @Test
    public void testAddDuplicateKeys() {
        dataset.add(10.0, 2.0, rowKey1, columnKey1);
        dataset.add(15.0, 3.0, rowKey1, columnKey1);
        assertEquals(15.0, dataset.getMeanValue(rowKey1, columnKey1));
        assertEquals(3.0, dataset.getStdDevValue(rowKey1, columnKey1));
        assertEquals(15.0, dataset.getRangeUpperBound(false));
        assertEquals(18.0, dataset.getRangeUpperBound(true));
    }
}