package org.apache.commons.math3.ode.sampling;

import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.sampling.StepNormalizerBounds;
import org.apache.commons.math3.ode.sampling.StepNormalizerMode;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.apache.commons.math3.ode.sampling.StepHandler;
import org.apache.commons.math3.ode.sampling.StepNormalizer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.ArgumentCaptor;
import java.lang.reflect.Field;

public class StepNormalizer_handleStep_0_2_Test {

    @Test
    @DisplayName("Handle step when lastState is null, mode is MULTIPLES, Precision.equals returns false")
    void TC06_handleStep_initial_MULTIPLES_Precision_false_final_step() throws Exception {
        // GIVEN
        // Mock StepInterpolator
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        doNothing().when(interpolator).setInterpolatedTime(anyDouble());

        // Initialize handler with a fake FixedStepHandler
        FixedStepHandler fixedStepHandler = spy(FixedStepHandler.class);

        // Initialize bounds mock
        StepNormalizerBounds bounds = mock(StepNormalizerBounds.class);
        when(bounds.lastIncluded()).thenReturn(true);

        // Initialize StepNormalizer with mode=MULTIPLES, h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, fixedStepHandler, StepNormalizerMode.MULTIPLES, bounds);

        // Use reflection to set private fields
        Field lastStateField = StepNormalizer.class.getDeclaredField("lastState");
        lastStateField.setAccessible(true);
        lastStateField.set(normalizer, null);

        // WHEN
        normalizer.handleStep(interpolator, true);

        // THEN
        // Capture the arguments passed to handler.handleStep()
        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivativesCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> isLastCaptor = ArgumentCaptor.forClass(Boolean.class);

        verify(fixedStepHandler, times(2)).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivativesCaptor.capture(), isLastCaptor.capture());

        // First call
        assertEquals(0.0, timeCaptor.getAllValues().get(0));
        assertArrayEquals(new double[]{1.0, 2.0}, stateCaptor.getAllValues().get(0));
        assertArrayEquals(new double[]{0.1, 0.2}, derivativesCaptor.getAllValues().get(0));
        assertFalse(isLastCaptor.getAllValues().get(0));

        // Second call
        assertEquals(0.1, timeCaptor.getAllValues().get(1));
        assertArrayEquals(new double[]{1.0, 2.0}, stateCaptor.getAllValues().get(1));
        assertArrayEquals(new double[]{0.1, 0.2}, derivativesCaptor.getAllValues().get(1));
        assertTrue(isLastCaptor.getAllValues().get(1));
    }

    @Test
    @DisplayName("Handle step when isNextInStep returns false immediately, resulting in no loop iterations")
    void TC07_handleStep_isNextInStep_false_no_iterations() throws Exception {
        // GIVEN
        // Mock StepInterpolator
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(0.05);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        doNothing().when(interpolator).setInterpolatedTime(anyDouble());

        // Initialize handler with a fake FixedStepHandler
        FixedStepHandler fixedStepHandler = spy(FixedStepHandler.class);

        // Initialize bounds mock
        StepNormalizerBounds bounds = mock(StepNormalizerBounds.class);
        when(bounds.lastIncluded()).thenReturn(false);

        // Initialize StepNormalizer with mode=INCREMENT, h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, fixedStepHandler, StepNormalizerMode.INCREMENT, bounds);

        // Use reflection to set private fields
        Field lastStateField = StepNormalizer.class.getDeclaredField("lastState");
        lastStateField.setAccessible(true);
        lastStateField.set(normalizer, new double[]{1.0, 2.0});

        Field lastTimeField = StepNormalizer.class.getDeclaredField("lastTime");
        lastTimeField.setAccessible(true);
        lastTimeField.set(normalizer, 0.0);

        // WHEN
        normalizer.handleStep(interpolator, false);

        // THEN
        // Verify handler.handleStep is called once
        verify(fixedStepHandler, times(1)).handleStep(eq(0.0), eq(new double[]{1.0, 2.0}), eq(new double[]{0.1, 0.2}), eq(false));
    }

    @Test
    @DisplayName("Handle step when isLast is true and bounds.lastIncluded is true, requiring final step processing")
    void TC08_handleStep_isLast_true_bounds_lastIncluded_true_final_step() throws Exception {
        // GIVEN
        // Mock StepInterpolator
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        doNothing().when(interpolator).setInterpolatedTime(anyDouble());

        // Initialize handler with a fake FixedStepHandler
        FixedStepHandler fixedStepHandler = spy(FixedStepHandler.class);

        // Initialize bounds mock
        StepNormalizerBounds bounds = mock(StepNormalizerBounds.class);
        when(bounds.lastIncluded()).thenReturn(true);

        // Initialize StepNormalizer with mode=INCREMENT, h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, fixedStepHandler, StepNormalizerMode.INCREMENT, bounds);

        // Use reflection to set private fields
        Field lastStateField = StepNormalizer.class.getDeclaredField("lastState");
        lastStateField.setAccessible(true);
        lastStateField.set(normalizer, new double[]{1.0, 2.0});

        Field lastTimeField = StepNormalizer.class.getDeclaredField("lastTime");
        lastTimeField.setAccessible(true);
        lastTimeField.set(normalizer, 0.0);

        // WHEN
        normalizer.handleStep(interpolator, true);

        // THEN
        // Capture the arguments passed to handler.handleStep()
        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivativesCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> isLastCaptor = ArgumentCaptor.forClass(Boolean.class);

        verify(fixedStepHandler, times(2)).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivativesCaptor.capture(), isLastCaptor.capture());

        // First call
        assertEquals(0.0, timeCaptor.getAllValues().get(0));
        assertArrayEquals(new double[]{1.0, 2.0}, stateCaptor.getAllValues().get(0));
        assertArrayEquals(new double[]{0.1, 0.2}, derivativesCaptor.getAllValues().get(0));
        assertFalse(isLastCaptor.getAllValues().get(0));

        // Second call
        assertEquals(0.1, timeCaptor.getAllValues().get(1));
        assertArrayEquals(new double[]{1.0, 2.0}, stateCaptor.getAllValues().get(1));
        assertArrayEquals(new double[]{0.1, 0.2}, derivativesCaptor.getAllValues().get(1));
        assertTrue(isLastCaptor.getAllValues().get(1));
    }

    @Test
    @DisplayName("Handle step when isLast is true and bounds.lastIncluded is false, requiring alternate final step processing")
    void TC09_handleStep_isLast_true_bounds_lastIncluded_false_final_step() throws Exception {
        // GIVEN
        // Mock StepInterpolator
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        doNothing().when(interpolator).setInterpolatedTime(anyDouble());

        // Initialize handler with a fake FixedStepHandler
        FixedStepHandler fixedStepHandler = spy(FixedStepHandler.class);

        // Initialize bounds mock
        StepNormalizerBounds bounds = mock(StepNormalizerBounds.class);
        when(bounds.lastIncluded()).thenReturn(false);

        // Initialize StepNormalizer with mode=INCREMENT, h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, fixedStepHandler, StepNormalizerMode.INCREMENT, bounds);

        // Use reflection to set private fields
        Field lastStateField = StepNormalizer.class.getDeclaredField("lastState");
        lastStateField.setAccessible(true);
        lastStateField.set(normalizer, new double[]{1.0, 2.0});

        Field lastTimeField = StepNormalizer.class.getDeclaredField("lastTime");
        lastTimeField.setAccessible(true);
        lastTimeField.set(normalizer, 0.0);

        // WHEN
        normalizer.handleStep(interpolator, true);

        // THEN
        // Capture the arguments passed to handler.handleStep()
        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivativesCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> isLastCaptor = ArgumentCaptor.forClass(Boolean.class);

        verify(fixedStepHandler, times(1)).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivativesCaptor.capture(), isLastCaptor.capture());

        // First call
        assertEquals(0.0, timeCaptor.getAllValues().get(0));
        assertArrayEquals(new double[]{1.0, 2.0}, stateCaptor.getAllValues().get(0));
        assertArrayEquals(new double[]{0.1, 0.2}, derivativesCaptor.getAllValues().get(0));
        assertFalse(isLastCaptor.getAllValues().get(0));
    }

    @Test
    @DisplayName("Handle step when mode is neither INCREMENT nor MULTIPLES, expecting correct nextTime calculation")
    void TC10_handleStep_mode_other_than_INCREMENT_or_MULTIPLES() throws Exception {
        // GIVEN
        // Mock StepInterpolator
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        doNothing().when(interpolator).setInterpolatedTime(anyDouble());

        // Initialize handler with a fake FixedStepHandler
        FixedStepHandler fixedStepHandler = spy(FixedStepHandler.class);

        // Initialize bounds mock
        StepNormalizerBounds bounds = mock(StepNormalizerBounds.class);
        when(bounds.lastIncluded()).thenReturn(true);

        // Initialize StepNormalizer with mode=INCREMENT, h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, fixedStepHandler, StepNormalizerMode.INCREMENT, bounds);

        // Use reflection to set private fields
        Field lastStateField = StepNormalizer.class.getDeclaredField("lastState");
        lastStateField.setAccessible(true);
        lastStateField.set(normalizer, new double[]{1.0, 2.0});

        Field lastTimeField = StepNormalizer.class.getDeclaredField("lastTime");
        lastTimeField.setAccessible(true);
        lastTimeField.set(normalizer, 0.0);

        // WHEN
        normalizer.handleStep(interpolator, false);

        // THEN
        // Verify handler.handleStep is called once
        verify(fixedStepHandler, times(1)).handleStep(eq(0.0), eq(new double[]{1.0, 2.0}), eq(new double[]{0.1, 0.2}), eq(false));
    }
}