package com.fasterxml.jackson.databind.deser.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.SettableAnyProperty;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.DeserializationFeature;

import java.lang.reflect.Field;
import java.util.BitSet;

import org.mockito.Mockito;

/**
 * JUnit 5 test class for PropertyValueBuffer#getParameters covering specified scenarios.
 */
public class PropertyValueBuffer_getParameters_2_1_Test {

    @Test
    @DisplayName("getParameters with _paramsNeeded > 0 and _paramsSeenBig is null, some creatorParameters are missing, FAIL_ON_NULL_CREATOR_PROPERTIES disabled")
    void TC12() throws Exception {
        // Arrange
        JsonParser parser = Mockito.mock(JsonParser.class);
        DeserializationContext context = Mockito.mock(DeserializationContext.class);
        SettableBeanProperty[] props = new SettableBeanProperty[3];
        for (int i = 0; i < 3; i++) {
            props[i] = Mockito.mock(SettableBeanProperty.class);
            Mockito.when(props[i].getCreatorIndex()).thenReturn(i);
            Mockito.when(props[i].isRequired()).thenReturn(false);
            Mockito.when(props[i].getValueDeserializer()).thenReturn(Mockito.mock(JsonDeserializer.class));
        }
        Mockito.when(context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)).thenReturn(false);

        PropertyValueBuffer buffer = new PropertyValueBuffer(parser, context, 3, null, null);

        // Using reflection to set _paramsNeeded > 0 and _paramsSeenBig is null
        Field paramsNeededField = PropertyValueBuffer.class.getDeclaredField("_paramsNeeded");
        paramsNeededField.setAccessible(true);
        paramsNeededField.setInt(buffer, 2); // Assume 2 parameters are still needed

        // Populate some creatorParameters
        Field creatorParametersField = PropertyValueBuffer.class.getDeclaredField("_creatorParameters");
        creatorParametersField.setAccessible(true);
        Object[] creatorParameters = (Object[]) creatorParametersField.get(buffer);
        creatorParameters[0] = "Value0";
        // creatorParameters[1] remains null to simulate missing parameter
        creatorParameters[2] = "Value2";

        // Act
        Object[] result = buffer.getParameters(props);

        // Assert
        assertNotNull(result);
        assertEquals(3, result.length);
        assertEquals("Value0", result[0]);
        assertNotNull(result[1], "Missing parameter should be assigned a default or absent value");
        assertEquals("Value2", result[2]);
    }

    @Test
    @DisplayName("getParameters with _paramsNeeded > 0 and _paramsSeenBig is not null, all creatorParameters are present, FAIL_ON_NULL_CREATOR_PROPERTIES enabled")
    void TC13() throws Exception {
        // Arrange
        JsonParser parser = Mockito.mock(JsonParser.class);
        DeserializationContext context = Mockito.mock(DeserializationContext.class);
        SettableBeanProperty[] props = new SettableBeanProperty[3];
        for (int i = 0; i < 3; i++) {
            props[i] = Mockito.mock(SettableBeanProperty.class);
            Mockito.when(props[i].getCreatorIndex()).thenReturn(i);
            Mockito.when(props[i].isRequired()).thenReturn(false);
            Mockito.when(props[i].getValueDeserializer()).thenReturn(Mockito.mock(JsonDeserializer.class));
        }
        Mockito.when(context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)).thenReturn(true);

        PropertyValueBuffer buffer = new PropertyValueBuffer(parser, context, 3, null, null);

        // Using reflection to set _paramsNeeded <= 0 and _paramsSeenBig is not null
        Field paramsNeededField = PropertyValueBuffer.class.getDeclaredField("_paramsNeeded");
        paramsNeededField.setAccessible(true);
        paramsNeededField.setInt(buffer, 0); // All parameters are provided

        Field paramsSeenBigField = PropertyValueBuffer.class.getDeclaredField("_paramsSeenBig");
        BitSet paramsSeenBig = new BitSet();
        paramsSeenBig.set(0);
        paramsSeenBig.set(1);
        paramsSeenBig.set(2);
        paramsSeenBigField.set(buffer, paramsSeenBig);

        // Populate all creatorParameters
        Field creatorParametersField = PropertyValueBuffer.class.getDeclaredField("_creatorParameters");
        creatorParametersField.setAccessible(true);
        Object[] creatorParameters = (Object[]) creatorParametersField.get(buffer);
        creatorParameters[0] = "Value0";
        creatorParameters[1] = "Value1";
        creatorParameters[2] = "Value2";

        // Act
        Object[] result = buffer.getParameters(props);

        // Assert
        assertNotNull(result);
        assertEquals(3, result.length);
        assertEquals("Value0", result[0]);
        assertEquals("Value1", result[1]);
        assertEquals("Value2", result[2]);
    }

    @Test
    @DisplayName("getParameters with _anyParamSetter present and _createAndSetAnySetterValue throws JsonMappingException")
    void TC14() throws Exception {
        // Arrange
        JsonParser parser = Mockito.mock(JsonParser.class);
        DeserializationContext context = Mockito.mock(DeserializationContext.class);
        SettableBeanProperty[] props = new SettableBeanProperty[2];
        for (int i = 0; i < 2; i++) {
            props[i] = Mockito.mock(SettableBeanProperty.class);
            Mockito.when(props[i].getCreatorIndex()).thenReturn(i);
            Mockito.when(props[i].isRequired()).thenReturn(false);
            Mockito.when(props[i].getValueDeserializer()).thenReturn(Mockito.mock(JsonDeserializer.class));
        }

        SettableAnyProperty anyParamSetter = Mockito.mock(SettableAnyProperty.class);
        Mockito.when(anyParamSetter.getParameterIndex()).thenReturn(1);

        PropertyValueBuffer buffer = new PropertyValueBuffer(parser, context, 2, null, anyParamSetter);

        // Mock _createAndSetAnySetterValue to throw JsonMappingException
        // Since _createAndSetAnySetterValue is a private method, we'll simulate the exception by mocking anyParamSetter.createParameterObject()
        Mockito.when(anyParamSetter.createParameterObject()).thenThrow(new JsonMappingException("Mock exception"));

        // Act & Assert
        JsonMappingException exception = assertThrows(JsonMappingException.class, () -> buffer.getParameters(props));
        assertEquals("Mock exception", exception.getOriginalMessage());
    }

    @Test
    @DisplayName("getParameters with _paramsNeeded > 0 and _paramsSeenBig is not null, some creatorParameters are missing, FAIL_ON_NULL_CREATOR_PROPERTIES enabled")
    void TC15() throws Exception {
        // Arrange
        JsonParser parser = Mockito.mock(JsonParser.class);
        DeserializationContext context = Mockito.mock(DeserializationContext.class);
        SettableBeanProperty[] props = new SettableBeanProperty[3];
        for (int i = 0; i < 3; i++) {
            props[i] = Mockito.mock(SettableBeanProperty.class);
            Mockito.when(props[i].getCreatorIndex()).thenReturn(i);
            Mockito.when(props[i].isRequired()).thenReturn(false);
            Mockito.when(props[i].getValueDeserializer()).thenReturn(Mockito.mock(JsonDeserializer.class));
            Mockito.when(props[i].getName()).thenReturn("prop" + i);
        }
        Mockito.when(context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)).thenReturn(true);

        PropertyValueBuffer buffer = new PropertyValueBuffer(parser, context, 3, null, null);

        // Using reflection to set _paramsNeeded > 0 and _paramsSeenBig is not null
        Field paramsNeededField = PropertyValueBuffer.class.getDeclaredField("_paramsNeeded");
        paramsNeededField.setAccessible(true);
        paramsNeededField.setInt(buffer, 1); // 1 parameter is still needed

        Field paramsSeenBigField = PropertyValueBuffer.class.getDeclaredField("_paramsSeenBig");
        BitSet paramsSeenBig = new BitSet();
        paramsSeenBig.set(0);
        paramsSeenBig.set(2);
        paramsSeenBigField.set(buffer, paramsSeenBig);

        // Populate some creatorParameters
        Field creatorParametersField = PropertyValueBuffer.class.getDeclaredField("_creatorParameters");
        creatorParametersField.setAccessible(true);
        Object[] creatorParameters = (Object[]) creatorParametersField.get(buffer);
        creatorParameters[0] = "Value0";
        // creatorParameters[1] remains null to simulate missing parameter
        creatorParameters[2] = "Value2"; // All except index 1 are present

        // Act & Assert
        JsonMappingException exception = assertThrows(JsonMappingException.class, () -> buffer.getParameters(props));
        assertTrue(exception.getMessage().contains("Null value for creator property 'prop1' (index 1)"));
    }
}