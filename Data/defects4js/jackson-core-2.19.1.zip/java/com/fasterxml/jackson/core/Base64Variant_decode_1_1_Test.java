package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.Base64Variant;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Base64Variant_decode_1_1_Test {

    @Test
    @DisplayName("decode with valid Base64 string")
    public void TC37_decode_ValidBase64String() {
        // Arrange
        Base64Variant variant = new Base64Variant("MIME", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        String base64Str = "QSB2YWxpZF9zdHJpbmc="; // 'A valid_string' encoded
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // Act
        variant.decode(base64Str, builder);
        byte[] result = builder.toByteArray();

        // Assert
        assertNotNull(result, "Result should not be null");
        assertTrue(result.length > 0, "Resulting array should contain decoded bytes");
    }

    @Test
    @DisplayName("decode with invalid Base64 string throws Exception")
    public void TC38_decode_InvalidBase64String_Exception() {
        // Arrange
        Base64Variant variant = new Base64Variant("MIME", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        String invalidBase64Str = "!!!"; // Invalid base64 string
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> variant.decode(invalidBase64Str, builder), "Expected to throw an IllegalArgumentException for invalid Base64 string");
    }

    @Test
    @DisplayName("decodeBase64Char with a valid Base64 character 'A' (c <= 127) returns 0")
    public void TC37_decodeBase64Char_ValidCharacterA() {
        // Arrange
        Base64Variant variant = new Base64Variant("MIME", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        char c = 'A';

        // Act
        int result = variant.decodeBase64Char(c);

        // Assert
        assertEquals(0, result, "Expected decodeBase64Char('A') to return 0");
    }

    @Test
    @DisplayName("decodeBase64Char with an invalid Base64 character '!' (c <= 127) returns -1")
    public void TC38_decodeBase64Char_InvalidCharacterExclamation() {
        // Arrange
        Base64Variant variant = new Base64Variant("MIME", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        char c = '!';

        // Act
        int result = variant.decodeBase64Char(c);

        // Assert
        assertEquals(-1, result, "Expected decodeBase64Char('!') to return -1");
    }

    @Test
    @DisplayName("decodeBase64Char with non-ASCII character '\u20AC' (c > 127) returns -1")
    public void TC39_decodeBase64Char_NonAsciiCharacterEuro() {
        // Arrange
        Base64Variant variant = new Base64Variant("MIME", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        char c = '\u20AC';

        // Act
        int result = variant.decodeBase64Char(c);

        // Assert
        assertEquals(-1, result, "Expected decodeBase64Char('\u20AC') to return -1");
    }

    @Test
    @DisplayName("decodeBase64Char with high-range Unicode character '\uFFFF' (c > 127) returns -1")
    public void TC40_decodeBase64Char_HighRangeUnicode() {
        // Arrange
        Base64Variant variant = new Base64Variant("MIME", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        char c = '\uFFFF';

        // Act
        int result = variant.decodeBase64Char(c);

        // Assert
        assertEquals(-1, result, "Expected decodeBase64Char('\uFFFF') to return -1");
    }
}
