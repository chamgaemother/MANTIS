import org.jsoup.parser.TokenQueue;
import org.jsoup.helper.Validate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

class TokenQueueTest {

    @Test
    void testChompBalanced_SimpleBalanced() {
        try (TokenQueue tq = new TokenQueue("(one)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_NestedBalanced() {
        try (TokenQueue tq = new TokenQueue("(one (two) three)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one (two) three", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_UnbalancedThrows() {
        try (TokenQueue tq = new TokenQueue("(one (two) three")) {
            IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
                tq.chompBalanced('(', ')');
            });
            assertTrue(exception.getMessage().contains("Did not find balanced marker"));
        }
    }

    @Test
    void testChompBalanced_WithEscapes() {
        try (TokenQueue tq = new TokenQueue("(one \\(two\\) three)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one \\(two\\) three", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithSingleQuotes() {
        try (TokenQueue tq = new TokenQueue("('one (two) three')")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("'one (two) three'", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithDoubleQuotes() {
        try (TokenQueue tq = new TokenQueue("(\"one (two) three\")")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("\"one (two) three\"", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithRegexQE() {
        try (TokenQueue tq = new TokenQueue("(one \\Q(two\\E) three)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one \\Q(two\\E) three", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_EmptyString() {
        try (TokenQueue tq = new TokenQueue("")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_OnlyOpenAndClose() {
        try (TokenQueue tq = new TokenQueue("()")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_EscapeFollowedByNonQE() {
        try (TokenQueue tq = new TokenQueue("(one \\A two)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one \\A two", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_EscapeFollowedByQ_then_E() {
        try (TokenQueue tq = new TokenQueue("(one \\Qtwo\\E three)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one \\Qtwo\\E three", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithMultipleNestedLevels() {
        try (TokenQueue tq = new TokenQueue("(a (b (c (d)) e) f)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("a (b (c (d)) e) f", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithMixedQuotesAndEscapes() {
        try (TokenQueue tq = new TokenQueue("(one 'two (three)' \"four \\\"five\\\"\")")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one 'two (three)' \"four \\\"five\\\"\"", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_OpenAndCloseSameCharacter() {
        try (TokenQueue tq = new TokenQueue("|one|")) {
            String result = tq.chompBalanced('|', '|');
            assertEquals("one", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_OpenAndCloseSameCharacterNested() {
        try (TokenQueue tq = new TokenQueue("|one | two | three|")) {
            String result = tq.chompBalanced('|', '|');
            assertEquals("one | two | three", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_UnbalancedWithSimilarCharacters() {
        try (TokenQueue tq = new TokenQueue("(one (two) three))")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one (two) three)", result);
            assertFalse(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_OnlyOpen() {
        try (TokenQueue tq = new TokenQueue("(")) {
            IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
                tq.chompBalanced('(', ')');
            });
            assertTrue(exception.getMessage().contains("Did not find balanced marker"));
        }
    }

    @Test
    void testChompBalanced_OnlyClose() {
        try (TokenQueue tq = new TokenQueue(")")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals(")", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_MultipleBalancedSegments() {
        try (TokenQueue tq = new TokenQueue("(one)(two)")) {
            String first = tq.chompBalanced('(', ')');
            assertEquals("one", first);
            String second = tq.chompBalanced('(', ')');
            assertEquals("two", second);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithEscapedBackslash() {
        try (TokenQueue tq = new TokenQueue("(one \\\\ two)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one \\\\ two", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithCarriageReturnNewline() {
        try (TokenQueue tq = new TokenQueue("(one\r\ntwo)\n")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one\r\ntwo", result);
            assertFalse(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithFormFeed() {
        try (TokenQueue tq = new TokenQueue("(one\f two)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one\f two", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithNullCharacter() {
        try (TokenQueue tq = new TokenQueue("(one\u0000two)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one\u0000two", result);
            assertTrue(tq.isEmpty());
        }
    }

    @Test
    void testChompBalanced_WithReplacementCharacter() {
        try (TokenQueue tq = new TokenQueue("(one\uFFFDtwo)")) {
            String result = tq.chompBalanced('(', ')');
            assertEquals("one\uFFFDtwo", result);
            assertTrue(tq.isEmpty());
        }
    }
}