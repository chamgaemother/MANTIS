package org.apache.commons.math3.stat.inference;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.stat.inference.KolmogorovSmirnovTest;
import org.apache.commons.math3.exception.TooManyIterationsException;

public class KolmogorovSmirnovTest_pelzGood_0_2_Test {

    @Test
    @DisplayName("Input causing i13 loop to reach maximum iterations, triggering TooManyIterationsException")
    public void test_TC06_pelzGood_i13_max_iterations() {
        KolmogorovSmirnovTest test = new KolmogorovSmirnovTest();
        double d = 1e10; // Adjust value to trigger i13 max iterations
        int n = 1;
        Assertions.assertThrows(TooManyIterationsException.class, () -> {
            test.pelzGood(d, n);
        });
    }

    @Test
    @DisplayName("Input causing i14 loop to reach maximum iterations, triggering TooManyIterationsException")
    public void test_TC07_pelzGood_i14_max_iterations() {
        KolmogorovSmirnovTest test = new KolmogorovSmirnovTest();
        double d = 1e11; // Adjust value to trigger i14 max iterations
        int n = 2;
        Assertions.assertThrows(TooManyIterationsException.class, () -> {
            test.pelzGood(d, n);
        });
    }

    @Test
    @DisplayName("Input causing i15 loop to reach maximum iterations, triggering TooManyIterationsException")
    public void test_TC08_pelzGood_i15_max_iterations() {
        KolmogorovSmirnovTest test = new KolmogorovSmirnovTest();
        double d = 1e12; // Adjust value to trigger i15 max iterations
        int n = 3;
        Assertions.assertThrows(TooManyIterationsException.class, () -> {
            test.pelzGood(d, n);
        });
    }

    @Test
    @DisplayName("Input causing i16 loop to reach maximum iterations, triggering TooManyIterationsException")
    public void test_TC09_pelzGood_i16_max_iterations() {
        KolmogorovSmirnovTest test = new KolmogorovSmirnovTest();
        double d = 1e13; // Adjust value to trigger i16 max iterations
        int n = 4;
        Assertions.assertThrows(TooManyIterationsException.class, () -> {
            test.pelzGood(d, n);
        });
    }

    @Test
    @DisplayName("Input with negative d to verify method's behavior with negative distance")
    public void test_TC10_pelzGood_negative_distance() {
        KolmogorovSmirnovTest test = new KolmogorovSmirnovTest();
        double d = -1.0;
        int n = 10;
        double result = test.pelzGood(d, n);
        Assertions.assertTrue(result > 0, "Result should be positive for negative d");
    }
}