import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.xy.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DatasetUtilsTest {

    private XYDataset dataset;
    private List<Comparable> seriesKeys;
    private Range xRange;
    private double validYValue = 5.0;

    @BeforeEach
    public void setup() {
        dataset = mock(XYDataset.class);
        seriesKeys = Arrays.asList("Series1", "Series2");
        xRange = new Range(0.0, 10.0);
    }

    @Test
    public void testNullDatasetThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(null, seriesKeys, xRange, true);
        });
    }

    @Test
    public void testNullSeriesKeysThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(dataset, null, xRange, true);
        });
    }

    @Test
    public void testNullXRangeThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, null, true);
        });
    }

    @Test
    public void testEmptySeriesReturnsNull() {
        doReturn(0).when(dataset).getSeriesCount();
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, xRange, true);
        assertNull(range);
    }

    @Test
    public void testSingleSeriesContainingValidYValues() {
        doReturn(1).when(dataset).getSeriesCount();
        setupXYDataset(0);
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, xRange, true);
        assertEquals(new Range(validYValue, validYValue), range);
    }

    @Test
    public void testRangeWithNonOverlappingXValues() {
        doReturn(1).when(dataset).getSeriesCount();
        doReturn(5).when(dataset).getItemCount(0);
        doReturn(15.0).when(dataset).getXValue(0, 0);
        doReturn(validYValue).when(dataset).getYValue(0, 0);
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, xRange, true);
        assertNull(range);
    }

    @Test
    public void testRangeIncludingIntervalXYDataset() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        doReturn(1).when(dataset).getSeriesCount();
        doReturn(5).when(dataset).getItemCount(0);
        doReturn(5.0).when(dataset).getXValue(0, 0);
        doReturn(validYValue).when(dataset).getYValue(0, 0);
        doReturn(4.0).when(dataset).getStartYValue(0, 0);
        doReturn(6.0).when(dataset).getEndYValue(0, 0);
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, xRange, true);
        assertEquals(new Range(4.0, 6.0), range);
    }

    @Test
    public void testRangeIncludingBoxAndWhiskerXYDataset() {
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        doReturn(1).when(dataset).getSeriesCount();
        doReturn(5).when(dataset).getItemCount(0);
        doReturn(5.0).when(dataset).getXValue(0, 0);
        doReturn(validYValue).when(dataset).getYValue(0, 0);
        doReturn(4.0).when(dataset).getMinRegularValue(0, 0);
        doReturn(6.0).when(dataset).getMaxRegularValue(0, 0);
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, xRange, true);
        assertEquals(new Range(4.0, 6.0), range);
    }

    @Test
    public void testRangeIncludingOHLCDataset() {
        OHLCDataset dataset = mock(OHLCDataset.class);
        doReturn(1).when(dataset).getSeriesCount();
        doReturn(5).when(dataset).getItemCount(0);
        doReturn(5.0).when(dataset).getXValue(0, 0);
        doReturn(4.0).when(dataset).getLowValue(0, 0);
        doReturn(6.0).when(dataset).getHighValue(0, 0);
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, xRange, true);
        assertEquals(new Range(4.0, 6.0), range);
    }

    @Test
    public void testRangeWithNonNaNYValue() {
        setupXYDataset(0);
        doReturn(Double.NaN).when(dataset).getYValue(0, 1);
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, seriesKeys, xRange, false);
        assertEquals(new Range(validYValue, validYValue), range);
    }

    private void setupXYDataset(int series) {
        doReturn(5).when(dataset).getItemCount(series);
        doReturn(validYValue).when(dataset).getYValue(series, 0);
        doReturn(5.0).when(dataset).getXValue(series, 0);
    }
}