import org.apache.commons.compress.harmony.pack200.*;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class CodecEncodingTest {

    @Test
    void testCanonicalCodecLengthCheck() {
        try {
            CodecEncoding.getCodec(116, new ByteArrayInputStream(new byte[0]), null);
            fail("Expected Error");
        } catch (Error e) {
            assertTrue(e.getMessage().contains("Canonical encodings have been incorrectly modified"));
        } catch (Exception e) {
            fail("Unexpected exception type: " + e);
        }
    }

    @Test
    void testValueLessThanZero() {
        try {
            CodecEncoding.getCodec(-1, new ByteArrayInputStream(new byte[0]), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertEquals("Encoding cannot be less than zero", e.getMessage());
        } catch (Exception e) {
            fail("Unexpected exception type: " + e);
        }
    }

    @Test
    void testValueZeroUsesDefault() throws IOException, Pack200Exception {
        Codec defaultCodec = new BHSDCodec(1, 256);
        assertEquals(defaultCodec, CodecEncoding.getCodec(0, new ByteArrayInputStream(new byte[0]), defaultCodec));
    }

    @Test
    void testCanonicalValueReturnsCodec() throws IOException, Pack200Exception {
        for (int i = 1; i <= 115; i++) {
            assertNotNull(CodecEncoding.getCodec(i, new ByteArrayInputStream(new byte[0]), null));
        }
    }

    @Test
    void testValue116ReadsStream() throws IOException, Pack200Exception {
        byte[] input = {(byte) 0b00100011, 5}; // d = 1, s = 1, b = 3, h = 6
        BHSDCodec codec = (BHSDCodec) CodecEncoding.getCodec(116, new ByteArrayInputStream(input), null);
        assertEquals(3, codec.getB());
        assertEquals(6, codec.getH());
        assertEquals(1, codec.getS());
        assertEquals(1, codec.isDelta() ? 1 : 0);
    }

    @Test
    void testValue116StreamEOF() {
        try {
            CodecEncoding.getCodec(116, new ByteArrayInputStream(new byte[]{(byte) 0b00100011}), null);
            fail("Expected EOFException");
        } catch (EOFException e) {
            assertTrue(e.getMessage().contains("End of buffer read whilst trying to decode codec"));
        } catch (Exception e) {
            fail("Unexpected exception type: " + e);
        }
    }

    @Test
    void testValue117To140RunCodec() throws IOException, Pack200Exception {
        byte[] input = {4, 10, 20};
        RunCodec codec = (RunCodec) CodecEncoding.getCodec(117, new ByteArrayInputStream(input), new BHSDCodec(1, 256));
        assertNotNull(codec);
        assertEquals(1, codec.getK());
    }

    @Test
    void testInvalidCodecByteThrowsException() {
        try {
            CodecEncoding.getCodec(189, new ByteArrayInputStream(new byte[0]), null);
            fail("Expected Pack200Exception");
        } catch (Pack200Exception e) {
            assertTrue(e.getMessage().contains("Invalid codec encoding byte"));
        } catch (Exception e) {
            fail("Unexpected exception type: " + e);
        }
    }

    @Test
    void testValue141To188PopulationCodec() throws IOException, Pack200Exception {
        byte[] input = {1, 2, 3};
        PopulationCodec codec = (PopulationCodec) CodecEncoding.getCodec(141, new ByteArrayInputStream(input), new BHSDCodec(1, 256));
        assertNotNull(codec);
    }
}