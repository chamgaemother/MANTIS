package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class AdamsBashforthIntegrator_integrate_2_2_Test {

//     @Test
//     @DisplayName("Integration correctly handles last step to exactly reach target time")
//     void TC40_integrate_handle_step_acceptance_at_final_step() throws Exception {
        // GIVEN
//         AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5);
//         FirstOrderDifferentialEquations ode = new FirstOrderDifferentialEquations() {
//             @Override
//             public int getDimension() {
//                 return 3;
//             }
// 
//             @Override
//             public void computeDerivatives(double t, double[] y, double[] yDot) {
//                 yDot[0] = 1.0;
//                 yDot[1] = 0.0;
//                 yDot[2] = 0.0;
//             }
//         };
//         ExpandableStatefulODE equations = new ExpandableStatefulODE(ode);
//         equations.setTime(0.0);
//         equations.setCompleteState(new double[]{1.0, 2.0, 3.0});
// 
        // WHEN
//         integrator.integrate(equations, 10.0);
// 
        // THEN
//         assertEquals(10.0, equations.getTime(), 1e-10, "Time should reach target time exactly.");
// 
        // Verify that the final step size was adjusted to reach the target time exactly
//         Field stepSizeField = AdamsBashforthIntegrator.class.getDeclaredField("stepSize");
//         stepSizeField.setAccessible(true);
//         double finalStepSize = stepSizeField.getDouble(integrator);
//         assertEquals(10.0 - 0.0, finalStepSize, 1e-10, "Final step size should exactly reach the target time.");
//     }

    @Test
    @DisplayName("Integration stops and propagates exception during error-prone step")
    void TC41_integrate_handle_exceptionDuringStepProcessing() {
        // GIVEN
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5);
        FirstOrderDifferentialEquations ode = new FirstOrderDifferentialEquations() {
            @Override
            public int getDimension() {
                return 3;
            }

            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                // Create a condition to throw an exception
                throw new RuntimeException("Error updating Nordsieck vector");
            }
        };
        ExpandableStatefulODE equations = new ExpandableStatefulODE(ode);
        equations.setTime(0.0);
        equations.setCompleteState(new double[]{1.0, 2.0, 3.0});

        // WHEN & THEN
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> integrator.integrate(equations, 10.0));
        assertEquals("Error updating Nordsieck vector", thrown.getMessage(), "Exception message should match the thrown exception.");
    }
}