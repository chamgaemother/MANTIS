package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ClassUtils_isAssignable_1_5_Test {

    @Test
    @DisplayName("cls is non-primitive (Number) and toClass is non-assignable (String) with autoboxing=true")
    void TC26_nonPrimitiveToNonAssignable_withAutoboxingTrue() {
        // GIVEN
        Class<?> cls = Number.class;
        Class<?> toClass = String.class;
        boolean autoboxing = true;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is non-primitive (List) and toClass is interface (Collection) with autoboxing=true")
    void TC27_nonPrimitiveToInterface_withAutoboxingTrue() {
        // GIVEN
        Class<?> cls = List.class;
        Class<?> toClass = Collection.class;
        boolean autoboxing = true;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is non-primitive (Iterable) and toClass is interface (Collection) with autoboxing=false")
    void TC28_nonPrimitiveToInterface_withAutoboxingFalse() {
        // GIVEN
        Class<?> cls = Iterable.class;
        Class<?> toClass = Collection.class;
        boolean autoboxing = false;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is wrapper (Boolean) and toClass is primitive (boolean) with autoboxing=true")
    void TC29_wrapperToPrimitive_withAutoboxingTrue() {
        // GIVEN
        Class<?> cls = Boolean.class;
        Class<?> toClass = boolean.class;
        boolean autoboxing = true;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Character) and toClass is primitive (char) with autoboxing=true")
    void TC30_wrapperToPrimitive_withAutoboxingTrue() {
        // GIVEN
        Class<?> cls = Character.class;
        Class<?> toClass = char.class;
        boolean autoboxing = true;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertTrue(result);
    }

}