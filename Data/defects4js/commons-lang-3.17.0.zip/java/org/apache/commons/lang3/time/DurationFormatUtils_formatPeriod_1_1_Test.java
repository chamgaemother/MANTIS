package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.util.TimeZone;

public class DurationFormatUtils_formatPeriod_1_1_Test {

    @Test
    @DisplayName("Format with optional tokens and non-zero duration elements, ensuring optional blocks are included")
    void TC26() {
        // GIVEN
        long startMillis = 1609459200000L; // Jan 1, 2021 00:00 GMT
        long endMillis = 1609545600000L;   // Jan 2, 2021 00:00 GMT
        String format = "[d'D']H'h'm'm's's'";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        Assertions.assertEquals("1D0h0m0s", result);
    }

    @Test
    @DisplayName("Format with optional tokens and zero duration elements, ensuring optional blocks are excluded")
    void TC27() {
        // GIVEN
        long startMillis = 1609459200000L; // Jan 1, 2021 00:00 GMT
        long endMillis = 1609459200000L;   // Jan 1, 2021 00:00 GMT
        String format = "[d'D']H'h'm'm's's'";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        Assertions.assertEquals("", result);
    }

    @Test
    @DisplayName("Format with nested optional tokens, expecting IllegalArgumentException")
    void TC28() {
        // GIVEN
        long startMillis = 1609459200000L; // Jan 1, 2021 00:00 GMT
        long endMillis = 1609459200000L;   // Jan 1, 2021 00:00 GMT
        String format = "[[d'D']]H'h'm'm's's'";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        });
    }

    @Test
    @DisplayName("Format with alternating optional and mandatory tokens, ensuring correct inclusion")
    void TC29() {
        // GIVEN
        long startMillis = 1609459200000L; // Jan 1, 2021 00:00 GMT
        long endMillis = 1609462800000L;   // Jan 1, 2021 01:00 GMT
        String format = "[d'D']H'h'm'm's's'";
        boolean padWithZeros = false;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        Assertions.assertEquals("1h0m0s", result);
    }
}