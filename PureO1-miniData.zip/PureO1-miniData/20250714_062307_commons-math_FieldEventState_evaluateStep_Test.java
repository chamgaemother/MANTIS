import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.solvers.BracketedRealFieldUnivariateSolver;
import org.apache.commons.math3.field.Binary64;
import org.apache.commons.math3.field.Field;
import org.apache.commons.math3.ode.FieldODEState;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.apache.commons.math3.ode.sampling.FieldStepInterpolator;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FieldEventStateTest {

    private FieldEventHandler<Binary64> handler;
    private BracketedRealFieldUnivariateSolver<Binary64> solver;
    private FieldEventState<Binary64> eventState;
    private Field<Binary64> field;

    @BeforeEach
    void setUp() {
        handler = mock(FieldEventHandler.class);
        solver = mock(BracketedRealFieldUnivariateSolver.class);
        field = Binary64.FIELD;
        eventState = new FieldEventState<>(handler, 1.0, field.getOne(), 100, solver);
    }

    @Test
    void testEvaluateStep_SmallStep_NoEvent() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getOne(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())).thenReturn(field.getOne());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
        assertFalse(eventState.pendingEvent);
        assertNull(eventState.pendingEventTime);
    }

    @Test
    void testEvaluateStep_SmallStep_ExactlyAtConvergence() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        Binary64 convergence = field.getOne();
        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getOne(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any()).thenReturn(field.getOne());

        eventState = new FieldEventState<>(handler, 1.0, convergence, 100, solver);

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
    }

    @Test
    void testEvaluateStep_NoSignChange_NoEvent() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any()).thenReturn(field.getOne());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
        assertFalse(eventState.pendingEvent);
    }

    @Test
    void testEvaluateStep_SignChange_EventDetected() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenReturn(field.getOne());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertTrue(eventState.pendingEvent);
        assertEquals(field.getOne(), eventState.pendingEventTime);
    }

    @Test
    void testEvaluateStep_SignChange_RootTooClose_SkipEvent() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-0.5))
            .thenReturn(field.newInstance(1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenReturn(field.newInstance(0.5));

        eventState.previousEventTime = field.getZero();

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
        assertFalse(eventState.pendingEvent);
    }

    @Test
    void testEvaluateStep_SignChange_RootTooClose_HandleEvent() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenReturn(field.newInstance(0.1));

        eventState.previousEventTime = field.getZero();

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertTrue(eventState.pendingEvent);
        assertEquals(field.newInstance(0.1), eventState.pendingEventTime);
    }

    @Test
    void testEvaluateStep_FullStep_NoEvent() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEState previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTen(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any()).thenReturn(field.getOne());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
        assertFalse(eventState.pendingEvent);
    }

    @Test
    void testEvaluateStep_SolverThrowsMaxCountExceededException() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEState previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenThrow(new MaxCountExceededException(100));

        eventState.reinitializeBegin(interpolator);

        assertThrows(MaxCountExceededException.class, () -> {
            eventState.evaluateStep(interpolator);
        });
    }

    @Test
    void testEvaluateStep_SolverThrowsNoBracketingException() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEState previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenThrow(new NoBracketingException(field.getOne(), field.getTwo()));

        eventState.reinitializeBegin(interpolator);

        assertThrows(NoBracketingException.class, () -> {
            eventState.evaluateStep(interpolator);
        });
    }

    @Test
    void testEvaluateStep_NullInterpolator() {
        assertThrows(NullPointerException.class, () -> {
            eventState.evaluateStep(null);
        });
    }

    @Test
    void testEvaluateStep_G0Zero_IgnoreEventAtStart() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getZero())
            .thenReturn(field.getOne());

        when(interpolator.getInterpolatedState(any())).thenReturn(new FieldODEState<>(field.getOne(), field.getZero()));

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
        verify(handler, times(2)).g(any());
    }

    @Test
    void testEvaluateStep_IncreasingDirection() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenReturn(field.getOne());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertTrue(eventState.increasing);
    }

    @Test
    void testEvaluateStep_DecreasingDirection() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(false);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getTwo(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenReturn(field.getOne());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertFalse(eventState.increasing);
    }

    @Test
    void testEvaluateStep_MultipleSubsteps_NoEvent() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getTen(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any()).thenReturn(field.getOne());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
        verify(handler, atLeastOnce()).g(any());
    }

    @Test
    void testEvaluateStep_MultipleSubsteps_WithEvent() throws Exception {
        FieldStepInterpolator<Binary64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Binary64> previousState = new FieldODEState<>(field.getZero(), field.getZero());
        when(interpolator.getPreviousState()).thenReturn(previousState);

        FieldODEStateAndDerivative<Binary64> currentState = new FieldODEState<>(field.getThree(), field.getZero());
        when(interpolator.getCurrentState()).thenReturn(currentState);

        when(handler.g(any())
            .thenReturn(field.getOne())
            .thenReturn(field.getOne())
            .thenReturn(field.newInstance(-1.0));

        when(solver.solve(anyInt(), any(), any(), any(), any())).thenReturn(field.getTwo());

        eventState.reinitializeBegin(interpolator);

        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertTrue(eventState.pendingEvent);
        assertEquals(field.getTwo(), eventState.pendingEventTime);
    }

}