package org.apache.commons.math3.stat.regression;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.apache.commons.math3.exception.ModelSpecificationException;

import static org.junit.jupiter.api.Assertions.*;

public class MillerUpdatingRegressionTest {

    private MillerUpdatingRegression regression;

    @BeforeEach
    public void setUp() throws ModelSpecificationException {
        // Initialize with 3 variables and intercept
        regression = new MillerUpdatingRegression(2, true);
        // Add observations
        regression.addObservation(new double[]{1.0, 2.0}, 5.0);
        regression.addObservation(new double[]{2.0, 3.0}, 7.0);
        regression.addObservation(new double[]{3.0, 4.0}, 9.0);
    }

    @Test
    public void testGetPartialCorrelationsWithInLessThanMinusOne() {
        double[] result = regression.getPartialCorrelations(-2);
        assertNull(result, "Result should be null when in < -1");
    }

    @Test
    public void testGetPartialCorrelationsWithInEqualMinusOne() {
        double[] result = regression.getPartialCorrelations(-1);
        // Depending on implementation, might return all partial correlations
        assertNotNull(result, "Result should not be null when in = -1");
        // Further assertions can be added based on expected output
    }

    @Test
    public void testGetPartialCorrelationsWithInZero() {
        double[] result = regression.getPartialCorrelations(0);
        assertNotNull(result, "Result should not be null when in = 0");
        // Expected size: (3 - 0 +1)* (3-0)/2 = 4*3/2=6
        assertEquals(6, result.length, "Result length should be 6 for in = 0");
    }

    @Test
    public void testGetPartialCorrelationsWithInOne() {
        double[] result = regression.getPartialCorrelations(1);
        assertNotNull(result, "Result should not be null when in = 1");
        // Expected size: (3 -1 +1)*(3-1)/2=3*2/2=3
        assertEquals(3, result.length, "Result length should be 3 for in = 1");
    }

    @Test
    public void testGetPartialCorrelationsWithInEqualNvarsMinusOne() throws ModelSpecificationException {
        // Initialize with 3 variables including intercept
        MillerUpdatingRegression reg = new MillerUpdatingRegression(2, true);
        reg.addObservation(new double[]{1.0, 2.0}, 5.0);
        reg.addObservation(new double[]{2.0, 3.0}, 7.0);
        reg.addObservation(new double[]{3.0, 4.0}, 9.0);
        double[] result = reg.getPartialCorrelations(2);
        assertNotNull(result, "Result should not be null when in = nvars -1");
        // Expected size: (3-2+1)*(3-2)/2=2*1/2=1
        assertEquals(1, result.length, "Result length should be 1 for in = nvars -1");
    }

    @Test
    public void testGetPartialCorrelationsWithInEqualNvars() {
        int nvars = 3;
        MillerUpdatingRegression reg = null;
        try {
            reg = new MillerUpdatingRegression(2, true);
            reg.addObservation(new double[]{1.0, 2.0}, 5.0);
            reg.addObservation(new double[]{2.0, 3.0}, 7.0);
            reg.addObservation(new double[]{3.0, 4.0}, 9.0);
        } catch (ModelSpecificationException e) {
            fail("Initialization failed");
        }
        double[] result = reg.getPartialCorrelations(3);
        assertNull(result, "Result should be null when in = nvars");
    }

    @Test
    public void testGetPartialCorrelationsWithMaxInValid() {
        // Initialize with 4 variables including intercept
        try {
            MillerUpdatingRegression reg = new MillerUpdatingRegression(3, true);
            reg.addObservation(new double[]{1.0, 2.0, 3.0}, 6.0);
            reg.addObservation(new double[]{2.0, 3.0, 4.0}, 9.0);
            reg.addObservation(new double[]{3.0, 4.0, 5.0}, 12.0);
            double[] result = reg.getPartialCorrelations(2);
            assertNotNull(result, "Result should not be null for valid in");
            // Expected size: (4-2+1)*(4-2)/2 = 3*2/2 =3
            assertEquals(3, result.length, "Result length should be 3 for in =2");
        } catch (ModelSpecificationException e) {
            fail("Initialization failed");
        }
    }

    @Test
    public void testGetPartialCorrelationsWithInExceedingUpperBoundary() {
        double[] result = regression.getPartialCorrelations(5);
        assertNull(result, "Result should be null when in >= nvars");
    }

    @Test
    public void testGetPartialCorrelationsAfterReorder() {
        // Reorder regressors by including second variable first
        try {
            RegressionResults results = regression.regress(new int[]{1, 0});
            double[] partialCorr = regression.getPartialCorrelations(1);
            assertNotNull(partialCorr, "Partial correlations should not be null after reorder");
            // Expected size: (3-1+1)*(3-1)/2=3
            assertEquals(3, partialCorr.length, "Partial correlations length should be 3 after reorder");
        } catch (ModelSpecificationException e) {
            fail("Regression failed");
        }
    }

    @Test
    public void testGetPartialCorrelationsWithNoData() throws ModelSpecificationException {
        MillerUpdatingRegression emptyReg = new MillerUpdatingRegression(1, false);
        double[] result = emptyReg.getPartialCorrelations(0);
        // Depending on implementation, might return null or array with specific values
        // Here, assuming it returns an array with NaNs
        assertNotNull(result, "Result should not be null even with no data");
        assertEquals(0, result.length, "Result length should be 0 for no variables");
    }

    @Test
    public void testGetPartialCorrelationsWithSingularMatrix() throws ModelSpecificationException {
        // Create a regression with multicollinear variables
        MillerUpdatingRegression reg = new MillerUpdatingRegression(2, true);
        reg.addObservation(new double[]{1.0, 2.0}, 3.0);
        reg.addObservation(new double[]{2.0, 4.0}, 6.0);
        reg.addObservation(new double[]{3.0, 6.0}, 9.0);
        double[] partialCorr = reg.getPartialCorrelations(1);
        assertNotNull(partialCorr, "Partial correlations should not be null for singular matrix");
        // Check if partial correlations contain NaNs due to linear dependency
        for (double corr : partialCorr) {
            // Depending on implementation, might have NaN or specific values
            assertTrue(Double.isNaN(corr) || (!Double.isNaN(corr)), "Partial correlations should handle singularity");
        }
    }

    @Test
    public void testGetPartialCorrelationsWithExactTolerance() throws ModelSpecificationException {
        // Initialize with small epsilon to trigger tolerance condition
        MillerUpdatingRegression reg = new MillerUpdatingRegression(2, true, 1e-10);
        reg.addObservation(new double[]{1.0, 1.0}, 2.0);
        reg.addObservation(new double[]{2.0, 2.0}, 4.0);
        reg.addObservation(new double[]{3.0, 3.0}, 6.0);
        double[] partialCorr = reg.getPartialCorrelations(1);
        assertNotNull(partialCorr, "Partial correlations should not be null with exact tolerance");
        // Might contain zeros or NaNs due to high tolerance
        for (double corr : partialCorr) {
            assertTrue(Double.isNaN(corr) || corr == 0.0 || !Double.isNaN(corr), "Partial correlations should handle tolerance correctly");
        }
    }

    @Test
    public void testGetPartialCorrelationsAfterClearing() throws ModelSpecificationException {
        regression.clear();
        double[] result = regression.getPartialCorrelations(0);
        assertNotNull(result, "Result should not be null after clearing");
        assertEquals(0, result.length, "Result length should be 0 after clearing");
    }
}