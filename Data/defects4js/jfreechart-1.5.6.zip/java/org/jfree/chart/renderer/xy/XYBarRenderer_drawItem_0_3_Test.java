package org.jfree.chart.renderer.xy;
import org.jfree.chart.ui.RectangleEdge;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class XYBarRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem handles zero visible series correctly")
    void TC11_drawItem_handles_zero_visible_series_correctly() throws Exception {
        // Arrange
        XYBarRenderer renderer = spy(new XYBarRenderer());
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Set up the renderer to have no visible series
        when(dataset.getSeriesCount()).thenReturn(5);
        for (int i = 0; i < 5; i++) {
            doReturn(false).when(renderer).isSeriesVisible(i);
        }

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        // Verify that no bars are drawn by ensuring paintBar and paintBarShadow are not called
        verify(renderer, never()).getBarPainter();
    }

    @Test
    @DisplayName("drawItem handles multiple visible series")
    void TC12_drawItem_handles_multiple_visible_series() throws Exception {
        // Arrange
        XYBarRenderer renderer = spy(new XYBarRenderer());
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Set up the renderer to have multiple visible series
        when(dataset.getSeriesCount()).thenReturn(3);
        for (int i = 0; i < 3; i++) {
            doReturn(true).when(renderer).isSeriesVisible(i);
        }

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        // Verify that bars are drawn proportionally by checking paintBar is called expected number of times
        verify(renderer.getBarPainter(), atLeastOnce()).paintBar(any(Graphics2D.class), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), any(RectangleEdge.class));
    }

    @Test
    @DisplayName("drawItem calculates seriesBarWidth correctly")
    void TC13_drawItem_calculates_seriesBarWidth_correctly() throws Exception {
        // Arrange
        XYBarRenderer renderer = spy(new XYBarRenderer());
        
        // Use reflection to set private fields if necessary
        Field marginField = XYBarRenderer.class.getDeclaredField("margin");
        marginField.setAccessible(true);
        marginField.set(renderer, 0.1);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Set up dataset
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(true);
        when(intervalDataset.getStartYValue(0, 0)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(0, 0)).thenReturn(20.0);
        when(renderer.getBase()).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        when(dataset.getSeriesCount()).thenReturn(2);
        doReturn(true).when(renderer).isSeriesVisible(0);
        doReturn(true).when(renderer).isSeriesVisible(1);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        // Access seriesBarWidth via reflection to verify calculation
        // Since domainAxis.valueToJava2D is mocked and not returning real values, verify the number of times paintBar was called
        verify(renderer.getBarPainter(), atLeastOnce()).paintBar(any(Graphics2D.class), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), any(RectangleEdge.class));
    }

    @Test
    @DisplayName("drawItem draws bar when orientation is HORIZONTAL")
    void TC14_drawItem_draws_bar_when_orientation_horizontal() throws Exception {
        // Arrange
        XYBarRenderer renderer = spy(new XYBarRenderer());
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Set plot orientation to HORIZONTAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        // Set up dataset
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(renderer.getBase()).thenReturn(5.0);
        when(intervalDataset.getYValue(0, 0)).thenReturn(15.0);
        when(intervalDataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(intervalDataset.getEndXValue(0, 0)).thenReturn(2.0);

        when(dataset.getSeriesCount()).thenReturn(2);
        doReturn(true).when(renderer).isSeriesVisible(0);
        doReturn(true).when(renderer).isSeriesVisible(1);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // Assert
        // Verify that paintBar is called with a horizontally drawn bar
        ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(renderer.getBarPainter(), atLeastOnce()).paintBar(eq(g2), eq(renderer), eq(0), eq(0), rectCaptor.capture(), any(RectangleEdge.class));
        for (Rectangle2D rect : rectCaptor.getAllValues()) {
            // In horizontal orientation, width should correspond to intervalH
            assertTrue(rect.getWidth() > 0, "Bar width should be positive for horizontal orientation");
        }
    }

    @Test
    @DisplayName("drawItem draws bar when orientation is VERTICAL")
    void TC15_drawItem_draws_bar_when_orientation_vertical() throws Exception {
        // Arrange
        XYBarRenderer renderer = spy(new XYBarRenderer());
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Set plot orientation to VERTICAL
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Set up dataset
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(renderer.getBase()).thenReturn(5.0);
        when(intervalDataset.getYValue(0, 0)).thenReturn(15.0);
        when(intervalDataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(intervalDataset.getEndXValue(0, 0)).thenReturn(2.0);

        when(dataset.getSeriesCount()).thenReturn(2);
        doReturn(true).when(renderer).isSeriesVisible(0);
        doReturn(true).when(renderer).isSeriesVisible(1);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // Assert
        // Verify that paintBar is called with a vertically drawn bar
        ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(renderer.getBarPainter(), atLeastOnce()).paintBar(eq(g2), eq(renderer), eq(0), eq(0), rectCaptor.capture(), any(RectangleEdge.class));
        for (Rectangle2D rect : rectCaptor.getAllValues()) {
            // In vertical orientation, height should correspond to intervalH
            assertTrue(rect.getHeight() > 0, "Bar height should be positive for vertical orientation");
        }
    }
}