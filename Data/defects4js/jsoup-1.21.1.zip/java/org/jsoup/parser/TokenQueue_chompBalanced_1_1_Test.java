package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jsoup.parser.TokenQueue;

public class TokenQueue_chompBalanced_1_1_Test {

    @Test
    @DisplayName("ChompBalanced with different open '{' and close '}' characters handles balanced input correctly")
    void TC24() {
        TokenQueue queue = new TokenQueue("{}");
        String result = queue.chompBalanced('{', '}');
        assertEquals("", result);
    }

    @Test
    @DisplayName("ChompBalanced with unmatched different open '{' and close ']' characters throws exception")
    void TC25() {
        TokenQueue queue = new TokenQueue("{]");
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            queue.chompBalanced('{', ']');
        });
        assertTrue(exception.getMessage().contains("Did not find balanced marker"));
    }

    @Test
    @DisplayName("ChompBalanced with escaped open character '\\{' inside input")
    void TC26() {
        TokenQueue queue = new TokenQueue("\\{a}");
        String result = queue.chompBalanced('{', '}');
        assertEquals("{a", result);
    }

    @Test
    @DisplayName("ChompBalanced with escaped close character '\\}' inside input")
    void TC27() {
        TokenQueue queue = new TokenQueue("\\}a}");
        String result = queue.chompBalanced('{', '}');
        assertEquals("}a", result);
    }

    @Test
    @DisplayName("ChompBalanced with invalid escape sequence throws exception")
    void TC28() {
        TokenQueue queue = new TokenQueue("\\x{a}");
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            queue.chompBalanced('{', '}');
        });
        assertTrue(exception.getMessage().contains("Did not find balanced marker"));
    }
}