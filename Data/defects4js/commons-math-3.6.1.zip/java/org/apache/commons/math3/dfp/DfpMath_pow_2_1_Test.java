package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class DfpMath_pow_2_1_Test {

    @Test
    @DisplayName("pow(x=3.0, y=7) correctly computes x^7 through multiple loop iterations")
    public void TC48_pow_3_to_7() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(128);
        
        // Create base Dfp
        Dfp base = new Dfp(field, "3.0");
        
        // Exponent y
        int y = 7;
        
        // Call the method under test
        Dfp result = DfpMath.pow(base, y);
        
        // Expected result
        Dfp expected = new Dfp(field, "2187.0");
        
        // Assertion
        assertEquals(expected, result, "pow(3.0, 7) should be 2187.0");
    }
    
    @Test
    @DisplayName("pow(x=2.0, y=8) correctly computes x^8 through multiple loop iterations")
    public void TC49_pow_2_to_8() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(128);
        
        // Create base Dfp
        Dfp base = new Dfp(field, "2.0");
        
        // Exponent y
        int y = 8;
        
        // Call the method under test
        Dfp result = DfpMath.pow(base, y);
        
        // Expected result
        Dfp expected = new Dfp(field, "256.0");
        
        // Assertion
        assertEquals(expected, result, "pow(2.0, 8) should be 256.0");
    }
}