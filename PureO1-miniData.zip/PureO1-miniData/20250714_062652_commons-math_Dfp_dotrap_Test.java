package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.apache.commons.math3.exception.DimensionMismatchException;

import static org.junit.jupiter.api.Assertions.*;

class DfpTest {

    private static class DfpTestHelper extends Dfp {
        public DfpTestHelper(DfpField field) {
            super(field);
        }

        public DfpTestHelper(DfpField field, int[] mant, byte sign, int exp, byte nans) {
            super(field);
            this.mant = mant.clone();
            this.sign = sign;
            this.exp = exp;
            this.nans = nans;
        }

        @Override
        protected Dfp dotrap(int type, String what, Dfp oper, Dfp result) {
            return super.dotrap(type, what, oper, result);
        }

        // Expose mant for testing
        public int[] getMant() {
            return mant.clone();
        }
    }

    @Test
    void testDotrapInvalid() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp oper = dfp.newInstance(1);
        Dfp result = dfp.newInstance(2);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_INVALID, "testInvalid", oper, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(Dfp.QNAN, trapped.nans);
    }

    @Test
    void testDotrapDivZeroFiniteNonZeroMant() {
        DfpField field = new DfpField(4);
        int[] mant = new int[field.getRadixDigits()];
        mant[mant.length - 1] = 1; // non-zero mantissa
        DfpTestHelper dfp = new DfpTestHelper(field, mant, (byte)1, 0, Dfp.FINITE);
        Dfp oper = dfp.newInstance(1);
        Dfp result = dfp.newInstance(2);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_DIV_ZERO, "testDivZeroFiniteNonZero", oper, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals((byte)1, trapped.sign);
        assertEquals(Dfp.INFINITE, trapped.nans);
    }

    @Test
    void testDotrapDivZeroFiniteZeroMant() {
        DfpField field = new DfpField(4);
        int[] mant = new int[field.getRadixDigits()];
        DfpTestHelper dfp = new DfpTestHelper(field, mant, (byte)1, 0, Dfp.FINITE);
        Dfp oper = dfp.newInstance(0);
        Dfp result = dfp.newInstance(0);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_DIV_ZERO, "testDivZeroFiniteZero", oper, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(Dfp.QNAN, trapped.nans);
    }

    @Test
    void testDotrapDivZeroInfinite() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        dfp.nans = Dfp.INFINITE;
        int[] mant = new int[field.getRadixDigits()];
        DfpTestHelper oper = new DfpTestHelper(field, mant, (byte)1, 0, Dfp.FINITE);
        Dfp result = dfp.newInstance(0);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_DIV_ZERO, "testDivZeroInfinite", oper, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(Dfp.QNAN, trapped.nans);
    }

    @Test
    void testDotrapDivZeroQnan() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        dfp.nans = Dfp.QNAN;
        Dfp oper = dfp.newInstance(1);
        Dfp result = dfp.newInstance(2);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_DIV_ZERO, "testDivZeroQnan", oper, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(Dfp.QNAN, trapped.nans);
    }

    @Test
    void testDotrapDivZeroSnan() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        dfp.nans = Dfp.SNAN;
        Dfp oper = dfp.newInstance(1);
        Dfp result = dfp.newInstance(2);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_DIV_ZERO, "testDivZeroSnan", oper, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(Dfp.QNAN, trapped.nans);
    }

    @Test
    void testDotrapUnderflowBelowMinExp() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field);
        result.exp = Dfp.MIN_EXP - field.getRadixDigits();
        result.sign = 1;
        Dfp trapped = dfp.dotrap(DfpField.FLAG_UNDERFLOW, "testUnderflowBelowMinExp", null, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(1, trapped.sign);
    }

    @Test
    void testDotrapUnderflowAboveMinExp() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field);
        result.exp = Dfp.MIN_EXP - field.getRadixDigits() + 1;
        result.sign = -1;
        Dfp trapped = dfp.dotrap(DfpField.FLAG_UNDERFLOW, "testUnderflowAboveMinExp", null, result);
        assertEquals(result, trapped);
    }

    @Test
    void testDotrapOverflow() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field);
        result.exp = Dfp.MAX_EXP + 1;
        result.sign = -1;
        result.nans = Dfp.INFINITE;
        Dfp trapped = dfp.dotrap(DfpField.FLAG_OVERFLOW, "testOverflow", null, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(-1, trapped.sign);
        assertEquals(Dfp.INFINITE, trapped.nans);
    }

    @Test
    void testDotrapDefault() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp oper = dfp.newInstance(1);
        Dfp result = dfp.newInstance(2);
        Dfp trapped = dfp.dotrap(9999, "testDefault", oper, result);
        assertEquals(result, trapped);
    }

    @Test
    void testDotrapInvalidNullOper() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = dfp.newInstance(2);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_INVALID, "testInvalidNullOper", null, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(Dfp.QNAN, trapped.nans);
    }

    @Test
    void testDotrapUnderflowPositive() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field, new int[field.getRadixDigits()], (byte)1, Dfp.MIN_EXP - field.getRadixDigits() + 1, Dfp.FINITE);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_UNDERFLOW, "testUnderflowPositive", null, result);
        assertEquals(result, trapped);
    }

    @Test
    void testDotrapUnderflowNegative() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field, new int[field.getRadixDigits()], (byte)-1, Dfp.MIN_EXP - field.getRadixDigits(), Dfp.FINITE);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_UNDERFLOW, "testUnderflowNegative", null, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(-1, trapped.sign);
    }

    @Test
    void testDotrapOverflowPositive() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field, new int[field.getRadixDigits()], (byte)1, Dfp.MAX_EXP + 10, Dfp.FINITE);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_OVERFLOW, "testOverflowPositive", null, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(1, trapped.sign);
        assertEquals(Dfp.INFINITE, trapped.nans);
    }

    @Test
    void testDotrapOverflowNegative() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field, new int[field.getRadixDigits()], (byte)-1, Dfp.MAX_EXP + 5, Dfp.FINITE);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_OVERFLOW, "testOverflowNegative", null, result);
        assertEquals(0, trapped.getZero().getMant()[0]);
        assertEquals(-1, trapped.sign);
        assertEquals(Dfp.INFINITE, trapped.nans);
    }

    @Test
    void testDotrapUnderflowGradual() {
        DfpField field = new DfpField(4);
        DfpTestHelper dfp = new DfpTestHelper(field);
        Dfp result = new DfpTestHelper(field, new int[field.getRadixDigits()], (byte)1, Dfp.MIN_EXP - field.getRadixDigits() + 2, Dfp.FINITE);
        Dfp trapped = dfp.dotrap(DfpField.FLAG_UNDERFLOW, "testUnderflowGradual", null, result);
        assertEquals(result, trapped);
    }

}