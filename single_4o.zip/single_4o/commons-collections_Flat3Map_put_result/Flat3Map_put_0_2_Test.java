package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;

public class Flat3Map_put_0_2_Test {

    @Test
    @DisplayName("Replace existing key2 in non-delegate map")
    void replaceExistingKey2() throws Exception {
        Flat3Map map = new Flat3Map();
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Object key = new Object();
        Object value = new Object();
        Object newValue = new Object();

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key);

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, key.hashCode());

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, value);

        Object result = map.put(key, newValue);

        assertEquals(newValue, value2Field.get(map));
        assertEquals(value, result);
    }

    @Test
    @DisplayName("Attempt to add null key to non-full map increments size")
    void addNullKeyToNonFullMap() throws Exception {
        Flat3Map map = new Flat3Map();
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Object value = new Object();
        Object result = map.put(null, value);

        assertEquals(3, sizeField.getInt(map));
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);

        assertNull(key3Field.get(map));
        assertEquals(value, value3Field.get(map));
        assertNull(result);
    }

    @Test
    @DisplayName("Attempt to insert duplicate hash but different key does not convert")
    void insertDuplicateHashDifferentKey() throws Exception {
        Flat3Map map = new Flat3Map();
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        Object key = new Object() { @Override public int hashCode() { return 1; } };
        Object differentKey = new Object() { @Override public int hashCode() { return 1; } };

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key);

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, key.hashCode());

        map.put(differentKey, new Object());

        assertEquals(2, sizeField.getInt(map));

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);

        assertEquals(differentKey, key2Field.get(map));
    }

    @Test
    @DisplayName("Insert non-null key into filled map leads to conversion")
    void insertNonNullKeyLeadsToConversion() throws Exception {
        Flat3Map map = new Flat3Map();
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Object key4 = new Object();

        map.put(key4, new Object());

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);

        assertNotNull(delegateMapField.get(map));
        assertTrue(((java.util.Map<?, ?>) delegateMapField.get(map)).containsKey(key4));
    }

    @Test
    @DisplayName("Replacing key3 with non-null key successfully updates value and returns old")
    void replaceKey3AndUpdateValue() throws Exception {
        Flat3Map map = new Flat3Map();
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Object key = new Object();
        Object value = new Object();
        Object newValue = new Object();

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, key);

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, key.hashCode());

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, value);

        Object result = map.put(key, newValue);

        assertEquals(newValue, value3Field.get(map));
        assertEquals(value, result);
    }
}