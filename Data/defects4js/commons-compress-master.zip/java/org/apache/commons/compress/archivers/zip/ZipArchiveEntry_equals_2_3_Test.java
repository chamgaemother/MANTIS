package org.apache.commons.compress.archivers.zip;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ZipArchiveEntry_equals_2_3_Test {
    
    @Test
    @DisplayName("equals() returns false when both ZipArchiveEntries have different generalPurposeBit")
    void TC41_equals_DifferentGeneralPurposeBit() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        GeneralPurposeBit bit1 = new GeneralPurposeBit();
        bit1.useUTF8ForNames(true);
        entry1.setGeneralPurposeBit(bit1);

        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        GeneralPurposeBit bit2 = new GeneralPurposeBit();
        bit2.useEncryption(true);
        entry2.setGeneralPurposeBit(bit2);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertFalse(result, "equals() should return false when GeneralPurposeBit configurations differ");
    }
    
    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntries have identical generalPurposeBit")
    void TC42_equals_IdenticalGeneralPurposeBit() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        GeneralPurposeBit bit1 = new GeneralPurposeBit();
        bit1.useUTF8ForNames(true);
        entry1.setGeneralPurposeBit(bit1);

        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        GeneralPurposeBit bit2 = new GeneralPurposeBit();
        bit2.useUTF8ForNames(true);
        entry2.setGeneralPurposeBit(bit2);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertTrue(result, "equals() should return true when GeneralPurposeBit configurations are identical");
    }
    
    @Test
    @DisplayName("equals() returns false when centralDirectoryExtra arrays are different")
    void TC43_equals_DifferentCentralDirectoryExtra() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        byte[] centralExtra1 = {1, 2, 3};
        entry1.setCentralDirectoryExtra(centralExtra1);

        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        byte[] centralExtra2 = {4, 5, 6};
        entry2.setCentralDirectoryExtra(centralExtra2);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertFalse(result, "equals() should return false when centralDirectoryExtra arrays are different");
    }
    
    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntries have identical centralDirectoryExtra arrays")
    void TC44_equals_IdenticalCentralDirectoryExtra() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        byte[] centralExtra = {1, 2, 3};
        entry1.setCentralDirectoryExtra(centralExtra);

        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setCentralDirectoryExtra(centralExtra);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertTrue(result, "equals() should return true when centralDirectoryExtra arrays are identical");
    }
    
    @Test
    @DisplayName("equals() returns false when localFileDataExtra arrays differ")
    void TC45_equals_DifferentLocalFileDataExtra() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        byte[] localExtra1 = {7, 8, 9};
        entry1.setExtra(localExtra1);

        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        byte[] localExtra2 = {10, 11, 12};
        entry2.setExtra(localExtra2);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertFalse(result, "equals() should return false when localFileDataExtra arrays are different");
    }
}