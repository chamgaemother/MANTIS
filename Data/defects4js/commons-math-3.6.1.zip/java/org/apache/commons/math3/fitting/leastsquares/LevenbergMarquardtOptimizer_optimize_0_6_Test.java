package org.apache.commons.math3.fitting.leastsquares;

import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem.Evaluation;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.apache.commons.math3.util.Incrementor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class LevenbergMarquardtOptimizer_optimize_0_6_Test {

    @Test
    @DisplayName("Optimize correctly handles scaled directional derivative and predicted reduction")
    public void TC26_optimize_handles_scaled_directional_derivative_and_predicted_reduction() {
        // GIVEN
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        Incrementor iterationCounter = mock(Incrementor.class);
        Incrementor evaluationCounter = mock(Incrementor.class);
        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);

        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getIterationCounter()).thenReturn(iterationCounter);
        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
        when(problem.getConvergenceChecker()).thenReturn(checker);

        double[] start = new double[5];
        ArrayRealVector startVector = new ArrayRealVector(start);
        when(problem.getStart()).thenReturn(startVector);

        // Mock Evaluation
        Evaluation evaluation = mock(Evaluation.class);
        double[] residuals = new double[10];
        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(residuals));
        when(evaluation.getCost()).thenReturn(1.0);
        double[] point = new double[5];
        ArrayRealVector pointVector = new ArrayRealVector(point);
        when(evaluation.getPoint()).thenReturn(pointVector);

        when(problem.evaluate(startVector)).thenReturn(evaluation);

        // WHEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);

        // THEN
        Assertions.assertNotNull(optimum, "Optimum should not be null");
        // Additional assertions can be added here to verify scaled directional derivative and predicted reduction
    }

    @Test
    @DisplayName("Optimize handles Zero xNorm correctly when starting point is zero vector")
    public void TC27_optimize_handles_zero_xNorm_with_zero_starting_point() {
        // GIVEN
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        Incrementor iterationCounter = mock(Incrementor.class);
        Incrementor evaluationCounter = mock(Incrementor.class);
        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);

        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getIterationCounter()).thenReturn(iterationCounter);
        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
        when(problem.getConvergenceChecker()).thenReturn(checker);

        double[] start = new double[5]; // Zero vector
        ArrayRealVector startVector = new ArrayRealVector(start);
        when(problem.getStart()).thenReturn(startVector);

        // Mock Evaluation
        Evaluation evaluation = mock(Evaluation.class);
        double[] residuals = new double[10];
        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(residuals));
        when(evaluation.getCost()).thenReturn(0.0);
        double[] point = new double[5];
        ArrayRealVector pointVector = new ArrayRealVector(point);
        when(evaluation.getPoint()).thenReturn(pointVector);

        when(problem.evaluate(startVector)).thenReturn(evaluation);

        // WHEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);

        // THEN
        Assertions.assertNotNull(optimum, "Optimum should not be null");
        // Additional assertions to verify delta initialization can be added here
    }

    @Test
    @DisplayName("Optimize throws ConvergenceException when cost reduction is too small")
    public void TC28_optimize_throws_when_cost_reduction_too_small() {
        // GIVEN
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        Incrementor iterationCounter = mock(Incrementor.class);
        Incrementor evaluationCounter = mock(Incrementor.class);
        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);

        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getIterationCounter()).thenReturn(iterationCounter);
        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
        when(problem.getConvergenceChecker()).thenReturn(checker);

        double[] start = new double[5];
        ArrayRealVector startVector = new ArrayRealVector(start);
        when(problem.getStart()).thenReturn(startVector);

        // Mock Evaluation with tiny cost reduction
        Evaluation evaluation = mock(Evaluation.class);
        double[] residuals = new double[10];
        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(residuals));
        when(evaluation.getCost()).thenReturn(Double.MIN_VALUE); // Very small cost
        double[] point = new double[5];
        ArrayRealVector pointVector = new ArrayRealVector(point);
        when(evaluation.getPoint()).thenReturn(pointVector);

        when(problem.evaluate(startVector)).thenReturn(evaluation);

        // WHEN & THEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();

        Assertions.assertThrows(ConvergenceException.class, () -> {
            optimizer.optimize(problem);
        }, "Expected ConvergenceException due to too small cost reduction");
    }

    @Test
    @DisplayName("Optimize throws ConvergenceException when parameter reduction is too small")
    public void TC29_optimize_throws_when_parameter_reduction_too_small() {
        // GIVEN
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        Incrementor iterationCounter = mock(Incrementor.class);
        Incrementor evaluationCounter = mock(Incrementor.class);
        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);

        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getIterationCounter()).thenReturn(iterationCounter);
        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
        when(problem.getConvergenceChecker()).thenReturn(checker);

        double[] start = new double[5];
        ArrayRealVector startVector = new ArrayRealVector(start);
        when(problem.getStart()).thenReturn(startVector);

        // Mock Evaluation with tiny parameter reduction
        Evaluation evaluation = mock(Evaluation.class);
        double[] residuals = new double[10];
        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(residuals));
        when(evaluation.getCost()).thenReturn(1.0);
        double[] point = new double[5];
        Arrays.fill(point, Double.MIN_VALUE); // Very small parameter changes
        ArrayRealVector pointVector = new ArrayRealVector(point);
        when(evaluation.getPoint()).thenReturn(pointVector);

        when(problem.evaluate(startVector)).thenReturn(evaluation);

        // WHEN & THEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();

        Assertions.assertThrows(ConvergenceException.class, () -> {
            optimizer.optimize(problem);
        }, "Expected ConvergenceException due to too small parameter reduction");
    }

    @Test
    @DisplayName("Optimize handles multiple permutation scenarios in QR decomposition correctly")
    public void TC30_optimize_handles_multiple_permutations_in_qr_decomposition() {
        // GIVEN
        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
        Incrementor iterationCounter = mock(Incrementor.class);
        Incrementor evaluationCounter = mock(Incrementor.class);
        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);

        when(problem.getObservationSize()).thenReturn(10);
        when(problem.getParameterSize()).thenReturn(5);
        when(problem.getIterationCounter()).thenReturn(iterationCounter);
        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
        when(problem.getConvergenceChecker()).thenReturn(checker);

        double[] start = new double[5];
        Arrays.fill(start, 1.0); // Some non-zero starting point
        ArrayRealVector startVector = new ArrayRealVector(start);
        when(problem.getStart()).thenReturn(startVector);

        // Mock Evaluation with multiple permutations
        Evaluation evaluation = mock(Evaluation.class);
        double[] residuals = new double[10];
        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(residuals));
        when(evaluation.getCost()).thenReturn(1.0);
        double[] point = new double[5];
        Arrays.fill(point, 1.0);
        ArrayRealVector pointVector = new ArrayRealVector(point);
        when(evaluation.getPoint()).thenReturn(pointVector);

        when(problem.evaluate(startVector)).thenReturn(evaluation);

        // WHEN
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);

        // THEN
        Assertions.assertNotNull(optimum, "Optimum should not be null");
        // Additional assertions to verify QR decomposition and permutation handling
    }
}
