package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_pow_0_3_Test {

    @Test
    @DisplayName("pow(x, y) returns Double.NaN when x is negative and y is non-integer")
    void pow_negative_x_non_integer_y() {
        double x = -2.0;
        double y = 3.5;
        double result = FastMath.pow(x, y);
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("pow(0.0, y) returns +0.0 when y > 0")
    void pow_zero_positive_y() {
        double x = 0.0;
        double y = 2.0;
        double result = FastMath.pow(x, y);
        assertEquals(+0.0, result);
    }

    @Test
    @DisplayName("pow(0.0, y) returns Double.POSITIVE_INFINITY when y < 0")
    void pow_zero_negative_y() {
        double x = 0.0;
        double y = -2.0;
        double result = FastMath.pow(x, y);
        assertEquals(Double.POSITIVE_INFINITY, result);
    }

    @Test
    @DisplayName("pow(Double.POSITIVE_INFINITY, y) returns Double.POSITIVE_INFINITY when y > 0")
    void pow_positive_infinity_y_positive() {
        double x = Double.POSITIVE_INFINITY;
        double y = 3.0;
        double result = FastMath.pow(x, y);
        assertEquals(Double.POSITIVE_INFINITY, result);
    }

    @Test
    @DisplayName("pow(Double.POSITIVE_INFINITY, y) returns +0.0 when y < 0")
    void pow_positive_infinity_y_negative() {
        double x = Double.POSITIVE_INFINITY;
        double y = -2.0;
        double result = FastMath.pow(x, y);
        assertEquals(+0.0, result);
    }
}