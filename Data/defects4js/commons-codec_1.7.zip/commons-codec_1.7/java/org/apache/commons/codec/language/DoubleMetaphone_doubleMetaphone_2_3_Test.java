package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_2_3_Test {

    @Test
    @DisplayName("doubleMetaphone(\"ZZZ\", false) handles triple 'Z'")
    public void TC61_doubleMetaphone_HandlesTripleZ() throws Exception {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "ZZZ";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertEquals("SSS", result, "The doubleMetaphone should return 'SSS' for input 'ZZZ'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"DANGER\", false) handles 'G' before 'E'")
    public void TC62_doubleMetaphone_HandlesGBeforeE() throws Exception {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "DANGER";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertEquals("DJNR", result, "The doubleMetaphone should return 'DJNR' for input 'DANGER'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"GHANA\", false) handles 'GH' after consonant'")
    public void TC63_doubleMetaphone_HandlesGHAfterConsonant() throws Exception {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GHANA";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertEquals("KNNA", result, "The doubleMetaphone should return 'KNNA' for input 'GHANA'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"PHRASE\", false) handles 'PH' combination'")
    public void TC64_doubleMetaphone_HandlesPHCombination() throws Exception {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "PHRASE";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertEquals("FRS", result, "The doubleMetaphone should return 'FRS' for input 'PHRASE'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"SCHMUCK\", false) handles 'SCH' combination'")
    public void TC65_doubleMetaphone_HandlesSCHCombination() throws Exception {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "SCHMUCK";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertEquals("SKMK", result, "The doubleMetaphone should return 'SKMK' for input 'SCHMUCK'");
    }
}