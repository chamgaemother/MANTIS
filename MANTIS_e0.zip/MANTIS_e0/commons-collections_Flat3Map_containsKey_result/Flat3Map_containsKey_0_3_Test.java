package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class Flat3Map_containsKey_0_3_Test {

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, and size <= 0")
    void TC11_containsKey_returnsFalse_delegateMapNull_nonNullKey_size0() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Setting size to 0
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setInt(map, 0);

        // WHEN
        boolean result = map.containsKey("key1");

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, size > 0, and hashCode does not match any key")
    void TC12_containsKey_returnsFalse_delegateMapNull_nonNullKey_size1_hashMismatch() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Setting size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setInt(map, 1);

        // Setting key1 to 'key1'
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        // Setting hash1 to hashCode of 'differentKey'
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, "differentKey".hashCode());

        // WHEN
        boolean result = map.containsKey("key1");

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, size > 0, hashCode matches but keys are not equal")
    void TC13_containsKey_returnsFalse_delegateMapNull_hashMatch_butKeysNotEqual() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Setting size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setInt(map, 1);

        // Setting key1 to 'key1'
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        // Setting hash1 to hashCode of 'key'
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, "key".hashCode());

        // WHEN
        boolean result = map.containsKey("key");

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("containsKey returns true when key is null and size steps through to key1 being null")
    void TC14_containsKey_returnsTrue_keyNull_size1_key1Null() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Setting size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setInt(map, 1);

        // Setting key1 to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // WHEN
        boolean result = map.containsKey(null);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("containsKey returns false when key is not null, size > 0, and no keys match")
    void TC15_containsKey_returnsFalse_noMatchingKeys_size3() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Setting size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setInt(map, 3);

        // Setting key1 to 'key1'
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        // Setting hash1 to hashCode of 'key1'
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, "key1".hashCode());

        // Setting key2 to 'key2'
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        // Setting hash2 to hashCode of 'key2'
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, "key2".hashCode());

        // Setting key3 to 'key3'
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // Setting hash3 to hashCode of 'key3'
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, "key3".hashCode());

        // WHEN
        boolean result = map.containsKey("nonMatchingKey");

        // THEN
        assertFalse(result);
    }
}