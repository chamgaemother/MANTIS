package org.apache.commons.compress.archivers.zip;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ZipArchiveEntry_equals_1_1_Test {
    @Test
    @DisplayName("equals() returns false when one entry has unparseableExtra and the other does not")
    public void TC31_equals_with_unparseableExtra_in_one_entry() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.zip");
        byte[] unparseableData = {0x00, 0x01, 0x02};
        entry1.setExtra(unparseableData);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result, "equals() should return false when one entry has unparseableExtra and the other does not");
    }

    @Test
    @DisplayName("equals() returns false when both entries have unparseableExtra with different data")
    public void TC32_equals_with_different_unparseableExtra() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.zip");
        byte[] unparseableData1 = {0x00, 0x01, 0x02};
        byte[] unparseableData2 = {0x03, 0x04, 0x05};
        entry1.setExtra(unparseableData1);
        entry2.setExtra(unparseableData2);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result, "equals() should return false when both entries have unparseableExtra with different data");
    }
}