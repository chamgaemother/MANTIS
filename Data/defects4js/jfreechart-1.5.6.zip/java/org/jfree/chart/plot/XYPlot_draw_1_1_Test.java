package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

public class XYPlot_draw_1_1_Test {

    @Test
    @DisplayName("Draw method propagates RuntimeException when a subplot's draw throws an exception")
    public void testDraw_PropagatesRuntimeExceptionFromSubplot() throws Exception {
        // Arrange
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot();
        XYPlot faultySubplot = mock(XYPlot.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = null;
        PlotState parentState = null;
        PlotRenderingInfo info = null;

        // Configure the faulty subplot to throw RuntimeException when draw is called
        doThrow(new RuntimeException("Drawing failed"))
            .when(faultySubplot)
            .draw(g2, area, anchor, parentState, info);

        // Add the faulty subplot to the combined plot
        combinedPlot.add(faultySubplot);

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            combinedPlot.draw(g2, area, anchor, parentState, info);
        }, "Expected draw() to throw, but it didn't");

        // Verify the exception message
        org.junit.jupiter.api.Assertions.assertEquals("Drawing failed", thrown.getMessage());
    }

    @Test
    @DisplayName("Draw method correctly handles multiple subplots with varying weights")
    public void testDraw_MultipleSubplotsWithVaryingWeights() {
        // Arrange
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot();
        XYPlot subplot1 = mock(XYPlot.class);
        XYPlot subplot2 = mock(XYPlot.class);
        XYPlot subplot3 = mock(XYPlot.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = null;
        PlotState parentState = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // Configure subplot weights
        // Assuming that higher weight means it should be rendered later (on top)
        subplot1.setWeight(1);
        subplot2.setWeight(2);
        subplot3.setWeight(3);

        // Add subplots to the combined plot
        combinedPlot.add(subplot1);
        combinedPlot.add(subplot2);
        combinedPlot.add(subplot3);

        // Act
        combinedPlot.draw(g2, area, anchor, parentState, info);

        // Assert
        // Verify that draw was called on subplots in the order of subplot1, subplot2, subplot3
        InOrder inOrder = org.mockito.Mockito.inOrder(subplot1, subplot2, subplot3);
        inOrder.verify(subplot1, times(1)).draw(g2, area, anchor, parentState, info);
        inOrder.verify(subplot2, times(1)).draw(g2, area, anchor, parentState, info);
        inOrder.verify(subplot3, times(1)).draw(g2, area, anchor, parentState, info);
    }
}