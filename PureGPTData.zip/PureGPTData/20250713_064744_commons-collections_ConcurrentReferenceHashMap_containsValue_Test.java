import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;
import org.apache.commons.collections4.map.ConcurrentReferenceHashMap.ReferenceType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConcurrentReferenceHashMapTest {

    private ConcurrentReferenceHashMap<String, String> map;

    @BeforeEach
    void setUp() {
        map = new ConcurrentReferenceHashMap<>(16, 0.75f, 16, ReferenceType.STRONG, ReferenceType.STRONG, null);
    }

    @Test
    void testContainsValueWithNull() {
        assertThrows(NullPointerException.class, () -> map.containsValue(null));
    }

    @Test
    void testContainsValueWhenEmpty() {
        assertFalse(map.containsValue("value"));
    }

    @Test
    void testContainsValueAfterSinglePut() {
        map.put("key", "value");
        assertTrue(map.containsValue("value"));
        assertFalse(map.containsValue("value2"));
    }

    @Test
    void testContainsValueWithMultipleEntries() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        assertTrue(map.containsValue("value1"));
        assertTrue(map.containsValue("value2"));
        assertFalse(map.containsValue("value3"));
    }

    @Test
    void testContainsValueAfterRemove() {
        map.put("key", "value");
        map.remove("key");
        assertFalse(map.containsValue("value"));
    }

    @Test
    void testConcurrentModification() {
        map.put("key", "value");
        map.remove("key");
        for (int i = 0; i < 10; i++) {
            map.put("key" + i, "value" + i);
        }
        assertTrue(map.containsValue("value5"));
        map.remove("key5");
        assertFalse(map.containsValue("value5"));
    }
}