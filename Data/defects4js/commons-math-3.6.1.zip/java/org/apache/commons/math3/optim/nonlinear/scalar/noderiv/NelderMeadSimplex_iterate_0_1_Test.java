package org.apache.commons.math3.optim.nonlinear.scalar.noderiv;

import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optim.PointValuePair;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;

public class NelderMeadSimplex_iterate_0_1_Test {

    @Test
    @DisplayName("iterate with valid MultivariateFunction and Comparator, reflection accepted between best and second best")
    void TC01_iterate_reflectionAccepted_replacesWorstPoint() throws Exception {
        // Initialize NelderMeadSimplex with valid points
        double[][] initialPoints = {
            {1.0, 2.0},
            {1.5, 2.5},
            {2.0, 3.0}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);

        // Provide valid MultivariateFunction and Comparator
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Invoke the method under test
        simplex.iterate(function, comparator);

        // Use reflection to access the worst point
        java.lang.reflect.Method getPointMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoint", int.class);
        getPointMethod.setAccessible(true);
        PointValuePair worstPoint = (PointValuePair) getPointMethod.invoke(simplex, simplex.getDimension());

        // Assert the worst point has been replaced by the reflected point
        assertNotNull(worstPoint);
        assertEquals(function.value(worstPoint.getPoint()), worstPoint.getValue(), 1e-6);
    }

    @Test
    @DisplayName("iterate with reflection point worse than best, triggers expansion")
    void TC02_iterate_reflectionWorseThanBest_triggersExpansion() throws Exception {
        // Initialize NelderMeadSimplex with points causing reflection to be worse than best
        double[][] initialPoints = {
            {1.0, 2.0},
            {1.5, 2.5},
            {2.0, 3.0}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);

        // Provide MultivariateFunction that makes reflection worse than best
        MultivariateFunction function = point -> 100.0; // High value to ensure reflection is worse
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Invoke the method under test
        simplex.iterate(function, comparator);

        // Use reflection to access the worst point
        java.lang.reflect.Method getPointMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoint", int.class);
        getPointMethod.setAccessible(true);
        PointValuePair worstPoint = (PointValuePair) getPointMethod.invoke(simplex, simplex.getDimension());

        // Assert the worst point has been replaced by the expansion point
        assertNotNull(worstPoint);
        assertEquals(100.0, worstPoint.getValue(), 1e-6);
    }

    @Test
    @DisplayName("iterate with reflection point better than best but not better than second best")
    void TC03_iterate_reflectionBetterThanBest_notBetterThanSecondBest() throws Exception {
        // Initialize NelderMeadSimplex with points causing reflection to be better than best but not better than second best
        double[][] initialPoints = {
            {1.0, 2.0},
            {1.2, 2.4},
            {1.5, 2.5}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);

        // Provide MultivariateFunction and Comparator
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Invoke the method under test
        simplex.iterate(function, comparator);

        // Use reflection to access the worst point
        java.lang.reflect.Method getPointMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoint", int.class);
        getPointMethod.setAccessible(true);
        PointValuePair worstPoint = (PointValuePair) getPointMethod.invoke(simplex, simplex.getDimension());

        // Assert the worst point has been replaced by the reflected point
        assertNotNull(worstPoint);
        assertEquals(function.value(worstPoint.getPoint()), worstPoint.getValue(), 1e-6);
    }

    @Test
    @DisplayName("iterate with reflected point better than best leading to expansion acceptance")
    void TC04_iterate_reflectedBetterThanBest_expansionAccepted() throws Exception {
        // Initialize NelderMeadSimplex with points allowing reflected point to accept expansion
        double[][] initialPoints = {
            {1.0, 2.0},
            {1.1, 2.1},
            {1.2, 2.2}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);

        // Provide MultivariateFunction that allows expansion to be better
        MultivariateFunction function = point -> point[0] + point[1] - 1.0; // Lower values for better points
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Invoke the method under test
        simplex.iterate(function, comparator);

        // Use reflection to access the worst point
        java.lang.reflect.Method getPointMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoint", int.class);
        getPointMethod.setAccessible(true);
        PointValuePair worstPoint = (PointValuePair) getPointMethod.invoke(simplex, simplex.getDimension());

        // Assert the worst point has been replaced by the expansion point
        assertNotNull(worstPoint);
        assertEquals(function.value(worstPoint.getPoint()), worstPoint.getValue(), 1e-6);
    }

    @Test
    @DisplayName("iterate with reflection leading to outside contraction acceptance")
    void TC05_iterate_reflectionLeadsToOutsideContractionAcceptance() throws Exception {
        // Initialize NelderMeadSimplex with points causing reflection to trigger outside contraction
        double[][] initialPoints = {
            {1.0, 2.0},
            {1.5, 2.5},
            {2.0, 3.0}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);

        // Provide MultivariateFunction that forces outside contraction
        MultivariateFunction function = point -> {
            if (point[0] > 2.0) return 100.0;
            return point[0] + point[1];
        };
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Invoke the method under test
        simplex.iterate(function, comparator);

        // Use reflection to access the worst point
        java.lang.reflect.Method getPointMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoint", int.class);
        getPointMethod.setAccessible(true);
        PointValuePair worstPoint = (PointValuePair) getPointMethod.invoke(simplex, simplex.getDimension());

        // Assert the worst point has been replaced by the outside contraction point
        assertNotNull(worstPoint);
        assertEquals(function.value(worstPoint.getPoint()), worstPoint.getValue(), 1e-6);
    }
}