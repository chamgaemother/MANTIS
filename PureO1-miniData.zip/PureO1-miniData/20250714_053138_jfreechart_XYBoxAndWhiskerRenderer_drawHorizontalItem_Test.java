package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.util.Collections;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class XYBoxAndWhiskerRendererTest {

    private XYBoxAndWhiskerRenderer renderer;

    @Mock
    private Graphics2D g2;

    @Mock
    private Rectangle2D dataArea;

    @Mock
    private PlotRenderingInfo info;

    @Mock
    private XYPlot plot;

    @Mock
    private ValueAxis domainAxis;

    @Mock
    private ValueAxis rangeAxis;

    @Mock
    private XYDataset dataset;

    @Mock
    private EntityCollection entities;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        renderer = new XYBoxAndWhiskerRenderer();
    }

    @Test
    public void testDrawHorizontalItem_NullGraphics() {
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(null, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        });
    }

    @Test
    public void testDrawHorizontalItem_NullDataArea() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, null, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        });
    }

    @Test
    public void testDrawHorizontalItem_NullPlot() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, dataArea, info, null, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        });
    }

    @Test
    public void testDrawHorizontalItem_NullDomainAxis() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, dataArea, info, plot, null, rangeAxis, dataset, 0, 0, null, 0);
        });
    }

    @Test
    public void testDrawHorizontalItem_NullRangeAxis() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, null, dataset, 0, 0, null, 0);
        });
    }

    @Test
    public void testDrawHorizontalItem_NullDataset() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, null, 0);
        });
    }

    @Test
    public void testDrawHorizontalItem_InvalidDatasetType() {
        XYDataset invalidDataset = mock(XYDataset.class);
        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, invalidDataset, 0, 0, null, 0);
        });
    }

    @Test
    public void testDrawHorizontalItem_BoxWidthFixed() {
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.setBoxWidth(10.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(domainAxis).valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge());
        verify(rangeAxis).valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge());
        verify(g2, times(1)).setPaint(any(Paint.class));
        verify(g2, times(1)).setStroke(any(Stroke.class));
    }

    @Test
    public void testDrawHorizontalItem_BoxWidthAuto() {
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getItemCount(0)).thenReturn(10);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.setBoxWidth(-1.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(domainAxis).valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge());
    }

    @Test
    public void testDrawHorizontalItem_FillBoxFalse() {
        renderer.setFillBox(false);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(null);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2, never()).fill(any());
    }

    @Test
    public void testDrawHorizontalItem_NoAverage() {
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(null);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2, never()).fill(any());
    }

    @Test
    public void testDrawHorizontalItem_WithAverage() {
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, plot.getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(6.0, dataArea, plot.getRangeAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.5, dataArea, plot.getRangeAxisEdge())).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, plot.getRangeAxisEdge())).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, plot.getRangeAxisEdge())).thenReturn(60.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2, atLeastOnce()).draw(any());
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    public void testDrawHorizontalItem_WithEntity() {
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, plot.getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(6.0, dataArea, plot.getRangeAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.5, dataArea, plot.getRangeAxisEdge())).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, plot.getRangeAxisEdge())).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, plot.getRangeAxisEdge())).thenReturn(60.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        when(dataArea.intersects(any())).thenReturn(true);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(entities).add(any());
    }

    @Test
    public void testDrawHorizontalItem_NoEntity() {
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(null);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(info.getOwner().getEntityCollection(), never()).add(any());
    }

    @Test
    public void testDrawHorizontalItem_FillBoxWithNullBoxPaint() {
        renderer.setBoxPaint(null);
        renderer.setFillBox(true);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(6.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.5, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(60.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    public void testDrawHorizontalItem_OutOfAreaAverage() {
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(1000.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(-1000.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(0.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(10000.0);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1000.0, dataArea, plot.getRangeAxisEdge())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(-1000.0, dataArea, plot.getRangeAxisEdge())).thenReturn(-150.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(10000.0, dataArea, plot.getRangeAxisEdge())).thenReturn(2000.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2, never()).fill(any());
        verify(g2, times(1)).draw(any());
    }

    @Test
    public void testDrawHorizontalItem_FarOutAverageVisible() {
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.5, dataArea, plot.getRangeAxisEdge())).thenReturn(45.0);
        renderer.setBoxWidth(10.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawHorizontalItem_NoFillBoxWithAverage() {
        renderer.setFillBox(false);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, plot.getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(6.0, dataArea, plot.getRangeAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.5, dataArea, plot.getRangeAxisEdge())).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, plot.getRangeAxisEdge())).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, plot.getRangeAxisEdge())).thenReturn(60.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2, never()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawHorizontalItem_EmptyOutliers() {
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
        when(boxDataset.getX(0, 0)).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(boxDataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(boxDataset.getMedianValue(0, 0)).thenReturn(6.0);
        when(boxDataset.getMeanValue(0, 0)).thenReturn(5.5);
        when(boxDataset.getQ1Value(0, 0)).thenReturn(4.0);
        when(boxDataset.getQ3Value(0, 0)).thenReturn(8.0);
        when(dataArea.getHeight()).thenReturn(100.0);
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        verify(g2, never()).draw(any());
    }
}