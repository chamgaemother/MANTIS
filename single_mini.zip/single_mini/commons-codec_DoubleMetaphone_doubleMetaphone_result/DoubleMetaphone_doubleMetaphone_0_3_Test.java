package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.DoubleMetaphone;

public class DoubleMetaphone_doubleMetaphone_0_3_Test {

    @Test
    @DisplayName("doubleMetaphone processes 'GH' when preceded by a vowel in 'ROUGH'")
    public void TC11_doubleMetaphone_GH_rough() {
        // GIVEN
        String value = "ROUGH";

        // WHEN
        String result = new DoubleMetaphone().doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("F"));
    }

    @Test
    @DisplayName("doubleMetaphone handles 'J' at the end of the word in 'BAJ'")
    public void TC12_doubleMetaphone_J_ending_BAJ() {
        // GIVEN
        String value = "BAJ";

        // WHEN
        String result = new DoubleMetaphone().doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("J"));
    }

    @Test
    @DisplayName("doubleMetaphone processes 'L' at the end of the word in 'BAL'")
    public void TC13_doubleMetaphone_L_ending_BAL() {
        // GIVEN
        String value = "BAL";

        // WHEN
        String result = new DoubleMetaphone().doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("L"));
    }

    @Test
    @DisplayName("doubleMetaphone handles 'M' followed by 'M' in 'AMM'")
    public void TC14_doubleMetaphone_MM_AMM() {
        // GIVEN
        String value = "AMM";

        // WHEN
        String result = new DoubleMetaphone().doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("M"));
    }

    @Test
    @DisplayName("doubleMetaphone handles 'N' followed by 'N' in 'ANN'")
    public void TC15_doubleMetaphone_NN_ANN() {
        // GIVEN
        String value = "ANN";

        // WHEN
        String result = new DoubleMetaphone().doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("N"));
    }
}