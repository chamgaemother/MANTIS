package org.apache.commons.jxpath.ri.parser;

import org.apache.commons.jxpath.ri.Compiler;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.io.InputStreamReader;
import java.lang.reflect.Field;

public class XPathParser_CoreFunctionName_0_1_Test {

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_LAST returns Compiler.FUNCTION_LAST")
    void TC01_CoreFunctionName_FUNCTION_LAST() throws Exception {
        // Instantiate XPathParser with a dummy InputStream
        XPathParser xpathParser = new XPathParser(new InputStreamReader(System.in));

        // Access and set jj_nt.kind to FUNCTION_LAST
        setKindField(xpathParser, XPathParserConstants.FUNCTION_LAST);

        // Invoke CoreFunctionName
        int result = xpathParser.CoreFunctionName();

        // Assert the result
        assertEquals(Compiler.FUNCTION_LAST, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_POSITION returns Compiler.FUNCTION_POSITION")
    void TC02_CoreFunctionName_FUNCTION_POSITION() throws Exception {
        // Instantiate XPathParser with a dummy InputStream
        XPathParser xpathParser = new XPathParser(new InputStreamReader(System.in));

        // Access and set jj_nt.kind to FUNCTION_POSITION
        setKindField(xpathParser, XPathParserConstants.FUNCTION_POSITION);

        // Invoke CoreFunctionName
        int result = xpathParser.CoreFunctionName();

        // Assert the result
        assertEquals(Compiler.FUNCTION_POSITION, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_COUNT returns Compiler.FUNCTION_COUNT")
    void TC03_CoreFunctionName_FUNCTION_COUNT() throws Exception {
        // Instantiate XPathParser with a dummy InputStream
        XPathParser xpathParser = new XPathParser(new InputStreamReader(System.in));

        // Access and set jj_nt.kind to FUNCTION_COUNT
        setKindField(xpathParser, XPathParserConstants.FUNCTION_COUNT);

        // Invoke CoreFunctionName
        int result = xpathParser.CoreFunctionName();

        // Assert the result
        assertEquals(Compiler.FUNCTION_COUNT, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_ID returns Compiler.FUNCTION_ID")
    void TC04_CoreFunctionName_FUNCTION_ID() throws Exception {
        // Instantiate XPathParser with a dummy InputStream
        XPathParser xpathParser = new XPathParser(new InputStreamReader(System.in));

        // Access and set jj_nt.kind to FUNCTION_ID
        setKindField(xpathParser, XPathParserConstants.FUNCTION_ID);

        // Invoke CoreFunctionName
        int result = xpathParser.CoreFunctionName();

        // Assert the result
        assertEquals(Compiler.FUNCTION_ID, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_LOCAL_NAME returns Compiler.FUNCTION_LOCAL_NAME")
    void TC05_CoreFunctionName_FUNCTION_LOCAL_NAME() throws Exception {
        // Instantiate XPathParser with a dummy InputStream
        XPathParser xpathParser = new XPathParser(new InputStreamReader(System.in));

        // Access and set jj_nt.kind to FUNCTION_LOCAL_NAME
        setKindField(xpathParser, XPathParserConstants.FUNCTION_LOCAL_NAME);

        // Invoke CoreFunctionName
        int result = xpathParser.CoreFunctionName();

        // Assert the result
        assertEquals(Compiler.FUNCTION_LOCAL_NAME, result);
    }

    // Helper method to set the kind field of jj_nt
    private void setKindField(XPathParser xpathParser, int kind) throws Exception {
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);

        Object jj_nt = jj_ntField.get(xpathParser);

        if (jj_nt == null) {
            // Initialize jj_nt Token if it's null.
            Field tokenField = XPathParser.class.getDeclaredField("token");
            tokenField.setAccessible(true);
            jj_nt = tokenField.get(xpathParser);
            jj_ntField.set(xpathParser, jj_nt);
        }

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, kind);
    }

}
