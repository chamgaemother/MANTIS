package org.jfree.chart.renderer.xy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.entity.EntityCollection;

public class XYBoxAndWhiskerRenderer_drawHorizontalItem_0_2_Test {

    @Test
    @DisplayName("r0 is null, yAverage is present, fillBox is true, box width calculation leads to multiple iterations")
    void TC06_testDrawHorizontalItem_multipleIterations() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = null;

        // Mock dataset methods
        when(dataset.getX(series, item)).thenReturn(10.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(20.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(5.0);
        when(dataset.getMedianValue(series, item)).thenReturn(12.0);
        when(dataset.getMeanValue(series, item)).thenReturn(15.0);
        when(dataset.getQ1Value(series, item)).thenReturn(8.0);
        when(dataset.getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(100.0);
        when(dataArea.getHeight()).thenReturn(200.0);

        // Set fillBox to true
        renderer.setFillBox(true);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);

        // Assert
        verify(g2, times(1)).setPaint(any(Paint.class));
        verify(g2, times(1)).fill(any(Rectangle2D.class));
        verify(g2, times(1)).draw(any(Line2D.class));
    }

//     @Test
//     @DisplayName("r0 is not null, yAverage is present, fillBox is false, box width is set to maximum limit")
//     void TC07_testDrawHorizontalItem_boxWidthMax() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 1;
//         int item = 1;
// 
        // Mock dataset methods
//         when(dataset.getX(series, item)).thenReturn(15.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(25.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(10.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(18.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(20.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(12.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(22.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(60.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(120.0);
//         when(dataArea.getHeight()).thenReturn(200.0);
// 
        // Set fillBox to false
//         renderer.setFillBox(false);
// 
        // Act
//         renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
// 
        // Assert
//         verify(g2, times(1)).setPaint(any(Paint.class));
//         verify(g2, never()).fill(any(Rectangle2D.class));
//         verify(g2, times(1)).draw(any(Line2D.class));
//     }

//     @Test
//     @DisplayName("yAverage is provided and exactly on the minimum dataArea boundary")
//     void TC08_testDrawHorizontalItem_yAverageAtMinBoundary() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 2;
//         int item = 2;
// 
        // Mock dataset methods
//         when(dataset.getX(series, item)).thenReturn(20.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(30.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(15.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(22.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(25.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(18.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(28.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(70.0);
//         when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(140.0);
//         when(dataArea.getMinX()).thenReturn(0.0);
//         when(dataArea.getHeight()).thenReturn(200.0);
//         when(dataArea.getMaxX()).thenReturn(200.0);
//         
// 
        // Enable fillBox
//         renderer.setFillBox(true);
// 
        // Act
//         renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 2);
// 
        // Assert
//         verify(g2, times(1)).fill(any(Rectangle2D.class));
//         verify(g2, times(1)).draw(any(Line2D.class));
//     }

//     @Test
//     @DisplayName("yAverage is provided and exactly on the maximum dataArea boundary")
//     void TC09_testDrawHorizontalItem_yAverageAtMaxBoundary() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 3;
//         int item = 3;
// 
        // Mock dataset methods
//         when(dataset.getX(series, item)).thenReturn(25.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(35.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(27.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(30.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(22.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(32.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(80.0);
//         when(rangeAxis.valueToJava2D(35.0, dataArea, RectangleEdge.RIGHT)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(160.0);
//         when(dataArea.getMaxX()).thenReturn(200.0);
//         when(dataArea.getHeight()).thenReturn(200.0);
//         when(dataArea.getMinX()).thenReturn(0.0);
// 
        // Enable fillBox
//         renderer.setFillBox(true);
// 
        // Act
//         renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 3);
// 
        // Assert
//         verify(g2, times(1)).fill(any(Rectangle2D.class));
//         verify(g2, times(1)).draw(any(Line2D.class));
//     }

//     @Test
//     @DisplayName("fillBox is true and box paint is null, default to item paint")
//     void TC10_testDrawHorizontalItem_fillBoxTrue_boxPaintNull() throws Exception {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 4;
//         int item = 4;
// 
        // Mock dataset methods
//         when(dataset.getX(series, item)).thenReturn(30.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(40.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(25.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(32.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(35.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(28.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(38.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(90.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(180.0);
//         when(dataArea.getHeight()).thenReturn(200.0);
// 
        // Enable fillBox
//         renderer.setFillBox(true);
// 
        // Act
//         renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 4);
// 
        // Assert
//         verify(g2, times(1)).setPaint(any(Paint.class));
//         verify(g2, times(1)).fill(any(Rectangle2D.class));
//         verify(g2, times(1)).draw(any(Line2D.class));
//     }
}