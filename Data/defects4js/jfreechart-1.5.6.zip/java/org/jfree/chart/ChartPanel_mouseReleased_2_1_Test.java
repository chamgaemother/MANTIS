package org.jfree.chart;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;

import javax.swing.JPopupMenu;
import java.awt.Cursor;
import java.awt.event.MouseEvent;

import static org.mockito.Mockito.*;

/**
 * JUnit 5 test class for testing the mouseReleased method of ChartPanel.
 */
public class ChartPanel_mouseReleased_2_1_Test {

    /**
     * Test TC11: mouseReleased with chart null and popup menu present,
     * triggering popup display.
     */
    @Test
    @DisplayName("mouseReleased with chart null and popup menu present, triggering popup display")
    public void TC11_mouseReleased_chartNull_popupPresent() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);
        JPopupMenu mockPopup = Mockito.mock(JPopupMenu.class);
        panel.setPopupMenu(mockPopup);

        MouseEvent mockEvent = Mockito.mock(MouseEvent.class);
        when(mockEvent.isPopupTrigger()).thenReturn(true);
        when(mockEvent.getX()).thenReturn(100);
        when(mockEvent.getY()).thenReturn(100);

        // Act
        panel.mouseReleased(mockEvent);

        // Assert
        verify(mockPopup, times(1)).show(eq(panel), eq(100), eq(100));
    }

    /**
     * Test TC12: mouseReleased with chart null and popup menu absent,
     * triggering no action.
     */
    @Test
    @DisplayName("mouseReleased with chart null and popup menu absent, triggering no action")
    public void TC12_mouseReleased_chartNull_popupAbsent() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);
        panel.setPopupMenu(null); // Ensure no popup menu is set

        MouseEvent mockEvent = Mockito.mock(MouseEvent.class);
        when(mockEvent.isPopupTrigger()).thenReturn(true);
        when(mockEvent.getX()).thenReturn(100);
        when(mockEvent.getY()).thenReturn(100);

        // Act & Assert
        // Expect no exception and no interaction since popup is absent
        panel.mouseReleased(mockEvent);
        // No verification needed as popup is null
    }
}