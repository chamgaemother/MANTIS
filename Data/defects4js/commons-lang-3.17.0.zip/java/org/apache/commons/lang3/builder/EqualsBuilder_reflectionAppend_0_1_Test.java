package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Arrays;

public class EqualsBuilder_reflectionAppend_0_1_Test {

    @Test
    @DisplayName("Returns early when isEquals is false")
    void TC01_ReturnsEarlyWhenIsEqualsIsFalse() throws Exception {
        // Arrange
        EqualsBuilder builder = new EqualsBuilder();
        // Set isEquals to false via reflection
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        isEqualsField.setBoolean(builder, false);
        Object lhs = new Object();
        Object rhs = new Object();

        // Act
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // Assert
        assertSame(builder, result, "Method should return the current EqualsBuilder instance");
    }

    @Test
    @DisplayName("Returns early when lhs and rhs reference the same object")
    void TC02_ReturnsEarlyWhenLhsAndRhsAreSameObject() throws Exception {
        // Arrange
        EqualsBuilder builder = new EqualsBuilder();
        Object obj = new Object();

        // Act
        EqualsBuilder result = builder.reflectionAppend(obj, obj);

        // Assert
        assertSame(builder, result, "Method should return the current EqualsBuilder instance");
    }

    @Test
    @DisplayName("Sets isEquals to false when lhs is null and rhs is not")
    void TC03_SetsIsEqualsToFalseWhenLhsIsNullAndRhsIsNot() throws Exception {
        // Arrange
        EqualsBuilder builder = new EqualsBuilder();
        Object lhs = null;
        Object rhs = new Object();

        // Act
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // Access isEquals via reflection
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);

        // Assert
        assertFalse(isEquals, "isEquals should be set to false");
        assertSame(builder, result, "Method should return the current EqualsBuilder instance");
    }

    @Test
    @DisplayName("Sets isEquals to false when rhs is null and lhs is not")
    void TC04_SetsIsEqualsToFalseWhenRhsIsNullAndLhsIsNot() throws Exception {
        // Arrange
        EqualsBuilder builder = new EqualsBuilder();
        Object lhs = new Object();
        Object rhs = null;

        // Act
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // Access isEquals via reflection
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);

        // Assert
        assertFalse(isEquals, "isEquals should be set to false");
        assertSame(builder, result, "Method should return the current EqualsBuilder instance");
    }

    @Test
    @DisplayName("Appends objects when classes are related and testClass is an array")
    void TC05_AppendsWhenClassesAreRelatedAndTestClassIsArray() throws Exception {
        // Arrange
        EqualsBuilder builder = new EqualsBuilder();
        Object[] lhs = {1, 2, 3};
        Object[] rhs = {1, 2, 3};

        // Act
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // Access isEquals via reflection
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);

        // Assert
        assertTrue(isEquals, "isEquals should remain true after appending arrays");
        assertSame(builder, result, "Method should return the current EqualsBuilder instance");
    }
}