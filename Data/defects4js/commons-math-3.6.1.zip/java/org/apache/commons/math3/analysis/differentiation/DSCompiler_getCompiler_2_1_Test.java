package org.apache.commons.math3.analysis.differentiation;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicReference;

public class DSCompiler_getCompiler_2_1_Test {

    /**
     * Test Case TC16:
     * Description: getCompiler throws IllegalArgumentException when called with negative parameters.
     */
    @Test
    @DisplayName("getCompiler throws IllegalArgumentException when called with negative parameters")
    public void TC16_getCompiler_negativeParameters_throwsException() {
        // GIVEN
        int parameters = -1;
        int order = 2;

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            DSCompiler.getCompiler(parameters, order);
        });
    }

    /**
     * Test Case TC17:
     * Description: getCompiler throws IllegalArgumentException when called with negative order.
     */
    @Test
    @DisplayName("getCompiler throws IllegalArgumentException when called with negative order")
    public void TC17_getCompiler_negativeOrder_throwsException() {
        // GIVEN
        int parameters = 2;
        int order = -1;

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            DSCompiler.getCompiler(parameters, order);
        });
    }

    /**
     * Test Case TC18:
     * Description: getCompiler initializes a new DSCompiler when called with parameters=0 and order=2 and cache is null.
     */
    @Test
    @DisplayName("getCompiler initializes a new DSCompiler when parameters=0 and order=2 and cache is null")
    public void TC18_getCompiler_parameters0_order2_cacheNull_createsCompiler() throws Exception {
        // GIVEN
        int parameters = 0;
        int order = 2;

        // Access the private static 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> compilers =
                (AtomicReference<DSCompiler[][]>) compilersField.get(null);

        // Reset the cache to null
        compilers.set(null);

        // WHEN
        DSCompiler compiler = DSCompiler.getCompiler(parameters, order);

        // THEN
        assertNotNull(compiler, "Compiler should not be null");
        assertEquals(parameters, compiler.getFreeParameters(), "Compiler should have 0 free parameters");
        assertEquals(order, compiler.getOrder(), "Compiler should have order 2");
    }

    /**
     * Test Case TC19:
     * Description: getCompiler creates and caches a new DSCompiler when cache entry for parameters=2 and order=2 is null.
     */
    @Test
    @DisplayName("getCompiler creates and caches a new DSCompiler when cache entry for parameters=2 and order=2 is null")
    public void TC19_getCompiler_parameters2_order2_cacheEntryNull_createsAndCachesCompiler() throws Exception {
        // GIVEN
        int parameters = 2;
        int order = 2;

        // Access the private static 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> compilers =
                (AtomicReference<DSCompiler[][]>) compilersField.get(null);

        DSCompiler[][] currentCache = compilers.get();
        if (currentCache == null) {
            currentCache = new DSCompiler[parameters + 1][order + 1];
            compilers.set(currentCache);
        } else {
            // Ensure the cache is large enough
            if (currentCache.length <= parameters) {
                DSCompiler[][] expandedCache = new DSCompiler[parameters + 1][];
                System.arraycopy(currentCache, 0, expandedCache, 0, currentCache.length);
                for (int i = currentCache.length; i <= parameters; i++) {
                    expandedCache[i] = new DSCompiler[order + 1];
                }
                currentCache = expandedCache;
                compilers.set(currentCache);
            }
            if (currentCache[parameters].length <= order) {
                DSCompiler[] expandedRow = new DSCompiler[order + 1];
                System.arraycopy(currentCache[parameters], 0, expandedRow, 0, currentCache[parameters].length);
                currentCache[parameters] = expandedRow;
            }
        }

        // Ensure cache[2][2] is null
        currentCache[parameters][order] = null;

        // WHEN
        DSCompiler compiler = DSCompiler.getCompiler(parameters, order);

        // THEN
        assertNotNull(compiler, "Compiler should not be null");
        assertEquals(parameters, compiler.getFreeParameters(), "Compiler should have 2 free parameters");
        assertEquals(order, compiler.getOrder(), "Compiler should have order 2");
        assertSame(compiler, currentCache[parameters][order], "Compiler should be cached in compilers[2][2]");
    }

    /**
     * Test Case TC20:
     * Description: getCompiler expands cache and creates a new DSCompiler when called with parameters=4 and order=4 exceeding existing cache sizes.
     */
    @Test
    @DisplayName("getCompiler expands cache and creates a new DSCompiler when parameters=4 and order=4 exceed cache sizes")
    public void TC20_getCompiler_parameters4_order4_exceedsCache_createsAndCachesCompiler() throws Exception {
        // GIVEN
        int parameters = 4;
        int order = 4;

        // Access the private static 'compilers' field via reflection
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> compilers =
                (AtomicReference<DSCompiler[][]>) compilersField.get(null);

        DSCompiler[][] currentCache = compilers.get();
        if (currentCache == null) {
            currentCache = new DSCompiler[parameters + 1][order + 1];
            compilers.set(currentCache);
        } else {
            // Expand the cache if necessary
            int currentParameters = currentCache.length;
            if (currentParameters <= parameters) {
                DSCompiler[][] expandedCache = new DSCompiler[parameters + 1][];
                System.arraycopy(currentCache, 0, expandedCache, 0, currentCache.length);
                for (int i = currentParameters; i <= parameters; i++) {
                    expandedCache[i] = new DSCompiler[order + 1];
                }
                currentCache = expandedCache;
                compilers.set(currentCache);
            }
            for (int i = 0; i <= parameters; i++) {
                if (currentCache[i] == null || currentCache[i].length <= order) {
                    DSCompiler[] expandedRow = new DSCompiler[order + 1];
                    if (currentCache[i] != null) {
                        System.arraycopy(currentCache[i], 0, expandedRow, 0, currentCache[i].length);
                    }
                    currentCache[i] = expandedRow;
                }
            }
        }

        // Ensure cache[4][4] is null
        currentCache[parameters][order] = null;

        // WHEN
        DSCompiler compiler = DSCompiler.getCompiler(parameters, order);

        // THEN
        assertNotNull(compiler, "Compiler should not be null");
        assertEquals(parameters, compiler.getFreeParameters(), "Compiler should have 4 free parameters");
        assertEquals(order, compiler.getOrder(), "Compiler should have order 4");
        assertSame(compiler, currentCache[parameters][order], "Compiler should be cached in compilers[4][4]");
    }
}