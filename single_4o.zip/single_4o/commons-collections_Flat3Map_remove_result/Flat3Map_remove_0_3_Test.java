package org.apache.commons.collections4.map;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Flat3Map_remove_0_3_Test {

    @Test
    @DisplayName("Remove with non-null key when match is neither at end nor start")
    void testRemoveMiddleKey() {
        // Setup the Flat3Map instance with 2 elements
        Flat3Map<String, String> flat3Map = new Flat3Map<>();
        flat3Map.put("key1", "value1"); // Start position
        flat3Map.put("key2", "value2"); // Middle position

        // Attempt to remove the middle key
        Object result = flat3Map.remove("key2");

        // Verify that the returned value is the object at the middle
        assertEquals("value2", result);
    }
}