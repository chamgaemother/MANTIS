package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TokenMgrError_addEscapes_0_5_Test {

    @Test
    @DisplayName("addEscapes with string containing multiple null characters")
    public void TC21() {
        // Arrange
        String input = "\0\0\0";
        TokenMgrError tokenMgrError = new TokenMgrError();

        // Act
        String result = tokenMgrError.addEscapes(input);

        // Assert
        assertEquals("", result);
    }
}