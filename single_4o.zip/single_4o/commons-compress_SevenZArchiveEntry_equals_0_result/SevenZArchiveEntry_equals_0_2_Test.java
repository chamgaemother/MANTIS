package org.apache.commons.compress.archivers.sevenz;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class SevenZArchiveEntry_equals_0_2_Test {
    
    @Test
    @DisplayName("Comparison with different hasStream returns false")
    void testDifferentHasStreamReturnsFalse() throws NoSuchFieldException, IllegalAccessException {
        SevenZArchiveEntry a = new SevenZArchiveEntry();
        SevenZArchiveEntry b = new SevenZArchiveEntry();

        Field hasStreamField = SevenZArchiveEntry.class.getDeclaredField("hasStream");
        hasStreamField.setAccessible(true);

        hasStreamField.set(a, true);
        hasStreamField.set(b, false);

        assertFalse(a.equals(b));
    }

    @Test
    @DisplayName("Comparison with different isDirectory returns false")
    void testDifferentIsDirectoryReturnsFalse() throws NoSuchFieldException, IllegalAccessException {
        SevenZArchiveEntry a = new SevenZArchiveEntry();
        SevenZArchiveEntry b = new SevenZArchiveEntry();

        Field isDirectoryField = SevenZArchiveEntry.class.getDeclaredField("isDirectory");
        isDirectoryField.setAccessible(true);

        isDirectoryField.set(a, true);
        isDirectoryField.set(b, false);

        assertFalse(a.equals(b));
    }

    @Test
    @DisplayName("Comparison with all boolean fields differing returns false")
    void testAllBooleanFieldsDifferingReturnsFalse() throws NoSuchFieldException, IllegalAccessException {
        SevenZArchiveEntry a = new SevenZArchiveEntry();
        SevenZArchiveEntry b = new SevenZArchiveEntry();

        Field[] booleanFields = {
            SevenZArchiveEntry.class.getDeclaredField("hasStream"),
            SevenZArchiveEntry.class.getDeclaredField("isDirectory"),
            SevenZArchiveEntry.class.getDeclaredField("isAntiItem"),
            SevenZArchiveEntry.class.getDeclaredField("hasCreationDate"),
            SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate"),
            SevenZArchiveEntry.class.getDeclaredField("hasAccessDate"),
            SevenZArchiveEntry.class.getDeclaredField("hasWindowsAttributes"),
            SevenZArchiveEntry.class.getDeclaredField("hasCrc")
        };

        for (Field field : booleanFields) {
            field.setAccessible(true);
            field.set(a, true);
            field.set(b, false);
        }

        assertFalse(a.equals(b));
    }

    @Test
    @DisplayName("Comparison with equalSevenZMethods returning false with multiple iterations")
    void testEqualSevenZMethodsReturningFalseWithMultipleIterations() throws NoSuchFieldException, IllegalAccessException {
        SevenZArchiveEntry a = new SevenZArchiveEntry();
        SevenZArchiveEntry b = new SevenZArchiveEntry();

        Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
        contentMethodsField.setAccessible(true);

        SevenZMethodConfiguration m1 = new SevenZMethodConfiguration();
        SevenZMethodConfiguration m2 = new SevenZMethodConfiguration();

        // To differentiate, tweak equals method or values in SevenZMethodConfiguration if needed
        contentMethodsField.set(a, Arrays.asList(m1));
        contentMethodsField.set(b, Collections.emptyList());

        assertFalse(a.equals(b));
    }

    @Test
    @DisplayName("Comparison with equalSevenZMethods matching on multiple but not all counts returns false")
    void testEqualSevenZMethodsMatchingOnMultipleButNotAllCountsReturnsFalse() throws NoSuchFieldException, IllegalAccessException {
        SevenZArchiveEntry a = new SevenZArchiveEntry();
        SevenZArchiveEntry b = new SevenZArchiveEntry();

        Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
        contentMethodsField.setAccessible(true);

        SevenZMethodConfiguration m1 = new SevenZMethodConfiguration();
        SevenZMethodConfiguration m2 = new SevenZMethodConfiguration();

        // To differentiate, tweak equals method or values in SevenZMethodConfiguration if needed
        contentMethodsField.set(a, Arrays.asList(m1, m2));
        contentMethodsField.set(b, Arrays.asList(m1));

        assertFalse(a.equals(b));
    }

}