package org.jfree.chart.util;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.awt.Shape;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.io.ObjectInputStream;
import org.jfree.chart.util.SerialUtils;

public class SerialUtils_readShape_0_4_Test {

    @Test
    @DisplayName("readShape returns null when isNull is true after multiple iterations")
    void TC16_readShape_returns_null_when_isNull_is_true_after_multiple_iterations() throws Exception {
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(true);

        Shape result = SerialUtils.readShape(stream);

        assertNull(result);
    }

    @Test
    @DisplayName("readShape handles GeneralPath with winding rule set to WIND_EVEN_ODD")
    void TC17_readShape_handles_GeneralPath_with_winding_rule_set_to_WIND_EVEN_ODD() throws Exception {
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(false);
        when(stream.readObject()).thenReturn(GeneralPath.class);
        when(stream.readBoolean()).thenReturn(false, true);
        when(stream.readInt()).thenReturn(PathIterator.SEG_MOVETO, GeneralPath.WIND_EVEN_ODD);
        when(stream.readFloat()).thenReturn(50.0f, 60.0f);

        Shape result = SerialUtils.readShape(stream);

        assertInstanceOf(GeneralPath.class, result);
        GeneralPath gp = (GeneralPath) result;
        assertEquals(GeneralPath.WIND_EVEN_ODD, gp.getWindingRule());
    }

    @Test
    @DisplayName("readShape handles GeneralPath with winding rule set to WIND_NON_ZERO")
    void TC18_readShape_handles_GeneralPath_with_winding_rule_set_to_WIND_NON_ZERO() throws Exception {
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(false);
        when(stream.readObject()).thenReturn(GeneralPath.class);
        when(stream.readBoolean()).thenReturn(false, true);
        when(stream.readInt()).thenReturn(PathIterator.SEG_LINETO, GeneralPath.WIND_NON_ZERO);
        when(stream.readFloat()).thenReturn(70.0f, 80.0f);

        Shape result = SerialUtils.readShape(stream);

        assertInstanceOf(GeneralPath.class, result);
        GeneralPath gp = (GeneralPath) result;
        assertEquals(GeneralPath.WIND_NON_ZERO, gp.getWindingRule());
    }

    @Test
    @DisplayName("readShape handles GeneralPath with multiple iterations and mixed commands")
    void TC19_readShape_handles_GeneralPath_with_multiple_iterations_and_mixed_commands() throws Exception {
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(false);
        when(stream.readObject()).thenReturn(GeneralPath.class);
        when(stream.readBoolean()).thenReturn(false, false, true);
        when(stream.readInt()).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO, GeneralPath.WIND_NON_ZERO);
        when(stream.readFloat()).thenReturn(10.0f, 20.0f, 30.0f, 40.0f);

        Shape result = SerialUtils.readShape(stream);

        assertInstanceOf(GeneralPath.class, result);
        GeneralPath gp = (GeneralPath) result;
        PathIterator pi = gp.getPathIterator(null);
        float[] coords = new float[6];

        // First element
        int type1 = pi.currentSegment(coords);
        assertEquals(PathIterator.SEG_MOVETO, type1);
        pi.next();

        // Second element
        int type2 = pi.currentSegment(coords);
        assertEquals(PathIterator.SEG_LINETO, type2);
        pi.next();

        assertTrue(pi.isDone());
        assertEquals(GeneralPath.WIND_NON_ZERO, gp.getWindingRule());
    }

    @Test
    @DisplayName("readShape handles stream readObject returning null when isNull is false")
    void TC20_readShape_handles_stream_readObject_returning_null_when_isNull_is_false() throws Exception {
        ObjectInputStream stream = mock(ObjectInputStream.class);
        when(stream.readBoolean()).thenReturn(false);
        when(stream.readObject()).thenReturn(null);

        Shape result = SerialUtils.readShape(stream);

        assertNull(result);
    }
}