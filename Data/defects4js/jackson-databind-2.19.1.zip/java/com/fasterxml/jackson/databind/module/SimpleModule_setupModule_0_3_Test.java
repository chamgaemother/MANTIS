package com.fasterxml.jackson.databind.module;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.LinkedHashSet;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.Module.SetupContext;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;

import static org.mockito.Mockito.*;

public class SimpleModule_setupModule_0_3_Test {

    @Test
    @DisplayName("Only _namingStrategy is not null; naming strategy is set in SetupContext")
    public void TC11() throws Exception {
        // GIVEN
        PropertyNamingStrategy namingStrategy = mock(PropertyNamingStrategy.class);
        SimpleModule module = new SimpleModule();
        
        // Use reflection to set _namingStrategy
        Field namingStrategyField = SimpleModule.class.getDeclaredField("_namingStrategy");
        namingStrategyField.setAccessible(true);
        namingStrategyField.set(module, namingStrategy);
        
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).setNamingStrategy(namingStrategy);
    }

    @Test
    @DisplayName("Only _mixins is not null with no entries; no mix-in annotations are set")
    public void TC12() throws Exception {
        // GIVEN
        SimpleModule module = new SimpleModule();

        // Use reflection to set _mixins to an empty HashMap
        Field mixinsField = SimpleModule.class.getDeclaredField("_mixins");
        mixinsField.setAccessible(true);
        mixinsField.set(module, new HashMap<Class<?>, Class<?>>() );

        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context, never()).setMixInAnnotations(any(), any());
    }

    @Test
    @DisplayName("Only _mixins is not null with one entry; one mix-in annotation is set")
    public void TC13() throws Exception {
        // GIVEN
        SimpleModule module = new SimpleModule();

        // Create dummy classes to avoid compilation issues
        class TargetClass {}
        class MixinClass {}

        // Use reflection to set _mixins with one entry
        HashMap<Class<?>, Class<?>> mixins = new HashMap<>();
        mixins.put(TargetClass.class, MixinClass.class);
        Field mixinsField = SimpleModule.class.getDeclaredField("_mixins");
        mixinsField.setAccessible(true);
        mixinsField.set(module, mixins);

        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).setMixInAnnotations(TargetClass.class, MixinClass.class);
    }

    @Test
    @DisplayName("Only _mixins is not null with multiple entries; multiple mix-in annotations are set")
    public void TC14() throws Exception {
        // GIVEN
        SimpleModule module = new SimpleModule();

        // Create dummy classes to avoid compilation issues
        class TargetClass1 {}
        class MixinClass1 {}
        class TargetClass2 {}
        class MixinClass2 {}

        // Use reflection to set _mixins with multiple entries
        HashMap<Class<?>, Class<?>> mixins = new HashMap<>();
        mixins.put(TargetClass1.class, MixinClass1.class);
        mixins.put(TargetClass2.class, MixinClass2.class);
        Field mixinsField = SimpleModule.class.getDeclaredField("_mixins");
        mixinsField.setAccessible(true);
        mixinsField.set(module, mixins);

        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).setMixInAnnotations(TargetClass1.class, MixinClass1.class);
        verify(context).setMixInAnnotations(TargetClass2.class, MixinClass2.class);
    }

    @Test
    @DisplayName("All configurational fields are populated; serializers, deserializers, key serializers/deserializers, resolvers, modifiers, subtypes, naming strategy, and mix-ins are added")
    public void TC15() throws Exception {
        // GIVEN
        SimpleSerializers serializers = mock(SimpleSerializers.class);
        SimpleDeserializers deserializers = mock(SimpleDeserializers.class);
        SimpleSerializers keySerializers = mock(SimpleSerializers.class);
        SimpleKeyDeserializers keyDeserializers = mock(SimpleKeyDeserializers.class);
        SimpleAbstractTypeResolver abstractTypeResolver = mock(SimpleAbstractTypeResolver.class);
        SimpleValueInstantiators valueInstantiators = mock(SimpleValueInstantiators.class);
        BeanDeserializerModifier deserializerModifier = mock(BeanDeserializerModifier.class);
        BeanSerializerModifier serializerModifier = mock(BeanSerializerModifier.class);
        LinkedHashSet<NamedType> subtypes = new LinkedHashSet<>();
        subtypes.add(new NamedType(Object.class));
        PropertyNamingStrategy namingStrategy = mock(PropertyNamingStrategy.class);

        // Create dummy classes to avoid compilation issues
        class TargetClass1 {}
        class MixinClass1 {}
        class TargetClass2 {}
        class MixinClass2 {}

        HashMap<Class<?>, Class<?>> mixins = new HashMap<>();
        mixins.put(TargetClass1.class, MixinClass1.class);
        mixins.put(TargetClass2.class, MixinClass2.class);

        SimpleModule module = new SimpleModule();

        // Use reflection to set all configurational fields
        Field serializersField = SimpleModule.class.getDeclaredField("_serializers");
        serializersField.setAccessible(true);
        serializersField.set(module, serializers);

        Field deserializersField = SimpleModule.class.getDeclaredField("_deserializers");
        deserializersField.setAccessible(true);
        deserializersField.set(module, deserializers);

        Field keySerializersField = SimpleModule.class.getDeclaredField("_keySerializers");
        keySerializersField.setAccessible(true);
        keySerializersField.set(module, keySerializers);

        Field keyDeserializersField = SimpleModule.class.getDeclaredField("_keyDeserializers");
        keyDeserializersField.setAccessible(true);
        keyDeserializersField.set(module, keyDeserializers);

        Field abstractTypesField = SimpleModule.class.getDeclaredField("_abstractTypes");
        abstractTypesField.setAccessible(true);
        abstractTypesField.set(module, abstractTypeResolver);

        Field valueInstantiatorsField = SimpleModule.class.getDeclaredField("_valueInstantiators");
        valueInstantiatorsField.setAccessible(true);
        valueInstantiatorsField.set(module, valueInstantiators);

        Field deserializerModifierField = SimpleModule.class.getDeclaredField("_deserializerModifier");
        deserializerModifierField.setAccessible(true);
        deserializerModifierField.set(module, deserializerModifier);

        Field serializerModifierField = SimpleModule.class.getDeclaredField("_serializerModifier");
        serializerModifierField.setAccessible(true);
        serializerModifierField.set(module, serializerModifier);

        Field subtypesField = SimpleModule.class.getDeclaredField("_subtypes");
        subtypesField.setAccessible(true);
        subtypesField.set(module, subtypes);

        Field namingStrategyField = SimpleModule.class.getDeclaredField("_namingStrategy");
        namingStrategyField.setAccessible(true);
        namingStrategyField.set(module, namingStrategy);

        Field mixinsField = SimpleModule.class.getDeclaredField("_mixins");
        mixinsField.setAccessible(true);
        mixinsField.set(module, mixins);

        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addSerializers(serializers);
        verify(context).addDeserializers(deserializers);
        verify(context).addKeySerializers(keySerializers);
        verify(context).addKeyDeserializers(keyDeserializers);
        verify(context).addAbstractTypeResolver(abstractTypeResolver);
        verify(context).addValueInstantiators(valueInstantiators);
        verify(context).addBeanDeserializerModifier(deserializerModifier);
        verify(context).addBeanSerializerModifier(serializerModifier);
        verify(context).registerSubtypes(new NamedType(Object.class));
        verify(context).setNamingStrategy(namingStrategy);
        verify(context).setMixInAnnotations(TargetClass1.class, MixinClass1.class);
        verify(context).setMixInAnnotations(TargetClass2.class, MixinClass2.class);
    }
}