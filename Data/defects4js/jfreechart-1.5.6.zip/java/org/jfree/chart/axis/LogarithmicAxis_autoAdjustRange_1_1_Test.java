package org.jfree.chart.axis;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.data.Range;

import java.lang.reflect.Field;

public class LogarithmicAxis_autoAdjustRange_1_1_Test {

    @Test
    @DisplayName("autoAdjustRange adjusts range correctly when allowNegativesFlag is true and upper bound is negative")
    public void TC21_autoAdjustRange_withAllowNegativesAndNegativeUpperBound() {
        // Arrange
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(true);
        ValueAxisPlot mockPlot = Mockito.mock(ValueAxisPlot.class);
        Range mockRange = new Range(5.0, -15.0);
        Mockito.when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // Set the plot using reflection
        try {
            Field plotField = LogarithmicAxis.class.getDeclaredField("plot");
            plotField.setAccessible(true);
            plotField.set(axis, mockPlot);
        } catch (Exception e) {
            Assertions.fail("Failed to set plot via reflection: " + e.getMessage());
        }

        // Act
        axis.autoAdjustRange();

        // Assert
        Range adjustedRange = axis.getRange();
        Assertions.assertEquals(5.0, adjustedRange.getLowerBound(), 0.0001);
        Assertions.assertEquals(-10.0, adjustedRange.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("autoAdjustRange throws RuntimeException when allowNegativesFlag is false and lower bound is exactly zero")
    public void TC22_autoAdjustRange_withAllowNegativesFalseAndLowerBoundZero() {
        // Arrange
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(false);
        axis.setStrictValuesFlag(true);
        ValueAxisPlot mockPlot = Mockito.mock(ValueAxisPlot.class);
        Range mockRange = new Range(0.0, 10.0);
        Mockito.when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // Set the plot using reflection
        try {
            Field plotField = LogarithmicAxis.class.getDeclaredField("plot");
            plotField.setAccessible(true);
            plotField.set(axis, mockPlot);
        } catch (Exception e) {
            Assertions.fail("Failed to set plot via reflection: " + e.getMessage());
        }

        // Act & Assert
        RuntimeException exception = Assertions.assertThrows(RuntimeException.class, () -> {
            axis.autoAdjustRange();
        });
        Assertions.assertEquals("Values less than or equal to zero not allowed with logarithmic axis", exception.getMessage());
    }

    @Test
    @DisplayName("autoAdjustRange correctly adjusts both lower and upper bounds when autoRangeNextLogFlag is true")
    public void TC23_autoAdjustRange_withAutoRangeNextLogFlagTrue() {
        // Arrange
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAutoRangeNextLogFlag(true);
        ValueAxisPlot mockPlot = Mockito.mock(ValueAxisPlot.class);
        Range mockRange = new Range(3.0, 30.0);
        Mockito.when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // Set the plot using reflection
        try {
            Field plotField = LogarithmicAxis.class.getDeclaredField("plot");
            plotField.setAccessible(true);
            plotField.set(axis, mockPlot);
        } catch (Exception e) {
            Assertions.fail("Failed to set plot via reflection: " + e.getMessage());
        }

        // Act
        axis.autoAdjustRange();

        // Assert
        Range adjustedRange = axis.getRange();
        Assertions.assertEquals(1.0, adjustedRange.getLowerBound(), 0.0001);
        Assertions.assertEquals(100.0, adjustedRange.getUpperBound(), 0.0001);
    }

    @Test
    @DisplayName("autoAdjustRange processes multiple adjustments when minimum range size is not met after initial adjustments")
    public void TC24_autoAdjustRange_withMinimumRangeSizeNotMet() {
        // Arrange
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAutoRangeMinimumSize(10.0);
        ValueAxisPlot mockPlot = Mockito.mock(ValueAxisPlot.class);
        Range mockRange = new Range(20.0, 25.0);
        Mockito.when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // Set the plot using reflection
        try {
            Field plotField = LogarithmicAxis.class.getDeclaredField("plot");
            plotField.setAccessible(true);
            plotField.set(axis, mockPlot);
        } catch (Exception e) {
            Assertions.fail("Failed to set plot via reflection: " + e.getMessage());
        }

        // Act
        axis.autoAdjustRange();

        // Assert
        Range adjustedRange = axis.getRange();
        Assertions.assertTrue(adjustedRange.getLength() >= 10.0, "Range should meet the minimum size after adjustments");
    }

}