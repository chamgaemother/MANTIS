import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.util.TypeUtils;
import org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer;
import org.jdom.CDATA;
import org.jdom.Comment;
import org.jdom.Element;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.jdom.input.SAXBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class JDOMNodePointerTest {

    private Element testElement;
    private Text testText;
    private JDOMNodePointer elementPointer;
    private JDOMNodePointer textPointer;

    @BeforeEach
    void setUp() {
        testElement = new Element("testElement");
        testText = new Text("initial");
        testElement.addContent(testText);
        elementPointer = new JDOMNodePointer(null, testElement);
        textPointer = new JDOMNodePointer(null, testText);
    }

    @Test
    void testSetValueOnTextWithStringValue() {
        textPointer.setValue("new value");
        assertEquals("new value", testText.getText());
    }

    @Test
    void testSetValueOnTextWithNull() {
        textPointer.setValue(null);
        assertTrue(((Element) textPointer.getImmediateNode()).getText().isEmpty());
    }

    @Test
    void testSetValueOnTextWithEmptyString() {
        textPointer.setValue("");
        assertTrue(((Element) textPointer.getImmediateNode()).getText().isEmpty());
    }

    @Test
    void testSetValueOnElementWithElement() {
        Element newElement = new Element("newElement");
        newElement.addContent(new Text("content"));
        elementPointer.setValue(newElement);
        assertEquals("content", testElement.getText());
    }

    @Test
    void testSetValueOnElementWithText() {
        Text newText = new Text("new content");
        elementPointer.setValue(newText);
        assertEquals("new content", testElement.getText());
    }

    @Test
    void testSetValueOnElementWithCDATA() {
        CDATA cdata = new CDATA("cdata content");
        elementPointer.setValue(cdata);
        assertEquals("cdata content", testElement.getText());
    }

    @Test
    void testSetValueOnElementWithPI() {
        ProcessingInstruction pi = new ProcessingInstruction("target", "data");
        elementPointer.setValue(pi);
        assertEquals(pi, testElement.getContent(0));
    }

    @Test
    void testSetValueOnElementWithComment() {
        Comment comment = new Comment("comment content");
        elementPointer.setValue(comment);
        assertEquals(comment, testElement.getContent(0));
    }

    @Test
    void testSetValueOnElementWithString() {
        elementPointer.setValue("string content");
        assertEquals("string content", testElement.getText());
    }

    @Test
    void testSetValueOnElementWithNull() {
        elementPointer.setValue(null);
        assertTrue(testElement.getContent().isEmpty());
    }

    @Test
    void testSetValueOnElementWithEmptyString() {
        elementPointer.setValue("");
        assertTrue(testElement.getContent().isEmpty());
    }
}