package org.jfree.chart.plot;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Polygon;
import java.awt.geom.Arc2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MeterPlot_draw_2_1_Test {

    @Test
    @DisplayName("Draw method with dataset value below the lower bound of the range")
    void TC21_draw_value_below_range() {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        ValueDataset dataset = new DefaultValueDataset(-10);
        plot.setDataset(dataset);
        plot.setRange(new Range(0, 100));
        plot.setValueVisible(true);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = null;
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that needle is not drawn by checking that setPaint for needlePaint is never called
        verify(g2, never()).setPaint(plot.getNeedlePaint());

        // Capture the string drawn for the value label
        ArgumentCaptor<String> stringCaptor = ArgumentCaptor.forClass(String.class);
        verify(g2).drawString(stringCaptor.capture(), anyFloat(), anyFloat());
        String drawnString = stringCaptor.getValue();
        assertEquals("-10 Units", drawnString, "Value label should indicate a value below range");
    }

    @Test
    @DisplayName("Draw method with dataset value above the upper bound of the range")
    void TC22_draw_value_above_range() {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        ValueDataset dataset = new DefaultValueDataset(150);
        plot.setDataset(dataset);
        plot.setRange(new Range(0, 100));
        plot.setValueVisible(true);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = null;
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that needle is not drawn by checking that setPaint for needlePaint is never called
        verify(g2, never()).setPaint(plot.getNeedlePaint());

        // Capture the string drawn for the value label
        ArgumentCaptor<String> stringCaptor = ArgumentCaptor.forClass(String.class);
        verify(g2).drawString(stringCaptor.capture(), anyFloat(), anyFloat());
        String drawnString = stringCaptor.getValue();
        assertEquals("150 Units", drawnString, "Value label should indicate a value above range");
    }

    @Test
    @DisplayName("Draw method when MeterInterval's outlinePaint is null")
    void TC23_draw_MeterInterval_with_null_outlinePaint() {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        MeterInterval interval = new MeterInterval("Low", new Range(0, 50), Color.GREEN, new BasicStroke(1.0f), null);
        plot.addInterval(interval);
        plot.setDataset(new DefaultValueDataset(25));
        plot.setRange(new Range(0, 100));

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = null;
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that fillArc is called with the backgroundPaint
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2, atLeastOnce()).setPaint(paintCaptor.capture());
        List<Paint> paints = paintCaptor.getAllValues();
        assertTrue(paints.contains(Color.GREEN), "Background paint should be set for interval");

        // Verify that drawArc is never called since outlinePaint is null
        verify(g2, never()).draw(any(Arc2D.class));
    }

    @Test
    @DisplayName("Draw method with multiple MeterIntervals covering the entire range")
    void TC24_draw_multiple_MeterIntervals_full_range() {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        MeterInterval interval1 = new MeterInterval("Low", new Range(0, 50), Color.GREEN, new BasicStroke(1.0f), Color.BLACK);
        MeterInterval interval2 = new MeterInterval("Medium", new Range(50, 80), Color.YELLOW, new BasicStroke(1.0f), Color.BLACK);
        MeterInterval interval3 = new MeterInterval("High", new Range(80, 100), Color.RED, new BasicStroke(1.0f), Color.BLACK);
        plot.addInterval(interval1);
        plot.addInterval(interval2);
        plot.addInterval(interval3);
        plot.setDataset(new DefaultValueDataset(75));
        plot.setRange(new Range(0, 100));

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 300, 300);
        Point2D anchor = null;
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that setPaint is called for each interval's backgroundPaint
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2, atLeast(3)).setPaint(any(Paint.class));

        // Verify that draw is called for each interval's outline
        ArgumentCaptor<Arc2D> arcCaptor = ArgumentCaptor.forClass(Arc2D.class);
        verify(g2, atLeast(3)).draw(arcCaptor.capture());
    }

    @Test
    @DisplayName("Draw method when meterAngle is exactly 180 degrees and shape is CHORD")
    void TC25_draw_meterAngle_180_CHORD_shape() {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        plot.setMeterAngle(180);
        plot.setDialShape(DialShape.CHORD);
        plot.setDataset(new DefaultValueDataset(90));
        plot.setRange(new Range(0, 100));

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 250, 250);
        Point2D anchor = null;
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that fill is called with Arc2D for CHORD shape
        ArgumentCaptor<Arc2D> arcCaptor = ArgumentCaptor.forClass(Arc2D.class);
        verify(g2, atLeastOnce()).fill(arcCaptor.capture());

        // Verify that draw is called with Arc2D for outline
        verify(g2, atLeastOnce()).draw(arcCaptor.capture());

        // Verify that needle is drawn
        verify(g2, atLeastOnce()).fill(any(Polygon.class));

        // Verify that the needle's paint is set
        verify(g2, atLeastOnce()).setPaint(plot.getNeedlePaint());
    }

}
