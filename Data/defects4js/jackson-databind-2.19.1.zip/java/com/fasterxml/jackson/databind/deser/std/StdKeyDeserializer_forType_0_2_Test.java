package com.fasterxml.jackson.databind.deser.std;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer;
import java.lang.reflect.Field;

public class StdKeyDeserializer_forType_0_2_Test {

    @Test
    @DisplayName("forType(Integer.class) returns StdKeyDeserializer with TYPE_INT")
    public void TC06() throws Exception {
        // GIVEN
        Class<?> raw = Integer.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access 'kind' field
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        // Access 'raw' field
        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        // Expected kind
        Field typeIntField = StdKeyDeserializer.class.getDeclaredField("TYPE_INT");
        typeIntField.setAccessible(true);
        int expectedKind = typeIntField.getInt(null);

        // Assertions
        assertEquals(expectedKind, kind);
        assertEquals(Integer.class, rawValue);
    }

    @Test
    @DisplayName("forType(Long.class) returns StdKeyDeserializer with TYPE_LONG")
    public void TC07() throws Exception {
        // GIVEN
        Class<?> raw = Long.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access 'kind' field
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        // Access 'raw' field
        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        // Expected kind
        Field typeLongField = StdKeyDeserializer.class.getDeclaredField("TYPE_LONG");
        typeLongField.setAccessible(true);
        int expectedKind = typeLongField.getInt(null);

        // Assertions
        assertEquals(expectedKind, kind);
        assertEquals(Long.class, rawValue);
    }

    @Test
    @DisplayName("forType(Date.class) returns StdKeyDeserializer with TYPE_DATE")
    public void TC08() throws Exception {
        // GIVEN
        Class<?> raw = java.util.Date.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access 'kind' field
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        // Access 'raw' field
        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        // Expected kind
        Field typeDateField = StdKeyDeserializer.class.getDeclaredField("TYPE_DATE");
        typeDateField.setAccessible(true);
        int expectedKind = typeDateField.getInt(null);

        // Assertions
        assertEquals(expectedKind, kind);
        assertEquals(java.util.Date.class, rawValue);
    }

    @Test
    @DisplayName("forType(Calendar.class) returns StdKeyDeserializer with TYPE_CALENDAR")
    public void TC09() throws Exception {
        // GIVEN
        Class<?> raw = java.util.Calendar.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access 'kind' field
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        // Access 'raw' field
        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        // Expected kind
        Field typeCalendarField = StdKeyDeserializer.class.getDeclaredField("TYPE_CALENDAR");
        typeCalendarField.setAccessible(true);
        int expectedKind = typeCalendarField.getInt(null);

        // Assertions
        assertEquals(expectedKind, kind);
        assertEquals(java.util.Calendar.class, rawValue);
    }

    @Test
    @DisplayName("forType(Boolean.class) returns StdKeyDeserializer with TYPE_BOOLEAN")
    public void TC10() throws Exception {
        // GIVEN
        Class<?> raw = Boolean.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access 'kind' field
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        // Access 'raw' field
        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        // Expected kind
        Field typeBooleanField = StdKeyDeserializer.class.getDeclaredField("TYPE_BOOLEAN");
        typeBooleanField.setAccessible(true);
        int expectedKind = typeBooleanField.getInt(null);

        // Assertions
        assertEquals(expectedKind, kind);
        assertEquals(Boolean.class, rawValue);
    }
}