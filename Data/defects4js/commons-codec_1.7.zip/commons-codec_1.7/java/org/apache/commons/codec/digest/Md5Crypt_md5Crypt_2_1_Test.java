package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.digest.Md5Crypt;

public class Md5Crypt_md5Crypt_2_1_Test {

    @Test
    @DisplayName("md5Crypt with keyBytes of odd length (1 byte) triggers specific branch in loop processing")
    void test_TC22() {
        // GIVEN
        byte[] keyBytes = {0x01};
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertTrue(hash.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        assertTrue(hash.length() > "$1$salt1234$".length(), "Hash length should be greater than the salt prefix length.");
    }

    @Test
    @DisplayName("md5Crypt with keyBytes of odd length (3 bytes) triggers specific branch in loop processing")
    void test_TC23() {
        // GIVEN
        byte[] keyBytes = {0x01, 0x02, 0x03};
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertTrue(hash.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        assertTrue(hash.length() > "$1$salt1234$".length(), "Hash length should be greater than the salt prefix length.");
    }

    @Test
    @DisplayName("md5Crypt with keyBytes of odd length (5 bytes) ensures proper branch coverage")
    void test_TC24() {
        // GIVEN
        byte[] keyBytes = {0x01, 0x02, 0x03, 0x04, 0x05};
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertTrue(hash.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        assertTrue(hash.length() > "$1$salt1234$".length(), "Hash length should be greater than the salt prefix length.");
    }

    @Test
    @DisplayName("md5Crypt with keyBytes of odd length (7 bytes) verifies branch execution")
    void test_TC25() {
        // GIVEN
        byte[] keyBytes = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07};
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertTrue(hash.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        assertTrue(hash.length() > "$1$salt1234$".length(), "Hash length should be greater than the salt prefix length.");
    }

    @Test
    @DisplayName("md5Crypt throws NullPointerException when keyBytes is null")
    void test_TC26() {
        // GIVEN
        byte[] keyBytes = null;
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        }, "Expected md5Crypt to throw NullPointerException when keyBytes is null");
    }
}