// package org.apache.commons.math3.dfp;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // 
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // import static org.junit.jupiter.api.Assertions.*;
// // import java.lang.reflect.Field;
// // 
// public class Dfp_nextAfter_1_1_Test {
// // 
// //     @Test
// //     @DisplayName("nextAfter with x as NaN sets FLAG_INVALID and returns QNAN")
// //     public void TC14_nextAfter_with_x_as_NaN() throws Exception {
// //         DfpField field = new DfpField(32);
// //         Dfp a = field.getOne();
// //         Dfp b = a.newInstance("NaN");
// //         Dfp result = a.nextAfter(b);
// // 
// //         Field flagsField = DfpField.class.getDeclaredField("flags");
// //         flagsField.setAccessible(true);
// //         int flags = flagsField.getInt(field);
// // 
// //         Field flagInvalidField = DfpField.class.getDeclaredField("FLAG_INVALID");
// //         flagInvalidField.setAccessible(true);
// //         int FLAG_INVALID = flagInvalidField.getInt(null);
// // 
// //         assertTrue((flags & FLAG_INVALID) != 0, "FLAG_INVALID should be set");
// //         assertEquals(Dfp.QNAN, result.classify(), "Result should be QNAN");
// //     }
// // 
// //     @Test
// //     @DisplayName("nextAfter with x as positive infinity and this finite increments towards infinity")
// //     public void TC15_nextAfter_with_x_positive_infinity() throws Exception {
// //         DfpField field = new DfpField(32);
// //         Dfp a = field.getOne();
// //         Dfp b = a.newInstance("Infinity");
// //         Dfp result = a.nextAfter(b);
// //         assertTrue(result.lessThan(b) || result.equals(b), "Result should be less than or equal to Infinity");
// //         assertTrue(a.lessThan(result), "Result should be greater than 'a'");
// //     }
// // 
// //     @Test
// //     @DisplayName("nextAfter with this as positive infinity and x finite decrements towards x")
// //     public void TC16_nextAfter_infinity_decrements() throws Exception {
// //         DfpField field = new DfpField(32);
// //         Dfp a = field.getOne().newInstance("Infinity");
// //         Dfp b = a.newInstance("1.0");
// //         Dfp result = a.nextAfter(b);
// //         assertTrue(result.lessThan(a), "Result should be less than Infinity");
// //         assertTrue(b.lessThan(result), "Result should be greater than 'b'");
// //     }
// // 
// //     @Test
// //     @DisplayName("nextAfter with this as zero and x positive increments towards positive")
// //     public void TC17_nextAfter_zero_to_positive() throws Exception {
// //         DfpField field = new DfpField(32);
// //         Dfp a = field.getZero();
// //         Dfp b = a.newInstance("1.0");
// //         Dfp result = a.nextAfter(b);
// // 
// //         Field flagsField = DfpField.class.getDeclaredField("flags");
// //         flagsField.setAccessible(true);
// //         int flags = flagsField.getInt(field);
// // 
// //         Field flagInexactField = DfpField.class.getDeclaredField("FLAG_INEXACT");
// //         flagInexactField.setAccessible(true);
// //         int FLAG_INEXACT = flagInexactField.getInt(null);
// // 
// //         assertTrue(result.greaterThan(field.getZero()), "Result should be greater than zero");
// //         assertTrue((flags & FLAG_INEXACT) != 0, "FLAG_INEXACT should be set");
// //     }
// // 
// //     @Test
// //     @DisplayName("nextAfter with this as zero and x negative decrements towards negative")
// //     public void TC18_nextAfter_zero_to_negative() throws Exception {
// //         DfpField field = new DfpField(32);
// //         Dfp a = field.getZero();
// //         Dfp b = a.newInstance("-1.0");
// //         Dfp result = a.nextAfter(b);
// // 
// //         Field flagsField = DfpField.class.getDeclaredField("flags");
// //         flagsField.setAccessible(true);
// //         int flags = flagsField.getInt(field);
// // 
// //         Field flagInexactField = DfpField.class.getDeclaredField("FLAG_INEXACT");
// //         flagInexactField.setAccessible(true);
// //         int FLAG_INEXACT = flagInexactField.getInt(null);
// // 
// //         assertTrue(result.lessThan(field.getZero()), "Result should be less than zero");
// //         assertTrue((flags & FLAG_INEXACT) != 0, "FLAG_INEXACT should be set");
// //     }
// // 
// // }
// }