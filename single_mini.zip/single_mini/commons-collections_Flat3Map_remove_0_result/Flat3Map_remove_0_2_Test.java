package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.collections4.map.Flat3Map;
import java.lang.reflect.Field;

public class Flat3Map_remove_0_2_Test {

    @Test
    @DisplayName("Remove null key when size is two and key1 is null")
    public void TC06() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        
        // Reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);
        
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);
        
        Object nonNullKey2 = "key2";
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, nonNullKey2);
        
        Object expectedValue1 = "value1";
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, expectedValue1);
        
        Object expectedValue2 = "value2";
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, expectedValue2);
        
        // Act
        Object result = map.remove(null);
        
        // Assert
        assertEquals(expectedValue1, result);
        
        // Verify key1 is shifted to key2
        Object updatedKey1 = key1Field.get(map);
        assertEquals(nonNullKey2, updatedKey1);
        
        // Verify size is updated
        int updatedSize = sizeField.getInt(map);
        assertEquals(1, updatedSize);
    }

    @Test
    @DisplayName("Attempt to remove null key when size is two but no keys are null")
    public void TC07() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        
        // Reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);
        
        Object nonNullKey1 = "key1";
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, nonNullKey1);
        
        Object nonNullKey2 = "key2";
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, nonNullKey2);
        
        // Act
        Object result = map.remove(null);
        
        // Assert
        assertNull(result);
        
        // Verify size remains unchanged
        int updatedSize = sizeField.getInt(map);
        assertEquals(2, updatedSize);
    }

    @Test
    @DisplayName("Remove null key when size is three and key3 is null")
    public void TC08() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        
        // Reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);
        
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);
        
        Object expectedValue3 = "value3";
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, expectedValue3);
        
        // Act
        Object result = map.remove(null);
        
        // Assert
        assertEquals(expectedValue3, result);
        
        // Verify key3 is removed
        Object updatedKey3 = key3Field.get(map);
        assertNull(updatedKey3);
        
        // Verify size is updated
        int updatedSize = sizeField.getInt(map);
        assertEquals(2, updatedSize);
    }

    @Test
    @DisplayName("Remove null key when size is three and key2 is null")
    public void TC09() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        
        // Reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);
        
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);
        
        Object expectedValue2 = "value2";
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, expectedValue2);
        
        // Act
        Object result = map.remove(null);
        
        // Assert
        assertEquals(expectedValue2, result);
        
        // Verify key2 is removed
        Object updatedKey2 = key2Field.get(map);
        assertNull(updatedKey2);
        
        // Verify size is updated
        int updatedSize = sizeField.getInt(map);
        assertEquals(1, updatedSize);
    }

    @Test
    @DisplayName("Remove null key when size is three and key1 is null")
    public void TC10() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        
        // Reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);
        
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);
        
        Object expectedValue1 = "value1";
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, expectedValue1);
        
        // Act
        Object result = map.remove(null);
        
        // Assert
        assertEquals(expectedValue1, result);
        
        // Verify key1 is shifted to key2
        Object key2 = Flat3Map.class.getDeclaredField("key2").get(map);
        assertEquals(key2, key1Field.get(map));
        
        // Verify size is updated
        int updatedSize = sizeField.getInt(map);
        assertEquals(2, updatedSize);
    }
}