package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class BHSDCodec_encode_1_2_Test {

    @Test
    @DisplayName("encode successfully encodes value with isSigned=false and delta encoding")
    void testEncodeUnsignedDelta() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(2, 100, 0, 1);
        int value = 150;
        int last = 100;

        // Act
        byte[] result = codec.encode(value, last);

        // Assert
        byte[] expected = {50};
        assertArrayEquals(expected, result, "The encoded byte array should correctly represent the value with unsigned delta encoding.");
    }

    @Test
    @DisplayName("encode successfully encodes negative value with isSigned=true and delta encoding")
    void testEncodeSignedDeltaNegative() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(2, 100, 1, 1);
        int value = -50;
        int last = 10;

        // Act
        byte[] result = codec.encode(value, last);

        // Assert
        byte[] expected = {119};
        assertArrayEquals(expected, result, "The encoded byte array should correctly represent the negative value with signed delta encoding.");
    }

    @Test
    @DisplayName("encode throws Pack200Exception when isDelta=true but value sequence leads to negative final z")
    void testEncodeDeltaResultNegative() throws Exception {
        // Arrange
        BHSDCodec codec = new BHSDCodec(2, 100, 1, 1);
        int value = 10;
        int last = 20;

        // Act & Assert
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            codec.encode(value, last);
        }, "Expected encode to throw Pack200Exception when the final z is negative.");
        assertEquals("unable to encode", exception.getMessage(), "Exception message should indicate encoding failure due to negative z.");
    }
}