package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;

public class UTF32Reader_read_1_1_Test {
    
    @Test
    @DisplayName("read() initializes _tmpBuf and successfully reads a single character, returning its integer value")
    public void test_TC14_readReturnsValidCharacter() throws Exception {
        // Arrange
        byte[] data = {0x00, 0x00, 0x00, 0x41}; // Represents 'A'
        IOContext context = new IOContext(null, null, false); // Provide necessary object dependencies
        InputStream in = new ByteArrayInputStream(data);
        UTF32Reader reader = new UTF32Reader(context, in, data, 0, data.length, true);

        // Ensure _tmpBuf is null via reflection
        Field tmpBufField = UTF32Reader.class.getDeclaredField("_tmpBuf");
        tmpBufField.setAccessible(true);
        tmpBufField.set(reader, null);

        // Act
        int result = reader.read();

        // Assert
        assertEquals(65, result, "The read() method should return the integer value of 'A' (65)");
    }

    @Test
    @DisplayName("read() initializes _tmpBuf and encounters end of stream, returning -1")
    public void test_TC15_readReturnsMinusOneAtEOF() throws Exception {
        // Arrange
        byte[] data = new byte[0]; // Empty buffer to simulate EOF
        IOContext context = new IOContext(null, null, false); // Provide necessary object dependencies
        InputStream in = new ByteArrayInputStream(data);
        UTF32Reader reader = new UTF32Reader(context, in, data, 0, data.length, true);

        // Ensure _tmpBuf is null via reflection
        Field tmpBufField = UTF32Reader.class.getDeclaredField("_tmpBuf");
        tmpBufField.setAccessible(true);
        tmpBufField.set(reader, null);

        // Act
        int result = reader.read();

        // Assert
        assertEquals(-1, result, "The read() method should return -1 to indicate EOF");
    }
}