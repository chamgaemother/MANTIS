package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import com.fasterxml.jackson.core.io.JsonStringEncoder;
import java.util.Arrays;

public class JsonStringEncoder_encodeAsUTF8_0_1_Test {

    @Test
    @DisplayName("encodeAsUTF8 with empty string returns empty byte array")
    public void TC01_encodeAsUTF8_emptyString() {
        // Given
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "";
        
        // When
        byte[] result = encoder.encodeAsUTF8(text);
        
        // Then
        Assertions.assertEquals(0, result.length, "Expected empty byte array");
    }

    @Test
    @DisplayName("encodeAsUTF8 with single ASCII character encodes correctly")
    public void TC02_encodeAsUTF8_singleASCII() {
        // Given
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "A";
        
        // When
        byte[] result = encoder.encodeAsUTF8(text);
        
        // Then
        Assertions.assertAll(
            () -> Assertions.assertEquals(1, result.length, "Expected byte array length of 1"),
            () -> Assertions.assertEquals((byte)0x41, result[0], "Expected byte value 0x41")
        );
    }

    @Test
    @DisplayName("encodeAsUTF8 with multiple ASCII characters encodes correctly")
    public void TC03_encodeAsUTF8_multipleASCII() {
        // Given
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "Hello";
        
        // When
        byte[] result = encoder.encodeAsUTF8(text);
        
        // Then
        byte[] expected = {0x48, 0x65, 0x6C, 0x6C, 0x6F};
        Assertions.assertTrue(Arrays.equals(expected, result), "Byte arrays do not match expected values");
    }

    @Test
    @DisplayName("encodeAsUTF8 with ASCII characters exceeding initial buffer size")
    public void TC04_encodeAsUTF8_ASCIIExceedingBuffer() {
        // Given
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "ABCDEFGHIJKLMNOPQRST"; // 20 characters
        
        // When
        byte[] result = encoder.encodeAsUTF8(text);
        
        // Then
        byte[] expected = text.getBytes(); // Default charset is UTF-8
        Assertions.assertTrue(Arrays.equals(expected, result), "Byte arrays do not match expected values after buffer expansion");
    }

    @Test
    @DisplayName("encodeAsUTF8 with single non-ASCII character requiring 2-byte encoding")
    public void TC05_encodeAsUTF8_single2ByteCharacter() {
        // Given
        JsonStringEncoder encoder = new JsonStringEncoder();
        String text = "Ã©";
        
        // When
        byte[] result = encoder.encodeAsUTF8(text);
        
        // Then
        byte[] expected = {(byte)0xC3, (byte)0xA9};
        Assertions.assertTrue(Arrays.equals(expected, result), "Byte arrays do not match expected 2-byte UTF-8 encoding");
    }

}