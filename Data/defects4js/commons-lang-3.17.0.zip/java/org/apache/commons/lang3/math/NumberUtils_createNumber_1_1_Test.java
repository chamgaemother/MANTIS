package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_createNumber_1_1_Test {

    @Test
    @DisplayName("Input string with invalid hexadecimal digit 'G', should throw NumberFormatException")
    void TC37_createNumber_InvalidHexadecimalDigit() {
        // GIVEN
        String input = "0x1G";
        
        // WHEN & THEN
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input));
    }

    @Test
    @DisplayName("Input string with leading zero and invalid octal digit '9', should throw NumberFormatException")
    void TC38_createNumber_InvalidOctalDigit() {
        // GIVEN
        String input = "0759";
        
        // WHEN & THEN
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input));
    }

    @Test
    @DisplayName("Input string with multiple decimal points, should throw NumberFormatException")
    void TC39_createNumber_MultipleDecimalPoints() {
        // GIVEN
        String input = "123.45.67";
        
        // WHEN & THEN
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input));
    }

    @Test
    @DisplayName("Input string with multiple exponents, should throw NumberFormatException")
    void TC40_createNumber_MultipleExponents() {
        // GIVEN
        String input = "1e2e3";
        
        // WHEN & THEN
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input));
    }

    @Test
    @DisplayName("Input string with lowercase type suffix 'd', should return Double")
    void TC41_createNumber_LowercaseTypeSuffixD() {
        // GIVEN
        String input = "123.45d";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertNotNull(result, "Result should not be null");
        assertTrue(result instanceof Double, "Result should be an instance of Double");
        assertEquals(123.45d, result.doubleValue(), "Double value should match the input");
    }
}