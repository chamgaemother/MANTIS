package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class TokenMgrErrorTest {

    @Test
    @DisplayName("Test addEscapes with null input")
    void testAddEscapesNullInput() {
        assertThrows(NullPointerException.class, () -> {
            TokenMgrError.addEscapes(null);
        });
    }

    @Test
    @DisplayName("Test addEscapes with empty string")
    void testAddEscapesEmptyString() {
        String input = "";
        String expected = "";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with no escapable characters")
    void testAddEscapesNoEscapes() {
        String input = "Hello World!";
        String expected = "Hello World!";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with all single-character escapes")
    void testAddEscapesSingleCharacters() {
        String input = "\b\t\n\f\r\"'\\";
        String expected = "\\b\\t\\n\\f\\r\\\"\\\'\\\\";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with null character")
    void testAddEscapesNullCharacter() {
        String input = "\0";
        String expected = "";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with control characters below 0x20")
    void testAddEscapesControlCharacters() {
        String input = "\u0001\u001F";
        String expected = "\\u0001\\u001f";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with characters above 0x7e")
    void testAddEscapesHighCharacters() {
        String input = "\u007F\u00A9\uD83D\uDE00";
        String expected = "\\u007f\\u00a9\\ud83d\\ude00";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with mixed content")
    void testAddEscapesMixedContent() {
        String input = "Hello\nWorld\t\u263A\u0000\"\\";
        String expected = "Hello\\nWorld\\t\\u263a\\\"\\\\";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with multiple sequential escapable characters")
    void testAddEscapesSequentialEscapable() {
        String input = "\b\t\n\f\r\"'\\";
        String expected = "\\b\\t\\n\\f\\r\\\"\\\'\\\\";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with boundary characters")
    void testAddEscapesBoundaryCharacters() {
        String input = "\u001F\u0020\u007E\u007F";
        String expected = "\\u001f \\~\\u007f";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test addEscapes with unicode surrogate pairs")
    void testAddEscapesUnicodeSurrogatePairs() {
        String input = "\uD834\uDD1E"; // Musical symbol G clef
        String expected = "\\ud834\\udd1e";
        String actual = TokenMgrError.addEscapes(input);
        assertEquals(expected, actual);
    }
}