package org.jfree.chart.plot;

import java.lang.reflect.Method;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.data.general.ValueDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MeterPlot_draw_0_2_Test {

    @Test
    @DisplayName("draw method with shape not equal to CIRCLE")
    public void TC06_draw_with_shape_not_CIRCLE() throws Exception {
        // Given
        MeterPlot plot = new MeterPlot();
        plot.setDialShape(DialShape.CHORD);  // Corrected method name to setDialShape
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        PlotState state = null;  // Made state null for simplicity
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        ValueDataset dataset = mock(ValueDataset.class);
        when(dataset.getValue()).thenReturn(50.0);
        plot.setDataset(dataset);

        // When
        plot.draw(g2, area, new Point2D.Double(50, 50), state, info);

        // Then
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    @DisplayName("draw method with dataset as null")
    public void TC07_draw_with_null_dataset() throws Exception {
        // Given
        MeterPlot plot = new MeterPlot();
        plot.setDataset(null);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // When
        assertDoesNotThrow(() -> {
            plot.draw(g2, area, new Point2D.Double(50, 50), state, info);
        });

        // Then
        verify(g2, never()).fill(any());
    }

    @Test
    @DisplayName("draw method with dialBackgroundPaint as null")
    public void TC08_draw_with_null_dialBackgroundPaint() throws Exception {
        // Given
        MeterPlot plot = new MeterPlot();
        plot.setDialBackgroundPaint(null);
        ValueDataset dataset = mock(ValueDataset.class);
        when(dataset.getValue()).thenReturn(75.0);
        plot.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // When
        plot.draw(g2, area, new Point2D.Double(50, 50), state, info);

        // Then
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2).setPaint(paintCaptor.capture());
        assertNotNull(paintCaptor.getValue(), "Default paint should be used when dialBackgroundPaint is null");
    }

    @Test
    @DisplayName("draw method with dialBackgroundPaint not null")
    public void TC09_draw_with_non_null_dialBackgroundPaint() throws Exception {
        // Given
        MeterPlot plot = new MeterPlot();
        plot.setDialBackgroundPaint(Color.BLUE);
        ValueDataset dataset = mock(ValueDataset.class);
        when(dataset.getValue()).thenReturn(85.0);
        plot.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // When
        plot.draw(g2, area, new Point2D.Double(50, 50), state, info);

        // Then
        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2).setPaint(paintCaptor.capture());
        assertEquals(Color.BLUE, paintCaptor.getValue(), "dialBackgroundPaint should be used when it is not null");
    }

    @Test
    @DisplayName("draw method with iterator having no MeterIntervals")
    public void TC10_draw_with_no_MeterIntervals() throws Exception {
        // Given
        MeterPlot plot = new MeterPlot();
        plot.clearIntervals();  // Clear all intervals to simulate none
        ValueDataset dataset = mock(ValueDataset.class);
        when(dataset.getValue()).thenReturn(60.0);
        plot.setDataset(dataset);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // When
        assertDoesNotThrow(() -> {
            plot.draw(g2, area, new Point2D.Double(50, 50), state, info);
        });

        // Then
        verify(g2, never()).setPaint(any());
    }
}
