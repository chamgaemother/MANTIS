package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_pow_2_2_Test {

    @Test
    @DisplayName("pow(x > 1, y is a large negative integer within range) returns +0.0")
    void TC11_pow_large_x_large_negative_integer_y_returns_zero() {
        // Given
        double x = 3.0;
        double y = -1e308;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertEquals(+0.0, result, "pow(x > 1, large negative y) should return +0.0");
    }

    @Test
    @DisplayName("pow(x < -1, y is a large odd integer within range) returns Double.NEGATIVE_INFINITY")
    void TC12_pow_negative_x_large_odd_integer_y_returns_neg_infty() {
        // Given
        double x = -2.0;
        // Using a large odd integer represented as a double
        double y = 9007199254740993.0; // 2^53 + 1, largest exact odd integer in double

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertEquals(Double.NEGATIVE_INFINITY, result, "pow(x < -1, large odd integer y) should return -Infinity");
    }

    @Test
    @DisplayName("pow(x < -1, y is a large even integer within range) returns Double.POSITIVE_INFINITY")
    void TC13_pow_negative_x_large_even_integer_y_returns_pos_infty() {
        // Given
        double x = -3.0;
        // Using a large even integer represented as a double
        double y = 9007199254740992.0; // 2^53, largest exact even integer in double

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertEquals(Double.POSITIVE_INFINITY, result, "pow(x < -1, large even integer y) should return +Infinity");
    }

    @Test
    @DisplayName("pow(x is negative and y is zero) returns 1.0")
    void TC14_pow_negative_x_y_zero_returns_one() {
        // Given
        double x = -1.0;
        double y = 0.0;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertEquals(1.0, result, "pow(x < 0, y=0.0) should return 1.0");
    }

    @Test
    @DisplayName("pow(x is NaN and y is not zero) returns Double.NaN")
    void TC15_pow_nan_x_y_non_zero_returns_nan() {
        // Given
        double x = Double.NaN;
        double y = 5.0;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertTrue(Double.isNaN(result), "pow(NaN, y!=0) should return NaN");
    }

}