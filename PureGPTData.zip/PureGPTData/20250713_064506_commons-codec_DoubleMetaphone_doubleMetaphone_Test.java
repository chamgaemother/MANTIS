import org.apache.commons.codec.language.DoubleMetaphone;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DoubleMetaphoneTest {

    private final DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

    @Test
    void testDoubleMetaphone_nullInput() {
        assertNull(doubleMetaphone.doubleMetaphone(null));
        assertNull(doubleMetaphone.doubleMetaphone(null, false));
        assertNull(doubleMetaphone.doubleMetaphone(null, true));
    }

    @Test
    void testDoubleMetaphone_emptyInput() {
        assertNull(doubleMetaphone.doubleMetaphone(""));
        assertNull(doubleMetaphone.doubleMetaphone("", false));
        assertNull(doubleMetaphone.doubleMetaphone("", true));
    }

    @Test
    void testDoubleMetaphone_simpleNames() {
        assertEquals("TMS", doubleMetaphone.doubleMetaphone("Thomas"));
        assertEquals("FRKS", doubleMetaphone.doubleMetaphone("Ferko"));
        assertEquals("S", doubleMetaphone.doubleMetaphone("S"));
    }

    @Test
    void testDoubleMetaphone_alternateEncoding() {
        assertEquals("TMS", doubleMetaphone.doubleMetaphone("Thomas", true));
        assertEquals("FRKS", doubleMetaphone.doubleMetaphone("Ferko", true));
        assertEquals("S", doubleMetaphone.doubleMetaphone("S", true));
        assertEquals("XL", doubleMetaphone.doubleMetaphone("Choler", true));
    }

    @Test
    void testDoubleMetaphone_silentStart() {
        assertEquals("N", doubleMetaphone.doubleMetaphone("Knapp"));
        assertEquals("PNN", doubleMetaphone.doubleMetaphone("Pneumonia"));
    }

    @Test
    void testDoubleMetaphone_specialCases() {
        assertEquals("JRS", doubleMetaphone.doubleMetaphone("Jurasek"));
        assertEquals("PS", doubleMetaphone.doubleMetaphone("Szymanski"));
        assertEquals("JRN", doubleMetaphone.doubleMetaphone("Jenkins"));
        assertEquals("SKLSK", doubleMetaphone.doubleMetaphone("Schlesinger"));
    }

    @Test
    void testDoubleMetaphone_slavoGermanic() {
        assertEquals("FRTS", doubleMetaphone.doubleMetaphone("Fritz"));
        assertEquals("KNPL", doubleMetaphone.doubleMetaphone("Knopfel"));
    }

    @Test
    void testDoubleMetaphone_edgeCases() {
        assertEquals("JX", doubleMetaphone.doubleMetaphone("Jack"));
        assertEquals("JK", doubleMetaphone.doubleMetaphone("Jock"));
    }

    @Test
    void testDoubleMetaphone_vowelEdgeCases() {
        assertEquals("YA", doubleMetaphone.doubleMetaphone("Yacht"));
        assertEquals("XSTNTN", doubleMetaphone.doubleMetaphone("Xtina", true));
    }

    @Test
    void testDoubleMetaphone_longInput() {
        doubleMetaphone.setMaxCodeLen(10);
        assertEquals("MRTN", doubleMetaphone.doubleMetaphone("Martiniously"));
    }
}