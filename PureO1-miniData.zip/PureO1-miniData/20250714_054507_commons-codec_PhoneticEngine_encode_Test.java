import org.apache.commons.codec.language.bm.Languages;
import org.apache.commons.codec.language.bm.NameType;
import org.apache.commons.codec.language.bm.RuleType;
import org.apache.commons.codec.language.bm.PhoneticEngine;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class PhoneticEngineTest {

    @Test
    void encode_NullInput_ShouldThrowException() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        assertThrows(NullPointerException.class, () -> engine.encode(null, Languages.LanguageSet.from("en")));
    }

    @Test
    void encode_NullLanguageSet_ShouldThrowException() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        assertThrows(NullPointerException.class, () -> engine.encode("John", null));
    }

    @ParameterizedTest
    @NullAndEmptySource
    void encode_EmptyOrNullInput_ShouldHandleGracefully(String input) {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        if (input == null) {
            assertThrows(NullPointerException.class, () -> engine.encode(input, Languages.LanguageSet.from("en")));
        } else {
            String result = engine.encode(input, Languages.LanguageSet.from("en"));
            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void encode_SingleWord_GenericNameType_NoPrefix() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "Smith";
        String expected = "S530";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_SingleWord_GenericNameType_WithPrefix() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "van Gogh";
        String expected = "(V500)-(VG200)";
        String actual = engine.encode(input, Languages.LanguageSet.from("nl"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_SingleWord_SephardicNameType_WithApostrophe() {
        PhoneticEngine engine = new PhoneticEngine(NameType.SEPHARDIC, RuleType.SOUNDEX, false);
        String input = "Abraham ibn Ezra";
        String expected = "(A160-)[-E660]";
        String actual = engine.encode(input, Languages.LanguageSet.from("he"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_SingleWord_AshkenaziNameType_WithPrefix() {
        PhoneticEngine engine = new PhoneticEngine(NameType.ASHKENAZI, RuleType.SOUNDEX, false);
        String input = "Ben-David";
        String expected = "(B350)-"
                + "(B350D130)";
        String actual = engine.encode(input, Languages.LanguageSet.from("he"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_MultipleWords_ConcatEnabled() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, true);
        String input = "John Doe";
        String expected = "J500 D000";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_MultipleWords_ConcatDisabled() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "John Doe";
        String expected = "J500-D000";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_GenericNameType_WithD_Apostrophe() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "d'Angelo";
        String expected = "(500)-("
                + "D530)";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_InvalidCharacters_ShouldDropSilently() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "J0hn! D@e#";
        String expected = "J500 D000";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_MaxPhonemesLimit_ShouldRespectLimit() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false, 5);
        String input = "ThisIsAVeryLongNameThatMightExceedThePhonemeLimit";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertTrue(actual.split("\\|").length <= 5);
    }

    @Test
    void encode_LanguageSpecificRules_ShouldApplyCorrectly() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "Göransson";
        String expected = "G660N200";
        String actual = engine.encode(input, Languages.LanguageSet.from("sv"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_NoMatchingRules_ShouldAppendAsIs() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "XYZ123";
        String expected = "XYZ123";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_EmptyLanguageSet_ShouldReturnEmpty() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "Smith";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from();
        String actual = engine.encode(input, languageSet);
        assertTrue(actual.isEmpty());
    }

    @Test
    void encode_InvalidRuleType_ShouldThrowExceptionOnEngineCreation() {
        assertThrows(IllegalArgumentException.class, () ->
                new PhoneticEngine(NameType.GENERIC, RuleType.RULES, false));
    }

    @Test
    void encode_SpecialCharacters_ShouldHandleGracefully() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "O'Connor";
        String expected = "O250";
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertEquals(expected, actual);
    }

    @ParameterizedTest
    @ValueSource(strings = {"", " ", "   "})
    void encode_WhitespaceOnly_ShouldReturnEmpty(String input) {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String actual = engine.encode(input, Languages.LanguageSet.from("en"));
        assertTrue(actual.isEmpty());
    }

    @Test
    void encode_MultiplePrefixes_GenericNameType_ShouldHandleAll() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        String input = "van der Meer";
        String expected = "(DM400)";
        String actual = engine.encode(input, Languages.LanguageSet.from("nl"));
        assertEquals(expected, actual);
    }

    @Test
    void encode_AllIfElsePaths_GenericNameType() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.SOUNDEX, false);
        // No prefix
        String input1 = "Johnson";
        String expected1 = "J525";
        String actual1 = engine.encode(input1, Languages.LanguageSet.from("en"));
        assertEquals(expected1, actual1);

        // With prefix
        String input2 = "de la Cruz";
        String expected2 = "(CR200)";
        String actual2 = engine.encode(input2, Languages.LanguageSet.from("es"));
        assertEquals(expected2, actual2);
    }
}