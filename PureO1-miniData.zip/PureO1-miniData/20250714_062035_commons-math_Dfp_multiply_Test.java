import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.dfp.DfpField.RoundingMode;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DfpTest {

    private DfpField field;
    private Dfp zero;
    private Dfp one;
    private Dfp two;
    private Dfp nan;
    private Dfp qnan;
    private Dfp snan;
    private Dfp posInf;
    private Dfp negInf;

    @BeforeEach
    void setUp() {
        field = new DfpField(5);
        zero = field.getZero();
        one = field.getOne();
        two = field.getTwo();
        nan = field.newDfp((byte)1, Dfp.QNAN);
        qnan = nan;
        snan = field.newDfp((byte)1, Dfp.SNAN);
        posInf = field.newDfp((byte)1, Dfp.INFINITE);
        negInf = field.newDfp((byte)-1, Dfp.INFINITE);
    }

    @Test
    void testMultiplyDifferentPrecision() {
        DfpField otherField = new DfpField(4);
        Dfp x = otherField.getOne();
        Dfp result = one.multiply(x);
        assertTrue(result.isNaN());
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testMultiplyNaNLeft() {
        Dfp result = nan.multiply(one);
        assertTrue(result.isNaN());
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testMultiplyNaNRight() {
        Dfp result = one.multiply(nan);
        assertTrue(result.isNaN());
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testMultiplyInfiniteLeftFiniteRight() {
        Dfp result = posInf.multiply(two);
        assertTrue(result.isInfinite());
        assertEquals(Dfp.INFINITE, result.classify());
        assertEquals(1, result.sign);
    }

    @Test
    void testMultiplyInfiniteRightFiniteLeft() {
        Dfp result = two.multiply(posInf);
        assertTrue(result.isInfinite());
        assertEquals(Dfp.INFINITE, result.classify());
        assertEquals(1, result.sign);
    }

    @Test
    void testMultiplyInfiniteBothSameSign() {
        Dfp result = posInf.multiply(posInf);
        assertTrue(result.isInfinite());
        assertEquals(Dfp.INFINITE, result.classify());
        assertEquals(1, result.sign);

        Dfp resultNeg = negInf.multiply(negInf);
        assertTrue(resultNeg.isInfinite());
        assertEquals(Dfp.INFINITE, resultNeg.classify());
        assertEquals(1, resultNeg.sign);
    }

    @Test
    void testMultiplyInfiniteBothDifferentSign() {
        Dfp result = posInf.multiply(negInf);
        assertTrue(result.isNaN());
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testMultiplyOverflow() {
        Dfp large1 = field.getOne();
        large1.exp = Dfp.MAX_EXP;
        Dfp large2 = field.getOne();
        large2.exp = Dfp.MAX_EXP;
        Dfp result = large1.multiply(large2);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    void testMultiplyNormal() {
        Dfp a = field.newInstance(1234);
        Dfp b = field.newInstance(5678);
        Dfp result = a.multiply(b);
        assertFalse(result.isNaN());
        assertFalse(result.isInfinite());
        assertEquals(1234 * 5678, result.toDouble(), 1e-10);
    }

    @Test
    void testMultiplyByZero() {
        Dfp result1 = one.multiply(zero);
        assertTrue(result1.isZero());
        assertEquals(1, result1.sign);

        Dfp result2 = zero.multiply(one);
        assertTrue(result2.isZero());
        assertEquals(1, result2.sign);

        Dfp negZero = field.newInstance(-0.0);
        Dfp result3 = negZero.multiply(one);
        assertTrue(result3.isZero());
        assertEquals(-1, result3.sign);
    }

    @Test
    void testMultiplyNegativeNumbers() {
        Dfp a = field.newInstance(-2);
        Dfp b = field.newInstance(-3);
        Dfp result = a.multiply(b);
        assertFalse(result.isNaN());
        assertFalse(result.isInfinite());
        assertEquals(6, result.toDouble(), 1e-10);
    }

    @Test
    void testMultiplyExponentAlignment() {
        Dfp a = field.newInstance("1e2");
        Dfp b = field.newInstance("1e3");
        Dfp result = a.multiply(b);
        assertFalse(result.isNaN());
        assertFalse(result.isInfinite());
        assertEquals(1e5, result.toDouble(), 1e-10);
    }

    @Test
    void testMultiplyRoundingException() {
        Dfp a = field.newInstance("9999");
        Dfp b = field.newInstance("9999");
        Dfp result = a.multiply(b);
        assertTrue(result.isInfinite() || result.toDouble() == 99980001); // Depending on rounding
    }

    @Test
    void testMultiplyResultZero() {
        Dfp a = field.getZero();
        Dfp b = field.getZero();
        Dfp result = a.multiply(b);
        assertTrue(result.isZero());
        assertEquals(1, result.sign);
    }

    @Test
    void testMultiplyNullInput() {
        assertThrows(NullPointerException.class, () -> {
            one.multiply(null);
        });
    }
}