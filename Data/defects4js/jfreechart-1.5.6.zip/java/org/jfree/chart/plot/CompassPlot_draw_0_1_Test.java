package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.needle.MeterNeedle;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CompassPlot_draw_0_1_Test {

    @Test
    @DisplayName("draw method with null PlotRenderingInfo and drawBorder=false")
    public void TC01_draw_with_null_PlotRenderingInfo_and_drawBorder_false() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D centerPoint = new Point2D.Double(100, 100);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo info = null;

        CompassPlot plot = new CompassPlot();
        plot.setDrawBorder(false);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, info);

        // THEN
        // Since info is null, setPlotArea should not be called.
        // Assuming drawBackground is a method that should not be called when drawBorder is false.
        // Using spy to verify interactions
        CompassPlot spyPlot = Mockito.spy(plot);
        spyPlot.draw(g2, area, centerPoint, plotState, info);
        verify(spyPlot, never()).drawBackground(any(Graphics2D.class), any(Rectangle2D.class));
    }

    @Test
    @DisplayName("draw method with non-null PlotRenderingInfo and drawBorder=true")
    public void TC02_draw_with_non_null_PlotRenderingInfo_and_drawBorder_true() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D centerPoint = new Point2D.Double(100, 100);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        CompassPlot plot = new CompassPlot();
        plot.setDrawBorder(true);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, info);

        // THEN
        // Verify that setPlotArea is called
        verify(info).setPlotArea(area);

        // Assuming drawBackground should be called when drawBorder is true
        CompassPlot spyPlot = Mockito.spy(plot);
        spyPlot.draw(g2, area, centerPoint, plotState, info);
        verify(spyPlot, times(1)).drawBackground(any(Graphics2D.class), any(Rectangle2D.class));
    }

    @Test
    @DisplayName("draw method when area height >= width")
    public void TC03_draw_with_area_height_greater_than_or_equal_to_width() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200); // height >= width
        Point2D centerPoint = new Point2D.Double(100, 100);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        CompassPlot plot = new CompassPlot();

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, info);

        // THEN
        // Verify that radius is set based on width
        // Access private field 'radius' via reflection
        Field radiusField = CompassPlot.class.getDeclaredField("radius");
        radiusField.setAccessible(true);
        int radius = radiusField.getInt(plot);
        assertEquals(100, radius, "Radius should be set based on width (200/2 -1)");
    }

    @Test
    @DisplayName("draw method when area height < width")
    public void TC04_draw_with_area_height_less_than_width() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 150); // height < width
        Point2D centerPoint = new Point2D.Double(100, 75);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        CompassPlot plot = new CompassPlot();

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, info);

        // THEN
        // Verify that radius is set based on height
        // Access private field 'radius' via reflection
        Field radiusField = CompassPlot.class.getDeclaredField("radius");
        radiusField.setAccessible(true);
        int radius = radiusField.getInt(plot);
        assertEquals(74, radius, "Radius should be set based on height (150/2 -1)");
    }

    @Test
    @DisplayName("draw method with zero iterations in first for-loop")
    public void TC05_draw_with_zero_iterations_in_first_for_loop() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D centerPoint = new Point2D.Double(100, 100);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        CompassPlot plot = new CompassPlot();

        // Use reflection to set revolutionDistance to a value that causes zero iterations
        Field revolutionDistanceField = CompassPlot.class.getDeclaredField("revolutionDistance");
        revolutionDistanceField.setAccessible(true);
        revolutionDistanceField.setDouble(plot, 0.0); // Assuming this causes zero iterations

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, info);

        // THEN
        // Verify that the first for-loop does not execute
        // This can be inferred by verifying that certain methods are not called
        // For example, no needles are drawn
        // Assuming seriesNeedle is an array of MeterNeedle
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedles = (MeterNeedle[]) seriesNeedleField.get(plot);
        for (MeterNeedle needle : seriesNeedles) {
            verify(needle, never()).draw(any(Graphics2D.class), any(Rectangle2D.class), anyDouble());
        }
    }
}