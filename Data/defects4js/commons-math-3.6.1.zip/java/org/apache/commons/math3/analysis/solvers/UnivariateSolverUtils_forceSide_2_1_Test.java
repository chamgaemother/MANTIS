package org.apache.commons.math3.analysis.solvers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;

public class UnivariateSolverUtils_forceSide_2_1_Test {

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE and fHi equals zero, method calls bracketing.solve and returns the solution")
    void TC17() throws Exception {
        // Given
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 5;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        when(bracketing.solve(eq(maxEval - 2), eq(f), anyDouble(), eq(0.0), eq(2.0), eq(allowedSolution))).thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // When
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // Then
        Assertions.assertEquals(2.0, result);
        verify(bracketing).solve(eq(maxEval - 2), eq(f), anyDouble(), eq(0.0), eq(2.0), eq(allowedSolution));
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, maxEval is less than or equal to 2, method throws NoBracketingException without calling bracketing.solve")
    void TC18() throws Exception {
        // Given
        AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
        int maxEval = 2;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // When & Then
        Assertions.assertThrows(NoBracketingException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        });
        verify(bracketing, never()).solve(anyInt(), any(), anyDouble(), anyDouble(), anyDouble(), any());
    }
}