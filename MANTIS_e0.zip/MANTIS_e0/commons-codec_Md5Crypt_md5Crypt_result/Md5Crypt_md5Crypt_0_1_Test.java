package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.nio.charset.StandardCharsets;

public class Md5Crypt_md5Crypt_0_1_Test {

    @Test
    @DisplayName("md5Crypt with null salt generates a hash with a randomly generated salt")
    public void TC01_md5Crypt_with_null_salt_generates_a_hash_with_a_randomly_generated_salt() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String salt = null;
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        Assertions.assertNotNull(hash, "Hash should not be null");
        Assertions.assertTrue(hash.startsWith("$1$"), "Hash should start with '$1$'");
        
        // Extract and verify the salt
        String[] parts = hash.split("\\$");
        Assertions.assertEquals(3, parts.length, "Hash should have three parts separated by '$'");
        String generatedSalt = parts[2];
        Assertions.assertEquals(8, generatedSalt.length(), "Salt should be 8 characters long");
        Assertions.assertTrue(generatedSalt.matches("[./a-zA-Z0-9]{8}"), "Salt should contain only allowed characters");
    }

    @Test
    @DisplayName("md5Crypt with valid salt starting with prefix processes correctly")
    public void TC02_md5Crypt_with_valid_salt_starting_with_prefix_processes_correctly() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        Assertions.assertNotNull(hash, "Hash should not be null");
        Assertions.assertTrue(hash.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        // Assuming the hash length should follow a specific pattern, adjust as needed
        Assertions.assertTrue(hash.length() > "$1$salt1234$".length(), "Hash length should be as expected");
    }

    @Test
    @DisplayName("md5Crypt with salt not starting with prefix prepends the prefix correctly")
    public void TC03_md5Crypt_with_salt_not_starting_with_prefix_prepends_the_prefix_correctly() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String salt = "salt1234";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        Assertions.assertNotNull(hash, "Hash should not be null");
        Assertions.assertTrue(hash.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
    }

    @Test
    @DisplayName("md5Crypt with invalid salt pattern throws IllegalArgumentException")
    public void TC04_md5Crypt_with_invalid_salt_pattern_throws_IllegalArgumentException() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String salt = "$1$invalid_salt!";
        String prefix = "$1$";

        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        }, "Expected IllegalArgumentException for invalid salt pattern");
    }

    @Test
    @DisplayName("md5Crypt with empty keyBytes array processes correctly")
    public void TC05_md5Crypt_with_empty_keyBytes_array_processes_correctly() {
        // GIVEN
        byte[] keyBytes = new byte[0];
        String salt = "$1$salt1234";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        Assertions.assertNotNull(hash, "Hash should not be null");
        Assertions.assertTrue(hash.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        // Additional verification can be added based on expected hash behavior with empty keyBytes
    }
}