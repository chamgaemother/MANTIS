package org.jfree.chart.ui;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * JUnit 5 test class for RectangleAnchor.getAnchorPoint method.
 */
public class RectangleAnchor_getAnchorPoint_0_1_Test {

    @Test
    @DisplayName("Returns center point when anchor is CENTER")
    void TC01_ReturnsCenterPointWhenAnchorIsCENTER() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.CENTER;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(5.0, point.getX(), 0.0001, "X coordinate should be 5.0");
        assertEquals(5.0, point.getY(), 0.0001, "Y coordinate should be 5.0");
    }

    @Test
    @DisplayName("Returns top point when anchor is TOP")
    void TC02_ReturnsTopPointWhenAnchorIsTOP() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.TOP;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(5.0, point.getX(), 0.0001, "X coordinate should be 5.0");
        assertEquals(0.0, point.getY(), 0.0001, "Y coordinate should be 0.0");
    }

    @Test
    @DisplayName("Returns bottom point when anchor is BOTTOM")
    void TC03_ReturnsBottomPointWhenAnchorIsBOTTOM() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.BOTTOM;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(5.0, point.getX(), 0.0001, "X coordinate should be 5.0");
        assertEquals(10.0, point.getY(), 0.0001, "Y coordinate should be 10.0");
    }

    @Test
    @DisplayName("Returns left point when anchor is LEFT")
    void TC04_ReturnsLeftPointWhenAnchorIsLEFT() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.LEFT;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(0.0, point.getX(), 0.0001, "X coordinate should be 0.0");
        assertEquals(5.0, point.getY(), 0.0001, "Y coordinate should be 5.0");
    }

    @Test
    @DisplayName("Returns right point when anchor is RIGHT")
    void TC05_ReturnsRightPointWhenAnchorIsRIGHT() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.RIGHT;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(10.0, point.getX(), 0.0001, "X coordinate should be 10.0");
        assertEquals(5.0, point.getY(), 0.0001, "Y coordinate should be 5.0");
    }

}