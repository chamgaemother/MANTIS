package org.joda.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.joda.time.DurationFieldType;
import org.joda.time.PeriodType;

import java.lang.reflect.Field;
import java.util.Map;

public class PeriodType_forFields_0_1_Test {

    @Test
    @DisplayName("Throws IllegalArgumentException when types array is null")
    void TC01() {
        // GIVEN
        DurationFieldType[] types = null;

        // WHEN & THEN
        Exception exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            PeriodType.forFields(types);
        });
        Assertions.assertEquals("Types array must not be null or empty", exception.getMessage());
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when types array is empty")
    void TC02() {
        // GIVEN
        DurationFieldType[] types = new DurationFieldType[0];

        // WHEN & THEN
        Exception exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            PeriodType.forFields(types);
        });
        Assertions.assertEquals("Types array must not be null or empty", exception.getMessage());
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when types array contains null element")
    void TC03() {
        // GIVEN
        DurationFieldType[] types = { DurationFieldType.years(), null, DurationFieldType.days() };

        // WHEN & THEN
        Exception exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            PeriodType.forFields(types);
        });
        Assertions.assertEquals("Types array must not contain null", exception.getMessage());
    }

    @Test
    @DisplayName("Returns cached PeriodType when cache is not empty and contains the type")
    void TC04() throws Exception {
        // GIVEN
        DurationFieldType[] types = { DurationFieldType.years(), DurationFieldType.days() };

        // Access the private static field cTypes via reflection
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);

        // Create a new PeriodType instance to cache
        PeriodType cachedType = PeriodType.yearDay();
        PeriodType key = new PeriodType(null, types, null);
        cTypes.put(key, cachedType);

        // WHEN
        PeriodType result = PeriodType.forFields(types);

        // THEN
        Assertions.assertSame(cachedType, result);

        // Clean up
        cTypes.clear();
    }

    @Test
    @DisplayName("Initializes cache when it is empty")
    void TC05() throws Exception {
        // GIVEN
        DurationFieldType[] types = { 
            DurationFieldType.years(), 
            DurationFieldType.months(),
            DurationFieldType.weeks(),
            DurationFieldType.days(),
            DurationFieldType.hours(),
            DurationFieldType.minutes(),
            DurationFieldType.seconds(),
            DurationFieldType.millis()
        };

        // Access the private static field cTypes via reflection
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);

        // Clear the cache
        cTypes.clear();

        // WHEN
        PeriodType result = PeriodType.forFields(types);

        // THEN
        // Verify cache is populated
        Assertions.assertFalse(cTypes.isEmpty());
        // Verify result is standard PeriodType
        Assertions.assertEquals(PeriodType.standard(), result);
    }
}