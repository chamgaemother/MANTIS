package org.apache.commons.compress.archivers.zip;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ZipArchiveInputStream_getNextZipEntry_1_2_Test {

    @Test
    @DisplayName("Throws ZipException when readFirstLocalFileHeader encounters invalid data")
    void TC26_readFirstLocalFileHeader_invalid_data_throws_exception() throws Exception {
        // Arrange
        byte[] invalidZipData = {0x00, 0x01, 0x02}; // Insufficient bytes for local file header
        InputStream inputStream = new ByteArrayInputStream(invalidZipData);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
        
        // Act & Assert
        assertThrows(ZipException.class, () -> {
            zipInputStream.getNextZipEntry();
        });
    }

    @Test
    @DisplayName("Processes multiple entries in sequence to cover loop iterations")
    void TC27_multiple_entries_sequential_processing() throws Exception {
        // Arrange
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            ZipEntry entry1 = new ZipEntry("entryName1");
            zos.putNextEntry(entry1);
            zos.write("Content of entry 1".getBytes());
            zos.closeEntry();
            
            ZipEntry entry2 = new ZipEntry("entryName2");
            zos.putNextEntry(entry2);
            zos.write("Content of entry 2".getBytes());
            zos.closeEntry();
            
            ZipEntry entry3 = new ZipEntry("entryName3");
            zos.putNextEntry(entry3);
            zos.write("Content of entry 3".getBytes());
            zos.closeEntry();
        }
        byte[] zipData = baos.toByteArray();
        InputStream inputStream = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
        
        // Act
        ZipArchiveEntry entry1Result = zipInputStream.getNextZipEntry();
        ZipArchiveEntry entry2Result = zipInputStream.getNextZipEntry();
        ZipArchiveEntry entry3Result = zipInputStream.getNextZipEntry();
        
        // Assert
        assertNotNull(entry1Result);
        assertEquals("entryName1", entry1Result.getName());
        
        assertNotNull(entry2Result);
        assertEquals("entryName2", entry2Result.getName());
        
        assertNotNull(entry3Result);
        assertEquals("entryName3", entry3Result.getName());
        
        zipInputStream.close();
    }

    @Test
    @DisplayName("Returns null after all entries have been processed")
    void TC28_end_of_entries_returns_null() throws Exception {
        // Arrange
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            ZipEntry entry1 = new ZipEntry("entryName1");
            zos.putNextEntry(entry1);
            zos.write("Content of entry 1".getBytes());
            zos.closeEntry();
        }
        byte[] zipData = baos.toByteArray();
        InputStream inputStream = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
        
        // Act
        ZipArchiveEntry entry1Result = zipInputStream.getNextZipEntry();
        ZipArchiveEntry finalEntry = zipInputStream.getNextZipEntry();
        
        // Assert
        assertNotNull(entry1Result);
        assertEquals("entryName1", entry1Result.getName());
        
        assertNull(finalEntry);
        
        zipInputStream.close();
    }
}