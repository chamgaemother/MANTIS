package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_1_Test {

    @Test
    @DisplayName("nysiis(null) returns null")
    void TC01() {
        Nysiis nysiis = new Nysiis();
        String input = null;
        String result = nysiis.nysiis(input);
        assertNull(result);
    }

    @Test
    @DisplayName("nysiis(\"\") returns empty string")
    void TC02() {
        Nysiis nysiis = new Nysiis();
        String input = "";
        String result = nysiis.nysiis(input);
        assertEquals("", result);
    }

    @Test
    @DisplayName("nysiis(\"MACDONALD\") replaces MAC with MCC")
    void TC03() {
        Nysiis nysiis = new Nysiis();
        String input = "MACDONALD";
        String result = nysiis.nysiis(input);
        assertTrue(result.startsWith("MCC"));
    }

    @Test
    @DisplayName("nysiis(\"KNIGHT\") replaces KN with NN")
    void TC04() {
        Nysiis nysiis = new Nysiis();
        String input = "KNIGHT";
        String result = nysiis.nysiis(input);
        assertTrue(result.contains("NN"));
    }

    @Test
    @DisplayName("nysiis(\"KELLY\") replaces K with C")
    void TC05() {
        Nysiis nysiis = new Nysiis();
        String input = "KELLY";
        String result = nysiis.nysiis(input);
        assertTrue(result.contains("C"));
    }
}