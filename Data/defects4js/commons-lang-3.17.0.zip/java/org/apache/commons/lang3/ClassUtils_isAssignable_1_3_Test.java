package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;

public class ClassUtils_isAssignable_1_3_Test {

    @Test
    @DisplayName("cls is non-primitive (ArrayList) and toClass is superclass (List) with autoboxing=true")
    void TC16() {
        // GIVEN
        Class<?> cls = ArrayList.class;
        Class<?> toClass = List.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is non-primitive (String) and toClass is not assignable (Integer) with autoboxing=false")
    void TC17() {
        // GIVEN
        Class<?> cls = String.class;
        Class<?> toClass = Integer.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is non-primitive (String) and toClass is not assignable (Integer) with autoboxing=true")
    void TC18() {
        // GIVEN
        Class<?> cls = String.class;
        Class<?> toClass = Integer.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is primitive (float) and toClass is assignable primitive (double) with autoboxing=false")
    void TC19() {
        // GIVEN
        Class<?> cls = float.class;
        Class<?> toClass = double.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is primitive (char) and toClass is non-primitive (Integer) with autoboxing=true")
    void TC20() {
        // GIVEN
        Class<?> cls = char.class;
        Class<?> toClass = Integer.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }
}