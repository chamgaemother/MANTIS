package com.fasterxml.jackson.databind.deser;

import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import org.mockito.ArgumentCaptor;
import org.mockito.MockitoAnnotations;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonTokenId;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BeanDeserializer_deserializeFromObject_1_2_Test {

    @Test
    @DisplayName("deserializeFromObject with _injectables set and injectValues invoked")
    void TC32() throws Exception {
        // Initialize Mockito annotations
        MockitoAnnotations.openMocks(this);

        // Create an instance of BeanDeserializer using reflection
        Class<?> clazz = Class.forName("com.fasterxml.jackson.databind.deser.BeanDeserializer");
        BeanDeserializerBuilder builder = Mockito.mock(BeanDeserializerBuilder.class);
        BeanDescription beanDesc = Mockito.mock(BeanDescription.class);
        BeanPropertyMap properties = Mockito.mock(BeanPropertyMap.class);
        Map<String, SettableBeanProperty> backRefs = Mockito.mock(Map.class);
        HashSet<String> ignorableProps = new HashSet<>();
        Set<String> includableProps = Mockito.mock(Set.class);

        BeanDeserializer deserializer = (BeanDeserializer) clazz.getDeclaredConstructor(
            BeanDeserializerBuilder.class,
            BeanDescription.class,
            BeanPropertyMap.class,
            Map.class,
            HashSet.class,
            boolean.class,
            Set.class,
            boolean.class
        ).newInstance(builder, beanDesc, properties, backRefs, ignorableProps, false, includableProps, false);

        // Use reflection to set the private _injectables field
        Field injectablesField = clazz.getDeclaredField("_injectables");
        injectablesField.setAccessible(true);
        Set<Object> mockInjectables = Mockito.mock(Set.class);
        injectablesField.set(deserializer, mockInjectables);

        // Use a spy on the deserializer to verify injectValues invocation
        BeanDeserializer spyDeserializer = Mockito.spy(deserializer);

        // Mock JsonParser and DeserializationContext
        JsonParser parser = Mockito.mock(JsonParser.class);
        DeserializationContext context = Mockito.mock(DeserializationContext.class);

        // Define behavior for parser
        Mockito.when(parser.isExpectedStartObjectToken()).thenReturn(true);
        Mockito.when(parser.hasTokenId(Mockito.eq(JsonTokenId.ID_FIELD_NAME))).thenReturn(false);

        // Invoke deserializeFromObject
        spyDeserializer.deserializeFromObject(parser, context);

        // Verify that injectValues was called
        Method injectValuesMethod = clazz.getDeclaredMethod("injectValues", DeserializationContext.class, Object.class);
        injectValuesMethod.setAccessible(true);
        ArgumentCaptor<Object> beanCaptor = ArgumentCaptor.forClass(Object.class);
        Mockito.verify(spyDeserializer).injectValues(Mockito.eq(context), beanCaptor.capture());

        // Assert that the bean has dependencies injected if applicable
        assertNotNull(beanCaptor.getValue());
    }

//     @Test
//     @DisplayName("deserializeFromObject with _needViewProcesing true, active view present, property not visible, and FAIL_ON_UNEXPECTED_VIEW_PROPERTIES enabled")
//     void TC33() throws Exception {
        // Initialize Mockito annotations
//         MockitoAnnotations.openMocks(this);
// 
        // Create an instance of BeanDeserializer using reflection
//         Class<?> clazz = Class.forName("com.fasterxml.jackson.databind.deser.BeanDeserializer");
//         BeanDeserializerBuilder builder = Mockito.mock(BeanDeserializerBuilder.class);
//         BeanDescription beanDesc = Mockito.mock(BeanDescription.class);
//         BeanPropertyMap properties = Mockito.mock(BeanPropertyMap.class);
//         Map<String, SettableBeanProperty> backRefs = Mockito.mock(Map.class);
//         HashSet<String> ignorableProps = new HashSet<>();
//         Set<String> includableProps = Mockito.mock(Set.class);
// 
//         BeanDeserializer deserializer = (BeanDeserializer) clazz.getDeclaredConstructor(
//             BeanDeserializerBuilder.class,
//             BeanDescription.class,
//             BeanPropertyMap.class,
//             Map.class,
//             HashSet.class,
//             boolean.class,
//             Set.class,
//             boolean.class
//         ).newInstance(builder, beanDesc, properties, backRefs, ignorableProps, false, includableProps, false);
// 
        // Use reflection to set the private _needViewProcesing field
//         Field needViewProcessingField = clazz.getDeclaredField("_needViewProcesing");
//         needViewProcessingField.setAccessible(true);
//         needViewProcessingField.set(deserializer, true);
// 
        // Use a spy on the deserializer to verify behavior
//         BeanDeserializer spyDeserializer = Mockito.spy(deserializer);
// 
        // Mock JsonParser and DeserializationContext
//         JsonParser parser = Mockito.mock(JsonParser.class);
//         DeserializationContext context = Mockito.mock(DeserializationContext.class);
// 
        // Define behavior for parser and context
//         Class<?> activeView = Mockito.mock(Class.class);
//         Mockito.when(context.getActiveView()).thenReturn(activeView);
//         Mockito.when(context.isEnabled(DeserializationFeature.FAIL_ON_UNEXPECTED_VIEW_PROPERTIES)).thenReturn(true);
//         Mockito.when(parser.hasTokenId(Mockito.eq(JsonTokenId.ID_FIELD_NAME))).thenReturn(true);
//         Mockito.when(parser.currentName()).thenReturn("hiddenProperty");
//         Mockito.when(properties.find("hiddenProperty")).thenReturn(null); // Property not visible
// 
        // Invoke deserializeFromObject and expect an exception
//         assertThrows(RuntimeException.class, () -> {
//             spyDeserializer.deserializeFromObject(parser, context);
//         });
// 
        // Verify that reportInputMismatch was called
//         Mockito.verify(context).reportInputMismatch(Mockito.eq(clazz), Mockito.contains("Input mismatch while deserializing"));
//     }

//     @Test
//     @DisplayName("deserializeFromObject with _needViewProcesing true, active view present, property not visible, and FAIL_ON_UNEXPECTED_VIEW_PROPERTIES disabled")
//     void TC34() throws Exception {
        // Initialize Mockito annotations
//         MockitoAnnotations.openMocks(this);
// 
        // Create an instance of BeanDeserializer using reflection
//         Class<?> clazz = Class.forName("com.fasterxml.jackson.databind.deser.BeanDeserializer");
//         BeanDeserializerBuilder builder = Mockito.mock(BeanDeserializerBuilder.class);
//         BeanDescription beanDesc = Mockito.mock(BeanDescription.class);
//         BeanPropertyMap properties = Mockito.mock(BeanPropertyMap.class);
//         Map<String, SettableBeanProperty> backRefs = Mockito.mock(Map.class);
//         HashSet<String> ignorableProps = new HashSet<>();
//         Set<String> includableProps = Mockito.mock(Set.class);
// 
//         BeanDeserializer deserializer = (BeanDeserializer) clazz.getDeclaredConstructor(
//             BeanDeserializerBuilder.class,
//             BeanDescription.class,
//             BeanPropertyMap.class,
//             Map.class,
//             HashSet.class,
//             boolean.class,
//             Set.class,
//             boolean.class
//         ).newInstance(builder, beanDesc, properties, backRefs, ignorableProps, false, includableProps, false);
// 
        // Use reflection to set the private _needViewProcesing field
//         Field needViewProcessingField = clazz.getDeclaredField("_needViewProcesing");
//         needViewProcessingField.setAccessible(true);
//         needViewProcessingField.set(deserializer, true);
// 
        // Use a spy on the deserializer to verify behavior
//         BeanDeserializer spyDeserializer = Mockito.spy(deserializer);
// 
        // Mock JsonParser and DeserializationContext
//         JsonParser parser = Mockito.mock(JsonParser.class);
//         DeserializationContext context = Mockito.mock(DeserializationContext.class);
// 
        // Define behavior for parser and context
//         Class<?> activeView = Mockito.mock(Class.class);
//         Mockito.when(context.getActiveView()).thenReturn(activeView);
//         Mockito.when(context.isEnabled(DeserializationFeature.FAIL_ON_UNEXPECTED_VIEW_PROPERTIES)).thenReturn(false);
//         Mockito.when(parser.hasTokenId(Mockito.eq(JsonTokenId.ID_FIELD_NAME))).thenReturn(true);
//         Mockito.when(parser.currentName()).thenReturn("hiddenProperty");
//         Mockito.when(properties.find("hiddenProperty")).thenReturn(null); // Property not visible
// 
        // Invoke deserializeFromObject
//         Object bean = spyDeserializer.deserializeFromObject(parser, context);
// 
        // Verify that unknown properties are skipped without exception
//         Mockito.verify(parser).skipChildren();
//         assertNotNull(bean);
//     }

    @Test
    @DisplayName("deserializeFromObject with deserializeAndSet throwing an exception")
    void TC35() throws Exception {
        // Initialize Mockito annotations
        MockitoAnnotations.openMocks(this);

        // Create an instance of BeanDeserializer using reflection
        Class<?> clazz = Class.forName("com.fasterxml.jackson.databind.deser.BeanDeserializer");
        BeanDeserializerBuilder builder = Mockito.mock(BeanDeserializerBuilder.class);
        BeanDescription beanDesc = Mockito.mock(BeanDescription.class);
        BeanPropertyMap properties = Mockito.mock(BeanPropertyMap.class);
        Map<String, SettableBeanProperty> backRefs = Mockito.mock(Map.class);
        HashSet<String> ignorableProps = new HashSet<>();
        Set<String> includableProps = Mockito.mock(Set.class);

        BeanDeserializer deserializer = (BeanDeserializer) clazz.getDeclaredConstructor(
            BeanDeserializerBuilder.class,
            BeanDescription.class,
            BeanPropertyMap.class,
            Map.class,
            HashSet.class,
            boolean.class,
            Set.class,
            boolean.class
        ).newInstance(builder, beanDesc, properties, backRefs, ignorableProps, false, includableProps, false);

        // Use a spy on the deserializer to verify behavior
        BeanDeserializer spyDeserializer = Mockito.spy(deserializer);

        // Mock JsonParser and DeserializationContext
        JsonParser parser = Mockito.mock(JsonParser.class);
        DeserializationContext context = Mockito.mock(DeserializationContext.class);

        // Define behavior for parser
        Mockito.when(parser.hasTokenId(Mockito.eq(JsonTokenId.ID_FIELD_NAME))).thenReturn(true);
        Mockito.when(parser.currentName()).thenReturn("faultyProperty");

        // Mock the property to throw exception during deserializeAndSet
        SettableBeanProperty faultyProp = Mockito.mock(SettableBeanProperty.class);
        Mockito.when(properties.find("faultyProperty")).thenReturn(faultyProp);
        Mockito.doThrow(new RuntimeException("Deserialization failed"))
               .when(faultyProp).deserializeAndSet(Mockito.eq(parser), Mockito.eq(context), Mockito.any());

        // Invoke deserializeFromObject and expect exception handling
        assertThrows(RuntimeException.class, () -> {
            spyDeserializer.deserializeFromObject(parser, context);
        });

        // Verify that wrapAndThrow was called
        Method wrapAndThrowMethod = clazz.getDeclaredMethod("wrapAndThrow", Throwable.class, Object.class, String.class, DeserializationContext.class);
        wrapAndThrowMethod.setAccessible(true);
        Mockito.verify(spyDeserializer).wrapAndThrow(Mockito.any(Throwable.class), Mockito.any(), Mockito.eq("faultyProperty"), Mockito.eq(context));
    }

    @Test
    @DisplayName("deserializeFromObject with handleUnknownProperty invoked for unknown property without _anySetter")
    void TC36() throws Exception {
        // Initialize Mockito annotations
        MockitoAnnotations.openMocks(this);

        // Create an instance of BeanDeserializer using reflection
        Class<?> clazz = Class.forName("com.fasterxml.jackson.databind.deser.BeanDeserializer");
        BeanDeserializerBuilder builder = Mockito.mock(BeanDeserializerBuilder.class);
        BeanDescription beanDesc = Mockito.mock(BeanDescription.class);
        BeanPropertyMap properties = Mockito.mock(BeanPropertyMap.class);
        Map<String, SettableBeanProperty> backRefs = Mockito.mock(Map.class);
        HashSet<String> ignorableProps = new HashSet<>();
        Set<String> includableProps = Mockito.mock(Set.class);

        BeanDeserializer deserializer = (BeanDeserializer) clazz.getDeclaredConstructor(
            BeanDeserializerBuilder.class,
            BeanDescription.class,
            BeanPropertyMap.class,
            Map.class,
            HashSet.class,
            boolean.class,
            Set.class,
            boolean.class
        ).newInstance(builder, beanDesc, properties, backRefs, ignorableProps, false, includableProps, false);

        // Ensure _anySetter is null
        Field anySetterField = clazz.getDeclaredField("_anySetter");
        anySetterField.setAccessible(true);
        anySetterField.set(deserializer, null);

        // Use a spy on the deserializer to verify handleUnknownProperty invocation
        BeanDeserializer spyDeserializer = Mockito.spy(deserializer);

        // Mock JsonParser and DeserializationContext
        JsonParser parser = Mockito.mock(JsonParser.class);
        DeserializationContext context = Mockito.mock(DeserializationContext.class);

        // Define behavior for parser
        Mockito.when(parser.hasTokenId(Mockito.eq(JsonTokenId.ID_FIELD_NAME))).thenReturn(true);
        Mockito.when(parser.currentName()).thenReturn("unknownProperty");

        // Mock properties to return null for unknown property
        Mockito.when(properties.find("unknownProperty")).thenReturn(null);

        // Mock handleUnknownProperty method
        Method handleUnknownPropertyMethod = clazz.getDeclaredMethod("handleUnknownProperty", JsonParser.class, DeserializationContext.class, Object.class, String.class);
        handleUnknownPropertyMethod.setAccessible(true);
        Mockito.doNothing().when(spyDeserializer).handleUnknownProperty(Mockito.eq(parser), Mockito.eq(context), Mockito.any(), Mockito.eq("unknownProperty"));

        // Invoke deserializeFromObject
        Object bean = spyDeserializer.deserializeFromObject(parser, context);

        // Verify that handleUnknownProperty was called
        Mockito.verify(spyDeserializer).handleUnknownProperty(Mockito.eq(parser), Mockito.eq(context), Mockito.any(), Mockito.eq("unknownProperty"));

        assertNotNull(bean);
    }
}