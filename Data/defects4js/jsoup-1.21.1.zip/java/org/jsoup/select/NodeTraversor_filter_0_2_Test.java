package org.jsoup.select;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.jsoup.select.NodeFilter.FilterResult;

public class NodeTraversor_filter_0_2_Test {

    @Test
    @DisplayName("filter returns SKIP_CHILDREN on head processing")
    public void TC06_filter_skips_children_on_head() {
        // GIVEN
        Node root = createNodeWithSiblings();
        NodeFilter filter = new SkipChildrenFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(FilterResult.SKIP_CHILDREN, result);
    }

    @Test
    @DisplayName("filter returns REMOVE on child node")
    public void TC07_filter_removes_a_child_node() {
        // GIVEN
        Node root = createNodeWithRemovableChild();
        NodeFilter filter = new RemoveChildFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertTrue(root.childNodeSize() == 0);
        assertEquals(FilterResult.CONTINUE, result);
    }

    @Test
    @DisplayName("filter throws AssertionError when node is null during tail processing")
    public void TC08_filter_throws_AssertionError_on_null_node_during_tail() {
        // GIVEN
        Node root = createNullNodeDuringTail();
        NodeFilter filter = new FaultyFilter();

        // WHEN & THEN
        assertThrows(AssertionError.class, () -> {
            NodeTraversor.filter(filter, root);
        });
    }

    @Test
    @DisplayName("filter returns STOP during tail processing")
    public void TC09_filter_stops_during_tail_processing() {
        // GIVEN
        Node root = createNodeWithTailProcessing();
        NodeFilter filter = new StopDuringTailFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(FilterResult.STOP, result);
    }

    @Test
    @DisplayName("filter returns CONTINUE after tail processing with siblings")
    public void TC10_filter_continues_after_tail_with_siblings() {
        // GIVEN
        Node root = createNodeWithSiblingsAfterTail();
        NodeFilter filter = new ContinueAfterTailFilter();

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(FilterResult.CONTINUE, result);
    }

    // Helper methods and filter implementations

    private Element createNodeWithSiblings() {
        Element parent = new Element("parent");
        Node child1 = new Element("child1");
        Node child2 = new Element("child2");
        parent.appendChild(child1);
        parent.appendChild(child2);
        return parent;
    }

    private Element createNodeWithRemovableChild() {
        Element parent = new Element("parent");
        Node child = new Element("child");
        parent.appendChild(child);
        return parent;
    }

    private Node createNullNodeDuringTail() {
        return null;
    }

    private Element createNodeWithTailProcessing() {
        Element parent = new Element("parent");
        Node child = new Element("child");
        parent.appendChild(child);
        return parent;
    }

    private Element createNodeWithSiblingsAfterTail() {
        Element parent = new Element("parent");
        Node child1 = new Element("child1");
        Node child2 = new Element("child2");
        parent.appendChild(child1);
        parent.appendChild(child2);
        return parent;
    }

    class SkipChildrenFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.SKIP_CHILDREN;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.CONTINUE;
        }
    }

    class RemoveChildFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.CONTINUE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            node.remove();
            return FilterResult.CONTINUE;
        }
    }

    class FaultyFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.CONTINUE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.CONTINUE;
        }
    }

    class StopDuringTailFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.CONTINUE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.STOP;
        }
    }

    class ContinueAfterTailFilter implements NodeFilter {
        @Override
        public FilterResult head(Node node, int depth) {
            return FilterResult.CONTINUE;
        }

        @Override
        public FilterResult tail(Node node, int depth) {
            return FilterResult.CONTINUE;
        }
    }
}