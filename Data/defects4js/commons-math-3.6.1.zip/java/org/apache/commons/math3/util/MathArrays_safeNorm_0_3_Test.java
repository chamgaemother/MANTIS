package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MathArrays_safeNorm_0_3_Test {

    @Test
    @DisplayName("safeNorm after loop with s1 equal to zero and s2 >= x3max path")
    void TC11() {
        double[] v = new double[]{1.0e+10, 1.0e+10};
        double result = MathArrays.safeNorm(v);
        double expected = Math.sqrt(2.0e+20);
        assertEquals(expected, result, 1e+10, "norm is calculated using s2 >= x3max path");
    }

    @Test
    @DisplayName("safeNorm after loop with s1 equal to zero and s2 < x3max path")
    void TC12() {
        double[] v = new double[]{5.0e+9, 1.0e+10};
        double result = MathArrays.safeNorm(v);
        double expected = Math.sqrt(1.025e+20);
        assertEquals(expected, result, 1e+10, "norm is calculated using s2 < x3max path");
    }

    @Test
    @DisplayName("safeNorm with multiple iterations covering boundary values for rdwarf and agiant")
    void TC13() {
        double[] v = new double[]{3.834e-20, 1.304e+19};
        double result = MathArrays.safeNorm(v);
        double expected = Math.sqrt((3.834e-20 * 3.834e-20) + (1.304e+19 * 1.304e+19));
        assertEquals(expected, result, 1e+5, "norm is correctly computed with boundary values");
    }

    @Test
    @DisplayName("safeNorm with elements exactly equal to rdwarf and agiant")
    void TC14() {
        double[] v = new double[]{3.834e-20, 1.304e+19};
        double result = MathArrays.safeNorm(v);
        double expected = Math.sqrt((3.834e-20 * 3.834e-20) + (1.304e+19 * 1.304e+19));
        assertEquals(expected, result, 1e+5, "norm is correctly computed with elements at exact boundaries");
    }

    @Test
    @DisplayName("safeNorm with mixed elements affecting s1, s2, and s3")
    void TC15() {
        double[] v = new double[]{1.0e-21, 5.0, 2.0e+19};
        double result = MathArrays.safeNorm(v);
        double expected = Math.sqrt((2.0e+19 * 2.0e+19) + (5.0 * 5.0) + (1.0e-21 * 1.0e-21));
        assertEquals(expected, result, 1e+10, "norm is correctly computed with mixed element types");
    }

}