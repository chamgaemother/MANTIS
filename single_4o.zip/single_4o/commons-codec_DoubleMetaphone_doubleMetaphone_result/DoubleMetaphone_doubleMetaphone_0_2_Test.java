package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DoubleMetaphone_doubleMetaphone_0_2_Test {

    @Test
    @DisplayName("Alternate encoding returns correct value with alternate=true")
    void testAlternateEncodingWithAlternateTrue() {
        // Given
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "JOEL";

        // When
        String primaryEncoding = doubleMetaphone.doubleMetaphone(value, false);
        String alternateEncoding = doubleMetaphone.doubleMetaphone(value, true);

        // Then
        assertNotEquals(primaryEncoding, alternateEncoding, "Primary and alternate encodings should differ when alternate is true.");
    }

    @Test
    @DisplayName("Input with connectors like 'MC' processes correctly")
    void testInputWithMcConnectors() {
        // Given
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "MACKENZIE";

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        // Assuming correct handling, expecting certain pattern in result
        assertTrue(result.startsWith("MK"), "Expected encoding to handle 'MC' correctly at start.");
    }

    @Test
    @DisplayName("Processes final character as a vowel with prefix handling")
    void testFinalVowelHandling() {
        // Given
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "AIDEN";

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.startsWith("A"), "Expected initial vowel handling to append 'A'.");
    }

    @Test
    @DisplayName("Processes doubled letters correctly like 'LL'")
    void testDoubledLetters() {
        // Given
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "DALLAS";

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        // Expect 'L' only once
        assertFalse(result.contains("LL"), "Encoding should not append 'LL' twice.");
    }

    @Test
    @DisplayName("Processes input with alternate=false properly returning primary")
    void testPrimaryEncodingWithAlternateFalse() {
        // Given
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "INVALID";

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        // Assuming default behavior provides primary encoding correctly
        assertNotNull(result, "Result should not be null for primary encoding.");
    }
}