import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.urls.PieURLGenerator;
import org.jfree.chart.util.PaintMap;
import org.jfree.chart.util.StrokeMap;
import org.jfree.chart.util.ShadowGenerator;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.Objects;
import java.util.TreeMap;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

class PiePlotTest {

    @Test
    void testHashCodeWithDifferentPieIndex() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setPieIndex(1);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentInteriorGap() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setInteriorGap(0.20);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentCircular() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setCircular(false);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentStartAngle() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setStartAngle(45.0);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentDirection() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setDirection(org.jfree.chart.util.Rotation.ANTICLOCKWISE);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentSectionPaintMap() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setSectionPaint("key", Color.RED);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentSectionOutlinesVisible() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setSectionOutlinesVisible(false);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    } 

    @Test
    void testHashCodeWithDifferentExplodePercentages() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setExplodePercent("key", 0.25);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentLabelGenerator() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        PieSectionLabelGenerator labelGenerator = (dataset, key) -> key.toString();
        plot2.setLabelGenerator(labelGenerator);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentToolTipGenerator() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setToolTipGenerator((dataset, key) -> "Tooltip");
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentURLGenerator() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        PieURLGenerator urlGenerator = (dataset, key, pieIndex) -> "http://example.com";
        plot2.setURLGenerator(urlGenerator);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentLegendLabelGenerator() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        PieSectionLabelGenerator legendLabelGenerator = (dataset, key) -> key.toString();
        plot2.setLegendLabelGenerator(legendLabelGenerator);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }

    @Test
    void testHashCodeWithDifferentShadowGenerator() {
        PiePlot<String> plot1 = new PiePlot<>();
        PiePlot<String> plot2 = new PiePlot<>();
        ShadowGenerator shadowGenerator = (image) -> image;
        plot2.setShadowGenerator(shadowGenerator);
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }
}