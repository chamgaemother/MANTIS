package org.jfree.chart.renderer.xy;
import org.jfree.chart.entity.EntityCollection;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class XYBarRenderer_drawItem_0_5_Test {

    @Test
    @DisplayName("drawItem paints bar when pass is 1")
    void TC21_drawItem_paints_bar_when_pass_is_1() throws Exception {
        // Arrange
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mock dependencies
        when(renderer.getShadowsVisible()).thenReturn(false); // Mocking the required method
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(dataset.getXValue(series, item)).thenReturn(1.0); // Adjust mocks for method logic
        when(dataset.getYValue(series, item)).thenReturn(5.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, pass);

        // Assert
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem draws item label when item label is visible")
    void TC22_drawItem_draws_item_label_when_visible() throws Exception {
        // Arrange
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        XYItemLabelGenerator generator = mock(XYItemLabelGenerator.class);

        // Mock dependencies
        when(renderer.getShadowsVisible()).thenReturn(true); // Mocking the required method
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(dataset.getXValue(series, item)).thenReturn(1.0); // Adjust mocks for method logic
        when(dataset.getYValue(series, item)).thenReturn(5.0);
        when(generator.generateLabel(dataset, series, item)).thenReturn("Label");

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, pass);

        // Assert
        verify(g2, atLeastOnce()).drawString(eq("Label"), anyFloat(), anyFloat());
    }

    @Test
    @DisplayName("drawItem adds entity when info is provided and entity collection is not null")
    void TC24_drawItem_adds_entity_when_info_and_collection_are_present() throws Exception {
        // Arrange
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        EntityCollection entities = mock(EntityCollection.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mock dependencies
        when(renderer.getShadowsVisible()).thenReturn(false); // Mocking the required method
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(dataset.getXValue(series, item)).thenReturn(1.0); // Adjust mocks for method logic
        when(dataset.getYValue(series, item)).thenReturn(5.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, pass);

        // Assert
        verify(renderer).addEntity(eq(entities), any(Rectangle2D.class), eq(dataset), eq(series), eq(item), anyDouble(),
                anyDouble());
    }

    @Test
    @DisplayName("drawItem does not add entity when EntityCollection is null")
    void TC25_drawItem_does_not_add_entity_when_entityCollection_is_null() throws Exception {
        // Arrange
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mock dependencies
        when(renderer.getShadowsVisible()).thenReturn(false); // Mocking the required method
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(dataset.getXValue(series, item)).thenReturn(1.0); // Adjust mocks for method logic
        when(dataset.getYValue(series, item)).thenReturn(5.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, pass);

        // Assert
        verify(renderer, never()).addEntity(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }
}