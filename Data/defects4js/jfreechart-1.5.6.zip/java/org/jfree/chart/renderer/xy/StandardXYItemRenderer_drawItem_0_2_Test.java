package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.awt.Point;
import java.awt.Image;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class StandardXYItemRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem with plotDiscontinuous disabled and valid gapThreshold")
    void TC06_drawItem_with_plotDiscontinuous_disabled_and_valid_gapThreshold() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 1;

        when(renderer.getPlotDiscontinuous()).thenReturn(false);
        when(renderer.getGapThreshold()).thenReturn(10.0);
        when(dataset.getItemCount(series)).thenReturn(2);
        when(dataset.getXValue(series, item)).thenReturn(20.0);
        when(dataset.getYValue(series, item)).thenReturn(30.0);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(30.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
                series, item, crosshairState, 0);

        // Assert
        // Verify that g2.draw() was called to draw the line between items
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("drawItem with baseShapesVisible false and plotImages disabled")
    void TC07_drawItem_with_baseShapesVisible_false_and_plotImages_disabled() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 1;

        when(renderer.getBaseShapesVisible()).thenReturn(false);
        when(renderer.getPlotImages()).thenReturn(false);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getItemCount(series)).thenReturn(2);
        when(dataset.getXValue(series, item)).thenReturn(20.0);
        when(dataset.getYValue(series, item)).thenReturn(30.0);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(30.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
                series, item, crosshairState, 0);

        // Assert
        // Verify that no shapes or images are drawn
        verify(g2, never()).draw(any(Shape.class));
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).drawImage(any(Image.class), anyInt(), anyInt(), any());
    }

    @Test
    @DisplayName("drawItem with itemLabelVisible true and label position valid")
    void TC08_drawItem_with_itemLabelVisible_true_and_label_position_valid() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = spy(new StandardXYItemRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 1;

        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getItemCount(series)).thenReturn(2);
        when(dataset.getXValue(series, item)).thenReturn(20.0);
        when(dataset.getYValue(series, item)).thenReturn(30.0);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(30.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
                series, item, crosshairState, 0);

        // Assert
        // Verify that drawItemLabel was called
        verify(renderer, times(1)).drawItemLabel(eq(g2), any(PlotOrientation.class), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("drawItem with itemLabelVisible true but label position invalid")
    void TC09_drawItem_with_itemLabelVisible_true_but_label_position_invalid() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = spy(new StandardXYItemRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 1;

        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getItemCount(series)).thenReturn(2);
        when(dataset.getXValue(series, item)).thenReturn(200.0); // Position outside dataArea
        when(dataset.getYValue(series, item)).thenReturn(300.0);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(300.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
                series, item, crosshairState, 0);

        // Assert
        // Verify that drawItemLabel was not called since position is invalid
        verify(renderer, never()).drawItemLabel(eq(g2), any(PlotOrientation.class), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("drawItem with seriesPath reset for a new series")
    void TC10_drawItem_with_seriesPath_reset_for_a_new_series() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = spy(new StandardXYItemRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int newSeries = 1;
        int item = 0;

        when(renderer.getItemVisible(newSeries, item)).thenReturn(true);
        when(dataset.getItemCount(newSeries)).thenReturn(1);
        when(dataset.getXValue(newSeries, item)).thenReturn(10.0);
        when(dataset.getYValue(newSeries, item)).thenReturn(15.0);
        when(renderer.getItemPaint(newSeries, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(newSeries, item)).thenReturn(mock(Stroke.class));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(15.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset,
                newSeries, item, crosshairState, 0);

        // Assert
        // Verify that seriesPath was reset and a new path was started
        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, atLeastOnce()).draw(lineCaptor.capture());
        // Additional assertions can be added here to verify the exact path if needed
    }
}