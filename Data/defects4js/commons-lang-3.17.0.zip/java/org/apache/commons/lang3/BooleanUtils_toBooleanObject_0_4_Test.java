package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class BooleanUtils_toBooleanObject_0_4_Test {

    @Test
    @DisplayName("Input string is single character '0', returns Boolean.FALSE")
    public void TC16() {
        String input = "0";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string is three characters 'YeS', returns Boolean.TRUE")
    public void TC17() {
        String input = "YeS";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is three characters 'OfF', returns Boolean.FALSE")
    public void TC18() {
        String input = "OfF";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string is two characters 'On', returns Boolean.TRUE")
    public void TC19() {
        String input = "On";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is five characters 'False', returns Boolean.FALSE")
    public void TC20() {
        String input = "False";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

}