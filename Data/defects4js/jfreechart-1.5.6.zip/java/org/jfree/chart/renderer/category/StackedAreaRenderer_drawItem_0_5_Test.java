package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class StackedAreaRenderer_drawItem_0_5_Test {

    @Test
    @DisplayName("Draw item with dataset.getValue(row, column) returning Infinity")
    void TC21_DrawItem_WithDatasetValueInfinity() {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setSeriesVisible(0, true);
        renderer.setRenderAsPercentages(false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getValue(0, 0)).thenReturn(Double.POSITIVE_INFINITY);
        when(dataset.getValue(0, -1)).thenReturn(30);
        when(dataset.getValue(0, 1)).thenReturn(20);

        // WHEN & THEN
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    @DisplayName("Draw item with dataset having zero visible series")
    void TC22_DrawItem_WithZeroVisibleSeries() {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setSeriesVisible(0, true);
        renderer.setRenderAsPercentages(false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(state.getVisibleSeriesArray()).thenReturn(new int[] {});
        when(dataset.getValue(0, 0)).thenReturn(50);
        when(dataset.getValue(0, -1)).thenReturn(30);
        when(dataset.getValue(0, 1)).thenReturn(20);

        // WHEN & THEN
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    @DisplayName("Draw item with dataset being empty")
    void TC23_DrawItem_WithEmptyDataset() {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setSeriesVisible(0, true);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getValue(0, 0)).thenReturn(null);
        when(dataset.getColumnCount()).thenReturn(0);

        // WHEN & THEN
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    @DisplayName("Draw item with only one visible series in dataset")
    void TC24_DrawItem_WithSingleVisibleSeries() {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setSeriesVisible(0, true);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(dataset.getValue(0, 0)).thenReturn(50);
        when(dataset.getValue(0, -1)).thenReturn(null);
        when(dataset.getValue(0, 1)).thenReturn(null);

        // WHEN & THEN
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    @DisplayName("Draw item with large dataset values to test rendering limits")
    void TC25_DrawItem_WithLargeDatasetValues() {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setSeriesVisible(0, true);
        renderer.setRenderAsPercentages(false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getValue(0, 0)).thenReturn(Double.MAX_VALUE);
        when(dataset.getValue(0, -1)).thenReturn(Double.MAX_VALUE);
        when(dataset.getValue(0, 1)).thenReturn(Double.MAX_VALUE);

        // WHEN & THEN
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }
}