package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.jxpath.JXPathException;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;

public class MethodLookupUtils_lookupStaticMethod_0_2_Test {

    // Dummy classes for testing purposes
    public static class SomeClass {
        public static void staticMethod(String value) {}
        public static void staticMethodWithNulls(String param1, String param2, int param3) {}
        public void nonStaticMethod() {}
        public static void ambiguousMethod(String value) {}
        public static void ambiguousMethod(Integer value) {}
    }

    public static class AmbiguousClass {
        public static void ambiguousMethod(String value) {}
        public static void ambiguousMethod(Integer value) {}
    }

    public static class NonStaticClass {
        public void nonStaticMethod() {}
    }

    @Test
    @DisplayName("Exact static method does not exist, but one matching method is found via type conversion")
    void TC06_lookupStaticMethod_without_exact_match_but_with_type_conversion() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethod";
        Object[] parameters = new Object[]{ "10" };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result);
        assertTrue(Modifier.isStatic(result.getModifiers()));
    }

    @Test
    @DisplayName("Multiple matching methods found after type conversion, leading to ambiguity")
    void TC07_lookupStaticMethod_with_ambiguous_method_matches_after_type_conversion() {
        // GIVEN
        Class<?> targetClass = AmbiguousClass.class;
        String name = "ambiguousMethod";
        Object[] parameters = new Object[]{ "value" };

        // WHEN & THEN
        JXPathException exception = assertThrows(JXPathException.class, () -> {
            MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
        });
        assertTrue(exception.getMessage().contains("Ambiguous method call"));
    }

    @Test
    @DisplayName("Exact static method exists but is not static, searching continues")
    void TC08_lookupStaticMethod_when_exact_method_is_not_static() {
        // GIVEN
        Class<?> targetClass = NonStaticClass.class;
        String name = "nonStaticMethod";
        Object[] parameters = new Object[]{};

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("No matching methods found even after type conversion")
    void TC09_lookupStaticMethod_with_no_matching_methods_after_type_conversion() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "nonExistentMethod";
        Object[] parameters = new Object[]{ "test" };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("Parameters array has multiple elements with some null, exact match exists")
    void TC10_lookupStaticMethod_with_multiple_parameters_containing_nulls_and_exact_match_exists() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethodWithNulls";
        Object[] parameters = new Object[]{ null, "test", 5 };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result);
        assertTrue(Modifier.isStatic(result.getModifiers()));
    }
}