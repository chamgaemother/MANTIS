package org.jfree.chart.renderer.xy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class CyclicXYItemRenderer_drawItem_2_2_Test {

    @Test
    @DisplayName("TC22: drawItem with plotLines=true, rangeAxis is CyclicNumberAxis with cycle splitting, domainAxis is not CyclicNumberAxis")
    public void testTC22_drawItem_RangeAxisCyclic_Split_DomainAxisNonCyclic() throws Exception {
        // Arrange
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);
        spyRenderer.setPlotLines(true);

        // Mock domainAxis as non-CyclicNumberAxis (ValueAxis)
        ValueAxis domainAxis = mock(ValueAxis.class);

        // Mock rangeAxis as CyclicNumberAxis
        CyclicNumberAxis rangeAxis = mock(CyclicNumberAxis.class);
        when(rangeAxis.getCycleBound()).thenReturn(200.0);
        when(rangeAxis.isBoundMappedToLastCycle()).thenReturn(false);

        // Mock dataset
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(190.0);
        when(dataset.getXValue(0, 1)).thenReturn(120.0);
        when(dataset.getYValue(0, 1)).thenReturn(210.0);

        // Mock other dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // Assert
        // Capture the XYDataset arguments passed to super.drawItem
        ArgumentCaptor<XYDataset> datasetCaptor = ArgumentCaptor.forClass(XYDataset.class);
        verify(spyRenderer, times(2)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(rangeAxis), datasetCaptor.capture(), eq(0), eq(1), eq(crosshairState), eq(0));
        
        // Further assertions can be added here to verify the state of the datasets if necessary
    }

    @Test
    @DisplayName("TC23: drawItem with plotLines=true, domainAxis and rangeAxis are CyclicNumberAxis, and no cycle splitting occurs on either axis")
    public void testTC23_drawItem_BothAxesCyclic_NoSplit() throws Exception {
        // Arrange
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);
        spyRenderer.setPlotLines(true);

        // Mock domainAxis as CyclicNumberAxis
        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis.getCycleBound()).thenReturn(80.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        // Mock rangeAxis as CyclicNumberAxis
        CyclicNumberAxis rangeAxis = mock(CyclicNumberAxis.class);
        when(rangeAxis.getCycleBound()).thenReturn(160.0);
        when(rangeAxis.isBoundMappedToLastCycle()).thenReturn(false);

        // Mock dataset
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(100.0);
        when(dataset.getXValue(0, 1)).thenReturn(120.0);
        when(dataset.getYValue(0, 1)).thenReturn(120.0);

        // Mock other dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // Assert
        // Verify that super.drawItem is called once without any cycle splitting
        verify(spyRenderer, times(1)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(rangeAxis), eq(dataset), eq(0), eq(1), eq(crosshairState), eq(0));
    }

    @Test
    @DisplayName("TC24: drawItem with plotLines=true, both domainAxis and rangeAxis are CyclicNumberAxis, and cycleBound is exactly matched by one of the x and y values")
    public void testTC24_drawItem_BothAxesCyclic_BoundaryMatch() throws Exception {
        // Arrange
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);
        spyRenderer.setPlotLines(true);

        // Mock domainAxis as CyclicNumberAxis with cycleBound exactly matched by x1
        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis.getCycleBound()).thenReturn(100.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        // Mock rangeAxis as CyclicNumberAxis with cycleBound exactly matched by y1
        CyclicNumberAxis rangeAxis = mock(CyclicNumberAxis.class);
        when(rangeAxis.getCycleBound()).thenReturn(200.0);
        when(rangeAxis.isBoundMappedToLastCycle()).thenReturn(false);

        // Mock dataset where x1 and y1 match the cycleBound
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(90.0);
        when(dataset.getYValue(0, 0)).thenReturn(190.0);
        when(dataset.getXValue(0, 1)).thenReturn(100.0);
        when(dataset.getYValue(0, 1)).thenReturn(200.0);

        // Mock other dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // Assert
        // Capture the XYDataset arguments passed to super.drawItem
        ArgumentCaptor<XYDataset> datasetCaptor = ArgumentCaptor.forClass(XYDataset.class);
        verify(spyRenderer, times(4)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(rangeAxis), datasetCaptor.capture(), eq(0), eq(1), eq(crosshairState), eq(0));
        
        // Further assertions can be added here to verify the state of the datasets if necessary
    }
}