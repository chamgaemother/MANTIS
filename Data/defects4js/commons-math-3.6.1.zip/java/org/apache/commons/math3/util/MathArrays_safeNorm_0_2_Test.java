package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.util.MathArrays;

public class MathArrays_safeNorm_0_2_Test {

    @Test
    @DisplayName("safeNorm with single element where xabs is below rdwarf but above x3max")
    public void TC06() {
        double[] v = new double[]{1.0e-19};
        double result = MathArrays.safeNorm(v);
        assertEquals(1.0e-19, result, 1e-20);
    }

    @Test
    @DisplayName("safeNorm with single element where xabs is below rdwarf and less than or equal to x3max and not zero")
    public void TC07() {
        double[] v = new double[]{1.0e-21};
        double result = MathArrays.safeNorm(v);
        assertEquals(1.0e-21, result, 1e-22);
    }

    @Test
    @DisplayName("safeNorm with multiple elements covering a mix of branches including updates to s1, s2, and s3")
    public void TC08() {
        double[] v = new double[]{1.0e+18, 5.0, 1.0e-21};
        double expected = Math.sqrt((1.0e+18 * 1.0e+18) + (5.0 * 5.0) + (1.0e-21 * 1.0e-21));
        double result = MathArrays.safeNorm(v);
        assertEquals(expected, result, 1e+3); // Delta adjusted for large magnitude
    }

    @Test
    @DisplayName("safeNorm after loop with s1 not equal to zero, computing norm using s1 path")
    public void TC09() {
        double[] v = new double[]{1.0e+18, 2.0e+18};
        double result = MathArrays.safeNorm(v);
        assertEquals(2.0e+18, result, 1e+12);
    }

    @Test
    @DisplayName("safeNorm after loop with s1 and s2 equal to zero, resulting in norm being zero")
    public void TC10() {
        double[] v = new double[]{0.0, 0.0};
        double result = MathArrays.safeNorm(v);
        assertEquals(0.0, result, 1e-15);
    }
}