package org.jfree.chart.plot;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.general.ValueDataset;
import org.jfree.data.Range;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

public class ThermometerPlot_draw_0_1_Test {

    @Test
    @DisplayName("Draw method with null PlotRenderingInfo") // Descriptive display name.
    void TC01_draw_with_null_PlotRenderingInfo() {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        ValueDataset nonNullDataset = mock(ValueDataset.class);
        when(nonNullDataset.getValue()).thenReturn(Double.valueOf(100.0));
        plot.setDataset(nonNullDataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 200);
        Point2D anchor = new Point2D.Double(50, 100);
        PlotState state = new PlotState();
        PlotRenderingInfo info = null;

        // WHEN & THEN
        assertDoesNotThrow(() -> plot.draw(g2, area, anchor, state, info));
    }

    @Test
    @DisplayName("Draw method with non-null PlotRenderingInfo and null dataset")
    void TC02_draw_with_non_null_PlotRenderingInfo_and_null_dataset() {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        plot.setDataset(null);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(10, 20, 150, 250);
        Point2D anchor = new Point2D.Double(75, 125);
        PlotState state = new PlotState();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(info, times(1)).setPlotArea(area);
    }

    @Test
    @DisplayName("Draw method with dataset.getValue() as null")
    void TC03_draw_with_dataset_getValue_null() {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        ValueDataset emptyDatasetWithNullValue = mock(ValueDataset.class);
        when(emptyDatasetWithNullValue.getValue()).thenReturn(null);
        plot.setDataset(emptyDatasetWithNullValue);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(5, 10, 200, 300);
        Point2D anchor = new Point2D.Double(100, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN & THEN
        assertDoesNotThrow(() -> plot.draw(g2, area, anchor, state, info));
        verify(info, times(1)).setPlotArea(area);
    }

//     @Test
//     @DisplayName("Draw method with valid dataset and subrangeIndicatorsVisible false")
//     void TC04_draw_with_valid_dataset_and_subrangeIndicatorsVisible_false() {
        // GIVEN
//         ThermometerPlot plot = new ThermometerPlot();
//         ValueDataset validDataset = mock(ValueDataset.class);
//         when(validDataset.getValue()).thenReturn(Double.valueOf(75.0));
//         plot.setDataset(validDataset);
//         plot.setSubrangeIndicatorsVisible(false);
// 
//         ValueAxis validRangeAxis = mock(ValueAxis.class);
//         when(validRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
//         plot.setRangeAxis(validRangeAxis);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(20, 40, 300, 400);
//         Point2D anchor = new Point2D.Double(150, 200);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
//         verify(info, times(1)).setPlotArea(area);
//         verify(g2, times(1)).setPaint(any(Paint.class));
//         verify(g2, times(1)).fill(any(Ellipse2D.class));
//         verify(g2, never()).draw(any(Line2D.class)); // No subrange indicators should be drawn
//     }

//     @Test
//     @DisplayName("Draw method with dataset value below minimum range")
//     void TC05_draw_with_dataset_value_below_minimum_range() {
        // GIVEN
//         ThermometerPlot plot = new ThermometerPlot();
//         ValueDataset datasetValueBelowMin = mock(ValueDataset.class);
//         when(datasetValueBelowMin.getValue()).thenReturn(Double.valueOf(-10.0));
//         plot.setDataset(datasetValueBelowMin);
//         plot.setSubrangeIndicatorsVisible(true);
// 
//         ValueAxis validRangeAxis = mock(ValueAxis.class);
//         when(validRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
//         when(validRangeAxis.getRange()).thenReturn(new Range(0.0, 100.0));
//         plot.setRangeAxis(validRangeAxis);
//         plot.setAxisLocation(ThermometerPlot.LEFT);
//         plot.setShowValueLines(false);
//         plot.setValueLocation(ThermometerPlot.RIGHT);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(30, 60, 350, 450);
//         Point2D anchor = new Point2D.Double(175, 225);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
//         verify(info, times(1)).setPlotArea(area);
//         verify(validRangeAxis, times(1)).valueToJava2D(-10.0, area, RectangleEdge.LEFT);
//         verify(g2, times(1)).setPaint(any(Paint.class));
//         verify(g2, times(1)).fill(any(Ellipse2D.class));
//     }
}