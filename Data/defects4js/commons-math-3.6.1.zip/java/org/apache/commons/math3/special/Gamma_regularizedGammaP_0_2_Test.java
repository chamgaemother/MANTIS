package org.apache.commons.math3.special;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.math3.exception.MaxCountExceededException;
import static org.junit.jupiter.api.Assertions.*;

public class Gamma_regularizedGammaP_0_2_Test {

    @Test
    @DisplayName("regularizedGammaP with x >= a + 1 uses regularizedGammaQ and returns 1.0 - Q")
    public void TC06() {
        // Given
        double a = 2.0;
        double x = 4.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // When
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // Then
        double expected = 1.0 - Gamma.regularizedGammaQ(a, x, epsilon, maxIterations);
        assertEquals(expected, result, epsilon, "regularizedGammaP should return 1.0 - regularizedGammaQ(a, x, epsilon, maxIterations)");
    }

    @Test
    @DisplayName("regularizedGammaP with x < a + 1 and loop terminates without iterations")
    public void TC07() {
        // Given
        double a = 5.0;
        double x = 3.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // When
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // Then
        // Expected value is calculated based on the known results or mathematical computation
        double expectedValue = 0.1511191932474688; // Replace with the correct pre-calculated value if needed
        assertEquals(expectedValue, result, epsilon, "regularizedGammaP should correctly calculate value with zero loop iterations");
    }

    @Test
    @DisplayName("regularizedGammaP with x < a + 1 and loop executes once")
    public void TC08() {
        // Given
        double a = 5.0;
        double x = 4.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // When
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // Then
        // Expected value is calculated based on the known results or mathematical computation
        double expectedValue = 0.01898815687615381; // Replace with the correct pre-calculated value if needed
        assertEquals(expectedValue, result, epsilon, "regularizedGammaP should correctly calculate value after one loop iteration");
    }

    @Test
    @DisplayName("regularizedGammaP with x < a + 1 and loop executes multiple times")
    public void TC09() {
        // Given
        double a = 5.0;
        double x = 4.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // When
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // Then
        // Expected value is calculated based on the known results or mathematical computation
        double expectedValue = 0.01898815687615381; // Replace with the correct pre-calculated value if needed
        assertEquals(expectedValue, result, epsilon, "regularizedGammaP should correctly calculate value after multiple loop iterations");
    }

    @Test
    @DisplayName("regularizedGammaP exceeding maxIterations")
    public void TC10() {
        // Given
        double a = 5.0;
        double x = 4.0;
        double epsilon = 1e-20;
        int maxIterations = 10;

        // When & Then
        assertThrows(MaxCountExceededException.class, () -> {
            Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        }, "regularizedGammaP should throw MaxCountExceededException when maxIterations is exceeded");
    }
}