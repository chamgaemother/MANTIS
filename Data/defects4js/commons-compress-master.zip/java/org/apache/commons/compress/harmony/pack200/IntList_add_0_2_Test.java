package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;

public class IntList_add_0_2_Test {

    /**
     * TC06: Add at end requiring growAtEnd
     */
    @Test
    @DisplayName("Add at end requiring growAtEnd")
    public void TC06_AddAtEndRequiringGrowAtEnd() throws Exception {
        // Initialize IntList with lastIndex=10, array length=10
        IntList list = new IntList();

        // Access and modify private fields using reflection
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 0);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 10);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = new int[10];
        arrayField.set(list, array);

        int location = 10;
        int object = 600;

        // Invoke the add method
        list.add(location, object);

        // Assertions
        int[] updatedArray = (int[]) arrayField.get(list);
        Assertions.assertTrue(updatedArray.length > 10, "Array should have grown at end.");
        int lastIndex = lastIndexField.getInt(list);
        Assertions.assertEquals(600, updatedArray[lastIndex - 1], "Added object should be at the end of the array.");
    }

    /**
     * TC07: Add at invalid negative location throws IndexOutOfBoundsException
     */
    @Test
    @DisplayName("Add at invalid negative location throws IndexOutOfBoundsException")
    public void TC07_AddAtInvalidNegativeLocationThrowsException() throws Exception {
        // Initialize IntList with any state
        IntList list = new IntList();

        // Access and modify private fields using reflection if needed
        // Here, default state is assumed

        int location = -1;
        int object = 700;

        // Invoke the add method and expect an exception
        Assertions.assertThrows(IndexOutOfBoundsException.class, () -> {
            list.add(location, object);
        }, "Adding at a negative location should throw IndexOutOfBoundsException.");
    }

    /**
     * TC08: Add at location greater than size throws IndexOutOfBoundsException
     */
    @Test
    @DisplayName("Add at location greater than size throws IndexOutOfBoundsException")
    public void TC08_AddAtLocationGreaterThanSizeThrowsException() throws Exception {
        // Initialize IntList with lastIndex=5, array length=10
        IntList list = new IntList();

        // Access and modify private fields using reflection
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 0);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 5);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = new int[10];
        arrayField.set(list, array);

        int location = 6;
        int object = 800;

        // Invoke the add method and expect an exception
        Assertions.assertThrows(IndexOutOfBoundsException.class, () -> {
            list.add(location, object);
        }, "Adding at a location greater than size should throw IndexOutOfBoundsException.");
    }

    /**
     * TC09: Add to empty IntList at location 0
     */
    @Test
    @DisplayName("Add to empty IntList at location 0")
    public void TC09_AddToEmptyIntListAtLocation0() throws Exception {
        // Initialize empty IntList with firstIndex=0, lastIndex=0, array length=10
        IntList list = new IntList();

        // Access and modify private fields using reflection
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 0);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 0);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = new int[10];
        arrayField.set(list, array);

        int location = 0;
        int object = 900;

        // Invoke the add method
        list.add(location, object);

        // Assertions
        int firstIndex = firstIndexField.getInt(list);
        int lastIndex = lastIndexField.getInt(list);
        int[] updatedArray = (int[]) arrayField.get(list);

        Assertions.assertEquals(0, firstIndex, "First index should remain 0.");
        Assertions.assertEquals(1, lastIndex, "Last index should be incremented to 1.");
        Assertions.assertEquals(900, updatedArray[0], "Object should be added at index 0.");
    }

    /**
     * TC10: Add at middle location when location < size/2 and firstIndex > 0
     */
    @Test
    @DisplayName("Add at middle location when location < size/2 and firstIndex > 0")
    public void TC10_AddAtMiddleLocationWithShiftFront() throws Exception {
        // Initialize IntList with firstIndex=2, lastIndex=8, array length=10
        IntList list = new IntList();

        // Access and modify private fields using reflection
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 2);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 8);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] array = new int[10];
        // Initialize some values in the array if necessary
        arrayField.set(list, array);

        int location = 2;
        int object = 1000;

        // Invoke the add method
        list.add(location, object);

        // Assertions
        int[] updatedArray = (int[]) arrayField.get(list);
        int firstIndex = firstIndexField.getInt(list);

        Assertions.assertEquals(1, firstIndex, "First index should have been decremented by 1.");
        Assertions.assertEquals(1000, updatedArray[location + firstIndex], "Object should be added at the correct middle location.");
    }
}