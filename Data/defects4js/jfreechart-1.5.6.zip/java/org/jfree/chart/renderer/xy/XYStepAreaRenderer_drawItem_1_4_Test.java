// package org.jfree.chart.renderer.xy;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// import org.jfree.data.xy.XYDataset;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.awt.BasicStroke;
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Shape;
// import java.awt.Stroke;
// import java.awt.geom.Ellipse2D;
// import java.awt.geom.Rectangle2D;
// import java.lang.reflect.Field;
// import java.lang.reflect.Method;
// import java.util.Optional;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.labels.XYToolTipGenerator;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.XYItemRendererState;
// import org.jfree.chart.renderer.xy.XYStepAreaRenderer;
// import org.jfree.chart.urls.XYURLGenerator;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// public class XYStepAreaRenderer_drawItem_1_4_Test {
// 
//     @Test
//     @DisplayName("drawItem with EntityCollection as null")
//     void TC16_drawItem_with_EntityCollection_null() throws Exception {
//         // Arrange
//         XYStepAreaRenderer renderer = new XYStepAreaRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         when(state.getEntityCollection()).thenReturn(null);
// 
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getItemCount(anyInt())).thenReturn(10);
//         when(dataset.getYValue(anyInt(), anyInt())).thenReturn(180.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(state).getEntityCollection();
//         // No entities should be added, so no further interactions
//         verifyNoMoreInteractions(state);
//     }
// 
//     @Test
//     @DisplayName("drawItem with EntityCollection present and shapes visible")
//     void TC17_drawItem_with_EntityCollection_present_and_shapes_visible() throws Exception {
//         // Arrange
//         XYStepAreaRenderer renderer = new XYStepAreaRenderer();
//         renderer.setShapesVisible(true);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
// 
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getItemCount(anyInt())).thenReturn(10);
//         when(dataset.getYValue(anyInt(), anyInt())).thenReturn(200.0);
// 
//         Shape shape = new Ellipse2D.Double();
//         Method getItemShapeMethod = XYStepAreaRenderer.class.getDeclaredMethod("getItemShape", int.class, int.class);
//         getItemShapeMethod.setAccessible(true);
//         when(getItemShapeMethod.invoke(renderer, series, item)).thenReturn(shape);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(state).getEntityCollection();
//         verify(entities).addEntity(any(Shape.class), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }
// 
//     @Test
//     @DisplayName("drawItem with last item and y1 not NaN")
//     void TC18_drawItem_with_last_item_and_y1_not_NaN() throws Exception {
//         // Arrange
//         XYStepAreaRenderer renderer = new XYStepAreaRenderer();
//         renderer.setOutline(true);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
// 
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getOutlineStroke()).thenReturn(new BasicStroke(1.5f));
//         when(plot.getOutlinePaint()).thenReturn(Color.BLUE);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(550.0);
// 
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getItemCount(series)).thenReturn(5);
//         when(dataset.getYValue(series, 4)).thenReturn(250.0);
// 
//         // Access and set pArea via reflection
//         Field pAreaField = XYStepAreaRenderer.class.getDeclaredField("pArea");
//         pAreaField.setAccessible(true);
//         Polygon pArea = new Polygon();
//         pAreaField.set(renderer, pArea);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, 4, crosshairState, pass);
// 
//         // Assert
//         verify(g2).fill(pArea);
//         verify(g2).setStroke(plot.getOutlineStroke());
//         verify(g2).setPaint(plot.getOutlinePaint());
//         verify(g2).draw(pArea);
// 
//         // Verify that pArea is reset to null
//         assertNull(pAreaField.get(renderer));
//     }
// 
//     @Test
//     @DisplayName("drawItem with last item and y1 is NaN")
//     void TC19_drawItem_with_last_item_and_y1_is_NaN() throws Exception {
//         // Arrange
//         XYStepAreaRenderer renderer = new XYStepAreaRenderer();
//         renderer.setOutline(true);
//         renderer.setRangeBase(0.0);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
// 
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getOutlineStroke()).thenReturn(new BasicStroke(1.5f));
//         when(plot.getOutlinePaint()).thenReturn(Color.RED);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(eq(0.0), eq(dataArea), eq(PlotOrientation.VERTICAL))).thenReturn(600.0);
// 
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getItemCount(series)).thenReturn(5);
//         when(dataset.getYValue(series, 4)).thenReturn(Double.NaN);
// 
//         // Access and set pArea via reflection
//         Field pAreaField = XYStepAreaRenderer.class.getDeclaredField("pArea");
//         pAreaField.setAccessible(true);
//         Polygon pArea = new Polygon();
//         pAreaField.set(renderer, pArea);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, 4, crosshairState, pass);
// 
//         // Assert
//         verify(g2).fill(pArea);
//         verify(g2).setStroke(plot.getOutlineStroke());
//         verify(g2).setPaint(plot.getOutlinePaint());
//         verify(g2).draw(pArea);
// 
//         // Verify that pArea is reset to null
//         assertNull(pAreaField.get(renderer));
//     }
// 
//     @Test
//     @DisplayName("drawItem with stepPoint set beyond valid range")
//     void TC20_drawItem_with_invalid_stepPoint_value() throws Exception {
//         // Arrange
//         XYStepAreaRenderer renderer = new XYStepAreaRenderer();
// 
//         // Act & Assert
//         assertThrows(IllegalArgumentException.class, () -> renderer.setStepPoint(-0.5));
//     }
// }