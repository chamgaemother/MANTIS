package org.apache.commons.math3.special;

import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BesselJTest {

    @Test
    void testRjBesl_XLessThanRTNSIG_AlphaZero_NbOne() {
        double x = 1.0e-5;
        double alpha = 0.0;
        int nb = 1;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(1, result.getnVals());
        assertEquals(1, result.getVals().length);
        assertTrue(result.getVals()[0] > 0);
    }

    @Test
    void testRjBesl_XLessThanRTNSIG_AlphaNonZero_NbMultiple() {
        double x = 1.0e-5;
        double alpha = 0.5;
        int nb = 3;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(3, result.getnVals());
        assertEquals(3, result.getVals().length);
        assertTrue(result.getVals()[0] > 0);
        assertTrue(result.getVals()[1] > 0);
        assertTrue(result.getVals()[2] > 0);
    }

    @Test
    void testRjBesl_XZero_AlphaZero_NbOne() {
        double x = 0.0;
        double alpha = 0.0;
        int nb = 1;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(1, result.getnVals());
        assertEquals(1, result.getVals().length);
        assertEquals(1.0, result.getVals()[0], 1e-10);
    }

    @Test
    void testRjBesl_XGreaterThanXMax() {
        double x = 1.0e5;
        double alpha = 0.5;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(-1, result.getnVals());
        assertEquals(2, result.getVals().length);
        assertEquals(0.0, result.getVals()[0], 1e-10);
        assertEquals(0.0, result.getVals()[1], 1e-10);
    }

    @Test
    void testRjBesl_XNegative() {
        double x = -1.0;
        double alpha = 0.5;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(-1, result.getnVals());
        assertEquals(2, result.getVals().length);
        assertEquals(0.0, result.getVals()[0], 1e-10);
        assertEquals(0.0, result.getVals()[1], 1e-10);
    }

    @Test
    void testRjBesl_AlphaNegative() {
        double x = 1.0;
        double alpha = -0.5;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(-1, result.getnVals());
        assertEquals(2, result.getVals().length);
        assertEquals(0.0, result.getVals()[0], 1e-10);
        assertEquals(0.0, result.getVals()[1], 1e-10);
    }

    @Test
    void testRjBesl_AlphaOne() {
        double x = 1.0;
        double alpha = 1.0;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(-1, result.getnVals());
        assertEquals(2, result.getVals().length);
        assertEquals(0.0, result.getVals()[0], 1e-10);
        assertEquals(0.0, result.getVals()[1], 1e-10);
    }

    @Test
    void testRjBesl_XGreaterThan25_NbLessOrEqualMagxPlus1() {
        double x = 30.0;
        double alpha = 0.5;
        int nb = 3;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertTrue(result.getnVals() >= nb);
        assertEquals(nb, result.getVals().length);
        for (double val : result.getVals()) {
            assertNotEquals(0.0, val);
        }
    }

    @Test
    void testRjBesl_XGreaterThan25_NbGreaterThanMagxPlus1() {
        double x = 30.0;
        double alpha = 0.5;
        int nb = 40;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertTrue(result.getnVals() <= nb);
        assertEquals(nb, result.getVals().length);
    }

    @Test
    void testRjBesl_NormalX_AlphaHalf_NbFive() {
        double x = 10.0;
        double alpha = 0.5;
        int nb = 5;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertTrue(result.getnVals() >= nb);
        assertEquals(nb, result.getVals().length);
        for (double val : result.getVals()) {
            assertNotEquals(0.0, val);
        }
    }

    @Test
    void testRjBesl_ExtremelySmallX() {
        double x = 1.0e-300;
        double alpha = 0.3;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(nb, result.getnVals());
        assertTrue(result.getVals()[0] > 0);
        assertTrue(result.getVals()[1] > 0);
    }

    @Test
    void testRjBesl_ExtremelyLargeX() {
        double x = 1.0e4;
        double alpha = 0.7;
        int nb = 1;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertTrue(result.getnVals() >= nb);
        assertEquals(nb, result.getVals().length);
        assertNotEquals(0.0, result.getVals()[0]);
    }

    @Test
    void testRjBesl_NbZero() {
        double x = 5.0;
        double alpha = 0.5;
        int nb = 0;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(-1, result.getnVals());
        assertEquals(0, result.getVals().length);
    }

    @Test
    void testRjBesl_NbNegative() {
        double x = 5.0;
        double alpha = 0.5;
        int nb = -3;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(-1, result.getnVals());
        assertEquals(0, result.getVals().length);
    }

    @Test
    void testRjBesl_AlphaBoundaryZero() {
        double x = 2.0;
        double alpha = 0.0;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(nb, result.getnVals());
        assertEquals(2, result.getVals().length);
        assertNotEquals(0.0, result.getVals()[0]);
        assertNotEquals(0.0, result.getVals()[1]);
    }

    @Test
    void testRjBesl_AlphaBoundaryOneMinusEpsilon() {
        double x = 2.0;
        double alpha = 0.999999999;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(nb, result.getnVals());
        assertEquals(2, result.getVals().length);
        assertNotEquals(0.0, result.getVals()[0]);
        assertNotEquals(0.0, result.getVals()[1]);
    }

    @Test
    void testRjBesl_XExactlyRTNSIG() {
        double x = 1.0e-4;
        double alpha = 0.5;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        // Depending on implementation, it may choose small x or not
        assertTrue(result.getnVals() >= 1);
        assertEquals(nb, result.getVals().length);
    }

    @Test
    void testRjBesl_XExactly25() {
        double x = 25.0;
        double alpha = 0.5;
        int nb = 3;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertTrue(result.getnVals() >= nb);
        assertEquals(nb, result.getVals().length);
    }

    @Test
    void testRjBesl_NbEquals1() {
        double x = 5.0;
        double alpha = 0.5;
        int nb = 1;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(1, result.getnVals());
        assertEquals(1, result.getVals().length);
        assertNotEquals(0.0, result.getVals()[0]);
    }

    @Test
    void testRjBesl_NbGreaterThan1_XZero() {
        double x = 0.0;
        double alpha = 0.5;
        int nb = 3;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(nb, result.getnVals());
        assertEquals(3, result.getVals().length);
        assertEquals(0.0, result.getVals()[1], 1e-10);
        assertEquals(0.0, result.getVals()[2], 1e-10);
    }
}