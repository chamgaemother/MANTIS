package org.apache.commons.math3.analysis.interpolation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.analysis.interpolation.TricubicSplineInterpolator;
import org.apache.commons.math3.analysis.interpolation.TricubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;

public class TricubicSplineInterpolator_interpolate_1_1_Test {
    
    @Test
    @DisplayName("Interpolate with yval array of length 1 and zval array of length greater than 1 to test single iteration in y-loop")
    public void TC23() throws Exception {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {
            { {1.0, 2.0} },
            { {3.0, 4.0} },
            { {5.0, 6.0} }
        };
        
        // WHEN
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);
        
        // THEN
        Assertions.assertNotNull(result, "The interpolating function should not be null.");
    }
    
    @Test
    @DisplayName("Interpolate with fval containing maximum and minimum double values to test numerical stability")
    public void TC24() throws Exception {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {
            { {Double.MAX_VALUE, Double.MIN_VALUE} },
            { {Double.MIN_VALUE, Double.MAX_VALUE} }
        };
        
        // WHEN
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);
        
        // THEN
        Assertions.assertNotNull(result, "The interpolating function should handle extreme double values without returning null.");
    }
    
    @Test
    @DisplayName("Interpolate with zval array of length 1 and yval array of length greater than 1 to test single iteration in z-loop")
    public void TC25() throws Exception {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[] zval = {1.0};
        double[][][] fval = {
            { {1.0}, {2.0}, {3.0} },
            { {4.0}, {5.0}, {6.0} }
        };
        
        // WHEN
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);
        
        // THEN
        Assertions.assertNotNull(result, "The interpolating function should not be null.");
    }
    
    @Test
    @DisplayName("Interpolate with yval and zval arrays of differing lengths to ensure DimensionMismatchException is thrown")
    public void TC26() {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {
            { {1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0} },
            { {7.0, 8.0}, {9.0, 10.0}, {11.0, 12.0} }
        };
        
        // WHEN & THEN
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        Assertions.assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        }, "Expected DimensionMismatchException due to yval and zval length mismatch.");
    }
    
    @Test
    @DisplayName("Interpolate with extremely large fval array dimensions to test handling of maximum capacity")
    public void TC27() throws Exception {
        // GIVEN
        int size = 500;
        double[] xval = generateLargeArray(size);
        double[] yval = generateLargeArray(size);
        double[] zval = generateLargeArray(size);
        double[][][] fval = generateLarge3DArray(size, size, size);
        
        // WHEN
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);
        
        // THEN
        Assertions.assertNotNull(result, "The interpolating function should handle extremely large fval arrays without returning null.");
    }
    
    // Helper methods to generate large arrays
    private double[] generateLargeArray(int size) {
        double[] array = new double[size];
        for (int i = 0; i < size; i++) {
            array[i] = i + 1.0;
        }
        return array;
    }
    
    private double[][][] generateLarge3DArray(int x, int y, int z) {
        double[][][] array = new double[x][y][z];
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                for (int k = 0; k < z; k++) {
                    array[i][j][k] = i + j + k + 1.0;
                }
            }
        }
        return array;
    }
}