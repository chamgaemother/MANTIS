package org.jfree.chart;

import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.event.OverlayChangeEvent;
import org.jfree.chart.event.OverlayChangeListener;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseDragged_0_3_Test {

    private ChartPanel chartPanel;
    private Graphics2D g2;

    @BeforeEach
    public void setUp() {
        // Initialize mocks for each test to ensure isolation
        chartPanel = spy(new ChartPanel(null));
        g2 = mock(Graphics2D.class);
        when(chartPanel.getGraphics()).thenReturn(g2);
    }

//     @Test
//     @DisplayName("mouseDragged zooming with domain zoom only")
//     public void TC11_mouseDragged_zooming_with_domain_zoom_only() throws Exception {
        // Arrange
// 
        // Set zoomPoint
//         Point2D zoomPoint = new Point2D.Double(300, 300);
//         setPrivateField(chartPanel, "zoomPoint", zoomPoint);
// 
        // Set useBuffer to false
//         setPrivateField(chartPanel, "useBuffer", false);
// 
        // Set orientation to HORIZONTAL
//         setPrivateField(chartPanel, "orientation", PlotOrientation.HORIZONTAL);
// 
        // Set domainZoomable to true
//         setPrivateField(chartPanel, "domainZoomable", true);
// 
        // Set rangeZoomable to false
//         setPrivateField(chartPanel, "rangeZoomable", false);
// 
        // Mock getScreenDataArea
//         when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(new Rectangle2D.Double(0, 0, 400, 400));
// 
        // Mock MouseEvent
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getX()).thenReturn(350);
//         when(e.getY()).thenReturn(400);
// 
        // Act
//         chartPanel.mouseDragged(e);
// 
        // Assert
        // Verify that drawZoomRectangle is called with XOR mode
//         verify(chartPanel, times(1)).drawZoomRectangle(g2, true);
// 
        // Verify that dispose is called on Graphics2D
//         verify(g2, times(1)).dispose();
//     }

//     @Test
//     @DisplayName("mouseDragged zooming with range zoom only")
//     public void TC12_mouseDragged_zooming_with_range_zoom_only() throws Exception {
        // Arrange
// 
        // Set zoomPoint
//         Point2D zoomPoint = new Point2D.Double(400, 400);
//         setPrivateField(chartPanel, "zoomPoint", zoomPoint);
// 
        // Set useBuffer to false
//         setPrivateField(chartPanel, "useBuffer", false);
// 
        // Set orientation to HORIZONTAL
//         setPrivateField(chartPanel, "orientation", PlotOrientation.HORIZONTAL);
// 
        // Set domainZoomable to false
//         setPrivateField(chartPanel, "domainZoomable", false);
// 
        // Set rangeZoomable to true
//         setPrivateField(chartPanel, "rangeZoomable", true);
// 
        // Mock getScreenDataArea
//         when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(new Rectangle2D.Double(0, 0, 500, 500));
// 
        // Mock MouseEvent
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getX()).thenReturn(450);
//         when(e.getY()).thenReturn(450);
// 
        // Act
//         chartPanel.mouseDragged(e);
// 
        // Assert
        // Verify that drawZoomRectangle is called with XOR mode
//         verify(chartPanel, times(1)).drawZoomRectangle(g2, true);
// 
        // Verify that dispose is called on Graphics2D
//         verify(g2, times(1)).dispose();
//     }

    /**
     * Utility method to set private fields via reflection.
     *
     * @param target    The object whose field should be modified.
     * @param fieldName The name of the field to modify.
     * @param value     The value to set.
     * @throws Exception If reflection fails.
     */
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = ChartPanel.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}