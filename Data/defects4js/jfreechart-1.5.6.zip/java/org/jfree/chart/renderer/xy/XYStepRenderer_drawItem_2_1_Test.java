package org.jfree.chart.renderer.xy;
import org.jfree.chart.ui.RectangleEdge;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYStepRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("drawItem with stepPoint set to 0.0 and orientation HORIZONTAL, ensuring step is drawn at the first data point")
    public void TC27() throws Exception {
        // GIVEN
        XYStepRenderer renderer = new XYStepRenderer();
        renderer.setStepPoint(0.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(plot.indexOf(dataset)).thenReturn(0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // THEN
        // Verify that steps are drawn at the first data point based on stepPoint=0.0
        verify(g2, times(1)).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("drawItem with stepPoint set to 1.0 and orientation VERTICAL, ensuring step is drawn at the second data point")
    public void TC28() throws Exception {
        // GIVEN
        XYStepRenderer renderer = new XYStepRenderer();
        renderer.setStepPoint(1.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(250.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);
        when(dataset.getXValue(0, 0)).thenReturn(3.0);
        when(dataset.getYValue(0, 0)).thenReturn(8.0);
        when(plot.indexOf(dataset)).thenReturn(0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // THEN
        // Verify that steps are drawn at the second data point based on stepPoint=1.0
        verify(g2, times(1)).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("drawItem with pass=1, label visible, orientation VERTICAL, Y1 < 0.0")
    public void TC29() throws Exception {
        // GIVEN
        XYStepRenderer renderer = new XYStepRenderer();

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(renderer.isItemLabelVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(4.0);
        when(dataset.getYValue(0, 1)).thenReturn(-5.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(-5.0, dataArea, RectangleEdge.LEFT)).thenReturn(-50.0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 1);

        // THEN
        // Assert true to verify that no exceptions occurred
        assertTrue(true);
    }

    @Test
    @DisplayName("drawItem with pass=1, label visible, orientation HORIZONTAL, Y1 < 0.0")
    public void TC30() throws Exception {
        // GIVEN
        XYStepRenderer renderer = new XYStepRenderer();

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(renderer.isItemLabelVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getXValue(0, 1)).thenReturn(6.0);
        when(dataset.getYValue(0, 1)).thenReturn(-10.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(6.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(-10.0, dataArea, RectangleEdge.LEFT)).thenReturn(-100.0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 1);

        // THEN
        // Assert true to verify that no exceptions occurred
        assertTrue(true);
    }

    @Test
    @DisplayName("drawItem with pass=1, label visible, orientation VERTICAL, Y1 >= 0.0")
    public void TC31() throws Exception {
        // GIVEN
        XYStepRenderer renderer = new XYStepRenderer();

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(renderer.isItemLabelVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(7.0);
        when(dataset.getYValue(0, 1)).thenReturn(15.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(7.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(350.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(400.0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 1);

        // THEN
        // Assert true to verify that no exceptions occurred
        assertTrue(true);
    }
}