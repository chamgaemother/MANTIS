package org.jfree.chart.title;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// 
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.NumberAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.renderer.PaintScale;
// import org.jfree.chart.renderer.StandardPaintScale;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// /**
//  * JUnit 5 test class for PaintScaleLegend#draw method.
//  */
public class PaintScaleLegend_draw_1_1_Test {
// 
//     /**
//      * Test TC17: draw method with position LEFT and stripOutlineVisible false.
//      * Verifies that no strip outlines are drawn for the LEFT edge.
//      */
//     @Test
//     @DisplayName("draw method with isTopOrBottom false and axis location LEFT, stripOutlineVisible false")
//     public void testDraw_PositionLeft_StripOutlineFalse_TC17() throws Exception {
        // Arrange
//         PaintScale scale = new StandardPaintScale(0.0, 100.0, Color.WHITE);
//         ValueAxis axis = new NumberAxis();
//         PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
//         legend.setAxisLocation(org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT);
//         legend.setStripOutlineVisible(false);
//         legend.setBackgroundPaint(null);
// 
//         Graphics2D graphics = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 100);
//         Object param = null;
// 
        // Act
//         Object result = legend.draw(graphics, area, param);
// 
        // Assert
//         assertNull(result, "The draw method should return null.");
// 
        // Verify that fill is called but outline is not drawn
//         verify(graphics, atLeastOnce()).fill(any(Rectangle2D.class));
//         verify(graphics, never()).draw(any(Rectangle2D.class));
//     }
// 
//     /**
//      * Test TC18: draw method with position RIGHT and stripOutlineVisible true.
//      * Verifies that strip outlines are drawn for the RIGHT edge.
//      */
//     @Test
//     @DisplayName("draw method with isTopOrBottom false and axis location RIGHT, stripOutlineVisible true")
//     public void testDraw_PositionRight_StripOutlineTrue_TC18() throws Exception {
        // Arrange
//         PaintScale scale = new StandardPaintScale(0.0, 100.0, Color.WHITE);
//         ValueAxis axis = new NumberAxis();
//         PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
//         legend.setAxisLocation(org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT);
//         legend.setStripOutlineVisible(true);
//         legend.setBackgroundPaint(Color.YELLOW);
// 
//         Graphics2D graphics = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 100);
//         Object param = null;
// 
        // Act
//         Object result = legend.draw(graphics, area, param);
// 
        // Assert
//         assertNull(result, "The draw method should return null.");
// 
        // Verify that fill and outline are called
//         verify(graphics, atLeastOnce()).fill(any(Rectangle2D.class));
//         verify(graphics, atLeastOnce()).draw(any(Rectangle2D.class));
//     }
// }
}