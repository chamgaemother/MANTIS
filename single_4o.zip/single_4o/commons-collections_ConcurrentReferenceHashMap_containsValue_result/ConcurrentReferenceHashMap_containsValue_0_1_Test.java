package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;
import java.util.Objects;

public class ConcurrentReferenceHashMap_containsValue_0_1_Test {

    @Test
    @DisplayName("containsValue(null) throws NullPointerException for null input")
    public void testContainsValueThrowsNullPointerExceptionForNullInput() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        
        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            map.containsValue(null);
        });
    }

    @Test
    @DisplayName("containsValue returns true when value is present in one of the segments without locking")
    public void testContainsValueReturnsTrueWhenValuePresentWithoutLocking() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = new Object();
        // Assuming we have a way to manually insert a value into the map's internal structure for testing
        // Since the segments and access to them are conceptual, this segment may vary based on test setup
        map.put("key1", value);
        
        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("containsValue returns false when no segment contains the value and no modifications happen")
    public void testContainsValueReturnsFalseWhenNoSegmentContains() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = new Object();

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("containsValue retries and returns true when modifications happen during initial checks")
    public void testContainsValueRetriesAndReturnsTrueOnConcurrentModification() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = new Object();
        // In a real scenario, concurrent modification may require a custom setup 
        Thread modifyThread = new Thread(() -> {
            try { Thread.sleep(100); } catch (InterruptedException e) { }
            map.put("key2", value);
        });
        modifyThread.start();

        // WHEN
        boolean result = map.containsValue(value); // This should retry and eventually find the value

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("containsValue locks and returns true when value is found only after locking all segments")
    public void testContainsValueLocksAndReturnsTrueAfterLocking() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object valueAddedAfter = new Object();
        // Simulate the addition of value after some operations
        Thread addValueThread = new Thread(() -> {
            try { Thread.sleep(200); } catch (InterruptedException e) { }
            map.put("key3", valueAddedAfter);
        });
        addValueThread.start();

        // WHEN
        boolean result = map.containsValue(valueAddedAfter); // This operation should lock and then find the value

        // THEN
        assertTrue(result);
    }
}