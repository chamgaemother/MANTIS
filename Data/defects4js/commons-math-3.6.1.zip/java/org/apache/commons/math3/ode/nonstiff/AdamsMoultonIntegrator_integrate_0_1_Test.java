package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AdamsMoultonIntegrator_integrate_0_1_Test {

    @Test
    @DisplayName("Integrate with target time less than or equal to current time, expecting no forward integration")
    void TC01() throws Exception {
        // GIVEN
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(5, 0.1, 10.0, 1.0e-10, 1.0e-10);
        FirstOrderDifferentialEquations equationsDefinition = new FirstOrderDifferentialEquations() {
            @Override
            public int getDimension() {
                return 1;
            }

            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                yDot[0] = 0;
            }
        };

        ExpandableStatefulODE equations = new ExpandableStatefulODE(equationsDefinition);
        equations.setTime(10.0);
        equations.setCompleteState(new double[] {1.0});
        double targetTime = 5.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        assertEquals(10.0, equations.getTime(), "Integration should not advance time");
        assertArrayEquals(new double[] {1.0}, equations.getCompleteState(), "State should remain unchanged");
    }

    @Test
    @DisplayName("Integrate with target time greater than current time, expecting forward integration")
    void TC02() throws Exception {
        // GIVEN
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(5, 0.1, 10.0, 1.0e-10, 1.0e-10);
        FirstOrderDifferentialEquations equationsDefinition = new FirstOrderDifferentialEquations() {
            @Override
            public int getDimension() {
                return 1;
            }

            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                yDot[0] = 1.0;
            }
        };

        ExpandableStatefulODE equations = new ExpandableStatefulODE(equationsDefinition);
        equations.setTime(5.0);
        equations.setCompleteState(new double[] {1.0});
        double targetTime = 10.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        assertEquals(10.0, equations.getTime(), "Integration should advance time to target");
        assertArrayEquals(new double[] {6.0}, equations.getCompleteState(), "State should be updated after integration");
    }

    @Test
    @DisplayName("Integration step size adjustment due to high error, expecting step rejection and reduction")
    void TC03() throws Exception {
        // GIVEN
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(5, 0.01, 1.0, 1.0e-5, 1.0e-5);
        // Adjusted tolerances to simulate high error
        FirstOrderDifferentialEquations equationsDefinition = new FirstOrderDifferentialEquations() {
            @Override
            public int getDimension() {
                return 1;
            }

            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                yDot[0] = 100.0; // Simulate high derivative
            }
        };

        ExpandableStatefulODE equations = new ExpandableStatefulODE(equationsDefinition);
        equations.setTime(5.0);
        equations.setCompleteState(new double[] {1.0});
        double targetTime = 10.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        assertEquals(10.0, equations.getTime(), "Integration should complete to target time after step size adjustments");
        assertTrue(equations.getCompleteState()[0] > 1.0, "State should reflect step size reductions and updates");
    }

    @Test
    @DisplayName("Integration completes in a single step without errors")
    void TC04() throws Exception {
        // GIVEN
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(10, 0.1, 5.0, 1.0e-10, 1.0e-10);
        FirstOrderDifferentialEquations equationsDefinition = new FirstOrderDifferentialEquations() {
            @Override
            public int getDimension() {
                return 1;
            }

            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                yDot[0] = 1.0;
            }
        };

        ExpandableStatefulODE equations = new ExpandableStatefulODE(equationsDefinition);
        equations.setTime(5.0);
        equations.setCompleteState(new double[] {1.0});
        double targetTime = 6.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        assertEquals(6.0, equations.getTime(), "Integration should complete in one step to target time");
        assertArrayEquals(new double[] {2.0}, equations.getCompleteState(), "State should be updated correctly after single step integration");
    }

    @Test
    @DisplayName("Integration with step size filtered to reach target exactly")
    void TC05() throws Exception {
        // GIVEN
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(3, 0.1, 5.0, 1.0e-10, 1.0e-10);
        FirstOrderDifferentialEquations equationsDefinition = new FirstOrderDifferentialEquations() {
            @Override
            public int getDimension() {
                return 1;
            }

            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                yDot[0] = 2.0;
            }
        };

        ExpandableStatefulODE equations = new ExpandableStatefulODE(equationsDefinition);
        equations.setTime(5.0);
        equations.setCompleteState(new double[] {1.0});
        double targetTime = 10.0;

        // WHEN
        integrator.integrate(equations, targetTime);

        // THEN
        assertEquals(10.0, equations.getTime(), "Integration should reach target time exactly");
        assertArrayEquals(new double[] {11.0}, equations.getCompleteState(), "State should reflect exact step size adjustment to reach target");
    }
}