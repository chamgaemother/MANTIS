package org.jfree.chart.labels;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Generated JUnit 5 test class for ItemLabelAnchor.isInternal()
 */
public class ItemLabelAnchor_isInternal_1_2_Test {

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE7")
    public void TC20() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE7;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE8")
    public void TC21() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE8;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE9")
    public void TC22() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE9;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE10")
    public void TC23() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE10;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE11")
    public void TC24() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE11;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }
}