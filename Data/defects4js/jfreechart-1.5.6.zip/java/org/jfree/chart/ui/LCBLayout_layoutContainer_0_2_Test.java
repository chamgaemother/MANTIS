package org.jfree.chart.ui;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.*;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class LCBLayout_layoutContainer_0_2_Test {

    @Test
    @DisplayName("TC06: layoutContainer where some components have larger preferred heights")
    public void TC06_layoutContainer_VariableHeight() throws Exception {
        // Initialize LCBLayout instance with appropriate number of maxrows
        LCBLayout layout = new LCBLayout(1);

        // Create parent container
        Container parent = new Container();
        parent.setLayout(layout);

        // Add 3 components with varying preferred heights
        Button comp1 = new Button();
        comp1.setPreferredSize(new Dimension(100, 50));
        Button comp2 = new Button();
        comp2.setPreferredSize(new Dimension(100, 70)); // Larger height
        Button comp3 = new Button();
        comp3.setPreferredSize(new Dimension(100, 60));
        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);

        // Invoke layoutContainer
        layout.layoutContainer(parent);

        // Access rowHeight via reflection
        Field rowHeightField = LCBLayout.class.getDeclaredField("rowHeight");
        rowHeightField.setAccessible(true);
        int[] rowHeight = (int[]) rowHeightField.get(layout);

        // Verify rowHeight is updated to accommodate larger component heights
        assertTrue(rowHeight[0] >= 70, "Row height should be updated to at least 70");
    }

    @Test
    @DisplayName("TC07: layoutContainer with maximum allowed components")
    public void TC07_layoutContainer_MaximumComponents() throws Exception {
        // Initialize LCBLayout instance with appropriate number of maxrows
        LCBLayout layout = new LCBLayout(3);

        // Create parent container
        Container parent = new Container();
        parent.setLayout(layout);

        // Add 9 components with preferred sizes
        for (int i = 0; i < 9; i++) {
            Button comp = new Button();
            comp.setPreferredSize(new Dimension(100, 50));
            parent.add(comp);
        }

        // Invoke layoutContainer
        layout.layoutContainer(parent);

        // Verify all components are positioned and sized within the parent container
        for (Component comp : parent.getComponents()) {
            Rectangle bounds = comp.getBounds();
            assertTrue(bounds.x + bounds.width <= parent.getWidth(), "Component exceeds parent width");
            assertTrue(bounds.y + bounds.height <= parent.getHeight(), "Component exceeds parent height");
        }
    }

    @Test
    @DisplayName("TC08: layoutContainer with parent container having excessive insets")
    public void TC08_layoutContainer_LargeInsets() throws Exception {
        // Initialize LCBLayout instance with appropriate number of maxrows
        LCBLayout layout = new LCBLayout(1);

        // Create parent container with large insets
        Container parent = new Container() {
            @Override
            public Insets getInsets() {
                return new Insets(50, 50, 50, 50); // Large insets
            }
        };
        parent.setLayout(layout);

        // Add 3 components with preferred sizes
        for (int i = 0; i < 3; i++) {
            Button comp = new Button();
            comp.setPreferredSize(new Dimension(100, 50));
            parent.add(comp);
        }

        // Set parent size
        parent.setSize(500, 500);

        // Invoke layoutContainer
        layout.layoutContainer(parent);

        // Verify components are within visible area accounting for insets
        for (Component comp : parent.getComponents()) {
            Rectangle bounds = comp.getBounds();
            Insets insets = parent.getInsets();
            assertTrue(bounds.x >= insets.left, "Component is within left inset");
            assertTrue(bounds.y >= insets.top, "Component is within top inset");
            assertTrue(bounds.x + bounds.width <= parent.getWidth() - insets.right, "Component is within right inset");
            assertTrue(bounds.y + bounds.height <= parent.getHeight() - insets.bottom, "Component is within bottom inset");
        }
    }

    @Test
    @DisplayName("TC09: layoutContainer with parent container width less than total column widths")
    public void TC09_layoutContainer_WidthAdjustment() throws Exception {
        // Initialize LCBLayout instance with appropriate number of maxrows
        LCBLayout layout = new LCBLayout(1);

        // Create parent container with reduced width
        Container parent = new Container();
        parent.setLayout(layout);
        parent.setSize(250, 300); // Width less than sum of colWidth[0] + colWidth[1] + colWidth[2]

        // Add 3 components with preferred sizes
        for (int i = 0; i < 3; i++) {
            Button comp = new Button();
            comp.setPreferredSize(new Dimension(80, 50));
            parent.add(comp);
        }

        // Invoke layoutContainer
        layout.layoutContainer(parent);

        // Access colWidth via reflection
        Field colWidthField = LCBLayout.class.getDeclaredField("colWidth");
        colWidthField.setAccessible(true);
        int[] colWidth = (int[]) colWidthField.get(layout);

        // Calculate totalWidth before adjustment
        int totalWidth = colWidth[0] + colWidth[1] + colWidth[2];

        // Calculate available width
        Insets insets = parent.getInsets();
        int available = parent.getWidth() - insets.left - insets.right - getFieldValue(layout, "labelGap") - getFieldValue(layout, "buttonGap");

        // Verify colWidth[1] is adjusted correctly
        assertEquals(colWidth[1], colWidth[1] + (available - totalWidth), "Second column width should be adjusted to fit within parent width");
    }

    @Test
    @DisplayName("TC10: layoutContainer handling exception when parent is null")
    public void TC10_layoutContainer_NullParent() {
        // Initialize LCBLayout instance with appropriate number of maxrows
        LCBLayout layout = new LCBLayout(1);

        // Invoke layoutContainer with null parent and expect NullPointerException
        assertThrows(NullPointerException.class, () -> {
            layout.layoutContainer(null);
        }, "Expected layoutContainer to throw NullPointerException when parent is null");
    }
    
    // Helper method to access integer fields via reflection
    private int getFieldValue(LCBLayout layout, String fieldName) throws Exception {
        Field field = LCBLayout.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getInt(layout);
    }
}