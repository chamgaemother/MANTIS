package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.codec.digest.Md5Crypt;
import static org.junit.jupiter.api.Assertions.*;

public class Md5Crypt_md5Crypt_0_1_Test {

    @Test
    @DisplayName("md5Crypt with null salt generates a random salt")
    void testMd5CryptWithNullSaltGeneratesRandomSalt() {
        // GIVEN a valid byte array for keyBytes
        byte[] keyBytes = "testPassword".getBytes();

        // WHEN md5Crypt is called with null salt
        String result = Md5Crypt.md5Crypt(keyBytes, null, "$1$");

        // THEN a valid md5 hash string is returned with a random salt
        assertNotNull(result);
        assertTrue(result.startsWith("$1$"));
    }

    
    @Test
    @DisplayName("md5Crypt with salt matching the prefix pattern")
    void testMd5CryptWithSaltMatchingPrefixPattern() {
        // GIVEN a valid byte array for keyBytes and a matching salt
        byte[] keyBytes = "testPassword".getBytes();
        String salt = "$1$abcdefgh";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, "$1$");

        // THEN a valid md5 hash string is returned using the provided salt
        assertNotNull(result);
        assertTrue(result.startsWith(salt));
    }

    
    @Test
    @DisplayName("md5Crypt throws IllegalArgumentException for invalid salt pattern")
    void testMd5CryptThrowsIllegalArgumentExceptionForInvalidSaltPattern() {
        // GIVEN a valid byte array for keyBytes and an invalid salt
        byte[] keyBytes = "testPassword".getBytes();
        String invalidSalt = "$1$invalid_salt";

        // WHEN md5Crypt is called
        // THEN IllegalArgumentException is thrown
        assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, invalidSalt, "$1$");
        });
    }

    
    @Test
    @DisplayName("md5Crypt with valid key and salt performs correct sequence of updates")
    void testMd5CryptWithValidKeyAndSaltPerformsCorrectSequence() {
        // GIVEN keyBytes with length > 16 and a matching salt
        byte[] keyBytes = "testPassword123456".getBytes();
        String salt = "$1$abcdefgh";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, "$1$");

        // THEN a valid md5 hash string, computed using the full sequence, is returned
        assertNotNull(result);
        assertTrue(result.startsWith(salt));
    }

    
    @Test
    @DisplayName("md5Crypt handles keyBytes of zero length")
    void testMd5CryptHandlesKeyBytesOfZeroLength() {
        // GIVEN an empty byte array for keyBytes and a valid salt
        byte[] keyBytes = new byte[0];
        String salt = "$1$abcdefgh";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, "$1$");

        // THEN a valid md5 hash string is returned
        assertNotNull(result);
        assertTrue(result.startsWith(salt));
    }
}