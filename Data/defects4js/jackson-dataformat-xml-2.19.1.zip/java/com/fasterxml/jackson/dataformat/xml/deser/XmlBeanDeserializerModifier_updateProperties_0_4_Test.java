package com.fasterxml.jackson.dataformat.xml.deser;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.introspect.Annotated;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class XmlBeanDeserializerModifier_updateProperties_0_4_Test {

    @Test
    @DisplayName("Multiple properties with some having null acc, ensuring they are skipped")
    void TC16() {
        try {
            // Create a mock DeserializationConfig
            DeserializationConfig config = mock(DeserializationConfig.class);
            // Create a mock BeanDescription
            BeanDescription beanDesc = mock(BeanDescription.class);

            // Create mock BeanPropertyDefinition instances using mock AnnotatedMember
            AnnotatedMember acc2 = mock(AnnotatedMember.class);
            PropertyName propName = new PropertyName("name2");
            BeanPropertyDefinition prop1 = mock(BeanPropertyDefinition.class);
            when(prop1.getPrimaryMember()).thenReturn(null);
            when(prop1.getName()).thenReturn("name1");
            when(prop1.withSimpleName("")).thenReturn(prop1);
            BeanPropertyDefinition prop2 = mock(BeanPropertyDefinition.class);
            when(prop2.getPrimaryMember()).thenReturn(acc2);
            when(prop2.getName()).thenReturn("name2");
            when(prop2.withSimpleName("name2")).thenReturn(prop2);
            when(prop2.getWrapperName()).thenReturn(propName);
            List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop1, prop2));

            // Instantiate the class under test
            XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

            // Invoke the method under test
            List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

            // Assertions
            assertEquals(2, result.size());
            assertEquals("name1", result.get(0).getName());
            assertEquals("name2", result.get(1).getName());

        } catch (Exception e) {
            fail("Exception occurred: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("Property with wrapperName having name length greater than 0 but same as property name, no renaming")
    void TC17() {
        try {
            // Create a mock DeserializationConfig
            DeserializationConfig config = mock(DeserializationConfig.class);
            // Create a mock BeanDescription
            BeanDescription beanDesc = mock(BeanDescription.class);

            // Create mock BeanPropertyDefinition instance using mock AnnotatedMember
            AnnotatedMember acc = mock(AnnotatedMember.class);
            PropertyName wrapper = new PropertyName("propertyName");
            BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
            when(prop.getPrimaryMember()).thenReturn(acc);
            when(prop.getName()).thenReturn("propertyName");
            when(prop.withSimpleName("propertyName")).thenReturn(prop);
            when(prop.getWrapperName()).thenReturn(wrapper);
            List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

            // Instantiate the class under test
            XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

            // Invoke the method under test
            List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

            // Assertions
            assertEquals(1, result.size());
            assertEquals("propertyName", result.get(0).getName());

        } catch (Exception e) {
            fail("Exception occurred: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("Multiple properties with various wrapperName conditions to ensure comprehensive coverage")
    void TC18() {
        try {
            // Create a mock DeserializationConfig
            DeserializationConfig config = mock(DeserializationConfig.class);
            // Create a mock BeanDescription
            BeanDescription beanDesc = mock(BeanDescription.class);

            // Create mock BeanPropertyDefinition instances using mock AnnotatedMember
            AnnotatedMember acc1 = mock(AnnotatedMember.class);
            AnnotatedMember acc2 = mock(AnnotatedMember.class);
            AnnotatedMember acc3 = mock(AnnotatedMember.class);
            AnnotatedMember acc4 = mock(AnnotatedMember.class);

            BeanPropertyDefinition prop1 = mock(BeanPropertyDefinition.class);
            when(prop1.getPrimaryMember()).thenReturn(acc1);
            when(prop1.getName()).thenReturn("name1");
            when(prop1.withSimpleName("name1")).thenReturn(prop1);
            when(prop1.getWrapperName()).thenReturn(PropertyName.NO_NAME);

            BeanPropertyDefinition prop2 = mock(BeanPropertyDefinition.class);
            when(prop2.getPrimaryMember()).thenReturn(acc2);
            when(prop2.getName()).thenReturn("name2");
            when(prop2.withSimpleName("wrapper2")).thenReturn(prop2);
            when(prop2.getWrapperName()).thenReturn(new PropertyName("wrapper2"));

            BeanPropertyDefinition prop3 = mock(BeanPropertyDefinition.class);
            when(prop3.getPrimaryMember()).thenReturn(acc3);
            when(prop3.getName()).thenReturn("name3");
            when(prop3.withSimpleName("name3")).thenReturn(prop3);
            when(prop3.getWrapperName()).thenReturn(PropertyName.NO_NAME);

            BeanPropertyDefinition prop4 = mock(BeanPropertyDefinition.class);
            when(prop4.getPrimaryMember()).thenReturn(acc4);
            when(prop4.getName()).thenReturn("name4");
            when(prop4.withSimpleName("name4")).thenReturn(prop4);
            when(prop4.getWrapperName()).thenReturn(new PropertyName("name4"));

            List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop1, prop2, prop3, prop4));

            // Instantiate the class under test
            XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

            // Invoke the method under test
            List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

            // Assertions
            assertEquals(4, result.size());
            assertEquals("name1", result.get(0).getName());
            assertEquals("wrapper2", result.get(1).getName());
            assertEquals("name3", result.get(2).getName());
            assertEquals("name4", result.get(3).getName());

        } catch (Exception e) {
            fail("Exception occurred: " + e.getMessage());
        }
    }
}