import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;

import static org.junit.jupiter.api.Assertions.*;

class LCBLayoutTest {

    private LCBLayout layout;
    private Container container;

    @BeforeEach
    public void setUp() {
        layout = new LCBLayout(3); // setting up for at least 3 rows
        container = new Container();
        container.setLayout(layout);
    }

    @Test
    public void testLayoutContainer_withSimpleComponents() {
        container.add(createComponentWithPreferredSize(100, 20));
        container.add(createComponentWithPreferredSize(200, 20));
        container.add(createComponentWithPreferredSize(50, 20));

        Dimension containerSize = new Dimension(500, 100);
        container.setSize(containerSize);

        layout.layoutContainer(container);

        Component firstComponent = container.getComponent(0);
        assertEquals(new Rectangle(0, 0, 100, 20), firstComponent.getBounds());

        Component secondComponent = container.getComponent(1);
        assertTrue(secondComponent.getBounds().width > 200); // adjusted width

        Component thirdComponent = container.getComponent(2);
        assertEquals(50, thirdComponent.getBounds().width);
    }

    @Test
    public void testLayoutContainer_withMarginsAndGaps() {
        container.setSize(new Dimension(300, 300));
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 20));

        layout.layoutContainer(container);
        assertEquals(50, container.getComponent(0).getBounds().height);
    }

    @Test
    public void testLayoutContainer_withIrregularComponentSizes() {
        container.setSize(new Dimension(300, 300));

        container.add(createComponentWithPreferredSize(80, 30));
        container.add(createComponentWithPreferredSize(120, 10));
        container.add(createComponentWithPreferredSize(60, 50));

        layout.layoutContainer(container);

        assertEquals(new Rectangle(0, 10, 80, 30), container.getComponent(0).getBounds());
        assertEquals(new Rectangle(100, 20, 120, 10), container.getComponent(1).getBounds());
        assertEquals(new Rectangle(240, 0, 60, 50), container.getComponent(2).getBounds());
    }

    @Test
    public void testLayoutContainer_withNoComponents() {
        container.setSize(new Dimension(200, 200));
        layout.layoutContainer(container);
        assertEquals(0, container.getComponentCount());
    }

    @Test
    public void testLayoutContainer_withNullParent() {
        assertThrows(NullPointerException.class, () -> {
            layout.layoutContainer(null);
        });
    }

    private Component createComponentWithPreferredSize(int width, int height) {
        return new Component() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(width, height);
            }

            @Override
            public Dimension getMinimumSize() {
                return new Dimension(width, height);
            }

            @Override
            public Dimension getMaximumSize() {
                return new Dimension(width, height);
            }
        };
    }

    @Test
    public void testLayoutContainer_withDifferentRowHeights() {
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 30));
        container.add(createComponentWithPreferredSize(50, 40));

        layout.layoutContainer(container);

        int firstRowHeight = container.getComponent(0).getBounds().height;
        int secondRowHeight = container.getComponent(3).getBounds().height;
        int thirdRowHeight = container.getComponent(6).getBounds().height;

        assertEquals(20, firstRowHeight);
        assertEquals(30, secondRowHeight);
        assertEquals(40, thirdRowHeight);
    }

    @Test
    public void testLayoutContainer_withExactNumberOfComponents() {
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 20));
        container.add(createComponentWithPreferredSize(50, 20));
        layout.layoutContainer(container);

        for (int i = 0; i < container.getComponentCount(); i++) {
            assertNotNull(container.getComponent(i).getBounds());
        }
    }

}