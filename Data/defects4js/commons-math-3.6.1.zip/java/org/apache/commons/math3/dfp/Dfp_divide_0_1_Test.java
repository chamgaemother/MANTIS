package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Dfp_divide_0_1_Test {

    @Test
    @DisplayName("Division with matching radix digits and finite operands")
    public void TC01() throws Exception {
        // Initialize DfpField with matching radix digits
        DfpField field = new DfpField(10); // assuming radix digits=10

        // Initialize dividend and divisor with finite values
        Dfp dividend = new Dfp(field, 10.0);
        Dfp divisor = new Dfp(field, 2.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Expected result is 5.0
        assertEquals(5.0, result.toDouble(), 1e-10, "Quotient should be 5.0");
    }

    @Test
    @DisplayName("Division with mismatching radix digits resulting in invalid flag")
    public void TC02() throws Exception {
        // Initialize DfpFields with different radix digits
        DfpField field1 = new DfpField(10);
        DfpField field2 = new DfpField(12); // different radix digits

        // Initialize dividend and divisor
        Dfp dividend = new Dfp(field1, 10.0);
        Dfp divisor = new Dfp(field2, 2.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert result is NaN
        assertTrue(result.isNaN(), "Result should be NaN");

        // Access IEEEFlagsBits via reflection
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField dfpField = (DfpField) fieldField.get(result);
        Method getIEEEFlagsBits = DfpField.class.getDeclaredMethod("getIEEEFlagsBits");
        getIEEEFlagsBits.setAccessible(true);
        long flags = (long) getIEEEFlagsBits.invoke(dfpField);

        // Assert FLAG_INVALID is set
        assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");
    }

    @Test
    @DisplayName("Division where dividend is NaN")
    public void TC03() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(10);

        // Initialize dividend as NaN and divisor as finite
        Dfp dividend = new Dfp(field, Double.NaN);
        Dfp divisor = new Dfp(field, 2.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert result is NaN
        assertTrue(result.isNaN(), "Result should be NaN");
    }

    @Test
    @DisplayName("Division where divisor is NaN")
    public void TC04() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(10);

        // Initialize dividend as finite and divisor as NaN
        Dfp dividend = new Dfp(field, 10.0);
        Dfp divisor = new Dfp(field, Double.NaN);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert result is NaN
        assertTrue(result.isNaN(), "Result should be NaN");
    }

    @Test
    @DisplayName("Division by zero resulting in infinite quotient")
    public void TC05() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(10);

        // Initialize dividend as finite and divisor as zero
        Dfp dividend = new Dfp(field, 10.0);
        Dfp divisor = new Dfp(field, 0.0);

        // Perform division
        Dfp result = dividend.divide(divisor);

        // Assert result is infinite
        assertTrue(result.isInfinite(), "Result should be Infinite");

        // Access IEEEFlagsBits via reflection
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField dfpField = (DfpField) fieldField.get(result);
        Method getIEEEFlagsBits = DfpField.class.getDeclaredMethod("getIEEEFlagsBits");
        getIEEEFlagsBits.setAccessible(true);
        long flags = (long) getIEEEFlagsBits.invoke(dfpField);

        // Assert FLAG_DIV_ZERO is set
        assertTrue((flags & DfpField.FLAG_DIV_ZERO) != 0, "FLAG_DIV_ZERO should be set");
    }
}