package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Dfp_sqrt_2_1_Test {

    @Test
    @DisplayName("TC19: sqrt() correctly handles mantissa last digit divided by 2000 equals 1, triggering case B17")
    public void testTC19_sqrt_mantissaDiv2000Equals1() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = field.getZero();

        // Use reflection to set protected fields
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length - 1] = 2000;
        mantField.set(input, mant);

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte) 0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte) 1); // Positive

        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 0); // Example exponent

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Access result fields via reflection
        int[] resultMant = (int[]) mantField.get(result);
        byte resultSign = signField.getByte(result);
        int resultExp = expField.getInt(result);
        byte resultNans = nansField.getByte(result);

        assertEquals(1500, resultMant[resultMant.length - 1], "Mantissa last digit should be 1500 after sqrt()");
        assertEquals(0, resultExp, "Exponent should remain correctly adjusted after sqrt()");
        assertEquals((byte)0, resultNans, "nans should remain FINITE after sqrt()");
        assertEquals(1, resultSign, "Sign should remain positive after sqrt()");
    }

    @Test
    @DisplayName("TC20: sqrt() executes multiple iterations and terminates when x equals previous x")
    public void testTC20_sqrt_multipleIterations() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = field.getOne();
        
        // Use reflection to set protected fields
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length - 1] = 3000; // Arbitrary value to require iterations
        mantField.set(input, mant);
        
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte) 0); // FINITE
        
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte) 1); // Positive
        
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 2); // Example exponent
        
        // Act
        Dfp result = input.sqrt();
        
        // Assert
        // Access result fields via reflection
        int[] resultMant = (int[]) mantField.get(result);
        byte resultSign = signField.getByte(result);
        int resultExp = expField.getInt(result);
        byte resultNans = nansField.getByte(result);

        // Verify mantissa last digit is correctly set
        assertEquals(1500, resultMant[resultMant.length - 1], "Mantissa last digit should be 1500 after sqrt()");
        
        // Verify exponent is correctly adjusted
        assertEquals(1, resultExp, "Exponent should be correctly adjusted after sqrt()");
        
        // Verify nans remains FINITE
        assertEquals((byte)0, resultNans, "nans should remain FINITE after sqrt()");
        
        // Verify sign remains positive
        assertEquals(1, resultSign, "Sign should remain positive after sqrt()");
    }

    @Test
    @DisplayName("TC21: sqrt() with mantissa last digit divided by 2000 equals 1 and verifies correct exponent adjustment")
    public void testTC21_sqrt_mantissaDiv2000AndExponentAdjustment() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = field.getOne();

        // Use reflection to set protected fields
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length - 1] = 2000;
        mantField.set(input, mant);

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte) 0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte) 1); // Positive

        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 4); // Specific exponent to test adjustment

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Access result fields via reflection
        int[] resultMant = (int[]) mantField.get(result);
        byte resultSign = signField.getByte(result);
        int resultExp = expField.getInt(result);
        byte resultNans = nansField.getByte(result);

        // Verify mantissa last digit is set to 1500
        assertEquals(1500, resultMant[resultMant.length - 1], "Mantissa last digit should be 1500 after sqrt()");

        // Verify exponent is correctly adjusted
        assertEquals(2, resultExp, "Exponent should be correctly adjusted after sqrt()");

        // Verify nans remains FINITE
        assertEquals((byte)0, resultNans, "nans should remain FINITE after sqrt()");

        // Verify sign remains positive
        assertEquals(1, resultSign, "Sign should remain positive after sqrt()");
    }

    @Test
    @DisplayName("TC22: sqrt() with mantissa last digit divided by 2000 equals 1 and handles normalization after rounding")
    public void testTC22_sqrt_mantissaDiv2000AndNormalizationAfterRounding() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = field.getOne();

        // Use reflection to set protected fields
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length - 1] = 2000;
        mantField.set(input, mant);

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte) 0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte) 1); // Positive

        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 4); // Specific exponent e.g., causes rounding

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Access result fields via reflection
        int[] resultMant = (int[]) mantField.get(result);
        byte resultSign = signField.getByte(result);
        int resultExp = expField.getInt(result);
        byte resultNans = nansField.getByte(result);

        // Verify mantissa last digit is set to 1500 after sqrt()
        assertEquals(1500, resultMant[resultMant.length - 1], "Mantissa last digit should be 1500 after sqrt()");

        // Verify mantissa is normalized (no leading zeros)
        assertTrue(resultMant[resultMant.length - 1] != 0, "Mantissa should be normalized and non-zero after sqrt()");

        // Verify exponent is correctly adjusted
        assertEquals(2, resultExp, "Exponent should be correctly adjusted after sqrt()");

        // Verify nans remains FINITE
        assertEquals((byte)0, resultNans, "nans should remain FINITE after sqrt()");

        // Verify sign remains positive
        assertEquals(1, resultSign, "Sign should remain positive after sqrt()");
    }

    @Test
    @DisplayName("TC23: sqrt() handles exact square resulting in correct mantissa and exponent without iterations")
    public void testTC23_sqrt_exactSquareNoIterations() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = field.getZero();

        // Use reflection to set protected fields for exact square (e.g., 16.0)
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length - 1] = 4000; // Represents 16.0 in radix 10000
        mantField.set(input, mant);

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte) 0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte) 1); // Positive

        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 4); // Specific exponent for 16.0

        // Act
        Dfp result = input.sqrt();

        // Assert
        // Access result fields via reflection
        int[] resultMant = (int[]) mantField.get(result);
        byte resultSign = signField.getByte(result);
        int resultExp = expField.getInt(result);
        byte resultNans = nansField.getByte(result);

        // Verify mantissa last digit is set to 1000 for sqrt(16.0) = 4.0
        assertEquals(1000, resultMant[resultMant.length - 1], "Mantissa last digit should be 1000 after sqrt(16.0)");

        // Verify exponent is correctly adjusted
        assertEquals(2, resultExp, "Exponent should be correctly adjusted after sqrt()");

        // Verify nans remains FINITE
        assertEquals((byte)0, resultNans, "nans should remain FINITE after sqrt()");

        // Verify sign remains positive
        assertEquals(1, resultSign, "Sign should remain positive after sqrt()");
    }

}