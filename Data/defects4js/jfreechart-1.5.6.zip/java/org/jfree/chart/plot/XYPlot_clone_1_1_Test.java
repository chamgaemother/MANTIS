package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.List;

import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYPlot_clone_1_1_Test {

    /**
     * Cloning a CombinedDomainXYPlot instance with one subplot and domainAxis set.
     * Expected Result: Cloned plot has one distinct subplot with parent set and domainAxis configured.
     */
//     @Test
//     @DisplayName("Cloning CombinedDomainXYPlot with one subplot and domainAxis set")
//     public void TC11_cloneWithOneSubplotAndDomainAxisSet() throws Exception {
        // GIVEN
//         CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
//         XYPlot subplot = new XYPlot();
//         plot.add(subplot);
//         ValueAxis domainAxis = new NumberAxis("Domain Axis");
//         plot.setDomainAxis(domainAxis);
// 
        // WHEN
//         CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone();
// 
        // THEN
//         assertNotSame(plot, clonedPlot, "Cloned plot should be a different instance.");
//         List<XYPlot> clonedSubplots = getSubplots(clonedPlot);
//         assertEquals(1, clonedSubplots.size(), "Cloned plot should have one subplot.");
//         XYPlot clonedSubplot = clonedSubplots.get(0);
//         assertNotSame(subplot, clonedSubplot, "Cloned subplot should be a different instance.");
//         assertEquals(clonedPlot, clonedSubplot.getParent(), "Cloned subplot's parent should be the cloned plot.");
//         assertTrue(clonedPlot.getDomainAxis(0).isConfigured(), "Cloned domainAxis should be configured.");
//     }

    /**
     * Cloning CombinedDomainXYPlot with one subplot and domainAxis null.
     * Expected Result: Cloned plot has one distinct subplot with parent set and domainAxis remains null.
     */
    @Test
    @DisplayName("Cloning CombinedDomainXYPlot with one subplot and domainAxis null")
    public void TC12_cloneWithOneSubplotAndDomainAxisNull() throws Exception {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        XYPlot subplot = new XYPlot();
        plot.add(subplot);
        plot.setDomainAxis(null);

        // WHEN
        CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone();

        // THEN
        assertNotSame(plot, clonedPlot, "Cloned plot should be a different instance.");
        List<XYPlot> clonedSubplots = getSubplots(clonedPlot);
        assertEquals(1, clonedSubplots.size(), "Cloned plot should have one subplot.");
        XYPlot clonedSubplot = clonedSubplots.get(0);
        assertNotSame(subplot, clonedSubplot, "Cloned subplot should be a different instance.");
        assertEquals(clonedPlot, clonedSubplot.getParent(), "Cloned subplot's parent should be the cloned plot.");
        assertNull(clonedPlot.getDomainAxis(0), "Cloned domainAxis should remain null.");
    }

    /**
     * Cloning CombinedDomainXYPlot with no subplots and domainAxis set.
     * Expected Result: Cloned plot has no subplots and domainAxis is configured.
     */
//     @Test
//     @DisplayName("Cloning CombinedDomainXYPlot with no subplots and domainAxis set")
//     public void TC13_cloneWithNoSubplotsAndDomainAxisSet() throws Exception {
        // GIVEN
//         CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
//         plot.setDomainAxis(new NumberAxis("Domain Axis"));
// 
        // WHEN
//         CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone();
// 
        // THEN
//         assertNotSame(plot, clonedPlot, "Cloned plot should be a different instance.");
//         List<XYPlot> clonedSubplots = getSubplots(clonedPlot);
//         assertTrue(clonedSubplots.isEmpty(), "Cloned plot should have no subplots.");
//         assertTrue(clonedPlot.getDomainAxis(0).isConfigured(), "Cloned domainAxis should be configured.");
//     }

    /**
     * Cloning CombinedDomainXYPlot with no subplots and domainAxis null.
     * Expected Result: Cloned plot has no subplots and domainAxis remains null.
     */
    @Test
    @DisplayName("Cloning CombinedDomainXYPlot with no subplots and domainAxis null")
    public void TC14_cloneWithNoSubplotsAndDomainAxisNull() throws Exception {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        plot.setDomainAxis(null);

        // WHEN
        CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone();

        // THEN
        assertNotSame(plot, clonedPlot, "Cloned plot should be a different instance.");
        List<XYPlot> clonedSubplots = getSubplots(clonedPlot);
        assertTrue(clonedSubplots.isEmpty(), "Cloned plot should have no subplots.");
        assertNull(clonedPlot.getDomainAxis(0), "Cloned domainAxis should remain null.");
    }

    /**
     * Cloning CombinedDomainXYPlot with multiple subplots and domainAxis set.
     * Expected Result: Cloned plot has multiple distinct subplots with parent set and domainAxis configured.
     */
//     @Test
//     @DisplayName("Cloning CombinedDomainXYPlot with multiple subplots and domainAxis set")
//     public void TC15_cloneWithMultipleSubplotsAndDomainAxisSet() throws Exception {
        // GIVEN
//         CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
//         XYPlot subplot1 = new XYPlot();
//         XYPlot subplot2 = new XYPlot();
//         XYPlot subplot3 = new XYPlot();
//         plot.add(subplot1);
//         plot.add(subplot2);
//         plot.add(subplot3);
//         plot.setDomainAxis(new NumberAxis("Domain Axis"));
// 
        // WHEN
//         CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone();
// 
        // THEN
//         assertNotSame(plot, clonedPlot, "Cloned plot should be a different instance.");
//         List<XYPlot> clonedSubplots = getSubplots(clonedPlot);
//         assertEquals(3, clonedSubplots.size(), "Cloned plot should have three subplots.");
//         for (XYPlot clonedSubplot : clonedSubplots) {
//             assertNotNull(clonedSubplot, "Cloned subplot should not be null.");
//             assertNotSame(subplot1, clonedSubplot, "Each cloned subplot should be a different instance.");
//             assertNotSame(subplot2, clonedSubplot, "Each cloned subplot should be a different instance.");
//             assertNotSame(subplot3, clonedSubplot, "Each cloned subplot should be a different instance.");
//             assertEquals(clonedPlot, clonedSubplot.getParent(), "Cloned subplot's parent should be the cloned plot.");
//         }
//         assertTrue(clonedPlot.getDomainAxis(0).isConfigured(), "Cloned domainAxis should be configured.");
//     }

    /**
     * Utility method to access the private 'subplots' field using reflection.
     *
     * @param plot The CombinedDomainXYPlot instance.
     * @return List of XYPlot subplots.
     * @throws Exception if reflection fails.
     */
    @SuppressWarnings("unchecked")
    private List<XYPlot> getSubplots(CombinedDomainXYPlot plot) throws Exception {
        Field subplotsField = CombinedDomainXYPlot.class.getDeclaredField("subplots");
        subplotsField.setAccessible(true);
        return (List<XYPlot>) subplotsField.get(plot);
    }
}