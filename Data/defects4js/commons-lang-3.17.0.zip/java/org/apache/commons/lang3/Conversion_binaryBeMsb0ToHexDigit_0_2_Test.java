package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryBeMsb0ToHexDigit_0_2_Test {

    @Test
    @DisplayName("Returns 'e' when pos >= 3, src[pos-3] is true, src[pos-2] is true, src[pos-1] is true, and src[pos] is true")
    void TC06_return_e() {
        // GIVEN
        boolean[] src = new boolean[]{true, true, true, true};
        int srcPos = 0;
        
        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        
        // THEN
        assertEquals('e', result);
    }

    @Test
    @DisplayName("Returns '4' when pos >= 2, src[pos-2] is false, src[pos-1] is false, and src[pos] is false")
    void TC07_return_4() {
        // GIVEN
        boolean[] src = new boolean[]{false, false, false};
        int srcPos = 1;
        
        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        
        // THEN
        assertEquals('4', result);
    }

    @Test
    @DisplayName("Returns 'd' when pos >= 3, src[pos-3] is true, src[pos-2] is true, src[pos-1] is false, and src[pos] is true")
    void TC08_return_d() {
        // GIVEN
        boolean[] src = new boolean[]{true, true, false, true};
        int srcPos = 0;
        
        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        
        // THEN
        assertEquals('d', result);
    }

    @Test
    @DisplayName("Returns 'f' when pos >= 3 and all related bits are true")
    void TC09_return_f() {
        // GIVEN
        boolean[] src = new boolean[]{true, true, true, true};
        int srcPos = 0;
        
        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        
        // THEN
        assertEquals('f', result);
    }

    @Test
    @DisplayName("Returns '8' when pos >= 3, src[pos-3] is false, src[pos-2] is false, src[pos-1] is false, and src[pos] is false")
    void TC10_return_8() {
        // GIVEN
        boolean[] src = new boolean[]{false, false, false, false};
        int srcPos = 0;
        
        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        
        // THEN
        assertEquals('8', result);
    }
}