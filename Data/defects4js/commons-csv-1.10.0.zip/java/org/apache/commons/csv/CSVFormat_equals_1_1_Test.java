package org.apache.commons.csv;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.csv.CSVFormat;

public class CSVFormat_equals_1_1_Test {

    @Test
    @DisplayName("equals returns false when headers contain different null elements")
    void TC24_equals_ReturnsFalse_WhenHeadersHaveDifferentNullElements() {
        // Arrange
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
            .setHeader("A", null)
            .build();

        CSVFormat format2 = CSVFormat.DEFAULT.builder()
            .setHeader("A", "B")
            .build();

        // Act
        boolean result = format1.equals(format2);

        // Assert
        assertFalse(result, "CSVFormat instances with different headers should not be equal");
    }

    @Test
    @DisplayName("equals returns true when headers contain the same null elements")
    void TC25_equals_ReturnsTrue_WhenHeadersHaveSameNullElements() {
        // Arrange
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
            .setHeader("A", null)
            .build();

        CSVFormat format2 = CSVFormat.DEFAULT.builder()
            .setHeader("A", null)
            .build();

        // Act
        boolean result = format1.equals(format2);

        // Assert
        assertTrue(result, "CSVFormat instances with identical headers should be equal");
    }
}