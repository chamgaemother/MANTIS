import org.apache.commons.collections4.iterators.PermutationIterator;
import org.junit.jupiter.api.Test;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class PermutationIteratorTest {

    @Test
    void testSingleElement() {
        List<String> list = Collections.singletonList("A");
        PermutationIterator<String> iterator = new PermutationIterator<>(list);

        assertTrue(iterator.hasNext());
        assertEquals(Collections.singletonList("A"), iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    void testTwoElements() {
        List<String> list = Arrays.asList("A", "B");
        PermutationIterator<String> iterator = new PermutationIterator<>(list);

        assertTrue(iterator.hasNext());
        List<String> perm1 = iterator.next();
        assertTrue(iterator.hasNext());
        List<String> perm2 = iterator.next();
        assertFalse(iterator.hasNext());

        // Check that permutations match
        assertTrue(
            (perm1.equals(Arrays.asList("A", "B")) && perm2.equals(Arrays.asList("B", "A"))) ||
            (perm1.equals(Arrays.asList("B", "A")) && perm2.equals(Arrays.asList("A", "B")))
        );
    }

    @Test
    void testEmptyCollection() {
        List<String> list = Collections.emptyList();
        PermutationIterator<String> iterator = new PermutationIterator<>(list);

        assertTrue(iterator.hasNext());
        assertEquals(Collections.emptyList(), iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    void testThreeElements() {
        List<String> list = Arrays.asList("A", "B", "C");
        PermutationIterator<String> iterator = new PermutationIterator<>(list);

        Set<List<String>> seenPermutations = new HashSet<>();
        while (iterator.hasNext()) {
            seenPermutations.add(iterator.next());
        }
        
        Set<List<String>> expectedPermutations = new HashSet<>(Arrays.asList(
            Arrays.asList("A", "B", "C"),
            Arrays.asList("A", "C", "B"),
            Arrays.asList("B", "A", "C"),
            Arrays.asList("B", "C", "A"),
            Arrays.asList("C", "A", "B"),
            Arrays.asList("C", "B", "A")
        ));

        assertEquals(expectedPermutations, seenPermutations);
    }

    @Test
    void testNoSuchElementException() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(list);

        while (iterator.hasNext()) {
            iterator.next();
        }

        assertThrows(NoSuchElementException.class, iterator::next);
    }
    
    @Test
    void testUnsupportedOperationException() {
        List<String> list = Arrays.asList("X", "Y", "Z");
        PermutationIterator<String> iterator = new PermutationIterator<>(list);

        assertThrows(UnsupportedOperationException.class, iterator::remove);
    }

    @Test
    void testFourElements() {
        List<String> list = Arrays.asList("A", "B", "C", "D");
        PermutationIterator<String> iterator = new PermutationIterator<>(list);

        List<List<String>> permutations = new ArrayList<>();
        while (iterator.hasNext()) {
            permutations.add(iterator.next());
        }

        // There should be 4! = 24 permutations
        assertEquals(24, permutations.size());
    }
}