package org.apache.commons.math3.analysis.solvers;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.util.Decimal64;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FieldBracketingNthOrderBrentSolver_solve_0_2_Test {

    @Test
    @DisplayName("solve successfully brackets the root when f(min) * f(startValue) < 0")
    void TC06_solve_bracketsRoot_fMin_fStartValueLessThanZero() throws Exception {
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = mock(RealFieldUnivariateFunction.class);
        Decimal64 min = new Decimal64(0.0);
        Decimal64 max = new Decimal64(1.0);
        Decimal64 startValue = new Decimal64(0.5);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1e-8);
        Decimal64 absoluteAccuracy = new Decimal64(1e-8);
        Decimal64 functionValueAccuracy = new Decimal64(1e-15);
        int maximalOrder = 5;

        when(f.value(min)).thenReturn(new Decimal64(1.0));
        when(f.value(startValue)).thenReturn(new Decimal64(-1.0));

        // Instantiate solver
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(
                        relativeAccuracy,
                        absoluteAccuracy,
                        functionValueAccuracy,
                        maximalOrder
                );

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        RealFieldElement fResult = f.value(result);
        assertEquals(0.0, fResult.getReal(), 1e-8, "The result should be a root.");
    }

    @Test
    @DisplayName("solve successfully brackets the root when f(startValue) * f(max) < 0")
    void TC07_solve_bracketsRoot_fStartValue_fMaxLessThanZero() throws Exception {
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = mock(RealFieldUnivariateFunction.class);
        Decimal64 min = new Decimal64(0.0);
        Decimal64 max = new Decimal64(1.0);
        Decimal64 startValue = new Decimal64(0.5);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1e-8);
        Decimal64 absoluteAccuracy = new Decimal64(1e-8);
        Decimal64 functionValueAccuracy = new Decimal64(1e-15);
        int maximalOrder = 5;

        when(f.value(startValue)).thenReturn(new Decimal64(1.0));
        when(f.value(max)).thenReturn(new Decimal64(-1.0));

        // Instantiate solver
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(
                        relativeAccuracy,
                        absoluteAccuracy,
                        functionValueAccuracy,
                        maximalOrder
                );

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        RealFieldElement fResult = f.value(result);
        assertEquals(0.0, fResult.getReal(), 1e-8, "The result should be a root.");
    }

    @Test
    @DisplayName("solve throws NoBracketingException when no bracketing is found")
    void TC08_solve_noBracketing_throwsException() {
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = mock(RealFieldUnivariateFunction.class);
        Decimal64 min = new Decimal64(0.0);
        Decimal64 max = new Decimal64(1.0);
        Decimal64 startValue = new Decimal64(0.5);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1e-8);
        Decimal64 absoluteAccuracy = new Decimal64(1e-8);
        Decimal64 functionValueAccuracy = new Decimal64(1e-15);
        int maximalOrder = 5;

        when(f.value(min)).thenReturn(new Decimal64(1.0));
        when(f.value(startValue)).thenReturn(new Decimal64(2.0));
        when(f.value(max)).thenReturn(new Decimal64(3.0));

        // Instantiate solver
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(
                        relativeAccuracy,
                        absoluteAccuracy,
                        functionValueAccuracy,
                        maximalOrder
                );

        // WHEN & THEN
        assertThrows(NoBracketingException.class, () -> {
            solver.solve(maxEval, f, min, max, startValue, allowedSolution);
        }, "Expected solve to throw NoBracketingException when no bracketing is found.");
    }

    @Test
    @DisplayName("solve converges based on xTol condition")
    void TC09_solve_converges_onXTol() throws Exception {
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = mock(RealFieldUnivariateFunction.class);
        Decimal64 min = new Decimal64(0.0);
        Decimal64 max = new Decimal64(1.0);
        Decimal64 startValue = new Decimal64(0.5);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1e-8);
        Decimal64 absoluteAccuracy = new Decimal64(1e-8);
        Decimal64 functionValueAccuracy = new Decimal64(1e-15);
        int maximalOrder = 5;

        // Mock behavior to simulate convergence based on xTol
        when(f.value(any())).thenReturn(new Decimal64(0.0));

        // Instantiate solver
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(
                        relativeAccuracy,
                        absoluteAccuracy,
                        functionValueAccuracy,
                        maximalOrder
                );

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        assertTrue(Math.abs(result.getReal()) <= absoluteAccuracy.getReal(),
                "The result should be within the specified x tolerance.");
    }

    @Test
    @DisplayName("solve converges based on functionValueAccuracy condition")
    void TC10_solve_converges_onFunctionValueAccuracy() throws Exception {
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = mock(RealFieldUnivariateFunction.class);
        Decimal64 min = new Decimal64(0.0);
        Decimal64 max = new Decimal64(1.0);
        Decimal64 startValue = new Decimal64(0.5);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1e-8);
        Decimal64 absoluteAccuracy = new Decimal64(1e-8);
        Decimal64 functionValueAccuracy = new Decimal64(1e-15);
        int maximalOrder = 5;

        when(f.value(any())).thenReturn(new Decimal64(1e-16));

        // Instantiate solver
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(
                        relativeAccuracy,
                        absoluteAccuracy,
                        functionValueAccuracy,
                        maximalOrder
                );

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        RealFieldElement fResult = f.value(result);
        assertTrue(Math.abs(fResult.getReal()) <= functionValueAccuracy.getReal(),
                "The function value at result should be within the specified function value accuracy.");
    }
}
