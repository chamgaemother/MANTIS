package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_isCreatable_1_3_Test {
    
    @Test
    @DisplayName("isCreatable(\"0\") returns true for zero value")
    void TC38_isCreatable_zeroValue() {
        // GIVEN
        String input = "0";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result, "Expected isCreatable(\"0\") to return true");
    }
    
    @Test
    @DisplayName("isCreatable(\"0.\") returns true for zero with trailing decimal point")
    void TC39_isCreatable_zeroWithTrailingDecimalPoint() {
        // GIVEN
        String input = "0.";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result, "Expected isCreatable(\"0.\") to return true");
    }
    
    @Test
    @DisplayName("isCreatable(\"0e0\") returns true for zero with exponent")
    void TC40_isCreatable_zeroWithExponent() {
        // GIVEN
        String input = "0e0";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertTrue(result, "Expected isCreatable(\"0e0\") to return true");
    }
}