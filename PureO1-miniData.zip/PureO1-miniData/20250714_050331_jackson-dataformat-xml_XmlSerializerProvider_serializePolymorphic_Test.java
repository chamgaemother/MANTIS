package com.fasterxml.jackson.dataformat.xml.ser;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.io.IOException;

import javax.xml.namespace.QName;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializationConfig;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.SerializerFactory;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

class XmlSerializerProviderTest {

    private XmlRootNameLookup rootNameLookup;
    private SerializationConfig config;
    private SerializerFactory serializerFactory;
    private XmlSerializerProvider provider;

    @BeforeEach
    void setUp() {
        rootNameLookup = mock(XmlRootNameLookup.class);
        config = mock(SerializationConfig.class);
        serializerFactory = mock(SerializerFactory.class);
        provider = new XmlSerializerProvider(rootNameLookup);
        provider = spy(new XmlSerializerProvider(provider, config, serializerFactory));
    }

    @Test
    void serializePolymorphic_NullValue_ShouldCallSerializeXmlNull() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        provider.serializePolymorphic(gen, null, null, null, null);
        verify(provider)._serializeXmlNull(gen);
        verifyNoMoreInteractions(gen);
    }

    @Test
    void serializePolymorphic_IncompatibleRootType_ShouldThrowException() {
        JsonGenerator gen = mock(JsonGenerator.class);
        Object value = new Object();
        JavaType rootType = mock(JavaType.class);
        when(rootType.getRawClass()).thenReturn(String.class);
        Exception exception = assertThrows(JsonMappingException.class, () -> {
            provider.serializePolymorphic(gen, value, rootType, null, null);
        });
        verify(provider)._reportIncompatibleRootType(value, rootType);
    }

    @Test
    void serializePolymorphic_GenNotToXmlGenerator_ShouldCallSerializeValue() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        Object value = "test";
        doReturn(null).when(provider)._asXmlGenerator(gen);
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        doReturn(serializer).when(provider).findTypedValueSerializer(eq(value.getClass()), eq(true), any());

        provider.serializePolymorphic(gen, value, null, null, null);

        verify(provider)._asXmlGenerator(gen);
        verify(provider, never())._initWithRootName(any(), any());
        verify(serializer).serialize(eq(value), eq(gen), eq(provider));
        verify(gen, never()).writeEndObject();
    }

    @Test
    void serializePolymorphic_WithRootTypeAndAssignable_ShouldSerializeWithType() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        Object value = "test";
        JavaType rootType = mock(JavaType.class);
        when(rootType.getRawClass()).thenReturn(String.class);
        doReturn(xgen).when(provider)._asXmlGenerator(gen);
        QName rootQName = new QName("test");
        when(provider._rootNameFromConfig()).thenReturn(rootQName);
        when(rootNameLookup.findRootName(eq(String.class), eq(config))).thenReturn(rootQName);
        when(provider._config).thenReturn(config);
        when(provider._shouldUnwrapObjectNode(xgen, value)).thenReturn(false);
        when(provider._initWithRootName(xgen, rootQName)).then(invocation -> null);
        when(config.constructType(String.class)).thenReturn(mock(JavaType.class));
        when(provider.findTypedValueSerializer(eq(rootType), eq(true), any())).thenReturn(mock(JsonSerializer.class));

        provider.serializePolymorphic(gen, value, rootType, null, null);

        verify(provider)._asXmlGenerator(gen);
        verify(provider)._initWithRootName(xgen, rootQName);
        verify(xgen).initGenerator();
        verify(provider).findTypedValueSerializer(eq(rootType), eq(true), any());
    }

    @Test
    void serializePolymorphic_UnwrapObjectNode_ShouldSerializeUnwrapped() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        ObjectNode objectNode = mock(ObjectNode.class);
        when(objectNode.size()).thenReturn(1);
        when(objectNode.fields()).thenReturn(mock(java.util.Iterator.class));
        JavaType rootType = mock(JavaType.class);
        doReturn(xgen).when(provider)._asXmlGenerator(gen);
        doReturn(true).when(provider)._shouldUnwrapObjectNode(xgen, objectNode);

        provider.serializePolymorphic(gen, objectNode, rootType, null, null);

        verify(provider)._serializeUnwrappedObjectNode(xgen, objectNode, null);
        verifyNoMoreInteractions(gen);
    }

    @Test
    void serializePolymorphic_AsArray_ShouldWriteEndObject() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        Object value = new String[]{"a", "b"};
        JavaType rootType = mock(JavaType.class);
        when(rootType.isContainerType()).thenReturn(true);
        when(rootType.getRawClass()).thenReturn(String[].class);
        doReturn(xgen).when(provider)._asXmlGenerator(gen);
        QName rootQName = new QName("arrayRoot");
        when(provider._rootNameFromConfig()).thenReturn(rootQName);
        when(rootNameLookup.findRootName(eq(String[].class), eq(config))).thenReturn(rootQName);
        when(provider._shouldUnwrapObjectNode(xgen, value)).thenReturn(false);
        when(config.constructType(String[].class)).thenReturn(mock(JavaType.class));
        when(provider.findTypedValueSerializer(eq(rootType), eq(true), any())).thenReturn(mock(JsonSerializer.class));
        when(provider._config.constructType(String[].class)).thenReturn(mock(JavaType.class));
        when(provider._initWithRootName(xgen, rootQName)).then(invocation -> null);
        when(provider.TypeUtil.isIndexedType(any())).thenReturn(true);

        provider.serializePolymorphic(gen, value, rootType, null, null);

        verify(xgen).writeStartObject();
        verify(xgen).writeFieldName("item");
        verify(provider).findTypedValueSerializer(eq(rootType), eq(true), any());
        verify(gen).writeEndObject();
    }

    @Test
    void serializePolymorphic_WithProvidedSerializer_ShouldUseIt() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        Object value = "test";
        JavaType rootType = mock(JavaType.class);
        TypeSerializer typeSer = mock(TypeSerializer.class);
        doReturn(xgen).when(provider)._asXmlGenerator(gen);
        QName rootQName = new QName("test");
        when(provider._rootNameFromConfig()).thenReturn(rootQName);
        when(rootNameLookup.findRootName(eq(String.class), eq(config))).thenReturn(rootQName);
        when(provider._shouldUnwrapObjectNode(xgen, value)).thenReturn(false);
        when(provider.findTypedValueSerializer(eq(rootType), eq(true), any())).thenReturn(mock(JsonSerializer.class));

        JsonSerializer<Object> providedSerializer = mock(JsonSerializer.class);
        provider.serializePolymorphic(gen, value, rootType, providedSerializer, typeSer);

        verify(providedSerializer).serializeWithType(eq(value), eq(gen), eq(provider), eq(typeSer));
        verify(gen, never()).writeEndObject();
    }

    @Test
    void serializePolymorphic_XgenHasNamespace_ShouldSetDefaultNamespace() throws IOException, javax.xml.stream.XMLStreamException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        Object value = "test";
        JavaType rootType = mock(JavaType.class);
        QName rootQName = new QName("namespace", "test");
        when(provider._rootNameFromConfig()).thenReturn(rootQName);
        when(provider._asXmlGenerator(gen)).thenReturn(xgen);
        when(provider._shouldUnwrapObjectNode(xgen, value)).thenReturn(false);
        when(rootNameLookup.findRootName(eq(String.class), eq(config))).thenReturn(rootQName);
        when(config.constructType(String.class)).thenReturn(mock(JavaType.class));
        when(provider.findTypedValueSerializer(eq(rootType), eq(true), any())).thenReturn(mock(JsonSerializer.class));

        provider.serializePolymorphic(gen, value, rootType, null, null);

        verify(xgen).getStaxWriter();
        verify(xgen.getStaxWriter()).setDefaultNamespace("namespace");
    }

    @Test
    void serializePolymorphic_ExceptionDuringSerialize_ShouldWrapIOException() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        Object value = "test";
        JavaType rootType = mock(JavaType.class);
        QName rootQName = new QName("test");
        when(provider._rootNameFromConfig()).thenReturn(rootQName);
        when(provider._asXmlGenerator(gen)).thenReturn(xgen);
        when(provider._shouldUnwrapObjectNode(xgen, value)).thenReturn(false);
        when(rootNameLookup.findRootName(eq(String.class), eq(config))).thenReturn(rootQName);
        when(config.constructType(String.class)).thenReturn(mock(JavaType.class));
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        when(provider.findTypedValueSerializer(eq(rootType), eq(true), any())).thenReturn(serializer);
        doThrow(new RuntimeException("Serialization error")).when(serializer).serializeWithType(eq(value), eq(gen), eq(provider), any());

        JsonMappingException exception = assertThrows(JsonMappingException.class, () -> {
            provider.serializePolymorphic(gen, value, rootType, null, null);
        });

        assertEquals("Serialization error", exception.getOriginalMessage());
    }

    @Test
    void serializePolymorphic_GenIsTokenBuffer_ShouldNotThrowException() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        Object value = "test";
        when(provider._asXmlGenerator(gen)).thenReturn(null);

        provider.serializePolymorphic(gen, value, null, null, null);

        verify(provider).findTypedValueSerializer(eq(value.getClass()), eq(true), any());
    }

    @Test
    void serializePolymorphic_ObjectNodeWithMultipleFields_ShouldNotUnwrap() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        ObjectNode objectNode = mock(ObjectNode.class);
        doReturn(2).when(objectNode).size();
        when(provider._asXmlGenerator(gen)).thenReturn(xgen);
        when(provider._shouldUnwrapObjectNode(xgen, objectNode)).thenReturn(false);
        when(provider.findTypedValueSerializer(eq(objectNode.getClass()), eq(true), any())).thenReturn(mock(JsonSerializer.class));

        provider.serializePolymorphic(gen, objectNode, null, null, null);

        verify(provider, never())._serializeUnwrappedObjectNode(any(), any(), any());
        verify(provider.findTypedValueSerializer(eq(objectNode.getClass()), eq(true), any())).serialize(eq(objectNode), eq(gen), eq(provider));
    }

    @Test
    void serializePolymorphic_SetNextNameIfMissingReturnsFalseButInRoot_ShouldSetNextName() throws IOException {
        JsonGenerator gen = mock(JsonGenerator.class);
        ToXmlGenerator xgen = mock(ToXmlGenerator.class);
        Object value = "test";
        QName rootQName = new QName("test");
        when(provider._rootNameFromConfig()).thenReturn(rootQName);
        when(provider._asXmlGenerator(gen)).thenReturn(xgen);
        when(xgen.setNextNameIfMissing(rootQName)).thenReturn(false);
        when(xgen.inRoot()).thenReturn(true);
        doNothing().when(xgen).setNextName(rootQName);
        when(provider._shouldUnwrapObjectNode(xgen, value)).thenReturn(false);
        when(rootNameLookup.findRootName(eq(String.class), eq(config))).thenReturn(rootQName);
        when(config.constructType(String.class)).thenReturn(mock(JavaType.class));
        when(provider.findTypedValueSerializer(eq(value.getClass()), eq(true), any())).thenReturn(mock(JsonSerializer.class));

        provider.serializePolymorphic(gen, value, null, null, null);

        verify(xgen).setNextNameIfMissing(rootQName);
        verify(xgen).setNextName(rootQName);
    }

    private static <T extends Throwable> T assertThrows(Class<T> expectedType, Executable executable) {
        try {
            executable.execute();
        } catch (Throwable actualException) {
            if (expectedType.isInstance(actualException)) {
                return expectedType.cast(actualException);
            }
            String message = String.format("Expected exception of type %s but got %s",
                    expectedType.getName(), actualException.getClass().getName());
            throw new AssertionError(message, actualException);
        }
        throw new AssertionError("Expected exception of type " + expectedType.getName() + " but no exception was thrown.");
    }

    @FunctionalInterface
    private interface Executable {
        void execute() throws Throwable;
    }
}