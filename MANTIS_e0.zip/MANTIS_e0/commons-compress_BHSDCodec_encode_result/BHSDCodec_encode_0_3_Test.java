package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class BHSDCodec_encode_0_3_Test {

    @Test
    @DisplayName("encode completes encoding loop with zero iterations")
    public void TC11() throws Exception {
        // Initialize BHSDCodec instance
        BHSDCodec codec = new BHSDCodec(1, 256, 0, 0);

        // Set private fields using reflection
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, 1);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 100);

        // Define input parameters
        int value = 50;
        int b = 0;

        // Execute the method under test
        byte[] result = codec.encode(value, b);

        // Assert the expected outcome
        assertEquals(0, result.length, "Expected an empty byte array");
    }

    @Test
    @DisplayName("encode completes encoding loop with one iteration")
    public void TC12() throws Exception {
        // Initialize BHSDCodec instance
        BHSDCodec codec = new BHSDCodec(1, 256, 0, 0);

        // Set private fields using reflection
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, 1);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 100);

        // Define input parameters
        int value = 50;
        int b = 1;

        // Execute the method under test
        byte[] result = codec.encode(value, b);

        // Assert the expected outcome
        assertEquals(1, result.length, "Expected a byte array with one byte");
        // Additional assertion can be added based on the encoding logic
    }

    @Test
    @DisplayName("encode completes encoding loop with multiple iterations")
    public void TC13() throws Exception {
        // Initialize BHSDCodec instance
        BHSDCodec codec = new BHSDCodec(3, 10, 0, 0);

        // Set private fields using reflection
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, 1);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 10000);

        // Define input parameters
        int value = 9999;
        int b = 3;

        // Execute the method under test
        byte[] result = codec.encode(value, b);

        // Assert the expected outcome
        assertTrue(result.length > 1, "Expected a byte array with multiple bytes");
        // Additional assertions can be added based on the encoding logic
    }

    @Test
    @DisplayName("encode throws Pack200Exception when final z is negative after loop")
    public void TC14() throws Exception {
        // Initialize BHSDCodec instance
        BHSDCodec codec = new BHSDCodec(2, 256, 1, 1);

        // Set private fields using reflection
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, -100);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 100);

        // Define input parameters that will cause final z < 0 after loop
        int value = -150;
        int b = 2;

        // Execute and assert exception
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            codec.encode(value, b);
        }, "Expected Pack200Exception to be thrown");

        assertEquals("unable to encode", exception.getMessage(), "Exception message mismatch");
    }
}