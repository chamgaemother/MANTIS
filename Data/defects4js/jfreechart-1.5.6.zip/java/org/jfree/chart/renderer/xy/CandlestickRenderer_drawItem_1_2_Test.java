// package org.jfree.chart.renderer.xy;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.CandlestickRenderer;
// import org.jfree.chart.renderer.xy.XYItemRendererState;
// import org.jfree.data.xy.IntervalXYDataset;
// import org.jfree.data.xy.OHLCDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.awt.geom.Rectangle2D;
// import java.lang.reflect.Field;
// import java.lang.reflect.Method;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// public class CandlestickRenderer_drawItem_1_2_Test {
// 
//     @Test
//     @DisplayName("drawItem calculates candle width using WIDTHMETHOD_INTERVALDATA")
//     public void TC06_drawItem_CandleWidth_IntervalData() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_INTERVALDATA);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         when(dataset.getStartXValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getEndXValue(0, 0)).thenReturn(2000.0);
//         when(dataset.getItemCount(0)).thenReturn(1);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(1000.0, new Rectangle2D.Double(), PlotOrientation.VERTICAL)).thenReturn(50.0);
//         when(domainAxis.valueToJava2D(2000.0, new Rectangle2D.Double(), PlotOrientation.VERTICAL)).thenReturn(150.0);
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
// 
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, new CrosshairState(), 0);
// 
//         // Assert
//         double expectedIntervalWidth = Math.abs(150.0 - 50.0);
//         double actualWidth = renderer.getCandleWidth();
//         assertEquals(expectedIntervalWidth, actualWidth, 0.001, "Candle width should be based on interval data");
//     }
// 
//     @Test
//     @DisplayName("drawItem handles candleWidth > 0 without auto-sizing")
//     public void TC07_drawItem_FixedCandleWidth() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer(10.0);
//         renderer.setMaxCandleWidthInMilliseconds(72000000.0); // 20 hours
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(1100.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(900.0);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(1050.0);
//         when(dataset.getVolumeValue(0, 0)).thenReturn(500.0);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(1000.0, new Rectangle2D.Double(), PlotOrientation.VERTICAL)).thenReturn(50.0);
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
// 
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, new CrosshairState(), 0);
// 
//         // Assert
//         assertEquals(10.0, renderer.getCandleWidth(), 0.001, "Candle width should be fixed as specified");
//     }
// 
//     @Test
//     @DisplayName("drawItem handles maximum candle width constraint")
//     public void TC08_drawItem_MaxCandleWidth() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer(10000.0);
//         renderer.setMaxCandleWidthInMilliseconds(72000000.0); // 20 hours
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(1100.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(900.0);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(1050.0);
//         when(dataset.getVolumeValue(0, 0)).thenReturn(500.0);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(1000.0, new Rectangle2D.Double(), PlotOrientation.VERTICAL)).thenReturn(50.0);
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
// 
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, new CrosshairState(), 0);
// 
//         // Assert
//         assertEquals(72000000.0, renderer.getMaxCandleWidthInMilliseconds(), 0.001, "Candle width should be capped at maximum constraint");
//     }
// 
//     @Test
//     @DisplayName("drawItem processes volume when drawVolume is true")
//     public void TC09_drawItem_DrawVolume_True() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setDrawVolume(true);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(1100.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(900.0);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(1050.0);
//         when(dataset.getVolumeValue(0, 0)).thenReturn(500.0);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(1000.0, new Rectangle2D.Double(), PlotOrientation.VERTICAL)).thenReturn(50.0);
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
// 
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, new CrosshairState(), 0);
// 
//         // Assert
//         verify(g2).fill(any(Rectangle2D.class));
//     }
// 
//     @Test
//     @DisplayName("drawItem does not draw volume when drawVolume is false")
//     public void TC10_drawItem_DrawVolume_False() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setDrawVolume(false);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(1100.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(900.0);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1000.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(1050.0);
//         when(dataset.getVolumeValue(0, 0)).thenReturn(500.0);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(1000.0, new Rectangle2D.Double(), PlotOrientation.VERTICAL)).thenReturn(50.0);
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
// 
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, new CrosshairState(), 0);
// 
//         // Assert
//         verify(g2, never()).fill(any(Rectangle2D.class));
//     }
// }