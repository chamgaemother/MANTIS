package org.apache.commons.lang3.text;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.text.DateFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Test class for ExtendedMessageFormat.applyPattern method.
 */
public class ExtendedMessageFormat_applyPattern_1_2_Test {

    // Mock FormatFactory for DateFormat
    private static class DateFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(String name, String args, Locale locale) {
            return DateFormat.getDateInstance(DateFormat.SHORT, locale);
        }
    }

    // Mock FormatFactory for NumberFormat
    private static class NumberFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(String name, String args, Locale locale) {
            return NumberFormat.getInstance(locale);
        }
    }

    @Test
    @DisplayName("applyPattern with multiple iterations of the parsing loop, ensuring correct handling of each format element")
    void test_TC19_applyPattern_multiple_iterations() {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("date", new DateFormatFactory());
        registry.put("number", new NumberFormatFactory());

        ExtendedMessageFormat emf = new ExtendedMessageFormat("Date: {0,date}, Amount: {1,number}", Locale.getDefault(), registry);

        // WHEN
        emf.applyPattern("Date: {0,date}, Amount: {1,number}");

        // THEN
        Format[] formats = emf.getFormats();
        assertNotNull(formats, "Formats array should not be null");
        assertEquals(2, formats.length, "Formats array should have two elements");
        assertInstanceOf(DateFormat.class, formats[0], "First format should be an instance of DateFormat");
        assertInstanceOf(NumberFormat.class, formats[1], "Second format should be an instance of NumberFormat");
    }
}
