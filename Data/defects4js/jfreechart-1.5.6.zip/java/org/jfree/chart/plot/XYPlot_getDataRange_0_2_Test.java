package org.jfree.chart.plot;

import org.jfree.data.Range;
import org.jfree.chart.axis.ValueAxis;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

public class XYPlot_getDataRange_0_2_Test {

    @Test
    @DisplayName("getDataRange combines valid Range and null from two subplots")
    public void TC06() {
        // GIVEN
        Range expectedRange = new Range(0.0, 10.0);
        XYPlot plot1 = mock(XYPlot.class);
        XYPlot plot2 = mock(XYPlot.class);
        when(plot1.getDataRange(any(ValueAxis.class))).thenReturn(expectedRange);
        when(plot2.getDataRange(any(ValueAxis.class))).thenReturn(null);
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot();
        combinedPlot.add(plot1);
        combinedPlot.add(plot2);
        ValueAxis axis = mock(ValueAxis.class);

        // WHEN
        Range result = combinedPlot.getDataRange(axis);

        // THEN
        assertEquals(expectedRange, result);
    }

    @Test
    @DisplayName("getDataRange returns null when both subplots return null")
    public void TC07() {
        // GIVEN
        XYPlot plot1 = mock(XYPlot.class);
        XYPlot plot2 = mock(XYPlot.class);
        when(plot1.getDataRange(any(ValueAxis.class))).thenReturn(null);
        when(plot2.getDataRange(any(ValueAxis.class))).thenReturn(null);
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot();
        combinedPlot.add(plot1);
        combinedPlot.add(plot2);
        ValueAxis axis = mock(ValueAxis.class);

        // WHEN
        Range result = combinedPlot.getDataRange(axis);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("getDataRange combines multiple valid Ranges from three subplots")
    public void TC08() {
        // GIVEN
        Range range1 = new Range(0.0, 5.0);
        Range range2 = new Range(5.0, 10.0);
        Range range3 = new Range(10.0, 15.0);
        Range expectedCombinedRange = Range.combine(Range.combine(range1, range2), range3);
        XYPlot plot1 = mock(XYPlot.class);
        XYPlot plot2 = mock(XYPlot.class);
        XYPlot plot3 = mock(XYPlot.class);
        when(plot1.getDataRange(any(ValueAxis.class))).thenReturn(range1);
        when(plot2.getDataRange(any(ValueAxis.class))).thenReturn(range2);
        when(plot3.getDataRange(any(ValueAxis.class))).thenReturn(range3);
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot();
        combinedPlot.add(plot1);
        combinedPlot.add(plot2);
        combinedPlot.add(plot3);
        ValueAxis axis = mock(ValueAxis.class);

        // WHEN
        Range result = combinedPlot.getDataRange(axis);

        // THEN
        assertEquals(expectedCombinedRange, result);
    }

    @Test
    @DisplayName("getDataRange correctly handles axis being null")
    public void TC09() {
        // GIVEN
        Range range = new Range(-5.0, 5.0);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getDataRange(eq(null))).thenReturn(range);
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot();
        combinedPlot.add(plot);
        ValueAxis axis = null;

        // WHEN
        Range result = combinedPlot.getDataRange(axis);

        // THEN
        assertEquals(range, result);
    }

    @Test
    @DisplayName("getDataRange handles exception thrown by p.getDataRange(axis)")
    public void TC10() {
        // GIVEN
        XYPlot plot = mock(XYPlot.class);
        when(plot.getDataRange(any(ValueAxis.class))).thenThrow(new RuntimeException("Data range error"));
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot();
        combinedPlot.add(plot);
        ValueAxis axis = mock(ValueAxis.class);

        // WHEN & THEN
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            combinedPlot.getDataRange(axis);
        });
        assertEquals("Data range error", exception.getMessage());
    }
}
