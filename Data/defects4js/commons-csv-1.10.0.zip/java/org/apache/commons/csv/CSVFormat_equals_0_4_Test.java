package org.apache.commons.csv;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.QuoteMode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class CSVFormat_equals_0_4_Test {

//     @Test
//     @DisplayName("equals returns false when quoteCharacter differs")
//     void TC16() {
        // GIVEN
//         CSVFormat format1 = CSVFormat.DEFAULT.withQuote('"');
//         CSVFormat format2 = CSVFormat.DEFAULT.withQuote(''');
// 
        // WHEN
//         boolean result = format1.equals(format2);
// 
        // THEN
//         assertFalse(result);
//     }

    @Test
    @DisplayName("equals returns false when quoteMode differs")
    void TC17() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        CSVFormat format2 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when quotedNullString differs")
    void TC18() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setNullString("\"NULL\"").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setNullString("N/A").build();

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when recordSeparator differs")
    void TC19() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when skipHeaderRecord differs")
    void TC20() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
        CSVFormat format2 = CSVFormat.DEFAULT.withSkipHeaderRecord(false);

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result);
    }
}