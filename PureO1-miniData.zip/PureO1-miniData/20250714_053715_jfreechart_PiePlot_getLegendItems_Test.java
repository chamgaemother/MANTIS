package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Stroke;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.labels.PieToolTipGenerator;
import org.jfree.chart.urls.PieURLGenerator;
import org.jfree.data.general.DefaultPieDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PiePlotTest {

    private PiePlot<String> piePlot;
    private DefaultPieDataset<String> dataset;

    @BeforeEach
    void setUp() {
        dataset = new DefaultPieDataset<>();
        piePlot = new PiePlot<>(dataset);
    }

    @Test
    void testGetLegendItemsWithNullDataset() {
        piePlot.setDataset(null);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(0, legend.getItemCount());
    }

    @Test
    void testGetLegendItemsWithEmptyDataset() {
        legendSetup();
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(0, legend.getItemCount());
    }

    @Test
    void testGetLegendItemsWithOnlyNullValuesIncludeTrue() {
        piePlot.setIgnoreNullValues(false);
        dataset.setValue("A", null);
        dataset.setValue("B", null);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(2, legend.getItemCount());
        assertEquals("A", legend.get(0).getLabel());
        assertEquals("B", legend.get(1).getLabel());
    }

    @Test
    void testGetLegendItemsWithOnlyNullValuesIncludeFalse() {
        piePlot.setIgnoreNullValues(true);
        dataset.setValue("A", null);
        dataset.setValue("B", null);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(0, legend.getItemCount());
    }

    @Test
    void testGetLegendItemsWithOnlyZeroValuesIncludeTrue() {
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 0.0);
        dataset.setValue("B", 0.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(2, legend.getItemCount());
        assertEquals("A", legend.get(0).getLabel());
        assertEquals("B", legend.get(1).getLabel());
    }

    @Test
    void testGetLegendItemsWithOnlyZeroValuesIncludeFalse() {
        piePlot.setIgnoreZeroValues(true);
        dataset.setValue("A", 0.0);
        dataset.setValue("B", 0.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(0, legend.getItemCount());
    }

    @Test
    void testGetLegendItemsWithPositiveValues() {
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        dataset.setValue("B", 20.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(2, legend.getItemCount());
        assertEquals("A", legend.get(0).getLabel());
        assertEquals("B", legend.get(1).getLabel());
    }

    @Test
    void testGetLegendItemsWithNegativeValues() {
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", -10.0);
        dataset.setValue("B", -20.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(0, legend.getItemCount());
    }

    @Test
    void testGetLegendItemsWithMixedValues() {
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(true);
        dataset.setValue("A", null);
        dataset.setValue("B", 0.0);
        dataset.setValue("C", 15.0);
        dataset.setValue("D", -5.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(2, legend.getItemCount());
        assertEquals("A", legend.get(0).getLabel());
        assertEquals("C", legend.get(1).getLabel());
    }

    @Test
    void testGetLegendItemsWithLegendLabelGeneratorReturningNull() {
        piePlot.setLegendLabelGenerator((dataset, key) -> null);
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(0, legend.getItemCount());
    }

    @Test
    void testGetLegendItemsWithLegendLabelToolTipGenerator() {
        piePlot.setLegendLabelToolTipGenerator((dataset, key) -> "Tooltip for " + key);
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(1, legend.getItemCount());
        LegendItem item = legend.get(0);
        assertEquals("A", item.getLabel());
        assertEquals("Tooltip for A", item.getToolTipText());
    }

    @Test
    void testGetLegendItemsWithLegendLabelURLGenerator() {
        piePlot.setLegendLabelURLGenerator((dataset, key, pieIndex) -> "http://example.com/" + key);
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(1, legend.getItemCount());
        LegendItem item = legend.get(0);
        assertEquals("A", item.getLabel());
        assertEquals("http://example.com/A", item.getURLText());
    }

    @Test
    void testGetLegendItemsWithNullLabelGenerator() {
        piePlot.setLegendLabelGenerator(null);
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(0, legend.getItemCount());
    }

    @Test
    void testGetLegendItemsWithPartialNullLabels() {
        piePlot.setLegendLabelGenerator((dataset, key) -> key.equals("A") ? null : key);
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        dataset.setValue("B", 20.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(1, legend.getItemCount());
        assertEquals("B", legend.get(0).getLabel());
    }

    @Test
    void testGetLegendItemsWithGeneratedLabelAndPaint() {
        piePlot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(1, legend.getItemCount());
        LegendItem item = legend.get(0);
        assertEquals("A", item.getLabel());
        Paint paint = piePlot.lookupSectionPaint("A");
        assertEquals(paint, item.getFillPaint());
    }

    @Test
    void testGetLegendItemsWithGeneratedLabelAndOutline() {
        piePlot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
        piePlot.setSectionOutlinesVisible(true);
        piePlot.setSectionOutlinePaint("A", Color.RED);
        piePlot.setSectionOutlineStroke("A", new BasicStroke(2.0f));
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(1, legend.getItemCount());
        LegendItem item = legend.get(0);
        assertEquals(Color.RED, item.getOutlinePaint());
        assertEquals(new BasicStroke(2.0f), item.getOutlineStroke());
    }

    @Test
    void testGetLegendItemsWithLegendLabelURLAndToolTip() {
        piePlot.setLegendLabelToolTipGenerator((dataset, key) -> "Tooltip " + key);
        piePlot.setLegendLabelURLGenerator((dataset, key, pieIndex) -> "URL " + key);
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        LegendItem item = legend.get(0);
        assertEquals("Tooltip A", item.getToolTipText());
        assertEquals("URL A", item.getURLText());
    }

    @Test
    void testGetLegendItemsWithMultipleSections() {
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
        dataset.setValue("A", 10.0);
        dataset.setValue("B", 0.0);
        dataset.setValue("C", null);
        dataset.setValue("D", 20.0);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertNotNull(legend);
        assertEquals(4, legend.getItemCount());

        LegendItem itemA = legend.get(0);
        LegendItem itemB = legend.get(1);
        LegendItem itemC = legend.get(2);
        LegendItem itemD = legend.get(3);

        assertEquals("A", itemA.getLabel());
        assertEquals("B", itemB.getLabel());
        assertEquals("C", itemC.getLabel());
        assertEquals("D", itemD.getLabel());
    }

    @Test
    void testGetLegendItemsWithMixedGenerators() {
        piePlot.setLegendLabelGenerator((dataset, key) -> key);
        piePlot.setLegendLabelToolTipGenerator(null);
        piePlot.setLegendLabelURLGenerator(null);
        piePlot.setIgnoreNullValues(true);
        piePlot.setIgnoreZeroValues(true);
        dataset.setValue("A", 10.0);
        dataset.setValue("B", 0.0);
        dataset.setValue("C", null);
        LegendItemCollection legend = piePlot.getLegendItems();
        assertEquals(1, legend.getItemCount());
        LegendItem itemA = legend.get(0);
        assertEquals("A", itemA.getLabel());
        assertNull(itemA.getToolTipText());
        assertNull(itemA.getURLText());
    }

    private void legendSetup() {
        piePlot.setIgnoreNullValues(false);
        piePlot.setIgnoreZeroValues(false);
    }
}