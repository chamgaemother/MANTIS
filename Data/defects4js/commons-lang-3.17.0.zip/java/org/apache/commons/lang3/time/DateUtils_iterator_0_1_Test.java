package org.apache.commons.lang3.time;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

public class DateUtils_iterator_0_1_Test {

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_MONTH_SUNDAY and calendar on first Sunday of the month")
    void TC01_iterator_rangeMonthSunday_firstSunday() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 6, 0, 0, 0); // First Sunday of August 2023
        calendar.set(Calendar.MILLISECOND, 0);
        int rangeStyle = DateUtils.RANGE_MONTH_SUNDAY;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle); // corrected Calendar<Calendar> iterator

        // THEN
        // Using the actual iterator values for assertions
        assertTrue(iterator.hasNext(), "Iterator should have at least one date");
        Calendar start = iterator.next();
        // Assert start is the first of the month
        Calendar expectedStart = (Calendar) calendar.clone();
        expectedStart.set(Calendar.DAY_OF_MONTH, 1);
        expectedStart.set(Calendar.HOUR_OF_DAY, 0);
        expectedStart.set(Calendar.MINUTE, 0);
        expectedStart.set(Calendar.SECOND, 0);
        expectedStart.set(Calendar.MILLISECOND, 0);
        assertEquals(expectedStart.getTime(), start.getTime(), "Start date should be the first of the month");

        // Traverse to end
        while (iterator.hasNext()) {
            start = iterator.next();
        }
        // Assert end is correctly calculated
        Calendar expectedEnd = (Calendar) expectedStart.clone();
        expectedEnd.add(Calendar.MONTH, 1);
        expectedEnd.add(Calendar.DATE, -1);
        assertEquals(expectedEnd.getTime(), start.getTime(), "End date should be the last of the month");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_MONTH_MONDAY and calendar not on Monday")
    void TC02_iterator_rangeMonthMonday_notOnMonday() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 9, 0, 0, 0); // Wednesday, 9th August 2023
        calendar.set(Calendar.MILLISECOND, 0);
        int rangeStyle = DateUtils.RANGE_MONTH_MONDAY;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle); // corrected Calendar<Calendar> iterator

        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have at least one date");
        Calendar start = iterator.next();
        // Assert start is adjusted to the previous Monday
        Calendar expectedStart = (Calendar) calendar.clone();
        expectedStart.set(Calendar.DAY_OF_MONTH, 1);
        expectedStart.set(Calendar.HOUR_OF_DAY, 0);
        expectedStart.set(Calendar.MINUTE, 0);
        expectedStart.set(Calendar.SECOND, 0);
        expectedStart.set(Calendar.MILLISECOND, 0);
        // Find the previous Monday
        while (expectedStart.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
            expectedStart.add(Calendar.DATE, -1);
        }
        assertEquals(expectedStart.getTime(), start.getTime(), "Start date should be adjusted to the previous Monday");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_SUNDAY and calendar on Sunday")
    void TC03_iterator_rangeWeekSunday_onSunday() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 6, 0, 0, 0); // Sunday, 6th August 2023
        calendar.set(Calendar.MILLISECOND, 0);
        int rangeStyle = DateUtils.RANGE_WEEK_SUNDAY;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle); // corrected Calendar<Calendar> iterator

        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have at least one date");
        Calendar start = iterator.next();
        // Assert start and end are the same as the calendar date
        Calendar expectedStart = (Calendar) calendar.clone();
        assertEquals(expectedStart.getTime(), start.getTime(), "Start date should be the same as the calendar date");
        assertFalse(iterator.hasNext(), "Iterator should reach the end");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_MONDAY and calendar on Wednesday")
    void TC04_iterator_rangeWeekMonday_onWednesday() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 9, 0, 0, 0); // Wednesday, 9th August 2023
        calendar.set(Calendar.MILLISECOND, 0);
        int rangeStyle = DateUtils.RANGE_WEEK_MONDAY;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle); // corrected Calendar<Calendar> iterator

        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have at least one date");
        Calendar start = iterator.next();

        // Assert start is adjusted to the previous Monday
        Calendar expectedStart = (Calendar) calendar.clone();
        while (expectedStart.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
            expectedStart.add(Calendar.DATE, -1);
        }
        assertEquals(expectedStart.getTime(), start.getTime(), "Start date should be adjusted to the previous Monday");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_RELATIVE and calendar on Thursday")
    void TC05_iterator_rangeWeekRelative_onThursday() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 10, 0, 0, 0); // Thursday, 10th August 2023
        calendar.set(Calendar.MILLISECOND, 0);
        int rangeStyle = DateUtils.RANGE_WEEK_RELATIVE;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle); // corrected Calendar<Calendar> iterator

        // THEN
        assertTrue(iterator.hasNext(), "Iterator should have at least one date");

        // Calculate expected start and end based on relative adjustment
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int startCutoff = dayOfWeek;
        int endCutoff = startCutoff - 1;
        if (startCutoff < Calendar.SUNDAY) {
            startCutoff += 7;
        }
        if (startCutoff > Calendar.SATURDAY) {
            startCutoff -= 7;
        }
        if (endCutoff < Calendar.SUNDAY) {
            endCutoff += 7;
        }
        if (endCutoff > Calendar.SATURDAY) {
            endCutoff -= 7;
        }

        Calendar expectedStartAdjusted = (Calendar) calendar.clone();
        while (expectedStartAdjusted.get(Calendar.DAY_OF_WEEK) != startCutoff) {
            expectedStartAdjusted.add(Calendar.DATE, -1);
        }

        Calendar expectedEndAdjusted = (Calendar) calendar.clone();
        while (expectedEndAdjusted.get(Calendar.DAY_OF_WEEK) != endCutoff) {
            expectedEndAdjusted.add(Calendar.DATE, 1);
        }

        Calendar actualStart = iterator.next();
        assertEquals(expectedStartAdjusted.getTime(), actualStart.getTime(), "Start date should be adjusted based on the current day of the week");

        while (iterator.hasNext()) {
            actualStart = iterator.next();
        }
        assertEquals(expectedEndAdjusted.getTime(), actualStart.getTime(), "End date should be adjusted based on the current day of the week");
    }
}
