package com.fasterxml.jackson.databind.cfg;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.type.LogicalType;

public class CoercionConfigs_findCoercion_1_1_Test {

    @Test
    @DisplayName("Returns CoercionAction.Fail when _defaultCoercions.findAction is null and DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT is disabled for structured type")
    public void TC25() throws Exception {
        // GIVEN
        CoercionConfigs coercionConfigs = new CoercionConfigs();

        // Use reflection to set _perClassCoercions and _perTypeCoercions to null
        Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
        perClassField.setAccessible(true);
        perClassField.set(coercionConfigs, null);

        Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
        perTypeField.setAccessible(true);
        perTypeField.set(coercionConfigs, null);

        // Mock DeserializationConfig with ACCEPT_EMPTY_STRING_AS_NULL_OBJECT disabled
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)).thenReturn(false);

        LogicalType targetType = LogicalType.Map;
        CoercionInputShape inputShape = CoercionInputShape.EmptyString;

        // WHEN
        CoercionAction result = coercionConfigs.findCoercion(config, targetType, null, inputShape);

        // THEN
        assertEquals(CoercionAction.Fail, result);
    }

    @Test
    @DisplayName("Returns CoercionAction.AsNull when _defaultCoercions.findAction is null and DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT is enabled for OtherScalar type")
    public void TC26() throws Exception {
        // GIVEN
        CoercionConfigs coercionConfigs = new CoercionConfigs();

        // Use reflection to set _perClassCoercions and _perTypeCoercions to null
        Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
        perClassField.setAccessible(true);
        perClassField.set(coercionConfigs, null);

        Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
        perTypeField.setAccessible(true);
        perTypeField.set(coercionConfigs, null);

        // Mock DeserializationConfig with ACCEPT_EMPTY_STRING_AS_NULL_OBJECT enabled
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)).thenReturn(true);

        LogicalType targetType = LogicalType.OtherScalar;
        CoercionInputShape inputShape = CoercionInputShape.EmptyString;

        // WHEN
        CoercionAction result = coercionConfigs.findCoercion(config, targetType, null, inputShape);

        // THEN
        assertEquals(CoercionAction.AsNull, result);
    }
}