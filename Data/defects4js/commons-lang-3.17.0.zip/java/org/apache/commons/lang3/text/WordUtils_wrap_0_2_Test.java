package org.apache.commons.lang3.text;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WordUtils_wrap_0_2_Test {

    @Test
    @DisplayName("wrap handles string with no wrap delimiters and wrapLongWords=true by breaking words")
    void TC06_wrap_handles_string_with_no_wrap_delimiters_wrapLongWords_true() {
        // GIVEN
        String str = "Supercalifragilisticexpialidocious";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ",";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "Supercalif\nragilistic\nexpialidoc\nious";
        assertEquals(expected, result, "The long word should be broken at every 10 characters.");
    }

    @Test
    @DisplayName("wrap handles string with no wrap delimiters and wrapLongWords=false by not breaking long words")
    void TC07_wrap_handles_string_with_no_wrap_delimiters_wrapLongWords_false() {
        // GIVEN
        String str = "Supercalifragilisticexpialidocious";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = false;
        String wrapOn = ",";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        assertFalse(result.contains(newLineStr), "Result should not contain any line breaks within the long word.");
        assertTrue(result.length() > wrapLength, "The long word should extend beyond the wrap length without breaks.");
    }

    @Test
    @DisplayName("wrap handles input string exactly equal to wrapLength with no further wrapping")
    void TC08_wrap_handles_input_string_exactly_equal_to_wrapLength() {
        // GIVEN
        String str = "abcdefghij"; // 10 characters
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = " ";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        assertEquals(str, result, "No wrapping should occur as string length equals wrapLength.");
    }

    @Test
    @DisplayName("wrap handles empty string input by returning empty string")
    void TC09_wrap_handles_empty_string_input() {
        // GIVEN
        String str = "";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = " ";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        assertEquals("", result, "The result should be an empty string.");
    }

    @Test
    @DisplayName("wrap handles single word shorter than wrapLength without wrapping")
    void TC10_wrap_handles_single_word_shorter_than_wrapLength() {
        // GIVEN
        String str = "Hello";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = " ";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        assertEquals("Hello", result, "No wrapping should occur as the word is shorter than wrapLength.");
    }
}