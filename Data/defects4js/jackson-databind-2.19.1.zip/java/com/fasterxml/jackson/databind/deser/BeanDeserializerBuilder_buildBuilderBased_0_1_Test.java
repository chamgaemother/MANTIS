package com.fasterxml.jackson.databind.deser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;

import java.lang.reflect.Field;

public class BeanDeserializerBuilder_buildBuilderBased_0_1_Test {

    @Test
    @DisplayName("_buildMethod is null and expBuildMethodName is empty, proceeds without reporting bad definition")
    void TC01_buildMethodNull_noReport() throws Exception {
        // GIVEN
        BeanDescription mockBeanDesc = mock(BeanDescription.class);
        DeserializationContext mockContext = mock(DeserializationContext.class);
        DeserializationConfig mockConfig = mock(DeserializationConfig.class);
        when(mockContext.getConfig()).thenReturn(mockConfig);
        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
        
        // Use reflection to set _buildMethod to null
        Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
        buildMethodField.setAccessible(true);
        buildMethodField.set(builder, null);
        
        JavaType javaType = mock(JavaType.class);
        
        // WHEN
        JsonDeserializer<?> deserializer = builder.buildBuilderBased(javaType, "");
        
        // THEN
        assertNotNull(deserializer);
    }

    @Test
    @DisplayName("_buildMethod is null and expBuildMethodName is not empty, reports bad definition")
    void TC02_buildMethodNull_withExpName_reportsBadDefinition() throws Exception {
        // GIVEN
        BeanDescription mockBeanDesc = mock(BeanDescription.class);
        DeserializationContext mockContext = mock(DeserializationContext.class);
        DeserializationConfig mockConfig = mock(DeserializationConfig.class);
        when(mockContext.getConfig()).thenReturn(mockConfig);
        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
        
        // Use reflection to set _buildMethod to null
        Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
        buildMethodField.setAccessible(true);
        buildMethodField.set(builder, null);
        
        // Mock behavior for context
        JavaType mockJavaType = mock(JavaType.class);
        when(mockBeanDesc.getType()).thenReturn(mockJavaType);
        doNothing().when(mockContext).reportBadDefinition(any(JavaType.class), anyString());

        // WHEN
        builder.buildBuilderBased(mockJavaType, "build");
        
        // THEN
        verify(mockContext, times(1)).reportBadDefinition(any(JavaType.class), anyString());
    }

//     @Test
//     @DisplayName("_buildMethod is present and its return type equals valueType")
//     void TC03_buildMethodPresent_returnTypeEquals() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         DeserializationContext mockContext = mock(DeserializationContext.class);
//         DeserializationConfig mockConfig = mock(DeserializationConfig.class);
//         when(mockContext.getConfig()).thenReturn(mockConfig);
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
//         
//         AnnotatedMethod buildMethod = mock(AnnotatedMethod.class);
//         when(buildMethod.getRawReturnType()).thenReturn(Object.class); 
//         
        // Use reflection to set _buildMethod
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, buildMethod);
//         
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(Object.class);
//         
        // WHEN
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");
//         
        // THEN
//         assertNotNull(deserializer);
//     }

//     @Test
//     @DisplayName("_buildMethod is present and its return type is assignable from valueType")
//     void TC04_buildMethodPresent_returnTypeAssignableFrom() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         DeserializationContext mockContext = mock(DeserializationContext.class);
//         DeserializationConfig mockConfig = mock(DeserializationConfig.class);
//         when(mockContext.getConfig()).thenReturn(mockConfig);
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
//         
//         AnnotatedMethod buildMethod = mock(AnnotatedMethod.class);
//         Class<?> buildReturnType = Number.class;
//         when(buildMethod.getRawReturnType()).thenReturn(buildReturnType);
//         
        // Use reflection to set _buildMethod
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, buildMethod);
//         
//         JavaType subTypeJavaType = mock(JavaType.class);
//         when(subTypeJavaType.getRawClass()).thenReturn(Integer.class); 
//         
        // WHEN
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(subTypeJavaType, "build");
//         
        // THEN
//         assertNotNull(deserializer);
//     }

//     @Test
//     @DisplayName("_buildMethod is present and valueType is assignable from build method's return type")
//     void TC05_buildMethodPresent_valueTypeAssignableFrom() throws Exception {
        // GIVEN
//         BeanDescription mockBeanDesc = mock(BeanDescription.class);
//         DeserializationContext mockContext = mock(DeserializationContext.class);
//         DeserializationConfig mockConfig = mock(DeserializationConfig.class);
//         when(mockContext.getConfig()).thenReturn(mockConfig);
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mockBeanDesc, mockContext);
//         
//         AnnotatedMethod buildMethod = mock(AnnotatedMethod.class);
//         Class<?> buildReturnType = Integer.class;
//         when(buildMethod.getRawReturnType()).thenReturn(buildReturnType);
//         
        // Use reflection to set _buildMethod
//         Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
//         buildMethodField.setAccessible(true);
//         buildMethodField.set(builder, buildMethod);
//         
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(Number.class);
//         
        // WHEN
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");
//         
        // THEN
//         assertNotNull(deserializer);
//     }
}