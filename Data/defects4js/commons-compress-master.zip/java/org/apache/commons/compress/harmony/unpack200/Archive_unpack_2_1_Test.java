package org.apache.commons.compress.harmony.unpack200;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.InputStream;
import java.util.jar.JarOutputStream;

import org.apache.commons.compress.harmony.pack200.Pack200Exception;

public class Archive_unpack_2_1_Test {

    @Test
    @DisplayName("InputStream does not support mark initially and remains unsupported after wrapping, leading to IllegalStateException")
    void TC29_Unpack_InputStreamMarkUnsupported_ThrowsIllegalStateException() throws Exception {
        // Arrange
        InputStream nonMarkSupportedStream = new FilterInputStream(new ByteArrayInputStream(new byte[0])) {
            @Override
            public boolean markSupported() {
                return false;
            }
        };
        // Override BufferedInputStream to not support mark
        InputStream customBufferedStream = new FilterInputStream(nonMarkSupportedStream) {
            @Override
            public boolean markSupported() {
                return false;
            }
        };
        JarOutputStream outputStream = new JarOutputStream(new ByteArrayOutputStream());
        
        Archive archive = new Archive(customBufferedStream, outputStream);
        
        // Act & Assert
        Assertions.assertThrows(IllegalStateException.class, () -> {
            archive.unpack();
        });
    }

    @Test
    @DisplayName("InputStream does not support mark initially but supports after wrapping with BufferedInputStream and GZIPInputStream")
    void TC30_Unpack_InputStreamWrappedWithBufferedAndGZIP_CompletesSuccessfully() throws Exception {
        // Arrange
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        // Write GZIP_MAGIC bytes
        byteStream.write(new byte[]{(byte)0x1F, (byte)0x8B, 3, 0});
        InputStream byteArrayInputStream = new ByteArrayInputStream(byteStream.toByteArray());
        JarOutputStream outputStream = new JarOutputStream(new ByteArrayOutputStream());
        
        Archive archive = new Archive(byteArrayInputStream, outputStream);
        
        // Act & Assert
        Assertions.assertDoesNotThrow(() -> {
            archive.unpack();
        });
    }

    @Test
    @DisplayName("Magic bytes do not match, leading to processing as original Jar with multiple JarEntries")
    void TC31_Unpack_MagicBytesMismatch_ProcessesOriginalJar() throws Exception {
        // Arrange
        byte[] mockData = {(byte)0x50, (byte)0x4B, (byte)0x03, (byte)0x04}; // ZIP file header
        InputStream inputStream = new ByteArrayInputStream(mockData);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        JarOutputStream outputStream = new JarOutputStream(byteArrayOutputStream);
        Archive archive = new Archive(inputStream, outputStream);
        
        // Act
        archive.unpack();
        
        // Assert
        Assertions.assertTrue(byteArrayOutputStream.size() > 0, "OutputStream should have data after unpacking non-magic byte stream.");
    }

    @Test
    @DisplayName("Magic bytes match and 'compressedWithE0' is false, processing multiple segments")
    void TC32_Unpack_MagicBytesMatch_MultipleSegmentsProcessed() throws Exception {
        // Arrange
        byte[] magicBytes = {(byte)0xCA, (byte)0xFE, (byte)0xD0, (byte)0x0D};
        byte[] segmentData = {0x01, 0x02, 0x03, 0x04}; // Mock segment data
        ByteArrayOutputStream combinedStream = new ByteArrayOutputStream();
        combinedStream.write(magicBytes);
        combinedStream.write(segmentData);
        InputStream inputStream = new ByteArrayInputStream(combinedStream.toByteArray());
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        JarOutputStream outputStream = new JarOutputStream(byteArrayOutputStream);
        Archive archive = new Archive(inputStream, outputStream);
        
        // Act
        archive.unpack();
        
        // Assert
        Assertions.assertTrue(byteArrayOutputStream.size() > 0, "OutputStream should have data after processing multiple segments.");
    }

    @Test
    @DisplayName("Handling zero iterations in loop when no data segments are available")
    void TC33_Unpack_MagicBytesMatch_NoSegmentsProcessed() throws Exception {
        // Arrange
        byte[] magicBytes = {(byte)0xCA, (byte)0xFE, (byte)0xD0, (byte)0x0D};
        InputStream inputStream = new ByteArrayInputStream(magicBytes);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        JarOutputStream outputStream = new JarOutputStream(byteArrayOutputStream);
        Archive archive = new Archive(inputStream, outputStream);
        
        // Act
        archive.unpack();
        
        // Assert
        Assertions.assertEquals(0, byteArrayOutputStream.size(), "OutputStream should have no data when no segments are processed.");
    }
}
