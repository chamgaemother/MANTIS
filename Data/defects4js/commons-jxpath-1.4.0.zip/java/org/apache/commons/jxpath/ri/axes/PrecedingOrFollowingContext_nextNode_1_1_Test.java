//package org.apache.commons.jxpath.ri.axes;
//
//import org.apache.commons.jxpath.ri.EvalContext;
//import org.apache.commons.jxpath.ri.compiler.NodeTest;
//import org.apache.commons.jxpath.ri.model.NodeIterator;
//import org.apache.commons.jxpath.ri.model.NodePointer;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//
//import java.lang.reflect.Field;
//import java.lang.reflect.Method;
//import java.util.Stack;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//public class PrecedingOrFollowingContext_nextNode_1_1_Test {
//
//    @Test
//    @DisplayName("nextNode() with setStarted=true, stack not empty, reverse=true, setPosition returns false, and stack is popped")
//    public void TC17_nextNode_setStartedTrue_stackNotEmpty_reverseTrue_setPositionFalse() throws Exception {
//        // Arrange
//        PrecedingOrFollowingContext context = createContext(true, true);
//
//        // Mock NodeIterator where setPosition returns false
//        NodeIterator mockIterator = mock(NodeIterator.class);
//        when(mockIterator.setPosition(anyInt())).thenReturn(false);
//
//        // Set the stack with the mocked iterator
//        setPrivateField(context, "stack", new Stack<NodeIterator>());
//        Stack<NodeIterator> stack = (Stack<NodeIterator>) getPrivateField(context, "stack");
//        stack.push(mockIterator);
//
//        // Act
//        boolean result = context.nextNode();
//
//        // Assert
//        assertFalse(result);
//    }
//
//    @Test
//    @DisplayName("nextNode() with setStarted=true, stack not empty, reverse=false, nodeTest fails and iterator is popped")
//    public void TC18_nextNode_setStartedTrue_stackNotEmpty_reverseFalse_nodeTestFails() throws Exception {
//        // Arrange
//        PrecedingOrFollowingContext context = createContext(true, false);
//
//        // Mock NodeIterator where nodeTest fails
//        NodeIterator mockIterator = mock(NodeIterator.class);
//        when(mockIterator.setPosition(anyInt())).thenReturn(true);
//        NodePointer mockNodePointer = mock(NodePointer.class);
//        when(mockIterator.getNodePointer()).thenReturn(mockNodePointer);
//        when(mockNodePointer.isLeaf()).thenReturn(true);
//        when(mockNodePointer.testNode(any(NodeTest.class))).thenReturn(false);
//
//        // Set the stack with the mocked iterator
//        setPrivateField(context, "stack", new Stack<NodeIterator>());
//        Stack<NodeIterator> stack = (Stack<NodeIterator>) getPrivateField(context, "stack");
//        stack.push(mockIterator);
//
//        // Act
//        boolean result = context.nextNode();
//
//        // Assert
//        assertFalse(result);
//    }
//
////    @Test
////    @DisplayName("nextNode() with setStarted=true, stack empty, and currentRootLocation is not root")
////    public void TC19_nextNode_setStartedTrue_stackEmpty_currentRootNotRoot() throws Exception {
////        // Arrange
////        PrecedingOrFollowingContext context = createContext(true, false);
////
////        // Ensure stack is empty
////        setPrivateField(context, "stack", new Stack<NodeIterator>());
////        Stack<NodeIterator> stack = (Stack<NodeIterator>) getPrivateField(context, "stack");
////        assertTrue(stack.isEmpty());
////
////        // Mock currentRootLocation to have a parent and not be root
////        NodePointer mockRootLocation = mock(NodePointer.class);
////        when(mockRootLocation.getParent()).thenReturn(mock(NodePointer.class));
////        when(mockRootLocation.isRoot()).thenReturn(false);
////        setPrivateField(context, "currentRootLocation", mockRootLocation);
////
////        // Act
////        boolean result = context.nextNode();
////
////        // Assert
////        // Depending on implementation, verify internal state or behavior
////        // Here we check that the method does not return prematurely
////        assertFalse(result); // Assuming no valid nodes are found
////    }
//
//    @Test
//    @DisplayName("nextNode() with setStarted=true, reverse=true, multiple iterators with varying setPosition outcomes")
//    public void TC20_nextNode_setStartedTrue_reverseTrue_multipleIterators_varyingSetPosition() throws Exception {
//        // Arrange
//        PrecedingOrFollowingContext context = createContext(true, true);
//
//        // Mock first NodeIterator returning true on setPosition
//        NodeIterator mockIterator1 = mock(NodeIterator.class);
//        when(mockIterator1.setPosition(anyInt())).thenReturn(true);
//        NodePointer mockNodePointer1 = mock(NodePointer.class);
//        when(mockIterator1.getNodePointer()).thenReturn(mockNodePointer1);
//        when(mockNodePointer1.isLeaf()).thenReturn(false);
//        when(mockNodePointer1.testNode(any(NodeTest.class))).thenReturn(true);
//
//        // Mock second NodeIterator returning false on setPosition
//        NodeIterator mockIterator2 = mock(NodeIterator.class);
//        when(mockIterator2.setPosition(anyInt())).thenReturn(false);
//
//        // Set the stack with multiple iterators
//        setPrivateField(context, "stack", new Stack<NodeIterator>());
//        Stack<NodeIterator> stack = (Stack<NodeIterator>) getPrivateField(context, "stack");
//        stack.push(mockIterator1);
//        stack.push(mockIterator2);
//
//        // Act
//        boolean result = context.nextNode();
//
//        // Assert
//        assertTrue(result);
//    }
//
//    @Test
//    @DisplayName("nextNode() with setStarted=true, stack not empty, reverse=false, nodeTest passes on nested iterator")
//    public void TC21_nextNode_setStartedTrue_stackNotEmpty_reverseFalse_nodeTestPassesNested() throws Exception {
//        // Arrange
//        PrecedingOrFollowingContext context = createContext(true, false);
//
//        // Mock parent NodeIterator
//        NodeIterator parentIterator = mock(NodeIterator.class);
//        when(parentIterator.setPosition(anyInt())).thenReturn(true);
//        NodePointer parentNodePointer = mock(NodePointer.class);
//        when(parentIterator.getNodePointer()).thenReturn(parentNodePointer);
//        when(parentNodePointer.isLeaf()).thenReturn(false);
//
//        // Mock child NodeIterator where nodeTest passes
//        NodeIterator childIterator = mock(NodeIterator.class);
//        when(childIterator.setPosition(anyInt())).thenReturn(true);
//        NodePointer childNodePointer = mock(NodePointer.class);
//        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
//        when(childNodePointer.isLeaf()).thenReturn(true);
//        when(childNodePointer.testNode(any(NodeTest.class))).thenReturn(true);
//
//        // Mock childIterator creation
//        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
//
//        // Set the stack with the parent iterator
//        setPrivateField(context, "stack", new Stack<NodeIterator>());
//        Stack<NodeIterator> stack = (Stack<NodeIterator>) getPrivateField(context, "stack");
//        stack.push(parentIterator);
//
//        // Act
//        boolean result = context.nextNode();
//
//        // Assert
//        assertTrue(result);
//    }
//
//    // Helper method to create and initialize PrecedingOrFollowingContext
//    private PrecedingOrFollowingContext createContext(boolean setStarted, boolean reverse) throws Exception {
//        // Mock parent EvalContext
//        EvalContext parentContext = mock(EvalContext.class);
//        NodePointer mockCurrentNodePointer = mock(NodePointer.class);
//        when(parentContext.getCurrentNodePointer()).thenReturn(mockCurrentNodePointer);
//
//        // Mock NodeTest
//        NodeTest mockNodeTest = mock(NodeTest.class);
//
//        // Create instance using reflection
//        PrecedingOrFollowingContext context = new PrecedingOrFollowingContext(parentContext, mockNodeTest, reverse);
//
//        // Set setStarted field
//        setPrivateField(context, "setStarted", setStarted);
//
//        return context;
//    }
//
//    // Helper method to set private fields via reflection
//    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
//        Field field = getField(target.getClass(), fieldName);
//        field.setAccessible(true);
//        field.set(target, value);
//    }
//
//    // Helper method to get private fields via reflection
//    private Object getPrivateField(Object target, String fieldName) throws Exception {
//        Field field = getField(target.getClass(), fieldName);
//        field.setAccessible(true);
//        return field.get(target);
//    }
//
//    // Helper method to retrieve Field object, including superclass fields
//    private Field getField(Class<?> clazz, String fieldName) throws NoSuchFieldException {
//        Class<?> current = clazz;
//        while (current != null) {
//            try {
//                return current.getDeclaredField(fieldName);
//            } catch (NoSuchFieldException e) {
//                current = current.getSuperclass();
//            }
//        }
//        throw new NoSuchFieldException("Field '" + fieldName + "' not found in class hierarchy of " + clazz.getName());
//    }
//}