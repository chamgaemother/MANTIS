package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_sqrt_0_3_Test {

    @Test
    @DisplayName("sqrt() with mantissa last digit divided by 2000 equals 3 applies case 3 in switch")
    void TC11_sqrt_switch_case3() throws Exception {
        // Arrange
        DfpField field = new DfpField(128);
        Dfp input = new Dfp(field, 4.0);

        // Access and modify private fields via reflection
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length - 1] = 2200; // Ensure mant[last] / 2000 == 3

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Assert
        int[] resultMant = (int[]) mantField.get(result);
        assertEquals(2200, resultMant[resultMant.length -1], "mantissa last digit should be set to 2200");
    }

    @Test
    @DisplayName("sqrt() with mantissa last digit divided by 2000 not matching any case applies default case")
    void TC12_sqrt_switch_default_case() throws Exception {
        // Arrange
        DfpField field = new DfpField(128);
        Dfp input = new Dfp(field, 5.0);

        // Access and modify private fields via reflection
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length - 1] = 2500; // Ensure mant[last] / 2000 does not match 0,2,3

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Assert
        int[] resultMant = (int[]) mantField.get(result);
        assertEquals(3000, resultMant[resultMant.length -1], "mantissa last digit should be set to 3000");
    }

    @Test
    @DisplayName("sqrt() loop terminates immediately when x equals px (no iterations)")
    void TC13_sqrt_loop_zero_iterations() throws Exception {
        // Arrange
        DfpField field = new DfpField(128);
        Dfp input = new Dfp(field, 9.0);

        // Access and modify private fields via reflection to set x equals px
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        for(int i = 0; i < mant.length; i++) {
            mant[i] = 1000; // Setting a fixed mantissa
        }

        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(input, 0);

        // Act
        Dfp result = input.sqrt();

        // Assert
        assertEquals(input, result, "Loop does not execute and returns initial x");
    }

    @Test
    @DisplayName("sqrt() loop executes once and then terminates")
    void TC14_sqrt_loop_single_iteration() throws Exception {
        // Arrange
        DfpField field = new DfpField(128);
        Dfp input = new Dfp(field, 16.0);

        // Access and modify private fields via reflection to allow one iteration
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length -1] = 2000; // Setup mant[last] / 2000 == 1, default case

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Assert
        int[] resultMant = (int[]) mantField.get(result);
        assertEquals(3000, resultMant[resultMant.length -1], "mantissa last digit should be set to 3000 after one iteration");
    }

    @Test
    @DisplayName("sqrt() loop executes multiple iterations and then terminates due to x.equals(ppx)")
    void TC15_sqrt_loop_multiple_iterations_convergence() throws Exception {
        // Arrange
        DfpField field = new DfpField(128);
        Dfp input = new Dfp(field, 25.0);

        // Access and modify private fields via reflection to allow multiple iterations
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(input);
        mant[mant.length -1] = 3000; // Setup mant[last] / 2000 == 1.5, default case

        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(input, (byte)0); // FINITE

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // Act
        Dfp result = input.sqrt();

        // Assert
        // For demonstration, we assume the sqrt of 25 is 5. Verify mantissa is set correctly
        // In a real scenario, more detailed checks would be necessary
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        int resultExp = expField.getInt(result);
        assertEquals(0, resultExp, "Exponent should be adjusted correctly after convergence");
    }
}