package org.apache.commons.math3.stat.correlation;

import org.apache.commons.math3.stat.correlation.KendallsCorrelation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class KendallsCorrelation_correlation_2_1_Test {

    @Test
    @DisplayName("correlation correctly handles xArray containing NaN values")
    void TC25() {
        // GIVEN
        double[] xArray = {1.0, Double.NaN, 3.0};
        double[] yArray = {1.0, 2.0, 3.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("correlation correctly handles yArray containing NaN values")
    void TC26() {
        // GIVEN
        double[] xArray = {1.0, 2.0, 3.0};
        double[] yArray = {1.0, Double.NaN, 3.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("correlation correctly handles xArray containing positive Infinity")
    void TC27() {
        // GIVEN
        double[] xArray = {1.0, Double.POSITIVE_INFINITY, 3.0};
        double[] yArray = {1.0, 2.0, 3.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("correlation correctly handles yArray containing negative Infinity")
    void TC28() {
        // GIVEN
        double[] xArray = {1.0, 2.0, 3.0};
        double[] yArray = {1.0, Double.NEGATIVE_INFINITY, 3.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("correlation correctly handles xArray and yArray containing both NaN and Infinity values")
    void TC29() {
        // GIVEN
        double[] xArray = {1.0, Double.NaN, 3.0};
        double[] yArray = {Double.POSITIVE_INFINITY, 2.0, Double.NEGATIVE_INFINITY};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertTrue(Double.isNaN(result));
    }
}