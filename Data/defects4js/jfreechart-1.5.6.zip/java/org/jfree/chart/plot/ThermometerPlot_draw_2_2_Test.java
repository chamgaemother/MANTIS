package org.jfree.chart.plot;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;

public class ThermometerPlot_draw_2_2_Test {

    @Test
    @DisplayName("Draw method with dataset value exactly at NORMAL-WARNING boundary sets mercury color to WARNING")
    void TC16_Draw_Mercury_Color_Warning_Boundary() throws Exception {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        ValueDataset dataset = new DefaultValueDataset(50.0);
        plot.setDataset(dataset);
        plot.setUseSubrangePaint(true);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 50.0);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 75.0);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75.0, 100.0);
        
        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        plot.draw(g2, area, anchor, state, info);
        
        // THEN
        verify(g2).setPaint(Color.ORANGE);
        verify(g2).fill(any(Area.class));
    }

    @Test
    @DisplayName("Draw method with followDataInSubranges=true and dataset value within WARNING subrange adjusts axis range accordingly")
    void TC17_Draw_FollowDataInSubranges_Adjusts_Axis_Range() throws Exception {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        ValueDataset dataset = new DefaultValueDataset(60.0);
        plot.setDataset(dataset);
        plot.setFollowDataInSubranges(true);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 50.0);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 75.0);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75.0, 100.0);
        
        // Mock the range axis to verify its range after drawing
        NumberAxis rangeAxis = new NumberAxis();
        plot.setRangeAxis(rangeAxis);
        
        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        plot.draw(g2, area, anchor, state, info);
        
        // THEN
        Range expectedRange = new Range(50.0, 75.0);
        Range actualRange = rangeAxis.getRange();
        org.junit.jupiter.api.Assertions.assertEquals(expectedRange, actualRange, "Axis range should be adjusted to WARNING subrange");
    }

    @Test
    @DisplayName("Draw method with axisLocation=RIGHT draws range axis on the right side")
    void TC18_Draw_Axis_Location_Right() throws Exception {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        ValueDataset dataset = new DefaultValueDataset(75.0);
        plot.setDataset(dataset);
        plot.setAxisLocation(ThermometerPlot.RIGHT);
        
        // Mock the range axis
        NumberAxis rangeAxis = new NumberAxis();
        plot.setRangeAxis(rangeAxis);
        
        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        when(area.getMinY()).thenReturn(0.0);
        when(area.getMaxY()).thenReturn(100.0);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        plot.draw(g2, area, anchor, state, info);
        
        // THEN
        // Verify that rangeAxis.draw is called with RectangleEdge.RIGHT
        Mockito.verify(rangeAxis).draw(Mockito.eq(g2), Mockito.anyDouble(), Mockito.eq(area), Mockito.any(Rectangle2D.class), Mockito.eq(RectangleEdge.RIGHT), Mockito.isNull());
    }

    @Test
    @DisplayName("Draw method with overlapping subranges ensures correct mercury color based on highest priority subrange")
    void TC19_Draw_Overlapping_Subranges_Mercury_Color_Priority() throws Exception {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        ValueDataset dataset = new DefaultValueDataset(55.0);
        plot.setDataset(dataset);
        plot.setUseSubrangePaint(true);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 60.0);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 70.0);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 65.0, 80.0);

        // Set subrange paints
        plot.setSubrangePaint(ThermometerPlot.NORMAL, Color.GREEN);
        plot.setSubrangePaint(ThermometerPlot.WARNING, Color.ORANGE);
        plot.setSubrangePaint(ThermometerPlot.CRITICAL, Color.RED);

        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Since value=55.0 falls into both NORMAL and WARNING, and WARNING has higher priority, expect ORANGE
        verify(g2).setPaint(Color.ORANGE);
        verify(g2).fill(any(Area.class));
    }

    @Test
    @DisplayName("Draw method with dataset value exactly at WARNING-CRITICAL boundary sets mercury color to CRITICAL")
    void TC20_Draw_Mercury_Color_Critical_Boundary() throws Exception {
        // GIVEN
        ThermometerPlot plot = new ThermometerPlot();
        ValueDataset dataset = new DefaultValueDataset(75.0);
        plot.setDataset(dataset);
        plot.setUseSubrangePaint(true);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 50.0);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 75.0);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75.0, 100.0);

        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(g2).setPaint(Color.RED);
        verify(g2).fill(any(Area.class));
    }
}