package org.apache.commons.compress.archivers.cpio;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Field;

public class CpioArchiveInputStream_getNextCPIOEntry_0_4_Test {

    @Test
    @DisplayName("Skips correctly when entryEOF is set to true")
    public void TC16_skipsCorrectlyWhenEntryEOFIsTrue() throws Exception {
        // Initialize CpioArchiveInputStream with an empty ByteArrayInputStream
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(new byte[0]);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // Use reflection to set 'entryEOF' to true
        Field entryEOFField = CpioArchiveInputStream.class.getDeclaredField("entryEOF");
        entryEOFField.setAccessible(true);
        entryEOFField.setBoolean(cpioInputStream, true);

        // Use reflection to set 'buffer2' to contain CPIO_TRAILER
        Field buffer2Field = CpioArchiveInputStream.class.getDeclaredField("buffer2");
        buffer2Field.setAccessible(true);
        byte[] trailerBytes = "CPIO_TRAILER".getBytes();
        buffer2Field.set(cpioInputStream, trailerBytes);

        // Invoke getNextCPIOEntry
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Assert that entry is null
        assertNull(entry, "Entry should be null when entryEOF is true");
    }

    @Test
    @DisplayName("Processes MAGIC_OLD_ASCII with valid entry")
    public void TC17_processesMAGIC_OLD_ASCIIWithValidEntry() throws Exception {
        // Initialize CpioArchiveInputStream with a ByteArrayInputStream containing MAGIC_OLD_ASCII
        byte[] magicOldAsciiBytes = "070707".getBytes();
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(magicOldAsciiBytes);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // Use reflection to set 'buffer2' to MAGIC_OLD_ASCII
        Field buffer2Field = CpioArchiveInputStream.class.getDeclaredField("buffer2");
        buffer2Field.setAccessible(true);
        buffer2Field.set(cpioInputStream, magicOldAsciiBytes);

        // Invoke getNextCPIOEntry
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Assert that entry is of type MAGIC_OLD_ASCII
        assertNotNull(entry, "Entry should not be null for valid MAGIC_OLD_ASCII");
        assertEquals("MAGIC_OLD_ASCII", entry.getFormat(), "Entry format should be MAGIC_OLD_ASCII");
    }

    @Test
    @DisplayName("Throws IOException for negative name size in entry")
    public void TC18_throwsIOExceptionForNegativeNameSizeInEntry() throws Exception {
        // Initialize CpioArchiveInputStream with a ByteArrayInputStream containing MAGIC_NEW
        byte[] magicNewBytes = "070701".getBytes();
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(magicNewBytes);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(byteArrayInputStream);

        // Use reflection to set 'buffer2' to MAGIC_NEW
        Field buffer2Field = CpioArchiveInputStream.class.getDeclaredField("buffer2");
        buffer2Field.setAccessible(true);
        buffer2Field.set(cpioInputStream, magicNewBytes);

        // Use reflection to set 'namesize' to a negative value
        Field namesizeField = CpioArchiveInputStream.class.getDeclaredField("namesize");
        namesizeField.setAccessible(true);
        namesizeField.setLong(cpioInputStream, -1L);

        // Invoke getNextCPIOEntry and expect IOException
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        }, "IOException should be thrown for negative name size in entry");

        assertTrue(exception.getMessage().contains("illegal entry with negative name length"), "Exception message should indicate negative name length");
    }
}