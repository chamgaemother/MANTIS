package com.fasterxml.jackson.databind.type;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.JavaType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class TypeFactory_constructSpecializedType_2_1_Test {

    @Test
    @DisplayName("Creates specialized type for DoubleStream when baseType is Stream.class")
    void TC24_create_specialized_DoubleStream_type() {
        // Arrange
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructType(Stream.class);
        Class<?> subclass = DoubleStream.class;
        boolean relaxedCompatibilityCheck = true;

        // Act
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // Assert
        assertEquals(DoubleStream.class, result.getRawClass(), "JavaType should be specialized for DoubleStream.class");
    }

    @Test
    @DisplayName("Creates specialized type for IntStream when baseType is Stream.class")
    void TC25_create_specialized_IntStream_type() {
        // Arrange
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructType(Stream.class);
        Class<?> subclass = IntStream.class;
        boolean relaxedCompatibilityCheck = true;

        // Act
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // Assert
        assertEquals(IntStream.class, result.getRawClass(), "JavaType should be specialized for IntStream.class");
    }
}