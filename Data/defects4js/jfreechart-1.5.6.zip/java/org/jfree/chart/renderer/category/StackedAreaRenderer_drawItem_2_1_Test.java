package org.jfree.chart.renderer.category;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.mock;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.Shape;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.DataUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class StackedAreaRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("Draw item with renderAsPercentages enabled and column total is zero, preventing division by zero")
    void TC32_renderAsPercentagesWithZeroColumnTotal() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer(true);
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(0);
        when(DataUtils.calculateColumnTotal(Mockito.eq(dataset), Mockito.eq(column), Mockito.any(int[].class))).thenReturn(0.0);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(renderer.isSeriesVisible(row)).thenReturn(true);

        // Mock domainAxis methods if necessary
        when(domainAxis.getCategoryMiddle(Mockito.eq(column), Mockito.anyInt(), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(100.0);
        when(domainAxis.getCategoryStart(Mockito.eq(column), Mockito.anyInt(), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(90.0);
        when(domainAxis.getCategoryEnd(Mockito.eq(column), Mockito.anyInt(), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(110.0);

        doNothing().when(g2).fill(any(Shape.class));

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    @DisplayName("Draw item with multiple visible series having mixed positive and negative values")
    void TC33_multipleSeriesWithMixedValues() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer(false);
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getValue(0, 1)).thenReturn(50);
        when(dataset.getValue(0, 0)).thenReturn(-30);
        when(dataset.getValue(0, 2)).thenReturn(20);
        when(dataset.getColumnCount()).thenReturn(3);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(renderer.isSeriesVisible(row)).thenReturn(true);

        // Mock domainAxis methods if necessary
        when(domainAxis.getCategoryMiddle(Mockito.eq(column), Mockito.eq(3), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(150.0);
        when(domainAxis.getCategoryStart(Mockito.eq(column), Mockito.eq(3), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(140.0);
        when(domainAxis.getCategoryEnd(Mockito.eq(column), Mockito.eq(3), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(160.0);

        doNothing().when(g2).fill(any(Shape.class));

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    @DisplayName("Draw item when column index is at maximum boundary, ensuring no out-of-bounds access")
    void TC34_maxColumnIndexBoundary() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer(false);
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 4; // assuming dataset has 5 columns (0-4)
        int pass = 0;

        renderer.setSeriesVisible(row, true);
        when(dataset.getValue(row, column)).thenReturn(50);
        when(dataset.getValue(row, column - 1)).thenReturn(30);
        when(dataset.getValue(row, column + 1)).thenReturn(null); // beyond max
        when(dataset.getColumnCount()).thenReturn(5);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(renderer.isSeriesVisible(row)).thenReturn(true);

        // Mock domainAxis methods if necessary
        when(domainAxis.getCategoryMiddle(Mockito.eq(column), Mockito.eq(5), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(200.0);
        when(domainAxis.getCategoryStart(Mockito.eq(column), Mockito.eq(5), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(190.0);
        when(domainAxis.getCategoryEnd(Mockito.eq(column), Mockito.eq(5), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(210.0);

        doNothing().when(g2).fill(any(Shape.class));

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    @DisplayName("Draw item with y1 equal to zero to test proper handling of zero values")
    void TC35_y1EqualsZeroHandling() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer(false);
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        renderer.setSeriesVisible(row, true);
        when(dataset.getValue(row, column)).thenReturn(0);
        when(dataset.getValue(row, column - 1)).thenReturn(30);
        when(dataset.getValue(row, column + 1)).thenReturn(20);
        when(dataset.getColumnCount()).thenReturn(3);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(renderer.isSeriesVisible(row)).thenReturn(true);

        // Mock domainAxis methods if necessary
        when(domainAxis.getCategoryMiddle(Mockito.eq(column), Mockito.eq(3), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(150.0);
        when(domainAxis.getCategoryStart(Mockito.eq(column), Mockito.eq(3), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(140.0);
        when(domainAxis.getCategoryEnd(Mockito.eq(column), Mockito.eq(3), Mockito.any(Rectangle2D.class), Mockito.any())).thenReturn(160.0);

        doNothing().when(g2).fill(any(Shape.class));

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        verify(g2, times(2)).fill(any(Shape.class));
    }
}