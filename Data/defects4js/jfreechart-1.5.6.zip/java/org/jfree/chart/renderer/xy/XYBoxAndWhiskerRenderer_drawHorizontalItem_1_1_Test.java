package org.jfree.chart.renderer.xy;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYBoxAndWhiskerRenderer_drawHorizontalItem_1_1_Test {

    @Test
    @DisplayName("drawHorizontalItem with r0 not null, r23 is null, fillBox is true, and box width calculated within limits")
    public void TC21_drawHorizontalItem_r0_not_null_r23_null_fillBox_true_boxWidth_within_limits() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(true);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        // Mock dataset behavior with r23 null
        when(dataset.getX(series, item)).thenReturn(10.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(20.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(5.0);
        when(dataset.getMedianValue(series, item)).thenReturn(12.0);
        when(dataset.getMeanValue(series, item)).thenReturn(null);
        when(dataset.getQ1Value(series, item)).thenReturn(9.0);
        when(dataset.getQ3Value(series, item)).thenReturn(15.0);
        when(dataset.getItemCount(series)).thenReturn(10);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Line2D.class));
        // Since yAverage is null, average marker should not be drawn
        verify(g2, never()).fill(any(Ellipse2D.class));
        verify(g2, never()).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawHorizontalItem with r0 not null, r23 is null, fillBox is true, and box width exceeds max limit")
    public void TC22_drawHorizontalItem_r0_not_null_r23_null_fillBox_true_boxWidth_exceeds_max_limit() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(true);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        // Mock dataset behavior with r23 null and high item count to simulate max box width
        when(dataset.getX(series, item)).thenReturn(10.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(20.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(5.0);
        when(dataset.getMedianValue(series, item)).thenReturn(12.0);
        when(dataset.getMeanValue(series, item)).thenReturn(null);
        when(dataset.getQ1Value(series, item)).thenReturn(9.0);
        when(dataset.getQ3Value(series, item)).thenReturn(15.0);
        when(dataset.getItemCount(series)).thenReturn(1);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Line2D.class));
        // Since yAverage is null, average marker should not be drawn
        verify(g2, never()).fill(any(Ellipse2D.class));
        verify(g2, never()).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawHorizontalItem with r0 not null, r23 is not null, fillBox is false, box width >0, and $i10 >0, $i11 >=0")
    public void TC23_drawHorizontalItem_r0_not_null_r23_not_null_fillBox_false_boxWidth_positive_i10_gt0_i11_ge0() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(false);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 1;

        // Mock dataset behavior with r23 not null
        when(dataset.getX(series, item)).thenReturn(15.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(10.0);
        when(dataset.getMedianValue(series, item)).thenReturn(18.0);
        when(dataset.getMeanValue(series, item)).thenReturn(17.0);
        when(dataset.getQ1Value(series, item)).thenReturn(14.0);
        when(dataset.getQ3Value(series, item)).thenReturn(20.0);
        when(dataset.getItemCount(series)).thenReturn(10);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
        verify(g2).draw(any(Line2D.class));
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawHorizontalItem with r0 not null, r23 is not null, fillBox is false, box width >0, and $i10 >0, $i11 <0")
    public void TC24_drawHorizontalItem_r0_not_null_r23_not_null_fillBox_false_boxWidth_positive_i10_gt0_i11_lt0() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(false);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 1;

        // Mock dataset behavior with r23 not null and $i11 <0
        when(dataset.getX(series, item)).thenReturn(15.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(10.0);
        when(dataset.getMedianValue(series, item)).thenReturn(18.0);
        when(dataset.getMeanValue(series, item)).thenReturn(17.0);
        when(dataset.getQ1Value(series, item)).thenReturn(14.0);
        when(dataset.getQ3Value(series, item)).thenReturn(20.0);
        when(dataset.getItemCount(series)).thenReturn(10);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
        // Assert that lower shadow and other lines are drawn
        verify(g2, times(2)).draw(any(Line2D.class));
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawHorizontalItem with r0 not null, r23 is not null, $i10 <=0, ensuring box width is set to minimum")
    public void TC25_drawHorizontalItem_r0_not_null_r23_not_null_i10_le0_boxWidth_minimum() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(true);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 1;

        // Mock dataset behavior with r23 not null and $i10 <=0
        when(dataset.getX(series, item)).thenReturn(15.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(10.0);
        when(dataset.getMedianValue(series, item)).thenReturn(18.0);
        when(dataset.getMeanValue(series, item)).thenReturn(17.0);
        when(dataset.getQ1Value(series, item)).thenReturn(14.0);
        when(dataset.getQ3Value(series, item)).thenReturn(20.0);
        when(dataset.getItemCount(series)).thenReturn(10);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Line2D.class));
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).draw(any(Ellipse2D.class));
    }
}