package org.apache.commons.jxpath.ri.model.jdom;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Text;
import org.jdom.Comment;

public class JDOMNodePointer_getValue_0_3_Test {

    @Test
    @DisplayName("getValue returns null when node type is unsupported")
    public void TC11_getValue_returns_null_with_unsupported_node_type() throws Exception {
        // GIVEN
        Document node = new Document();
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, null);

        // WHEN
        Object result = nodePointer.getValue();

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("getValue handles childIterator with multiple iterations and mixed node types")
    public void TC12_getValue_handles_childIterator_with_multiple_iterations_and_mixed_node_types() throws Exception {
        // GIVEN
        Element child1 = new Element("child1").setText("Value1");
        Text text = new Text("TextValue");
        Comment comment = new Comment("CommentText");
        Element node = new Element("root")
                            .addContent(child1)
                            .addContent(text)
                            .addContent(comment);
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, null);

        // WHEN
        Object result = nodePointer.getValue();

        // THEN
        assertEquals("Value1TextValue", result);
    }

    @Test
    @DisplayName("getValue returns concatenated child values when childIterator iterates multiple times successfully")
    public void TC13_getValue_returns_concatenated_child_values_when_childIterator_iterates_multiple_times_successfully() throws Exception {
        // GIVEN
        Element child1 = new Element("child1").setText("Value1");
        Element child2 = new Element("child2").setText("Value2");
        Text text = new Text("TextValue");
        Element node = new Element("root")
                            .addContent(child1)
                            .addContent(child2)
                            .addContent(text);
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, null);

        // WHEN
        Object result = nodePointer.getValue();

        // THEN
        assertEquals("Value1Value2TextValue", result);
    }
}