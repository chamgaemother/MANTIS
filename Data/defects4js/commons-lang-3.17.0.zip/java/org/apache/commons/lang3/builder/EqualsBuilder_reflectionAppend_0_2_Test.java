package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class EqualsBuilder_reflectionAppend_0_2_Test {

//     @Test
//     @DisplayName("Performs reflection append when classes are related and not in bypass list")
//     void TC06_PerformsReflectionAppendWhenClassesRelatedAndNotInBypassList() throws Exception {
        // GIVEN
//         EqualsBuilder builder = spy(new EqualsBuilder());
//         Object lhs = new CustomClass();
//         Object rhs = new CustomClass();
//         Method setBypassMethod = EqualsBuilder.class.getDeclaredMethod("setBypassReflectionClasses", List.class);
//         setBypassMethod.setAccessible(true);
//         setBypassMethod.invoke(builder, (List<?>) null); // Fixed cast
// 
        // WHEN
//         EqualsBuilder result = builder.reflectionAppend(lhs, rhs);
// 
        // THEN
//         Method reflectionAppendMethod = EqualsBuilder.class.getDeclaredMethod("reflectionAppend", Object.class, Object.class, Class.class);
//         reflectionAppendMethod.setAccessible(true);
//         verify(builder, times(1)).reflectionAppend(lhs, rhs, CustomClass.class);
//         assertTrue(builder.isEquals());
//         assertSame(builder, result);
//     }

    @Test
    @DisplayName("Uses equals method when lhs class is in bypassReflectionClasses")
    void TC07_UsesEqualsMethodWhenLhsClassIsInBypassReflectionClasses() throws Exception {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        Object lhs = new String("test");
        Object rhs = new String("test");
        Method setBypassMethod = EqualsBuilder.class.getDeclaredMethod("setBypassReflectionClasses", List.class);
        setBypassMethod.setAccessible(true);
        setBypassMethod.invoke(builder, Arrays.asList(String.class));

        // WHEN
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // THEN
        assertTrue(builder.isEquals());
        assertSame(builder, result);
    }

    @Test
    @DisplayName("Uses equals method when rhs class is in bypassReflectionClasses")
    void TC08_UsesEqualsMethodWhenRhsClassIsInBypassReflectionClasses() throws Exception {
        // GIVEN
        EqualsBuilder builder = new EqualsBuilder();
        Object lhs = new Integer(5);
        Object rhs = new Integer(5);
        Method setBypassMethod = EqualsBuilder.class.getDeclaredMethod("setBypassReflectionClasses", List.class);
        setBypassMethod.setAccessible(true);
        setBypassMethod.invoke(builder, Arrays.asList(Integer.class));

        // WHEN
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // THEN
        assertTrue(builder.isEquals());
        assertSame(builder, result);
    }

//     @Test
//     @DisplayName("Performs multiple reflection appends through superclass hierarchy without exceptions")
//     void TC09_PerformsMultipleReflectionAppendsThroughSuperclassHierarchyWithoutExceptions() throws Exception {
        // GIVEN
//         EqualsBuilder builder = spy(new EqualsBuilder());
//         SubClass lhs = new SubClass();
//         SubClass rhs = new SubClass();
//         Method setReflectUpToMethod = EqualsBuilder.class.getDeclaredMethod("setReflectUpToClass", Class.class);
//         setReflectUpToMethod.setAccessible(true);
//         setReflectUpToMethod.invoke(builder, Object.class);
// 
        // WHEN
//         EqualsBuilder result = builder.reflectionAppend(lhs, rhs);
// 
        // THEN
//         verify(builder, atLeastOnce()).reflectionAppend(any(), any(), any(Class.class));
//         assertTrue(builder.isEquals());
//         assertSame(builder, result);
//     }

//     @Test
//     @DisplayName("Sets isEquals to false when reflectionAppend throws IllegalArgumentException")
//     void TC10_SetsIsEqualsToFalseWhenReflectionAppendThrowsIllegalArgumentException() throws Exception {
        // GIVEN
//         EqualsBuilder builder = spy(new EqualsBuilder());
//         Object lhs = new CustomClass();
//         Object rhs = new CustomClass();
//         Method reflectionAppendMethod = EqualsBuilder.class.getDeclaredMethod("reflectionAppend", Object.class, Object.class, Class.class);
//         reflectionAppendMethod.setAccessible(true);
//         doThrow(new IllegalArgumentException()).when(builder).reflectionAppend(lhs, rhs, CustomClass.class);
// 
        // WHEN
//         EqualsBuilder result = builder.reflectionAppend(lhs, rhs);
// 
        // THEN
//         assertFalse(builder.isEquals());
//         assertSame(builder, result);
//     }

    // Mock or helper classes for testing
    private static class CustomClass {}

    private static class SubClass extends SuperClass {}

    private static class SuperClass {}

    private static class ClassWithIvars {}

}