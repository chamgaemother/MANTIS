import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

class BarRendererTest {

    private BarRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;

    @BeforeEach
    void setUp() {
        renderer = new BarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = new DefaultCategoryDataset();

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
    }

    @Test
    void testDrawItemWithNullValue() {
        when(dataset.getValue(0, 0)).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItemNegativeValue() {
        when(dataset.getValue(0, 0)).thenReturn(-1.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(20.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItemPositiveValue() {
        when(dataset.getValue(0, 0)).thenReturn(1.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(20.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItemInvisibleRow() {
        when(state.getVisibleSeriesIndex(0)).thenReturn(-1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItemWithShadow() {
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(50.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        renderer.setShadowVisible(true);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItemWithoutShadow() {
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(50.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        renderer.setShadowVisible(false);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any());
    }
}