package com.fasterxml.jackson.databind.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializable;
import com.fasterxml.jackson.databind.util.RawValue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import static org.mockito.Mockito.*;

public class TokenBuffer_serialize_0_7_Test {

//     @Test
//     @DisplayName("serialize with VALUE_EMBEDDED_OBJECT token as RawValue and JsonSerializable in the same buffer")
//     void TC31_serialize_mixed_embedded_objects() throws Exception {
        // GIVEN
//         TokenBuffer buffer = new TokenBuffer((JsonGenerator) null, false);
//         RawValue raw = new RawValue("{\"raw\": true}");
//         JsonSerializable serializable = mock(JsonSerializable.class);
//         buffer.writeObject(raw);
//         buffer.writeObject(serializable);
//         JsonGenerator gen = mock(JsonGenerator.class);
// 
        // WHEN
//         buffer.serialize(gen);
// 
        // THEN
//         verify(gen).writeEmbeddedObject(raw);
//         verify(serializable).serialize(gen, null);
//     }

//     @Test
//     @DisplayName("serialize with FIELD_NAME followed by VALUE_NUMBER_INT and VALUE_NUMBER_FLOAT tokens")
//     void TC32_serialize_field_name_and_numbers() throws Exception {
        // GIVEN
//         TokenBuffer buffer = new TokenBuffer((JsonGenerator) null, false);
//         buffer.writeStartObject();
//         buffer.writeFieldName("count");
//         buffer.writeNumber(100);
//         buffer.writeFieldName("pi");
//         buffer.writeNumber(3.14159);
//         buffer.writeEndObject();
//         JsonGenerator gen = mock(JsonGenerator.class);
// 
        // WHEN
//         buffer.serialize(gen);
// 
        // THEN
//         InOrder inOrder = inOrder(gen);
//         inOrder.verify(gen).writeStartObject();
//         inOrder.verify(gen).writeFieldName("count");
//         inOrder.verify(gen).writeNumber(100);
//         inOrder.verify(gen).writeFieldName("pi");
//         inOrder.verify(gen).writeNumber(3.14159);
//         inOrder.verify(gen).writeEndObject();
//     }

//     @Test
//     @DisplayName("serialize with multiple VALUE_EMBEDDED_OBJECT tokens, some null and some valid")
//     void TC33_serialize_embedded_objects_with_nulls() throws Exception {
        // GIVEN
//         TokenBuffer buffer = new TokenBuffer((JsonGenerator) null, false);
//         buffer.writeObject((Object)null);
//         RawValue raw = new RawValue("{\"valid\": true}");
//         buffer.writeObject(raw);
//         JsonGenerator gen = mock(JsonGenerator.class);
// 
        // WHEN
//         buffer.serialize(gen);
// 
        // THEN
//         verify(gen).writeEmbeddedObject(null);
//         verify(gen).writeEmbeddedObject(raw);
//     }

//     @Test
//     @DisplayName("serialize with VALUE_OBJECT_ID token present")
//     void TC34_serialize_with_object_id() throws Exception {
        // GIVEN
//         TokenBuffer buffer = new TokenBuffer((JsonGenerator) null, true);
//         buffer.writeStartObject();
//         buffer.writeObjectId("obj-1234");
//         buffer.writeEndObject();
//         JsonGenerator gen = mock(JsonGenerator.class);
// 
        // WHEN
//         buffer.serialize(gen);
// 
        // THEN
//         verify(gen).writeObjectId("obj-1234");
//         verify(gen).writeStartObject();
//         verify(gen).writeEndObject();
//     }

//     @Test
//     @DisplayName("serialize with VALUE_TYPE_ID token present")
//     void TC35_serialize_with_type_id() throws Exception {
        // GIVEN
//         TokenBuffer buffer = new TokenBuffer((JsonGenerator) null, true);
//         buffer.writeStartObject();
//         buffer.writeTypeId("type-xyz");
//         buffer.writeEndObject();
//         JsonGenerator gen = mock(JsonGenerator.class);
// 
        // WHEN
//         buffer.serialize(gen);
// 
        // THEN
//         verify(gen).writeTypeId("type-xyz");
//         verify(gen).writeStartObject();
//         verify(gen).writeEndObject();
//     }
}