package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Dfp_multiply_0_8_Test {

    @Test
    @DisplayName("Multiplying Dfp numbers where the product exponent equals MIN_EXP without underflow")
    public void TC36_multiply_resulting_in_MIN_EXP() {
        DfpField field = new DfpField(50); // assumed radix digits value
        Dfp a = new Dfp(field, 1e-300); // small values for MIN_EXP scenario
        Dfp b = new Dfp(field, 1e-300);

        // Assuming getMnExp() returns MIN_EXP.
        Dfp result = a.multiply(b);

        int exponent = result.exp; // Accessing directly since it may not be private
        int minExp = Dfp.MIN_EXP;

        assertEquals(minExp, exponent, "Exponent should be equal to MIN_EXP");
        assertFalse(result.exp < minExp, "Underflow should not occur");
    }

//    @Test
//    @DisplayName("Multiplying Dfp numbers where the product exponent exceeds MAX_EXP causing overflow")
//    public void TC37_multiply_causing_exponent_overflow() {
//        DfpField field = new DfpField(50); // assumed radix digits value
//        Dfp a = new Dfp(field, Double.MAX_VALUE);
//        Dfp b = new Dfp(field, 2.0);
//
//        Dfp result = a.multiply(b);
//
//        assertTrue(result.isInfinite(), "Result should be infinite due to overflow");
//        int flags = field.getIEEEFlagsBits(); // Correct method to retrieve IEEE flags
//        assertTrue((flags & DfpField.FLAG_OVERFLOW) != 0, "FLAG_OVERFLOW should be set");
//    }

    @Test
    @DisplayName("Multiplying Dfp numbers where one operand is zero with non-zero exponent")
    public void TC38_multiply_with_zero_mantissa_non_zero_exponent() {
        DfpField field = new DfpField(50);
        Dfp a = new Dfp(field, 0.0);
        Dfp b = new Dfp(field, 1.0);

        Dfp result = a.multiply(b);

        assertTrue(result.isZero(), "Result should be zero");
        assertEquals(0, result.exp, "Exponent should be set to zero");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where both operands have maximum exponent without causing overflow")
    public void TC39_multiply_max_exponent_without_overflow() {
        DfpField field = new DfpField(50);
        Dfp a = new Dfp(field, Math.pow(10, Dfp.MAX_EXP));
        Dfp b = new Dfp(field, Math.pow(10, Dfp.MAX_EXP));

        Dfp result = a.multiply(b);

        assertTrue(result.nans == Dfp.FINITE, "Result should be finite");
        assertTrue(result.exp <= Dfp.MAX_EXP, "Exponent should not exceed MAX_EXP");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where multiplication leads to negative exponent without underflow")
    public void TC40_multiply_leading_to_negative_exponent() {
        DfpField field = new DfpField(50);
        Dfp a = new Dfp(field, 1e-50); // smaller values for scenario
        Dfp b = new Dfp(field, 1e-50);

        Dfp result = a.multiply(b);

        int expectedExp = a.exp + b.exp; // estimated expected value
        assertEquals(expectedExp, result.exp, "Exponent should be correctly adjusted to negative value");
        assertTrue(result.nans == Dfp.FINITE, "Result should be finite");
    }
}
