package com.fasterxml.jackson.core.json;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.nio.charset.StandardCharsets;

public class UTF8DataInputJsonParser_nextToken_1_1_Test {

    @Test
    @DisplayName("nextToken() correctly parses and returns VALUE_FALSE when 'false' is encountered")
    public void testParseFalseToken() throws Exception {
        // GIVEN
        String json = "false";
        DataInput dataInput = new DataInputStream(new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8)));
        IOContext ioContext = new IOContext(null, null, false);
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int firstByte = 'f'; // ASCII value for 'f'

        // WHEN
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, dataInput, codec, sym, firstByte);
        JsonToken result = parser.nextToken();

        // THEN
        assertEquals(JsonToken.VALUE_FALSE, result);
    }

    @Test
    @DisplayName("nextToken() correctly parses and returns VALUE_NULL when 'null' is encountered")
    public void testParseNullToken() throws Exception {
        // GIVEN
        String json = "null";
        DataInput dataInput = new DataInputStream(new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8)));
        IOContext ioContext = new IOContext(null, null, false);
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int firstByte = 'n'; // ASCII value for 'n'

        // WHEN
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, dataInput, codec, sym, firstByte);
        JsonToken result = parser.nextToken();

        // THEN
        assertEquals(JsonToken.VALUE_NULL, result);
    }

    @Test
    @DisplayName("nextToken() correctly parses and returns VALUE_NUMBER_FLOAT for floating-point numbers")
    public void testParseFloatNumber() throws Exception {
        // GIVEN
        String json = "123.45";
        DataInput dataInput = new DataInputStream(new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8)));
        IOContext ioContext = new IOContext(null, null, false);
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int firstByte = '1'; // ASCII value for '1'

        // WHEN
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, dataInput, codec, sym, firstByte);
        JsonToken result = parser.nextToken();
        double value = parser.getDoubleValue();

        // THEN
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, result);
        assertEquals(123.45, value, 0.0001);
    }

    @Test
    @DisplayName("nextToken() correctly parses and returns VALUE_NUMBER_FLOAT for numbers with exponents")
    public void testParseNumberWithExponent() throws Exception {
        // GIVEN
        String json = "1.23e4";
        DataInput dataInput = new DataInputStream(new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8)));
        IOContext ioContext = new IOContext(null, null, false);
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int firstByte = '1'; // ASCII value for '1'

        // WHEN
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, dataInput, codec, sym, firstByte);
        JsonToken result = parser.nextToken();
        double value = parser.getDoubleValue();

        // THEN
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, result);
        assertEquals(12300.0, value, 0.0001);
    }

    @Test
    @DisplayName("nextToken() correctly parses and returns START_ARRAY when '[' is encountered inside an object")
    public void testParseStartArrayInsideObject() throws Exception {
        // GIVEN
        String json = "{\"numbers\":[1,2,3]}";
        DataInput dataInput = new DataInputStream(new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8)));
        IOContext ioContext = new IOContext(null, null, false);
        ObjectCodec codec = null;
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int firstByte = '{'; // ASCII value for '{'

        // WHEN
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, dataInput, codec, sym, firstByte);
        JsonToken token1 = parser.nextToken(); // START_OBJECT
        JsonToken token2 = parser.nextToken(); // FIELD_NAME
        JsonToken result = parser.nextToken(); // START_ARRAY

        // THEN
        assertEquals(JsonToken.START_OBJECT, token1);
        assertEquals(JsonToken.FIELD_NAME, token2);
        assertEquals(JsonToken.START_ARRAY, result);
    }

}