package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.DateTimeFieldType;
import java.util.Arrays;
import java.util.Collection;

public class ISODateTimeFormat_forFields_0_3_Test {

    @Test
    @DisplayName("Test with fields containing only dayOfMonth (workingFields.contains(dayOfMonth) == true), expecting ---DD format")
    public void TC11() {
        // Given
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.dayOfMonth());
        boolean extended = false;
        boolean strictISO = true;
        
        // When
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        
        // Then
        Assertions.assertEquals("---DD", formatter.toString());
    }
    
    @Test
    @DisplayName("Test with fields containing weekyear but not weekOfWeekyear or dayOfWeek (workingFields.contains(weekyear) == true and others false), expecting YYYY format")
    public void TC12() {
        // Given
        Collection<DateTimeFieldType> fields = Arrays.asList(DateTimeFieldType.weekyear());
        boolean extended = false;
        boolean strictISO = true;
        
        // When
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        
        // Then
        Assertions.assertEquals("YYYY", formatter.toString());
    }
}