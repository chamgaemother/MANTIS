import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
import com.fasterxml.jackson.core.filter.TokenFilter;
import com.fasterxml.jackson.core.filter.TokenFilter.Inclusion;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class FilteringParserDelegateTest {

    private static class IncludeAllFilter extends TokenFilter {
        @Override
        public TokenFilter includeProperty(String name) {
            return INCLUDE_ALL;
        }

        @Override
        public TokenFilter includeElement(int index) {
            return INCLUDE_ALL;
        }

        @Override
        public TokenFilter filterStartObject() {
            return INCLUDE_ALL;
        }

        @Override
        public TokenFilter filterStartArray() {
            return INCLUDE_ALL;
        }
    }

    private JsonParser createParser(String json) throws IOException {
        return new JsonFactory().createParser(json);
    }

    @Test
    void testNextTokenWithEmptyObject() throws IOException {
        String json = "{}";
        JsonParser parser = createParser(json);
        FilteringParserDelegate delegate =
                new FilteringParserDelegate(parser, new IncludeAllFilter(), Inclusion.ONLY_INCLUDE_ALL, false);

        assertEquals(JsonToken.START_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.END_OBJECT, delegate.nextToken());
        assertNull(delegate.nextToken());
    }

    @Test
    void testNextTokenWithSimpleArray() throws IOException {
        String json = "[1,2,3]";
        JsonParser parser = createParser(json);
        FilteringParserDelegate delegate =
                new FilteringParserDelegate(parser, new IncludeAllFilter(), Inclusion.INCLUDE_ALL_AND_PATH, true);

        assertEquals(JsonToken.START_ARRAY, delegate.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, delegate.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, delegate.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, delegate.nextToken());
        assertEquals(JsonToken.END_ARRAY, delegate.nextToken());
        assertNull(delegate.nextToken());
    }

    @Test
    void testStartObjectFilterOut() throws IOException {
        String json = "{\"shouldBeFiltered\": [1, 2, 3]}";
        JsonParser parser = createParser(json);
        TokenFilter filter = new TokenFilter() {
            @Override
            public TokenFilter includeProperty(String name) {
                return null;  // Exclude everything
            }
        };

        FilteringParserDelegate delegate =
                new FilteringParserDelegate(parser, filter, Inclusion.ONLY_INCLUDE_ALL, false);

        assertNull(delegate.nextToken());
    }

    @Test
    void testNextTokenWithMultipleMatches() throws IOException {
        String json = "{\"a\": 1, \"b\": 2}";
        JsonParser parser = createParser(json);
        TokenFilter filter = new IncludeAllFilter();

        FilteringParserDelegate delegate =
                new FilteringParserDelegate(parser, filter, Inclusion.ONLY_INCLUDE_ALL, true);

        assertEquals(JsonToken.START_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.FIELD_NAME, delegate.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, delegate.nextToken());
        assertEquals(JsonToken.FIELD_NAME, delegate.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, delegate.nextToken());
        assertEquals(JsonToken.END_OBJECT, delegate.nextToken());
        assertNull(delegate.nextToken());
    }

    @Test
    void testFieldNameWithInclusionPath() throws IOException {
        String json = "{\"obj\": {\"a\": 123}}";
        JsonParser parser = createParser(json);
        TokenFilter filter = new IncludeAllFilter();

        FilteringParserDelegate delegate =
                new FilteringParserDelegate(parser, filter, Inclusion.INCLUDE_ALL_AND_PATH, false);

        assertEquals(JsonToken.START_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.FIELD_NAME, delegate.nextToken());
        assertEquals(JsonToken.START_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.FIELD_NAME, delegate.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, delegate.nextToken());
        assertEquals(JsonToken.END_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.END_OBJECT, delegate.nextToken());
        assertNull(delegate.nextToken());
    }

    @Test
    void testFilterEndObject() throws IOException {
        String json = "{\"nested\": {}}";
        JsonParser parser = createParser(json);
        TokenFilter filter = new IncludeAllFilter();

        FilteringParserDelegate delegate =
                new FilteringParserDelegate(parser, filter, Inclusion.INCLUDE_NON_NULL, false);

        assertEquals(JsonToken.START_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.FIELD_NAME, delegate.nextToken());
        assertEquals(JsonToken.START_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.END_OBJECT, delegate.nextToken());
        assertEquals(JsonToken.END_OBJECT, delegate.nextToken());
        assertNull(delegate.nextToken());
    }
}