package org.apache.commons.jxpath.ri.axes;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;

import java.lang.reflect.Field;
import java.util.Stack;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class PrecedingOrFollowingContext_nextNode_1_2_Test {

    @Test
    @DisplayName("nextNode() with setStarted=true, reverse=true, all nodeTest checks fail across iterators")
    void TC22_nextNode_with_setStarted_true_reverse_true_all_nodeTest_fail() throws Exception {
        // Mock dependencies
        EvalContext parentContext = mock(EvalContext.class);
        NodeTest nodeTest = mock(NodeTest.class);
        NodePointer rootPointer = mock(NodePointer.class);
        when(parentContext.getCurrentNodePointer()).thenReturn(rootPointer);

        // Initialize PrecedingOrFollowingContext with reverse=true
        PrecedingOrFollowingContext context = new PrecedingOrFollowingContext(parentContext, nodeTest, true);

        // Use reflection to set setStarted=true
        Field setStartedField = PrecedingOrFollowingContext.class.getDeclaredField("setStarted");
        setStartedField.setAccessible(true);
        setStartedField.setBoolean(context, true);

        // Use reflection to set stack with multiple NodeIterators that fail nodeTest
        Stack<NodeIterator> stack = new Stack<>();

        // First failing NodeIterator
        NodeIterator failingIterator1 = mock(NodeIterator.class);
        when(failingIterator1.setPosition(anyInt())).thenReturn(true);
        NodePointer nodePointer1 = mock(NodePointer.class);
        when(failingIterator1.getNodePointer()).thenReturn(nodePointer1);
        when(nodePointer1.isLeaf()).thenReturn(false);
        when(nodePointer1.testNode(nodeTest)).thenReturn(false);
        stack.push(failingIterator1);

        // Second failing NodeIterator
        NodeIterator failingIterator2 = mock(NodeIterator.class);
        when(failingIterator2.setPosition(anyInt())).thenReturn(false);
        stack.push(failingIterator2);

        Field stackField = PrecedingOrFollowingContext.class.getDeclaredField("stack");
        stackField.setAccessible(true);
        stackField.set(context, stack);

        // Call nextNode and assert false
        boolean result = context.nextNode();
        assertFalse(result, "Expected nextNode() to return false when all nodeTest checks fail.");
    }
}