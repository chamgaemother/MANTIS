package org.apache.commons.math3.analysis.solvers;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.Field;
import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.Decimal64Field;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class FieldBracketingNthOrderBrentSolver_solve_0_4_Test {

//     @Test
//     @DisplayName("solve returns left side when AllowedSolution is ANY_SIDE and yA.abs() < yB.abs()")
//     void TC16_solveAnySide_yAAbsLessThan_yBAbs() throws Exception {
//         int maxEval = 100;
//         RealFieldUnivariateFunction<RealFieldElement<?>> f = Mockito.mock(RealFieldUnivariateFunction.class);
//         Field<RealFieldElement<?>> field = Decimal64Field.getInstance();
//         RealFieldElement<?> min = field.getZero();
//         RealFieldElement<?> max = field.getOne();
//         RealFieldElement<?> startValue = field.getOne().multiply(0.5); // Correctly defined computation
//         AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
//         RealFieldElement<?> xA = min;
//         RealFieldElement<?> xB = max;
//         RealFieldElement<?> yA = field.getOne().negate(); // |yA| < |yB|
//         RealFieldElement<?> yB = field.getOne().multiply(2);
// 
//         when(f.value(xA)).thenReturn(yA);
//         when(f.value(xB)).thenReturn(yB);
// 
        // Corrected the instantiation
//         FieldBracketingNthOrderBrentSolver<RealFieldElement<?>> solver = new FieldBracketingNthOrderBrentSolver<>(
//                 field.getOne(), field.getOne(), field.getOne(), 3);
// 
        // Direct call to the public method
//         RealFieldElement<?> result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// 
//         assertEquals(xA, result, "Solver should return xA as the root");
//     }

//     @Test
//     @DisplayName("solve returns right side when AllowedSolution is ANY_SIDE and |yB| < |yA|")
//     void TC17_solveAnySide_yBAbsLessThan_yAAbs() throws Exception {
//         int maxEval = 100;
//         RealFieldUnivariateFunction<RealFieldElement<?>> f = Mockito.mock(RealFieldUnivariateFunction.class);
//         Field<RealFieldElement<?>> field = Decimal64Field.getInstance();
//         RealFieldElement<?> min = field.getZero();
//         RealFieldElement<?> max = field.getOne();
//         RealFieldElement<?> startValue = field.getOne().multiply(0.5);
//         AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
//         RealFieldElement<?> xA = min;
//         RealFieldElement<?> xB = max;
//         RealFieldElement<?> yA = field.getOne().multiply(2);
//         RealFieldElement<?> yB = field.getOne().negate();
// 
//         when(f.value(xA)).thenReturn(yA);
//         when(f.value(xB)).thenReturn(yB);
// 
//         FieldBracketingNthOrderBrentSolver<RealFieldElement<?>> solver = new FieldBracketingNthOrderBrentSolver<>(
//                 field.getOne(), field.getOne(), field.getOne(), 3);
// 
//         RealFieldElement<?> result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// 
//         assertEquals(xB, result, "Solver should return xB as the root");
//     }

//     @Test
//     @DisplayName("solve handles multiple iterations with balanced bracketing")
//     void TC18_solveMultipleBalancedIterations() throws Exception {
//         int maxEval = 100;
//         RealFieldUnivariateFunction<RealFieldElement<?>> f = Mockito.mock(RealFieldUnivariateFunction.class);
//         Field<RealFieldElement<?>> field = Decimal64Field.getInstance();
//         RealFieldElement<?> min = field.getZero();
//         RealFieldElement<?> max = field.getOne();
//         RealFieldElement<?> startValue = field.getOne().multiply(0.5);
//         AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
//         RealFieldElement<?> xA = min;
//         RealFieldElement<?> xB = max;
//         RealFieldElement<?> yA = field.getOne().negate();
//         RealFieldElement<?> yB = field.getOne();
// 
//         when(f.value(any())).thenReturn(yA, yB, yA, yB, yA, yB, field.getZero());
// 
//         FieldBracketingNthOrderBrentSolver<RealFieldElement<?>> solver = new FieldBracketingNthOrderBrentSolver<>(
//                 field.getOne(), field.getOne(), field.getOne(), 3);
// 
//         RealFieldElement<?> result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// 
//         assertNotNull(result, "Solver should find a root");
//     }

//     @Test
//     @DisplayName("solve correctly alternates bracketing when aging thresholds are met")
//     void TC19_solveAgingExceedsThresholds() throws Exception {
//         int maxEval = 100;
//         RealFieldUnivariateFunction<RealFieldElement<?>> f = Mockito.mock(RealFieldUnivariateFunction.class);
//         Field<RealFieldElement<?>> field = Decimal64Field.getInstance();
//         RealFieldElement<?> min = field.getZero();
//         RealFieldElement<?> max = field.getOne();
//         RealFieldElement<?> startValue = field.getOne().multiply(0.5);
//         AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
//         RealFieldElement<?> xA = min;
//         RealFieldElement<?> xB = max;
//         RealFieldElement<?> yA = field.getOne().negate();
//         RealFieldElement<?> yB = field.getOne();
// 
//         when(f.value(xA)).thenReturn(yA);
//         when(f.value(xB)).thenReturn(yB);
//         when(f.value(any())).thenReturn(yA, yB, yA.negate(), yB.negate(), field.getZero());
// 
//         FieldBracketingNthOrderBrentSolver<RealFieldElement<?>> solver = new FieldBracketingNthOrderBrentSolver<>(
//                 field.getOne(), field.getOne(), field.getOne(), 3);
// 
//         RealFieldElement<?> result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// 
//         assertNotNull(result, "Solver should adjust bracketing and find a root");
//     }

//     @Test
//     @DisplayName("solve handles AllowedSolution.LEFT_SIDE with yA <= 0")
//     void TC20_solveLeftSide_yAIsLessOrEqualZero() throws Exception {
//         int maxEval = 100;
//         RealFieldUnivariateFunction<RealFieldElement<?>> f = Mockito.mock(RealFieldUnivariateFunction.class);
//         Field<RealFieldElement<?>> field = Decimal64Field.getInstance();
//         RealFieldElement<?> min = field.getZero();
//         RealFieldElement<?> max = field.getOne();
//         RealFieldElement<?> startValue = field.getOne().multiply(0.5);
//         AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
//         RealFieldElement<?> xA = min;
//         RealFieldElement<?> xB = max;
//         RealFieldElement<?> yA = field.getOne().negate();
//         RealFieldElement<?> yB = field.getOne();
// 
//         when(f.value(xA)).thenReturn(yA);
//         when(f.value(xB)).thenReturn(yB);
// 
//         FieldBracketingNthOrderBrentSolver<RealFieldElement<?>> solver = new FieldBracketingNthOrderBrentSolver<>(
//                 field.getOne(), field.getOne(), field.getOne(), 3);
// 
//         RealFieldElement<?> result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// 
//         assertEquals(xA, result, "Solver should return xA as the root when AllowedSolution is LEFT_SIDE and yA <= 0");
//     }

}