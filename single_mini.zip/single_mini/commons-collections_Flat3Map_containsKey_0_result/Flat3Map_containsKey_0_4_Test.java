package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_containsKey_0_4_Test {

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, size is 2, and hash does not match hash2")
    public void TC16_containsKey_returnsFalse_delegateMapNull_keyNotNull_size2_hashMismatch() throws Exception {
        // Initialize Flat3Map
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Set delegateMap to null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 2 via reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 2);

        // Create a specific key
        Object key = new Object();

        // Set hash2 to a different hashCode than key.hashCode() via reflection
        int keyHash = key.hashCode();
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(flat3Map, keyHash + 1); // Ensure hash2 != key.hashCode()

        // Invoke containsKey
        boolean result = flat3Map.containsKey(key);

        // Assert the result is false
        assertFalse(result, "containsKey should return false when delegateMap is null, key is not null, size is 2, and hash does not match hash2");
    }
}