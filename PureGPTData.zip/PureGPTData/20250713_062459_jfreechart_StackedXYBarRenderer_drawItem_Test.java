import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class StackedXYBarRendererTest {
    private StackedXYBarRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    public void setUp() {
        renderer = new StackedXYBarRenderer();
        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
        g2 = image.createGraphics();
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class, RETURNS_DEEP_STUBS);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(IntervalXYDataset.class, withSettings().extraInterfaces(TableXYDataset.class));
        crosshairState = mock(CrosshairState.class);
        state = new XYItemRendererState(info);
        
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0);
        when((plot.getOrientation())).thenReturn(PlotOrientation.VERTICAL);
    }

    @Test
    public void testDrawItem_withNullDataset() {
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_withInvalidDataset() {
        XYDataset invalidDataset = mock(XYDataset.class);
        assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, invalidDataset, 0, 0, crosshairState, 0);
        });
    }

    @Test
    public void testDrawItem_seriesNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_valueIsNaN() {
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_renderAsPercentages() {
        renderer.setRenderAsPercentages(true);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_startXIsNaN() {
        when(((IntervalXYDataset) dataset).getStartXValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_endXIsNaN() {
        when(((IntervalXYDataset) dataset).getEndXValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_negativeValue() {
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(-1.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 2);
    }

    @Test
    public void testDrawItem_horizontalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    public void testDrawItem_verticalOrientation() {
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
    }

    @Test
    public void testDrawItem_itemLabelVisible() {
        when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 2);
    }

    @Test
    public void testDrawItem_itemLabelNotVisible() {
        when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 2);
    }
}