package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.util.Arrays;
import java.util.List;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/**
 * Test class for XYBoxAndWhiskerRenderer's drawVerticalItem method.
 */
public class XYBoxAndWhiskerRenderer_drawVerticalItem_1_2_Test {

    /**
     * TC26: drawVerticalItem with exception thrown by getItemStroke.
     * 
     * Description: Verifies that drawVerticalItem propagates a RuntimeException
     * thrown by the getItemStroke method.
     */
    @Test
    @DisplayName("TC26: drawVerticalItem with exception thrown by getItemStroke")
    void TC26_drawVerticalItem_RuntimeExceptionFromGetItemStroke() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
        
        // Mock getItemStroke to throw RuntimeException
        doThrow(new RuntimeException("Test exception")).when(renderer)
                .getItemStroke(Mockito.anyInt(), Mockito.anyInt());
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;
        
        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, 
                                     dataset, series, item, crosshairState, pass);
        });
    }

    /**
     * TC27: drawVerticalItem with multiple iterations in outliers processing loop.
     * 
     * Description: Verifies that all outliers are processed correctly with appropriate
     * calls to drawEllipse or drawMultipleEllipse.
     */
    @Test
    @DisplayName("TC27: drawVerticalItem with multiple iterations in outliers processing loop")
    void TC27_drawVerticalItem_MultipleOutliersProcessing() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;
        
        // Create a mock dataset with multiple outliers
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset.getX(series, item)).thenReturn(1.0);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(10.0);
        when(dataset.getMinRegularValue(series, item)).thenReturn(2.0);
        when(dataset.getMedianValue(series, item)).thenReturn(5.0);
        when(dataset.getMeanValue(series, item)).thenReturn(5.5);
        when(dataset.getQ1Value(series, item)).thenReturn(3.0);
        when(dataset.getQ3Value(series, item)).thenReturn(7.0);
        List<Double> outliers = Arrays.asList(1.5, 1.6, 1.7);
        when(dataset.getOutliers(series, item)).thenReturn(outliers);
        
        // Mock domain and range axis conversions
        when(domainAxis.valueToJava2D(any(Double.class), any(Rectangle2D.class), any()))
            .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(any(Double.class), any(Rectangle2D.class), any()))
            .thenAnswer(invocation -> {
                Double value = invocation.getArgument(0);
                // Simple mock conversion for demonstration
                return value * 10.0;
            });
        
        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, 
                                 dataset, series, item, crosshairState, pass);
        
        // Assert
        // Verify that drawEllipse is called for each outlier
        verify(renderer, times(outliers.size())).drawEllipse(any(Point2D.class), Mockito.anyDouble(), Mockito.eq(g2));
    }
}