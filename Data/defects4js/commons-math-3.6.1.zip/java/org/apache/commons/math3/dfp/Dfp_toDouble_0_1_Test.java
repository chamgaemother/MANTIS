package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Dfp_toDouble_0_1_Test {

    @Test
    @DisplayName("toDouble returns Double.NEGATIVE_INFINITY when Dfp is infinite and less than zero")
    public void TC01() {
        // Arrange
        Dfp dfp = new DfpField(10).getZero();
        dfp.nans = Dfp.INFINITE;
        dfp.sign = -1;

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(Double.NEGATIVE_INFINITY, result);
    }

    @Test
    @DisplayName("toDouble returns Double.POSITIVE_INFINITY when Dfp is infinite and not less than zero")
    public void TC02() {
        // Arrange
        Dfp dfp = new DfpField(10).getZero();
        dfp.nans = Dfp.INFINITE;
        dfp.sign = 1;

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(Double.POSITIVE_INFINITY, result);
    }

    @Test
    @DisplayName("toDouble returns Double.NaN when Dfp is NaN")
    public void TC03() {
        // Arrange
        Dfp dfp = new DfpField(10).getZero();
        dfp.nans = Dfp.QNAN;

        // Act
        double result = dfp.toDouble();

        // Assert
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("toDouble returns -0.0 when Dfp is zero with negative sign")
    public void TC04() {
        // Arrange
        Dfp dfp = new DfpField(10).getZero();
        dfp.sign = -1;

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(-0.0, result);
    }

    @Test
    @DisplayName("toDouble returns +0.0 when Dfp is zero with non-negative sign")
    public void TC05() {
        // Arrange
        Dfp dfp = new DfpField(10).getZero();
        dfp.sign = 1;

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(+0.0, result);
    }

}