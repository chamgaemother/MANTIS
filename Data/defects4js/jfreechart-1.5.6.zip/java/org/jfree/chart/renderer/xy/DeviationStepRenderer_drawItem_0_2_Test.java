package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Field;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class DeviationStepRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem handles NaN yHigh in pass=0")
    public void TC06_drawItem_handles_NaN_yHigh_in_pass0() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 1;
        int pass = 0;

        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getStartYValue(series, item)).thenReturn(0.5);
        when(dataset.getEndYValue(series, item)).thenReturn(Double.NaN);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        DeviationStepRenderer renderer = new DeviationStepRenderer();
        DeviationStepRenderer spyRenderer = spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(series, item);

        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, never()).fill(any(GeneralPath.class));
    }

//     @Test
//     @DisplayName("drawItem processes horizontal orientation in pass=0")
//     public void TC07_drawItem_processes_horizontal_orientation_in_pass0() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new DeviationStepRenderer.State(); // Correctly use the State class
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 2;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(2.0);
//         when(dataset.getStartYValue(series, item)).thenReturn(1.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(3.0);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(150.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
//         DeviationStepRenderer renderer = new DeviationStepRenderer();
//         DeviationStepRenderer spyRenderer = spy(renderer);
//         doReturn(true).when(spyRenderer).getItemVisible(series, item);
// 
//         spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         ArgumentCaptor<GeneralPath> pathCaptor = ArgumentCaptor.forClass(GeneralPath.class);
//         verify(g2).fill(pathCaptor.capture());
//         GeneralPath path = pathCaptor.getValue();
//         assertNotNull(path);
//     }

//     @Test
//     @DisplayName("drawItem processes vertical orientation in pass=0")
//     public void TC08_drawItem_processes_vertical_orientation_in_pass0() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new DeviationStepRenderer.State(); // Correctly use the State class
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 1;
//         int item = 3;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(3.0);
//         when(dataset.getStartYValue(series, item)).thenReturn(2.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(4.0);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(300.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(250.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         DeviationStepRenderer renderer = new DeviationStepRenderer();
//         DeviationStepRenderer spyRenderer = spy(renderer);
//         doReturn(true).when(spyRenderer).getItemVisible(series, item);
// 
//         spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         ArgumentCaptor<GeneralPath> pathCaptor = ArgumentCaptor.forClass(GeneralPath.class);
//         verify(g2).fill(pathCaptor.capture());
//         GeneralPath path = pathCaptor.getValue();
//         assertNotNull(path);
//     }

//     @Test
//     @DisplayName("drawItem draws shading when item is the last in the series")
//     public void TC09_drawItem_draws_shading_when_item_is_last_in_series() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new DeviationStepRenderer.State(); // Correctly use the State class
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 2;
//         int item = 4;
//         int pass = 0;
// 
//         when(dataset.getItemCount(series)).thenReturn(5);
//         when(dataset.getXValue(series, item)).thenReturn(4.0);
//         when(dataset.getStartYValue(series, item)).thenReturn(3.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(5.0);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(400.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(350.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         DeviationStepRenderer renderer = new DeviationStepRenderer();
//         DeviationStepRenderer spyRenderer = spy(renderer);
//         doReturn(true).when(spyRenderer).getItemVisible(series, item);
// 
//         spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         ArgumentCaptor<GeneralPath> pathCaptor = ArgumentCaptor.forClass(GeneralPath.class);
//         verify(g2).fill(pathCaptor.capture());
//         GeneralPath path = pathCaptor.getValue();
//         assertNotNull(path);
//     }

//     @Test
//     @DisplayName("drawItem does not draw shading if lowerCoordinates size is <=1")
//     public void TC10_drawItem_does_not_draw_shading_if_lowerCoordinates_size_le_1() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new DeviationStepRenderer.State(); // Correctly use the State class
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 3;
//         int item = 5;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(5.0);
//         when(dataset.getStartYValue(series, item)).thenReturn(4.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(6.0);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(500.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(450.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
        // State must be initialized correctly
//         List<double[]> lowerCoordinates = new ArrayList<>();
//         Field lowerField = DeviationStepRenderer.State.class.getDeclaredField("lowerCoordinates");
//         lowerField.setAccessible(true);
//         lowerField.set(state, lowerCoordinates);
// 
//         lowerCoordinates.add(new double[]{100.0, 200.0}); // Add initial value so size is not <= 1
// 
//         DeviationStepRenderer renderer = new DeviationStepRenderer();
//         DeviationStepRenderer spyRenderer = spy(renderer);
//         doReturn(true).when(spyRenderer).getItemVisible(series, item);
// 
//         spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         verify(g2, never()).fill(any(GeneralPath.class));
//     }

}