package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class DfpMath_pow_0_7_Test {

    @Test
    @DisplayName("pow(x, y) handles y with fractional part, ensuring exp and log are used")
    public void TC31() throws Exception {
        // Initialize x > 0
        DfpField dfpField = new DfpField(20); // Added a suitable precision initialization
        Dfp x = dfpField.newDfp("2.0");

        // Initialize y with fractional part
        Dfp y = dfpField.newDfp("3.5");

        // Perform pow operation
        Dfp result = DfpMath.pow(x, y);

        // Compute expected result using exp and log
        Dfp expected = DfpMath.exp(DfpMath.log(x).multiply(y));

        // Assert the result is as expected
        assertEquals(expected, result, "Result should be equal to exp(log(x) * y)");
    }

    @Test
    @DisplayName("pow(x=-Infinity, y odd positive integer >0) returns -Infinity")
    public void TC32() throws Exception {
        // Initialize x as -Infinity
        DfpField dfpField = new DfpField(20);
        Dfp x = dfpField.getZero().divide(dfpField.getZero()).negate();

        // Initialize y as odd positive integer
        Dfp y = dfpField.newDfp("3");

        // Perform pow operation
        Dfp result = DfpMath.pow(x, y);

        // Assert the result is -Infinity
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertTrue(result.lessThan(dfpField.getZero()), "Result should be negative infinity");
    }

    @Test
    @DisplayName("pow(x=-Infinity, y odd negative integer <0) returns +0")
    public void TC33() throws Exception {
        // Initialize x as -Infinity
        DfpField dfpField = new DfpField(20);
        Dfp x = dfpField.getZero().divide(dfpField.getZero()).negate();

        // Initialize y as odd negative integer
        Dfp y = dfpField.newDfp("-3");

        // Perform pow operation
        Dfp result = DfpMath.pow(x, y);

        // Assert the result is +0
        assertFalse(result.isInfinite(), "Result should not be infinite");
        assertEquals(dfpField.getZero(), result, "Result should be zero");
    }

    @Test
    @DisplayName("pow(x=Infinity, y even integer) returns +Infinity")
    public void TC34() throws Exception {
        // Initialize x as +Infinity
        DfpField dfpField = new DfpField(20);
        Dfp x = dfpField.getZero().divide(dfpField.getZero());

        // Initialize y as even integer
        Dfp y = dfpField.newDfp("2");

        // Perform pow operation
        Dfp result = DfpMath.pow(x, y);

        // Assert the result is +Infinity
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertTrue(result.greaterThan(dfpField.getZero()), "Result should be positive infinity");
    }

    @Test
    @DisplayName("pow(x<0, y even integer) returns pow(|x|, y)")
    public void TC35() throws Exception {
        // Initialize x as negative finite Dfp
        DfpField dfpField = new DfpField(20);
        Dfp x = dfpField.newDfp("-2.0");

        // Initialize y as even integer
        Dfp y = dfpField.newDfp("4");

        // Perform pow operation
        Dfp result = DfpMath.pow(x, y);

        // Compute expected result as pow(|x|, y)
        Dfp expected = DfpMath.pow(x.negate(), y);

        // Assert the result is equal to expected
        assertEquals(expected, result, "Result should be equal to pow(|x|, y)");
    }

    @Test
    @DisplayName("pow(x<0, y fractional) returns NaN with FLAG_INVALID")
    public void TC36() throws Exception {
        // Initialize x as negative finite Dfp
        DfpField dfpField = new DfpField(20);
        Dfp x = dfpField.newDfp("-2.0");

        // Initialize y as fractional Dfp
        Dfp y = dfpField.newDfp("2.5");

        // Perform pow operation
        Dfp result = DfpMath.pow(x, y);

        // Assert the result is NaN
        assertTrue(result.isNaN(), "Result should be NaN");

        // Access the IEEEFlagsBits using reflection
        Field field = Dfp.class.getDeclaredField("field");
        field.setAccessible(true);
        DfpField fieldInstance = (DfpField) field.get(x);

        Field flagsField = DfpField.class.getDeclaredField("ieeeFlagsBits");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(fieldInstance);

        // Assert that FLAG_INVALID is set
        assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");
    }
}