package org.jsoup.select;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeTraversor;
import org.jsoup.select.NodeVisitor;

import static org.junit.jupiter.api.Assertions.*;

public class NodeTraversor_traverse_2_1_Test {

    private static class MockNodeVisitor implements NodeVisitor {
        int headCallCount = 0;
        int tailCallCount = 0;

        @Override
        public void head(Node node, int depth) {
            headCallCount++;
        }

        @Override
        public void tail(Node node, int depth) {
            tailCallCount++;
        }
    }

    @Test
    @DisplayName("Traverse with node having no next sibling and not the root, triggering ascension")
    public void TC06() {
        // GIVEN
        MockNodeVisitor visitor = new MockNodeVisitor();
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        assertEquals(2, visitor.headCallCount, "head should be called 2 times");
        assertEquals(2, visitor.tailCallCount, "tail should be called 2 times");
    }

    @Test
    @DisplayName("Traverse with multiple iterations causing depth to increment and decrement")
    public void TC07() {
        // GIVEN
        MockNodeVisitor visitor = new MockNodeVisitor();
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element grandchild = new Element("grandchild");
        root.appendChild(child1);
        root.appendChild(child2);
        child1.appendChild(grandchild);

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        assertEquals(4, visitor.headCallCount, "head should be called 4 times");
        assertEquals(4, visitor.tailCallCount, "tail should be called 4 times");
    }

    @Test
    @DisplayName("Traverse where node.nextSibling() is null and node equals root, triggering normal return")
    public void TC08() {
        // GIVEN
        MockNodeVisitor visitor = new MockNodeVisitor();
        Element root = new Element("root");

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        assertEquals(1, visitor.headCallCount, "head should be called 1 time");
        assertEquals(1, visitor.tailCallCount, "tail should be called 1 time");
    }

    @Test
    @DisplayName("Traverse causing node.nextSibling() to return null and node != root, triggering ascension")
    public void TC09() {
        // GIVEN
        MockNodeVisitor visitor = new MockNodeVisitor();
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        assertEquals(2, visitor.headCallCount, "head should be called 2 times");
        assertEquals(2, visitor.tailCallCount, "tail should be called 2 times");
    }

    @Test
    @DisplayName("Traverse with multiple iterations where depth increments and no child nodes to descend")
    public void TC10() {
        // GIVEN
        MockNodeVisitor visitor = new MockNodeVisitor();
        Element root = new Element("root");
        root.appendChild(new Element("child1"));
        root.appendChild(new Element("child2"));
        root.appendChild(new Element("child3"));

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        assertEquals(4, visitor.headCallCount, "head should be called 4 times");
        assertEquals(4, visitor.tailCallCount, "tail should be called 4 times");
    }
}