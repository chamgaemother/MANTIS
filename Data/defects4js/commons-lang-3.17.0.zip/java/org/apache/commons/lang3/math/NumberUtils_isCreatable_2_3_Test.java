package org.apache.commons.lang3.math;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_isCreatable_2_3_Test {

    @Test
    @DisplayName("isCreatable(\"0x1A3Ff\") returns false for invalid type qualifier 'f' after hexadecimal")
    void test_TC51_isCreatable_invalid_type_qualifier_after_hexadecimal() {
        // GIVEN
        String input = "0x1A3Ff";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result, "Expected isCreatable(\"0x1A3Ff\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\" 123\") returns false for leading whitespace")
    void test_TC52_isCreatable_leading_whitespace() {
        // GIVEN
        String input = " 123";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result, "Expected isCreatable(\" 123\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"123 \") returns false for trailing whitespace")
    void test_TC53_isCreatable_trailing_whitespace() {
        // GIVEN
        String input = "123 ";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result, "Expected isCreatable(\"123 \" ) to return false");
    }

    @Test
    @DisplayName("isCreatable(\"123abc\") returns false for trailing non-numeric characters")
    void test_TC54_isCreatable_trailing_non_numeric_characters() {
        // GIVEN
        String input = "123abc";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result, "Expected isCreatable(\"123abc\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"0x1A3G\") returns false for invalid hexadecimal character 'G'")
    void test_TC55_isCreatable_invalid_hexadecimal_character() {
        // GIVEN
        String input = "0x1A3G";
        
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        
        // THEN
        assertFalse(result, "Expected isCreatable(\"0x1A3G\") to return false");
    }
}