package org.apache.commons.math3.stat.descriptive.rank;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

public class PSquarePercentile_equals_1_1_Test {

    @Test
    @DisplayName("equals returns true when comparing the object to itself (this == o)")
    public void TC01_equals_SameObject_ReturnsTrue() {
        // GIVEN
        PSquarePercentile obj = new PSquarePercentile(50.0);

        // WHEN
        boolean result = obj.equals(obj);

        // THEN
        assertTrue(result, "An object should be equal to itself.");
    }

    @Test
    @DisplayName("equals returns false when the other object is null")
    public void TC02_equals_NullObject_ReturnsFalse() {
        // GIVEN
        PSquarePercentile obj = new PSquarePercentile(50.0);

        // WHEN
        boolean result = obj.equals(null);

        // THEN
        assertFalse(result, "An object should not be equal to null.");
    }

    @Test
    @DisplayName("equals returns false when the other object is not an instance of PSquarePercentile")
    public void TC03_equals_DifferentType_ReturnsFalse() {
        // GIVEN
        PSquarePercentile obj = new PSquarePercentile(50.0);
        String other = "Not a PSquarePercentile";

        // WHEN
        boolean result = obj.equals(other);

        // THEN
        assertFalse(result, "PSquarePercentile should not be equal to an object of a different type.");
    }

    @Test
    @DisplayName("equals returns true when both objects have non-null, equal markers and equal observation counts")
    public void TC04_equals_EqualMarkersAndCounts_ReturnsTrue() throws Exception {
        // GIVEN
        PSquarePercentile obj1 = new PSquarePercentile(50.0);
        PSquarePercentile obj2 = new PSquarePercentile(50.0);

        // Creating identical markers using the public newMarkers method
        List<Double> initialFive = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        double p = 50.0 / 100.0;
        PSquarePercentile.PSquareMarkers markers = PSquarePercentile.newMarkers(initialFive, p);

        // Using reflection to set the private 'markers' field
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(obj1, markers);
        markersField.set(obj2, markers);

        // Using reflection to set the private 'countOfObservations' field to the same value
        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(obj1, 10L);
        countField.setLong(obj2, 10L);

        // WHEN
        boolean result = obj1.equals(obj2);

        // THEN
        assertTrue(result, "Both objects should be equal when they have identical markers and observation counts.");
    }

    @Test
    @DisplayName("equals returns false when both objects have non-null, equal markers but different observation counts")
    public void TC05_equals_EqualMarkersDifferentCounts_ReturnsFalse() throws Exception {
        // GIVEN
        PSquarePercentile obj1 = new PSquarePercentile(50.0);
        PSquarePercentile obj2 = new PSquarePercentile(50.0);

        // Creating identical markers using the public newMarkers method
        List<Double> initialFive = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        double p = 50.0 / 100.0;
        PSquarePercentile.PSquareMarkers markers = PSquarePercentile.newMarkers(initialFive, p);

        // Using reflection to set the private 'markers' field
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(obj1, markers);
        markersField.set(obj2, markers);

        // Using reflection to set the private 'countOfObservations' field to different values
        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(obj1, 10L);
        countField.setLong(obj2, 20L);

        // WHEN
        boolean result = obj1.equals(obj2);

        // THEN
        assertFalse(result, "Objects should not be equal when their observation counts differ, even if markers are identical.");
    }
}