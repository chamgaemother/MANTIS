import org.apache.commons.compress.harmony.pack200.IntList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IntListTest {

    @Test
    void testAddAtMiddle_withGrowForInsert() {
        // Arrange
        IntList list = new IntList(5);
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // Act
        list.add(2, 100);
        // Assert
        assertEquals(6, list.size());
        assertEquals(100, list.get(2));
        for (int i = 0; i < 2; i++) {
            assertEquals(i, list.get(i));
        }
        for (int i = 3; i < 6; i++) {
            assertEquals(i - 1, list.get(i));
        }
    }

    @Test
    void testAddAtMiddle_withSystemArraycopy_locationLessThanHalfAndFirstIndexGreaterThanZero() {
        // Arrange
        IntList list = new IntList(10);
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // Simulate firstIndex > 0
        list.add(0, -1);
        list.add(0, -2);
        // Act
        list.add(2, 100);
        // Assert
        assertEquals(7, list.size());
        assertEquals(100, list.get(2));
        assertEquals(-2, list.get(0));
        assertEquals(-1, list.get(1));
        for (int i = 3; i < 7; i++) {
            assertEquals(i - 3, list.get(i));
        }
    }

    @Test
    void testAddAtMiddle_withSystemArraycopy_lastIndexAtArrayLength() {
        // Arrange
        IntList list = new IntList(5);
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // Act
        list.add(2, 100);
        // Assert
        assertEquals(6, list.size());
        assertEquals(100, list.get(2));
        for (int i = 0; i < 2; i++) {
            assertEquals(i, list.get(i));
        }
        for (int i = 3; i < 6; i++) {
            assertEquals(i - 1, list.get(i));
        }
    }

    @Test
    void testAddAtMiddle_elseCondition() {
        // Arrange
        IntList list = new IntList(10);
        for (int i = 0; i < 6; i++) {
            list.add(i);
        }
        // Act
        list.add(4, 100);
        // Assert
        assertEquals(7, list.size());
        assertEquals(100, list.get(4));
        for (int i = 0; i < 4; i++) {
            assertEquals(i, list.get(i));
        }
        for (int i = 5; i < 7; i++) {
            assertEquals(i - 1, list.get(i));
        }
    }

    @Test
    void testAddAtZero_withGrowAtFront() {
        // Arrange
        IntList list = new IntList(5);
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // Act
        list.add(0, 100);
        // Assert
        assertEquals(6, list.size());
        assertEquals(100, list.get(0));
        for (int i = 1; i < 6; i++) {
            assertEquals(i - 1, list.get(i));
        }
    }

    @Test
    void testAddAtZero_withoutGrowAtFront() {
        // Arrange
        IntList list = new IntList(10);
        list.add(1);
        list.add(2);
        // Act
        list.add(0, 100);
        // Assert
        assertEquals(3, list.size());
        assertEquals(100, list.get(0));
        assertEquals(1, list.get(1));
        assertEquals(2, list.get(2));
    }

    @Test
    void testAddAtSize_withGrowAtEnd() {
        // Arrange
        IntList list = new IntList(5);
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // Act
        list.add(5, 100);
        // Assert
        assertEquals(6, list.size());
        assertEquals(100, list.get(5));
    }

    @Test
    void testAddAtSize_withoutGrowAtEnd() {
        // Arrange
        IntList list = new IntList(10);
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // Act
        list.add(5, 100);
        // Assert
        assertEquals(6, list.size());
        assertEquals(100, list.get(5));
    }

    @Test
    void testAdd_withInvalidNegativeLocation() {
        // Arrange
        IntList list = new IntList();
        list.add(1);
        // Act & Assert
        assertThrows(IndexOutOfBoundsException.class, () -> list.add(-1, 100));
    }

    @Test
    void testAdd_withLocationGreaterThanSize() {
        // Arrange
        IntList list = new IntList();
        list.add(1);
        // Act & Assert
        assertThrows(IndexOutOfBoundsException.class, () -> list.add(2, 100));
    }

    @Test
    void testAddAtMiddle_firstIndexNotZero_lastIndexNotArrayLength() {
        // Arrange
        IntList list = new IntList(10);
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // Simulate firstIndex > 0
        list.remove(0);
        list.remove(0);
        // Act
        list.add(1, 100);
        // Assert
        assertEquals(4, list.size());
        assertEquals(100, list.get(1));
        assertEquals(2, list.get(0));
        assertEquals(3, list.get(2));
        assertEquals(4, list.get(3));
    }

    @Test
    void testAddAtZero_whenListIsEmpty() {
        // Arrange
        IntList list = new IntList();
        // Act
        list.add(0, 100);
        // Assert
        assertEquals(1, list.size());
        assertEquals(100, list.get(0));
    }

    @Test
    void testAddAtSize_whenListIsEmpty() {
        // Arrange
        IntList list = new IntList();
        // Act
        list.add(0, 100);
        // Assert
        assertEquals(1, list.size());
        assertEquals(100, list.get(0));
    }

    @Test
    void testAddMultipleElements() {
        // Arrange
        IntList list = new IntList(5);
        list.add(0, 1);
        list.add(1, 2);
        list.add(1, 3);
        list.add(0, 4);
        list.add(3, 5);
        // Act & Assert
        assertEquals(5, list.size());
        assertArrayEquals(new int[]{4, 1, 3, 2, 5}, list.toArray());
    }
}