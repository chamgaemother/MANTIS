package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DoubleMetaphone_doubleMetaphone_0_3_Test {

    @Test
    @DisplayName("doubleMetaphone(\"GGGG\", false) handles multiple 'G's")
    public void TC11_doubleMetaphone_multiple_Gs() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GGGG";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        String expected = "KKKK"; // Assuming each 'G' is encoded as 'K'
        assertEquals(expected, result, "Multiple 'G's should be encoded correctly as 'KKKK'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"HELLO\", false) handles 'H' between vowels")
    public void TC12_doubleMetaphone_H_between_vowels() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "HELLO";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        String expected = "HL"; // 'H' between vowels is typically encoded as 'H'
        assertEquals(expected, result, "'H' between vowels should be encoded correctly as 'H'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"JAZZ\", false) handles 'J' with double 'Z'")
    public void TC13_doubleMetaphone_J_double_Z() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "JAZZ";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        String expected = "JTS"; // 'J' -> 'J', 'Z' -> 'S'
        assertEquals(expected, result, "'J' and double 'Z's should be encoded correctly as 'JTS'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"LLAMA\", false) handles double 'L'")
    public void TC14_doubleMetaphone_double_L() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "LLAMA";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        String expected = "LAMA"; // Double 'L' encoded as single 'L'
        assertEquals(expected, result, "Double 'L' should be encoded as single 'L'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"MMMM\", false) handles multiple 'M's with conditionM0")
    public void TC15_doubleMetaphone_multiple_Ms_conditionM0() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "MMMM";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        String expected = "MM"; // Assuming conditionM0 encodes multiple 'M's as 'MM'
        assertEquals(expected, result, "Multiple 'M's should be encoded correctly based on conditionM0 as 'MM'");
    }
}