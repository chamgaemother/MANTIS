import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.DefaultOHLCDataset;
import org.jfree.data.xy.DefaultIntervalXYDataset;
import org.jfree.data.xy.YIntervalSeries;
import org.jfree.data.xy.YIntervalSeriesCollection;
import org.junit.jupiter.api.Test;

public class DatasetUtilsTest {
    
    @Test
    public void testIterateRangeBoundsWithNullDataset() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateRangeBounds(null, true);
        });
    }
    
    @Test
    public void testIterateRangeBoundsWithEmptyDataset() {
        XYDataset dataset = new DefaultXYDataset();
        Range result = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNull(result);
    }

    @Test
    public void testIterateRangeBoundsWithNonIntervalDataset() {
        DefaultXYDataset dataset = new DefaultXYDataset();
        dataset.addSeries("Series1", new double[][]{{1.0, 2.0, 3.0}, {5.0, 0.0, 10.0}});
        Range result = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNotNull(result);
        assertEquals(0.0, result.getLowerBound());
        assertEquals(10.0, result.getUpperBound());
    }

    @Test
    public void testIterateRangeBoundsWithIntervalXYDataset() {
        YIntervalSeries series = new YIntervalSeries("Series1");
        series.add(1.0, 2.0, 1.5, 2.5);
        series.add(2.0, 3.0, 2.5, 3.5);
        series.add(3.0, Double.NaN, Double.NaN, Double.NaN);
        YIntervalSeriesCollection dataset = new YIntervalSeriesCollection();
        dataset.addSeries(series);
        Range result = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(result);
        assertEquals(1.5, result.getLowerBound());
        assertEquals(3.5, result.getUpperBound());
    }

    @Test
    public void testIterateRangeBoundsWithNaNValues() {
        DefaultXYDataset dataset = new DefaultXYDataset();
        dataset.addSeries("Series1", new double[][]{{1.0, 2.0, 3.0}, {Double.NaN, Double.NaN, Double.NaN}});
        Range result = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNull(result);
    }

    @Test
    public void testIterateRangeBoundsWithOHLCDataset() {
        double[] date = {1.0, 2.0, 3.0};
        double[] high = {5.0, 8.0, 9.0};
        double[] low = {2.0, 1.5, 6.0};
        double[] open = {3.0, 6.0, 7.0};
        double[] close = {4.0, 7.0, 8.0};
        DefaultOHLCDataset dataset = new DefaultOHLCDataset("Series1", 
                new Object[] {date, high, low, open, close, null});
        Range result = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(result);
        assertEquals(1.5, result.getLowerBound());
        assertEquals(9.0, result.getUpperBound());
    }

    @Test
    public void testIterateRangeBoundsWithNonOHLCDataset() {
        DefaultXYDataset dataset = new DefaultXYDataset();
        dataset.addSeries("Series1", new double[][]{{1.0, 2.0, 3.0}, {5.0, Double.NaN, 10.0}});
        Range result = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNotNull(result);
        assertEquals(5.0, result.getLowerBound());
        assertEquals(10.0, result.getUpperBound());
    }
}