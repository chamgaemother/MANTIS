package org.apache.commons.math3.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ArithmeticUtils_gcd_1_2_Test {

    @Test
    @DisplayName("gcd(270, 192) returns 6 with multiple iterations in main GCD loop")
    void testGcd_TC22() {
        int p = 270;
        int q = 192;
        int result = ArithmeticUtils.gcd(p, q);
        assertEquals(6, result, "The GCD of 270 and 192 should be 6");
    }
}