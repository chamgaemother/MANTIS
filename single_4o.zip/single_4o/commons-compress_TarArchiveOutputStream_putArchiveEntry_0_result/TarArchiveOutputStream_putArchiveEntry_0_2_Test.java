package org.apache.commons.compress.archivers.tar;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import java.util.Map;
import java.util.HashMap;
import java.io.IOException;

public class TarArchiveOutputStream_putArchiveEntry_0_2_Test {

    @Test
    @DisplayName("Check handling of null link name in entry.")
    void testNullLinkNameHandling() throws Exception {
        // GIVEN an entry with a null link name
        TarArchiveEntry entry = new TarArchiveEntry("testEntry");
        entry.setLinkName(null);

        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());

        // WHEN putArchiveEntry is run
        // THEN expect no exceptions and accurate handling of the entry
        assertDoesNotThrow(() -> outputStream.putArchiveEntry(entry));
    }

    @Test
    @DisplayName("Verify exception throw for truncated long names.")
    void testExceptionForTruncatedLongNames() throws Exception {
        // GIVEN entry exceeding length limits and stream in error longfile mode
        TarArchiveEntry entry = new TarArchiveEntry("aVeryLongFileNameThatExceedsNormalLimitationsInTarArchives");
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());

        // Manually set the longFileMode to LONGFILE_ERROR using reflection
        Field longFileModeField = TarArchiveOutputStream.class.getDeclaredField("longFileMode");
        longFileModeField.setAccessible(true);
        longFileModeField.set(outputStream, TarArchiveOutputStream.LONGFILE_ERROR);  // Using constant for clarity

        // WHEN putArchiveEntry is executed
        // THEN IllegalArgumentException is thrown for truncated length
        assertThrows(IllegalArgumentException.class, () -> outputStream.putArchiveEntry(entry));
    }

    @Test
    @DisplayName("Ensure proper handling of a directory entry.")
    void testDirectoryEntryHandling() throws Exception {
        // GIVEN a directory TarArchiveEntry
        TarArchiveEntry entry = new TarArchiveEntry("testDirectory/");
        entry.setDirectory(true);

        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());

        // WHEN putArchiveEntry is being used
        // THEN ensure currSize is fixed to zero, validating the directory is treated correctly
        outputStream.putArchiveEntry(entry);

        // Assert currSize is zero
        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
        currSizeField.setAccessible(true);
        long currSize = (long) currSizeField.get(outputStream);

        assertEquals(0L, currSize, "currSize should be zero for directory entries.");
    }

    @Test
    @DisplayName("Confirm PaxHeaders addition when big numbers require it.")
    void testPaxHeadersForBigNumbers() throws Exception {
        // GIVEN entry demanding big number handling under POSIX mode
        TarArchiveEntry entry = new TarArchiveEntry("testBigNumberEntry");
        entry.setSize((long)Integer.MAX_VALUE + 1);  // large size to trigger big number handling

        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());

        // Manually set the bigNumberMode to BIGNUMBER_POSIX using reflection
        Field bigNumberModeField = TarArchiveOutputStream.class.getDeclaredField("bigNumberMode");
        bigNumberModeField.setAccessible(true);
        bigNumberModeField.set(outputStream, TarArchiveOutputStream.BIGNUMBER_POSIX);  // Using constant for clarity

        // WHEN putArchiveEntry is called
        Map<String, String> paxHeaders = new HashMap<>();

        Method addPaxHeadersForBigNumbersMethod = TarArchiveOutputStream.class.getDeclaredMethod("addPaxHeadersForBigNumbers", Map.class, TarArchiveEntry.class);
        addPaxHeadersForBigNumbersMethod.setAccessible(true);

        // THEN PaxHeaders are appropriately added for big numbers
        assertDoesNotThrow(() -> addPaxHeadersForBigNumbersMethod.invoke(outputStream, paxHeaders, entry));
        assertFalse(paxHeaders.isEmpty(), "PaxHeaders should be added for big numbers.");
    }

    @Test
    @DisplayName("Verify correct process of writing header for standard entry.")
    void testStandardEntryHeaderWriting() throws Exception {
        // GIVEN standard file entry
        TarArchiveEntry entry = new TarArchiveEntry("testStandardEntry");
        entry.setSize(1024);

        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(new ByteArrayOutputStream());

        // WHEN putArchiveEntry is called
        outputStream.putArchiveEntry(entry);

        // THEN standard entry header is written without complications
        // There are no direct assertions as this will just ensure no exceptions occur
        assertTrue(true, "Standard entry should be processed without exceptions.");
    }
}