package org.apache.commons.math3.analysis.solvers;

import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.util.Decimal64;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class FieldBracketingNthOrderBrentSolver_solve_2_1_Test {

    @Test
    @DisplayName("solve adjusts bracketing by dropping the lower point when guessX is outside the interval")
    void TC06_adjustBracketing_dropLowerPoint() throws NumberIsTooSmallException {
        // GIVEN
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = value -> value.getReal() < 0.5 ? new Decimal64(1.0) : new Decimal64(-1.0);
        Decimal64 min = new Decimal64(0.0);
        Decimal64 max = new Decimal64(1.0);
        Decimal64 startValue = new Decimal64(0.6);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;

        Decimal64 relativeAccuracy = new Decimal64(1e-8);
        Decimal64 absoluteAccuracy = new Decimal64(1e-8);
        Decimal64 functionValueAccuracy = new Decimal64(1e-15);
        int maximalOrder = 5;

        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
            new FieldBracketingNthOrderBrentSolver<>(relativeAccuracy, absoluteAccuracy, functionValueAccuracy, maximalOrder);

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        Assertions.assertEquals(0.5, result.getReal(), 1e-10);
    }

    @Test
    @DisplayName("solve handles multiple iterations with aging triggering targetY adjustment")
    void TC07_handleAgingTriggerTargetYAdjustment() throws NumberIsTooSmallException {
        // GIVEN
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = value -> new Decimal64(1.0); // Constant function, no root
        Decimal64 min = new Decimal64(0.0);
        Decimal64 max = new Decimal64(1.0);
        Decimal64 startValue = new Decimal64(0.5);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;

        Decimal64 relativeAccuracy = new Decimal64(1e-8);
        Decimal64 absoluteAccuracy = new Decimal64(1e-8);
        Decimal64 functionValueAccuracy = new Decimal64(1e-12);
        int maximalOrder = 5;

        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
            new FieldBracketingNthOrderBrentSolver<>(relativeAccuracy, absoluteAccuracy, functionValueAccuracy, maximalOrder);

        // WHEN
        Executable action = () -> solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        Assertions.assertThrows(NoBracketingException.class, action);
    }

}