import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYErrorRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

class XYErrorRendererTest {

    private XYErrorRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYErrorRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
    }

    @Test
    void testDrawItem_PassNotZero() {
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 1);
        verify(dataset, never()).getClass();
    }

    @Test
    void testDrawItem_DatasetNotIntervalXYDataset() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(dataset, never()).getClass();
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(ixyd);
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(ixyd, never()).getStartXValue(0, 0);
    }

    @Test
    void testDrawItem_DrawXErrorVerticalWithErrorPaintAndStroke() {
        IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(ixyd);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(ixyd.getStartXValue(0, 0)).thenReturn(1.0);
        when(ixyd.getEndXValue(0, 0)).thenReturn(2.0);
        when(ixyd.getYValue(0, 0)).thenReturn(5.0);

        renderer.setDrawXError(true);
        renderer.setErrorPaint(mock(Paint.class));
        renderer.setErrorStroke(mock(Stroke.class));

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);

        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, times(3)).draw(any());
    }

    @Test
    void testDrawItem_DrawXErrorHorizontalWithoutErrorPaintAndStroke() {
        IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(ixyd);
        when(renderer.getItemVisible(1, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(ixyd.getStartXValue(1, 1)).thenReturn(3.0);
        when(ixyd.getEndXValue(1, 1)).thenReturn(4.0);
        when(ixyd.getYValue(1, 1)).thenReturn(6.0);

        renderer.setDrawXError(true);
        renderer.setErrorPaint(null);
        renderer.setErrorStroke(null);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 1, 1, crosshairState, 0);

        verify(g2).setPaint(renderer.getItemPaint(1, 1));
        verify(g2).setStroke(renderer.getItemStroke(1, 1));
        verify(g2, times(3)).draw(any());
    }

    @Test
    void testDrawItem_DrawYErrorVerticalWithErrorPaintNullStrokeNonNull() {
        IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(ixyd);
        when(renderer.getItemVisible(2, 2)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(ixyd.getStartYValue(2, 2)).thenReturn(7.0);
        when(ixyd.getEndYValue(2, 2)).thenReturn(8.0);
        when(ixyd.getXValue(2, 2)).thenReturn(9.0);

        renderer.setDrawYError(true);
        renderer.setErrorPaint(null);
        renderer.setErrorStroke(mock(Stroke.class));

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 2, 2, crosshairState, 0);

        verify(g2).setPaint(renderer.getItemPaint(2, 2));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, times(3)).draw(any());
    }

    @Test
    void testDrawItem_DrawYErrorHorizontalWithoutError() {
        IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(ixyd);
        when(renderer.getItemVisible(3, 3)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(ixyd.getStartYValue(3, 3)).thenReturn(10.0);
        when(ixyd.getEndYValue(3, 3)).thenReturn(11.0);
        when(ixyd.getXValue(3, 3)).thenReturn(12.0);

        renderer.setDrawYError(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 3, 3, crosshairState, 0);

        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawItem_NullInputs() {
        renderer.drawItem(null, null, null, null, null, null, null, null, 0, 0, null, 0);
        // Expect no exception
    }

    @Test
    void testDrawItem_AllErrorsFalse() {
        IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(ixyd);
        when(renderer.getItemVisible(4, 4)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(ixyd.getStartXValue(4, 4)).thenReturn(13.0);
        when(ixyd.getEndXValue(4, 4)).thenReturn(14.0);
        when(ixyd.getYValue(4, 4)).thenReturn(15.0);

        renderer.setDrawXError(false);
        renderer.setDrawYError(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 4, 4, crosshairState, 0);

        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawItem_CapLengthZero() {
        IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
        when(dataset instanceof IntervalXYDataset).thenReturn(true);
        when((IntervalXYDataset) dataset).thenReturn(ixyd);
        when(renderer.getItemVisible(5, 5)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(ixyd.getStartXValue(5, 5)).thenReturn(16.0);
        when(ixyd.getEndXValue(5, 5)).thenReturn(17.0);
        when(ixyd.getYValue(5, 5)).thenReturn(18.0);

        renderer.setDrawXError(true);
        renderer.setCapLength(0.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 5, 5, crosshairState, 0);

        verify(g2, atLeastOnce()).draw(any());
    }
}