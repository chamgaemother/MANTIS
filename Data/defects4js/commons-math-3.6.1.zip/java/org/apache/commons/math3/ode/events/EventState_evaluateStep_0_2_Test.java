package org.apache.commons.math3.ode.events;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver;
import org.apache.commons.math3.analysis.solvers.UnivariateSolver;
import org.apache.commons.math3.analysis.solvers.PegasusSolver;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class EventState_evaluateStep_0_2_Test {

//    @Test
//    @DisplayName("evaluateStep detects an event on the first iteration with sign change")
//    void TC06_evaluateStep_detects_event_on_first_iteration_with_sign_change() {
//        // Arrange
//        StepInterpolator interpolator = mock(StepInterpolator.class);
//        when(interpolator.isForward()).thenReturn(true);
//        when(interpolator.getPreviousTime()).thenReturn(0.0);
//        when(interpolator.getCurrentTime()).thenReturn(1.0);
//
//        EventHandler handler = mock(EventHandler.class);
//        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0, 1.0);
//
//        BracketedUnivariateSolver<UnivariateFunction> solver = mock(BracketedUnivariateSolver.class);
//        when(solver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble(), any(AllowedSolution.class)))
//                .thenReturn(0.5);
//
//        EventState eventState = new EventState(handler, 0.1, 0.1, 100, solver);
//
//        // Act
//        boolean result = eventState.evaluateStep(interpolator);
//
//        // Assert
//        assertTrue(result);
//        assertEquals(0.5, extractField(eventState, "pendingEventTime"));
//        assertTrue((boolean) extractField(eventState, "pendingEvent"));
//    }
//
//    @Test
//    @DisplayName("evaluateStep detects multiple events across iterations")
//    void TC07_evaluateStep_detects_multiple_events_across_iterations() {
//        // Arrange
//        StepInterpolator interpolator = mock(StepInterpolator.class);
//        when(interpolator.isForward()).thenReturn(true);
//        when(interpolator.getPreviousTime()).thenReturn(0.0);
//        when(interpolator.getCurrentTime()).thenReturn(2.0);
//
//        EventHandler handler = mock(EventHandler.class);
//        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0, 1.0, -1.0, 1.0);
//
//        BracketedUnivariateSolver<UnivariateFunction> solver = mock(BracketedUnivariateSolver.class);
//        when(solver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble(), any(AllowedSolution.class)))
//                .thenReturn(0.5, 1.5);
//
//        EventState eventState = new EventState(handler, 0.1, 0.1, 100, solver);
//
//        // Act
//        boolean result = eventState.evaluateStep(interpolator);
//
//        // Assert
//        assertTrue(result);
//        assertEquals(1.5, extractField(eventState, "pendingEventTime"));
//        assertTrue((boolean) extractField(eventState, "pendingEvent"));
//    }
//
//    @Test
//    @DisplayName("evaluateStep handles no sign change within iteration")
//    void TC08_evaluateStep_handles_no_sign_change_within_iteration() {
//        // Arrange
//        StepInterpolator interpolator = mock(StepInterpolator.class);
//        when(interpolator.isForward()).thenReturn(true);
//        when(interpolator.getPreviousTime()).thenReturn(0.0);
//        when(interpolator.getCurrentTime()).thenReturn(1.0);
//
//        EventHandler handler = mock(EventHandler.class);
//        when(handler.g(anyDouble(), any(double[].class))).thenReturn(1.0, 1.0);
//
//        UnivariateSolver solver = mock(BracketedUnivariateSolver.class);
//
//        EventState eventState = new EventState(handler, 0.1, 0.1, 100, solver);
//
//        // Act
//        boolean result = eventState.evaluateStep(interpolator);
//
//        // Assert
//        assertFalse(result);
//        assertTrue(Double.isNaN((double) extractField(eventState, "pendingEventTime")));
//        assertFalse((boolean) extractField(eventState, "pendingEvent"));
//    }
//
//    @Test
//    @DisplayName("evaluateStep detects event with BracketedUnivariateSolver")
//    void TC09_evaluateStep_detects_event_with_BracketedUnivariateSolver() {
//        // Arrange
//        StepInterpolator interpolator = mock(StepInterpolator.class);
//        when(interpolator.isForward()).thenReturn(true);
//        when(interpolator.getPreviousTime()).thenReturn(0.0);
//        when(interpolator.getCurrentTime()).thenReturn(1.0);
//
//        EventHandler handler = mock(EventHandler.class);
//        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0, 1.0);
//
//        BracketedUnivariateSolver<UnivariateFunction> solver = mock(BracketedUnivariateSolver.class);
//        when(solver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble(), any(AllowedSolution.class)))
//                .thenReturn(0.5);
//
//        EventState eventState = new EventState(handler, 0.1, 0.1, 100, solver);
//
//        // Act
//        boolean result = eventState.evaluateStep(interpolator);
//
//        // Assert
//        assertTrue(result);
//        assertEquals(0.5, extractField(eventState, "pendingEventTime"));
//        assertTrue((boolean) extractField(eventState, "pendingEvent"));
//    }

    @Test
    @DisplayName("evaluateStep detects event with non-BracketedUnivariateSolver")
    void TC10_evaluateStep_detects_event_with_non_BracketedUnivariateSolver() {
        // Arrange
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);

        EventHandler handler = mock(EventHandler.class);
        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0, 1.0);

        UnivariateSolver solver = mock(UnivariateSolver.class);
        when(solver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble())).thenReturn(0.5);
        when(solver.getEvaluations()).thenReturn(10);

        EventState eventState = new EventState(handler, 0.1, 0.1, 100, solver);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertTrue(result);
        assertEquals(0.5, extractField(eventState, "pendingEventTime"));
        assertTrue((boolean) extractField(eventState, "pendingEvent"));
    }

    private Object extractField(Object obj, String fieldName) {
        try {
            Field field = obj.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(obj);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
