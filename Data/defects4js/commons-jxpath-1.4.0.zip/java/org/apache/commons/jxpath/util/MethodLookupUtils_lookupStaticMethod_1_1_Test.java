package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.JXPathException;

public class MethodLookupUtils_lookupStaticMethod_1_1_Test {

//     @Test
//     @DisplayName("Parameters array has first element as ExpressionContext and exact static method exists")
//     void TC14_lookupStaticMethod_with_ExpressionContext_first_parameter_and_exact_match() throws Exception {
        // Arrange
//         Class<?> targetClass = SomeClass.class;
//         String name = "staticMethodWithExpressionContext";
//         ExpressionContext context = new ExpressionContext();
//         Object[] parameters = new Object[] { context, "test" };
// 
        // Act
//         Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
// 
        // Assert
//         Assertions.assertNotNull(result, "Expected exact static method to be found with ExpressionContext as first parameter.");
//         Assertions.assertEquals("staticMethodWithExpressionContext", result.getName(), "Method name should match the requested name.");
//         Assertions.assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
//     }

    @Test
    @DisplayName("Parameters array length does not match any static method signature, resulting in NO_MATCH")
    void TC15_lookupStaticMethod_with_parameter_length_mismatch() throws Exception {
        // Arrange
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethodWithDifferentParameters";
        Object[] parameters = new Object[] { "onlyOneParameter" };

        // Act
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // Assert
        Assertions.assertNull(result, "Expected no method to be found due to parameter length mismatch.");
    }

//     @Test
//     @DisplayName("Parameters array includes an ExpressionContext but no matching static method exists")
//     void TC16_lookupStaticMethod_with_ExpressionContext_and_no_matching_method() throws Exception {
        // Arrange
//         Class<?> targetClass = SomeClass.class;
//         String name = "nonExistentStaticMethodWithExpressionContext";
//         ExpressionContext context = new ExpressionContext();
//         Object[] parameters = new Object[] { context, "extraParameter" };
// 
        // Act
//         Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
// 
        // Assert
//         Assertions.assertNull(result, "Expected no method to be found when including ExpressionContext without a matching method.");
//     }

    @Test
    @DisplayName("Parameters array contains primitive type parameters requiring type conversion")
    void TC17_lookupStaticMethod_with_primitive_parameters_requiring_conversion() throws Exception {
        // Arrange
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethodWithPrimitives";
        Object[] parameters = new Object[] { 10, 20 };

        // Act
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // Assert
        Assertions.assertNotNull(result, "Expected static method to be found after converting primitives to their wrapper types.");
        Assertions.assertEquals("staticMethodWithPrimitives", result.getName(), "Method name should match the requested name.");
        Assertions.assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }

//     @Test
//     @DisplayName("Ambiguous method call due to multiple static methods matching after type conversion with ExpressionContext")
//     void TC18_lookupStaticMethod_with_ExpressionContext_and_ambiguous_matches() {
        // Arrange
//         Class<?> targetClass = AmbiguousClassWithExpressionContext.class;
//         String name = "ambiguousStaticMethod";
//         ExpressionContext context = new ExpressionContext();
//         Object[] parameters = new Object[] { context, "value" };
// 
        // Act & Assert
//         JXPathException exception = Assertions.assertThrows(JXPathException.class, () -> {
//             Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
//         });
//         Assertions.assertTrue(exception.getMessage().contains("Ambiguous method call"), "Exception message should indicate ambiguity.");
//     }

    // Helper classes for testing
    public static class SomeClass {
        public static void staticMethodWithExpressionContext(ExpressionContext context, String param) {
            // Dummy implementation
        }

        public static void staticMethodWithDifferentParameters(String param) {
            // Dummy implementation
        }

        public static void staticMethodWithPrimitives(int a, int b) {
            // Dummy implementation
        }
    }

    public static class AmbiguousClassWithExpressionContext {
        public static void ambiguousStaticMethod(ExpressionContext context, String param) {
            // Dummy implementation
        }

        public static void ambiguousStaticMethod(ExpressionContext context, String param, int extra) {
            // Dummy implementation leading to ambiguity
        }
    }
}