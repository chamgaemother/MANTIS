package org.apache.commons.lang3.reflect;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MethodUtils_getMatchingAccessibleMethod_2_1_Test {

    private static class SampleClass {
        public void sampleMethod(String param) {
            // Sample method for testing
        }
    }

    @Test
    @DisplayName("getMatchingAccessibleMethod throws NullPointerException when cls is null")
    void TC19() {
        Class<?> cls = null;
        String methodName = "sampleMethod";
        Class<?>[] parameterTypes = {String.class};

        assertThrows(NullPointerException.class, () -> {
            MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);
        });
    }

    @Test
    @DisplayName("getMatchingAccessibleMethod throws NullPointerException when methodName is null")
    void TC20() {
        Class<?> cls = SampleClass.class;
        String methodName = null;
        Class<?>[] parameterTypes = {String.class};

        assertThrows(NullPointerException.class, () -> {
            MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);
        });
    }
}