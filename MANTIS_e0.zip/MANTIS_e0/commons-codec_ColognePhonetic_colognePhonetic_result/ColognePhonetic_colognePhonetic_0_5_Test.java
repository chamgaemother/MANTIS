package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_5_Test {

    @Test
    @DisplayName("Input with lowercase letters, should be converted to uppercase during preprocessing")
    void TC21_InputWithLowercaseLetters_ShouldBeConvertedToUppercase() throws Exception {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "hello world";

        // Act
        String result = colognePhonetic.colognePhonetic(input);

        // To verify preprocessing, compare with the expected result after preprocessing
        String expectedInput = "HELLO WORLD";
        String expectedResult = colognePhonetic.colognePhonetic(expectedInput);

        // Assert
        assertEquals(expectedResult, result, "The input should be processed in uppercase.");
    }

    @Test
    @DisplayName("Input with mixed characters, ensuring correct code assignments")
    void TC22_InputWithMixedCharacters_ShouldAssignCorrectCodes() {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "MÃ¼ller-LÃ¼denscheidt"; // Note: Umlauts will be processed in preprocess

        // Act
        String result = colognePhonetic.colognePhonetic(input);

        // Expected processing steps:
        // 1. Preprocess: "MÃ¼ller-LÃ¼denscheidt" -> "MULLERLUDENSCHEIDT"
        // 2. Encode: "6005507500206880022"
        // 3. Collapse: "6050750206802"
        // 4. Remove zeros: "65752682"
        String expected = "65752682";

        // Assert
        assertEquals(expected, result, "The colognePhonetic encoding should match the expected value.");
    }

    @Test
    @DisplayName("Input with consecutive 'H's, should handle multiple '-' correctly")
    void TC23_InputWithConsecutiveHs_ShouldHandleMultipleDashes() {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Hannah"; // Contains consecutive 'H's

        // Act
        String result = colognePhonetic.colognePhonetic(input);

        // Expected processing:
        // After encoding, ensure that multiple '-' are not present due to consecutive 'H's
        // Assuming '-' is represented by code '-
        // Since 'H' maps to '-', we need to ensure no duplicate '-'

        // Check that '-' appears only once consecutively
        long dashCount = result.chars()
                                .filter(ch -> ch == '-')
                                .count();

        // Assert
        // Depending on implementation, adjust the assertion. Here, ensure no two '-' are adjacent
        assertFalse(result.contains("--"), "Multiple '-' should not be present for consecutive 'H's.");
    }

    @Test
    @DisplayName("Input with 'C' after 'S', should assign code '8'")
    void TC24_InputWithCAfterS_ShouldAssignCode8() {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Sceptic"; // 'C' after 'S'

        // Act
        String result = colognePhonetic.colognePhonetic(input);

        // Assert
        assertTrue(result.contains("8"), "The code should include '8' for 'C' after 'S'.");
    }

    @Test
    @DisplayName("Input with 'D' before non C/S/Z, should assign code '8'")
    void TC25_InputWithDBeforeNonCSZ_ShouldAssignCode8() {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Data"; // 'D' before 'a' which is not C/S/Z

        // Act
        String result = colognePhonetic.colognePhonetic(input);

        // Assert
        assertTrue(result.contains("8"), "The code should include '8' for 'D' before non C/S/Z.");
    }
}