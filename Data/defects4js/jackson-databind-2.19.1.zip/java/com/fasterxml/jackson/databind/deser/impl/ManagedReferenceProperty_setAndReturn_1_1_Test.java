package com.fasterxml.jackson.databind.deser.impl;
import java.lang.reflect.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;

import java.io.IOException;

public class ManagedReferenceProperty_setAndReturn_1_1_Test {
    
    @Test
    @DisplayName("value is of unsupported container type String when _isContainer is true, throws IllegalStateException")
    void TC15_unsupported_container_type_String() throws IOException {
        // Arrange
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);
        Object instance = new Object();
        String value = "unsupported";
        
        // Act & Assert
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            property.setAndReturn(instance, value);
        });
        
        // Verify exception message
        assert(exception.getMessage().contains("Unsupported container type"));
    }
    
    @Test
    @DisplayName("value is of unsupported container type Integer when _isContainer is true, throws IllegalStateException")
    void TC16_unsupported_container_type_Integer() throws IOException {
        // Arrange
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);
        Object instance = new Object();
        Integer value = 42;
        
        // Act & Assert
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            property.setAndReturn(instance, value);
        });
        
        // Verify exception message
        assert(exception.getMessage().contains("Unsupported container type"));
    }
}