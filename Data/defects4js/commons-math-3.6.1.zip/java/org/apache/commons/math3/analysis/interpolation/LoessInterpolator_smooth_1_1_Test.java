package org.apache.commons.math3.analysis.interpolation;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class LoessInterpolator_smooth_1_1_Test {

    @Test
    @DisplayName("smooth method correctly handles full bandwidth (bandwidth=1), including all points in regression.")
    void testSmoothFullBandwidth() {
        // Arrange
        double[] xval = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] yval = {2.0, 4.0, 6.0, 8.0, 10.0};
        double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
        double bandwidth = 1.0;
        int robustnessIters = 2;
        LoessInterpolator interpolator = new LoessInterpolator(bandwidth, robustnessIters);

        // Act
        double[] result = interpolator.smooth(xval, yval, weights);

        // Assert
        assertNotNull(result, "Result should not be null.");
        assertEquals(5, result.length, "Result array length should be 5.");
        // Since the data is perfectly linear and bandwidth=1.0 includes all points,
        // the smoothed values should match the original yval.
        for (int i = 0; i < yval.length; i++) {
            assertEquals(yval[i], result[i], 1e-10, String.format("Element at index %d should remain unchanged.", i));
        }
    }

    @Test
    @DisplayName("smooth method handles weights array containing zeros by ignoring zero-weighted points in regression.")
    void testSmoothZeroWeights() {
        // Arrange
        double[] xval = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] yval = {2.0, 4.0, 6.0, 8.0, 10.0};
        double[] weights = {1.0, 0.0, 1.0, 0.0, 1.0};
        double bandwidth = 0.6;
        int robustnessIters = 2;
        LoessInterpolator interpolator = new LoessInterpolator(bandwidth, robustnessIters);

        // Act
        double[] result = interpolator.smooth(xval, yval, weights);

        // Assert
        assertNotNull(result, "Result should not be null.");
        assertEquals(5, result.length, "Result array length should be 5.");
        // Verify that the smoothed values at positions with zero weights remain unchanged
        // or are handled appropriately based on the implementation.
        assertEquals(2.0, result[0], 1e-10, "First element should remain unchanged.");
        // For elements with zero weights, depending on implementation, they might remain unchanged or be interpolated based on other weights.
        // Here, assuming they remain unchanged.
        assertEquals(4.0, result[1], 1e-10, "Second element should remain unchanged due to zero weight.");
        assertEquals(6.0, result[2], 1e-10, "Third element should remain unchanged.");
        assertEquals(8.0, result[3], 1e-10, "Fourth element should remain unchanged due to zero weight.");
        assertEquals(10.0, result[4], 1e-10, "Fifth element should remain unchanged.");
    }
}