package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_6_Test {

    @Test
    @DisplayName("metaphone(\"CYCLE\") processes 'CY' as 'S'")
    public void TC26() {
        // GIVEN
        String input = "cycle";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertTrue(result.contains("S"), "metaphone code should contain 'S'");
    }

    @Test
    @DisplayName("metaphone(\"TICHON\") handles 'TCH' as silent")
    public void TC27() {
        // GIVEN
        String input = "tichon";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertFalse(result.contains("TCH"), "metaphone code should omit 'TCH'");
    }

    @Test
    @DisplayName("metaphone(\"SIA\") processes 'SIA' as 'S'")
    public void TC28() {
        // GIVEN
        String input = "sial";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertTrue(result.contains("S"), "metaphone code should contain 'S'");
    }

    @Test
    @DisplayName("metaphone(\"SILENCE\") handles 'SIE' correctly")
    public void TC29() {
        // GIVEN
        String input = "silence";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertTrue(result.contains("S"), "metaphone code should contain 'S'");
    }

    @Test
    @DisplayName("metaphone(\"GHAST\") processes 'GH' as silent before 'A'")
    public void TC30() {
        // GIVEN
        String input = "ghast";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertFalse(result.contains("GH"), "metaphone code should omit 'GH'");
    }

}