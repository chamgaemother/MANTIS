package org.apache.commons.compress.archivers.sevenz;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class SevenZArchiveEntry_equals_1_2_Test {

    @Test
    @DisplayName("equals(obj) returns false when hasStream fields differ")
    void equals_different_hasStream_returns_false() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        Field hasStreamField = SevenZArchiveEntry.class.getDeclaredField("hasStream");
        hasStreamField.setAccessible(true);
        hasStreamField.set(entry1, true);
        hasStreamField.set(entry2, false);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when isDirectory fields differ")
    void equals_different_isDirectory_returns_false() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        Field isDirectoryField = SevenZArchiveEntry.class.getDeclaredField("isDirectory");
        isDirectoryField.setAccessible(true);
        isDirectoryField.set(entry1, true);
        isDirectoryField.set(entry2, false);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when isAntiItem fields differ")
    void equals_different_isAntiItem_returns_false() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        Field isAntiItemField = SevenZArchiveEntry.class.getDeclaredField("isAntiItem");
        isAntiItemField.setAccessible(true);
        isAntiItemField.set(entry1, true);
        isAntiItemField.set(entry2, false);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when hasCreationDate fields differ")
    void equals_different_hasCreationDate_returns_false() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        Field hasCreationDateField = SevenZArchiveEntry.class.getDeclaredField("hasCreationDate");
        hasCreationDateField.setAccessible(true);
        hasCreationDateField.set(entry1, true);
        hasCreationDateField.set(entry2, false);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when hasLastModifiedDate fields differ")
    void equals_different_hasLastModifiedDate_returns_false() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        Field hasLastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate");
        hasLastModifiedDateField.setAccessible(true);
        hasLastModifiedDateField.set(entry1, true);
        hasLastModifiedDateField.set(entry2, false);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }
}