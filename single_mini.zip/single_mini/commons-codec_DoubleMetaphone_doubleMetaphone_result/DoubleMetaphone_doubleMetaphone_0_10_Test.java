package org.apache.commons.codec.language;

import org.apache.commons.codec.language.DoubleMetaphone;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_10_Test {

    @Test
    @DisplayName("doubleMetaphone handles 'CIA' sequence in 'Focaccia'")
    void TC46_doubleMetaphone_handles_CIA_sequence_in_Focaccia() {
        // Given
        String value = "FOCACCIA";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("X"), "Encoded 'CIA' should be 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'CI' followed by 'O' in 'CIOPS'")
    void TC47_doubleMetaphone_handles_CIO_followed_by_O_in_CIOPS() {
        // Given
        String value = "CIOPS";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("X"), "Encoded 'CIO' should be 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'DZ' sequence not followed by 'EY' in 'ADZEY'")
    void TC48_doubleMetaphone_handles_DZ_sequence_not_followed_by_EY_in_ADZEY() {
        // Given
        String value = "ADZEY";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("TK"), "Encoded 'DZ' should be 'TK'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'C' followed by 'H' and not Greek rule in 'CHURCH'")
    void TC49_doubleMetaphone_handles_CH_followed_by_not_Greek_rule_in_CHURCH() {
        // Given
        String value = "CHURCH";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("X"), "Encoded 'CH' should be 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'K' followed by 'K' in 'KICK'")
    void TC50_doubleMetaphone_handles_KK_followed_in_KICK() {
        // Given
        String value = "KICK";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("K"), "Encoded 'KK' should be single 'K'");
    }
}