package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class BooleanUtils_toBooleanObject_0_2_Test {

    @Test
    @DisplayName("Input string is single character 'N', returns Boolean.FALSE")
    void testTC06() {
        String input = "N";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string is single character '1', returns Boolean.TRUE")
    void testTC07() {
        String input = "1";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is two characters 'on', returns Boolean.TRUE")
    void testTC08() {
        String input = "on";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is two characters 'NO', returns Boolean.FALSE")
    void testTC09() {
        String input = "NO";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string is three characters 'yes', returns Boolean.TRUE")
    void testTC10() {
        String input = "yes";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.TRUE, result);
    }
}