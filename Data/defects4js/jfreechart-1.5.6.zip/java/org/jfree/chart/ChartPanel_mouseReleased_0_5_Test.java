package org.jfree.chart;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseReleased_0_5_Test {

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, getScreenDataArea returns null, ensuring no zoom is performed")
    void TC21_mouseReleased_zoomRectangle_present_getScreenDataArea_null() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);
        MouseEvent event = mock(MouseEvent.class);

        // Set zoomRectangle to a non-null value via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));

        // Spy on the panel to mock getScreenDataArea
        ChartPanel spyPanel = spy(panel);
        doReturn(null).when(spyPanel).getScreenDataArea(anyInt(), anyInt());

        // Act
        spyPanel.mouseReleased(event);

        // Assert
        verify(spyPanel, never()).zoom(any(Rectangle2D.class));

        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(spyPanel));

        assertNull(zoomRectangleField.get(spyPanel));
    }

//     @Test
//     @DisplayName("mouseReleased with zoomRectangle present, getGraphics returns null, ensuring no drawing occurs")
//     void TC22_mouseReleased_zoomRectangle_present_getGraphics_null() throws Exception {
        // Arrange
//         ChartPanel panel = new ChartPanel(null);
//         MouseEvent event = mock(MouseEvent.class);
// 
//         Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
//         zoomRectangleField.setAccessible(true);
//         zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));
// 
        // Spy on the panel to mock getGraphics
//         ChartPanel spyPanel = spy(panel);
//         doReturn(null).when(spyPanel).getGraphics();
// 
        // Act
//         spyPanel.mouseReleased(event);
// 
        // Assert
//         verify(spyPanel, never()).drawZoomRectangle(any(Graphics2D.class), anyBoolean());
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         assertNull(zoomPointField.get(spyPanel));
// 
//         assertNull(zoomRectangleField.get(spyPanel));
//     }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, zoom method throws exception, ensuring exception is handled gracefully")
    void TC23_mouseReleased_zoomRectangle_present_zoom_throws_exception() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);
        MouseEvent event = mock(MouseEvent.class);

        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));

        // Spy on the panel to mock zoom to throw an exception
        ChartPanel spyPanel = spy(panel);
        doThrow(new RuntimeException("Zoom failed")).when(spyPanel).zoom(any(Rectangle2D.class));

        // Act & Assert
        assertDoesNotThrow(() -> spyPanel.mouseReleased(event));

        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(spyPanel));

        assertNull(zoomRectangleField.get(spyPanel));
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, useBuffer is true, verifying repaint is called")
    void TC24_mouseReleased_zoom_not_triggered_with_buffer_enabled() throws Exception {
        // Arrange
        ChartPanel panel = new ChartPanel(null);
        MouseEvent event = mock(MouseEvent.class);

        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));

        Field useBufferField = ChartPanel.class.getDeclaredField("useBuffer");
        useBufferField.setAccessible(true);
        useBufferField.set(panel, true);

        // Spy on the panel
        ChartPanel spyPanel = spy(panel);
        when(spyPanel.getX()).thenReturn(50);
        when(spyPanel.getY()).thenReturn(50);
        when(event.getX()).thenReturn(200);
        when(event.getY()).thenReturn(200);

        // Act
        spyPanel.mouseReleased(event);

        // Assert
        verify(spyPanel, times(1)).repaint();

        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        assertNull(zoomPointField.get(spyPanel));

        assertNull(zoomRectangleField.get(spyPanel));
    }

//     @Test
//     @DisplayName("mouseReleased with zoomRectangle present, useBuffer is false, verifying drawZoomRectangle is called")
//     void TC25_mouseReleased_zoom_not_triggered_with_buffer_disabled() throws Exception {
        // Arrange
//         ChartPanel panel = new ChartPanel(null);
//         MouseEvent event = mock(MouseEvent.class);
// 
//         Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
//         zoomRectangleField.setAccessible(true);
//         zoomRectangleField.set(panel, new Rectangle2D.Double(10, 10, 100, 100));
// 
//         Field useBufferField = ChartPanel.class.getDeclaredField("useBuffer");
//         useBufferField.setAccessible(true);
//         useBufferField.set(panel, false);
// 
        // Spy on the panel
//         ChartPanel spyPanel = spy(panel);
//         when(spyPanel.getX()).thenReturn(50);
//         when(spyPanel.getY()).thenReturn(50);
//         when(event.getX()).thenReturn(200);
//         when(event.getY()).thenReturn(200);
// 
        // Mock getGraphics to return a Graphics2D mock
//         Graphics2D graphicsMock = mock(Graphics2D.class);
//         doReturn(graphicsMock).when(spyPanel).getGraphics();
// 
        // Act
//         spyPanel.mouseReleased(event);
// 
        // Assert
//         verify(spyPanel, times(1)).drawZoomRectangle(eq(graphicsMock), eq(true));
// 
//         verify(graphicsMock, times(1)).dispose();
// 
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         assertNull(zoomPointField.get(spyPanel));
// 
//         assertNull(zoomRectangleField.get(spyPanel));
//     }
}