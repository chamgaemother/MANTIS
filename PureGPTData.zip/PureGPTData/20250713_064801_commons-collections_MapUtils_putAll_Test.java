import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class MapUtilsTest {

    private Map<Object, Object> map;

    @BeforeEach
    void setUp() {
        map = new HashMap<>();
    }

    @Test
    void testPutAllWithEntryArray() {
        Map.Entry<String, String> entry1 = Map.entry("key1", "value1");
        Map.Entry<String, String> entry2 = Map.entry("key2", "value2");
        Object[] entries = new Object[] { entry1, entry2 };

        MapUtils.putAll(map, entries);

        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testPutAllWithKeyValueArray() {
        Object[] array = new Object[] { "key1", "value1", "key2", "value2" };

        MapUtils.putAll(map, array);

        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testPutAllWithNestedArray() {
        Object[] subArray1 = new Object[] { "key1", "value1" };
        Object[] subArray2 = new Object[] { "key2", "value2" };
        Object[] array = new Object[] { subArray1, subArray2 };

        MapUtils.putAll(map, array);

        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testPutAllWithInvalidNestedArray() {
        Object[] subArray1 = new Object[] { "key1" }; // invalid sub-array, less than 2 elements.
        Object[] array = new Object[] { subArray1 };

        assertThrows(IllegalArgumentException.class, () -> MapUtils.putAll(map, array));
    }

    @Test
    void testPutAllWithEmptyArray() {
        Object[] emptyArray = new Object[] {};

        MapUtils.putAll(map, emptyArray);

        assertTrue(map.isEmpty());
    }

    @Test
    void testPutAllWithNullArray() {
        Object[] nullArray = null;

        MapUtils.putAll(map, nullArray);

        assertTrue(map.isEmpty());
    }

    @Test
    void testPutAllWithKeyValuePairsArray_withOddLength() {
        Object[] array = new Object[] { "key1", "value1", "key2" };

        MapUtils.putAll(map, array);

        assertEquals("value1", map.get("key1"));
        assertNull(map.get("key2")); // 'key2' doesn't have a pair and should be ignored
    }
}