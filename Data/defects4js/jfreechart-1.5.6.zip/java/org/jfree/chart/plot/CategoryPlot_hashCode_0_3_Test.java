package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.plot.CategoryPlot;

public class CategoryPlot_hashCode_0_3_Test {

    @Test
    @DisplayName("hashCode with a mixture of true and false boolean flags")
    void TC11_hashCode_mixed_boolean_flags() {
        // GIVEN
        CategoryPlot plot = new CategoryPlot();
        plot.setDrawSharedDomainAxis(true);
        plot.setDomainGridlinesVisible(false);
        plot.setRangeZeroBaselineVisible(true);
        plot.setRangeGridlinesVisible(false);
        plot.setRangeMinorGridlinesVisible(true);
        plot.setDomainCrosshairVisible(false);
        plot.setRangeCrosshairVisible(true);
        plot.setRangeCrosshairLockedOnData(true);
        plot.setRangePannable(false);

        // WHEN
        int hash1 = plot.hashCode();
        int hash2 = plot.hashCode();

        // THEN
        assertEquals(hash1, hash2, "hashCode should be consistent across invocations");
    }

    @Test
    @DisplayName("hashCode with some object fields set to null and boolean flags set variably")
    void TC12_hashCode_null_object_fields_mixed_boolean_flags() {
        // GIVEN
        CategoryPlot plot = new CategoryPlot();
        plot.setDrawSharedDomainAxis(false);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeZeroBaselineVisible(false);
        plot.setRangeGridlinesVisible(true);
        plot.setRangeMinorGridlinesVisible(false);
        plot.setDomainCrosshairVisible(true);
        plot.setRangeCrosshairVisible(false);
        plot.setRangeCrosshairLockedOnData(false);
        plot.setRangePannable(true);
        plot.setOrientation(null);
        plot.setAxisOffset(null);
        // Other object fields can be left as null

        // WHEN
        int hash1 = plot.hashCode();
        int hash2 = plot.hashCode();

        // THEN
        assertEquals(hash1, hash2, "hashCode should be consistent across invocations even with null object fields");
    }

}