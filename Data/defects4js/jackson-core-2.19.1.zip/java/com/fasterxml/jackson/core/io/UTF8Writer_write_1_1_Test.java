package com.fasterxml.jackson.core.io;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.OutputStream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class UTF8Writer_write_1_1_Test {

    @Test
    @DisplayName("write with len=3 containing multi-byte 2-byte UTF-8 characters")
    void testTC05() throws IOException {
        // GIVEN
        char[] cbuf = { '\u00C2', '\u00A2', '\u00B4' };
        int off = 0;
        int len = 3;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        IOContext mockContext = Mockito.mock(IOContext.class);
        byte[] writeBuffer = new byte[1024];
        when(mockContext.allocWriteEncodingBuffer()).thenReturn(writeBuffer);
        UTF8Writer writer = new UTF8Writer(mockContext, mockOut);

        // WHEN
        writer.write(cbuf, off, len);

        // THEN
        verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(6));
    }

    @Test
    @DisplayName("write with len=3 containing a single 3-byte UTF-8 character")
    void testTC06() throws IOException {
        // GIVEN
        char[] cbuf = { '\u0800', 'A', 'B' };
        int off = 0;
        int len = 3;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        IOContext mockContext = Mockito.mock(IOContext.class);
        byte[] writeBuffer = new byte[1024];
        when(mockContext.allocWriteEncodingBuffer()).thenReturn(writeBuffer);
        UTF8Writer writer = new UTF8Writer(mockContext, mockOut);

        // WHEN
        writer.write(cbuf, off, len);

        // THEN
        verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(5));
    }

    @Test
    @DisplayName("write with len=4 containing a 4-byte UTF-8 character and ASCII characters")
    void testTC07() throws IOException {
        // GIVEN
        char[] cbuf = { '\uD83D', '\uDE00', 'A', 'B' }; // Surrogate pair for emoji followed by 'A' and 'B'
        int off = 0;
        int len = 4;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        IOContext mockContext = Mockito.mock(IOContext.class);
        byte[] writeBuffer = new byte[1024];
        when(mockContext.allocWriteEncodingBuffer()).thenReturn(writeBuffer);
        UTF8Writer writer = new UTF8Writer(mockContext, mockOut);

        // WHEN
        writer.write(cbuf, off, len);

        // THEN
        verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(6));
    }

    @Test
    @DisplayName("write with len=2 containing an unmatched first surrogate, expecting IOException")
    void testTC08() throws IOException {
        // GIVEN
        char[] cbuf = { '\uD800', 'A' }; // Unmatched high surrogate followed by 'A'
        int off = 0;
        int len = 2;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        IOContext mockContext = Mockito.mock(IOContext.class);
        byte[] writeBuffer = new byte[1024];
        when(mockContext.allocWriteEncodingBuffer()).thenReturn(writeBuffer);
        UTF8Writer writer = new UTF8Writer(mockContext, mockOut);

        // WHEN & THEN
        assertThrows(IOException.class, () -> writer.write(cbuf, off, len));
        verify(mockOut, times(0)).write(any(byte[].class), anyInt(), anyInt());
    }

    @Test
    @DisplayName("write with len=2 containing an unmatched second surrogate, expecting IOException")
    void testTC09() throws IOException {
        // GIVEN
        char[] cbuf = { 'A', '\uDC00' }; // 'A' followed by unmatched low surrogate
        int off = 0;
        int len = 2;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        IOContext mockContext = Mockito.mock(IOContext.class);
        byte[] writeBuffer = new byte[1024];
        when(mockContext.allocWriteEncodingBuffer()).thenReturn(writeBuffer);
        UTF8Writer writer = new UTF8Writer(mockContext, mockOut);

        // WHEN & THEN
        assertThrows(IOException.class, () -> writer.write(cbuf, off, len));
        verify(mockOut, times(0)).write(any(byte[].class), anyInt(), anyInt());
    }
}