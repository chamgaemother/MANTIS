package org.apache.commons.math3.analysis.interpolation;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.analysis.interpolation.SmoothingPolynomialBicubicSplineInterpolator;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;

public class SmoothingPolynomialBicubicSplineInterpolator_interpolate_1_1_Test {

    @Test
    @DisplayName("interpolate throws NonMonotonicSequenceException when xval is not sorted in ascending order")
    void TC14_interpolate_with_unsorted_xval() {
        // Initialize the interpolator
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();

        // Define test inputs
        double[] xval = {3.0, 2.0, 1.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[][] fval = {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0},
            {7.0, 8.0, 9.0}
        };

        // Assert that NonMonotonicSequenceException is thrown
        Assertions.assertThrows(NonMonotonicSequenceException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

    @Test
    @DisplayName("interpolate throws NonMonotonicSequenceException when yval is not sorted in ascending order")
    void TC15_interpolate_with_unsorted_yval() {
        // Initialize the interpolator
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();

        // Define test inputs
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {3.0, 2.0, 1.0};
        double[][] fval = {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0},
            {7.0, 8.0, 9.0}
        };

        // Assert that NonMonotonicSequenceException is thrown
        Assertions.assertThrows(NonMonotonicSequenceException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }
}