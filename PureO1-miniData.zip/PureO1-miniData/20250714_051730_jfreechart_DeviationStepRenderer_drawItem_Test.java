import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DeviationStepRendererTest {

    private DeviationStepRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private IntervalXYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new DeviationStepRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(IntervalXYDataset.class);
        crosshairState = mock(CrosshairState.class);
        
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
    }

    @Test
    void drawItem_ItemNotVisible_ShouldReturn() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_PassNotZero_ShouldHandleLinePass() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.isLinePass(1)).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        verify(state, atLeast(0)).seriesPath;
    }

    @Test
    void drawItem_PassZero_IntervalGoodVerticalOrientation_LastItem() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndYValue(0, 0)).thenReturn(1.5);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.5, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.5, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(renderer.isLinePass(0)).thenReturn(false);
        when(state.getLastItemIndex()).thenReturn(0);
        when(state.lowerCoordinates).thenReturn(new java.util.ArrayList<>());
        when(state.upperCoordinates).thenReturn(new java.util.ArrayList<>());
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2).setComposite(any(AlphaComposite.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void drawItem_PassZero_IntervalGoodHorizontalOrientation_NotLastItem() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndYValue(0, 0)).thenReturn(1.5);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getStartYValue(0, 1)).thenReturn(1.0);
        when(dataset.getEndYValue(0, 1)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.5, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.5, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(state.lowerCoordinates).thenReturn(new java.util.ArrayList<>());
        when(state.upperCoordinates).thenReturn(new java.util.ArrayList<>());
        when(renderer.isLinePass(0)).thenReturn(false);
        when(renderer.isLinePass(0)).thenReturn(false);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    void drawItem_PassZero_IntervalNotGood_ShouldNotFill() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(0, 0)).thenReturn(Double.NaN);
        when(renderer.isLinePass(0)).thenReturn(false);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    void drawItem_PassZero_WithPreviousItem() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndYValue(0, 0)).thenReturn(1.5);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getStartYValue(0, 1)).thenReturn(1.0);
        when(dataset.getEndYValue(0, 1)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(0.5, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.5, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        java.util.ArrayList<double[]> lower = new java.util.ArrayList<>();
        java.util.ArrayList<double[]> upper = new java.util.ArrayList<>();
        when(state.lowerCoordinates).thenReturn(lower);
        when(state.upperCoordinates).thenReturn(upper);
        when(renderer.isLinePass(0)).thenReturn(false);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        
        assertEquals(2, lower.size());
        assertEquals(2, upper.size());
    }

    @Test
    void drawItem_NullGraphics_ShouldHandleGracefully() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        assertDoesNotThrow(() -> renderer.drawItem(null, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
    }

    @Test
    void drawItem_NullDataset_ShouldThrowException() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        assertThrows(ClassCastException.class, () -> renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, mock(XYDataset.class), 0, 0, crosshairState, 0));
    }

    @Test
    void drawItem_NaNValues_ShouldNotAddCoordinates() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(0, 0)).thenReturn(Double.NaN);
        when(renderer.isLinePass(0)).thenReturn(false);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(state.lowerCoordinates, never()).add(any());
        verify(state.upperCoordinates, never()).add(any());
    }

    @Test
    void drawItem_LastItem_ShouldFillArea() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndYValue(0, 0)).thenReturn(1.5);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getStartYValue(0, 1)).thenReturn(1.0);
        when(dataset.getEndYValue(0, 1)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(0.5, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.5, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        java.util.ArrayList<double[]> lower = new java.util.ArrayList<>();
        java.util.ArrayList<double[]> upper = new java.util.ArrayList<>();
        when(state.lowerCoordinates).thenReturn(lower);
        when(state.upperCoordinates).thenReturn(upper);
        when(renderer.isLinePass(0)).thenReturn(false);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        
        verify(g2, times(1)).fill(any(Shape.class));
    }

    @Test
    void drawItem_DrawPrimaryLineAsPath_ShouldHandleGoodPoint() {
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        XYItemRendererState state = new XYItemRendererState();
        
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(renderer.isLinePass(0)).thenReturn(true);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        // Further assertions can be done based on the internal state
    }

    @Test
    void drawItem_DrawPrimaryLineAsPath_ShouldHandleNaNPoint() {
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        XYItemRendererState state = new XYItemRendererState();
        
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(renderer.isLinePass(0)).thenReturn(true);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        // Verify that last point is not good
    }

    @Test
    void drawItem_ItemPass_ShouldDrawShapes() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.isItemPass(1)).thenReturn(true);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        verify(renderer, times(1)).drawSecondaryPass(g2, plot, dataset, 1, 0, 0, domainAxis, dataArea, rangeAxis, crosshairState, entities);
    }

    @Test
    void drawItem_BoundaryValues_ShouldHandleMinMax() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.MIN_VALUE);
        when(dataset.getStartYValue(0, 0)).thenReturn(Double.MIN_VALUE);
        when(dataset.getEndYValue(0, 0)).thenReturn(Double.MIN_VALUE);
        when(dataset.getXValue(0, 1)).thenReturn(Double.MAX_VALUE);
        when(dataset.getStartYValue(0, 1)).thenReturn(Double.MAX_VALUE);
        when(dataset.getEndYValue(0, 1)).thenReturn(Double.MAX_VALUE);
        when(domainAxis.valueToJava2D(Double.MIN_VALUE, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(domainAxis.valueToJava2D(Double.MAX_VALUE, dataArea, RectangleEdge.BOTTOM)).thenReturn(1000.0);
        when(rangeAxis.valueToJava2D(Double.MIN_VALUE, dataArea, RectangleEdge.LEFT)).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(Double.MAX_VALUE, dataArea, RectangleEdge.LEFT)).thenReturn(1000.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.isLinePass(0)).thenReturn(false);
        java.util.ArrayList<double[]> lower = new java.util.ArrayList<>();
        java.util.ArrayList<double[]> upper = new java.util.ArrayList<>();
        when(state.lowerCoordinates).thenReturn(lower);
        when(state.upperCoordinates).thenReturn(upper);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        
        verify(g2, times(1)).fill(any(Shape.class));
    }

    @Test
    void drawItem_InvalidSeriesIndex_ShouldHandleGracefully() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndYValue(0, 0)).thenReturn(1.5);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.5, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.5, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(renderer.isLinePass(0)).thenReturn(false);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, -1, 0, crosshairState, 0);
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    void drawItem_PassZero_WithAlphaTransparency() {
        renderer.alpha = 0.5f;
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndYValue(0, 0)).thenReturn(1.5);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(0.5, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.5, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        java.util.ArrayList<double[]> lower = new java.util.ArrayList<>();
        java.util.ArrayList<double[]> upper = new java.util.ArrayList<>();
        when(state.lowerCoordinates).thenReturn(lower);
        when(state.upperCoordinates).thenReturn(upper);
        when(renderer.isLinePass(0)).thenReturn(false);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(g2).setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void drawItem_SeriesPathResetAtFirstItem() {
        XYItemRendererState state = mock(XYItemRendererState.class);
        when(state.seriesPath).thenReturn(new GeneralPath());
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);
        when(renderer.isLinePass(1)).thenReturn(true);
        
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        verify(state, atLeastOnce()).seriesPath;
    }
}