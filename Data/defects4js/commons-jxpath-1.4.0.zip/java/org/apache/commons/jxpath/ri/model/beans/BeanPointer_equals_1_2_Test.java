package org.apache.commons.jxpath.ri.model.beans;

import org.apache.commons.jxpath.JXPathBeanInfo;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.mock;

import javax.xml.namespace.QName;

public class BeanPointer_equals_1_2_Test {

//     @Test
//     @DisplayName("equals returns false when beans are different custom object references")
//     public void equals_returnsFalse_whenBeansAreDifferentCustomObjectReferences() {
        // Arrange
//         NodePointer parent = mock(NodePointer.class);
//         QName qName = new QName("uri", "local");
//         JXPathBeanInfo mockBeanInfo = mock(JXPathBeanInfo.class);
//         
//         BeanPointer bp1 = new BeanPointer(parent, qName, new Object(), mockBeanInfo);
//         BeanPointer bp2 = new BeanPointer(parent, qName, new Object(), mockBeanInfo);
//         
        // Act
//         boolean result = bp1.equals(bp2);
//         
        // Assert
//         assertFalse(result);
//     }
}