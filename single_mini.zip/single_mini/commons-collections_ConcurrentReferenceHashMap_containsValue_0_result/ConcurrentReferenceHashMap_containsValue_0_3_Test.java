package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;

import java.lang.reflect.Field;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ConcurrentReferenceHashMap_containsValue_0_3_Test {

    @Test
    @DisplayName("TC11 containsValue throws exception and ensures all locks are released")
    void TC11_containsValue_throwsException_and_all_locks_released() {
        // GIVEN
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.builder().build();
        map.put("key1", "value1");
        Object value = "testValue";

        try {
            // Access the 'segments' field via reflection
            Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
            segmentsField.setAccessible(true);
            @SuppressWarnings("unchecked")
            ConcurrentReferenceHashMap.Segment<String, String>[] segments = (ConcurrentReferenceHashMap.Segment<String, String>[]) segmentsField.get(map);

            // Obtain the Segment class via reflection
            Class<?> segmentClass = Class.forName("org.apache.commons.collections4.map.ConcurrentReferenceHashMap$Segment");

            // Mock the first segment to throw an exception on containsValue
            Object faultySegment = Mockito.mock(segmentClass, invocation -> {
                if ("containsValue".equals(invocation.getMethod().getName())) {
                    throw new RuntimeException("Simulated exception in containsValue");
                }
                return invocation.callRealMethod();
            });

            // Replace the first segment with the mocked faulty segment
            segments[0] = (ConcurrentReferenceHashMap.Segment<String, String>) faultySegment;
            segmentsField.set(map, segments);
        } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException e) {
            fail("Reflection setup failed: " + e.getMessage());
        }

        // WHEN
        Executable executable = () -> map.containsValue(value);

        // THEN
        RuntimeException thrownException = assertThrows(RuntimeException.class, executable, "Expected containsValue to throw RuntimeException");
        assertEquals("Simulated exception in containsValue", thrownException.getMessage());

        // Verify all segments are unlocked
        try {
            Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
            segmentsField.setAccessible(true);
            @SuppressWarnings("unchecked")
            ConcurrentReferenceHashMap.Segment<String, String>[] segments = (ConcurrentReferenceHashMap.Segment<String, String>[]) segmentsField.get(map);
            for (ConcurrentReferenceHashMap.Segment<String, String> segment : segments) {
                // Since Segment extends ReentrantLock, we can check if it's locked
                assertFalse(segment.isLocked(), "Segment should be unlocked after exception");
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection verification failed: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("TC12 containsValue handles single-segment map and finds the value")
    void TC12_containsValue_singleSegment_findsValue() {
        // GIVEN
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.builder().build();
        Object value = "testValue";
        map.put("key1", (String) value);

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result, "containsValue should return true when the value is present in a single-segment map");
    }

    @Test
    @DisplayName("TC13 containsValue returns false when all segments contain different values")
    void TC13_containsValue_multipleSegments_noMatch() {
        // GIVEN
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.builder().build();
        map.put("key1", "value1");
        map.put("key2", "value2");
        Object value = "nonExistentValue";

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertFalse(result, "containsValue should return false when the value is not present in any segment");
    }

    @Test
    @DisplayName("TC14 containsValue correctly handles boundary segment sizes")
    void TC14_containsValue_boundarySegmentSizes() {
        // GIVEN
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.builder().build();
        Object value = "testValue";
        map.put("key1", "value1");
        map.put("key2", (String) value);
        // Assuming some segments have no entries by design

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result, "containsValue should return true when the value is present among segments with varying sizes");
    }

    @Test
    @DisplayName("TC15 containsValue handles high concurrency with multiple threads searching and modifying")
    void TC15_containsValue_highConcurrency() throws InterruptedException {
        // GIVEN
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.builder().build();
        Object value = "testValue";
        CountDownLatch latch = new CountDownLatch(2);
        AtomicBoolean resultHolder = new AtomicBoolean(false);

        // Start multiple threads modifying the map
        Thread modifier1 = new Thread(() -> {
            map.put("key1", "value1");
            latch.countDown();
        });

        Thread modifier2 = new Thread(() -> {
            map.put("key2", (String) value);
            latch.countDown();
        });

        modifier1.start();
        modifier2.start();

        latch.await(); // Wait for both modifiers to finish

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result || !result, "containsValue should return accurate presence status of the value under concurrency");
    }
}