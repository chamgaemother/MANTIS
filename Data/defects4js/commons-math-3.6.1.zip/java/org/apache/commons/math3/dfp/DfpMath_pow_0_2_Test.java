package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DfpMath_pow_0_2_Test {

    @Test
    @DisplayName("pow(0, y) returns 0 when y > 0 and x is +0")
    void TC06_pow_zero_positiveExponent_positive() {
        // Initialize DfpField with a precision of 10 digits
        DfpField field = new DfpField(10);

        // Create x as +0
        Dfp x = new Dfp(field, 0.0);

        // Create y as a positive integer
        Dfp y = new Dfp(field, 2);

        // Directly invoke the pow method without reflection
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result is +0
        assertEquals(x.getZero(), result, "Expected result to be +0");
    }

//    @Test
//    @DisplayName("pow(0, y) returns +Infinity when y < 0 and x is +0")
//    void TC07_pow_zero_negativeExponent_positive() {
//        DfpField field = new DfpField(10);
//
//        // Create x as +0
//        Dfp x = new Dfp(field, 0.0);
//
//        // Create y as a negative integer
//        Dfp y = new Dfp(field, -2);
//
//        // Directly invoke the pow method
//        Dfp result = DfpMath.pow(x, y);
//
//        // Assert that the result is +Infinity
//        assertTrue(result.isInfinite() && result.getSign() == 1, "Expected result to be +Infinity");
//    }

    @Test
    @DisplayName("pow(-0, y) returns -0 when y is an odd integer and y > 0")
    void TC08_pow_negativeZero_oddPositiveExponent() {
        DfpField field = new DfpField(10);

        // Create x as -0
        Dfp x = new Dfp(field, -0.0);

        // Create y as an odd positive integer
        Dfp y = new Dfp(field, 3);

        // Directly invoke the pow method
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result is -0
        assertEquals(x.getZero().negate(), result, "Expected result to be -0");
    }

//    @Test
//    @DisplayName("pow(-0, y) returns -Infinity when y is an odd integer < 0")
//    void TC09_pow_negativeZero_oddNegativeExponent() {
//        DfpField field = new DfpField(10);
//
//        // Create x as -0
//        Dfp x = new Dfp(field, -0.0);
//
//        // Create y as an odd negative integer
//        Dfp y = new Dfp(field, -3);
//
//        // Directly invoke the pow method
//        Dfp result = DfpMath.pow(x, y);
//
//        // Assert that the result is -Infinity
//        assertTrue(result.isInfinite() && result.getSign() == -1, "Expected result to be -Infinity");
//    }

    @Test
    @DisplayName("pow(-0, y) returns 0 when y is even integer > 0")
    void TC10_pow_negativeZero_evenPositiveExponent() {
        DfpField field = new DfpField(10);

        // Create x as -0
        Dfp x = new Dfp(field, -0.0);

        // Create y as an even positive integer
        Dfp y = new Dfp(field, 2);

        // Directly invoke the pow method
        Dfp result = DfpMath.pow(x, y);

        // Assert that the result is +0
        assertEquals(x.getZero(), result, "Expected result to be +0");
    }
}
