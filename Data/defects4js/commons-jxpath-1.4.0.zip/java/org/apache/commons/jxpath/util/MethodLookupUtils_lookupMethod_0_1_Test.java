package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class MethodLookupUtils_lookupMethod_0_1_Test {

    // Mock classes for testing purposes
    public static class SomeClass {
        public void desiredMethod(String param1) {}
        public void methodName(Object param1) {}
    }

    public static class NonMatchingClass {}

    public static class ConvertibleObject {
        // Assume this can be converted to targetClass
    }

    @Test
    @DisplayName("lookupMethod returns null when parameters are null")
    void TC01_lookupMethod_with_null_parameters() {
        Class<?> targetClass = SomeClass.class;
        String name = "methodName";
        Object[] parameters = null;

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        assertNull(result, "Expected method to be null when parameters are null");
    }

    @Test
    @DisplayName("lookupMethod returns null when parameters array is empty")
    void TC02_lookupMethod_with_empty_parameters_array() {
        Class<?> targetClass = SomeClass.class;
        String name = "methodName";
        Object[] parameters = new Object[]{};

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        assertNull(result, "Expected method to be null when parameters array is empty");
    }

    @Test
    @DisplayName("lookupMethod returns null when first parameter is non-null and matchType returns NO_MATCH")
    void TC03_lookupMethod_with_non_matching_first_parameter() {
        Class<?> targetClass = SomeClass.class;
        String name = "methodName";
        Object[] parameters = new Object[]{new NonMatchingClass(), "param2"};

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        assertNull(result, "Expected method to be null when first parameter does not match targetClass");
    }

    @Test
    @DisplayName("lookupMethod returns method when matchType returns EXACT_MATCH")
    void TC04_lookupMethod_with_exact_type_match() {
        Class<?> targetClass = SomeClass.class;
        String name = "desiredMethod";
        Object[] parameters = new Object[]{targetClass, "param1"};

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        assertNotNull(result, "Expected method to be returned when exact type match");
        assertEquals("desiredMethod", result.getName(), "Method name should match the desired method");
    }

    @Test
    @DisplayName("lookupMethod converts parameter type and continues search when matchType returns APPROXIMATE_MATCH")
    void TC05_lookupMethod_with_approximate_type_match_and_valid_method() {
        Class<?> targetClass = SomeClass.class;
        String name = "desiredMethod";
        Object convertibleObject = new ConvertibleObject();
        Object[] parameters = new Object[]{convertibleObject, "param1", "param2"};

        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        assertNotNull(result, "Expected method to be returned after type conversion");
        assertEquals("desiredMethod", result.getName(), "Method name should match the desired method");
    }
}