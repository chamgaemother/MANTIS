import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.jfree.chart.plot.flow.FlowPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.flow.FlowDataset;
import org.jfree.data.flow.FlowKey;
import org.jfree.data.flow.NodeKey;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.ui.VerticalAlignment;
import org.jfree.chart.labels.FlowLabelGenerator;
import org.jfree.chart.labels.StandardFlowLabelGenerator;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FlowPlotTest {

    private FlowPlot plot;
    private FlowDataset dataset;
    private Graphics2D g2;
    private Rectangle2D area;
    private PlotRenderingInfo plotInfo;

    @BeforeEach
    void setUp() {
        dataset = mock(FlowDataset.class);
        plot = new FlowPlot(dataset);
        g2 = new BufferedImage(10, 10, BufferedImage.TYPE_INT_ARGB).createGraphics();
        area = new Rectangle2D.Double(0, 0, 100, 100);
        plotInfo = new PlotRenderingInfo(null);
    }

    @Test
    void testDrawWithNullGraphics2D() {
        assertThrows(IllegalArgumentException.class, () -> plot.draw(null, area, null, null, plotInfo));
    }

    @Test
    void testDrawWithNullArea() {
        assertThrows(IllegalArgumentException.class, () -> plot.draw(g2, null, null, null, plotInfo));
    }

    @Test
    void testDrawWithToolTips() throws Exception {
        EntityCollection entities = new EntityCollection();
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.JFreeChart.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(anyInt())).thenReturn(Collections.singletonList("Source"));
        when(dataset.getDestinations(anyInt())).thenReturn(Collections.singletonList("Destination"));
        when(dataset.getFlow(anyInt(), any(), any())).thenReturn(100.0);

        plot.draw(g2, area, null, new PlotState(), plotInfo);

        assertFalse(entities.getEntities().isEmpty());
    }

    @Test
    void testDrawWithoutToolTips() {
        plot.setToolTipGenerator(null);

        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(anyInt())).thenReturn(Collections.singletonList("Source"));
        when(dataset.getDestinations(anyInt())).thenReturn(Collections.singletonList("Destination"));
        when(dataset.getFlow(anyInt(), any(), any())).thenReturn(100.0);

        plot.draw(g2, area, null, null, plotInfo);
    }

    @Test
    void testDrawWithZeroFlows() {
        when(dataset.getStageCount()).thenReturn(0);
        plot.draw(g2, area, null, null, plotInfo);
    }

    @Test
    void testDrawWithFullStages() {
        when(dataset.getStageCount()).thenReturn(2);
        when(dataset.getSources(0)).thenReturn(Arrays.asList("Source1", "Source2"));
        when(dataset.getDestinations(0)).thenReturn(Arrays.asList("Dest1"));
        when(dataset.getFlow(0, "Source1", "Dest1")).thenReturn(50.0);
        when(dataset.getFlow(0, "Source2", "Dest1")).thenReturn(50.0);
        when(dataset.getFlow(1, "Dest1", "FinDest")).thenReturn(100.0);
        when(dataset.getDestinations(1)).thenReturn(Collections.singletonList("FinDest"));

        plot.draw(g2, area, null, null, plotInfo);
    }
}