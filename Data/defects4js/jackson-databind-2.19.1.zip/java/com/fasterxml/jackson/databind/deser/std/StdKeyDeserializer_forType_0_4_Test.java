package com.fasterxml.jackson.databind.deser.std;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer;
import com.fasterxml.jackson.databind.deser.std.FromStringDeserializer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.net.URI;
import java.net.URL;
import java.util.Currency;
import java.util.Locale;

public class StdKeyDeserializer_forType_0_4_Test {

    @Test
    @DisplayName("forType(URI.class) returns StdKeyDeserializer with TYPE_URI")
    void TC16() throws Exception {
        // GIVEN
        Class<?> raw = URI.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNotNull(result);

        // Access private fields using reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_valueClass");
        rawField.setAccessible(true);
        Class<?> resultRaw = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_URI, kind);
        assertEquals(URI.class, resultRaw);
    }

    @Test
    @DisplayName("forType(URL.class) returns StdKeyDeserializer with TYPE_URL")
    void TC17() throws Exception {
        // GIVEN
        Class<?> raw = URL.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNotNull(result);

        // Access private fields using reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_valueClass");
        rawField.setAccessible(true);
        Class<?> resultRaw = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_URL, kind);
        assertEquals(URL.class, resultRaw);
    }

    @Test
    @DisplayName("forType(Class.class) returns StdKeyDeserializer with TYPE_CLASS")
    void TC18() throws Exception {
        // GIVEN
        Class<?> raw = Class.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNotNull(result);

        // Access private fields using reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_valueClass");
        rawField.setAccessible(true);
        Class<?> resultRaw = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_CLASS, kind);
        assertEquals(Class.class, resultRaw);
    }

    @Test
    @DisplayName("forType(Locale.class) returns StdKeyDeserializer with TYPE_LOCALE and appropriate deserializer")
    void TC19() throws Exception {
        // GIVEN
        Class<?> raw = Locale.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNotNull(result);

        // Access private fields using reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_valueClass");
        rawField.setAccessible(true);
        Class<?> resultRaw = (Class<?>) rawField.get(result);

        Field deserField = StdKeyDeserializer.class.getDeclaredField("_deserializer");
        deserField.setAccessible(true);
        FromStringDeserializer<?> deser = (FromStringDeserializer<?>) deserField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_LOCALE, kind);
        assertEquals(Locale.class, resultRaw);
        assertNotNull(deser);
        assertTrue(deser instanceof FromStringDeserializer);
    }

    @Test
    @DisplayName("forType(Currency.class) returns StdKeyDeserializer with TYPE_CURRENCY and appropriate deserializer")
    void TC20() throws Exception {
        // GIVEN
        Class<?> raw = Currency.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNotNull(result);

        // Access private fields using reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_valueClass");
        rawField.setAccessible(true);
        Class<?> resultRaw = (Class<?>) rawField.get(result);

        Field deserField = StdKeyDeserializer.class.getDeclaredField("_deserializer");
        deserField.setAccessible(true);
        FromStringDeserializer<?> deser = (FromStringDeserializer<?>) deserField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_CURRENCY, kind);
        assertEquals(Currency.class, resultRaw);
        assertNotNull(deser);
        assertTrue(deser instanceof FromStringDeserializer);
    }
}