package org.apache.commons.compress.archivers.sevenz;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.attribute.FileTime;
import java.util.Collections;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class SevenZArchiveEntry_equals_2_1_Test {

    @Test
    @DisplayName("equals(obj) returns true when both entries have hasCrc=false and all other fields are identical")
    public void TC31_equals_WithHasCrcFalseAndIdenticalFields() {
        // GIVEN
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Set all fields identically for entry1
        entry1.setName("file.txt");
        entry1.setHasStream(true);
        entry1.setDirectory(false);
        entry1.setAntiItem(false);
        entry1.setHasCreationDate(true);
        entry1.setHasLastModifiedDate(true);
        entry1.setHasAccessDate(true);
        entry1.setCreationTime(FileTime.fromMillis(1000));
        entry1.setLastModifiedTime(FileTime.fromMillis(2000));
        entry1.setAccessTime(FileTime.fromMillis(3000));
        entry1.setHasWindowsAttributes(true);
        entry1.setWindowsAttributes(1234);
        entry1.setHasCrc(false);
        entry1.setCrcValue(0);
        entry1.setCompressedCrcValue(0);
        entry1.setSize(1024);
        entry1.setCompressedSize(512);
        entry1.setContentMethods(Collections.emptyList());

        // Set identically for entry2
        entry2.setName("file.txt");
        entry2.setHasStream(true);
        entry2.setDirectory(false);
        entry2.setAntiItem(false);
        entry2.setHasCreationDate(true);
        entry2.setHasLastModifiedDate(true);
        entry2.setHasAccessDate(true);
        entry2.setCreationTime(FileTime.fromMillis(1000));
        entry2.setLastModifiedTime(FileTime.fromMillis(2000));
        entry2.setAccessTime(FileTime.fromMillis(3000));
        entry2.setHasWindowsAttributes(true);
        entry2.setWindowsAttributes(1234);
        entry2.setHasCrc(false);
        entry2.setCrcValue(0);
        entry2.setCompressedCrcValue(0);
        entry2.setSize(1024);
        entry2.setCompressedSize(512);
        entry2.setContentMethods(Collections.emptyList());

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("equals(obj) returns true when both entries have hasWindowsAttributes=false and all other fields are identical")
    public void TC32_equals_WithHasWindowsAttributesFalseAndIdenticalFields() {
        // GIVEN
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Set all fields identically for entry1
        entry1.setName("file.txt");
        entry1.setHasStream(true);
        entry1.setDirectory(false);
        entry1.setAntiItem(false);
        entry1.setHasCreationDate(true);
        entry1.setHasLastModifiedDate(true);
        entry1.setHasAccessDate(true);
        entry1.setCreationTime(FileTime.fromMillis(1000));
        entry1.setLastModifiedTime(FileTime.fromMillis(2000));
        entry1.setAccessTime(FileTime.fromMillis(3000));
        entry1.setHasWindowsAttributes(false);
        entry1.setWindowsAttributes(0);
        entry1.setHasCrc(true);
        entry1.setCrcValue(5678);
        entry1.setCompressedCrcValue(91011);
        entry1.setSize(1024);
        entry1.setCompressedSize(512);
        entry1.setContentMethods(Collections.emptyList());

        // Set identically for entry2
        entry2.setName("file.txt");
        entry2.setHasStream(true);
        entry2.setDirectory(false);
        entry2.setAntiItem(false);
        entry2.setHasCreationDate(true);
        entry2.setHasLastModifiedDate(true);
        entry2.setHasAccessDate(true);
        entry2.setCreationTime(FileTime.fromMillis(1000));
        entry2.setLastModifiedTime(FileTime.fromMillis(2000));
        entry2.setAccessTime(FileTime.fromMillis(3000));
        entry2.setHasWindowsAttributes(false);
        entry2.setWindowsAttributes(0);
        entry2.setHasCrc(true);
        entry2.setCrcValue(5678);
        entry2.setCompressedCrcValue(91011);
        entry2.setSize(1024);
        entry2.setCompressedSize(512);
        entry2.setContentMethods(Collections.emptyList());

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertTrue(result);
    }
}