package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_atan2_0_6_Test {

    @Test
    @DisplayName("atan2(x=1.0, y=0.0000000001) returns correct small angle for finite inputs")
    void TC26_testSmallAngleFiniteInputs() {
        // GIVEN
        double x = 1.0;
        double y = 1e-10;
        
        // WHEN
        double result = FastMath.atan2(x, y);
        
        // THEN
        double expected = Math.atan2(y, x);
        assertTrue(Math.abs(result - expected) < 1e-10, "Result is not within the expected small angle range.");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=-0.0) returns -0.0 for finite x and negative zero y")
    void TC27_testNegativeZeroY() {
        // GIVEN
        double x = 1.0;
        double y = -0.0;
        
        // WHEN
        double result = FastMath.atan2(x, y);
        
        // THEN
        assertEquals(Double.doubleToLongBits(-0.0), Double.doubleToLongBits(result), "Result is not -0.0 as expected.");
    }

    @Test
    @DisplayName("atan2(x=-1.0, y=1.0) returns correct angle in second quadrant for finite inputs")
    void TC28_testSecondQuadrant() {
        // GIVEN
        double x = -1.0;
        double y = 1.0;
        
        // WHEN
        double result = FastMath.atan2(x, y);
        
        // THEN
        double expected = Math.PI * 3 / 4;
        assertTrue(Math.abs(result - expected) < 1e-10, "Result is not within the expected second quadrant angle range.");
    }

    @Test
    @DisplayName("atan2(x=-1.0, y=-1.0) returns correct angle in third quadrant for finite inputs")
    void TC29_testThirdQuadrant() {
        // GIVEN
        double x = -1.0;
        double y = -1.0;
        
        // WHEN
        double result = FastMath.atan2(x, y);
        
        // THEN
        double expected = -Math.PI * 3 / 4;
        assertTrue(Math.abs(result - expected) < 1e-10, "Result is not within the expected third quadrant angle range.");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=Infinity) handles extremely large y correctly")
    void TC30_testInfiniteY() {
        // GIVEN
        double x = 1.0;
        double y = Double.POSITIVE_INFINITY;
        
        // WHEN
        double result = FastMath.atan2(x, y);
        
        // THEN
        double expected = Math.PI / 2;
        assertEquals(expected, result, "Result does not match Math.PI / 2 for infinite y.");
    }

}