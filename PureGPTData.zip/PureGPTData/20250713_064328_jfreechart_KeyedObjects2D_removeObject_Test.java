import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.jfree.data.UnknownKeyException;

import static org.junit.jupiter.api.Assertions.*;

public class KeyedObjects2DTest {

    private KeyedObjects2D data;

    @BeforeEach
    public void setUp() {
        data = new KeyedObjects2D();
        data.addObject(1, "Row1", "Col1");
        data.addObject(2, "Row1", "Col2");
        data.addObject(3, "Row2", "Col1");
        data.addObject(4, "Row2", "Col2");
    }

    @Test
    public void testRemoveObjectNormalCase() {
        data.removeObject("Row1", "Col1");
        assertNull(data.getObject("Row1", "Col1"));
    }

    @Test
    public void testRemoveObjectInvalidRowKey() {
        assertThrows(UnknownKeyException.class, () -> data.removeObject("RowInvalid", "Col1"));
    }

    @Test
    public void testRemoveObjectInvalidColumnKey() {
        assertThrows(UnknownKeyException.class, () -> data.removeObject("Row1", "ColInvalid"));
    }

    @Test
    public void testRemoveObjectRowBecameEmpty() {
        data.removeObject("Row1", "Col1");
        data.removeObject("Row1", "Col2");
        assertEquals(-1, data.getRowIndex("Row1"));
    }

    @Test
    public void testRemoveObjectColumnBecameEmpty() {
        data.removeObject("Row1", "Col1");
        data.removeObject("Row2", "Col1");
        assertEquals(-1, data.getColumnIndex("Col1"));
    }
    
    // Test for removing object when row and column keys are null to cover branch in setObject
    @Test
    public void testRemoveObjectNullRowKey() {
        assertThrows(IllegalArgumentException.class, () -> data.removeObject(null, "Col1"));
    }

    @Test
    public void testRemoveObjectNullColumnKey() {
        assertThrows(IllegalArgumentException.class, () -> data.removeObject("Row1", null));
    }
}