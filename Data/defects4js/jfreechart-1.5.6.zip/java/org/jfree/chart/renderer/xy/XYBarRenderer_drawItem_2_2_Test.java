package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.ui.RectangleEdge;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class XYBarRenderer_drawItem_2_2_Test {

    @Test
    @DisplayName("TC08: drawItem handles margin set to zero, rendering full-width bars")
    public void testDrawItem_MarginZero_FullWidthBars() throws Exception {
        // GIVEN
        XYBarRenderer renderer = new XYBarRenderer();
        renderer.setMargin(0.0);
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(10.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);

        // Mocking renderer methods
        XYBarRenderer rendererSpy = Mockito.spy(renderer);
        doReturn(false).when(rendererSpy).getUseYInterval();
        doReturn(0.0).when(rendererSpy).getBase();
        doReturn(true).when(rendererSpy).getItemVisible(0, 0);
        
        // Mocking axes
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(0.0, any(Rectangle2D.class), any())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(10.0, any(Rectangle2D.class), any())).thenReturn(100.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(1.0, any(Rectangle2D.class), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, any(Rectangle2D.class), any())).thenReturn(100.0);
        
        // Mocking plot
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        // Mocking state and other parameters
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        Graphics2D g2 = mock(Graphics2D.class);

        // Mocking barPainter via reflection
        XYBarPainter barPainterMock = mock(XYBarPainter.class);
        Field barPainterField = XYBarRenderer.class.getDeclaredField("barPainter");
        barPainterField.setAccessible(true);
        barPainterField.set(rendererSpy, barPainterMock);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // THEN
        ArgumentCaptor<Rectangle2D> barCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        ArgumentCaptor<RectangleEdge> edgeCaptor = ArgumentCaptor.forClass(RectangleEdge.class);
        verify(barPainterMock).paintBar(eq(g2), eq(rendererSpy), eq(0), eq(0), barCaptor.capture(), edgeCaptor.capture());
        
        Rectangle2D capturedBar = barCaptor.getValue();
        assertEquals(0.0, capturedBar.getX(), 0.001);
        assertEquals(50.0, capturedBar.getY(), 0.001);
        assertEquals(100.0, capturedBar.getWidth(), 0.001);
        assertEquals(100.0, capturedBar.getHeight(), 0.001);
    }

    @Test
    @DisplayName("TC09: drawItem handles item label visibility set to true, drawing labels correctly")
    public void testDrawItem_ItemLabelVisible_DrawsLabels() throws Exception {
        // GIVEN
        XYBarRenderer renderer = new XYBarRenderer();
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartYValue(0, 0)).thenReturn(0.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(10.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);

        // Mocking renderer methods
        XYBarRenderer rendererSpy = Mockito.spy(renderer);
        doReturn(false).when(rendererSpy).getUseYInterval();
        doReturn(0.0).when(rendererSpy).getBase();
        doReturn(true).when(rendererSpy).getItemVisible(0, 0);
        doReturn(true).when(rendererSpy).isItemLabelVisible(0, 0);

        // Mocking label generator
        XYItemLabelGenerator labelGenerator = mock(XYItemLabelGenerator.class);
        when(labelGenerator.generateLabel(dataset, 0, 0)).thenReturn("Label");
        doReturn(labelGenerator).when(rendererSpy).getItemLabelGenerator(0, 0);

        // Mocking axes
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(0.0, any(Rectangle2D.class), any())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(10.0, any(Rectangle2D.class), any())).thenReturn(100.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(1.0, any(Rectangle2D.class), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, any(Rectangle2D.class), any())).thenReturn(100.0);
        
        // Mocking plot
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        // Mocking state and other parameters
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        Graphics2D g2 = mock(Graphics2D.class);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // THEN
        verify(labelGenerator).generateLabel(dataset, 0, 0);
        verify(rendererSpy).drawItemLabel(eq(g2), eq(dataset), eq(0), eq(0), eq(plot), eq(labelGenerator), any(Rectangle2D.class), eq(false));
    }

    @Test
    @DisplayName("TC10: drawItem handles negative y1 with non-inverted axis, rendering bar correctly")
    public void testDrawItem_NegativeY1_NonInvertedAxis() throws Exception {
        // GIVEN
        XYBarRenderer renderer = new XYBarRenderer();
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartYValue(0, 0)).thenReturn(-10.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(-5.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);

        // Mocking renderer methods
        XYBarRenderer rendererSpy = Mockito.spy(renderer);
        doReturn(true).when(rendererSpy).getUseYInterval();
        doReturn(true).when(rendererSpy).getItemVisible(0, 0);
        
        // Mocking axes
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(-10.0, any(Rectangle2D.class), any())).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(-5.0, any(Rectangle2D.class), any())).thenReturn(60.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(1.0, any(Rectangle2D.class), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, any(Rectangle2D.class), any())).thenReturn(100.0);
        
        // Mocking plot
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        // Mocking state and other parameters
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        Graphics2D g2 = mock(Graphics2D.class);

        // Mocking barPainter via reflection
        XYBarPainter barPainterMock = mock(XYBarPainter.class);
        Field barPainterField = XYBarRenderer.class.getDeclaredField("barPainter");
        barPainterField.setAccessible(true);
        barPainterField.set(rendererSpy, barPainterMock);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // THEN
        ArgumentCaptor<Rectangle2D> barCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        ArgumentCaptor<RectangleEdge> edgeCaptor = ArgumentCaptor.forClass(RectangleEdge.class);
        verify(barPainterMock).paintBar(eq(g2), eq(rendererSpy), eq(0), eq(0), barCaptor.capture(), edgeCaptor.capture());
        
        Rectangle2D capturedBar = barCaptor.getValue();
        assertEquals(50.0, capturedBar.getX(), 0.001);
        assertEquals(40.0, capturedBar.getY(), 0.001);
        assertEquals(100.0, capturedBar.getWidth(), 0.001);
        assertEquals(20.0, capturedBar.getHeight(), 0.001);
        
        // Verify RectangleEdge.TOP
        assertEquals(RectangleEdge.TOP, edgeCaptor.getValue());
    }

    @Test
    @DisplayName("TC11: drawItem handles multiple visible series with varying iteration counts")
    public void testDrawItem_MultipleVisibleSeries_VaryingIterations() throws Exception {
        // GIVEN
        XYBarRenderer renderer = new XYBarRenderer();
        
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(3);
        
        // Mocking renderer visibility
        XYBarRenderer rendererSpy = Mockito.spy(renderer);
        when(rendererSpy.isSeriesVisible(0)).thenReturn(true);
        when(rendererSpy.isSeriesVisible(1)).thenReturn(false);
        when(rendererSpy.isSeriesVisible(2)).thenReturn(true);
        
        // Mocking dataset values for series 0
        when(dataset.getStartYValue(0, 0)).thenReturn(0.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(10.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(rendererSpy.getItemVisible(0, 0)).thenReturn(true);
        
        // Mocking dataset values for series 2
        when(dataset.getStartYValue(2, 0)).thenReturn(5.0);
        when(dataset.getEndYValue(2, 0)).thenReturn(15.0);
        when(dataset.getStartXValue(2, 0)).thenReturn(3.0);
        when(dataset.getEndXValue(2, 0)).thenReturn(4.0);
        when(rendererSpy.getItemVisible(2, 0)).thenReturn(true);
        
        when(rendererSpy.getUseYInterval()).thenReturn(true);
        
        // Mocking axes
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(0.0, any(Rectangle2D.class), any())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(10.0, any(Rectangle2D.class), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, any(Rectangle2D.class), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(15.0, any(Rectangle2D.class), any())).thenReturn(150.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(1.0, any(Rectangle2D.class), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, any(Rectangle2D.class), any())).thenReturn(100.0);
        when(domainAxis.valueToJava2D(3.0, any(Rectangle2D.class), any())).thenReturn(150.0);
        when(domainAxis.valueToJava2D(4.0, any(Rectangle2D.class), any())).thenReturn(200.0);
        
        // Mocking plot
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        // Mocking state and other parameters
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        Graphics2D g2 = mock(Graphics2D.class);

        // Mocking barPainter via reflection
        XYBarPainter barPainterMock = mock(XYBarPainter.class);
        Field barPainterField = XYBarRenderer.class.getDeclaredField("barPainter");
        barPainterField.setAccessible(true);
        barPainterField.set(rendererSpy, barPainterMock);

        // Mocking margin
        when(rendererSpy.getMargin()).thenReturn(0.1);
        when(rendererSpy.getShadowsVisible()).thenReturn(true);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        rendererSpy.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 2, 0, crosshairState, 1);

        // THEN
        verify(barPainterMock, times(2)).paintBar(eq(g2), eq(rendererSpy), anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class));
    }

    @Test
    @DisplayName("TC12: drawItem throws ClassCastException when dataset is not IntervalXYDataset")
    public void testDrawItem_DatasetNotIntervalXYDataset_ThrowsException() throws Exception {
        // GIVEN
        XYBarRenderer renderer = new XYBarRenderer();
        
        XYDataset dataset = mock(XYDataset.class);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(true);
        
        // Mocking axes
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        
        // Mocking plot
        XYPlot plot = mock(XYPlot.class);
        
        // Mocking state and other parameters
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        Graphics2D g2 = mock(Graphics2D.class);

        // WHEN & THEN
        assertThrows(ClassCastException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        });
    }
}