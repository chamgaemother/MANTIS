import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.attribute.FileTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration;
import org.apache.commons.compress.archivers.sevenz.SevenZMethod;
import org.junit.jupiter.api.Test;

class SevenZArchiveEntryTest {

    private static class MockSevenZMethodConfiguration implements SevenZMethodConfiguration {
        private final SevenZMethod method;
        private final int options;

        public MockSevenZMethodConfiguration(SevenZMethod method, int options) {
            this.method = method;
            this.options = options;
        }

        @Override
        public SevenZMethod getMethod() {
            return method;
        }

        @Override
        public int getOptions() {
            return options;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null || getClass() != obj.getClass())
                return false;
            MockSevenZMethodConfiguration other = (MockSevenZMethodConfiguration) obj;
            return method == other.method && options == other.options;
        }

        @Override
        public int hashCode() {
            return method.hashCode() * 31 + options;
        }
    }

    @Test
    void testEqualsSameObject() {
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        assertTrue(entry.equals(entry));
    }

    @Test
    void testEqualsNull() {
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        assertFalse(entry.equals(null));
    }

    @Test
    void testEqualsDifferentClass() {
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        String other = "NotASevenZArchiveEntry";
        assertFalse(entry.equals(other));
    }

    @Test
    void testEqualsAllFieldsEqualNullContentMethods() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        assertTrue(entry1.equals(entry2));
    }

    @Test
    void testEqualsAllFieldsEqualNonNullContentMethods() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        SevenZMethodConfiguration methodConfig1 = new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0);
        SevenZMethodConfiguration methodConfig2 = new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0);

        entry1.setContentMethods(Arrays.asList(methodConfig1));
        entry2.setContentMethods(Arrays.asList(methodConfig2));

        assertTrue(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentName() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName("Name1");
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName("Name2");
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentHasStream() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasStream(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasStream(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentIsDirectory() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setDirectory(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setDirectory(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentIsAntiItem() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setAntiItem(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setAntiItem(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentHasCreationDate() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasCreationDate(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasCreationDate(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentCreationDate() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCreationTime(FileTime.fromMillis(1000));
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCreationTime(FileTime.fromMillis(2000));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentHasLastModifiedDate() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasLastModifiedDate(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasLastModifiedDate(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentLastModifiedDate() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setLastModifiedTime(FileTime.fromMillis(1000));
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setLastModifiedTime(FileTime.fromMillis(2000));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentHasAccessDate() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasAccessDate(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasAccessDate(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentAccessDate() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setAccessTime(FileTime.fromMillis(1000));
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setAccessTime(FileTime.fromMillis(2000));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentHasWindowsAttributes() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasWindowsAttributes(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasWindowsAttributes(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentWindowsAttributes() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setWindowsAttributes(123);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setWindowsAttributes(456);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentHasCrc() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasCrc(true);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasCrc(false);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentCrc() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCrcValue(123L);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCrcValue(456L);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentCompressedCrc() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCompressedCrcValue(123L);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCompressedCrcValue(456L);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentSize() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setSize(100L);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setSize(200L);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentCompressedSize() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setCompressedSize(100L);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setCompressedSize(200L);
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsContentMethodsOneNull() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setContentMethods(null);
        entry2.setContentMethods(Collections.singletonList(new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0)));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsContentMethodsBothNull() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setContentMethods(null);
        entry2.setContentMethods(null);
        assertTrue(entry1.equals(entry2));
    }

    @Test
    void testEqualsContentMethodsDifferentSize() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setContentMethods(Arrays.asList(
                new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0),
                new MockSevenZMethodConfiguration(SevenZMethod.DEFLATE, 0)));
        entry2.setContentMethods(Collections.singletonList(
                new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0)));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsContentMethodsDifferentElements() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setContentMethods(Collections.singletonList(
                new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0)));
        entry2.setContentMethods(Collections.singletonList(
                new MockSevenZMethodConfiguration(SevenZMethod.DEFLATE, 0)));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsContentMethodsSameElementsDifferentOrder() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setContentMethods(Arrays.asList(
                new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0),
                new MockSevenZMethodConfiguration(SevenZMethod.DEFLATE, 0)));
        entry2.setContentMethods(Arrays.asList(
                new MockSevenZMethodConfiguration(SevenZMethod.DEFLATE, 0),
                new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 0)));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsContentMethodsNullAndEmpty() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setContentMethods(null);
        entry2.setContentMethods(Collections.emptyList());
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsContentMethodsEmptyLists() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setContentMethods(Collections.emptyList());
        entry2.setContentMethods(Collections.emptyList());
        assertTrue(entry1.equals(entry2));
    }

    @Test
    void testEqualsWithDifferentContentMethods() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        SevenZMethodConfiguration methodConfig1 = new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 1);
        SevenZMethodConfiguration methodConfig2 = new MockSevenZMethodConfiguration(SevenZMethod.LZMA2, 2);
        entry1.setContentMethods(Collections.singletonList(methodConfig1));
        entry2.setContentMethods(Collections.singletonList(methodConfig2));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsWithIdenticalContentMethods() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        SevenZMethodConfiguration methodConfig1 = new MockSevenZMethodConfiguration(SevenZMethod.BZIP2, 0);
        SevenZMethodConfiguration methodConfig2 = new MockSevenZMethodConfiguration(SevenZMethod.BZIP2, 0);
        entry1.setContentMethods(Collections.singletonList(methodConfig1));
        entry2.setContentMethods(Collections.singletonList(methodConfig2));
        assertTrue(entry1.equals(entry2));
    }

    @Test
    void testEqualsDifferentAccessDatePresence() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasAccessDate(false);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasAccessDate(true);
        entry2.setAccessTime(FileTime.fromMillis(1000));
        assertFalse(entry1.equals(entry2));
    }

    @Test
    void testEqualsBothAccessDateAbsent() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setHasAccessDate(false);
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setHasAccessDate(false);
        assertTrue(entry1.equals(entry2));
    }
}