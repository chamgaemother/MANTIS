package com.fasterxml.jackson.databind.introspect;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.type.TypeFactory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class JacksonAnnotationIntrospector_refineDeserializationType_0_2_Test {

//     @Test
//     @DisplayName("type is map-like, jsonDeser is not null, keyClass specialization throws IllegalArgumentException")
//     void TC06_typeIsMapLike_jsonDeserNotNull_keyClassSpecializationThrows() throws Exception {
//         MapperConfig<?> config = mock(MapperConfig.class);
//         TypeFactory typeFactory = mock(TypeFactory.class);
//         when(config.getTypeFactory()).thenReturn(typeFactory);
// 
//         Annotated annotated = mock(Annotated.class);
//         JsonDeserialize jsonDeser = mock(JsonDeserialize.class);
//         when(annotated.getAnnotation(JsonDeserialize.class)).thenReturn(jsonDeser);
//         when(jsonDeser.keyAs()).thenReturn((Class<?>) null);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.isMapLikeType()).thenReturn(true);
//         JavaType keyType = mock(JavaType.class);
//         when(baseType.getKeyType()).thenReturn(keyType);
// 
//         JacksonAnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
// 
//         JacksonAnnotationIntrospector spyIntrospector = spy(introspector);
//         doReturn(jsonDeser).when(spyIntrospector)._findAnnotation(any(), eq(JsonDeserialize.class));
//         doReturn(null).when(spyIntrospector)._classIfExplicit(any(), any());
// 
//         when(typeFactory.constructSpecializedType(any(), any())).thenThrow(new IllegalArgumentException("Failed to narrow key type"));
// 
//         JsonMappingException exception = assertThrows(JsonMappingException.class, () -> {
//             spyIntrospector.refineDeserializationType(config, annotated, baseType);
//         });
// 
//         assertTrue(exception.getMessage().contains("Failed to narrow key type"));
//     }

//     @Test
//     @DisplayName("type has contentType, jsonDeser is not null, contentClass provided and specialization successful")
//     void TC07_typeHasContentType_jsonDeserNotNull_contentClassSpecializationSuccessful() throws Exception {
//         MapperConfig<?> config = mock(MapperConfig.class);
//         TypeFactory typeFactory = mock(TypeFactory.class);
//         when(config.getTypeFactory()).thenReturn(typeFactory);
// 
//         Annotated annotated = mock(Annotated.class);
//         JsonDeserialize jsonDeser = mock(JsonDeserialize.class);
//         when(annotated.getAnnotation(JsonDeserialize.class)).thenReturn(jsonDeser);
//         when(jsonDeser.contentAs()).thenReturn(String.class);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.getContentType()).thenReturn(mock(JavaType.class));
//         when(baseType.withContentType(any())).thenReturn(baseType);
//         when(baseType.isMapLikeType()).thenReturn(false);
// 
//         JavaType contentType = mock(JavaType.class);
//         when(baseType.getContentType()).thenReturn(contentType);
// 
//         JavaType specializedContentType = mock(JavaType.class);
//         when(typeFactory.constructSpecializedType(contentType, String.class)).thenReturn(specializedContentType);
//         when(baseType.withContentType(specializedContentType)).thenReturn(baseType);
// 
//         JacksonAnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
//         JacksonAnnotationIntrospector spyIntrospector = spy(introspector);
//         doReturn(jsonDeser).when(spyIntrospector)._findAnnotation(any(), eq(JsonDeserialize.class));
//         doReturn(String.class).when(spyIntrospector)._classIfExplicit(any(), any());
// 
//         JavaType result = spyIntrospector.refineDeserializationType(config, annotated, baseType);
// 
//         assertEquals(baseType, result);
//         verify(typeFactory).constructSpecializedType(contentType, String.class);
//     }

    @Test
    @DisplayName("type has contentType, jsonDeser is null, proceed without content specialization")
    void TC08_typeHasContentType_jsonDeserNull_noContentSpecialization() throws Exception {
        MapperConfig<?> config = mock(MapperConfig.class);
        TypeFactory typeFactory = mock(TypeFactory.class);
        when(config.getTypeFactory()).thenReturn(typeFactory);

        Annotated annotated = mock(Annotated.class);
        when(annotated.getAnnotation(JsonDeserialize.class)).thenReturn(null);

        JavaType baseType = mock(JavaType.class);
        when(baseType.getContentType()).thenReturn(mock(JavaType.class));
        when(baseType.isMapLikeType()).thenReturn(false);

        JavaType contentType = mock(JavaType.class);
        when(baseType.getContentType()).thenReturn(contentType);

        JacksonAnnotationIntrospector introspector = new JacksonAnnotationIntrospector();

        JavaType result = introspector.refineDeserializationType(config, annotated, baseType);

        assertEquals(baseType, result);
        verify(typeFactory, never()).constructSpecializedType(any(), any());
    }

//     @Test
//     @DisplayName("contentClass is null, no content specialization applied")
//     void TC09_contentClassNull_noContentSpecialization() throws Exception {
//         MapperConfig<?> config = mock(MapperConfig.class);
//         TypeFactory typeFactory = mock(TypeFactory.class);
//         when(config.getTypeFactory()).thenReturn(typeFactory);
// 
//         Annotated annotated = mock(Annotated.class);
//         JsonDeserialize jsonDeser = mock(JsonDeserialize.class);
//         when(annotated.getAnnotation(JsonDeserialize.class)).thenReturn(jsonDeser);
//         when(jsonDeser.contentAs()).thenReturn(void.class);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.getContentType()).thenReturn(mock(JavaType.class));
//         when(baseType.isMapLikeType()).thenReturn(false);
// 
//         JavaType contentType = mock(JavaType.class);
//         when(baseType.getContentType()).thenReturn(contentType);
// 
//         JacksonAnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
//         JacksonAnnotationIntrospector spyIntrospector = spy(introspector);
//         doReturn(jsonDeser).when(spyIntrospector)._findAnnotation(any(), eq(JsonDeserialize.class));
//         doReturn(null).when(spyIntrospector)._classIfExplicit(any(), any());
// 
//         JavaType result = spyIntrospector.refineDeserializationType(config, annotated, baseType);
// 
//         assertEquals(baseType, result);
//         verify(typeFactory, never()).constructSpecializedType(any(), any());
//     }

//     @Test
//     @DisplayName("contentClass specialization throws IllegalArgumentException, expect JsonMappingException")
//     void TC10_contentClassSpecializationThrows_expectJsonMappingException() throws Exception {
//         MapperConfig<?> config = mock(MapperConfig.class);
//         TypeFactory typeFactory = mock(TypeFactory.class);
//         when(config.getTypeFactory()).thenReturn(typeFactory);
// 
//         Annotated annotated = mock(Annotated.class);
//         JsonDeserialize jsonDeser = mock(JsonDeserialize.class);
//         when(annotated.getAnnotation(JsonDeserialize.class)).thenReturn(jsonDeser);
//         when(jsonDeser.contentAs()).thenReturn(String.class);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.getContentType()).thenReturn(mock(JavaType.class));
//         when(baseType.withContentType(any())).thenReturn(baseType);
//         when(baseType.isMapLikeType()).thenReturn(false);
// 
//         JavaType contentType = mock(JavaType.class);
//         when(baseType.getContentType()).thenReturn(contentType);
// 
//         when(typeFactory.constructSpecializedType(any(), eq(String.class))).thenThrow(new IllegalArgumentException("Failed to narrow value type"));
// 
//         JacksonAnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
//         JacksonAnnotationIntrospector spyIntrospector = spy(introspector);
//         doReturn(jsonDeser).when(spyIntrospector)._findAnnotation(any(), eq(JsonDeserialize.class));
//         doReturn(String.class).when(spyIntrospector)._classIfExplicit(any(), any());
// 
//         JsonMappingException exception = assertThrows(JsonMappingException.class, () -> {
//             spyIntrospector.refineDeserializationType(config, annotated, baseType);
//         });
// 
//         assertTrue(exception.getMessage().contains("Failed to narrow value type"));
//     }
}