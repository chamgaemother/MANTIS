package org.apache.commons.math3.analysis.differentiation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

public class DSCompiler_getCompiler_0_1_Test {

    @Test
    @DisplayName("getCompiler with null cache initializes new cache and returns newly created DSCompiler")
    public void test_TC01_getCompiler_initializesNewCacheWhenNull() throws Exception {
        // Arrange
        int parameters = 1;
        int order = 1;

        // Use reflection to set the private static 'compilers' field to an AtomicReference with initial null
        Class<?> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, new AtomicReference<>(null));

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertNotNull(result, "A new DSCompiler should be created and returned when cache is null.");
    }

    @Test
    @DisplayName("getCompiler retrieves existing DSCompiler from non-null cache within bounds")
    public void test_TC02_getCompiler_returnsExistingCompilerFromCache() throws Exception {
        // Arrange
        int parameters = 2;
        int order = 2;
        DSCompiler existingCompiler = DSCompiler.getCompiler(parameters, order); // Use getCompiler instead of raw constructor
        DSCompiler[][] cache = new DSCompiler[parameters + 1][order + 1];
        cache[parameters][order] = existingCompiler;

        // Use reflection to set the private static 'compilers' field
        Class<?> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> atomicCache = new AtomicReference<>(cache);
        compilersField.set(null, atomicCache);

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertSame(existingCompiler, result, "getCompiler should return the existing DSCompiler from cache.");
    }

    @Test
    @DisplayName("getCompiler expands cache when cache length <= parameters")
    public void test_TC03_getCompiler_expandsCacheWhenLengthLessThanOrEqualParameters() throws Exception {
        // Arrange
        int parameters = 5;
        int order = 3;
        DSCompiler[][] cache = new DSCompiler[parameters][order];

        // Use reflection to set the private static 'compilers' field
        Class<?> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> atomicCache = new AtomicReference<>(cache);
        compilersField.set(null, atomicCache);

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertNotNull(result, "Cache should be expanded and a new DSCompiler should be created.");
    }

    @Test
    @DisplayName("getCompiler expands cache when order index is out of bounds")
    public void test_TC04_getCompiler_expandsCacheWhenOrderIndexOutOfBounds() throws Exception {
        // Arrange
        int parameters = 3;
        int order = 4;
        DSCompiler[][] cache = new DSCompiler[parameters + 1][order];

        // Use reflection to set the private static 'compilers' field
        Class<?> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> atomicCache = new AtomicReference<>(cache);
        compilersField.set(null, atomicCache);

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertNotNull(result, "Cache should be expanded and a new DSCompiler should be created when order index is out of bounds.");
    }

    @Test
    @DisplayName("getCompiler creates new DSCompiler when cache entry is null")
    public void test_TC05_getCompiler_createsNewCompilerWhenCacheEntryIsNull() throws Exception {
        // Arrange
        int parameters = 2;
        int order = 2;
        DSCompiler[][] cache = new DSCompiler[parameters + 1][order + 1];
        cache[parameters][order] = null;

        // Use reflection to set the private static 'compilers' field
        Class<?> cls = DSCompiler.class;
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        AtomicReference<DSCompiler[][]> atomicCache = new AtomicReference<>(cache);
        compilersField.set(null, atomicCache);

        // Act
        DSCompiler result = DSCompiler.getCompiler(parameters, order);

        // Assert
        assertNotNull(result, "A new DSCompiler should be created and returned when cache entry is null.");
    }
}