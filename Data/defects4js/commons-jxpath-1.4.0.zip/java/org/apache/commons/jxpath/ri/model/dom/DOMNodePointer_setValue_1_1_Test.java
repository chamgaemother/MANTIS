package org.apache.commons.jxpath.ri.model.dom;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Locale;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;

public class DOMNodePointer_setValue_1_1_Test {

    @Test
    @DisplayName("setValue with COMMENT_NODE and non-empty string sets node value")
    void TC17_setValue_With_COMMENT_NODE_NonEmptyString_SetsNodeValue() throws Exception {
        // Arrange
        Comment commentNode = mock(Comment.class);
        when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
        String value = "Updated Comment";
        DOMNodePointer domNodePointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
        
        // Act
        domNodePointer.setValue(value);
        
        // Assert
        verify(commentNode).setNodeValue("Updated Comment");
    }

    @Test
    @DisplayName("setValue with COMMENT_NODE and empty string removes node")
    void TC18_setValue_With_COMMENT_NODE_EmptyString_RemovesNode() throws Exception {
        // Arrange
        Comment commentNode = mock(Comment.class);
        Node parent = mock(Node.class);
        when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
        when(commentNode.getParentNode()).thenReturn(parent);
        String value = "";
        DOMNodePointer domNodePointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
        
        // Act
        domNodePointer.setValue(value);
        
        // Assert
        verify(parent).removeChild(commentNode);
    }

    @Test
    @DisplayName("setValue with PROCESSING_INSTRUCTION_NODE and non-empty string sets node data")
    void TC19_setValue_With_PROCESSING_INSTRUCTION_NODE_NonEmptyString_SetsNodeData() throws Exception {
        // Arrange
        ProcessingInstruction piNode = mock(ProcessingInstruction.class);
        when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
        String value = "Updated PI Data";
        DOMNodePointer domNodePointer = new DOMNodePointer(piNode, Locale.ENGLISH);
        
        // Act
        domNodePointer.setValue(value);
        
        // Assert
        verify(piNode).setNodeValue("Updated PI Data");
    }

    @Test
    @DisplayName("setValue with PROCESSING_INSTRUCTION_NODE and empty string removes node")
    void TC20_setValue_With_PROCESSING_INSTRUCTION_NODE_EmptyString_RemovesNode() throws Exception {
        // Arrange
        ProcessingInstruction piNode = mock(ProcessingInstruction.class);
        Node parent = mock(Node.class);
        when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
        when(piNode.getParentNode()).thenReturn(parent);
        String value = "";
        DOMNodePointer domNodePointer = new DOMNodePointer(piNode, Locale.ENGLISH);
        
        // Act
        domNodePointer.setValue(value);
        
        // Assert
        verify(parent).removeChild(piNode);
    }

    @Test
    @DisplayName("setValue with ATTRIBUTE_NODE and non-empty string updates attribute value")
    void TC21_setValue_With_ATTRIBUTE_NODE_NonEmptyString_UpdatesAttributeValue() throws Exception {
        // Arrange
        Attr attrNode = mock(Attr.class);
        when(attrNode.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
        String value = "Updated Attribute";
        DOMNodePointer domNodePointer = new DOMNodePointer(attrNode, Locale.ENGLISH);
        
        // Act
        domNodePointer.setValue(value);
        
        // Assert
        verify(attrNode).setNodeValue("Updated Attribute");
    }
}