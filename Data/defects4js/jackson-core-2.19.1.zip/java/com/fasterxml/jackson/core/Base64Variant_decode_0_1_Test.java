package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Base64Variant_decode_0_1_Test {

    @Test
    @DisplayName("decode with an empty string returns without appending bytes")
    void TC01() {
        // GIVEN
        String str = "";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN
        Base64Variant variant = new Base64Variant("TestVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        variant.decode(str, builder);

        // THEN
        assertEquals(0, builder.toByteArray().length);
    }

    @Test
    @DisplayName("decode string with only whitespace is ignored and returns without appending bytes")
    void TC02() {
        // GIVEN
        String str = "   ";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN
        Base64Variant variant = new Base64Variant("TestVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        variant.decode(str, builder);

        // THEN
        assertEquals(0, builder.toByteArray().length);
    }

    @Test
    @DisplayName("decode with valid base64 string without padding appends three bytes")
    void TC03() {
        // GIVEN
        String str = "TWFu";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN
        Base64Variant variant = new Base64Variant("TestVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        variant.decode(str, builder);

        // THEN
        byte[] expected = new byte[]{77, 97, 110};
        assertArrayEquals(expected, builder.toByteArray());
    }

    @Test
    @DisplayName("decode with valid base64 string with padding appends two bytes")
    void TC04() {
        // GIVEN
        String str = "TWE=";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN
        Base64Variant variant = new Base64Variant("TestVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        variant.decode(str, builder);

        // THEN
        byte[] expected = new byte[]{77, 97};
        assertArrayEquals(expected, builder.toByteArray());
    }

    @Test
    @DisplayName("decode with valid base64 string with double padding appends one byte")
    void TC05() {
        // GIVEN
        String str = "TQ==";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN
        Base64Variant variant = new Base64Variant("TestVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
        variant.decode(str, builder);

        // THEN
        byte[] expected = new byte[]{77};
        assertArrayEquals(expected, builder.toByteArray());
    }

}