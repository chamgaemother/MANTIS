package com.fasterxml.jackson.databind.deser.impl;
import java.lang.reflect.*;
import java.io.*;
import java.lang.reflect.Field;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ManagedReferenceProperty_setAndReturn_0_1_Test {

    @Test
    @DisplayName("TC01: value is null, method returns delegate.setAndReturn without setting _backProperty")
    public void TC01_setAndReturn_withNullValue() throws Exception {
        // GIVEN
        Object value = null;
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        when(delegate.setAndReturn(instance, value)).thenReturn("expectedResult");

        SettableBeanProperty _backProperty = mock(SettableBeanProperty.class);

        // Correctly Instantiate ManagedReferenceProperty with required arguments
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", _backProperty, false);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(delegate, times(1)).setAndReturn(instance, value);
        verifyNoInteractions(_backProperty);
        assertEquals("expectedResult", result);
    }

    @Test
    @DisplayName("TC02: value is non-null and _isContainer is false, single object is set")
    public void TC02_setAndReturn_withNonContainerSingleObject() throws Exception {
        // GIVEN
        Object value = new Object();
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        when(delegate.setAndReturn(instance, value)).thenReturn("expectedResult");

        SettableBeanProperty _backProperty = mock(SettableBeanProperty.class);

        // Correctly Instantiate ManagedReferenceProperty with required arguments
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", _backProperty, false);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(_backProperty, times(1)).set(value, instance);
        verify(delegate, times(1)).setAndReturn(instance, value);
        assertEquals("expectedResult", result);
    }

    @Test
    @DisplayName("TC03: value is Object[] with zero elements, no _backProperty.set calls")
    public void TC03_setAndReturn_withEmptyObjectArray() throws Exception {
        // GIVEN
        Object[] value = new Object[0];
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        when(delegate.setAndReturn(instance, value)).thenReturn("expectedResult");

        SettableBeanProperty _backProperty = mock(SettableBeanProperty.class);

        // Correctly Instantiate ManagedReferenceProperty with required arguments
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", _backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verifyNoInteractions(_backProperty);
        verify(delegate, times(1)).setAndReturn(instance, value);
        assertEquals("expectedResult", result);
    }

    @Test
    @DisplayName("TC04: value is Object[] with one null element, _backProperty.set is not called")
    public void TC04_setAndReturn_withObjectArrayContainingNull() throws Exception {
        // GIVEN
        Object[] value = new Object[]{null};
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        when(delegate.setAndReturn(instance, value)).thenReturn("expectedResult");

        SettableBeanProperty _backProperty = mock(SettableBeanProperty.class);

        // Correctly Instantiate ManagedReferenceProperty with required arguments
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", _backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verifyNoInteractions(_backProperty);
        verify(delegate, times(1)).setAndReturn(instance, value);
        assertEquals("expectedResult", result);
    }

    @Test
    @DisplayName("TC05: value is Object[] with one non-null element, _backProperty.set is called once")
    public void TC05_setAndReturn_withObjectArrayContainingOneNonNull() throws Exception {
        // GIVEN
        Object element = new Object();
        Object[] value = new Object[]{element};
        Object instance = new Object();

        // Mock dependencies
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        when(delegate.setAndReturn(instance, value)).thenReturn("expectedResult");

        SettableBeanProperty _backProperty = mock(SettableBeanProperty.class);

        // Correctly Instantiate ManagedReferenceProperty with required arguments
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", _backProperty, true);

        // WHEN
        Object result = property.setAndReturn(instance, value);

        // THEN
        verify(_backProperty, times(1)).set(element, instance);
        verify(delegate, times(1)).setAndReturn(instance, value);
        assertEquals("expectedResult", result);
    }
}