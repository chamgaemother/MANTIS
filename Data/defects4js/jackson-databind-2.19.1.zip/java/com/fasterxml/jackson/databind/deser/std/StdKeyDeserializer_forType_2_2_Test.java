package com.fasterxml.jackson.databind.deser.std;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer;

public class StdKeyDeserializer_forType_2_2_Test {

    @Test
    @DisplayName("forType(void.class) returns null for unsupported primitive type")
    public void TC29_forType_voidClass_ShouldReturnNull() {
        // Given
        Class<?> raw = void.class;

        // When
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // Then
        assertNull(result, "Expected StdKeyDeserializer.forType(void.class) to return null");
    }

    @Test
    @DisplayName("forType(Object[].class) returns null for unsupported array type")
    public void TC30_forType_ObjectArrayClass_ShouldReturnNull() {
        // Given
        Class<?> raw = Object[].class;

        // When
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // Then
        assertNull(result, "Expected StdKeyDeserializer.forType(Object[].class) to return null");
    }
}