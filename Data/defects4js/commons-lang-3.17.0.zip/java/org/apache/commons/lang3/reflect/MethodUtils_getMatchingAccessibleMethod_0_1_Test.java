package org.apache.commons.lang3.reflect;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.lang3.reflect.MethodUtils;

import java.lang.reflect.Method;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MethodUtils_getMatchingAccessibleMethod_0_1_Test {

    // Helper Classes for Testing

    private static class SampleClass {
        public void sampleMethod(String arg) {
            // Sample method for TC01
        }
    }

    private static class EmptyClass {
        // No methods for TC02
    }

    private static class MultiMethodClass {
        public void overloadedMethod(String arg) {
            // Accessible method for TC03
        }

        private void overloadedMethod(Integer arg) {
            // Non-accessible method
        }

        protected void overloadedMethod(Object arg) {
            // Non-public method
        }
    }

    private static class BestFitClass {
        public void bestFitMethod(Number num) {
            // Less specific method
        }

        public void bestFitMethod(Integer num) {
            // More specific method for best fit
        }
    }

    private static class VarargsClass {
        public void varargsMethod(String arg, Integer... nums) {
            // Varargs method for TC05
        }
    }

    // Test Cases

    @Test
    @DisplayName("Returns the candidate method when getMethodObject finds a non-null method")
    void TC01_ReturnsCandidateMethod_WhenMethodObjectFound() throws Exception {
        // Arrange
        Class<?> cls = SampleClass.class;
        String methodName = "sampleMethod";
        Class<?>[] parameterTypes = {String.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        Assertions.assertNotNull(result, "Method should not be null");
        Assertions.assertEquals("sampleMethod", result.getName(), "Method name should match");
        // Additional reflection checks can be added here if necessary
    }

    @Test
    @DisplayName("Returns null when getMethodObject returns null and no matching methods are found")
    void TC02_ReturnsNull_WhenNoMatchingMethodFound() throws Exception {
        // Arrange
        Class<?> cls = EmptyClass.class;
        String methodName = "nonExistentMethod";
        Class<?>[] parameterTypes = {int.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        Assertions.assertNull(result, "Method should be null when no match is found");
    }

    @Test
    @DisplayName("Returns the single accessible matching method when multiple methods exist")
    void TC03_ReturnsAccessibleMethod_WhenMultipleMethodsExist() throws Exception {
        // Arrange
        Class<?> cls = MultiMethodClass.class;
        String methodName = "overloadedMethod";
        Class<?>[] parameterTypes = {String.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        Assertions.assertNotNull(result, "Accessible method should not be null");
        Assertions.assertEquals("overloadedMethod", result.getName(), "Method name should match");
        Assertions.assertEquals(String.class, result.getParameterTypes()[0], "Parameter type should match");
    }

    @Test
    @DisplayName("Returns the best matching method when multiple accessible methods are present")
    void TC04_ReturnsBestMatchingMethod_WhenMultipleAccessibleMethodsExist() throws Exception {
        // Arrange
        Class<?> cls = BestFitClass.class;
        String methodName = "bestFitMethod";
        Class<?>[] parameterTypes = {Integer.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        Assertions.assertNotNull(result, "Best matching method should not be null");
        Assertions.assertEquals("bestFitMethod", result.getName(), "Method name should match");
        Assertions.assertEquals(Integer.class, result.getParameterTypes()[0], "Parameter type should be Integer.class");
    }

    @Test
    @DisplayName("Handles varargs correctly when bestMatch is varargs and conditions pass")
    void TC05_HandlesVarargsMethod_WhenConditionsAreSatisfied() throws Exception {
        // Arrange
        Class<?> cls = VarargsClass.class;
        String methodName = "varargsMethod";
        Class<?>[] parameterTypes = {String.class, Integer.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        Assertions.assertNotNull(result, "Varargs method should not be null");
        Assertions.assertTrue(result.isVarArgs(), "Method should be a varargs method");
        Assertions.assertEquals("varargsMethod", result.getName(), "Method name should match");
    }
}