package com.fasterxml.jackson.databind.deser.std;

import com.fasterxml.jackson.databind.deser.ValueInstantiator;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.deser.std.MapDeserializer;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.KeyDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;

import java.lang.reflect.Field;
import java.util.Map;

public class MapDeserializer_createContextual_2_1_Test {

    @Test
    @DisplayName("createContextual with non-null _keyDeserializer and non-null _valueDeserializer")
    public void TC13_createContextual_with_all_deserializers_set() throws Exception {
        // Arrange
        JavaType mapType = TypeFactory.defaultInstance().constructMapType(Map.class, Object.class, Object.class);
        ValueInstantiator valueInstantiator = mock(ValueInstantiator.class);
        KeyDeserializer keyDeser = mock(KeyDeserializer.class);
        JsonDeserializer<Object> valueDeser = mock(JsonDeserializer.class);
        TypeDeserializer valueTypeDeser = mock(TypeDeserializer.class);
        
        MapDeserializer deserializer = new MapDeserializer(mapType, valueInstantiator, keyDeser, valueDeser, valueTypeDeser);
        
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);
        
        // Act
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);
        
        // Assert
        assertSame(deserializer, result, "The same deserializer instance should be returned when deserializers are already set.");
    }

    @Test
    @DisplayName("createContextual with null _keyDeserializer, resolving and setting _keyDeserializer")
    public void TC14_createContextual_with_null_keyDeserializer() throws Exception {
        // Arrange
        JavaType mapType = TypeFactory.defaultInstance().constructMapType(Map.class, Object.class, Object.class);
        ValueInstantiator valueInstantiator = mock(ValueInstantiator.class);
        JsonDeserializer<Object> valueDeser = mock(JsonDeserializer.class);
        TypeDeserializer valueTypeDeser = mock(TypeDeserializer.class);
        
        // Initialize with _keyDeserializer as null
        MapDeserializer deserializer = new MapDeserializer(mapType, valueInstantiator, null, valueDeser, valueTypeDeser);
        
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);
        KeyDeserializer resolvedKeyDeser = mock(KeyDeserializer.class);
        
        // Mock the resolution of key deserializer
        when(ctxt.findKeyDeserializer(any(JavaType.class), any(BeanProperty.class))).thenReturn(resolvedKeyDeser);
        
        // Act
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);
        
        // Assert
        assertNotSame(deserializer, result, "A new deserializer instance should be returned when resolving _keyDeserializer.");
        
        // Use reflection to verify that the _keyDeserializer is set to the resolvedKeyDeser
        Field keyDeserField = MapDeserializer.class.getDeclaredField("_keyDeserializer");
        keyDeserField.setAccessible(true);
        KeyDeserializer updatedKeyDeser = (KeyDeserializer) keyDeserField.get(result);
        
        assertNotNull(updatedKeyDeser, "_keyDeserializer should be resolved and set.");
        assertEquals(resolvedKeyDeser, updatedKeyDeser, "_keyDeserializer should be the resolved key deserializer.");
    }

    // Helper methods for mocks
    private static <T> T mock(Class<T> clazz) {
        return Mockito.mock(clazz);
    }

    private static <T> T any(Class<T> clazz) {
        return Mockito.any(clazz);
    }
}
