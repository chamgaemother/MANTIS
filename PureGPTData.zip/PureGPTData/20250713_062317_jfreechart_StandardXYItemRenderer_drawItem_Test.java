import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StandardXYItemRendererTest {

    private StandardXYItemRenderer renderer;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private XYItemRendererState state;
    private PlotRenderingInfo plotRenderingInfo;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new StandardXYItemRenderer(StandardXYItemRenderer.SHAPES_AND_LINES);
        g2 = new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB).createGraphics();
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = createDataset();
        state = new XYItemRendererState(plotRenderingInfo);

        plotRenderingInfo = new PlotRenderingInfo(null);
        crosshairState = new CrosshairState();
        
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
    }

    private XYDataset createDataset() {
        XYSeries series = new XYSeries(1);
        series.add(1.0, 1.0);
        series.add(2.0, 3.0);
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        return dataset;
    }

    @Test
    void testDrawItemValidInputs() {
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, plot.getRangeAxisEdge())).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plotRenderingInfo, plot,
                domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    void testDrawItemInvalidCoordinates() {
        when(domainAxis.valueToJava2D(Double.NaN, dataArea, plot.getDomainAxisEdge())).thenReturn(Double.NaN);
        when(rangeAxis.valueToJava2D(Double.NaN, dataArea, plot.getRangeAxisEdge())).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, plotRenderingInfo, plot,
                domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }

    @Test
    void testDrawItemWithNullDomainAxis() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plotRenderingInfo, plot,
                    null, rangeAxis, dataset, 0, 0, crosshairState, 0);
        });
    }

    @Test
    void testDrawItemWithNullRangeAxis() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plotRenderingInfo, plot,
                    domainAxis, null, dataset, 0, 0, crosshairState, 0);
        });
    }

    @Test
    void testDrawItemWithSeriesPath() {
        renderer.setDrawSeriesLineAsPath(true);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, plot.getRangeAxisEdge())).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plotRenderingInfo, plot,
                domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
    }
}