package org.apache.commons.collections4.map;

import java.lang.reflect.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ConcurrentReferenceHashMap_size_0_2_Test {

    @Test
    @DisplayName("size() returns Integer.MAX_VALUE when total count exceeds Integer.MAX_VALUE")
    public void TC06_sizeExceedsIntegerMAX_VALUE() throws Exception {
        // GIVEN
        // Use the builder to construct the map with default settings
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();

        // Access the 'segments' field via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set each segment's count to Integer.MAX_VALUE to exceed the total count
        long totalCount = 0;
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.setInt(segment, Integer.MAX_VALUE); // Use setInt for primitive int
            totalCount += (long) Integer.MAX_VALUE;
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(Integer.MAX_VALUE, result, "Expected size to be Integer.MAX_VALUE when total count exceeds Integer.MAX_VALUE");
    }

    @Test
    @DisplayName("size() handles zero segments correctly")
    public void TC07_sizeZeroSegments() throws Exception {
        // GIVEN
        // Use the builder to construct the map with a concurrency level of 1 (minimum allowed)
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
            .setConcurrencyLevel(1)
            .build();

        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);

        // Simulate zero segments by setting the segments array to length 0 via reflection
        Object[] emptySegments = (Object[]) Array.newInstance(map.getClass().getDeclaredField("segments").getType().getComponentType(), 0);
        segmentsField.set(map, emptySegments);

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(0, result, "Expected size to be 0 when there are zero segments");
    }

    @Test
    @DisplayName("size() correctly sums counts with multiple segments having zero counts")
    public void TC08_sizeMultipleSegmentsZeroCounts() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();

        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set each segment's count to 0
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.setInt(segment, 0); // Use setInt for primitive int
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(0, result, "Expected size to be 0 when all segments have zero counts");
    }

    @Test
    @DisplayName("size() correctly handles segments with varying counts and consistent modCounts")
    public void TC09_sizeVaryingCountsConsistentModCounts() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();

        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        int expectedSum = 0;
        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            int count = (i + 1) * 10; // Varying counts
            countField.setInt(segment, count); // Use setInt for primitive int
            expectedSum += count;

            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            modCountField.setInt(segment, 0); // Consistent modCount
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(expectedSum, result, "Expected size to be the sum of all segment counts");
    }

    @Test
    @DisplayName("size() handles segments with varying counts and inconsistent modCounts requiring retries")
    public void TC10_sizeVaryingCountsInconsistentModCountsRetriesSucceed() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();

        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        int expectedSum = 0;
        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            int count = (i + 1) * 5; // Varying counts
            countField.setInt(segment, count); // Use setInt for primitive int
            expectedSum += count;

            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            if (i == 0) {
                modCountField.setInt(segment, 1); // Inconsistent modCount on first attempt
            } else {
                modCountField.setInt(segment, 0); // Consistent modCount
            }
        }

        // Simulate the retry by resetting modCounts to consistent values
        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            modCountField.setInt(segment, 0); // Now consistent
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(expectedSum, result, "Expected size to be the sum of all segment counts after handling inconsistent modCounts");
    }
}