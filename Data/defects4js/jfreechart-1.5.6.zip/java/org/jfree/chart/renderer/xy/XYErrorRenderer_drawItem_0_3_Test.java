package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import org.jfree.chart.renderer.xy.XYErrorRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.plot.PlotOrientation;
import static org.mockito.Mockito.*;

public class XYErrorRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem with drawXError=true, drawYError=false, errorPaint null, orientation VERTICAL")
    void TC11_drawItem_with_drawXError_true_drawYError_false_errorPaint_null_orientation_VERTICAL() throws Exception {
        // GIVEN
        int pass = 0;
        XYDataset dataset = mock(IntervalXYDataset.class);
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(true);
        renderer.setDrawYError(false);
        renderer.setErrorPaint(null);
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorStroke(customErrorStroke);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Mock dataset behavior
        when(((IntervalXYDataset) dataset).getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(((IntervalXYDataset) dataset).getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        when(((IntervalXYDataset) dataset).getYValue(anyInt(), anyInt())).thenReturn(3.0);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.BLACK);
        when(renderer.getItemStroke(anyInt(), anyInt())).thenReturn(customErrorStroke);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);

        // THEN
        verify(g2).setPaint(Color.BLACK);
        verify(g2).setStroke(customErrorStroke);
        verify(g2, times(3)).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("drawItem with null dataset should throw NullPointerException")
    void TC12_drawItem_with_null_dataset_should_throw_NullPointerException() {
        // GIVEN
        int pass = 0;
        XYErrorRenderer renderer = new XYErrorRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        XYDataset dataset = null;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("drawItem with orientation not VERTICAL or HORIZONTAL should skip drawing error bars")
    void TC13_drawItem_with_invalid_orientation_should_skip_drawing_error_bars() throws Exception {
        // GIVEN
        int pass = 0;
        XYDataset dataset = mock(IntervalXYDataset.class);
        XYErrorRenderer renderer = new XYErrorRenderer();
        renderer.setDrawXError(true);
        renderer.setDrawYError(false);
        Paint customErrorPaint = mock(Paint.class);
        renderer.setErrorPaint(customErrorPaint);
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorStroke(customErrorStroke);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(null); // Undefined orientation
        Rectangle2D dataArea = mock(Rectangle2D.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Mock dataset behavior
        when(((IntervalXYDataset) dataset).getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(((IntervalXYDataset) dataset).getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        when(((IntervalXYDataset) dataset).getYValue(anyInt(), anyInt())).thenReturn(3.0);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);

        // THEN
        verify(g2, never()).setPaint(any());
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any(Line2D.class));
    }
}