package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CategoryPlot_render_1_1_Test {

    @Test
    @DisplayName("TC01: rendererChanged handles null parent by configuring range axes and notifying listeners")
    void TC01_rendererChanged_handlesNullParent() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        plot.setParent(null); // Ensure parent is null
        RendererChangeEvent event = mock(RendererChangeEvent.class);
        CategoryPlot spyPlot = spy(plot);
        doNothing().when(spyPlot).configureRangeAxes();
        doNothing().when(spyPlot).notifyListeners(any(PlotChangeEvent.class));

        // Act
        spyPlot.rendererChanged(event);

        // Assert
        verify(spyPlot, times(1)).configureRangeAxes();
        verify(spyPlot, times(1)).notifyListeners(any(PlotChangeEvent.class));
    }

    @Test
    @DisplayName("TC02: rendererChanged with null parent and pre-configured range axes")
    void TC02_rendererChanged_withNullParentAndPreConfiguredRangeAxes() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        AxisSpace mockAxisSpace = mock(AxisSpace.class);
        plot.setFixedRangeAxisSpace(mockAxisSpace);
        plot.setParent(null); // Ensure parent is null
        RendererChangeEvent event = mock(RendererChangeEvent.class);
        CategoryPlot spyPlot = spy(plot);
        doNothing().when(spyPlot).configureRangeAxes();
        doNothing().when(spyPlot).notifyListeners(any(PlotChangeEvent.class));

        // Act
        spyPlot.rendererChanged(event);

        // Assert
        verify(spyPlot, times(1)).configureRangeAxes();
        verify(spyPlot, times(1)).notifyListeners(any(PlotChangeEvent.class));
        assertEquals(mockAxisSpace, spyPlot.getFixedRangeAxisSpace());
    }

    @Test
    @DisplayName("TC03: rendererChanged invokes parent.rendererChanged when parent is RendererChangeListener")
    void TC03_rendererChanged_invokesParentRendererChanged() {
        // Arrange
        RendererChangeListener parentListener = mock(RendererChangeListener.class);
        CategoryPlot plot = new CategoryPlot();
        plot.setParent((Plot) parentListener);
        RendererChangeEvent event = mock(RendererChangeEvent.class);

        // Act
        plot.rendererChanged(event);

        // Assert
        verify(parentListener, times(1)).rendererChanged(event);
    }

    @Test
    @DisplayName("TC04: rendererChanged processes multiple events when parent is RendererChangeListener")
    void TC04_rendererChanged_processesMultipleEvents() {
        // Arrange
        RendererChangeListener parentListener = mock(RendererChangeListener.class);
        CategoryPlot plot = new CategoryPlot();
        plot.setParent((Plot) parentListener);
        RendererChangeEvent event1 = mock(RendererChangeEvent.class);
        RendererChangeEvent event2 = mock(RendererChangeEvent.class);

        // Act
        plot.rendererChanged(event1);
        plot.rendererChanged(event2);

        // Assert
        verify(parentListener, times(1)).rendererChanged(event1);
        verify(parentListener, times(1)).rendererChanged(event2);
    }

    @Test
    @DisplayName("TC05: rendererChanged throws RuntimeException when parent does not implement RendererChangeListener")
    void TC05_rendererChanged_throwsRuntimeException() {
        // Arrange
        Plot nonListenerParent = mock(Plot.class);
        CategoryPlot plot = new CategoryPlot();
        plot.setParent(nonListenerParent);
        RendererChangeEvent event = mock(RendererChangeEvent.class);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            plot.rendererChanged(event);
        }, "Expected RuntimeException when parent is not RendererChangeListener");
        assertEquals("The renderer has changed and I don't know what to do!", exception.getMessage());
    }
}