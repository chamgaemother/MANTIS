package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601Utils_parse_0_8_Test {

    @Test
    @DisplayName("Parse throws ParseException when month has non-digit characters")
    void TC36() {
        String date = "2023-1A-05";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("Invalid number"));
    }

    @Test
    @DisplayName("Parse successfully parses date without 'T' but with time and timezone")
    void TC37() throws ParseException {
        String date = "2023-10-05 14:30:00Z";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);
        assertNotNull(result);

        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("Z"));
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.OCTOBER);
        calendar.set(Calendar.DAY_OF_MONTH, 5);
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 30);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        assertEquals(calendar.getTime(), result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse throws ParseException when minutes in timezone are invalid")
    void TC38() {
        String date = "2023-10-05T14:30:00+02:6A";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("Invalid time zone"));
    }

    @Test
    @DisplayName("Parse successfully handles date with exact millis length")
    void TC39() throws ParseException {
        String date = "2023-10-05T14:30:00.123Z";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);
        assertNotNull(result);

        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("Z"));
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.OCTOBER);
        calendar.set(Calendar.DAY_OF_MONTH, 5);
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 30);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 123);

        assertEquals(calendar.getTime(), result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse successfully handles maximum valid input length")
    void TC40() throws ParseException {
        String date = "9999-12-31T23:59:59.999+14:00";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);
        assertNotNull(result);

        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+14:00"));
        calendar.set(Calendar.YEAR, 9999);
        calendar.set(Calendar.MONTH, Calendar.DECEMBER);
        calendar.set(Calendar.DAY_OF_MONTH, 31);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);

        assertEquals(calendar.getTime(), result);
        assertEquals(date.length(), pos.getIndex());
    }
}