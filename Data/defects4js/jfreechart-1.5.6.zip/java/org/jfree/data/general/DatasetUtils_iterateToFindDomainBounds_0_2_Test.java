package org.jfree.data.general;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DatasetUtils_iterateToFindDomainBounds_0_2_Test {

    @Test
    @DisplayName("Returns Range with multiple series when includeInterval is false")
    void TC06_returnsRangeWithMultipleSeriesIncludeIntervalFalse() {
        // GIVEN
        XYDataset dataset = mock(XYDataset.class);
        Comparable seriesKey1 = "Series1";
        Comparable seriesKey2 = "Series2";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey1, seriesKey2);
        when(dataset.indexOf(seriesKey1)).thenReturn(0);
        when(dataset.indexOf(seriesKey2)).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getItemCount(1)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(5.0);
        when(dataset.getXValue(0, 1)).thenReturn(15.0);
        when(dataset.getXValue(1, 0)).thenReturn(10.0);
        when(dataset.getXValue(1, 1)).thenReturn(20.0);
        boolean includeInterval = false;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertEquals(new Range(5.0, 20.0), result);
    }

    @Test
    @DisplayName("Throws ClassCastException when dataset is not IntervalXYDataset but includeInterval is true")
    void TC07_throwsClassCastExceptionWhenDatasetNotIntervalXYDatasetAndIncludeIntervalTrue() {
        // GIVEN
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN & THEN
        assertThrows(ClassCastException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);
        });
    }

    @Test
    @DisplayName("Returns null when includeInterval is true, dataset is IntervalXYDataset, and visibleSeriesKeys is empty")
    void TC08_returnsNullWhenIncludeIntervalTrueDatasetIsIntervalXYDatasetAndVisibleSeriesKeysEmpty() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        List<Comparable> visibleSeriesKeys = Collections.emptyList();
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("Returns Range when includeInterval is true and IntervalXYDataset has valid x, l, u values")
    void TC09_returnsRangeWhenIncludeIntervalTrueAndIntervalXYDatasetHasValidValues() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Comparable seriesKey = "Series1";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey);
        when(dataset.indexOf(seriesKey)).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(8.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(12.0);
        when(dataset.getXValue(0, 1)).thenReturn(20.0);
        when(dataset.getStartXValue(0, 1)).thenReturn(18.0);
        when(dataset.getEndXValue(0, 1)).thenReturn(22.0);
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertEquals(new Range(8.0, 22.0), result);
    }

    @Test
    @DisplayName("Handles NaN x, l, u values when includeInterval is true")
    void TC10_handlesNaNValuesWhenIncludeIntervalTrue() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Comparable seriesKey = "Series1";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey);
        when(dataset.indexOf(seriesKey)).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getStartXValue(0, 0)).thenReturn(8.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(20.0);
        when(dataset.getStartXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getEndXValue(0, 1)).thenReturn(22.0);
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertEquals(new Range(8.0, 22.0), result);
    }
}