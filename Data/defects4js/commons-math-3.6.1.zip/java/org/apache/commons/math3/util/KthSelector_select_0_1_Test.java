package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

public class KthSelector_select_0_1_Test {

    @Test
    @DisplayName("select method with r1 as null and $i11 > 15, triggering Arrays.sort")
    void testTC01() {
        // GIVEN
        double[] work = {23.5, 12.1, 45.3, 7.8, 19.6, 34.2, 28.4, 5.5, 16.7, 39.0, 22.2, 11.1, 8.8, 14.4, 30.3, 27.7};
        int[] r1 = null;
        int k = 5;
        
        // Expected Result after sorting the entire array
        double[] sortedWork = Arrays.copyOf(work, work.length);
        Arrays.sort(sortedWork);
        double expected = sortedWork[k];
        
        // WHEN
        KthSelector selector = new KthSelector(); // Fixed: Creating an instance of KthSelector
        double result = selector.select(work, r1, k);
        
        // THEN
        assertEquals(expected, result, "The selected element should match the expected value after sort.");
    }

    @Test
    @DisplayName("select method with r1 as non-null and $i11 <= 15, z0 is false")
    void testTC02() {
        // GIVEN
        double[] work = {9.5, 3.2, 14.7, 1.1, 6.6, 8.8, 2.2, 5.5, 4.4, 7.7, 10.0, 12.1, 11.1, 13.3, 15.5};
        int[] r1 = {2, 5, 8};
        int k = 4;
        
        // Expected Result after one partitioning
        // For simplicity, assume partition returns pivot index 5 and work[k] is 8.8
        double expected = 8.8;
        
        // WHEN
        KthSelector selector = new KthSelector(); // Fixed: Creating an instance of KthSelector
        double result = selector.select(work, r1, k);
        
        // THEN
        assertEquals(expected, result, "The selected element should match the expected value after partition.");
    }

    @Test
    @DisplayName("select method with r1 as non-null, $i11 <= 15, z0 is false, i10 >= $i6")
    void testTC03() {
        // GIVEN
        double[] work = {20.5, 18.2, 25.7, 22.1, 19.6, 23.8, 21.4, 17.5, 24.4, 26.7, 28.0, 30.1, 27.1, 29.3, 31.5};
        int[] r1 = {-1, 3, 5};
        int k = 7;
        
        // Expected Result after handling negative pivot index
        double[] sortedWork = Arrays.copyOf(work, work.length);
        Arrays.sort(sortedWork);
        double expected = sortedWork[k];
        
        // WHEN
        KthSelector selector = new KthSelector(); // Fixed: Creating an instance of KthSelector
        double result = selector.select(work, r1, k);
        
        // THEN
        assertEquals(expected, result, "The selected element should match the expected value after handling negative pivot index.");
    }

    @Test
    @DisplayName("select method with r1 as non-null, $i11 <= 15, z0 is false, i10 < $i6")
    void testTC04() {
        // GIVEN
        double[] work = {5.5, 3.3, 6.6, 2.2, 4.4, 1.1, 7.7, 8.8, 9.9, 10.0, 11.1, 12.2, 13.3, 14.4, 15.5};
        int[] r1 = {1, 4, 7};
        int k = 3;
        
        // Expected Result after updating begin index
        double[] sortedWork = Arrays.copyOf(work, work.length);
        Arrays.sort(sortedWork);
        double expected = sortedWork[k];
        
        // WHEN
        KthSelector selector = new KthSelector(); // Fixed: Creating an instance of KthSelector
        double result = selector.select(work, r1, k);
        
        // THEN
        assertEquals(expected, result, "The selected element should match the expected value after updating begin index.");
    }

    @Test
    @DisplayName("select method with r1 as non-null, $i11 <= 15, z0 is true")
    void testTC05() {
        // GIVEN
        double[] work = {16.5, 14.2, 19.7, 13.1, 18.6, 20.8, 17.4, 15.5, 21.4, 22.7, 23.0, 24.1, 25.3, 26.4, 27.5};
        int[] r1 = {0, 2, 4};
        int k = 10;
        
        // Expected Result using pivot from pivotsHeap
        double[] sortedWork = Arrays.copyOf(work, work.length);
        Arrays.sort(sortedWork);
        double expected = sortedWork[k];
        
        // WHEN
        KthSelector selector = new KthSelector(); // Fixed: Creating an instance of KthSelector
        double result = selector.select(work, r1, k);
        
        // THEN
        assertEquals(expected, result, "The selected element should match the expected value using pivot from pivotsHeap.");
    }
}
