package org.apache.commons.compress.archivers.zip;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class ZipArchiveInputStreamTest {

    @Test
    void testGetNextZipEntry_EmptyArchive() throws IOException {
        byte[] emptyZip = createEmptyZip();
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(emptyZip))) {
            assertNull(zis.getNextZipEntry());
        }
    }

    @Test
    void testGetNextZipEntry_SingleStoredEntryWithoutDataDescriptor() throws IOException {
        byte[] zip = createSingleStoredEntry(false);
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zip))) {
            ZipArchiveEntry entry = zis.getNextZipEntry();
            assertNotNull(entry);
            assertEquals("test.txt", entry.getName());
            assertEquals(ZipArchiveOutputStream.STORED, entry.getMethod());
            assertEquals(11, entry.getSize());
            assertNull(zis.getNextZipEntry());
        }
    }

    @Test
    void testGetNextZipEntry_SingleStoredEntryWithDataDescriptor() throws IOException {
        byte[] zip = createSingleStoredEntry(true);
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zip), "UTF-8", true, true)) {
            ZipArchiveEntry entry = zis.getNextZipEntry();
            assertNotNull(entry);
            assertEquals("test.txt", entry.getName());
            assertEquals(ZipArchiveOutputStream.STORED, entry.getMethod());
            assertEquals(11, entry.getSize());
            assertNull(zis.getNextZipEntry());
        }
    }

    @Test
    void testGetNextZipEntry_SingleDeflatedEntryWithoutDataDescriptor() throws IOException {
        byte[] zip = createSingleDeflatedEntry(false);
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zip))) {
            ZipArchiveEntry entry = zis.getNextZipEntry();
            assertNotNull(entry);
            assertEquals("deflated.txt", entry.getName());
            assertEquals(ZipArchiveOutputStream.DEFLATED, entry.getMethod());
            assertEquals(11, entry.getSize());
            assertNull(zis.getNextZipEntry());
        }
    }

    @Test
    void testGetNextZipEntry_SingleDeflatedEntryWithDataDescriptor() throws IOException {
        byte[] zip = createSingleDeflatedEntry(true);
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zip), "UTF-8", true, true)) {
            ZipArchiveEntry entry = zis.getNextZipEntry();
            assertNotNull(entry);
            assertEquals("deflated.txt", entry.getName());
            assertEquals(ZipArchiveOutputStream.DEFLATED, entry.getMethod());
            assertEquals(11, entry.getSize());
            assertNull(zis.getNextZipEntry());
        }
    }

    @Test
    void testGetNextZipEntry_MultipleEntries() throws IOException {
        byte[] zip = createMultipleEntries();
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(zip))) {
            ZipArchiveEntry entry1 = zis.getNextZipEntry();
            assertNotNull(entry1);
            assertEquals("file1.txt", entry1.getName());

            ZipArchiveEntry entry2 = zis.getNextZipEntry();
            assertNotNull(entry2);
            assertEquals("file2.txt", entry2.getName());

            assertNull(zis.getNextZipEntry());
        }
    }

    @Test
    void testGetNextZipEntry_InvalidSignature() {
        byte[] invalidZip = {0x00, 0x01, 0x02, 0x03};
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(invalidZip))) {
            Executable executable = zis::getNextZipEntry;
            ZipException exception = assertThrows(ZipException.class, executable);
            assertTrue(exception.getMessage().contains("Unexpected record signature"));
        } catch (IOException e) {
            fail("IOException should not be thrown");
        }
    }

    @Test
    void testGetNextZipEntry_CorruptedZip64ExtraField() {
        byte[] corruptedZip = createCorruptedZip64ExtraField();
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(corruptedZip))) {
            Executable executable = zis::getNextZipEntry;
            ZipException exception = assertThrows(ZipException.class, executable);
            assertTrue(exception.getMessage().contains("archive contains corrupted zip64 extra field"));
        } catch (IOException e) {
            fail("IOException should not be thrown");
        }
    }

    @Test
    void testGetNextZipEntry_ApkSigningBlock() throws IOException {
        byte[] apkSigningBlockZip = createApkSigningBlockZip();
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(apkSigningBlockZip))) {
            ZipArchiveEntry entry = zis.getNextZipEntry();
            assertNull(entry);
        }
    }

    @Test
    void testGetNextZipEntry_SplitZipArchive() {
        byte[] splitZip = createSplitZip();
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(splitZip), "UTF-8", true, true, false)) {
            Executable executable = zis::getNextZipEntry;
            UnsupportedZipFeatureException exception = assertThrows(UnsupportedZipFeatureException.class, executable);
            assertEquals(UnsupportedZipFeatureException.Feature.SPLITTING, exception.getFeature());
        } catch (IOException e) {
            fail("IOException should not be thrown");
        }
    }

    @Test
    void testGetNextZipEntry_UnsupportedCompressionMethod() {
        byte[] unsupportedZip = createUnsupportedCompressionMethodZip();
        try (ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(unsupportedZip))) {
            Executable executable = zis::getNextZipEntry;
            ZipException exception = assertThrows(ZipException.class, executable);
            assertTrue(exception.getMessage().contains("Unexpected record signature"));
        } catch (IOException e) {
            fail("IOException should not be thrown");
        }
    }

    // Helper methods to create various ZIP byte arrays

    private byte[] createEmptyZip() throws IOException {
        return new byte[] {
            // EOCD signature
            0x50, 0x4b, 0x05, 0x06,
            // Number of this disk
            0x00, 0x00,
            // Number of the disk with the start of the central directory
            0x00, 0x00,
            // Total number of entries in the central directory on this disk
            0x00, 0x00,
            // Total number of entries in the central directory
            0x00, 0x00,
            // Size of the central directory
            0x00, 0x00, 0x00, 0x00,
            // Offset of start of central directory
            0x00, 0x00, 0x00, 0x00,
            // .ZIP file comment length
            0x00, 0x00
        };
    }

    private byte[] createSingleStoredEntry(boolean withDataDescriptor) throws IOException {
        byte[] fileName = "test.txt".getBytes(StandardCharsets.UTF_8);
        byte[] fileData = "Hello World".getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // Local File Header
        baos.write(new byte[] {0x50, 0x4b, 0x03, 0x04}); // LFH signature
        baos.write(shortToBytes((short) 20)); // version needed
        baos.write(shortToBytes((short) 0x0800)); // general purpose bit flag (data descriptor if needed)
        baos.write(shortToBytes((short) ZipArchiveOutputStream.STORED)); // compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes((int) fileData.length)); // compressed size
        baos.write(intToBytes((int) fileData.length)); // uncompressed size
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 0)); // extra field length
        baos.write(fileName); // file name

        // File data
        baos.write(fileData);

        if (withDataDescriptor) {
            // Data Descriptor
            baos.write(new byte[] {0x50, 0x4b, 0x07, 0x08}); // DD signature
            baos.write(intToBytes(0)); // CRC-32
            baos.write(intToBytes(fileData.length)); // compressed size
            baos.write(intToBytes(fileData.length)); // uncompressed size
        }

        // Central Directory
        baos.write(new byte[] {0x50, 0x4b, 0x01, 0x02}); // CFH signature
        baos.write(shortToBytes((short) 20)); // version made by
        baos.write(shortToBytes((short) 20)); // version needed
        baos.write(shortToBytes((short) 0x0800)); // general purpose bit flag
        baos.write(shortToBytes((short) ZipArchiveOutputStream.STORED)); // compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes((int) fileData.length)); // compressed size
        baos.write(intToBytes((int) fileData.length)); // uncompressed size
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 0)); // extra field length
        baos.write(shortToBytes((short) 0)); // file comment length
        baos.write(shortToBytes((short) 0)); // disk number start
        baos.write(shortToBytes((short) 0)); // internal file attributes
        baos.write(intToBytes(0)); // external file attributes
        baos.write(intToBytes(0)); // relative offset of local header
        baos.write(fileName); // file name

        // End of Central Directory
        baos.write(new byte[] {0x50, 0x4b, 0x05, 0x06}); // EOCD signature
        baos.write(shortToBytes((short) 0)); // number of this disk
        baos.write(shortToBytes((short) 0)); // number of the disk with the start of the central directory
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory on this disk
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory
        baos.write(intToBytes((int) (fileData.length + 30))); // size of the central directory
        baos.write(intToBytes((int) (fileData.length + 30))); // offset of start of central directory
        baos.write(shortToBytes((short) 0)); // .ZIP file comment length

        return baos.toByteArray();
    }

    private byte[] createSingleDeflatedEntry(boolean withDataDescriptor) throws IOException {
        byte[] fileName = "deflated.txt".getBytes(StandardCharsets.UTF_8);
        byte[] fileData = "Hello World".getBytes(StandardCharsets.UTF_8);
        // Simple deflate compression (zlib header + deflate data + adler32)
        byte[] deflatedData = new byte[] { 
            0x78, (byte) 0x9c, // zlib header
            0x4b, 0xcb, 0xcf, 0x07, 0x00, 0x02, 0x82, 0x01, // deflate data
            0x45, 0x87, (byte) 0xe1, 0x0c // Adler-32
        };
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // Local File Header
        baos.write(new byte[] {0x50, 0x4b, 0x03, 0x04}); // LFH signature
        baos.write(shortToBytes((short) 20)); // version needed
        baos.write(shortToBytes((short) 0x0808)); // general purpose bit flag (deflated, data descriptor)
        baos.write(shortToBytes((short) ZipArchiveOutputStream.DEFLATED)); // compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes(0)); // compressed size
        baos.write(intToBytes(0)); // uncompressed size
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 0)); // extra field length
        baos.write(fileName); // file name

        // File data
        baos.write(deflatedData);

        if (withDataDescriptor) {
            // Data Descriptor
            baos.write(new byte[] {0x50, 0x4b, 0x07, 0x08}); // DD signature
            baos.write(intToBytes(0)); // CRC-32
            baos.write(intToBytes(deflatedData.length)); // compressed size
            baos.write(intToBytes(fileData.length)); // uncompressed size
        }

        // Central Directory
        baos.write(new byte[] {0x50, 0x4b, 0x01, 0x02}); // CFH signature
        baos.write(shortToBytes((short) 20)); // version made by
        baos.write(shortToBytes((short) 20)); // version needed
        baos.write(shortToBytes((short) 0x0808)); // general purpose bit flag
        baos.write(shortToBytes((short) ZipArchiveOutputStream.DEFLATED)); // compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes(deflatedData.length)); // compressed size
        baos.write(intToBytes(fileData.length)); // uncompressed size
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 0)); // extra field length
        baos.write(shortToBytes((short) 0)); // file comment length
        baos.write(shortToBytes((short) 0)); // disk number start
        baos.write(shortToBytes((short) 0)); // internal file attributes
        baos.write(intToBytes(0)); // external file attributes
        baos.write(intToBytes(0)); // relative offset of local header
        baos.write(fileName); // file name

        // End of Central Directory
        baos.write(new byte[] {0x50, 0x4b, 0x05, 0x06}); // EOCD signature
        baos.write(shortToBytes((short) 0)); // number of this disk
        baos.write(shortToBytes((short) 0)); // number of the disk with the start of the central directory
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory on this disk
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory
        baos.write(intToBytes((int) (deflatedData.length + 30))); // size of the central directory
        baos.write(intToBytes((int) (deflatedData.length + 30))); // offset of start of central directory
        baos.write(shortToBytes((short) 0)); // .ZIP file comment length

        return baos.toByteArray();
    }

    private byte[] createMultipleEntries() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos.write(createSingleStoredEntry(false));
        baos.write(createSingleDeflatedEntry(false));
        return baos.toByteArray();
    }

    private byte[] createCorruptedZip64ExtraField() throws IOException {
        byte[] fileName = "zip64.txt".getBytes(StandardCharsets.UTF_8);
        byte[] fileData = "Zip64 data".getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // Local File Header with Zip64 extra field
        baos.write(new byte[] {0x50, 0x4b, 0x03, 0x04}); // LFH signature
        baos.write(shortToBytes((short) 45)); // version needed
        baos.write(shortToBytes((short) 0x0008)); // general purpose bit flag
        baos.write(shortToBytes((short) ZipArchiveOutputStream.STORED)); // compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes(0xFFFFFFFF)); // compressed size (Zip64)
        baos.write(intToBytes(0xFFFFFFFF)); // uncompressed size (Zip64)
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 20)); // extra field length
        baos.write(fileName); // file name

        // Corrupted Zip64 Extra Field
        baos.write(new byte[] {0x62, 0x75, 0x7A, 0x39, 0x32, 0x00, 0x00, 0x00}); // Invalid data

        // File data
        baos.write(fileData);

        // Central Directory with corrupted Zip64 extra field
        baos.write(new byte[] {0x50, 0x4b, 0x01, 0x02}); // CFH signature
        baos.write(shortToBytes((short) 45)); // version made by
        baos.write(shortToBytes((short) 45)); // version needed
        baos.write(shortToBytes((short) 0x0008)); // general purpose bit flag
        baos.write(shortToBytes((short) ZipArchiveOutputStream.STORED)); // compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes(0xFFFFFFFF)); // compressed size
        baos.write(intToBytes(0xFFFFFFFF)); // uncompressed size
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 20)); // extra field length
        baos.write(shortToBytes((short) 0)); // file comment length
        baos.write(shortToBytes((short) 0)); // disk number start
        baos.write(shortToBytes((short) 0)); // internal file attributes
        baos.write(intToBytes(0)); // external file attributes
        baos.write(intToBytes(0)); // relative offset of local header
        baos.write(fileName); // file name

        // Corrupted Zip64 Extra Field in Central Directory
        baos.write(new byte[] {0x62, 0x75, 0x7A, 0x39, 0x32, 0x00, 0x00, 0x00}); // Invalid data

        // End of Central Directory
        baos.write(new byte[] {0x50, 0x4b, 0x05, 0x06}); // EOCD signature
        baos.write(shortToBytes((short) 0)); // number of this disk
        baos.write(shortToBytes((short) 0)); // number of the disk with the start of the central directory
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory on this disk
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory
        baos.write(intToBytes((int) (fileData.length + 30))); // size of the central directory
        baos.write(intToBytes((int) (fileData.length + 30))); // offset of start of central directory
        baos.write(shortToBytes((short) 0)); // .ZIP file comment length

        return baos.toByteArray();
    }

    private byte[] createApkSigningBlockZip() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] magic = "APK Sig Block 42".getBytes(StandardCharsets.UTF_8);
        baos.write(magic);
        // No actual ZIP data
        return baos.toByteArray();
    }

    private byte[] createSplitZip() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // Split ZIP signature
        baos.write(new byte[] {0x50, 0x4b, 0x07, 0x08});
        // Rest of the data is irrelevant for this test
        baos.write(new byte[] {0x00, 0x01, 0x02, 0x03});
        return baos.toByteArray();
    }

    private byte[] createUnsupportedCompressionMethodZip() throws IOException {
        byte[] fileName = "unsupported.txt".getBytes(StandardCharsets.UTF_8);
        byte[] fileData = "Unsupported Method".getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // Local File Header with unsupported compression method (e.g., 99)
        baos.write(new byte[] {0x50, 0x4b, 0x03, 0x04}); // LFH signature
        baos.write(shortToBytes((short) 20)); // version needed
        baos.write(shortToBytes((short) 0x0000)); // general purpose bit flag
        baos.write(shortToBytes((short) 99)); // unsupported compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes(fileData.length)); // compressed size
        baos.write(intToBytes(fileData.length)); // uncompressed size
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 0)); // extra field length
        baos.write(fileName); // file name

        // File data
        baos.write(fileData);

        // Central Directory
        baos.write(new byte[] {0x50, 0x4b, 0x01, 0x02}); // CFH signature
        baos.write(shortToBytes((short) 20)); // version made by
        baos.write(shortToBytes((short) 20)); // version needed
        baos.write(shortToBytes((short) 0x0000)); // general purpose bit flag
        baos.write(shortToBytes((short) 99)); // unsupported compression method
        baos.write(intToBytes((int) (System.currentTimeMillis() / 1000))); // last mod time
        baos.write(intToBytes(0)); // CRC-32
        baos.write(intToBytes(fileData.length)); // compressed size
        baos.write(intToBytes(fileData.length)); // uncompressed size
        baos.write(shortToBytes((short) fileName.length)); // file name length
        baos.write(shortToBytes((short) 0)); // extra field length
        baos.write(shortToBytes((short) 0)); // file comment length
        baos.write(shortToBytes((short) 0)); // disk number start
        baos.write(shortToBytes((short) 0)); // internal file attributes
        baos.write(intToBytes(0)); // external file attributes
        baos.write(intToBytes(0)); // relative offset of local header
        baos.write(fileName); // file name

        // End of Central Directory
        baos.write(new byte[] {0x50, 0x4b, 0x05, 0x06}); // EOCD signature
        baos.write(shortToBytes((short) 0)); // number of this disk
        baos.write(shortToBytes((short) 0)); // number of the disk with the start of the central directory
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory on this disk
        baos.write(shortToBytes((short) 1)); // total number of entries in the central directory
        baos.write(intToBytes((int) (fileData.length + 30))); // size of the central directory
        baos.write(intToBytes((int) (fileData.length + 30))); // offset of start of central directory
        baos.write(shortToBytes((short) 0)); // .ZIP file comment length

        return baos.toByteArray();
    }

    private byte[] shortToBytes(short value) {
        return new byte[] { 
            (byte) (value & 0xff),
            (byte) ((value >> 8) & 0xff)
        };
    }

    private byte[] intToBytes(int value) {
        return new byte[] { 
            (byte) (value & 0xff),
            (byte) ((value >> 8) & 0xff),
            (byte) ((value >> 16) & 0xff),
            (byte) ((value >> 24) & 0xff)
        };
    }
}