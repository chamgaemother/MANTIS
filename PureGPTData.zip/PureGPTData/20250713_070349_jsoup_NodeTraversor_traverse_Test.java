import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;
import org.jsoup.nodes.Document;
import org.jsoup.select.NodeTraversor;
import org.jsoup.select.NodeVisitor;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class NodeTraversorTest {

    @Test
    public void testTraverseWithNullVisitor() {
        Element root = new Element("div");
        assertThrows(IllegalArgumentException.class, () -> {
            NodeTraversor.traverse(null, root);
        });
    }

    @Test
    public void testTraverseWithNullRoot() {
        NodeVisitor visitor = new NodeVisitor() {
            public void head(Node node, int depth) {
            }

            public void tail(Node node, int depth) {
            }
        };
        assertThrows(IllegalArgumentException.class, () -> {
            NodeTraversor.traverse(visitor, null);
        });
    }

    @Test
    public void testTraverseSimpleNode() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        Element child1 = root.appendElement("child1");
        NodeVisitor visitor = new NodeVisitor() {
            public void head(Node node, int depth) {
            }

            public void tail(Node node, int depth) {
            }
        };
        NodeTraversor.traverse(visitor, root);
        // This will cover branches where a node has children and descends into them
    }

    @Test
    public void testTraverseNodeWithSiblings() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        Element child1 = root.appendElement("child1");
        Element child2 = root.appendElement("child2");
        NodeVisitor visitor = new NodeVisitor() {
            public void head(Node node, int depth) {
            }

            public void tail(Node node, int depth) {
            }
        };
        NodeTraversor.traverse(visitor, root);
        // This will cover branches where a node has siblings
    }

    @Test
    public void testTraverseRemovedNode() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        Element child1 = root.appendElement("child1");
        NodeVisitor visitor = new NodeVisitor() {
            public void head(Node node, int depth) {
                if (node.nodeName().equals("child1")) {
                    node.remove();
                }
            }

            public void tail(Node node, int depth) {
            }
        };
        NodeTraversor.traverse(visitor, root);
        // This will cover branches where a node is removed during traversal
    }

    @Test
    public void testTraverseReplacedNode() {
        Document doc = new Document("");
        Element root = doc.appendElement("root");
        Element child1 = root.appendElement("child1");
        Element child2 = new Element("child2");
        NodeVisitor visitor = new NodeVisitor() {
            public void head(Node node, int depth) {
                if (node.nodeName().equals("child1")) {
                    node.replaceWith(child2);
                }
            }

            public void tail(Node node, int depth) {
            }
        };
        NodeTraversor.traverse(visitor, root);
        // This will cover branches where a node is replaced during traversal
    }
}