package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StringUtils_indexOfDifference_0_2_Test {

    @Test
    @DisplayName("All strings same and lengths equal returns INDEX_NOT_FOUND")
    public void TC06_AllStringsSame_ReturnsIndexNotFound() {
        // GIVEN
        CharSequence[] css = {"test", "test", "test"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(StringUtils.INDEX_NOT_FOUND, result);
    }

    @Test
    @DisplayName("Strings differ at first character")
    public void TC07_StringsDifferAtFirstCharacter() {
        // GIVEN
        CharSequence[] css = {"apple", "banana", "apricot"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("Strings differ at middle character")
    public void TC08_StringsDifferAtMiddleCharacter() {
        // GIVEN
        CharSequence[] css = {"testing", "tesping", "testling"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(3, result);
    }

    @Test
    @DisplayName("Strings differ due to different lengths but identical prefixes")
    public void TC09_StringsDifferDueToDifferentLengthsIdenticalPrefixes() {
        // GIVEN
        CharSequence[] css = {"test", "testing", "testable"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(4, result);
    }

    @Test
    @DisplayName("Strings identical up to the shortest length and different in lengths")
    public void TC10_StringsIdenticalUpToShortestLength_DifferentLengths() {
        // GIVEN
        CharSequence[] css = {"hello", "hell", "hello world"};

        // WHEN
        int result = StringUtils.indexOfDifference(css);

        // THEN
        assertEquals(4, result);
    }
}