package com.fasterxml.jackson.databind.ser.std;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.type.TypeFactory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MapSerializer_serializeFilteredFields_1_1_Test {

    @Test
    @DisplayName("serializeFilteredFields with checkEmpty=true, valueSer.isEmpty=false, and suppressableValue does not equal valueElem")
    public void TC15() throws Exception {
        // Arrange
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");

        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = MapSerializer.MARKER_FOR_EMPTY;

        @SuppressWarnings("unchecked")
        JsonSerializer<Object> keySerializer = (JsonSerializer<Object>) mock(JsonSerializer.class);
        @SuppressWarnings("unchecked")
        JsonSerializer<Object> valueSerializer = (JsonSerializer<Object>) mock(JsonSerializer.class);

        when(valueSerializer.isEmpty(provider, "value1")).thenReturn(false);

        // Construct MapSerializer
        MapSerializer mapSerializer = MapSerializer.construct(
            null, // ignoredEntries
            null, // includedEntries
            TypeFactory.defaultInstance().constructMapType(Map.class, Object.class, Object.class), // mapType
            true, // staticValueType
            null, // vts
            keySerializer,
            valueSerializer,
            null // filterId
        );

        // Set private fields
        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, false);

        Field inclusionCheckerField = MapSerializer.class.getDeclaredField("_inclusionChecker");
        inclusionCheckerField.setAccessible(true);
        inclusionCheckerField.set(mapSerializer, null);

        // Act
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // Assert
        verify(filter).serializeAsField(eq(value), eq(gen), eq(provider), any());
    }

//     @Test
//     @DisplayName("serializeFilteredFields with non-null _filterId and active PropertyFilter")
//     public void TC16() throws Exception {
        // Arrange
//         Map<Object, Object> value = new HashMap<>();
//         value.put("key1", "value1");
// 
//         JsonGenerator gen = mock(JsonGenerator.class);
//         SerializerProvider provider = mock(SerializerProvider.class);
//         PropertyFilter filter = mock(PropertyFilter.class);
//         Object suppressableValue = null;
//         Object filterId = "activeFilterId";
// 
//         @SuppressWarnings("unchecked")
//         JsonSerializer<Object> keySerializer = (JsonSerializer<Object>) mock(JsonSerializer.class);
//         @SuppressWarnings("unchecked")
//         JsonSerializer<Object> valueSerializer = (JsonSerializer<Object>) mock(JsonSerializer.class);
// 
        // Configure provider to return filter when findPropertyFilter is called
//         when(provider.findPropertyFilter(eq(filterId), any())).thenReturn(filter);
// 
        // Construct MapSerializer with filterId
//         MapSerializer mapSerializer = MapSerializer.construct(
//             null, // ignoredEntries
//             null, // includedEntries
//             TypeFactory.defaultInstance().constructMapType(Map.class, Object.class, Object.class), // mapType
//             false, // staticValueType
//             null, // vts
//             keySerializer,
//             valueSerializer,
//             filterId
//         );
// 
        // Set private fields
//         Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
//         suppressNullsField.setAccessible(true);
//         suppressNullsField.set(mapSerializer, false);
// 
//         Field inclusionCheckerField = MapSerializer.class.getDeclaredField("_inclusionChecker");
//         inclusionCheckerField.setAccessible(true);
//         inclusionCheckerField.set(mapSerializer, null);
// 
        // Act
//         mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);
// 
        // Assert
//         verify(filter).serializeAsField(eq(value), eq(gen), eq(provider), any());
//     }

}