package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.io.ByteArrayInputStream;
import java.io.CharConversionException;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class UTF32ReaderTest {

    private IOContext ioContext;

    @BeforeEach
    void setUp() {
        ioContext = new IOContext(null, null, false);
    }

    @Test
    void testRead_BufferNull_ReturnsMinusOne() throws IOException {
        UTF32Reader reader = new UTF32Reader(ioContext, null, null, 0, 0, true);
        char[] buffer = new char[10];
        int result = reader.read(buffer, 0, 10);
        assertEquals(-1, result);
    }

    @Test
    void testRead_LengthZero_ReturnsZero() throws IOException {
        byte[] bytes = {};
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 0, true);
        char[] buffer = new char[10];
        int result = reader.read(buffer, 0, 0);
        assertEquals(0, result);
    }

    @Test
    void testRead_LengthNegative_ReturnsNegative() throws IOException {
        byte[] bytes = {};
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 0, true);
        char[] buffer = new char[10];
        int result = reader.read(buffer, 0, -5);
        assertEquals(-5, result);
    }

    @Test
    void testRead_StartNegative_ThrowsException() {
        byte[] bytes = {};
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 0, true);
        char[] buffer = new char[10];
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> reader.read(buffer, -1, 5));
    }

    @Test
    void testRead_StartPlusLenExceedsBuffer_ThrowsException() {
        byte[] bytes = {};
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 0, true);
        char[] buffer = new char[10];
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> reader.read(buffer, 8, 5));
    }

    @Test
    void testRead_WithSurrogate_ReturnsSurrogate() throws IOException {
        byte[] bytes = {};
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 0, true);
        reader._surrogate = '\uD800';
        char[] buffer = new char[2];
        int result = reader.read(buffer, 0, 2);
        assertEquals(1, result);
        assertEquals('\uD800', buffer[0]);
        assertEquals('\0', reader._surrogate);
    }

    @Test
    void testRead_EnoughBytes_NoSurrogate() throws IOException {
        byte[] bytes = {0x00, 0x00, 0x00, 0x41}; // 'A' in UTF-32BE
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 4, true);
        char[] buffer = new char[2];
        int result = reader.read(buffer, 0, 2);
        assertEquals(1, result);
        assertEquals('A', buffer[0]);
    }

    @Test
    void testRead_LeftLessThan4_LoadMoreTrue() throws IOException {
        byte[] initial = {0x00, 0x00, 0x00};
        byte[] additional = {0x41}; // 'A' needs one more byte to make 4
        ByteArrayInputStream in = new ByteArrayInputStream(initial) {
            private boolean firstRead = true;

            @Override
            public int read(byte[] b, int off, int len) {
                if (firstRead) {
                    firstRead = false;
                    return 1;
                } else {
                    System.arraycopy(additional, 0, b, off, additional.length);
                    return additional.length;
                }
            }
        };
        byte[] buffer = new byte[4];
        System.arraycopy(initial, 0, buffer, 0, 3);
        UTF32Reader reader = new UTF32Reader(ioContext, in, buffer, 3, 3, true);
        char[] cbuf = new char[2];
        assertThrows(CharConversionException.class, () -> reader.read(cbuf, 0, 2));
    }

    @Test
    void testRead_LeftLessThan4_LoadMoreFalse_LeftZero_ReturnsMinusOne() throws IOException {
        byte[] bytes = {};
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), new byte[4], 4, 4, true);
        char[] buffer = new char[2];
        int result = reader.read(buffer, 0, 2);
        assertEquals(-1, result);
    }

    @Test
    void testRead_LeftLessThan4_LoadMoreFalse_LeftGreaterZero_ThrowsException() throws IOException {
        byte[] initial = {0x00, 0x00, 0x00};
        ByteArrayInputStream in = new ByteArrayInputStream(initial);
        byte[] buffer = new byte[4];
        System.arraycopy(initial, 0, buffer, 0, 3);
        UTF32Reader reader = new UTF32Reader(ioContext, in, buffer, 3, 3, true);
        char[] cbuf = new char[2];
        CharConversionException exception = assertThrows(CharConversionException.class, () -> reader.read(cbuf, 0, 2));
        assertTrue(exception.getMessage().contains("Unexpected EOF"));
    }

    @Test
    void testRead_InvalidUTF32Character_ThrowsException() throws IOException {
        // Invalid surrogate pair
        byte[] bytes = {0x00, 0x11, 0x00, 0x00}; // Above 0x10FFFF
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 4, true);
        char[] buffer = new char[2];
        CharConversionException exception = assertThrows(CharConversionException.class, () -> reader.read(buffer, 0, 2));
        assertTrue(exception.getMessage().contains("Invalid UTF-32 character"));
    }

    @Test
    void testRead_WithSurrogatePair() throws IOException {
        // U+1D11E (Musical Symbol G Clef)
        int codePoint = 0x1D11E;
        byte[] bytes = {
                0x00, 0x01, (byte) 0xD8, 0x1E
        };
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 4, true);
        char[] buffer = new char[2];
        int result = reader.read(buffer, 0, 2);
        // Should split into surrogate pair
        assertEquals(2, result);
        assertEquals('\uD834', buffer[0]);
        assertEquals('\uDD1E', buffer[1]);
    }

    @Test
    void testRead_ReportStrangeStream_ThrowsException() throws IOException {
        ByteArrayInputStream in = new ByteArrayInputStream(new byte[0]) {
            @Override
            public int read(byte[] b, int off, int len) {
                return 0; // Always return 0
            }
        };
        byte[] buffer = new byte[4];
        UTF32Reader reader = new UTF32Reader(ioContext, in, buffer, 0, 0, true);
        char[] cbuf = new char[2];
        IOException exception = assertThrows(IOException.class, () -> reader.read(cbuf, 0, 2));
        assertTrue(exception.getMessage().contains("Strange I/O stream"));
    }

    @Test
    void testRead_MultipleCharacters() throws IOException {
        // 'A' and 'B' in UTF-32BE
        byte[] bytes = {
                0x00, 0x00, 0x00, 0x41,
                0x00, 0x00, 0x00, 0x42
        };
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 8, true);
        char[] buffer = new char[4];
        int result1 = reader.read(buffer, 0, 4);
        assertEquals(2, result1);
        assertEquals('A', buffer[0]);
        assertEquals('B', buffer[1]);
        int result2 = reader.read(buffer, 0, 4);
        assertEquals(-1, result2);
    }

    @Test
    void testRead_LittleEndian() throws IOException {
        // 'A' in UTF-32LE
        byte[] bytes = {0x41, 0x00, 0x00, 0x00};
        UTF32Reader reader = new UTF32Reader(ioContext, new ByteArrayInputStream(bytes), bytes, 0, 4, false);
        char[] buffer = new char[1];
        int result = reader.read(buffer, 0, 1);
        assertEquals(1, result);
        assertEquals('A', buffer[0]);
    }

    @Test
    void testRead_SurrogateAtEnd_Buffered() throws IOException {
        // U+1D11E split across reads
        byte[] firstPart = {0x00, 0x01, (byte) 0xD8};
        byte[] secondPart = {0x1E};
        ByteArrayInputStream in = new ByteArrayInputStream(concat(firstPart, secondPart));
        byte[] buffer = new byte[4];
        System.arraycopy(firstPart, 0, buffer, 0, 3);
        UTF32Reader reader = new UTF32Reader(ioContext, in, buffer, 3, 3, true);
        char[] cbuf = new char[2];
        int result = reader.read(cbuf, 0, 2);
        assertEquals(2, result);
        assertEquals('\uD834', cbuf[0]);
        assertEquals('\uDD1E', cbuf[1]);
    }

    private byte[] concat(byte[] a, byte[] b) {
        byte[] c = new byte[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        return c;
    }
}