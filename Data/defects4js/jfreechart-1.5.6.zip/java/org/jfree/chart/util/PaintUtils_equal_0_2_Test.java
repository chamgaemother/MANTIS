package org.jfree.chart.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Point;
import org.jfree.chart.util.PaintUtils;

public class PaintUtils_equal_0_2_Test {

    @Test
    @DisplayName("Both p1 and p2 are GradientPaint instances with different color1, expect false")
    public void TC06_GradientPaint_different_color1() {
        // GIVEN
        GradientPaint gp1 = new GradientPaint(new Point(0, 0), Color.RED, new Point(1, 1), Color.BLUE);
        GradientPaint gp2 = new GradientPaint(new Point(0, 0), Color.GREEN, new Point(1, 1), Color.BLUE);
        
        // WHEN
        boolean result = PaintUtils.equal(gp1, gp2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are GradientPaint instances with different color2, expect false")
    public void TC07_GradientPaint_different_color2() {
        // GIVEN
        GradientPaint gp1 = new GradientPaint(new Point(0, 0), Color.GREEN, new Point(1, 1), Color.YELLOW);
        GradientPaint gp2 = new GradientPaint(new Point(0, 0), Color.GREEN, new Point(1, 1), Color.BLACK);
        
        // WHEN
        boolean result = PaintUtils.equal(gp1, gp2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are GradientPaint instances with different points, expect false")
    public void TC08_GradientPaint_different_points() {
        // GIVEN
        GradientPaint gp1 = new GradientPaint(new Point(0, 0), Color.RED, new Point(1, 1), Color.BLUE);
        GradientPaint gp2 = new GradientPaint(new Point(0, 0), Color.RED, new Point(2, 2), Color.BLUE);
        
        // WHEN
        boolean result = PaintUtils.equal(gp1, gp2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are GradientPaint instances with different cyclic flags, expect false")
    public void TC09_GradientPaint_different_cyclic() {
        // GIVEN
        GradientPaint gp1 = new GradientPaint(new Point(0, 0), Color.RED, new Point(1, 1), Color.BLUE, true);
        GradientPaint gp2 = new GradientPaint(new Point(0, 0), Color.RED, new Point(1, 1), Color.BLUE, false);
        
        // WHEN
        boolean result = PaintUtils.equal(gp1, gp2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are GradientPaint instances with different transparency, expect false")
    public void TC10_GradientPaint_different_transparency() {
        // GIVEN
        GradientPaint gp1 = new GradientPaint(new Point(0, 0), new Color(255, 0, 0, 255), new Point(1, 1), new Color(0, 0, 255, 255));
        GradientPaint gp2 = new GradientPaint(new Point(0, 0), new Color(255, 0, 0, 128), new Point(1, 1), new Color(0, 0, 255, 255));
        
        // WHEN
        boolean result = PaintUtils.equal(gp1, gp2);
        
        // THEN
        assertFalse(result);
    }
}