package com.fasterxml.jackson.databind.util;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializable;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TokenBuffer_serialize_0_3_Test {

    @Test
    @DisplayName("serialize with VALUE_FALSE token")
    void serialize_with_VALUE_FALSE_token() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeBoolean(false);
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeBoolean(false);
        verifyNoMoreInteractions(gen);
    }

    @Test
    @DisplayName("serialize with VALUE_NULL token")
    void serialize_with_VALUE_NULL_token() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNull();
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeNull();
        verifyNoMoreInteractions(gen);
    }

    @Test
    @DisplayName("serialize with VALUE_EMBEDDED_OBJECT token as JsonSerializable")
    void serialize_with_VALUE_EMBEDDED_OBJECT_token_as_JsonSerializable() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        JsonSerializable serializable = mock(JsonSerializable.class);
        buffer.writeObject(serializable);
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(serializable).serialize(gen, null);
        verifyNoMoreInteractions(gen);
    }

    @Test
    @DisplayName("serialize with VALUE_EMBEDDED_OBJECT token as raw Object")
    void serialize_with_VALUE_EMBEDDED_OBJECT_token_as_raw_Object() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        Object obj = new Object();
        buffer.writeEmbeddedObject(obj);
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeEmbeddedObject(obj);
        verifyNoMoreInteractions(gen);
    }

    @Test
    @DisplayName("serialize encounters unrecognized VALUE_NUMBER_FLOAT type, throws RuntimeException")
    void serialize_encounters_unrecognized_VALUE_NUMBER_FLOAT_type_throws_RuntimeException() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNumber(1234.2); // Mock valid floating-point value
        JsonGenerator gen = mock(JsonGenerator.class);

        boolean caught = false;

        try {
            // WHEN
            buffer.serialize(gen);
        } catch (RuntimeException exception) {
            // THEN
            caught = true;
            assertEquals("Internal error: should never end up through this code path", exception.getMessage());
        }

        assertTrue(caught);
    }
}