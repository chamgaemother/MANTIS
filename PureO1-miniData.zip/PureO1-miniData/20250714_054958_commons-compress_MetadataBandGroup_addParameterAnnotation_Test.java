java
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.compress.harmony.pack200.CPUTF8;
import org.apache.commons.compress.harmony.pack200.CPConstant;
import org.apache.commons.compress.harmony.pack200.CpBands;
import org.apache.commons.compress.harmony.pack200.CPSignature;
import org.apache.commons.compress.harmony.pack200.IntList;
import org.apache.commons.compress.harmony.pack200.MetadataBandGroup;
import org.apache.commons.compress.harmony.pack200.SegmentHeader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class MetadataBandGroupTest {

    private CpBands mockCpBands;
    private SegmentHeader mockSegmentHeader;
    private MetadataBandGroup metadataBandGroup;

    @BeforeEach
    public void setUp() {
        mockCpBands = mock(CpBands.class);
        mockSegmentHeader = mock(SegmentHeader.class);
        metadataBandGroup = new MetadataBandGroup("AD", MetadataBandGroup.CONTEXT_CLASS, mockCpBands, mockSegmentHeader, 0);
    }

    @Test
    public void testAddParameterAnnotation_withAllTags() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        when(mockCpBands.getCPUtf8(any(String.class))).thenReturn(mock(CPUTF8.class));
        CPConstant<?> mockConstant = mock(CPConstant.class);
        when(mockCpBands.getConstant(any())).thenReturn(mockConstant);

        int numParams = 2;
        int[] annoN = {1, 2};
        IntList pairN = new IntList();
        pairN.add(3);
        pairN.add(4);
        List<String> typeRS = Arrays.asList("Type1", "Type2");
        List<String> nameRU = Arrays.asList("Name1", "Name2");
        List<String> tags = Arrays.asList("B", "D", "c", "e", "s");
        List<Object> values = Arrays.asList(100, 200.0, "Signature", "UTF8", "StringValue");
        List<Integer> caseArrayN = Arrays.asList(1);
        List<String> nestTypeRS = Arrays.asList("NestType1");
        List<String> nestNameRU = Arrays.asList("NestName1");
        List<Integer> nestPairN = Arrays.asList(2);

        metadataBandGroup.addParameterAnnotation(numParams, annoN, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        assertEquals(1, metadataBandGroup.param_NB.size());
        assertEquals(2, metadataBandGroup.param_NB.get(0));

        assertEquals(2, metadataBandGroup.anno_N.size());
        assertEquals(1, metadataBandGroup.anno_N.get(0));
        assertEquals(2, metadataBandGroup.anno_N.get(1));

        assertEquals(3, metadataBandGroup.pair_N.size());
        assertEquals(3, metadataBandGroup.pair_N.get(0));
        assertEquals(4, metadataBandGroup.pair_N.get(1));

        assertEquals(2, metadataBandGroup.type_RS.size());
        assertEquals(2, metadataBandGroup.name_RU.size());

        assertEquals(5, metadataBandGroup.T.size());
        assertEquals("B", metadataBandGroup.T.get(0));
        assertEquals("D", metadataBandGroup.T.get(1));
        assertEquals("c", metadataBandGroup.T.get(2));
        assertEquals("e", metadataBandGroup.T.get(3));
        assertEquals("s", metadataBandGroup.T.get(4));

        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertEquals(mockConstant, metadataBandGroup.caseI_KI.get(0));

        assertEquals(1, metadataBandGroup.caseD_KD.size());
        assertEquals(mockConstant, metadataBandGroup.caseD_KD.get(0));

        assertEquals(1, metadataBandGroup.casec_RS.size());

        assertEquals(1, metadataBandGroup.caseet_RS.size());
        assertEquals(1, metadataBandGroup.caseec_RU.size());

        assertEquals(1, metadataBandGroup.cases_RU.size());

        assertEquals(1, metadataBandGroup.casearray_N.size());
        assertEquals(1, metadataBandGroup.casearray_N.get(0));

        assertEquals(1, metadataBandGroup.nesttype_RS.size());
        assertEquals(1, metadataBandGroup.nestname_RU.size());

        assertEquals(1, metadataBandGroup.nestpair_N.size());
        assertEquals(2, metadataBandGroup.nestpair_N.get(0));

        assertEquals(1, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    public void testAddParameterAnnotation_withEmptyLists() {
        metadataBandGroup.addParameterAnnotation(0, new int[]{}, new IntList(), Collections.emptyList(), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList());

        assertEquals(1, metadataBandGroup.param_NB.size());
        assertEquals(0, metadataBandGroup.param_NB.get(0));

        assertEquals(0, metadataBandGroup.anno_N.size());
        assertEquals(0, metadataBandGroup.pair_N.size());
        assertEquals(0, metadataBandGroup.type_RS.size());
        assertEquals(0, metadataBandGroup.name_RU.size());
        assertEquals(0, metadataBandGroup.T.size());
        assertEquals(0, metadataBandGroup.caseI_KI.size());
        assertEquals(0, metadataBandGroup.caseD_KD.size());
        assertEquals(0, metadataBandGroup.caseF_KF.size());
        assertEquals(0, metadataBandGroup.caseJ_KJ.size());
        assertEquals(0, metadataBandGroup.casec_RS.size());
        assertEquals(0, metadataBandGroup.caseet_RS.size());
        assertEquals(0, metadataBandGroup.caseec_RU.size());
        assertEquals(0, metadataBandGroup.cases_RU.size());
        assertEquals(0, metadataBandGroup.casearray_N.size());
        assertEquals(0, metadataBandGroup.nesttype_RS.size());
        assertEquals(0, metadataBandGroup.nestpair_N.size());
        assertEquals(0, metadataBandGroup.nestname_RU.size());
        assertEquals(0, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    public void testAddParameterAnnotation_withNullInputs() {
        assertThrows(NullPointerException.class, () -> {
            metadataBandGroup.addParameterAnnotation(1, null, new IntList(), Arrays.asList("Type"), Arrays.asList("Name"),
                    Arrays.asList("B"), Arrays.asList(100), Arrays.asList(1), Arrays.asList("NestType"),
                    Arrays.asList("NestName"), Arrays.asList(1));
        });

        assertThrows(NullPointerException.class, () -> {
            metadataBandGroup.addParameterAnnotation(1, new int[]{1}, null, Arrays.asList("Type"), Arrays.asList("Name"),
                    Arrays.asList("B"), Arrays.asList(100), Arrays.asList(1), Arrays.asList("NestType"),
                    Arrays.asList("NestName"), Arrays.asList(1));
        });

        assertThrows(NullPointerException.class, () -> {
            metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(), null, Arrays.asList("Name"),
                    Arrays.asList("B"), Arrays.asList(100), Arrays.asList(1), Arrays.asList("NestType"),
                    Arrays.asList("NestName"), Arrays.asList(1));
        });

        // Additional null checks can be added similarly for other parameters if method does not handle them
    }

    @Test
    public void testAddParameterAnnotation_singleTagB() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        when(mockCpBands.getCPUtf8(any(String.class))).thenReturn(mock(CPUTF8.class));
        CPConstant<?> mockConstant = mock(CPConstant.class);
        when(mockCpBands.getConstant(any())).thenReturn(mockConstant);

        metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(),
                Arrays.asList("TypeB"), Arrays.asList("NameB"),
                Arrays.asList("B"), Arrays.asList(100), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertEquals(mockConstant, metadataBandGroup.caseI_KI.get(0));
        assertEquals(1, metadataBandGroup.T.size());
        assertEquals("B", metadataBandGroup.T.get(0));
    }

    @Test
    public void testAddParameterAnnotation_singleTagD() {
        when(mockCpBands.getConstant(any())).thenReturn(mock(CPConstant.class));
        metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(),
                Arrays.asList("TypeD"), Arrays.asList("NameD"),
                Arrays.asList("D"), Arrays.asList(200.0), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        assertEquals(1, metadataBandGroup.caseD_KD.size());
    }

    @Test
    public void testAddParameterAnnotation_singleTagc() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(),
                Arrays.asList("Typec"), Arrays.asList("Namec"),
                Arrays.asList("c"), Arrays.asList("Signature"), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        assertEquals(1, metadataBandGroup.casec_RS.size());
    }

    @Test
    public void testAddParameterAnnotation_singleTage() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        when(mockCpBands.getCPUtf8(any(String.class))).thenReturn(mock(CPUTF8.class));
        metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(),
                Arrays.asList("Typee"), Arrays.asList("Namee"),
                Arrays.asList("e"), Arrays.asList("Signature", "UTF8"), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        assertEquals(1, metadataBandGroup.caseet_RS.size());
        assertEquals(1, metadataBandGroup.caseec_RU.size());
    }

    @Test
    public void testAddParameterAnnotation_singleTags_withMultipleAnnotations() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        when(mockCpBands.getCPUtf8(any(String.class))).thenReturn(mock(CPUTF8.class));
        CPConstant<?> mockConstant = mock(CPConstant.class);
        when(mockCpBands.getConstant(any())).thenReturn(mockConstant);

        metadataBandGroup.addParameterAnnotation(2, new int[]{1, 2}, new IntList(),
                Arrays.asList("TypeB", "TypeD"), Arrays.asList("NameB", "NameD"),
                Arrays.asList("B", "D"), Arrays.asList(100, 200.0), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        assertEquals(2, metadataBandGroup.caseI_KI.size());
        assertEquals(mockConstant, metadataBandGroup.caseI_KI.get(0));
        assertEquals(mockConstant, metadataBandGroup.caseI_KI.get(1));
        assertEquals(2, metadataBandGroup.caseD_KD.size());
    }

    @Test
    public void testAddParameterAnnotation_invalidTags() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        when(mockCpBands.getCPUtf8(any(String.class))).thenReturn(mock(CPUTF8.class));
        // Tags not handled in switch should be ignored
        metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(),
                Arrays.asList("TypeX"), Arrays.asList("NameX"),
                Arrays.asList("X", "Y"), Arrays.asList("Value1", "Value2"), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        assertEquals(2, metadataBandGroup.T.size());
        assertEquals("X", metadataBandGroup.T.get(0));
        assertEquals("Y", metadataBandGroup.T.get(1));
        // No additions to case lists
        assertEquals(0, metadataBandGroup.caseI_KI.size());
        assertEquals(0, metadataBandGroup.caseD_KD.size());
        assertEquals(0, metadataBandGroup.caseF_KF.size());
        assertEquals(0, metadataBandGroup.caseJ_KJ.size());
        assertEquals(0, metadataBandGroup.casec_RS.size());
        assertEquals(0, metadataBandGroup.caseet_RS.size());
        assertEquals(0, metadataBandGroup.caseec_RU.size());
        assertEquals(0, metadataBandGroup.cases_RU.size());
    }

    @Test
    public void testAddParameterAnnotation_withCaseArrayN() {
        metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(),
                Arrays.asList("TypeB"), Arrays.asList("NameB"),
                Arrays.asList("B"), Arrays.asList(100), Arrays.asList(3),
                Collections.emptyList(), Collections.emptyList(), Arrays.asList(2));

        assertEquals(1, metadataBandGroup.casearray_N.size());
        assertEquals(3, metadataBandGroup.casearray_N.get(0));
        assertEquals(2, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    public void testAddParameterAnnotation_withNestFields() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        when(mockCpBands.getCPUtf8(any(String.class))).thenReturn(mock(CPUTF8.class));
        metadataBandGroup.addParameterAnnotation(1, new int[]{1}, new IntList(),
                Arrays.asList("TypeNest"), Arrays.asList("NameNest"),
                Arrays.asList("c"), Arrays.asList("Signature"),
                Collections.emptyList(), Arrays.asList("NestType"), Arrays.asList("NestName"),
                Arrays.asList(1));

        assertEquals(1, metadataBandGroup.casec_RS.size());
        assertEquals(1, metadataBandGroup.nesttype_RS.size());
        assertEquals(1, metadataBandGroup.nestname_RU.size());
        assertEquals(1, metadataBandGroup.nestpair_N.size());
        assertEquals(1, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    public void testAddParameterAnnotation_boundaryValues() {
        when(mockCpBands.getCPSignature(any(String.class))).thenReturn(mock(CPSignature.class));
        when(mockCpBands.getCPUtf8(any(String.class))).thenReturn(mock(CPUTF8.class));
        CPConstant<?> mockConstant = mock(CPConstant.class);
        when(mockCpBands.getConstant(any())).thenReturn(mockConstant);

        int numParams = Integer.MAX_VALUE;
        int[] annoN = {Integer.MIN_VALUE, 0, Integer.MAX_VALUE};
        IntList pairN = new IntList();
        pairN.add(0);
        pairN.add(Integer.MAX_VALUE);
        pairN.add(Integer.MIN_VALUE);
        List<String> typeRS = Arrays.asList("", "T");
        List<String> nameRU = Arrays.asList("", "N");
        List<String> tags = Arrays.asList("Z", "F");
        List<Object> values = Arrays.asList(false, 3.14f);
        List<Integer> caseArrayN = Arrays.asList(0, Integer.MAX_VALUE);
        List<String> nestTypeRS = Arrays.asList("", "NestT");
        List<String> nestNameRU = Arrays.asList("", "NestN");
        List<Integer> nestPairN = Arrays.asList(0, Integer.MAX_VALUE);

        metadataBandGroup.addParameterAnnotation(numParams, annoN, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        assertEquals(1, metadataBandGroup.param_NB.size());
        assertEquals(Integer.MAX_VALUE, metadataBandGroup.param_NB.get(0));

        assertEquals(3, metadataBandGroup.anno_N.size());
        assertEquals(Integer.MIN_VALUE, metadataBandGroup.anno_N.get(0));
        assertEquals(0, metadataBandGroup.anno_N.get(1));
        assertEquals(Integer.MAX_VALUE, metadataBandGroup.anno_N.get(2));

        assertEquals(3, metadataBandGroup.pair_N.size());
        assertEquals(0, metadataBandGroup.pair_N.get(0));
        assertEquals(Integer.MAX_VALUE, metadataBandGroup.pair_N.get(1));
        assertEquals(Integer.MIN_VALUE, metadataBandGroup.pair_N.get(2));

        assertEquals(2, metadataBandGroup.type_RS.size());
        assertEquals(2, metadataBandGroup.name_RU.size());

        assertEquals(2, metadataBandGroup.T.size());
        assertEquals("Z", metadataBandGroup.T.get(0));
        assertEquals("F", metadataBandGroup.T.get(1));

        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertEquals(mockConstant, metadataBandGroup.caseI_KI.get(0));

        assertEquals(1, metadataBandGroup.caseF_KF.size());
        assertEquals(mockConstant, metadataBandGroup.caseF_KF.get(0));

        assertEquals(2, metadataBandGroup.casearray_N.size());
        assertEquals(0, metadataBandGroup.casearray_N.get(0));
        assertEquals(Integer.MAX_VALUE, metadataBandGroup.casearray_N.get(1));

        assertEquals(2, metadataBandGroup.nesttype_RS.size());
        assertEquals(2, metadataBandGroup.nestname_RU.size());

        assertEquals(2, metadataBandGroup.nestpair_N.size());
        assertEquals(0, metadataBandGroup.nestpair_N.get(0));
        assertEquals(Integer.MAX_VALUE, metadataBandGroup.nestpair_N.get(1));

        assertEquals(Integer.MAX_VALUE, metadataBandGroup.numBackwardsCalls());
    }
}