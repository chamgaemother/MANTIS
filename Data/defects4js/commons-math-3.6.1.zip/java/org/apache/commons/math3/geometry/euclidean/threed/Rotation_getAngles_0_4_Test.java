package org.apache.commons.math3.geometry.euclidean.threed;


import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Rotation_getAngles_0_4_Test {

    @Test
    @DisplayName("TC16: getAngles with VECTOR_OPERATOR convention and XZX order where v2.getX() exceeds upper boundary, throwing exception")
    void TC16_getAngles_VECTOR_OPERATOR_XZX_v2X_exceeds_upper_boundary() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 1.0, 0.0, false);

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XZX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    @DisplayName("TC17: getAngles with VECTOR_OPERATOR convention and YXY order where v2.getY() is within bounds")
    void TC17_getAngles_VECTOR_OPERATOR_YXY_within_bounds() {
        // GIVEN
        Rotation rotation = new Rotation(FastMath.cos(FastMath.PI / 6), FastMath.sin(FastMath.PI / 6), 0.0, 0.0, false);

        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.YXY, RotationConvention.VECTOR_OPERATOR);

        // THEN
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    @DisplayName("TC18: getAngles with VECTOR_OPERATOR convention and YXY order where v2.getY() exceeds upper boundary, throwing exception")
    void TC18_getAngles_VECTOR_OPERATOR_YXY_v2Y_exceeds_upper_boundary() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 1.0, 0.0, false);

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YXY, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    @DisplayName("TC19: getAngles with VECTOR_OPERATOR convention and YZY order where v2.getY() is within bounds")
    void TC19_getAngles_VECTOR_OPERATOR_YZY_within_bounds() {
        // GIVEN
        Rotation rotation = new Rotation(FastMath.cos(FastMath.PI / 4), FastMath.sin(FastMath.PI / 4), 0.0, 0.0, false);

        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.YZY, RotationConvention.VECTOR_OPERATOR);

        // THEN
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    @DisplayName("TC20: getAngles with VECTOR_OPERATOR convention and YZY order where v2.getY() exceeds upper boundary, throwing exception")
    void TC20_getAngles_VECTOR_OPERATOR_YZY_v2Y_exceeds_upper_boundary() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 1.0, false);

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YZY, RotationConvention.VECTOR_OPERATOR);
        });
    }
}
