import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem.Evaluation;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer.Optimum;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.apache.commons.math3.util.Incrementor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.mockito.Mockito.*;

class LevenbergMarquardtOptimizerTest {

    private LevenbergMarquardtOptimizer optimizer;
    private LeastSquaresProblem problem;
    private Evaluation evaluation;
    private RealVector start;
    private RealVector point;
    private double[] residuals;
    private double cost;
    private RealMatrix jacobian;
    private int observationSize;
    private int parameterSize;
    private ConvergenceChecker<Evaluation> checker;

    @BeforeEach
    void setUp() {
        optimizer = new LevenbergMarquardtOptimizer();
        problem = mock(LeastSquaresProblem.class);
        evaluation = mock(Evaluation.class);
        checker = mock(ConvergenceChecker.class);

        // Mocking the problem and evaluation conditions
        observationSize = 2;
        parameterSize = 2;
        start = new ArrayRealVector(new double[] {1, 1});
        point = new ArrayRealVector(new double[] {1, 1});
        residuals = new double[] {1, 1};
        cost = 1.0;

        when(problem.getObservationSize()).thenReturn(observationSize);
        when(problem.getParameterSize()).thenReturn(parameterSize);
        when(problem.getIterationCounter()).thenReturn(new Incrementor(100));
        when(problem.getEvaluationCounter()).thenReturn(new Incrementor(100));
        when(problem.getConvergenceChecker()).thenReturn(checker);
        when(problem.getStart()).thenReturn(start);
        when(problem.evaluate(any(RealVector.class))).thenReturn(evaluation);

        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(residuals));
        when(evaluation.getCost()).thenReturn(cost);
        when(evaluation.getPoint()).thenReturn(point);
        when(evaluation.getJacobian()).thenReturn(jacobian);
    }

    @Test
    void testOptimizeValidInputsConverged() {
        jacobian = mock(RealMatrix.class);
        when(jacobian.getData()).thenReturn(new double[][] { {1, 0}, {0, 1} });
        when(checker.converged(anyInt(), any(Evaluation.class), any(Evaluation.class))).thenReturn(true);

        Optimum optimum = optimizer.optimize(problem);
        Assertions.assertNotNull(optimum);
    }

    @Test
    void testOptimizeValidInputsNonConverged() {
        jacobian = mock(RealMatrix.class);
        when(jacobian.getData()).thenReturn(new double[][] { {1, 0}, {0, 1} });
        when(checker.converged(anyInt(), any(Evaluation.class), any(Evaluation.class))).thenReturn(false);
        
        Optimum optimum = optimizer.optimize(problem);
        Assertions.assertNotNull(optimum);
    }

    @Test
    void testOptimizeInvalidJacobian() {
        jacobian = mock(RealMatrix.class);
        when(jacobian.getData()).thenReturn(new double[][] { {Double.NaN, 0}, {0, Double.NaN} });
        
        Assertions.assertThrows(ConvergenceException.class, () -> optimizer.optimize(problem));
    }

    @Test
    void testOptimizeNegativeCost() {
        when(evaluation.getCost()).thenReturn(-1.0);
        jacobian = mock(RealMatrix.class);
        when(jacobian.getData()).thenReturn(new double[][] { {1, 0}, {0, 1} });

        Assertions.assertThrows(ConvergenceException.class, () -> optimizer.optimize(problem));
    }
    
    @Test
    void testOptimizeNegativeResiduals() {
        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(new double[] {-1, -1}));
        jacobian = mock(RealMatrix.class);
        when(jacobian.getData()).thenReturn(new double[][] { {1, 0}, {0, 1} });

        Optimum optimum = optimizer.optimize(problem);
        Assertions.assertNotNull(optimum);
    }
}