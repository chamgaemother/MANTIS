package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import org.apache.commons.collections4.map.Flat3Map;

public class Flat3Map_get_0_4_Test {

    @Test
    @DisplayName("Delegate map is null, key is not null, size=3, hash3 matches but keys are not equal")
    public void TC16() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set hash1 to key.hashCode() + 1 to not match
        String key = "key";
        String nonMatchingKey3 = "nonMatchingKey3";
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, key.hashCode() + 1);

        // Set hash2 to key.hashCode() + 2 to not match
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, key.hashCode() + 2);

        // Set hash3 to key.hashCode() to match
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, key.hashCode());

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "otherKey1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "otherKey2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, nonMatchingKey3);

        // Set value1, value2, value3
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke get
        Object result = map.get(key);

        // Assert result is null
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=3, hash2 matches and keys are equal")
    public void TC17() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set hash1 to key.hashCode() + 1 to not match
        String key = "key2";
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, key.hashCode() + 1);

        // Set hash2 to key.hashCode() to match
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, key.hashCode());

        // Set hash3 to key.hashCode() + 2 to not match
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, key.hashCode() + 2);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "otherKey1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "otherKey3");

        // Set value1, value2, value3
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke get
        Object result = map.get(key);

        // Assert result equals value2
        assertEquals("value2", result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=3, hash2 matches but keys are not equal")
    public void TC18() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set hash1 to key.hashCode() + 1 to not match
        String key = "key2";
        String nonMatchingKey2 = "nonMatchingKey2";
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, key.hashCode() + 1);

        // Set hash2 to key.hashCode() to match
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, key.hashCode());

        // Set hash3 to key.hashCode() + 2 to not match
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, key.hashCode() + 2);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "otherKey1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, nonMatchingKey2);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "otherKey3");

        // Set value1, value2, value3
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke get
        Object result = map.get(key);

        // Assert result is null
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=3, hash1 matches and keys are equal")
    public void TC19() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set hash1 to key.hashCode() to match
        String key = "key1";
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, key.hashCode());

        // Set hash2 to key.hashCode() + 1 to not match
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, key.hashCode() + 1);

        // Set hash3 to key.hashCode() + 2 to not match
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, key.hashCode() + 2);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "otherKey2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "otherKey3");

        // Set value1, value2, value3
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke get
        Object result = map.get(key);

        // Assert result equals value1
        assertEquals("value1", result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=3, hash1 matches but keys are not equal")
    public void TC20() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set hash1 to key.hashCode() to match
        String key = "key1";
        String nonMatchingKey1 = "nonMatchingKey1";
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, key.hashCode());

        // Set hash2 to key.hashCode() + 1 to not match
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, key.hashCode() + 1);

        // Set hash3 to key.hashCode() + 2 to not match
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, key.hashCode() + 2);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, nonMatchingKey1);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "otherKey2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "otherKey3");

        // Set value1, value2, value3
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke get
        Object result = map.get(key);

        // Assert result is null
        assertNull(result);
    }
}