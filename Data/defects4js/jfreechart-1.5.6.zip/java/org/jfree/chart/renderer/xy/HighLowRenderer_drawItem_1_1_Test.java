// package org.jfree.chart.renderer.xy;
// import org.jfree.chart.ChartRenderingInfo;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// 
// import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.data.Range;
// import org.jfree.data.xy.OHLCDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// public class HighLowRenderer_drawItem_1_1_Test {
// 
//     @Test
//     @DisplayName("DrawItem returns early when x value is below the domain axis range")
//     void TC01_drawItem_XBelowDomainRange() {
//         // Arrange
//         XYDataset dataset = mock(XYDataset.class);
//         HighLowRenderer renderer = new HighLowRenderer();
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(5.0);
// 
//         // Act & Assert
//         assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, info, plot,
//                 domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
//         // Verify that no painting methods are called
//         verify(g2, never()).draw(any());
//     }
// 
//     @Test
//     @DisplayName("DrawItem returns early when x value is above the domain axis range")
//     void TC02_drawItem_XAboveDomainRange() {
//         // Arrange
//         XYDataset dataset = mock(XYDataset.class);
//         HighLowRenderer renderer = new HighLowRenderer();
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(25.0);
// 
//         // Act & Assert
//         assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, info, plot,
//                 domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
//         // Verify that no painting methods are called
//         verify(g2, never()).draw(any());
//     }
// 
//     @Test
//     @DisplayName("DrawItem proceeds when x value is within the domain axis range")
//     void TC03_drawItem_XWithinDomainRange() {
//         // Arrange
//         XYDataset dataset = mock(XYDataset.class);
//         HighLowRenderer renderer = spy(new HighLowRenderer());
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(15.0);
// 
//         doNothing().when(renderer).fireChangeEvent();
// 
//         // Act & Assert
//         assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, info, plot,
//                 domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
//         // Verify that getXValue is called
//         verify(dataset, times(1)).getXValue(0, 0);
//     }
// 
//     @Test
//     @DisplayName("DrawItem handles null PlotRenderingInfo")
//     void TC04_drawItem_NullPlotRenderingInfo_NonOHLCDataset() {
//         // Arrange
//         XYDataset dataset = mock(XYDataset.class);
//         HighLowRenderer renderer = spy(new HighLowRenderer());
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         XYPlot plot = mock(XYPlot.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset instanceof OHLCDataset).thenReturn(false);
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(15.0);
// 
//         doNothing().when(renderer).fireChangeEvent();
// 
//         // Act & Assert
//         assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, null, plot,
//                 domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
//         // Verify that no entity is added since info is null
//         verify(renderer, never()).addEntity(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
//     }
// 
//     @Test
//     @DisplayName("DrawItem processes OHLCDataset with valid yHigh and yLow in VERTICAL orientation")
//     void TC05_drawItem_OHLCDataset_ValidYHighYLow_VERTICAL() {
//         // Arrange
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         HighLowRenderer renderer = spy(new HighLowRenderer());
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(15.0);
//         when(dataset.getHighValue(anyInt(), anyInt())).thenReturn(25.0);
//         when(dataset.getLowValue(anyInt(), anyInt())).thenReturn(15.0);
// 
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
// 
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(25.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
// 
//         doNothing().when(renderer).fireChangeEvent();
// 
//         // Act & Assert
//         assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, info, plot,
//                 domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
//         // Verify that vertical high and low lines are drawn
//         verify(g2, times(1)).draw(any());
//     }
// }