package org.apache.commons.math3.geometry.euclidean.threed;

import java.lang.reflect.Field;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Rotation_getAngles_0_2_Test {

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and YXZ order where v2.getZ() exceeds upper boundary, throwing exception")
    public void TC06() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        try {
            Field q0 = Rotation.class.getDeclaredField("q0");
            Field q1 = Rotation.class.getDeclaredField("q1");
            Field q2 = Rotation.class.getDeclaredField("q2");
            Field q3 = Rotation.class.getDeclaredField("q3");
            q0.setAccessible(true);
            q1.setAccessible(true);
            q2.setAccessible(true);
            q3.setAccessible(true);
            // Set quaternion to cause v2.getZ() > 0.9999999999
            q0.setDouble(rotation, 0.0);
            q1.setDouble(rotation, 0.0);
            q2.setDouble(rotation, 0.0);
            q3.setDouble(rotation, 1.0);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection setup failed: " + e.getMessage());
        }

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YXZ, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and YZX order where v2.getX() is within bounds")
    public void TC07() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        try {
            Field q0 = Rotation.class.getDeclaredField("q0");
            Field q1 = Rotation.class.getDeclaredField("q1");
            Field q2 = Rotation.class.getDeclaredField("q2");
            Field q3 = Rotation.class.getDeclaredField("q3");
            q0.setAccessible(true);
            q1.setAccessible(true);
            q2.setAccessible(true);
            q3.setAccessible(true);
            // Set quaternion to ensure v2.getX() is within bounds (-0.9999999999 <= x <= 0.9999999999)
            q0.setDouble(rotation, 0.7071067811865476);
            q1.setDouble(rotation, 0.0);
            q2.setDouble(rotation, 0.7071067811865475);
            q3.setDouble(rotation, 0.0);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection setup failed: " + e.getMessage());
        }

        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.YZX, RotationConvention.VECTOR_OPERATOR);

        // THEN
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        // Additional assertions can be added here
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and YZX order where v2.getX() exceeds upper boundary, throwing exception")
    public void TC08() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        try {
            Field q0 = Rotation.class.getDeclaredField("q0");
            Field q1 = Rotation.class.getDeclaredField("q1");
            Field q2 = Rotation.class.getDeclaredField("q2");
            Field q3 = Rotation.class.getDeclaredField("q3");
            q0.setAccessible(true);
            q1.setAccessible(true);
            q2.setAccessible(true);
            q3.setAccessible(true);
            // Set quaternion to cause v2.getX() > 0.9999999999
            q0.setDouble(rotation, 0.0);
            q1.setDouble(rotation, 1.0);
            q2.setDouble(rotation, 0.0);
            q3.setDouble(rotation, 0.0);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection setup failed: " + e.getMessage());
        }

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YZX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZXY order where v2.getY() is within bounds")
    public void TC09() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        try {
            Field q0 = Rotation.class.getDeclaredField("q0");
            Field q1 = Rotation.class.getDeclaredField("q1");
            Field q2 = Rotation.class.getDeclaredField("q2");
            Field q3 = Rotation.class.getDeclaredField("q3");
            q0.setAccessible(true);
            q1.setAccessible(true);
            q2.setAccessible(true);
            q3.setAccessible(true);
            // Set quaternion to ensure v2.getY() is within bounds (-0.9999999999 <= y <= 0.9999999999)
            q0.setDouble(rotation, 0.7071067811865476);
            q1.setDouble(rotation, 0.7071067811865475);
            q2.setDouble(rotation, 0.0);
            q3.setDouble(rotation, 0.0);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection setup failed: " + e.getMessage());
        }

        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.ZXY, RotationConvention.VECTOR_OPERATOR);

        // THEN
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        // Additional assertions can be added here
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZXY order where v2.getY() exceeds upper boundary, throwing exception")
    public void TC10() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        try {
            Field q0 = Rotation.class.getDeclaredField("q0");
            Field q1 = Rotation.class.getDeclaredField("q1");
            Field q2 = Rotation.class.getDeclaredField("q2");
            Field q3 = Rotation.class.getDeclaredField("q3");
            q0.setAccessible(true);
            q1.setAccessible(true);
            q2.setAccessible(true);
            q3.setAccessible(true);
            // Set quaternion to cause v2.getY() > 0.9999999999
            q0.setDouble(rotation, 0.0);
            q1.setDouble(rotation, 0.0);
            q2.setDouble(rotation, 1.0);
            q3.setDouble(rotation, 0.0);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection setup failed: " + e.getMessage());
        }

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZXY, RotationConvention.VECTOR_OPERATOR);
        });
    }
}