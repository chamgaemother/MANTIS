package org.apache.commons.math3.fitting.leastsquares;
import java.lang.reflect.*;


import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Incrementor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LevenbergMarquardtOptimizer_optimize_0_9_Test {

//    @Test
//    @DisplayName("Optimize correctly updates weightedResidual after function evaluation")
//    public void TC41_weightedResidualUpdateAfterEvaluation() throws Exception {
//        LeastSquaresProblem problem = createProblemWithEvaluations();
//
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//
//        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);
//
//        // Access the private field 'oldRes' using reflection
//        Field oldResField = LevenbergMarquardtOptimizer.class.getDeclaredField("oldRes");
//        oldResField.setAccessible(true);
//
//        double[] weightedResidualFromOptimizer = (double[]) oldResField.get(optimizer);
//
//        // Assert that 'oldRes' has been updated correctly
//        double[] expectedWeightedResidual = getExpectedWeightedResidual(); // Define this method based on test setup
//        assertArrayEquals(expectedWeightedResidual, weightedResidualFromOptimizer, 1e-6, "'oldRes' should be updated correctly after each evaluation");
//    }

//    @Test
//    @DisplayName("Optimize correctly handles scenarios where initial function evaluation fails")
//    public void TC42_initialFunctionEvaluationFailureThrowsException() {
//        LeastSquaresProblem problem = createProblemWithFailingInitialEvaluation();
//
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//
//        assertThrows(EvaluationException.class, () -> {
//            optimizer.optimize(problem);
//        }, "Optimizer should propagate EvaluationException on initial evaluation failure");
//    }

//    private LeastSquaresProblem createProblemWithEvaluations() {
//        return new MockLeastSquaresProblem();
//    }
//
//    private LeastSquaresProblem createProblemWithFailingInitialEvaluation() {
//        return new LeastSquaresProblem() {
//            @Override
//            public int getObservationSize() {
//                return 2;
//            }
//
//            @Override
//            public int getParameterSize() {
//                return 2;
//            }
//
//            @Override
//            public RealVector getStart() {
//                return new ArrayRealVector(new double[]{1.0, 1.0});
//            }
//
//            @Override
//            public Incrementor getEvaluationCounter() {
//                return new Incrementor();
//            }
//
//            @Override
//            public Incrementor getIterationCounter() {
//                return new Incrementor();
//            }
//
//            @Override
//            public ConvergenceChecker<Evaluation> getConvergenceChecker() {
//                return null;
//            }
//
//        };
//    }
//
//    private static class MockLeastSquaresProblem implements LeastSquaresProblem {
//        private final Incrementor evaluationCounter = new Incrementor();
//        private final Incrementor iterationCounter = new Incrementor();
//
//        @Override
//        public int getObservationSize() {
//            return 2;
//        }
//
//        @Override
//        public int getParameterSize() {
//            return 2;
//        }
//
//        @Override
//        public RealVector getStart() {
//            return new ArrayRealVector(new double[]{1.0, 1.0});
//        }
//
//        @Override
//        public Incrementor getEvaluationCounter() {
//            return evaluationCounter;
//        }
//
//        @Override
//        public Incrementor getIterationCounter() {
//            return iterationCounter;
//        }
//
//        @Override
//        public ConvergenceChecker<Evaluation> getConvergenceChecker() {
//            return (iteration, previous, current) -> false;
//        }
//
//        @Override
//        public Evaluation evaluate(RealVector point) {
//            evaluationCounter.incrementCount();
//            double[] residuals = new double[]{point.getEntry(0) - 1.0, point.getEntry(1) - 1.0};
//            return new Evaluation() {
//                @Override
//                public RealVector getPoint() {
//                    return point;
//                }
//
//                @Override
//                public RealVector getResiduals() {
//                    return new ArrayRealVector(residuals);
//                }
//
//                @Override
//                public double getCost() {
//                    return FastMath.sqrt(residuals[0] * residuals[0] + residuals[1] * residuals[1]);
//                }
//
//                @Override
//                public RealMatrix getJacobian() {
//                    return new Array2DRowRealMatrix(new double[][]{{1, 0}, {0, 1}});
//                }
//            };
//        }
//    }

    private double[] getExpectedWeightedResidual() {
        return new double[]{0.0, 0.0};
    }
}
