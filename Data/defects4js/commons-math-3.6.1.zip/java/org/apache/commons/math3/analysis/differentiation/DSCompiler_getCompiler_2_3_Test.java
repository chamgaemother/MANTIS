package org.apache.commons.math3.analysis.differentiation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Test class for DSCompiler.getCompiler method.
 */
public class DSCompiler_getCompiler_2_3_Test {

    @Test
    @DisplayName("getCompiler handles simultaneous cache expansions for multiple parameter and order increments")
    public void test_TC26() throws Exception {
        // Access DSCompiler class
        Class<DSCompiler> cls = DSCompiler.class;

        // Access private static field 'compilers'
        Field compilersField = cls.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        @SuppressWarnings("unchecked")
        AtomicReference<DSCompiler[][]> compilers = (AtomicReference<DSCompiler[][]>) compilersField.get(null);

        // Setup precondition: cache size less than [3][5]
        DSCompiler[][] initialCache = new DSCompiler[2][4]; // parameters=2, order=3
        compilers.set(initialCache);

        // Invoke getCompiler(3,5)
        DSCompiler compiler = DSCompiler.getCompiler(3, 5);

        // Assertions
        assertNotNull(compiler, "Compiler should not be null");
        assertEquals(3, compiler.getFreeParameters(), "Compiler parameters should be 3");
        assertEquals(5, compiler.getOrder(), "Compiler order should be 5");

        // Access updated cache
        DSCompiler[][] updatedCache = compilers.get();

        // Check cache size is expanded beyond [3][5]
        assertTrue(updatedCache.length > 3, "Cache should have more than 3 parameters");
        assertTrue(updatedCache[3].length > 5, "Cache should have more than 5 orders for parameters=3");

        // Check that cache[3][5] == compiler
        assertSame(compiler, updatedCache[3][5], "Compiler should be cached at [3][5]");
    }
}