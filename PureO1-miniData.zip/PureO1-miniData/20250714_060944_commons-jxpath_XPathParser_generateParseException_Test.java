package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.io.StringReader;

class XPathParserTest {

    @Test
    void testGenerateParseExceptionWithEmptyInput() {
        XPathParser parser = new XPathParser(new StringReader(""));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithInvalidToken() {
        XPathParser parser = new XPathParser(new StringReader("//*//"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithIncompleteFunction() {
        XPathParser parser = new XPathParser(new StringReader("function("));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithUnexpectedEOF() {
        XPathParser parser = new XPathParser(new StringReader("(/a/b"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithMismatchedParentheses() {
        XPathParser parser = new XPathParser(new StringReader("(a/b))"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithInvalidAxis() {
        XPathParser parser = new XPathParser(new StringReader("ancestor::child::"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithInvalidPredicate() {
        XPathParser parser = new XPathParser(new StringReader("/a[b[c]]"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithInvalidOperator() {
        XPathParser parser = new XPathParser(new StringReader("/a/b | | /c"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithMultipleErrors() {
        XPathParser parser = new XPathParser(new StringReader("/a/b["));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithOnlySlash() {
        XPathParser parser = new XPathParser(new StringReader("/"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithOnlyDoubleSlash() {
        XPathParser parser = new XPathParser(new StringReader("//"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithInvalidFunctionName() {
        XPathParser parser = new XPathParser(new StringReader("invalidFunc()"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithMissingFunctionParenthesis() {
        XPathParser parser = new XPathParser(new StringReader("function(arg"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithExtraComma() {
        XPathParser parser = new XPathParser(new StringReader("key('name',)"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGenerateParseExceptionWithIncompleteUnion() {
        XPathParser parser = new XPathParser(new StringReader("/a |"));
        ParseException exception = assertThrows(ParseException.class, parser::generateParseException);
        assertNotNull(exception.getMessage());
    }
}