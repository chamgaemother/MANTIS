import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.direct.NelderMeadSimplex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;

class NelderMeadSimplexTest {

    private NelderMeadSimplex simplex;
    private MultivariateFunction mockFunction;
    private Comparator<PointValuePair> mockComparator;

    @BeforeEach
    void setUp() {
        // Initialize with 2 dimensions for simplicity
        simplex = new NelderMeadSimplex(2);
        mockFunction = point -> 0.0;
        mockComparator = Comparator.comparingDouble(PointValuePair::getValue);
    }

    @Test
    void testIterate_acceptReflectedPoint() {
        // Arrange
        // Setup simplex points such that reflected point is better than secondBest but worse than best
        PointValuePair best = new PointValuePair(new double[]{0, 0}, 1.0, false);
        PointValuePair secondBest = new PointValuePair(new double[]{1, 0}, 2.0, false);
        PointValuePair worst = new PointValuePair(new double[]{1, 1}, 3.0, false);
        simplex.setPoint(0, best);
        simplex.setPoint(1, secondBest);
        simplex.setPoint(2, worst);

        // Mock function to return specific values
        mockFunction = point -> {
            if (point[0] == 0.5 && point[1] == 0.5) {
                return 1.5;
            }
            return 0.0;
        };

        // Act
        simplex.iterate(mockFunction, mockComparator);

        // Assert
        PointValuePair newWorst = simplex.getPoint(2);
        assertEquals(1.5, newWorst.getValue());
        assertArrayEquals(new double[]{0.5, 0.5}, newWorst.getPoint());
    }

    @Test
    void testIterate_acceptExpandedPoint() {
        // Arrange
        PointValuePair best = new PointValuePair(new double[]{0, 0}, 1.0, false);
        PointValuePair secondBest = new PointValuePair(new double[]{1, 0}, 2.0, false);
        PointValuePair worst = new PointValuePair(new double[]{1, 1}, 3.0, false);
        simplex.setPoint(0, best);
        simplex.setPoint(1, secondBest);
        simplex.setPoint(2, worst);

        mockFunction = point -> {
            if (point[0] == -1 && point[1] == -1) {
                return 0.5;
            } else if (point[0] == -0.5 && point[1] == -0.5) {
                return 1.2;
            }
            return 3.0;
        };

        // Act
        simplex.iterate(mockFunction, mockComparator);

        // Assert
        PointValuePair newWorst = simplex.getPoint(2);
        assertEquals(0.5, newWorst.getValue());
        assertArrayEquals(new double[]{-1.0, -1.0}, newWorst.getPoint());
    }

    @Test
    void testIterate_acceptReflectedWhenExpansionNotBetter() {
        // Arrange
        PointValuePair best = new PointValuePair(new double[]{0, 0}, 1.0, false);
        PointValuePair secondBest = new PointValuePair(new double[]{1, 0}, 2.0, false);
        PointValuePair worst = new PointValuePair(new double[]{1, 1}, 3.0, false);
        simplex.setPoint(0, best);
        simplex.setPoint(1, secondBest);
        simplex.setPoint(2, worst);

        mockFunction = point -> {
            if (point[0] == 0.5 && point[1] == 0.5) {
                return 1.5;
            } else if (point[0] == 1.5 && point[1] == 1.5) {
                return 1.4;
            }
            return 3.0;
        };

        // Act
        simplex.iterate(mockFunction, mockComparator);

        // Assert
        PointValuePair newWorst = simplex.getPoint(2);
        assertEquals(1.5, newWorst.getValue());
        assertArrayEquals(new double[]{0.5, 0.5}, newWorst.getPoint());
    }

    @Test
    void testIterate_acceptExpandedPointWhenBetter() {
        // Arrange
        PointValuePair best = new PointValuePair(new double[]{0, 0}, 1.0, false);
        PointValuePair secondBest = new PointValuePair(new double[]{1, 0}, 2.0, false);
        PointValuePair worst = new PointValuePair(new double[]{1, 1}, 3.0, false);
        simplex.setPoint(0, best);
        simplex.setPoint(1, secondBest);
        simplex.setPoint(2, worst);

        mockFunction = point -> {
            if (point[0] == 0.5 && point[1] == 0.5) {
                return 1.5;
            } else if (point[0] == 0 && point[1] == 0) {
                return 0.5;
            }
            return 3.0;
        };

        // Act
        simplex.iterate(mockFunction, mockComparator);

        // Assert
        PointValuePair newWorst = simplex.getPoint(2);
        assertEquals(1.5, newWorst.getValue());
        assertArrayEquals(new double[]{0.5, 0.5}, newWorst.getPoint());
    }

    @Test
    void testIterate_acceptOutsideContraction() {
        // Arrange
        PointValuePair best = new PointValuePair(new double[]{0, 0}, 1.0, false);
        PointValuePair secondBest = new PointValuePair(new double[]{1, 0}, 2.0, false);
        PointValuePair worst = new PointValuePair(new double[]{2, 2}, 4.0, false);
        simplex.setPoint(0, best);
        simplex.setPoint(1, secondBest);
        simplex.setPoint(2, worst);

        mockFunction = point -> {
            if (point[0] == 1.5 && point[1] == 1.5) {
                return 3.5;
            } else if (point[0] == 1.25 && point[1] == 1.25) {
                return 3.25;
            }
            return 4.0;
        };

        // Act
        simplex.iterate(mockFunction, mockComparator);

        // Assert
        PointValuePair newWorst = simplex.getPoint(2);
        assertEquals(3.25, newWorst.getValue());
        assertArrayEquals(new double[]{1.25, 1.25}, newWorst.getPoint());
    }

    @Test
    void testIterate_acceptInsideContraction() {
        // Arrange
        PointValuePair best = new PointValuePair(new double[]{0, 0}, 1.0, false);
        PointValuePair secondBest = new PointValuePair(new double[]{1, 0}, 2.0, false);
        PointValuePair worst = new PointValuePair(new double[]{2, 2}, 4.0, false);
        simplex.setPoint(0, best);
        simplex.setPoint(1, secondBest);
        simplex.setPoint(2, worst);

        mockFunction = point -> {
            if (point[0] == 1.5 && point[1] == 1.5) {
                return 4.5;
            } else if (point[0] == 0.5 && point[1] == 0.5) {
                return 2.5;
            }
            return 4.0;
        };

        // Act
        simplex.iterate(mockFunction, mockComparator);

        // Assert
        PointValuePair newWorst = simplex.getPoint(2);
        assertEquals(2.5, newWorst.getValue());
        assertArrayEquals(new double[]{0.5, 0.5}, newWorst.getPoint());
    }

    @Test
    void testIterate_shrink() {
        // Arrange
        PointValuePair best = new PointValuePair(new double[]{0, 0}, 1.0, false);
        PointValuePair secondBest = new PointValuePair(new double[]{1, 0}, 2.0, false);
        PointValuePair worst = new PointValuePair(new double[]{2, 2}, 4.0, false);
        simplex.setPoint(0, best);
        simplex.setPoint(1, secondBest);
        simplex.setPoint(2, worst);

        mockFunction = point -> 4.0; // All points evaluate to worst value

        // Act
        simplex.iterate(mockFunction, mockComparator);

        // Assert
        for (int i = 1; i <= 2; i++) {
            PointValuePair point = simplex.getPoint(i);
            assertEquals(1.0, point.getValue());
            assertArrayEquals(new double[]{0 + 0.5 * (point.getPoint()[0] - 0),
                                          0 + 0.5 * (point.getPoint()[1] - 0)}, point.getPoint());
        }
    }

    @Test
    void testIterate_nullEvaluationFunction() {
        // Arrange
        Executable action = () -> simplex.iterate(null, mockComparator);

        // Act & Assert
        assertThrows(NullPointerException.class, action);
    }

    @Test
    void testIterate_nullComparator() {
        // Arrange
        Executable action = () -> simplex.iterate(mockFunction, null);

        // Act & Assert
        assertThrows(NullPointerException.class, action);
    }

    @Test
    void testIterate_singlePointSimplex() {
        // Arrange
        NelderMeadSimplex singlePointSimplex = new NelderMeadSimplex(new double[]{0, 0});
        singlePointSimplex.setPoint(0, new PointValuePair(new double[]{0, 0}, 1.0, false));
        mockFunction = point -> 1.0;

        // Act
        Executable action = () -> singlePointSimplex.iterate(mockFunction, mockComparator);

        // Assert
        assertThrows(IllegalArgumentException.class, action);
    }
}