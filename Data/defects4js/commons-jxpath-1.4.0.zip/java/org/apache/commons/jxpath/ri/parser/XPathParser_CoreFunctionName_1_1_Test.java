package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.apache.commons.jxpath.ri.parser.XPathParser;
import org.apache.commons.jxpath.ri.parser.ParseException;
import org.apache.commons.jxpath.ri.parser.Token;
import java.io.StringReader;

public class XPathParser_CoreFunctionName_1_1_Test {

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind set to an undefined value (-1) throws ParseException")
    public void TC33_CoreFunctionName_InvalidKindMinusOne_ThrowsParseException() throws Exception {
        // Arrange
        XPathParser parser = new XPathParser(new StringReader(""));
        parser.jj_nt.kind = -1;

        // Act & Assert
        assertThrows(ParseException.class, () -> parser.CoreFunctionName());
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind set to an undefined value (999) throws ParseException")
    public void TC34_CoreFunctionName_InvalidKind999_ThrowsParseException() throws Exception {
        // Arrange
        XPathParser parser = new XPathParser(new StringReader(""));
        parser.jj_nt.kind = 999;

        // Act & Assert
        assertThrows(ParseException.class, () -> parser.CoreFunctionName());
    }
}