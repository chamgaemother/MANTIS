package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_2_Test {

    @Test
    @DisplayName("doubleMetaphone encodes consecutive 'B's correctly in 'ABBey'")
    public void TC06_doubleMetaphone_consecutive_Bs_ABBey() throws Exception {
        // GIVEN
        String value = "ABBey";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("P"), "The encoded result should contain 'P'");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'CHURCH' correctly with 'CH' sequence")
    public void TC07_doubleMetaphone_CH_sequence_CHURCH() throws Exception {
        // GIVEN
        String value = "CHURCH";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("X") || result.contains("K"), "The encoded result should contain 'X' or 'K'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'C' followed by 'I' in 'CITY'")
    public void TC08_doubleMetaphone_CI_sequence_CITY() throws Exception {
        // GIVEN
        String value = "CITY";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("S") || result.contains("X"), "The encoded result should contain 'S' or 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'CC' followed by 'I' in 'BACCI'")
    public void TC09_doubleMetaphone_CC_sequence_BACCI() throws Exception {
        // GIVEN
        String value = "BACCI";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("X"), "The encoded result should contain 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'DG' followed by 'I' in 'EDGE'")
    public void TC10_doubleMetaphone_DG_sequence_EDGE() throws Exception {
        // GIVEN
        String value = "EDGE";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("J"), "The encoded result should contain 'J'");
    }
}