package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

public class DateUtils_iterator_0_2_Test {

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_CENTER and calendar on Monday")
    void TC06_iterator_RANGE_WEEK_CENTER_calendar_on_Monday() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.AUGUST);
        calendar.set(Calendar.DAY_OF_MONTH, 7); // Assuming August 7, 2023 is a Monday
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;

        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // Then
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Reflection to access the 'spot' field of DateIterator
        Field spotField = iterator.getClass().getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);

        Assertions.assertEquals(Calendar.MONDAY, spot.get(Calendar.DAY_OF_WEEK), "Start should be centered around Monday");
    }

    @Test
    @DisplayName("iterator with invalid rangeStyle throws IllegalArgumentException")
    void TC07_iterator_invalid_rangeStyle_throws_Exception() {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 10); // Any valid date
        int invalidRangeStyle = 999;

        // When & Then
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DateUtils.iterator(calendar, invalidRangeStyle);
        }, "Expected IllegalArgumentException for invalid rangeStyle");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_MONTH_SUNDAY and calendar already on cutoff Sunday")
    void TC08_iterator_RANGE_MONTH_SUNDAY_calendar_on_cutoff_Sunday() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 6); // Assuming August 6, 2023 is a Sunday at month start
        int rangeStyle = DateUtils.RANGE_MONTH_SUNDAY;

        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // Then
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Reflection to access the 'spot' field of DateIterator
        Field spotField = iterator.getClass().getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);

        Assertions.assertEquals(calendar.getTime(), spot.getTime(), "Start date should be unchanged when already on cutoff Sunday");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_MONDAY and calendar on Sunday requiring adjustment")
    void TC09_iterator_RANGE_WEEK_MONDAY_calendar_on_Sunday_requires_adjustment() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 6); // Assuming August 6, 2023 is a Sunday
        int rangeStyle = DateUtils.RANGE_WEEK_MONDAY;

        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // Then
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Reflection to access the 'spot' field of DateIterator
        Field spotField = iterator.getClass().getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);

        // The start should be the previous Monday
        Calendar expectedStart = (Calendar) calendar.clone();
        expectedStart.add(Calendar.DAY_OF_MONTH, -6);
        Assertions.assertEquals(expectedStart.getTime(), spot.getTime(), "Start date should be adjusted to the previous Monday");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_RELATIVE and cutoff adjustment required")
    void TC10_iterator_RANGE_WEEK_RELATIVE_cutoff_adjustment_required() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.AUGUST, 10); // A specific day needing cutoff adjustment
        int rangeStyle = DateUtils.RANGE_WEEK_RELATIVE;

        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // Then
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Reflection to access the start and end dates of DateIterator
        Field spotField = iterator.getClass().getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);

        Field endFinalField = iterator.getClass().getDeclaredField("endFinal");
        endFinalField.setAccessible(true);
        Calendar endFinal = (Calendar) endFinalField.get(iterator);

        // Add specific assertions based on expected adjustments
        // Example: Ensure that the start and end dates correctly reflect the cutoff
        Assertions.assertTrue(
                spot.get(Calendar.DAY_OF_WEEK) >= Calendar.SUNDAY && spot.get(Calendar.DAY_OF_WEEK) <= Calendar.SATURDAY,
                "Start cutoff should be within a valid week range");

        Assertions.assertTrue(
                endFinal.get(Calendar.DAY_OF_WEEK) >= Calendar.SUNDAY && endFinal.get(Calendar.DAY_OF_WEEK) <= Calendar.SATURDAY,
                "End cutoff should be within a valid week range");
    }
}