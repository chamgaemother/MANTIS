package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class XPathParser_NCName_0_2_Test {

    @Test
    @DisplayName("NCName() processes kind NODE and returns token image")
    public void TC06() throws Exception {
        // Initialize parser with mock constructor since no default constructor available
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Set jj_nt.kind to NODE
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, 48); // Assuming NODE has the integer value 48

        // Set token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "NODE_Image");

        // Call NCName
        String result = parser.NCName();

        // Assert the result
        assertEquals("NODE_Image", result);
    }

    @Test
    @DisplayName("NCName() processes kind TEXT and returns token image")
    public void TC07() throws Exception {
        // Initialize parser with mock constructor
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Set jj_nt.kind to TEXT
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, 49); // Assuming TEXT has the integer value 49

        // Set token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "TEXT_Image");

        // Call NCName
        String result = parser.NCName();

        // Assert the result
        assertEquals("TEXT_Image", result);
    }

    @Test
    @DisplayName("NCName() processes kind COMMENT and returns token image")
    public void TC08() throws Exception {
        // Initialize parser with mock constructor
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Set jj_nt.kind to COMMENT
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, 50); // Assuming COMMENT has the integer value 50

        // Set token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "COMMENT_Image");

        // Call NCName
        String result = parser.NCName();

        // Assert the result
        assertEquals("COMMENT_Image", result);
    }

    @Test
    @DisplayName("NCName() processes kind PI and returns token image")
    public void TC09() throws Exception {
        // Initialize parser with mock constructor
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Set jj_nt.kind to PI
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, 51); // Assuming PI has the integer value 51

        // Set token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "PI_Image");

        // Call NCName
        String result = parser.NCName();

        // Assert the result
        assertEquals("PI_Image", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_LAST and returns token image")
    public void TC10() throws Exception {
        // Initialize parser with mock constructor
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Set jj_nt.kind to FUNCTION_LAST
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, 53); // Assuming FUNCTION_LAST has the integer value 53

        // Set token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "FUNCTION_LAST_Image");

        // Call NCName
        String result = parser.NCName();

        // Assert the result
        assertEquals("FUNCTION_LAST_Image", result);
    }
}