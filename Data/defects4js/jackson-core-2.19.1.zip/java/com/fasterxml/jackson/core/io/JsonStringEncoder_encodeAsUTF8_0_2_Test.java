package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

public class JsonStringEncoder_encodeAsUTF8_0_2_Test {

    @Test
    @DisplayName("encodeAsUTF8 with single non-ASCII character requiring 3-byte encoding")
    void TC06_encodeAsUTF8_singleNonASCII_3Byte() {
        // GIVEN
        String text = "à¥";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().encodeAsUTF8(text);

        // THEN
        byte[] expected = {(byte)0xE0, (byte)0xA5, (byte)0x90};
        assertArrayEquals(expected, result, "The byte array does not match the expected 3-byte UTF-8 encoding.");
    }

    @Test
    @DisplayName("encodeAsUTF8 with single surrogate pair forming valid 4-byte character")
    void TC07_encodeAsUTF8_validSurrogatePair_4Byte() {
        // GIVEN
        // U+1F600 GRINNING FACE
        String text = "\uD83D\uDE00";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().encodeAsUTF8(text);

        // THEN
        byte[] expected = {(byte)0xF0, (byte)0x9F, (byte)0x98, (byte)0x80};
        assertArrayEquals(expected, result, "The byte array does not match the expected 4-byte UTF-8 encoding.");
    }

    @Test
    @DisplayName("encodeAsUTF8 with high surrogate not followed by low surrogate throws exception")
    void TC08_encodeAsUTF8_highSurrogateWithoutLowSurrogate_ThrowsException() {
        // GIVEN
        String text = "\uD800";

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            JsonStringEncoder.getInstance().encodeAsUTF8(text);
        }, "Expected encodeAsUTF8 to throw IllegalArgumentException for broken surrogate pair.");
    }

    @Test
    @DisplayName("encodeAsUTF8 with low surrogate without preceding high surrogate throws exception")
    void TC09_encodeAsUTF8_lowSurrogateWithoutHighSurrogate_ThrowsException() {
        // GIVEN
        String text = "\uDC00";

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            JsonStringEncoder.getInstance().encodeAsUTF8(text);
        }, "Expected encodeAsUTF8 to throw IllegalArgumentException for orphan low surrogate.");
    }

    @Test
    @DisplayName("encodeAsUTF8 with surrogate pair resulting in code point greater than 0x10FFFF throws exception")
    void TC10_encodeAsUTF8_invalidCodePoint_ThrowsException() {
        // GIVEN
        // Code point >0x10FFFF is not possible via valid surrogate pairs, simulate invalid input
        String text = "\uD83D\uDFFF";

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            JsonStringEncoder.getInstance().encodeAsUTF8(text);
        }, "Expected encodeAsUTF8 to throw IllegalArgumentException for code point exceeding 0x10FFFF.");
    }
}