package org.apache.commons.compress.harmony.pack200;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class BcBands_visitLdcInsn_0_1_Test {

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is true and constant is CPInt")
    void TC01() throws Exception {
        // Arrange
        CPBands mockCPBands = mock(CPBands.class);
        Segment mockSegment = mock(Segment.class);
        BcBands bcBands = new BcBands(mockCPBands, mockSegment, 0);

        // Mock behavior
        when(mockSegment.lastConstantHadWideIndex()).thenReturn(true);

        // Create CPInt constant
        CPInt cpIntConstant = new CPInt(123);
        when(mockCPBands.getConstant(any())).thenReturn(cpIntConstant);

        // Set initial byteCodeOffset and initialize lists with reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = new IntList();
        bcCodesField.set(bcBands, bcCodes);

        Field bcIntrefField = BcBands.class.getDeclaredField("bcIntref");
        bcIntrefField.setAccessible(true);
        List<CPInt> bcIntref = new ArrayList<>();
        bcIntrefField.set(bcBands, bcIntref);

        // Act
        bcBands.visitLdcInsn(cpIntConstant);

        // Assert
        assertEquals(3, byteCodeOffsetField.getInt(bcBands));
        assertEquals(237, bcCodes.get(0).intValue());
        assertEquals(cpIntConstant, bcIntref.get(0));
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is true and constant is CPFloat")
    void TC02() throws Exception {
        // Arrange 
        CPBands mockCPBands = mock(CPBands.class);
        Segment mockSegment = mock(Segment.class);
        BcBands bcBands = new BcBands(mockCPBands, mockSegment, 0);

        // Mock behavior
        when(mockSegment.lastConstantHadWideIndex()).thenReturn(true);

        // Create CPFloat constant
        CPFloat cpFloatConstant = new CPFloat(123.456f);
        when(mockCPBands.getConstant(any())).thenReturn(cpFloatConstant);

        // Set initial byteCodeOffset and initialize lists with reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = new IntList();
        bcCodesField.set(bcBands, bcCodes);

        Field bcFloatRefField = BcBands.class.getDeclaredField("bcFloatRef");
        bcFloatRefField.setAccessible(true);
        List<CPFloat> bcFloatRef = new ArrayList<>();
        bcFloatRefField.set(bcBands, bcFloatRef);

        // Act
        bcBands.visitLdcInsn(cpFloatConstant);

        // Assert
        assertEquals(3, byteCodeOffsetField.getInt(bcBands));
        assertEquals(238, bcCodes.get(0).intValue());
        assertEquals(cpFloatConstant, bcFloatRef.get(0));
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is true and constant is CPLong")
    void TC03() throws Exception {
        // Arrange
        CPBands mockCPBands = mock(CPBands.class);
        Segment mockSegment = mock(Segment.class);
        BcBands bcBands = new BcBands(mockCPBands, mockSegment, 0);

        // Mock behavior
        when(mockSegment.lastConstantHadWideIndex()).thenReturn(true);

        // Create CPLong constant
        CPLong cpLongConstant = new CPLong(123456789L);
        when(mockCPBands.getConstant(any())).thenReturn(cpLongConstant);

        // Set initial byteCodeOffset and initialize lists with reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = new IntList();
        bcCodesField.set(bcBands, bcCodes);

        Field bcLongRefField = BcBands.class.getDeclaredField("bcLongRef");
        bcLongRefField.setAccessible(true);
        List<CPLong> bcLongRef = new ArrayList<>();
        bcLongRefField.set(bcBands, bcLongRef);

        // Act
        bcBands.visitLdcInsn(cpLongConstant);

        // Assert
        assertEquals(3, byteCodeOffsetField.getInt(bcBands));
        assertEquals(20, bcCodes.get(0).intValue());
        assertEquals(cpLongConstant, bcLongRef.get(0));
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is true and constant is CPDouble")
    void TC04() throws Exception {
        // Arrange
        CPBands mockCPBands = mock(CPBands.class);
        Segment mockSegment = mock(Segment.class);
        BcBands bcBands = new BcBands(mockCPBands, mockSegment, 0);

        // Mock behavior
        when(mockSegment.lastConstantHadWideIndex()).thenReturn(true);

        // Create CPDouble constant
        CPDouble cpDoubleConstant = new CPDouble(123456.789);
        when(mockCPBands.getConstant(any())).thenReturn(cpDoubleConstant);

        // Set initial byteCodeOffset and initialize lists with reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = new IntList();
        bcCodesField.set(bcBands, bcCodes);

        Field bcDoubleRefField = BcBands.class.getDeclaredField("bcDoubleRef");
        bcDoubleRefField.setAccessible(true);
        List<CPDouble> bcDoubleRef = new ArrayList<>();
        bcDoubleRefField.set(bcBands, bcDoubleRef);

        // Act
        bcBands.visitLdcInsn(cpDoubleConstant);

        // Assert
        assertEquals(3, byteCodeOffsetField.getInt(bcBands));
        assertEquals(239, bcCodes.get(0).intValue());
        assertEquals(cpDoubleConstant, bcDoubleRef.get(0));
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is true and constant is CPString")
    void TC05() throws Exception {
        // Arrange
        CPBands mockCPBands = mock(CPBands.class);
        Segment mockSegment = mock(Segment.class);
        BcBands bcBands = new BcBands(mockCPBands, mockSegment, 0);

        // Mock behavior
        when(mockSegment.lastConstantHadWideIndex()).thenReturn(true);

        // Create CPString constant
        CPString cpStringConstant = new CPString("TestString");
        when(mockCPBands.getConstant(any())).thenReturn(cpStringConstant);

        // Set initial byteCodeOffset and initialize lists with reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = new IntList();
        bcCodesField.set(bcBands, bcCodes);

        Field bcStringRefField = BcBands.class.getDeclaredField("bcStringRef");
        bcStringRefField.setAccessible(true);
        List<CPString> bcStringRef = new ArrayList<>();
        bcStringRefField.set(bcBands, bcStringRef);

        // Act
        bcBands.visitLdcInsn(cpStringConstant);

        // Assert
        assertEquals(3, byteCodeOffsetField.getInt(bcBands));
        assertEquals(19, bcCodes.get(0).intValue());
        assertEquals(cpStringConstant, bcStringRef.get(0));
    }
}