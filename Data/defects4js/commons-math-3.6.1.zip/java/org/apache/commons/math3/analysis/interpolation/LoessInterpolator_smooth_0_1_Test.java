package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LoessInterpolator_smooth_0_1_Test {

    @Test
    @DisplayName("Throws DimensionMismatchException when xval and yval arrays have different lengths.")
    void TC01() throws Exception {
        // Arrange
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0};
        double[] weights = {1.0, 1.0};
        LoessInterpolator interpolator = new LoessInterpolator();

        // Act & Assert
        assertThrows(DimensionMismatchException.class, () -> interpolator.smooth(xval, yval, weights));
    }

    @Test
    @DisplayName("Throws NoDataException when input arrays are empty.")
    void TC02() throws Exception {
        // Arrange
        double[] xval = {};
        double[] yval = {};
        double[] weights = {};
        LoessInterpolator interpolator = new LoessInterpolator();

        // Act & Assert
        assertThrows(NoDataException.class, () -> interpolator.smooth(xval, yval, weights));
    }

    @Test
    @DisplayName("Returns single-element array when input arrays contain one element.")
    void TC03() throws Exception {
        // Arrange
        double[] xval = {1.0};
        double[] yval = {2.0};
        double[] weights = {1.0};
        LoessInterpolator interpolator = new LoessInterpolator();

        // Act
        double[] result = interpolator.smooth(xval, yval, weights);

        // Assert
        assertAll("Single-element array",
            () -> assertEquals(1, result.length, "Result array length should be 1"),
            () -> assertEquals(2.0, result[0], 1e-10, "Result array element should be equal to yval[0]")
        );
    }

    @Test
    @DisplayName("Returns two-element array when input arrays contain two elements.")
    void TC04() throws Exception {
        // Arrange
        double[] xval = {1.0, 2.0};
        double[] yval = {2.0, 3.0};
        double[] weights = {1.0, 1.0};
        LoessInterpolator interpolator = new LoessInterpolator();

        // Act
        double[] result = interpolator.smooth(xval, yval, weights);

        // Assert
        assertAll("Two-element array",
            () -> assertEquals(2, result.length, "Result array length should be 2"),
            () -> assertEquals(2.0, result[0], 1e-10, "First element should be equal to yval[0]"),
            () -> assertEquals(3.0, result[1], 1e-10, "Second element should be equal to yval[1]")
        );
    }

    @Test
    @DisplayName("Throws NumberIsTooSmallException when bandwidthInPoints is less than 2.")
    void TC05() throws Exception {
        // Arrange
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {2.0, 3.0, 4.0};
        double[] weights = {1.0, 1.0, 1.0};
        LoessInterpolator interpolator = new LoessInterpolator();

        // Use Reflection to set the private bandwidth field to 0.5
        java.lang.reflect.Field bandwidthField = LoessInterpolator.class.getDeclaredField("bandwidth");
        bandwidthField.setAccessible(true);
        bandwidthField.set(interpolator, 0.5);

        // Act & Assert
        assertThrows(NumberIsTooSmallException.class, () -> interpolator.smooth(xval, yval, weights));
    }

}