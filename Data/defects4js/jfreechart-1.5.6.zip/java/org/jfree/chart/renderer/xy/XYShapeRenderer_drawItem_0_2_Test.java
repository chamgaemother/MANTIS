package org.jfree.chart.renderer.xy;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.data.xy.XYDataset;
// import org.jfree.ui.RectangleEdge;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import java.awt.Graphics2D;
// import java.awt.Shape;
// import java.awt.geom.Line2D;
// import java.awt.geom.Rectangle2D;
// import java.lang.reflect.Field;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
public class XYShapeRenderer_drawItem_0_2_Test {
// 
//     @Test
//     @DisplayName("info is provided, pass=1, orientation is HORIZONTAL, shape intersects dataArea, drawOutlines=true, useOutlinePaint=true, entities is not null")
//     void TC06() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
// 
        // Use reflection to set private fields
//         setPrivateField(renderer, "drawOutlines", true);
//         setPrivateField(renderer, "useOutlinePaint", true);
//         setPrivateField(renderer, "guideLinesVisible", true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(plot);
//         when(plot.getEntityCollection()).thenReturn(entities);
// 
//         when(dataset.getXValue(0, 0)).thenReturn(10.0);
//         when(dataset.getYValue(0, 0)).thenReturn(20.0);
//         when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
//         Shape shape = mock(Shape.class);
//         when(renderer.getItemShape(0, 0)).thenReturn(shape);
//         when(shape.intersects(any(Rectangle2D.class))).thenReturn(true);
//         when(renderer.getPaint(dataset, 0, 0)).thenReturn(mock(java.awt.Paint.class));
//         when(renderer.getItemOutlinePaint(0, 0)).thenReturn(mock(java.awt.Paint.class));
//         when(renderer.getItemOutlineStroke(0, 0)).thenReturn(mock(java.awt.Stroke.class));
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         verify(g2).fill(shape);
//         verify(g2).setPaint(any(java.awt.Paint.class));
//         verify(g2).draw(shape);
//         verify(entities).add(any());
//     }
// 
//     @Test
//     @DisplayName("info is provided, pass=1, orientation is VERTICAL, shape intersects dataArea, drawOutlines=false, entities are null")
//     void TC07() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
// 
        // Use reflection to set private fields
//         setPrivateField(renderer, "guideLinesVisible", false);
//         setPrivateField(renderer, "drawOutlines", false);
//         setPrivateField(renderer, "useOutlinePaint", false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(info.getOwner()).thenReturn(plot);
//         when(plot.getEntityCollection()).thenReturn(null);
// 
//         when(dataset.getXValue(1, 1)).thenReturn(15.0);
//         when(dataset.getYValue(1, 1)).thenReturn(25.0);
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
//         when(rangeAxis.valueToJava2D(25.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         Shape shape = mock(Shape.class);
//         when(renderer.getItemShape(1, 1)).thenReturn(shape);
//         when(shape.intersects(any(Rectangle2D.class))).thenReturn(true);
//         when(renderer.getPaint(dataset, 1, 1)).thenReturn(mock(java.awt.Paint.class));
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 1);
// 
        // Assert
//         verify(g2).fill(shape);
//         verify(g2, never()).draw(shape);
//     }
// 
//     @Test
//     @DisplayName("info is provided, pass=1, shape does not intersect dataArea")
//     void TC08() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
// 
        // Use reflection to set private fields
//         setPrivateField(renderer, "guideLinesVisible", false);
//         setPrivateField(renderer, "drawOutlines", false);
//         setPrivateField(renderer, "useOutlinePaint", false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(info.getOwner()).thenReturn(plot);
// 
//         when(dataset.getXValue(2, 2)).thenReturn(20.0);
//         when(dataset.getYValue(2, 2)).thenReturn(30.0);
//         when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(30.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);
// 
//         Shape shape = mock(Shape.class);
//         when(renderer.getItemShape(2, 2)).thenReturn(shape);
//         when(shape.intersects(any(Rectangle2D.class))).thenReturn(false);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 2, 2, crosshairState, 1);
// 
        // Assert
//         verify(g2, never()).fill(shape);
//         verify(g2, never()).draw(shape);
//     }
// 
//     @Test
//     @DisplayName("info is provided, pass=1, orientation is HORIZONTAL, shape intersects, drawOutlines=true, useOutlinePaint=false, entities are null")
//     void TC09() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
// 
        // Use reflection to set private fields
//         setPrivateField(renderer, "guideLinesVisible", true);
//         setPrivateField(renderer, "drawOutlines", true);
//         setPrivateField(renderer, "useOutlinePaint", false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(info.getOwner()).thenReturn(plot);
//         when(plot.getEntityCollection()).thenReturn(null);
// 
//         when(dataset.getXValue(3, 3)).thenReturn(25.0);
//         when(dataset.getYValue(3, 3)).thenReturn(35.0);
//         when(domainAxis.valueToJava2D(25.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(250.0);
//         when(rangeAxis.valueToJava2D(35.0, dataArea, RectangleEdge.LEFT)).thenReturn(350.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
//         Shape shape = mock(Shape.class);
//         when(renderer.getItemShape(3, 3)).thenReturn(shape);
//         when(shape.intersects(any(Rectangle2D.class))).thenReturn(true);
//         when(renderer.getPaint(dataset, 3, 3)).thenReturn(mock(java.awt.Paint.class));
//         when(renderer.getItemPaint(3, 3)).thenReturn(mock(java.awt.Paint.class));
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 3, 3, crosshairState, 1);
// 
        // Assert
//         verify(g2).fill(shape);
//         verify(g2).setPaint(any(java.awt.Paint.class));
//         verify(g2).draw(shape);
//     }
// 
//     @Test
//     @DisplayName("info is provided, pass=0, guideLinesVisible=false, orientation is HORIZONTAL")
//     void TC10() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
// 
        // Use reflection to set private fields
//         setPrivateField(renderer, "guideLinesVisible", false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(info.getOwner()).thenReturn(plot);
//         when(plot.getEntityCollection()).thenReturn(null);
// 
//         when(dataset.getXValue(4, 4)).thenReturn(30.0);
//         when(dataset.getYValue(4, 4)).thenReturn(40.0);
//         when(domainAxis.valueToJava2D(30.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(300.0);
//         when(rangeAxis.valueToJava2D(40.0, dataArea, RectangleEdge.LEFT)).thenReturn(400.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 4, 4, crosshairState, 0);
// 
        // Assert
//         verify(g2, never()).fill(any());
//         verify(g2, never()).draw(any(Line2D.class));
//     }
// 
//     /**
//      * Utility method to set private fields via reflection.
//      */
//     private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
//         Field field = null;
//         Class<?> clazz = target.getClass();
//         while (clazz != null) {
//             try {
//                 field = clazz.getDeclaredField(fieldName);
//                 break;
//             } catch (NoSuchFieldException e) {
//                 clazz = clazz.getSuperclass();
//             }
//         }
//         if (field == null) {
//             throw new NoSuchFieldException("Field " + fieldName + " not found in class hierarchy.");
//         }
//         field.setAccessible(true);
//         field.set(target, value);
//     }
// }
}