package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.ri.parser.XPathParser;
import org.apache.commons.jxpath.ri.parser.Token;

import java.lang.reflect.Field;

public class XPathParser_NCName_0_5_Test {

    @Test
    @DisplayName("NCName() processes kind FUNCTION_CONTAINS and returns token image")
    public void TC21() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);
        Token token = new Token();

        // Set token.kind to FUNCTION_CONTAINS
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, XPathParser.FUNCTION_CONTAINS);

        // Set token.image to "contains"
        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "contains");

        // Set parser's jj_nt to token
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName()
        String result = parser.NCName();

        // Assert the result
        assertEquals("contains", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_SUBSTRING_BEFORE and returns token image")
    public void TC22() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);
        Token token = new Token();

        // Set token.kind to FUNCTION_SUBSTRING_BEFORE
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, XPathParser.FUNCTION_SUBSTRING_BEFORE);

        // Set token.image to "substring-before"
        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "substring-before");

        // Set parser's jj_nt to token
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName()
        String result = parser.NCName();

        // Assert the result
        assertEquals("substring-before", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_SUBSTRING_AFTER and returns token image")
    public void TC23() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);
        Token token = new Token();

        // Set token.kind to FUNCTION_SUBSTRING_AFTER
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, XPathParser.FUNCTION_SUBSTRING_AFTER);

        // Set token.image to "substring-after"
        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "substring-after");

        // Set parser's jj_nt to token
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName()
        String result = parser.NCName();

        // Assert the result
        assertEquals("substring-after", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_SUBSTRING and returns token image")
    public void TC24() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);
        Token token = new Token();

        // Set token.kind to FUNCTION_SUBSTRING
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, XPathParser.FUNCTION_SUBSTRING);

        // Set token.image to "substring"
        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "substring");

        // Set parser's jj_nt to token
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName()
        String result = parser.NCName();

        // Assert the result
        assertEquals("substring", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_STRING_LENGTH and returns token image")
    public void TC25() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);
        Token token = new Token();

        // Set token.kind to FUNCTION_STRING_LENGTH
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, XPathParser.FUNCTION_STRING_LENGTH);

        // Set token.image to "string-length"
        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "string-length");

        // Set parser's jj_nt to token
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName()
        String result = parser.NCName();

        // Assert the result
        assertEquals("string-length", result);
    }
}