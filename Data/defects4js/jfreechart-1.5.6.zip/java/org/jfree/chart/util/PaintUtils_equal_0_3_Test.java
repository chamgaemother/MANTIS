package org.jfree.chart.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Color;
import java.awt.LinearGradientPaint;
import java.awt.Paint;
import java.awt.RadialGradientPaint;
import java.awt.geom.Point2D;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class PaintUtils_equal_0_3_Test {

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with identical properties, expect true")
    void TC11() {
        // Given
        Point2D startPoint = new Point2D.Float(0, 0);
        Point2D endPoint = new Point2D.Float(1, 1);
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        LinearGradientPaint lgp1 = new LinearGradientPaint(startPoint, endPoint, fractions, colors);
        LinearGradientPaint lgp2 = new LinearGradientPaint(startPoint, endPoint, fractions, colors);

        // When
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with different start points, expect false")
    void TC12() {
        // Given
        Point2D startPoint1 = new Point2D.Float(0, 0);
        Point2D endPoint = new Point2D.Float(1, 1);
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        LinearGradientPaint lgp1 = new LinearGradientPaint(startPoint1, endPoint, fractions, colors);

        Point2D startPoint2 = new Point2D.Float(2, 2);
        LinearGradientPaint lgp2 = new LinearGradientPaint(startPoint2, endPoint, fractions, colors);

        // When
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with different fractions, expect false")
    void TC13() {
        // Given
        float[] fractions1 = {0.0f, 0.5f, 1.0f};
        float[] fractions2 = {0.0f, 0.6f, 1.0f};
        Point2D startPoint = new Point2D.Float(0, 0);
        Point2D endPoint = new Point2D.Float(1, 1);
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        LinearGradientPaint lgp1 = new LinearGradientPaint(startPoint, endPoint, fractions1, colors);
        LinearGradientPaint lgp2 = new LinearGradientPaint(startPoint, endPoint, fractions2, colors);

        // When
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with different colors, expect false")
    void TC14() {
        // Given
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors1 = {Color.RED, Color.GREEN, Color.BLUE};
        Color[] colors2 = {Color.RED, Color.YELLOW, Color.BLUE};
        Point2D startPoint = new Point2D.Float(0, 0);
        Point2D endPoint = new Point2D.Float(1, 1);
        LinearGradientPaint lgp1 = new LinearGradientPaint(startPoint, endPoint, fractions, colors1);
        LinearGradientPaint lgp2 = new LinearGradientPaint(startPoint, endPoint, fractions, colors2);

        // When
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are RadialGradientPaint instances with identical properties, expect true")
    void TC15() {
        // Given
        Point2D centerPoint = new Point2D.Float(0, 0);
        float radius = 1.0f;
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        RadialGradientPaint rgp1 = new RadialGradientPaint(centerPoint, radius, fractions, colors);
        RadialGradientPaint rgp2 = new RadialGradientPaint(centerPoint, radius, fractions, colors);

        // When
        boolean result = PaintUtils.equal(rgp1, rgp2);

        // Then
        assertTrue(result);
    }
}