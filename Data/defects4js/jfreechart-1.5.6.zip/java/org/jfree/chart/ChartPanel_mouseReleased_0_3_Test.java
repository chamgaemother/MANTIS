package org.jfree.chart;

import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import javax.swing.JPopupMenu;

import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseReleased_0_3_Test {

    @Test
    @DisplayName("mouseReleased with popup trigger activated but popup menu is null")
    void TC11_mouseReleased_PopupTrigger_Activated_PopupMenuNull() throws Exception {
        ChartPanel panel = spy(new ChartPanel(null));

        // Setup panel state
        setPrivateField(panel, "panLast", null);
        setPrivateField(panel, "zoomRectangle", null);
        setPrivateField(panel, "popup", null);

        MouseEvent event = mock(MouseEvent.class);
        when(event.isPopupTrigger()).thenReturn(true);

        panel.mouseReleased(event);

        // Ensure popup menu never gets called
        verify(panel, never()).displayPopupMenu(anyInt(), anyInt());
    }

    @Test
    @DisplayName("mouseReleased without popup trigger and no zoomRectangle, ensuring no action")
    void TC12_mouseReleased_NoPopupTrigger_NoZoomRectangle_NoAction() throws Exception {
        ChartPanel panel = spy(new ChartPanel(null));

        // Setup panel state
        setPrivateField(panel, "panLast", null);
        setPrivateField(panel, "zoomRectangle", null);
        setPrivateField(panel, "popup", mock(JPopupMenu.class));

        MouseEvent event = mock(MouseEvent.class);
        when(event.isPopupTrigger()).thenReturn(false);

        panel.mouseReleased(event);

        // Ensure popup menu never gets called
        verify(panel, never()).displayPopupMenu(anyInt(), anyInt());
    }

    @Test
    @DisplayName("mouseReleased with both panLast and zoomRectangle not null, ensuring pan takes precedence")
    void TC13_mouseReleased_PanAndZoomActive_PanPrecedence() throws Exception {
        ChartPanel panel = spy(new ChartPanel(null));

        // Setup panel state
        setPrivateField(panel, "panLast", new Point2D.Double(100, 100));
        setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(50, 50, 150, 150));

        MouseEvent event = mock(MouseEvent.class);

        panel.mouseReleased(event);

        // Ensure panLast is reset to null
        assertNull(getPrivateField(panel, "panLast"), "panLast should be reset to null");

        // Ensure cursor is set to default
        verify(panel).setCursor(Cursor.getDefaultCursor());

        // Ensure zoomRectangle remains unchanged
        assertNotNull(getPrivateField(panel, "zoomRectangle"), "zoomRectangle should remain unchanged");
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, zoomTrigger1 false, zoomTrigger2 true, zoom direction vertical")
    void TC14_mouseReleased_HorizontalOrientation_VerticalZoomTrigger() throws Exception {
        ChartPanel panel = spy(new ChartPanel(null));

        // Setup panel state
        setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(50, 50, 100, 100));
        setPrivateField(panel, "orientation", PlotOrientation.HORIZONTAL);
        setPrivateField(panel, "rangeZoomable", true);
        setPrivateField(panel, "domainZoomable", true);
        setPrivateField(panel, "zoomTriggerDistance", 10);

        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(55);
        when(event.getY()).thenReturn(70);
        when(event.isPopupTrigger()).thenReturn(false);

        setPrivateField(panel, "zoomPoint", new Point2D.Double(50, 50));

        Rectangle2D screenDataArea = new Rectangle2D.Double(0, 0, 200, 200);
        doReturn(screenDataArea).when(panel).getScreenDataArea(anyInt(), anyInt());

        panel.mouseReleased(event);

        verify(panel).zoom(any(Rectangle2D.class));

        assertNull(getPrivateField(panel, "zoomPoint"), "zoomPoint should be reset to null");
        assertNull(getPrivateField(panel, "zoomRectangle"), "zoomRectangle should be reset to null");
    }

//     @Test
//     @DisplayName("mouseReleased with zoomRectangle present, non-standard orientation, both zoomable false, no zoom triggered")
//     void TC15_mouseReleased_InvalidOrientation_NoZoomable_NoZoom() throws Exception {
//         ChartPanel panel = spy(new ChartPanel(null));
// 
        // Setup panel state
//         setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(50, 50, 100, 100));
//         setPrivateField(panel, "orientation", PlotOrientation.VERTICAL);
//         setPrivateField(panel, "rangeZoomable", false);
//         setPrivateField(panel, "domainZoomable", false);
// 
//         MouseEvent event = mock(MouseEvent.class);
//         when(event.isPopupTrigger()).thenReturn(false);
// 
//         setPrivateField(panel, "zoomPoint", new Point2D.Double(50, 50));
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         doNothing().when(panel).drawZoomRectangle(g2, true);
//         panel.mouseReleased(event);
// 
//         verify(panel, never()).zoom(any(Rectangle2D.class));
// 
//         verify(panel).drawZoomRectangle(any(Graphics2D.class), eq(true));
// 
//         assertNull(getPrivateField(panel, "zoomPoint"), "zoomPoint should be reset to null");
//         assertNull(getPrivateField(panel, "zoomRectangle"), "zoomRectangle should be reset to null");
//     }

    private void setPrivateField(Object object, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(object, value);
    }

    private Object getPrivateField(Object object, String fieldName) throws NoSuchFieldException, IllegalAccessException {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(object);
    }

}