package org.joda.time.tz;

import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ZoneInfoCompiler_parseDataFile_1_1_Test {

    @Test
    @DisplayName("parseDataFile processes a line without '#' and without matching any lookup, resulting in 'Unknown line' message")
    void TC25_parseDataFile_UnknownLine() throws Exception {
        // Arrange
        BufferedReader in = new BufferedReader(new StringReader("UnknownToken data"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Capture System.out
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        try {
            // Act
            compiler.parseDataFile(in, z9);
        } finally {
            // Restore System.out
            System.setOut(originalOut);
        }

        // Assert
        String output = outContent.toString();
        assertTrue(output.contains("Unknown line"), "Expected unknown line message not found in output.");

        // Access iZones via reflection
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<?> iZones = (List<?>) iZonesField.get(compiler);
        assertTrue(iZones.isEmpty(), "iZones should remain empty.");
        
        // Access iRuleSets via reflection
        Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
        iRuleSetsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, ?> iRuleSets = (Map<String, ?>) iRuleSetsField.get(compiler);
        assertTrue(iRuleSets.isEmpty(), "iRuleSets should remain empty.");
    }

//     @Test
//     @DisplayName("parseDataFile processes a RULE_LOOKUP line with short alias 'r'")
//     void TC26_parseDataFile_RuleLookupShortAlias() throws Exception {
        // Arrange
//         BufferedReader in = new BufferedReader(new StringReader("rule summer 1970 max - Mar 21 2:00 1:00 S"));
//         boolean z9 = false;
//         ZoneInfoCompiler compiler = new ZoneInfoCompiler();
// 
        // Act
//         compiler.parseDataFile(in, z9);
// 
        // Access iRuleSets via reflection
//         Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
//         iRuleSetsField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Map<String, ZoneInfoCompiler.RuleSet> iRuleSets = (Map<String, ZoneInfoCompiler.RuleSet>) iRuleSetsField.get(compiler);
//         
//         assertTrue(iRuleSets.containsKey("summer"), "iRuleSets should contain the rule set 'summer'.");
//         ZoneInfoCompiler.RuleSet ruleSet = iRuleSets.get("summer");
//         assertNotNull(ruleSet, "RuleSet 'summer' should not be null.");
//         assertEquals(1, ruleSet.iRules.size(), "RuleSet 'summer' should contain one rule.");
//         assertEquals("summer", ruleSet.iRules.get(0).iName, "Rule name should be 'summer'.");
//     }

    @Test
    @DisplayName("parseDataFile processes LINK_LOOKUP with alias 'XYZ' not in special cases")
    void TC27_parseDataFile_LinkLookupAliasXYZ() throws Exception {
        // Arrange
        BufferedReader in = new BufferedReader(new StringReader("link RealXYZ XYZ"));
        boolean z9 = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Act
        compiler.parseDataFile(in, z9);

        // Access iGoodLinks via reflection
        Field iGoodLinksField = ZoneInfoCompiler.class.getDeclaredField("iGoodLinks");
        iGoodLinksField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> iGoodLinks = (List<String>) iGoodLinksField.get(compiler);

        assertTrue(iGoodLinks.contains("RealXYZ"), "iGoodLinks should contain 'RealXYZ'.");
        assertTrue(iGoodLinks.contains("XYZ"), "iGoodLinks should contain 'XYZ'.");
    }
}