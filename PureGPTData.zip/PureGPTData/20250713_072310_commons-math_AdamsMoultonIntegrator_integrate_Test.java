import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.apache.commons.math3.ode.nonstiff.AdamsMoultonIntegrator;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import static org.junit.jupiter.api.Assertions.*;

public class AdamsMoultonIntegratorTest {

    private static class TestODE implements FirstOrderDifferentialEquations {
        private final int dimension;

        public TestODE(int dimension) {
            this.dimension = dimension;
        }

        @Override
        public int getDimension() {
            return dimension;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            for (int i = 0; i < y.length; i++) {
                yDot[i] = y[i];
            }
        }
    }

    @Test
    void testNullODE() {
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(3, 0.1, 1.0, 1e-6, 1e-6);
        Executable exec = () -> integrator.integrate(null, 1.0);
        assertThrows(NullPointerException.class, exec);
    }

    @Test
    void testNegativeTime() {
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(3, 0.1, 1.0, 1e-6, 1e-6);
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new TestODE(2));
        ode.setTime(-1.0);
        ode.setPrimaryState(new double[]{1.0, 0.0});

        Executable exec = () -> integrator.integrate(ode, 0.0);
        assertThrows(IllegalArgumentException.class, exec);
    }

    @Test
    void testValidIntegrationForward() {
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(3, 0.1, 1.0, 1e-6, 1e-6);
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new TestODE(2));
        ode.setTime(0.0);
        ode.setPrimaryState(new double[]{1.0, 0.0});
        
        integrator.integrate(ode, 1.0);
        
        double[] state = ode.getPrimaryState();
        assertNotNull(state);
        assertEquals(2, state.length);
        assertTrue(state[0] > 1.0 && state[1] > 0.0);
    }

    @Test
    void testValidIntegrationBackward() {
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(3, 0.1, 1.0, 1e-6, 1e-6);
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new TestODE(2));
        ode.setTime(1.0);
        ode.setPrimaryState(new double[]{1.0, 0.0});

        integrator.integrate(ode, 0.0);
        
        double[] state = ode.getPrimaryState();
        assertNotNull(state);
        assertEquals(2, state.length);
        assertTrue(state[0] < 1.0 && state[1] < 0.0);
    }

    @Test
    void testStepSizeControl() {
        int order = 3;
        double minStep = 0.001;
        double maxStep = 0.1;
        double tol = 1e-6;
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(order, minStep, maxStep, tol, tol);
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new TestODE(2));
        ode.setTime(0.0);
        ode.setPrimaryState(new double[]{1.0, 0.0});
        
        integrator.integrate(ode, 1.0);
        
        double[] state = ode.getPrimaryState();
        assertNotNull(state);
        assertEquals(2, state.length);
        assertTrue(state[0] > 1.0 && state[1] > 0.0);
    }

    @Test
    void testDimensionMismatch() {
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(3, 0.1, 1.0, 1e-6, 1e-6);
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new TestODE(3));
        ode.setTime(0.0);
        ode.setPrimaryState(new double[]{1.0, 0.0, 0.0});

        ode.getSecondaryMappers().add(new EquationsMapper(1, 0) {
            @Override
            public void insertEquationData(double[] state, double[] equationData) {
            }

            @Override
            public void extractEquationData(double[] equationData, double[] state) {
            }
        });

        Executable exec = () -> integrator.integrate(ode, 1.0);
        assertThrows(DimensionMismatchException.class, exec);
    }

    @Test
    void testSmallStepSize() {
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(2, 1e-10, 1e-5, 1e-10, 1e-10);
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new TestODE(2));
        ode.setTime(0.0);
        ode.setPrimaryState(new double[]{1.0, 0.0});

        integrator.integrate(ode, 1.0);

        double[] state = ode.getPrimaryState();
        assertNotNull(state);
        assertEquals(2, state.length);
        assertTrue(state[0] > 1.0 && state[1] > 0.0);
    }

    @Test
    void testNoSolutionExceptionHandling() {
        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(3, 0.1, 1.0, 1e-6, 1e-6);
        ExpandableStatefulODE ode = new ExpandableStatefulODE(new TestODE(2));
        ode.setTime(0.0);
        ode.setPrimaryState(new double[]{0.0, 0.0});

        Executable exec = () -> integrator.integrate(ode, Double.NaN);
        assertThrows(MaxCountExceededException.class, exec);
    }
}