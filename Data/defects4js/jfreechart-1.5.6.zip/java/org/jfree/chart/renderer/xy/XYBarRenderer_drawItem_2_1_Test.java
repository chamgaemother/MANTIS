package org.jfree.chart.renderer.xy;

import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class XYBarRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("TC03: drawItem handles case when both y0 and y1 are NaN, resulting in early return")
    void testDrawItem_BothY0_Y1_NaN() {
        // Given
        XYBarRenderer renderer = spy(new XYBarRenderer());
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = new CrosshairState();

        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(true);
        when(dataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(0, 0)).thenReturn(Double.NaN);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 1);

        // Then
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("TC04: drawItem handles case when y0 equals y1, rendering a bar of zero height")
    void testDrawItem_Y0_Equals_Y1_ZeroHeight() {
        // Given
        XYBarRenderer renderer = spy(new XYBarRenderer());
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = new CrosshairState();

        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(true);
        when(dataset.getStartYValue(0, 0)).thenReturn(10.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(10.0);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 1);

        // Then
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), any(RectangleEdge.class));
        // Optionally verify that the bar has zero height
    }

    @Test
    @DisplayName("TC05: drawItem processes when y0 is greater than y1, correctly determining bar orientation")
    void testDrawItem_Y0_Greater_Y1_Orientation() {
        // Given
        XYBarRenderer renderer = spy(new XYBarRenderer());
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = new CrosshairState();

        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(true);
        when(dataset.getStartYValue(0, 0)).thenReturn(20.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(10.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(20.0, dataArea, any(RectangleEdge.class))).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, any(RectangleEdge.class))).thenReturn(100.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, any(RectangleEdge.class))).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, any(RectangleEdge.class))).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getMargin()).thenReturn(0.1);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 1);

        // Then
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), eq(RectangleEdge.BOTTOM));
    }

    @Test
    @DisplayName("TC06: drawItem handles plot orientation as VERTICAL and y1 positive")
    void testDrawItem_Vertical_Orientation_Y1_Positive() {
        // Given
        XYBarRenderer renderer = spy(new XYBarRenderer());
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = new CrosshairState();

        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(true);
        when(dataset.getStartYValue(0, 0)).thenReturn(5.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(15.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(5.0, dataArea, any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, any(RectangleEdge.class))).thenReturn(150.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, any(RectangleEdge.class))).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, any(RectangleEdge.class))).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getMargin()).thenReturn(0.1);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 1);

        // Then
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), eq(RectangleEdge.BOTTOM));
    }

    @Test
    @DisplayName("TC07: drawItem handles plot orientation as HORIZONTAL and y1 negative with inverted axis")
    void testDrawItem_Horizontal_Orientation_Y1_Negative_InvertedAxis() {
        // Given
        XYBarRenderer renderer = spy(new XYBarRenderer());
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = new CrosshairState();

        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(true);
        when(dataset.getStartYValue(0, 0)).thenReturn(10.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(-5.0);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(rangeAxis.valueToJava2D(10.0, dataArea, any(RectangleEdge.class))).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(-5.0, dataArea, any(RectangleEdge.class))).thenReturn(50.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, any(RectangleEdge.class))).thenReturn(30.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, any(RectangleEdge.class))).thenReturn(60.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getMargin()).thenReturn(0.2);
        when(renderer.getShadowsVisible()).thenReturn(false);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, 0, 0, crosshairState, 1);

        // Then
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), eq(RectangleEdge.LEFT));
    }
}