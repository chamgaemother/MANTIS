package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.Shape;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.XYStepAreaRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class XYStepAreaRenderer_drawItem_1_3_Test {

    @Test
    @DisplayName("drawItem with plotArea disabled")
    void TC11_drawItem_with_plotArea_disabled() throws Exception {
        // Arrange
        XYStepAreaRenderer renderer = new XYStepAreaRenderer();
        renderer.setPlotArea(false);

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        when(dataset.getItemCount(series)).thenReturn(10);
        when(dataset.getYValue(series, item)).thenReturn(140.0);

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("drawItem with rangeBase set to a specific value")
    void TC12_drawItem_with_specific_rangeBase() throws Exception {
        // Arrange
        XYStepAreaRenderer renderer = new XYStepAreaRenderer();
        renderer.setRangeBase(50.0);

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 2;
        when(dataset.getItemCount(series)).thenReturn(10);
        when(dataset.getYValue(series, item)).thenReturn(160.0);

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(50.0, any(Rectangle2D.class), any())).thenReturn(300.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer, times(1)).getRangeBase();
        assertEquals(50.0, renderer.getRangeBase(), 0.001);
        // Additional assertions can be added here to ensure area base aligns with rangeBase
    }

    @Test
    @DisplayName("drawItem triggers RendererChangeEvent when setting plotArea")
    void TC13_drawItem_RendererChangeEvent_on_plotArea_change() throws Exception {
        // Arrange
        XYStepAreaRenderer renderer = new XYStepAreaRenderer();
        RendererChangeListener listener = mock(RendererChangeListener.class);
        renderer.addChangeListener(listener);

        // Act
        renderer.setPlotArea(true);
        renderer.setPlotArea(false);

        // Assert
        verify(listener, times(1)).rendererChanged(any(RendererChangeEvent.class));
    }

    @Test
    @DisplayName("drawItem with restrictValueToDataArea limiting transY1 below minimum")
    void TC14_drawItem_transY1_below_dataArea_minimum() throws Exception {
        // Arrange
        XYStepAreaRenderer renderer = new XYStepAreaRenderer();

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 3;
        when(dataset.getItemCount(series)).thenReturn(10);
        when(dataset.getYValue(series, item)).thenReturn(-10.0);

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(Mockito.eq(-10.0), any(Rectangle2D.class), any())).thenReturn(-50.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        double limitedY = XYStepAreaRenderer.restrictValueToDataArea(-10.0, plot, dataArea);
        assertEquals(dataArea.getMinY(), limitedY, 0.001);
    }

    @Test
    @DisplayName("drawItem with restrictValueToDataArea limiting transY1 above maximum")
    void TC15_drawItem_transY1_above_dataArea_maximum() throws Exception {
        // Arrange
        XYStepAreaRenderer renderer = new XYStepAreaRenderer();

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 4;
        when(dataset.getItemCount(series)).thenReturn(10);
        when(dataset.getYValue(series, item)).thenReturn(700.0);

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(Mockito.eq(700.0), any(Rectangle2D.class), any())).thenReturn(650.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        double limitedY = XYStepAreaRenderer.restrictValueToDataArea(700.0, plot, dataArea);
        assertEquals(dataArea.getMaxY(), limitedY, 0.001);
    }
}