import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.Title;
import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.util.XYCoordinateType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class XYTitleAnnotationTest {

    @Mock private Graphics2D g2;
    @Mock private XYPlot plot;
    @Mock private Rectangle2D dataArea;
    @Mock private ValueAxis domainAxis;
    @Mock private ValueAxis rangeAxis;
    @Mock private PlotRenderingInfo info;
    @Mock private Title title;

    private XYTitleAnnotation annotation;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisLocation()).thenReturn(AxisLocation.BOTTOM_OR_LEFT);
        when(plot.getRangeAxisLocation()).thenReturn(AxisLocation.BOTTOM_OR_LEFT);
        
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 5.0));
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 5.0));
        
        when(domainAxis.valueToJava2D(0.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(0.0);
        
        annotation = new XYTitleAnnotation(0.5, 0.5, title, RectangleAnchor.CENTER);
    }

    @Test
    public void testDrawRelativeCoordinateNoMaxWidthHeight() {
        assertDoesNotThrow(() -> annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 0, info));
    }

    @Test
    public void testDrawDataCoordinateWithMaxWidthHeight() {
        annotation = new XYTitleAnnotation(2.5, 2.5, title, RectangleAnchor.CENTER);
        when(domainAxis.valueToJava2D(2.5, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(2.5, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        annotation.setMaxWidth(100.0);
        annotation.setMaxHeight(100.0);
        assertDoesNotThrow(() -> annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 0, info));
    }
    
    @Test
    public void testDrawHorizontalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        assertDoesNotThrow(() -> annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 0, info));
    }
    
    @Test
    public void testDrawWithNullInfo() {
        assertDoesNotThrow(() -> annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 0, null));
    }
}