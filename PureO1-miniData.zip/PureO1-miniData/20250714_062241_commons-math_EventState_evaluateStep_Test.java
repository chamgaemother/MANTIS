import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.solvers.*;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.events.EventHandler;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class EventStateTest {

    private EventHandler handler;
    private UnivariateSolver solver;
    private ExpandableStatefulODE expandable;
    private EventState eventState;
    private StepInterpolator interpolator;

    private final double maxCheckInterval = 1.0;
    private final double convergence = 1e-6;
    private final int maxIterationCount = 100;

    @BeforeEach
    public void setUp() {
        handler = mock(EventHandler.class);
        solver = mock(UnivariateSolver.class);
        expandable = mock(ExpandableStatefulODE.class);
        interpolator = mock(StepInterpolator.class);
        eventState = new EventState(handler, maxCheckInterval, convergence, maxIterationCount, solver);
        eventState.setExpandable(expandable);
    }

    @Test
    public void testEvaluateStep_NullInterpolator() {
        assertThrows(NullPointerException.class, () -> eventState.evaluateStep(null));
    }

    @Test
    public void testEvaluateStep_StepSizeBelowConvergence() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1e-7);
        when(interpolator.isForward()).thenReturn(true);
        when(handler.g(anyDouble(), any())).thenReturn(1.0);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
    }

    @Test
    public void testEvaluateStep_NoSignChange() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        when(handler.g(anyDouble(), any())).thenReturn(1.0);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);
        when(handler.g(anyDouble(), any())).thenReturn(1.0);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
    }

    @Test
    public void testEvaluateStep_SignChangeSingleSubstep() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);
        when(handler.g(0.0, state)).thenReturn(1.0);
        when(handler.g(2.0, state)).thenReturn(-1.0);
        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(2.0), any()))
            .thenReturn(1.0);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertEquals(1.0, eventState.getEventTime(), 1e-12);
    }

    @Test
    public void testEvaluateStep_SignChangeMultipleSubsteps() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(3.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);

        when(handler.g(0.0, state)).thenReturn(1.0);
        when(handler.g(1.0, state)).thenReturn(-1.0);
        when(handler.g(2.0, state)).thenReturn(1.0);
        when(handler.g(3.0, state)).thenReturn(-1.0);

        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(1.0), any()))
            .thenReturn(0.5);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertEquals(0.5, eventState.getEventTime(), 1e-12);
    }

    @Test
    public void testEvaluateStep_RootNearPreviousEvent_ShouldSkip() throws Exception {
        // Setup previousEventTime close to root
        // First event at 1.0
        // Next event attempt at 1.000001 which should be skipped
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);

        when(handler.g(0.0, state)).thenReturn(1.0);
        when(handler.g(1.0, state)).thenReturn(-1.0);
        when(handler.g(2.0, state)).thenReturn(1.0);

        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(2.0), any()))
            .thenReturn(1.0);

        eventState.reinitializeBegin(interpolator);
        boolean firstResult = eventState.evaluateStep(interpolator);
        assertTrue(firstResult);
        assertEquals(1.0, eventState.getEventTime(), 1e-12);

        // Simulate step acceptance
        when(handler.eventOccurred(eq(1.0), any(), anyBoolean()))
            .thenReturn(EventHandler.Action.CONTINUE);
        eventState.stepAccepted(1.0, state);

        // Next evaluate step with event time very close to previous
        when(handler.g(1.000001, state)).thenReturn(-1.0);
        when(handler.g(2.0, state)).thenReturn(1.0);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(1.0), eq(2.0), any()))
            .thenReturn(1.000001);

        boolean secondResult = eventState.evaluateStep(interpolator);
        assertTrue(secondResult);
        assertEquals(1.000001, eventState.getEventTime(), 1e-12);
    }

    @Test
    public void testEvaluateStep_HandlerGZeroAtStart() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(1.0);
        when(interpolator.getCurrentTime()).thenReturn(3.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);

        // g(t0) = 0
        when(handler.g(1.0, state)).thenReturn(0.0);
        // After epsilon
        double epsilon = Math.max(solver.getAbsoluteAccuracy(), Math.abs(solver.getRelativeAccuracy() * 1.0));
        double tStart = 1.0 + 0.5 * epsilon;
        when(handler.g(tStart, state)).thenReturn(1.0);

        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        // No sign change after adjustment
        assertFalse(result);
    }

    @Test
    public void testEvaluateStep_SolverThrowsNoBracketingException() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);

        when(handler.g(0.0, state)).thenReturn(1.0);
        when(handler.g(2.0, state)).thenReturn(-1.0);

        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(2.0), any()))
            .thenThrow(new NoBracketingException(0.0, 2.0, 0.5));

        eventState.reinitializeBegin(interpolator);
        assertThrows(NoBracketingException.class, () -> eventState.evaluateStep(interpolator));
    }

    @Test
    public void testEvaluateStep_SolverThrowsMaxCountExceededException() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);

        when(handler.g(0.0, state)).thenReturn(1.0);
        when(handler.g(2.0, state)).thenReturn(-1.0);

        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(2.0), any()))
            .thenThrow(new MaxCountExceededException(maxIterationCount, 0));

        eventState.reinitializeBegin(interpolator);
        assertThrows(MaxCountExceededException.class, () -> eventState.evaluateStep(interpolator));
    }

    @Test
    public void testEvaluateStep_SolverIsNotBracketedSolver() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);

        when(handler.g(0.0, state)).thenReturn(1.0);
        when(handler.g(2.0, state)).thenReturn(-1.0);

        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(2.0)))
            .thenReturn(1.0);

        // Mock that solver is not a BracketedUnivariateSolver
        when(solver instanceof BracketedUnivariateSolver<?>).thenReturn(false);
        BracketedUnivariateSolver<?> bracketedSolver = mock(PegasusSolver.class);
        whenNew(PegasusSolver.class).withAnyArguments().thenReturn(bracketedSolver);
        when(bracketedSolver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble(), any()))
            .thenReturn(1.0);
        when(bracketedSolver.getRelativeAccuracy()).thenReturn(1e-6);
        when(bracketedSolver.getAbsoluteAccuracy()).thenReturn(1e-6);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertEquals(1.0, eventState.getEventTime(), 1e-12);
    }

    @Test
    public void testGetEventTime_NoPendingEvent() {
        assertEquals(Double.POSITIVE_INFINITY, eventState.getEventTime());
    }

    @Test
    public void testEvaluateStep_PendingEventFalseAfterNoEvent() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);
        when(handler.g(anyDouble(), any())).thenReturn(1.0);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertFalse(result);
        assertFalse(eventState.pendingEvent);
        assertTrue(Double.isNaN(eventState.pendingEventTime));
    }

    @Test
    public void testEvaluateStep_IncreasingFalse() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);
        when(handler.g(0.0, state)).thenReturn(-1.0);
        when(handler.g(2.0, state)).thenReturn(1.0);
        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(2.0), any()))
            .thenReturn(1.0);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertTrue(eventState.increasing);
    }

    @Test
    public void testEvaluateStep_ResetEvent() throws Exception {
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);
        when(handler.g(0.0, state)).thenReturn(1.0);
        when(handler.g(2.0, state)).thenReturn(-1.0);
        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(2.0), any()))
            .thenReturn(1.0);
        when(handler.eventOccurred(eq(1.0), eq(state), anyBoolean()))
            .thenReturn(EventHandler.Action.RESET_STATE);

        eventState.reinitializeBegin(interpolator);
        boolean result = eventState.evaluateStep(interpolator);
        assertTrue(result);
        assertEquals(1.0, eventState.getEventTime(), 1e-12);

        // Simulate step acceptance
        eventState.stepAccepted(1.0, state);
        assertEquals(EventHandler.Action.RESET_STATE, eventState.nextAction);
    }

    @Test
    public void testEvaluateStep_PreviousEventTimeNotClose() throws Exception {
        // Previous event was far from current root
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(3.0);
        when(interpolator.isForward()).thenReturn(true);
        double[] state = new double[] {1.0};
        when(interpolator.getInterpolatedState()).thenReturn(state);
        when(handler.g(anyDouble(), any())).thenReturn(1.0, -1.0, 1.0, -1.0);
        when(solver.getAbsoluteAccuracy()).thenReturn(1e-6);
        when(solver.getRelativeAccuracy()).thenReturn(1e-6);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(0.0), eq(3.0), any()))
            .thenReturn(1.0);

        eventState.reinitializeBegin(interpolator);
        boolean firstResult = eventState.evaluateStep(interpolator);
        assertTrue(firstResult);
        assertEquals(1.0, eventState.getEventTime(), 1e-12);

        // Simulate step acceptance with distant previousEventTime
        when(handler.eventOccurred(eq(1.0), eq(state), anyBoolean()))
            .thenReturn(EventHandler.Action.CONTINUE);
        eventState.stepAccepted(1.0, state);

        // Next step with another event far from previous
        when(handler.g(anyDouble(), any())).thenReturn(1.0, -1.0);
        when(solver.solve(eq(maxIterationCount), any(UnivariateFunction.class), eq(1.0), eq(3.0), any()))
            .thenReturn(2.0);

        boolean secondResult = eventState.evaluateStep(interpolator);
        assertTrue(secondResult);
        assertEquals(2.0, eventState.getEventTime(), 1e-12);
    }
}