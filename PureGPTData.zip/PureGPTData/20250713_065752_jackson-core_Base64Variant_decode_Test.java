import com.fasterxml.jackson.core.Base64Variant;
import com.fasterxml.jackson.core.Base64Variants;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Base64VariantTest {

    private final Base64Variant MIME_VARIANT = Base64Variants.MIME;

    @Test
    public void testDecodeValidBase64String() {
        ByteArrayBuilder builder = new ByteArrayBuilder();
        assertDoesNotThrow(() -> MIME_VARIANT.decode("TWFu", builder));
        byte[] result = builder.toByteArray();
        assertArrayEquals(new byte[] {'M', 'a', 'n'}, result);
    }

    @Test
    public void testDecodeValidBase64StringWithPadding() {
        ByteArrayBuilder builder = new ByteArrayBuilder();
        assertDoesNotThrow(() -> MIME_VARIANT.decode("TWE=", builder));
        byte[] result = builder.toByteArray();
        assertArrayEquals(new byte[] {'M', 'a'}, result);
    }

    @Test
    public void testDecodeValidBase64StringWithoutPadding() {
        Base64Variant variantNoPadding = MIME_VARIANT.withPaddingAllowed();
        ByteArrayBuilder builder = new ByteArrayBuilder();
        assertDoesNotThrow(() -> variantNoPadding.decode("TWFu", builder));
        byte[] result = builder.toByteArray();
        assertArrayEquals(new byte[] {'M', 'a', 'n'}, result);
    }

    @Test
    public void testDecodeWithUnexpectedPadding() {
        Base64Variant variantNoPadding = MIME_VARIANT.withPaddingForbidden();
        ByteArrayBuilder builder = new ByteArrayBuilder();
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class, () -> variantNoPadding.decode("TWFu=", builder)
        );
        assertTrue(exception.getMessage().contains("Unexpected end"));
    }

    @Test
    public void testDecodeWithMissingPaddingOnRequired() {
        Base64Variant variantWithRequiredPadding = MIME_VARIANT.withPaddingRequired();
        ByteArrayBuilder builder = new ByteArrayBuilder();
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class, () -> variantWithRequiredPadding.decode("TWE", builder)
        );
        assertTrue(exception.getMessage().contains("Unexpected end"));
    }

    @Test
    public void testDecodeInvalidBase64Character() {
        ByteArrayBuilder builder = new ByteArrayBuilder();
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class, () -> MIME_VARIANT.decode("TW@u", builder)
        );
        assertTrue(exception.getMessage().contains("Illegal character"));
    }

    @Test
    public void testDecodeEndsWithWhiteSpace() {
        ByteArrayBuilder builder = new ByteArrayBuilder();
        assertDoesNotThrow(() -> MIME_VARIANT.decode("TWFu\n", builder));
        byte[] result = builder.toByteArray();
        assertArrayEquals(new byte[] {'M', 'a', 'n'}, result);
    }

    @Test
    public void testDecodeEmptyString() {
        ByteArrayBuilder builder = new ByteArrayBuilder();
        assertDoesNotThrow(() -> MIME_VARIANT.decode("", builder));
        byte[] result = builder.toByteArray();
        assertArrayEquals(new byte[] {}, result);
    }

    @Test
    public void testDecodeNullString() {
        Base64Variant variant = Base64Variants.MIME;
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class, () -> variant.decode(null, new ByteArrayBuilder())
        );
        assertTrue(exception.getMessage().contains("Unexpected end"));
    }
}