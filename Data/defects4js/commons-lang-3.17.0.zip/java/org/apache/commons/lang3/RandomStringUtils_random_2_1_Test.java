
package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

public class RandomStringUtils_random_2_1_Test {

    @Test
    @DisplayName("random(count, start=20, end=10, letters=true, numbers=true, chars=null, random) throws IllegalArgumentException when end <= start")
    void TC06_invalid_end_less_than_start() {
        // Given
        int count = 5;
        int start = 20;
        int end = 10;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // When & Then
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils utils = new RandomStringUtils();
            utils.random(count, start, end, letters, numbers, chars, random);
        });
        assertEquals("Parameter end (10) must be greater than start (20)", exception.getMessage());
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=empty array, random) throws IllegalArgumentException when chars array is empty")
    void TC07_empty_chars_array() {
        // Given
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = new char[0];
        Random random = new Random();

        // When & Then
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils utils = new RandomStringUtils();
            utils.random(count, start, end, letters, numbers, chars, random);
        });
        assertEquals("The chars array must not be empty", exception.getMessage());
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=null, random) throws IllegalArgumentException when end <= ASCII for letters")
    void TC08_invalid_end_for_letters_and_numbers() {
        // Given
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // When & Then
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils utils = new RandomStringUtils();
            utils.random(count, start, end, letters, numbers, chars, random);
        });
        assertTrue(exception.getMessage().contains("must be greater then (48) for generating digits or greater then (65) for generating letters."));
    }

    @Test
    @DisplayName("random(count, start=50, end=100, letters=false, numbers=false, chars=null, random) throws IllegalArgumentException when range is insufficient for numbers and letters")
    void TC09_insufficient_range_for_letters_and_numbers() {
        // Given
        int count = 5;
        int start = 50;
        int end = 100;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // When & Then
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils utils = new RandomStringUtils();
            utils.random(count, start, end, letters, numbers, chars, random);
        });
        assertTrue(exception.getMessage().toLowerCase().contains("invalid character positions"), "Expected message related to invalid character positions");
    }

    @Test
    @DisplayName("random(count, start=70, end=80, letters=true, numbers=true, chars=null, random) returns alphanumerical string within specified range")
    void TC10_alphanumerical_within_range() {
        // Given
        int count = 5;
        int start = 70;
        int end = 80;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // When
        RandomStringUtils utils = new RandomStringUtils();
        String result = utils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(count, result.length(), "The length of the generated string should match the count");
        assertTrue(result.chars().allMatch(c -> 
            (Character.isLetterOrDigit(c) && c >= start && c < end)
        ), "All characters should be letters or digits within the specified range");
    }

}