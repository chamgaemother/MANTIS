package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.general.DatasetUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class StackedXYBarRenderer_drawItem_0_5_Test {

//     @Test
//     @DisplayName("drawItem calculates total stack correctly when renderAsPercentages is true")
//     public void TC21_drawItem_calculatesTotalStackCorrectlyWhenRenderAsPercentagesIsTrue() throws Exception {
        // Arrange
//         StackedXYBarRenderer renderer = new StackedXYBarRenderer();
//         renderer.setRenderAsPercentages(true);
// 
//         TableXYDataset dataset = mock(TableXYDataset.class, withSettings().extraInterfaces(IntervalXYDataset.class));
//         when(dataset.getYValue(0, 0)).thenReturn(50.0);
//         when(dataset.getYValue(1, 0)).thenReturn(-20.0);
//         when(dataset.getYValue(2, 0)).thenReturn(30.0);
//         when(((IntervalXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
//         when(((IntervalXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(renderer.isSeriesVisible(anyInt())).thenReturn(true);
//         when(renderer.getBarPainter()).thenReturn(mock(BarPainter.class));
//         when(renderer.getMargin()).thenReturn(0.1);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         double total = DatasetUtils.calculateStackTotal(dataset, 0);
//         assertEquals(60.0, total, "Total stack should be correctly calculated as 60.0");
//     }

//     @Test
//     @DisplayName("drawItem handles inverted axis correctly")
//     public void TC22_drawItem_handlesInvertedAxisCorrectly() throws Exception {
        // Arrange
//         StackedXYBarRenderer renderer = new StackedXYBarRenderer();
// 
//         TableXYDataset dataset = mock(TableXYDataset.class, withSettings().extraInterfaces(IntervalXYDataset.class));
//         when(dataset.getYValue(0, 0)).thenReturn(40.0);
//         when(((IntervalXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
//         when(((IntervalXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(rangeAxis.isInverted()).thenReturn(true);
//         when(renderer.isSeriesVisible(anyInt())).thenReturn(true);
//         when(renderer.getBarPainter()).thenReturn(mock(BarPainter.class));
//         when(renderer.getMargin()).thenReturn(0.1);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         verify(rangeAxis).valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT));
//     }

//     @Test
//     @DisplayName("drawItem handles translatedWidth less than 1 by setting minimum width")
//     public void TC23_drawItem_handlesTranslatedWidthLessThan1BySettingMinimumWidth() throws Exception {
        // Arrange
//         StackedXYBarRenderer renderer = new StackedXYBarRenderer();
// 
//         TableXYDataset dataset = mock(TableXYDataset.class, withSettings().extraInterfaces(IntervalXYDataset.class));
//         when(dataset.getYValue(0, 0)).thenReturn(10.0);
//         when(((IntervalXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
//         when(((IntervalXYDataset) dataset).getEndXValue(0, 0)).thenReturn(1.0001); // Small width
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(renderer.isSeriesVisible(anyInt())).thenReturn(true);
//         when(renderer.getBarPainter()).thenReturn(mock(BarPainter.class));
//         when(renderer.getMargin()).thenReturn(0.0); // No margin to force width < 1
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
        // Ensure the test handles the situation gracefully
//     }

//     @Test
//     @DisplayName("drawItem adds entity with correct center coordinates")
//     public void TC24_drawItem_addsEntityWithCorrectCenterCoordinates() {
        // Arrange
//         StackedXYBarRenderer renderer = new StackedXYBarRenderer();
// 
//         TableXYDataset dataset = mock(TableXYDataset.class, withSettings().extraInterfaces(IntervalXYDataset.class));
//         when(dataset.getYValue(0, 0)).thenReturn(25.0);
//         when(((IntervalXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
//         when(((IntervalXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.Plot.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entityCollection);
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(renderer.isSeriesVisible(anyInt())).thenReturn(true);
//         when(renderer.getBarPainter()).thenReturn(mock(BarPainter.class));
//         when(renderer.getMargin()).thenReturn(0.1);
//         when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(false);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         verify(entityCollection).add(any());
//     }
}