package com.fasterxml.jackson.core;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;

public class JsonPointer_forPath_0_2_Test {

    @Test
    @DisplayName("Context is in array with includeRoot=false")
    public void test_TC06_ContextIsInArrayWithIncludeRootFalse() throws Exception {
        // Given
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        Mockito.when(context.inArray()).thenReturn(true);
        Mockito.when(context.getCurrentIndex()).thenReturn(5);
        Mockito.when(context.hasPathSegment()).thenReturn(true);
        Mockito.when(context.getParent()).thenReturn(null);
        boolean includeRoot = false;

        // When
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // Then
        assertNotNull(result, "Resulting JsonPointer should not be null");
        assertEquals("/5", result.toString(), "JsonPointer should correctly include the array index 5");
    }

    @Test
    @DisplayName("Context is in array with includeRoot=true")
    public void test_TC07_ContextIsInArrayWithIncludeRootTrue() throws Exception {
        // Given
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        Mockito.when(context.inArray()).thenReturn(true);
        Mockito.when(context.getCurrentIndex()).thenReturn(3);
        Mockito.when(context.hasPathSegment()).thenReturn(true);
        Mockito.when(context.inRoot()).thenReturn(true);
        Mockito.when(context.hasCurrentIndex()).thenReturn(true);
        Mockito.when(context.getParent()).thenReturn(null);
        boolean includeRoot = true;

        // When
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // Then
        assertNotNull(result, "Resulting JsonPointer should not be null");
        assertEquals("/root/3", result.toString(), "JsonPointer should include root and array index 3");
    }

    @Test
    @DisplayName("Context has multiple parent segments with includeRoot=false")
    public void test_TC08_ContextHasMultipleParentsWithoutRoot() throws Exception {
        // Given
        JsonStreamContext parentContext = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext childContext = Mockito.mock(JsonStreamContext.class);
        Mockito.when(childContext.hasPathSegment()).thenReturn(true);
        Mockito.when(childContext.inArray()).thenReturn(false);
        Mockito.when(childContext.inObject()).thenReturn(true);
        Mockito.when(childContext.getCurrentName()).thenReturn("child");
        Mockito.when(childContext.getParent()).thenReturn(parentContext);
        Mockito.when(parentContext.hasPathSegment()).thenReturn(true);
        Mockito.when(parentContext.inObject()).thenReturn(true);
        Mockito.when(parentContext.getCurrentName()).thenReturn("parent");
        Mockito.when(parentContext.getParent()).thenReturn(null);
        boolean includeRoot = false;

        // When
        JsonPointer result = JsonPointer.forPath(childContext, includeRoot);

        // Then
        assertNotNull(result, "Resulting JsonPointer should not be null");
        assertEquals("/parent/child", result.toString(), "JsonPointer should correctly represent the nested path");
    }

    @Test
    @DisplayName("Context has multiple parent segments with includeRoot=true")
    public void test_TC09_ContextHasMultipleParentsWithRoot() throws Exception {
        // Given
        JsonStreamContext rootContext = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext parentContext = Mockito.mock(JsonStreamContext.class);
        JsonStreamContext childContext = Mockito.mock(JsonStreamContext.class);
        Mockito.when(childContext.hasPathSegment()).thenReturn(true);
        Mockito.when(childContext.inArray()).thenReturn(false);
        Mockito.when(childContext.inObject()).thenReturn(true);
        Mockito.when(childContext.getCurrentName()).thenReturn("child");
        Mockito.when(childContext.getParent()).thenReturn(parentContext);
        Mockito.when(parentContext.hasPathSegment()).thenReturn(true);
        Mockito.when(parentContext.inObject()).thenReturn(true);
        Mockito.when(parentContext.getCurrentName()).thenReturn("parent");
        Mockito.when(parentContext.inRoot()).thenReturn(true);
        Mockito.when(parentContext.hasCurrentIndex()).thenReturn(true);
        Mockito.when(parentContext.getParent()).thenReturn(rootContext);
        Mockito.when(rootContext.hasPathSegment()).thenReturn(true);
        Mockito.when(rootContext.inObject()).thenReturn(true);
        Mockito.when(rootContext.getCurrentName()).thenReturn("root");
        Mockito.when(rootContext.getParent()).thenReturn(null);
        boolean includeRoot = true;

        // When
        JsonPointer result = JsonPointer.forPath(childContext, includeRoot);

        // Then
        assertNotNull(result, "Resulting JsonPointer should not be null");
        assertEquals("/root/parent/child", result.toString(), "JsonPointer should include root and multiple segments");
    }

    @Test
    @DisplayName("Context has no path segments but includeRoot=true and has current index")
    public void test_TC10_NoPathSegmentsWithRootAndCurrentIndex() throws Exception {
        // Given
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        Mockito.when(context.hasPathSegment()).thenReturn(false);
        Mockito.when(context.inRoot()).thenReturn(true);
        Mockito.when(context.hasCurrentIndex()).thenReturn(true);
        Mockito.when(context.getCurrentIndex()).thenReturn(2);
        Mockito.when(context.getParent()).thenReturn(null);
        boolean includeRoot = true;

        // When
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // Then
        assertNotNull(result, "Resulting JsonPointer should not be null");
        assertEquals("/root/2", result.toString(), "JsonPointer should include root and current index even with no path segments");
    }
}