import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import javax.swing.Icon;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class MinMaxCategoryRendererTest {

    private MinMaxCategoryRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;

    @BeforeEach
    void setUp() {
        renderer = new MinMaxCategoryRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT);
    }

    @Test
    void testDrawItem_ValueIsNull() {
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_VerticalOrientation_LastCategory_DrawLineAndIcons() {
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any()))
                .thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        Icon objectIcon = renderer.getObjectIcon();
        Icon minIcon = renderer.getMinIcon();
        Icon maxIcon = renderer.getMaxIcon();

        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).setStroke(renderer.getItemStroke(0, 0));
        verify(objectIcon).paintIcon(null, g2, 50, 100);
        verify(g2).setPaint(renderer.getGroupPaint());
        verify(g2).setStroke(renderer.getGroupStroke());
        verify(g2).draw(any(Line2D.class));
        verify(minIcon).paintIcon(null, g2, 50, 100);
        verify(maxIcon).paintIcon(null, g2, 50, 100);
    }

    @Test
    void testDrawItem_HorizontalOrientation_LastCategory_DrawLineAndIcons() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getValue(0, 0)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(60.0);
        when(rangeAxis.valueToJava2D(eq(20.0), eq(dataArea), any()))
                .thenReturn(120.0);
        when(dataset.getRowCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        Icon objectIcon = renderer.getObjectIcon();
        Icon minIcon = renderer.getMinIcon();
        Icon maxIcon = renderer.getMaxIcon();

        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).setStroke(renderer.getItemStroke(0, 0));
        verify(objectIcon).paintIcon(null, g2, 120, 60);
        verify(g2).setPaint(renderer.getGroupPaint());
        verify(g2).setStroke(renderer.getGroupStroke());
        verify(g2).draw(any(Line2D.class));
        verify(minIcon).paintIcon(null, g2, 120, 60);
        verify(maxIcon).paintIcon(null, g2, 120, 60);
    }

    @Test
    void testDrawItem_UpdateMinAndMax_NotLastRow() {
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(30.0);
        when(rangeAxis.valueToJava2D(eq(5.0), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getRowCount()).thenReturn(2);
        when(dataset.getValue(1, 0)).thenReturn(15.0);

        // First row
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Second row
        when(dataset.getValue(1, 0)).thenReturn(15.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(30.0);
        when(rangeAxis.valueToJava2D(eq(15.0), eq(dataArea), any()))
                .thenReturn(70.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0, 1);

        verify(g2).draw(any(Line2D.class));
        verify(renderer.getMinIcon()).paintIcon(null, g2, 30, 50);
        verify(renderer.getMaxIcon()).paintIcon(null, g2, 30, 70);
    }

    @Test
    void testDrawItem_PlotLinesEnabled_DrawConnectingLine() {
        renderer.setDrawLines(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, 1)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(40.0);
        when(domainAxis.getCategoryMiddle(eq(1), anyInt(), eq(dataArea), any()))
                .thenReturn(60.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any()))
                .thenReturn(80.0);
        when(rangeAxis.valueToJava2D(eq(20.0), eq(dataArea), any()))
                .thenReturn(160.0);
        when(dataset.getRowCount()).thenReturn(2);

        // First item
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Second item
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 1);

        verify(g2, times(2)).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_PlotLinesDisabled_NoConnectingLine() {
        renderer.setDrawLines(false);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, 1)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(40.0);
        when(domainAxis.getCategoryMiddle(eq(1), anyInt(), eq(dataArea), any()))
                .thenReturn(60.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any()))
                .thenReturn(80.0);
        when(rangeAxis.valueToJava2D(eq(20.0), eq(dataArea), any()))
                .thenReturn(160.0);
        when(dataset.getRowCount()).thenReturn(2);

        // First item
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Second item
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 1);

        verify(g2, times(0)).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_PlotLinesEnabled_PreviousValueNull_NoConnectingLine() {
        renderer.setDrawLines(true);
        when(dataset.getValue(0, 0)).thenReturn(null);
        when(dataset.getValue(0, 1)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(eq(1), anyInt(), eq(dataArea), any()))
                .thenReturn(60.0);
        when(rangeAxis.valueToJava2D(eq(20.0), eq(dataArea), any()))
                .thenReturn(160.0);
        when(dataset.getRowCount()).thenReturn(2);

        // First item with null value
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        // Second item with non-null value
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 1);

        verify(g2, times(0)).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_EntitiesNull_NoEntityAdded() {
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any()))
                .thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        verify(state, times(0)).getEntityCollection();
    }

    @Test
    void testDrawItem_EntitiesNotNull_EntityAdded() {
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any()))
                .thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        ArgumentCaptor<Rectangle2D> hotspotCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(entities).add(any(), any(), eq(0), eq(0), hotspotCaptor.capture());
    }

    @Test
    void testDrawItem_LastCategoryNotEqual_CurrentCategorySet() {
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any()))
                .thenReturn(100.0);
        when(dataset.getRowCount()).thenReturn(2);

        // First item, lastCategory != column
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Verify initial draw
        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).setStroke(renderer.getItemStroke(0, 0));

        // Since it's not the last row, no line drawn
        verify(g2, times(0)).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_MinAndMaxUpdate() {
        when(dataset.getRowCount()).thenReturn(3);
        when(dataset.getValue(0, 0)).thenReturn(15.0);
        when(dataset.getValue(1, 0)).thenReturn(10.0);
        when(dataset.getValue(2, 0)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(domainAxis.getCategoryMiddle(eq(1), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(domainAxis.getCategoryMiddle(eq(2), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(15.0), eq(dataArea), any()))
                .thenReturn(150.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any()))
                .thenReturn(100.0);
        when(rangeAxis.valueToJava2D(eq(20.0), eq(dataArea), any()))
                .thenReturn(200.0);

        // First row
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Second row, min updated
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0, 1);
        // Third row, max updated and draw line/icons
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 0, 2);

        verify(g2, times(1)).draw(any(Line2D.class));
        verify(renderer.getMinIcon()).paintIcon(null, g2, 50, 100);
        verify(renderer.getMaxIcon()).paintIcon(null, g2, 50, 200);
    }
}