package org.apache.commons.jxpath.util;

import org.apache.commons.jxpath.JXPathException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;

public class MethodLookupUtils_lookupMethod_0_2_Test {

    // Helper classes for testing
    public static class AmbiguousClass {
        public void ambiguousMethod(String param1, Integer param2) {}
        public void ambiguousMethod(String param1, Integer param2, Double param3) {}
    }

    public static class SomeClass {
        public void singleParamMethod(String param) {}
        public void methodWithOneParam(String param) {}
        public void bestMatchMethod(String param1, String param2, String param3) {}
    }

    // Assume TypeUtils is a utility class available in the context
    public static class TypeUtils {
        public static Object convert(Object obj, Class<?> targetClass) {
            // Simplified conversion logic for testing purposes
            return obj;
        }
        
        public static boolean canConvert(Object obj, Class<?> targetClass) {
            // Simplified conversion capability check
            return obj != null && targetClass.isAssignableFrom(obj.getClass());
        }
    }

    @Test
    @DisplayName("lookupMethod throws JXPathException when multiple methods match with the same priority")
    void TC06_lookupMethod_AmbiguousMethodThrowsException() {
        // GIVEN
        Class<?> targetClass = AmbiguousClass.class;
        String name = "ambiguousMethod";
        Object[] parameters = new Object[]{"param1", 123};

        // WHEN & THEN
        JXPathException exception = assertThrows(JXPathException.class, () -> {
            MethodLookupUtils.lookupMethod(targetClass, name, parameters);
        });
        assertTrue(exception.getMessage().contains("Ambiguous method call"));
    }

    @Test
    @DisplayName("lookupMethod returns null when all type matches fail")
    void TC07_lookupMethod_NoMatchingMethodReturnsNull() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "nonExistentMethod";
        Object[] parameters = new Object[]{"convertibleObject", "param1"};

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("lookupMethod handles loop with zero iterations when parameter count is one")
    void TC08_lookupMethod_SingleParameter_ZeroLoopIterations() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "singleParamMethod";
        Object[] parameters = new Object[]{"param1"};

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result);
        assertEquals("singleParamMethod", result.getName());
    }

    @Test
    @DisplayName("lookupMethod handles loop with one iteration for parameter processing")
    void TC09_lookupMethod_OneLoopIteration_Positive() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "methodWithOneParam";
        Object[] parameters = new Object[]{"param1"};

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result);
        assertEquals("methodWithOneParam", result.getName());
    }

    @Test
    @DisplayName("lookupMethod correctly processes multiple loop iterations and finds the best match")
    void TC10_lookupMethod_MultipleLoopIterations_BestMatch() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "bestMatchMethod";
        Object[] parameters = new Object[]{"param1", "param2", "param3"};

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result);
        assertEquals("bestMatchMethod", result.getName());
    }
}