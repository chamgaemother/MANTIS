package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class FastMath_scalb_2_1_Test {
    
    @Test
    @DisplayName("scalb with n exactly -1023 and d is a positive normal number, testing lower boundary")
    public void TC27_scalb_lowerBoundary() {
        // GIVEN
        double d = 1.0;
        int n = -1023;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        double expected = 1.1125369292536007E-308;
        assertEquals(expected, result, "Result should be 1.1125369292536007E-308 for n=-1023 and d=1.0");
    }
    
    @Test
    @DisplayName("scalb with n exactly 1023 and d is a positive normal number, testing upper boundary before overflow")
    public void TC28_scalb_upperBoundaryBeforeOverflow() {
        // GIVEN
        double d = 1.0;
        int n = 1023;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        double expected = 8.98846567431158E307;
        assertEquals(expected, result, "Result should be 8.98846567431158E307 for n=1023 and d=1.0");
    }
    
    @Test
    @DisplayName("scalb with n=1024 and d is a positive normal number, testing transition to overflow")
    public void TC29_scalb_transitionToOverflow() {
        // GIVEN
        double d = 1.0;
        int n = 1024;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be Double.POSITIVE_INFINITY for n=1024 and d=1.0 due to exponent overflow");
    }
    
    @Test
    @DisplayName("scalb with d as a subnormal number and n=0, ensuring no scaling and correct handling of subnormal")
    public void TC30_scalb_subnormalNoScaling() {
        // GIVEN
        double d = Double.longBitsToDouble(0x0008000000000000L); // Smallest subnormal number
        int n = 0;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        assertEquals(d, result, "Result should be unchanged for subnormal d and n=0");
    }
    
    @Test
    @DisplayName("scalb with d as a subnormal number and n=53, ensuring normalization to a normal number")
    public void TC31_scalb_subnormalNormalization() {
        // GIVEN
        double d = Double.longBitsToDouble(0x0008000000000000L); // Smallest subnormal number
        int n = 53;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        double expected = 1.1125369292536007E-308; // Expected normalized value
        assertEquals(expected, result, "Result should be normalized to 1.1125369292536007E-308 for d=subnormal and n=53");
    }
}