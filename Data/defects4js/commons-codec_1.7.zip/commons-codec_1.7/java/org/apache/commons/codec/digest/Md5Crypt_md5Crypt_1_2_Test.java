package org.apache.commons.codec.digest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.charset.StandardCharsets;

public class Md5Crypt_md5Crypt_1_2_Test {

    @Test
    @DisplayName("md5Crypt with iteration count reaching ROUNDS completes successfully")
    public void TC21() {
        // GIVEN
        byte[] keyBytes = "complexpassword".getBytes(StandardCharsets.UTF_8);
        String salt = "$1$iter1234$";
        String prefix = "$1$";

        // WHEN
        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);

        // THEN
        assertNotNull(hash, "The generated hash should not be null");
        assertTrue(hash.startsWith("$1$iter1234$"), "The hash should start with the correct prefix and salt");
        // Additional assertions can be added based on expected hash output
    }
}