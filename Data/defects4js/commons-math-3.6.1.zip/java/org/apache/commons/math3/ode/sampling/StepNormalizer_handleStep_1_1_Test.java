// package org.apache.commons.math3.ode.sampling;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // 
// // import org.apache.commons.math3.exception.MaxCountExceededException;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import static org.junit.jupiter.api.Assertions.*;
// // 
// // /**
// //  * Test class for {@link StepNormalizer#handleStep(StepInterpolator, boolean)}.
// //  */
// public class StepNormalizer_handleStep_1_1_Test {
// // 
// //     /**
// //      * Mock implementation of FixedStepHandler to track handleStep invocations.
// //      */
// //     private static class MockFixedStepHandler implements FixedStepHandler {
// //         private boolean handleStepCalled = false;
// //         private double[] lastState = null;
// //         private boolean isLast = false;
// // 
// //         @Override
// //         public void handleStep(double time, double[] state, double[] derivatives, boolean isLast) {
// //             this.handleStepCalled = true;
// //             this.lastState = state;
// //             this.isLast = isLast;
// //         }
// // 
// //         public boolean isHandleStepCalled() {
// //             return handleStepCalled;
// //         }
// // 
// //         public double[] getLastState() {
// //             return lastState;
// //         }
// // 
// //         public boolean wasLast() {
// //             return isLast;
// //         }
// //     }
// // 
// //     /**
// //      * Mock implementation of StepInterpolator to provide controlled state data.
// //      */
// //     private static class MockStepInterpolator implements StepInterpolator {
// //         private final double previousTime;
// //         private final double[] previousState;
// //         private final double currentTime;
// //         private final double[] currentState;
// // 
// //         public MockStepInterpolator(double previousTime, double[] previousState, double currentTime, double[] currentState) {
// //             this.previousTime = previousTime;
// //             this.previousState = previousState;
// //             this.currentTime = currentTime;
// //             this.currentState = currentState;
// //         }
// // 
// //         @Override
// //         public double getPreviousTime() {
// //             return previousTime;
// //         }
// // 
// //         @Override
// //         public double getCurrentTime() {
// //             return currentTime;
// //         }
// // 
// //         @Override
// //         public void setInterpolatedTime(double time) {
//             // No-op for mock
// //         }
// // 
// //         @Override
// //         public double[] getInterpolatedState() {
// //             return previousState;
// //         }
// // 
// //         @Override
// //         public double[] getInterpolatedDerivatives() {
// //             return previousState; // Assuming derivatives are mocked the same
// //         }
// //     }
// // 
// //     /**
// //      * Test TC15:
// //      * Handle step when bounds.firstIncluded is false and firstTime equals lastTime,
// //      * ensuring doNormalizedStep is skipped.
// //      */
// //     @Test
// //     @DisplayName("TC15 Handle step with bounds.firstIncluded=false and firstTime==lastTime")
// //     public void TC15_handleStep_boundsFirstIncludedFalse_firstTimeEqualsLastTime() throws Exception {
//         // GIVEN
// //         double h = 1.0;
// //         MockFixedStepHandler handler = new MockFixedStepHandler();
// //         StepNormalizer stepNormalizer = new StepNormalizer(
// //                 h,
// //                 handler,
// //                 StepNormalizerMode.INCREMENT,
// //                 StepNormalizerBounds.NEITHER
// //         );
// // 
//         // Use reflection to set firstTime and lastTime to be equal
// //         
// //         java.lang.reflect.Field firstTimeField = StepNormalizer.class.getDeclaredField("firstTime");
// //         java.lang.reflect.Field lastTimeField = StepNormalizer.class.getDeclaredField("lastTime");
// //         firstTimeField.setAccessible(true);
// //         lastTimeField.setAccessible(true);
// //         firstTimeField.setDouble(stepNormalizer, 5.0);
// //         lastTimeField.setDouble(stepNormalizer, 5.0);
// // 
//         // Create a mock StepInterpolator
// //         MockStepInterpolator interpolator = new MockStepInterpolator(5.0, new double[]{1.0}, 6.0, new double[]{1.5});
// // 
//         // WHEN
// //         stepNormalizer.handleStep(interpolator, false);
// // 
//         // THEN
// //         assertFalse(handler.isHandleStepCalled(), "doNormalizedStep should not be called when firstTime equals lastTime and bounds.firstIncluded is false.");
// //     }
// // 
// //     /**
// //      * Test TC16:
// //      * Handle step when bounds.firstIncluded is false and firstTime does not equal lastTime,
// //      * ensuring doNormalizedStep is executed.
// //      */
// //     @Test
// //     @DisplayName("TC16 Handle step with bounds.firstIncluded=false and firstTime!=lastTime")
// //     public void TC16_handleStep_boundsFirstIncludedFalse_firstTimeNotEqualsLastTime() throws Exception {
//         // GIVEN
// //         double h = 1.0;
// //         MockFixedStepHandler handler = new MockFixedStepHandler();
// //         StepNormalizer stepNormalizer = new StepNormalizer(
// //                 h,
// //                 handler,
// //                 StepNormalizerMode.INCREMENT,
// //                 StepNormalizerBounds.NEITHER
// //         );
// // 
//         // Use reflection to set firstTime and lastTime to be different
// //         java.lang.reflect.Field firstTimeField = StepNormalizer.class.getDeclaredField("firstTime");
// //         java.lang.reflect.Field lastTimeField = StepNormalizer.class.getDeclaredField("lastTime");
// //         firstTimeField.setAccessible(true);
// //         lastTimeField.setAccessible(true);
// //         firstTimeField.setDouble(stepNormalizer, 4.0);
// //         lastTimeField.setDouble(stepNormalizer, 5.0);
// // 
//         // Create a mock StepInterpolator
// //         MockStepInterpolator interpolator = new MockStepInterpolator(5.0, new double[]{1.0}, 6.0, new double[]{1.5});
// // 
//         // WHEN
// //         stepNormalizer.handleStep(interpolator, true);
// // 
//         // THEN
// //         assertTrue(handler.isHandleStepCalled(), "doNormalizedStep should be called once when firstTime does not equal lastTime and bounds.firstIncluded is false.");
// //         assertArrayEquals(new double[]{1.0}, handler.getLastState(), "Handler should receive the correct state.");
// //         assertTrue(handler.wasLast(), "Handler should be notified if it's the last step.");
// //     }
// // }
// }