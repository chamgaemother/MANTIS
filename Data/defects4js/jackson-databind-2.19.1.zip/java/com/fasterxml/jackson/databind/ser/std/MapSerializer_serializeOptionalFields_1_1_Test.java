package com.fasterxml.jackson.databind.ser.std;

import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.JsonSerializer;

public class MapSerializer_serializeOptionalFields_1_1_Test {

    @Test
    @DisplayName("serializeOptionalFields throws exception during value serialization")
    public void TC16() throws Exception {
        // Arrange
        // Create mocks
        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        
        // Instantiate MapSerializer with null dependencies
        MapSerializer mapSerializer = new MapSerializer(
            null, null, // ignoredEntries, includedEntries
            null, // keyType
            null, // valueType
            false, // valueTypeIsStatic
            null, // TypeSerializer
            null, // keySerializer
            null  // valueSerializer to be set via reflection
        );
        
        // Use reflection to set the private _valueSerializer field
        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, valueSerializer);
        
        // Mock valueSerializer to throw exception when serialize is called
        doThrow(new JsonProcessingException("Value serialization failed") {}).when(valueSerializer)
            .serialize(any(), eq(jsonGenerator), eq(serializerProvider));

        // Create a map with one entry
        Map<String, Object> map = new HashMap<>();
        map.put("key1", "value1");

        // Act & Assert
        JsonProcessingException thrownException = Assertions.assertThrows(
            JsonProcessingException.class,
            () -> mapSerializer.serializeOptionalFields(map, jsonGenerator, serializerProvider, MapSerializer.MARKER_FOR_EMPTY),
            "Expected serializeOptionalFields to throw, but it didn't"
        );
        
        Assertions.assertEquals("Value serialization failed", thrownException.getOriginalMessage());
    }

    @Test
    @DisplayName("serializeOptionalFields skips entry when value serializer's isEmpty returns true")
    public void TC17() throws Exception {
        // Arrange
        // Create mocks
        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        
        // Instantiate MapSerializer with null dependencies
        MapSerializer mapSerializer = new MapSerializer(
            null, null, // ignoredEntries, includedEntries
            null, // keyType
            null, // valueType
            false, // valueTypeIsStatic
            null, // TypeSerializer
            null, // keySerializer to be set via reflection
            null  // valueSerializer to be set via reflection
        );
        
        // Use reflection to set the private _valueSerializer and _keySerializer fields
        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, valueSerializer);
        
        Field keySerializerField = MapSerializer.class.getDeclaredField("_keySerializer");
        keySerializerField.setAccessible(true);
        keySerializerField.set(mapSerializer, keySerializer);
        
        // Mock valueSerializer's isEmpty to return true for "emptyValue"
        when(valueSerializer.isEmpty(serializerProvider, "emptyValue")).thenReturn(true);

        // Create a map with one entry
        Map<String, Object> map = new HashMap<>();
        map.put("key1", "emptyValue");

        // Act
        mapSerializer.serializeOptionalFields(map, jsonGenerator, serializerProvider, MapSerializer.MARKER_FOR_EMPTY);

        // Assert
        // Verify that keySerializer.serialize and valueSerializer.serialize were never called
        verify(keySerializer, never()).serialize(any(), any(JsonGenerator.class), any(SerializerProvider.class));
        verify(valueSerializer, never()).serialize(any(), any(JsonGenerator.class), any(SerializerProvider.class));
    }
}