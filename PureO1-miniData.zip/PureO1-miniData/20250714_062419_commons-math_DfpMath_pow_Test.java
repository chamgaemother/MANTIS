package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

class DfpMathTest {

    @Test
    @DisplayName("pow(x, y) should return 1 when y is 0")
    void testPow_YIsZero_ReturnsOne() {
        DfpField field = new DfpField(10);
        Dfp x = field.getOne();
        Dfp y = field.getZero();
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getOne(), result);
    }

    @Test
    @DisplayName("pow(x, y) should return x when y is 1")
    void testPow_YIsOne_ReturnsX() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "2.5");
        Dfp y = field.getOne();
        Dfp result = DfpMath.pow(x, y);
        assertEquals(x, result);
    }

    @Test
    @DisplayName("pow(x, y) should return NaN when x is NaN and y is not zero")
    void testPow_XIsNaN_YNotZero_ReturnsNaN() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, Dfp.QNAN);
        Dfp y = new Dfp(field, "2");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("pow(x, y) should return NaN when y is NaN")
    void testPow_YIsNaN_ReturnsNaN() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "2");
        Dfp y = new Dfp(field, Dfp.QNAN);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("pow(x, y) should return +0 when x is +0 and y > 0")
    void testPow_XIsPositiveZero_YPositive_ReturnsPositiveZero() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "0");
        Dfp y = new Dfp(field, "3");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return +Infinity when x is +0 and y < 0")
    void testPow_XIsPositiveZero_YNegative_ReturnsPositiveInfinity() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "0");
        Dfp y = new Dfp(field, "-3");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return -0 when x is -0 and y is odd integer > 0")
    void testPow_XIsNegativeZero_YOddIntegerPositive_ReturnsNegativeZero() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "-0");
        Dfp y = new Dfp(field, "3");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
        assertTrue(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return -Infinity when x is -0 and y is odd integer < 0")
    void testPow_XIsNegativeZero_YOddIntegerNegative_ReturnsNegativeInfinity() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "-0");
        Dfp y = new Dfp(field, "-3");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertTrue(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return +0 when x is -0 and y is not odd integer > 0")
    void testPow_XIsNegativeZero_YNotOddIntegerPositive_ReturnsPositiveZero() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "-0");
        Dfp y = new Dfp(field, "2");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return +Infinity when x is -0 and y is not odd integer < 0")
    void testPow_XIsNegativeZero_YNotOddIntegerNegative_ReturnsPositiveInfinity() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "-0");
        Dfp y = new Dfp(field, "-2");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return -|x|^y when x < 0 and y is odd integer")
    void testPow_XNegative_YOddInteger_ReturnsNegativeResult() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "-2");
        Dfp y = new Dfp(field, "3");
        Dfp expected = DfpMath.pow(new Dfp(field, "2"), y).negate();
        Dfp result = DfpMath.pow(x, y);
        assertEquals(expected, result);
        assertTrue(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return NaN when x < 0 and y is not integer")
    void testPow_XNegative_YNotInteger_ReturnsNaN() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "-2");
        Dfp y = new Dfp(field, "2.5");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("pow(x, y) should return Infinity when x > 1 and y is +Infinity")
    void testPow_XGreaterThanOne_YPositiveInfinity_ReturnsInfinity() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "2");
        Dfp y = new Dfp(field, Double.POSITIVE_INFINITY);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return 0 when x > 1 and y is -Infinity")
    void testPow_XGreaterThanOne_YNegativeInfinity_ReturnsZero() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "2");
        Dfp y = new Dfp(field, Double.NEGATIVE_INFINITY);
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
    }

    @Test
    @DisplayName("pow(x, y) should return 0 when x < 1 and y is +Infinity")
    void testPow_XLessThanOne_YPositiveInfinity_ReturnsZero() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "0.5");
        Dfp y = new Dfp(field, Double.POSITIVE_INFINITY);
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
    }

    @Test
    @DisplayName("pow(x, y) should return Infinity when x < 1 and y is -Infinity")
    void testPow_XLessThanOne_YNegativeInfinity_ReturnsInfinity() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "0.5");
        Dfp y = new Dfp(field, Double.NEGATIVE_INFINITY);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return NaN when x == 1 and y is Infinity")
    void testPow_XIsOne_YIsInfinity_ReturnsNaN() {
        DfpField field = new DpfField(10);
        Dfp x = field.getOne();
        Dfp y = new Dfp(field, Double.POSITIVE_INFINITY);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("pow(x, y) should return Infinity when x is +Infinity and y > 0")
    void testPow_XIsPositiveInfinity_YPositive_ReturnsInfinity() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, Double.POSITIVE_INFINITY);
        Dfp y = new Dfp(field, "2");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return 0 when x is +Infinity and y < 0")
    void testPow_XIsPositiveInfinity_YNegative_ReturnsZero() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, Double.POSITIVE_INFINITY);
        Dfp y = new Dfp(field, "-2");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
    }

    @Test
    @DisplayName("pow(x, y) should return -Infinity when x is -Infinity and y is odd integer > 0")
    void testPow_XIsNegativeInfinity_YOddIntegerPositive_ReturnsNegativeInfinity() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, Double.NEGATIVE_INFINITY);
        Dfp y = new Dfp(field, "3");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertTrue(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return +0 when x is -Infinity and y is odd integer < 0")
    void testPow_XIsNegativeInfinity_YOddIntegerNegative_ReturnsPositiveZero() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, Double.NEGATIVE_INFINITY);
        Dfp y = new Dfp(field, "-3");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return Infinity when x is -Infinity and y is not odd integer > 0")
    void testPow_XIsNegativeInfinity_YNotOddIntegerPositive_ReturnsInfinity() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, Double.NEGATIVE_INFINITY);
        Dfp y = new Dfp(field, "2");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
        assertFalse(result.isNegative());
    }

    @Test
    @DisplayName("pow(x, y) should return 0 when x is -Infinity and y is not odd integer < 0")
    void testPow_XIsNegativeInfinity_YNotOddIntegerNegative_ReturnsZero() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, Double.NEGATIVE_INFINITY);
        Dfp y = new Dfp(field, "-2");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
    }

    @Test
    @DisplayName("pow(x, y) should return NaN when x is -Infinity and y is not finite odd integer")
    void testPow_XIsNegativeInfinity_YNotFiniteOddInteger_ReturnsNaN() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, Double.NEGATIVE_INFINITY);
        Dfp y = new Dfp(field, Double.NaN);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("pow(x, y) should return Exception when x is null")
    void testPow_XIsNull_ThrowsNullPointerException() {
        DfpField field = new DpfField(10);
        Dfp y = new Dfp(field, "2");
        Executable executable = () -> DfpMath.pow(null, y);
        assertThrows(NullPointerException.class, executable);
    }

    @Test
    @DisplayName("pow(x, y) should return Exception when y is null")
    void testPow_YIsNull_ThrowsNullPointerException() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "2");
        Executable executable = () -> DfpMath.pow(x, null);
        assertThrows(NullPointerException.class, executable);
    }

    @Test
    @DisplayName("pow(x, y) should return NaN when x and y have different radix digits")
    void testPow_DifferentRadixDigits_ReturnsNaN() {
        DfpField field1 = new DpfField(10);
        DfpField field2 = new DpfField(20);
        Dfp x = new Dfp(field1, "2");
        Dfp y = new Dfp(field2, "3");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("pow(x, y) should handle large positive exponents")
    void testPow_LargePositiveExponent() {
        DfpField field = new DpfField(50);
        Dfp x = new Dfp(field, "1.0001");
        Dfp y = new Dfp(field, "100000000");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.classify() == Dfp.INFINITE);
    }

    @Test
    @DisplayName("pow(x, y) should handle large negative exponents")
    void testPow_LargeNegativeExponent() {
        DfpField field = new DpfField(50);
        Dfp x = new Dfp(field, "1.0001");
        Dfp y = new Dfp(field, "-100000000");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.equals(field.getZero()));
    }

    @Test
    @DisplayName("pow(x, y) should return 1 when both x and y are 1")
    void testPow_XAndYAreOne_ReturnsOne() {
        DfpField field = new DpfField(10);
        Dfp x = field.getOne();
        Dfp y = field.getOne();
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getOne(), result);
    }

    @Test
    @DisplayName("pow(x, y) should return correct value for positive x and y")
    void testPow_PositiveXAndY_ReturnsCorrectValue() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "2");
        Dfp y = new Dfp(field, "3");
        Dfp expected = new DpfField(10).newDfp("8");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("pow(x, y) should return correct value for positive x and negative y")
    void testPow_PositiveXAndNegativeY_ReturnsCorrectValue() {
        DfpField field = new DpfField(10);
        Dfp x = new Dfp(field, "2");
        Dfp y = new Dfp(field, "-3");
        Dfp expected = new DpfField(10).newDfp("0.125");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("pow(x, y) should return correct value for fraction x and integer y")
    void testPow_FractionX_IntegerY_ReturnsCorrectValue() {
        DfpField field = new DpfField(10);
        Dfp x = new DpfField(10).newDfp("0.5");
        Dfp y = new DpfField(10).newDfp("3");
        Dfp expected = new DpfField(10).newDfp("0.125");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("pow(x, y) should return 0 when x is 0 and y > 0")
    void testPow_XIsZero_YPositive_ReturnsZero() {
        DfpField field = new DpfField(10);
        Dfp x = field.getZero();
        Dfp y = new DpfField(10).newDfp("5");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(field.getZero(), result);
    }

    @Test
    @DisplayName("pow(x, y) should return Infinity when x is 0 and y < 0")
    void testPow_XIsZero_YNegative_ReturnsInfinity() {
        DfpField field = new DpfField(10);
        Dfp x = field.getZero();
        Dfp y = new DpfField(10).newDfp("-5");
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isInfinite());
    }

    @Test
    @DisplayName("pow(x, y) should return correct value for x = -1 and y = Infinity")
    void testPow_XIsMinusOne_YIsInfinity_ReturnsNaN() {
        DfpField field = new DpfField(10);
        Dfp x = new DpfField(10).newDfp("-1");
        Dfp y = new DpfField(10).newDfp(Double.POSITIVE_INFINITY);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }

    @Test
    @DisplayName("pow(x, y) should return correct value for x = -1 and y = -Infinity")
    void testPow_XIsMinusOne_YIsNegativeInfinity_ReturnsNaN() {
        DfpField field = new DpfField(10);
        Dfp x = new DpfField(10).newDfp("-1");
        Dfp y = new DpfField(10).newDfp(Double.NEGATIVE_INFINITY);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());
    }
}