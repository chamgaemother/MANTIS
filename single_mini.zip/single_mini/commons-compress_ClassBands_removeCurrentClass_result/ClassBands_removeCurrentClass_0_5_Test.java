package org.apache.commons.compress.harmony.pack200;

import java.lang.reflect.Field;
import java.util.ArrayList;

import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.apache.commons.compress.harmony.pack200.Segment;
import org.apache.commons.compress.harmony.pack200.AttributeDefinitionBands;
import org.apache.commons.compress.harmony.pack200.CpBands;
import org.apache.commons.compress.harmony.pack200.SegmentHeader;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;

public class ClassBands_removeCurrentClass_0_5_Test {

    @Test
    @DisplayName("Removes codeMaxLocals, codeMaxStack, and codeHandlerCount when class_flags have bit 17 set")
    void TC21_removeCodeAttributesWhenFlag17Set() throws Exception {
        // Arrange
        // Mock Segment and its dependencies
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        SegmentHeader segmentHeader = mock(SegmentHeader.class);
        
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        
        // Instantiate ClassBands with the mocked Segment
        ClassBands classBands = new ClassBands(segment, 1, 0, false);

        // Use reflection to access and set private fields
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = {1L << 17};
        classFlagsField.set(classBands, classFlags);

        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        // Initialize lists with correct types
        Field codeMaxLocalsField = ClassBands.class.getDeclaredField("codeMaxLocals");
        codeMaxLocalsField.setAccessible(true);
        IntList codeMaxLocals = new IntList();
        codeMaxLocals.add(10);
        codeMaxLocalsField.set(classBands, codeMaxLocals);

        Field codeMaxStackField = ClassBands.class.getDeclaredField("codeMaxStack");
        codeMaxStackField.setAccessible(true);
        IntList codeMaxStack = new IntList();
        codeMaxStack.add(20);
        codeMaxStackField.set(classBands, codeMaxStack);

        Field codeHandlerCountField = ClassBands.class.getDeclaredField("codeHandlerCount");
        codeHandlerCountField.setAccessible(true);
        IntList codeHandlerCount = new IntList();
        codeHandlerCount.add(2);
        codeHandlerCountField.set(classBands, codeHandlerCount);

        // Act
        classBands.removeCurrentClass();

        // Assert
        assertTrue(codeMaxLocals.isEmpty(), "codeMaxLocals should be empty after removal");
        assertTrue(codeMaxStack.isEmpty(), "codeMaxStack should be empty after removal");
        assertTrue(codeHandlerCount.isEmpty(), "codeHandlerCount should be empty after removal");
    }

    @Test
    @DisplayName("Does not remove codeMaxLocals, codeMaxStack, and codeHandlerCount when class_flags do not have bit 17 set")
    void TC22_doNotRemoveCodeAttributesWhenFlag17NotSet() throws Exception {
        // Arrange
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        SegmentHeader segmentHeader = mock(SegmentHeader.class);
        
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        
        ClassBands classBands = new ClassBands(segment, 1, 0, false);

        // Use reflection to access and set private fields
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = {0L};
        classFlagsField.set(classBands, classFlags);

        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        // Initialize lists with correct types
        Field codeMaxLocalsField = ClassBands.class.getDeclaredField("codeMaxLocals");
        codeMaxLocalsField.setAccessible(true);
        IntList codeMaxLocals = new IntList();
        codeMaxLocals.add(10);
        codeMaxLocalsField.set(classBands, codeMaxLocals);

        Field codeMaxStackField = ClassBands.class.getDeclaredField("codeMaxStack");
        codeMaxStackField.setAccessible(true);
        IntList codeMaxStack = new IntList();
        codeMaxStack.add(20);
        codeMaxStackField.set(classBands, codeMaxStack);

        Field codeHandlerCountField = ClassBands.class.getDeclaredField("codeHandlerCount");
        codeHandlerCountField.setAccessible(true);
        IntList codeHandlerCount = new IntList();
        codeHandlerCount.add(2);
        codeHandlerCountField.set(classBands, codeHandlerCount);

        // Act
        classBands.removeCurrentClass();

        // Assert
        assertEquals(1, codeMaxLocals.size(), "codeMaxLocals size should remain unchanged");
        assertEquals(1, codeMaxStack.size(), "codeMaxStack size should remain unchanged");
        assertEquals(1, codeHandlerCount.size(), "codeHandlerCount size should remain unchanged");
    }

    @Test
    @DisplayName("Removes codeLocalVariableTable elements when code_flags have bit 19 set")
    void TC23_removeLocalVariableTableWhenFlag19Set() throws Exception {
        // Arrange
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        SegmentHeader segmentHeader = mock(SegmentHeader.class);
        
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        
        ClassBands classBands = new ClassBands(segment, 1, 0, false);

        // Use reflection to access and set private fields
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        IntList tempMethodFlags = new IntList();
        tempMethodFlags.add(1L << 19); // Bit 19 set
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        Field codeLocalVariableTableNField = ClassBands.class.getDeclaredField("codeLocalVariableTableN");
        codeLocalVariableTableNField.setAccessible(true);
        IntList codeLocalVariableTableN = new IntList();
        codeLocalVariableTableN.add(2);
        codeLocalVariableTableNField.set(classBands, codeLocalVariableTableN);

        Field codeLocalVariableTableBciPField = ClassBands.class.getDeclaredField("codeLocalVariableTableBciP");
        codeLocalVariableTableBciPField.setAccessible(true);
        IntList codeLocalVariableTableBciP = new IntList();
        codeLocalVariableTableBciP.add(100);
        codeLocalVariableTableBciP.add(200);
        codeLocalVariableTableBciPField.set(classBands, codeLocalVariableTableBciP);

        // Act
        classBands.removeCurrentClass();

        // Assert
        assertTrue(codeLocalVariableTableBciP.isEmpty(), "codeLocalVariableTableBciP should be empty after removal");
        assertTrue(codeLocalVariableTableN.isEmpty(), "codeLocalVariableTableN should be empty after removal");
    }

    @Test
    @DisplayName("Does not remove codeLocalVariableTable elements when code_flags do not have bit 19 set")
    void TC24_doNotRemoveLocalVariableTableWhenFlag19NotSet() throws Exception {
        // Arrange
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        SegmentHeader segmentHeader = mock(SegmentHeader.class);
        
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        
        ClassBands classBands = new ClassBands(segment, 1, 0, false);

        // Use reflection to access and set private fields
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        IntList tempMethodFlags = new IntList();
        tempMethodFlags.add(0L); // Bit 19 not set
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        Field codeLocalVariableTableNField = ClassBands.class.getDeclaredField("codeLocalVariableTableN");
        codeLocalVariableTableNField.setAccessible(true);
        IntList codeLocalVariableTableN = new IntList();
        codeLocalVariableTableN.add(2);
        codeLocalVariableTableNField.set(classBands, codeLocalVariableTableN);

        Field codeLocalVariableTableBciPField = ClassBands.class.getDeclaredField("codeLocalVariableTableBciP");
        codeLocalVariableTableBciPField.setAccessible(true);
        IntList codeLocalVariableTableBciP = new IntList();
        codeLocalVariableTableBciP.add(100);
        codeLocalVariableTableBciP.add(200);
        codeLocalVariableTableBciPField.set(classBands, codeLocalVariableTableBciP);

        // Act
        classBands.removeCurrentClass();

        // Assert
        assertEquals(2, codeLocalVariableTableBciP.size(), "codeLocalVariableTableBciP size should remain unchanged");
        assertEquals(1, codeLocalVariableTableN.size(), "codeLocalVariableTableN size should remain unchanged");
    }

    @Test
    @DisplayName("Removes codeLineNumberTable elements when code_flags have bit 1 set")
    void TC25_removeLineNumberTableWhenFlag1Set() throws Exception {
        // Arrange
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        SegmentHeader segmentHeader = mock(SegmentHeader.class);
        
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        
        ClassBands classBands = new ClassBands(segment, 1, 0, false);

        // Use reflection to access and set private fields
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        IntList tempMethodFlags = new IntList();
        tempMethodFlags.add(1L << 1); // Bit 1 set
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        Field codeLineNumberTableNField = ClassBands.class.getDeclaredField("codeLineNumberTableN");
        codeLineNumberTableNField.setAccessible(true);
        IntList codeLineNumberTableN = new IntList();
        codeLineNumberTableN.add(3);
        codeLineNumberTableNField.set(classBands, codeLineNumberTableN);

        Field codeLineNumberTableBciPField = ClassBands.class.getDeclaredField("codeLineNumberTableBciP");
        codeLineNumberTableBciPField.setAccessible(true);
        IntList codeLineNumberTableBciP = new IntList();
        codeLineNumberTableBciP.add(150);
        codeLineNumberTableBciP.add(250);
        codeLineNumberTableBciP.add(350);
        codeLineNumberTableBciPField.set(classBands, codeLineNumberTableBciP);

        Field codeLineNumberTableLineField = ClassBands.class.getDeclaredField("codeLineNumberTableLine");
        codeLineNumberTableLineField.setAccessible(true);
        IntList codeLineNumberTableLine = new IntList();
        codeLineNumberTableLine.add(10);
        codeLineNumberTableLine.add(20);
        codeLineNumberTableLine.add(30);
        codeLineNumberTableLineField.set(classBands, codeLineNumberTableLine);

        // Act
        classBands.removeCurrentClass();

        // Assert
        assertTrue(codeLineNumberTableBciP.isEmpty(), "codeLineNumberTableBciP should be empty after removal");
        assertTrue(codeLineNumberTableLine.isEmpty(), "codeLineNumberTableLine should be empty after removal");
        assertTrue(codeLineNumberTableN.isEmpty(), "codeLineNumberTableN should be empty after removal");
    }
}