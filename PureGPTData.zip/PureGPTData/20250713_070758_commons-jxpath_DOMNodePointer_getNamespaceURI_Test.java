import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

public class DOMNodePointerTest {

    private Document document;
    private Element element;
    private DOMNodePointer pointer;

    @BeforeEach
    public void setUp() {
        document = Mockito.mock(Document.class);
        element = Mockito.mock(Element.class);
        when(document.getDocumentElement()).thenReturn(element);
        pointer = new DOMNodePointer(document, null);
    }

    @Test
    public void testGetNamespaceURI_withNullPrefix() {
        String nsURI = pointer.getNamespaceURI((String) null);
        assertNull(nsURI);
    }

    @Test
    public void testGetNamespaceURI_withEmptyPrefix() {
        String nsURI = pointer.getNamespaceURI("");
        assertNull(nsURI);
    }

    @Test
    public void testGetNamespaceURI_withXmlPrefix() {
        String nsURI = pointer.getNamespaceURI("xml");
        assertEquals(DOMNodePointer.XML_NAMESPACE_URI, nsURI);
    }

    @Test
    public void testGetNamespaceURI_withXmlnsPrefix() {
        String nsURI = pointer.getNamespaceURI("xmlns");
        assertEquals(DOMNodePointer.XMLNS_NAMESPACE_URI, nsURI);
    }

    @Test
    public void testGetNamespaceURI_notFoundReturnsUnknownNamespace() {
        when(element.getAttributeNode("xmlns:myPrefix")).thenReturn(null);
        String nsURI = pointer.getNamespaceURI("myPrefix");
        assertNull(nsURI);
    }

    @Test
    public void testGetNamespaceURI_prefixFound() {
        Attr attr = Mockito.mock(Attr.class);
        when(attr.getValue()).thenReturn("http://example.com/myNamespace");
        when(element.getAttributeNode("xmlns:myPrefix")).thenReturn(attr);
        String nsURI = pointer.getNamespaceURI("myPrefix");
        assertEquals("http://example.com/myNamespace", nsURI);
    }

    @Test
    public void testGetNamespaceURI_emptyNamespaceValue() {
        Attr attr = Mockito.mock(Attr.class);
        when(attr.getValue()).thenReturn("");
        when(element.getAttributeNode("xmlns:myPrefix")).thenReturn(attr);
        String nsURI = pointer.getNamespaceURI("myPrefix");
        assertNull(nsURI);
    }
}