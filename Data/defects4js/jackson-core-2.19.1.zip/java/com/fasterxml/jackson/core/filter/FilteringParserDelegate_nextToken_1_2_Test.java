package com.fasterxml.jackson.core.filter;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.filter.TokenFilter.Inclusion;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Test class for FilteringParserDelegate#nextToken method.
 */
public class FilteringParserDelegate_nextToken_1_2_Test {

    /**
     * Scenario 1: _allowMultipleMatches is false, _currToken is a scalar value,
     * _exposedContext is null, _inclusion is ONLY_INCLUDE_ALL, and _itemFilter is INCLUDE_ALL.
     * Expected: nextToken() returns null.
     */
    @Test
    @DisplayName("Scenario 1: Single scalar match without multiple matches allowed")
    public void testNextToken_SingleScalarMatch_NoMultipleMatches() throws Exception {
        // Mock the delegate JsonParser
        JsonParser mockDelegate = mock(JsonParser.class);
        when(mockDelegate.nextToken()).thenReturn(JsonToken.VALUE_STRING).thenReturn(null);

        // Create instance of FilteringParserDelegate with mocked delegate
        FilteringParserDelegate parser = new FilteringParserDelegate(mockDelegate, TokenFilter.INCLUDE_ALL, Inclusion.ONLY_INCLUDE_ALL, false);

        // Set private fields using reflection
        setPrivateField(parser, "._currToken", JsonToken.VALUE_STRING);
        setPrivateField(parser, "._exposedContext", null);

        // Invoke nextToken
        JsonToken result = parser.nextToken();

        // Assert
        assertNull(result, "Expected nextToken() to return null when multiple matches are not allowed and a scalar match has been made.");
    }

    /**
     * Scenario 2: _exposedContext has a buffered token to return.
     * Expected: nextToken() returns the buffered token.
     */
    @Test
    @DisplayName("Scenario 2: Buffered token in _exposedContext is returned")
    public void testNextToken_BufferedToken_Returned() throws Exception {
        // Mock the delegate JsonParser
        JsonParser mockDelegate = mock(JsonParser.class);

        // Create instance of FilteringParserDelegate with mocked delegate
        FilteringParserDelegate parser = new FilteringParserDelegate(mockDelegate, TokenFilter.INCLUDE_ALL, Inclusion.INCLUDE_ALL_AND_PATH, true);

        // Create a mock TokenFilterContext with a buffered token
        TokenFilterContext mockContext = mock(TokenFilterContext.class);
        when(mockContext.nextTokenToRead()).thenReturn(JsonToken.START_OBJECT).thenReturn(null);

        // Set private fields using reflection
        setPrivateField(parser, "._exposedContext", mockContext);

        // Invoke nextToken
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.START_OBJECT, result, "Expected nextToken() to return the buffered START_OBJECT token from _exposedContext.");
    }

    /**
     * Scenario 3: Delegate throws JsonParseException.
     * Expected: nextToken() propagates the exception.
     */
    @Test
    @DisplayName("Scenario 3: Delegate throws JsonParseException")
    public void testNextToken_DelegateThrowsException() throws Exception {
        // Mock the delegate JsonParser
        JsonParser mockDelegate = mock(JsonParser.class);
        when(mockDelegate.nextToken()).thenThrow(new JsonParseException(mockDelegate, "Parsing error"));

        // Create instance of FilteringParserDelegate with mocked delegate
        FilteringParserDelegate parser = new FilteringParserDelegate(mockDelegate, TokenFilter.INCLUDE_ALL, Inclusion.INCLUDE_ALL_AND_PATH, true);

        // Invoke nextToken and expect exception
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        }, "Expected nextToken() to throw JsonParseException when delegate throws an exception.");

        // Assert exception message
        assertEquals("Parsing error", exception.getOriginalMessage(), "Exception message should match the one thrown by the delegate.");
    }

    /**
     * Scenario 4: nextToken() processes an END_ARRAY token.
     * Expected: Updates _headContext and _itemFilter accordingly.
     */
    @Test
    @DisplayName("Scenario 4: Processing END_ARRAY token updates context")
    public void testNextToken_EndArray_UpdatesContext() throws Exception {
        // Mock the delegate JsonParser
        JsonParser mockDelegate = mock(JsonParser.class);
        when(mockDelegate.nextToken()).thenReturn(JsonToken.END_ARRAY).thenReturn(null);

        // Create instance of FilteringParserDelegate with mocked delegate
        FilteringParserDelegate parser = new FilteringParserDelegate(mockDelegate, TokenFilter.INCLUDE_ALL, Inclusion.INCLUDE_ALL_AND_PATH, true);

        // Invoke nextToken
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.END_ARRAY, result, "Expected nextToken() to return END_ARRAY token.");

        // Verify that _headContext and _itemFilter are updated
        TokenFilterContext headContext = (TokenFilterContext) getPrivateField(parser, "._headContext");
        TokenFilter itemFilter = (TokenFilter) getPrivateField(parser, "._itemFilter");
        assertNotNull(headContext, "Head context should not be null after processing END_ARRAY.");
        assertEquals(TokenFilter.INCLUDE_ALL, itemFilter, "Item filter should remain INCLUDE_ALL after processing END_ARRAY.");
    }

    /**
     * Scenario 5: nextToken() encounters FIELD_NAME and includes the property.
     * Expected: nextToken() returns FIELD_NAME token and updates _itemFilter.
     */
    @Test
    @DisplayName("Scenario 5: FIELD_NAME token is included and _itemFilter is updated")
    public void testNextToken_FieldName_Included() throws Exception {
        // Mock the delegate JsonParser
        JsonParser mockDelegate = mock(JsonParser.class);
        when(mockDelegate.currentName()).thenReturn("testField");
        when(mockDelegate.nextToken()).thenReturn(JsonToken.FIELD_NAME).thenReturn(JsonToken.VALUE_STRING).thenReturn(null);

        // Create instance of FilteringParserDelegate with mocked delegate
        FilteringParserDelegate parser = new FilteringParserDelegate(mockDelegate, TokenFilter.INCLUDE_ALL, Inclusion.INCLUDE_ALL_AND_PATH, true);

        // Invoke nextToken to process FIELD_NAME
        JsonToken result = parser.nextToken();

        // Assert
        assertEquals(JsonToken.FIELD_NAME, result, "Expected nextToken() to return FIELD_NAME token.");

        // Verify that _itemFilter is still INCLUDE_ALL
        TokenFilter itemFilter = (TokenFilter) getPrivateField(parser, "._itemFilter");
        assertEquals(TokenFilter.INCLUDE_ALL, itemFilter, "Item filter should remain INCLUDE_ALL after processing FIELD_NAME.");
    }

    /**
     * Utility method to set private fields via reflection.
     */
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = getField(target.getClass(), fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    /**
     * Utility method to get private fields via reflection.
     */
    private Object getPrivateField(Object target, String fieldName) throws Exception {
        Field field = getField(target.getClass(), fieldName);
        field.setAccessible(true);
        return field.get(target);
    }

    /**
     * Utility method to retrieve a Field object, handling inner classes if necessary.
     */
    private Field getField(Class<?> clazz, String fieldName) throws NoSuchFieldException {
        // Remove the leading dot if present
        if (fieldName.startsWith(".")) {
            fieldName = fieldName.substring(1);
        }
        return clazz.getDeclaredField(fieldName);
    }
}