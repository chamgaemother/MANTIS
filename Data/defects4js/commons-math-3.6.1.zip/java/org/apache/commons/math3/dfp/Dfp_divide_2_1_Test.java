package org.apache.commons.math3.dfp;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_divide_2_1_Test {

//     @Test
//     @DisplayName("Division by a signaling NaN divisor resulting in QNAN and FLAG_INVALID")
//     public void TC16_divide_by_signaling_NaN_divisor() {
        // Initialize DfpField with 10 radix digits
//         DfpField field = new DfpField(10);
// 
        // Create dividend as finite
//         Dfp dividend = new Dfp(field, 50.0);
// 
        // Create divisor as signaling NaN
//         Dfp divisor = new Dfp(field, (byte) 1, Dfp.SNAN);
// 
        // Perform division
//         Dfp result = dividend.divide(divisor);
// 
        // Assert result is NaN
//         assertTrue(result.isNaN(), "Result should be NaN");
// 
        // Assert FLAG_INVALID is set
//         int flags = result.getField().getIEEEFlagsBits();
//         assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");
//     }

//     @Test
//     @DisplayName("Division where rounding up causes overflow resulting in Infinity and FLAG_OVERFLOW")
//     public void TC17_divide_rounding_causes_overflow() {
        // Initialize DfpField with 10 radix digits
//         DfpField field = new DfpField(10);
// 
        // Create dividend and divisor such that division result is at overflow boundary
//         Dfp dividend = new Dfp(field, Double.MAX_VALUE); // Specify maximum representable finite value for testing overflow
//         Dfp divisor = new Dfp(field, 1.0); // Use a value close to 1 to cause potential overflow
// 
        // Perform division
//         Dfp result = dividend.divide(divisor);
// 
        // Assert result is Infinite
//         assertTrue(result.isInfinite(), "Result should be Infinite");
// 
        // Assert FLAG_OVERFLOW is set
//         int flags = result.getField().getIEEEFlagsBits();
//         assertTrue((flags & DfpField.FLAG_OVERFLOW) != 0, "FLAG_OVERFLOW should be set");
//     }

}