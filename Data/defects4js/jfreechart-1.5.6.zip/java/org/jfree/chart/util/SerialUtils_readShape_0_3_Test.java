package org.jfree.chart.util;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// import java.awt.Shape;
// import java.awt.geom.GeneralPath;
// import java.awt.geom.PathIterator;
// import java.io.ByteArrayInputStream;
// import java.io.ByteArrayOutputStream;
// import java.io.IOException;
// import java.io.ObjectInputStream;
// import java.io.ObjectOutputStream;
// 
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
public class SerialUtils_readShape_0_3_Test {
// 
//     @Test
//     @DisplayName("readShape correctly processes GeneralPath with one quadTo command")
//     public void TC11_readShape_processes_GeneralPath_with_one_quadTo_command() throws Exception {
        // GIVEN
//         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//         ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
//         objectOutputStream.writeBoolean(false); // not null
//         objectOutputStream.writeObject(GeneralPath.class);
//         objectOutputStream.writeBoolean(false); // path not done
//         objectOutputStream.writeInt(PathIterator.SEG_QUADTO);
//         objectOutputStream.writeFloat(110.0f);
//         objectOutputStream.writeFloat(120.0f);
//         objectOutputStream.writeFloat(130.0f);
//         objectOutputStream.writeFloat(140.0f);
//         objectOutputStream.writeInt(GeneralPath.WIND_EVEN_ODD);
//         objectOutputStream.writeBoolean(true); // path done
//         objectOutputStream.flush();
// 
//         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
//         ObjectInputStream stream = new ObjectInputStream(byteArrayInputStream);
// 
        // WHEN
//         Shape result = SerialUtils.readShape(stream);
// 
        // THEN
//         assertTrue(result instanceof GeneralPath, "Result should be an instance of GeneralPath");
//         GeneralPath gp = (GeneralPath) result;
//         PathIterator pi = gp.getPathIterator(null);
//         assertFalse(pi.isDone(), "PathIterator should not be done initially");
//         float[] coords = new float[6];
//         int type = pi.currentSegment(coords);
//         assertEquals(PathIterator.SEG_QUADTO, type, "Segment type should be SEG_QUADTO");
//         assertAll("Coordinates",
//             () -> assertEquals(110.0f, coords[0], 0.0001f, "First coordinate X"),
//             () -> assertEquals(120.0f, coords[1], 0.0001f, "First coordinate Y"),
//             () -> assertEquals(130.0f, coords[2], 0.0001f, "Second coordinate X"),
//             () -> assertEquals(140.0f, coords[3], 0.0001f, "Second coordinate Y")
//         );
//         pi.next();
//         assertTrue(pi.isDone(), "PathIterator should be done after one segment");
//         assertEquals(GeneralPath.WIND_EVEN_ODD, gp.getWindingRule(), "Winding rule should be WIND_EVEN_ODD");
//     }
// 
//     @Test
//     @DisplayName("readShape correctly processes GeneralPath with one closePath command")
//     public void TC12_readShape_processes_GeneralPath_with_one_closePath_command() throws Exception {
        // GIVEN
//         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//         ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
//         objectOutputStream.writeBoolean(false); // not null
//         objectOutputStream.writeObject(GeneralPath.class);
//         objectOutputStream.writeBoolean(false); // path not done
//         objectOutputStream.writeInt(PathIterator.SEG_CLOSE);
//         objectOutputStream.writeInt(GeneralPath.WIND_NON_ZERO);
//         objectOutputStream.writeBoolean(true); // path done
//         objectOutputStream.flush();
// 
//         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
//         ObjectInputStream stream = new ObjectInputStream(byteArrayInputStream);
// 
        // WHEN
//         Shape result = SerialUtils.readShape(stream);
// 
        // THEN
//         assertTrue(result instanceof GeneralPath, "Result should be an instance of GeneralPath");
//         GeneralPath gp = (GeneralPath) result;
//         PathIterator pi = gp.getPathIterator(null);
//         assertFalse(pi.isDone(), "PathIterator should not be done initially");
//         float[] coords = new float[6];
//         int type = pi.currentSegment(coords);
//         assertEquals(PathIterator.SEG_CLOSE, type, "Segment type should be SEG_CLOSE");
//         pi.next();
//         assertTrue(pi.isDone(), "PathIterator should be done after one segment");
//         assertEquals(GeneralPath.WIND_NON_ZERO, gp.getWindingRule(), "Winding rule should be WIND_NON_ZERO");
//     }
// 
//     @Test
//     @DisplayName("readShape throws RuntimeException when GeneralPath has invalid path type")
//     public void TC13_readShape_throws_RuntimeException_for_invalid_GeneralPath_type() throws Exception {
        // GIVEN
//         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//         ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
//         objectOutputStream.writeBoolean(false); // not null
//         objectOutputStream.writeObject(GeneralPath.class);
//         objectOutputStream.writeBoolean(false); // path not done
//         objectOutputStream.writeInt(999); // invalid path type
//         objectOutputStream.writeBoolean(true); // path done
//         objectOutputStream.flush();
// 
//         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
//         ObjectInputStream stream = new ObjectInputStream(byteArrayInputStream);
// 
        // WHEN & THEN
//         RuntimeException exception = assertThrows(RuntimeException.class, () -> {
//             SerialUtils.readShape(stream);
//         }, "Expected readShape to throw RuntimeException");
//         assertEquals("JFreeChart - No path exists", exception.getMessage(), "Exception message should match");
//     }
// 
//     @Test
//     @DisplayName("readShape successfully reads and returns a Shape from an unknown class")
//     public void TC14_readShape_returns_Shape_when_class_is_unknown() throws Exception {
        // GIVEN
//         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//         ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
//         objectOutputStream.writeBoolean(false); // not null
//         objectOutputStream.writeObject(CustomShape.class);
//         objectOutputStream.flush();
// 
//         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
//         ObjectInputStream stream = new ObjectInputStream(byteArrayInputStream);
// 
        // WHEN
//         Shape result = SerialUtils.readShape(stream);
// 
        // THEN
//         assertTrue(result instanceof CustomShape, "Result should be an instance of CustomShape");
//     }
// 
//     @Test
//     @DisplayName("readShape processes GeneralPath with multiple path elements")
//     public void TC15_readShape_processes_GeneralPath_with_multiple_path_elements() throws Exception {
        // GIVEN
//         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//         ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
//         objectOutputStream.writeBoolean(false); // not null
//         objectOutputStream.writeObject(GeneralPath.class);
//         objectOutputStream.writeBoolean(false); // path not done
//         objectOutputStream.writeInt(PathIterator.SEG_MOVETO);
//         objectOutputStream.writeFloat(10.0f);
//         objectOutputStream.writeFloat(20.0f);
//         objectOutputStream.writeInt(PathIterator.SEG_LINETO);
//         objectOutputStream.writeFloat(30.0f);
//         objectOutputStream.writeFloat(40.0f);
//         objectOutputStream.writeInt(GeneralPath.WIND_NON_ZERO);
//         objectOutputStream.writeBoolean(true); // path done
//         objectOutputStream.flush();
// 
//         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
//         ObjectInputStream stream = new ObjectInputStream(byteArrayInputStream);
// 
        // WHEN
//         Shape result = SerialUtils.readShape(stream);
// 
        // THEN
//         assertTrue(result instanceof GeneralPath, "Result should be an instance of GeneralPath");
//         GeneralPath gp = (GeneralPath) result;
//         PathIterator pi = gp.getPathIterator(null);
//         float[] coords = new float[6];
// 
        // First element
//         assertFalse(pi.isDone(), "PathIterator should not be done initially");
//         int type1 = pi.currentSegment(coords);
//         assertEquals(PathIterator.SEG_MOVETO, type1, "First segment type should be SEG_MOVETO");
//         assertEquals(10.0f, coords[0], 0.0001f, "First segment X coordinate");
//         assertEquals(20.0f, coords[1], 0.0001f, "First segment Y coordinate");
//         pi.next();
// 
        // Second element
//         assertFalse(pi.isDone(), "PathIterator should not be done after first segment");
//         int type2 = pi.currentSegment(coords);
//         assertEquals(PathIterator.SEG_LINETO, type2, "Second segment type should be SEG_LINETO");
//         assertEquals(30.0f, coords[0], 0.0001f, "Second segment X coordinate");
//         assertEquals(40.0f, coords[1], 0.0001f, "Second segment Y coordinate");
//         pi.next();
// 
        // End of Path
//         assertTrue(pi.isDone(), "PathIterator should be done after two segments");
//         assertEquals(GeneralPath.WIND_NON_ZERO, gp.getWindingRule(), "Winding rule should be WIND_NON_ZERO");
//     }
// 
    // CustomShape class for testing purposes
//     private static class CustomShape implements Shape {
//         @Override
//         public Rectangle getBounds() { return null; }
//         @Override
//         public Rectangle2D getBounds2D() { return null; }
//         @Override
//         public boolean contains(double x, double y) { return false; }
//         @Override
//         public boolean contains(Point2D p) { return false; }
//         @Override
//         public boolean intersects(double x, double y, double w, double h) { return false; }
//         @Override
//         public boolean intersects(Rectangle2D r) { return false; }
//         @Override
//         public boolean contains(double x, double y, double w, double h) { return false; }
//         @Override
//         public boolean contains(Rectangle2D r) { return false; }
//         @Override
//         public PathIterator getPathIterator(AffineTransform at) { return null; }
//         @Override
//         public PathIterator getPathIterator(AffineTransform at, double flatness) { return null; }
//     }
// }
}