package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import java.lang.reflect.Field;

public class Dfp_nextAfter_0_1_Test {

    @Test
    @DisplayName("nextAfter with different radix digits sets FLAG_INVALID and returns QNAN")
    public void TC01_nextAfter_radixDigitsMismatch() throws Exception {
        // GIVEN
        DfpField fieldA = new DfpField(32);
        Dfp a = new Dfp(fieldA, 1.0);
        DfpField fieldB = new DfpField(64);
        Dfp b = new Dfp(fieldB, 2.0);

        // WHEN
        Dfp result = a.nextAfter(b);

        // THEN
        // Verify a.field has FLAG_INVALID set
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField aField = (DfpField) fieldField.get(a);

        Field flagsField = DfpField.class.getDeclaredField("flags");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(aField);
        Assertions.assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");

        // Assert result.nans == QNAN
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte resultNans = nansField.getByte(result);
        Assertions.assertEquals(Dfp.QNAN, resultNans, "Result should be QNAN");
    }

//    @Test
//    @DisplayName("nextAfter where this is less than x and compare(this, x) != 0")
//    public void TC02_nextAfter_lessThan_and_compareNotZero() throws Exception {
//        // GIVEN
//        DfpField field = new DfpField(32);
//        Dfp a = new Dfp(field, 1.0);
//        Dfp b = new Dfp(field, 2.0);
//
//        // Ensure a < b and a.compare(b) != 0
//        Assertions.assertTrue(a.lessThan(b), "a should be less than b");
//        Assertions.assertNotEquals(0, Dfp.compare(a, b), "a.compare(b) should not be zero");
//
//        // WHEN
//        Dfp result = a.nextAfter(b);
//
//        // THEN
//        // Verify result is incremented towards b
//        Assertions.assertTrue(a.lessThan(result), "Result should be greater than a");
//        Assertions.assertTrue(result.lessThan(b), "Result should be less than b");
//    }

    @Test
    @DisplayName("nextAfter where this equals x returns a new instance of x")
    public void TC03_nextAfter_equalsX_returnsNewInstance() throws Exception {
        // GIVEN
        DfpField field = new DfpField(32);
        Dfp a = new Dfp(field, 5.0);
        Dfp b = new Dfp(field, 5.0);

        // Ensure a equals b
        Assertions.assertTrue(a.equals(b), "a should equal b");

        // WHEN
        Dfp result = a.nextAfter(b);

        // THEN
        // Verify result is a new instance of b
        Assertions.assertNotSame(a, result, "Result should be a new instance");
        Assertions.assertEquals(b, result, "Result should be equal to b");
    }

//    @Test
//    @DisplayName("nextAfter with this less than zero toggles direction")
//    public void TC04_nextAfter_lessThanZero_togglesDirection() throws Exception {
//        // GIVEN
//        DfpField field = new DfpField(32);
//        Dfp a = new Dfp(field, -1.0);
//        Dfp b = new Dfp(field, 2.0);
//
//        // Ensure a < 0, a < b, and a.compare(b) != 0
//        Assertions.assertTrue(a.lessThan(Dfp.ZERO), "a should be less than zero");
//        Assertions.assertTrue(a.lessThan(b), "a should be less than b");
//        Assertions.assertNotEquals(0, Dfp.compare(a, b), "a.compare(b) should not be zero");
//
//        // WHEN
//        Dfp result = a.nextAfter(b);
//
//        // THEN
//        // Verify result is decremented away from zero
//        Assertions.assertTrue(result.lessThan(a), "Result should be less than a");
//    }

    @Test
    @DisplayName("nextAfter results in classification INFINITE and sets FLAG_INEXACT")
    public void TC05_nextAfter_overflowToInfinite() throws Exception {
        // GIVEN
        DfpField field = new DfpField(32);
        Dfp a = new Dfp(field, Double.MAX_VALUE);
        Dfp b = new Dfp(field, Double.MAX_VALUE * 2); // This should cause overflow

        // WHEN
        Dfp result = a.nextAfter(b);

        // THEN
        // Verify FLAG_INEXACT is set
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField aField = (DfpField) fieldField.get(a);

        Field flagsField = DfpField.class.getDeclaredField("flags");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(aField);
        Assertions.assertTrue((flags & DfpField.FLAG_INEXACT) != 0, "FLAG_INEXACT should be set");

        // Verify result.classify() == INFINITE
        Assertions.assertEquals(Dfp.INFINITE, result.classify(), "Result should classify as INFINITE");
    }

}
