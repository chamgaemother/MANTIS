package org.apache.commons.compress.compressors.gzip;

import org.apache.commons.compress.compressors.gzip.GzipParameters;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GzipParameters_equals_0_1_Test {

    @Test
    @DisplayName("Self-comparison yields true.")
    void testEqualsSelf() {
        GzipParameters params = new GzipParameters();
        boolean result = params.equals(params);
        assertTrue(result);
    }

    @Test
    @DisplayName("Comparing with null yields false.")
    void testEqualsNull() {
        GzipParameters params = new GzipParameters();
        boolean result = params.equals(null);
        assertFalse(result);
    }

    @Test
    @DisplayName("Comparing with non-instance yields false.")
    void testEqualsNonInstance() {
        GzipParameters params = new GzipParameters();
        Object other = new Object();
        boolean result = params.equals(other);
        assertFalse(result);
    }

    @Test
    @DisplayName("Different bufferSize values yield false.")
    void testEqualsDifferentBufferSize() {
        GzipParameters params1 = new GzipParameters();
        GzipParameters params2 = new GzipParameters();
        params1.setBufferSize(1024);
        params2.setBufferSize(2048);
        boolean result = params1.equals(params2);
        assertFalse(result);
    }

    @Test
    @DisplayName("Different comment values yield false.")
    void testEqualsDifferentComment() {
        GzipParameters params1 = new GzipParameters();
        GzipParameters params2 = new GzipParameters();
        params1.setComment("Hello");
        params2.setComment("World");
        boolean result = params1.equals(params2);
        assertFalse(result);
    }
}