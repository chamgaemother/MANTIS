package org.jfree.chart.renderer.xy;

import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D; 

public class XYBoxAndWhiskerRenderer_drawHorizontalItem_0_3_Test {

    @Test
    @DisplayName("fillBox is false and box paint is provided")
    public void TC11() throws Exception {
        // Given
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        
        // Use reflection to set fillBox to false
        Field fillBoxField = XYBoxAndWhiskerRenderer.class.getDeclaredField("fillBox");
        fillBoxField.setAccessible(true);
        fillBoxField.set(renderer, false);
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(boxDataset.getX(anyInt(), anyInt())).thenReturn(1.0);
        when(boxDataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(5.0);
        when(boxDataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(0.0);
        when(boxDataset.getMedianValue(anyInt(), anyInt())).thenReturn(2.5);
        when(boxDataset.getMeanValue(anyInt(), anyInt())).thenReturn(2.5);
        when(boxDataset.getQ1Value(anyInt(), anyInt())).thenReturn(1.5);
        when(boxDataset.getQ3Value(anyInt(), anyInt())).thenReturn(3.5);

        int series = 0;
        int item = 0;
        Paint boxPaint = mock(Paint.class);
        
        // Spy the renderer to mock lookupBoxPaint
        XYBoxAndWhiskerRenderer spyRenderer = spy(renderer);
        doReturn(boxPaint).when(spyRenderer).lookupBoxPaint(series, item);
        
        // When
        spyRenderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
        
        // Then
        verify(g2).setPaint(boxPaint);
        verify(g2, never()).fill(any(Shape.class));
    }

//     @Test
//     @DisplayName("Entity collection is not null and box intersects dataArea")
//     public void TC12() throws Exception {
        // Given
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
//         when(boxDataset.getX(anyInt(), anyInt())).thenReturn(1.0);
//         when(boxDataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(boxDataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(0.0);
//         when(boxDataset.getMedianValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getMeanValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getQ1Value(anyInt(), anyInt())).thenReturn(1.5);
//         when(boxDataset.getQ3Value(anyInt(), anyInt())).thenReturn(3.5);
//         
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(plotRenderingInfo);
//         when(plotRenderingInfo.getEntityCollection()).thenReturn(entityCollection);
// 
//         int series = 0;
//         int item = 0;
// 
//         Shape boxShape = mock(Shape.class);
//         when(boxShape.intersects(any(Rectangle2D.class))).thenReturn(true);
// 
        // Spy the renderer to mock necessary methods
//         XYBoxAndWhiskerRenderer spyRenderer = spy(renderer);
//         doNothing().when(spyRenderer).addEntity(eq(entityCollection), any(Shape.class), eq(boxDataset), eq(series), 
//             eq(item), anyDouble(), anyDouble());
//         
        // When
//         spyRenderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
// 
        // Then
//         verify(entityCollection).add(any(), any(), eq(boxDataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }

//     @Test
//     @DisplayName("Entity collection is present but box does not intersect dataArea")
//     public void TC13() throws Exception {
        // Given
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
//         when(boxDataset.getX(anyInt(), anyInt())).thenReturn(1.0);
//         when(boxDataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(boxDataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(0.0);
//         when(boxDataset.getMedianValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getMeanValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getQ1Value(anyInt(), anyInt())).thenReturn(1.5);
//         when(boxDataset.getQ3Value(anyInt(), anyInt())).thenReturn(3.5);
// 
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(plotRenderingInfo);
//         when(plotRenderingInfo.getEntityCollection()).thenReturn(entityCollection);
// 
//         int series = 0;
//         int item = 0;
// 
//         Shape boxShape = mock(Shape.class);
//         when(boxShape.intersects(any(Rectangle2D.class))).thenReturn(false);
//         
        // Spy the renderer to mock necessary methods
//         XYBoxAndWhiskerRenderer spyRenderer = spy(renderer);
//         doNothing().when(spyRenderer).addEntity(eq(entityCollection), eq(boxShape), eq(boxDataset), eq(series), eq(item), anyDouble(), anyDouble());
// 
        // When
//         spyRenderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
// 
        // Then
//         verify(entityCollection, never()).add(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
//     }

//     @Test
//     @DisplayName("PlotRenderingInfo with EntityCollection, yAverage is provided, fillBox is true, exactBoxWidth > 0 and <= maxBoxWidth")
//     public void TC14() throws Exception {
        // Given
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         
        // Use reflection to set fillBox to true
//         Field fillBoxField = XYBoxAndWhiskerRenderer.class.getDeclaredField("fillBox");
//         fillBoxField.setAccessible(true);
//         fillBoxField.set(renderer, true);
//         
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
//         when(boxDataset.getX(anyInt(), anyInt())).thenReturn(1.0);
//         when(boxDataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(boxDataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(0.0);
//         when(boxDataset.getMedianValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getMeanValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getQ1Value(anyInt(), anyInt())).thenReturn(1.5);
//         when(boxDataset.getQ3Value(anyInt(), anyInt())).thenReturn(3.5);
// 
//         when(dataArea.getHeight()).thenReturn(100.0);
// 
        // Spy the renderer to control getBoxWidth and lookupBoxPaint
//         XYBoxAndWhiskerRenderer spyRenderer = spy(renderer);
//         doReturn(10.0).when(spyRenderer).getBoxWidth(); // exactBoxWidth > 0 and <= maxBoxWidth (10 <= 10)
// 
        // Mock lookupBoxPaint to return a specific paint
//         Paint boxPaint = mock(Paint.class);
//         doReturn(boxPaint).when(spyRenderer).lookupBoxPaint(series, item);
// 
        // Mock artifactPaint
//         Paint artifactPaint = mock(Paint.class);
//         doReturn(artifactPaint).when(spyRenderer).getArtifactPaint();
// 
        // When
//         spyRenderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
// 
        // Then
        // Assert box is drawn with exactBoxWidth
//         verify(g2).fill(any(Shape.class));
//         verify(g2).draw(any(Shape.class));
        // Assert average marker is drawn
//         verify(g2).draw(any(Shape.class));
        // Assert box is filled
//         verify(g2).setPaint(boxPaint);
//         verify(g2).fill(any(Shape.class));
//     }

//     @Test
//     @DisplayName("Box Q1 median is greater than Q3 median resulting in negative width")
//     public void TC15() throws Exception {
        // Given
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
// 
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
//         when(boxDataset.getX(anyInt(), anyInt())).thenReturn(1.0);
//         when(boxDataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(boxDataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(0.0);
//         when(boxDataset.getMedianValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getMeanValue(anyInt(), anyInt())).thenReturn(2.5);
//         when(boxDataset.getQ1Value(anyInt(), anyInt())).thenReturn(4.0);
//         when(boxDataset.getQ3Value(anyInt(), anyInt())).thenReturn(3.0);
// 
        // Spy the renderer
//         XYBoxAndWhiskerRenderer spyRenderer = spy(renderer);
// 
        // When
//         spyRenderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, boxDataset, series, item, null, 0);
// 
        // Then
        // Verify that Q1 and Q3 are swapped to ensure positive box width
        // This can be inferred by ensuring that Rectangle2D is created with positive width
//         verify(g2).draw(any(Shape.class));
//     }
}