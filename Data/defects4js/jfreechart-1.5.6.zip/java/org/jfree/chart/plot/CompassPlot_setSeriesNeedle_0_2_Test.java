package org.jfree.chart.plot;

import java.lang.reflect.Field;

import org.jfree.chart.needle.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.BasicStroke;

public class CompassPlot_setSeriesNeedle_0_2_Test {

    @Test
    @DisplayName("setSeriesNeedle with type=5 sets PointerNeedle")
    public void testTC06_setSeriesNeedle_type5() throws Exception {
        CompassPlot compassPlot = new CompassPlot();
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedle = new MeterNeedle[1];
        seriesNeedleField.set(compassPlot, seriesNeedle);

        int type = 5;
        int index = 0;

        compassPlot.setSeriesNeedle(index, type);

        MeterNeedle needle = seriesNeedle[index];

        assertTrue(needle instanceof PointerNeedle, "Needle at index should be PointerNeedle");
    }

    @Test
    @DisplayName("setSeriesNeedle with type=6 sets ShipNeedle, null paint, and outline stroke of 3")
    public void testTC07_setSeriesNeedle_type6() throws Exception {
        CompassPlot compassPlot = new CompassPlot();
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedle = new MeterNeedle[1];
        seriesNeedleField.set(compassPlot, seriesNeedle);

        int type = 6;
        int index = 0;

        compassPlot.setSeriesNeedle(index, type);

        MeterNeedle needle = seriesNeedle[index];

        // Reflection to access private fields
        Field fillPaintField = needle.getClass().getDeclaredField("fillPaint");
        fillPaintField.setAccessible(true);
        Color fillPaint = (Color) fillPaintField.get(needle);

        Field outlineStrokeField = needle.getClass().getDeclaredField("outlineStroke");
        outlineStrokeField.setAccessible(true);
        BasicStroke outlineStroke = (BasicStroke) outlineStrokeField.get(needle);

        assertAll("Verify ShipNeedle, null paint, and outline stroke",
            () -> assertTrue(needle instanceof ShipNeedle, "Needle at index should be ShipNeedle"),
            () -> assertNull(fillPaint, "Fill paint should be null"),
            () -> assertNotNull(outlineStroke, "Outline stroke should not be null"),
            () -> assertEquals(3.0f, outlineStroke.getLineWidth(), "Outline stroke width should be 3")
        );
    }

    @Test
    @DisplayName("setSeriesNeedle with type=7 sets WindNeedle and blue paint")
    public void testTC08_setSeriesNeedle_type7() throws Exception {
        CompassPlot compassPlot = new CompassPlot();
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedle = new MeterNeedle[1];
        seriesNeedleField.set(compassPlot, seriesNeedle);

        int type = 7;
        int index = 0;

        compassPlot.setSeriesNeedle(index, type);

        MeterNeedle needle = seriesNeedle[index];

        // Reflection to access private fields
        Field fillPaintField = needle.getClass().getDeclaredField("fillPaint");
        fillPaintField.setAccessible(true);
        Color fillPaint = (Color) fillPaintField.get(needle);

        assertAll("Verify WindNeedle and blue paint",
            () -> assertTrue(needle instanceof WindNeedle, "Needle at index should be WindNeedle"),
            () -> assertEquals(Color.BLUE, fillPaint, "Fill paint should be Color.BLUE")
        );
    }

    @Test
    @DisplayName("setSeriesNeedle with type=8 sets ArrowNeedle")
    public void testTC09_setSeriesNeedle_type8() throws Exception {
        CompassPlot compassPlot = new CompassPlot();
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedle = new MeterNeedle[1];
        seriesNeedleField.set(compassPlot, seriesNeedle);

        int type = 8;
        int index = 0;

        compassPlot.setSeriesNeedle(index, type);

        MeterNeedle needle = seriesNeedle[index];

        assertTrue(needle instanceof ArrowNeedle, "Needle at index should be ArrowNeedle");
    }

    @Test
    @DisplayName("setSeriesNeedle with type=9 sets MiddlePinNeedle")
    public void testTC10_setSeriesNeedle_type9() throws Exception {
        CompassPlot compassPlot = new CompassPlot();
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedle = new MeterNeedle[1];
        seriesNeedleField.set(compassPlot, seriesNeedle);

        int type = 9;
        int index = 0;

        compassPlot.setSeriesNeedle(index, type);

        MeterNeedle needle = seriesNeedle[index];

        assertTrue(needle instanceof MiddlePinNeedle, "Needle at index should be MiddlePinNeedle");
    }
}
