package com.fasterxml.jackson.databind.ser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.JsonSerializer;

public class BeanPropertyWriter_serializeAsField_1_1_Test {

    @Test
    @DisplayName("serializeAsField with _suppressableValue as MARKER_FOR_EMPTY and serializer.isEmpty returns false, expecting normal serialization")
    void TC11_serializeAsField_MarkerForEmpty_SerializerNotEmpty() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter();

        // Use reflection to set protected fields
        Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(writer, BeanPropertyWriter.MARKER_FOR_EMPTY);

        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        when(serializer.isEmpty(any(SerializerProvider.class), any())).thenReturn(false);

        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writer, serializer);

        // Mock other necessary fields
        Field nameField = BeanPropertyWriter.class.getDeclaredField("_name");
        nameField.setAccessible(true);
        nameField.set(writer, new com.fasterxml.jackson.core.io.SerializedString("testField"));

        Object bean = new Object();
        Object value = new Object();

        // Mock JsonGenerator and SerializerProvider
        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        // Mock the get method
        Method getMethod = BeanPropertyWriter.class.getDeclaredMethod("get", Object.class);
        getMethod.setAccessible(true);
        when(getMethod.invoke(writer, bean)).thenReturn(value);

        // Act
        writer.serializeAsField(bean, jsonGenerator, serializerProvider);

        // Assert
        verify(jsonGenerator).writeFieldName("testField");
        verify(serializer).serialize(value, jsonGenerator, serializerProvider);
    }

    @Test
    @DisplayName("serializeAsField with _suppressableValue defined but not MARKER_FOR_EMPTY and serializer.isEmpty returns true, expecting field suppression")
    void TC12_serializeAsField_SuppressableValueDefined_SerializerEmpty() throws Exception {
        // Arrange
        BeanPropertyWriter writer = new BeanPropertyWriter();

        // Use reflection to set protected fields
        Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(writer, new Object());

        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        when(serializer.isEmpty(any(SerializerProvider.class), any())).thenReturn(true);

        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        serializerField.set(writer, serializer);

        // Mock other necessary fields
        Field nameField = BeanPropertyWriter.class.getDeclaredField("_name");
        nameField.setAccessible(true);
        nameField.set(writer, new com.fasterxml.jackson.core.io.SerializedString("testField"));

        Object bean = new Object();
        Object value = new Object();

        // Mock JsonGenerator and SerializerProvider
        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        // Mock the get method
        Method getMethod = BeanPropertyWriter.class.getDeclaredMethod("get", Object.class);
        getMethod.setAccessible(true);
        when(getMethod.invoke(writer, bean)).thenReturn(value);

        // Act
        writer.serializeAsField(bean, jsonGenerator, serializerProvider);

        // Assert
        verify(serializer).isEmpty(serializerProvider, value);
        verify(jsonGenerator, never()).writeFieldName(anyString());
        verify(serializer, never()).serialize(any(), any(), any());
    }

    @Test
    @DisplayName("serializeAsField with value referencing the bean and _handleSelfReference throws JsonMappingException")
    void TC13_serializeAsField_SelfReference_ExceptionThrown() throws Exception {
        // Arrange
        BeanPropertyWriter writer = spy(new BeanPropertyWriter());

        // Use reflection to set protected fields
        Field serializerField = BeanPropertyWriter.class.getDeclaredField("_serializer");
        serializerField.setAccessible(true);
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        serializerField.set(writer, serializer);

        // Mock other necessary fields
        Field nameField = BeanPropertyWriter.class.getDeclaredField("_name");
        nameField.setAccessible(true);
        nameField.set(writer, new com.fasterxml.jackson.core.io.SerializedString("testField"));

        Object bean = new Object();
        Object value = bean; // Self-reference

        // Mock JsonGenerator and SerializerProvider
        JsonGenerator jsonGenerator = mock(JsonGenerator.class);
        SerializerProvider serializerProvider = mock(SerializerProvider.class);

        // Configure SerializerProvider to enable FAIL_ON_SELF_REFERENCES
        when(serializerProvider.isEnabled(SerializationFeature.FAIL_ON_SELF_REFERENCES)).thenReturn(true);

        // Mock _handleSelfReference to throw JsonMappingException
        doThrow(new JsonMappingException("Direct self-reference leading to cycle")).when(writer).
            _handleSelfReference(any(), any(), any(), any());

        // Mock the get method
        Method getMethod = BeanPropertyWriter.class.getDeclaredMethod("get", Object.class);
        getMethod.setAccessible(true);
        when(getMethod.invoke(writer, bean)).thenReturn(value);

        // Act & Assert
        JsonMappingException exception = assertThrows(JsonMappingException.class, () -> {
            writer.serializeAsField(bean, jsonGenerator, serializerProvider);
        });
        assertEquals("Direct self-reference leading to cycle", exception.getMessage());
    }
}