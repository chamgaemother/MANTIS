import com.fasterxml.jackson.dataformat.xml.util.StaxUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StaxUtilTest {

    @Test
    public void testSanitizeXmlTypeNameNullInput() {
        assertEquals(null, StaxUtil.sanitizeXmlTypeName(null));
    }

    @Test
    public void testSanitizeXmlTypeNameNoChangeNeeded() {
        assertEquals("SimpleName", StaxUtil.sanitizeXmlTypeName("SimpleName"));
    }

    @Test
    public void testSanitizeXmlTypeNameArrayTypes() {
        assertEquals("Namees", StaxUtil.sanitizeXmlTypeName("Name[]"));
        assertEquals("Dataes", StaxUtil.sanitizeXmlTypeName("Data[][][]"));
        assertEquals("NamesNames", StaxUtil.sanitizeXmlTypeName("Names[]Names[]"));
    }

    @Test
    public void testSanitizeXmlTypeNameWithSpecialCharacters() {
        assertEquals("Com_example_Name", StaxUtil.sanitizeXmlTypeName("Com$example$Name"));
        assertEquals("_Name_", StaxUtil.sanitizeXmlTypeName("_$Name$"));
        assertEquals("A_b_c_", StaxUtil.sanitizeXmlTypeName("A$b*c$"));
    }

    @Test
    public void testSanitizeXmlTypeNameMixedContent() {
        assertEquals("Entity_Specials", StaxUtil.sanitizeXmlTypeName("Entity$Special[]$"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"$", "a$", "9$", "a-.-9$_"})
    public void testSanitizeXmlTypeNameEdgeCases(String input) {
        assertEquals(input.replace("$", "."), StaxUtil.sanitizeXmlTypeName(input));
    }
}