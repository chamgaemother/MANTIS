package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TokenMgrError_addEscapes_1_1_Test {

    @Test
    @DisplayName("addEscapes with a single ASCII control character (char 1) triggers Unicode escape sequence")
    void TC22() {
        // GIVEN
        String input = "\u0001";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\u0001", result);
    }

    @Test
    @DisplayName("addEscapes with characters at the boundary of high-ASCII (char 127 and char 128) triggers Unicode escape sequences")
    void TC23() {
        // GIVEN
        String input = "\u007f\u0080";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\u007f\\u0080", result);
    }

    @Test
    @DisplayName("addEscapes with a mix of escape characters and Unicode characters within the string")
    void TC24() {
        // GIVEN
        String input = "\n\u001E";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\n\\u001E", result);
    }

    @Test
    @DisplayName("addEscapes with a string ending with a high-ASCII character to ensure proper Unicode escaping")
    void TC25() {
        // GIVEN
        String input = "End\u0081";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("End\\u0081", result);
    }

    @Test
    @DisplayName("addEscapes with consecutive high-ASCII characters to verify multiple Unicode escapes")
    void TC26() {
        // GIVEN
        String input = "\u0082\u0083";
        // WHEN
        String result = TokenMgrError.addEscapes(input);
        // THEN
        assertEquals("\\u0082\\u0083", result);
    }
}