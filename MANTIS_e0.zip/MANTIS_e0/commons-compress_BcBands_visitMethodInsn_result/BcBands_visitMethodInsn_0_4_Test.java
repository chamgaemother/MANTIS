package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.List;

public class BcBands_visitMethodInsn_0_4_Test {

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), owner is superClass, name is <init>")
    public void TC16() throws Exception {
        int opcode = 183;
        String owner = "superClass";
        String name = "<init>";
        String desc = "()V";
        BcBands bcBands = createBcBands();

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        bcCodes.clear();

        bcBands.visitMethodInsn(opcode, owner, name, desc);

        Field bcCodesResultField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesResultField.setAccessible(true);
        List<Integer> opcodes = (List<Integer>) bcCodesResultField.get(bcBands);
        assertEquals(231, opcodes.get(opcodes.size() - 1).intValue(), "Opcode should be set to 231 (invokespecial_super_init)");

        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        List<Object> bcInitRef = (List<Object>) bcInitRefField.get(bcBands);
        assertFalse(bcInitRef.isEmpty(), "bcInitRef should contain the method reference");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), owner is superClass and name is not <init>")
    public void TC17() throws Exception {
        int opcode = 183;
        String owner = "superClass";
        String name = "superMethod";
        String desc = "(I)V";
        BcBands bcBands = createBcBands();

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        bcCodes.clear();

        bcBands.visitMethodInsn(opcode, owner, name, desc);

        Field bcCodesResultField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesResultField.setAccessible(true);
        List<Integer> opcodes = (List<Integer>) bcCodesResultField.get(bcBands);
        assertEquals(221, opcodes.get(opcodes.size() - 1).intValue(), "Opcode should be set to 221");

        Field bcSuperMethodField = BcBands.class.getDeclaredField("bcSuperMethod");
        bcSuperMethodField.setAccessible(true);
        List<Object> bcSuperMethod = (List<Object>) bcSuperMethodField.get(bcBands);
        assertFalse(bcSuperMethod.isEmpty(), "bcSuperMethod should contain the method reference");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), z5 is false and name is not <init>")
    public void TC18() throws Exception {
        int opcode = 183;
        String owner = "anotherClass";
        String name = "anotherMethod";
        String desc = "(Ljava/lang/String;)V";
        BcBands bcBands = createBcBands();

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        bcCodes.clear();
        bcCodes.add(50);

        bcBands.visitMethodInsn(opcode, owner, name, desc);

        Field bcCodesResultField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesResultField.setAccessible(true);
        List<Integer> opcodes = (List<Integer>) bcCodesResultField.get(bcBands);
        assertEquals(176, opcodes.get(opcodes.size() - 1).intValue(), "Opcode should be decreased by 7 to 176");

        assertTrue(bcCodes.contains(42), "ALOAD_0 (42) should be added back to bcCodes");

        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        List<Object> bcMethodRef = (List<Object>) bcMethodRefField.get(bcBands);
        assertFalse(bcMethodRef.isEmpty(), "bcMethodRef should contain the method reference");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), owner is neither currentClass nor superClass and name is not <init>")
    public void TC19() throws Exception {
        int opcode = 183;
        String owner = "externalOtherClass";
        String name = "externalMethod";
        String desc = "(I)V";
        BcBands bcBands = createBcBands();

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        bcCodes.clear();

        bcBands.visitMethodInsn(opcode, owner, name, desc);

        Field bcCodesResultField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesResultField.setAccessible(true);
        List<Integer> opcodes = (List<Integer>) bcCodesResultField.get(bcBands);
        assertEquals(232, opcodes.get(opcodes.size() - 1).intValue(), "Opcode should be set to 232");

        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        List<Object> bcInitRef = (List<Object>) bcInitRefField.get(bcBands);
        assertFalse(bcInitRef.isEmpty(), "bcInitRef should contain the method reference");

        assertTrue(bcCodes.contains(42), "ALOAD_0 (42) should be added back to bcCodes");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), owner equals superClass and name is <init>")
    public void TC20() throws Exception {
        int opcode = 183;
        String owner = "superClass";
        String name = "<init>";
        String desc = "()V";
        BcBands bcBands = createBcBands();

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        bcCodes.clear();

        bcBands.visitMethodInsn(opcode, owner, name, desc);

        Field bcCodesResultField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesResultField.setAccessible(true);
        List<Integer> opcodes = (List<Integer>) bcCodesResultField.get(bcBands);
        assertEquals(231, opcodes.get(opcodes.size() - 1).intValue(), "Opcode should be set to 231 (invokespecial_super_init)");

        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        List<Object> bcInitRef = (List<Object>) bcInitRefField.get(bcBands);
        assertFalse(bcInitRef.isEmpty(), "bcInitRef should contain the method reference");
    }

    private BcBands createBcBands() throws Exception {
        // Assuming defaults for CpBands and Segment constructors are required
        CpBands mockCpBands = new CpBands();
        Segment mockSegment = new Segment();
        return new BcBands(mockCpBands, mockSegment, 1);
    }
} 
