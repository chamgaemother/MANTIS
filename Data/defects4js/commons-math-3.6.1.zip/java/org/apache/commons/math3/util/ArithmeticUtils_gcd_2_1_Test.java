package org.apache.commons.math3.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ArithmeticUtils_gcd_2_1_Test {

    @Test
    @DisplayName("gcd(Integer.MAX_VALUE, 1) returns 1 when one operand is Integer.MAX_VALUE and the other is 1")
    void TC23_gcd_IntegerMaxValue_and_1() {
        // GIVEN
        int p = Integer.MAX_VALUE;
        int q = 1;

        // WHEN
        int result = ArithmeticUtils.gcd(p, q);

        // THEN
        assertEquals(1, result, "Expected gcd(Integer.MAX_VALUE, 1) to be 1");
    }

    @Test
    @DisplayName("gcd(1, Integer.MAX_VALUE) returns 1 when one operand is 1 and the other is Integer.MAX_VALUE")
    void TC24_gcd_1_and_IntegerMaxValue() {
        // GIVEN
        int p = 1;
        int q = Integer.MAX_VALUE;

        // WHEN
        int result = ArithmeticUtils.gcd(p, q);

        // THEN
        assertEquals(1, result, "Expected gcd(1, Integer.MAX_VALUE) to be 1");
    }

    @Test
    @DisplayName("gcd(100, 100) returns 100 when both operands are equal and positive")
    void TC25_gcd_equal_positive_operands() {
        // GIVEN
        int p = 100;
        int q = 100;

        // WHEN
        int result = ArithmeticUtils.gcd(p, q);

        // THEN
        assertEquals(100, result, "Expected gcd(100, 100) to be 100");
    }

    @Test
    @DisplayName("gcd(1, 7) returns 1 when first operand is 1 and second is positive")
    void TC26_gcd_1_and_7() {
        // GIVEN
        int p = 1;
        int q = 7;

        // WHEN
        int result = ArithmeticUtils.gcd(p, q);

        // THEN
        assertEquals(1, result, "Expected gcd(1, 7) to be 1");
    }

    @Test
    @DisplayName("gcd(7, 1) returns 1 when second operand is 1 and first is positive")
    void TC27_gcd_7_and_1() {
        // GIVEN
        int p = 7;
        int q = 1;

        // WHEN
        int result = ArithmeticUtils.gcd(p, q);

        // THEN
        assertEquals(1, result, "Expected gcd(7, 1) to be 1");
    }
}