package org.jfree.chart.renderer.category;
// 
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.data.category.CategoryDataset;
// import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.geom.Rectangle2D;
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
public class BoxAndWhiskerRenderer_drawHorizontalItem_2_2_Test {
// 
//     @Test
//     @DisplayName("Handles useOutlinePaintForWhiskers=false ensuring item paint is used for whiskers")
//     void TC26_UseOutlinePaintForWhiskersFalse() throws Exception {
        // Arrange
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setUseOutlinePaintForWhiskers(false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
// 
//         when(dataset.getQ1Value(row, column)).thenReturn(3.0);
//         when(dataset.getQ3Value(row, column)).thenReturn(7.0);
//         when(dataset.getMaxRegularValue(row, column)).thenReturn(9.0);
//         when(dataset.getMinRegularValue(row, column)).thenReturn(2.0);
//         when(dataset.getMeanValue(row, column)).thenReturn(5.0);
//         when(dataset.getMedianValue(row, column)).thenReturn(5.5);
// 
//         Paint itemPaint = mock(Paint.class);
//         when(renderer.getItemPaint(row, column)).thenReturn(itemPaint);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
        // Act
//         renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
// 
        // Assert
        // Verify that setPaint was called with itemPaint before drawing whiskers
//         verify(g2).setPaint(itemPaint);
//     }
// 
//     @Test
//     @DisplayName("Throws IllegalArgumentException when dataset is not an instance of BoxAndWhiskerCategoryDataset")
//     void TC27_InvalidDataset_ThrowsException() {
        // Arrange
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset invalidDataset = mock(CategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
// 
        // Act & Assert
//         assertThrows(IllegalArgumentException.class, () -> {
//             renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, invalidDataset, row, column);
//         });
//     }
// 
//     @Test
//     @DisplayName("Handles scenario where Q1 equals Q3 resulting in a zero-width box")
//     void TC28_Q1EqualsQ3_DrawsZeroWidthBox() throws Exception {
        // Arrange
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
// 
//         when(dataset.getQ1Value(row, column)).thenReturn(5.0);
//         when(dataset.getQ3Value(row, column)).thenReturn(5.0);
//         when(dataset.getMaxRegularValue(row, column)).thenReturn(10.0);
//         when(dataset.getMinRegularValue(row, column)).thenReturn(0.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
        // Act
//         renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
// 
        // Assert
        // Verify that a box with zero width is drawn as a vertical line
//         ArgumentCaptor<Rectangle2D> rectangleCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
//         verify(g2, atLeastOnce()).draw(rectangleCaptor.capture());
//         boolean zeroWidthBoxDrawn = rectangleCaptor.getAllValues().stream()
//             .anyMatch(rectangle -> rectangle.getWidth() == 0);
//         assertTrue(zeroWidthBoxDrawn, "A zero-width box (vertical line) should be drawn");
//     }
// }
}