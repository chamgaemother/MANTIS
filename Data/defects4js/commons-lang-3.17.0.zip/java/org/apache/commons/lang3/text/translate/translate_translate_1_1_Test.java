package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;

import java.io.StringWriter;
import java.io.Writer;
import java.io.IOException;

public class translate_translate_1_1_Test {

    @Test
    @DisplayName("translate method returns 0 when translators list is empty")
    public void TC01_translate_method_returns_0_when_translators_list_is_empty() throws IOException {
        // GIVEN
        AggregateTranslator translator = new AggregateTranslator();
        CharSequence input = "Test input";
        int index = 0;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(0, result, "Expected translate to return 0 when translators list is empty");
    }

    @Test
    @DisplayName("translate method returns 0 with empty translators and different input index")
    public void TC02_translate_method_returns_0_with_empty_translators_and_different_input_index() throws IOException {
        // GIVEN
        AggregateTranslator translator = new AggregateTranslator();
        CharSequence input = "Another test input";
        int index = 5;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(0, result, "Expected translate to return 0 with empty translators and non-zero index");
    }

    @Test
    @DisplayName("translate method returns 0 when single translator returns 0")
    public void TC03_translate_method_returns_0_when_single_translator_returns_0() throws IOException {
        // GIVEN
        CharSequenceTranslator stubTranslator = mock(CharSequenceTranslator.class);
        when(stubTranslator.translate(any(), anyInt(), any())).thenReturn(0);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator);
        CharSequence input = "Sample input";
        int index = 0;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(0, result, "Expected translate to return 0 when single translator returns 0");
    }

    @Test
    @DisplayName("translate method returns 0 with single translator returning 0 and different input")
    public void TC04_translate_method_returns_0_with_single_translator_returning_0_and_different_input() throws IOException {
        // GIVEN
        CharSequenceTranslator stubTranslator = mock(CharSequenceTranslator.class);
        when(stubTranslator.translate(any(), anyInt(), any())).thenReturn(0);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator);
        CharSequence input = "Another sample input";
        int index = 3;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(0, result, "Expected translate to return 0 with single translator returning 0 and non-zero index");
    }

    @Test
    @DisplayName("translate method returns consumed value when single translator returns non-zero")
    public void TC05_translate_method_returns_consumed_value_when_single_translator_returns_non_zero() throws IOException {
        // GIVEN
        CharSequenceTranslator stubTranslator = mock(CharSequenceTranslator.class);
        when(stubTranslator.translate(any(), anyInt(), any())).thenReturn(5);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator);
        CharSequence input = "Translatable input";
        int index = 0;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(5, result, "Expected translate to return the consumed value from the translator");
    }
}