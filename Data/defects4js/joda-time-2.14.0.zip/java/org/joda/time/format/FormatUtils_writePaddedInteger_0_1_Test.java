package org.joda.time.format;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.io.StringWriter;
import java.io.Writer;
import static org.junit.jupiter.api.Assertions.*;

public class FormatUtils_writePaddedInteger_0_1_Test {

    @Test
    @DisplayName("writePaddedInteger with positive value <10 and size equals 1 (no padding needed)")
    void TC01_writePaddedInteger_positive_single_digit_no_padding() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 5;
        int size = 1;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("5", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value <10 and size equals 3 (two padding iterations)")
    void TC02_writePaddedInteger_positive_single_digit_with_padding() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 7;
        int size = 3;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("007", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value <10 and size equals 5 (multiple padding iterations)")
    void TC03_writePaddedInteger_positive_single_digit_with_multiple_paddings() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 3;
        int size = 5;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("00003", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value between 10 and 99 and size <=10")
    void TC04_writePaddedInteger_positive_two_digit_with_padding() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 45;
        int size = 4;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("0045", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value between 10 and 99 and size >10 (writes \"2147483648\")")
    void TC05_writePaddedInteger_positive_two_digit_with_maximum_padding() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 99;
        int size = 11;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("2147483648", writer.toString());
    }
}