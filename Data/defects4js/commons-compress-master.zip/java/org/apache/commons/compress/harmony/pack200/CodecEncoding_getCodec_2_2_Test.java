package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;

public class CodecEncoding_getCodec_2_2_Test {

    @Test
    @DisplayName("Handles PopulationCodec with tdef=true, fdef=true, udef=true")
    void TC38_PopulationCodec_tdef_true_fdef_true_udef_true() throws Exception {
        // GIVEN
        int value = 161; // Adjusted value to set tDef=true, fDef=true, uDef=true
        byte[] inputData = {}; // No additional input required when all defs are true
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = new BHSDCodec(1, 256, 1, 1); // Example defaultCodec initialization
        
        // WHEN
        Codec result = CodecEncoding.getCodec(value, inputStream, defaultCodec);
        
        // THEN
        assertAll("PopulationCodec Assertions",
            () -> assertTrue(result instanceof PopulationCodec, "Result should be an instance of PopulationCodec"),
            () -> assertEquals(defaultCodec, ((PopulationCodec) result).getFavouredCodec(), "fCodec should equal defaultCodec"),
            () -> assertEquals(defaultCodec, ((PopulationCodec) result).getUnfavouredCodec(), "uCodec should equal defaultCodec")
        );
    }
}