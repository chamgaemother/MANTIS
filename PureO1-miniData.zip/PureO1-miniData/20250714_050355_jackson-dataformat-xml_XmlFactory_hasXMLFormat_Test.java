package com.fasterxml.jackson.dataformat.xml;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.format.InputAccessor;
import com.fasterxml.jackson.core.format.MatchStrength;

/**
 * Test class for XmlFactory.hasXMLFormat method.
 */
public class XmlFactoryTest {

    /**
     * Helper class to implement InputAccessor from byte array.
     */
    private static class ByteArrayInputAccessor implements InputAccessor {
        private final byte[] data;
        private final int length;
        private int ptr;

        public ByteArrayInputAccessor(byte[] data, int offset, int len) {
            this.data = data;
            this.length = offset + len;
            this.ptr = offset;
        }

        @Override
        public boolean hasMoreBytes() {
            return ptr < length;
        }

        @Override
        public byte nextByte() throws IOException {
            if (!hasMoreBytes()) {
                throw new IOException("No more bytes available");
            }
            return data[ptr++];
        }

        @Override
        public void reset() throws IOException {
            ptr = 0;
        }

        @Override
        public Object getSourceReference() {
            return data;
        }
    }

    @Test
    public void hasXMLFormat_NoBytes() throws IOException {
        InputAccessor accessor = new ByteArrayInputAccessor(new byte[0], 0, 0);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void hasXMLFormat_UTF8BOM_Valid() throws IOException {
        byte[] bom = {(byte)0xEF, (byte)0xBB, (byte)0xBF};
        byte[] data = concatenate(bom, "<xml>".getBytes());
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_UTF8BOM_Invalid2ndByte() throws IOException {
        byte[] data = {(byte)0xEF, (byte)0x00, (byte)0xBF, '<'};
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_UTF8BOM_Invalid3rdByte() throws IOException {
        byte[] data = {(byte)0xEF, (byte)0xBB, (byte)0x00, '<'};
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_UTF8BOM_Incomplete() throws IOException {
        byte[] bomPartial = {(byte)0xEF, (byte)0xBB};
        InputAccessor accessor = new ByteArrayInputAccessor(bomPartial, 0, bomPartial.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void hasXMLFormat_XMLDeclaration_FullMatch() throws IOException {
        String xmlDecl = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root/>";
        byte[] data = xmlDecl.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.FULL_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_XMLDeclaration_Incomplete() throws IOException {
        String xmlDeclPartial = "<?xml";
        byte[] data = xmlDeclPartial.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_XMLQuestionMark_NotXmlDecl() throws IOException {
        String dataStr = "<?test>";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_XMLExclamation_Hyphen_Hyphen() throws IOException {
        String dataStr = "<!-- comment -->";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_XMLExclamation_DocType() throws IOException {
        String dataStr = "<!DOCTYPE html>";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_XMLExclamation_Invalid() throws IOException {
        String dataStr = "<!invalid>";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_StartWithLessThanFollowedByValidName() throws IOException {
        String dataStr = "<tag>";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_StartWithLessThanFollowedByInvalidName() throws IOException {
        String dataStr = "<1tag>";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_SpacesThenLessThan() throws IOException {
        String dataStr = "    <tag>";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_SpacesThenInvalid() throws IOException {
        String dataStr = "    invalid";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_NoLeadingLT() throws IOException {
        String dataStr = "data";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }

    @Test
    public void hasXMLFormat_IncompleteAfterLT() throws IOException {
        String dataStr = "<";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void hasXMLFormat_EndAfterSpaces() throws IOException {
        String dataStr = "    ";
        byte[] data = dataStr.getBytes();
        InputAccessor accessor = new ByteArrayInputAccessor(data, 0, data.length);
        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void hasXMLFormat_NullInput() throws IOException {
        assertThrows(NullPointerException.class, () -> {
            XmlFactory.hasXMLFormat(null);
        });
    }

    // Helper method to concatenate two byte arrays
    private byte[] concatenate(byte[] a, byte[] b) {
        byte[] result = new byte[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }
}