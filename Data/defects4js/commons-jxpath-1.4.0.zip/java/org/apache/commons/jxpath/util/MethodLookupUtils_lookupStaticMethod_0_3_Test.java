package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.jxpath.util.MethodLookupUtils;
import org.apache.commons.jxpath.JXPathException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import static org.junit.jupiter.api.Assertions.*;

public class MethodLookupUtils_lookupStaticMethod_0_3_Test {

    @Test
    @DisplayName("Loop over methods with single static method matching after type conversion")
    public void TC11() throws Exception {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "convertibleMethod";
        Object[] parameters = new Object[]{ "123" };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected method to be found");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Expected method to be static");
        assertEquals(Integer.class, result.getParameterTypes()[0], "Expected parameter type to be Integer.class");
    }

    @Test
    @DisplayName("Loop over methods with no static methods matching the name")
    public void TC12() {
        // GIVEN
        Class<?> targetClass = NoStaticMethodClass.class;
        String name = "nonStaticMethod";
        Object[] parameters = new Object[]{ };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNull(result, "Expected no method to be found");
    }

    @Test
    @DisplayName("Ambiguous method call due to multiple static methods matching equally after type conversion")
    public void TC13() {
        // GIVEN
        Class<?> targetClass = AmbiguousClass.class;
        String name = "ambiguousMethod";
        Object[] parameters = new Object[]{ "value" };

        // WHEN & THEN
        JXPathException exception = assertThrows(JXPathException.class, () -> {
            Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);
        }, "Expected JXPathException to be thrown");
        assertTrue(exception.getMessage().contains("Ambiguous method call"), "Exception message should indicate ambiguity");
    }

    // Inner classes for testing purposes
    static class SomeClass {
        public static Integer convertibleMethod(Integer value) { return value; }
    }

    static class NoStaticMethodClass {
        public void nonStaticMethod() { }
    }

    static class AmbiguousClass {
        public static Integer ambiguousMethod(String value) { return 1; }
        public static Integer ambiguousMethod(Integer value) { return 2; }
    }
}