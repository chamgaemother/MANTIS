package org.jfree.chart.renderer.category;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import org.mockito.ArgumentCaptor;

public class StatisticalLineAndShapeRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("Entity collection is present and entity is added after drawing")
    void TC11_entityCollectionIsPresentAndEntityIsAddedAfterDrawing() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        int row = 1;
        int column = 1;
        int pass = 1;

        StatisticalCategoryDataset statDataset = mock(StatisticalCategoryDataset.class);
        when(statDataset.getMeanValue(row, column)).thenReturn(22.0);
        when(state.getVisibleSeriesIndex(row)).thenReturn(1);
        when(state.getVisibleSeriesCount()).thenReturn(5);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        StatisticalLineAndShapeRenderer renderer = spy(new StatisticalLineAndShapeRenderer());
        when(renderer.getUseSeriesOffset()).thenReturn(true);
        when(renderer.getItemShapeVisible(row, column)).thenReturn(false);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);
        when(state.getEntityCollection()).thenReturn(mock(EntityCollection.class));
        when(renderer.getItemVisible(row, column)).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, pass);

        // Assert
        verify(renderer).addEntity(any(EntityCollection.class), any(), eq(statDataset), eq(row), eq(column), anyDouble(), anyDouble());
    }

    @Test
    @DisplayName("Standard deviation exceeds upper and lower bounds, capped at axis bounds")
    void TC12_standardDeviationExceedsBounds_CappedAtAxis() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        int row = 1;
        int column = 2;
        int pass = 1;

        StatisticalCategoryDataset statDataset = mock(StatisticalCategoryDataset.class);
        when(statDataset.getMeanValue(row, column)).thenReturn(95.0);
        when(statDataset.getStdDevValue(row, column)).thenReturn(10.0);
        Range axisRange = new Range(0.0, 100.0);
        when(rangeAxis.getRange()).thenReturn(axisRange);
        when(state.getVisibleSeriesIndex(row)).thenReturn(1);
        when(state.getVisibleSeriesCount()).thenReturn(5);

        StatisticalLineAndShapeRenderer renderer = spy(new StatisticalLineAndShapeRenderer());
        when(renderer.getUseSeriesOffset()).thenReturn(true);
        when(renderer.getItemVisible(row, column)).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, pass);

        // Assert
        // Verify that standard deviation lines are drawn
        ArgumentCaptor<Line2D> captor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, atLeastOnce()).draw(captor.capture());

        for (Line2D line : captor.getAllValues()) {
            assertTrue(line.getY1() <= 100.0 && line.getY1() >= 0.0, "Line exceeds range bounds");
        }
    }
}