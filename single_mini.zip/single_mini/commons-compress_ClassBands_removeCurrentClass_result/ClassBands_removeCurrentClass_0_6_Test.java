package org.apache.commons.compress.harmony.pack200;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ClassBands_removeCurrentClass_0_6_Test {

    @Mock
    private Segment segment;

    @Mock
    private CpBands cpBands;

    @Mock
    private AttributeDefinitionBands attrBands;

    @InjectMocks
    private ClassBands classBands;

    @Test
    @DisplayName("Does not remove codeLineNumberTable elements when codeFlags do not have bit 1 set")
    void TC26() throws Exception {
        // Setup mocks
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with required parameters
        classBands = new ClassBands(segment, 1, 0, false);

        // Reflection setup for class_flags
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] class_flags = new long[1];
        class_flags[0] = 0; // Ensure bit 1 is not set
        classFlagsField.set(classBands, class_flags);

        // Reflection setup for tempMethodFlags
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add(0L); // Flags without bit 1 set
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Reflection setup for codeLineNumberTableN
        Field codeLineNumberTableNField = ClassBands.class.getDeclaredField("codeLineNumberTableN");
        codeLineNumberTableNField.setAccessible(true);
        List<Integer> codeLineNumberTableN = new ArrayList<>();
        codeLineNumberTableN.add(1); // Initial size
        codeLineNumberTableNField.set(classBands, codeLineNumberTableN);

        Field codeLineNumberTableLineField = ClassBands.class.getDeclaredField("codeLineNumberTableLine");
        codeLineNumberTableLineField.setAccessible(true);
        List<Integer> codeLineNumberTableLine = new ArrayList<>();
        codeLineNumberTableLine.add(100); // Example line number
        codeLineNumberTableLineField.set(classBands, codeLineNumberTableLine);

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that codeLineNumberTable remains unchanged
        assertEquals(1, codeLineNumberTableN.size(), "codeLineNumberTableN size should remain unchanged");
        assertEquals(100, codeLineNumberTableLine.get(0), "codeLineNumberTableLine should remain unchanged");
    }

    @Test
    @DisplayName("Removes method_RVA_bands when methodFlags have bit 21 set")
    void TC27() throws Exception {
        // Setup mocks
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with required parameters
        classBands = new ClassBands(segment, 1, 0, false);

        // Reflection setup for tempMethodFlags
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add(1L << 21); // Flags with bit 21 set
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Reflection setup for method_RVA_bands
        Field methodRVABandsField = ClassBands.class.getDeclaredField("method_RVA_bands");
        methodRVABandsField.setAccessible(true);
        MetadataBandGroup method_RVA_bands = new MetadataBandGroup("RVA", MetadataBandGroup.CONTEXT_METHOD, cpBands, null, 0);
        method_RVA_bands.addEntry("Entry1");
        methodRVABandsField.set(classBands, method_RVA_bands);

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that the latest entry is removed
        assertTrue(method_RVA_bands.isEmpty(), "method_RVA_bands should be empty after removal");
    }

    @Test
    @DisplayName("Does not remove method_RVA_bands when methodFlags do not have bit 21 set")
    void TC28() throws Exception {
        // Setup mocks
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with required parameters
        classBands = new ClassBands(segment, 1, 0, false);

        // Reflection setup for tempMethodFlags
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add(0L); // Flags without bit 21 set
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Reflection setup for method_RVA_bands
        Field methodRVABandsField = ClassBands.class.getDeclaredField("method_RVA_bands");
        methodRVABandsField.setAccessible(true);
        MetadataBandGroup method_RVA_bands = new MetadataBandGroup("RVA", MetadataBandGroup.CONTEXT_METHOD, cpBands, null, 0);
        method_RVA_bands.addEntry("Entry1");
        methodRVABandsField.set(classBands, method_RVA_bands);

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that method_RVA_bands remains unchanged
        assertEquals(1, method_RVA_bands.size(), "method_RVA_bands size should remain unchanged");
    }

    @Test
    @DisplayName("Removes method_RIPA_bands and method_AD_bands when methodFlags have bits 24 and 25 set")
    void TC29() throws Exception {
        // Setup mocks
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with required parameters
        classBands = new ClassBands(segment, 1, 0, false);

        // Reflection setup for tempMethodFlags
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add((1L << 24) | (1L << 25)); // Flags with bits 24 and 25 set
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Reflection setup for method_RIPA_bands
        Field methodRIPABandsField = ClassBands.class.getDeclaredField("method_RIPA_bands");
        methodRIPABandsField.setAccessible(true);
        MetadataBandGroup method_RIPA_bands = new MetadataBandGroup("RIPA", MetadataBandGroup.CONTEXT_METHOD, cpBands, null, 0);
        method_RIPA_bands.addEntry("Entry1");
        methodRIPABandsField.set(classBands, method_RIPA_bands);

        // Reflection setup for method_AD_bands
        Field methodADBandsField = ClassBands.class.getDeclaredField("method_AD_bands");
        methodADBandsField.setAccessible(true);
        MetadataBandGroup method_AD_bands = new MetadataBandGroup("AD", MetadataBandGroup.CONTEXT_METHOD, cpBands, null, 0);
        method_AD_bands.addEntry("Entry1");
        methodADBandsField.set(classBands, method_AD_bands);

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that the latest entries are removed
        assertTrue(method_RIPA_bands.isEmpty(), "method_RIPA_bands should be empty after removal");
        assertTrue(method_AD_bands.isEmpty(), "method_AD_bands should be empty after removal");
    }

    @Test
    @DisplayName("Handles index decrement correctly when index > 0")
    void TC30() throws Exception {
        // Setup mocks
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with required parameters
        classBands = new ClassBands(segment, 2, 0, false);

        // Reflection setup for index
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 1); // Set index > 0

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that index is decremented by one
        assertEquals(0, indexField.getInt(classBands), "index should be decremented by one");
    }
}