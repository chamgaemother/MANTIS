package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.CompassPlot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CompassPlot_setSeriesNeedle_0_3_Test {

    @Test
    @DisplayName("setSeriesNeedle with unrecognised type throws IllegalArgumentException")
    void TC11_setSeriesNeedle_invalidType() {
        CompassPlot compassPlot = new CompassPlot();
        int type = 10;
        int index = 0;

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            compassPlot.setSeriesNeedle(type, index);
        });
        assertEquals("Unrecognised type.", exception.getMessage());
    }
}