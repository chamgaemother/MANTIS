import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.annotations.XYAnnotationBoundsInfo;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.data.Range;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.general.DatasetUtilities;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class XYPlotTest {

    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYItemRenderer renderer;
    private XYDataset dataset;

    @BeforeEach
    public void setUp() {
        plot = new XYPlot();
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        renderer = mock(XYItemRenderer.class);
        dataset = mock(XYDataset.class);
        
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
    }

    @Test
    public void testGetDataRange_NoAxis() {
        assertNull(plot.getDataRange(null));
    }

    @Test
    public void testGetDataRange_DomainAxis_NullDataset() {
        plot.setDataset(null);
        assertNull(plot.getDataRange(domainAxis));
    }

    @Test
    public void testGetDataRange_RangeAxis_NullDataset() {
        plot.setDataset(null);
        assertNull(plot.getDataRange(rangeAxis));
    }

    @Test
    public void testGetDataRange_DomainAxis_EmptyDataset() {
        when(renderer.findDomainBounds(dataset)).thenReturn(null);
        when(dataset.getItemCount(0)).thenReturn(0);
        assertNull(plot.getDataRange(domainAxis));
    }

    @Test
    public void testGetDataRange_RangeAxis_EmptyDataset() {
        when(renderer.findRangeBounds(dataset)).thenReturn(null);
        when(dataset.getItemCount(0)).thenReturn(0);
        assertNull(plot.getDataRange(rangeAxis));
    }

    @Test
    public void testGetDataRange_DomainAxis_ValidDataset() {
        Range domainRange = new Range(1.0, 8.0);
        when(renderer.findDomainBounds(dataset)).thenReturn(domainRange);
        assertEquals(domainRange, plot.getDataRange(domainAxis));
    }

    @Test
    public void testGetDataRange_RangeAxis_ValidDataset() {
        Range rangeRange = new Range(2.0, 10.0);
        when(renderer.findRangeBounds(dataset)).thenReturn(rangeRange);
        assertEquals(rangeRange, plot.getDataRange(rangeAxis));
    }

    @Test
    public void testGetDataRange_DomainAxis_WithAnnotations() {
        Range domainRange = new Range(1.0, 8.0);
        when(renderer.findDomainBounds(dataset)).thenReturn(domainRange);
        
        XYAnnotation annotation = mock(XYAnnotationBoundsInfo.class);
        when(((XYAnnotationBoundsInfo) annotation).getXRange()).thenReturn(
                new Range(5.0, 15.0));
        when(((XYAnnotationBoundsInfo) annotation).getIncludeInDataBounds())
                .thenReturn(true);
        plot.addAnnotation(annotation);

        assertEquals(new Range(1.0, 15.0), plot.getDataRange(domainAxis));
    }

    @Test
    public void testGetDataRange_RangeAxis_WithAnnotations() {
        Range rangeRange = new Range(2.0, 10.0);
        when(renderer.findRangeBounds(dataset)).thenReturn(rangeRange);
        
        XYAnnotation annotation = mock(XYAnnotationBoundsInfo.class);
        when(((XYAnnotationBoundsInfo) annotation).getYRange()).thenReturn(
                new Range(3.0, 15.0));
        when(((XYAnnotationBoundsInfo) annotation).getIncludeInDataBounds())
                .thenReturn(true);
        plot.addAnnotation(annotation);

        assertEquals(new Range(2.0, 15.0), plot.getDataRange(rangeAxis));
    }
}