package com.fasterxml.jackson.dataformat.xml;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.format.InputAccessor;
import com.fasterxml.jackson.core.format.MatchStrength;

public class XmlFactory_hasXMLFormat_0_1_Test {

    static class MockInputAccessor implements InputAccessor {
        private final byte[] data;
        private int position = 0;

        MockInputAccessor(byte[] data) { this.data = data; }

        @Override
        public boolean hasMoreBytes() { return position < data.length; }

        @Override
        public byte nextByte() { return data[position++]; }

        @Override
        public void reset() { position = 0; }
    }

    @Test
    @DisplayName("InputAccessor has no bytes, should return INCONCLUSIVE")
    void TC01() throws IOException {
        // Arrange
        InputAccessor acc = new MockInputAccessor(new byte[0]);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.INCONCLUSIVE, result);
    }

    @Test
    @DisplayName("InputAccessor has only UTF-8 BOM byte 1, incomplete BOM, should return INCONCLUSIVE")
    void TC02() throws IOException {
        // Arrange
        InputAccessor acc = new MockInputAccessor(new byte[] {(byte) -17});
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.INCONCLUSIVE, result);
    }

    @Test
    @DisplayName("InputAccessor has complete UTF-8 BOM followed by '<?xml', should return FULL_MATCH")
    void TC03() throws IOException {
        // Arrange
        byte[] data = {(byte)-17, (byte)-69, (byte)-65, '<', '?', 'x', 'm', 'l', ' '};
        InputAccessor acc = new MockInputAccessor(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.FULL_MATCH, result);
    }

    @Test
    @DisplayName("InputAccessor has UTF-8 BOM followed by '<root', should return SOLID_MATCH")
    void TC04() throws IOException {
        // Arrange
        byte[] data = {(byte)-17, (byte)-69, (byte)-65, '<', 'r', 'o', 'o', 't'};
        InputAccessor acc = new MockInputAccessor(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.SOLID_MATCH, result);
    }

    @Test
    @DisplayName("InputAccessor without BOM, starts with '<?xml', should return FULL_MATCH")
    void TC05() throws IOException {
        // Arrange
        byte[] data = {'<', '?', 'x', 'm', 'l', ' '};
        InputAccessor acc = new MockInputAccessor(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.FULL_MATCH, result);
    }
}