package org.jfree.data.general;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DatasetUtils_iterateToFindDomainBounds_1_1_Test {

    @Test
    @DisplayName("Throws IndexOutOfBoundsException when visibleSeriesKeys includes a nonexistent series key")
    public void TC13_iterateToFindDomainBounds_withNonexistentSeriesKey_throwsException() {
        // Arrange
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("NonexistentSeries");
        when(dataset.indexOf("NonexistentSeries")).thenReturn(-1);
        when(dataset.getItemCount(-1)).thenThrow(new IndexOutOfBoundsException());

        boolean includeInterval = true;

        // Act & Assert
        assertThrows(IndexOutOfBoundsException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);
        });
    }

    @Test
    @DisplayName("Returns correct Range when includeInterval is false and dataset is IntervalXYDataset")
    public void TC14_iterateToFindDomainBounds_includeIntervalFalse_returnsCorrectRange() {
        // Arrange
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Comparable seriesKey = "Series1";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey);
        when(dataset.indexOf(seriesKey)).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(20.0);
        // Since includeInterval is false, getStartXValue and getEndXValue are ignored
        boolean includeInterval = false;

        // Act
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // Assert
        assertNotNull(result, "The result should not be null");
        assertEquals(10.0, result.getLowerBound(), "Lower bound should be 10.0");
        assertEquals(20.0, result.getUpperBound(), "Upper bound should be 20.0");
    }
}