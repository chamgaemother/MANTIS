package org.jfree.chart.renderer.category;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BoxAndWhiskerRenderer_drawHorizontalItem_0_3_Test {

    @Test
    @DisplayName("Handles useOutlinePaintForWhiskers=false to use item paint for whiskers")
    public void TC11_handlesUseOutlinePaintForWhiskersFalse() throws Exception {
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field useOutlinePaintForWhiskersField = BoxAndWhiskerRenderer.class.getDeclaredField("useOutlinePaintForWhiskers");
        useOutlinePaintForWhiskersField.setAccessible(true);
        useOutlinePaintForWhiskersField.set(renderer, false);

        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(2, 3)).thenReturn(10.0);
        when(dataset.getQ3Value(2, 3)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(2, 3)).thenReturn(30.0);
        when(dataset.getMinRegularValue(2, 3)).thenReturn(5.0);
        when(dataset.getMeanValue(2, 3)).thenReturn(null);
        when(dataset.getMedianValue(2, 3)).thenReturn(null);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getBarWidth()).thenReturn(5.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 50);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(10.0);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(20.0);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 3);

        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2).setPaint(paintCaptor.capture());
        Paint usedPaint = paintCaptor.getValue();
        Paint expectedPaint = renderer.getItemPaint(2, 3);
        assertEquals(expectedPaint, usedPaint, "Whiskers should use item paint when useOutlinePaintForWhiskers is false");
    }

    @Test
    @DisplayName("Handles meanVisible=true with a visible mean within dataArea bounds")
    public void TC12_handlesMeanVisibleTrueWithinBounds() throws Exception {
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field meanVisibleField = BoxAndWhiskerRenderer.class.getDeclaredField("meanVisible");
        meanVisibleField.setAccessible(true);
        meanVisibleField.set(renderer, true);

        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(3, 1)).thenReturn(15.0);
        when(dataset.getQ3Value(3, 1)).thenReturn(25.0);
        when(dataset.getMaxRegularValue(3, 1)).thenReturn(35.0);
        when(dataset.getMinRegularValue(3, 1)).thenReturn(10.0);
        when(dataset.getMeanValue(3, 1)).thenReturn(20.0);
        when(dataset.getMedianValue(3, 1)).thenReturn(null);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getBarWidth()).thenReturn(5.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 50);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(10.0);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(20.0);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);

        when(rangeAxis.valueToJava2D(20.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(25.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 3, 1);

        ArgumentCaptor<java.awt.Shape> shapeCaptor = ArgumentCaptor.forClass(java.awt.Shape.class);
        verify(g2).fill(shapeCaptor.capture());
        java.awt.Shape drawnShape = shapeCaptor.getValue();
        assertTrue(drawnShape instanceof java.awt.geom.Ellipse2D, "Mean should be drawn as an ellipse within dataArea bounds");
    }

    @Test
    @DisplayName("Handles meanVisible=true with mean outside dataArea bounds")
    public void TC13_handlesMeanVisibleTrueOutsideBounds() throws Exception {
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field meanVisibleField = BoxAndWhiskerRenderer.class.getDeclaredField("meanVisible");
        meanVisibleField.setAccessible(true);
        meanVisibleField.set(renderer, true);

        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(3, 2)).thenReturn(15.0);
        when(dataset.getQ3Value(3, 2)).thenReturn(25.0);
        when(dataset.getMaxRegularValue(3, 2)).thenReturn(35.0);
        when(dataset.getMinRegularValue(3, 2)).thenReturn(10.0);
        when(dataset.getMeanValue(3, 2)).thenReturn(200.0);
        when(dataset.getMedianValue(3, 2)).thenReturn(null);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getBarWidth()).thenReturn(5.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 50);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(10.0);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(20.0);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);

        when(rangeAxis.valueToJava2D(200.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(150.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 3, 2);

        verify(g2, never()).fill(any(java.awt.Shape.class));
        verify(g2, never()).draw(any(java.awt.Shape.class));
    }

    @Test
    @DisplayName("Handles meanVisible=false ensuring mean is not drawn")
    public void TC14_handlesMeanVisibleFalse() throws Exception {
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field meanVisibleField = BoxAndWhiskerRenderer.class.getDeclaredField("meanVisible");
        meanVisibleField.setAccessible(true);
        meanVisibleField.set(renderer, false);

        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(3, 3)).thenReturn(15.0);
        when(dataset.getQ3Value(3, 3)).thenReturn(25.0);
        when(dataset.getMaxRegularValue(3, 3)).thenReturn(35.0);
        when(dataset.getMinRegularValue(3, 3)).thenReturn(10.0);
        when(dataset.getMeanValue(3, 3)).thenReturn(20.0);
        when(dataset.getMedianValue(3, 3)).thenReturn(null);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getBarWidth()).thenReturn(5.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 50);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(10.0);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(20.0);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);

        when(rangeAxis.valueToJava2D(20.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(25.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 3, 3);

        verify(g2, never()).fill(any(java.awt.Shape.class));
        verify(g2, never()).draw(any(java.awt.Shape.class));
    }

    @Test
    @DisplayName("Handles medianVisible=true with a valid median value")
    public void TC15_handlesMedianVisibleTrueWithValidMedian() throws Exception {
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field medianVisibleField = BoxAndWhiskerRenderer.class.getDeclaredField("medianVisible");
        medianVisibleField.setAccessible(true);
        medianVisibleField.set(renderer, true);

        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(4, 1)).thenReturn(15.0);
        when(dataset.getQ3Value(4, 1)).thenReturn(25.0);
        when(dataset.getMaxRegularValue(4, 1)).thenReturn(35.0);
        when(dataset.getMinRegularValue(4, 1)).thenReturn(10.0);
        when(dataset.getMeanValue(4, 1)).thenReturn(null);
        when(dataset.getMedianValue(4, 1)).thenReturn(20.0);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        when(state.getBarWidth()).thenReturn(5.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 50);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(10.0);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(20.0);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);

        when(rangeAxis.valueToJava2D(20.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(25.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 4, 1);

        ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
        verify(g2).draw(lineCaptor.capture());
        java.awt.geom.Line2D drawnLine = lineCaptor.getValue();
        assertNotNull(drawnLine, "Median line should be drawn when medianVisible is true and median value is valid");
        assertEquals(25.0, drawnLine.getX1(), 0.001, "Median line X1 should match the converted median value");
        assertEquals(0.0, drawnLine.getY1(), "Median line Y1 should match the starting Y coordinate");
        assertEquals(25.0, drawnLine.getX2(), 0.001, "Median line X2 should match the converted median value");
        assertEquals(5.0, drawnLine.getY2(), "Median line Y2 should match the ending Y coordinate based on bar width");
    }
}
