package org.apache.commons.jxpath.ri.model.dom;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DOMNodePointer_setValue_0_1_Test {

    @Test
    @DisplayName("setValue with TEXT_NODE and non-empty string sets node value")
    public void TC01() throws Exception {
        // GIVEN
        Text node = mock(Text.class);
        when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
        String value = "New Value";
        
        // Use real instance since mocking may be unnecessary
        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        verify(node).setNodeValue("New Value");
    }

    @Test
    @DisplayName("setValue with TEXT_NODE and empty string removes node")
    public void TC02() throws Exception {
        // GIVEN
        Text node = mock(Text.class);
        Node parent = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
        when(node.getParentNode()).thenReturn(parent);
        String value = "";

        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        verify(parent).removeChild(node);
    }

    @Test
    @DisplayName("setValue with TEXT_NODE and null string removes node")
    public void TC03() throws Exception {
        // GIVEN
        Text node = mock(Text.class);
        Node parent = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
        when(node.getParentNode()).thenReturn(parent);
        String value = null;

        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        verify(parent).removeChild(node);
    }

    @Test
    @DisplayName("setValue with CDATA_SECTION_NODE and non-empty string sets node value")
    public void TC04() throws Exception {
        // GIVEN
        Text node = mock(Text.class);
        when(node.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
        String value = "New CDATA Value";

        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        verify(node).setNodeValue("New CDATA Value");
    }

    @Test
    @DisplayName("setValue with non-text node and value as Element node appends cloned children")
    public void TC05() throws Exception {
        // GIVEN
        Node node = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE); // Assuming non-text node is ELEMENT_NODE

        NodeList children = mock(NodeList.class);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(2);
        Node child1 = mock(Node.class);
        Node child2 = mock(Node.class);
        when(children.item(0)).thenReturn(child1);
        when(children.item(1)).thenReturn(child2);

        Element valueElement = mock(Element.class);
        NodeList valueChildren = mock(NodeList.class);
        when(valueElement.getChildNodes()).thenReturn(valueChildren);
        when(valueChildren.getLength()).thenReturn(2);
        Node valueChild1 = mock(Node.class);
        Node valueChild2 = mock(Node.class);
        when(valueChildren.item(0)).thenReturn(valueChild1);
        when(valueChildren.item(1)).thenReturn(valueChild2);

        // Mock cloneNode to return the same mock for simplicity
        when(valueChild1.cloneNode(true)).thenReturn(valueChild1);
        when(valueChild2.cloneNode(true)).thenReturn(valueChild2);

        Object value = valueElement;

        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // WHEN
        domNodePointer.setValue(value);

        // THEN
        verify(node).removeChild(child1);
        verify(node).removeChild(child2);
        verify(node).appendChild(valueChild1.cloneNode(true));
        verify(node).appendChild(valueChild2.cloneNode(true));
    }
}