package org.apache.commons.csv;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.csv.CSVFormat;
import static org.junit.jupiter.api.Assertions.*;

public class CSVFormat_equals_0_3_Test {

    @Test
    @DisplayName("equals returns false when headerComments differ")
    public void TC11() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withHeaderComments("Comment1");
        CSVFormat format2 = CSVFormat.DEFAULT.withHeaderComments("Comment2");

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result, "Expected equals to return false when headerComments differ");
    }

    @Test
    @DisplayName("equals returns false when ignoreEmptyLines differs")
    public void TC12() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
        CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result, "Expected equals to return false when ignoreEmptyLines differs");
    }

    @Test
    @DisplayName("equals returns false when ignoreHeaderCase differs")
    public void TC13() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
        CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result, "Expected equals to return false when ignoreHeaderCase differs");
    }

    @Test
    @DisplayName("equals returns false when ignoreSurroundingSpaces differs")
    public void TC14() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
        CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result, "Expected equals to return false when ignoreSurroundingSpaces differs");
    }

    @Test
    @DisplayName("equals returns false when nullString differs")
    public void TC15() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withNullString("NULL");
        CSVFormat format2 = CSVFormat.DEFAULT.withNullString("N/A");

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result, "Expected equals to return false when nullString differs");
    }
}