package org.apache.commons.compress.archivers.zip;
// import org.apache.commons.compress.archivers.zip.ZipUtil;
// 
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;
// import org.apache.commons.compress.utils.ZipUtil;
// 
// import java.io.*;
// import java.nio.charset.StandardCharsets;
// import java.util.zip.ZipException;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
public class ZipArchiveInputStream_getNextZipEntry_1_1_Test {
// 
//     /**
//      * Helper method to create a valid ZIP stream with an ENHANCED_DEFLATED entry.
//      */
//     private InputStream createValidZipStreamWithEnhancedDeflate() throws IOException {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos)) {
//             ZipArchiveEntry entry = new ZipArchiveEntry("enhanced_deflate_entry.txt");
//             entry.setMethod(ZipMethod.ENHANCED_DEFLATED.getCode());
//             zos.putArchiveEntry(entry);
//             zos.write("Test data for enhanced deflate".getBytes(StandardCharsets.UTF_8));
//             zos.closeArchiveEntry();
//         }
//         return new ByteArrayInputStream(baos.toByteArray());
//     }
// 
//     /**
//      * Helper method to create a valid ZIP stream with an UNSHRINKING entry.
//      * Note: Apache Commons Compress does not support writing UNSHRINKING entries.
//      * This method manually constructs a ZIP entry with UNSHRINKING compression.
//      */
//     private InputStream createValidZipStreamWithUnshrinking() throws IOException {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         try (DataOutputStream dos = new DataOutputStream(baos)) {
            // Local File Header
//             dos.writeInt(Integer.reverseBytes(0x04034b50)); // Local file header signature
//             dos.writeShort(Short.reverseBytes((short) 20)); // Version needed to extract
//             dos.writeShort(Short.reverseBytes((short) 0));  // General purpose bit flag
//             dos.writeShort(Short.reverseBytes((short) ZipMethod.UNSHRINKING.getCode())); // Compression method (UNSHRINKING)
//             dos.writeInt(Integer.reverseBytes((int) ZipUtil.javaToDosTime(System.currentTimeMillis()))); // Last mod file time/date
//             dos.writeInt(0); // CRC-32
//             dos.writeInt(0); // Compressed size
//             dos.writeInt(0); // Uncompressed size
//             byte[] filename = "unshrinking_entry.txt".getBytes(StandardCharsets.UTF_8);
//             dos.writeShort(Short.reverseBytes((short) filename.length)); // File name length
//             dos.writeShort(Short.reverseBytes((short) 0)); // Extra field length
//             dos.write(filename); // File name
            // No extra field
            // File data (empty)
            // Since UNSHRINKING has no actual compression, no data follows
//         }
//         return new ByteArrayInputStream(baos.toByteArray());
//     }
// 
//     /**
//      * Helper method to create a ZIP stream with corrupted Zip64 extra fields.
//      */
//     private InputStream createZipStreamWithCorruptedZip64Extras() throws IOException {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos)) {
//             ZipArchiveEntry entry = new ZipArchiveEntry("corrupted_zip64_entry.txt");
            // Manually set corrupted Zip64 extra field
//             byte[] corruptedExtra = { 0x00, 0x00, 0x00 }; // Invalid Zip64 extra field
//             entry.setExtra(corruptedExtra);
//             entry.setSize(0);
//             entry.setCompressedSize(0);
//             zos.putArchiveEntry(entry);
//             zos.write("Corrupted Zip64 extra field data".getBytes(StandardCharsets.UTF_8));
//             zos.closeArchiveEntry();
//         }
//         return new ByteArrayInputStream(baos.toByteArray());
//     }
// 
//     /**
//      * Helper method to create a valid ZIP stream with an XZ compressed entry.
//      */
//     private InputStream createValidZipStreamWithXZ() throws IOException {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         try (ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos)) {
//             ZipArchiveEntry entry = new ZipArchiveEntry("xz_compressed_entry.txt");
//             entry.setMethod(ZipMethod.XZ.getCode());
//             zos.putArchiveEntry(entry);
//             try (XZCompressorOutputStream xzOut = new XZCompressorOutputStream(zos)) {
//                 xzOut.write("Test data for XZ compression".getBytes(StandardCharsets.UTF_8));
//             }
//             zos.closeArchiveEntry();
//         }
//         return new ByteArrayInputStream(baos.toByteArray());
//     }
// 
//     /**
//      * Helper method to create a ZIP stream with an unsupported compression method.
//      */
//     private InputStream createZipStreamWithUnsupportedCompression() throws IOException {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         try (DataOutputStream dos = new DataOutputStream(baos)) {
            // Local File Header
//             dos.writeInt(Integer.reverseBytes(0x04034b50)); // Local file header signature
//             dos.writeShort(Short.reverseBytes((short) 20)); // Version needed to extract
//             dos.writeShort(Short.reverseBytes((short) 0));  // General purpose bit flag
//             dos.writeShort(Short.reverseBytes((short) 99)); // Unsupported compression method (99)
//             dos.writeInt(Integer.reverseBytes((int) ZipUtil.javaToDosTime(System.currentTimeMillis()))); // Last mod file time/date
//             dos.writeInt(0); // CRC-32
//             dos.writeInt(0); // Compressed size
//             dos.writeInt(0); // Uncompressed size
//             byte[] filename = "unsupported_compression_entry.txt".getBytes(StandardCharsets.UTF_8);
//             dos.writeShort(Short.reverseBytes((short) filename.length)); // File name length
//             dos.writeShort(Short.reverseBytes((short) 0)); // Extra field length
//             dos.write(filename); // File name
            // No extra field
            // File data (empty)
//         }
//         return new ByteArrayInputStream(baos.toByteArray());
//     }
// 
//     @Test
//     @DisplayName("Processes an entry with ENHANCED_DEFLATED compression method")
//     void TC21_ENHANCED_DEFLATED_compression() throws IOException, ZipException {
        // Arrange
//         InputStream inputStream = createValidZipStreamWithEnhancedDeflate();
//         ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
// 
        // Act
//         ZipArchiveEntry entry = zipInputStream.getNextZipEntry();
// 
        // Assert
//         assertNotNull(entry, "Entry should not be null");
//         assertEquals(ZipMethod.ENHANCED_DEFLATED.getCode(), entry.getMethod(), "Compression method should be ENHANCED_DEFLATED");
//         assertEquals("enhanced_deflate_entry.txt", entry.getName(), "Entry name should match expected");
//     }
// 
//     @Test
//     @DisplayName("Handles an entry with UNSHRINKING compression method")
//     void TC22_UNSHRINKING_compression() throws IOException, ZipException {
        // Arrange
//         InputStream inputStream = createValidZipStreamWithUnshrinking();
//         ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
// 
        // Act
//         ZipArchiveEntry entry = zipInputStream.getNextZipEntry();
// 
        // Assert
//         assertNotNull(entry, "Entry should not be null");
//         assertEquals(ZipMethod.UNSHRINKING.getCode(), entry.getMethod(), "Compression method should be UNSHRINKING");
//         assertEquals("unshrinking_entry.txt", entry.getName(), "Entry name should match expected");
//     }
// 
//     @Test
//     @DisplayName("Throws ZipException when Zip64 extra fields are corrupted")
//     void TC23_corrupted_Zip64_extra_fields() throws IOException {
        // Arrange
//         InputStream inputStream = createZipStreamWithCorruptedZip64Extras();
//         ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
// 
        // Act & Assert
//         ZipException exception = assertThrows(ZipException.class, () -> {
//             zipInputStream.getNextZipEntry();
//         }, "Expected ZipException due to corrupted Zip64 extra fields");
//         assertTrue(exception.getMessage().contains("corrupted zip64 extra field"), "Exception message should indicate corrupted Zip64 extra field");
//     }
// 
//     @Test
//     @DisplayName("Processes an entry with XZ compression method")
//     void TC24_XZ_compression() throws IOException, ZipException {
        // Arrange
//         InputStream inputStream = createValidZipStreamWithXZ();
//         ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
// 
        // Act
//         ZipArchiveEntry entry = zipInputStream.getNextZipEntry();
// 
        // Assert
//         assertNotNull(entry, "Entry should not be null");
//         assertEquals(ZipMethod.XZ.getCode(), entry.getMethod(), "Compression method should be XZ");
//         assertEquals("xz_compressed_entry.txt", entry.getName(), "Entry name should match expected");
//     }
// 
//     @Test
//     @DisplayName("Handles unsupported compression methods gracefully")
//     void TC25_unsupported_compression_method() throws IOException, ZipException {
        // Arrange
//         InputStream inputStream = createZipStreamWithUnsupportedCompression();
//         ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
// 
        // Act
//         ZipArchiveEntry entry = zipInputStream.getNextZipEntry();
// 
        // Assert
//         assertNull(entry, "Unsupported compression method should result in null entry");
//     }
// }
}