package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.needle.PlumNeedle;
import org.jfree.chart.needle.PinNeedle;
import org.jfree.chart.needle.LongNeedle;
import org.jfree.chart.needle.LineNeedle;
import org.jfree.chart.needle.MeterNeedle;
import org.jfree.chart.needle.ArrowNeedle;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class CompassPlot_setSeriesNeedle_0_1_Test {

    @Test
    @DisplayName("setSeriesNeedle with type=0 sets ArrowNeedle, red paint, and white highlight")
    void TC01_setSeriesNeedle_type0() throws Exception {
        // Initialize CompassPlot instance
        CompassPlot compassPlot = new CompassPlot();

        // Define type and index
        int type = 0;
        int index = 0;

        // Invoke setSeriesNeedle method
        compassPlot.setSeriesNeedle(type, index);

        // Access the private seriesNeedle field via reflection
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        Object[] seriesNeedle = (Object[]) seriesNeedleField.get(compassPlot);

        // Verify the needle is an instance of ArrowNeedle
        assertTrue(seriesNeedle[index] instanceof ArrowNeedle, "Needle is not an instance of ArrowNeedle");

        // Access the getFillPaint and getHighlightPaint methods
        Method getFillPaintMethod = MeterNeedle.class.getDeclaredMethod("getFillPaint");
        getFillPaintMethod.setAccessible(true); // Making sure the method is accessible
        Color paint = (Color) getFillPaintMethod.invoke(seriesNeedle[index]);
        assertEquals(Color.RED, paint, "Series paint is not RED");

        Method getHighlightPaintMethod = MeterNeedle.class.getDeclaredMethod("getHighlightPaint");
        getHighlightPaintMethod.setAccessible(true); // Making sure the method is accessible
        Color highlightPaint = (Color) getHighlightPaintMethod.invoke(seriesNeedle[index]);
        assertEquals(Color.WHITE, highlightPaint, "Highlight paint is not WHITE");
    }

    @Test
    @DisplayName("setSeriesNeedle with type=1 sets LineNeedle")
    void TC02_setSeriesNeedle_type1() throws Exception {
        // Initialize CompassPlot instance
        CompassPlot compassPlot = new CompassPlot();

        // Define type and index
        int type = 1;
        int index = 0;

        // Invoke setSeriesNeedle method
        compassPlot.setSeriesNeedle(type, index);

        // Access the private seriesNeedle field via reflection
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        Object[] seriesNeedle = (Object[]) seriesNeedleField.get(compassPlot);

        // Verify the needle is an instance of LineNeedle
        assertTrue(seriesNeedle[index] instanceof LineNeedle, "Needle is not an instance of LineNeedle");
    }

    @Test
    @DisplayName("setSeriesNeedle with type=2 sets LongNeedle with rotateY=0.5")
    void TC03_setSeriesNeedle_type2() throws Exception {
        // Initialize CompassPlot instance
        CompassPlot compassPlot = new CompassPlot();

        // Define type and index
        int type = 2;
        int index = 0;

        // Invoke setSeriesNeedle method
        compassPlot.setSeriesNeedle(type, index);

        // Access the private seriesNeedle field via reflection
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        Object[] seriesNeedle = (Object[]) seriesNeedleField.get(compassPlot);

        // Verify the needle is an instance of LongNeedle
        assertTrue(seriesNeedle[index] instanceof LongNeedle, "Needle is not an instance of LongNeedle");

        // Access the rotateY field via reflection
        Method getRotateYMethod = MeterNeedle.class.getDeclaredMethod("getRotateY");
        getRotateYMethod.setAccessible(true); // Making sure the method is accessible
        double rotateY = (double) getRotateYMethod.invoke(seriesNeedle[index]);
        assertEquals(0.5, rotateY, "LongNeedle rotateY is not 0.5");
    }

    @Test
    @DisplayName("setSeriesNeedle with type=3 sets PinNeedle")
    void TC04_setSeriesNeedle_type3() throws Exception {
        // Initialize CompassPlot instance
        CompassPlot compassPlot = new CompassPlot();

        // Define type and index
        int type = 3;
        int index = 0;

        // Invoke setSeriesNeedle method
        compassPlot.setSeriesNeedle(type, index);

        // Access the private seriesNeedle field via reflection
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        Object[] seriesNeedle = (Object[]) seriesNeedleField.get(compassPlot);

        // Verify the needle is an instance of PinNeedle
        assertTrue(seriesNeedle[index] instanceof PinNeedle, "Needle is not an instance of PinNeedle");
    }

    @Test
    @DisplayName("setSeriesNeedle with type=4 sets PlumNeedle")
    void TC05_setSeriesNeedle_type4() throws Exception {
        // Initialize CompassPlot instance
        CompassPlot compassPlot = new CompassPlot();

        // Define type and index
        int type = 4;
        int index = 0;

        // Invoke setSeriesNeedle method
        compassPlot.setSeriesNeedle(type, index);

        // Access the private seriesNeedle field via reflection
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        Object[] seriesNeedle = (Object[]) seriesNeedleField.get(compassPlot);

        // Verify the needle is an instance of PlumNeedle
        assertTrue(seriesNeedle[index] instanceof PlumNeedle, "Needle is not an instance of PlumNeedle");
    }
}