package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import org.apache.commons.lang3.builder.EqualsBuilder;
import java.util.ArrayList;
import java.util.HashSet;

public class EqualsBuilder_reflectionAppend_1_1_Test {

    @Test
    @DisplayName("Sets isEquals to false when classes of lhs and rhs are not related")
    public void TC14_unrelatedClasses_shouldNotBeEqual() throws Exception {
        EqualsBuilder builder = new EqualsBuilder();
        Object lhs = "test";
        Object rhs = Integer.valueOf(5);
        builder.reflectionAppend(lhs, rhs);
        
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);
        
        assertFalse(isEquals);
    }

    @Test
    @DisplayName("Sets isEquals to false when classes of lhs and rhs are not related with different object types")
    public void TC15_unrelatedClasses_differentTypes_shouldNotBeEqual() throws Exception {
        EqualsBuilder builder = new EqualsBuilder();
        Object lhs = new ArrayList<>();
        Object rhs = new HashSet<>();
        builder.reflectionAppend(lhs, rhs);
        
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);
        
        assertFalse(isEquals);
    }

    @Test
    @DisplayName("Sets isEquals to false when array elements differ")
    public void TC16_unequalArrayElements_shouldSetIsEqualsFalse() throws Exception {
        EqualsBuilder builder = new EqualsBuilder();
        Object[] lhs = {1, 2, 3};
        Object[] rhs = {1, 2, 4};
        builder.reflectionAppend(lhs, rhs);
        
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);
        
        assertFalse(isEquals);
    }

    @Test
    @DisplayName("Sets isEquals to false when arrays have different lengths")
    public void TC17_unequalArrayLengths_shouldSetIsEqualsFalse() throws Exception {
        EqualsBuilder builder = new EqualsBuilder();
        Object[] lhs = {1, 2, 3};
        Object[] rhs = {1, 2};
        builder.reflectionAppend(lhs, rhs);
        
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);
        
        assertFalse(isEquals);
    }

    @Test
    @DisplayName("Performs reflection append when classes are related and not in bypassReflectionClasses")
    public void TC18_reflectionAppend_relatedClasses_notBypassed() throws Exception {
        EqualsBuilder builder = new EqualsBuilder();
        CustomClass lhs = new CustomClass(10, "field2Value");
        CustomClass rhs = new CustomClass(10, "field2Value");
        builder.reflectionAppend(lhs, rhs);
        
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);
        
        assertTrue(isEquals);
    }

    private static class CustomClass {
        private int field1;
        private String field2;

        public CustomClass(int field1, String field2) {
            this.field1 = field1;
            this.field2 = field2;
        }
    }
}