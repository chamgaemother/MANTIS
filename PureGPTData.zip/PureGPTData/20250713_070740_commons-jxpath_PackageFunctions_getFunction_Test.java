import org.apache.commons.jxpath.Function;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.NodeSet;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.functions.PackageFunctions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class PackageFunctionsTest {
    
    private PackageFunctions packageFunctions;

    @BeforeEach
    void setUp() {
        packageFunctions = new PackageFunctions("java.util.", "util");
    }

    @Test
    void testGetFunctionNamespaceMismatch() {
        Function fn = packageFunctions.getFunction("differentNamespace", "Collections.singleton", new Object[]{"foo"});
        assertNull(fn);
    }

    @Test
    void testGetFunctionStaticMethodValid() {
        Function fn = packageFunctions.getFunction("util", "Collections.singleton", new Object[]{"foo"});
        assertNotNull(fn);
    }

    @Test
    void testGetFunctionStaticMethodInvalid() {
        Function fn = packageFunctions.getFunction("util", "Collections.nonExistentMethod", new Object[]{"foo"});
        assertNull(fn);
    }

    @Test
    void testGetFunctionConstructorValid() {
        Function fn = packageFunctions.getFunction("util", "Date.new", null);
        assertNotNull(fn);
    }

    @Test
    void testGetFunctionConstructorInvalid() {
        Function fn = packageFunctions.getFunction("util", "NonExistentClass.new", null);
        assertNull(fn);
    }

    @Test
    void testGetFunctionTargetMethodValid() {
        Function fn = packageFunctions.getFunction("util", "startsWith", new Object[]{"hello", "h"});
        assertNotNull(fn);
    }

    @Test
    void testGetFunctionTargetMethodInvalid() {
        Function fn = packageFunctions.getFunction("util", "nonExistentMethod", new Object[]{"hello", "h"});
        assertNull(fn);
    }

    @Test
    void testGetFunctionNodeSetTarget() {
        NodeSet nodeSet = () -> Collections.singletonList(new StringPointer("hello"));
        Function fn = packageFunctions.getFunction("util", "length", new Object[]{nodeSet});
        assertNotNull(fn);
    }

    @Test
    void testGetFunctionEmptyCollectionTarget() {
        Function fn = packageFunctions.getFunction("util", "length", new Object[]{Collections.emptyList()});
        assertNull(fn);
    }
    
    @Test
    void testGetFunctionExceptionHandling() {
        PackageFunctions invalidPackageFunctions = new PackageFunctions("non.existent.", "util");
        assertThrows(JXPathException.class, () ->
            invalidPackageFunctions.getFunction("util", "NonExistentClass.new", null)
        );
    }
    
    @Test
    void testGetUsedNamespaces() {
        Set<String> namespaces = packageFunctions.getUsedNamespaces();
        assertEquals(1, namespaces.size());
        assertTrue(namespaces.contains("util"));
    }

    static class StringPointer implements Pointer {
        private final String value;

        StringPointer(String value) {
            this.value = value;
        }

        @Override
        public Object getValue() {
            return value;
        }
    }
}