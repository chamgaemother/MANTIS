import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import com.fasterxml.jackson.core.io.JsonStringEncoder;

public class JsonStringEncoderTest {

    private final JsonStringEncoder encoder = JsonStringEncoder.getInstance();

    @Test
    public void testEncodeAsUTF8_NullInput() {
        assertThrows(NullPointerException.class, () -> {
            encoder.encodeAsUTF8((CharSequence) null);
        });
    }

    @Test
    public void testEncodeAsUTF8_EmptyString() {
        byte[] result = encoder.encodeAsUTF8("");
        assertArrayEquals(new byte[0], result);
    }

    @Test
    public void testEncodeAsUTF8_OnlyASCII() {
        String input = "Hello, World!";
        byte[] expected = "Hello, World!".getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testEncodeAsUTF8_ASCIIWithEscapes() {
        String input = "Line1\nLine2\tEnd\r";
        byte[] expected = "\\u000ALine2\\u0009End\\u000D".getBytes();
        byte[] result = encoder.encodeAsUTF8(input);
        // Since encodeAsUTF8 doesn't perform escaping, the expected should be escaped bytes
        // However, encodeAsUTF8 does perform escaping, so let's build expected accordingly
        byte[] expectedBytes = new byte[] {
            '\\', 'u', '0', '0', '0', 'A',
            'L', 'i', 'n', 'e', '2',
            '\\', 'u', '0', '0', '0', '9',
            'E', 'n', 'd',
            '\\', 'u', '0', '0', '0', 'D'
        };
        assertArrayEquals(expectedBytes, result);
    }

    @Test
    public void testEncodeAsUTF8_NonASCIICharacters() {
        String input = "Café Münster";
        byte[] expected = new byte[] {
            'C', 'a', 'f', (byte)0xC3, (byte)0xA9, ' ',
            'M', 'ü', 'n', 's', 't', 'e', 'r'
        };
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testEncodeAsUTF8_SurrogatePair() {
        // Emoji U+1F600 GRINNING FACE
        String input = "\uD83D\uDE00";
        byte[] expected = new byte[] {
            (byte)0xF0, (byte)0x9F, (byte)0x98, (byte)0x80
        };
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testEncodeAsUTF8_UnmatchedHighSurrogate() {
        String input = "\uD83DHello";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    public void testEncodeAsUTF8_UnmatchedLowSurrogate() {
        String input = "Hello\uDE00";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    public void testEncodeAsUTF8_InvalidSurrogatePair() {
        String input = "\uD83D\uD83D";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    public void testEncodeAsUTF8_MaxValidCodePoint() {
        // U+10FFFF
        String input = "\uDBFF\uDFFF";
        byte[] expected = new byte[] {
            (byte)0xF4, (byte)0x8F, (byte)0xBF, (byte)0xBF
        };
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testEncodeAsUTF8_ExceedMaxCodePoint() {
        // U+110000 is invalid
        String input = "\uDBFF\uE000";
        Executable executable = () -> encoder.encodeAsUTF8(input);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertTrue(exception.getMessage().contains("illegal"));
    }

    @Test
    public void testEncodeAsUTF8_LongString() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 40000; i++) {
            sb.append("a");
        }
        byte[] expected = new byte[40000];
        for(int i = 0; i < 40000; i++) {
            expected[i] = 'a';
        }
        byte[] result = encoder.encodeAsUTF8(sb.toString());
        assertArrayEquals(expected, result);
    }

    @Test
    public void testEncodeAsUTF8_MixedCharacters() {
        String input = "Hello \n 世界 \uD83D\uDE00";
        byte[] expected = new byte[] {
            'H', 'e', 'l', 'l', 'o', ' ',
            '\\', 'u', '0', '0', '0', 'A',
            '世', '界', ' ',
            (byte)0xF0, (byte)0x9F, (byte)0x98, (byte)0x80
        };
        byte[] result = encoder.encodeAsUTF8(input);
        // Building expected bytes manually considering the escaping
        byte[] expectedBytes = new byte[] {
            'H', 'e', 'l', 'l', 'o', ' ',
            '\\', 'u', '0', '0', '0', 'A',
            (byte)0xE4, (byte)0xB8, (byte)0x96, // '世'
            (byte)0xE7, (byte)0x95, (byte)0x8C, // '界'
            ' ',
            (byte)0xF0, (byte)0x9F, (byte)0x98, (byte)0x80
        };
        assertArrayEquals(expectedBytes, result);
    }
}