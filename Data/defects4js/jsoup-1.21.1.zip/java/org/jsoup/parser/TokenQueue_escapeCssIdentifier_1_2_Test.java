package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.jsoup.parser.TokenQueue;

/**
 * JUnit 5 Test class for TokenQueue.escapeCssIdentifier
 */
public class TokenQueue_escapeCssIdentifier_1_2_Test {

    @Test
    @DisplayName("Input contains multiple hyphens followed by digits, correctly escapes each digit")
    void TC19_escapeCssIdentifier_multiple_hyphens_digits() {
        // GIVEN
        String input = "-1-2-3";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("-\\31-\\32-\\33 ", result);
    }

    @Test
    @DisplayName("Input ends with a non-identifier character, escapes the final character")
    void TC20_escapeCssIdentifier_final_non_ident_char() {
        // GIVEN
        String input = "abc!";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("abc\\!", result);
    }

    @Test
    @DisplayName("Input contains mixed case letters and special characters, correctly escapes only special characters")
    void TC21_escapeCssIdentifier_mixed_case_special_chars() {
        // GIVEN
        String input = "AbC@d#E";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("AbC\\@d\\#E", result);
    }
}