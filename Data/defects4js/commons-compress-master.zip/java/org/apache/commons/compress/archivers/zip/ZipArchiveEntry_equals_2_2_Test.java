package org.apache.commons.compress.archivers.zip;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

public class ZipArchiveEntry_equals_2_2_Test {

    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntry lastModifiedTimes are null")
    void TC36_equals_returns_true_with_both_null_lastModifiedTimes() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setLastModifiedTime(null);
        
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setLastModifiedTime(null);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertTrue(result, "equals() should return true when both lastModifiedTimes are null");
    }

    @Test
    @DisplayName("equals() returns false when one ZipArchiveEntry has a null lastAccessTime and the other has a non-null lastAccessTime")
    void TC37_equals_returns_false_with_one_null_lastAccessTime() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setLastAccessTime(null);
        
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setLastAccessTime(FileTime.from(Instant.now()));
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertFalse(result, "equals() should return false when one lastAccessTime is null and the other is not");
    }

    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntries lastAccessTimes are null")
    void TC38_equals_returns_true_with_both_null_lastAccessTimes() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setLastAccessTime(null);
        
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setLastAccessTime(null);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertTrue(result, "equals() should return true when both lastAccessTimes are null");
    }

    @Test
    @DisplayName("equals() returns false when one ZipArchiveEntry has a null creationTime and the other has a non-null creationTime")
    void TC39_equals_returns_false_with_one_null_creationTime() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setCreationTime(null);
        
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setCreationTime(FileTime.from(Instant.now()));
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertFalse(result, "equals() should return false when one creationTime is null and the other is not");
    }

    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntries creationTimes are null")
    void TC40_equals_returns_true_with_both_null_creationTimes() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setCreationTime(null);
        
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setCreationTime(null);
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertTrue(result, "equals() should return true when both creationTimes are null");
    }
}