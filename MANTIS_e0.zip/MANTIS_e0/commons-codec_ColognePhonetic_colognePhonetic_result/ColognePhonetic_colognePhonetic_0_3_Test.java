package org.apache.commons.codec.language;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.codec.language.ColognePhonetic;
import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_3_Test {

    @Test
    @DisplayName("Input with 'C' at onset before 'A', should assign code '4'")
    void TC11() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Carl";
        String result = colognePhonetic.colognePhonetic(input);
        assertTrue(result.contains("4"), "Result should contain '4' for 'C' at onset before 'A'");
    }

    @Test
    @DisplayName("Input with 'C' not before A,H,K,L,O,Q,R,U,X, should assign code '8'")
    void TC12() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Cancer";
        String result = colognePhonetic.colognePhonetic(input);
        assertTrue(result.contains("8"), "Result should contain '8' for 'C' not before specified letters");
    }

    @Test
    @DisplayName("Input with 'S' and 'Z', should assign code '8'")
    void TC13() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Szilard";
        String result = colognePhonetic.colognePhonetic(input);
        assertTrue(result.contains("8"), "Result should contain '8' for 'S' and 'Z'");
    }

    @Test
    @DisplayName("Input with 'G', 'K', 'Q' should assign code '4'")
    void TC14() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Gauss, Kraft, Queen";
        String result = colognePhonetic.colognePhonetic(input);
        assertTrue(result.contains("4"), "Result should contain '4' for 'G', 'K', 'Q'");
    }

    @Test
    @DisplayName("Input with 'L' should assign code '5'")
    void TC15() {
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Lukas";
        String result = colognePhonetic.colognePhonetic(input);
        assertTrue(result.contains("5"), "Result should contain '5' for 'L'");
    }

}