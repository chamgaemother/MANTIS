import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.univariate.BracketFinder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class BracketFinderTest {

    @Test
    void testSearchMinimizeInitialOrder() {
        BracketFinder bracketFinder = new BracketFinder(100, 50);
        UnivariateFunction func = x -> (x - 1) * (x - 1);

        bracketFinder.search(func, GoalType.MINIMIZE, 0, 2);

        assertTrue(bracketFinder.getLo() <= bracketFinder.getMid());
        assertTrue(bracketFinder.getMid() <= bracketFinder.getHi());
    }

    @Test
    void testSearchMinimizeSwapInitialOrder() {
        BracketFinder bracketFinder = new BracketFinder(100, 50);
        UnivariateFunction func = x -> (x - 2) * (x - 2);

        bracketFinder.search(func, GoalType.MINIMIZE, 3, 1);

        assertEquals(1, bracketFinder.getLo(), 1e-10);
        assertEquals(2, bracketFinder.getMid(), 1e-10);
        assertTrue(bracketFinder.getHi() > bracketFinder.getMid());
    }

    @Test
    void testSearchMaximizeInitialOrder() {
        BracketFinder bracketFinder = new BracketFinder(100, 50);
        UnivariateFunction func = x -> - (x - 1) * (x - 1);

        bracketFinder.search(func, GoalType.MAXIMIZE, 0, 2);

        assertTrue(bracketFinder.getLo() <= bracketFinder.getMid());
        assertTrue(bracketFinder.getMid() <= bracketFinder.getHi());
    }

    @Test
    void testSearchMaximizeSwapInitialOrder() {
        BracketFinder bracketFinder = new BracketFinder(100, 50);
        UnivariateFunction func = x -> - (x - 2) * (x - 2);

        bracketFinder.search(func, GoalType.MAXIMIZE, 3, 1);

        assertEquals(1, bracketFinder.getLo(), 1e-10);
        assertEquals(2, bracketFinder.getMid(), 1e-10);
        assertTrue(bracketFinder.getHi() > bracketFinder.getMid());
    }

    @Test
    void testSearchBracketAlreadyFoundMinimize() {
        BracketFinder bracketFinder = new BracketFinder(100, 50);
        UnivariateFunction func = x -> (x - 1) * (x - 1);

        bracketFinder.search(func, GoalType.MINIMIZE, 0.5, 1.5);

        assertEquals(0.5, bracketFinder.getLo(), 1e-10);
        assertEquals(1.0, bracketFinder.getMid(), 1e-10);
        assertEquals(1.5, bracketFinder.getHi(), 1e-10);
    }

    @Test
    void testSearchBracketAlreadyFoundMaximize() {
        BracketFinder bracketFinder = new BracketFinder(100, 50);
        UnivariateFunction func = x -> - (x - 1) * (x - 1);

        bracketFinder.search(func, GoalType.MAXIMIZE, 0.5, 1.5);

        assertEquals(0.5, bracketFinder.getLo(), 1e-10);
        assertEquals(1.0, bracketFinder.getMid(), 1e-10);
        assertEquals(1.5, bracketFinder.getHi(), 1e-10);
    }

    @Test
    void testSearchBracketExpandMinimize() {
        BracketFinder bracketFinder = new BracketFinder(10, 100);
        UnivariateFunction func = x -> (x - 1) * (x - 1);

        bracketFinder.search(func, GoalType.MINIMIZE, 3, 2);

        assertTrue(bracketFinder.getLo() <= bracketFinder.getMid());
        assertTrue(bracketFinder.getMid() <= bracketFinder.getHi());
    }

    @Test
    void testSearchBracketExpandMaximize() {
        BracketFinder bracketFinder = new BracketFinder(10, 100);
        UnivariateFunction func = x -> - (x - 1) * (x - 1);

        bracketFinder.search(func, GoalType.MAXIMIZE, 3, 2);

        assertTrue(bracketFinder.getLo() <= bracketFinder.getMid());
        assertTrue(bracketFinder.getMid() <= bracketFinder.getHi());
    }

    @Test
    void testSearchTooManyEvaluations() {
        BracketFinder bracketFinder = new BracketFinder(1, 3);
        UnivariateFunction func = new UnivariateFunction() {
            @Override
            public double value(double x) {
                return x;
            }
        };

        Executable executable = () -> bracketFinder.search(func, GoalType.MINIMIZE, 0, 10);

        assertThrows(MaxCountExceededException.class, executable);
    }

    @Test
    void testSearchNullFunction() {
        BracketFinder bracketFinder = new BracketFinder();

        Executable executable = () -> bracketFinder.search(null, GoalType.MINIMIZE, 0, 1);

        assertThrows(NullPointerException.class, executable);
    }

    @Test
    void testSearchNullGoal() {
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = x -> x;

        Executable executable = () -> bracketFinder.search(func, null, 0, 1);

        assertThrows(NullPointerException.class, executable);
    }

    @Test
    void testSearchBoundaryValues() {
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = x -> (x - 1) * (x - 1);

        bracketFinder.search(func, GoalType.MINIMIZE, 1, 1);

        assertEquals(1, bracketFinder.getLo(), 1e-10);
        assertEquals(1, bracketFinder.getMid(), 1e-10);
        assertTrue(bracketFinder.getHi() > 1);
    }

    @Test
    void testSearchFunctionEvaluationException() {
        BracketFinder bracketFinder = new BracketFinder(10, 10);
        UnivariateFunction func = x -> {
            if (x == 2) {
                throw new IllegalArgumentException("Invalid input");
            }
            return x;
        };

        Executable executable = () -> bracketFinder.search(func, GoalType.MINIMIZE, 1, 3);

        assertThrows(IllegalArgumentException.class, executable);
    }

    @Test
    void testSearchLoHiSwapAfterSearch() {
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = x -> (x - 2) * (x - 2);

        bracketFinder.search(func, GoalType.MINIMIZE, 3, 1);

        assertTrue(bracketFinder.getLo() <= bracketFinder.getHi());
    }
}