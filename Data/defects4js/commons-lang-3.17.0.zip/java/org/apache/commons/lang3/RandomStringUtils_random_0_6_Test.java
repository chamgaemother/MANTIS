package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.RandomStringUtils;
import java.util.Random;

public class RandomStringUtils_random_0_6_Test {

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=false, chars=null, random) adjusts start and end to 'A' and 'z'+1")
    void test_TC26_random_adjusts_start_end_to_A_z_plus_1() {
        // GIVEN
        int count = 11;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(11, result.length(), "Result length should be 11");
        assertTrue(result.chars().allMatch(Character::isLetter), "All characters should be letters");
    }

    @Test
    @DisplayName("random(count, start=70, end=80, letters=true, numbers=true, chars=null, random) adjusts start and end based on letters and numbers")
    void test_TC27_random_adjusts_start_end_based_on_letters_and_numbers() {
        // GIVEN
        int count = 9;
        int start = 70;
        int end = 80;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(9, result.length(), "Result length should be 9");
        assertTrue(result.chars().allMatch(c -> (c >= 70 && c < 80) && (Character.isLetterOrDigit(c))), "All characters should be letters or digits within the specified range");
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=false, numbers=false, chars=null, random) handles full Unicode generation with multiple iterations")
    void test_TC28_random_handles_full_unicode_generation_with_multiple_iterations() {
        // GIVEN
        int count = 20;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(20, result.length(), "Result length should be 20");
        assertTrue(result.chars().allMatch(c -> c >= 0 && c <= Character.MAX_CODE_POINT), "All characters should be within 0 to Character.MAX_CODE_POINT");
        assertTrue(result.chars().allMatch(c -> {
            int type = Character.getType(c);
            return type != Character.UNASSIGNED && type != Character.PRIVATE_USE && type != Character.SURROGATE;
        }), "No characters should be unassigned, private use, or surrogate");
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=false, numbers=false, chars=null, random) handles single iteration")
    void test_TC29_random_handles_single_iteration() {
        // GIVEN
        int count = 1;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(1, result.length(), "Result length should be 1");
        assertTrue(result.chars().allMatch(c -> c >= 0 && c <= Character.MAX_CODE_POINT), "Character should be within 0 to Character.MAX_CODE_POINT");
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=false, chars=null, random) throws exception when adjusted end <= adjusted start for letters")
    void test_TC30_random_throws_exception_when_adjusted_end_less_than_or_equal_to_start_for_letters() {
        // GIVEN
        int count = 5;
        int start = 90;
        int end = 65;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        }, "Expected IllegalArgumentException to be thrown");
        assertEquals("Parameter end (" + end + ") must be greater than start (" + start + ")", exception.getMessage(), "Exception message should match");
    }
}