package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
import org.apache.commons.math3.ode.events.EventHandler;
import org.apache.commons.math3.analysis.solvers.BrentSolver;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

class GraggBulirschStoerIntegratorTest {

    @Test
    void testIntegrateWithNullEquations() {
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        assertThrows(NullPointerException.class, () -> integrator.integrate(null, 1.0));
    }

    @Test
    void testIntegrateWithSameInitialAndFinalTime() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        assertDoesNotThrow(() -> integrator.integrate(expandable, 0.0));
        assertEquals(0.0, expandable.getTime());
        assertArrayEquals(new double[]{1.0}, expandable.getCompleteState());
    }

    @Test
    void testIntegrateForward() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        assertDoesNotThrow(() -> integrator.integrate(expandable, 1.0));
        assertEquals(1.0, expandable.getTime());
        assertArrayEquals(new double[]{2.0}, expandable.getCompleteState(), 1.0e-10);
    }

    @Test
    void testIntegrateBackward() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(1.0);
        expandable.setPrimaryState(new double[]{2.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        assertDoesNotThrow(() -> integrator.integrate(expandable, 0.0));
        assertEquals(0.0, expandable.getTime());
        assertArrayEquals(new double[]{1.0}, expandable.getCompleteState(), 1.0e-10);
    }

    @Test
    void testIntegrateWithMinStepGreaterThanMaxStep() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(10.0, 1.0, 1.0e-10, 1.0e-10);
        assertThrows(IllegalArgumentException.class, () -> integrator.integrate(expandable, 1.0));
    }

    @Test
    void testIntegrateWithNegativeMinStep() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(-0.1, 10.0, 1.0e-10, 1.0e-10);
        Executable executable = () -> integrator.integrate(expandable, 1.0);
        assertThrows(IllegalArgumentException.class, executable);
    }

    @Test
    void testIntegrateWithZeroSteps() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.0, 10.0, 1.0e-10, 1.0e-10);
        assertDoesNotThrow(() -> integrator.integrate(expandable, 1.0));
        assertEquals(1.0, expandable.getTime());
        assertArrayEquals(new double[]{2.0}, expandable.getCompleteState(), 1.0e-10);
    }

    @Test
    void testIntegrateWithTooSmallTolerance() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-20, 1.0e-20);
        Executable executable = () -> integrator.integrate(expandable, 1.0);
        assertThrows(NumberIsTooSmallException.class, executable);
    }

    @Test
    void testIntegrateWithDimensionMismatch() {
        FirstOrderDifferentialEquations equations = new DummyEquations(2);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        Executable executable = () -> integrator.integrate(expandable, 1.0);
        assertThrows(DimensionMismatchException.class, executable);
    }

    @Test
    void testIntegrateWithMaxCountExceeded() {
        FirstOrderDifferentialEquations equations = new DivergingEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        integrator.setMaxEvaluations(100);
        Executable executable = () -> integrator.integrate(expandable, 1000.0);
        assertThrows(MaxCountExceededException.class, executable);
    }

    @Test
    void testIntegrateWithNoBracketingException() {
        FirstOrderDifferentialEquations equations = new EventEquations(1, true);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        BrentSolver solver = new BrentSolver();
        integrator.addEventHandler(new SimpleEventHandler(), 1.0, 1.0e-10, 100);
        integrator.setMaxEvaluations(50);
        Executable executable = () -> integrator.integrate(expandable, 10.0);
        assertThrows(NoBracketingException.class, executable);
    }

    @Test
    void testIntegrateWithStepRejection() {
        FirstOrderDifferentialEquations equations = new StepRejectingEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{1.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-5, 1.0e-5);
        assertDoesNotThrow(() -> integrator.integrate(expandable, 1.0));
        assertTrue(expandable.getTime() > 0.0);
        assertTrue(expandable.getTime() <= 1.0);
    }

    @Test
    void testIntegrateWithEvents() {
        FirstOrderDifferentialEquations equations = new DummyEquations(1);
        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
        expandable.setTime(0.0);
        expandable.setPrimaryState(new double[]{0.0});
        GraggBulirschStoerIntegrator integrator = new GraggBulirschStoerIntegrator(0.1, 10.0, 1.0e-10, 1.0e-10);
        integrator.addEventHandler(new SimpleEventHandler(), 1.0, 1.0e-10, 100, new BrentSolver());
        assertDoesNotThrow(() -> integrator.integrate(expandable, 10.0));
        assertEquals(5.0, expandable.getTime(), 1.0e-10);
        assertArrayEquals(new double[]{5.0}, expandable.getCompleteState(), 1.0e-10);
    }

    // Dummy equations that integrate y' = 1
    static class DummyEquations implements FirstOrderDifferentialEquations {
        private final int dimension;

        DummyEquations(int dimension) {
            this.dimension = dimension;
        }

        @Override
        public int getDimension() {
            return dimension;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            for (int i = 0; i < dimension; i++) {
                yDot[i] = 1.0;
            }
        }
    }

    // Equations that diverge: y' = y
    static class DivergingEquations implements FirstOrderDifferentialEquations {
        private final int dimension;

        DivergingEquations(int dimension) {
            this.dimension = dimension;
        }

        @Override
        public int getDimension() {
            return dimension;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            for (int i = 0; i < dimension; i++) {
                yDot[i] = y[i];
            }
        }
    }

    // Equations that trigger step rejection
    static class StepRejectingEquations implements FirstOrderDifferentialEquations {
        private final int dimension;

        StepRejectingEquations(int dimension) {
            this.dimension = dimension;
        }

        @Override
        public int getDimension() {
            return dimension;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = (t < 0.5) ? 1.0 : -1.0;
        }
    }

    // Event handler that triggers no bracketing
    static class SimpleEventHandler implements EventHandler {
        @Override
        public void init(double t0, double[] y0, double t) {
        }

        @Override
        public double g(double t, double[] y) {
            return y[0] - 5.0;
        }

        @Override
        public Action eventOccurred(double t, double[] y, boolean increasing) {
            return Action.CONTINUE;
        }

        @Override
        public void resetState(double t, double[] y) {
        }
    }
}