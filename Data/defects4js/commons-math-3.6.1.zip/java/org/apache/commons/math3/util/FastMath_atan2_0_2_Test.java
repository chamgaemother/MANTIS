package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class FastMath_atan2_0_2_Test {

    @Test
    @DisplayName("atan2(x=0.0, y=Infinity) returns Math.PI/2 when y is positive infinity and x is zero")
    public void TC06() {
        double x = 0.0;
        double y = Double.POSITIVE_INFINITY;
        double result = FastMath.atan2(x, y);
        assertEquals(Math.PI / 2, result);
    }

    @Test
    @DisplayName("atan2(x=0.0, y=-Infinity) returns -Math.PI/2 when y is negative infinity and x is zero")
    public void TC07() {
        double x = 0.0;
        double y = Double.NEGATIVE_INFINITY;
        double result = FastMath.atan2(x, y);
        assertEquals(-Math.PI / 2, result);
    }

    @Test
    @DisplayName("atan2(x=Infinity, y=1.0) returns +0.0 when x is positive infinity and y is positive")
    public void TC08() {
        double x = Double.POSITIVE_INFINITY;
        double y = 1.0;
        double result = FastMath.atan2(x, y);
        assertEquals(0.0, result);
    }

    @Test
    @DisplayName("atan2(x=Infinity, y=-1.0) returns -0.0 when x is positive infinity and y is negative")
    public void TC09() {
        double x = Double.POSITIVE_INFINITY;
        double y = -1.0;
        double result = FastMath.atan2(x, y);
        assertEquals(Double.doubleToLongBits(-0.0), Double.doubleToLongBits(result));
    }

    @Test
    @DisplayName("atan2(x=-Infinity, y=1.0) returns Math.PI when x is negative infinity and y is positive")
    public void TC10() {
        double x = Double.NEGATIVE_INFINITY;
        double y = 1.0;
        double result = FastMath.atan2(x, y);
        assertEquals(Math.PI, result);
    }
}