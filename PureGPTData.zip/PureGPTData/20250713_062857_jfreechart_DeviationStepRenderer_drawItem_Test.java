import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationStepRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;

public class DeviationStepRendererTest {
    
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private IntervalXYDataset dataset;
    private CrosshairState crosshairState;

    private DeviationStepRenderer renderer;

    @BeforeEach
    public void setUp() {
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(IntervalXYDataset.class);
        crosshairState = mock(CrosshairState.class);
        
        renderer = new DeviationStepRenderer();
    }

    @Test
    public void testDrawItemItemNotVisible() {
        when(dataset.getItemCount(0)).thenReturn(1);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItemNullDataset() {
        assertThrows(ClassCastException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, crosshairState, 0);
        });
    }

    @Test
    public void testDrawItemPass0() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, plot.getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, plot.getRangeAxisEdge())).thenReturn(30.0);
        XYItemRendererState localState = new DeviationStepRenderer.State(info);
        
        renderer.drawItem(g2, localState, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, times(0)).fill(any());
    }

    @Test
    public void testDrawItemIsLinePass() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(20.0);
        when(dataset.getItemCount(0)).thenReturn(1);
        
        XYItemRendererState localState = new DeviationStepRenderer.State(info);

        renderer.drawItem(g2, localState, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, times(1)).draw(any(Shape.class));
    }

    @Test
    public void testDrawItemIsItemPass() {
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        EntityCollection collection = mock(EntityCollection.class);
        when(mockInfo.getOwner()).thenReturn(mock(PlotRenderingInfo.Owner.class));
        when(mockInfo.getOwner().getEntityCollection()).thenReturn(collection);
        when(dataset.getItemCount(anyInt())).thenReturn(1);
        
        renderer.drawItem(g2, state, dataArea, mockInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 2);

        verify(g2, times(0)).draw(any(Shape.class));
    }
}