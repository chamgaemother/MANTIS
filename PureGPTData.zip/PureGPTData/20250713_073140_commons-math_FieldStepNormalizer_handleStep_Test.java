import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.apache.commons.math3.ode.sampling.FieldFixedStepHandler;
import org.apache.commons.math3.ode.sampling.FieldStepInterpolator;
import org.apache.commons.math3.ode.sampling.FieldStepNormalizer;
import org.apache.commons.math3.ode.sampling.StepNormalizerBounds;
import org.apache.commons.math3.ode.sampling.StepNormalizerMode;
import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

class FieldStepNormalizerTest {

    @Test
    void testHandleStepForwardIncrementNeitherBound() throws MaxCountExceededException {
        FieldFixedStepHandler<RealFieldElementDummy> handler = mock(FieldFixedStepHandler.class);
        FieldStepNormalizer<RealFieldElementDummy> normalizer =
                new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);

        FieldStepInterpolator<RealFieldElementDummy> interpolator =
                mock(FieldStepInterpolator.class);
        
        when(interpolator.isForward()).thenReturn(true);
        
        RealFieldElementDummy startTime = new RealFieldElementDummy(0.3);
        RealFieldElementDummy endTime = new RealFieldElementDummy(3.1);
        FieldODEStateAndDerivative<RealFieldElementDummy> prevState =
                new FieldODEStateAndDerivative<>(startTime, null, null);
        FieldODEStateAndDerivative<RealFieldElementDummy> currState =
                new FieldODEStateAndDerivative<>(endTime, null, null);
        
        when(interpolator.getPreviousState()).thenReturn(prevState);
        when(interpolator.getCurrentState()).thenReturn(currState);
        
        normalizer.handleStep(interpolator, true);
        
        verify(handler, times(1)).handleStep(any(), eq(true));
    }

    @Test
    void testHandleStepBackwardIncrementBothBounds() throws MaxCountExceededException {
        FieldFixedStepHandler<RealFieldElementDummy> handler = mock(FieldFixedStepHandler.class);
        FieldStepNormalizer<RealFieldElementDummy> normalizer =
                new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);

        FieldStepInterpolator<RealFieldElementDummy> interpolator =
                mock(FieldStepInterpolator.class);
        
        when(interpolator.isForward()).thenReturn(false);
        
        RealFieldElementDummy startTime = new RealFieldElementDummy(3.1);
        RealFieldElementDummy endTime = new RealFieldElementDummy(0.3);
        FieldODEStateAndDerivative<RealFieldElementDummy> prevState =
                new FieldODEStateAndDerivative<>(startTime, null, null);
        FieldODEStateAndDerivative<RealFieldElementDummy> currState =
                new FieldODEStateAndDerivative<>(endTime, null, null);
        
        when(interpolator.getPreviousState()).thenReturn(prevState);
        when(interpolator.getCurrentState()).thenReturn(currState);
        
        normalizer.handleStep(interpolator, true);
        
        verify(handler, times(1)).handleStep(any(), eq(true));
    }

    @Test
    void testHandleStepForwardMultipleFirstBound() throws MaxCountExceededException {
        FieldFixedStepHandler<RealFieldElementDummy> handler = mock(FieldFixedStepHandler.class);
        FieldStepNormalizer<RealFieldElementDummy> normalizer =
                new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.FIRST);

        FieldStepInterpolator<RealFieldElementDummy> interpolator =
                mock(FieldStepInterpolator.class);
        
        when(interpolator.isForward()).thenReturn(true);
        
        RealFieldElementDummy startTime = new RealFieldElementDummy(0.3);
        RealFieldElementDummy endTime = new RealFieldElementDummy(2.1);
        FieldODEStateAndDerivative<RealFieldElementDummy> prevState =
                new FieldODEStateAndDerivative<>(startTime, null, null);
        FieldODEStateAndDerivative<RealFieldElementDummy> currState =
                new FieldODEStateAndDerivative<>(endTime, null, null);
        
        when(interpolator.getPreviousState()).thenReturn(prevState);
        when(interpolator.getCurrentState()).thenReturn(currState);
        
        normalizer.handleStep(interpolator, false);
        
        verify(handler, times(1)).handleStep(any(), eq(false));
    }

    @Test
    void testHandleStepBackwardMultipleLastBound() throws MaxCountExceededException {
        FieldFixedStepHandler<RealFieldElementDummy> handler = mock(FieldFixedStepHandler.class);
        FieldStepNormalizer<RealFieldElementDummy> normalizer =
                new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.LAST);

        FieldStepInterpolator<RealFieldElementDummy> interpolator =
                mock(FieldStepInterpolator.class);
        
        when(interpolator.isForward()).thenReturn(false);
        
        RealFieldElementDummy startTime = new RealFieldElementDummy(3.1);
        RealFieldElementDummy endTime = new RealFieldElementDummy(0.3);
        FieldODEStateAndDerivative<RealFieldElementDummy> prevState =
                new FieldODEStateAndDerivative<>(startTime, null, null);
        FieldODEStateAndDerivative<RealFieldElementDummy> currState =
                new FieldODEStateAndDerivative<>(endTime, null, null);
        
        when(interpolator.getPreviousState()).thenReturn(prevState);
        when(interpolator.getCurrentState()).thenReturn(currState);
        
        normalizer.handleStep(interpolator, true);
        
        verify(handler, times(1)).handleStep(any(), eq(true));
    }
 
    // Mock class implementing RealFieldElement<T>
    static class RealFieldElementDummy implements RealFieldElement<RealFieldElementDummy> {
        private final double value;

        RealFieldElementDummy(double value) {
            this.value = value;
        }

        @Override public RealFieldElementDummy add(RealFieldElementDummy a) { return new RealFieldElementDummy(this.value + a.value); }
        @Override public RealFieldElementDummy subtract(RealFieldElementDummy a) { return new RealFieldElementDummy(this.value - a.value); }
        @Override public RealFieldElementDummy negate() { return new RealFieldElementDummy(-this.value); }
        @Override public RealFieldElementDummy multiply(RealFieldElementDummy a) { return new RealFieldElementDummy(this.value * a.value); }
        @Override public RealFieldElementDummy multiply(int n) { return new RealFieldElementDummy(this.value * n); }
        @Override public RealFieldElementDummy divide(RealFieldElementDummy a) { return new RealFieldElementDummy(this.value / a.value); }
        @Override public RealFieldElementDummy reciprocal() { return new RealFieldElementDummy(1 / this.value);}
        @Override public double getReal() { return this.value; }
        @Override public Class<? extends RealFieldElement<RealFieldElementDummy>> getField() { return null; }
        @Override public int compareTo(RealFieldElementDummy o) { return Double.compare(this.value, o.value); }
    }
}