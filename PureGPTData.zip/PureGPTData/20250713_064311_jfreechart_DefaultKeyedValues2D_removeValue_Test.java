import org.jfree.data.DefaultKeyedValues2D;
import org.jfree.data.UnknownKeyException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DefaultKeyedValues2DTest {

    private DefaultKeyedValues2D data;

    @BeforeEach
    public void setUp() {
        data = new DefaultKeyedValues2D();
    }

    @Test
    public void testRemoveValueValidRowColumn() {
        data.addValue(5, "Row1", "Col1");
        assertDoesNotThrow(() -> data.removeValue("Row1", "Col1"));
        assertNull(data.getValue("Row1", "Col1"));
        assertTrue(data.getRowIndex("Row1") < 0); // Ensures row is removed
        assertTrue(data.getColumnIndex("Col1") < 0); // Ensures column is removed
    }

    @Test
    public void testRemoveValueInvalidRowKey() {
        data.addValue(5, "Row1", "Col1");
        assertThrows(UnknownKeyException.class, () -> data.removeValue("InvalidRow", "Col1"));
    }

    @Test
    public void testRemoveValueInvalidColumnKey() {
        data.addValue(5, "Row1", "Col1");
        assertThrows(UnknownKeyException.class, () -> data.removeValue("Row1", "InvalidCol"));
    }

    @Test
    public void testRemoveValueRowBecomesEmpty() {
        data.addValue(5, "Row1", "Col1");
        data.addValue(null, "Row1", "Col2");
        data.removeValue("Row1", "Col1");
        assertTrue(data.getRowIndex("Row1") < 0); // Ensures row is removed
    }

    @Test
    public void testRemoveValueColumnBecomesEmpty() {
        data.addValue(5, "Row1", "Col1");
        data.addValue(null, "Row2", "Col1");
        data.removeValue("Row1", "Col1");
        assertTrue(data.getColumnIndex("Col1") < 0); // Ensures column is removed
    }

    @Test
    public void testRemoveValueNonNullInRow() {
        data.addValue(5, "Row1", "Col1");
        data.addValue(10, "Row1", "Col2");
        data.removeValue("Row1", "Col1");
        assertNotNull(data.getValue("Row1", "Col2"));
        assertEquals(1, data.getRowCount()); // Row should still exist
    }

    @Test
    public void testRemoveValueNonNullInColumn() {
        data.addValue(5, "Row1", "Col1");
        data.addValue(10, "Row2", "Col1");
        data.removeValue("Row1", "Col1");
        assertNotNull(data.getValue("Row2", "Col1"));
        assertEquals(1, data.getColumnCount()); // Column should still exist
    }

    @Test
    public void testRemoveValueRowAndColumnMultipleEntries() {
        data.addValue(5, "Row1", "Col1");
        data.addValue(4, "Row2", "Col2");
        data.removeValue("Row1", "Col1");
        assertNull(data.getValue("Row1", "Col1"));
        assertTrue(data.getRowIndex("Row1") < 0); // Ensures row is removed
        assertTrue(data.getColumnIndex("Col1") < 0); // Ensures column is removed
    }
}