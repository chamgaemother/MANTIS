package org.apache.commons.codec.language;


import org.apache.commons.codec.language.Metaphone;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_4_Test {

    @Test
    @DisplayName("metaphone(\"DGE\") converts 'DGE' to 'J'")
    void TC16() {
        Metaphone metaphone = new Metaphone();
        String input = "judge";
        String result = metaphone.metaphone(input);
        assertTrue(result.contains("J"), "metaphone code should contain 'J'");
    }

    @Test
    @DisplayName("metaphone(\"XEROX\") converts 'X' to 'KS'")
    void TC17() {
        Metaphone metaphone = new Metaphone();
        String input = "XEROX";
        String result = metaphone.metaphone(input);
        assertTrue(result.contains("KS"), "metaphone code should contain 'KS'");
    }

    @Test
    @DisplayName("metaphone(\"PHENOMENON\") handles 'PH' and 'N'")
    void TC18() {
        Metaphone metaphone = new Metaphone();
        String input = "PHENOMENON";
        String result = metaphone.metaphone(input);
        assertTrue(result.contains("F") && result.contains("N"), "metaphone code should contain 'F' and 'N'");
    }

    @Test
    @DisplayName("metaphone(\"GG\") handles duplicate 'G's correctly")
    void TC19() {
        Metaphone metaphone = new Metaphone();
        String input = "gg";
        String result = metaphone.metaphone(input);
        assertEquals("G", result, "Duplicate 'G's should result in single 'G'");
    }

    @Test
    @DisplayName("metaphone(\"SIO\") processes 'SIO' as 'X'")
    void TC20() {
        Metaphone metaphone = new Metaphone();
        String input = "sion";
        String result = metaphone.metaphone(input);
        assertTrue(result.contains("X"), "metaphone code should contain 'X'");
    }

}