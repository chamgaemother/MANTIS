package org.jfree.chart.ui;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class RectangleAnchorTest {

    @Test
    @DisplayName("Test getAnchorPoint with CENTER anchor")
    void testGetAnchorPoint_CENTER() {
        Rectangle2D rectangle = new Rectangle2D.Double(10, 20, 30, 40);
        Point2D expected = new Point2D.Double(25, 40);
        Point2D actual = RectangleAnchor.CENTER.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "CENTER anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with TOP anchor")
    void testGetAnchorPoint_TOP() {
        Rectangle2D rectangle = new Rectangle2D.Double(15, 25, 35, 45);
        Point2D expected = new Point2D.Double(32.5, 25);
        Point2D actual = RectangleAnchor.TOP.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "TOP anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with BOTTOM anchor")
    void testGetAnchorPoint_BOTTOM() {
        Rectangle2D rectangle = new Rectangle2D.Double(5, 10, 20, 30);
        Point2D expected = new Point2D.Double(15, 40);
        Point2D actual = RectangleAnchor.BOTTOM.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "BOTTOM anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with LEFT anchor")
    void testGetAnchorPoint_LEFT() {
        Rectangle2D rectangle = new Rectangle2D.Double(0, 0, 50, 100);
        Point2D expected = new Point2D.Double(0, 50);
        Point2D actual = RectangleAnchor.LEFT.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "LEFT anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with RIGHT anchor")
    void testGetAnchorPoint_RIGHT() {
        Rectangle2D rectangle = new Rectangle2D.Double(10, 20, 30, 40);
        Point2D expected = new Point2D.Double(40, 40);
        Point2D actual = RectangleAnchor.RIGHT.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "RIGHT anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with TOP_LEFT anchor")
    void testGetAnchorPoint_TOP_LEFT() {
        Rectangle2D rectangle = new Rectangle2D.Double(5, 15, 25, 35);
        Point2D expected = new Point2D.Double(5, 15);
        Point2D actual = RectangleAnchor.TOP_LEFT.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "TOP_LEFT anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with TOP_RIGHT anchor")
    void testGetAnchorPoint_TOP_RIGHT() {
        Rectangle2D rectangle = new Rectangle2D.Double(10, 20, 30, 40);
        Point2D expected = new Point2D.Double(40, 20);
        Point2D actual = RectangleAnchor.TOP_RIGHT.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "TOP_RIGHT anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with BOTTOM_LEFT anchor")
    void testGetAnchorPoint_BOTTOM_LEFT() {
        Rectangle2D rectangle = new Rectangle2D.Double(7, 14, 21, 28);
        Point2D expected = new Point2D.Double(7, 42);
        Point2D actual = RectangleAnchor.BOTTOM_LEFT.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "BOTTOM_LEFT anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with BOTTOM_RIGHT anchor")
    void testGetAnchorPoint_BOTTOM_RIGHT() {
        Rectangle2D rectangle = new Rectangle2D.Double(12, 24, 36, 48);
        Point2D expected = new Point2D.Double(48, 72);
        Point2D actual = RectangleAnchor.BOTTOM_RIGHT.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "BOTTOM_RIGHT anchor point mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with rectangle having zero width and height")
    void testGetAnchorPoint_ZeroWidthHeight() {
        Rectangle2D rectangle = new Rectangle2D.Double(10, 20, 0, 0);
        Point2D expectedCenter = new Point2D.Double(10, 20);
        Point2D actualCenter = RectangleAnchor.CENTER.getAnchorPoint(rectangle);
        assertEquals(expectedCenter, actualCenter, "CENTER anchor point with zero width and height mismatch");
    }

    @Test
    @DisplayName("Test getAnchorPoint with null rectangle")
    void testGetAnchorPoint_NullRectangle() {
        assertThrows(NullPointerException.class, () -> {
            RectangleAnchor.CENTER.getAnchorPoint(null);
        }, "Expected NullPointerException for null rectangle");
    }

    @Test
    @DisplayName("Test getAnchorPoint with negative coordinates")
    void testGetAnchorPoint_NegativeCoordinates() {
        Rectangle2D rectangle = new Rectangle2D.Double(-50, -100, 200, 300);
        Point2D expected = new Point2D.Double(-50 + 200 / 2.0, -100 + 300 / 2.0);
        Point2D actual = RectangleAnchor.CENTER.getAnchorPoint(rectangle);
        assertEquals(expected, actual, "CENTER anchor point with negative coordinates mismatch");
    }
}