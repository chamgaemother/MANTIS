import com.fasterxml.jackson.core.io.ContentReference;
import com.fasterxml.jackson.core.ErrorReportConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.net.URI;
import java.net.URL;
import java.io.File;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ContentReferenceTest {

    private ErrorReportConfiguration errorReportConfiguration;

    @BeforeEach
    void setUp() {
        errorReportConfiguration = ErrorReportConfiguration.defaults();
    }
    
    @Test
    void testAppendSourceDescription_nullRawContent() {
        ContentReference cr = new ContentReference(false, null, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);
        
        assertEquals("UNKNOWN", result.toString());
    }

    @Test
    void testAppendSourceDescription_redactedContent() {
        ContentReference cr = ContentReference.redacted();
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);
        
        assertEquals("REDACTED (`StreamReadFeature.INCLUDE_SOURCE_IN_LOCATION` disabled)", result.toString());
    }

    @Test
    void testAppendSourceDescription_classAsRawContent() {
        ContentReference cr = new ContentReference(true, String.class, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(Class)\"\"", result.toString());
    }
    
    @Test
    void testAppendSourceDescription_stringAsRawContent() {
        ContentReference cr = new ContentReference(true, "test", errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(String)\"test\"", result.toString());
    }
    
    @Test
    void testAppendSourceDescription_charArrayAsRawContent() {
        ContentReference cr = new ContentReference(true, new char[]{'t', 'e', 's', 't'}, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(char[])\"test\"", result.toString());
    }
    
    @Test
    void testAppendSourceDescription_byteArrayAsRawContent() {
        ContentReference cr = new ContentReference(true, "test".getBytes(), errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(byte[])\"test\"", result.toString());
    }

    @Test
    void testAppendSourceDescription_nonTextualContent() {
        ContentReference cr = new ContentReference(false, "test".getBytes(), errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(byte[])[4 bytes]", result.toString());
    }

    @ParameterizedTest
    @CsvSource({
        "true, byte[], byte[]",
        "true, char[], char[]",
        "false, byte[], byte[]"
    })
    void testAppendSourceDescription_specialCases(boolean isTextual, String type, String expectedType) {
        Object rawContent = "test".getBytes();
        if ("char[]".equals(type)) {
            rawContent = new char[]{'t', 'e', 's', 't'};
        }
        ContentReference cr = new ContentReference(isTextual, rawContent, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        if (isTextual) {
            assertEquals("(" + expectedType + ")\"test\"", result.toString());
        } else {
            assertEquals("(" + expectedType + ")[4 bytes]", result.toString());
        }
    }

    @Test
    void testAppendSourceDescription_withFile() {
        File file = new File("test.txt");
        ContentReference cr = new ContentReference(false, file, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(File)[0 bytes]", result.toString());
    }
    
    @Test
    void testAppendSourceDescription_withURL() throws Exception {
        URL url = new URL("http://example.com");
        ContentReference cr = new ContentReference(false, url, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(URL)[0 bytes]", result.toString());
    }
    
    @Test
    void testAppendSourceDescription_withURI() throws Exception {
        URI uri = new URI("http://example.com");
        ContentReference cr = new ContentReference(false, uri, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(URI)[0 bytes]", result.toString());
    }
    
    @Test
    void testAppendSourceDescription_withHashMap() {
        HashMap<String, String> map = new HashMap<>();
        map.put("key", "value");
        ContentReference cr = new ContentReference(true, map, errorReportConfiguration);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = cr.appendSourceDescription(sb);

        assertEquals("(java.util.HashMap)\"\"", result.toString());
    }
}