package org.apache.commons.compress.compressors.gzip;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class GzipParameters_equals_0_1_Test {

    @Test
    @DisplayName("equals returns true when comparing the object with itself")
    void TC01_equalsSameObject() {
        // GIVEN
        GzipParameters params = new GzipParameters();
        
        // WHEN
        boolean result = params.equals(params);
        
        // THEN
        assertTrue(result);
    }
    
    @Test
    @DisplayName("equals returns false when comparing with null")
    void TC02_equalsWithNull() {
        // GIVEN
        GzipParameters params = new GzipParameters();
        
        // WHEN
        boolean result = params.equals(null);
        
        // THEN
        assertFalse(result);
    }
    
    @Test
    @DisplayName("equals returns false when comparing with an object of different type")
    void TC03_equalsWithDifferentType() {
        // GIVEN
        GzipParameters params = new GzipParameters();
        String differentType = "Not a GzipParameters";
        
        // WHEN
        boolean result = params.equals(differentType);
        
        // THEN
        assertFalse(result);
    }
    
    @Test
    @DisplayName("equals returns false when bufferSize differs")
    void TC04_equalsDifferentBufferSize() {
        // GIVEN
        GzipParameters params1 = new GzipParameters();
        params1.setBufferSize(1024);
        GzipParameters params2 = new GzipParameters();
        params2.setBufferSize(2048);
        
        // WHEN
        boolean result = params1.equals(params2);
        
        // THEN
        assertFalse(result);
    }
    
    @Test
    @DisplayName("equals returns false when comment differs")
    void TC05_equalsDifferentComment() {
        // GIVEN
        GzipParameters params1 = new GzipParameters();
        params1.setComment("Comment A");
        GzipParameters params2 = new GzipParameters();
        params2.setComment("Comment B");
        
        // WHEN
        boolean result = params1.equals(params2);
        
        // THEN
        assertFalse(result);
    }
}