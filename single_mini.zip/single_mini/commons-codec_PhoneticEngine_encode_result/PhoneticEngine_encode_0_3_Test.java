package org.apache.commons.codec.language.bm;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.bm.PhoneticEngine;
import org.apache.commons.codec.language.bm.NameType;
import org.apache.commons.codec.language.bm.RuleType;
import org.apache.commons.codec.language.bm.Languages;

public class PhoneticEngine_encode_0_3_Test {

    @Test
    @DisplayName("encode with concatenation disabled and multi-word input")
    void TC11() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.LANGUAGE, false);
        String input = "John Doe";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("en");

        // When
        String result = engine.encode(input, languageSet);

        // Then
        assertNotNull(result, "The result should not be null");
        assertEquals("JHN-D", result, "Phonetic encoding mismatch");
    }

    @Test
    @DisplayName("encode with invalid NameType leading to NullPointerException")
    void TC12() {
        // Given
        // Attempting to instantiate PhoneticEngine with an invalid NameType (null)
        // Note: Passing null to simulate an invalid NameType
        RuleType validRuleType = RuleType.LANGUAGE; // Assuming RuleType.LANGUAGE is valid

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            PhoneticEngine engine = new PhoneticEngine(null, validRuleType, true);
            engine.encode("Invalid", Languages.LanguageSet.from("en"));
        }, "Expected NullPointerException when NameType is null");
    }

    @Test
    @DisplayName("encode with empty input")
    void TC13() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.LANGUAGE, true);
        String input = "";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("en");

        // When
        String result = engine.encode(input, languageSet);

        // Then
        assertEquals("", result, "Encoding of empty input should be empty string");
    }

    @Test
    @DisplayName("encode with input containing multiple consecutive spaces")
    void TC14() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.LANGUAGE, true);
        String input = "John   Doe";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("en");

        // When
        String result = engine.encode(input, languageSet);

        // Then
        assertNotNull(result, "The result should not be null");
        assertEquals("JHN-D", result, "Phonetic encoding mismatch");
    }

    @Test
    @DisplayName("encode with input containing special characters and punctuation")
    void TC15() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.SEPHARDIC, RuleType.LANGUAGE, true);
        String input = "O'Connor!";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("en");

        // When
        String result = engine.encode(input, languageSet);

        // Then
        assertNotNull(result, "The result should not be null");
        assertEquals("CNNR", result, "Phonetic encoding mismatch");
    }
}