package org.apache.commons.math3.optim.univariate;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyDouble;

public class BracketFinder_search_0_4_Test {

    private static final double EPS_MIN = 1e-20;
    private static final double GOLD = 1.618034;
    private static final double MAX_DOUBLE = Double.MAX_VALUE;

    @Test
    @DisplayName("search method with denom < EPS_MIN, ensuring prevention of division by very small number")
    void testTC16() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.618034;

        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
        // Mock behavior to cause val < EPS_MIN
        // Assuming 'val' is computed as 2 * EPS_MIN
        Mockito.when(func.value(anyDouble())).thenAnswer(invocation -> {
            double x = invocation.getArgument(0);
            // Return values that will lead to val < EPS_MIN
            if (x == xA) return 1.0;
            if (x == xB) return 2.0;
            return 0.0;
        });

        BracketFinder bracketFinder = new BracketFinder();

        // WHEN
        bracketFinder.search(func, goal, xA, growLimit);

        // THEN
        // Access the private field 'denominator' via reflection if it exists
        // Since 'denominator' is a local variable, we verify side effects
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        hiField.setAccessible(true);
        double hi = hiField.getDouble(bracketFinder);
        assertEquals(2.0, hi, 1e-6, "Hi should remain as initial xB since denominator adjustment prevents swapping.");
    }

    @Test
    @DisplayName("search method with denominator val >= EPS_MIN, normal division operation")
    void testTC17() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 3.0;
        double xB = 4.0;
        double growLimit = 2.0;

        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
        // Mock behavior to cause val >= EPS_MIN
        Mockito.when(func.value(anyDouble())).thenAnswer(invocation -> {
            double x = invocation.getArgument(0);
            if (x == xA) return 5.0;
            if (x == xB) return 3.0;
            return 0.0;
        });

        BracketFinder bracketFinder = new BracketFinder();

        // WHEN
        bracketFinder.search(func, goal, xA, growLimit);

        // THEN
        // Verify that denominator was calculated as 2 * val by checking internal state
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        hiField.setAccessible(true);
        double hi = hiField.getDouble(bracketFinder);
        assertEquals(3.0, hi, 1e-6, "Hi should be updated based on normal denominator calculation.");
    }

    @Test
    @DisplayName("search method where (w - xC)*(xB - w) > 0, evaluating fW and updating xA, xB")
    void testTC18() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 2.0;
        double xB = 3.0;
        double growLimit = 1.618034;

        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
        // Mock behavior to satisfy (w - xC)*(xB - w) > 0
        Mockito.when(func.value(anyDouble())).thenAnswer(invocation -> {
            double x = invocation.getArgument(0);
            if (x == xA) return 2.0;
            if (x == xB) return 1.5;
            if (x > xB) return 1.0;
            return 3.0;
        });

        BracketFinder bracketFinder = new BracketFinder();

        // WHEN
        bracketFinder.search(func, goal, xA, growLimit);

        // THEN
        // Verify that xA and xB are updated based on new w evaluation
        Field xAField = BracketFinder.class.getDeclaredField("lo");
        Field xBField = BracketFinder.class.getDeclaredField("mid");
        xAField.setAccessible(true);
        xBField.setAccessible(true);
        double updatedXA = xAField.getDouble(bracketFinder);
        double updatedXB = xBField.getDouble(bracketFinder);
        assertEquals(3.0, updatedXA, 1e-6, "xA should be updated to previous xB.");
        assertEquals(1.5, updatedXB, 1e-6, "xB should be updated based on fW evaluation.");
    }

    @Test
    @DisplayName("search method with w exceeding wLim, setting w to wLim")
    void testTC19() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.0;

        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
        // Mock behavior to cause w > wLim
        Mockito.when(func.value(anyDouble())).thenAnswer(invocation -> {
            double x = invocation.getArgument(0);
            if (x == xA) return 3.0;
            if (x == xB) return 2.0;
            if (x > xB) return 1.0;
            return 4.0;
        });

        BracketFinder bracketFinder = new BracketFinder();

        // WHEN
        bracketFinder.search(func, goal, xA, growLimit);

        // THEN
        // Verify that w is set to wLim
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        hiField.setAccessible(true);
        double hi = hiField.getDouble(bracketFinder);
        assertEquals(xB + growLimit * (xB - xA), hi, 1e-6, "w should be set to wLim.");
    }

    @Test
    @DisplayName("search method with (w - wLim)*(wLim - xC) >= 0, setting w to wLim")
    void testTC20() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 0.5;
        double xB = 1.0;
        double growLimit = 1.618034;

        UnivariateFunction func = Mockito.mock(UnivariateFunction.class);
        // Mock behavior to satisfy (w - wLim)*(wLim - xC) >= 0
        Mockito.when(func.value(anyDouble())).thenAnswer(invocation -> {
            double x = invocation.getArgument(0);
            if (x == xA) return 1.0;
            if (x == xB) return 0.5;
            if (x > xB) return 0.3;
            return 0.7;
        });

        BracketFinder bracketFinder = new BracketFinder();

        // WHEN
        bracketFinder.search(func, goal, xA, growLimit);

        // THEN
        // Verify that w is set to wLim and fW is evaluated correctly
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        hiField.setAccessible(true);
        double hi = hiField.getDouble(bracketFinder);
        assertEquals(xB + growLimit * (xB - xA), hi, 1e-6, "w should be set to wLim.");
    }
}