package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryBeMsb0ToHexDigit_0_3_Test {

    @Test
    @DisplayName("Returns 'c' when pos >= 3, src[pos-3] is true, src[pos-2] is false, src[pos-1] is true, and src[pos] is false")
    void test_TC11_Returns_c() {
        boolean[] src = new boolean[]{false, true, false, true};
        int srcPos = 0;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('c', result);
    }

    @Test
    @DisplayName("Handles srcPos at upper boundary (srcPos = src.length - 1)")
    void test_TC12_srcPos_upper_boundary() {
        boolean[] src = new boolean[]{false};
        int srcPos = src.length - 1;
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        assertEquals('0', result);
    }
}