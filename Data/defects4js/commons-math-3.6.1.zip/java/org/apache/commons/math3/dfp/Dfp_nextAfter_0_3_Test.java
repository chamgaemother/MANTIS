package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_nextAfter_0_3_Test {

    @Test
    @DisplayName("nextAfter handles addition overflow by setting FLAG_INEXACT")
    void TC11_nextAfter_additionOverflow_sets_FLAG_INEXACT() throws Exception {
        // Arrange
        DfpField testField = new DfpField(20); // Assuming a precision
        Dfp a = new Dfp(testField, Integer.MAX_VALUE); // Dfp with high magnitude to cause overflow on add
        Dfp b = new Dfp(testField, 1);
        
        // Act
        Dfp result = a.nextAfter(b);
        
        // Assert
        Field field = Dfp.class.getDeclaredField("field");
        field.setAccessible(true);
        DfpField dfpField = (DfpField) field.get(a);
        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlagsBits");
        ieeeFlagsField.setAccessible(true);
        int flags = ieeeFlagsField.getInt(dfpField);
        assertTrue((flags & DfpField.FLAG_INEXACT) != 0, "FLAG_INEXACT should be set");
        assertEquals(Dfp.INFINITE, result.classify(), "Result should be INFINITE");
    }

    @Test
    @DisplayName("nextAfter results in zero while this is non-zero sets FLAG_INEXACT")
    void TC12_nextAfter_resultsInZero_and_thisNotZero_sets_FLAG_INEXACT() throws Exception {
        // Arrange
        DfpField testField = new DfpField(20); // Assuming a precision
        Dfp a = new Dfp(testField, 1e-300); // Dfp with magnitude causing underflow to zero
        Dfp b = new Dfp(testField, 0);
        
        // Act
        Dfp result = a.nextAfter(b);
        
        // Assert
        Field field = Dfp.class.getDeclaredField("field");
        field.setAccessible(true);
        DfpField dfpField = (DfpField) field.get(a);
        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlagsBits");
        ieeeFlagsField.setAccessible(true);
        int flags = ieeeFlagsField.getInt(dfpField);
        assertTrue((flags & DfpField.FLAG_INEXACT) != 0, "FLAG_INEXACT should be set");
        assertTrue(!result.equals(a.getZero()), "Result should not equal zero");
    }

    @Test
    @DisplayName("nextAfter finite result with this INFINITE")
    void TC13_nextAfter_finiteResult_with_this_INFINITE_doesNotSet_FLAG_INEXACT() throws Exception {
        // Arrange
        DfpField testField = new DfpField(20); // Assuming a precision
        Dfp a = new Dfp(testField, (byte) 1, Dfp.INFINITE); // Create an infinite Dfp instance
        Dfp b = new Dfp(testField, 1);
        
        // Act
        Dfp result = a.nextAfter(b);
        
        // Assert
        Field field = Dfp.class.getDeclaredField("field");
        field.setAccessible(true);
        DfpField dfpField = (DfpField) field.get(a);
        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlagsBits");
        ieeeFlagsField.setAccessible(true);
        int flags = ieeeFlagsField.getInt(dfpField);
        assertFalse((flags & DfpField.FLAG_INEXACT) != 0, "FLAG_INEXACT should not be set");
        assertNotEquals(Dfp.INFINITE, result.classify(), "Result should be finite");
    }

    private DfpField getField() throws Exception {
        return new DfpField(20); // Assuming a precision value of 20 digits
    }
}
