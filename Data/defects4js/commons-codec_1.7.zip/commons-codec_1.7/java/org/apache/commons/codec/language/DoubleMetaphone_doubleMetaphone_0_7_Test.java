package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.DoubleMetaphone;

/**
 * JUnit 5 test class for DoubleMetaphone.doubleMetaphone method based on provided scenarios.
 */
public class DoubleMetaphone_doubleMetaphone_0_7_Test {

    @Test
    @DisplayName("doubleMetaphone(\"XERXES\", true) handles alternate encoding with 'X'")
    void TC31_doubleMetaphone_X_alternate_encoding() {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "XERXES";

        // Act
        String result = encoder.doubleMetaphone(input, true);

        // Assert
        assertEquals("SRSKS", result, "Alternate encoding should encode 'X' as 'S'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"ZZZ\", false) handles triple 'Z'")
    void TC32_doubleMetaphone_triple_Z() {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "ZZZ";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertEquals("SSS", result, "Triple 'Z' should be encoded correctly as 'SSS'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"SCHMUCK\", false) handles 'SCH'")
    void TC33_doubleMetaphone_SCH_combination() {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "SCHMUCK";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertTrue(result.equals("SKMK") || result.equals("XMK"), "'SCH' should be encoded as 'SK' or 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"WITCH\", false) handles 'W' with 'H'")
    void TC34_doubleMetaphone_WH_combination() {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "WITCH";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertTrue(result.equals("FCH") || result.equals("ACH"), "'WH' should be encoded as 'F' or 'A'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"CZECH\", false) handles 'CZ' not preceded by 'W'")
    void TC35_doubleMetaphone_CZ_combination() {
        // Arrange
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "CZECH";

        // Act
        String result = encoder.doubleMetaphone(input, false);

        // Assert
        assertEquals("SCJS", result, "'CZ' should be encoded as 'S'");
    }
}