package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.List;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class XYStepRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem with stepPoint set to 1.0 ensures step is drawn at the second data point")
    public void TC25_stepPointAt1_0_drawStepsAtSecondPoint() {
        // Given
        XYStepRenderer renderer = new XYStepRenderer();
        renderer.setStepPoint(1.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Arrange dataset with at least two data points with distinct Y values
        when(dataset.getItemCount(anyInt())).thenReturn(2);
        when(dataset.getXValue(anyInt(), eq(0))).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), eq(0))).thenReturn(2.0);
        when(dataset.getXValue(anyInt(), eq(1))).thenReturn(2.0);
        when(dataset.getYValue(anyInt(), eq(1))).thenReturn(3.0);

        // Mock plot orientation and axis edges
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        // Mock axis value transformations
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // Then
        ArgumentCaptor<Line2D.Double> lineCaptor = ArgumentCaptor.forClass(Line2D.Double.class);
        verify(g2, times(3)).draw(lineCaptor.capture());

        List<Line2D.Double> capturedLines = lineCaptor.getAllValues();

        // First line: Horizontal step from (100.0, 150.0) to (200.0, 150.0)
        assertEquals(100.0, capturedLines.get(0).getX1());
        assertEquals(150.0, capturedLines.get(0).getY1());
        assertEquals(200.0, capturedLines.get(0).getX2());
        assertEquals(150.0, capturedLines.get(0).getY2());

        // Second line: Vertical step from (200.0, 150.0) to (200.0, 250.0)
        assertEquals(200.0, capturedLines.get(1).getX1());
        assertEquals(150.0, capturedLines.get(1).getY1());
        assertEquals(200.0, capturedLines.get(1).getX2());
        assertEquals(250.0, capturedLines.get(1).getY2());

        // Third line: Horizontal line at the second data point (redundant in this case)
        assertEquals(200.0, capturedLines.get(2).getX1());
        assertEquals(250.0, capturedLines.get(2).getY1());
        assertEquals(200.0, capturedLines.get(2).getX2());
        assertEquals(250.0, capturedLines.get(2).getY2());
    }

    @Test
    @DisplayName("drawItem with lines outside dataArea are clipped, resulting in no lines being drawn")
    public void TC26_clipLineReturnsFalse_noLinesDrawn() {
        // Given
        XYStepRenderer renderer = new XYStepRenderer();

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Arrange dataset with two data points
        when(dataset.getItemCount(anyInt())).thenReturn(2);
        when(dataset.getXValue(anyInt(), eq(0))).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), eq(0))).thenReturn(2.0);
        when(dataset.getXValue(anyInt(), eq(1))).thenReturn(2.0);
        when(dataset.getYValue(anyInt(), eq(1))).thenReturn(3.0);

        // Mock plot orientation and axis edges
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        // Mock axis value transformations to return coordinates outside dataArea
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM))).thenReturn(-100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(-150.0);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // Then
        verify(g2, never()).draw(any(Line2D.class));
    }
}