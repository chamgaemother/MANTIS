package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.io.IOContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ByteSourceJsonBootstrapper_detectEncoding_0_1_Test {

    @Test
    @DisplayName("ensureLoaded(4) returns true and handleBOM successfully detects UTF32_BE")
    public void TC01_detectEncoding_UTF32_BE_via_handleBOM() throws Exception {
        // Setup input stream with UTF32_BE BOM: 00 00 FE FF
        byte[] utf32BEBom = {(byte)0x00, (byte)0x00, (byte)0xFE, (byte)0xFF, (byte)0x00};
        ByteArrayInputStream inputStream = new ByteArrayInputStream(utf32BEBom);
        IOContext context = new IOContext(null, inputStream, false);

        // Initialize ByteSourceJsonBootstrapper instance
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, inputStream);

        // Invoke detectEncoding()
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // Assert the encoding is UTF32_BE
        assertEquals(JsonEncoding.UTF32_BE, encoding);
    }

    @Test
    @DisplayName("ensureLoaded(4) returns true and handleBOM successfully detects UTF32_LE")
    public void TC02_detectEncoding_UTF32_LE_via_handleBOM() throws Exception {
        // Setup input stream with UTF32_LE BOM: FF FE 00 00
        byte[] utf32LEBom = {(byte)0xFF, (byte)0xFE, (byte)0x00, (byte)0x00, (byte)0x00};
        ByteArrayInputStream inputStream = new ByteArrayInputStream(utf32LEBom);
        IOContext context = new IOContext(null, inputStream, false);

        // Initialize ByteSourceJsonBootstrapper instance
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, inputStream);

        // Invoke detectEncoding()
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // Assert the encoding is UTF32_LE
        assertEquals(JsonEncoding.UTF32_LE, encoding);
    }

    @Test
    @DisplayName("ensureLoaded(4) returns true and handleBOM successfully detects UTF16_BE")
    public void TC03_detectEncoding_UTF16_BE_via_handleBOM() throws Exception {
        // Setup input stream with UTF16_BE BOM: FE FF 00 00
        byte[] utf16BEBom = {(byte)0xFE, (byte)0xFF, (byte)0x00, (byte)0x00, (byte)0x00};
        ByteArrayInputStream inputStream = new ByteArrayInputStream(utf16BEBom);
        IOContext context = new IOContext(null, inputStream, false);

        // Initialize ByteSourceJsonBootstrapper instance
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, inputStream);

        // Invoke detectEncoding()
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // Assert the encoding is UTF16_BE
        assertEquals(JsonEncoding.UTF16_BE, encoding);
    }

    @Test
    @DisplayName("ensureLoaded(4) returns true and handleBOM successfully detects UTF16_LE")
    public void TC04_detectEncoding_UTF16_LE_via_handleBOM() throws Exception {
        // Setup input stream with UTF16_LE BOM: FF FE 00 00
        byte[] utf16LEBom = {(byte)0xFF, (byte)0xFE, (byte)0x00, (byte)0x00, (byte)0x00};
        ByteArrayInputStream inputStream = new ByteArrayInputStream(utf16LEBom);
        IOContext context = new IOContext(null, inputStream, false);

        // Initialize ByteSourceJsonBootstrapper instance
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, inputStream);

        // Invoke detectEncoding()
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // Assert the encoding is UTF16_LE
        assertEquals(JsonEncoding.UTF16_LE, encoding);
    }

    @Test
    @DisplayName("ensureLoaded(4) returns true and handleBOM detects UTF8 BOM")
    public void TC05_detectEncoding_UTF8_via_handleBOM() throws Exception {
        // Setup input stream with UTF8 BOM: EF BB BF 00
        byte[] utf8Bom = {(byte)0xEF, (byte)0xBB, (byte)0xBF, (byte)0x00};
        ByteArrayInputStream inputStream = new ByteArrayInputStream(utf8Bom);
        IOContext context = new IOContext(null, inputStream, false);

        // Initialize ByteSourceJsonBootstrapper instance
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, inputStream);

        // Invoke detectEncoding()
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // Assert the encoding is UTF8
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    // Helper method to set private fields via reflection
    private void setPrivateField(Object instance, String fieldName, Object value) throws Exception {
        Field field = ByteSourceJsonBootstrapper.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(instance, value);
    }
}