package org.apache.commons.compress.harmony.pack200;

import java.lang.reflect.Field;
import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;

public class BcBands_visitMethodInsn_0_3_Test {

    @Test
    @DisplayName("Test aload_0 condition false with valid opcode 182")
    public void testAload0ConditionFalseWithValidOpcode182() throws Exception {
        // Arrange
        CpBands cpBands = Mockito.mock(CpBands.class); // Use mock for dependency-backed object
        Segment segment = Mockito.mock(Segment.class); // Required dependency
        SegmentHeader segmentHeader = Mockito.mock(SegmentHeader.class);
        Mockito.when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        BcBands bcBands = new BcBands(cpBands, segment, 0); // Correct constructor call

        int validOpcode = 182;
        String owner = "someOwnerClass";
        String name = "nonInitMethod";
        String desc = "methodDesc";

        // Simulating private field access and initialization
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        bcCodesField.set(bcBands, new IntList());

        // Act
        bcBands.visitMethodInsn(validOpcode, owner, name, desc);

        // Assert
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        assertEquals(List.of(validOpcode), bcCodes.toArrayList(), "Opcode should be added without aload_0 adjustment");
    }

    // Utility class to help with ArrayList assertion
    private static class IntList extends ArrayList<Integer> {
        public ArrayList<Integer> toArrayList() {
            return new ArrayList<>(this);
        }
    }
}