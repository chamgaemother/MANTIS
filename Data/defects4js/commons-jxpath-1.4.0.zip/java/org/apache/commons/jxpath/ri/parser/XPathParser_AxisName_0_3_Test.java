package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.parser.Token;
import org.apache.commons.jxpath.ri.parser.ParseException;

public class XPathParser_AxisName_0_3_Test {
    
    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_FOLLOWING_SIBLING returns Compiler.AXIS_FOLLOWING_SIBLING")
    public void TC11() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((java.io.Reader) null);  // Fixed: No parameter constructor doesn't exist
        
        // Access and set jj_nt.kind via reflection
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = (Token) jjNtField.get(parser);
        
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_FOLLOWING_SIBLING);
        
        // Call AxisName
        int axis = parser.AxisName();
        
        // Assert the expected result
        assertEquals(Compiler.AXIS_FOLLOWING_SIBLING, axis);
    }
    
    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_PRECEDING_SIBLING returns Compiler.AXIS_PRECEDING_SIBLING")
    public void TC12() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((java.io.Reader) null);
        
        // Access and set jj_nt.kind via reflection
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = (Token) jjNtField.get(parser);
        
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_PRECEDING_SIBLING);
        
        // Call AxisName
        int axis = parser.AxisName();
        
        // Assert the expected result
        assertEquals(Compiler.AXIS_PRECEDING_SIBLING, axis);
    }
    
    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_DESCENDANT_OR_SELF returns Compiler.AXIS_DESCENDANT_OR_SELF")
    public void TC13() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((java.io.Reader) null);
        
        // Access and set jj_nt.kind via reflection
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = (Token) jjNtField.get(parser);
        
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_DESCENDANT_OR_SELF);
        
        // Call AxisName
        int axis = parser.AxisName();
        
        // Assert the expected result
        assertEquals(Compiler.AXIS_DESCENDANT_OR_SELF, axis);
    }
    
    @Test
    @DisplayName("AxisName with invalid jj_nt.kind throws ParseException")
    public void TC14() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((java.io.Reader) null);
        
        // Access and set jj_nt.kind via reflection
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = (Token) jjNtField.get(parser);
        
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, -1);
        
        // Call AxisName and expect ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }
}
