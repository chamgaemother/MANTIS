package org.apache.commons.jxpath.util;

import java.lang.reflect.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

public class BasicTypeConverter_canConvert_0_4_Test {

    private final BasicTypeConverter typeConverter = new BasicTypeConverter();  // Instantiate

    @Test
    @DisplayName("object is String and useType is Float, should return true")
    void TC16_StringToFloat_ShouldReturnTrue() {
        // GIVEN
        Object object = "3.14";
        Class<?> toType = Float.class;

        // WHEN
        boolean result = typeConverter.canConvert(object, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true for String to Float conversion");
    }

    @Test
    @DisplayName("object is String and useType is Double, should return true")
    void TC17_StringToDouble_ShouldReturnTrue() {
        // GIVEN
        Object object = "2.71828";
        Class<?> toType = Double.class;

        // WHEN
        boolean result = typeConverter.canConvert(object, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true for String to Double conversion");
    }

    @Test
    @DisplayName("object is String and useType is unsupported type, should return false")
    void TC18_StringToUnsupportedType_ShouldReturnFalse() {
        // GIVEN
        Object object = "invalid";
        Class<?> toType = Object.class;

        // WHEN
        boolean result = typeConverter.canConvert(object, toType);

        // THEN
        assertFalse(result, "Expected canConvert to return false for String to unsupported Object conversion");
    }

    @Test
    @DisplayName("fromType is array and useType is array with all elements convertible, should return true")
    void TC19_ArrayToArrayAllConvertible_ShouldReturnTrue() {
        // GIVEN
        Object object = new Integer[]{1, 2, 3};
        Class<?> toType = Number[].class;

        // WHEN
        boolean result = typeConverter.canConvert(object, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true when all array elements are convertible");
    }

    @Test
    @DisplayName("fromType is array and useType is array with some elements not convertible, should return false")
    void TC20_ArrayToArraySomeNotConvertible_ShouldReturnFalse() {
        // GIVEN
        Object object = new Object[]{1, "two", 3};
        Class<?> toType = Number[].class;

        // WHEN
        boolean result = typeConverter.canConvert(object, toType);

        // THEN
        assertFalse(result, "Expected canConvert to return false when some array elements are not convertible");
    }
}
