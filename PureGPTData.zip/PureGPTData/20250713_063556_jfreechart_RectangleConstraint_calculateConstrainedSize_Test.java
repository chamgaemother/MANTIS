import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.jfree.chart.block.RectangleConstraint;
import org.jfree.chart.ui.Size2D;
import org.jfree.chart.util.Args;
import org.jfree.data.Range;
import org.junit.jupiter.api.Test;

public class RectangleConstraintTest {

    @Test
    public void testFixedWidthAndHeight() {
        RectangleConstraint constraint = new RectangleConstraint(10, 20);
        Size2D result = constraint.calculateConstrainedSize(new Size2D(15, 25));
        assertEquals(10, result.width);
        assertEquals(20, result.height);
    }

    @Test
    public void testRangeWidthAndHeight() {
        RectangleConstraint constraint = new RectangleConstraint(new Range(5, 15), new Range(10, 30));
        Size2D result = constraint.calculateConstrainedSize(new Size2D(20, 25));
        assertEquals(15, result.width);
        assertEquals(25, result.height);
    }

    @Test
    public void testNoneWidthAndHeight() {
        RectangleConstraint constraint = RectangleConstraint.NONE;
        Size2D result = constraint.calculateConstrainedSize(new Size2D(5, 10));
        assertEquals(5, result.width);
        assertEquals(10, result.height);
    }

    @Test
    public void testFixedWidthRangeHeight() {
        RectangleConstraint constraint = new RectangleConstraint(10, new Range(15, 25));
        Size2D result = constraint.calculateConstrainedSize(new Size2D(20, 30));
        assertEquals(10, result.width);
        assertEquals(25, result.height);
    }

    @Test
    public void testRangeWidthFixedHeight() {
        RectangleConstraint constraint = new RectangleConstraint(new Range(5, 15), 20);
        Size2D result = constraint.calculateConstrainedSize(new Size2D(20, 25));
        assertEquals(15, result.width);
        assertEquals(20, result.height);
    }

    @Test
    public void testRangeWidthNoneHeight() {
        RectangleConstraint constraint = new RectangleConstraint(new Range(5, 10), new Range(0, 0));
        Size2D result = constraint.calculateConstrainedSize(new Size2D(7, 30));
        assertEquals(7, result.width);
        assertEquals(30, result.height);
    }

    @Test
    public void testNoneWidthFixedHeight() {
        RectangleConstraint constraint = new RectangleConstraint(new Range(0, 0), 10);
        Size2D result = constraint.calculateConstrainedSize(new Size2D(7, 3));
        assertEquals(7, result.width);
        assertEquals(10, result.height);
    }

    @Test
    public void testInvalidWidthRange() {
        Range invalidRange = new Range(10, 5);
        assertThrows(IllegalArgumentException.class, () -> {
            new RectangleConstraint(0.0, invalidRange, LengthConstraintType.RANGE, 0.0, null, LengthConstraintType.NONE);
        });
    }

    @Test
    public void testInvalidHeightRange() {
        Range invalidRange = new Range(10, 5);
        assertThrows(IllegalArgumentException.class, () -> {
            new RectangleConstraint(0.0, null, LengthConstraintType.NONE, 0.0, invalidRange, LengthConstraintType.RANGE);
        });
    }
}