package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.util.Arrays;
import java.util.Collections;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_2_2_Test {

    @Test
    @DisplayName("drawVerticalItem with exception thrown by getBoxPaint")
    void TC31_drawVerticalItem_withExceptionInGetBoxPaint() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
        // Throwing exception when getBoxPaint is called
        doThrow(new RuntimeException("Test getBoxPaint exception")).when(renderer).getBoxPaint();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
        when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
        when(dataset.getX(0, 0)).thenReturn(50.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(80.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(20.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(50.0);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        });
    }

    @Test
    @DisplayName("drawVerticalItem with yQ1Median > yQ3Median, ensuring box is drawn correctly")
    void TC32_drawVerticalItem_yQ1GreaterThanYQ3() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(5.0); // Q1 > Q3
        when(dataset.getX(0, 0)).thenReturn(10.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(7.5);
        when(dataset.getMeanValue(0, 0)).thenReturn(7.5);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        // Assert
        verify(g2, times(1)).fill(any(Rectangle2D.class));
        verify(g2, times(1)).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawVerticalItem with overlapping outliers requiring multiple ellipses")
    void TC33_drawVerticalItem_overlappingOutliers() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(50.0);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(15.0, 15.0)); // Overlapping outliers
        when(dataset.getMaxOutlier(0, 0)).thenReturn(80.0);
        when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
        when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
        when(dataset.getX(0, 0)).thenReturn(50.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(50.0);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        // Assert
        verify(renderer, times(2)).drawEllipse(any(Point2D.class), anyDouble(), eq(g2));
    }

//     @Test
//     @DisplayName("drawVerticalItem with outliers processing loop iterating zero times")
//     void TC34_drawVerticalItem_noOutliers() {
        // Arrange
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         when(dataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
//         when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
//         when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
//         when(dataset.getX(0, 0)).thenReturn(50.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
//         when(dataset.getMeanValue(0, 0)).thenReturn(50.0);
// 
        // Act
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
        // Assert
//         verify(dataset, times(1)).getOutliers(0, 0);
//         verify(g2, never()).draw(any());
//     }

    @Test
    @DisplayName("drawVerticalItem with outliers processing loop iterating once")
    void TC35_drawVerticalItem_singleOutlier() {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(25.0)); // Within regular range
        when(dataset.getMaxOutlier(0, 0)).thenReturn(80.0);
        when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
        when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
        when(dataset.getX(0, 0)).thenReturn(50.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(50.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(50.0);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        // Assert
        verify(renderer, times(1)).drawEllipse(any(Point2D.class), anyDouble(), eq(g2));
    }
}