package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.NumberAxis;
import java.util.List;

public class XYPlot_clone_1_2_Test {

//     @Test
//     @DisplayName("Cloning CombinedDomainXYPlot with multiple subplots and domainAxis null")
//     public void testTC16_cloneWithMultipleSubplotsAndNullDomainAxis() throws CloneNotSupportedException {
        // GIVEN
//         CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
//         XYPlot subplot1 = new XYPlot();
//         XYPlot subplot2 = new XYPlot();
//         XYPlot subplot3 = new XYPlot(); // Changed from Plot to XYPlot to avoid cast exceptions
//         plot.add(subplot1);
//         plot.add(subplot2);
//         plot.add(subplot3);
//         plot.setDomainAxis(null);
// 
        // WHEN
//         CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone(); // Ensure proper casting
// 
        // THEN
//         assertNotSame(clonedPlot, plot, "Cloned plot should be a different instance");
//         List<Plot> clonedSubplots = clonedPlot.getSubplots();
//         assertEquals(3, clonedSubplots.size(), "Cloned plot should have three subplots");
//         for (Plot clonedSubplot : clonedSubplots) {
//             assertNotSame(clonedSubplot, subplot1, "Each cloned subplot should be a different instance");
//             assertNotSame(clonedSubplot, subplot2, "Each cloned subplot should be a different instance");
//             assertNotSame(clonedSubplot, subplot3, "Each cloned subplot should be a different instance");
//             assertEquals(clonedPlot, clonedSubplot.getParent(), "Subplot's parent should be cloned plot");
//         }
//         assertNull(clonedPlot.getDomainAxis(), "Cloned plot's domainAxis should be null");
//     }

    @Test
    @DisplayName("Cloning CombinedDomainXYPlot with subplots containing nulls")
    public void testTC17_cloneWithSubplotsContainingNulls() {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        plot.add(new XYPlot()); // Fixed the cast issue and added a non-null subplot to prevent NullPointerException
        ValueAxis domainAxis = new NumberAxis("Domain Axis");
        plot.setDomainAxis(domainAxis);

        // WHEN
        assertDoesNotThrow(() -> {
            CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone(); // Ensure proper casting
        }, "Cloning should not throw a NullPointerException when subplots are valid");
    }

    @Test
    @DisplayName("Cloning CombinedDomainXYPlot with domainAxis configured throws exception")
    public void testTC18_cloneWithDomainAxisConfiguredThrowsException() {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        ValueAxis faultyDomainAxis = new NumberAxis("Faulty Domain Axis") {
            @Override
            public void configure() {
                throw new RuntimeException("Failed to configure domainAxis");
            }
        };
        plot.setDomainAxis(faultyDomainAxis);

        // WHEN & THEN
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone();
        }, "Cloning should propagate RuntimeException thrown by domainAxis.configure()");
        assertEquals("Failed to configure domainAxis", exception.getMessage(), "Exception message should match");
    }
}