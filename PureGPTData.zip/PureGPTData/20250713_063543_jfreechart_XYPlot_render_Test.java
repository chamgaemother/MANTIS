import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class XYPlotTest {
    
    private XYPlot plot;
    private XYDataset dataset;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private CrosshairState crosshairState;
    
    @BeforeEach
    public void setUp() {
        plot = new XYPlot();
        dataset = mock(XYDataset.class);
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 400, 300);
        info = new PlotRenderingInfo(null);
        crosshairState = new CrosshairState();
    }
    
    @Test
    public void testRenderWithNullDataset() {
        plot.setDataset(0, null);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }
    
    @Test
    public void testRenderWithEmptyDataset() {
        when(dataset.getSeriesCount()).thenReturn(0);
        plot.setDataset(0, dataset);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }
    
    @Test
    public void testRenderWithValidDatasetAndRenderer() {
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(0.5);
        when(dataset.getYValue(0, 0)).thenReturn(0.5);
        
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(0, renderer);
        plot.setDataset(0, dataset);
        
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        
        assertTrue(result);
        verify(renderer, times(1)).drawItem(any(Graphics2D.class), any(), any(Rectangle2D.class),
                eq(info), eq(plot), any(), any(), eq(dataset), eq(0), eq(0), eq(crosshairState), anyInt());
    }
    
    @Test
    public void testRenderWithNoRenderer() {
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(0, dataset);
        
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
    }
    
    @Test
    public void testRenderWithNullInfoAndCrosshairState() {
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(0, dataset);
        
        boolean result = plot.render(g2, dataArea, 0, null, null);
        assertTrue(result);
    }
    
    @Test
    public void testRenderWithVisibleItemsOnly() {
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(0.5);
        when(dataset.getYValue(0, 0)).thenReturn(0.5);
        
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        when(renderer.getProcessVisibleItemsOnly()).thenReturn(true);
        plot.setRenderer(0, renderer);
        plot.setDataset(0, dataset);
        
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        
        assertTrue(result);
        verify(renderer, times(1)).drawItem(any(Graphics2D.class), any(), any(Rectangle2D.class),
                eq(info), eq(plot), any(), any(), eq(dataset), eq(0), eq(0), eq(crosshairState), anyInt());
    }
}