package com.fasterxml.jackson.dataformat.xml.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StaxUtil_sanitizeXmlTypeName_2_1_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName with name ending with 's' after stripping multiple '[]'")
    public void TC28_sanitizeXmlTypeName_EndingWithSAfterStrippingArrays() {
        // Given
        String input = "Statuses[][]";

        // When
        String result = StaxUtil.sanitizeXmlTypeName(input);

        // Then
        assertEquals("Statuseses", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with mixed disallowed characters and no array suffix")
    public void TC29_sanitizeXmlTypeName_MixedDisallowedCharactersNoArraySuffix() {
        // Given
        String input = "Mix$ed!Name";

        // When
        String result = StaxUtil.sanitizeXmlTypeName(input);

        // Then
        assertEquals("Mix.ed_Name", result);
    }
}