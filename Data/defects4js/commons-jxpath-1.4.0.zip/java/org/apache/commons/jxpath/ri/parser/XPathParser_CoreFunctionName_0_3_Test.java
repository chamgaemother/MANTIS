package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class XPathParser_CoreFunctionName_0_3_Test {

    private static final int FUNCTION_ENDS_WITH = 11;
    private static final int FUNCTION_CONTAINS = 14;
    private static final int FUNCTION_SUBSTRING_BEFORE = 15;
    private static final int FUNCTION_SUBSTRING_AFTER = 16;
    private static final int FUNCTION_SUBSTRING = 17;

//     @Test
//     @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_ENDS_WITH returns Compiler.FUNCTION_ENDS_WITH")
//     public void TC11() throws Exception {
//         XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(new SimpleCharStream()));
//         Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
//         jj_ntField.setAccessible(true);
//         Token jj_nt = new Token();
//         jj_ntField.set(xpathParser, jj_nt);
//         Field kindField = Token.class.getDeclaredField("kind");
//         kindField.setAccessible(true);
//         kindField.setInt(jj_nt, FUNCTION_ENDS_WITH);
//         int result = xpathParser.CoreFunctionName();
//         assertEquals(Compiler.FUNCTION_ENDS_WITH, result);
//     }

//     @Test
//     @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_CONTAINS returns Compiler.FUNCTION_CONTAINS")
//     public void TC12() throws Exception {
//         XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(new SimpleCharStream()));
//         Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
//         jj_ntField.setAccessible(true);
//         Token jj_nt = new Token();
//         jj_ntField.set(xpathParser, jj_nt);
//         Field kindField = Token.class.getDeclaredField("kind");
//         kindField.setAccessible(true);
//         kindField.setInt(jj_nt, FUNCTION_CONTAINS);
//         int result = xpathParser.CoreFunctionName();
//         assertEquals(Compiler.FUNCTION_CONTAINS, result);
//     }

//     @Test
//     @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_SUBSTRING_BEFORE returns Compiler.FUNCTION_SUBSTRING_BEFORE")
//     public void TC13() throws Exception {
//         XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(new SimpleCharStream()));
//         Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
//         jj_ntField.setAccessible(true);
//         Token jj_nt = new Token();
//         jj_ntField.set(xpathParser, jj_nt);
//         Field kindField = Token.class.getDeclaredField("kind");
//         kindField.setAccessible(true);
//         kindField.setInt(jj_nt, FUNCTION_SUBSTRING_BEFORE);
//         int result = xpathParser.CoreFunctionName();
//         assertEquals(Compiler.FUNCTION_SUBSTRING_BEFORE, result);
//     }

//     @Test
//     @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_SUBSTRING_AFTER returns Compiler.FUNCTION_SUBSTRING_AFTER")
//     public void TC14() throws Exception {
//         XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(new SimpleCharStream()));
//         Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
//         jj_ntField.setAccessible(true);
//         Token jj_nt = new Token();
//         jj_ntField.set(xpathParser, jj_nt);
//         Field kindField = Token.class.getDeclaredField("kind");
//         kindField.setAccessible(true);
//         kindField.setInt(jj_nt, FUNCTION_SUBSTRING_AFTER);
//         int result = xpathParser.CoreFunctionName();
//         assertEquals(Compiler.FUNCTION_SUBSTRING_AFTER, result);
//     }

//     @Test
//     @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_SUBSTRING returns Compiler.FUNCTION_SUBSTRING")
//     public void TC15() throws Exception {
//         XPathParser xpathParser = new XPathParser(new XPathParserTokenManager(new SimpleCharStream()));
//         Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
//         jj_ntField.setAccessible(true);
//         Token jj_nt = new Token();
//         jj_ntField.set(xpathParser, jj_nt);
//         Field kindField = Token.class.getDeclaredField("kind");
//         kindField.setAccessible(true);
//         kindField.setInt(jj_nt, FUNCTION_SUBSTRING);
//         int result = xpathParser.CoreFunctionName();
//         assertEquals(Compiler.FUNCTION_SUBSTRING, result);
//     }

}