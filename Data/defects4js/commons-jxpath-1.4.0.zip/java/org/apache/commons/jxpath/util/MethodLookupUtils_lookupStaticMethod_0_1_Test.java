package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.util.MethodLookupUtils;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class MethodLookupUtils_lookupStaticMethod_0_1_Test {

    // Inner class SomeClass with required static methods
    public static class SomeClass {
        // No methods named "someMethod" for TC01

        public static void staticMethod() {
            // Implementation for TC02
        }

        public static void staticMethod(Integer param) {
            // Implementation for TC03
        }

        public static void staticMethod(String param1, Integer param2) {
            // Implementation for TC04
        }

        public static void staticMethod(Object param1, String param2) {
            // Implementation for TC05
        }
    }

    @Test
    @DisplayName("Parameters are null, leading to zero iterations in parameter type setup")
    public void TC01_lookupStaticMethod_with_null_parameters() throws Exception {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "someMethod";
        Object[] parameters = null;

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNull(result, "Expected method to be null when parameters are null and method does not exist.");
    }

    @Test
    @DisplayName("Parameters array is empty, exact static method exists")
    public void TC02_lookupStaticMethod_with_empty_parameters_and_exact_static_method_exists() throws Exception {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethod";
        Object[] parameters = new Object[] {};

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected method to be found when exact static method exists with no parameters.");
        assertEquals("staticMethod", result.getName(), "Method name should match the requested name.");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }

    @Test
    @DisplayName("Parameters array has one non-null element, exact static method exists")
    public void TC03_lookupStaticMethod_with_one_non_null_parameter_and_exact_static_method_exists() throws Exception {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethod";
        Object[] parameters = new Object[] { Integer.valueOf(10) };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected method to be found when exact static method exists with one parameter.");
        assertEquals("staticMethod", result.getName(), "Method name should match the requested name.");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }

    @Test
    @DisplayName("Parameters array has multiple non-null elements, some methods require type conversion")
    public void TC04_lookupStaticMethod_with_multiple_parameters_requiring_type_conversion() throws Exception {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethod";
        Object[] parameters = new Object[] { "10", Integer.valueOf(20) };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected method to be found after type conversion with multiple parameters.");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }

    @Test
    @DisplayName("Parameters array contains null elements, exact matching without type conversion")
    public void TC05_lookupStaticMethod_with_parameters_containing_null_elements() throws Exception {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "staticMethod";
        Object[] parameters = new Object[] { null, "test" };

        // WHEN
        Method result = MethodLookupUtils.lookupStaticMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected method to be found when parameters contain null elements without type conversion.");
        assertTrue(Modifier.isStatic(result.getModifiers()), "Method should be static.");
    }
}