package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.analysis.interpolation.LoessInterpolator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LoessInterpolator_smooth_2_2_Test {

    @Test
    @DisplayName("Successfully handles varying weights, emphasizing certain data points affecting the smoothing outcome.")
    public void TC34_VaryingWeightsInfluence() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] yval = {2.0, 4.0, 6.0, 8.0, 10.0};
        double[] weights = {1.0, 10.0, 1.0, 10.0, 1.0};
        LoessInterpolator interpolator = new LoessInterpolator(0.8, 2, 1e-12);

        // WHEN
        double[] result = interpolator.smooth(xval, yval, weights);

        // THEN
        assertNotNull(result, "The result should not be null.");
        assertEquals(5, result.length, "The result array should have a length of 5.");

        // Verify that points with higher weights have greater influence on the smoothed result
        // Typically, higher weights should make the smoothed values closer to the original yval
        assertEquals(yval[1], result[1], 1e-6, "The smoothed value at index 1 should closely match the original yval due to higher weight.");
        assertEquals(yval[3], result[3], 1e-6, "The smoothed value at index 3 should closely match the original yval due to higher weight.");
        
        // Optionally, verify that points with lower weights have less influence, allowing more smoothing
        assertNotEquals(yval[0], result[0], "The smoothed value at index 0 should differ from the original yval due to lower weight.");
        assertNotEquals(yval[2], result[2], "The smoothed value at index 2 should differ from the original yval due to lower weight.");
        assertNotEquals(yval[4], result[4], "The smoothed value at index 4 should differ from the original yval due to lower weight.");
    }
}