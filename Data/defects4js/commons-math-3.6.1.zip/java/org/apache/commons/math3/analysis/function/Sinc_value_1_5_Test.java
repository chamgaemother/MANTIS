package org.apache.commons.math3.analysis.function;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Sinc_value_1_5_Test {

    @Test
    @DisplayName("value(1.0e-3) with normalized=true and |x| < SHORTCUT/Ï evaluates the Taylor series branch")
    void TC18() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        double x = 1.0e-3;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double scaledX = Math.PI * x;
        double scaledX2 = scaledX * scaledX;
        double expectedValue = ((scaledX2 - 20) * scaledX2 + 120) / 120;
        assertEquals(expectedValue, result, 1e-10, "TC18 failed: Taylor series approximation mismatch");
    }

    @Test
    @DisplayName("value(1.9098593e-3) with normalized=true and |x| equals SHORTCUT/Ï evaluates the Taylor series branch")
    void TC19() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        double x = 1.9098593e-3;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double scaledX = Math.PI * x;
        double scaledX2 = scaledX * scaledX;
        double expectedValue = ((scaledX2 - 20) * scaledX2 + 120) / 120;
        assertEquals(expectedValue, result, 1e-10, "TC19 failed: Taylor series approximation at boundary mismatch");
    }

    @Test
    @DisplayName("value(1.0) with normalized=true and |x| > SHORTCUT/Ï evaluates the sine definition expression branch")
    void TC20() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        double x = 1.0;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double expected = Math.sin(Math.PI) / Math.PI;
        assertEquals(expected, result, 1e-10, "TC20 failed: Sine definition expression mismatch");
    }

    @Test
    @DisplayName("value(NaN) with normalized=false handles NaN input gracefully")
    void TC21() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = Double.NaN;

        // WHEN
        double result = sinc.value(x);

        // THEN
        assertTrue(Double.isNaN(result), "TC21 failed: Expected result to be NaN");
    }

    @Test
    @DisplayName("value(Infinity) with normalized=false handles Infinity input gracefully")
    void TC22() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = Double.POSITIVE_INFINITY;

        // WHEN
        double result = sinc.value(x);

        // THEN
        assertTrue(Double.isNaN(result), "TC22 failed: Expected result to be NaN for Infinity input");
    }

}