package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.io.IOException;

public class TarArchiveOutputStream_putArchiveEntry_0_6_Test {

//     @Test
//     @DisplayName("putArchiveEntry with empty link name when entry is symbolic link")
//     void TC26() throws Exception {
        // Given
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         TarArchiveEntry entry = new TarArchiveEntry("dummy");
//         entry.setLink(true);
// 
        // Set link name to check edge case
//         entry.setLinkName("");
// 
        // When & Then
        // Expecting IllegalArgumentException due to empty link name
//         assertThrows(IllegalArgumentException.class, () -> outputStream.putArchiveEntry(entry));
//     }

    @Test
    @DisplayName("putArchiveEntry with addPaxHeadersForNonAsciiNames disabled and non-ASCII entry name")
    void TC27() throws Exception {
        // Given
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);

        // Disable addPaxHeadersForNonAsciiNames using reflection
        Field addPaxHeadersField = TarArchiveOutputStream.class.getDeclaredField("addPaxHeadersForNonAsciiNames");
        addPaxHeadersField.setAccessible(true);
        addPaxHeadersField.setBoolean(outputStream, false);

        // Create entry with non-ASCII name
        TarArchiveEntry entry = new TarArchiveEntry("ÃÂ£ÃÂÃÂ©");

        // When
        outputStream.putArchiveEntry(entry);
        outputStream.closeArchiveEntry();

        // Then
        // Verify that no PAX headers are added.
        String tarContent = baos.toString("UTF-8");
        assertFalse(tarContent.contains("PaxHeaders"));
    }

    @Test
    @DisplayName("putArchiveEntry with archive entry size not a multiple of RECORD_SIZE")
    void TC28() throws Exception {
        // Given
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
        TarArchiveEntry entry = new TarArchiveEntry("dummy");

        // Access RECORD_SIZE via reflection
        Field recordSizeField = TarArchiveOutputStream.class.getDeclaredField("RECORD_SIZE");
        recordSizeField.setAccessible(true);
        int RECORD_SIZE = recordSizeField.getInt(null);

        entry.setSize(RECORD_SIZE + 50);

        // When
        outputStream.putArchiveEntry(entry);
        outputStream.closeArchiveEntry();

        // Then
        // Verify that the record is written and size is handled correctly
        int expectedPadding = RECORD_SIZE - ((RECORD_SIZE + 50) % RECORD_SIZE);
        assertEquals(RECORD_SIZE + 50 + expectedPadding, baos.size());
    }

    @Test
    @DisplayName("putArchiveEntry with recordBuf null causing IOException")
    void TC29() throws Exception {
        // Given
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);

        // Set recordBuf to a zero-filled array to simulate null (cannot set to null in Java)
        Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
        recordBufField.setAccessible(true);
        recordBufField.set(outputStream, new byte[0]); // To simulate null behavior by making it invalid

        TarArchiveEntry entry = new TarArchiveEntry("dummy");

        // When & Then
        assertThrows(IOException.class, () -> outputStream.putArchiveEntry(entry));
    }

//     @Test
//     @DisplayName("putArchiveEntry with multiple symbolic links and PAX headers")
//     void TC30() throws Exception {
        // Given
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
// 
//         TarArchiveEntry entry1 = new TarArchiveEntry("dummy1");
//         entry1.setLink(true);
//         entry1.setLinkName("link1");
// 
//         TarArchiveEntry entry2 = new TarArchiveEntry("dummy2");
//         entry2.setLink(true);
//         entry2.setLinkName("link2");
// 
        // When
//         outputStream.putArchiveEntry(entry1);
//         outputStream.closeArchiveEntry();
//         outputStream.putArchiveEntry(entry2);
//         outputStream.closeArchiveEntry();
// 
        // Then
        // Verify that both symbolic links are written with correct PAX headers.
//         String tarContent = baos.toString("UTF-8");
//         assertTrue(tarContent.contains("link1"));
//         assertTrue(tarContent.contains("link2"));
//     }
}