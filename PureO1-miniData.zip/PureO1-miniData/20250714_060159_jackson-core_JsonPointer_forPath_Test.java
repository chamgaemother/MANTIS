import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonPointer;
import com.fasterxml.jackson.core.JsonStreamContext;

public class JsonPointerTest {

    @Test
    @DisplayName("forPath with null context should return EMPTY")
    public void testForPath_NullContext() {
        JsonPointer pointer = JsonPointer.forPath(null, true);
        assertSame(JsonPointer.empty(), pointer);
    }

    @Test
    @DisplayName("forPath with empty context and includeRoot false should return EMPTY")
    public void testForPath_EmptyContext_IncludeRootFalse() {
        JsonStreamContext context = mock(JsonStreamContext.class);
        when(context.hasPathSegment()).thenReturn(false);
        when(context.hasParent()).thenReturn(false);
        when(context.getParent()).thenReturn(null);
        when(context.inRoot()).thenReturn(false);
        when(context.hasCurrentIndex()).thenReturn(false);

        JsonPointer pointer = JsonPointer.forPath(context, false);
        assertSame(JsonPointer.empty(), pointer);
    }

    @Test
    @DisplayName("forPath with root context including index should return correct pointer")
    public void testForPath_RootContext_IncludeRootTrue() {
        JsonStreamContext rootContext = mock(JsonStreamContext.class);
        when(rootContext.hasPathSegment()).thenReturn(true);
        when(rootContext.inRoot()).thenReturn(true);
        when(rootContext.hasCurrentIndex()).thenReturn(true);
        when(rootContext.inObject()).thenReturn(false);
        when(rootContext.inArray()).thenReturn(true);
        when(rootContext.getCurrentIndex()).thenReturn(0);

        JsonPointer expected = JsonPointer.compile("/0");
        JsonPointer actual = JsonPointer.forPath(rootContext, true);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with object context having non-null property name")
    public void testForPath_ObjectContext_NonNullProperty() {
        JsonStreamContext childContext = mock(JsonStreamContext.class);
        JsonStreamContext parentContext = mock(JsonStreamContext.class);

        when(childContext.hasPathSegment()).thenReturn(true);
        when(childContext.inObject()).thenReturn(true);
        when(childContext.getCurrentName()).thenReturn("branch");
        when(childContext.getParent()).thenReturn(parentContext);

        when(parentContext.hasPathSegment()).thenReturn(false);
        when(parentContext.inRoot()).thenReturn(false);
        when(parentContext.hasCurrentIndex()).thenReturn(false);

        JsonPointer expected = JsonPointer.compile("/branch");
        JsonPointer actual = JsonPointer.forPath(childContext, false);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with object context having null property name")
    public void testForPath_ObjectContext_NullProperty() {
        JsonStreamContext childContext = mock(JsonStreamContext.class);
        JsonStreamContext parentContext = mock(JsonStreamContext.class);

        when(childContext.hasPathSegment()).thenReturn(true);
        when(childContext.inObject()).thenReturn(true);
        when(childContext.getCurrentName()).thenReturn(null);
        when(childContext.getParent()).thenReturn(parentContext);

        when(parentContext.hasPathSegment()).thenReturn(false);
        when(parentContext.inRoot()).thenReturn(false);
        when(parentContext.hasCurrentIndex()).thenReturn(false);

        JsonPointer expected = JsonPointer.compile("/"); // Empty property name
        JsonPointer actual = JsonPointer.forPath(childContext, false);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with array context having negative index")
    public void testForPath_ArrayContext_NegativeIndex() {
        JsonStreamContext arrayContext = mock(JsonStreamContext.class);
        when(arrayContext.hasPathSegment()).thenReturn(true);
        when(arrayContext.inObject()).thenReturn(false);
        when(arrayContext.inArray()).thenReturn(true);
        when(arrayContext.getCurrentIndex()).thenReturn(-1);
        when(arrayContext.getParent()).thenReturn(null);

        JsonPointer expected = JsonPointer.compile("/-1");
        JsonPointer actual = JsonPointer.forPath(arrayContext, false);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with multiple nested contexts")
    public void testForPath_MultipleNestedContexts() {
        JsonStreamContext leafContext = mock(JsonStreamContext.class);
        JsonStreamContext arrayContext = mock(JsonStreamContext.class);
        JsonStreamContext objectContext = mock(JsonStreamContext.class);
        JsonStreamContext rootContext = mock(JsonStreamContext.class);

        when(leafContext.hasPathSegment()).thenReturn(true);
        when(leafContext.inObject()).thenReturn(false);
        when(leafContext.inArray()).thenReturn(true);
        when(leafContext.getCurrentIndex()).thenReturn(2);
        when(leafContext.getParent()).thenReturn(arrayContext);

        when(arrayContext.hasPathSegment()).thenReturn(true);
        when(arrayContext.inObject()).thenReturn(true);
        when(arrayContext.getCurrentName()).thenReturn("items");
        when(arrayContext.getParent()).thenReturn(objectContext);

        when(objectContext.hasPathSegment()).thenReturn(true);
        when(objectContext.inObject()).thenReturn(true);
        when(objectContext.getCurrentName()).thenReturn("root");
        when(objectContext.getParent()).thenReturn(rootContext);

        when(rootContext.hasPathSegment()).thenReturn(false);
        when(rootContext.inRoot()).thenReturn(false);
        when(rootContext.hasCurrentIndex()).thenReturn(false);

        JsonPointer expected = JsonPointer.compile("/root/items/2");
        JsonPointer actual = JsonPointer.forPath(leafContext, false);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with includeRoot true and non-root context")
    public void testForPath_IncludeRootTrue_NonRootContext() {
        JsonStreamContext context = mock(JsonStreamContext.class);
        when(context.hasPathSegment()).thenReturn(true);
        when(context.inRoot()).thenReturn(false);
        when(context.hasCurrentIndex()).thenReturn(false);
        when(context.inObject()).thenReturn(true);
        when(context.getCurrentName()).thenReturn("data");
        when(context.getParent()).thenReturn(null);

        JsonPointer expected = JsonPointer.compile("/data");
        JsonPointer actual = JsonPointer.forPath(context, true);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with includeRoot false and root context with current index")
    public void testForPath_IncludeRootFalse_RootWithIndex() {
        JsonStreamContext rootContext = mock(JsonStreamContext.class);
        when(rootContext.hasPathSegment()).thenReturn(true);
        when(rootContext.inRoot()).thenReturn(true);
        when(rootContext.hasCurrentIndex()).thenReturn(true);
        when(rootContext.inObject()).thenReturn(false);
        when(rootContext.inArray()).thenReturn(true);
        when(rootContext.getCurrentIndex()).thenReturn(5);
        when(rootContext.getParent()).thenReturn(null);

        JsonPointer expected = JsonPointer.compile("/5");
        JsonPointer actual = JsonPointer.forPath(rootContext, false);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with empty property name in nested contexts")
    public void testForPath_EmptyPropertyName_NestedContexts() {
        JsonStreamContext childContext = mock(JsonStreamContext.class);
        JsonStreamContext parentContext = mock(JsonStreamContext.class);

        when(childContext.hasPathSegment()).thenReturn(true);
        when(childContext.inObject()).thenReturn(true);
        when(childContext.getCurrentName()).thenReturn("");
        when(childContext.getParent()).thenReturn(parentContext);

        when(parentContext.hasPathSegment()).thenReturn(true);
        when(parentContext.inObject()).thenReturn(true);
        when(parentContext.getCurrentName()).thenReturn("parent");
        when(parentContext.getParent()).thenReturn(null);

        JsonPointer expected = JsonPointer.compile("/parent/");
        JsonPointer actual = JsonPointer.forPath(childContext, false);
        assertEquals(expected, actual);
    }

    @ParameterizedTest
    @CsvSource({
        "/parent/child", 
        "/parent/child/0",
        "/parent/child/~0",
        "/parent/child/~1",
        "/parent/child/~0~1"
    })
    @DisplayName("forPath with various escaped and unescaped segments")
    public void testForPath_EscapedSegments(String pointerStr) throws Exception {
        JsonPointer pointer = JsonPointer.compile(pointerStr);
        JsonStreamContext leafContext = mock(JsonStreamContext.class);
        JsonStreamContext parentContext = mock(JsonStreamContext.class);
        when(leafContext.hasPathSegment()).thenReturn(true);
        when(leafContext.inObject()).thenReturn(true);
        if (pointerStr.contains("/0")) {
            when(leafContext.inArray()).thenReturn(true);
            when(leafContext.getCurrentIndex()).thenReturn(0);
        } else {
            when(leafContext.inArray()).thenReturn(false);
            when(leafContext.inObject()).thenReturn(true);
            if (pointerStr.endsWith("~0~1")) {
                when(leafContext.getCurrentName()).thenReturn("~0~1");
            } else if (pointerStr.endsWith("~0")) {
                when(leafContext.getCurrentName()).thenReturn("~0");
            } else if (pointerStr.endsWith("~1")) {
                when(leafContext.getCurrentName()).thenReturn("~1");
            } else {
                when(leafContext.getCurrentName()).thenReturn("child");
            }
        }
        when(leafContext.getParent()).thenReturn(parentContext);

        when(parentContext.hasPathSegment()).thenReturn(true);
        when(parentContext.inObject()).thenReturn(true);
        when(parentContext.getCurrentName()).thenReturn("parent");
        when(parentContext.getParent()).thenReturn(null);

        JsonPointer actual = JsonPointer.forPath(leafContext, false);
        assertEquals(pointer, actual);
    }

    @Test
    @DisplayName("forPath with multiple array indices in contexts")
    public void testForPath_MultipleArrayIndices() {
        JsonStreamContext index2 = mock(JsonStreamContext.class);
        JsonStreamContext index1 = mock(JsonStreamContext.class);
        JsonStreamContext root = mock(JsonStreamContext.class);

        when(index2.hasPathSegment()).thenReturn(true);
        when(index2.inObject()).thenReturn(false);
        when(index2.inArray()).thenReturn(true);
        when(index2.getCurrentIndex()).thenReturn(2);
        when(index2.getParent()).thenReturn(index1);

        when(index1.hasPathSegment()).thenReturn(true);
        when(index1.inObject()).thenReturn(false);
        when(index1.inArray()).thenReturn(true);
        when(index1.getCurrentIndex()).thenReturn(1);
        when(index1.getParent()).thenReturn(root);

        when(root.hasPathSegment()).thenReturn(false);
        when(root.inRoot()).thenReturn(false);
        when(root.hasCurrentIndex()).thenReturn(false);
        when(root.getParent()).thenReturn(null);

        JsonPointer expected = JsonPointer.compile("/1/2");
        JsonPointer actual = JsonPointer.forPath(index2, false);
        assertEquals(expected, actual);
    }

    @Test
    @DisplayName("forPath with includeRoot true and root not having index")
    public void testForPath_IncludeRootTrue_RootWithoutIndex() {
        JsonStreamContext rootContext = mock(JsonStreamContext.class);
        JsonStreamContext childContext = mock(JsonStreamContext.class);

        when(rootContext.hasPathSegment()).thenReturn(true);
        when(rootContext.inRoot()).thenReturn(true);
        when(rootContext.hasCurrentIndex()).thenReturn(false);
        when(rootContext.inObject()).thenReturn(true);
        when(rootContext.getCurrentName()).thenReturn("root");
        when(rootContext.getParent()).thenReturn(null);

        when(childContext.hasPathSegment()).thenReturn(false);
        when(childContext.inRoot()).thenReturn(false);
        when(childContext.hasCurrentIndex()).thenReturn(false);
        when(childContext.getParent()).thenReturn(rootContext);

        JsonPointer expected = JsonPointer.compile("/root");
        JsonPointer actual = JsonPointer.forPath(childContext, true);
        assertEquals(expected, actual);
    }
}