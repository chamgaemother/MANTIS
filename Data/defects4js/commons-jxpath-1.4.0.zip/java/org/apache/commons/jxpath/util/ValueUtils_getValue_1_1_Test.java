package org.apache.commons.jxpath.util;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// 
// import org.apache.commons.jxpath.Container;
// 
public class ValueUtils_getValue_1_1_Test {
// 
//     /**
//      * A simple implementation of the Container interface for testing purposes.
//      */
//     private static class SimpleContainer implements Container {
//         private final Object value;
// 
//         public SimpleContainer(Object value) {
//             this.value = value;
//         }
// 
//         @Override
//         public Object getValue() {
//             return this.value;
//         }
//     }
// 
//     @Test
//     @DisplayName("getValue returns the object itself when it is not a Container")
//     public void TC12() {
        // GIVEN
//         Object object = "testObject";
// 
        // WHEN
//         Object result = ValueUtils.getValue(object);
// 
        // THEN
//         assertEquals("testObject", result);
//     }
// 
//     @Test
//     @DisplayName("getValue returns the object itself when it is a primitive type and not a Container")
//     public void TC13() {
        // GIVEN
//         Object object = Integer.valueOf(100);
// 
        // WHEN
//         Object result = ValueUtils.getValue(object);
// 
        // THEN
//         assertEquals(Integer.valueOf(100), result);
//     }
// 
//     @Test
//     @DisplayName("getValue processes one Container layer and returns the inner non-Container object")
//     public void TC14() {
        // GIVEN
//         Container container = new SimpleContainer("innerObject");
// 
        // WHEN
//         Object result = ValueUtils.getValue(container);
// 
        // THEN
//         assertEquals("innerObject", result);
//     }
// 
//     @Test
//     @DisplayName("getValue processes one Container layer and returns the inner non-Container primitive object")
//     public void TC15() {
        // GIVEN
//         Container container = new SimpleContainer(Integer.valueOf(50));
// 
        // WHEN
//         Object result = ValueUtils.getValue(container);
// 
        // THEN
//         assertEquals(Integer.valueOf(50), result);
//     }
// 
//     @Test
//     @DisplayName("getValue processes multiple Container layers and returns the innermost non-Container object")
//     public void TC16() {
        // GIVEN
//         Container innerContainer = new SimpleContainer("innermostObject");
//         Container outerContainer = new SimpleContainer(innerContainer);
// 
        // WHEN
//         Object result = ValueUtils.getValue(outerContainer);
// 
        // THEN
//         assertEquals("innermostObject", result);
//     }
// }
}