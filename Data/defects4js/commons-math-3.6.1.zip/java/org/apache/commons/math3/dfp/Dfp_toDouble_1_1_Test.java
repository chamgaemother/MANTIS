// package org.apache.commons.math3.dfp;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // 
// // import java.lang.reflect.Field;
// // 
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import static org.junit.jupiter.api.Assertions.*;
// // 
// public class Dfp_toDouble_1_1_Test {
// // 
// //     /**
// //      * Helper method to set private fields of Dfp using reflection.
// //      *
// //      * @param dfp       The Dfp instance to modify.
// //      * @param mant      The mantissa array to set.
// //      * @param sign      The sign byte to set.
// //      * @param exp       The exponent to set.
// //      * @param nans      The nans byte to set.
// //      * @throws Exception If reflection fails.
// //      */
// //     private void setDfpFields(Dfp dfp, int[] mant, byte sign, int exp, byte nans) throws Exception {
// //         Field mantField = Dfp.class.getDeclaredField("mant");
// //         mantField.setAccessible(true);
// //         mantField.set(dfp, mant.clone());
// // 
// //         Field signField = Dfp.class.getDeclaredField("sign");
// //         signField.setAccessible(true);
// //         signField.setByte(dfp, sign);
// // 
// //         Field expField = Dfp.class.getDeclaredField("exp");
// //         expField.setAccessible(true);
// //         expField.setInt(dfp, exp);
// // 
// //         Field nansField = Dfp.class.getDeclaredField("nans");
// //         nansField.setAccessible(true);
// //         nansField.setByte(dfp, nans);
// //     }
// // 
// //     /**
// //      * Test TC14: toDouble correctly converts a subnormal positive Dfp number with exponent exactly -1074.
// //      * Expected result: 0.0
// //      */
// //     @Test
// //     @DisplayName("toDouble correctly converts a subnormal positive Dfp number with exponent exactly -1074")
// //     public void testToDouble_TC14() throws Exception {
//         // GIVEN
// //         DfpField field = new DfpField(5); // Example precision
// //         Dfp dfp = field.getZero();
// // 
//         // Set fields to represent a subnormal positive Dfp with exponent -1074
// //         int[] mantissa = new int[field.getRadixDigits()];
// //         byte sign = 1;
// //         int exponent = -1074;
// //         byte nans = Dfp.FINITE;
// // 
// //         setDfpFields(dfp, mantissa, sign, exponent, nans);
// // 
//         // WHEN
// //         double result = dfp.toDouble();
// // 
//         // THEN
// //         assertEquals(0.0, result, "Expected toDouble() to return 0.0 for subnormal positive Dfp with exponent -1074");
// //     }
// // 
// //     /**
// //      * Test TC15: toDouble correctly converts a subnormal negative Dfp number with exponent exactly -1074.
// //      * Expected result: -0.0
// //      */
// //     @Test
// //     @DisplayName("toDouble correctly converts a subnormal negative Dfp number with exponent exactly -1074")
// //     public void testToDouble_TC15() throws Exception {
//         // GIVEN
// //         DfpField field = new DfpField(5); // Example precision
// //         Dfp dfp = field.getZero();
// // 
//         // Set fields to represent a subnormal negative Dfp with exponent -1074
// //         int[] mantissa = new int[field.getRadixDigits()];
// //         byte sign = -1;
// //         int exponent = -1074;
// //         byte nans = Dfp.FINITE;
// // 
// //         setDfpFields(dfp, mantissa, sign, exponent, nans);
// // 
//         // WHEN
// //         double result = dfp.toDouble();
// // 
//         // THEN
// //         assertEquals(-0.0, result, "Expected toDouble() to return -0.0 for subnormal negative Dfp with exponent -1074");
// //     }
// // 
// //     /**
// //      * Test TC16: toDouble correctly converts a normal positive Dfp number with exponent exactly 1023.
// //      * Expected result: Double.MAX_VALUE
// //      */
// //     @Test
// //     @DisplayName("toDouble correctly converts a normal positive Dfp number with exponent exactly 1023")
// //     public void testToDouble_TC16() throws Exception {
//         // GIVEN
// //         DfpField field = new DfpField(5); // Example precision
// //         Dfp dfp = field.getOne();
// // 
//         // Set fields to represent a normal positive Dfp with exponent 1023
// //         int[] mantissa = new int[field.getRadixDigits()];
// //         mantissa[mantissa.length - 1] = 9999; // Max mantissa for demonstration
// //         byte sign = 1;
// //         int exponent = 1023;
// //         byte nans = Dfp.FINITE;
// // 
// //         setDfpFields(dfp, mantissa, sign, exponent, nans);
// // 
//         // WHEN
// //         double result = dfp.toDouble();
// // 
//         // THEN
// //         assertTrue(result > Double.MAX_VALUE / 2, "Expected toDouble() to approximate Double.MAX_VALUE for normal positive Dfp with exponent 1023");
// //     }
// // 
// //     /**
// //      * Test TC17: toDouble correctly converts a normal negative Dfp number with exponent exactly 1023.
// //      * Expected result: -Double.MAX_VALUE
// //      */
// //     @Test
// //     @DisplayName("toDouble correctly converts a normal negative Dfp number with exponent exactly 1023")
// //     public void testToDouble_TC17() throws Exception {
//         // GIVEN
// //         DfpField field = new DfpField(5); // Example precision
// //         Dfp dfp = field.getOne();
// // 
//         // Set fields to represent a normal negative Dfp with exponent 1023
// //         int[] mantissa = new int[field.getRadixDigits()];
// //         mantissa[mantissa.length - 1] = 9999; // Max mantissa for demonstration
// //         byte sign = -1;
// //         int exponent = 1023;
// //         byte nans = Dfp.FINITE;
// // 
// //         setDfpFields(dfp, mantissa, sign, exponent, nans);
// // 
//         // WHEN
// //         double result = dfp.toDouble();
// // 
//         // THEN
// //         assertTrue(result < -Double.MAX_VALUE / 2, "Expected toDouble() to approximate -Double.MAX_VALUE for normal negative Dfp with exponent 1023");
// //     }
// // 
// //     /**
// //      * Test TC18: toDouble handles mantissa rounding down to nearest double representation.
// //      * Expected result: correctly rounded down double.
// //      */
// //     @Test
// //     @DisplayName("toDouble handles mantissa rounding down to nearest double representation")
// //     public void testToDouble_TC18() throws Exception {
//         // GIVEN
// //         DfpField field = new DfpField(5); // Example precision
// //         Dfp dfp = field.getZero();
// // 
//         // Set fields to represent a Dfp requiring rounding down
// //         int[] mantissa = new int[field.getRadixDigits()];
// //         mantissa[mantissa.length - 2] = 4999; // Example value for rounding down
// //         byte sign = 1;
// //         int exponent = 0; // Adjust as needed for the specific case
// //         byte nans = Dfp.FINITE;
// // 
// //         setDfpFields(dfp, mantissa, sign, exponent, nans);
// // 
//         // WHEN
// //         double result = dfp.toDouble();
// // 
//         // THEN
// //         double expected = new Dfp(field, 4999).toDouble();  // Expected value after rounding down
// //         assertEquals(expected, result, "Expected toDouble() to return correctly rounded down double");
// //     }
// // }
// }