package org.jsoup.nodes;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.jsoup.parser.Tag;
import org.jsoup.nodes.FormElement;
import org.jsoup.nodes.Element;
import org.jsoup.Connection;

import java.util.List;

public class FormElement_formData_2_1_Test {

    @Test
    @DisplayName("formData processes textarea elements with non-empty value")
    public void TC21() {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element textarea = new Element(Tag.valueOf("textarea"), "")
                            .attr("name", "comments")
                            .text("This is a comment.");
        form.addElement(textarea);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(1, data.size());
        assertEquals("comments", data.get(0).key());
        assertEquals("This is a comment.", data.get(0).value());
    }

    @Test
    @DisplayName("formData processes textarea elements with empty value")
    public void TC22() {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element textarea = new Element(Tag.valueOf("textarea"), "")
                            .attr("name", "comments")
                            .text("");
        form.addElement(textarea);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(1, data.size());
        assertEquals("comments", data.get(0).key());
        assertEquals("", data.get(0).value());
    }

    @Test
    @DisplayName("formData processes input elements with type 'password' and non-empty value")
    public void TC23() {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element passwordInput = new Element(Tag.valueOf("input"), "")
                                .attr("type", "password")
                                .attr("name", "user_password")
                                .attr("value", "securePass123");
        form.addElement(passwordInput);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(1, data.size());
        assertEquals("user_password", data.get(0).key());
        assertEquals("securePass123", data.get(0).value());
    }

    @Test
    @DisplayName("formData processes input elements with type 'password' and empty value")
    public void TC24() {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element passwordInput = new Element(Tag.valueOf("input"), "")
                                .attr("type", "password")
                                .attr("name", "user_password")
                                .attr("value", "");
        form.addElement(passwordInput);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(1, data.size());
        assertEquals("user_password", data.get(0).key());
        assertEquals("on", data.get(0).value());
    }

    @Test
    @DisplayName("formData processes input elements without type attribute (defaults to 'text')")
    public void TC25() {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element textInput = new Element(Tag.valueOf("input"), "")
                             .attr("name", "username")
                             .attr("value", "john_doe");
        form.addElement(textInput);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(1, data.size());
        assertEquals("username", data.get(0).key());
        assertEquals("john_doe", data.get(0).value());
    }
}