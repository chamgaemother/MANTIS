package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Test class for LineUtils.clipLine method.
 */
public class LineUtils_clipLine_1_1_Test {

    @Test
    @DisplayName("clipLine(null, rect) throws NullPointerException")
    void TC21_clipLine_nullLine_throwsNullPointerException() {
        // Given
        Line2D line = null;
        Rectangle2D rect = new Rectangle2D.Double(0.0, 0.0, 5.0, 5.0);

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            LineUtils.clipLine(line, rect);
        }, "Expected clipLine to throw NullPointerException when line is null");
    }

    @Test
    @DisplayName("clipLine(line, null) throws NullPointerException")
    void TC22_clipLine_nullRectangle_throwsNullPointerException() {
        // Given
        Line2D line = new Line2D.Double(1.0, 1.0, 4.0, 4.0);
        Rectangle2D rect = null;

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            LineUtils.clipLine(line, rect);
        }, "Expected clipLine to throw NullPointerException when rectangle is null");
    }
}