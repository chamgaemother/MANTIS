package org.apache.commons.math3.util;

import org.apache.commons.math3.exception.MathArithmeticException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ArithmeticUtilsTest {

    @Test
    void testGcdBothZero() {
        assertEquals(0L, ArithmeticUtils.gcd(0L, 0L));
    }

    @Test
    void testGcdFirstZeroSecondPositive() {
        assertEquals(5L, ArithmeticUtils.gcd(0L, 5L));
    }

    @Test
    void testGcdFirstZeroSecondNegative() {
        assertEquals(5L, ArithmeticUtils.gcd(0L, -5L));
    }

    @Test
    void testGcdFirstZeroSecondMinValue() {
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(0L, Long.MIN_VALUE));
    }

    @Test
    void testGcdFirstPositiveSecondZero() {
        assertEquals(7L, ArithmeticUtils.gcd(7L, 0L));
    }

    @Test
    void testGcdFirstNegativeSecondZero() {
        assertEquals(7L, ArithmeticUtils.gcd(-7L, 0L));
    }

    @Test
    void testGcdFirstMinValueSecondZero() {
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(Long.MIN_VALUE, 0L));
    }

    @Test
    void testGcdBothMinValue() {
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(Long.MIN_VALUE, Long.MIN_VALUE));
    }

    @Test
    void testGcdFirstMinValueSecondMinValue() {
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(Long.MIN_VALUE, Long.MIN_VALUE));
    }

    @Test
    void testGcdFirstMinValueSecondPositive() {
        assertEquals(1L, ArithmeticUtils.gcd(Long.MIN_VALUE, 1L));
    }

    @Test
    void testGcdFirstMinValueSecondNegative() {
        assertEquals(1L, ArithmeticUtils.gcd(Long.MIN_VALUE, -1L));
    }

    @Test
    void testGcdFirstPositiveSecondMinValue() {
        assertEquals(1L, ArithmeticUtils.gcd(1L, Long.MIN_VALUE));
    }

    @Test
    void testGcdFirstNegativeSecondMinValue() {
        assertEquals(1L, ArithmeticUtils.gcd(-1L, Long.MIN_VALUE));
    }

    @Test
    void testGcdBothPositive() {
        assertEquals(6L, ArithmeticUtils.gcd(54L, 24L));
    }

    @Test
    void testGcdFirstPositiveSecondNegative() {
        assertEquals(6L, ArithmeticUtils.gcd(54L, -24L));
    }

    @Test
    void testGcdFirstNegativeSecondPositive() {
        assertEquals(6L, ArithmeticUtils.gcd(-54L, 24L));
    }

    @Test
    void testGcdBothNegative() {
        assertEquals(6L, ArithmeticUtils.gcd(-54L, -24L));
    }

    @Test
    void testGcdLargeNumbersNoOverflow() {
        assertEquals(1000000L, ArithmeticUtils.gcd(1000000L, 2000000L));
    }

    @Test
    void testGcdOddAndEven() {
        assertEquals(1L, ArithmeticUtils.gcd(17L, 12L));
    }

    @Test
    void testGcdBothEvenWithPowerOfTwo() {
        assertEquals(8L, ArithmeticUtils.gcd(56L, 24L));
    }

    @Test
    void testGcdResultingInShiftOverflow() {
        // This test aims to create k = 63 by providing numbers that are both divisible by 2^63
        // However, since 2^63 is Long.MIN_VALUE which cannot be represented as a positive number
        // It's challenging to create such a case. Alternatively, force k to reach high by using large powers of two
        // As a workaround, use Long.MAX_VALUE which is odd, so use Long.MIN_VALUE / 2 and Long.MIN_VALUE / 2
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(Long.MIN_VALUE / 2, Long.MIN_VALUE / 2));
    }

    @Test
    void testGcdPrimeNumbers() {
        assertEquals(1L, ArithmeticUtils.gcd(13L, 17L));
    }

    @Test
    void testGcdOneAndAnyNumber() {
        assertEquals(1L, ArithmeticUtils.gcd(1L, 999L));
        assertEquals(1L, ArithmeticUtils.gcd(-1L, 999L));
    }

    @Test
    void testGcdSameNumbers() {
        assertEquals(100L, ArithmeticUtils.gcd(100L, 100L));
        assertEquals(100L, ArithmeticUtils.gcd(-100L, -100L));
    }
}