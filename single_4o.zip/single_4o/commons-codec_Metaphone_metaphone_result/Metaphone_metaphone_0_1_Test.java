package org.apache.commons.codec.language;

import org.apache.commons.codec.language.Metaphone;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_1_Test {

    @Test
    @DisplayName("metaphone(null) returns an empty string for null input")
    void testMetaphoneNullInput() {
        Metaphone metaphone = new Metaphone();
        String input = null;
        String result = metaphone.metaphone(input);
        assertTrue(result.isEmpty(), "Expected an empty string for null input.");
    }

    @Test
    @DisplayName("metaphone('') returns an empty string for empty input")
    void testMetaphoneEmptyInput() {
        Metaphone metaphone = new Metaphone();
        String input = "";
        String result = metaphone.metaphone(input);
        assertTrue(result.isEmpty(), "Expected an empty string for empty input.");
    }

    @Test
    @DisplayName("metaphone('A') returns same character for single character input")
    void testMetaphoneSingleCharacter() {
        Metaphone metaphone = new Metaphone();
        String input = "A";
        String result = metaphone.metaphone(input);
        assertEquals("A", result, "Expected 'A' for single character input 'A'.");
    }

    @Test
    @DisplayName("metaphone('Knuth') skips initial 'K' and returns 'N0'")
    void testMetaphoneInitialK() {
        Metaphone metaphone = new Metaphone();
        String input = "Knuth";
        String result = metaphone.metaphone(input);
        assertEquals("N0", result, "Expected 'N0' for input 'Knuth'.");
    }

    @Test
    @DisplayName("metaphone('Xerox') changes initial 'X' to 'S' and returns 'SR'")
    void testMetaphoneInitialX() {
        Metaphone metaphone = new Metaphone();
        String input = "Xerox";
        String result = metaphone.metaphone(input);
        assertEquals("SR", result, "Expected 'SR' for input 'Xerox'.");
    }
}