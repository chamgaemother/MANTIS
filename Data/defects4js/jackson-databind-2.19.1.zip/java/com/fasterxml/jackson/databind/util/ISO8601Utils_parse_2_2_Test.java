package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.text.ParseException;
import java.text.ParsePosition;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class ISO8601Utils_parse_2_2_Test {

    @Test
    @DisplayName("Parse throws ParseException when milliseconds have more than three digits")
    void TC58_parseExcessiveMillisecondDigits() {
        String date = "2023-10-05T14:30:00.1234Z";
        ParsePosition pos = new ParsePosition(0);

        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("Parse throws ParseException when day has non-digit characters")
    void TC59_parseNonDigitInDay() {
        String date = "2023-10-0A*T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);

        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("Parse throws ParseException when year has less than four digits")
    void TC60_parseIncompleteYearDigits() {
        String date = "202-10-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);

        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }
}