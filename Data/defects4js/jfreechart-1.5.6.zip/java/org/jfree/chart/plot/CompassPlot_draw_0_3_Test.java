package org.jfree.chart.plot;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.lang.reflect.Field;

import org.jfree.data.general.ValueDataset;
import org.jfree.chart.needle.MeterNeedle;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * JUnit 5 test class for testing the draw method in CompassPlot.
 */
public class CompassPlot_draw_0_3_Test {

    @Test
    @DisplayName("draw method with dataset value resulting in exact revolution distance")
    public void TC11_draw_with_exact_revolution_distance() throws Exception {
        // GIVEN
        CompassPlot plot = new CompassPlot();
        double revolutionDistance = 360.0;
        plot.setRevolutionDistance(revolutionDistance);

        ValueDataset dataset1 = Mockito.mock(ValueDataset.class);
        Mockito.when(dataset1.getValue()).thenReturn(revolutionDistance);
        plot.addDataset(dataset1);

        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = Mockito.mock(Rectangle2D.class);
        Point2D centerPoint = Mockito.mock(Point2D.class);
        PlotState plotState = Mockito.mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = Mockito.mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedles = (MeterNeedle[]) seriesNeedleField.get(plot);
        Mockito.verify(seriesNeedles[0], Mockito.times(1)).draw(Mockito.eq(g2), Mockito.any(Rectangle2D.class), Mockito.eq(0.0));
    }

    @Test
    @DisplayName("draw method with drawBorder=true and calling drawOutline")
    public void TC12_draw_with_drawBorder_true() throws Exception {
        // GIVEN
        CompassPlot plot = Mockito.spy(new CompassPlot());
        plot.setDrawBorder(true);

        ValueDataset dataset1 = Mockito.mock(ValueDataset.class);
        Mockito.when(dataset1.getValue()).thenReturn(90.0);
        plot.addDataset(dataset1);

        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = Mockito.mock(Rectangle2D.class);
        Point2D centerPoint = Mockito.mock(Point2D.class);
        PlotState plotState = Mockito.mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = Mockito.mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        Mockito.verify(plot, Mockito.times(1)).drawOutline(Mockito.eq(g2), Mockito.eq(area));
    }

    @Test
    @DisplayName("draw method with drawBorder=false and skipping drawOutline")
    public void TC13_draw_with_drawBorder_false() throws Exception {
        // GIVEN
        CompassPlot plot = Mockito.spy(new CompassPlot());
        plot.setDrawBorder(false);

        ValueDataset dataset1 = Mockito.mock(ValueDataset.class);
        Mockito.when(dataset1.getValue()).thenReturn(180.0);
        plot.addDataset(dataset1);

        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = Mockito.mock(Rectangle2D.class);
        Point2D centerPoint = Mockito.mock(Point2D.class);
        PlotState plotState = Mockito.mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = Mockito.mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        Mockito.verify(plot, Mockito.never()).drawOutline(Mockito.any(Graphics2D.class), Mockito.any(Rectangle2D.class));
    }

    @Test
    @DisplayName("draw method with localizationResources missing direction strings")
    public void TC14_draw_with_missing_direction_strings() throws Exception {
        // GIVEN
        CompassPlot plot = new CompassPlot();
        plot.localizationResources = new ResourceBundleMissingDirections();

        ValueDataset dataset1 = Mockito.mock(ValueDataset.class);
        Mockito.when(dataset1.getValue()).thenReturn(45.0);
        plot.addDataset(dataset1);

        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = Mockito.mock(Rectangle2D.class);
        Point2D centerPoint = Mockito.mock(Point2D.class);
        PlotState plotState = Mockito.mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = Mockito.mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        Mockito.verify(g2).drawString("", Mockito.anyInt(), Mockito.anyInt());
    }

    @Test
    @DisplayName("draw method with exception thrown in drawBackground")
    public void TC15_draw_with_exception_in_drawBackground() {
        // GIVEN
        CompassPlot plot = Mockito.spy(new CompassPlot());
        plot.setDrawBorder(true);

        Mockito.doThrow(new RuntimeException("drawBackground exception")).when(plot).drawBackground(Mockito.any(Graphics2D.class), Mockito.any(Rectangle2D.class));

        ValueDataset dataset1 = Mockito.mock(ValueDataset.class);
        Mockito.when(dataset1.getValue()).thenReturn(270.0);
        plot.addDataset(dataset1);

        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = Mockito.mock(Rectangle2D.class);
        Point2D centerPoint = Mockito.mock(Point2D.class);
        PlotState plotState = Mockito.mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = Mockito.mock(PlotRenderingInfo.class);

        // WHEN & THEN
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);
        });
        assertEquals("drawBackground exception", exception.getMessage());
    }

    /**
     * Custom ResourceBundle that is missing 'N', 'S', 'E', 'W' keys.
     */
    private static class ResourceBundleMissingDirections extends java.util.ResourceBundle {
        @Override
        protected Object handleGetObject(String key) {
            return ""; // Missing keys
        }

        @Override
        public java.util.Enumeration<String> getKeys() {
            return java.util.Collections.enumeration(java.util.Arrays.asList("N", "S", "E", "W"));
        }
    }
}
