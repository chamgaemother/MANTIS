package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class ClassUtils_isAssignable_1_4_Test {

    @Test
    @DisplayName("cls is primitive (double) and toClass is non-primitive (Object) with autoboxing=false")
    void TC21_isPrimitive_double_toNonPrimitive_Object_autoboxingFalse() {
        // GIVEN
        Class<?> cls = double.class;
        Class<?> toClass = Object.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is wrapper (Comparable) and toClass is primitive (int) with autoboxing=true")
    void TC22_wrapper_Comparable_toPrimitive_int_autoboxingTrue() {
        // GIVEN
        Class<?> cls = Comparable.class;
        Class<?> toClass = int.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is wrapper (Double) and toClass is primitive (double) with autoboxing=true")
    void TC23_wrapper_Double_toPrimitive_double_autoboxingTrue() {
        // GIVEN
        Class<?> cls = Double.class;
        Class<?> toClass = double.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is non-primitive (String) and toClass is superclass (Object) with autoboxing=false")
    void TC24_nonPrimitive_String_toSuperclass_Object_autoboxingFalse() {
        // GIVEN
        Class<?> cls = String.class;
        Class<?> toClass = Object.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is non-primitive (StringBuilder) and toClass is not assignable (List) with autoboxing=false")
    void TC25_nonPrimitive_StringBuilder_toNonAssignable_List_autoboxingFalse() {
        // GIVEN
        Class<?> cls = StringBuilder.class;
        Class<?> toClass = List.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

}