package org.jfree.chart.axis;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.*;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.data.Range;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;

public class LogarithmicAxis_autoAdjustRange_0_1_Test {

    @Test
    @DisplayName("autoAdjustRange returns immediately when plot is null")
    public void TC01_autoAdjustRange_with_null_plot() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");

        // Using reflection to set the private plot field to null
        Method setPlotMethod = LogarithmicAxis.class.getDeclaredMethod("setPlot", Plot.class);
        setPlotMethod.setAccessible(true);
        setPlotMethod.invoke(axis, (Plot) null);

        // Using reflection to get the initial range
        Method getRangeMethod = LogarithmicAxis.class.getDeclaredMethod("getRange");
        getRangeMethod.setAccessible(true);
        Range initialRange = (Range) getRangeMethod.invoke(axis);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range finalRange = (Range) getRangeMethod.invoke(axis);
        Assertions.assertEquals(initialRange, finalRange, "Range should remain unchanged when plot is null");
    }

    @Test
    @DisplayName("autoAdjustRange returns immediately when plot is not a ValueAxisPlot")
    public void TC02_autoAdjustRange_with_non_ValueAxisPlot() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        Plot mockPlot = mock(Plot.class);

        // Using reflection to set the private plot field
        Method setPlotMethod = LogarithmicAxis.class.getDeclaredMethod("setPlot", Plot.class);
        setPlotMethod.setAccessible(true);
        setPlotMethod.invoke(axis, mockPlot);

        // Using reflection to get the initial range
        Method getRangeMethod = LogarithmicAxis.class.getDeclaredMethod("getRange");
        getRangeMethod.setAccessible(true);
        Range initialRange = (Range) getRangeMethod.invoke(axis);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Range finalRange = (Range) getRangeMethod.invoke(axis);
        Assertions.assertEquals(initialRange, finalRange, "Range should remain unchanged when plot is not a ValueAxisPlot");
    }

    @Test
    @DisplayName("autoAdjustRange processes when data range is null, retrieving default auto range")
    public void TC03_autoAdjustRange_with_null_data_range() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);

        // Using reflection to set the private plot field
        Method setPlotMethod = LogarithmicAxis.class.getDeclaredMethod("setPlot", Plot.class);
        setPlotMethod.setAccessible(true);
        setPlotMethod.invoke(axis, mockPlot);

        when(mockPlot.getDataRange(axis)).thenReturn(null);

        Method getDefaultAutoRangeMethod = LogarithmicAxis.class.getDeclaredMethod("getDefaultAutoRange");
        getDefaultAutoRangeMethod.setAccessible(true);
        Range defaultRange = (Range) getDefaultAutoRangeMethod.invoke(axis);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Method getRangeMethod = LogarithmicAxis.class.getDeclaredMethod("getRange");
        getRangeMethod.setAccessible(true);
        Range finalRange = (Range) getRangeMethod.invoke(axis);
        Assertions.assertEquals(defaultRange, finalRange, "Range should be set based on default auto range and minimum size is enforced");
    }

    @Test
    @DisplayName("autoAdjustRange throws RuntimeException when strictValuesFlag is true, allowNegativesFlag is false, and lower bound <= 0")
    public void TC04_autoAdjustRange_throws_RuntimeException_for_non_positive_lower_bound_with_strict_values() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);

        // Using reflection to set flags and plot
        Method setStrictValuesFlagMethod = LogarithmicAxis.class.getDeclaredMethod("setStrictValuesFlag", boolean.class);
        setStrictValuesFlagMethod.setAccessible(true);
        setStrictValuesFlagMethod.invoke(axis, true);

        Method setAllowNegativesFlagMethod = LogarithmicAxis.class.getDeclaredMethod("setAllowNegativesFlag", boolean.class);
        setAllowNegativesFlagMethod.setAccessible(true);
        setAllowNegativesFlagMethod.invoke(axis, false);

        Method setPlotMethod = LogarithmicAxis.class.getDeclaredMethod("setPlot", Plot.class);
        setPlotMethod.setAccessible(true);
        setPlotMethod.invoke(axis, mockPlot);

        Range mockRange = new Range(-5.0, 15.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN & THEN
        RuntimeException exception = Assertions.assertThrows(RuntimeException.class, () -> {
            axis.autoAdjustRange();
        });

        Assertions.assertEquals("Values less than or equal to zero not allowed with logarithmic axis", exception.getMessage());
    }

    @Test
    @DisplayName("autoAdjustRange correctly adjusts lower bound with positive lower margin")
    public void TC05_autoAdjustRange_adjusts_lower_bound_with_positive_margin() throws Exception {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);

        // Using reflection to set lower margin and plot
        Method setLowerMarginMethod = LogarithmicAxis.class.getDeclaredMethod("setLowerMargin", double.class);
        setLowerMarginMethod.setAccessible(true);
        setLowerMarginMethod.invoke(axis, 0.1);

        Method setPlotMethod = LogarithmicAxis.class.getDeclaredMethod("setPlot", Plot.class);
        setPlotMethod.setAccessible(true);
        setPlotMethod.invoke(axis, mockPlot);

        Range mockRange = new Range(2.0, 20.0);
        when(mockPlot.getDataRange(axis)).thenReturn(mockRange);

        // WHEN
        axis.autoAdjustRange();

        // THEN
        Method getRangeMethod = LogarithmicAxis.class.getDeclaredMethod("getRange");
        getRangeMethod.setAccessible(true);
        Range finalRange = (Range) getRangeMethod.invoke(axis);

        // Calculate expected lower bound decrease
        double log10 = Math.log(mockRange.getLowerBound()) / LogarithmicAxis.LOG10_VALUE;
        double logAbs = Math.abs(log10) < 1.0 ? 1.0 : Math.abs(log10);
        double expectedLower = Math.pow(10, (log10 - (logAbs * 0.1)));

        Assertions.assertEquals(expectedLower, finalRange.getLowerBound(), 1e-6, "Lower bound should be decreased correctly by margin");
    }

}