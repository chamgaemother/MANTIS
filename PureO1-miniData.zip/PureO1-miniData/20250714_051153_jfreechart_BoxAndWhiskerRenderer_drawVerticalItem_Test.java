import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Collections;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BoxAndWhiskerCategoryDataset;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

class BoxAndWhiskerRendererTest {

    private BoxAndWhiskerRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private BoxAndWhiskerCategoryDataset dataset;

    @BeforeEach
    void setUp() {
        renderer = new BoxAndWhiskerRenderer();
        g2 = mock(Graphics2D.class);
        state = new CategoryItemRendererState();
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(BoxAndWhiskerCategoryDataset.class);
    }

    @Test
    void drawVerticalItem_ItemNotVisible_NoAction() {
        renderer.setItemVisible(false);
        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
        // Verify no interactions since item is not visible
        verifyNoInteractions(g2);
    }

    @Test
    void drawVerticalItem_InvalidDataset_ThrowsException() {
        CategoryItemRendererState validState = new CategoryItemRendererState();
        Rectangle2D validDataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot validPlot = mock(CategoryPlot.class);
        CategoryAxis validDomainAxis = mock(CategoryAxis.class);
        ValueAxis validRangeAxis = mock(ValueAxis.class);
        CategoryDataset invalidDataset = mock(CategoryDataset.class);

        try {
            renderer.drawVerticalItem(g2, validState, validDataArea, validPlot, validDomainAxis, validRangeAxis, invalidDataset, 0, 0);
        } catch (IllegalArgumentException e) {
            // Expected exception
            return;
        }
        // Fail if exception not thrown
        assert false;
    }

    @Test
    void drawVerticalItem_SeriesCountOne_FillBoxTrue_NoOutliers() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
        when(dataset.getOutliers(0, 0)).thenReturn(null);

        renderer.setFillBox(true);
        renderer.setMeanVisible(true);
        renderer.setMedianVisible(true);
        renderer.setUseOutlinePaintForWhiskers(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).setStroke(any());
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    void drawVerticalItem_SeriesCountMultiple_FillBoxFalse_WithOutliers() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getRowCount()).thenReturn(3);
        when(dataset.getQ1Value(1, 1)).thenReturn(12.0);
        when(dataset.getQ3Value(1, 1)).thenReturn(22.0);
        when(dataset.getMaxRegularValue(1, 1)).thenReturn(28.0);
        when(dataset.getMinRegularValue(1, 1)).thenReturn(8.0);
        when(dataset.getMeanValue(1, 1)).thenReturn(16.0);
        when(dataset.getMedianValue(1, 1)).thenReturn(16.0);
        when(dataset.getOutliers(1, 1)).thenReturn(Arrays.asList(30.0, 7.0));

        renderer.setFillBox(false);
        renderer.setMeanVisible(true);
        renderer.setMedianVisible(true);
        renderer.setUseOutlinePaintForWhiskers(false);
        renderer.setMaxOutlierVisible(true);
        renderer.setMinOutlierVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);

        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).setStroke(any());
        verify(g2, never()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    void drawVerticalItem_FillBoxFalse_NoFillBoxPath() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(null);

        renderer.setFillBox(false);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(false);
        renderer.setUseOutlinePaintForWhiskers(false);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        verify(g2, never()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    void drawVerticalItem_MeanVisible_MeanWithinDataArea() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
        when(dataset.getOutliers(0, 0)).thenReturn(null);

        renderer.setFillBox(true);
        renderer.setMeanVisible(true);
        renderer.setMedianVisible(false);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        verify(g2, atLeastOnce()).fill(ArgumentMatchers.any());
        verify(g2, atLeastOnce()).draw(ArgumentMatchers.any());
    }

    @Test
    void drawVerticalItem_MeanVisible_MeanOutsideDataArea() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(-10.0); // Outside
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
        when(dataset.getOutliers(0, 0)).thenReturn(null);

        renderer.setFillBox(true);
        renderer.setMeanVisible(true);
        renderer.setMedianVisible(false);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Since mean is outside, ellipse should not be drawn
        verify(g2, atLeastOnce()).fill(ArgumentMatchers.any());
        // No additional draw calls for mean
    }

    @Test
    void drawVerticalItem_MedianVisible_MedianNull_NoMedianDraw() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(null);

        renderer.setFillBox(true);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // No median should be drawn
        verify(g2, atLeastOnce()).fill(ArgumentMatchers.any());
        verify(g2, never()).draw(ArgumentMatchers.argThat(shape -> shape instanceof Line2D.Double));
    }

    @Test
    void drawVerticalItem_MedianVisible_DrawMedian() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
        when(dataset.getOutliers(0, 0)).thenReturn(null);

        renderer.setFillBox(true);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Median line should be drawn
        verify(g2, atLeastOnce()).draw(ArgumentMatchers.any());
    }

    @Test
    void drawVerticalItem_WithOutliers_DrawOutliers() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(30.0, dataArea, RectangleEdge.LEFT)).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(7.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(30.0, 7.0));
        when(dataset.getMinOutlier(0, 0)).thenReturn(7.0);
        when(dataset.getMaxOutlier(0, 0)).thenReturn(30.0);

        renderer.setFillBox(true);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(false);
        renderer.setMaxOutlierVisible(true);
        renderer.setMinOutlierVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        verify(g2, atLeastOnce()).draw(ArgumentMatchers.any());
    }

    @Test
    void drawVerticalItem_MaxOutlierVisible_DrawHighFarOut() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(35.0, dataArea, RectangleEdge.LEFT)).thenReturn(90.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(10.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(35.0));
        when(dataset.getMinOutlier(0, 0)).thenReturn(5.0);
        when(dataset.getMaxOutlier(0, 0)).thenReturn(35.0);

        renderer.setFillBox(true);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(false);
        renderer.setMaxOutlierVisible(true);
        renderer.setMinOutlierVisible(false);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Verify that high far out indicator is drawn
        verify(g2, atLeastOnce()).draw(ArgumentMatchers.any());
    }

    @Test
    void drawVerticalItem_MinOutlierVisible_DrawLowFarOut() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(5.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(0.0));
        when(dataset.getMinOutlier(0, 0)).thenReturn(0.0);
        when(dataset.getMaxOutlier(0, 0)).thenReturn(25.0);

        renderer.setFillBox(true);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(false);
        renderer.setMaxOutlierVisible(false);
        renderer.setMinOutlierVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Verify that low far out indicator is drawn
        verify(g2, atLeastOnce()).draw(ArgumentMatchers.any());
    }

    @Test
    void drawVerticalItem_OutliersNull_NoOutlierDraw() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(null);

        renderer.setFillBox(true);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(false);
        renderer.setMaxOutlierVisible(true);
        renderer.setMinOutlierVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // No outliers to draw
        verify(g2, atLeastOnce()).draw(ArgumentMatchers.any());
    }

    @Test
    void drawVerticalItem_UseOutlinePaintForWhiskers_True() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenReturn(50.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(null);
        when(dataset.getForePaint(anyInt(), anyInt())).thenReturn(java.awt.Color.RED);
        when(dataset.getOutlinePaint(anyInt(), anyInt())).thenReturn(java.awt.Color.BLUE);

        renderer.setFillBox(true);
        renderer.setUseOutlinePaintForWhiskers(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Verify that outline paint is used for whiskers
        verify(g2, atLeastOnce()).setPaint(java.awt.Color.BLUE);
    }

    @Test
    void drawVerticalItem_UseOutlinePaintForWhiskers_False() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenReturn(50.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(null);
        when(dataset.getSeriesPaint(anyInt())).thenReturn(java.awt.Color.GREEN);
        when(dataset.getOutlinePaint(anyInt(), anyInt())).thenReturn(java.awt.Color.BLUE);

        renderer.setFillBox(true);
        renderer.setUseOutlinePaintForWhiskers(false);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Verify that series paint is used for whiskers
        verify(g2, atLeastOnce()).setPaint(java.awt.Color.GREEN);
    }

    @Test
    void drawVerticalItem_OutlierListMultiple_DrawMultipleEllipses() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(35.0, dataArea, RectangleEdge.LEFT)).thenReturn(90.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(10.0);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(20.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(25.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMedianValue(0, 0)).thenReturn(null);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(27.0, 28.0, 29.0));
        when(dataset.getMinOutlier(0, 0)).thenReturn(5.0);
        when(dataset.getMaxOutlier(0, 0)).thenReturn(30.0);

        renderer.setFillBox(true);
        renderer.setMeanVisible(false);
        renderer.setMedianVisible(false);
        renderer.setMaxOutlierVisible(true);
        renderer.setMinOutlierVisible(true);

        renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Verify that multiple ellipses are drawn for multiple outliers
        verify(g2, atLeast(2)).draw(ArgumentMatchers.any());
    }

    @Test
    void drawVerticalItem_AllConditionsCovered() {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMargin()).thenReturn(0.2);
        when(domainAxis.getLowerMargin()).thenReturn(0.1);
        when(domainAxis.getUpperMargin()).thenReturn(0.1);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getRowCount()).thenReturn(2);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenAnswer(invocation -> {
                double value = invocation.getArgument(0);
                return value * 2;
            });
        when(dataset.getQ1Value(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getQ3Value(anyInt(), anyInt())).thenReturn(20.0);
        when(dataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(25.0);
        when(dataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(15.0);
        when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(15.0);
        when(dataset.getOutliers(anyInt(), anyInt())).thenReturn(Arrays.asList(30.0, 2.0));
        when(dataset.getMinOutlier(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getMaxOutlier(anyInt(), anyInt())).thenReturn(30.0);
        when(dataset.getRows()).thenReturn(Collections.emptyList());

        renderer.setFillBox(true);
        renderer.setItemMargin(0.2);
        renderer.setMaximumBarWidth(0.5);
        renderer.setMeanVisible(true);
        renderer.setMedianVisible(true);
        renderer.setMaxOutlierVisible(true);
        renderer.setMinOutlierVisible(true);
        renderer.setUseOutlinePaintForWhiskers(true);
        renderer.setWhiskerWidth(0.8);

        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 3; col++) {
                renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, col);
            }
        }

        verify(g2, atLeast(1)).setPaint(any());
        verify(g2, atLeast(1)).setStroke(any());
        verify(g2, atLeast(2)).fill(any());
        verify(g2, atLeast(2)).draw(any());
    }

}