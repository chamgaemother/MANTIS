package org.apache.commons.math3.ode.sampling;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class StepNormalizer_handleStep_2_1_Test {

    @Test
    @DisplayName("handleStep with bounds=LAST, mode=INCREMENT, and forward=true covering path B0âB3âB5âB6âB9âB10âB12âB13âB16âB17âB19âB20âB22")
    public void TC17() throws Exception {
        // Arrange
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.LAST);
        StepInterpolator interpolator = mock(StepInterpolator.class);

        when(interpolator.getPreviousTime()).thenReturn(2.5);
        when(interpolator.getCurrentTime()).thenReturn(3.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.5, 3.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.25, 0.3});
        when(interpolator.isForward()).thenReturn(true);

        // Act
        normalizer.handleStep(interpolator, true);

        // Assert
        verify(handler).handleStep(eq(3.0), any(double[].class), any(double[].class), eq(true));
    }

    @Test
    @DisplayName("handleStep with bounds=LAST, mode=INCREMENT, and forward=false covering path B0âB1âB2âB3âB4âB6âB9âB10âB12âB13âB16âB17âB19âB20âB22")
    public void TC18() throws Exception {
        // Arrange
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.LAST);
        StepInterpolator interpolator = mock(StepInterpolator.class);

        when(interpolator.getPreviousTime()).thenReturn(3.0);
        when(interpolator.getCurrentTime()).thenReturn(2.5);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.5, 3.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.25, 0.3});
        when(interpolator.isForward()).thenReturn(false);

        // Act
        normalizer.handleStep(interpolator, true);

        // Assert
        verify(handler).handleStep(eq(2.5), any(double[].class), any(double[].class), eq(true));
    }

    @Test
    @DisplayName("handleStep with bounds=BOTH, mode=MULTIPLES, and forward=true covering path B0âB3âB5âB6âB9âB10âB12âB13âB16âB17âB18âB20âB22")
    public void TC19() throws Exception {
        // Arrange
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.BOTH);
        StepInterpolator interpolator = mock(StepInterpolator.class);

        when(interpolator.getPreviousTime()).thenReturn(1.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        when(interpolator.isForward()).thenReturn(true);

        // Act
        normalizer.handleStep(interpolator, true);

        // Assert
        verify(handler).handleStep(eq(2.0), any(double[].class), any(double[].class), eq(true));
    }

    @Test
    @DisplayName("handleStep with bounds=BOTH, mode=MULTIPLES, and forward=false covering path B0âB1âB2âB3âB4âB6âB9âB10âB12âB13âB16âB17âB18âB20âB22")
    public void TC20() throws Exception {
        // Arrange
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.BOTH);
        StepInterpolator interpolator = mock(StepInterpolator.class);

        when(interpolator.getPreviousTime()).thenReturn(2.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.0, 1.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.2, 0.1});
        when(interpolator.isForward()).thenReturn(false);

        // Act
        normalizer.handleStep(interpolator, true);

        // Assert
        verify(handler).handleStep(eq(1.0), any(double[].class), any(double[].class), eq(true));
    }

    @Test
    @DisplayName("handleStep with bounds=LAST, mode=MULTIPLES, and forward=true covering path B0âB3âB5âB6âB9âB10âB12âB13âB16âB17âB18âB20âB22")
    public void TC21() throws Exception {
        // Arrange
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.LAST);
        StepInterpolator interpolator = mock(StepInterpolator.class);

        when(interpolator.getPreviousTime()).thenReturn(1.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1, 0.2});
        when(interpolator.isForward()).thenReturn(true);

        // Act
        normalizer.handleStep(interpolator, true);

        // Assert
        verify(handler).handleStep(eq(1.0), any(double[].class), any(double[].class), eq(true));
    }
}