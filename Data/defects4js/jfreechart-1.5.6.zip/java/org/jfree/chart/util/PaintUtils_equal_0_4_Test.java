package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.assertFalse;

import java.awt.Color;
import java.awt.MultipleGradientPaint;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.Paint;
import java.awt.geom.Point2D;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class PaintUtils_equal_0_4_Test {

    @Test
    @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different center points, expect false")
    public void TC16_radialGradientPaint_different_center_point() {
        // GIVEN
        Point2D center1 = new Point2D.Float(0, 0);
        float radius = 50f;
        Point2D focus1 = new Point2D.Float(1, 1);
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        MultipleGradientPaint.CycleMethod cycleMethod = MultipleGradientPaint.CycleMethod.NO_CYCLE;
        MultipleGradientPaint.ColorSpaceType colorSpace = MultipleGradientPaint.ColorSpaceType.SRGB;
        RadialGradientPaint rgp1 = new RadialGradientPaint(center1, radius, focus1, fractions, colors, cycleMethod, colorSpace, null);

        Point2D center2 = new Point2D.Float(2, 2); // Different center point
        RadialGradientPaint rgp2 = new RadialGradientPaint(center2, radius, focus1, fractions, colors, cycleMethod, colorSpace, null);

        // WHEN
        boolean result = PaintUtils.equal(rgp1, rgp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different radii, expect false")
    public void TC17_radialGradientPaint_different_radius() {
        // GIVEN
        Point2D center = new Point2D.Float(0, 0);
        float radius1 = 50f;
        float radius2 = 60f; // Different radius
        Point2D focus = new Point2D.Float(1, 1);
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        MultipleGradientPaint.CycleMethod cycleMethod = MultipleGradientPaint.CycleMethod.NO_CYCLE;
        MultipleGradientPaint.ColorSpaceType colorSpace = MultipleGradientPaint.ColorSpaceType.SRGB;
        RadialGradientPaint rgp1 = new RadialGradientPaint(center, radius1, focus, fractions, colors, cycleMethod, colorSpace, null);
        RadialGradientPaint rgp2 = new RadialGradientPaint(center, radius2, focus, fractions, colors, cycleMethod, colorSpace, null);

        // WHEN
        boolean result = PaintUtils.equal(rgp1, rgp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different focus points, expect false")
    public void TC18_radialGradientPaint_different_focus_point() {
        // GIVEN
        Point2D center = new Point2D.Float(0, 0);
        float radius = 50f;
        Point2D focus1 = new Point2D.Float(1, 1);
        Point2D focus2 = new Point2D.Float(2, 2); // Different focus point
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        MultipleGradientPaint.CycleMethod cycleMethod = MultipleGradientPaint.CycleMethod.NO_CYCLE;
        MultipleGradientPaint.ColorSpaceType colorSpace = MultipleGradientPaint.ColorSpaceType.SRGB;
        RadialGradientPaint rgp1 = new RadialGradientPaint(center, radius, focus1, fractions, colors, cycleMethod, colorSpace, null);
        RadialGradientPaint rgp2 = new RadialGradientPaint(center, radius, focus2, fractions, colors, cycleMethod, colorSpace, null);

        // WHEN
        boolean result = PaintUtils.equal(rgp1, rgp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different fractions, expect false")
    public void TC19_radialGradientPaint_different_fractions() {
        // GIVEN
        Point2D center = new Point2D.Float(0, 0);
        float radius = 50f;
        Point2D focus = new Point2D.Float(1, 1);
        float[] fractions1 = {0.0f, 0.5f, 1.0f};
        float[] fractions2 = {0.0f, 0.6f, 1.0f}; // Different fractions
        Color[] colors = {Color.RED, Color.GREEN, Color.BLUE};
        MultipleGradientPaint.CycleMethod cycleMethod = MultipleGradientPaint.CycleMethod.NO_CYCLE;
        MultipleGradientPaint.ColorSpaceType colorSpace = MultipleGradientPaint.ColorSpaceType.SRGB;
        RadialGradientPaint rgp1 = new RadialGradientPaint(center, radius, focus, fractions1, colors, cycleMethod, colorSpace, null);
        RadialGradientPaint rgp2 = new RadialGradientPaint(center, radius, focus, fractions2, colors, cycleMethod, colorSpace, null);

        // WHEN
        boolean result = PaintUtils.equal(rgp1, rgp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different colors, expect false")
    public void TC20_radialGradientPaint_different_colors() {
        // GIVEN
        Point2D center = new Point2D.Float(0, 0);
        float radius = 50f;
        Point2D focus = new Point2D.Float(1, 1);
        float[] fractions = {0.0f, 0.5f, 1.0f};
        Color[] colors1 = {Color.RED, Color.GREEN, Color.BLUE};
        Color[] colors2 = {Color.RED, Color.YELLOW, Color.BLUE}; // Different colors
        MultipleGradientPaint.CycleMethod cycleMethod = MultipleGradientPaint.CycleMethod.NO_CYCLE;
        MultipleGradientPaint.ColorSpaceType colorSpace = MultipleGradientPaint.ColorSpaceType.SRGB;
        RadialGradientPaint rgp1 = new RadialGradientPaint(center, radius, focus, fractions, colors1, cycleMethod, colorSpace, null);
        RadialGradientPaint rgp2 = new RadialGradientPaint(center, radius, focus, fractions, colors2, cycleMethod, colorSpace, null);

        // WHEN
        boolean result = PaintUtils.equal(rgp1, rgp2);

        // THEN
        assertFalse(result);
    }
}