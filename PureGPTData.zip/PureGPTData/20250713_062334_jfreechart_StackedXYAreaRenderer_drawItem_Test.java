import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.xy.StackedXYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.urls.XYURLGenerator;
import org.jfree.chart.util.ShapeUtils;
import org.jfree.data.xy.DefaultTableXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class StackedXYAreaRendererTest {

    private StackedXYAreaRenderer renderer;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private XYPlot plot;
    private TableXYDataset dataset;
    private PlotRenderingInfo info;
    private CrosshairState crosshairState;
    private XYItemEntity entity;
    private XYURLGenerator urlGenerator;

    @BeforeEach
    public void setUp() {
        renderer = new StackedXYAreaRenderer(StackedXYAreaRenderer.AREA);
        g2 = (Graphics2D) new BufferedImage(100, 100, BufferedImage.TYPE_INT_ARGB).getGraphics();
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = new PlotRenderingInfo(null);
        plot = new XYPlot();
        plot.setDomainAxis(new NumberAxis());
        plot.setRangeAxis(new NumberAxis());
        plot.setOrientation(PlotOrientation.VERTICAL);
        dataset = createDataset();
        crosshairState = new CrosshairState();
        urlGenerator = (dataset, series, item) -> "http://example.com/item=" + item;
    }

    private TableXYDataset createDataset() {
        DefaultTableXYDataset dataset = new DefaultTableXYDataset();
        XYSeries series1 = new XYSeries("Series 1", false, true);
        series1.add(1.0, 5.0);
        series1.add(2.0, Double.NaN); // Null point case
        series1.add(3.0, 3.0);
        dataset.addSeries(series1);

        XYSeries series2 = new XYSeries("Series 2", false, true);
        series2.add(1.0, 3.0);
        series2.add(2.0, 2.0);
        series2.add(3.0, 1.0);
        dataset.addSeries(series2);
        
        return dataset;
    }

    @Test
    public void testDrawItemForFirstPass() {
        XYItemRendererState state = renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, plot.getDomainAxis(), plot.getRangeAxis(), dataset, 
                0, 0, crosshairState, 0);
        
        EntityCollection entities = state.getEntityCollection();
        assertNotNull(entities);
    }

    @Test
    public void testDrawItemForSecondPass() {
        XYItemRendererState state = renderer.initialise(g2, dataArea, plot, dataset, info);
        renderer.drawItem(g2, state, dataArea, info, plot, plot.getDomainAxis(), plot.getRangeAxis(), dataset, 
                0, 0, crosshairState, 1);

        EntityCollection entities = state.getEntityCollection();
        assertNotNull(entities);
    }

    @Test
    public void testDrawItemWithNullParameters() {
        XYItemRendererState state = renderer.initialise(g2, dataArea, plot, dataset, info);
        
        renderer.drawItem(g2, state, dataArea, info, plot, plot.getDomainAxis(), plot.getRangeAxis(), 
                null, 0, 0, crosshairState, 0);
        
        renderer.drawItem(null, state, null, null, null, null, null, dataset, 
                0, 0, null, 0);
    }

    @Test
    public void testDrawItemHorizontalOrientation() {
        plot.setOrientation(PlotOrientation.HORIZONTAL);
        XYItemRendererState state = renderer.initialise(g2, dataArea, plot, dataset, info);
        
        renderer.drawItem(g2, state, dataArea, info, plot, plot.getDomainAxis(), plot.getRangeAxis(), dataset, 
                1, 2, crosshairState, 0);
    }
}