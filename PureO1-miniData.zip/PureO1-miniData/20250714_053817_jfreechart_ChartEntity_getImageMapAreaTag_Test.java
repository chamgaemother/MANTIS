package org.jfree.chart.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.awt.Rectangle;
import java.awt.Shape;

import org.jfree.chart.imagemap.ToolTipTagFragmentGenerator;
import org.jfree.chart.imagemap.URLTagFragmentGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ChartEntityTest {

    private ToolTipTagFragmentGenerator toolTipGenerator;
    private URLTagFragmentGenerator urlGenerator;
    private Shape rectangleShape;
    private Shape polygonShape;

    @BeforeEach
    void setUp() {
        toolTipGenerator = mock(ToolTipTagFragmentGenerator.class);
        urlGenerator = mock(URLTagFragmentGenerator.class);
        rectangleShape = new Rectangle(10, 20, 30, 40);
        polygonShape = new Rectangle(50, 60, 70, 80); // Using rectangle for simplicity
    }

    @Test
    void testGetImageMapAreaTag_HasURLAndToolTip() {
        String toolTipFragment = " title=\"Tooltip\" alt=\"Tooltip\" ";
        String urlFragment = " href=\"http://example.com\" ";

        when(toolTipGenerator.generateToolTipFragment("Sample Tooltip")).thenReturn(toolTipFragment);
        when(urlGenerator.generateURLFragment("http://example.com")).thenReturn(urlFragment);

        ChartEntity entity = new ChartEntity(rectangleShape, "Sample Tooltip", "http://example.com");
        String expected = "<area shape=\"rect\" coords=\"10,20,40,60\" title=\"Tooltip\" alt=\"Tooltip\" href=\"http://example.com\"/>";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_HasURLOnly() {
        String urlFragment = " href=\"http://example.com\" ";

        when(urlGenerator.generateURLFragment("http://example.com")).thenReturn(urlFragment);

        ChartEntity entity = new ChartEntity(rectangleShape, null, "http://example.com");
        String expected = "<area shape=\"rect\" coords=\"10,20,40,60\" href=\"http://example.com\" alt=\"\"/>";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_HasToolTipOnly() {
        String toolTipFragment = " title=\"Tooltip\" alt=\"Tooltip\" ";

        when(toolTipGenerator.generateToolTipFragment("Sample Tooltip")).thenReturn(toolTipFragment);

        ChartEntity entity = new ChartEntity(rectangleShape, "Sample Tooltip", null);
        String expected = "<area shape=\"rect\" coords=\"10,20,40,60\" title=\"Tooltip\" alt=\"Tooltip\" nohref=\"nohref\"/>";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_HasNeitherURLNorToolTip() {
        ChartEntity entity = new ChartEntity(rectangleShape, null, null);
        String expected = "";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_EmptyURLAndToolTip() {
        ChartEntity entity = new ChartEntity(rectangleShape, "", "");
        String expected = "";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_EmptyToolTipOnly() {
        String urlFragment = " href=\"http://example.com\" ";

        when(urlGenerator.generateURLFragment("http://example.com")).thenReturn(urlFragment);

        ChartEntity entity = new ChartEntity(rectangleShape, "", "http://example.com");
        String expected = "<area shape=\"rect\" coords=\"10,20,40,60\" href=\"http://example.com\" alt=\"\"/>";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_EmptyURLOnly() {
        String toolTipFragment = " title=\"Tooltip\" alt=\"Tooltip\" ";

        when(toolTipGenerator.generateToolTipFragment("Sample Tooltip")).thenReturn(toolTipFragment);

        ChartEntity entity = new ChartEntity(rectangleShape, "Sample Tooltip", "");
        String expected = "<area shape=\"rect\" coords=\"10,20,40,60\" title=\"Tooltip\" alt=\"Tooltip\" nohref=\"nohref\"/>";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_PolygonShape_WithURLAndToolTip() {
        String toolTipFragment = " title=\"Polygon Tooltip\" alt=\"Polygon Tooltip\" ";
        String urlFragment = " href=\"http://polygon.com\" ";

        when(toolTipGenerator.generateToolTipFragment("Polygon Tooltip")).thenReturn(toolTipFragment);
        when(urlGenerator.generateURLFragment("http://polygon.com")).thenReturn(urlFragment);

        ChartEntity entity = new ChartEntity(polygonShape, "Polygon Tooltip", "http://polygon.com");
        String expected = "<area shape=\"rect\" coords=\"50,60,120,140\" title=\"Polygon Tooltip\" alt=\"Polygon Tooltip\" href=\"http://polygon.com\"/>";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_NullToolTipGenerator() {
        String urlFragment = " href=\"http://example.com\" ";

        when(urlGenerator.generateURLFragment("http://example.com")).thenReturn(urlFragment);

        ChartEntity entity = new ChartEntity(rectangleShape, null, "http://example.com");
        String expected = "<area shape=\"rect\" coords=\"10,20,40,60\" href=\"http://example.com\" alt=\"\"/>";

        String actual = entity.getImageMapAreaTag(null, urlGenerator);
        assertEquals(expected, actual);
    }

    @Test
    void testGetImageMapAreaTag_NullURLGenerator() {
        String toolTipFragment = " title=\"Tooltip\" alt=\"Tooltip\" ";

        when(toolTipGenerator.generateToolTipFragment("Sample Tooltip")).thenReturn(toolTipFragment);

        ChartEntity entity = new ChartEntity(rectangleShape, "Sample Tooltip", "http://example.com");
        String expected = "<area shape=\"rect\" coords=\"10,20,40,60\" title=\"Tooltip\" alt=\"Tooltip\" href=\"http://example.com\"/>";

        String actual = entity.getImageMapAreaTag(toolTipGenerator, null);
        assertEquals(expected, actual);
    }

}