package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import java.lang.reflect.Constructor;

public class Dfp_toDouble_0_3_Test {

    @Test
    @DisplayName("toDouble handles loop with one iteration during exponent calculation")
    public void test_TC11_toDouble_with_one_loop_iteration() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp dfp = new Dfp(field, 1.0); // Assuming 1.0 causes one loop iteration

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(1.0, result, "Expected double value after one loop iteration.");
    }

    @Test
    @DisplayName("toDouble handles loop with multiple iterations during exponent calculation")
    public void test_TC12_toDouble_with_multiple_loop_iterations() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp dfp = new Dfp(field, 1000.0); // Assuming 1000.0 causes multiple loop iterations

        // Act
        double result = dfp.toDouble();

        // Assert
        assertEquals(1000.0, result, "Expected double value after multiple loop iterations.");
    }

    @Test
    @DisplayName("toDouble handles mantissa rounding up to next power of two")
    public void test_TC13_toDouble_with_mantissa_rounding_up() throws Exception {
        // Arrange
        DfpField field = new DfpField(53); // 53 bits for double precision
        Dfp dfp = new Dfp(field, Math.pow(2, 52) - 0.5); // Value that requires mantissa rounding

        // Act
        double result = dfp.toDouble();

        // Assert
        // Verify mantissa rounding by checking if the result is correctly rounded up
        long bits = Double.doubleToLongBits(result);
        long expectedMantissa = 1L << 52; // Next power of two mantissa
        long actualMantissa = bits & 0xFFFFFFFFFFFFFL;
        assertEquals(expectedMantissa, actualMantissa, "Mantissa should be rounded up to the next power of two.");
    }
}