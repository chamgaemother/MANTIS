package org.apache.commons.math3.analysis.interpolation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;

public class TricubicSplineInterpolator_interpolate_0_2_Test {

    @Test
    @DisplayName("Interpolate with malformed fval arrays throws DimensionMismatchException for fval[i].length != yLen")
    public void test_TC06() {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {{{1, 2}}, {{3}}};

        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // WHEN & THEN
        Assertions.assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with malformed fval arrays throws DimensionMismatchException for fval[i][j].length != zLen")
    public void test_TC07() {
        // GIVEN
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {
            { {1, 2}, {3} },
            { {4, 5}, {6, 7} }
        };

        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // WHEN & THEN
        Assertions.assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with correctly sized inputs proceeds without exception")
    public void test_TC08() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[] zval = {1.0, 2.0, 3.0};
        double[][][] fval = {
            { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} },
            { {10, 11, 12}, {13, 14, 15}, {16, 17, 18} },
            { {19, 20, 21}, {22, 23, 24}, {25, 26, 27} }
        };

        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // WHEN
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);

        // THEN
        Assertions.assertNotNull(result, "The interpolated function should not be null.");
    }

    @Test
    @DisplayName("Interpolate with single-element arrays processes correctly")
    public void test_TC09() {
        // GIVEN
        double[] xval = {1.0};
        double[] yval = {1.0};
        double[] zval = {1.0};
        double[][][] fval = {{{1}}};

        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // WHEN
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);

        // THEN
        Assertions.assertNotNull(result, "The interpolated function should not be null for single-element arrays.");
    }

    @Test
    @DisplayName("Interpolate with multiple iterations in outer loop")
    public void test_TC10() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0, 4.0};
        double[] yval = {1.0, 2.0, 3.0, 4.0};
        double[] zval = {1.0, 2.0, 3.0, 4.0};
        double[][][] fval = {
            { {1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16} },
            { {17, 18, 19, 20}, {21, 22, 23, 24}, {25, 26, 27, 28}, {29, 30, 31, 32} },
            { {33, 34, 35, 36}, {37, 38, 39, 40}, {41, 42, 43, 44}, {45, 46, 47, 48} },
            { {49, 50, 51, 52}, {53, 54, 55, 56}, {57, 58, 59, 60}, {61, 62, 63, 64} }
        };

        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // WHEN
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);

        // THEN
        Assertions.assertNotNull(result, "The interpolated function should not be null for multiple iterations.");
    }
}