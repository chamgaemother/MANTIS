package org.apache.commons.jxpath.functions;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.JXPathInvalidAccessException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MethodFunction_invoke_2_2_Test {

    @Test
    @DisplayName("invoke method and handle InvocationTargetException with custom exception type")
    void test_TC23_InvokeMethodHandleInvocationTargetException() throws Exception {
        // Arrange
        ExpressionContext context = mock(ExpressionContext.class);
        Object[] parameters = new Object[]{"param1"};
        Method method = mock(Method.class);
        when(method.getModifiers()).thenReturn(Modifier.STATIC);
        when(method.invoke(null, parameters)).thenThrow(new InvocationTargetException(new CustomException("Custom Error")));
        MethodFunction methodFunction = new MethodFunction(method);
        
        // Act & Assert
        JXPathInvalidAccessException exception = assertThrows(JXPathInvalidAccessException.class, () -> {
            methodFunction.invoke(context, parameters);
        });
        assertEquals("Cannot invoke " + method, exception.getMessage());
        assertTrue(exception.getCause() instanceof CustomException);
        assertEquals("Custom Error", exception.getCause().getMessage());
    }
    
    // Custom exception for testing
    private static class CustomException extends Exception {
        public CustomException(String message) {
            super(message);
        }
    }
}