package org.jfree.chart.renderer.category;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

public class BarRenderer_drawItem_0_8_Test {

    @Test
    @DisplayName("drawItem handles negative series index correctly")
    void TC36_drawItem_with_negative_series_index() throws Exception {
        // Arrange
        BarRenderer renderer = spy(new BarRenderer());

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up state
        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(-1); // Negative index

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        // No bar should be drawn
        verify(g2, never()).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles minimumBarLength zero")
    void TC37_drawItem_with_minimumBarLength_zero() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();

        Field minBarLengthField = BarRenderer.class.getDeclaredField("minimumBarLength");
        minBarLengthField.setAccessible(true);
        minBarLengthField.set(renderer, 0.0);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(10);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        // Bar should be drawn
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles very small minimumBarLength values")
    void TC38_drawItem_with_very_small_minimumBarLength() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();

        Field minBarLengthField = BarRenderer.class.getDeclaredField("minimumBarLength");
        minBarLengthField.setAccessible(true);
        minBarLengthField.set(renderer, 0.0001);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(0.00005);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        // Minimal adjustment means bar should still be drawn
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles item label position fallback correctly")
    void TC39_drawItem_with_label_position_fallback() throws Exception {
        // Arrange
        BarRenderer renderer = spy(new BarRenderer());

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        ItemLabelPosition fallbackPosition = mock(ItemLabelPosition.class);

        when(renderer.getItemLabelGenerator(0, 0)).thenReturn(generator);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(10);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        verify(renderer).drawItemLabel(any(Graphics2D.class), eq(dataset), eq(0), eq(0), eq(plot), eq(generator), any(Rectangle2D.class), anyBoolean());
    }

    @Test
    @DisplayName("drawItem handles multiple label rotation angles")
    void TC40_drawItem_with_multiple_label_rotation_angles() throws Exception {
        // Arrange
        BarRenderer renderer = new BarRenderer();

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);

        when(renderer.getItemLabelGenerator(0, 0)).thenReturn(generator);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(10);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        verify(renderer).drawItemLabel(any(Graphics2D.class), eq(dataset), eq(0), eq(0), eq(plot), eq(generator), any(Rectangle2D.class), anyBoolean());
    }
}