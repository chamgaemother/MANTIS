package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.codec.language.DoubleMetaphone;

public class DoubleMetaphone_doubleMetaphone_0_2_Test {

    @Test
    @DisplayName("doubleMetaphone with alternate encoding enabled")
    public void testDoubleMetaphoneAlternateEncoding() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "Michael";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, true);
        
        // THEN
        String expected = "MKL"; // Expected alternate metaphone value for "Michael"
        assertEquals(expected, result);
    }
    
    @Test
    @DisplayName("doubleMetaphone(\"AEIOUY\", false) handles all vowels")
    public void testDoubleMetaphoneAllVowels() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "AEIOUY";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "AEIO"; // Expected metaphone value for "AEIOUY", limited to maxCodeLen=4
        assertEquals(expected, result);
    }
    
    @Test
    @DisplayName("doubleMetaphone(\"Bamboo\", false) handles double 'B'")
    public void testDoubleMetaphoneDoubleB() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "Bamboo";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "PAMP"; // Expected metaphone value, double 'B' as single 'P'
        assertEquals(expected, result);
    }
    
    @Test
    @DisplayName("doubleMetaphone(\"CATCH\", false) handles 'CH' combination")
    public void testDoubleMetaphoneCHCombination() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "CATCH";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "TXT"; // 'CH' is encoded as 'X', resulting in "TXT"
        assertEquals(expected, result);
    }
    
    @Test
    @DisplayName("doubleMetaphone(\"DOUBLE\", true) uses alternate encoding for 'D'")
    public void testDoubleMetaphoneDAlternateEncoding() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "DOUBLE";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, true);
        
        // THEN
        String expected = "TOUP"; // Expected alternate encoding for "DOUBLE"
        assertEquals(expected, result);
    }
}