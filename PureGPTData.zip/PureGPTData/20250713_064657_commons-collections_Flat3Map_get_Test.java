import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Flat3MapTest {
    
    @Test
    void testGetFromEmptyMap() {
        Flat3Map<String, String> map = new Flat3Map<>();
        assertNull(map.get("key"));
    }

    @Test
    void testGetFromMapWithOneElement() {
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("key1", "value1");
        assertEquals("value1", map.get("key1"));
        assertNull(map.get("key2"));
    }

    @Test
    void testGetFromMapWithTwoElements() {
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("key1", "value1");
        map.put("key2", "value2");
        assertEquals("value2", map.get("key2"));
        assertNull(map.get("key3"));
    }

    @Test
    void testGetFromMapWithThreeElements() {
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertEquals("value3", map.get("key3"));
        assertNull(map.get("key4"));
    }

    @Test
    void testGetNullKeyFromMap() {
        Flat3Map<String, String> map = new Flat3Map<>();
        map.put(null, "nullValue");
        map.put("key1", "value1");
        assertEquals("nullValue", map.get(null));
    }

    @Test
    void testGetNullKeyFromEmptyMap() {
        Flat3Map<String, String> map = new Flat3Map<>();
        assertNull(map.get(null));
    }

    @Test
    void testGetWithSameHashDifferentContent() {
        Flat3Map<Object, String> map = new Flat3Map<>();
        String key1 = new String("key1");
        String key2 = new String("key1"); // same hash, different instances
        map.put(key1, "value1");
        assertEquals("value1", map.get(key1));
        assertNull(map.get(key2));
    }
}