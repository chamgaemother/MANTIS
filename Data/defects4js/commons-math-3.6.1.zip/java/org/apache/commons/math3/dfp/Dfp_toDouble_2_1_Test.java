package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.*;

public class Dfp_toDouble_2_1_Test {

    @Test
    @DisplayName("toDouble correctly converts a normal positive Dfp number with exponent exactly -1023")
    void test_TC22() throws Exception {
        // Create DfpField with radixDigits =1
        Class<?> dfpFieldClass = Class.forName("org.apache.commons.math3.dfp.DfpField");
        Constructor<?> dfpFieldConstructor = dfpFieldClass.getDeclaredConstructor(int.class);
        dfpFieldConstructor.setAccessible(true);
        Object dfpField = dfpFieldConstructor.newInstance(1);

        // Instantiate Dfp with DfpField
        Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
        Constructor<?> dfpConstructor = dfpClass.getDeclaredConstructor(dfpFieldClass);
        dfpConstructor.setAccessible(true);
        Object dfp = dfpConstructor.newInstance(dfpField);

        // Set mantissa, sign, exp, nans via reflection
        Field mantField = dfpClass.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = new int[]{1};
        mantField.set(dfp, mant);

        Field signField = dfpClass.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(dfp, (byte)1);

        Field expField = dfpClass.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(dfp, -1023);

        Field nansField = dfpClass.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(dfp, (byte)0); // FINITE

        // Invoke toDouble()
        Method toDoubleMethod = dfpClass.getMethod("toDouble");
        double actual = (Double) toDoubleMethod.invoke(dfp);

        // Assert equals expected double 0.0
        assertEquals(0.0, actual, "Dfp toDouble did not return expected value for TC22");
    }

    @Test
    @DisplayName("toDouble handles mantissa rounding that increments the exponent")
    void test_TC23() throws Exception {
        // Create DfpField with radixDigits =1
        Class<?> dfpFieldClass = Class.forName("org.apache.commons.math3.dfp.DfpField");
        Constructor<?> dfpFieldConstructor = dfpFieldClass.getDeclaredConstructor(int.class);
        dfpFieldConstructor.setAccessible(true);
        Object dfpField = dfpFieldConstructor.newInstance(1);

        // Instantiate Dfp with DfpField
        Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
        Constructor<?> dfpConstructor = dfpClass.getDeclaredConstructor(dfpFieldClass);
        dfpConstructor.setAccessible(true);
        Object dfp = dfpConstructor.newInstance(dfpField);

        // Set mantissa, sign, exp, nans via reflection
        Field mantField = dfpClass.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = new int[]{9999};
        mantField.set(dfp, mant);

        Field signField = dfpClass.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(dfp, (byte)1);

        Field expField = dfpClass.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(dfp, -1024);

        Field nansField = dfpClass.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(dfp, (byte)0); // FINITE

        // Invoke toDouble()
        Method toDoubleMethod = dfpClass.getMethod("toDouble");
        double actual = (Double) toDoubleMethod.invoke(dfp);

        // Assert equals expected double Double.MIN_NORMAL
        assertEquals(Double.MIN_NORMAL, actual, "Dfp toDouble did not handle rounding correctly for TC23");
    }
}