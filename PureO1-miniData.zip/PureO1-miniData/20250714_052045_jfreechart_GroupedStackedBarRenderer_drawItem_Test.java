import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GroupedStackedBarRendererTest {

    private GroupedStackedBarRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;

    @BeforeEach
    public void setUp() {
        renderer = new GroupedStackedBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);
        
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisForDataset(anyInt())).thenReturn(domainAxis);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        renderer.setSeriesToGroupMap(new KeyToGroupMap("Group"));
    }

    @Test
    public void testDrawItem_NullDataValue() {
        int row = 0;
        int column = 0;
        when(dataset.getValue(row, column)).thenReturn(null);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        // Verify that no further interactions occur when dataValue is null
        verify(dataset).getValue(row, column);
        verifyNoMoreInteractions(g2, state, plot, domainAxis, rangeAxis, dataset);
    }

    @Test
    public void testDrawItem_PositiveValue_Vertical_NonInverted() {
        int row = 1;
        int column = 1;
        double value = 10.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(20.0).thenReturn(30.0);
        when(state.getBarWidth()).thenReturn(5.0);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
        verify(rangeAxis).isInverted();
        verify(domainAxis).getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class));
        verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(state).getBarWidth();
        verify(state).getInfo();
    }

    @Test
    public void testDrawItem_NegativeValue_Vertical_NonInverted() {
        int row = 2;
        int column = 2;
        double value = -5.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(25.0).thenReturn(20.0);
        when(state.getBarWidth()).thenReturn(5.0);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
        verify(rangeAxis).isInverted();
        verify(domainAxis).getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class));
        verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(state).getBarWidth();
        verify(state).getInfo();
    }

    @Test
    public void testDrawItem_PositiveValue_Vertical_Inverted() {
        int row = 3;
        int column = 3;
        double value = 8.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(40.0).thenReturn(48.0);
        when(state.getBarWidth()).thenReturn(5.0);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
        verify(rangeAxis).isInverted();
        verify(domainAxis).getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class));
        verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(state).getBarWidth();
        verify(state).getInfo();
    }

    @Test
    public void testDrawItem_NegativeValue_Vertical_Inverted() {
        int row = 4;
        int column = 4;
        double value = -12.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(60.0).thenReturn(48.0);
        when(state.getBarWidth()).thenReturn(5.0);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
        verify(rangeAxis).isInverted();
        verify(domainAxis).getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class));
        verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(state).getBarWidth();
        verify(state).getInfo();
    }

    @Test
    public void testDrawItem_HorizontalOrientation() {
        int row = 5;
        int column = 5;
        double value = 7.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(35.0).thenReturn(42.0);
        when(state.getBarWidth()).thenReturn(5.0);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
        verify(rangeAxis).isInverted();
        verify(domainAxis).getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class));
        verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(state).getBarWidth();
        verify(state).getInfo();
    }

    @Test
    public void testDrawItem_Grouped_SingleGroup() {
        int row = 0;
        int column = 0;
        double value = 5.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(renderer.getMaximumBarWidth()).thenReturn(0.2);
        when(domainAxis.getCategoryMargin()).thenReturn(0.1);
        when(renderer.getItemMargin()).thenReturn(0.05);
        when(renderer.getMinimumBarLength()).thenReturn(2.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(20.0).thenReturn(25.0);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getInfo()).thenReturn(null);
        
        renderer.setSeriesToGroupMap(new KeyToGroupMap("Group1"));
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(renderer).getMaximumBarWidth();
        verify(renderer).getItemMargin();
        verify(renderer).getMinimumBarLength();
    }

    @Test
    public void testDrawItem_Grouped_MultipleGroups() {
        int row = 1;
        int column = 1;
        double value = 15.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(renderer.getMaximumBarWidth()).thenReturn(0.2);
        when(domainAxis.getCategoryMargin()).thenReturn(0.1);
        when(renderer.getItemMargin()).thenReturn(0.05);
        when(renderer.getMinimumBarLength()).thenReturn(2.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(30.0).thenReturn(45.0);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getInfo()).thenReturn(mock(Object.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(generator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        
        KeyToGroupMap map = new KeyToGroupMap("Group");
        map.mapKeyToGroup("Series1", "Group1");
        map.mapKeyToGroup("Series2", "Group2");
        when(dataset.getRowKey(row)).thenReturn("Series2");
        when(dataset.getRowKey(0)).thenReturn("Series1");
        when(dataset.getValue(0, column)).thenReturn(10.0);
        
        renderer.setSeriesToGroupMap(map);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(entities).add(any());
        verify(generator).generateLabel(any(), any(), any(), any());
    }

    @Test
    public void testDrawItem_GeneratorNull() {
        int row = 2;
        int column = 2;
        double value = 20.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(null);
        when(state.getInfo()).thenReturn(null);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
        verify(renderer).getItemLabelGenerator(row, column);
    }

    @Test
    public void testDrawItem_ItemLabelInvisible() {
        int row = 3;
        int column = 3;
        double value = 25.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(generator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);
        when(state.getInfo()).thenReturn(null);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(generator, never()).generateLabel(any(), any(), any(), any());
    }

    @Test
    public void testDrawItem_StateInfoNull() {
        int row = 4;
        int column = 4;
        double value = 30.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(state.getInfo()).thenReturn(null);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(state).getInfo();
    }

    @Test
    public void testDrawItem_EntityCollectionNull() {
        int row = 5;
        int column = 5;
        double value = 35.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(state.getInfo()).thenReturn(mock(Object.class));
        when(state.getEntityCollection()).thenReturn(null);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(state).getEntityCollection();
    }

    @Test
    public void testDrawItem_EntityCollectionPresent() {
        int row = 6;
        int column = 6;
        double value = 40.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(state.getInfo()).thenReturn(mock(Object.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_ValueZero() {
        int row = 7;
        int column = 7;
        double value = 0.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0).thenReturn(50.0);
        when(state.getBarWidth()).thenReturn(5.0);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
    }

    @Test
    public void testDrawItem_AllBranchesCovered() {
        int row = 8;
        int column = 8;
        double value = -10.0;
        when(dataset.getValue(row, column)).thenReturn(value);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(60.0).thenReturn(50.0);
        when(state.getBarWidth()).thenReturn(5.0);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(null);
        when(state.getInfo()).thenReturn(null);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        
        verify(dataset).getValue(row, column);
        verify(rangeAxis).isInverted();
        verify(domainAxis).getCategoryStart(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class));
        verify(rangeAxis, times(2)).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(state).getBarWidth();
    }
}