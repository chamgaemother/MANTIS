package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.awt.geom.Point2D;
import java.lang.reflect.Field;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYPlot_getDataRange_1_1_Test {

    /**
     * A mock subclass of XYPlot to simulate getDataRange behavior.
     */
    private static class MockXYPlot extends XYPlot {
        private Range mockRange;

        public MockXYPlot(Range range) {
            super();
            this.mockRange = range;
        }

        @Override
        public Range getDataRange(ValueAxis axis) {
            return mockRange;
        }
    }

    /**
     * Test case TC11: getDataRange correctly combines multiple valid Ranges from several subplots.
     */
    @Test
    @DisplayName("getDataRange correctly combines multiple valid Ranges from several subplots")
    void TC11_getDataRange_combineMultipleSubplots() throws Exception {
        // GIVEN
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(new NumberAxis());

        // Create mock subplots with predefined Ranges
        XYPlot subplot1 = new MockXYPlot(new Range(0.0, 5.0));
        XYPlot subplot2 = new MockXYPlot(new Range(5.0, 10.0));
        XYPlot subplot3 = new MockXYPlot(new Range(10.0, 15.0));

        // Use reflection to set the private 'subplots' field
        Field subplotsField = CombinedDomainXYPlot.class.getDeclaredField("subplots");
        subplotsField.setAccessible(true);
        subplotsField.set(combinedPlot, List.of(subplot1, subplot2, subplot3));

        ValueAxis axis = new NumberAxis();

        // WHEN
        Range result = combinedPlot.getDataRange(axis);

        // THEN
        assertEquals(new Range(0.0, 15.0), result, "The combined Range should span from 0.0 to 15.0");
    }

    /**
     * Test case TC12: getDataRange throws NullPointerException when a subplot is null.
     */
    @Test
    @DisplayName("getDataRange throws NullPointerException when a subplot is null")
    void TC12_getDataRange_nullSubplot() throws Exception {
        // GIVEN
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(new NumberAxis());

        // Create subplots list with a null subplot
        XYPlot subplot1 = null;

        // Use reflection to set the private 'subplots' field
        Field subplotsField = CombinedDomainXYPlot.class.getDeclaredField("subplots");
        subplotsField.setAccessible(true);
        subplotsField.set(combinedPlot, List.of(subplot1));

        ValueAxis axis = new NumberAxis();

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> combinedPlot.getDataRange(axis), "Expected getDataRange to throw NullPointerException when a subplot is null");
    }
}