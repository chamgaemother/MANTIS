package com.fasterxml.jackson.databind.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

/**
 * JUnit 5 test class for {@link TokenBuffer#copyCurrentEvent(JsonParser)}.
 * This class includes tests to maximize branch coverage based on provided scenarios.
 */
public class TokenBuffer_copyCurrentEvent_1_1_Test {

    @Test
    @DisplayName("copyCurrentEvent with null JsonParser throws NullPointerException")
    void TC31_copyCurrentEvent_nullJsonParser_throwsNullPointerException() {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        JsonParser p = null;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> buffer.copyCurrentEvent(p),
                "Expected copyCurrentEvent to throw NullPointerException when JsonParser is null");
    }

    @Test
    @DisplayName("copyCurrentEvent with VALUE_NUMBER_INT and NumberType.DOUBLE calls writeNumber(long)")
    void TC32_copyCurrentEvent_valueNumberIntWithDouble_callsWriteNumberLong() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        JsonParser p = mock(JsonParser.class);
        when(p.currentToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(p.getNumberType()).thenReturn(JsonParser.NumberType.DOUBLE);
        when(p.getLongValue()).thenReturn(123456789L);

        // WHEN
        buffer.copyCurrentEvent(p);

        // THEN
        // Use reflection to access the private _first field of TokenBuffer
        Field firstField = TokenBuffer.class.getDeclaredField("_first");
        firstField.setAccessible(true);
        Object firstSegmentObj = firstField.get(buffer);

        // Ensure the first segment is not null
        assertNotNull(firstSegmentObj, "The first segment should not be null");
        assertTrue(firstSegmentObj instanceof TokenBuffer.Segment, "The first segment should be an instance of TokenBuffer.Segment");

        TokenBuffer.Segment firstSegment = (TokenBuffer.Segment) firstSegmentObj;

        // Access the private _tokenTypes field of Segment
        Field tokenTypesField = TokenBuffer.Segment.class.getDeclaredField("_tokenTypes");
        tokenTypesField.setAccessible(true);
        long tokenTypes = tokenTypesField.getLong(firstSegment);

        // Extract the token type at index 0
        int tokenTypeInt = (int) (tokenTypes & 0xF);
        JsonToken tokenType = JsonToken.values()[tokenTypeInt];

        // Assert the token type is VALUE_NUMBER_INT
        assertEquals(JsonToken.VALUE_NUMBER_INT, tokenType, "The token type should be VALUE_NUMBER_INT");

        // Access the private _tokens array of Segment
        Field tokensField = TokenBuffer.Segment.class.getDeclaredField("_tokens");
        tokensField.setAccessible(true);
        Object[] tokens = (Object[]) tokensField.get(firstSegment);

        // Assert that the first token is the expected long value
        assertEquals(123456789L, tokens[0], "The first token should be the long value 123456789L");
    }
}