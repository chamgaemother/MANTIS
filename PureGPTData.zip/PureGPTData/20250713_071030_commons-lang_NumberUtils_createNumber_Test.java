import org.apache.commons.lang3.math.NumberUtils;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class NumberUtilsTest {

    @Test
    void testCreateNumberWithNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberWithBlankString() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("  "));
    }

    @Test
    void testCreateNumberWithDecimal() {
        assertEquals(123.45, NumberUtils.createNumber("123.45"));
        assertEquals(-123.45, NumberUtils.createNumber("-123.45"));
    }

    @Test
    void testCreateNumberWithExponent() {
        assertEquals(1.2345E2, NumberUtils.createNumber("1.2345E2"));
        assertEquals(-1.2345E2, NumberUtils.createNumber("-1.2345E2"));
    }

    @Test
    void testCreateNumberWithValidLong() {
        assertEquals(123456789012345L, NumberUtils.createNumber("123456789012345L"));
    }

    @Test
    void testCreateNumberWithOverflowingLong() {
        assertEquals(new java.math.BigInteger("9223372036854775808"), NumberUtils.createNumber("9223372036854775808"));
    }

    @Test
    void testCreateNumberWithHexadecimal() {
        assertEquals(255, NumberUtils.createNumber("0xFF"));
        assertEquals(-255, NumberUtils.createNumber("-0xFF"));
    }

    @Test
    void testCreateNumberWithOctal() {
        assertEquals(83, NumberUtils.createNumber("0123"));
    }

    @Test
    void testCreateNumberWithInvalidOctal() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("09"));
    }

    @Test
    void testCreateNumberWithTypeQualifier() {
        assertEquals(123L, NumberUtils.createNumber("123L"));
        assertEquals(123f, NumberUtils.createNumber("123f"));
        assertEquals(123d, NumberUtils.createNumber("123d"));
    }

    @Test
    void testCreateNumberWithTrailingDot() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("123."));
    }

    @Test
    void testCreateNumberWithLeadingSignAndHex() {
        assertEquals(-255, NumberUtils.createNumber("-0xFF"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("+0xFF"));
    }

    @Test
    void testCreateNumberWithWhitespace() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(" 123 "));
    }
}