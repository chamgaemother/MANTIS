package com.fasterxml.jackson.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import com.fasterxml.jackson.core.Base64Variant;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;

public class Base64Variant_decode_0_8_Test {

    @Test
    @DisplayName("decode with builder reaching capacity during multiple iterations appends until capacity")
    public void TC36() throws Exception {
        // GIVEN
        String str = "TWFuTWE=";
        ByteArrayBuilder builder = new ByteArrayBuilder(3);
        Base64Variant variant = new Base64Variant("TestVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', Integer.MAX_VALUE);

        // WHEN
        variant.decode(str, builder);

        // THEN
        byte[] expected = "ManMa".getBytes();
        assertArrayEquals(expected, builder.toByteArray(), "Decoded bytes should match the expected result");
    }

    @Test
    @DisplayName("decode with intermittent whitespace in multi-iteration input decodes correctly")
    public void TC37() throws Exception {
        // GIVEN
        String str = "T W F u I G l z I G R p c3Rpbmdf"; // Base64 for "Man is distingu"
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = new Base64Variant("TestVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', Integer.MAX_VALUE);

        // WHEN
        variant.decode(str, builder);

        // THEN
        byte[] expected = "Man is distingu".getBytes();
        assertArrayEquals(expected, builder.toByteArray(), "Decoded bytes should match the expected result ignoring whitespace");
    }
}