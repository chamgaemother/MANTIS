import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WordUtilsTest {

    @Test
    void testWrapWithNullString() {
        assertNull(WordUtils.wrap(null, 20, null, false, null));
    }

    @Test
    void testWrapWithEmptyString() {
        assertEquals("", WordUtils.wrap("", 20, null, false, null));
    }

    @Test
    void testWrapWithNullNewLineStr() {
        assertEquals("This is a test" + System.lineSeparator() + "string",
                WordUtils.wrap("This is a test string", 15, null, false, null));
    }

    @Test
    void testWrapWithNonNullNewLineStr() {
        assertEquals("This is a test<br>string",
                WordUtils.wrap("This is a test string", 15, "<br>", false, null));
    }

    @Test
    void testWrapWithWrapLongWordsFalse() {
        assertEquals("Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org",
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org",
                        20, "\n", false, " "));
    }

    @Test
    void testWrapWithWrapLongWordsTrue() {
        assertEquals("Click here to jump\nto the commons\nwebsite -\nhttps://commons.apach\ne.org",
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org",
                        20, "\n", true, " "));
    }

    @Test
    void testWrapWithAlternativeDelimiter() {
        assertEquals("flammable\ninflammable",
                WordUtils.wrap("flammable/inflammable", 10, "\n", true, "/"));
    }

    @Test
    void testWrapWithShortWrapLengthAndNonBreaking() {
        assertEquals("word-\nword-\nword-\nword",
                WordUtils.wrap("word-word-word-word", 5, "\n", false, "-"));
    }

    @Test
    void testWrapWithSingleCharacterWrap() {
        assertEquals("a\na\na",
                WordUtils.wrap("aaa", 1, "\n", true, " "));
    }

    // Additional edge cases
    @Test
    void testWrapOnSpaceWithLeadingSpaces() {
        assertEquals("   Word with space\n   leading space\n   and trailing\n   ",
                WordUtils.wrap("   Word with space leading space and trailing    ", 15, "\n", false, " "));
    }

    @Test
    void testWrapWithZeroWrapLength() {
        assertEquals("a", WordUtils.wrap("a", 0, null, false, null));
    }

    @Test
    void testWrapWithNegativeWrapLength() {
        assertEquals("a", WordUtils.wrap("a", -5, null, false, null));
    }

    @Test
    void testWrapWithVeryLongWordWithoutBreaking() {
        String longWord = "abcdefgh";
        assertEquals(longWord, WordUtils.wrap(longWord, 3, "\n", false, " "));
    }
}