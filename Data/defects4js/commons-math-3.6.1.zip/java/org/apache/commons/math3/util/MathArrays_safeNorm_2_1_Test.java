package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MathArrays_safeNorm_2_1_Test {

    @Test
    @DisplayName("safeNorm with elements exactly equal to rdwarf and agiant to verify boundary handling")
    public void TC24_safeNorm_boundaryValues() {
        // GIVEN
        double[] v = {3.834e-20, 1.304e+19};
        
        // WHEN
        double result = MathArrays.safeNorm(v);
        
        // THEN
        double expected = Math.sqrt((3.834e-20 * 3.834e-20) + (1.304e+19 * 1.304e+19));
        assertEquals(expected, result, 1e+5, "norm is correctly computed using boundary values rdwarf and agiant");
    }
    
    @Test
    @DisplayName("safeNorm with multiple small elements causing multiple s3 updates")
    public void TC25_safeNorm_multipleSmallElements() {
        // GIVEN
        double[] v = {1.0e-21, 2.0e-21, 3.0e-21};
        
        // WHEN
        double result = MathArrays.safeNorm(v);
        
        // THEN
        double expected = Math.sqrt((1.0e-21 * 1.0e-21) + (2.0e-21 * 2.0e-21) + (3.0e-21 * 3.0e-21));
        assertEquals(expected, result, 1e-42, "norm is correctly computed with multiple small elements affecting s3");
    }
    
    @Test
    @DisplayName("safeNorm with multiple large elements causing multiple s1 updates")
    public void TC26_safeNorm_multipleLargeElements() {
        // GIVEN
        double[] v = {1.0e+18, 2.0e+18, 3.0e+18};
        
        // WHEN
        double result = MathArrays.safeNorm(v);
        
        // THEN
        double expected = Math.sqrt((1.0e+18 * 1.0e+18) + (2.0e+18 * 2.0e+18) + (3.0e+18 * 3.0e+18));
        assertEquals(expected, result, 1e+0, "norm is correctly computed with multiple large elements affecting s1");
    }
}