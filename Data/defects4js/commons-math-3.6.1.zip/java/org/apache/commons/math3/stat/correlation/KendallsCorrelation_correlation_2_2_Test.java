package org.apache.commons.math3.stat.correlation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class KendallsCorrelation_correlation_2_2_Test {

    @Test
    @DisplayName("correlation correctly handles arrays with maximum double values")
    void TC30() {
        double[] xArray = {Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE};
        double[] yArray = {Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE};
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);
        assertEquals(1.0, result, 1e-10);
    }

    @Test
    @DisplayName("correlation correctly handles arrays with minimum double values")
    void TC31() {
        double[] xArray = {Double.MIN_VALUE, Double.MIN_VALUE, Double.MIN_VALUE};
        double[] yArray = {Double.MIN_VALUE, Double.MIN_VALUE, Double.MIN_VALUE};
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);
        assertEquals(1.0, result, 1e-10);
    }

}