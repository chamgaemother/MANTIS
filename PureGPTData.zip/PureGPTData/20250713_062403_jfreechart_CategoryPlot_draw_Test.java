import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.CategoryCrosshairState;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.data.category.CategoryDataset;
import org.jfree.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class CategoryPlotTest {

    private CategoryPlot plot;
    private Graphics2D graphics;
    private Rectangle2D plotArea;
    private Point2D anchor;
    private PlotState state;
    private PlotRenderingInfo info;
    
    @BeforeEach
    void setUp() {
        plot = new CategoryPlot();
        graphics = Mockito.mock(Graphics2D.class);
        plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        anchor = new Point2D.Double(50, 50);
        state = Mockito.mock(PlotState.class);
        info = Mockito.mock(PlotRenderingInfo.class);

        plot.setDomainAxis(mock(CategoryAxis.class));
        plot.setRangeAxis(mock(ValueAxis.class));
        plot.setRenderer(mock(CategoryItemRenderer.class));
    }

    @Test
    void testDrawWithNullInputs() {
        assertThrows(NullPointerException.class, () -> plot.draw(null, plotArea, anchor, state, info));
        assertThrows(NullPointerException.class, () -> plot.draw(graphics, null, anchor, state, info));
    }

    @Test
    void testDrawWithSmallPlotArea() {
        plotArea = new Rectangle2D.Double(0, 0, 0.5, 0.5);
        plot.draw(graphics, plotArea, anchor, state, info);
        verify(state, never()).setDataArea(any(Rectangle2D.class));
    }

    @Test
    void testDrawWithLargePlotArea() {
        plot.setInsets(new RectangleInsets(0, 0, 0, 0));
        plot.draw(graphics, plotArea, anchor, state, info);
        verify(state).setDataArea(any(Rectangle2D.class));
    }
    
    @Test
    void testDrawWithNoDataset() {
        plot.setDataset(null);
        plot.draw(graphics, plotArea, anchor, state, info);
        verify(graphics).setClip(any(Shape.class));
    }
    
    @Test
    void testDrawWithNullRenderer() {
        plot.setRenderer(null);
        plot.draw(graphics, plotArea, anchor, state, info);
        verify(graphics).fill(any(Rectangle2D.class)); // Default background draw
    }
    
    @Test
    void testDrawAnnotationsPresent() {
        plot.getAnnotations().add(Mockito.mock(CategoryAnnotation.class));
        plot.draw(graphics, plotArea, anchor, state, info);
        verify(graphics).setClip(any(Shape.class));
    }

    @Test
    void testDrawCrosshairVisible() {
        plot.setRangeCrosshairVisible(true);
        plot.setDomainCrosshairVisible(true);
        plot.draw(graphics, plotArea, anchor, state, info);
        verify(graphics).draw(any(Shape.class));
    }

    @Test
    void testDrawNoDataMessage() {
        plot.setRenderer(null);
        plot.draw(graphics, plotArea, anchor, state, info);
        verify(graphics).setComposite(any(Composite.class));
    }
    
    @Test
    void testDrawWithUnmatchedState() {
        plot.setRangeCrosshairLockedOnData(false);
        when(state.getSharedAxisStates()).thenReturn(new HashMap<>());
        plot.draw(graphics, plotArea, anchor, state, null);
        verify(graphics).setClip(any(Shape.class));
    }
}