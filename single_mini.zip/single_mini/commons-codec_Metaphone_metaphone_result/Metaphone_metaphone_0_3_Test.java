package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.Metaphone;

/**
 * Generated JUnit 5 test class for Metaphone.metaphone method.
 */
public class Metaphone_metaphone_0_3_Test {

    @Test
    @DisplayName("metaphone(\"CIAO\") converts 'CIA' to 'X'")
    void test_TC11() {
        String input = "CIAO";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(input);
        assertTrue(result.contains("X"), "Metaphone code should contain 'X'");
    }

    @Test
    @DisplayName("metaphone(\"GNOME\") handles silent 'G'")
    void test_TC12() {
        String input = "GNOME";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(input);
        assertFalse(result.contains("G"), "Metaphone code should not contain 'G'");
    }

    @Test
    @DisplayName("metaphone(\"JAZZ\") processes double 'Z'")
    void test_TC13() {
        String input = "JAZZ";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(input);
        assertEquals("JAS", result, "Metaphone code should equal 'JAS'");
    }

    @Test
    @DisplayName("metaphone(\"BOUGHT\") handles silent 'GH'")
    void test_TC14() {
        String input = "BOUGHT";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(input);
        assertFalse(result.contains("GH"), "Metaphone code should not contain 'GH'");
    }

    @Test
    @DisplayName("metaphone(\"SENSOR\") processes 'SEN' correctly")
    void test_TC15() {
        String input = "SENSOR";
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(input);
        assertTrue(result.contains("SN"), "Metaphone code should contain 'SN'");
    }
}