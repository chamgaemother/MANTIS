package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_atan2_0_5_Test {

    @Test
    @DisplayName("atan2(x=Finite, y=-Infinity) returns -Math.PI/2 when y is negative infinity")
    public void TC21() {
        // GIVEN
        double x = 1.0;
        double y = Double.NEGATIVE_INFINITY;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(-Math.PI / 2, result, "atan2 did not return -Math.PI / 2 for y = -Infinity");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=Infinity) returns Math.PI/2 for positive finite x and y=Infinity")
    public void TC22() {
        // GIVEN
        double x = 1.0;
        double y = Double.POSITIVE_INFINITY;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(Math.PI / 2, result, "atan2 did not return Math.PI / 2 for y = Infinity");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=-Infinity) returns -Math.PI/2 for positive finite x and y=-Infinity")
    public void TC23() {
        // GIVEN
        double x = 1.0;
        double y = Double.NEGATIVE_INFINITY;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(-Math.PI / 2, result, "atan2 did not return -Math.PI / 2 for y = -Infinity");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=1e308) returns correct angle for large finite inputs")
    public void TC24() {
        // GIVEN
        double x = 1.0;
        double y = 1e308;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertTrue(Math.abs(result - Math.atan2(y, x)) < 1e-10, "atan2 did not return a value within the expected tolerance for large finite inputs");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=-1e308) returns correct angle for large negative finite inputs")
    public void TC25() {
        // GIVEN
        double x = 1.0;
        double y = -1e308;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertTrue(Math.abs(result - Math.atan2(y, x)) < 1e-10, "atan2 did not return a value within the expected tolerance for large negative finite inputs");
    }
}