package org.apache.commons.collections4.iterators;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import static org.junit.jupiter.api.Assertions.*;

public class PermutationIterator_next_0_4_Test {

    @Test
    @DisplayName("Handles keys array with alternating direction flags")
    public void TC16() throws Exception {
        // Initialize PermutationIterator with a list
        PermutationIterator<Integer> iterator = new PermutationIterator<>(
                List.of(1, 2, 3)
        );
        
        // Use reflection to set private fields if necessary
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{3, 1, 2});
        
        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, new boolean[]{true, false, true});
        
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPerm = List.of(1, 2, 3);
        nextPermutationField.set(iterator, nextPerm);
        
        // Call next()
        List<Integer> result = iterator.next();
        
        // Assert that swaps respect individual alternating direction flags and updates are correct
        List<Integer> expected = List.of(2, 1, 3);
        assertEquals(expected, result, "The next permutation should swap based on alternating direction flags correctly.");
    }

    @Test
    @DisplayName("Handles keys array where k is the first element")
    public void TC17() throws Exception {
        // Initialize PermutationIterator with a list
        PermutationIterator<Integer> iterator = new PermutationIterator<>(
                List.of(3, 1, 2)
        );
        
        // Use reflection to set private fields if necessary
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{3, 1, 2});
        
        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, new boolean[]{true, false, true});
        
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPerm = List.of(1, 2, 3);
        nextPermutationField.set(iterator, nextPerm);
        
        // Call next()
        List<Integer> result = iterator.next();
        
        // Assert that k is swapped to the right correctly and directions are updated
        List<Integer> expected = List.of(1, 3, 2);
        assertEquals(expected, result, "The largest mobile integer k should be swapped to the right correctly and directions updated.");
    }

    @Test
    @DisplayName("Handles keys array where k is the last element")
    public void TC18() throws Exception {
        // Initialize PermutationIterator with a list
        PermutationIterator<Integer> iterator = new PermutationIterator<>(
                List.of(1, 2, 3)
        );
        
        // Use reflection to set private fields if necessary
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{1, 2, 3});
        
        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, new boolean[]{true, false, true});
        
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPerm = List.of(1, 3, 2);
        nextPermutationField.set(iterator, nextPerm);
        
        // Call next()
        List<Integer> result = iterator.next();
        
        // Assert that k is swapped to the left correctly and directions are updated
        List<Integer> expected = List.of(1, 3, 2);
        assertEquals(expected, result, "The largest mobile integer k should be swapped to the left correctly and directions updated.");
    }
}