package com.google.gson.internal.bind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.TimeZone;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class ISO8601Utils_parse_0_4_Test {

    @Test
    @DisplayName("parse date with ParsePosition index non-zero")
    void TC16_parseDateWithParsePositionIndexNonZero() {
        // GIVEN
        String date = "2023-10-05";
        ParsePosition pos = new ParsePosition(2);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertEquals("Failed to parse date [\"2023-10-05\"]: No time zone indicator", exception.getMessage());
        assertEquals(2, pos.getIndex());
    }

    @Test
    @DisplayName("parse date with incomplete time component")
    void TC17_parseDateWithIncompleteTimeComponent() {
        // GIVEN
        String date = "2023-10-05T14:30";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("Failed to parse date"));
        assertEquals(14, pos.getIndex());
    }

    @Test
    @DisplayName("parse date with missing month component")
    void TC18_parseDateWithMissingMonthComponent() {
        // GIVEN
        String date = "2023-10";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("Failed to parse date"));
        assertEquals(7, pos.getIndex());
    }

    @Test
    @DisplayName("parse date with extra characters after valid date")
    void TC19_parseDateWithExtraCharactersAfterValidDate() {
        // GIVEN
        String date = "2023-10-05abc";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("Failed to parse date"));
        assertEquals(10, pos.getIndex());
    }

    @Test
    @DisplayName("parse date with milliseconds component")
    void TC20_parseDateWithMillisecondsComponent() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00.123Z";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.setTime(result);
        assertEquals(123, calendar.get(Calendar.MILLISECOND));
        assertEquals(date.length(), pos.getIndex());
    }

}