package org.apache.commons.math3.stat.descriptive.rank;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class PSquarePercentile_equals_0_2_Test {

    @Test
    @DisplayName("Equals returns true when both markers are null and getN is equal")
    public void TC06_equalsMarkersNull_getNEqual() throws Exception {
        // GIVEN
        PSquarePercentile instance1 = new PSquarePercentile();
        PSquarePercentile instance2 = new PSquarePercentile();

        // Set markers to null via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(instance1, null);
        markersField.set(instance2, null);

        // Set countOfObservations via reflection
        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(instance1, 10L);
        countField.setLong(instance2, 10L);

        // WHEN
        boolean result = instance1.equals(instance2);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("Equals returns false when both markers are null but getN is not equal")
    public void TC07_equalsMarkersNull_getNNotEqual() throws Exception {
        // GIVEN
        PSquarePercentile instance1 = new PSquarePercentile();
        PSquarePercentile instance2 = new PSquarePercentile();

        // Set markers to null via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(instance1, null);
        markersField.set(instance2, null);

        // Set countOfObservations via reflection
        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(instance1, 10L);
        countField.setLong(instance2, 15L);

        // WHEN
        boolean result = instance1.equals(instance2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Equals returns false when this.markers is null and other.markers is not null")
    public void TC08_equalsThisMarkersNullOtherNotNull() throws Exception {
        // GIVEN
        PSquarePercentile instance1 = new PSquarePercentile();
        PSquarePercentile instance2 = new PSquarePercentile();

        // Set this.markers to null and other.markers to a new PSquareMarkers via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(instance1, null);
        markersField.set(instance2, new PSquareMarkers());

        // WHEN
        boolean result = instance1.equals(instance2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Equals returns false when other.markers is null and this.markers is not null")
    public void TC09_equalsThisMarkersNotNullOtherNull() throws Exception {
        // GIVEN
        PSquarePercentile instance1 = new PSquarePercentile();
        PSquarePercentile instance2 = new PSquarePercentile();

        // Set this.markers to a new PSquareMarkers and other.markers to null via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(instance1, new PSquareMarkers());
        markersField.set(instance2, null);

        // WHEN
        boolean result = instance1.equals(instance2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Equals returns false when markers are equal but getN values are different")
    public void TC10_equalsMarkersEqual_getNNotEqual() throws Exception {
        // GIVEN
        PSquarePercentile instance1 = new PSquarePercentile();
        PSquarePercentile instance2 = new PSquarePercentile();

        // Set markers to new PSquareMarkers via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        PSquareMarkers markers = new PSquareMarkers();
        markersField.set(instance1, markers);
        markersField.set(instance2, markers);

        // Set countOfObservations via reflection
        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(instance1, 10L);
        countField.setLong(instance2, 20L);

        // WHEN
        boolean result = instance1.equals(instance2);

        // THEN
        assertFalse(result);
    }
}