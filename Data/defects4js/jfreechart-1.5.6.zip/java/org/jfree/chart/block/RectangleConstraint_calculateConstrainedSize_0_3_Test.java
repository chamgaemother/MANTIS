package org.jfree.chart.block;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.ui.Size2D;
import org.jfree.data.Range;

import java.lang.reflect.Field;

public class RectangleConstraint_calculateConstrainedSize_0_3_Test {

    @Test
    @DisplayName("WidthConstraintType is RANGE with widthRange.constrain throwing exception")
    void test_TC11() {
        try {
            // Create a RectangleConstraint instance using the constructor with parameters
            RectangleConstraint constraint = new RectangleConstraint(0.0, new Range(0.0, 10.0), LengthConstraintType.RANGE, 0.0, null, LengthConstraintType.FIXED);

            // Create a subclass of Range that throws exception when constrain is called
            Range faultyWidthRange = new Range(0.0, 10.0) {
                @Override
                public double constrain(double value) {
                    throw new RuntimeException("Constrain method exception");
                }
            };

            // Set widthRange via reflection to the faulty range
            Field widthRangeField = RectangleConstraint.class.getDeclaredField("widthRange");
            widthRangeField.setAccessible(true);
            widthRangeField.set(constraint, faultyWidthRange);

            // Initialize base Size2D
            Size2D base = new Size2D(5.0, 5.0);

            // Execute and expect exception
            assertThrows(RuntimeException.class, () -> {
                constraint.calculateConstrainedSize(base);
            });

        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("WidthConstraintType is FIXED with invalid fixed width")
    void test_TC12() {
        try {
            // Create a RectangleConstraint instance using the constructor with parameters
            RectangleConstraint constraint = new RectangleConstraint(-10.0, null, LengthConstraintType.FIXED, 5.0, null, LengthConstraintType.FIXED);

            // Initialize base Size2D
            Size2D base = new Size2D(5.0, 5.0);

            // Execute
            Size2D result = constraint.calculateConstrainedSize(base);

            // Assert appropriate handling, assuming negative width is preserved
            assertEquals(-10.0, result.getWidth(), "Width should be set to fixed invalid value");
            assertEquals(5.0, result.getHeight(), "Height should be set to fixed value");

        } catch (Exception e) {
            fail("Test setup failed: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("WidthConstraintType is NONE and HeightConstraintType is FIXED with zero height")
    void test_TC13() {
        try {
            // Create a RectangleConstraint instance using the constructor with parameters
            RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.NONE, 0.0, null, LengthConstraintType.FIXED);

            // Initialize base Size2D
            Size2D base = new Size2D(100.0, 100.0);

            // Execute
            Size2D result = constraint.calculateConstrainedSize(base);

            // Assert
            assertEquals(base.getWidth(), result.getWidth(), "Width should be equal to base.width");
            assertEquals(0.0, result.getHeight(), "Height should be zero as fixed");

        } catch (Exception e) {
            fail("Test setup failed: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("WidthConstraintType is RANGE and HeightConstraintType is RANGE with boundary values")
    void test_TC14() {
        try {
            // Define boundary ranges
            Range widthRange = new Range(50.0, 150.0);
            Range heightRange = new Range(30.0, 130.0);

            // Create a RectangleConstraint instance using the constructor with parameters
            RectangleConstraint constraint = new RectangleConstraint(0.0, widthRange, LengthConstraintType.RANGE, 0.0, heightRange, LengthConstraintType.RANGE);

            // Initialize base Size2D at boundary values
            Size2D base = new Size2D(50.0, 130.0);

            // Execute
            Size2D result = constraint.calculateConstrainedSize(base);

            // Assert constrained values at boundary
            assertEquals(50.0, result.getWidth(), "Width should be constrained at lower boundary");
            assertEquals(130.0, result.getHeight(), "Height should be constrained at upper boundary");

        } catch (Exception e) {
            fail("Test setup failed: " + e.getMessage());
        }
    }
}