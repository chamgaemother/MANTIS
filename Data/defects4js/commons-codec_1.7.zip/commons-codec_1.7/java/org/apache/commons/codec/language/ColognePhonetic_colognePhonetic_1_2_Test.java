package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_1_2_Test {

    @Test
    @DisplayName("Input with 'G' followed by 'H', should assign code '4'")
    public void TC42_G_followed_by_H_assigns_code_4() {
        // GIVEN
        String input = "Ghost";

        // WHEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);

        // THEN
        assertTrue(result.contains("4"), "Result should contain '4' for 'G' followed by 'H'");
    }

    @Test
    @DisplayName("Input with 'D' before 'Z', should assign code '2'")
    public void TC43_D_before_Z_assigns_code_2() {
        // GIVEN
        String input = "Dazzle";

        // WHEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);

        // THEN
        assertTrue(result.contains("2"), "Result should contain '2' for 'D' before 'Z'");
    }
}