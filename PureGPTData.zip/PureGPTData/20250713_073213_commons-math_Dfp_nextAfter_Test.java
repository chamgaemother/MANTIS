import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DfpTest {

    private final DfpField field = new DfpField(10);
    private final Dfp zero = field.getZero();
    private final Dfp one = field.getOne();
    private final Dfp negativeOne = one.negate();

    @Test
    void testNextAfterTowardsPositive() {
        Dfp two = one.add(one);
        Dfp result = one.nextAfter(two);
        assertTrue(result.greaterThan(one), "Result should be greater than 1.0");
    }

    @Test
    void testNextAfterTowardsNegative() {
        Dfp result = one.nextAfter(zero);
        assertTrue(result.lessThan(one), "Result should be less than 1.0");
    }

    @Test
    void testNextAfterZeroTowardsNonzeroPositive() {
        Dfp result = zero.nextAfter(one);
        assertTrue(result.greaterThan(zero), "Result should be greater than 0.0");
    }

    @Test
    void testNextAfterZeroTowardsNonzeroNegative() {
        Dfp result = zero.nextAfter(negativeOne);
        assertTrue(result.lessThan(zero), "Result should be less than 0.0");
    }

    @Test
    void testNextAfterSameValue() {
        Dfp result = one.nextAfter(one);
        assertTrue(result.equals(one), "Result should be equal to 1.0");
    }

    @Test
    void testNextAfterNegativeTowardsNegative() {
        Dfp result = negativeOne.nextAfter(negativeOne.divide(field.getTwo()));
        assertTrue(result.greaterThan(negativeOne), "Result should be greater than -1.0");
    }

    @Test
    void testNextAfterTowardsInfinity() {
        Dfp infinity = field.newDfp(one.sign, Dfp.INFINITE);
        Dfp result = one.nextAfter(infinity);
        assertTrue(result.greaterThan(one), "Result should be greater than 1.0");
    }

    @Test
    void testNextAfterFromInfinite() {
        Dfp infinity = field.newDfp(one.sign, Dfp.INFINITE);
        Dfp result = infinity.nextAfter(one);
        assertTrue(result.equals(infinity), "NextAfter from infinity should remain infinity");
    }

    @Test
    void testNextAfterNaN() {
        Dfp nan = field.newDfp(one.sign, Dfp.QNAN);
        Dfp result = one.nextAfter(nan);
        assertTrue(result.isNaN(), "NextAfter from NaN should result in NaN");
    }
}