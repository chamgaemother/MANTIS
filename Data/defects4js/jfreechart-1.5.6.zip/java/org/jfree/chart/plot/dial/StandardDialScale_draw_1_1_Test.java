package org.jfree.chart.plot.dial;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;

import static org.mockito.Mockito.*;

public class StandardDialScale_draw_1_1_Test {

    @Test
    @DisplayName("draw with upperBound not evenly divisible by majorTickIncrement, ensuring partial major ticks are not drawn")
    public void TC12_draw_with_non_divisible_majorTickIncrement() throws Exception {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(0, 95, 0, 360, 10, 2);
        scale.setMinorTickLength(5.0);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = mock(DialPlot.class);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // 10 major ticks and 18 minor ticks = 28 draw calls
        verify(g2, times(28)).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("draw with negative lowerBound and upperBound, ensuring ticks are drawn correctly in negative range")
    public void TC13_draw_with_negative_bounds() throws Exception {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(-50, -10, 0, 360, 10, 2);
        scale.setMinorTickLength(5.0);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = mock(DialPlot.class);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // Major ticks at -50, -40, -30, -20, -10: 5 ticks
        // Minor ticks between each major tick: 4 intervals * 2 = 8
        // Total draw calls: 5 + 8 = 13
        verify(g2, times(13)).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("draw with tickLabelsVisible=true and firstTickLabelVisible=false, ensuring the first label is not drawn")
    public void TC14_draw_firstTickLabelInvisible() throws Exception {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(0, 100, 0, 360, 10, 2);
        scale.setTickLabelsVisible(true);
        scale.setFirstTickLabelVisible(false);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = mock(DialPlot.class);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // 10 major ticks and 18 minor ticks = 28 draw calls
        // Since firstTickLabelVisible=false, labels drawn from second tick onwards
        // However, draw calls for lines remain the same
        verify(g2, times(28)).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("draw with tickLabelsVisible=false and firstTickLabelVisible=true, ensuring no labels are drawn")
    public void TC15_draw_labelsInvisible() throws Exception {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(0, 100, 0, 360, 10, 2);
        scale.setTickLabelsVisible(false);
        scale.setFirstTickLabelVisible(true); // Should have no effect
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = mock(DialPlot.class);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // 10 major ticks and 18 minor ticks = 28 draw calls
        verify(g2, times(28)).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("draw with zero minorTickCount and positive minorTickLength, ensuring no minor ticks are drawn")
    public void TC16_draw_zero_minorTickCount_positive_minorTickLength() throws Exception {
        // GIVEN
        StandardDialScale scale = new StandardDialScale(0, 100, 0, 360, 10, 0);
        scale.setMinorTickLength(5.0);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = mock(DialPlot.class);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);
        
        // WHEN
        scale.draw(g2, plot, frame, frame);
        
        // THEN
        // 10 major ticks and 0 minor ticks = 10 draw calls
        verify(g2, times(10)).draw(any(Line2D.class));
    }
}