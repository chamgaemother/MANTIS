import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYErrorRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

import java.awt.*;
import java.awt.geom.Rectangle2D;

class XYErrorRendererTest {

    private XYErrorRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYErrorRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        crosshairState = mock(CrosshairState.class);
    }

    @Test
    void testDrawItemWithValidIntervalXYDataset() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(dataset.getYValue(0, 0)).thenReturn(3.0);
        when(dataset.getStartYValue(0, 0)).thenReturn(2.5);
        when(dataset.getEndYValue(0, 0)).thenReturn(3.5);
        when(dataset.getXValue(0, 0)).thenReturn(1.5);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(mock(RectangleEdge.class));
        when(plot.getRangeAxisEdge()).thenReturn(mock(RectangleEdge.class));
        when(domainAxis.valueToJava2D(anyDouble(), ArgumentMatchers.eq(dataArea), any(RectangleEdge.class)))
                .thenReturn(10.0, 20.0, 15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), ArgumentMatchers.eq(dataArea), any(RectangleEdge.class)))
                .thenReturn(30.0, 25.0, 35.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, atLeastOnce()).draw(any(Line2D.class));
    }

    @Test
    void testDrawItemWithNullDataset() {
        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, crosshairState, 0));
    }

    @Test
    void testDrawItemWithNonIntervalXYDataset() {
        XYDataset dataset = mock(XYDataset.class);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    void testDrawItemWhenXErrorNotDrawn() {
        renderer.setDrawXError(false);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 0)).thenReturn(1.5);
        when(dataset.getYValue(0, 0)).thenReturn(3.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, atLeastOnce()).draw(any(Line2D.class));  // Only Y error bars should be drawn
    }

    @Test
    void testDrawItemWhenYErrorNotDrawn() {
        renderer.setDrawYError(false);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(dataset.getYValue(0, 0)).thenReturn(3.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, atLeastOnce()).draw(any(Line2D.class));  // Only X error bars should be drawn
    }

    @Test
    void testDrawItemPassNotZero() {
        renderer.setDrawXError(true);
        renderer.setDrawYError(true);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, never()).draw(any(Line2D.class));  // No error bars should be drawn for pass != 0
    }
}