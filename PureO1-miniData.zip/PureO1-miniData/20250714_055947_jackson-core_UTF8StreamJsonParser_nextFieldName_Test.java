package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public class UTF8StreamJsonParserTest {

    @Test
    public void testNextFieldNameEmptyObject() throws IOException {
        String json = "{}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameSingleField() throws IOException {
        String json = "{\"name\":\"value\"}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals("name", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameMultipleFields() throws IOException {
        String json = "{\"name1\":\"value1\", \"name2\":123, \"name3\":true}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("name1", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value1", parser.getText());

        assertEquals("name2", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());

        assertEquals("name3", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());

        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameWithNestedObject() throws IOException {
        String json = "{\"outer\":{\"inner\":\"value\"}, \"number\":456}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("outer", parser.nextFieldName());
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("inner", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());

        assertEquals(JsonToken.END_OBJECT, parser.nextToken());

        assertEquals("number", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(456, parser.getIntValue());

        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameWithArray() throws IOException {
        String json = "{\"array\":[1,2,3], \"status\":\"ok\"}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("array", parser.nextFieldName());
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(3, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());

        assertEquals("status", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("ok", parser.getText());

        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameWithEmptyFieldName() throws IOException {
        String json = "{\"\":\"empty\", \"key\":\"value\"}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("empty", parser.getText());

        assertEquals("key", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());

        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameWithSingleQuotes() throws IOException {
        String json = "{'name':'value'}";
        JsonParser parser = new JsonFactory().configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true)
                .createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("name", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());

        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameWithTrailingComma() throws IOException {
        String json = "{\"name1\":\"value1\", \"name2\":\"value2\",}";
        JsonParser parser = new JsonFactory().configure(JsonParser.Feature.ALLOW_TRAILING_COMMA, true)
                .createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("name1", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value1", parser.getText());

        assertEquals("name2", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value2", parser.getText());

        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameWithMissingValue() throws IOException {
        String json = "{\"name1\":\"value1\", \"name2\":}";
        JsonParser parser = new JsonFactory().configure(JsonParser.Feature.ALLOW_MISSING_VALUES, true)
                .createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("name1", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value1", parser.getText());

        assertEquals("name2", parser.nextFieldName());
        assertNull(parser.nextToken());

        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameWithInvalidJson() throws IOException {
        String json = "{\"name1\":value1}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());

        assertEquals("name1", parser.nextFieldName());
        assertThrows(com.fasterxml.jackson.core.JsonParseException.class, () -> {
            parser.nextToken();
        });

        parser.close();
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "{\"name\": \"value\", \"age\": 30, \"active\": true}",
        "{\"empty\":\"\", \"nullValue\":null}",
        "{\"list\":[1,2,3], \"map\":{\"a\":1, \"b\":2}}",
        "{\"unicode\":\"\u00A9\", \"escape\":\"\\n\"}",
        "{\"number\":-123.45e+6}"
    })
    public void testNextFieldNameVariousValidInputs(String json) throws IOException {
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        while (parser.nextFieldName() != null) {
            JsonToken valueToken = parser.nextToken();
            assertNotNull(valueToken);
        }
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    public void testNextFieldNameEmptyInput() throws IOException {
        String json = "";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertNull(parser.nextFieldName());
        parser.close();
    }

    @Test
    public void testNextFieldNameNullInput() {
        assertThrows(NullPointerException.class, () -> {
            new JsonFactory().createParser((ByteArrayInputStream) null);
        });
    }

    @Test
    public void testNextFieldNameMalformedJson() throws IOException {
        String json = "{name:\"value\"}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertThrows(com.fasterxml.jackson.core.JsonParseException.class, () -> {
            parser.nextFieldName();
        });
        parser.close();
    }

    @Test
    public void testNextFieldNameOnlyFieldName() throws IOException {
        String json = "{\"name\":\"value\"}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals("name", parser.nextFieldName());
        parser.close();
    }

    @Test
    public void testNextFieldNameAfterEndObject() throws IOException {
        String json = "{\"name\":\"value\"}";
        JsonParser parser = new JsonFactory().createParser(new ByteArrayInputStream(json.getBytes()));
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals("name", parser.nextFieldName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextFieldName());
        parser.close();
    }
}