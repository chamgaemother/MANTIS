import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.apache.commons.jxpath.JXPathTypeConversionException;
import org.apache.commons.jxpath.NodeSet;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.util.BasicTypeConverter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.lang.reflect.Array;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.jupiter.api.Assertions.*;

public class BasicTypeConverterTest {

    private final BasicTypeConverter converter = new BasicTypeConverter();

    @Test
    void canConvertWithNullObjectReturnsTrue() {
        assertTrue(converter.canConvert(null, String.class));
        assertTrue(converter.canConvert(null, int.class));
    }

    @Test
    void canConvertWithAssignableFromReturnsTrue() {
        assertTrue(converter.canConvert("test", String.class));
        assertTrue(converter.canConvert(5, Integer.class));
    }

    @Test
    void canConvertToStringReturnsTrue() {
        assertTrue(converter.canConvert(123, String.class));
        assertTrue(converter.canConvert(true, String.class));
    }

    @Test
    void canConvertBooleanToNumberReturnsTrue() {
        assertTrue(converter.canConvert(true, Integer.class));
    }

    @Test
    void canConvertNumberToBooleanReturnsTrue() {
        assertTrue(converter.canConvert(1, Boolean.class));
    }

    @Test
    void canConvertStringToPrimitiveReturnsTrue() {
        assertTrue(converter.canConvert("123", Integer.class));
        assertTrue(converter.canConvert("true", Boolean.class));
    }

    @Test
    void canConvertArrayToCollectionReturnsTrue() {
        Integer[] integers = {1, 2, 3};
        assertTrue(converter.canConvert(integers, List.class));
    }

    @Test
    void canConvertArrayToArrayReturnsTrue() {
        Integer[] integers = {1, 2, 3};
        assertTrue(converter.canConvert(integers, Integer[].class));
    }

    @Test
    void canConvertArrayWithNonConvertibleElementReturnsFalse() {
        Object[] objects = {1, "a"};
        assertFalse(converter.canConvert(objects, Integer[].class));
    }

    @Test
    void canConvertCollectionToArrayReturnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertTrue(converter.canConvert(list, Integer[].class));
    }

    @Test
    void canConvertCollectionToCollectionReturnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertTrue(converter.canConvert(list, List.class));
    }

    @Test
    void canConvertCollectionWithNonConvertibleElementReturnsFalse() {
        List<Object> list = Arrays.asList(1, "a");
        assertFalse(converter.canConvert(list, Integer[].class));
    }

    @Test
    void canConvertNodeSetReturnsTrue() {
        NodeSet nodeSet = new NodeSet() {
            @Override
            public List getNodes() {
                return List.of();
            }

            @Override
            public List getPointers() {
                return List.of();
            }

            @Override
            public List getValues() {
                return List.of(1, 2, 3);
            }
        };
        assertTrue(converter.canConvert(nodeSet, Integer[].class));
    }

    @Test
    void canConvertPointerReturnsTrue() {
        Pointer pointer = new BasicTypeConverter.ValuePointer(5);
        assertTrue(converter.canConvert(pointer, Integer.class));
    }

    @Test
    void canConvertWithUnconvertibleTypeReturnsFalse() {
        assertFalse(converter.canConvert(new Object(), AtomicBoolean.class));
    }

    @Test
    void canConvertArrayComponentTypeMismatchReturnsFalse() {
        Object[] array = {1, 2.5};
        assertFalse(converter.canConvert(array, Integer[].class));
    }

    @Test
    void canConvertComplexCollectionReturnsTrue() {
        List<List<Integer>> complexCollection = List.of(List.of(1, 2), List.of(3, 4));
        assertTrue(converter.canConvert(complexCollection, List.class));
    }

    @Test
    void canConvertNonCollectionNonArrayTypeMismatchReturnsFalse() {
        assertFalse(converter.canConvert("test", Integer.class));
    }

    @ParameterizedTest
    @ValueSource(classes = {List.class, Collection.class, Set.class})
    void canConvertEmptyArrayToCollectionReturnsTrue(Class<?> collectionType) {
        Object[] emptyArray = {};
        assertTrue(converter.canConvert(emptyArray, collectionType));
    }

    @ParameterizedTest
    @ValueSource(classes = {List.class, Collection.class, Set.class})
    void canConvertEmptyCollectionToCollectionReturnsTrue(Class<?> collectionType) {
        Collection<Object> emptyCollection = Collections.emptyList();
        assertTrue(converter.canConvert(emptyCollection, collectionType));
    }

    @Test
    void canConvertNullToPrimitiveReturnsTrue() {
        assertTrue(converter.canConvert(0, int.class));
    }

    @Test
    void canConvertNullToPrimitiveWrapperReturnsTrue() {
        assertTrue(converter.canConvert(0, Integer.class));
    }
}