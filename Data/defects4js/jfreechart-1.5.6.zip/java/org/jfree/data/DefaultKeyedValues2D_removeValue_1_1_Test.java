package org.jfree.data;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.data.DefaultKeyedValues2D;

public class DefaultKeyedValues2D_removeValue_1_1_Test {

    @Test
    @DisplayName("Remove a value from a row that contains other non-null values, ensuring the row is not removed")
    public void TC10_removeValueWithoutRowDeletion() {
        // Arrange
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(10, "Row1", "Col1");
        data.addValue(20, "Row1", "Col2");
        
        // Act
        data.removeValue("Row1", "Col1");
        
        // Assert
        assertNull(data.getValue("Row1", "Col1"), "Value should be null after removal");
        assertEquals(1, data.getRowCount(), "Row count should remain unchanged");
        assertEquals(2, data.getColumnCount(), "Column count should remain unchanged");
    }

    @Test
    @DisplayName("Remove a value from a column that exists in multiple rows, ensuring the column is not removed if other rows still contain values")
    public void TC11_removeValueWithoutColumnDeletion() {
        // Arrange
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(30, "Row1", "Col3");
        data.addValue(40, "Row2", "Col3");
        
        // Act
        data.removeValue("Row1", "Col3");
        
        // Assert
        assertNull(data.getValue("Row1", "Col3"), "Value should be null after removal");
        assertEquals(2, data.getRowCount(), "Row count should remain unchanged");
        assertEquals(1, data.getColumnCount(), "Column count should remain unchanged");
    }
}