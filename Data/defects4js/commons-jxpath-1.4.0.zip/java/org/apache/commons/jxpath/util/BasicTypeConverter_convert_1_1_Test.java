package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.util.BasicTypeConverter;
import org.apache.commons.jxpath.JXPathTypeConversionException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

public class BasicTypeConverter_convert_1_1_Test {

    @Test
    @DisplayName("Converting a non-empty String to Character type")
    public void TC13() {
        // GIVEN
        String object = "A";
        Class<?> toType = Character.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        
        // WHEN
        Object result = converter.convert(object, toType);
        
        // THEN
        assertEquals('A', result);
    }

    @Test
    @DisplayName("Converting an empty Collection to a Set type")
    public void TC14() {
        // GIVEN
        Collection<Object> object = new ArrayList<>();
        Class<?> toType = Set.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        
        // WHEN
        Object result = converter.convert(object, toType);
        
        // THEN
        assertTrue(result instanceof Set);
        assertTrue(((Set<?>) result).isEmpty());
    }

    @Test
    @DisplayName("Converting a Collection with multiple elements to a List type")
    public void TC15() {
        // GIVEN
        Collection<String> object = Arrays.asList("alpha", "beta", "gamma");
        Class<?> toType = List.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        
        // WHEN
        Object result = converter.convert(object, toType);
        
        // THEN
        assertTrue(result instanceof List);
        assertEquals(3, ((List<?>) result).size());
        assertTrue(((List<?>) result).containsAll(object));
    }

    @Test
    @DisplayName("Converting a String to Integer type")
    public void TC16() {
        // GIVEN
        String object = "123";
        Class<?> toType = Integer.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        
        // WHEN
        Object result = converter.convert(object, toType);
        
        // THEN
        assertEquals(123, result);
    }

    @Test
    @DisplayName("Converting a String to Integer with invalid format, expecting JXPathTypeConversionException")
    public void TC17() {
        // GIVEN
        String object = "abc";
        Class<?> toType = Integer.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        
        // WHEN & THEN
        assertThrows(JXPathTypeConversionException.class, () -> {
            converter.convert(object, toType);
        });
    }
}