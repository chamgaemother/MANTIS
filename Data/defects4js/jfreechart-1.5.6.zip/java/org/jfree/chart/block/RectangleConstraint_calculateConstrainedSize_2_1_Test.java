package org.jfree.chart.block;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jfree.chart.ui.Size2D;
import org.jfree.data.Range;
import static org.junit.jupiter.api.Assertions.*;

public class RectangleConstraint_calculateConstrainedSize_2_1_Test {

    @Test
    @DisplayName("calculateConstrainedSize with WidthConstraintType FIXED set to zero and HeightConstraintType FIXED")
    public void TC19_calculateConstrainedSize_withFixedWidthZeroAndFixedHeight() {
        // Arrange
        RectangleConstraint constraint = new RectangleConstraint(
                0.0, null, LengthConstraintType.FIXED,
                50.0, null, LengthConstraintType.FIXED
        );
        Size2D base = new Size2D(100.0, 50.0);

        // Act
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assert
        assertEquals(0.0, result.getWidth(), "Width should be constrained to 0.0");
        assertEquals(50.0, result.getHeight(), "Height should remain at 50.0");
    }

    @Test
    @DisplayName("calculateConstrainedSize with WidthConstraintType RANGE and base width exceeding maximum, HeightConstraintType RANGE and base height below minimum")
    public void TC20_calculateConstrainedSize_withWidthRangeExceedingMaxAndHeightRangeBelowMin() {
        // Arrange
        Range widthRange = new Range(80.0, 120.0);
        Range heightRange = new Range(40.0, 60.0);
        RectangleConstraint constraint = new RectangleConstraint(
                0.0, widthRange, LengthConstraintType.RANGE,
                0.0, heightRange, LengthConstraintType.RANGE
        );
        Size2D base = new Size2D(150.0, 30.0);

        // Act
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assert
        assertEquals(120.0, result.getWidth(), "Width should be constrained to 120.0");
        assertEquals(40.0, result.getHeight(), "Height should be constrained to 40.0");
    }
}