
package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryToHexDigit_0_2_Test {

    @Test
    @DisplayName("Returns 'b' when src.length > srcPos + 3 and src[srcPos+3] is true, src[srcPos+2] is false, src[srcPos+1] is true, src[srcPos] is true")
    public void TC06() {
        // GIVEN
        boolean[] src = new boolean[] {true, true, false, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('b', result);
    }

    @Test
    @DisplayName("Returns 'a' when src.length > srcPos + 3 and src[srcPos+3] is true, src[srcPos+2] is false, src[srcPos+1] is true, src[srcPos] is false")
    public void TC07() {
        // GIVEN
        boolean[] src = new boolean[] {false, true, false, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('a', result);
    }

    @Test
    @DisplayName("Returns '9' when src.length > srcPos + 3 and src[srcPos+3], src[srcPos+2], src[srcPos+1] are false and src[srcPos] is true")
    public void TC08() {
        // GIVEN
        boolean[] src = new boolean[] {true, false, false, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('9', result);
    }

    @Test
    @DisplayName("Returns '8' when src.length > srcPos + 3 and src[srcPos+3], src[srcPos+2], src[srcPos+1], src[srcPos] are all false")
    public void TC09() {
        // GIVEN
        boolean[] src = new boolean[] {false, false, false, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('8', result);
    }

    @Test
    @DisplayName("Returns '7' when src.length > srcPos + 2 and src[srcPos+3] is false, src[srcPos+2] is true, src[srcPos+1] is true, src[srcPos] is true")
    public void TC10() {
        // GIVEN
        boolean[] src = new boolean[] {true, true, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('7', result);
    }

}