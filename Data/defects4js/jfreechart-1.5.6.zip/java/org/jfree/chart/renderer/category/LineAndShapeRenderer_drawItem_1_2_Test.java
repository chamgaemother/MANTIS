package org.jfree.chart.renderer.category;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

/**
 * JUnit 5 test class for LineAndShapeRenderer#drawItem method scenarios.
 */
public class LineAndShapeRenderer_drawItem_1_2_Test {

    @Test
    @DisplayName("drawItem handles useFillPaint correctly when filling shapes")
    void TC11_drawItem_handles_useFillPaint_correctly_when_filling_shapes() throws Exception {
        // GIVEN
        LineAndShapeRenderer renderer = new LineAndShapeRenderer(true, true);

        // Use reflection to set private fields
        Field useFillPaintField = LineAndShapeRenderer.class.getDeclaredField("useFillPaint");
        useFillPaintField.setAccessible(true);
        useFillPaintField.setBoolean(renderer, true);

        Field drawOutlinesField = LineAndShapeRenderer.class.getDeclaredField("drawOutlines");
        drawOutlinesField.setAccessible(true);
        drawOutlinesField.setBoolean(renderer, true);

        // Configure renderer to have shapes visible and filled
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesShapesFilled(0, true);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Setup dataset
        when(dataset.getValue(0, 0)).thenReturn(10);

        // Setup plot
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDataset(0)).thenReturn(dataset);

        // Setup axes
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                .thenReturn(100.0);

        // Define row and column
        int row = 0;
        int column = 0;
        int pass = 1;

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        // Capture the shape used
        ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
        // Verify that fill was called with the correct shape
        verify(g2).fill(shapeCaptor.capture());
        Shape filledShape = shapeCaptor.getValue();
        assertNotNull(filledShape, "Shape should be filled with fill paint");

        // Verify that draw was called with the correct shape
        verify(g2).draw(filledShape);

        // Verify paint settings
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    @DisplayName("drawItem does not fill shape when getItemShapeFilled returns false")
    void TC12_drawItem_does_not_fill_shape_when_getItemShapeFilled_returns_false() throws Exception {
        // GIVEN
        LineAndShapeRenderer renderer = new LineAndShapeRenderer(true, true);

        // Use reflection to set private fields
        Field useFillPaintField = LineAndShapeRenderer.class.getDeclaredField("useFillPaint");
        useFillPaintField.setAccessible(true);
        useFillPaintField.setBoolean(renderer, false);

        Field drawOutlinesField = LineAndShapeRenderer.class.getDeclaredField("drawOutlines");
        drawOutlinesField.setAccessible(true);
        drawOutlinesField.setBoolean(renderer, true);

        // Configure renderer to have shapes visible but not filled
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesShapesFilled(0, false);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Setup dataset
        when(dataset.getValue(0, 0)).thenReturn(20);

        // Setup plot
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDataset(0)).thenReturn(dataset);

        // Setup axes
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any()))
                .thenReturn(60.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                .thenReturn(120.0);

        // Define row and column
        int row = 0;
        int column = 0;
        int pass = 1;

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        // Verify that fill was NOT called
        verify(g2, never()).fill(any(Shape.class));

        // Capture the shape used
        ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
        // Verify that draw was called with the correct shape
        verify(g2).draw(shapeCaptor.capture());
        Shape drawnShape = shapeCaptor.getValue();
        assertNotNull(drawnShape, "Shape should be outlined without being filled");

        // Verify paint settings
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    @DisplayName("drawItem draws shape without outlines when drawOutlines is false")
    void TC13_drawItem_draws_shape_without_outlines_when_drawOutlines_is_false() throws Exception {
        // GIVEN
        LineAndShapeRenderer renderer = new LineAndShapeRenderer(true, true);

        // Use reflection to set private fields
        Field useFillPaintField = LineAndShapeRenderer.class.getDeclaredField("useFillPaint");
        useFillPaintField.setAccessible(true);
        useFillPaintField.setBoolean(renderer, false);

        Field drawOutlinesField = LineAndShapeRenderer.class.getDeclaredField("drawOutlines");
        drawOutlinesField.setAccessible(true);
        drawOutlinesField.setBoolean(renderer, false);

        // Configure renderer to have shapes visible and filled
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesShapesFilled(0, true);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Setup dataset
        when(dataset.getValue(0, 0)).thenReturn(30);

        // Setup plot
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDataset(0)).thenReturn(dataset);

        // Setup axes
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any()))
                .thenReturn(70.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                .thenReturn(140.0);

        // Define row and column
        int row = 0;
        int column = 0;
        int pass = 1;

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        // Capture the shape used
        ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
        // Verify that fill was called with the correct shape
        verify(g2).fill(shapeCaptor.capture());
        Shape filledShape = shapeCaptor.getValue();
        assertNotNull(filledShape, "Shape should be filled without an outline");

        // Verify that draw was NOT called for outline
        verify(g2, never()).draw(any(Shape.class));

        // Verify paint settings
        verify(g2).setPaint(any(Paint.class));
    }
}
