package org.jfree.chart.plot.flow;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.FlowEntity;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.data.flow.FlowDataset;
import org.jfree.chart.ui.RectangleInsets;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Mockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Test class for FlowPlot#draw method.
 */
@ExtendWith(MockitoExtension.class)
public class FlowPlot_draw_2_1_Test {

    @Mock
    private FlowDataset mockDataset;

    @Mock
    private Graphics2D mockGraphics2D;

    @Mock
    private PlotState mockPlotState;

    @Mock
    private PlotRenderingInfo mockPlotRenderingInfo;

    @Mock
    private ChartRenderingInfo mockChartRenderingInfo;

    @Mock
    private EntityCollection mockEntityCollection;

    /**
     * Test TC31: draw method handles null toolTipGenerator by not adding tooltips to FlowEntities.
     */
//     @Test
//     @DisplayName("TC31: draw method handles null toolTipGenerator by not adding tooltips to FlowEntities")
//     void TC31_draw_handles_null_toolTipGenerator() {
        // Arrange
//         when(mockDataset.getStageCount()).thenReturn(1);
//         when(mockDataset.getSources(0)).thenReturn(java.util.Arrays.asList("Source1"));
//         when(mockDataset.getDestinations(0)).thenReturn(java.util.Arrays.asList("Destination1"));
//         when(mockDataset.getFlow(0, "Source1", "Destination1")).thenReturn(100);
// 
//         when(mockPlotRenderingInfo.getOwner()).thenReturn(mockChartRenderingInfo);
//         when(mockChartRenderingInfo.getEntityCollection()).thenReturn(mockEntityCollection);
// 
//         FlowPlot plot = new FlowPlot(mockDataset);
//         plot.setToolTipGenerator(null);
// 
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
//         Point2D anchor = new Point2D.Double(400, 300);
// 
        // Act
//         plot.draw(mockGraphics2D, area, anchor, mockPlotState, mockPlotRenderingInfo);
// 
        // Assert
//         verify(mockEntityCollection).add(argThat(new ArgumentMatcher<FlowEntity>() {
//             @Override
//             public boolean matches(FlowEntity entity) {
//                 return entity instanceof FlowEntity && entity.getToolTip() == null;
//             }
//         }));
//     }

    /**
     * Test TC32: draw method throws exception when getInsets fails during execution.
     */
   @Test
   @DisplayName("TC32: draw method throws exception when getInsets fails during execution")
   void TC32_draw_throws_exception_when_getInsets_fails() {
        // Arrange
        when(mockDataset.getStageCount()).thenReturn(1);
        when(mockDataset.getSources(0)).thenReturn(java.util.Arrays.asList("Source1"));
        when(mockDataset.getDestinations(0)).thenReturn(java.util.Arrays.asList("Destination1"));
        when(mockDataset.getFlow(0, "Source1", "Destination1")).thenReturn(100);

        when(mockPlotRenderingInfo.getOwner()).thenReturn(mockChartRenderingInfo);
        when(mockChartRenderingInfo.getEntityCollection()).thenReturn(null);

        // Spy on FlowPlot to mock getInsets
        FlowPlot plot = spy(new FlowPlot(mockDataset));
        doReturn(new RectangleInsets(0, 0, 0, 0)).when(plot).getInsets();

        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            plot.draw(mockGraphics2D, area, anchor, mockPlotState, mockPlotRenderingInfo);
        }, "draw should propagate exception from getInsets");

        assertEquals("getInsets failure", exception.getMessage());
    }
}