package org.apache.commons.math3.geometry.euclidean.twod.hull;

import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class AklToussaintHeuristic_reducePoints_0_2_Test {

    @Test
    @DisplayName("reducePoints with multiple points all inside the quadrilateral")
    void TC06_reducePoints_allPointsInside() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(1, 1);
        Vector2D p2 = new Vector2D(2, 2);
        Vector2D p3 = new Vector2D(3, 1);
        Vector2D p4 = new Vector2D(2, 0);
        Vector2D p5 = new Vector2D(2, 1);
        Vector2D p6 = new Vector2D(2, 1.5);
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4, p5, p6);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertAll("Verify result",
            () -> assertEquals(4, result.size(), "Result size should be 4"),
            () -> assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4)), "Result should contain quadrilateral points")
        );
    }

    @Test
    @DisplayName("reducePoints with multiple points all outside the quadrilateral")
    void TC07_reducePoints_allPointsOutside() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(-1, -1);
        Vector2D p2 = new Vector2D(-2, -2);
        Vector2D p3 = new Vector2D(-3, -1);
        Vector2D p4 = new Vector2D(-2, 0);
        Vector2D p5 = new Vector2D(-2, -1);
        Vector2D p6 = new Vector2D(-2, -1.5);
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4, p5, p6);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertAll("Verify result",
            () -> assertEquals(8, result.size(), "Result size should be 8"),
            () -> assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4, p5, p6)), "Result should contain all original points")
        );
    }

    @Test
    @DisplayName("reducePoints with some points lying exactly on the quadrilateral edges")
    void TC08_reducePoints_pointsOnEdges() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(1, 1);
        Vector2D p2 = new Vector2D(2, 2);
        Vector2D p3 = new Vector2D(3, 1);
        Vector2D p4 = new Vector2D(2, 0);
        Vector2D pEdge1 = new Vector2D(2, 1);
        Vector2D pEdge2 = new Vector2D(2, 1.5);
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4, pEdge1, pEdge2);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4, pEdge1, pEdge2)), "Result should include quadrilateral points and points on the edges");
    }

    @Test
    @DisplayName("reducePoints with duplicate points in the collection")
    void TC09_reducePoints_withDuplicatePoints() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(1, 1);
        Vector2D p2 = new Vector2D(2, 2);
        Vector2D p3 = new Vector2D(3, 1);
        Vector2D p4 = new Vector2D(2, 0);
        Collection<Vector2D> points = Arrays.asList(p1, p2, p2, p3, p4, p4);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertTrue(result.containsAll(Arrays.asList(p1, p2, p3, p4)), "Result should handle duplicates correctly and contain unique points");
    }

    @Test
    @DisplayName("reducePoints with points having boundary values for x and y coordinates")
    void TC10_reducePoints_boundaryCoordinatePoints() throws Exception {
        // GIVEN
        Vector2D pMinX = new Vector2D(Double.MIN_VALUE, 1);
        Vector2D pMaxX = new Vector2D(Double.MAX_VALUE, 2);
        Vector2D pMinY = new Vector2D(1, Double.MIN_VALUE);
        Vector2D pMaxY = new Vector2D(2, Double.MAX_VALUE);
        Collection<Vector2D> points = Arrays.asList(pMinX, pMaxX, pMinY, pMaxY);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertTrue(result.containsAll(Arrays.asList(pMinX, pMaxX, pMinY, pMaxY)), "Result should accurately reflect points with boundary coordinates");
    }
}