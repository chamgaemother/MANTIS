package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CodecEncoding_getCodec_0_1_Test {

    @Test
    @DisplayName("Throws Error when canonicalCodec length is modified")
    void testCanonicalCodecLengthModified() {
        Field canonicalCodecField = null;
        BHSDCodec[] originalCanonicalCodec = null;
        try {
            // Use reflection to modify the private static field
            canonicalCodecField = CodecEncoding.class.getDeclaredField("canonicalCodec");
            canonicalCodecField.setAccessible(true);
            originalCanonicalCodec = (BHSDCodec[]) canonicalCodecField.get(null);
            BHSDCodec[] modifiedCanonicalCodec = new BHSDCodec[100]; // Altered length
            canonicalCodecField.set(null, modifiedCanonicalCodec);

            // Assertion
            Throwable error = assertThrows(Error.class, () ->
                CodecEncoding.getCodec(0, InputStream.nullInputStream(), new DefaultCodec()));
            assertEquals("Canonical encodings have been incorrectly modified", error.getMessage());
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        } finally {
            // Restore original state
            try {
                if (canonicalCodecField != null) {
                     canonicalCodecField.set(null, originalCanonicalCodec);
                }
            } catch (Exception e) {
                // Log or handle restoration failure
            }
        }
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when value is less than zero")
    void testValueLessThanZero() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            CodecEncoding.getCodec(-1, InputStream.nullInputStream(), new DefaultCodec());
        });
        assertEquals("Encoding cannot be less than zero", exception.getMessage());
    }

    @Test
    @DisplayName("Returns defaultCodec for value 0")
    void testReturnDefaultCodecForValueZero() {
        Codec defaultCodec = new DefaultCodec();
        Codec result = CodecEncoding.getCodec(0, InputStream.nullInputStream(), defaultCodec);
        assertEquals(defaultCodec, result);
    }

    @Test
    @DisplayName("Returns canonicalCodec[value] for 0 < value <= 115")
    void testReturnCanonicalCodecWithinBounds() {
        try {
            // Use reflection to modify the private static field
            Field canonicalCodecField = CodecEncoding.class.getDeclaredField("canonicalCodec");
            canonicalCodecField.setAccessible(true);
            BHSDCodec[] canonicalCodec = new BHSDCodec[116];
            BHSDCodec expectedCodec = new BHSDCodec(1, 256);
            canonicalCodec[50] = expectedCodec;
            canonicalCodecField.set(null, canonicalCodec);

            // Assertion
            Codec result = CodecEncoding.getCodec(50, InputStream.nullInputStream(), new DefaultCodec());
            assertEquals(expectedCodec, result);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("Throws EOFException when no data available for value 116 read")
    void testEOFExceptionForValue116() {
        InputStream exhaustedInputStream = new ByteArrayInputStream(new byte[0]); // No data
        EOFException exception = assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(116, exhaustedInputStream, new DefaultCodec());
        });
        assertEquals("End of buffer read whilst trying to decode codec", exception.getMessage());
    }
}

// The assumed necessary minimal implementation for testing purposes
class DefaultCodec extends Codec {
    // Implement necessary methods or define as needed
}

class SomeCodec extends Codec {
    // Implement necessary methods or define as needed
}
