package org.jfree.chart.plot;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.jfree.chart.needle.ArrowNeedle;
import org.jfree.chart.needle.MeterNeedle;
import java.awt.Color;
import java.lang.reflect.Field;

public class CompassPlot_setSeriesNeedle_2_1_Test {

    @Test
    @DisplayName("setSeriesNeedle with a valid type=0 and index=0 correctly updates the first needle")
    void TC14_setSeriesNeedle_validType0_index0() throws Exception {
        // GIVEN
        CompassPlot compassPlot = new CompassPlot();
        int type = 0;
        int index = 0;

        // WHEN
        compassPlot.setSeriesNeedle(index, type);

        // THEN
        // Use reflection to access the private 'seriesNeedle' field
        Field seriesNeedleField = CompassPlot.class.getDeclaredField("seriesNeedle");
        seriesNeedleField.setAccessible(true);
        MeterNeedle[] seriesNeedle = (MeterNeedle[]) seriesNeedleField.get(compassPlot);

        assertNotNull(seriesNeedle, "seriesNeedle array should not be null");
        assertTrue(seriesNeedle.length > index, "seriesNeedle array should have enough elements");

        MeterNeedle needle = seriesNeedle[index];
        assertNotNull(needle, "Needle at index should not be null");
        assertTrue(needle instanceof ArrowNeedle, "Needle should be an instance of ArrowNeedle");

        // Further assertions using reflection to access properties
        // Access 'fillPaint' field
        Field fillPaintField = needle.getClass().getDeclaredField("fillPaint");
        fillPaintField.setAccessible(true);
        Color fillPaint = (Color) fillPaintField.get(needle);
        assertEquals(Color.RED, fillPaint, "Fill paint should be Color.RED");

        // Access 'highlightPaint' field
        Field highlightPaintField = needle.getClass().getDeclaredField("highlightPaint");
        highlightPaintField.setAccessible(true);
        Color highlightPaint = (Color) highlightPaintField.get(needle);
        assertEquals(Color.WHITE, highlightPaint, "Highlight paint should be Color.WHITE");
    }

    @Test
    @DisplayName("setSeriesNeedle with type=10 throws IllegalArgumentException")
    void TC15_setSeriesNeedle_invalidType10() {
        // GIVEN
        CompassPlot compassPlot = new CompassPlot();
        int type = 10;
        int index = 0;

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            compassPlot.setSeriesNeedle(index, type);
        }, "Expected setSeriesNeedle to throw, but it didn't");
        assertEquals("Unrecognised type.", exception.getMessage(), "Exception message should match");
    }
}