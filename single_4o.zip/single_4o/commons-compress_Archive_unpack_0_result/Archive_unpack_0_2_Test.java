package org.apache.commons.compress.harmony.unpack200;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.jar.JarOutputStream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Archive_unpack_0_2_Test {

    @Test
    @DisplayName("Unpack and delete input path if removePackFile is true")
    void testRemovePackFileTrue() throws Exception {
        // Given
        Path tempFile = Files.createTempFile("testfile", ".pack");
        Archive archive = new Archive(tempFile.toString(), tempFile.toString());

        Field removePackFileField = Archive.class.getDeclaredField("removePackFile");
        removePackFileField.setAccessible(true);
        removePackFileField.setBoolean(archive, true);

        // When
        archive.unpack();

        // Then
        assertFalse(Files.exists(tempFile), "Input file should be deleted after unpacking");
    }

    @Test
    @DisplayName("Verify closeStreams correctly closes streams after processing")
    void testCloseStreamsTrue() throws Exception {
        // Given
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Archive archive = new Archive(new ByteArrayInputStream(new byte[0]), new JarOutputStream(outputStream));

        Field closeStreamsField = Archive.class.getDeclaredField("closeStreams");
        closeStreamsField.setAccessible(true);
        closeStreamsField.setBoolean(archive, true);

        // When
        archive.unpack();

        // Then
        assertTrue(isStreamClosed(archive.inputStream), "Input stream should be closed");
        assertTrue(isStreamClosed(new JarOutputStream(outputStream)), "Output stream should be closed");
    }

    @Test
    @DisplayName("Test exception handling and ensure streams are closed")
    void testExceptionHandling() throws Exception {
        // Given
        InputStream input = new InputStream() {
            @Override
            public int read() throws IOException { throw new IOException("Forced exception for testing"); }
            @Override
            public int available() throws IOException { return 1; }
        };
        Archive archive = new Archive(input, new JarOutputStream(new ByteArrayOutputStream()));

        Field closeStreamsField = Archive.class.getDeclaredField("closeStreams");
        closeStreamsField.setAccessible(true);
        closeStreamsField.setBoolean(archive, true);

        // When & Then
        assertThrows(IOException.class, archive::unpack);
        assertTrue(isStreamClosed(archive.inputStream), "Input stream should be closed after exception");
    }

    @Test
    @DisplayName("Check overrideDeflateHint modification during segment unpacking")
    void testOverrideDeflateHintModification() throws Exception {
        // Given
        InputStream input = new ByteArrayInputStream(new byte[0]);
        JarOutputStream output = new JarOutputStream(new ByteArrayOutputStream());
        Archive archive = new Archive(input, output);

        Field overrideDeflateHintField = Archive.class.getDeclaredField("overrideDeflateHint");
        overrideDeflateHintField.setAccessible(true);
        overrideDeflateHintField.setBoolean(archive, true);

        // When
        archive.unpack();

        // Then
        // Verify if the deflate hint override logic hits by checking internal handling logic directly.
        // This typically needs segment mocking to fully verify which is beyond this straightforward test.
    }

    @Test
    @DisplayName("No removal of pack file when inputPath is null")
    void testNoRemoveWhenInputPathIsNull() throws Exception {
        // Given
        Archive archive = new Archive(new ByteArrayInputStream(new byte[0]), new JarOutputStream(new ByteArrayOutputStream()));

        Field removePackFileField = Archive.class.getDeclaredField("removePackFile");
        removePackFileField.setAccessible(true);
        removePackFileField.setBoolean(archive, true);

        // When
        archive.unpack();

        // Then
        // Since the inputPath is null, no deletion should have occurred.
        // Asserting primarily for non-exception and correct logic path run.
    }

    private boolean isStreamClosed(InputStream is) {
        try {
            is.read();
            return false;
        } catch (IOException e) {
            return true;
        }
    }

    private boolean isStreamClosed(OutputStream os) {
        try {
            os.write(0);
            return false;
        } catch (IOException e) {
            return true;
        }
    }
}
