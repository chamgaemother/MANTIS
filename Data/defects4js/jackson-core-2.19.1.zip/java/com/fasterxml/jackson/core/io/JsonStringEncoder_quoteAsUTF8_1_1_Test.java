package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.io.JsonStringEncoder;

public class JsonStringEncoder_quoteAsUTF8_1_1_Test {

    @Test
    @DisplayName("quoteAsUTF8 with a string containing the boundary character at 0x7F")
    void TC21_quoteAsUTF8_boundaryCharacter_0x7F() {
        String text = "\u007F";
        byte[] expected = {(byte)0x7F};
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);
        assertArrayEquals(expected, result, "Byte array should correctly encode the 0x7F character.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with a string containing the boundary character at 0x80")
    void TC22_quoteAsUTF8_boundaryCharacter_0x80() {
        String text = "\u0080";
        byte[] expected = {(byte)0xC2, (byte)0x80};
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);
        assertArrayEquals(expected, result, "Byte array should correctly encode the 0x80 character.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with a string containing the boundary character at 0x7FF")
    void TC23_quoteAsUTF8_boundaryCharacter_0x7FF() {
        String text = "\u07FF";
        byte[] expected = {(byte)0xDF, (byte)0xBF};
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);
        assertArrayEquals(expected, result, "Byte array should correctly encode the 0x7FF character.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with a string containing the boundary character at 0x800")
    void TC24_quoteAsUTF8_boundaryCharacter_0x800() {
        String text = "\u0800";
        byte[] expected = {(byte)0xE0, (byte)0xA0, (byte)0x80};
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);
        assertArrayEquals(expected, result, "Byte array should correctly encode the 0x800 character.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with a string containing the maximum Unicode code point 0x10FFFF")
    void TC25_quoteAsUTF8_maxUnicodeCodePoint() {
        String text = "\uDBFF\uDFFF"; // 0x10FFFF
        byte[] expected = {(byte)0xF4, (byte)0x8F, (byte)0xBF, (byte)0xBF};
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);
        assertArrayEquals(expected, result, "Byte array should correctly encode the 0x10FFFF character.");
    }
}