import org.apache.commons.math3.analysis.differentiation.DSCompiler;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DSCompilerTest {

    // Test boundary values for getCompiler method
    @Test
    public void testGetCompilerWithZeroParametersZeroOrder() throws NumberIsTooLargeException {
        DSCompiler compiler = DSCompiler.getCompiler(0, 0);
        assertNotNull(compiler);
        assertEquals(0, compiler.getFreeParameters());
        assertEquals(0, compiler.getOrder());
    }

    @Test
    public void testGetCompilerWithPositiveParametersZeroOrder() throws NumberIsTooLargeException {
        DSCompiler compiler = DSCompiler.getCompiler(3, 0);
        assertNotNull(compiler);
        assertEquals(3, compiler.getFreeParameters());
        assertEquals(0, compiler.getOrder());
    }

    @Test
    public void testGetCompilerWithZeroParametersPositiveOrder() throws NumberIsTooLargeException {
        DSCompiler compiler = DSCompiler.getCompiler(0, 3);
        assertNotNull(compiler);
        assertEquals(0, compiler.getFreeParameters());
        assertEquals(3, compiler.getOrder());
    }

    @Test
    public void testGetCompilerWithPositiveParametersPositiveOrder() throws NumberIsTooLargeException {
        DSCompiler compiler = DSCompiler.getCompiler(3, 3);
        assertNotNull(compiler);
        assertEquals(3, compiler.getFreeParameters());
        assertEquals(3, compiler.getOrder());
    }

    // Test higher values to see if caching and atomic reference mechanics work correctly
    @Test
    public void testGetCompilerWithLargeValues() throws NumberIsTooLargeException {
        DSCompiler compiler = DSCompiler.getCompiler(10, 10);
        assertNotNull(compiler);
        assertEquals(10, compiler.getFreeParameters());
        assertEquals(10, compiler.getOrder());
    }

    // Test the boundaries and ensure they do not throw exceptions unless invalid
    @Test
    public void testGetCompilerEdgeCases() throws NumberIsTooLargeException {
        assertDoesNotThrow(() -> {
            DSCompiler.getCompiler(Integer.MAX_VALUE, 1);
        });

        assertDoesNotThrow(() -> {
            DSCompiler.getCompiler(1, Integer.MAX_VALUE);
        });
    }

    // Test throwing of the exception
    @Test
    public void testGetCompilerThrowsNumberIsTooLargeException() {
        assertThrows(NumberIsTooLargeException.class, () -> DSCompiler.getCompiler(Integer.MAX_VALUE, Integer.MAX_VALUE));
    }
}