package org.jfree.chart.plot;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.plot.SeriesRenderingOrder;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.util.Args;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class XYPlot_render_0_2_Test {

    @Test
    @DisplayName("Render method uses default renderer when renderer at index is null")
    void TC06_renderUsesDefaultRendererWhenRendererAtIndexIsNull() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        plot.setDataset(index, dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setDomainAxis(index, xAxis);
        plot.setRangeAxis(index, yAxis);
        // Mock the plot renderer to return null
        when(plot.getRenderer(index)).thenReturn(null);
        XYItemRenderer defaultRenderer = mock(XYItemRenderer.class);
        // Ensure the default renderer is returned
        when(defaultRenderer.getPassCount()).thenReturn(1);
        when(plot.getRenderer()).thenReturn(defaultRenderer);
        when(plot.getSeriesRenderingOrder()).thenReturn(SeriesRenderingOrder.FORWARD);
        XYItemRendererState state = mock(XYItemRendererState.class);
        // Use initialized state
        when(defaultRenderer.initialise(g2, dataArea, plot, dataset, info)).thenReturn(state);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result);
        verify(defaultRenderer, atLeastOnce()).drawItem(any(Graphics2D.class), eq(state), eq(dataArea), eq(info), eq(plot), eq(xAxis), eq(yAxis), eq(dataset), anyInt(), anyInt(), eq(crosshairState), anyInt());
    }

    @Test
    @DisplayName("Render method returns true without rendering when no renderer is available")
    void TC07_renderReturnsTrueWithoutRenderer() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        plot.setDataset(index, dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setDomainAxis(index, xAxis);
        plot.setRangeAxis(index, yAxis);
        // Mock the plot renderer to return null
        when(plot.getRenderer(index)).thenReturn(null);
        when(plot.getRenderer()).thenReturn(null);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Render method executes rendering with forward series order, single pass, single series, single item")
    void TC08_renderForwardSinglePassSingleSeriesSingleItem() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        plot.setDataset(index, dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setDomainAxis(index, xAxis);
        plot.setRangeAxis(index, yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        // Ensure the proper renderer is returned
        when(plot.getRenderer(index)).thenReturn(renderer);
        when(renderer.getPassCount()).thenReturn(1);
        when(plot.getSeriesRenderingOrder()).thenReturn(SeriesRenderingOrder.FORWARD);
        XYItemRendererState state = mock(XYItemRendererState.class);
        when(renderer.initialise(g2, dataArea, plot, dataset, info)).thenReturn(state);
        when(state.getProcessVisibleItemsOnly()).thenReturn(false);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result);
        verify(renderer, atLeastOnce()).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(xAxis), eq(yAxis), eq(dataset), anyInt(), anyInt(), eq(crosshairState), anyInt());
    }

    @Test
    @DisplayName("Render method executes rendering with forward series order, multiple passes, multiple series and items")
    void TC09_renderForwardMultiplePassesMultipleSeriesItems() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(3);
        when(dataset.getItemCount(anyInt())).thenReturn(5);
        plot.setDataset(index, dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setDomainAxis(index, xAxis);
        plot.setRangeAxis(index, yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        // Ensure the proper renderer is returned
        when(plot.getRenderer(index)).thenReturn(renderer);
        when(renderer.getPassCount()).thenReturn(2);
        when(plot.getSeriesRenderingOrder()).thenReturn(SeriesRenderingOrder.FORWARD);
        XYItemRendererState state = mock(XYItemRendererState.class);
        when(renderer.initialise(g2, dataArea, plot, dataset, info)).thenReturn(state);
        when(state.getProcessVisibleItemsOnly()).thenReturn(false);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result);
        verify(renderer, atLeastOnce()).drawItem(eq(g2), any(XYItemRendererState.class), eq(dataArea), eq(info), eq(plot), eq(xAxis), eq(yAxis), eq(dataset), anyInt(), anyInt(), eq(crosshairState), anyInt());
    }

    @Test
    @DisplayName("Render method executes rendering with reverse series order, single pass, single series, single item")
    void TC10_renderReverseSinglePassSingleSeriesSingleItem() {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        int index = 0;
        PlotRenderingInfo info = new PlotRenderingInfo(null);
        CrosshairState crosshairState = new CrosshairState();
        XYPlot plot = new XYPlot();
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        plot.setDataset(index, dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setDomainAxis(index, xAxis);
        plot.setRangeAxis(index, yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        // Ensure the proper renderer is returned
        when(plot.getRenderer(index)).thenReturn(renderer);
        when(renderer.getPassCount()).thenReturn(1);
        when(plot.getSeriesRenderingOrder()).thenReturn(SeriesRenderingOrder.REVERSE);
        XYItemRendererState state = mock(XYItemRendererState.class);
        when(renderer.initialise(g2, dataArea, plot, dataset, info)).thenReturn(state);
        when(state.getProcessVisibleItemsOnly()).thenReturn(false);

        // WHEN
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // THEN
        assertTrue(result);
        verify(renderer, atLeastOnce()).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(xAxis), eq(yAxis), eq(dataset), anyInt(), anyInt(), eq(crosshairState), anyInt());
    }
}
