package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_2_2_Test {

    // Helper classes for testing inner classes and interfaces
    private static class Outer {
        static class Inner implements MyInterface {}
    }

    private interface MyInterface {}

    @Test
    @DisplayName("cls is array class (int[]), toClass is non-assignable array class (Number[]) with autoboxing=true; expect false")
    void TC50() {
        Class<?> cls = int[].class;
        Class<?> toClass = Number[].class;
        boolean autoboxing = true;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertFalse(result);
    }

    @Test
    @DisplayName("cls is inner class (Outer.Inner), toClass is its outer class (Outer) with autoboxing=true; expect false")
    void TC51() {
        Class<?> cls = Outer.Inner.class;
        Class<?> toClass = Outer.class;
        boolean autoboxing = true;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertFalse(result);
    }

    @Test
    @DisplayName("cls is inner class (Outer.Inner), toClass is interface implemented by Outer (MyInterface) with autoboxing=true; expect false")
    void TC52() {
        Class<?> cls = Outer.Inner.class;
        Class<?> toClass = MyInterface.class;
        boolean autoboxing = true;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertFalse(result);
    }

    @Test
    @DisplayName("cls is null, toClass is non-primitive with autoboxing=true; expect true")
    void TC53() {
        Class<?> cls = null;
        Class<?> toClass = Object.class;
        boolean autoboxing = true;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertTrue(result);
    }

    @Test
    @DisplayName("cls is primitive (byte), toClass is assignable primitive (short) with autoboxing=true; expect true")
    void TC54() {
        Class<?> cls = byte.class;
        Class<?> toClass = short.class;
        boolean autoboxing = true;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertTrue(result);
    }
}