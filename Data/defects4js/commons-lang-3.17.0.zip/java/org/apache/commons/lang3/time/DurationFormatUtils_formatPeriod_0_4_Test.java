package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.TimeZone;
import org.apache.commons.lang3.time.DurationFormatUtils;

public class DurationFormatUtils_formatPeriod_0_4_Test {

    @Test
    @DisplayName("Duration with only 'd' token, ensuring days are calculated correctly")
    public void test_TC16_d_token() {
        // GIVEN
        long startMillis = 1609459200000L; // Jan 1, 2021
        long endMillis = 1609545600000L; // Jan 2, 2021
        String format = "d";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        assertEquals("1", result);
    }

    @Test
    @DisplayName("Duration with mixed token presence and absence")
    public void test_TC17_mixed_tokens() {
        // GIVEN
        long startMillis = 1609459200000L;
        long endMillis = 1609462800000L; // +1 hour
        String format = "H:s";
        boolean padWithZeros = false;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        assertEquals("1:0", result);
    }

    @Test
    @DisplayName("Duration with only 'S' token, verifying milliseconds display")
    public void test_TC18_S_token() {
        // GIVEN
        long startMillis = 1609459200000L;
        long endMillis = 1609459200100L; // +100 milliseconds
        String format = "S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        assertEquals("100", result);
    }

    @Test
    @DisplayName("Duration spanning multiple days and hours")
    public void test_TC19_multiple_days_hours() {
        // GIVEN
        long startMillis = 1609459200000L; // Jan 1, 2021 00:00 GMT
        long endMillis = 1609632000000L; // Jan 3, 2021 00:00 GMT
        String format = "d:H";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        assertEquals("2:0", result);
    }

    @Test
    @DisplayName("Duration with all tokens excluded, expecting empty string")
    public void test_TC20_all_tokens_excluded() {
        // GIVEN
        long startMillis = 1609459200000L;
        long endMillis = 1609462800000L; // +1 hour
        String format = "";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");

        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);

        // THEN
        assertEquals("", result);
    }
}