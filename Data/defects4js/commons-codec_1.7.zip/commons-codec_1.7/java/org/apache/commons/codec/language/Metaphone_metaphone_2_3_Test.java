package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Generated JUnit 5 test class for Metaphone.metaphone method.
 * This class includes tests to augment branch coverage based on enhanced scenarios.
 */
public class Metaphone_metaphone_2_3_Test {

    @Test
    @DisplayName("metaphone word with 'WH' not followed by 'R' or 'H' retains 'W'")
    public void TC63_metaphone_WH_not_followed_by_R_or_H_retains_W() throws Exception {
        // GIVEN
        String txt = "whist";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("WST", result);
    }

    @Test
    @DisplayName("metaphone word with 'W' followed by 'R' removes 'W'")
    public void TC64_metaphone_W_followed_by_R_removes_W() throws Exception {
        // GIVEN
        String txt = "write";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("RT", result);
    }

    @Test
    @DisplayName("metaphone word with 'WH' followed by 'H' converts 'WH' to 'W'")
    public void TC65_metaphone_WH_followed_by_H_converts_WH_to_W() throws Exception {
        // GIVEN
        String txt = "whale";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("WL", result);
    }

    @Test
    @DisplayName("metaphone word with 'X' not at initial position converts to 'KS'")
    public void TC66_metaphone_X_not_at_initial_position_converts_to_KS() throws Exception {
        // GIVEN
        String txt = "box";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("KS", result);
    }

    @Test
    @DisplayName("metaphone word with 'X' at initial position converts to 'S'")
    public void TC67_metaphone_X_at_initial_position_converts_to_S() throws Exception {
        // GIVEN
        String txt = "xenon";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("SN", result);
    }
}