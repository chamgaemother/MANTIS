package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.util.FastMath;

public class FastMath_pow_0_5_Test {

    @Test
    @DisplayName("pow(x, y) returns -8.0 when y is an odd integer and x is negative")
    void pow_negative_x_odd_integer_y() {
        double x = -2.0;
        double y = 3.0;
        double result = FastMath.pow(x, y);
        assertEquals(-8.0, result);
    }

    @Test
    @DisplayName("pow(x, y) correctly computes fractional exponent for positive x")
    void pow_positive_x_fractional_y() {
        double x = 9.0;
        double y = 0.5;
        double result = FastMath.pow(x, y);
        assertEquals(3.0, result, 1e-10);
    }

    @Test
    @DisplayName("pow(x, y) handles very small x with large negative y returning Double.POSITIVE_INFINITY")
    void pow_small_x_large_negative_y() {
        double x = 1e-10;
        double y = -1e10;
        double result = FastMath.pow(x, y);
        assertEquals(Double.POSITIVE_INFINITY, result);
    }
}