import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DefaultStatisticalCategoryDatasetTest {

    private DefaultStatisticalCategoryDataset dataset;

    @BeforeEach
    void setUp() {
        dataset = new DefaultStatisticalCategoryDataset();
    }

    @Test
    void testAddValidData() {
        dataset.add(5.0, 1.5, "Row1", "Col1");
        assertEquals(5.0, dataset.getMeanValue("Row1", "Col1"));
        assertEquals(1.5, dataset.getStdDevValue("Row1", "Col1"));
    }

    @Test
    void testAddNullMeanValue() {
        dataset.add(null, 1.5, "Row2", "Col2");
        assertNull(dataset.getMeanValue("Row2", "Col2"));
        assertEquals(1.5, dataset.getStdDevValue("Row2", "Col2"));
    }

    @Test
    void testAddNullStdDevValue() {
        dataset.add(5.0, null, "Row3", "Col3");
        assertEquals(5.0, dataset.getMeanValue("Row3", "Col3"));
        assertNull(dataset.getStdDevValue("Row3", "Col3"));
    }

    @Test
    void testAddNullMeanAndStdDev() {
        dataset.add(null, null, "Row4", "Col4");
        assertNull(dataset.getMeanValue("Row4", "Col4"));
        assertNull(dataset.getStdDevValue("Row4", "Col4"));
    }

    @Test
    void testAddExistingDataWithHigherValues() {
        dataset.add(5.0, 2.0, "Row5", "Col5");
        dataset.add(6.0, 3.0, "Row5", "Col5");
        assertEquals(6.0, dataset.getMeanValue("Row5", "Col5"));
        assertEquals(3.0, dataset.getStdDevValue("Row5", "Col5"));
    }

    @Test
    void testAddUpdatingMaximumRangeValue() {
        dataset.add(5.0, 1.0, "Row6", "Col6");
        dataset.add(6.0, 0.5, "Row7", "Col7");
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

    @Test
    void testAddUpdatingMinimumRangeValue() {
        dataset.add(5.0, 1.0, "Row8", "Col8");
        dataset.add(4.0, 0.5, "Row9", "Col9");
        assertEquals(4.0, dataset.getRangeLowerBound(false));
    }

    @Test
    void testAddMinAndMaxWithStdDev() {
        dataset.add(5.0, 2.0, "Row10", "Col10");
        dataset.add(6.0, 1.0, "Row11", "Col11");
        dataset.add(4.0, 3.0, "Row12", "Col12");
        assertEquals(9.0, dataset.getRangeUpperBound(true));
        assertEquals(1.0, dataset.getRangeLowerBound(true));
    }
}