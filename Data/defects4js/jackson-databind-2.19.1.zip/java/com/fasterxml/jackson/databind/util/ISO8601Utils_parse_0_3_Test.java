package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParsePosition;
import java.text.ParseException;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601Utils_parse_0_3_Test {

    @Test
    @DisplayName("Parse successfully handles time with milliseconds (three digits)")
    void TC11_parseTimeWithMillisecondsThreeDigits() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00.123Z";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN
        Date result = ISO8601Utils.parse(date, pos);
        
        // THEN
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        calendar.set(Calendar.MILLISECOND, 123);
        Date expected = calendar.getTime();
        
        assertEquals(expected, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse successfully handles time with milliseconds (two digits)")
    void TC12_parseTimeWithMillisecondsTwoDigits() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00.12Z";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN
        Date result = ISO8601Utils.parse(date, pos);
        
        // THEN
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        calendar.set(Calendar.MILLISECOND, 120);
        Date expected = calendar.getTime();
        
        assertEquals(expected, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse successfully handles time with milliseconds (one digit)")
    void TC13_parseTimeWithMillisecondsOneDigit() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00.1Z";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN
        Date result = ISO8601Utils.parse(date, pos);
        
        // THEN
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        calendar.set(Calendar.MILLISECOND, 100);
        Date expected = calendar.getTime();
        
        assertEquals(expected, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse throws ParseException when seconds are invalid (>63)")
    void TC14_parseInvalidSecondsThrowsParseException() {
        // GIVEN
        String date = "2023-10-05T14:30:64Z";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        
        assertTrue(exception.getMessage().contains("invalid seconds"));
    }

    @Test
    @DisplayName("Parse throws ParseException when timezone indicator is missing")
    void TC15_parseMissingTimezoneIndicatorThrowsIllegalArgumentException() {
        // GIVEN
        String date = "2023-10-05T14:30:00";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        
        assertEquals("No time zone indicator", exception.getMessage());
    }
}