package org.apache.commons.math3.analysis.solvers;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;

import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.util.Decimal64;
import org.apache.commons.math3.util.Decimal64Field;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FieldBracketingNthOrderBrentSolver_solve_0_1_Test {

    @Test
    @DisplayName("solve throws NullArgumentException when the function f is null")
    void TC01_solve_throws_NullArgumentException_when_f_is_null() {
        // GIVEN
        int maxEval = 100;
        RealFieldUnivariateFunction<Decimal64> f = null;
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 min = field.getZero();
        Decimal64 max = field.getOne();
        Decimal64 startValue = field.getOne().divide(2);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1.0e-6);
        Decimal64 absoluteAccuracy = new Decimal64(1.0e-10);
        Decimal64 functionValueAccuracy = new Decimal64(1.0e-10);
        int maximalOrder = 5;

        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(relativeAccuracy, absoluteAccuracy, functionValueAccuracy, maximalOrder);

        // WHEN & THEN
        assertThrows(NullArgumentException.class,
                () -> solver.solve(maxEval, f, min, max, startValue, allowedSolution));
    }

    @Test
    @DisplayName("solve throws NumberIsTooSmallException when maximalOrder is less than 2")
    void TC02_solve_throws_NumberIsTooSmallException_when_maximalOrder_is_less_than_2() {
        // GIVEN
        Decimal64 relativeAccuracy = new Decimal64(1.0e-6);
        Decimal64 absoluteAccuracy = new Decimal64(1.0e-10);
        Decimal64 functionValueAccuracy = new Decimal64(1.0e-10);
        int maximalOrder = 1; // Invalid

        // WHEN & THEN
        assertThrows(NumberIsTooSmallException.class,
                () -> new FieldBracketingNthOrderBrentSolver<>(relativeAccuracy, absoluteAccuracy, functionValueAccuracy, maximalOrder));
    }

    @Test
    @DisplayName("solve returns startValue when it is an exact root")
    void TC03_solve_returns_startValue_when_it_is_an_exact_root() throws Exception {
        // GIVEN
        int maxEval = 100;
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 min = field.getZero();
        Decimal64 max = field.getOne();
        Decimal64 startValue = field.getOne().divide(2);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1.0e-6);
        Decimal64 absoluteAccuracy = new Decimal64(1.0e-10);
        Decimal64 functionValueAccuracy = new Decimal64(1.0e-10);
        int maximalOrder = 5;

        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(relativeAccuracy, absoluteAccuracy, functionValueAccuracy, maximalOrder);

        RealFieldUnivariateFunction<Decimal64> f = value -> {
            if (value.equals(startValue)) return Decimal64Field.getInstance().getZero();
            if (value.equals(min)) return new Decimal64(1.0);
            if (value.equals(max)) return new Decimal64(-1.0);
            return value; // For safety, although should not be reached
        };

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        assertEquals(startValue, result, "The solver should return the startValue as it is an exact root.");
    }

    @Test
    @DisplayName("solve returns min when f(min) is an exact root")
    void TC04_solve_returns_min_when_f_min_is_an_exact_root() throws Exception {
        // GIVEN
        int maxEval = 100;
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 min = field.getZero();
        Decimal64 max = field.getOne();
        Decimal64 startValue = field.getOne().divide(2);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1.0e-6);
        Decimal64 absoluteAccuracy = new Decimal64(1.0e-10);
        Decimal64 functionValueAccuracy = new Decimal64(1.0e-10);
        int maximalOrder = 5;

        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(relativeAccuracy, absoluteAccuracy, functionValueAccuracy, maximalOrder);

        RealFieldUnivariateFunction<Decimal64> f = value -> {
            if (value.equals(min)) return Decimal64Field.getInstance().getZero();
            if (value.equals(startValue)) return new Decimal64(1.0);
            if (value.equals(max)) return new Decimal64(-1.0);
            return value; // For safety, although should not be reached
        };

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        assertEquals(min, result, "The solver should return min as f(min) is an exact root.");
    }

    @Test
    @DisplayName("solve returns max when f(max) is an exact root")
    void TC05_solve_returns_max_when_f_max_is_an_exact_root() throws Exception {
        // GIVEN
        int maxEval = 100;
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 min = field.getZero();
        Decimal64 max = field.getOne();
        Decimal64 startValue = field.getOne().divide(2);
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        Decimal64 relativeAccuracy = new Decimal64(1.0e-6);
        Decimal64 absoluteAccuracy = new Decimal64(1.0e-10);
        Decimal64 functionValueAccuracy = new Decimal64(1.0e-10);
        int maximalOrder = 5;

        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
                new FieldBracketingNthOrderBrentSolver<>(relativeAccuracy, absoluteAccuracy, functionValueAccuracy, maximalOrder);

        RealFieldUnivariateFunction<Decimal64> f = value -> {
            if (value.equals(max)) return Decimal64Field.getInstance().getZero();
            if (value.equals(min)) return new Decimal64(1.0);
            if (value.equals(startValue)) return new Decimal64(-1.0);
            return value; // For safety, although should not be reached
        };

        // WHEN
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // THEN
        assertEquals(max, result, "The solver should return max as f(max) is an exact root.");
    }
}