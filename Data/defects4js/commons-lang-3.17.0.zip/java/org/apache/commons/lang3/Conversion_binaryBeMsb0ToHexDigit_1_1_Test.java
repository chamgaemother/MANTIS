package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryBeMsb0ToHexDigit_1_1_Test {

    @Test
    @DisplayName("Returns 'b' when pos >= 3, src[pos-3] is true, src[pos-2] is false, src[pos-1] is true, and src[pos] is true")
    void TC13_binaryBeMsb0ToHexDigit_returns_b() {
        // GIVEN
        boolean[] src = {true, false, true, true};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);

        // THEN
        assertEquals('b', result);
    }

    @Test
    @DisplayName("Returns '2' when pos >= 3, src[pos-3] is false, src[pos-2] is true, src[pos-1] is false, and src[pos] is false")
    void TC14_binaryBeMsb0ToHexDigit_returns_2() {
        // GIVEN
        boolean[] src = {false, true, false, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);

        // THEN
        assertEquals('2', result);
    }

    @Test
    @DisplayName("Returns '3' when pos >= 3, src[pos-3] is false, src[pos-2] is true, src[pos-1] is true, and src[pos] is false")
    void TC15_binaryBeMsb0ToHexDigit_returns_3() {
        // GIVEN
        boolean[] src = {false, true, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);

        // THEN
        assertEquals('3', result);
    }

    @Test
    @DisplayName("Returns '5' when pos >= 3, src[pos-3] is false, src[pos-2] is true, src[pos-1] is false, and src[pos] is true")
    void TC16_binaryBeMsb0ToHexDigit_returns_5() {
        // GIVEN
        boolean[] src = {false, true, false, true};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);

        // THEN
        assertEquals('5', result);
    }

    @Test
    @DisplayName("Throws NullPointerException when src array is null")
    void TC17_binaryBeMsb0ToHexDigit_throws_NullPointerException() {
        // GIVEN
        boolean[] src = null;
        int srcPos = 0;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> Conversion.binaryBeMsb0ToHexDigit(src, srcPos));
    }
}