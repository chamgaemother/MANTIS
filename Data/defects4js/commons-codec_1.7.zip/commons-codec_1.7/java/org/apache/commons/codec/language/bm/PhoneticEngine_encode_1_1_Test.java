package org.apache.commons.codec.language.bm;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.codec.language.bm.PhoneticEngine;
import org.apache.commons.codec.language.bm.NameType;
import org.apache.commons.codec.language.bm.RuleType;
import org.apache.commons.codec.language.bm.Languages.LanguageSet;

import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Collections;

public class PhoneticEngine_encode_1_1_Test {
//
//    @Test
//    @DisplayName("encode with empty Languages.LanguageSet to test handling of no languages")
//    public void test_TC14_encode_with_empty_LanguageSet() {
//        // Given
//        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, false);
//        String input = "StandardInput";
//        LanguageSet languageSet = Languages.LanguageSet.empty();
//
//        // When
//        String result = engine.encode(input, languageSet);
//
//        // Then
//        // Verify that the encoded result is as expected when languageSet is empty
//        assertNotNull(result, "Encoded result should not be null.");
//    }

    @Test
    @DisplayName("encode with multiple languages in Languages.LanguageSet to test multi-language processing")
    public void test_TC15_encode_with_multiple_languages() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, false);
        String input = "MultiLanguageInput";
        Set<String> languages = new HashSet<>(Arrays.asList("english", "french"));
        LanguageSet languageSet = Languages.LanguageSet.from(languages);

        // When
        String result = engine.encode(input, languageSet);

        // Then
        // Verify that the encoded result accurately reflects multi-language phonetic encoding
        assertNotNull(result, "Encoded result should not be null.");
    }

    @Test
    @DisplayName("encode with input containing characters that do not match any phonetic rules to test dropping of unmatched characters")
    public void test_TC16_encode_with_unmatched_characters() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, false);
        String input = "1234!@#$";
        Set<String> languages = new HashSet<>(Collections.singletonList("english"));
        LanguageSet languageSet = Languages.LanguageSet.from(languages);

        // When
        String result = engine.encode(input, languageSet);

        // Then
        // Verify that all unmatched characters are dropped, resulting in an empty encoding
        assertEquals("", result, "All unmatched characters should be dropped, resulting in an empty encoding.");
    }

    @Test
    @DisplayName("encode with input that exceeds maxPhonemes to test phoneme builder's max limit handling")
    public void test_TC17_encode_exceeding_maxPhonemes() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, false, 5); // Set maxPhonemes to 5 for testing
        String input = "ExcessivelyLongInputToTriggerMaxPhonemes";
        Set<String> languages = new HashSet<>(Collections.singletonList("english"));
        LanguageSet languageSet = Languages.LanguageSet.from(languages);

        // When
        String result = engine.encode(input, languageSet);

        // Then
        // Verify that the encoded phonemes do not exceed the maxPhonemes limit
        String[] phonemes = result.split("\\|");
        assertTrue(phonemes.length <= 5, "Encoded phonemes should not exceed the maxPhonemes limit.");
    }

    @Test
    @DisplayName("encode with null input to test handling of null input string")
    public void test_TC18_encode_with_null_input() {
        // Given
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, false);
        String input = null;
        Set<String> languages = new HashSet<>(Collections.singletonList("english"));
        LanguageSet languageSet = Languages.LanguageSet.from(languages);

        // When & Then
        // Verify that a NullPointerException is thrown for null input
        assertThrows(NullPointerException.class, () -> {
            engine.encode(input, languageSet);
        }, "Encoding a null input should throw NullPointerException.");
    }
}
