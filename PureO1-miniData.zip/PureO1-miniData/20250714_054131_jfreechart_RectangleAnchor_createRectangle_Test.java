package org.jfree.chart.ui;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class RectangleAnchorTest {

    @Nested
    @DisplayName("createRectangle Tests for CENTER Anchor")
    class CenterAnchorTests {
        @Test
        @DisplayName("Create rectangle with CENTER anchor")
        void testCreateRectangleCenter() {
            Size2D size = new Size2D(100.0, 50.0);
            double anchorX = 200.0;
            double anchorY = 100.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.CENTER);
            assertNotNull(rect);
            assertEquals(150.0, rect.getX());
            assertEquals(75.0, rect.getY());
            assertEquals(100.0, rect.getWidth());
            assertEquals(50.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for TOP Anchor")
    class TopAnchorTests {
        @Test
        @DisplayName("Create rectangle with TOP anchor")
        void testCreateRectangleTop() {
            Size2D size = new Size2D(80.0, 40.0);
            double anchorX = 150.0;
            double anchorY = 50.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.TOP);
            assertNotNull(rect);
            assertEquals(110.0, rect.getX());
            assertEquals(50.0, rect.getY());
            assertEquals(80.0, rect.getWidth());
            assertEquals(40.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for BOTTOM Anchor")
    class BottomAnchorTests {
        @Test
        @DisplayName("Create rectangle with BOTTOM anchor")
        void testCreateRectangleBottom() {
            Size2D size = new Size2D(120.0, 60.0);
            double anchorX = 300.0;
            double anchorY = 200.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.BOTTOM);
            assertNotNull(rect);
            assertEquals(240.0, rect.getX());
            assertEquals(140.0, rect.getY());
            assertEquals(120.0, rect.getWidth());
            assertEquals(60.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for LEFT Anchor")
    class LeftAnchorTests {
        @Test
        @DisplayName("Create rectangle with LEFT anchor")
        void testCreateRectangleLeft() {
            Size2D size = new Size2D(50.0, 100.0);
            double anchorX = 75.0;
            double anchorY = 150.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.LEFT);
            assertNotNull(rect);
            assertEquals(75.0, rect.getX());
            assertEquals(100.0, rect.getY());
            assertEquals(50.0, rect.getWidth());
            assertEquals(100.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for RIGHT Anchor")
    class RightAnchorTests {
        @Test
        @DisplayName("Create rectangle with RIGHT anchor")
        void testCreateRectangleRight() {
            Size2D size = new Size2D(60.0, 80.0);
            double anchorX = 200.0;
            double anchorY = 160.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.RIGHT);
            assertNotNull(rect);
            assertEquals(140.0, rect.getX());
            assertEquals(120.0, rect.getY());
            assertEquals(60.0, rect.getWidth());
            assertEquals(80.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for TOP_LEFT Anchor")
    class TopLeftAnchorTests {
        @Test
        @DisplayName("Create rectangle with TOP_LEFT anchor")
        void testCreateRectangleTopLeft() {
            Size2D size = new Size2D(90.0, 45.0);
            double anchorX = 50.0;
            double anchorY = 25.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.TOP_LEFT);
            assertNotNull(rect);
            assertEquals(50.0, rect.getX());
            assertEquals(25.0, rect.getY());
            assertEquals(90.0, rect.getWidth());
            assertEquals(45.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for TOP_RIGHT Anchor")
    class TopRightAnchorTests {
        @Test
        @DisplayName("Create rectangle with TOP_RIGHT anchor")
        void testCreateRectangleTopRight() {
            Size2D size = new Size2D(70.0, 35.0);
            double anchorX = 120.0;
            double anchorY = 30.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.TOP_RIGHT);
            assertNotNull(rect);
            assertEquals(50.0, rect.getX());
            assertEquals(30.0, rect.getY());
            assertEquals(70.0, rect.getWidth());
            assertEquals(35.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for BOTTOM_LEFT Anchor")
    class BottomLeftAnchorTests {
        @Test
        @DisplayName("Create rectangle with BOTTOM_LEFT anchor")
        void testCreateRectangleBottomLeft() {
            Size2D size = new Size2D(60.0, 60.0);
            double anchorX = 80.0;
            double anchorY = 120.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.BOTTOM_LEFT);
            assertNotNull(rect);
            assertEquals(80.0, rect.getX());
            assertEquals(60.0, rect.getY());
            assertEquals(60.0, rect.getWidth());
            assertEquals(60.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for BOTTOM_RIGHT Anchor")
    class BottomRightAnchorTests {
        @Test
        @DisplayName("Create rectangle with BOTTOM_RIGHT anchor")
        void testCreateRectangleBottomRight() {
            Size2D size = new Size2D(100.0, 50.0);
            double anchorX = 250.0;
            double anchorY = 200.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.BOTTOM_RIGHT);
            assertNotNull(rect);
            assertEquals(150.0, rect.getX());
            assertEquals(150.0, rect.getY());
            assertEquals(100.0, rect.getWidth());
            assertEquals(50.0, rect.getHeight());
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for Null Inputs")
    class NullInputTests {
        @Test
        @DisplayName("Create rectangle with null dimensions")
        void testCreateRectangleNullDimensions() {
            double anchorX = 100.0;
            double anchorY = 100.0;
            assertThrows(NullPointerException.class, () -> {
                RectangleAnchor.createRectangle(null, anchorX, anchorY, RectangleAnchor.CENTER);
            });
        }

        @Test
        @DisplayName("Create rectangle with null anchor")
        void testCreateRectangleNullAnchor() {
            Size2D size = new Size2D(100.0, 50.0);
            double anchorX = 100.0;
            double anchorY = 100.0;
            assertThrows(NullPointerException.class, () -> {
                RectangleAnchor.createRectangle(size, anchorX, anchorY, null);
            });
        }
    }

    @Nested
    @DisplayName("createRectangle Tests for Edge Cases")
    class EdgeCaseTests {
        @Test
        @DisplayName("Create rectangle with zero width and height")
        void testCreateRectangleZeroSize() {
            Size2D size = new Size2D(0.0, 0.0);
            double anchorX = 0.0;
            double anchorY = 0.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.CENTER);
            assertNotNull(rect);
            assertEquals(0.0, rect.getX());
            assertEquals(0.0, rect.getY());
            assertEquals(0.0, rect.getWidth());
            assertEquals(0.0, rect.getHeight());
        }

        @Test
        @DisplayName("Create rectangle with negative width")
        void testCreateRectangleNegativeWidth() {
            Size2D size = new Size2D(-50.0, 50.0);
            double anchorX = 100.0;
            double anchorY = 100.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.CENTER);
            assertNotNull(rect);
            assertEquals(125.0, rect.getX());
            assertEquals(75.0, rect.getY());
            assertEquals(-50.0, rect.getWidth());
            assertEquals(50.0, rect.getHeight());
        }

        @Test
        @DisplayName("Create rectangle with negative height")
        void testCreateRectangleNegativeHeight() {
            Size2D size = new Size2D(50.0, -50.0);
            double anchorX = 100.0;
            double anchorY = 100.0;
            Rectangle2D rect = RectangleAnchor.createRectangle(size, anchorX, anchorY, RectangleAnchor.CENTER);
            assertNotNull(rect);
            assertEquals(75.0, rect.getX());
            assertEquals(125.0, rect.getY());
            assertEquals(50.0, rect.getWidth());
            assertEquals(-50.0, rect.getHeight());
        }
    }
}