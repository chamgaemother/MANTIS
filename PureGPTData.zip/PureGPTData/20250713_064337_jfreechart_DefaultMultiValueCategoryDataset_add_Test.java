import org.jfree.data.statistics.DefaultMultiValueCategoryDataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.chart.util.Args;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DefaultMultiValueCategoryDatasetTest {

    @Test
    public void testAddWithValidInputs() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        List<Double> values = Arrays.asList(1.0, 2.0, 3.0);
        dataset.add(values, "Row1", "Col1");
        assertEquals(2.0, dataset.getValue("Row1", "Col1"));
    }

    @Test
    public void testAddWithNaNValues() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        List<Double> values = Arrays.asList(1.0, Double.NaN, 3.0);
        dataset.add(values, "Row1", "Col1");
        assertEquals(2.0, dataset.getValue("Row1", "Col1"));
    }

    @Test
    public void testAddWithEmptyValues() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        List<Double> values = Collections.emptyList();
        dataset.add(values, "Row1", "Col1");
        assertNull(dataset.getValue("Row1", "Col1"));
    }

    @Test
    public void testAddUpdatesRange() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        List<Double> values1 = Arrays.asList(1.0, 2.0, 3.0);
        List<Double> values2 = Arrays.asList(-1.0, 4.0);
        dataset.add(values1, "Row1", "Col1");
        dataset.add(values2, "Row2", "Col2");
        assertEquals(new Range(-1.0, 4.0), dataset.getRangeBounds(false));
    }

    @Test
    public void testAddNullValues() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        assertThrows(IllegalArgumentException.class, () -> dataset.add(null, "Row1", "Col1"));
    }

    @Test
    public void testAddNullRowKey() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        List<Double> values = Arrays.asList(1.0, 2.0, 3.0);
        assertThrows(IllegalArgumentException.class, () -> dataset.add(values, null, "Col1"));
    }

    @Test
    public void testAddNullColumnKey() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        List<Double> values = Arrays.asList(1.0, 2.0, 3.0);
        assertThrows(IllegalArgumentException.class, () -> dataset.add(values, "Row1", null));
    }

    @Test
    public void testAddSendsDatasetChangeEvent() {
        DefaultMultiValueCategoryDataset dataset = spy(new DefaultMultiValueCategoryDataset());
        List<Double> values = Arrays.asList(1.0, 2.0, 3.0);
        dataset.add(values, "Row1", "Col1");
        verify(dataset, times(1)).fireDatasetChanged();
    }
}