package org.jfree.data;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class DefaultKeyedValues2D_removeValue_2_1_Test {

    @Test
    @DisplayName("Remove a value from a column present in multiple rows without removing the column")
    public void TC14_removeValue_partialColumnRemoval() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(100, "Row1", "ColA");
        data.addValue(200, "Row2", "ColA");

        // WHEN
        data.removeValue("Row1", "ColA");

        // THEN
        assertNull(data.getValue("Row1", "ColA"), "Value at 'Row1', 'ColA' should be null");
        assertEquals(2, data.getRowCount(), "Row count should remain 2");
        assertEquals(1, data.getColumnCount(), "Column count should remain 1");
        assertNotNull(data.getValue("Row2", "ColA"), "Value at 'Row2', 'ColA' should still exist");
    }
    
    @Test
    @DisplayName("Remove a value causing both row and column to be removed when they become empty")
    public void TC15_removeValue_rowAndColumnDeletion() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(300, "RowX", "ColY");

        // WHEN
        data.removeValue("RowX", "ColY");

        // THEN
        assertNull(data.getValue("RowX", "ColY"), "Value at 'RowX', 'ColY' should be null");
        assertEquals(0, data.getRowCount(), "Row count should be 0");
        assertEquals(0, data.getColumnCount(), "Column count should be 0");
    }
}