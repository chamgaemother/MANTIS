package org.apache.commons.lang3;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.RandomStringUtils;
import java.util.Random;

public class RandomStringUtils_random_2_2_Test {

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars={@, #, $, %}, random) generates alphanumerical string from specified chars")
    void TC11_alphanumerical_chars_array() {
        // Given
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = {'@', '#', '$', '%', 'A', '1', 'b', '2', 'C', '3'};
        Random random = new Random();

        // When
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(count, result.length());
        assertTrue(result.chars().allMatch(c -> new String(chars).indexOf(c) >= 0 && Character.isLetterOrDigit(c)), "All characters should be alphanumerical and from the provided chars array");
    }

    @Test
    @DisplayName("random(count=10, start=0, end=0, letters=true, numbers=true, chars=null, random) handles multiple iterations without throwing exceptions")
    void TC12_multiple_iterations() {
        // Given
        int count = 10;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // When
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(count, result.length());
        assertTrue(result.chars().allMatch(Character::isLetterOrDigit), "All characters should be alphanumerical");
    }

    @Test
    @DisplayName("random(count=15, start=0, end=0, letters=false, numbers=true, chars=null, random) generates numeric string within full Unicode range")
    void TC13_numeric_full_unicode() {
        // Given
        int count = 15;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // When
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(count, result.length());
        assertTrue(result.chars().allMatch(c -> Character.isDigit(c) && c >= 0 && c <= Character.MAX_CODE_POINT), "All characters should be digits within the full Unicode range");
    }

    @Test
    @DisplayName("random(count=7, start=65, end=65, letters=true, numbers=false, chars=null, random) throws IllegalArgumentException when end <= start after adjustment for letters")
    void TC14_invalid_adjusted_end_for_letters() {
        // Given
        int count = 7;
        int start = 65;
        int end = 65;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // When & Then
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
        assertEquals("Parameter end (65) must be greater than start (65)", exception.getMessage());
    }

    @Test
    @DisplayName("random(count=4, start=-5, end=10, letters=false, numbers=true, chars=null, random) throws IllegalArgumentException for negative start")
    void TC15_negative_start() {
        // Given
        int count = 4;
        int start = -5;
        int end = 10;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // When & Then
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
        assertEquals("Character positions MUST be >= 0", exception.getMessage());
    }

}