// package org.jfree.chart.renderer.xy;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// 
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.CandlestickRenderer;
// import org.jfree.chart.renderer.xy.XYItemRendererState;
// import org.jfree.chart.util.PublicCloneable;
// import org.jfree.data.xy.OHLCDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// public class CandlestickRenderer_drawItem_1_1_Test {
// 
//     @Test
//     @DisplayName("drawItem executes with PlotOrientation.HORIZONTAL")
//     void TC01_drawItem_with_HORIZONTAL_orientation() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setDrawVolume(false); // Ensure volume bars are not drawn
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(100.0);
//         when(dataset.getHighValue(anyInt(), anyInt())).thenReturn(110.0);
//         when(dataset.getLowValue(anyInt(), anyInt())).thenReturn(90.0);
//         when(dataset.getOpenValue(anyInt(), anyInt())).thenReturn(95.0);
//         when(dataset.getCloseValue(anyInt(), anyInt())).thenReturn(105.0);
//         when(dataset.getVolumeValue(anyInt(), anyInt())).thenReturn(1000.0);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotRenderingInfo.Owner.class));
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// 
//         // Assert
//         verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
//         verify(g2, never()).fill(any()); // Volume bars should not be drawn
//     }
// 
//     @Test
//     @DisplayName("drawItem executes with PlotOrientation.VERTICAL")
//     void TC02_drawItem_with_VERTICAL_orientation_and_volume() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setDrawVolume(true); // Ensure volume bars are drawn
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(200.0);
//         when(dataset.getHighValue(anyInt(), anyInt())).thenReturn(210.0);
//         when(dataset.getLowValue(anyInt(), anyInt())).thenReturn(190.0);
//         when(dataset.getOpenValue(anyInt(), anyInt())).thenReturn(195.0);
//         when(dataset.getCloseValue(anyInt(), anyInt())).thenReturn(205.0);
//         when(dataset.getVolumeValue(anyInt(), anyInt())).thenReturn(1500.0);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotRenderingInfo.Owner.class));
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 1);
// 
//         // Assert
//         verify(g2, atLeastOnce()).fill(any(Rectangle2D.class)); // Candle body
//         verify(g2, atLeastOnce()).fill(any(Rectangle2D.class)); // Volume bars
//         verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
//     }
// 
//     @Test
//     @DisplayName("drawItem handles null PlotRenderingInfo")
//     void TC03_drawItem_with_null_PlotRenderingInfo() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setDrawVolume(true);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(300.0);
//         when(dataset.getHighValue(anyInt(), anyInt())).thenReturn(310.0);
//         when(dataset.getLowValue(anyInt(), anyInt())).thenReturn(290.0);
//         when(dataset.getOpenValue(anyInt(), anyInt())).thenReturn(295.0);
//         when(dataset.getCloseValue(anyInt(), anyInt())).thenReturn(305.0);
//         when(dataset.getVolumeValue(anyInt(), anyInt())).thenReturn(2000.0);
// 
//         PlotRenderingInfo info = null; // Null PlotRenderingInfo
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 2, 2, crosshairState, 2);
// 
//         // Assert
//         verify(g2, atLeastOnce()).fill(any(Rectangle2D.class)); // Only candle body drawn
//         verify(g2, never()).fill(any()); // Volume bars should not be drawn as info is null
//     }
// 
//     @Test
//     @DisplayName("drawItem calculates candle width using WIDTHMETHOD_AVERAGE")
//     void TC04_drawItem_with_WIDTHMETHOD_AVERAGE() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_AVERAGE);
//         renderer.setDrawVolume(false);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(anyInt())).thenReturn(10);
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(100.0 + anyDouble());
//         when(dataset.getHighValue(anyInt(), anyInt())).thenReturn(110.0);
//         when(dataset.getLowValue(anyInt(), anyInt())).thenReturn(90.0);
//         when(dataset.getOpenValue(anyInt(), anyInt())).thenReturn(95.0);
//         when(dataset.getCloseValue(anyInt(), anyInt())).thenReturn(105.0);
//         when(dataset.getVolumeValue(anyInt(), anyInt())).thenReturn(1000.0);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotRenderingInfo.Owner.class));
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         when(dataArea.getWidth()).thenReturn(1000.0); // Example width
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.getLowerBound()).thenReturn(0.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(500.0); // Example position
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 3, 3, crosshairState, 3);
// 
//         // Assert
//         // Since candleWidth is calculated automatically, verify that fill is called with expected Rectangle2D
//         verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
//     }
// 
//     @Test
//     @DisplayName("drawItem calculates candle width using WIDTHMETHOD_SMALLEST")
//     void TC05_drawItem_with_WIDTHMETHOD_SMALLEST() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_SMALLEST);
//         renderer.setDrawVolume(false);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(anyInt())).thenReturn(5);
//         when(dataset.getXValue(anyInt(), anyInt())).thenReturn(100.0 * anyDouble()); // Varying positions
//         when(dataset.getHighValue(anyInt(), anyInt())).thenReturn(110.0);
//         when(dataset.getLowValue(anyInt(), anyInt())).thenReturn(90.0);
//         when(dataset.getOpenValue(anyInt(), anyInt())).thenReturn(95.0);
//         when(dataset.getCloseValue(anyInt(), anyInt())).thenReturn(105.0);
//         when(dataset.getVolumeValue(anyInt(), anyInt())).thenReturn(1000.0);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.PlotRenderingInfo.Owner.class));
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         when(dataArea.getWidth()).thenReturn(500.0); // Example width
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.getLowerBound()).thenReturn(0.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(250.0); // Example position
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 4, 4, crosshairState, 4);
// 
//         // Assert
//         // Since candleWidth is calculated based on smallest interval, verify that fill is called with expected Rectangle2D
//         verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
//     }
// }