package org.jfree.chart.renderer.category;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.lang.reflect.Field;
import java.awt.geom.Line2D;

public class MinMaxCategoryRenderer_drawItem_0_4_Test {

    @Test
    @DisplayName("drawItem handles lastSeries condition correctly when row is last row")
    void TC16_drawItem_handles_lastSeries_condition_correctly_when_row_is_last_row() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(15);
        when(dataset.getRowCount()).thenReturn(row + 1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Create instance of renderer
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        // Using reflection to set private fields if necessary
        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.set(renderer, -1); // Initialize to a different value

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        // Verify that min and max lines are drawn appropriately
        // This can include verifying interactions with Graphics2D, such as draw calls
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).setStroke(any(Stroke.class));
    }

    @Test
    @DisplayName("drawItem ensures min and max are drawn only once per category")
    void TC17_drawItem_ensures_min_and_max_are_drawn_only_once_per_category() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(10);
        when(dataset.getRowCount()).thenReturn(row + 1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Create instance of renderer and set fields via reflection
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.set(renderer, column);

        Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
        minField.setAccessible(true);
        minField.setDouble(renderer, 5.0);

        Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
        maxField.setAccessible(true);
        maxField.setDouble(renderer, 15.0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        // Verify that min and max lines are drawn only once
        verify(g2, times(1)).draw(any(Line2D.class));
    }

//     @Test
//     @DisplayName("drawItem draws Line2D correctly in horizontal orientation")
//     void TC18_drawItem_draws_Line2D_correctly_in_horizontal_orientation() throws Exception {
        // GIVEN
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(dataset.getValue(row, column)).thenReturn(20.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         when(dataset.getRowCount()).thenReturn(row + 1);
// 
        // Create instance of renderer and set fields via reflection
//         MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
// 
//         Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
//         minField.setAccessible(true);
//         minField.setDouble(renderer, 10.0);
// 
//         Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
//         maxField.setAccessible(true);
//         maxField.setDouble(renderer, 30.0);
// 
//         Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
//         lastCategoryField.setAccessible(true);
//         lastCategoryField.set(renderer, column);
// 
        // WHEN
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
        // THEN
        // Verify that Line2D is drawn horizontally
//         verify(g2, atLeastOnce()).draw(argThat(line ->
//             line.getX1() == line.getX2() // Horizontal line has same Y
//         ));
//     }

    @Test
    @DisplayName("drawItem handles plotLines being false and does not draw lines")
    void TC19_drawItem_handles_plotLines_false_and_does_not_draw_lines() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(25);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Create instance of renderer and set fields via reflection
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
        plotLinesField.setAccessible(true);
        plotLinesField.setBoolean(renderer, false);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // THEN
        // Verify that no lines are drawn
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("drawItem handles multiple categories and resets min and max accordingly")
    void TC20_drawItem_handles_multiple_categories_and_resets_min_and_max() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getRowCount()).thenReturn(4);
        when(dataset.getValue(row, column)).thenReturn(10, 20, 5, 25);

        // Create instance of renderer and set fields via reflection
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
        plotLinesField.setAccessible(true);
        plotLinesField.setBoolean(renderer, true);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column + 1, pass);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column + 2, pass);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column + 3, pass);

        // THEN
        // Verify that min and max are reset and drawn correctly for each category
        // This can include verifying multiple draw calls
        verify(g2, atLeast(2)).draw(any(Line2D.class));
    }
}