package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.io.NumberInput;

public class NumberInput_parseInt_0_1_Test {

    @Test
    @DisplayName("parseInt with a single positive digit")
    public void test_TC01() {
        String s = "5";
        int result = NumberInput.parseInt(s);
        assertEquals(5, result);
    }

    @Test
    @DisplayName("parseInt with a single negative digit")
    public void test_TC02() {
        String s = "-7";
        int result = NumberInput.parseInt(s);
        assertEquals(-7, result);
    }

    @Test
    @DisplayName("parseInt with maximum positive digits (9 digits)")
    public void test_TC03() {
        String s = "123456789";
        int result = NumberInput.parseInt(s);
        assertEquals(123456789, result);
    }

    @Test
    @DisplayName("parseInt with maximum negative digits (10 characters including '-')")
    public void test_TC04() {
        String s = "-123456789";
        int result = NumberInput.parseInt(s);
        assertEquals(-123456789, result);
    }

    @Test
    @DisplayName("parseInt with more than 9 digits without sign defers to Integer.parseInt")
    public void test_TC05() {
        String s = "1234567890";
        int result = NumberInput.parseInt(s);
        assertEquals(1234567890, result);
    }
}