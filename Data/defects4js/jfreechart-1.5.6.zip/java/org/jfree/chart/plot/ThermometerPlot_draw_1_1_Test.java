package org.jfree.chart.plot;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.awt.geom.Area;
import java.awt.geom.Line2D;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.ui.RectangleEdge;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ThermometerPlot_draw_1_1_Test {

    private ThermometerPlot plot;
    private Graphics2D g2;
    private PlotRenderingInfo info;

    @BeforeEach
    public void setUp() {
        plot = new ThermometerPlot();
        g2 = mock(Graphics2D.class);
        info = mock(PlotRenderingInfo.class);
    }

//     @Test
//     @DisplayName("Draw method with useSubrangePaint=false ensures mercuryPaint is used regardless of subrange")
//     public void TC21_draw_withoutSubrangePaint() {
        // GIVEN
//         plot.setUseSubrangePaint(false);
//         ValueDataset dataset = new DefaultValueDataset(75.0);
//         plot.setDataset(dataset);
//         plot.setSubrangeIndicatorsVisible(true);
//         ValueAxis rangeAxis = new NumberAxis();
//         rangeAxis.setRange(0, 100);
//         plot.setRangeAxis(rangeAxis);
//         plot.setValueLocation(ThermometerPlot.RIGHT);
//         Rectangle2D area = new Rectangle2D.Double(10, 10, 200, 400);
//         Point2D anchor = new Point2D.Double(100, 200);
//         PlotState state = new PlotState();
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
//         verify(g2).setPaint(eq(plot.getMercuryPaint()));
//         verify(g2).fill(any(Area.class));
//         verify(g2, times(3)).draw(any(Line2D.class)); // Updated count as per thermometer line drawing
//         verify(g2, times(1)).drawString(eq("\u00B0C"), anyInt(), anyInt());
//     }

//     @Test
//     @DisplayName("Draw method with followDataInSubranges=true and dataset value within a subrange adjusts axis range accordingly")
//     public void TC22_draw_withFollowDataInSubranges_NormalSubrange() {
        // GIVEN
//         plot.setFollowDataInSubranges(true);
//         ValueDataset dataset = new DefaultValueDataset(25.0);
//         plot.setDataset(dataset);
//         plot.setSubrangeIndicatorsVisible(true);
//         plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 50.0);
//         plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 75.0);
//         plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75.0, 100.0);
//         Paint normalPaint = java.awt.Color.GREEN;
//         plot.setSubrangePaint(ThermometerPlot.NORMAL, normalPaint);
//         ValueAxis rangeAxis = new NumberAxis();
//         plot.setRangeAxis(rangeAxis);
//         plot.setValueLocation(ThermometerPlot.BULB);
//         Rectangle2D area = new Rectangle2D.Double(20, 20, 300, 500);
//         Point2D anchor = new Point2D.Double(150, 250);
//         PlotState state = new PlotState();
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
//         assertEquals(0.0, rangeAxis.getRange().getLowerBound());
//         assertEquals(50.0, rangeAxis.getRange().getUpperBound());
//         verify(g2).fill(any(Area.class));
//         verify(g2, times(3)).draw(any(Line2D.class)); // Updated count as per thermometer line drawing
//         verify(g2, times(1)).drawString(anyString(), anyInt(), anyInt());
//     }
}