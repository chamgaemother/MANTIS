package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_get_2_1_Test {

    @Test
    @DisplayName("Returns null for a key that exists with a null value when delegateMap is null and size=1")
    void TC26_getReturnsNullForExistingKeyWithNullValue() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set private field 'size' to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Set private field 'key1' to 'existingKey'
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "existingKey");

        // Set private field 'value1' to null
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, null);

        // WHEN
        Object result = map.get("existingKey");

        // THEN
        assertNull(result, "Expected get method to return null for existing key with null value.");
    }

    @Test
    @DisplayName("Returns null when key's hash matches but keys are not equal and delegateMap is null and size=3")
    void TC27_getReturnsNullWhenHashMatchesButKeysAreNotEqual() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set private field 'size' to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set private field 'key3' to 'key3'
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // Set private field 'hash3' to hashCode of 'key2'
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, "key2".hashCode());

        // Ensure 'key3' is not equal to 'key2'
        assertNotEquals("key3", "key2", "Precondition failed: 'key3' should not be equal to 'key2'");

        // WHEN
        Object result = map.get("key2");

        // THEN
        assertNull(result, "Expected get method to return null when hashes match but keys are not equal.");
    }
}