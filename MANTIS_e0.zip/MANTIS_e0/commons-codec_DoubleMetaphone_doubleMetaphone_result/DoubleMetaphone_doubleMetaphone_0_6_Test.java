package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 test class for DoubleMetaphone.doubleMetaphone method.
 */
public class DoubleMetaphone_doubleMetaphone_0_6_Test {

    @Test
    @DisplayName("doubleMetaphone(\"GHASTLY\", false) handles 'GH' combination")
    public void testTC26() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GHASTLY";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "KASTL";
        assertEquals(expected, result, "'GH' should be encoded as 'K'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"HAPPY\", false) handles 'P' before 'Y'")
    public void testTC27() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "HAPPY";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "HAPI";
        assertEquals(expected, result, "'P' before 'Y' should be encoded correctly");
    }

    @Test
    @DisplayName("doubleMetaphone(\"QUICK\", false) handles 'Q'")
    public void testTC28() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "QUICK";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "KK";
        assertEquals(expected, result, "'Q' should be encoded as 'K'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"VAN\", false) handles 'VAN ' prefix")
    public void testTC29() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "VAN";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "FN";
        assertEquals(expected, result, "'VAN ' prefix should be encoded correctly");
    }

    @Test
    @DisplayName("doubleMetaphone(\"WITZ\", false) handles 'WITZ' suffix")
    public void testTC30() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "WITZ";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        String expected = "FX";
        assertEquals(expected, result, "'WITZ' should be encoded as 'FX'");
    }
}