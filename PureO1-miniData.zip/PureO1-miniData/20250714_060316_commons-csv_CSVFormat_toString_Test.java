package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.*;

import java.io.Serializable;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

public class CSVFormatTest {

    @Test
    public void testToString_DefaultFormat() {
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, CSVFormat.DEFAULT.toString());
    }
    
    @Test
    public void testToString_WithEscapeCharacter() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setEscape('\\')
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutEscapeCharacter() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setEscape(null)
                .build();
        String expected = "Delimiter=<,> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithQuoteCharacter() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setQuote('\'')
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<'> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutQuoteCharacter() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setQuote(null)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithQuoteMode() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setQuoteMode(QuoteMode.ALL)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<ALL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutQuoteMode() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setQuoteMode(null)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithCommentMarker() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> CommentStart=<#> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutCommentMarker() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker(null)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithNullString() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setNullString("\\N")
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> NullString=<\\N> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutNullString() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setNullString(null)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithRecordSeparator() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setRecordSeparator("\n")
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> RecordSeparator=<\n> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutRecordSeparator() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setRecordSeparator(null)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithIgnoreEmptyLines() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setIgnoreEmptyLines(true)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> EmptyLines:ignored SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutIgnoreEmptyLines() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setIgnoreEmptyLines(false)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithIgnoreSurroundingSpaces() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setIgnoreSurroundingSpaces(true)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SurroundingSpaces:ignored SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutIgnoreSurroundingSpaces() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setIgnoreSurroundingSpaces(false)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithIgnoreHeaderCase() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setIgnoreHeaderCase(true)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> IgnoreHeaderCase:ignored SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutIgnoreHeaderCase() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setIgnoreHeaderCase(false)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithSkipHeaderRecordTrue() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setSkipHeaderRecord(true)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:true";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithSkipHeaderRecordFalse() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setSkipHeaderRecord(false)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithHeaderComments() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeaderComments("Generated by Apache Commons CSV.", "2023-10-05")
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false HeaderComments:[Generated by Apache Commons CSV., 2023-10-05]";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutHeaderComments() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeaderComments((Object[]) null)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithHeaders() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("Name", "Email", "Phone")
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false Header:[Name, Email, Phone]";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithoutHeaders() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader((String[]) null)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_AllOptionsSet() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDelimiter(';')
                .setEscape('#')
                .setQuote('\'')
                .setQuoteMode(QuoteMode.ALL)
                .setCommentMarker('%')
                .setNullString("NULL")
                .setRecordSeparator("\r\n")
                .setIgnoreEmptyLines(true)
                .setIgnoreSurroundingSpaces(true)
                .setIgnoreHeaderCase(true)
                .setSkipHeaderRecord(true)
                .setHeaderComments("Header Comment 1", "Header Comment 2")
                .setHeader("ID", "Name", "Value")
                .build();
        String expected = "Delimiter=<>Escape=<#> QuoteChar=<'> QuoteMode=<ALL> CommentStart=<?> NullString=<NULL> RecordSeparator=<\r\n> EmptyLines:ignored SurroundingSpaces:ignored IgnoreHeaderCase:ignored SkipHeaderRecord:true HeaderComments:[Header Comment 1, Header Comment 2] Header=[ID, Name, Value]";
        // Fix expected string to match actual delimiter
        expected = "Delimiter=<>Escape=<#> QuoteChar=<'> QuoteMode=<ALL> CommentStart=<%> NullString=<NULL> RecordSeparator=<\r\n> EmptyLines:ignored SurroundingSpaces:ignored IgnoreHeaderCase:ignored SkipHeaderRecord:true HeaderComments:[Header Comment 1, Header Comment 2] Header:[ID, Name, Value]";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_NoOptionalFieldsSet() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDelimiter(',')
                .setEscape('\\')
                .setQuote('"')
                .setQuoteMode(QuoteMode.MINIMAL)
                .setSkipHeaderRecord(false)
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_MinimalFieldsSet() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithEmptyHeaderComments() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeaderComments()
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false HeaderComments:[]";
        assertEquals(expected, format.toString());
    }
    
    @Test
    public void testToString_WithEmptyHeaders() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> QuoteMode=<MINIMAL> SkipHeaderRecord:false Header:[]";
        assertEquals(expected, format.toString());
    }
}