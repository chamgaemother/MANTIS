package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.ode.sampling.NordsieckStepInterpolator;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.ode.EquationsMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class AdamsBashforthIntegrator_integrate_2_1_Test {

//     @Test
//     @DisplayName("Integration step is rejected when error estimation equals 1.0, triggering step size reduction")
//     void TC35_integrate_errorExactlyOne_stepRejected() throws Exception {
        // Arrange
//         AdamsBashforthIntegrator integrator = spy(new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5));
//         ExpandableStatefulODE equations = mock(ExpandableStatefulODE.class);
//         when(equations.getTime()).thenReturn(0.0);
//         when(equations.getCompleteState()).thenReturn(new double[]{1.0, 2.0, 3.0});
//         when(equations.getPrimaryMapper()).thenReturn(mock(EquationsMapper.class));
//         when(equations.getSecondaryMappers()).thenReturn(new EquationsMapper[]{});
//         doReturn(1.0).when(integrator).errorEstimation(any(double[].class), any(double[].class), any(double[].class), any(RealMatrix.class));
// 
        // Act
//         integrator.integrate(equations, 10.0);
// 
        // Assert
//         verify(integrator).filterStep(anyDouble(), eq(false), eq(false));
//     }

//     @Test
//     @DisplayName("Integration step is accepted when error estimation is below 1.0, triggering step size increase")
//     void TC36_integrate_errorBelowOne_stepAccepted_stepSizeIncreased() throws Exception {
        // Arrange
//         AdamsBashforthIntegrator integrator = spy(new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5));
//         ExpandableStatefulODE equations = mock(ExpandableStatefulODE.class);
//         when(equations.getTime()).thenReturn(0.0);
//         when(equations.getCompleteState()).thenReturn(new double[]{1.0, 2.0, 3.0});
//         when(equations.getPrimaryMapper()).thenReturn(mock(EquationsMapper.class));
//         when(equations.getSecondaryMappers()).thenReturn(new EquationsMapper[]{});
//         doReturn(0.5).when(integrator).errorEstimation(any(double[].class), any(double[].class), any(double[].class), any(RealMatrix.class));
// 
        // Act
//         integrator.integrate(equations, 10.0);
// 
        // Assert
//         verify(integrator).filterStep(anyDouble(), eq(false), eq(false));
//     }

//     @Test
//     @DisplayName("Integration stops and propagates exception when acceptStep throws exception")
//     void TC37_integrate_acceptStep_throwsException() throws Exception {
        // Arrange
//         AdamsBashforthIntegrator integrator = spy(new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5));
//         ExpandableStatefulODE equations = mock(ExpandableStatefulODE.class);
//         when(equations.getTime()).thenReturn(0.0);
//         when(equations.getCompleteState()).thenReturn(new double[]{1.0, 2.0, 3.0});
//         when(equations.getPrimaryMapper()).thenReturn(mock(EquationsMapper.class));
//         when(equations.getSecondaryMappers()).thenReturn(new EquationsMapper[]{});
//         doThrow(new RuntimeException("Error in acceptStep")).when(integrator).acceptStep(any(NordsieckStepInterpolator.class), any(double[].class), any(double[].class), anyDouble());
// 
        // Act & Assert
//         assertThrows(RuntimeException.class, () -> integrator.integrate(equations, 10.0));
//     }

//     @Test
//     @DisplayName("Integration handles multiple step size reductions occur before a step is accepted")
//     void TC38_integrate_handle_multiple_rejections_and_acceptances() throws Exception {
        // Arrange
//         AdamsBashforthIntegrator integrator = spy(new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5));
//         ExpandableStatefulODE equations = mock(ExpandableStatefulODE.class);
//         when(equations.getTime()).thenReturn(0.0);
//         when(equations.getCompleteState()).thenReturn(new double[]{1.0, 2.0, 3.0});
//         when(equations.getPrimaryMapper()).thenReturn(mock(EquationsMapper.class));
//         when(equations.getSecondaryMappers()).thenReturn(new EquationsMapper[]{});
        // First rejection with error >=1.0
//         doReturn(1.2).when(integrator).errorEstimation(any(double[].class), any(double[].class), any(double[].class), any(RealMatrix.class));
        // Then acceptance with error <1.0
//         doReturn(0.5).when(integrator).errorEstimation(any(double[].class), any(double[].class), any(double[].class), any(RealMatrix.class));
// 
        // Act
//         integrator.integrate(equations, 10.0);
// 
        // Assert
//         verify(integrator, times(1)).computeStepGrowShrinkFactor(1.2);
//         verify(integrator, times(1)).computeStepGrowShrinkFactor(0.5);
//         verify(equations, times(1)).setTime(10.0);
//         verify(equations, times(1)).setCompleteState(any(double[].class));
//     }

//     @Test
//     @DisplayName("Integration correctly handles loops with single iteration")
//     void TC39_integrate_handle_loop_with_single_iteration() throws Exception {
        // Arrange
//         AdamsBashforthIntegrator integrator = spy(new AdamsBashforthIntegrator(3, 0.1, 1.0, 1e-5, 1e-5));
//         ExpandableStatefulODE equations = mock(ExpandableStatefulODE.class);
//         when(equations.getTime()).thenReturn(0.0);
//         when(equations.getCompleteState()).thenReturn(new double[]{1.0, 2.0, 3.0});
//         when(equations.getPrimaryMapper()).thenReturn(mock(EquationsMapper.class));
//         when(equations.getSecondaryMappers()).thenReturn(new EquationsMapper[]{});
//         doReturn(0.5).when(integrator).errorEstimation(any(double[].class), any(double[].class), any(double[].class), any(RealMatrix.class));
// 
        // Act
//         integrator.integrate(equations, 1.0);
// 
        // Assert
//         verify(integrator, times(1)).errorEstimation(any(double[].class), any(double[].class), any(double[].class), any(RealMatrix.class));
//         verify(equations, times(1)).setTime(1.0);
//         verify(equations, times(1)).setCompleteState(any(double[].class));
//     }

}