package com.fasterxml.jackson.databind.module;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
import com.fasterxml.jackson.databind.deser.ValueInstantiators;
import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
import com.fasterxml.jackson.databind.Module.SetupContext;

/**
 * JUnit 5 test class for SimpleModule.setupModule method.
 */
public class SimpleModule_setupModule_0_2_Test {

    @Test
    @DisplayName("Only _keyDeserializers is not null; key deserializers are added to SetupContext")
    public void test_TC06() {
        // GIVEN
        SimpleKeyDeserializers keyDeserializers = new SimpleKeyDeserializers();
        SimpleModule module = new SimpleModule();
        module.setKeyDeserializers(keyDeserializers);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addKeyDeserializers(keyDeserializers);
    }

    @Test
    @DisplayName("Only _abstractTypes is not null; abstract type resolver is added to SetupContext")
    public void test_TC07() {
        // GIVEN
        SimpleAbstractTypeResolver abstractTypeResolver = new SimpleAbstractTypeResolver();
        SimpleModule module = new SimpleModule();
        module.setAbstractTypes(abstractTypeResolver);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addAbstractTypeResolver(abstractTypeResolver);
    }

//     @Test
//     @DisplayName("Only _valueInstantiators is not null; value instantiators are added to SetupContext")
//     public void test_TC08() {
        // GIVEN
//         ValueInstantiators valueInstantiators = mock(ValueInstantiators.class);
//         SimpleModule module = new SimpleModule();
//         module.setValueInstantiators(valueInstantiators);
//         SetupContext context = mock(SetupContext.class);
// 
        // WHEN
//         module.setupModule(context);
// 
        // THEN
//         verify(context).addValueInstantiators(valueInstantiators);
//     }

    @Test
    @DisplayName("Only _deserializerModifier is not null; deserializer modifier is added to SetupContext")
    public void test_TC09() {
        // GIVEN
        BeanDeserializerModifier deserializerModifier = mock(BeanDeserializerModifier.class);
        SimpleModule module = new SimpleModule();
        module.setDeserializerModifier(deserializerModifier);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addBeanDeserializerModifier(deserializerModifier);
    }

    @Test
    @DisplayName("Only _serializerModifier is not null; serializer modifier is added to SetupContext")
    public void test_TC10() {
        // GIVEN
        BeanSerializerModifier serializerModifier = mock(BeanSerializerModifier.class);
        SimpleModule module = new SimpleModule();
        module.setSerializerModifier(serializerModifier);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addBeanSerializerModifier(serializerModifier);
    }

}