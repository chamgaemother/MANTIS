package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CyclicXYItemRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("Cycle splitting in both domain and range axes")
    void TC06_drawItem_cycleSplittingBothAxes() throws Exception {
        // Given
        CyclicXYItemRenderer renderer = Mockito.spy(new CyclicXYItemRenderer());
        // Set plot lines on which was missing in setup and replace invalid method super_drawItem with drawItem
        renderer.setPlotLines(true);

        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        CyclicNumberAxis rangeAxis = mock(CyclicNumberAxis.class);

        when(domainAxis.getCycleBound()).thenReturn(100.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);
        when(rangeAxis.getCycleBound()).thenReturn(200.0);
        when(rangeAxis.isBoundMappedToLastCycle()).thenReturn(false);

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        when(dataset.getXValue(series, item - 1)).thenReturn(90.0);
        when(dataset.getYValue(series, item - 1)).thenReturn(190.0);
        when(dataset.getXValue(series, item)).thenReturn(110.0);
        when(dataset.getYValue(series, item)).thenReturn(210.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Then
        ArgumentCaptor<XYDataset> datasetCaptor = ArgumentCaptor.forClass(XYDataset.class);
        verify(renderer, times(2)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(rangeAxis), datasetCaptor.capture(), eq(series), anyInt(), eq(crosshairState), eq(pass));
    }

    @Test
    @DisplayName("Handling item index zero, should delegate to super.drawItem")
    void TC07_drawItem_itemIndexZero() throws Exception {
        // Given
        CyclicXYItemRenderer renderer = Mockito.spy(new CyclicXYItemRenderer());
        // Set plot lines on which was missing in setup
        renderer.setPlotLines(true);

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Then
        verify(renderer, times(1)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(rangeAxis), eq(dataset), eq(series), eq(item), eq(crosshairState), eq(pass));
    }

    @Test
    @DisplayName("Cycle bound exactly matches the first x-value, updates bound mapping accordingly")
    void TC08_drawItem_cycleBoundMatchesFirstXValue() throws Exception {
        // Given
        CyclicXYItemRenderer renderer = Mockito.spy(new CyclicXYItemRenderer());
        // Set plot lines on which was missing in setup
        renderer.setPlotLines(true);

        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis.getCycleBound()).thenReturn(100.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        when(dataset.getXValue(series, item - 1)).thenReturn(100.0);
        when(dataset.getYValue(series, item - 1)).thenReturn(50.0);
        when(dataset.getXValue(series, item)).thenReturn(110.0);
        when(dataset.getYValue(series, item)).thenReturn(60.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Then
        verify(renderer, times(1)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(domainAxis), eq(dataset), eq(series), anyInt(), eq(crosshairState), eq(pass));
    }

    @Test
    @DisplayName("Cycle splitting with equal x-values, ensures no division by zero and delegates to super.drawItem")
    void TC09_drawItem_equalXValuesNoSplit() throws Exception {
        // Given
        CyclicXYItemRenderer renderer = Mockito.spy(new CyclicXYItemRenderer());
        // Set plot lines on which was missing in setup
        renderer.setPlotLines(true);

        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis.getCycleBound()).thenReturn(100.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        when(dataset.getXValue(series, item - 1)).thenReturn(100.0);
        when(dataset.getYValue(series, item - 1)).thenReturn(50.0);
        when(dataset.getXValue(series, item)).thenReturn(100.0);
        when(dataset.getYValue(series, item)).thenReturn(60.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Then
        verify(renderer, times(1)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(domainAxis), eq(dataset), eq(series), eq(item), eq(crosshairState), eq(pass));
    }

    @Test
    @DisplayName("Multiple cycle splits due to complex axis bounds, ensures all splits are handled correctly")
    void TC10_drawItem_multipleCycleSplits() throws Exception {
        // Given
        CyclicXYItemRenderer renderer = Mockito.spy(new CyclicXYItemRenderer());
        // Set plot lines on which was missing in setup
        renderer.setPlotLines(true);

        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        CyclicNumberAxis rangeAxis = mock(CyclicNumberAxis.class);

        when(domainAxis.getCycleBound()).thenReturn(100.0, 200.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false, true);
        when(rangeAxis.getCycleBound()).thenReturn(150.0, 250.0);
        when(rangeAxis.isBoundMappedToLastCycle()).thenReturn(false, true);

        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        when(dataset.getXValue(series, item - 1)).thenReturn(90.0);
        when(dataset.getYValue(series, item - 1)).thenReturn(140.0);
        when(dataset.getXValue(series, item)).thenReturn(210.0);
        when(dataset.getYValue(series, item)).thenReturn(260.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Then
        ArgumentCaptor<XYDataset> datasetCaptor = ArgumentCaptor.forClass(XYDataset.class);
        verify(renderer, times(3)).drawItem(eq(g2), eq(state), eq(dataArea), eq(info), eq(plot), eq(domainAxis), eq(rangeAxis), datasetCaptor.capture(), eq(series), anyInt(), eq(crosshairState), eq(pass));
    }
}