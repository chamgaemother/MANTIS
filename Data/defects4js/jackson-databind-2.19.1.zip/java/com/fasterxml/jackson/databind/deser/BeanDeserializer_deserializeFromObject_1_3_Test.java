package com.fasterxml.jackson.databind.deser;
import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
import com.fasterxml.jackson.databind.BeanDescription;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.core.JsonToken;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@ExtendWith(MockitoExtension.class)
public class BeanDeserializer_deserializeFromObject_1_3_Test {

    @Test
    @DisplayName("deserializeFromObject with JSON array token and _arrayDelegateDeserializer is present")
    public void TC37_deserializeFromObject_withArrayDelegateDeserializer() throws Exception {
        // Arrange
        // Mock dependencies
        BeanDeserializerBuilder mockBuilder = Mockito.mock(BeanDeserializerBuilder.class);
        BeanDescription mockBeanDesc = Mockito.mock(BeanDescription.class);
        BeanPropertyMap mockProperties = Mockito.mock(BeanPropertyMap.class);
        Map<String, SettableBeanProperty> mockBackRefs = Mockito.mock(Map.class);
        HashSet<String> ignorableProps = new HashSet<>();
        Set<String> includableProps = Mockito.mock(Set.class);
        boolean ignoreAllUnknown = false;
        boolean hasViews = false;

        // Instantiate BeanDeserializer with mocked constructor parameters
        BeanDeserializer beanDeserializer = new BeanDeserializer(
                mockBuilder,
                mockBeanDesc,
                mockProperties,
                mockBackRefs,
                ignorableProps,
                ignoreAllUnknown,
                includableProps,
                hasViews
        );

        // Set private field _arrayDelegateDeserializer via reflection
        JsonDeserializer<?> mockArrayDelegateDeserializer = Mockito.mock(JsonDeserializer.class);
        Field arrayDelegateDeserializerField = BeanDeserializerBase.class.getDeclaredField("_arrayDelegateDeserializer");
        arrayDelegateDeserializerField.setAccessible(true);
        arrayDelegateDeserializerField.set(beanDeserializer, mockArrayDelegateDeserializer);

        // Mock JsonParser to have START_ARRAY token
        JsonParser mockParser = Mockito.mock(JsonParser.class);
        Mockito.when(mockParser.isExpectedStartArrayToken()).thenReturn(true);
        Mockito.when(mockParser.nextToken())
               .thenReturn(JsonToken.START_ARRAY) // Initial START_ARRAY token
               .thenReturn(JsonToken.END_ARRAY);  // End of array

        // Mock DeserializationContext
        DeserializationContext mockContext = Mockito.mock(DeserializationContext.class);

        // Define expected bean to be returned by _arrayDelegateDeserializer
        Object expectedBean = new Object();
        Mockito.when(mockArrayDelegateDeserializer.deserialize(Mockito.eq(mockParser), Mockito.eq(mockContext)))
               .thenReturn(expectedBean);

        // Act
        Object result = beanDeserializer.deserializeFromObject(mockParser, mockContext);

        // Assert
        Assertions.assertEquals(expectedBean, result, "Bean should be deserialized using _arrayDelegateDeserializer");
        Mockito.verify(mockArrayDelegateDeserializer, Mockito.times(1)).deserialize(mockParser, mockContext);
    }
}