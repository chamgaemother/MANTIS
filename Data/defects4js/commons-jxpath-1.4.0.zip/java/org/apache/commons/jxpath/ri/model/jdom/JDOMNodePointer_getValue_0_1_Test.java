package org.apache.commons.jxpath.ri.model.jdom;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.jdom.Comment;
import org.jdom.Element;
import org.jdom.Text;

import java.lang.reflect.Field;
import java.util.Locale;

public class JDOMNodePointer_getValue_0_1_Test {

    @Test
    @DisplayName("getValue returns concatenated child values when node is an Element with zero children")
    public void TC01_getValue_ElementWithZeroChildren() throws Exception {
        // Arrange
        Element node = new Element("root");
        // Providing the necessary Locale argument during instantiation
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, Locale.getDefault());
        
        // Act
        Object result = nodePointer.getValue();
        
        // Assert
        assertEquals("", result, "Expected an empty string for Element with zero children.");
    }

    @Test
    @DisplayName("getValue returns concatenated child values when node is an Element with one Element child")
    public void TC02_getValue_ElementWithOneElementChild() throws Exception {
        // Arrange
        Element child = new Element("child").setText("ChildValue");
        Element node = new Element("root").addContent(child);
        // Providing the necessary Locale argument during instantiation
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, Locale.getDefault());
        
        // Act
        Object result = nodePointer.getValue();
        
        // Assert
        assertEquals("ChildValue", result, "Expected the child's value to be returned.");
    }

    @Test
    @DisplayName("getValue returns concatenated child values when node is an Element with multiple Element and Text children")
    public void TC03_getValue_ElementWithMultipleElementAndTextChildren() throws Exception {
        // Arrange
        Element child1 = new Element("child1").setText("Value1");
        Element child2 = new Element("child2").setText("Value2");
        Text text = new Text("TextValue");
        Element node = new Element("root").addContent(child1).addContent(child2).addContent(text);
        // Providing the necessary Locale argument during instantiation
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, Locale.getDefault());
        
        // Act
        Object result = nodePointer.getValue();
        
        // Assert
        assertEquals("Value1Value2TextValue", result, "Expected concatenated child and text values.");
    }

    @Test
    @DisplayName("getValue returns trimmed comment text when node is a Comment with non-null text")
    public void TC04_getValue_CommentWithNonNullText() throws Exception {
        // Arrange
        Comment node = new Comment("  Comment Text  ");
        // Providing the necessary Locale argument during instantiation
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, Locale.getDefault());
        
        // Act
        Object result = nodePointer.getValue();
        
        // Assert
        assertEquals("Comment Text", result, "Expected trimmed comment text.");
    }

    @Test
    @DisplayName("getValue returns null when node is a Comment with null text")
    public void TC05_getValue_CommentWithNullText() throws Exception {
        // Arrange
        Comment node = new Comment(null);
        // Providing the necessary Locale argument during instantiation
        JDOMNodePointer nodePointer = new JDOMNodePointer(node, Locale.getDefault());
        
        // Act
        Object result = nodePointer.getValue();
        
        // Assert
        assertNull(result, "Expected null when comment text is null.");
    }
}