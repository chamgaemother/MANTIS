import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.HighLowRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class HighLowRendererTest {

    private HighLowRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private OHLCDataset dataset;

    @BeforeEach
    public void setUp() {
        renderer = new HighLowRenderer();
        g2 = Mockito.mock(Graphics2D.class);
        state = Mockito.mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = new PlotRenderingInfo(null);
        plot = Mockito.mock(XYPlot.class);
        domainAxis = Mockito.mock(ValueAxis.class);
        rangeAxis = Mockito.mock(ValueAxis.class);
        dataset = Mockito.mock(OHLCDataset.class);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
    }

    @Test
    public void testDrawItemWithNullDataset() {
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, null, 0);
        verify(g2, never()).setPaint(any());
    }

    @Test
    public void testDrawItemOutOfRangeX() {
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(150.0);
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        
        verify(g2, never()).setPaint(any());
    }

    @Test
    public void testDrawItemInRangeXWithoutNaNValues() {
        when(dataset.getXValue(0, 0)).thenReturn(50.0);
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(dataset.getHighValue(0, 0)).thenReturn(10.0);
        when(dataset.getLowValue(0, 0)).thenReturn(5.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(5.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        
        verify(g2).draw(any());
    }

    @Test
    public void testDrawItemWithNaNHighLow() {
        when(dataset.getXValue(0, 0)).thenReturn(50.0);
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(dataset.getHighValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getLowValue(0, 0)).thenReturn(Double.NaN);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        
        verify(g2, never()).draw(any());
    }

    @Test
    public void testDrawOpenTicks() {
        renderer.setDrawOpenTicks(true);
        renderer.setOpenTickPaint(Color.RED);

        when(dataset.getXValue(0, 0)).thenReturn(50.0);
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(dataset.getOpenValue(0, 0)).thenReturn(7.0);
        when(rangeAxis.valueToJava2D(7.0, dataArea, RectangleEdge.LEFT)).thenReturn(7.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        verify(g2).setPaint(Color.RED);
        verify(g2).draw(any());
    }

    @Test
    public void testDrawCloseTicks() {
        renderer.setDrawCloseTicks(true);
        renderer.setCloseTickPaint(Color.BLUE);

        when(dataset.getXValue(0, 0)).thenReturn(50.0);
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(dataset.getCloseValue(0, 0)).thenReturn(3.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(3.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        verify(g2).setPaint(Color.BLUE);
        verify(g2).draw(any());
    }

    @Test
    public void testNonOHLCDataset() {
        XYDataset nonOHLCDataset = mock(XYDataset.class);
        when(nonOHLCDataset.getXValue(0, 0)).thenReturn(50.0);
        when(nonOHLCDataset.getYValue(0, 0)).thenReturn(20.0);
        when(nonOHLCDataset.getXValue(0, 1)).thenReturn(40.0);
        when(nonOHLCDataset.getYValue(0, 1)).thenReturn(15.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, nonOHLCDataset, 0, 1, null, 0);

        verify(g2).draw(any());
    }
}