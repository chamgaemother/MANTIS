import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.stat.correlation.KendallsCorrelation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

class KendallsCorrelationTest {

    @Test
    void testCorrelationWithMatchingLengthArrays() {
        double[] xArray = {1.0, 2.0, 3.0, 4.0};
        double[] yArray = {4.0, 3.0, 2.0, 1.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        assertDoesNotThrow(() -> kc.correlation(xArray, yArray));
    }

    @Test
    void testCorrelationWithDifferentLengthArrays() {
        double[] xArray = {1.0, 2.0, 3.0};
        double[] yArray = {4.0, 3.0, 2.0, 1.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        Executable correlationCall = () -> kc.correlation(xArray, yArray);
        assertThrows(DimensionMismatchException.class, correlationCall);
    }

    @Test
    void testCorrelationWithEmptyArrays() {
        double[] xArray = {};
        double[] yArray = {};
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);
        assertFalse(Double.isNaN(result));
    }

    @Test
    void testCorrelationWithAllTiedValues() {
        double[] xArray = {1.0, 1.0, 1.0, 1.0};
        double[] yArray = {2.0, 2.0, 2.0, 2.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);
        assertTrue(Double.isNaN(result));
    }

    @Test
    void testCorrelationIdentifiesConcordantAndDiscordantPairs() {
        double[] xArray = {1.0, 3.0, 2.0, 4.0};
        double[] yArray = {2.0, 1.0, 4.0, 3.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);
        assertTrue(result < 0); // More discordant pairs
    }

    @Test
    void testCorrelationWithSingleElementArrays() {
        double[] xArray = {1.0};
        double[] yArray = {2.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);
        assertFalse(Double.isNaN(result));
    }

    @Test
    void testCorrelationWithDuplicatesAndTies() {
        double[] xArray = {1.0, 2.0, 2.0, 3.0};
        double[] yArray = {4.0, 4.0, 3.0, 3.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        assertDoesNotThrow(() -> kc.correlation(xArray, yArray));
    }
}