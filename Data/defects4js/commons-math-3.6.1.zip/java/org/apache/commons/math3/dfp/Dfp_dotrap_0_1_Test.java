package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class Dfp_dotrap_0_1_Test {

    @Test
    @DisplayName("dotrap with type FLAG_INVALID sets def as zero, copies sign, and sets nans to QNAN")
    void TC01_dotrap_FLAG_INVALID() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(128);
        Dfp dfp = new Dfp(field, 1.0);

        // Given
        int type = DfpField.FLAG_INVALID;
        String what = "invalid operation";
        Dfp oper = new Dfp(field, 2.0);
        Dfp result = new Dfp(field, 3.0);

        // When
        Dfp output = dfp.dotrap(type, what, oper, result);

        // Then
        // Access private fields using reflection
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte nans = (byte) nansField.get(output);

        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte sign = (byte) signField.get(output);

        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(output);

        boolean isZero = true;
        for (int m : mant) {
            if (m != 0) {
                isZero = false;
                break;
            }
        }

        assertTrue(isZero, "Output should be zero");
        assertEquals(result.sign, sign, "Sign should be copied from result");
        assertEquals(Dfp.QNAN, nans, "NaN status should be QNAN");
    }

    @Test
    @DisplayName("dotrap with type FLAG_DIV_ZERO, nans=FINITE, mant[last] != 0 sets def sign and nans to INFINITE")
    void TC02_dotrap_FLAG_DIV_ZERO_Finite_NonZeroMantissa() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(128);
        Dfp dfp = new Dfp(field, 1.0);

        // Given
        int type = DfpField.FLAG_DIV_ZERO;
        String what = "division by zero";
        Dfp oper = new Dfp(field, 2.0);
        Dfp result = new Dfp(field, 3.0);
        // Set nans to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.set(result, Dfp.FINITE);
        // Set mantissa last element to non-zero
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = {1, 2, 3};  // Example array, adjust depending on precision requirements.
        mantField.set(result, mantissa);

        // When
        Dfp output = dfp.dotrap(type, what, oper, result);

        // Then
        // Access private fields using reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte sign = (byte) signField.get(output);

        Field mantOutputField = Dfp.class.getDeclaredField("mant");
        mantOutputField.setAccessible(true);
        int[] mantOutput = (int[]) mantOutputField.get(output);

        boolean isZero = true;
        for (int m : mantOutput) {
            if (m != 0) {
                isZero = false;
                break;
            }
        }

        assertTrue(isZero, "Output should be zero");
        assertEquals(result.sign * oper.sign, sign, "Sign should be sign * oper.sign");
        assertEquals(Dfp.INFINITE, nansField.get(output), "NaN status should be INFINITE");
    }

    @Test
    @DisplayName("dotrap with type FLAG_DIV_ZERO, nans=FINITE, mant[last] == 0 sets def nans to QNAN")
    void TC03_dotrap_FLAG_DIV_ZERO_Finite_ZeroMantissa() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(128);
        Dfp dfp = new Dfp(field, 1.0);

        // Given
        int type = DfpField.FLAG_DIV_ZERO;
        String what = "0 divided by 0";
        Dfp oper = new Dfp(field, 2.0);
        Dfp result = new Dfp(field, 0.0);
        // Set nans to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.set(result, Dfp.FINITE);
        // Set mantissa last element to zero
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = {0, 0, 0};  // Example array, adjust depending on precision requirements.
        mantField.set(result, mantissa);

        // When
        Dfp output = dfp.dotrap(type, what, oper, result);

        // Then
        // Access private fields using reflection
        Field mantOutputField = Dfp.class.getDeclaredField("mant");
        mantOutputField.setAccessible(true);
        int[] mantOutput = (int[]) mantOutputField.get(output);

        boolean isZero = true;
        for (int m : mantOutput) {
            if (m != 0) {
                isZero = false;
                break;
            }
        }

        assertTrue(isZero, "Output should be zero");
        assertEquals(Dfp.QNAN, nansField.get(output), "NaN status should be QNAN");
    }

    @Test
    @DisplayName("dotrap with type FLAG_DIV_ZERO, nans=INFINITE sets def nans to QNAN")
    void TC04_dotrap_FLAG_DIV_ZERO_InfiniteNans() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(128);
        Dfp dfp = new Dfp(field, 1.0);

        // Given
        int type = DfpField.FLAG_DIV_ZERO;
        String what = "infinite division";
        Dfp oper = new Dfp(field, 2.0);
        Dfp result = new Dfp(field, 3.0);
        // Set nans to INFINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.set(result, Dfp.INFINITE);

        // When
        Dfp output = dfp.dotrap(type, what, oper, result);

        // Then
        // Access private fields using reflection
        Field mantOutputField = Dfp.class.getDeclaredField("mant");
        mantOutputField.setAccessible(true);
        int[] mantOutput = (int[]) mantOutputField.get(output);

        boolean isZero = true;
        for (int m : mantOutput) {
            if (m != 0) {
                isZero = false;
                break;
            }
        }

        assertTrue(isZero, "Output should be zero");
        assertEquals(Dfp.QNAN, nansField.get(output), "NaN status should be QNAN");
    }

    @Test
    @DisplayName("dotrap with type FLAG_DIV_ZERO, nans=QNAN sets def nans to QNAN")
    void TC05_dotrap_FLAG_DIV_ZERO_QNAN() throws Exception {
        // Initialize DfpField
        DfpField field = new DfpField(128);
        Dfp dfp = new Dfp(field, 1.0);

        // Given
        int type = DfpField.FLAG_DIV_ZERO;
        String what = "quiet NaN division";
        Dfp oper = new Dfp(field, 2.0);
        Dfp result = new Dfp(field, 3.0);
        // Set nans to QNAN
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.set(result, Dfp.QNAN);

        // When
        Dfp output = dfp.dotrap(type, what, oper, result);

        // Then
        // Access private fields using reflection
        Field mantOutputField = Dfp.class.getDeclaredField("mant");
        mantOutputField.setAccessible(true);
        int[] mantOutput = (int[]) mantOutputField.get(output);

        boolean isZero = true;
        for (int m : mantOutput) {
            if (m != 0) {
                isZero = false;
                break;
            }
        }

        assertTrue(isZero, "Output should be zero");
        assertEquals(Dfp.QNAN, nansField.get(output), "NaN status should be QNAN");
    }
}
