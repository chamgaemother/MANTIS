package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_remove_1_1_Test {

    @Test
    @DisplayName("Remove a key with a null value from Flat3Map in flat mode")
    void TC13_removeKeyWithNullValueInFlatMode() throws Exception {
        // Arrange
        Flat3Map<String, String> map = new Flat3Map<>();

        // Using reflection to set flat mode with size 3, key1, key2, key3, value1, value2, value3
        Class<?> clazz = map.getClass();

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field value1Field = clazz.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field key2Field = clazz.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field value2Field = clazz.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field key3Field = clazz.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        Field value3Field = clazz.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, null);

        // Act
        Object result = map.remove("key3");

        // Assert
        assertNull(result, "Expected remove to return null for key with null value");

        // Verify key3 is nullified
        assertNull(key3Field.get(map), "Expected key3 to be null after removal");

        // Verify size is decremented to 2
        assertEquals(2, sizeField.getInt(map), "Expected size to be decremented to 2");
    }

    @Test
    @DisplayName("Remove a key with a null value from Flat3Map in delegate mode")
    void TC14_removeKeyWithNullValueInDelegateMode() throws Exception {
        // Arrange
        Flat3Map<String, String> map = new Flat3Map<>();

        // Using reflection to set delegateMap with a key mapped to null
        Class<?> clazz = map.getClass();

        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        HashMap<String, String> delegateMap = new HashMap<>();
        delegateMap.put("key1", "value1");
        delegateMap.put("key2", null);
        delegateMapField.set(map, delegateMap);

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Act
        Object result = map.remove("key2");

        // Assert
        assertNull(result, "Expected remove to return null for key with null value");

        // Verify key2 is removed from delegateMap
        @SuppressWarnings("unchecked")
        HashMap<String, String> updatedDelegateMap = (HashMap<String, String>) delegateMapField.get(map);
        assertFalse(updatedDelegateMap.containsKey("key2"), "Expected delegateMap to not contain 'key2' after removal");

        // Verify size is decremented to 1
        assertEquals(1, sizeField.getInt(map), "Expected size to be decremented to 1");
    }

    @Test
    @DisplayName("Remove a key that exists with matching hash but not equal in delegateMap")
    void TC15_removeKeyWithMatchingHashButNotEqualInDelegateMap() throws Exception {
        // Arrange
        Flat3Map<String, String> map = new Flat3Map<>();

        // Using reflection to set delegateMap with keys having same hash but not equal
        Class<?> clazz = map.getClass();

        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        HashMap<String, String> delegateMap = new HashMap<>();
        delegateMap.put("FB", "valueFB"); // "FB" and "Ea" have same hashCode
        delegateMap.put("Ea", "valueEa");
        delegateMapField.set(map, delegateMap);

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Act
        Object result = map.remove("EaNotPresent");

        // Assert
        assertNull(result, "Expected remove to return null for non-existent key");

        // Verify delegateMap still contains original keys
        @SuppressWarnings("unchecked")
        HashMap<String, String> updatedDelegateMap = (HashMap<String, String>) delegateMapField.get(map);
        assertTrue(updatedDelegateMap.containsKey("FB"), "Expected delegateMap to still contain 'FB'");
        assertTrue(updatedDelegateMap.containsKey("Ea"), "Expected delegateMap to still contain 'Ea'");
        
        // Verify size remains unchanged
        assertEquals(2, sizeField.getInt(map), "Expected size to remain unchanged at 2");
    }
}