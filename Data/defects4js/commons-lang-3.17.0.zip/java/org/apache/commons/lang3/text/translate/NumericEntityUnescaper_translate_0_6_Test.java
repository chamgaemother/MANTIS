package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.StringWriter;
import java.io.Writer;

public class NumericEntityUnescaper_translate_0_6_Test {

    @Test
    @DisplayName("Input entity with non-digit characters after '&#' but before ';', returns 0")
    public void TC26() throws Exception {
        // GIVEN
        CharSequence input = "&#6A;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("Input with multiple consecutive entities, ensuring each is processed correctly")
    public void TC27() throws Exception {
        // GIVEN
        CharSequence input = "&#65;&#66;&#67;";
        int index1 = 0;
        int index2 = 4;
        int index3 = 8;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result1 = unescaper.translate(input, index1, out);
        int result2 = unescaper.translate(input, index2, out);
        int result3 = unescaper.translate(input, index3, out);

        // THEN
        assertEquals("ABC", out.toString());
        assertEquals(4, result1);
        assertEquals(4, result2);
        assertEquals(4, result3);
    }

    @Test
    @DisplayName("Input with nested entities, ensuring proper processing")
    public void TC28() throws Exception {
        // GIVEN
        CharSequence input = "&amp;&#70;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals("&F", out.toString());
        assertEquals(5, result);
    }

    @Test
    @DisplayName("Input with '%' character after '&#', not a valid entity, returns 0")
    public void TC29() throws Exception {
        // GIVEN
        CharSequence input = "&#%41;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("Input with additional characters after valid entity, ensures correct offset")
    public void TC30() throws Exception {
        // GIVEN
        CharSequence input = "&#70;XYZ";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals("F", out.toString());
        assertEquals(4, result);
    }
}