import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
// package org.jsoup.select;
// 
// import org.jsoup.nodes.Node;
// import org.jsoup.select.NodeFilter.FilterResult;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// public class NodeTraversor_traverse_1_1_Test {
// 
//     // Mock implementation of NodeVisitor for testing
//     private static class MockNodeVisitor implements NodeVisitor {
//         int headCallCount = 0;
//         int tailCallCount = 0;
// 
//         @Override
//         public void head(Node node, int depth) {
//             headCallCount++;
//         }
// 
//         @Override
//         public void tail(Node node, int depth) {
//             tailCallCount++;
//         }
//     }
// 
//     // Simple MockNode implementation for testing purposes
//     private static class MockNode extends Node {
//         private Node parent;
//         private final String name;
//         private Node firstChild;
//         private Node nextSibling;
//         private int childCount = 0;
// 
//         public MockNode(String name) {
//             super(""); // Call to super with empty baseUri
//             this.name = name;
//         }
// 
//         public void setParent(Node parent) {
//             this.parent = parent;
//         }
// 
//         public void addChild(MockNode child) {
//             if (firstChild == null) {
//                 firstChild = child;
//             } else {
//                 MockNode current = (MockNode) firstChild;
//                 while (current.nextSibling != null) {
//                     current = (MockNode) current.nextSibling;
//                 }
//                 current.nextSibling = child;
//             }
//             child.setParent(this);
//             childCount++;
//         }
// 
//         @Override
//         public Node parentNode() {
//             return parent;
//         }
// 
//         @Override
//         public int childNodeSize() {
//             return childCount;
//         }
// 
//         @Override
//         public Node childNode(int index) {
//             Node current = firstChild;
//             for (int i = 0; i < index; i++) {
//                 if (current == null) return null;
//                 current = current.nextSibling();
//             }
//             return current;
//         }
// 
//         @Override
//         public Node nextSibling() {
//             return nextSibling;
//         }
// 
//         @Override
//         public int siblingIndex() {
//             if (parent == null) return 0;
//             int index = 0;
//             Node current = parent.firstChild;
//             while (current != null && current != this) {
//                 index++;
//                 current = current.nextSibling();
//             }
//             return index;
//         }
// 
//         @Override
//         public boolean hasParent() {
//             return parent != null;
//         }
// 
//         @Override
//         public void remove() {
//             if (parent == null) return;
//             MockNode prev = null;
//             MockNode current = (MockNode) parent.firstChild;
//             while (current != null) {
//                 if (current == this) {
//                     if (prev == null) {
//                         parent.firstChild = current.nextSibling;
//                     } else {
//                         prev.nextSibling = current.nextSibling;
//                     }
//                     parent.childCount--;
//                     break;
//                 }
//                 prev = current;
//                 current = (MockNode) current.nextSibling();
//             }
//         }
// 
//         @Override
//         public String nodeName() {
//             return name;
//         }
// 
//         @Override
//         public String outerHtml() {
//             return name;
//         }
//     }
// 
//     @Test
//     @DisplayName("Traverse a single root node with no children")
//     public void TC01() {
//         // GIVEN
//         MockNodeVisitor visitor = new MockNodeVisitor();
//         MockNode root = new MockNode("root");
// 
//         // WHEN
//         NodeTraversor.traverse(visitor, root);
// 
//         // THEN
//         assertEquals(1, visitor.headCallCount, "Head should be called once for root");
//         assertEquals(1, visitor.tailCallCount, "Tail should be called once for root");
//     }
// 
//     @Test
//     @DisplayName("Traverse a tree with multiple sibling nodes")
//     public void TC02() {
//         // GIVEN
//         MockNodeVisitor visitor = new MockNodeVisitor();
//         MockNode root = new MockNode("root");
//         root.addChild(new MockNode("child1"));
//         root.addChild(new MockNode("child2"));
//         root.addChild(new MockNode("child3"));
// 
//         // WHEN
//         NodeTraversor.traverse(visitor, root);
// 
//         // THEN
//         assertEquals(4, visitor.headCallCount, "Head should be called for root and each child");
//         assertEquals(4, visitor.tailCallCount, "Tail should be called for root and each child");
//     }
// 
//     @Test
//     @DisplayName("Traverse a tree with nested child nodes (depth > 1)")
//     public void TC03() {
//         // GIVEN
//         MockNodeVisitor visitor = new MockNodeVisitor();
//         MockNode root = new MockNode("root");
//         MockNode child1 = new MockNode("child1");
//         MockNode grandchild1 = new MockNode("grandchild1");
//         child1.addChild(grandchild1);
//         root.addChild(child1);
// 
//         // WHEN
//         NodeTraversor.traverse(visitor, root);
// 
//         // THEN
//         assertEquals(3, visitor.headCallCount, "Head should be called for root, child1, and grandchild1");
//         assertEquals(3, visitor.tailCallCount, "Tail should be called for root, child1, and grandchild1");
//     }
// 
//     @Test
//     @DisplayName("Traverse with a node being replaced during traversal")
//     public void TC04() {
//         // GIVEN
//         MockNodeVisitor visitor = new MockNodeVisitor() {
//             @Override
//             public void head(Node node, int depth) {
//                 super.head(node, depth);
//                 if (node.nodeName().equals("child1")) {
//                     // Replace child1 with newNode
//                     MockNode newNode = new MockNode("newChild1");
//                     node.replaceWith(newNode);
//                 }
//             }
//         };
// 
//         MockNode root = new MockNode("root");
//         MockNode child1 = new MockNode("child1");
//         MockNode child2 = new MockNode("child2");
//         root.addChild(child1);
//         root.addChild(child2);
// 
//         // WHEN
//         NodeTraversor.traverse(visitor, root);
// 
//         // THEN
//         assertEquals(4, visitor.headCallCount, "Head should be called for root, child1, newChild1, and child2");
//         assertEquals(4, visitor.tailCallCount, "Tail should be called for root, child1, newChild1, and child2");
//         assertNull(child1.parentNode(), "Original child1 should have no parent after replacement");
//     }
// 
//     @Test
//     @DisplayName("Traverse with a node being removed during traversal")
//     public void TC05() {
//         // GIVEN
//         MockNodeVisitor visitor = new MockNodeVisitor() {
//             @Override
//             public void tail(Node node, int depth) {
//                 super.tail(node, depth);
//                 if (node.nodeName().equals("child1")) {
//                     // Remove child1
//                     node.remove();
//                 }
//             }
//         };
// 
//         MockNode root = new MockNode("root");
//         MockNode child1 = new MockNode("child1");
//         MockNode child2 = new MockNode("child2");
//         root.addChild(child1);
//         root.addChild(child2);
// 
//         // WHEN
//         NodeTraversor.traverse(visitor, root);
// 
//         // THEN
//         assertEquals(3, visitor.headCallCount, "Head should be called for root, child1, and child2");
//         assertEquals(3, visitor.tailCallCount, "Tail should be called for root, child1, and child2");
//         assertNull(child1.parentNode(), "child1 should have no parent after removal");
//     }
// }