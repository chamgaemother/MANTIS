import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.LegendItem;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class XYBubbleRendererTest {

    private XYBubbleRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private int series;
    private int item;
    private CrosshairState crosshairState;
    private int pass;

    @BeforeEach
    public void setUp() {
        renderer = new XYBubbleRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        series = 0;
        item = 0;
        crosshairState = mock(CrosshairState.class);
        pass = 0;

        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.Plot.class));
    }

    @Test
    public void testDrawItem_ItemNotVisible() {
        renderer = spy(renderer);
        doReturn(false).when(renderer).getItemVisible(series, item);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, times(1)).getItemVisible(series, item);
        verifyNoMoreInteractions(g2, state, info, plot, domainAxis, rangeAxis, dataset, crosshairState);
    }

    @Test
    public void testDrawItem_DatasetNotXYZ_NaNZ() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);
        when(dataset instanceof XYZDataset).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, times(1)).getItemVisible(series, item);
        verify(dataset, times(1)).getXValue(series, item);
        verify(dataset, times(1)).getYValue(series, item);
        verifyNoMoreInteractions(g2, state, info, plot, domainAxis, rangeAxis, dataset, crosshairState);
    }

    @Test
    public void testDrawItem_ZIsNaN() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(dataset instanceof XYZDataset).thenReturn(true);
        when((XYZDataset) dataset.getZValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, times(1)).getItemVisible(series, item);
        verify(dataset, times(1)).getXValue(series, item);
        verify(dataset, times(1)).getYValue(series, item);
        verify(xyzDataset, times(1)).getZValue(series, item);
        verifyNoMoreInteractions(g2, state, info, plot, domainAxis, rangeAxis, xyzDataset, crosshairState);
    }

    @ParameterizedTest
    @ValueSource(ints = {XYBubbleRenderer.SCALE_ON_BOTH_AXES, XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS, XYBubbleRenderer.SCALE_ON_RANGE_AXIS})
    public void testDrawItem_ScaleTypes(int scaleType) {
        renderer = new XYBubbleRenderer(scaleType);
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(dataset instanceof XYZDataset).thenReturn(true);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when((XYZDataset) dataset).getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);

        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(plot.getDataset(anyInt())).thenReturn(dataset);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, times(1)).getItemVisible(series, item);
        verify(dataset, times(1)).getXValue(series, item);
        verify(dataset, times(1)).getYValue(series, item);
        verify(xyzDataset, times(1)).getZValue(series, item);
        verify(domainAxis, atLeastOnce()).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(rangeAxis, atLeastOnce()).valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class));
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).fill(any(Shape.class));
        verify(g2, atLeastOnce()).setStroke(any(Stroke.class));
        verify(g2, atLeastOnce()).draw(any(Shape.class));
        verify(plot, atLeastOnce()).getOrientation();
        verify(plot, atLeastOnce()).getDomainAxisEdge();
        verify(plot, atLeastOnce()).getRangeAxisEdge();
        verifyNoMoreInteractions(g2, state, info, plot, domainAxis, rangeAxis, dataset, crosshairState, xyzDataset);
    }

    @Test
    public void testDrawItem_VerticalOrientation() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when((XYZDataset) dataset).getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(plot, times(1)).getOrientation();
        verify(g2, times(1)).fill(any(Shape.class));
        verify(g2, times(1)).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_HorizontalOrientation() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when((XYZDataset) dataset).getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(plot, times(1)).getOrientation();
        verify(g2, times(1)).fill(any(Shape.class));
        verify(g2, times(1)).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_InvalidOrientation() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(null);

        assertThrows(IllegalStateException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        });
    }

    @Test
    public void testDrawItem_ItemLabelVisible() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, times(1)).isItemLabelVisible(series, item);
        verify(renderer, times(1)).drawItemLabel(eq(g2), eq(PlotOrientation.VERTICAL), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble(), eq(false));
    }

    @Test
    public void testDrawItem_ItemLabelNotVisible() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, times(1)).isItemLabelVisible(series, item);
        verify(renderer, never()).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    public void testDrawItem_InfoNull() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, null, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(info, never()).getOwner();
    }

    @Test
    public void testDrawItem_EntityCollectionNull() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        org.jfree.chart.plot.Plot plotOwner = mock(org.jfree.chart.plot.Plot.class);
        when(info.getOwner()).thenReturn(plotOwner);
        when(plotOwner.getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(info.getOwner(), times(1)).getEntityCollection();
    }

    @Test
    public void testDrawItem_EntityCollectionNotNull_CircleIntersects() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        org.jfree.chart.plot.Plot plotOwner = mock(org.jfree.chart.plot.Plot.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(plotOwner);
        when(plotOwner.getEntityCollection()).thenReturn(entities);
        Shape circle = mock(Shape.class);
        when(circle.intersects(dataArea)).thenReturn(true);
        doReturn(circle).when(renderer).createBubbleShape(anyDouble(), anyDouble(), anyDouble(), anyDouble());

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(entities, times(1)).add(any());
    }

    @Test
    public void testDrawItem_EntityCollectionNotNull_CircleDoesNotIntersect() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        org.jfree.chart.plot.Plot plotOwner = mock(org.jfree.chart.plot.Plot.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(plotOwner);
        when(plotOwner.getEntityCollection()).thenReturn(entities);
        Shape circle = mock(Shape.class);
        when(circle.intersects(dataArea)).thenReturn(false);
        doReturn(circle).when(renderer).createBubbleShape(anyDouble(), anyDouble(), anyDouble(), anyDouble());

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(entities, never()).add(any());
    }

    @Test
    public void testDrawItem_UpdateCrosshairValues() {
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset instanceof XYZDataset).thenReturn(true);
        XYZDataset xyzDataset = mock(XYZDataset.class);
        when(xyzDataset.getZValue(series, item)).thenReturn(5.0);
        when((XYZDataset) dataset).getZValue(series, item)).thenReturn(5.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(plot.indexOf(dataset)).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(crosshairState, times(1)).updateCrosshairValues(eq(10.0), eq(20.0), eq(1), eq(50.0), eq(50.0), eq(PlotOrientation.VERTICAL));
    }
}