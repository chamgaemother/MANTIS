package org.jfree.data.general;

import org.jfree.data.Range;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class DatasetUtils_iterateToFindRangeBounds_0_3_Test {

//     @Test
//     @DisplayName("Handles multiple iterations in MultiValueCategoryDataset with valid and invalid numbers")
//     public void iterateToFindRangeBounds_MultiValueDataset_mixedValues() {
        // GIVEN
//         MultiValueCategoryDataset dataset = new MultiValueCategoryDataset() {
//             @Override
//             public List getValues(int row, int column) {
//                 if (row == 0 && column == 0) {
//                     return Arrays.asList(1, 2, Double.NaN);
//                 } else if (row == 0 && column == 1) {
//                     return Arrays.asList(5, Double.NaN, 7);
//                 }
//                 return null;
//             }
// 
//             @Override
//             public int getColumnCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getColumnKey(int column) {
//                 return null;
//             }
// 
//             @Override
//             public int getColumnIndex(Comparable key) {
//                 return 0;
//             }
// 
//             @Override
//             public int getRowIndex(Comparable key) {
//                 return "Series1".equals(key) ? 0 : -1;
//             }
// 
//             @Override
//             public int getRowCount() {
//                 return 1;
//             }
// 
//             @Override
//             public Comparable getRowKey(int row) {
//                 return "Series1";
//             }
// 
//             @Override
//             public int getCategoryCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getCategory(int rowCount) {
//                 return null;
//             }
//         };
// 
//         List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
//         boolean includeInterval = true;
// 
        // WHEN
//         Range result = DatasetUtils.iterateToFindRangeBounds((CategoryDataset) dataset, visibleSeriesKeys, includeInterval);
// 
        // THEN
//         assertEquals(new Range(1.0, 7.0), result);
//     }

    @Test
    @DisplayName("Handles includeInterval=true with non-special CategoryDataset")
    public void iterateToFindRangeBounds_includeIntervalWithStandardDataset() {
        // GIVEN
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(4.0, "Series1", "Category1");
        dataset.addValue(9.0, "Series1", "Category2");
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertEquals(new Range(4.0, 9.0), result);
    }

//     @Test
//     @DisplayName("Handles StatisticalCategoryDataset with multiple series and complete data")
//     public void iterateToFindRangeBounds_StatisticalDataset_multipleSeries() {
        // GIVEN
//         StatisticalCategoryDataset dataset = new StatisticalCategoryDataset() {
//             @Override
//             public Number getMeanValue(int row, int column) {
//                 if (row == 0 && column == 0) {
//                     return 10.0;
//                 } else if (row == 1 && column == 1) {
//                     return 20.0;
//                 }
//                 return 0;
//             }
// 
//             @Override
//             public int getRowIndex(Comparable key) {
//                 if ("Series1".equals(key)) {
//                     return 0;
//                 } else if ("Series2".equals(key)) {
//                     return 1;
//                 }
//                 return -1;
//             }
// 
//             @Override
//             public Number getStdDevValue(int row, int column) {
//                 if (row == 0 && column == 0) {
//                     return 2.0;
//                 } else if (row == 1 && column == 1) {
//                     return 5.0;
//                 }
//                 return 0;
//             }
// 
//             @Override
//             public int getColumnCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getColumnKey(int column) {
//                 return null;
//             }
// 
//             @Override
//             public int getColumnIndex(Comparable key) {
//                 return 0;
//             }
// 
//             @Override
//             public int getRowCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getRowKey(int row) {
//                 return row == 0 ? "Series1" : "Series2";
//             }
// 
//             @Override
//             public int getCategoryCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getCategory(int rowCount) {
//                 return null;
//             }
//         };
// 
//         List<Comparable> visibleSeriesKeys = Arrays.asList("Series1", "Series2");
//         boolean includeInterval = true;
// 
        // WHEN
//         Range result = DatasetUtils.iterateToFindRangeBounds((CategoryDataset) dataset, visibleSeriesKeys, includeInterval);
// 
        // THEN
//         assertEquals(new Range(8.0, 25.0), result);
//     }

//     @Test
//     @DisplayName("Handles datasets with getRowIndex returning -1 for non-existing series")
//     public void iterateToFindRangeBounds_invalidSeriesKeys() {
        // GIVEN
//         BoxAndWhiskerCategoryDataset dataset = new BoxAndWhiskerCategoryDataset() {
//             @Override
//             public List getValues(int row, int column) {
//                 return null;
//             }
// 
//             @Override
//             public int getColumnCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getColumnKey(int column) {
//                 return null;
//             }
// 
//             @Override
//             public int getColumnIndex(Comparable key) {
//                 return 0;
//             }
// 
//             @Override
//             public int getRowIndex(Comparable key) {
//                 return -1;
//             }
// 
//             @Override
//             public int getRowCount() {
//                 return 1;
//             }
// 
//             @Override
//             public Comparable getRowKey(int row) {
//                 return null;
//             }
// 
//             @Override
//             public int getCategoryCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getCategory(int rowCount) {
//                 return null;
//             }
//         };
// 
//         List<Comparable> visibleSeriesKeys = Arrays.asList("InvalidSeries");
//         boolean includeInterval = true;
// 
        // WHEN
//         Range result = DatasetUtils.iterateToFindRangeBounds((CategoryDataset) dataset, visibleSeriesKeys, includeInterval);
// 
        // THEN
//         assertNull(result);
//     }

    @Test
    @DisplayName("Handles datasets with all values as NaN")
    public void iterateToFindRangeBounds_allValuesNaN() {
        // GIVEN
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Double.NaN, "Series1", "Category1");
        dataset.addValue(Double.NaN, "Series1", "Category2");
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = false;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertNull(result);
    }
}