package org.apache.commons.csv;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

public class CSVFormat_equals_0_1_Test {

    @Test
    @DisplayName("equals returns true when comparing the object to itself")
    public void TC01_equals_with_same_instance() {
        CSVFormat format = CSVFormat.DEFAULT;
        boolean result = format.equals(format);
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("equals returns false when comparing to null")
    public void TC02_equals_with_null_object() {
        CSVFormat format = CSVFormat.DEFAULT;
        Object obj = null;
        boolean result = format.equals(obj);
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when comparing to an object of a different class")
    public void TC03_equals_with_different_class_object() {
        CSVFormat format = CSVFormat.DEFAULT;
        Object obj = new Object();
        boolean result = format.equals(obj);
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when duplicateHeaderMode differs")
    public void TC04_equals_with_different_duplicateHeaderMode() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).build();
        boolean result = format1.equals(format2);
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when allowMissingColumnNames differs")
    public void TC05_equals_with_different_allowMissingColumnNames() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(false).build();
        boolean result = format1.equals(format2);
        Assertions.assertFalse(result);
    }
}