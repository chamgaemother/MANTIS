package org.apache.commons.math3.optim.univariate;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BracketFinder_search_0_2_Test {

    @Test
    @DisplayName("search method with multiple loop iterations (3 iterations) improving fC each time")
    void testTC06() throws Exception {
        // Arrange
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = mock(UnivariateFunction.class);
        GoalType goal = GoalType.MINIMIZE;
        double xA = 0.0;
        double growLimit = 2.0;
        
        // Mock behavior: fC improves each iteration
        when(func.value(anyDouble())).thenReturn(5.0, 4.0, 3.0, 2.0);
        
        // Act
        bracketFinder.search(func, goal, xA, growLimit);
        
        // Access private fields via reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        
        double lo = loField.getDouble(bracketFinder);
        double mid = midField.getDouble(bracketFinder);
        double hi = hiField.getDouble(bracketFinder);
        
        // Assert
        assertAll("BracketFinder search results",
            () -> assertEquals(0.0, lo, 1e-6, "lo should be updated correctly"),
            () -> assertEquals(1.0, mid, 1e-6, "mid should be updated correctly"),
            () -> assertEquals(2.0, hi, 1e-6, "hi should be updated correctly")
        );

        // Verify that func.value was called 4 times (3 iterations + initial call)
        verify(func, times(4)).value(anyDouble());
    }

    @Test
    @DisplayName("search method with multiple loop iterations (5 iterations) with fluctuating fC")
    void testTC07() throws Exception {
        // Arrange
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = mock(UnivariateFunction.class);
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 2.0;
        double growLimit = 1.5;
        
        // Mock behavior: fC fluctuates over 5 iterations
        when(func.value(anyDouble())).thenReturn(1.0, 2.0, 1.5, 2.5, 2.0, 3.0);
        
        // Act
        bracketFinder.search(func, goal, xA, growLimit);
        
        // Access private fields via reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        
        double lo = loField.getDouble(bracketFinder);
        double mid = midField.getDouble(bracketFinder);
        double hi = hiField.getDouble(bracketFinder);
        
        // Assert
        assertAll("BracketFinder search results",
            () -> assertTrue(lo < mid && mid < hi, "lo should be less than mid and mid less than hi"),
            () -> assertEquals(2.0, lo, 1e-6, "lo should be updated correctly"),
            () -> assertEquals(3.0, mid, 1e-6, "mid should be updated correctly"),
            () -> assertEquals(3.0, hi, 1e-6, "hi should be updated correctly")
        );

        // Verify that func.value was called 6 times (5 iterations + initial call)
        verify(func, times(6)).value(anyDouble());
    }

    @Test
    @DisplayName("search method with growLimit causing wLim condition to be true")
    void testTC08() throws Exception {
        // Arrange
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = mock(UnivariateFunction.class);
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double growLimit = 10.0;
        
        // Mock behavior: trigger wLim condition
        when(func.value(anyDouble())).thenReturn(10.0, 9.0, 8.0, 7.0, 6.0);
        
        // Act
        bracketFinder.search(func, goal, xA, growLimit);
        
        // Access private fields via reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        
        double lo = loField.getDouble(bracketFinder);
        double mid = midField.getDouble(bracketFinder);
        double hi = hiField.getDouble(bracketFinder);
        
        // Assert
        assertAll("BracketFinder search results",
            () -> assertEquals(1.0, lo, 1e-6, "lo should be updated correctly"),
            () -> assertEquals(2.0, mid, 1e-6, "mid should be updated correctly"),
            () -> assertEquals(11.0, hi, 1e-6, "hi should be updated correctly due to wLim condition")
        );
    }

    @Test
    @DisplayName("search method evaluates w multiple times within loop without triggering breaks")
    void testTC09() throws Exception {
        // Arrange
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = mock(UnivariateFunction.class);
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 1.0;
        double growLimit = 5.0;
        
        // Mock behavior: w evaluations never improve fC sufficiently
        when(func.value(anyDouble())).thenReturn(3.0, 2.5, 2.0, 2.5, 2.0, 2.5, 2.0);
        
        // Act
        bracketFinder.search(func, goal, xA, growLimit);
        
        // Access private fields via reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        
        double lo = loField.getDouble(bracketFinder);
        double mid = midField.getDouble(bracketFinder);
        double hi = hiField.getDouble(bracketFinder);
        
        // Assert
        assertAll("BracketFinder search results",
            () -> assertTrue(lo < mid && mid < hi, "lo should be less than mid and mid less than hi"),
            () -> assertEquals(1.0, lo, 1e-6, "lo should remain unchanged"),
            () -> assertEquals(3.0, mid, 1e-6, "mid should remain unchanged"),
            () -> assertEquals(5.0, hi, 1e-6, "hi should remain unchanged")
        );

        // Verify that func.value was called multiple times without triggering breaks
        verify(func, atLeast(7)).value(anyDouble());
    }

    @Test
    @DisplayName("search method with zero evaluations available, causing TooManyEvaluationsException")
    void testTC10() throws Exception {
        // Arrange
        BracketFinder bracketFinder = new BracketFinder();
        UnivariateFunction func = mock(UnivariateFunction.class);
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double growLimit = 1.618034;
        
        // Mock behavior: throw TooManyEvaluationsException when eval is called
        doThrow(new TooManyEvaluationsException(0)).when(func).value(anyDouble());
        
        // Act & Assert
        assertThrows(TooManyEvaluationsException.class, () -> {
            bracketFinder.search(func, goal, xA, growLimit);
        }, "Expected TooManyEvaluationsException to be thrown");
    }
}