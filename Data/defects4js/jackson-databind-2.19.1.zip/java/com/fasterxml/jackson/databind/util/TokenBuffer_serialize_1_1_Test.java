package com.fasterxml.jackson.databind.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.RawValue;
import com.fasterxml.jackson.databind.JsonSerializable;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.ArgumentCaptor;

public class TokenBuffer_serialize_1_1_Test {

    @Test
    @DisplayName("serialize with multiple segments, some segments have object IDs and others have type IDs")
    void TC37_serializeWithMultipleSegmentsAndMixedIds() throws IOException {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, true);
        buffer.writeStartObject();
        buffer.writeObjectId("object-1");
        buffer.writeFieldName("key1");
        buffer.writeString("value1");
        buffer.writeEndObject();
        buffer.writeStartObject();
        buffer.writeTypeId("type-1");
        buffer.writeFieldName("key2");
        buffer.writeString("value2");
        buffer.writeEndObject();

        JsonGenerator gen = mock(JsonGenerator.class);

        // Act
        buffer.serialize(gen);

        // Assert
        InOrder inOrder = inOrder(gen);
        inOrder.verify(gen).writeObjectId("object-1");
        inOrder.verify(gen).writeStartObject();
        inOrder.verify(gen).writeFieldName("key1");
        inOrder.verify(gen).writeString("value1");
        inOrder.verify(gen).writeEndObject();
        inOrder.verify(gen).writeTypeId("type-1");
        inOrder.verify(gen).writeStartObject();
        inOrder.verify(gen).writeFieldName("key2");
        inOrder.verify(gen).writeString("value2");
        inOrder.verify(gen).writeEndObject();
        inOrder.verifyNoMoreInteractions();
    }

    @Test
    @DisplayName("serialize with unsupported JsonToken, expecting RuntimeException")
    void TC38_serializeWithUnsupportedJsonToken() throws Exception {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, false);

        // Use reflection to inject an unsupported JsonToken
        java.lang.reflect.Field firstField = TokenBuffer.class.getDeclaredField("_first");
        firstField.setAccessible(true);
        Object firstSegment = firstField.get(buffer);

        java.lang.reflect.Field tokenTypesField = firstSegment.getClass().getDeclaredField("_tokenTypes");
        tokenTypesField.setAccessible(true);
        
        // Set an 'invalid' token type onto an unoccupied position in the token buffer, simulating rare cases.
        final long invalidTokenType = 16L;
        tokenTypesField.setLong(firstSegment, invalidTokenType);

        // Also, set a null token to prevent other tokens from interfering
        java.lang.reflect.Field tokensField = firstSegment.getClass().getDeclaredField("_tokens");
        tokensField.setAccessible(true);
        ((Object[]) tokensField.get(firstSegment))[0] = null;

        JsonGenerator gen = mock(JsonGenerator.class);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> buffer.serialize(gen));
        assertEquals("Internal error: should never end up through this code path", exception.getMessage());
    }

    @Test
    @DisplayName("serialize with FIELD_NAME token as null, expecting NullPointerException")
    void TC39_serializeWithNullFieldName() throws IOException {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeStartObject();
        buffer.writeFieldName((String) null); // Explicit cast to remove ambiguity
        JsonGenerator gen = mock(JsonGenerator.class);

        // Act & Assert
        NullPointerException exception = assertThrows(NullPointerException.class, () -> buffer.serialize(gen));
        assertNull(exception.getMessage()); // Depending on implementation, message might be null
    }

    @Test
    @DisplayName("serialize with VALUE_EMBEDDED_OBJECT as JsonSerializable returning exception")
    void TC40_serializeWithFaultyJsonSerializable() throws IOException {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, false);
        JsonSerializable faultySerializable = mock(JsonSerializable.class);
        doThrow(new IOException("Serialization failed")).when(faultySerializable).serialize(any(JsonGenerator.class), any());

        buffer.writeObject(faultySerializable);
        buffer.writeEndObject();
        JsonGenerator gen = mock(JsonGenerator.class);

        // Act & Assert
        IOException exception = assertThrows(IOException.class, () -> buffer.serialize(gen));
        assertEquals("Serialization failed", exception.getMessage());
    }

    @Test
    @DisplayName("serialize with multiple VALUE_EMBEDDED_OBJECT tokens mixed with other tokens in multiple segments")
    void TC41_serializeWithMixedEmbeddedObjectsAndOtherTokens() throws IOException {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, true);
        buffer.writeStartArray();
        buffer.writeObject(new RawValue("{\"custom\":\"data\"}")); // VALUE_EMBEDDED_OBJECT
        buffer.writeFieldName("key");
        buffer.writeString("value");
        buffer.writeObject(null); // VALUE_EMBEDDED_OBJECT with null
        buffer.writeEndArray();
        for (int i = 0; i < 20; i++) {
            buffer.writeNumber(i);
        }
        JsonGenerator gen = mock(JsonGenerator.class);

        // Act
        buffer.serialize(gen);

        // Assert
        InOrder inOrder = inOrder(gen);
        inOrder.verify(gen).writeStartArray();
        ArgumentCaptor<Object> embeddedObjectCaptor = ArgumentCaptor.forClass(Object.class);
        inOrder.verify(gen).writeEmbeddedObject(embeddedObjectCaptor.capture());
        assertTrue(embeddedObjectCaptor.getValue() instanceof RawValue);
        inOrder.verify(gen).writeFieldName("key");
        inOrder.verify(gen).writeString("value");
        inOrder.verify(gen).writeEmbeddedObject(null);
        inOrder.verify(gen).writeEndArray();
        for (int i = 0; i < 20; i++) {
            inOrder.verify(gen).writeNumber(i);
        }
        inOrder.verifyNoMoreInteractions();
    }
}
