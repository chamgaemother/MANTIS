package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class Dfp_dotrap_1_5_Test {

    @Test
    @DisplayName("dotrap with type FLAG_INVALID when result.nans is SNAN sets def as zero, copies sign, and sets nans to QNAN")
    public void TC16_dotrap_FLAG_INVALID_with_Snan() throws Exception {
        // Obtain DfpField from a zero Dfp instance
        Dfp zero = getZeroInstance();
        DfpField field = zero.getField();

        // Use reflection to access the protected constructor Dfp(DfpField, byte, byte)
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
        constructor.setAccessible(true);

        // Create a Dfp instance with nans set to SNAN (2) and sign set to +1
        Dfp result = constructor.newInstance(field, (byte)1, (byte)2);

        // Create a Dfp 'oper' instance, for example, zero
        Dfp oper = zero.newInstance(zero);

        // Call the dotrap method with FLAG_INVALID
        int type = DfpField.FLAG_INVALID;
        String what = "Invalid Operation";
        Dfp def = result.dotrap(type, what, oper, result);

        // Assert that def is zero
        Assertions.assertTrue(def.isZero(), "def should be zero");

        // Assert that the sign is copied from result
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte defSign = signField.getByte(def);
        Assertions.assertEquals(result.sign, defSign, "def sign should match result sign");

        // Assert that nans is set to QNAN (3)
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte defNans = nansField.getByte(def);
        Assertions.assertEquals((byte)3, defNans, "def nans should be QNAN");
    }

    @Test
    @DisplayName("dotrap with type FLAG_UNDERFLOW and (result.exp + mant.length) > MIN_EXP copies result and increments exp by ERR_SCALE")
    public void TC17_dotrap_FLAG_UNDERFLOW_exp_plus_mant_gt_MIN_EXP() throws Exception {
        // Obtain DfpField from a zero Dfp instance
        Dfp zero = getZeroInstance();
        DfpField field = zero.getField();

        // Use reflection to access the protected constructor Dfp(DfpField, byte, byte)
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
        constructor.setAccessible(true);

        // Create a Dfp instance with nans set to FINITE (0) and sign set to +1
        Dfp result = constructor.newInstance(field, (byte)1, (byte)0);

        // Set result.exp such that result.exp + mant.length > MIN_EXP
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int mantLength = ((int[]) mantField.get(result)).length;
        int minExp = -32767; // Assuming MIN_EXP is accessible or known
        expField.setInt(result, minExp - mantLength + 1);

        // Create a Dfp 'oper' instance, for example, zero
        Dfp oper = zero.newInstance(zero);

        // Call the dotrap method with FLAG_UNDERFLOW
        int type = DfpField.FLAG_UNDERFLOW;
        String what = "Underflow Operation";
        Dfp def = result.dotrap(type, what, oper, result);

        // Assert that def is a copy of result
        Assertions.assertEquals(result, def, "def should be a copy of result");

        // Assert that def.exp is incremented by ERR_SCALE
        Field defExpField = Dfp.class.getDeclaredField("exp");
        defExpField.setAccessible(true);
        int defExp = defExpField.getInt(def);
        Assertions.assertEquals(result.exp + 32760, defExp, "def.exp should be incremented by ERR_SCALE");
    }

    // Helper method to obtain a zero instance for initializing DfpField
    private Dfp getZeroInstance() throws Exception {
        // Assume DfpField has a constructor that takes precision as an int
        Constructor<DfpField> fieldConstructor = DfpField.class.getDeclaredConstructor(int.class);
        fieldConstructor.setAccessible(true);
        DfpField field = fieldConstructor.newInstance(10); // Example precision

        // Use reflection to access the protected constructor Dfp(DfpField, byte, byte)
        Constructor<Dfp> dfpConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
        dfpConstructor.setAccessible(true);
        return dfpConstructor.newInstance(field, (byte)1, (byte)0);
    }

}