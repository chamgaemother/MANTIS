package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.DoubleMetaphone;

public class DoubleMetaphone_doubleMetaphone_0_8_Test {

    @Test
    @DisplayName("doubleMetaphone(\"CIVIL\", false) handles 'CI' followed by 'V'")
    void TC36_doubleMetaphone_CI_before_V() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "CIVIL";
        boolean alternate = false;
        String result = encoder.doubleMetaphone(input, alternate);
        assertEquals("SFL", result, "'CI' before 'V' should be encoded as 'S'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"GODZILLA\", false) handles 'GZ'")
    void TC37_doubleMetaphone_GZ_combination() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GODZILLA";
        boolean alternate = false;
        String result = encoder.doubleMetaphone(input, alternate);
        assertEquals("KTSL", result, "'GZ' should be encoded correctly");
    }

    @Test
    @DisplayName("doubleMetaphone(\"PHILIPP\", false) handles 'PH'")
    void TC38_doubleMetaphone_PH_combination() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "PHILIPP";
        boolean alternate = false;
        String result = encoder.doubleMetaphone(input, alternate);
        assertEquals("FLPP", result, "'PH' should be encoded as 'F'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"GHANA\", false) handles 'GH' after consonant")
    void TC39_doubleMetaphone_GH_after_consonant() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GHANA";
        boolean alternate = false;
        String result = encoder.doubleMetaphone(input, alternate);
        assertEquals("KNNA", result, "'GH' after consonant should be encoded as 'K'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"JAZZ\", true) uses alternate encoding for 'J'")
    void TC40_doubleMetaphone_J_alternate_encoding() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "JAZZ";
        boolean alternate = true;
        String result = encoder.doubleMetaphone(input, alternate);
        assertEquals("JS", result, "Alternate encoding for 'J' should be used");
    }
}