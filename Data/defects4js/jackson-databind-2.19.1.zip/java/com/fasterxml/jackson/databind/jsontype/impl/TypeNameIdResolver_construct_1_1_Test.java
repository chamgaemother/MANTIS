package com.fasterxml.jackson.databind.jsontype.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.jsontype.NamedType;

/**
 * Generated JUnit 5 test class for TypeNameIdResolver.construct method.
 */
public class TypeNameIdResolver_construct_1_1_Test {

    @Test
    @DisplayName("Construct with annotation processing enabled and subtype having an annotated type name")
    void TC13_construct_with_annotation_processing_enabled_and_annotated_subtype() throws Exception {
        // Given
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        Mockito.when(config.isEnabled(Mockito.eq(com.fasterxml.jackson.databind.MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES)))
               .thenReturn(true);
        Mockito.when(config.isAnnotationProcessingEnabled()).thenReturn(true);

        JavaType baseType = Mockito.mock(JavaType.class);

        NamedType subtype = new NamedType(AnnotatedClass.class, "AnnotatedName");
        Collection<NamedType> subtypes = Arrays.asList(subtype);

        boolean forSer = false;
        boolean forDeser = true;

        // When
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // Then
        // Access _typeToId via reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);
        assertTrue(typeToId.containsKey(AnnotatedClass.class.getName()));
        assertEquals("AnnotatedName", typeToId.get(AnnotatedClass.class.getName()));

        // Access _idToType via reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        Map<String, JavaType> idToType = (Map<String, JavaType>) idToTypeField.get(resolver);
        assertTrue(idToType.containsKey("annotatedname"));
        // Assuming constructType returns the same mock instance for simplicity
        Mockito.verify(config).constructType(AnnotatedClass.class);
    }

    @Test
    @DisplayName("Construct with annotation processing enabled and subtype without an annotated type name, using default type ID")
    void TC14_construct_with_annotation_processing_enabled_and_unannotated_subtype() throws Exception {
        // Given
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        Mockito.when(config.isEnabled(Mockito.eq(com.fasterxml.jackson.databind.MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES)))
               .thenReturn(true);
        Mockito.when(config.isAnnotationProcessingEnabled()).thenReturn(true);

        JavaType baseType = Mockito.mock(JavaType.class);

        NamedType subtype = new NamedType(DefaultClass.class);
        Collection<NamedType> subtypes = Arrays.asList(subtype);

        boolean forSer = false;
        boolean forDeser = true;

        // When
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // Then
        // Access _typeToId via reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);
        String expectedId = DefaultClass.class.getSimpleName().toLowerCase();
        assertTrue(typeToId.containsKey(DefaultClass.class.getName()));
        assertEquals(expectedId, typeToId.get(DefaultClass.class.getName()));

        // Access _idToType via reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        Map<String, JavaType> idToType = (Map<String, JavaType>) idToTypeField.get(resolver);
        assertTrue(idToType.containsKey(expectedId));
        // Assuming constructType returns the same mock instance for simplicity
        Mockito.verify(config).constructType(DefaultClass.class);
    }

    // Dummy classes for testing purposes
    private static class AnnotatedClass {}
    private static class DefaultClass {}
}