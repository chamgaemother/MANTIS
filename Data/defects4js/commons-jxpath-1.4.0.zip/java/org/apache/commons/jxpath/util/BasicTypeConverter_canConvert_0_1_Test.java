package org.apache.commons.jxpath.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class BasicTypeConverter_canConvert_0_1_Test {

    @Test
    @DisplayName("object is null, should return true")
    void TC01_objectIsNull_shouldReturnTrue() {
        // Arrange
        Object object = null;
        Class<?> toType = Integer.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // Act
        boolean result = converter.canConvert(object, toType);

        // Assert
        assertTrue(result, "Expected canConvert to return true when object is null");
    }

    @Test
    @DisplayName("object type is assignable to useType, should return true")
    void TC02_objectTypeAssignable_shouldReturnTrue() {
        // Arrange
        Object object = new Integer(5);
        Class<?> toType = Number.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // Act
        boolean result = converter.canConvert(object, toType);

        // Assert
        assertTrue(result, "Expected canConvert to return true when object type is assignable to useType");
    }

    @Test
    @DisplayName("useType is String.class, should return true")
    void TC03_useTypeIsString_shouldReturnTrue() {
        // Arrange
        Object object = new Object();
        Class<?> toType = String.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // Act
        boolean result = converter.canConvert(object, toType);

        // Assert
        assertTrue(result, "Expected canConvert to return true when useType is String.class");
    }

    @Test
    @DisplayName("object is Boolean and useType is Number, should return true")
    void TC04_objectIsBoolean_useTypeIsNumber_shouldReturnTrue() {
        // Arrange
        Object object = Boolean.TRUE;
        Class<?> toType = Double.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // Act
        boolean result = converter.canConvert(object, toType);

        // Assert
        assertTrue(result, "Expected canConvert to return true when object is Boolean and useType is Number");
    }

    @Test
    @DisplayName("object is Boolean and useType is AtomicBoolean, should return true")
    void TC05_objectIsBoolean_useTypeIsAtomicBoolean_shouldReturnTrue() {
        // Arrange
        Object object = Boolean.FALSE;
        Class<?> toType = AtomicBoolean.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // Act
        boolean result = converter.canConvert(object, toType);

        // Assert
        assertTrue(result, "Expected canConvert to return true when object is Boolean and useType is AtomicBoolean");
    }
}