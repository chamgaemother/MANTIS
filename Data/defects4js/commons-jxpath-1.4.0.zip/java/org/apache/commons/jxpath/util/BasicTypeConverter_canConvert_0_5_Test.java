package org.apache.commons.jxpath.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

public class BasicTypeConverter_canConvert_0_5_Test {

    @Test
    @DisplayName("fromType is array and useType is Collection and canCreateCollection returns true, should return true")
    public void TC21() {
        // GIVEN
        Object object = new String[]{};
        Class<?> toType = ArrayList.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // WHEN
        boolean result = converter.canConvert(object, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true for TC21");
    }

    @Test
    @DisplayName("fromType is array and useType is Collection and canCreateCollection returns false, should return false")
    public void TC22() {
        // GIVEN
        Object object = new String[]{"test"};
        Class<?> toType = AbstractCollection.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // WHEN
        boolean result = converter.canConvert(object, toType);

        // THEN
        assertFalse(result, "Expected canConvert to return false for TC22");
    }

    @Test
    @DisplayName("fromType is Collection and useType is array with all elements convertible, should return true")
    public void TC23() {
        // GIVEN
        Collection<Object> collection = Arrays.asList(1, 2, 3);
        Class<?> toType = Number[].class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // WHEN
        boolean result = converter.canConvert(collection, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true for TC23");
    }

    @Test
    @DisplayName("fromType is Collection and useType is array with some elements not convertible, should return false")
    public void TC24() {
        // GIVEN
        Collection<Object> collection = Arrays.asList(1, "two", 3);
        Class<?> toType = Number[].class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // WHEN
        boolean result = converter.canConvert(collection, toType);

        // THEN
        assertFalse(result, "Expected canConvert to return false for TC24");
    }

    @Test
    @DisplayName("fromType is Collection and useType is Collection and canCreateCollection returns true, should return true")
    public void TC25() {
        // GIVEN
        Collection<Object> collection = Arrays.asList();
        Class<?> toType = ArrayList.class;
        BasicTypeConverter converter = new BasicTypeConverter();

        // WHEN
        boolean result = converter.canConvert(collection, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true for TC25");
    }
}