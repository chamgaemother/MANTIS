package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;

class ReaderBasedJsonParserTest {

    private ReaderBasedJsonParser createParser(String json) throws IOException {
        IOContext ctxt = new IOContext(null, json, false);
        Reader reader = new StringReader(json);
        CharsToNameCanonicalizer st = CharsToNameCanonicalizer.createRoot();
        return new ReaderBasedJsonParser(ctxt, 0, reader, null, st);
    }

    @Test
    void testNextFieldName_ObjectWithSingleField() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\":\"value\"}");
        assertEquals("name", parser.nextFieldName());
        assertEquals("value", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_EmptyObject() throws IOException {
        ReaderBasedJsonParser parser = createParser("{}");
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_MultipleFields() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name1\":\"value1\", \"name2\":\"value2\"}");
        assertEquals("name1", parser.nextFieldName());
        assertEquals("value1", parser.nextTextValue());
        assertEquals("name2", parser.nextFieldName());
        assertEquals("value2", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_TrailingComma() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name1\":\"value1\",}");
        assertEquals("name1", parser.nextFieldName());
        assertEquals("value1", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_SingleQuotes() throws IOException {
        ReaderBasedJsonParser parser = createParser("{'name':'value'}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_SINGLE_QUOTES;
        assertEquals("name", parser.nextFieldName());
        assertEquals("value", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_UnquotedNames() throws IOException {
        ReaderBasedJsonParser parser = createParser("{name:value}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_UNQUOTED_NAMES;
        assertEquals("name", parser.nextFieldName());
        assertEquals("value", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_InvalidUnquotedName() throws IOException {
        ReaderBasedJsonParser parser = createParser("{na me:value}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_UNQUOTED_NAMES;
        assertThrows(JsonParseException.class, () -> parser.nextFieldName());
    }

    @Test
    void testNextFieldName_MissingColon() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\" \"value\"}");
        assertEquals("name", parser.nextFieldName());
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    void testNextFieldName_UnexpectedCharacter() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\"@:\"value\"}");
        assertEquals("name", parser.nextFieldName());
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    void testNextFieldName_NonStandardToken() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\":NaN}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_NON_NUM_NUMBERS;
        assertEquals("name", parser.nextFieldName());
        assertTrue(parser.nextToken().isNaN());
    }

    @Test
    void testNextFieldName_ComplexObject() throws IOException {
        String json = "{\"name1\":\"value1\", \"name2\":{\"innerName\":\"innerValue\"}, \"name3\":[1,2,3]}";
        ReaderBasedJsonParser parser = createParser(json);
        assertEquals("name1", parser.nextFieldName());
        assertEquals("value1", parser.nextTextValue());
        assertEquals("name2", parser.nextFieldName());
        assertEquals("{\"innerName\":\"innerValue\"}", parser.getText());
        assertEquals("name3", parser.nextFieldName());
        assertEquals("[1,2,3]", parser.getText());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_EndOfInput() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"name\":\"value\"");
        assertEquals("name", parser.nextFieldName());
        assertEquals("value", parser.nextTextValue());
        assertThrows(JsonParseException.class, () -> parser.nextFieldName());
    }

    @Test
    void testNextFieldName_NullInput() throws IOException {
        ReaderBasedJsonParser parser = createParser(null);
        assertThrows(NullPointerException.class, () -> parser.nextFieldName());
    }

    @Test
    void testNextFieldName_OnlyComma() throws IOException {
        ReaderBasedJsonParser parser = createParser("{,}");
        assertThrows(JsonParseException.class, () -> parser.nextFieldName());
    }

    @Test
    void testNextFieldName_WhitespaceHandling() throws IOException {
        ReaderBasedJsonParser parser = createParser("{   \"name\"   :   \"value\"   }");
        assertEquals("name", parser.nextFieldName());
        assertEquals("value", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_NestedObjects() throws IOException {
        String json = "{\"outer\":{\"inner\":\"value\"}}";
        ReaderBasedJsonParser parser = createParser(json);
        assertEquals("outer", parser.nextFieldName());
        assertEquals("inner", parser.nextFieldName());
        assertEquals("value", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_ArrayContext() throws IOException {
        ReaderBasedJsonParser parser = createParser("[{\"name\":\"value\"}]");
        assertNull(parser.nextFieldName());
        parser.nextToken(); // START_ARRAY
        assertEquals("name", parser.nextFieldName());
        assertEquals("value", parser.nextTextValue());
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_RootNonObject() throws IOException {
        ReaderBasedJsonParser parser = createParser("\"just a string\"");
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldName_LeadingPlusSign() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"number\":+123}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS;
        assertEquals("number", parser.nextFieldName());
        assertEquals("123", parser.getText());
    }

    @Test
    void testNextFieldName_InvalidLeadingPlusSign() throws IOException {
        ReaderBasedJsonParser parser = createParser("{\"number\":+abc}");
        parser._features |= ReaderBasedJsonParser.FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS;
        assertEquals("number", parser.nextFieldName());
        assertThrows(JsonParseException.class, () -> parser.nextToken());
    }
}