import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TokenQueueTest {

    @Test
    void testEscapeCssIdentifier_EmptyString() {
        String input = "";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("", result);
    }
    
    @Test
    void testEscapeCssIdentifier_SimpleIdentifier() {
        String input = "simpleIdentifier";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("simpleIdentifier", result);
    }

    @Test
    void testEscapeCssIdentifier_StartsWithHyphen() {
        String input = "-identifier";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("-identifier", result);
    }

    @Test
    void testEscapeCssIdentifier_StartsWithHyphen_Digit() {
        String input = "-1identifier";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("-\\31 identifier", result);
    }

    @Test
    void testEscapeCssIdentifier_StartsWithDigit() {
        String input = "123identifier";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("\\31 23identifier", result);
    }

    @Test
    void testEscapeCssIdentifier_NullCharacter() {
        String input = "\u0000abc";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("\uFFFDabc", result);
    }

    @Test
    void testEscapeCssIdentifier_ControlCharacter() {
        String input = "\u0001abc";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("\\1 abc", result);
    }

    @Test
    void testEscapeCssIdentifier_UnescapedCharacters() {
        String input = "valid-identifier_123xyz";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("valid-identifier_123xyz", result);
    }

    @Test
    void testEscapeCssIdentifier_EscapedCharacters() {
        String input = "id#name";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("id\\#name", result);
    }

    @Test
    void testEscapeCssIdentifier_HighAscii() {
        String input = "\u0080abc";
        String result = TokenQueue.escapeCssIdentifier(input);
        assertEquals("\u0080abc", result);
    }
}