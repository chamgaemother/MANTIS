import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.XYStepRenderer;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class XYStepRendererTest {

    private XYStepRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    public void setUp() {
        renderer = new XYStepRenderer();
        g2 = Mockito.mock(Graphics2D.class);
        state = Mockito.mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = Mockito.mock(PlotRenderingInfo.class);
        plot = Mockito.mock(XYPlot.class);
        domainAxis = Mockito.mock(ValueAxis.class);
        rangeAxis = Mockito.mock(ValueAxis.class);
        dataset = Mockito.mock(XYDataset.class);
        crosshairState = Mockito.mock(CrosshairState.class);
    }

    @Test
    public void testDrawItem_NotVisible() {
        renderer.setItemVisible(0, 0, false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).setPaint(any(Paint.class));
    }

    @Test
    public void testDrawItem_HorizontalOrientation_SameY() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        mockAxesAndDataset(1.0, 2.0, 1.0, 2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any());
    }

    @Test
    public void testDrawItem_HorizontalOrientation_DifferentY() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        mockAxesAndDataset(1.0, 1.0, 1.0, 2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawItem_VerticalOrientation_SameY() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        mockAxesAndDataset(1.0, 2.0, 1.0, 2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any());
    }

    @Test
    public void testDrawItem_VerticalOrientation_DifferentY() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        mockAxesAndDataset(1.0, 1.0, 1.0, 2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawItem_NaNValues() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(Double.NaN, dataArea, RectangleEdge.BOTTOM)).thenReturn(Double.NaN);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2, never()).draw(any());
    }

    private void mockAxesAndDataset(double x0, double x1, double y0, double y1) {
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(dataset.getXValue(0, 0)).thenReturn(x0);
        when(dataset.getYValue(0, 0)).thenReturn(y0);
        when(dataset.getXValue(0, 1)).thenReturn(x1);
        when(dataset.getYValue(0, 1)).thenReturn(y1);
        when(domainAxis.valueToJava2D(x0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(x1, dataArea, RectangleEdge.BOTTOM)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(y0, dataArea, RectangleEdge.LEFT)).thenReturn(15.0);
        when(rangeAxis.valueToJava2D(y1, dataArea, RectangleEdge.LEFT)).thenReturn(15.0);
    }
}