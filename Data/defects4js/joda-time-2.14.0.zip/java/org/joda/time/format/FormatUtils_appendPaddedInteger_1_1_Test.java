package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

/**
 * Generated JUnit 5 test class for FormatUtils#appendPaddedInteger(Appendable, int, int)
 */
public class FormatUtils_appendPaddedInteger_1_1_Test {

    /**
     * A failing Appendable that throws IOException on any append operation.
     */
    private static class FailingAppendable implements Appendable {
        @Override
        public Appendable append(CharSequence csq) throws IOException {
            throw new IOException("Append failed");
        }

        @Override
        public Appendable append(CharSequence csq, int start, int end) throws IOException {
            throw new IOException("Append failed");
        }

        @Override
        public Appendable append(char c) throws IOException {
            throw new IOException("Append failed");
        }
    }

    @Test
    @DisplayName("appendPaddedInteger throws IOException when Appendable fails during append")
    public void TC16_appendPaddedInteger_IOExceptionHandling() {
        // Arrange
        Appendable appendable = new FailingAppendable();
        int value = 123;
        int size = 5;

        // Act & Assert
        assertDoesNotThrow(() -> {
            FormatUtils.appendPaddedInteger(appendable, value, size);
        }, "Method should handle IOException without throwing it.");
    }

    @Test
    @DisplayName("appendPaddedInteger handles IOException when Appendable fails with different size")
    public void TC17_appendPaddedInteger_IOExceptionHandling_DifferentSize() {
        // Arrange
        Appendable appendable = new FailingAppendable();
        int value = -456;
        int size = 8;

        // Act & Assert
        assertDoesNotThrow(() -> {
            FormatUtils.appendPaddedInteger(appendable, value, size);
        }, "Method should handle IOException without throwing it.");
    }
}