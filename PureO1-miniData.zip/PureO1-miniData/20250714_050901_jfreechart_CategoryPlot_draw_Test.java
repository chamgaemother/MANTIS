import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class CategoryPlotTest {

    private CategoryPlot plot;
    private Graphics2D g2Mock;
    private Rectangle2D areaMock;
    private Point2D anchorMock;
    private PlotState parentStateMock;
    private PlotRenderingInfo stateMock;
    private CategoryItemRenderer rendererMock;

    @BeforeEach
    public void setUp() {
        plot = new CategoryPlot();
        g2Mock = mock(Graphics2D.class);
        areaMock = mock(Rectangle2D.class);
        anchorMock = mock(Point2D.class);
        parentStateMock = mock(PlotState.class);
        stateMock = mock(PlotRenderingInfo.class);
        rendererMock = mock(CategoryItemRenderer.class);
        plot.setRenderer(rendererMock);
    }

    @Test
    public void testDraw_WidthTooSmall_ReturnsEarly() {
        when(areaMock.getWidth()).thenReturn(CategoryPlot.MINIMUM_WIDTH_TO_DRAW - 1);
        when(areaMock.getHeight()).thenReturn(CategoryPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verifyNoInteractions(g2Mock);
    }

    @Test
    public void testDraw_HeightTooSmall_ReturnsEarly() {
        when(areaMock.getWidth()).thenReturn(CategoryPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(areaMock.getHeight()).thenReturn(CategoryPlot.MINIMUM_HEIGHT_TO_DRAW - 1);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verifyNoInteractions(g2Mock);
    }

    @Test
    public void testDraw_StateNull_CreatesNewState() {
        when(areaMock.getWidth()).thenReturn(CategoryPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(areaMock.getHeight()).thenReturn(CategoryPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        when(areaMock.isEmpty()).thenReturn(false);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, null);
        // Assuming renderer.drawBackground is called
        verify(rendererMock, times(1)).drawBackground(g2Mock, plot, any(Rectangle2D.class));
    }

    @Test
    public void testDraw_DataAreaEmpty_ReturnsEarly() {
        when(areaMock.getWidth()).thenReturn(CategoryPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(areaMock.getHeight()).thenReturn(CategoryPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        when(areaMock.isEmpty()).thenReturn(true);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verifyNoInteractions(rendererMock);
    }

    @Test
    public void testDraw_RendererNotNull_DrawsBackgroundWithRenderer() {
        when(areaMock.getWidth()).thenReturn(CategoryPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(areaMock.getHeight()).thenReturn(CategoryPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        when(areaMock.isEmpty()).thenReturn(false);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(rendererMock, times(1)).drawBackground(g2Mock, plot, any(Rectangle2D.class));
    }

    @Test
    public void testDraw_RendererNull_DrawsDefaultBackground() {
        plot.setRenderer(null);
        when(areaMock.getWidth()).thenReturn(CategoryPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(areaMock.getHeight()).thenReturn(CategoryPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        when(areaMock.isEmpty()).thenReturn(false);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(plot, times(1)).drawBackground(g2Mock, any(Rectangle2D.class));
    }

    @Test
    public void testDraw_RangeAxisStateNull_DoesNotDrawRangeGridlines() {
        plot.clearRangeMarkers();
        when(areaMock.getWidth()).thenReturn(100.0);
        when(areaMock.getHeight()).thenReturn(100.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.drawItem(any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt()))
            .thenReturn(false);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        // Since rangeAxisState is null, verify that drawRangeGridlines is not called
        verify(rendererMock, never()).drawRangeLine(any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    public void testDraw_RangeAxisStateNotNull_DrawsRangeGridlines() {
        // Setup
        when(areaMock.getWidth()).thenReturn(100.0);
        when(areaMock.getHeight()).thenReturn(100.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        when(stateMock.getTicks()).thenReturn(mock(java.util.List.class));
        when(rendererMock.getPassCount()).thenReturn(1);
        when(rendererMock.drawItem(any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt()))
            .thenReturn(false);
        // Execute
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        // Verify
        verify(rendererMock, atLeastOnce()).drawRangeLine(any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    public void testDraw_ShadowGeneratorNull_NoShadow() {
        plot.setShadowGenerator(null);
        when(areaMock.getWidth()).thenReturn(200.0);
        when(areaMock.getHeight()).thenReturn(200.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        // Verify that no shadow drawing methods are called
        verify(g2Mock, never()).drawImage(any(), anyInt(), anyInt(), any());
    }

    @Test
    public void testDraw_ShadowGeneratorNotNull_DrawsShadow() throws Exception {
        ShadowGenerator shadowGeneratorMock = mock(ShadowGenerator.class);
        plot.setShadowGenerator(shadowGeneratorMock);
        when(shadowGeneratorMock.createDropShadow(any())).thenReturn(mock(java.awt.image.BufferedImage.class));
        when(shadowGeneratorMock.calculateOffsetX()).thenReturn(5);
        when(shadowGeneratorMock.calculateOffsetY()).thenReturn(5);
        when(areaMock.getWidth()).thenReturn(200.0);
        when(areaMock.getHeight()).thenReturn(200.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        // Verify that shadow is drawn
        verify(shadowGeneratorMock, times(1)).createDropShadow(any());
        verify(g2Mock, times(1)).drawImage(any(), eq(5), eq(5), any());
    }

    @Test
    public void testDraw_NoData_FindsNoData_ShowsNoDataMessage() {
        plot.setRenderer(null);
        when(plot.getDataset()).thenReturn(null);
        when(areaMock.getWidth()).thenReturn(100.0);
        when(areaMock.getHeight()).thenReturn(100.0);
        when(areaMock.isEmpty()).thenReturn(false);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(plot, times(1)).drawNoDataMessage(g2Mock, areaMock);
    }

    @Test
    public void testDraw_DataPresent_RenderData() {
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        plot.setRenderer(renderer);
        when(plot.getDataset()).thenReturn(mock(org.jfree.data.category.CategoryDataset.class));
        when(areaMock.getWidth()).thenReturn(150.0);
        when(areaMock.getHeight()).thenReturn(150.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        when(renderer.getPassCount()).thenReturn(1);
        when(renderer.drawItem(any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt()))
            .thenReturn(true);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(renderer, atLeastOnce()).drawItem(any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    public void testDraw_CrosshairVisible_DrawsCrosshair() {
        plot.setRangeCrosshairVisible(true);
        plot.setRangeCrosshairValue(50.0);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(rangeAxis.getPlot()).thenReturn(plot);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(75.0);
        when(areaMock.contains(anyDouble(), anyDouble())).thenReturn(true);
        when(areaMock.getWidth()).thenReturn(100.0);
        when(areaMock.getHeight()).thenReturn(100.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(rendererMock, atLeastOnce()).drawRangeLine(any(), any(), any(), eq(50.0), any(), any());
    }

    @Test
    public void testDraw_CrosshairNotVisible_DoesNotDrawCrosshair() {
        plot.setRangeCrosshairVisible(false);
        plot.setRangeCrosshairValue(50.0);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(rangeAxis.isInverted()).thenReturn(false);
        when(areaMock.contains(anyDouble(), anyDouble())).thenReturn(true);
        when(areaMock.getWidth()).thenReturn(100.0);
        when(areaMock.getHeight()).thenReturn(100.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(rendererMock, never()).drawRangeLine(any(), any(), any(), eq(50.0), any(), any());
    }

    @Test
    public void testDraw_ShadowGeneratorAndSuppressShadow_DoesNotDrawShadow() {
        ShadowGenerator shadowGeneratorMock = mock(ShadowGenerator.class);
        plot.setShadowGenerator(shadowGeneratorMock);
        when(g2Mock.getRenderingHint(eq(CategoryPlot.KEY_SUPPRESS_SHADOW_GENERATION))).thenReturn(Boolean.TRUE);
        when(areaMock.getWidth()).thenReturn(200.0);
        when(areaMock.getHeight()).thenReturn(200.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        // Verify that shadow is not drawn
        verify(shadowGeneratorMock, never()).createDropShadow(any());
        verify(g2Mock, never()).drawImage(any(), anyInt(), anyInt(), any());
    }

    @Test
    public void testDraw_DrawsOutlineWhenVisible() {
        plot.setOutlineVisible(true);
        when(plot.getRenderer()).thenReturn(rendererMock);
        when(rendererMock.drawOutline(any(), any(), any())).thenReturn(true);
        when(areaMock.getWidth()).thenReturn(200.0);
        when(areaMock.getHeight()).thenReturn(200.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(rendererMock, atLeastOnce()).drawOutline(any(), eq(plot), any());
    }

    @Test
    public void testDraw_DoesNotDrawOutlineWhenNotVisible() {
        plot.setOutlineVisible(false);
        when(plot.getRenderer()).thenReturn(rendererMock);
        when(areaMock.getWidth()).thenReturn(200.0);
        when(areaMock.getHeight()).thenReturn(200.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(rendererMock, never()).drawOutline(any(), eq(plot), any());
    }

    @Test
    public void testDraw_AnnotationsDrawn() {
        CategoryPlot plotWithAnnotation = new CategoryPlot();
        plotWithAnnotation.setRenderer(rendererMock);
        org.jfree.chart.annotations.CategoryAnnotation annotationMock = mock(org.jfree.chart.annotations.CategoryAnnotation.class);
        plotWithAnnotation.addAnnotation(annotationMock);
        when(areaMock.getWidth()).thenReturn(150.0);
        when(areaMock.getHeight()).thenReturn(150.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plotWithAnnotation.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(annotationMock, times(1)).draw(any(), any(), any(), any(), any());
    }

    @Test
    public void testDraw_ShadowGeneratorCreatesAndDrawsShadowImage() throws Exception {
        ShadowGenerator shadowGeneratorMock = mock(ShadowGenerator.class);
        when(shadowGeneratorMock.createDropShadow(any())).thenReturn(mock(java.awt.image.BufferedImage.class));
        when(shadowGeneratorMock.calculateOffsetX()).thenReturn(10);
        when(shadowGeneratorMock.calculateOffsetY()).thenReturn(10);
        plot.setShadowGenerator(shadowGeneratorMock);
        when(g2Mock.getRenderingHint(eq(CategoryPlot.KEY_SUPPRESS_SHADOW_GENERATION))).thenReturn(Boolean.FALSE);
        when(areaMock.getWidth()).thenReturn(200.0);
        when(areaMock.getHeight()).thenReturn(200.0);
        when(areaMock.isEmpty()).thenReturn(false);
        when(stateMock.getDataArea()).thenReturn(areaMock);
        plot.draw(g2Mock, areaMock, anchorMock, parentStateMock, stateMock);
        verify(shadowGeneratorMock, times(1)).createDropShadow(any());
        verify(g2Mock, times(1)).drawImage(any(), eq(10), eq(10), any());
    }
}