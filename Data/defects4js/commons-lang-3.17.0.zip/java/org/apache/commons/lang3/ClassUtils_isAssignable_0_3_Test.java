package org.apache.commons.lang3;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;

public class ClassUtils_isAssignable_0_3_Test {

    @Test
    @DisplayName("autoboxing is false, cls and toClass are compatible non-primitive classes; expect true")
    public void TC11_autoboxing_false_nonPrimitive_assignable() {
        // GIVEN
        Class<?> cls = ArrayList.class;
        Class<?> toClass = List.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result, "Expected isAssignable to return true");
    }

    @Test
    @DisplayName("autoboxing is false, cls and toClass are non-assignable non-primitive classes; expect false")
    public void TC12_autoboxing_false_nonPrimitive_nonAssignable() {
        // GIVEN
        Class<?> cls = String.class;
        Class<?> toClass = Integer.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result, "Expected isAssignable to return false");
    }

    @Test
    @DisplayName("autoboxing converts primitive cls to wrapper and classes are assignable; expect true")
    public void TC13_autoboxing_true_primitive_to_wrapper_assignable() {
        // GIVEN
        Class<?> cls = int.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result, "Expected isAssignable to return true");
    }

    @Test
    @DisplayName("autoboxing converts primitive cls to wrapper but classes are not assignable; expect false")
    public void TC14_autoboxing_true_primitive_to_wrapper_not_assignable() {
        // GIVEN
        Class<?> cls = int.class;
        Class<?> toClass = String.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result, "Expected isAssignable to return false");
    }

    @Test
    @DisplayName("autoboxing is true, cls is wrapper, toClass is primitive, and assignable; expect true")
    public void TC15_autoboxing_true_wrapper_to_primitive_assignable() {
        // GIVEN
        Class<?> cls = Integer.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result, "Expected isAssignable to return true");
    }
}