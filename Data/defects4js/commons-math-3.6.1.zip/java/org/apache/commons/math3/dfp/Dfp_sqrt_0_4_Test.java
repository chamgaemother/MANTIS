package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Dfp_sqrt_0_4_Test {

    @Test
    @DisplayName("sqrt() loop terminates when dx mantissa last digit is zero")
    public void test_sqrt_loopTerminates_whenDxMantissaLastDigitZero() throws Exception {
        // Arrange
        // Initialize Dfp instance with finite nans and specific mantissa
        DfpField field = new DfpField(10); // Assuming a field precision of 10 digits
        Dfp input = new Dfp(field);
        
        // Use reflection to set the 'mant' field
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = new int[field.getRadixDigits()];
        mantField.set(input, mantissa);
        
        // Modify the last digit of mantissa to zero to satisfy the termination condition
        mantissa[mantissa.length - 1] = 0;
        
        // Act
        Dfp result = input.sqrt();
        
        // Assert
        // Verify that the last digit of dx.mant is zero
        int[] resultMantissa = (int[]) mantField.get(result);
        assertEquals(0, resultMantissa[resultMantissa.length - 1], "The last digit of mantissa should be zero");
    }
}
