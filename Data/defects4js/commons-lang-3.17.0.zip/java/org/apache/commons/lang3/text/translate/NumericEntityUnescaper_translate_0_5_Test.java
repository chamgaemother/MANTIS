package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.Set;

public class NumericEntityUnescaper_translate_0_5_Test {

    @Test
    @DisplayName("Input entity with semicolon but OPTION not set, performs translation")
    public void TC21() throws Exception {
        // GIVEN
        CharSequence input = "&#66;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        Assertions.assertEquals("B", out.toString());
        Assertions.assertEquals(4, result);
    }

    @Test
    @DisplayName("Input entity with semicolon and OPTION.errorIfNoSemiColon set, performs translation")
    public void TC22() throws Exception {
        // GIVEN
        CharSequence input = "&#67;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // Set OPTION.errorIfNoSemiColon using reflection
        Field optionsField = NumericEntityUnescaper.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<NumericEntityUnescaper.OPTION> options = (Set<NumericEntityUnescaper.OPTION>) optionsField.get(unescaper);
        options.add(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        Assertions.assertEquals("C", out.toString());
        Assertions.assertEquals(4, result);
    }

    @Test
    @DisplayName("Input entity with missing semicolon and OPTION.errorIfNoSemiColon set, throws exception")
    public void TC23() throws Exception {
        // GIVEN
        CharSequence input = "&#68";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // Set OPTION.errorIfNoSemiColon using reflection
        Field optionsField = NumericEntityUnescaper.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<NumericEntityUnescaper.OPTION> options = (Set<NumericEntityUnescaper.OPTION>) optionsField.get(unescaper);
        options.add(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);

        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            unescaper.translate(input, index, out);
        });
    }

    @Test
    @DisplayName("Input entity with OPTION.semiColonRequired set but semicolon present, performs translation")
    public void TC24() throws Exception {
        // GIVEN
        CharSequence input = "&#69;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // Set OPTION.semiColonRequired using reflection
        Field optionsField = NumericEntityUnescaper.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<NumericEntityUnescaper.OPTION> options = (Set<NumericEntityUnescaper.OPTION>) optionsField.get(unescaper);
        options.add(NumericEntityUnescaper.OPTION.semiColonRequired);

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        Assertions.assertEquals("E", out.toString());
        Assertions.assertEquals(4, result);
    }

    @Test
    @DisplayName("Input contains incomplete entity at end of input, no translation performed")
    public void TC25() throws Exception {
        // GIVEN
        CharSequence input = "Text &#70";
        int index = 5;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        Assertions.assertEquals(0, result);
    }
}