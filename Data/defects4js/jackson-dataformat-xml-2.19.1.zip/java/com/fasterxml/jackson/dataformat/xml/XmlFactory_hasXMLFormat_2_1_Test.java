package com.fasterxml.jackson.dataformat.xml;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// import com.fasterxml.jackson.core.format.InputAccessor;
// import com.fasterxml.jackson.core.format.ByteArrayInputAccessor;
// import com.fasterxml.jackson.core.format.MatchStrength;
// 
public class XmlFactory_hasXMLFormat_2_1_Test {
// 
//     @Test
//     @DisplayName("InputAccessor starts with '<?x', representing an incomplete XML declaration, returns SOLID_MATCH")
//     public void TC19_hasXMLFormat_with_partial_declaration_returns_SolidMatch() throws Exception {
        // GIVEN
//         byte[] bytes = { '<', '?', 'x' };
//         InputAccessor acc = new ByteArrayInputAccessor(bytes);
//         XmlFactory factory = new XmlFactory();
// 
        // WHEN
//         MatchStrength result = factory.hasXMLFormat(acc);
// 
        // THEN
//         assertEquals(MatchStrength.SOLID_MATCH, result);
//     }
// 
//     @Test
//     @DisplayName("InputAccessor starts with '<!DOCTYPE' fully, returns SOLID_MATCH")
//     public void TC20_hasXMLFormat_with_complete_doctype_returns_SolidMatch() throws Exception {
        // GIVEN
//         byte[] bytes = { '<', '!', 'D', 'O', 'C', 'T', 'Y', 'P', 'E' };
//         InputAccessor acc = new ByteArrayInputAccessor(bytes);
//         XmlFactory factory = new XmlFactory();
// 
        // WHEN
//         MatchStrength result = factory.hasXMLFormat(acc);
// 
        // THEN
//         assertEquals(MatchStrength.SOLID_MATCH, result);
//     }
// }
}