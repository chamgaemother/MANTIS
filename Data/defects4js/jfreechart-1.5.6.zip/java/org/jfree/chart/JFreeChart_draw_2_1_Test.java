package org.jfree.chart;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.ui.Align;
import org.jfree.chart.ChartRenderingInfo;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class JFreeChart_draw_2_1_Test {

//     @Test
//     @DisplayName("TC04: Draw method with elementHinting enabled and id is null, expecting only 'ref' rendering hint is set")
//     void test_TC04_draw_with_elementHinting_enabled_id_null() throws Exception {
        // GIVEN
        // Mock Plot
//         Plot mockPlot = mock(Plot.class);
//         JFreeChart chart = new JFreeChart("Test Chart", mockPlot);
// 
        // Use reflection to set private fields: elementHinting=true, id=null
//         setPrivateField(chart, "elementHinting", true);
//         setPrivateField(chart, "id", null);
// 
        // Mock Graphics2D and other dependencies
//         Graphics2D mockG2 = mock(Graphics2D.class);
//         Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 100, 100);
//         Point2D anchor = new Point2D.Double(50, 50);
//         ChartRenderingInfo info = mock(ChartRenderingInfo.class);
//         EntityCollection mockEntityCollection = mock(EntityCollection.class);
//         when(info.getEntityCollection()).thenReturn(mockEntityCollection);
// 
        // WHEN
//         chart.draw(mockG2, chartArea, anchor, info);
// 
        // THEN
        // Capture the arguments passed to setRenderingHint
//         ArgumentCaptor<Object> keyCaptor = ArgumentCaptor.forClass(Object.class);
//         ArgumentCaptor<Object> valueCaptor = ArgumentCaptor.forClass(Object.class);
//         verify(mockG2, atLeastOnce()).setRenderingHint(keyCaptor.capture(), valueCaptor.capture());
// 
        // Verify at least one rendering hint is set
//         assertTrue(keyCaptor.getAllValues().contains("org.jfree.chart.JFreeChart$1"), "Rendering hint key should be KEY_BEGIN_ELEMENT");
// 
        // Assert value is Map with only 'ref' key with 'JFREECHART_TOP_LEVEL'
//         @SuppressWarnings("unchecked")
//         Map<String, String> hintMap = (Map<String, String>) valueCaptor.getAllValues().stream().filter(value -> value instanceof Map).findFirst().orElse(null);
//         assertTrue(hintMap != null && hintMap.size() == 1, "Rendering hint map should contain only one entry");
//         assertEquals("JFREECHART_TOP_LEVEL", hintMap.get("ref"), "Rendering hint 'ref' should be 'JFREECHART_TOP_LEVEL");
//     }

    @Test
    @DisplayName("TC05: Draw method with backgroundImage set and alignment to left, expecting image drawn aligned to the left")
    void test_TC05_draw_with_backgroundImage_set_alignment_left() throws Exception {
        // GIVEN
        // Mock Plot
        Plot mockPlot = mock(Plot.class);
        JFreeChart chart = new JFreeChart("Test Chart", mockPlot);

        // Mock backgroundImage
        Image mockImage = mock(Image.class);
        when(mockImage.getWidth(null)).thenReturn(50);
        when(mockImage.getHeight(null)).thenReturn(50);

        // Set backgroundImage via reflection
        setPrivateField(chart, "backgroundImage", mockImage);

        // Set backgroundImageAlignment to Align.LEFT via reflection
        setPrivateField(chart, "backgroundImageAlignment", Align.LEFT);

        // Set backgroundImageAlpha to 0.5f via reflection
        setPrivateField(chart, "backgroundImageAlpha", 0.5f);

        // Mock Graphics2D
        Graphics2D mockG2 = mock(Graphics2D.class);

        // Define chartArea and anchor
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D anchor = new Point2D.Double(50, 50);

        // Create ChartRenderingInfo
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        when(info.getEntityCollection()).thenReturn(mock(EntityCollection.class));

        // WHEN
        chart.draw(mockG2, chartArea, anchor, info);

        // THEN
        // Verify that drawImage was called with image aligned to left
        // Expected x=0, y=(100-50)/2=25, width=50, height=50, observer=null
        verify(mockG2).drawImage(eq(mockImage), eq(0), eq(25), eq(50), eq(50), isNull());
    }

    @Test
    @DisplayName("TC06: Draw method with backgroundImage set and alignment to right, expecting image drawn aligned to the right")
    void test_TC06_draw_with_backgroundImage_set_alignment_right() throws Exception {
        // GIVEN
        // Mock Plot
        Plot mockPlot = mock(Plot.class);
        JFreeChart chart = new JFreeChart("Test Chart", mockPlot);

        // Mock backgroundImage
        Image mockImage = mock(Image.class);
        when(mockImage.getWidth(null)).thenReturn(50);
        when(mockImage.getHeight(null)).thenReturn(50);

        // Set backgroundImage via reflection
        setPrivateField(chart, "backgroundImage", mockImage);

        // Set backgroundImageAlignment to Align.RIGHT via reflection
        setPrivateField(chart, "backgroundImageAlignment", Align.RIGHT);

        // Set backgroundImageAlpha to 0.5f via reflection
        setPrivateField(chart, "backgroundImageAlpha", 0.5f);

        // Mock Graphics2D
        Graphics2D mockG2 = mock(Graphics2D.class);

        // Define chartArea and anchor
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D anchor = new Point2D.Double(50, 50);

        // Create ChartRenderingInfo
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        when(info.getEntityCollection()).thenReturn(mock(EntityCollection.class));

        // WHEN
        chart.draw(mockG2, chartArea, anchor, info);

        // THEN
        // Verify that drawImage was called with image aligned to right
        // Expected x=100-50=50, y=(100-50)/2=25, width=50, height=50, observer=null
        verify(mockG2).drawImage(eq(mockImage), eq(50), eq(25), eq(50), eq(50), isNull());
    }

    private void setPrivateField(JFreeChart chart, String fieldName, Object value) throws Exception {
        Field field = JFreeChart.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(chart, value);
    }
}