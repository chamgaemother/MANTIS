import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.utils.FixedLengthBlockOutputStream;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class TarArchiveOutputStreamTest {

    private ByteArrayOutputStream byteArrayOutputStream;
    private TarArchiveOutputStream tarOutputStream;

    @BeforeEach
    void setUp() {
        byteArrayOutputStream = new ByteArrayOutputStream();
        tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
    }

    @Test
    void testNullEntryThrowsException() {
        Exception exception = assertThrows(ClassCastException.class, () -> {
            tarOutputStream.putArchiveEntry(null);
        });

        String expectedMessage = "Cannot invoke \"org.apache.commons.compress.archivers.tar.TarArchiveEntry.getName()\" because \"archiveEntry\" is null";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void testGlobalPaxHeaderEntry() throws IOException {
        TarArchiveEntry entry = new TarArchiveEntry("./GlobalPaxHeader", TarConstants.LF_PAX_GLOBAL_EXTENDED_HEADER);
        withOutputsSuppressed(() -> {

            tarOutputStream.putArchiveEntry(entry);
            tarOutputStream.closeArchiveEntry();

            assertEquals(0, entry.getSize());
        });
    }

    @Test
    void testOverflowEntryName_FAIL() throws IOException {
        TarArchiveEntry entry = new TarArchiveEntry(generateStringOfLength(TarConstants.NAMELEN + 1));

        try {
            tarOutputStream.putArchiveEntry(entry);
            fail("Expected IllegalArgumentException for overflow entry name.");
        } catch (IllegalArgumentException e) {
            assertEquals("file name '" + entry.getName() + "' is too long ( > 100 bytes)", e.getMessage());
        }
    }

    @Test
    void testTruncatedEntryName() throws IOException {
        TarArchiveEntry entry = new TarArchiveEntry(generateStringOfLength(TarConstants.NAMELEN + 1));
        tarOutputStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);

        tarOutputStream.putArchiveEntry(entry);

        assertNotNull(entry.getName());
    }

    @Test
    void testAddPaxHeadersForNonAsciiNames() throws IOException {
        TarArchiveEntry entry = new TarArchiveEntry("nameWithÜmlaut");
        tarOutputStream.setAddPaxHeadersForNonAsciiNames(true);

        tarOutputStream.putArchiveEntry(entry);
    }

    @Test
    void testBigNumber_FAIL() {
        TarArchiveEntry entry = new TarArchiveEntry("normalName");
        entry.setSize(TarConstants.MAXSIZE + 1);

        try {
            tarOutputStream.putArchiveEntry(entry);
            fail("Expected IllegalArgumentException for big number.");
        } catch (IllegalArgumentException e) {
            assertEquals("entry size '" + entry.getSize() + "' is too big ( > 8589934591 ). Use STAR or POSIX extensions to overcome this limit", e.getMessage());
        }
    }

    @Test
    void testBigNumber_POSIX() throws IOException {
        TarArchiveEntry entry = new TarArchiveEntry("normalName");
        entry.setSize(TarConstants.MAXSIZE + 1);
        tarOutputStream.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);

        tarOutputStream.putArchiveEntry(entry);
    }

    @Test
    void testBigNumber_STAR() throws IOException {
        TarArchiveEntry entry = new TarArchiveEntry("normalName");
        entry.setSize(TarConstants.MAXSIZE + 1);
        tarOutputStream.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR);

        tarOutputStream.putArchiveEntry(entry);
    }

    private String generateStringOfLength(int length) {
        return new String(new char[length]).replace('\0', 'a');
    }

    private void withOutputsSuppressed(Runnable runnable) {
        // Suppress the console output for clean test results
        java.io.PrintStream originalOut = System.out;
        java.io.PrintStream originalErr = System.err;
        try {
            System.setOut(new java.io.PrintStream(new java.io.OutputStream() {
                public void write(int b) {/*NO */}
            }));
            System.setErr(new java.io.PrintStream(new java.io.OutputStream() {
                public void write(int b) {/*NO */}
            }));
            runnable.run();
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
        }
    }
}