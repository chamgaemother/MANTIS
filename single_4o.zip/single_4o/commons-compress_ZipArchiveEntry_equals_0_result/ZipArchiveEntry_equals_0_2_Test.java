package org.apache.commons.compress.archivers.zip;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

public class ZipArchiveEntry_equals_0_2_Test {

    private ZipArchiveEntry createZipArchiveEntry(String name, String comment,
                                                   long lastModifiedTime, long lastAccessTime, long creationTime,
                                                   int internalAttributes, int platform, long externalAttributes,
                                                   int method, long size, long crc, long compressedSize, byte[] centralDirExtra,
                                                   byte[] localFileDataExtra, long localHeaderOffset, long dataOffset,
                                                   GeneralPurposeBit generalPurposeBit) {
        try {
            ZipArchiveEntry entry = new ZipArchiveEntry(name);
            setField(entry, "comment", comment);
            setField(entry, "lastModifiedTime", lastModifiedTime);
            setField(entry, "lastAccessTime", lastAccessTime);
            setField(entry, "creationTime", creationTime);
            setField(entry, "internalAttributes", internalAttributes);
            setField(entry, "platform", platform);
            setField(entry, "externalAttributes", externalAttributes);
            setField(entry, "method", method);
            setField(entry, "size", size);
            setField(entry, "crc", crc);
            setField(entry, "compressedSize", compressedSize);
            setField(entry, "localHeaderOffset", localHeaderOffset);
            setField(entry, "dataOffset", dataOffset);
            setField(entry, "centralDirectoryExtra", centralDirExtra);
            setField(entry, "localFileDataExtra", localFileDataExtra);
            setField(entry, "generalPurposeBit", generalPurposeBit);
            return entry;
        } catch (Exception e) {
            throw new RuntimeException("Reflection error", e);
        }
    }

    private void setField(Object object, String fieldName, Object value) throws Exception {
        Field field = ZipArchiveEntry.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(object, value);
    }

    private boolean equalsWithReflection(ZipArchiveEntry entry, Object obj) {
        try {
            Method equalsMethod = ZipArchiveEntry.class.getDeclaredMethod("equals", Object.class);
            return (boolean) equalsMethod.invoke(entry, obj);
        } catch (Exception e) {
            throw new RuntimeException("Reflection invoke error", e);
        }
    }

    @Test
    @DisplayName("Verify equality with one null comment")
    void test_Equals_With_Null_Comment() {
        ZipArchiveEntry entry1 = createZipArchiveEntry("entryName", null, 100L, 100L, 100L,
                1, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        ZipArchiveEntry entry2 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        boolean result = equalsWithReflection(entry1, entry2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Verify equality with different internal attributes")
    void test_Equals_With_Different_Internal_Attributes() {
        ZipArchiveEntry entry1 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        ZipArchiveEntry entry2 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                2, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        boolean result = equalsWithReflection(entry1, entry2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Verify equality when external attributes differ")
    void test_Equals_With_Different_External_Attributes() {
        ZipArchiveEntry entry1 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        ZipArchiveEntry entry2 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 2L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        boolean result = equalsWithReflection(entry1, entry2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Verify equality check with different size values")
    void test_Equals_With_Different_Sizes() {
        ZipArchiveEntry entry1 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        ZipArchiveEntry entry2 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 1L, 1, 200L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        boolean result = equalsWithReflection(entry1, entry2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Verify equality when all properties match")
    void test_Equals_With_All_Properties_Match() {
        ZipArchiveEntry entry1 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        ZipArchiveEntry entry2 = createZipArchiveEntry("entryName", "Some Comment", 100L, 100L, 100L,
                1, 1, 1L, 1, 100L, 1L, 100L, new byte[]{0x01}, new byte[]{0x01}, 100L, 100L, new GeneralPurposeBit());

        boolean result = equalsWithReflection(entry1, entry2);

        assertTrue(result);
    }
}