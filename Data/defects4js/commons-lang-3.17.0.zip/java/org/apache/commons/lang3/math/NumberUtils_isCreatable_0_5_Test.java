package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_isCreatable_0_5_Test {

    @Test
    @DisplayName("isCreatable(\"1e+10\") returns true for exponent with '+' sign")
    public void TC21() {
        String input = "1e+10";
        boolean result = NumberUtils.isCreatable(input);
        assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\".5\") returns false for missing leading digit")
    public void TC22() {
        String input = ".5";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"1e-\") returns false when exponent sign is present without digits")
    public void TC23() {
        String input = "1e-";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"1e10.5\") returns false for decimal point in exponent")
    public void TC24() {
        String input = "1e10.5";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"0x1A3F\") returns true for valid hexadecimal without sign")
    public void TC25() {
        String input = "0x1A3F";
        boolean result = NumberUtils.isCreatable(input);
        assertTrue(result);
    }
}