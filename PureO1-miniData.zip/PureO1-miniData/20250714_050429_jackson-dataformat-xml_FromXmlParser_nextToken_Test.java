package com.fasterxml.jackson.dataformat.xml.deser;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.StringWriter;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;

public class FromXmlParserTest {

    private IOContext ioContext;
    private ObjectCodec objectCodec;
    private XMLStreamReader xmlStreamReader;
    private XmlNameProcessor xmlNameProcessor;
    private FromXmlParser parser;

    @BeforeEach
    public void setUp() throws XMLStreamException, IOException {
        ioContext = mock(IOContext.class);
        objectCodec = mock(ObjectCodec.class);
        xmlStreamReader = mock(XMLStreamReader.class);
        xmlNameProcessor = mock(XmlNameProcessor.class);
        when(ioContext.contentReference()).thenReturn(mock(com.fasterxml.jackson.core.type.ContentReference.class));
    }

    private void initializeParser(int firstToken) throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(firstToken, XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(firstToken);
        when(xmlStreamReader.getLocalName()).thenReturn("root");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
    }

    @Test
    public void testNextToken_StartObject() throws XMLStreamException, IOException {
        initializeParser(XMLStreamReader.START_ELEMENT);
        JsonToken token = parser.nextToken();
        assertEquals(JsonToken.START_OBJECT, token);
    }

    @Test
    public void testNextToken_EndObject() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(XMLStreamReader.START_ELEMENT, XMLStreamReader.END_ELEMENT, XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(XMLStreamReader.START_ELEMENT, XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        parser.nextToken(); // START_OBJECT
        JsonToken token = parser.nextToken();
        assertEquals(JsonToken.END_OBJECT, token);
    }

    @Test
    public void testNextToken_FieldName() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root", "field");
        when(xmlStreamReader.getText()).thenReturn("value");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        parser.nextToken(); // START_OBJECT
        JsonToken token = parser.nextToken(); // FIELD_NAME
        assertEquals(JsonToken.FIELD_NAME, token);
        assertEquals("field", parser.currentName());
    }

    @Test
    public void testNextToken_ValueString() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root");
        when(xmlStreamReader.getText()).thenReturn("value");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // FIELD_NAME
        assertEquals(JsonToken.FIELD_NAME, token);
        token = parser.nextToken(); // VALUE_STRING
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals("value", parser.getText());
    }

    @Test
    public void testNextToken_ValueNull() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root", "field");
        when(xmlStreamReader.hasNext()).thenReturn(true, true, false);
        when(xmlStreamReader.getText()).thenReturn("");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // FIELD_NAME
        assertEquals(JsonToken.FIELD_NAME, token);
        token = parser.nextToken(); // VALUE_NULL
        assertEquals(JsonToken.VALUE_NULL, token);
    }

    @Test
    public void testNextToken_StartArray() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root", "array");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // FIELD_NAME
        assertEquals(JsonToken.FIELD_NAME, token);
        token = parser.nextToken(); // START_ARRAY
        assertEquals(JsonToken.START_ARRAY, token);
        token = parser.nextToken(); // END_ARRAY
        assertEquals(JsonToken.END_ARRAY, token);
    }

    @Test
    public void testNextToken_MixedContent() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root", "field", "child");
        when(xmlStreamReader.getText()).thenReturn("mixed", "content");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // FIELD_NAME "field"
        assertEquals(JsonToken.FIELD_NAME, token);
        assertEquals("field", parser.currentName());
        token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // FIELD_NAME "child"
        assertEquals(JsonToken.FIELD_NAME, token);
        assertEquals("child", parser.currentName());
        token = parser.nextToken(); // VALUE_STRING "content"
        assertEquals(JsonToken.VALUE_STRING, token);
        token = parser.nextToken(); // END_OBJECT
        assertEquals(JsonToken.END_OBJECT, token);
        token = parser.nextToken(); // END_OBJECT
        assertEquals(JsonToken.END_OBJECT, token);
    }

    @Test
    public void testNextToken_EmptyElementAsNull() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root");
        when(xmlStreamReader.hasNext()).thenReturn(true, false);
        parser = new FromXmlParser(ioContext, 0, FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL.getMask(), objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // END_OBJECT or VALUE_NULL based on feature
        assertEquals(JsonToken.VALUE_NULL, token);
    }

    @Test
    public void testNextToken_ProcessXsiNil() throws XMLStreamException, IOException {
        // Simulate xsi:nil attribute
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.ATTRIBUTE,
                XMLStreamReader.ATTRIBUTE,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.ATTRIBUTE,
                XMLStreamReader.ATTRIBUTE,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root", "xsi:nil");
        when(xmlStreamReader.getText()).thenReturn("true");
        parser = new FromXmlParser(ioContext, 0, FromXmlParser.Feature.PROCESS_XSI_NIL.getMask(), objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // VALUE_NULL due to xsi:nil
        assertEquals(JsonToken.VALUE_NULL, token);
    }

    @Test
    public void testNextToken_InvalidXMLStreamException() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenThrow(new XMLStreamException("Invalid XML"));
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        });
    }

    @Test
    public void testNextToken_InternalErrorUnknownToken() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(9999); // Unknown token
        when(xmlStreamReader.getEventType()).thenReturn(9999);
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        assertThrows(IllegalStateException.class, () -> {
            parser.nextToken();
        });
    }

    @Test
    public void testNextToken_NullInput() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getLocalName()).thenReturn(null);
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken();
        assertNull(token);
    }

    @Test
    public void testNextToken_BoundaryValues_IntMax() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("number");
        when(xmlStreamReader.getText()).thenReturn(String.valueOf(Integer.MAX_VALUE));
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        parser.nextToken(); // START_OBJECT
        parser.nextToken(); // FIELD_NAME
        JsonToken token = parser.nextToken(); // VALUE_NUMBER_INT
        assertEquals(JsonToken.VALUE_STRING, token); // Since XML treats as string
        assertEquals(String.valueOf(Integer.MAX_VALUE), parser.getText());
    }

    @Test
    public void testNextToken_BoundaryValues_LongMax() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("number");
        when(xmlStreamReader.getText()).thenReturn(String.valueOf(Long.MAX_VALUE));
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        parser.nextToken(); // START_OBJECT
        parser.nextToken(); // FIELD_NAME
        JsonToken token = parser.nextToken(); // VALUE_NUMBER_INT
        assertEquals(JsonToken.VALUE_STRING, token); // Since XML treats as string
        assertEquals(String.valueOf(Long.MAX_VALUE), parser.getText());
    }

    @Test
    public void testNextToken_EmptyTextInObjectContext() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.CHARACTERS,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root");
        when(xmlStreamReader.getText()).thenReturn("   ");
        parser = new FromXmlParser(ioContext, 0, 0, objectCodec, xmlStreamReader, xmlNameProcessor);
        parser.nextToken(); // START_OBJECT
        parser.nextToken(); // FIELD_NAME
        JsonToken token = parser.nextToken(); // Should skip whitespace
        assertNull(token);
    }

    @Test
    public void testNextToken_AutoDetectXsiTypeEnabled() throws XMLStreamException, IOException {
        when(xmlStreamReader.next()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.ATTRIBUTE,
                XMLStreamReader.END_ELEMENT,
                XMLStreamReader.END_DOCUMENT);
        when(xmlStreamReader.getEventType()).thenReturn(
                XMLStreamReader.START_ELEMENT,
                XMLStreamReader.ATTRIBUTE,
                XMLStreamReader.END_ELEMENT);
        when(xmlStreamReader.getLocalName()).thenReturn("root", "xsi:type");
        when(xmlStreamReader.getText()).thenReturn("typeValue");
        parser = new FromXmlParser(ioContext, 0, FromXmlParser.Feature.AUTO_DETECT_XSI_TYPE.getMask(), objectCodec, xmlStreamReader, xmlNameProcessor);
        JsonToken token = parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.START_OBJECT, token);
        token = parser.nextToken(); // FIELD_NAME "xsi:type"
        assertEquals(JsonToken.FIELD_NAME, token);
        assertEquals("xsi:type", parser.currentName());
        token = parser.nextToken(); // VALUE_STRING "typeValue"
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals("typeValue", parser.getText());
    }
}