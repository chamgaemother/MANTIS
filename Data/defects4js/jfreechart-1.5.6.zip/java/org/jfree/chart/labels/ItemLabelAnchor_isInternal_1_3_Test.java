package org.jfree.chart.labels;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ItemLabelAnchor_isInternal_1_3_Test {

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE12")
    void testIsInternalReturnsFalseWhenAnchorIsOUTSIDE12() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE12;
        
        // Act
        boolean result = anchor.isInternal();
        
        // Assert
        assertFalse(result);
    }

}