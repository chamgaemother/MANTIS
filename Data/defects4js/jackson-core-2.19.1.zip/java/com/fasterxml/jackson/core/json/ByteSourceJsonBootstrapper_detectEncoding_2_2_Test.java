package com.fasterxml.jackson.core.json;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper;
import com.fasterxml.jackson.core.io.IOContext;

import java.io.ByteArrayInputStream;
import java.io.CharConversionException;
import java.lang.reflect.Field;

public class ByteSourceJsonBootstrapper_detectEncoding_2_2_Test {

    @Test
    @DisplayName("TC28: detectEncoding returns UTF16_BE via checkUTF16 when ensureLoaded(4) is false and ensureLoaded(2) is true with bigEndian=true")
    public void TC28() throws Exception {
        // GIVEN
        byte[] input = {(byte)0xFE, (byte)0xFF}; // UTF16_BE BOM
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF16_BE, encoding);
    }

    @Test
    @DisplayName("TC29: detectEncoding returns UTF16_LE via checkUTF16 when ensureLoaded(4) is false and ensureLoaded(2) is true with bigEndian=false")
    public void TC29() throws Exception {
        // GIVEN
        byte[] input = {(byte)0xFF, (byte)0xFE}; // UTF16_LE BOM
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF16_LE, encoding);
    }

    @Test
    @DisplayName("TC30: detectEncoding defaults to UTF8 when ensureLoaded(4) is false and ensureLoaded(2) returns false")
    public void TC30() throws Exception {
        // GIVEN
        byte[] input = {(byte)0x00}; // Less than 2 bytes
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    @Test
    @DisplayName("TC31: detectEncoding throws RuntimeException with invalid _bytesPerChar")
    public void TC31() throws Exception {
        // GIVEN
        byte[] input = {0x00, 0x00, 0x00, 0x31}; // Valid input for UTF32_BE
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);
        
        // Using reflection to set _bytesPerChar to invalid value
        Field bytesPerCharField = ByteSourceJsonBootstrapper.class.getDeclaredField("_bytesPerChar");
        bytesPerCharField.setAccessible(true);
        bytesPerCharField.setInt(bootstrapper, 3);

        // WHEN & THEN
        Exception exception = assertThrows(RuntimeException.class, () -> {
            bootstrapper.detectEncoding();
        });
    }

    @Test
    @DisplayName("TC32: detectEncoding throws CharConversionException when handleBOM detects invalid UCS-4 encoding")
    public void TC32() throws Exception {
        // GIVEN
        byte[] input = {0x00, 0x00, (byte)0xFF, (byte)0xFE}; // Invalid UCS-4 encoding
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN & THEN
        assertThrows(CharConversionException.class, () -> {
            bootstrapper.detectEncoding();
        });
    }
}