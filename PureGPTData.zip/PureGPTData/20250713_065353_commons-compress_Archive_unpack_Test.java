import org.apache.commons.compress.harmony.unpack200.Archive;
import org.apache.commons.io.output.NullOutputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.jar.JarOutputStream;
import java.util.zip.GZIPOutputStream;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class ArchiveTest {

    @TempDir
    Path tempDir;

    private Path inputFilePath;
    private Path outputFilePath;

    @BeforeEach
    public void setup() throws IOException {
        inputFilePath = Files.createTempFile(tempDir, "input", ".pack");
        outputFilePath = tempDir.resolve("output.jar");
        try (FileOutputStream fos = new FileOutputStream(inputFilePath.toFile())) {
            fos.write(0xCA);
            fos.write(0xFE);
            fos.write(0xD0);
            fos.write(0x0D);
        }
    }

    @Test
    public void testUnpackValidFile() throws IOException {
        Archive archive = new Archive(inputFilePath.toString(), outputFilePath.toString());
        archive.unpack();
        // Ensure that an output file is created
        assert Files.exists(outputFilePath);
    }

    @Test
    public void testUnpackCompressedFile() throws IOException {
        // Create a GZipped pack file content
        byte[] compressed = new byte[]{(byte) 0x1F, (byte) 0x8B, 0x08, 0x00}; 
        Files.write(inputFilePath, compressed);
        
        Archive archive = new Archive(inputFilePath.toString(), outputFilePath.toString());
        archive.unpack();
        // Ensure that an output file is created
        assert Files.exists(outputFilePath);
    }

    @Test
    public void testUnpackNonPackFile() throws IOException {
        Files.write(inputFilePath, new byte[]{0x00, 0x00, 0x00, 0x00});
        Archive archive = new Archive(inputFilePath.toString(), outputFilePath.toString());
        archive.unpack();
        // Ensure that an output file is created
        assert Files.exists(outputFilePath);
    }

    @Test
    public void testUnpackShouldRemovePackFile() throws IOException {
        Archive archive = new Archive(inputFilePath.toString(), outputFilePath.toString());
        archive.setRemovePackFile(true);
        archive.unpack();
        assert Files.notExists(inputFilePath);
    }

    @Test
    public void testUnpackWithInputStream() throws IOException {
        byte[] data = new byte[]{(byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D};
        ByteArrayInputStream bais = new ByteArrayInputStream(data);
        JarOutputStream jos = new JarOutputStream(new NullOutputStream());
        Archive archive = new Archive(bais, jos);
        archive.unpack();
        // Since the input stream is mocked, we can't assert file creation
    }
    
    @Test
    public void testUnpackWithOverrideDeflateHint() throws IOException {
        Archive archive = new Archive(inputFilePath.toString(), outputFilePath.toString());
        archive.setDeflateHint(true);
        archive.unpack();
        // Ensure that an output file is created
        assert Files.exists(outputFilePath);
    }

    @Test
    public void testPreCheckForGzipHeader() throws IOException {
        try (FileOutputStream fos = new FileOutputStream(inputFilePath.toFile());
             GZIPOutputStream gzos = new GZIPOutputStream(fos)) {
            gzos.write(0xCA);
            gzos.write(0xFE);
            gzos.write(0xD0);
            gzos.write(0x0D);
        }
        Archive archive = new Archive(inputFilePath.toString(), outputFilePath.toString());
        archive.unpack();
        // Ensure that an output file is created
        assert Files.exists(outputFilePath);
    }

    @Test
    public void testUnpackThrowsIOException() throws IOException {
        Archive archive = new Archive(inputFilePath.toString(), outputFilePath.toString());
        IOException ioException = new IOException("Test IO Exception");
        BoundedInputStream bis = mock(BoundedInputStream.class);
        when(bis.read()).thenThrow(ioException);
        archive.inputStream = bis;

        assertThrows(IOException.class, archive::unpack);
    }

    @Test
    public void testUnpackWithInvalidInputStream() throws IOException {
        ByteArrayInputStream invalidStream = new ByteArrayInputStream(new byte[]{});
        JarOutputStream jos = new JarOutputStream(new NullOutputStream());
        Archive archive = new Archive(invalidStream, jos);
        assertThrows(IllegalStateException.class, archive::unpack);
    }
}