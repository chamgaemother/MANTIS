package org.jfree.chart.plot.dial;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.plot.dial.DialPlot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class StandardDialScale_draw_0_3_Test {

    @Test
    @DisplayName("draw with startAngle set to 0 and verify tick positions")
    public void TC11_draw_with_startAngle_set_to_0_and_verify_tick_positions() throws Exception {
        // GIVEN
        StandardDialScale scale = new StandardDialScale();

        // Use reflection to set private field 'startAngle' to 0
        Field startAngleField = StandardDialScale.class.getDeclaredField("startAngle");
        startAngleField.setAccessible(true); // Ensure accessibility
        startAngleField.setDouble(scale, 0.0);

        // Mock Graphics2D
        Graphics2D g2 = mock(Graphics2D.class);

        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);

        // WHEN
        scale.draw(g2, plot, frame, frame);

        // THEN
        // Capture the arguments passed to g2.draw(Line2D)
        ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
        verify(g2, times((int)((scale.getUpperBound() - scale.getLowerBound()) / scale.getMajorTickIncrement()))).draw(lineCaptor.capture());

        // Verify that the first tick starts at angle 0
        java.awt.geom.Line2D firstLine = lineCaptor.getAllValues().get(0);
        assertEquals(50.0, firstLine.getX1(), 0.1); // Assuming center at (50,50)
        assertEquals(100.0, firstLine.getY1(), 0.1); // Point at angle 0
    }

    @Test
    @DisplayName("draw with tickLabelFont set to a specific font and verify label rendering")
    public void run_draw_with_customFont_and_verify_label_rendering() throws Exception {
        // GIVEN
        Font customFont = new Font("Arial", Font.BOLD, 12);
        StandardDialScale scale = new StandardDialScale();

        // Use reflection to set private field 'tickLabelFont' to customFont
        Field tickLabelFontField = StandardDialScale.class.getDeclaredField("tickLabelFont");
        tickLabelFontField.setAccessible(true); // Ensure accessibility
        tickLabelFontField.set(scale, customFont);

        // Mock Graphics2D
        Graphics2D g2 = mock(Graphics2D.class);

        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);

        // WHEN
        scale.draw(g2, plot, frame, frame);

        // THEN
        // Verify that setFont was called with customFont
        verify(g2).setFont(customFont);
    }

}