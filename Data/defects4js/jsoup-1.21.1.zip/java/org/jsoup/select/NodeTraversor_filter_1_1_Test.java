package org.jsoup.select;

import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeFilter.FilterResult;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NodeTraversor_filter_1_1_Test {

    @Test
    @DisplayName("filter returns REMOVE when result is REMOVE during head processing")
    public void TC15_filter_remove_on_head() {
        // GIVEN
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.REMOVE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(0, root.childNodeSize(), "Child node should be removed");
        assertEquals(FilterResult.CONTINUE, result, "Result should be CONTINUE");
    }

    @Test
    @DisplayName("filter returns SKIP_CHILDREN and CONTINUE during tail processing")
    public void TC16_filter_skip_children_on_tail() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        root.appendChild(child1);
        root.appendChild(child2);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.equals(child1)) {
                    return FilterResult.SKIP_CHILDREN;
                }
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        // Since SKIP_CHILDREN is returned on tail of child1, ensure no further processing on its children
        // In this simple case, child1 has no children, so we just verify traversal continues
        assertEquals(FilterResult.CONTINUE, result, "Result should be CONTINUE");
        assertEquals(2, root.childNodeSize(), "Root should still have two children");
    }

    @Test
    @DisplayName("filter returns REMOVE when result is REMOVE during tail processing with no siblings")
    public void TC17_filter_remove_on_tail_no_siblings() {
        // GIVEN
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.equals(child)) {
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(0, root.childNodeSize(), "Child node should be removed from parent");
        assertEquals(FilterResult.CONTINUE, result, "Result should be CONTINUE");
    }

    @Test
    @DisplayName("filter throws AssertionError when node becomes null unexpectedly")
    public void TC18_filter_assertion_error_on_null_node() {
        // GIVEN
        Element root = new Element("root");
        // Manipulate root to have no parent, but simulate node becoming null during traversal
        // Since we cannot directly set node to null, we'll create a faulty NodeFilter

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                // Simulate node becoming null unexpectedly by throwing AssertionError
                throw new AssertionError("Node became null unexpectedly");
            }
        };

        // WHEN & THEN
        assertThrows(AssertionError.class, () -> NodeTraversor.filter(filter, root), "An AssertionError should be thrown");
    }

    @Test
    @DisplayName("filter returns STOP after removing multiple nodes in succession")
    public void TC19_filter_stop_after_multiple_removals() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element child3 = new Element("child3");
        root.appendChild(child1);
        root.appendChild(child2);
        root.appendChild(child3);

        NodeFilter filter = new NodeFilter() {
            private int removeCount = 0;

            @Override
            public FilterResult head(Node node, int depth) {
                if (removeCount < 2) {
                    removeCount++;
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                if (removeCount >= 2) {
                    return FilterResult.STOP;
                }
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(1, root.childNodeSize(), "Only one child node should remain after removals");
        assertEquals(child3, root.childNode(0), "Remaining child should be child3");
        assertEquals(FilterResult.STOP, result, "Result should be STOP");
    }
}