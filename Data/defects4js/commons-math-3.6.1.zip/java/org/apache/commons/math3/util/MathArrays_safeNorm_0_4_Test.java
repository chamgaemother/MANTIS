package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class MathArrays_safeNorm_0_4_Test {

    @Test
    @DisplayName("safeNorm with elements including zero to ensure s3 is not incorrectly updated")
    public void TC16() {
        double[] v = new double[]{0.0, 1.0e-21};
        double result = MathArrays.safeNorm(v);
        assertEquals(Math.sqrt(0.0 + (1.0e-21 * 1.0e-21)), result);
    }

    @Test
    @DisplayName("safeNorm with all elements contributing to s2, ensuring s1 remains zero")
    public void TC17() {
        double[] v = new double[]{5.0, 10.0, 15.0};
        double result = MathArrays.safeNorm(v);
        assertEquals(Math.sqrt((5.0 * 5.0) + (10.0 * 10.0) + (15.0 * 15.0)), result);
    }

    @Test
    @DisplayName("safeNorm with elements resetting s1 and s3 multiple times across iterations")
    public void TC18() {
        double[] v = new double[]{1.0e+18, 2.0e+19, 1.0e-21, 3.0e+19, 4.0e-21};
        double result = MathArrays.safeNorm(v);
        assertEquals(Math.sqrt((3.0e+19 * 3.0e+19) + (1.0e-21 * 1.0e-21) + (4.0e-21 * 4.0e-21)), result);
    }

    @Test
    @DisplayName("safeNorm with all elements zero, ensuring norm is zero")
    public void TC19() {
        double[] v = new double[]{0.0, 0.0, 0.0};
        double result = MathArrays.safeNorm(v);
        assertEquals(0.0, result);
    }

    @Test
    @DisplayName("safeNorm with very large and very small elements to test numerical stability")
    public void TC20() {
        double[] v = new double[]{1.0e+20, 1.0e-20, 5.0, -1.0e+20};
        double result = MathArrays.safeNorm(v);
        assertTrue(Double.isFinite(result) && result > 0);
    }
}