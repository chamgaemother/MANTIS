package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class BooleanUtils_toBooleanObject_0_5_Test {

    @Test
    @DisplayName("Input string is single character 'z', returns null")
    public void TC21_toBooleanObject_z_returns_null() {
        // GIVEN
        String input = "z";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertNull(result, "Expected result to be null for input 'z'");
    }

    @Test
    @DisplayName("Input string is two characters 'ab', returns null")
    public void TC22_toBooleanObject_ab_returns_null() {
        // GIVEN
        String input = "ab";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertNull(result, "Expected result to be null for input 'ab'");
    }

    @Test
    @DisplayName("Input string is three characters 'xyz', returns null")
    public void TC23_toBooleanObject_xyz_returns_null() {
        // GIVEN
        String input = "xyz";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertNull(result, "Expected result to be null for input 'xyz'");
    }

    @Test
    @DisplayName("Input string is four characters 'TruE', returns Boolean.TRUE")
    public void TC24_toBooleanObject_TruE_returns_TRUE() {
        // GIVEN
        String input = "TruE";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.TRUE, result, "Expected result to be Boolean.TRUE for input 'TruE'");
    }

    @Test
    @DisplayName("Input string is five characters 'FaLsE', returns Boolean.FALSE")
    public void TC25_toBooleanObject_FaLsE_returns_FALSE() {
        // GIVEN
        String input = "FaLsE";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.FALSE, result, "Expected result to be Boolean.FALSE for input 'FaLsE'");
    }
}