package org.jfree.chart.plot;

import org.jfree.chart.ui.RectangleInsets;
import org.jfree.data.general.ValueDataset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ThermometerPlot_draw_0_4_Test {

//     @Test
//     @DisplayName("TC16: Draw method with i129 > 0 leading to units drawn at bottom")
//     void TC16_draw_with_i129_greater_than_0_units_drawn_at_bottom() throws Exception {
        // GIVEN
//         ThermometerPlot plot = new ThermometerPlot();
//         plot.setUnits(ThermometerPlot.UNITS_FAHRENHEIT); // Correctly set units
//         ValueDataset validDataset = mock(ValueDataset.class);
//         when(validDataset.getValue()).thenReturn(25.0);
//         plot.setDataset(validDataset);
//         plot.setSubrangeIndicatorsVisible(false);
//         ValueAxis validRangeAxis = mock(ValueAxis.class);
//         when(validRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), eq(RectangleEdge.LEFT)))
//                 .thenReturn(50.0);
//         plot.setRangeAxis(validRangeAxis);
//         plot.setAxisLocation(ThermometerPlot.LEFT);
//         plot.setShowValueLines(false);
//         plot.setValueLocation(ThermometerPlot.RIGHT);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 200);
//         Point2D anchor = new Point2D.Double(50, 100);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo();
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
        // Verify units are drawn at the bottom
//         verify(g2).drawString(eq("Â°F"), anyInt(), anyInt()); // Correct unit display check
        // Verify mercury is filled correctly
//         verify(g2).fill(any());
//     }

//     @Test
//     @DisplayName("TC17: Draw method with rangeAxis null")
//     void TC17_draw_with_rangeAxis_null() throws Exception {
        // GIVEN
//         ThermometerPlot plot = new ThermometerPlot();
//         ValueDataset validDataset = mock(ValueDataset.class);
//         when(validDataset.getValue()).thenReturn(30.0);
//         plot.setDataset(validDataset);
//         plot.setSubrangeIndicatorsVisible(false);
//         plot.setRangeAxis(new ValueAxis("Range Axis") {
//             @Override
//             protected double calculateLowestVisibleTickValue() { return 0; }
// 
//             @Override
//             protected double calculateHighestVisibleTickValue() { return 1; }
// 
//             @Override
//             public double valueToJava2D(double value, Rectangle2D area, RectangleEdge edge) {
//                 return edge == RectangleEdge.LEFT ? area.getHeight() - value : value;
//             }
// 
//             @Override
//             public double java2DToValue(double java2DValue, Rectangle2D area, RectangleEdge edge) {
//                 return edge == RectangleEdge.LEFT ? area.getHeight() - java2DValue : java2DValue;
//             }
// 
//             @Override
//             public void configure() { }
//         });
//         plot.setAxisLocation(ThermometerPlot.LEFT);
//         plot.setShowValueLines(false);
//         plot.setValueLocation(ThermometerPlot.RIGHT);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(10, 10, 120, 220);
//         Point2D anchor = new Point2D.Double(60, 110);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo();
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
        // Verify no axis is drawn
//         verify(g2, never()).draw(any(Line2D.class));
        // Verify mercury is filled based on default range
//         verify(g2).fill(any());
//     }

//     @Test
//     @DisplayName("TC18: Draw method with invalid subrangeInfo indices causing no subrange indicators")
//     void TC18_draw_with_invalid_subrangeInfo_indices() throws Exception {
        // GIVEN
//         ThermometerPlot plot = new ThermometerPlot();
//         ValueDataset validDataset = mock(ValueDataset.class);
//         when(validDataset.getValue()).thenReturn(15.0);
//         plot.setDataset(validDataset);
//         plot.setSubrangeIndicatorsVisible(true);
//         ValueAxis validRangeAxis = mock(ValueAxis.class);
//         when(validRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), eq(RectangleEdge.LEFT)))
//                 .thenReturn(40.0);
//         plot.setRangeAxis(validRangeAxis);
        // Correctly set subrange info with 4 values for ranges
//         plot.setSubrangeInfo(0, 0, 50.0);
//         Paint normalPaint = mock(Paint.class);
//         Paint warningPaint = mock(Paint.class);
//         Paint criticalPaint = mock(Paint.class);
//         plot.setSubrangePaint(0, normalPaint);
//         plot.setSubrangePaint(1, warningPaint);
//         plot.setSubrangePaint(2, criticalPaint);
//         plot.setAxisLocation(ThermometerPlot.LEFT);
//         plot.setShowValueLines(false);
//         plot.setValueLocation(ThermometerPlot.RIGHT);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(20, 20, 140, 240);
//         Point2D anchor = new Point2D.Double(70, 120);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo();
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
        // Verify no subrange indicators are drawn
//         verify(g2, never()).draw(any(Line2D.class));
        // Verify method handles invalid indices without exceptions
        // No exception means pass
//     }

//     @Test
//     @DisplayName("TC19: Draw method with multiple subrange indicators visible and overlapping ranges")
//     void TC19_draw_with_multiple_overlapping_subrange_indicators() throws Exception {
        // GIVEN
//         ThermometerPlot plot = new ThermometerPlot();
//         ValueDataset validDataset = mock(ValueDataset.class);
//         when(validDataset.getValue()).thenReturn(40.0);
//         plot.setDataset(validDataset);
//         plot.setSubrangeIndicatorsVisible(true);
//         ValueAxis validRangeAxis = mock(ValueAxis.class);
//         when(validRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), eq(RectangleEdge.LEFT)))
//                 .thenReturn(60.0);
//         plot.setRangeAxis(validRangeAxis);
        // Correctly set overlapping subrange info
//         plot.setSubrangeInfo(0, 20.0, 40.0);
//         plot.setSubrangeInfo(1, 30.0, 50.0);
//         plot.setSubrangeInfo(2, 40.0, 70.0);
//         Paint normalPaint = mock(Paint.class);
//         Paint warningPaint = mock(Paint.class);
//         Paint criticalPaint = mock(Paint.class);
//         plot.setSubrangePaint(0, normalPaint);
//         plot.setSubrangePaint(1, warningPaint);
//         plot.setSubrangePaint(2, criticalPaint);
//         plot.setAxisLocation(ThermometerPlot.LEFT);
//         plot.setShowValueLines(true);
//         plot.setValueLocation(ThermometerPlot.RIGHT);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(30, 30, 160, 260);
//         Point2D anchor = new Point2D.Double(80, 130);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo();
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
        // Verify all applicable subrange indicators are drawn without overlaps
//         verify(g2, times(3)).draw(any(Line2D.class));
        // Verify mercury is filled correctly
//         verify(g2).fill(any());
//     }

//     @Test
//     @DisplayName("TC20: Draw method with dataset value exactly at subrange boundaries")
//     void TC20_draw_with_dataset_value_at_subrange_boundaries() throws Exception {
        // GIVEN
//         ThermometerPlot plot = new ThermometerPlot();
//         ValueDataset datasetValueAtSubrangeBoundaries = mock(ValueDataset.class);
//         when(datasetValueAtSubrangeBoundaries.getValue()).thenReturn(50.0);
//         plot.setDataset(datasetValueAtSubrangeBoundaries);
//         plot.setSubrangeIndicatorsVisible(true);
//         ValueAxis validRangeAxis = mock(ValueAxis.class);
//         when(validRangeAxis.valueToJava2D(eq(50.0), any(Rectangle2D.class), eq(RectangleEdge.LEFT)))
//                 .thenReturn(80.0);
//         plot.setRangeAxis(validRangeAxis);
//         double[][] boundarySubrangeInfo = new double[][] {{50.0, 60.0}, {60.0, 70.0}, {70.0, 80.0}}; // Boundary values
        // Manually set info
//         plot.setSubrangeInfo(0, 50.0, 60.0);
//         plot.setSubrangeInfo(1, 60.0, 70.0);
//         plot.setSubrangeInfo(2, 70.0, 80.0);
//         Paint normalPaint = mock(Paint.class);
//         Paint warningPaint = mock(Paint.class);
//         Paint criticalPaint = mock(Paint.class);
//         plot.setSubrangePaint(0, normalPaint);
//         plot.setSubrangePaint(1, warningPaint);
//         plot.setSubrangePaint(2, criticalPaint);
//         plot.setAxisLocation(ThermometerPlot.LEFT);
//         plot.setShowValueLines(true);
//         plot.setValueLocation(ThermometerPlot.RIGHT);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         FontMetrics metrics = mock(FontMetrics.class);
//         when(g2.getFontMetrics()).thenReturn(metrics);
//         when(metrics.stringWidth(anyString())).thenReturn(50);
//         Rectangle2D area = new Rectangle2D.Double(40, 40, 180, 280);
//         Point2D anchor = new Point2D.Double(90, 140);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo();
// 
        // WHEN
//         plot.draw(g2, area, anchor, state, info);
// 
        // THEN
        // Verify mercury is filled correctly at boundary
//         verify(g2).fill(any());
        // Verify appropriate subrange indicators are drawn
//         verify(g2, times(3)).draw(any(Line2D.class));
        // Verify the value is drawn correctly
//         verify(g2).drawString(eq("50"), anyInt(), anyInt());
//     }

}