import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.StackedAreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.Range;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class StackedAreaRendererTest {

    private StackedAreaRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;
    private int row;
    private int column;
    private int pass;

    @BeforeEach
    void setUp() {
        renderer = new StackedAreaRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);
        row = 0;
        column = 0;
        pass = 0;
    }

    @Test
    void testDrawItem_SeriesNotVisible() {
        renderer = spy(renderer);
        doReturn(false).when(renderer).isSeriesVisible(row);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(renderer, times(1)).isSeriesVisible(row);
        verifyNoMoreInteractions(g2, state, plot, domainAxis, rangeAxis, dataset);
    }

    @Test
    void testDrawItem_Y1Null_RenderAsFalse_Pass0_WithEntities() {
        when(renderer.getRenderAsPercentages()).thenReturn(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(mock(EntityCollection.class));
        when(dataset.getValue(row, column)).thenReturn(null);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
            .thenReturn(10.0);
        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any()))
            .thenReturn(5.0);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(Rectangle2D.class), any()))
            .thenReturn(15.0);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(null);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(any(Paint.class));
        verify(g2, times(2)).fill(any(Shape.class));
        verify(state.getEntityCollection(), times(1)).add(any());
    }

    @Test
    void testDrawItem_Y1Positive_Y0Positive_Pass0_WithEntities() {
        when(renderer.getRenderAsPercentages()).thenReturn(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(5.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(15.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
        verify(entities, times(1)).add(any());
    }

    @Test
    void testDrawItem_Y1Positive_Y0Negative_Pass0_WithEntities() {
        when(renderer.getRenderAsPercentages()).thenReturn(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(-5.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(15.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
        verify(entities, times(1)).add(any());
    }

    @Test
    void testDrawItem_Y1Negative_Y0Positive_Pass0_WithEntities() {
        when(renderer.getRenderAsPercentages()).thenReturn(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(row, column)).thenReturn(-10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(5.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(-15.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
        verify(entities, times(1)).add(any());
    }

    @Test
    void testDrawItem_Y1Negative_Y0Negative_Pass0_WithEntities() {
        when(renderer.getRenderAsPercentages()).thenReturn(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(row, column)).thenReturn(-10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(-5.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(-15.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
        verify(entities, times(1)).add(any());
    }

    @Test
    void testDrawItem_Pass1_DrawLabel() {
        when(renderer.getRenderAsPercentages()).thenReturn(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(5.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(15.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 1);

        verify(g2, times(0)).setPaint(any());
        verify(g2, times(0)).fill(any(Shape.class));
        verify(renderer, times(1)).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyBoolean());
    }

    @Test
    void testDrawItem_NullDataset() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, row, column, pass);
        });
    }

    @Test
    void testDrawItem_RenderAsPercentage_Y1Null() {
        renderer = new StackedAreaRenderer(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(row, column)).thenReturn(null);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(null);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(null);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(any(Paint.class));
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_RenderAsPercentage_Y1Positive() {
        renderer = new StackedAreaRenderer(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(row, column)).thenReturn(50.0);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(DataUtils.calculateColumnTotal(dataset, column, new int[] {0})).thenReturn(100.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(25.0);
        when(DataUtils.calculateColumnTotal(dataset, Math.max(column - 1, 0), new int[] {0}))
            .thenReturn(50.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(75.0);
        when(DataUtils.calculateColumnTotal(dataset, Math.min(column + 1, 0), new int[] {0}))
            .thenReturn(150.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_RenderAsPercentage_Y1Negative() {
        renderer = new StackedAreaRenderer(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(row, column)).thenReturn(-50.0);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0});
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(DataUtils.calculateColumnTotal(dataset, column, new int[] {0})).thenReturn(100.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(25.0);
        when(DataUtils.calculateColumnTotal(dataset, Math.max(column - 1, 0), new int[] {0}))
            .thenReturn(50.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(-75.0);
        when(DataUtils.calculateColumnTotal(dataset, Math.min(column + 1, 0), new int[] {0}))
            .thenReturn(150.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_WithNullEntityCollection_Pass0() {
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(5.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(15.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
        verify(state.getEntityCollection(), times(0)).add(any());
    }

    @Test
    void testDrawItem_PassInvalid() {
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(5.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(15.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 2);

        verify(g2, times(0)).setPaint(any());
        verify(g2, times(0)).fill(any(Shape.class));
        verify(renderer, times(0)).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyBoolean());
    }

    @Test
    void testDrawItem_WithClonePath_Y1Positive() {
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(domainAxis.getCategoryMiddle(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(5.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(15.0);
        when(domainAxis.getCategoryStart(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(domainAxis.getCategoryEnd(column, 1, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_WithValidAndInvalidInputs() {
        renderer = new StackedAreaRenderer(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(row, column)).thenReturn(50.0);
        when(state.getVisibleSeriesArray()).thenReturn(new int[] {0, 1});
        when(domainAxis.getCategoryMiddle(column, 2, dataArea, mock(RectangleEdge.class)))
            .thenReturn(10.0);
        when(DataUtils.calculateColumnTotal(dataset, column, new int[] {0, 1})).thenReturn(100.0);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(null);
        when(DataUtils.calculateColumnTotal(dataset, Math.max(column - 1, 0), new int[] {0, 1}))
            .thenReturn(0.0);
        when(dataset.getValue(row, Math.min(column + 1, 0))).thenReturn(-75.0);
        when(DataUtils.calculateColumnTotal(dataset, Math.min(column + 1, 0), new int[] {0, 1}))
            .thenReturn(150.0);
        when(domainAxis.getCategoryStart(column, 2, dataArea, mock(RectangleEdge.class)))
            .thenReturn(5.0);
        when(domainAxis.getCategoryEnd(column, 2, dataArea, mock(RectangleEdge.class)))
            .thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
            .thenReturn(20.0);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, times(1)).setPaint(paint);
        verify(g2, times(2)).fill(any(Shape.class));
        verify(entities, times(1)).add(any());
    }

    @Test
    void testEquals_Symmetric() {
        StackedAreaRenderer renderer1 = new StackedAreaRenderer(true);
        StackedAreaRenderer renderer2 = new StackedAreaRenderer(true);
        assertEquals(renderer1, renderer2);
        renderer2.setRenderAsPercentages(false);
        assertNotEquals(renderer1, renderer2);
    }

    @Test
    void testFindRangeBounds_RenderAsPercentage() {
        renderer = new StackedAreaRenderer(true);
        CategoryDataset dataset = mock(CategoryDataset.class);
        Range range = renderer.findRangeBounds(dataset);
        assertEquals(new Range(0.0, 1.0), range);
    }

    @Test
    void testFindRangeBounds_RenderAsValue() {
        renderer = new StackedAreaRenderer(false);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getRowCount()).thenReturn(2);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(1, 0)).thenReturn(20.0);
        when(dataset.getValue(0, 1)).thenReturn(-5.0);
        when(dataset.getValue(1, 1)).thenReturn(15.0);
        Range range = renderer.findRangeBounds(dataset);
        assertEquals(new Range(-5.0, 35.0), range);
    }

}