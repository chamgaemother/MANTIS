package org.joda.time.format;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FormatUtils_appendPaddedInteger_0_2_Test {

    @Test
    @DisplayName("Append three-digit positive integer with size greater than 3, expecting leading zeros")
    public void TC06() throws Exception {
        // GIVEN
        Appendable appendable = new StringBuilder();
        int value = 999;
        int size = 5;

        // WHEN
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // THEN
        assertEquals("00999", appendable.toString(), "Appendable should contain leading zeros and the three-digit number.");
    }

    @Test
    @DisplayName("Append four-digit positive integer with size equal to 4, expecting no padding")
    public void TC07() throws Exception {
        // GIVEN
        Appendable appendable = new StringBuilder();
        int value = 2021;
        int size = 4;

        // WHEN
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // THEN
        assertEquals("2021", appendable.toString(), "Appendable should contain the four-digit number without padding.");
    }

    @Test
    @DisplayName("Append four-digit positive integer with size greater than 4, expecting leading zeros")
    public void TC08() throws Exception {
        // GIVEN
        Appendable appendable = new StringBuilder();
        int value = 1234;
        int size = 6;

        // WHEN
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // THEN
        assertEquals("001234", appendable.toString(), "Appendable should contain leading zeros and the four-digit number.");
    }

    @Test
    @DisplayName("Append five-digit positive integer with size equal to digit count, expecting no padding")
    public void TC09() throws Exception {
        // GIVEN
        Appendable appendable = new StringBuilder();
        int value = 10000;
        int size = 5;

        // WHEN
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // THEN
        assertEquals("10000", appendable.toString(), "Appendable should contain the five-digit number without padding.");
    }

    @Test
    @DisplayName("Append five-digit positive integer with size greater than digit count, expecting leading zeros")
    public void TC10() throws Exception {
        // GIVEN
        Appendable appendable = new StringBuilder();
        int value = 54321;
        int size = 7;

        // WHEN
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // THEN
        assertEquals("0054321", appendable.toString(), "Appendable should contain leading zeros and the five-digit number.");
    }
}