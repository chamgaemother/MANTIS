package org.apache.commons.math3.optim.univariate;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

public class BracketFinder_search_1_2_Test {

    @Test
    @DisplayName("search method triggered TooManyEvaluationsException when function evaluations exceed max")
    void TC29_searchExceedsMaxEvaluations_throwsTooManyEvaluationsException() {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.618034;

        UnivariateFunction func = mock(UnivariateFunction.class);
        // Configure func to always return a constant value, preventing convergence
        when(func.value(anyDouble())).thenReturn(1.0);

        // WHEN
        BracketFinder finder = new BracketFinder(growLimit, 10); // set maxEvaluations to 10

        // THEN
        assertThrows(TooManyEvaluationsException.class, () -> {
            finder.search(func, goal, xA, xB);
        }, "Expected TooManyEvaluationsException to be thrown when evaluations exceed max");
    }

    @Test
    @DisplayName("search method with boundary value near EPS_MIN, ensuring denominator safety")
    void TC30_searchWithValNearEPS_MIN_denominatorSafety() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.618034;

        UnivariateFunction func = mock(UnivariateFunction.class);
        // Mock func to return values that will make 'val' near EPS_MIN
        when(func.value(1.0)).thenReturn(1.0);
        when(func.value(2.0)).thenReturn(2.0);
        when(func.value(2.618034)).thenReturn(1.0);
        when(func.value(3.618034)).thenReturn(1.0);

        // WHEN
        BracketFinder finder = new BracketFinder();
        finder.search(func, goal, xA, xB);

        // THEN
        // Use reflection to access private fields
        Field denomField = BracketFinder.class.getDeclaredField("EPS_MIN");
        denomField.setAccessible(true);
        double EPS_MIN = denomField.getDouble(finder);
        // Since denom is a local variable, we cannot access it directly. Instead, verify internal state.
        // For example, ensure that lo <= hi
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        loField.setAccessible(true);
        hiField.setAccessible(true);
        double lo = loField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        assertTrue(lo <= hi, "lo should be less than or equal to hi after search");
        // Further assertions can be added based on expected behavior
    }

    @Test
    @DisplayName("search method with multiple iterations reaching growLimit without finding better fC")
    void TC31_searchReachesGrowLimitWithoutImprovement() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.618034;

        UnivariateFunction func = mock(UnivariateFunction.class);
        // Mock func to never improve fC
        when(func.value(anyDouble())).thenReturn(2.0);

        // WHEN
        BracketFinder finder = new BracketFinder(5, 10); // set growLimit to 5 and maxEvaluations to 10
        finder.search(func, goal, xA, xB);

        // THEN
        // Use reflection to access private fields
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);

        assertEquals(1.0, lo, 1e-6, "lo should remain unchanged");
        assertEquals(2.0, mid, 1e-6, "mid should remain unchanged");
        assertTrue(hi > mid, "hi should be greater than mid");
    }

    @Test
    @DisplayName("search method with single iteration improving fW")
    void TC32_searchSingleIterationImprovesFW() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.618034;

        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(1.0)).thenReturn(1.0);
        when(func.value(2.0)).thenReturn(2.0);
        when(func.value(2.618034)).thenReturn(0.5);

        // WHEN
        BracketFinder finder = new BracketFinder();
        finder.search(func, goal, xA, xB);

        // THEN
        // Use reflection to access private fields
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        Field fLoField = BracketFinder.class.getDeclaredField("fLo");
        Field fMidField = BracketFinder.class.getDeclaredField("fMid");
        Field fHiField = BracketFinder.class.getDeclaredField("fHi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        fLoField.setAccessible(true);
        fMidField.setAccessible(true);
        fHiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        double fLo = fLoField.getDouble(finder);
        double fMid = fMidField.getDouble(finder);
        double fHi = fHiField.getDouble(finder);

        assertEquals(2.0, lo, 1e-6, "lo should be updated to xB");
        assertEquals(1.0, mid, 1e-6, "mid should be updated to xA");
        assertTrue(hi > mid, "hi should be greater than mid");
        assertEquals(2.0, fLo, 1e-6, "fLo should be fB after swap");
        assertEquals(1.0, fMid, 1e-6, "fMid should be fA after swap");
        assertEquals(0.5, fHi, 1e-6, "fHi should be fW after improvement");
    }

    @Test
    @DisplayName("search method triggering multiple branch conditions within loop without exceptions")
    void TC33_searchMultipleBranchConditions() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 2.0;

        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(1.0)).thenReturn(3.0);
        when(func.value(2.0)).thenReturn(2.0);
        when(func.value(3.618034)).thenReturn(4.0);
        when(func.value(4.236068)).thenReturn(5.0);

        // WHEN
        BracketFinder finder = new BracketFinder();
        finder.search(func, goal, xA, xB);

        // THEN
        // Use reflection to access private fields
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        Field fLoField = BracketFinder.class.getDeclaredField("fLo");
        Field fMidField = BracketFinder.class.getDeclaredField("fMid");
        Field fHiField = BracketFinder.class.getDeclaredField("fHi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        fLoField.setAccessible(true);
        fMidField.setAccessible(true);
        fHiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        double fLo = fLoField.getDouble(finder);
        double fMid = fMidField.getDouble(finder);
        double fHi = fHiField.getDouble(finder);

        assertTrue(lo <= hi, "lo should be less than or equal to hi after search");
        assertEquals(1.0, lo, 1e-6, "lo should remain unchanged");
        assertEquals(2.0, mid, 1e-6, "mid should remain unchanged");
        assertEquals(4.236068, hi, 1e-6, "hi should be updated correctly");
        assertEquals(3.0, fLo, 1e-6, "fLo should remain as fA");
        assertEquals(2.0, fMid, 1e-6, "fMid should remain as fB");
        assertEquals(5.0, fHi, 1e-6, "fHi should be updated to fW");
    }
}