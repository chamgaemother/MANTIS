package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class NumberInput_parseInt_1_2_Test {

    @Test
    @DisplayName("parseInt with length=4 parses correctly without sign")
    void TC23_parseInt_with_length_4_parses_correctly_without_sign() {
        char[] input = new char[] {'2', '5', '6', '7'};
        int off = 0;
        int len = 4;
        int result = NumberInput.parseInt(input, off, len);
        assertEquals(2567, result);
    }
    
    @Test
    @DisplayName("parseInt with length=6 parses correctly without sign")
    void TC24_parseInt_with_length_6_parses_correctly_without_sign() {
        char[] input = new char[] {'3', '4', '5', '6', '7', '8'};
        int off = 0;
        int len = 6;
        int result = NumberInput.parseInt(input, off, len);
        assertEquals(345678, result);
    }
    
    @Test
    @DisplayName("parseInt with length=7 parses correctly without sign")
    void TC25_parseInt_with_length_7_parses_correctly_without_sign() {
        char[] input = new char[] {'4', '5', '6', '7', '8', '9', '0'};
        int off = 0;
        int len = 7;
        int result = NumberInput.parseInt(input, off, len);
        assertEquals(4567890, result);
    }
    
    @Test
    @DisplayName("parseInt with length=8 parses correctly without sign")
    void TC26_parseInt_with_length_8_parses_correctly_without_sign() {
        char[] input = new char[] {'5', '6', '7', '8', '9', '0', '1', '2'};
        int off = 0;
        int len = 8;
        int result = NumberInput.parseInt(input, off, len);
        assertEquals(56789012, result);
    }
    
    @Test
    @DisplayName("parseInt with '+' sign and maximum digits parses correctly")
    void TC27_parseInt_with_plus_sign_and_maximum_digits_parses_correctly() {
        char[] input = new char[] {'+', '2', '1', '4', '7', '4', '8', '3', '6', '4', '7'};
        int off = 0;
        int len = 10;
        int result = NumberInput.parseInt(input, off, len);
        assertEquals(2147483647, result);
    }
}