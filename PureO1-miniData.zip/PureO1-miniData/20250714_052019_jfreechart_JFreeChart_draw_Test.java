import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.title.TextTitle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class JFreeChartTest {

    private JFreeChart chart;
    private Plot plot;

    @BeforeEach
    void setUp() {
        plot = mock(Plot.class);
        chart = new JFreeChart("Test Chart", plot);
    }

    @Test
    void testDraw_NullGraphics2D() {
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D anchor = null;
        ChartRenderingInfo info = null;
        assertThrows(NullPointerException.class, () -> {
            chart.draw(null, area, anchor, info);
        });
    }

    @Test
    void testDraw_NullRectangle2D() {
        Graphics2D g2 = mock(Graphics2D.class);
        Point2D anchor = null;
        ChartRenderingInfo info = null;
        assertThrows(NullPointerException.class, () -> {
            chart.draw(g2, null, anchor, info);
        });
    }

    @Test
    void testDraw_ElementHintingFalse_NoBackgroundImage_NoBorder_NoTitles_NoSubtitles() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setElementHinting(false);
        chart.setBackgroundImage(null);
        chart.setBackgroundPaint(null);
        chart.setBorderVisible(false);
        chart.setTitle(null);
        chart.clearSubtitles();

        chart.draw(g2, area, anchor, info);

        verify(g2).clip(area);
        verify(g2, never()).setRenderingHint(any(), any());
        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
        verify(plot).draw(eq(g2), eq(area), eq(anchor), any(), any());
    }

    @Test
    void testDraw_ElementHintingTrue_WithBackgroundImage() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(10, 10, 300, 300);
        Point2D anchor = new Point2D.Double(50, 50);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        Image bgImage = mock(Image.class);

        chart.setElementHinting(true);
        chart.setBackgroundImage(bgImage);
        chart.setBackgroundImageAlignment(1); // Align.FIT
        chart.setBackgroundImageAlpha(0.7f);

        when(bgImage.getWidth(null)).thenReturn(100);
        when(bgImage.getHeight(null)).thenReturn(100);

        chart.draw(g2, area, anchor, info);

        ArgumentCaptor<RenderingHints.Key> keyCaptor = ArgumentCaptor.forClass(RenderingHints.Key.class);
        ArgumentCaptor<Object> valueCaptor = ArgumentCaptor.forClass(Object.class);
        verify(g2).setRenderingHint(keyCaptor.capture(), valueCaptor.capture());
        assertEquals("id", null, chart.getID());
        verify(g2).setRenderingHint(eq(JFreeChart.KEY_SUPPRESS_SHADOW_GENERATION), any());
        verify(g2).drawImage(eq(bgImage), anyInt(), anyInt(), anyInt(), anyInt(), eq(null));
    }

    @Test
    void testDraw_NullChartRenderingInfo() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(5, 5, 150, 150);
        Point2D anchor = new Point2D.Double(75, 75);
        ChartRenderingInfo info = null;

        chart.draw(g2, area, anchor, info);

        verify(g2).clip(area);
        verify(plot).draw(eq(g2), eq(area), eq(anchor), any(), eq(null));
    }

    @Test
    void testDraw_WithChartRenderingInfo_EntitiesNotNull() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(20, 20, 250, 250);
        Point2D anchor = new Point2D.Double(100, 100);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        when(info.getEntityCollection()).thenReturn(mock(org.jfree.chart.entity.EntityCollection.class));

        chart.draw(g2, area, anchor, info);

        verify(info).clear();
        verify(info).setChartArea(area);
        verify(plot).draw(eq(g2), eq(area), eq(anchor), any(), any());
    }

    @Test
    void testDraw_WithBorderVisible_BorderPaintAndStrokeSet() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 400, 400);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setBorderVisible(true);
        chart.setBorderPaint(Color.RED);
        chart.setBorderStroke(new BasicStroke(2.0f));

        chart.draw(g2, area, anchor, info);

        verify(g2).setPaint(Color.RED);
        verify(g2).setStroke(any(BasicStroke.class));
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDraw_WithBorderVisible_NullPaintOrStroke() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 400, 400);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setBorderVisible(true);
        chart.setBorderPaint(null);
        chart.setBorderStroke(null);

        chart.draw(g2, area, anchor, info);

        verify(g2, never()).setPaint(any());
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void testDraw_WithTitleVisible() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(50, 50, 300, 300);
        Point2D anchor = null;
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        TextTitle title = mock(TextTitle.class);
        when(title.isVisible()).thenReturn(true);
        chart.setTitle(title);

        chart.draw(g2, area, anchor, info);

        verify(title).draw(eq(g2), any(Rectangle2D.class), any(), any());
    }

    @Test
    void testDraw_WithTitleNotVisible() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(50, 50, 300, 300);
        Point2D anchor = null;
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        TextTitle title = mock(TextTitle.class);
        when(title.isVisible()).thenReturn(false);
        chart.setTitle(title);

        chart.draw(g2, area, anchor, info);

        verify(title, never()).draw(any(), any(), any(), any());
    }

    @Test
    void testDraw_WithSubtitlesVisible() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(30, 30, 350, 350);
        Point2D anchor = null;
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        TextTitle subtitle = mock(TextTitle.class);
        when(subtitle.isVisible()).thenReturn(true);
        chart.addSubtitle(subtitle);

        chart.draw(g2, area, anchor, info);

        verify(subtitle).draw(eq(g2), any(Rectangle2D.class), any(), any());
    }

    @Test
    void testDraw_WithSubtitlesNotVisible() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(30, 30, 350, 350);
        Point2D anchor = null;
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        TextTitle subtitle = mock(TextTitle.class);
        when(subtitle.isVisible()).thenReturn(false);
        chart.addSubtitle(subtitle);

        chart.draw(g2, area, anchor, info);

        verify(subtitle, never()).draw(any(), any(), any(), any());
    }

    @Test
    void testDraw_WithBackgroundPaint() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setBackgroundPaint(Color.BLUE);

        chart.draw(g2, area, anchor, info);

        verify(g2).setPaint(Color.BLUE);
        verify(g2).fill(area);
    }

    @Test
    void testDraw_WithoutBackgroundPaint() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setBackgroundPaint(null);

        chart.draw(g2, area, anchor, info);

        verify(g2, never()).setPaint(null);
        verify(g2, never()).fill(any());
    }

    @Test
    void testDraw_WithNullBackgroundImage() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 250, 250);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setBackgroundImage(null);

        chart.draw(g2, area, anchor, info);

        verify(g2, never()).setComposite(any());
        verify(g2, never()).drawImage(any(), anyInt(), anyInt(), anyInt(), anyInt(), any());
    }

    @Test
    void testDraw_WithBackgroundImage() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(10, 10, 400, 400);
        Point2D anchor = null;
        ChartRenderingInfo info = null;
        Image bgImage = mock(Image.class);

        chart.setBackgroundImage(bgImage);
        chart.setBackgroundImageAlignment(Align.FIT);
        chart.setBackgroundImageAlpha(0.3f);

        when(bgImage.getWidth(null)).thenReturn(100);
        when(bgImage.getHeight(null)).thenReturn(100);

        chart.draw(g2, area, anchor, info);

        verify(g2).setComposite(any());
        verify(g2).drawImage(eq(bgImage), anyInt(), anyInt(), anyInt(), anyInt(), eq(null));
        verify(g2).setComposite(any());
    }

    @Test
    void testDraw_WithElementHinting() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(15, 15, 350, 350);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setElementHinting(true);
        chart.setID("chart123");

        chart.draw(g2, area, anchor, info);

        verify(g2).setRenderingHint(eq(JFreeChart.KEY_SUPPRESS_SHADOW_GENERATION), any());
        verify(g2).setRenderingHint(eq(RenderingHints.KEY_TEXT_ANTIALIASING), any());
    }

    @Test
    void testDraw_WithNotifyFalse() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setNotify(false);
        chart.draw(g2, area, anchor, info);

        // Since notify is false, no events should be fired
        // Can't directly verify without more infrastructure
        // Just ensure no exceptions
        assertDoesNotThrow(() -> chart.draw(g2, area, anchor, info));
    }

    @Test
    void testDraw_WithClipRestore() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(25, 25, 275, 275);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        when(g2.getClip()).thenReturn(mock(Shape.class));

        chart.draw(g2, area, anchor, info);

        verify(g2).clip(area);
        verify(g2).setClip(any());
    }

    @Test
    void testDraw_WithMultipleSubtitles() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(20, 20, 300, 300);
        Point2D anchor = null;
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);

        TextTitle subtitle1 = mock(TextTitle.class);
        when(subtitle1.isVisible()).thenReturn(true);
        TextTitle subtitle2 = mock(TextTitle.class);
        when(subtitle2.isVisible()).thenReturn(true);

        chart.addSubtitle(subtitle1);
        chart.addSubtitle(subtitle2);

        chart.draw(g2, area, anchor, info);

        verify(subtitle1).draw(eq(g2), any(Rectangle2D.class), any(), any());
        verify(subtitle2).draw(eq(g2), any(Rectangle2D.class), any(), any());
    }

    @Test
    void testDraw_WithNullAnchor() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(60, 60, 400, 400);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.draw(g2, area, anchor, info);

        verify(plot).draw(eq(g2), eq(area), eq(anchor), any(), any());
    }

    @Test
    void testDraw_WithNonNullAnchor() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(60, 60, 400, 400);
        Point2D anchor = new Point2D.Double(200, 200);
        ChartRenderingInfo info = null;

        chart.draw(g2, area, anchor, info);

        verify(plot).draw(eq(g2), eq(area), eq(anchor), any(), any());
    }

    @Test
    void testDraw_AntialiasingOn() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0,0,100,100);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setAntiAlias(true);

        chart.draw(g2, area, anchor, info);

        verify(g2).addRenderingHints(any(RenderingHints.class));
    }

    @Test
    void testDraw_AntialiasingOff() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0,0,100,100);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setAntiAlias(false);

        chart.draw(g2, area, anchor, info);

        verify(g2).addRenderingHints(any(RenderingHints.class));
    }

    @Test
    void testDraw_WithNotifyTrue() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(50,50,150,150);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setNotify(true);
        chart.draw(g2, area, anchor, info);

        // Since notify is true, events should be fired
        // However, without actual listeners, just ensure no exceptions
        assertDoesNotThrow(() -> chart.draw(g2, area, anchor, info));
    }

    @Test
    void testDraw_WithNullTitleAndSubtitles() {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(10,10,100,100);
        Point2D anchor = null;
        ChartRenderingInfo info = null;

        chart.setTitle(null);
        chart.clearSubtitles();

        chart.draw(g2, area, anchor, info);

        verify(g2).clip(area);
    }
}