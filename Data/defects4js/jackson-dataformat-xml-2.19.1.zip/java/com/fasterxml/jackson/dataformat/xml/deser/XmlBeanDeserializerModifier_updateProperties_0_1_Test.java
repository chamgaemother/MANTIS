package com.fasterxml.jackson.dataformat.xml.deser;
import java.lang.reflect.*;
import java.io.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import static org.mockito.Mockito.*;
import java.util.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.introspect.*;
import com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil;

public class XmlBeanDeserializerModifier_updateProperties_0_1_Test {

    @Test
    @DisplayName("Empty propDefs list causes the method to return immediately without modifications")
    public void TC01() throws Exception {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();
        
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        Assertions.assertTrue(result.isEmpty(), "The returned list should be empty");
    }

    @Test
    @DisplayName("Single property with acc not null and b is true, property name remains unchanged")
    public void TC02() throws Exception {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getName()).thenReturn("propertyName");
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.TRUE);

        List<BeanPropertyDefinition> propDefs = Arrays.asList(prop);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        Assertions.assertEquals(1, result.size(), "The returned list should have one property");
        Assertions.assertEquals("propertyName", result.get(0).getName(), "Property name should remain unchanged");
    }

    @Test
    @DisplayName("Single property with acc not null and b is true, property is renamed")
    public void TC03() throws Exception {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getName()).thenReturn("originalName");
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.TRUE);

        BeanPropertyDefinition renamedProp = mock(BeanPropertyDefinition.class);
        when(renamedProp.getName()).thenReturn("");
        when(prop.withSimpleName(""))
            .thenReturn(renamedProp);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        Assertions.assertEquals(1, result.size(), "The returned list should have one property");
        Assertions.assertEquals("", result.get(0).getName(), "Property name should be renamed");
    }

    @Test
    @DisplayName("Single property with acc not null and b is null, property is processed without renaming")
    public void TC04() throws Exception {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getName()).thenReturn("propertyName");
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(null);

        List<BeanPropertyDefinition> propDefs = Arrays.asList(prop);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        Assertions.assertEquals(1, result.size(), "The returned list should have one property");
        Assertions.assertEquals("propertyName", result.get(0).getName(), "Property name should remain unchanged");
    }

    @Test
    @DisplayName("Single property with acc not null and b is false, property is processed without renaming")
    public void TC05() throws Exception {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getName()).thenReturn("propertyName");
        AnnotatedMember acc = mock(AnnotatedMember.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.FALSE);

        List<BeanPropertyDefinition> propDefs = Arrays.asList(prop);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");

        // WHEN
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        Assertions.assertEquals(1, result.size(), "The returned list should have one property");
        Assertions.assertEquals("propertyName", result.get(0).getName(), "Property name should remain unchanged");
    }
}