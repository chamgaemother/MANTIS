import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.language.ColognePhonetic;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ColognePhoneticTest {

    private final ColognePhonetic colognePhonetic = new ColognePhonetic();

    @Test
    @DisplayName("Test null input returns null")
    void testColognePhonetic_NullInput() {
        assertNull(colognePhonetic.colognePhonetic(null));
    }

    @Test
    @DisplayName("Test empty string input returns empty string")
    void testColognePhonetic_EmptyInput() {
        assertEquals("", colognePhonetic.colognePhonetic(""));
    }

    @Test
    @DisplayName("Test lowercase input is correctly uppercased")
    void testColognePhonetic_LowercaseInput() {
        assertEquals("800", colognePhonetic.colognePhonetic("oss"));
    }

    @Test
    @DisplayName("Test German umlauts are replaced correctly")
    void testColognePhonetic_GermanUmlauts() {
        assertEquals("4000S", colognePhonetic.colognePhonetic("ÄußS"));
    }

    @Test
    @DisplayName("Test vowels are encoded as '0'")
    void testColognePhonetic_Vowels() {
        assertEquals("0000", colognePhonetic.colognePhonetic("AEIO"));
    }

    @Test
    @DisplayName("Test 'H' character is handled correctly")
    void testColognePhonetic_HCharacter() {
        assertEquals("7", colognePhonetic.colognePhonetic("H"));
    }

    @Test
    @DisplayName("Test 'B' character is encoded as '1'")
    void testColognePhonetic_BCharacter() {
        assertEquals("1", colognePhonetic.colognePhonetic("B"));
    }

    @Test
    @DisplayName("Test 'P' not before 'H' is encoded as '1'")
    void testColognePhonetic_PNotBeforeH() {
        assertEquals("1", colognePhonetic.colognePhonetic("P"));
    }

    @Test
    @DisplayName("Test 'P' before 'H' is encoded as '3'")
    void testColognePhonetic_PBeforeH() {
        assertEquals("3", colognePhonetic.colognePhonetic("PH"));
    }

    @Test
    @DisplayName("Test 'D' not before 'C', 'S', 'Z' is encoded as '2'")
    void testColognePhonetic_DNotBeforeCSZ() {
        assertEquals("2", colognePhonetic.colognePhonetic("D"));
    }

    @Test
    @DisplayName("Test 'D' before 'C' is encoded as '8'")
    void testColognePhonetic_DBeforeC() {
        assertEquals("8", colognePhonetic.colognePhonetic("DC"));
    }

    @Test
    @DisplayName("Test 'T' not before 'S' is encoded as '2'")
    void testColognePhonetic_TNotBeforeS() {
        assertEquals("2", colognePhonetic.colognePhonetic("T"));
    }

    @Test
    @DisplayName("Test 'T' before 'S' is encoded as '8'")
    void testColognePhonetic_TBeforeS() {
        assertEquals("8", colognePhonetic.colognePhonetic("TS"));
    }

    @Test
    @DisplayName("Test 'W', 'F', 'V' are encoded as '3'")
    void testColognePhonetic_WFVPCharacters() {
        assertEquals("333", colognePhonetic.colognePhonetic("WFV"));
    }

    @Test
    @DisplayName("Test 'G', 'K', 'Q' are encoded as '4'")
    void testColognePhonetic_GKQCharacters() {
        assertEquals("444", colognePhonetic.colognePhonetic("GKQ"));
    }

    @Test
    @DisplayName("Test 'X' not after 'C', 'K', 'Q' is encoded as '48' and adds 'S'")
    void testColognePhonetic_XNotAfterCKQ() {
        assertEquals("48", colognePhonetic.colognePhonetic("X"));
    }

    @Test
    @DisplayName("Test 'X' after 'C' is encoded as '4'")
    void testColognePhonetic_XAfterC() {
        assertEquals("4", colognePhonetic.colognePhonetic("CX"));
    }

    @Test
    @DisplayName("Test 'X' after 'K' is encoded as '4'")
    void testColognePhonetic_XAfterK() {
        assertEquals("4", colognePhonetic.colognePhonetic("KX"));
    }

    @Test
    @DisplayName("Test 'X' after 'Q' is encoded as '4'")
    void testColognePhonetic_XAfterQ() {
        assertEquals("4", colognePhonetic.colognePhonetic("QX"));
    }

    @Test
    @DisplayName("Test 'S' and 'Z' are encoded as '8'")
    void testColognePhonetic_SZCharacters() {
        assertEquals("88", colognePhonetic.colognePhonetic("SZ"));
    }

    @Test
    @DisplayName("Test 'C' at onset before A, H, K, L, O, Q, R, U, X is encoded as '4'")
    void testColognePhonetic_CAtOnsetBeforeCertainLetters() {
        assertEquals("4", colognePhonetic.colognePhonetic("CA"));
        assertEquals("4", colognePhonetic.colognePhonetic("CH"));
        assertEquals("4", colognePhonetic.colognePhonetic("CK"));
        assertEquals("4", colognePhonetic.colognePhonetic("CL"));
        assertEquals("4", colognePhonetic.colognePhonetic("CO"));
        assertEquals("4", colognePhonetic.colognePhonetic("CQ"));
        assertEquals("4", colognePhonetic.colognePhonetic("CR"));
        assertEquals("4", colognePhonetic.colognePhonetic("CU"));
        assertEquals("4", colognePhonetic.colognePhonetic("CX"));
    }

    @Test
    @DisplayName("Test 'C' after 'S' or 'Z' is encoded as '8'")
    void testColognePhonetic_CAfterSZ() {
        assertEquals("88", colognePhonetic.colognePhonetic("SC"));
        assertEquals("88", colognePhonetic.colognePhonetic("ZC"));
    }

    @Test
    @DisplayName("Test 'C' not before A, H, K, L, O, Q, R, U, X is encoded as '8'")
    void testColognePhonetic_CNotBeforeCertainLetters() {
        assertEquals("8", colognePhonetic.colognePhonetic("CB"));
        assertEquals("8", colognePhonetic.colognePhonetic("CD"));
        assertEquals("8", colognePhonetic.colognePhonetic("CG"));
    }

    @Test
    @DisplayName("Test 'R' is encoded as '7'")
    void testColognePhonetic_RCharacter() {
        assertEquals("7", colognePhonetic.colognePhonetic("R"));
    }

    @Test
    @DisplayName("Test 'L' is encoded as '5'")
    void testColognePhonetic_LCharacter() {
        assertEquals("5", colognePhonetic.colognePhonetic("L"));
    }

    @Test
    @DisplayName("Test 'M' and 'N' are encoded as '6'")
    void testColognePhonetic_MNCharacters() {
        assertEquals("66", colognePhonetic.colognePhonetic("MN"));
    }

    @Test
    @DisplayName("Test non-alphabetic characters are handled correctly")
    void testColognePhonetic_NonAlphabeticCharacters() {
        assertEquals("", colognePhonetic.colognePhonetic("1234!@#$"));
    }

    @Test
    @DisplayName("Test collapsing of duplicate codes")
    void testColognePhonetic_CollapseDuplicateCodes() {
        assertEquals("123", colognePhonetic.colognePhonetic("BBPPT"));
    }

    @Test
    @DisplayName("Test removal of '0' codes except at the beginning")
    void testColognePhonetic_RemoveZeroCodes() {
        assertEquals("1", colognePhonetic.colognePhonetic("A1A"));
    }

    @Test
    @DisplayName("Test mixed input covering multiple branches")
    void testColognePhonetic_MixedInput() {
        assertEquals("6005507500206880022", colognePhonetic.colognePhonetic("Müller-Lüdenscheidt"));
    }

    @Test
    @DisplayName("Test input with consecutive similar codes after processing")
    void testColognePhonetic_ConsecutiveSimilarCodes() {
        assertEquals("123", colognePhonetic.colognePhonetic("BBD"));
    }

    @Test
    @DisplayName("Test input that results in codes outside '0'-'8'")
    void testColognePhonetic_CodesOutsideRange() {
        // Since the code assigns chr if not matched, but it's unlikely in this algorithm
        // However, testing with a character outside A-Z to trigger code='-'
        assertEquals("", colognePhonetic.colognePhonetic("1"));
    }

    @Test
    @DisplayName("Test preprocess replaces German characters and encodes correctly")
    void testColognePhonetic_PreprocessAndEncode() {
        assertEquals("4", colognePhonetic.colognePhonetic("Ä"));
        assertEquals("4", colognePhonetic.colognePhonetic("Ö"));
        assertEquals("4", colognePhonetic.colognePhonetic("Ü"));
        assertEquals("8", colognePhonetic.colognePhonetic("ß"));
    }
}