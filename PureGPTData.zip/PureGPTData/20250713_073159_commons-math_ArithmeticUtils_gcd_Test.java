import org.apache.commons.math3.exception.MathArithmeticException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArithmeticUtilsTest {

    @Test
    void gcdOfZeroAndZeroShouldReturnZero() {
        assertEquals(0L, ArithmeticUtils.gcd(0L, 0L));
    }

    @Test
    void gcdOfZeroAndPositiveShouldReturnPositive() {
        assertEquals(5L, ArithmeticUtils.gcd(0L, 5L));
    }

    @Test
    void gcdOfPositiveAndZeroShouldReturnPositive() {
        assertEquals(7L, ArithmeticUtils.gcd(7L, 0L));
    }

    @Test
    void gcdOfMinValueAndZeroShouldThrowException() {
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(Long.MIN_VALUE, 0L));
    }

    @Test
    void gcdOfZeroAndMinValueShouldThrowException() {
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(0L, Long.MIN_VALUE));
    }

    @Test
    void gcdOfMinValueAndMinValueShouldThrowException() {
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(Long.MIN_VALUE, Long.MIN_VALUE));
    }

    @Test
    void gcdOfNegativeAndPositiveShouldReturnGCD() {
        assertEquals(4L, ArithmeticUtils.gcd(-8L, 12L));
    }

    @Test
    void gcdOfPositiveAndNegativeShouldReturnGCD() {
        assertEquals(6L, ArithmeticUtils.gcd(18L, -6L));
    }

    @Test
    void gcdOfPositiveAndPositiveShouldReturnGCD() {
        assertEquals(14L, ArithmeticUtils.gcd(56L, 98L));
    }

    @Test
    void gcdOfNegativeAndNegativeShouldReturnGCD() {
        assertEquals(9L, ArithmeticUtils.gcd(-81L, -45L));
    }

    @Test
    void gcdWhenOneNumberIsOneShouldReturnOne() {
        assertEquals(1L, ArithmeticUtils.gcd(1L, Long.MAX_VALUE));
        assertEquals(1L, ArithmeticUtils.gcd(Long.MAX_VALUE, 1L));
    }

    @Test
    void gcdWhenOneNumberIsNegativeOneShouldReturnOne() {
        assertEquals(1L, ArithmeticUtils.gcd(-1L, Long.MAX_VALUE));
        assertEquals(1L, ArithmeticUtils.gcd(Long.MAX_VALUE, -1L));
    }
}