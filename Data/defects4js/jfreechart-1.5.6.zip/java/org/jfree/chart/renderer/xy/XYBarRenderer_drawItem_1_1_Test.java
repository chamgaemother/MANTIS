package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class XYBarRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem returns early when both y0 and y1 are NaN")
    void TC28_drawItem_bothY0AndY1NaN() throws Exception {
        // Given
        XYBarRenderer renderer = new XYBarRenderer();
        XYBarRenderer spyRenderer = Mockito.spy(renderer);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mock behaviors
        doReturn(true).when(spyRenderer).getItemVisible(series, item);
        doReturn(true).when(spyRenderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(series, item)).thenReturn(Double.NaN);

        // When
        spyRenderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis,
                            dataset, series, item, crosshairState, pass);

        // Then
        verify(g2, never()).fill(any(Rectangle2D.class));
    }

//     @Test
//     @DisplayName("drawItem throws IllegalStateException for unsupported plot orientation")
//     void TC29_drawItem_unsupportedOrientation_throwsException() throws Exception {
        // Given
//         XYBarRenderer renderer = new XYBarRenderer();
//         XYBarRenderer spyRenderer = Mockito.spy(renderer);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         int series = 0;
//         int item = 0;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 1;
// 
        // Mock behaviors
//         doReturn(true).when(spyRenderer).getItemVisible(series, item);
//         doReturn(false).when(spyRenderer).getUseYInterval();
//         doReturn(0.0).when(spyRenderer).getBase();
//         when(dataset.getYValue(series, item)).thenReturn(10.0);
//         when(dataset.getStartXValue(series, item)).thenReturn(1.0);
//         when(dataset.getEndXValue(series, item)).thenReturn(2.0);
//         when(rangeAxis.valueToJava2D(any(Double.class), eq(dataArea), any())).thenReturn(100.0);
//         when(domainAxis.valueToJava2D(any(Double.class), eq(dataArea), any())).thenReturn(50.0);
//         when(plot.getOrientation()).thenReturn(null); // Unsupported orientation
// 
        // When & Then
//         assertThrows(IllegalStateException.class, () -> {
//             spyRenderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis,
//                                 dataset, series, item, crosshairState, pass);
//         });
//     }

    @Test
    @DisplayName("drawItem handles scenario when y0 is greater than y1")
    void TC30_drawItem_y0GreaterThanY1_drawsBar() throws Exception {
        // Given
        XYBarRenderer renderer = new XYBarRenderer();
        XYBarRenderer spyRenderer = Mockito.spy(renderer);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mock behaviors
        doReturn(true).when(spyRenderer).getItemVisible(series, item);
        doReturn(true).when(spyRenderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(20.0); // y0 > y1
        when(dataset.getEndYValue(series, item)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, any())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, any())).thenReturn(100.0);
        when(dataset.getStartXValue(series, item)).thenReturn(1.0);
        when(dataset.getEndXValue(series, item)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, any())).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        doReturn(0.1).when(spyRenderer).getMargin();

        // When
        spyRenderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis,
                            dataset, series, item, crosshairState, pass);

        // Then
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
        // Further verification can be added to check the correctness of the drawn bar
    }

    @Test
    @DisplayName("drawItem handles multiple iterations with one visible series")
    void TC31_drawItem_multipleIterations_oneVisibleSeries() throws Exception {
        // Given
        XYBarRenderer renderer = new XYBarRenderer();
        XYBarRenderer spyRenderer = Mockito.spy(renderer);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mock behaviors
        doReturn(true).when(spyRenderer).getItemVisible(series, item);
        doReturn(true).when(spyRenderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(5.0);
        when(dataset.getEndYValue(series, item)).thenReturn(15.0);
        when(dataset.getStartXValue(series, item)).thenReturn(1.0);
        when(dataset.getEndXValue(series, item)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, any())).thenReturn(150.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, any())).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        doReturn(0.1).when(spyRenderer).getMargin();
        when(dataset.getSeriesCount()).thenReturn(1);
        doReturn(true).when(spyRenderer).isSeriesVisible(0);

        // When
        spyRenderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis,
                            dataset, series, item, crosshairState, pass);

        // Then
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
        // Further verification can be added to ensure correct handling of iterations
    }

    @Test
    @DisplayName("drawItem handles exception when dataset casting fails")
    void TC32_drawItem_invalidDatasetCasting_throwsClassCastException() {
        // Given
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class); // Not an IntervalXYDataset
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mock behaviors
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();
        doReturn(0.0).when(renderer).getBase();
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // When & Then
        assertThrows(ClassCastException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis,
                               dataset, series, item, crosshairState, pass);
        });
    }
}