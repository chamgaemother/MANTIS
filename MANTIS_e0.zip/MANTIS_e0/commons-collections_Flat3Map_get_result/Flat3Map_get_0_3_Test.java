package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Flat3Map_get_0_3_Test {

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 2, hash2 matches but keys not equal")
    public void TC11() throws Exception {
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);

        // Set key to "nonEqualKey2"
        Object key = "nonEqualKey2";

        // Set key2 to "differentKey2"
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "differentKey2");

        // Set hash2 to key.hashCode()
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, key.hashCode());

        // Set key1 to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // Invoke get method
        Object result = map.get(key);

        // Assert that result is null
        assertNull(result);
    }

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 1, hash1 matches and keys are equal")
    public void TC12() throws Exception {
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 1);

        // Set key to "existingKey1"
        Object key = "existingKey1";

        // Set key1 to key
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key);

        // Set hash1 to key.hashCode()
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, key.hashCode());

        // Invoke get method
        Object result = map.get(key);

        // Assert that result equals value1
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = value1Field.get(map);
        assertEquals(value1, result);
    }

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 1, hash1 does not match")
    public void TC13() throws Exception {
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 1);

        // Set key to "nonMatchingKey1"
        Object key = "nonMatchingKey1";

        // Set key1 to "existingKey1"
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "existingKey1");

        // Set hash1 to key.hashCode() + 1
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, key.hashCode() + 1);

        // Invoke get method
        Object result = map.get(key);

        // Assert that result is null
        assertNull(result);
    }

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 0")
    public void TC14() throws Exception {
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 0
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 0);

        // Set key to "anyKey"
        Object key = "anyKey";

        // Invoke get method
        Object result = map.get(key);

        // Assert that result is null
        assertNull(result);
    }
}