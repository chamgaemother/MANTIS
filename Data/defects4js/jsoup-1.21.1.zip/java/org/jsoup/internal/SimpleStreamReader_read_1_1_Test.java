package org.jsoup.internal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.charset.CharacterCodingException;
import java.lang.reflect.Field;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.CharsetDecoder;

public class SimpleStreamReader_read_1_1_Test {

    @Test
    @DisplayName("read is called with charBuffer position at 0, expecting -1 for empty input stream")
    public void TC17() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        InputStream in = new ByteArrayInputStream(new byte[0]);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertEquals(-1, result);
    }

    @Test
    @DisplayName("read is called with charBuffer position at 0 and available bytes, expecting non-negative result on read")
    public void TC18() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        InputStream in = new ByteArrayInputStream(new byte[]{0});
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertTrue(result >= 0);
    }

    @Test
    @DisplayName("read encounters overflow condition, customized to throw CharacterCodingException")
    public void TC19() throws Exception {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        InputStream in = new ByteArrayInputStream(new byte[]{'x'});
        CharsetDecoder realDecoder = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
        Field decoderField = SimpleStreamReader.class.getDeclaredField("decoder");
        decoderField.setAccessible(true);
        decoderField.set(reader, realDecoder);

        // WHEN & THEN
        Exception exception = assertThrows(CharacterCodingException.class, () -> {
            reader.read(buffer, off, len);
        });

        assertNotNull(exception);
    }

    @Test
    @DisplayName("read is called with zero length, expecting immediate return of 0")
    public void TC20() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 0;
        InputStream in = new ByteArrayInputStream(new byte[]{'a', 'b', 'c'});
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("read with negative offset, expecting IndexOutOfBoundsException")
    public void TC21() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = -1;
        int len = 5;
        InputStream in = new ByteArrayInputStream(new byte[]{'a', 'b', 'c', 'd', 'e'});
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN & THEN
        assertThrows(IndexOutOfBoundsException.class, () -> {
            reader.read(buffer, off, len);
        });
    }
}