package com.fasterxml.jackson.core.io;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ContentReference_appendSourceDescription_0_2_Test {

    @Test
    @DisplayName("srcRef is not Class, tn does not start with \"java.\", and srcRef is of unknown type, appends original class name")
    void TC06_srcRef_is_unknown_type_and_non_java_package() throws Exception {
        // GIVEN
        ContentReference instance = ContentReference.unknown();
        // Creating an object of a non-Java defined class (NonJavaClass)
        Object nonJavaObject = new NonJavaClass();  // Assume NonJavaClass is non-Java class
        
        // Using reflection to set the _rawContent field
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        rawContentField.set(instance, nonJavaObject);

        StringBuilder sb = new StringBuilder();

        // WHEN
        Method appendMethod = ContentReference.class.getDeclaredMethod("appendSourceDescription", StringBuilder.class);
        appendMethod.setAccessible(true);
        StringBuilder result = (StringBuilder) appendMethod.invoke(instance, sb);

        // THEN
        assertNotNull(result);
        assertTrue(result.toString().contains("(" + nonJavaObject.getClass().getName() + ")"));
    }

    @Test
    @DisplayName("hasTextualContent is true with srcRef as CharSequence, contentLength <= maxRawContentLength, appends trimmed content without truncation")
    void TC07_hasTextualContent_true_with_CharSequence_no_truncation() throws Exception {
        // GIVEN
        ContentReference instance = ContentReference.unknown();

        Field isContentTextualField = ContentReference.class.getDeclaredField("_isContentTextual");
        isContentTextualField.setAccessible(true);
        isContentTextualField.set(instance, true);  // setting boolean

        // Setting raw content as char sequence
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        CharSequence charSequence = "SampleContent";
        rawContentField.set(instance, charSequence);

        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, charSequence.length());  // directly assigning length

        Field maxRawContentLengthField = ContentReference.class.getDeclaredField("_maxRawContentLength");
        maxRawContentLengthField.setAccessible(true);
        maxRawContentLengthField.set(instance, 50);  // larger than charSequence length

        StringBuilder sb = new StringBuilder();

        // WHEN
        Method appendMethod = ContentReference.class.getDeclaredMethod("appendSourceDescription", StringBuilder.class);
        appendMethod.setAccessible(true);
        StringBuilder result = (StringBuilder) appendMethod.invoke(instance, sb);

        // THEN
        assertNotNull(result);
        assertTrue(result.toString().contains(charSequence.toString()));
        assertFalse(result.toString().contains("truncated"));
    }

    @Test
    @DisplayName("hasTextualContent is true with srcRef as byte[], contentLength > maxRawContentLength, appends truncated notice")
    void TC08_hasTextualContent_true_with_byte_array_truncated() throws Exception {
        // GIVEN
        ContentReference instance = ContentReference.unknown();

        Field isContentTextualField = ContentReference.class.getDeclaredField("_isContentTextual");
        isContentTextualField.setAccessible(true);
        isContentTextualField.set(instance, true);  // setting boolean

        // Setting raw content as byte array
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        byte[] byteArray = new byte[100];
        rawContentField.set(instance, byteArray);

        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, byteArray.length);  // correct length assignment

        Field maxRawContentLengthField = ContentReference.class.getDeclaredField("_maxRawContentLength");
        maxRawContentLengthField.setAccessible(true);
        maxRawContentLengthField.set(instance, 50);  // setting the max length smaller than byteArray

        StringBuilder sb = new StringBuilder();

        // WHEN
        Method appendMethod = ContentReference.class.getDeclaredMethod("appendSourceDescription", StringBuilder.class);
        appendMethod.setAccessible(true);
        StringBuilder result = (StringBuilder) appendMethod.invoke(instance, sb);

        // THEN
        assertNotNull(result);
        assertTrue(result.toString().contains("[truncated 50 bytes]"));
    }

    @Test
    @DisplayName("hasTextualContent is true with srcRef as char[], contentLength > maxRawContentLength, appends truncated chars notice")
    void TC09_hasTextualContent_true_with_char_array_truncated() throws Exception {
        // GIVEN
        ContentReference instance = ContentReference.unknown();

        Field isContentTextualField = ContentReference.class.getDeclaredField("_isContentTextual");
        isContentTextualField.setAccessible(true);
        isContentTextualField.set(instance, true);  // setting boolean

        // Setting raw content as char array
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        char[] charArray = new char[100];
        rawContentField.set(instance, charArray);

        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, charArray.length);  // correct length assignment

        Field maxRawContentLengthField = ContentReference.class.getDeclaredField("_maxRawContentLength");
        maxRawContentLengthField.setAccessible(true);
        maxRawContentLengthField.set(instance, 50);  // smaller than charArray length

        StringBuilder sb = new StringBuilder();

        // WHEN
        Method appendMethod = ContentReference.class.getDeclaredMethod("appendSourceDescription", StringBuilder.class);
        appendMethod.setAccessible(true);
        StringBuilder result = (StringBuilder) appendMethod.invoke(instance, sb);

        // THEN
        assertNotNull(result);
        assertTrue(result.toString().contains("[truncated 50 chars]"));
    }

    @Test
    @DisplayName("hasTextualContent is false with srcRef as byte[], contentLength >= 0, appends byte array length statement")
    void TC10_hasTextualContent_false_with_byte_array_non_truncated() throws Exception {
        // GIVEN
        ContentReference instance = ContentReference.unknown();

        Field isContentTextualField = ContentReference.class.getDeclaredField("_isContentTextual");
        isContentTextualField.setAccessible(true);
        isContentTextualField.set(instance, false);  // setting as non-textual

        // Setting raw content as byte array
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        byte[] byteArray = new byte[100];
        rawContentField.set(instance, byteArray);

        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, byteArray.length);

        StringBuilder sb = new StringBuilder();

        // WHEN
        Method appendMethod = ContentReference.class.getDeclaredMethod("appendSourceDescription", StringBuilder.class);
        appendMethod.setAccessible(true);
        StringBuilder result = (StringBuilder) appendMethod.invoke(instance, sb);

        // THEN
        assertNotNull(result);
        assertTrue(result.toString().contains("[100 bytes]"));
    }

    // Mock class for non-java package class
    private static class NonJavaClass {
        // Add fields or methods if necessary
    }
}