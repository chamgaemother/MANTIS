package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

public class TarArchiveOutputStream_putArchiveEntry_0_7_Test {

//     @Test
//     @DisplayName("putArchiveEntry with directory entry and non-ASCII link name")
//     public void TC31_putArchiveEntry_with_directory_entry_nonASCII_linkName() {
        // GIVEN
//         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(byteArrayOutputStream);
//         TarArchiveEntry entry = new TarArchiveEntry("dummyName");
//         entry.setDirectory(true);
        // Ensure linkName is not set for directories
        // WHEN & THEN
//         assertDoesNotThrow(() -> outputStream.putArchiveEntry(entry),
//                 "Expected putArchiveEntry to handle directory entry without throwing an exception.");
//         
        // Clean up
//         try {
//             outputStream.closeArchiveEntry(); // Added closeArchiveEntry to avoid unclosed entry exception
//             outputStream.close();
//         } catch (IOException e) {
            // Handle exception if necessary
//         }
//     }
}