import org.apache.commons.lang3.math.NumberUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

class NumberUtilsTest {

    @Nested
    @DisplayName("isCreatable Tests")
    class IsCreatableTests {

        @Test
        @DisplayName("Null input should return false")
        void testNullInput() {
            assertFalse(NumberUtils.isCreatable(null));
        }

        @ParameterizedTest(name = "Empty String \"{0}\" should return false")
        @CsvSource({
            "",
            "   ",
            "\t",
            "\n"
        })
        void testEmptyOrBlankInput(String input) {
            assertFalse(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Valid decimal number \"{0}\" should return true")
        @CsvSource({
            "123",
            "-123",
            "+123",
            "0",
            "456.789",
            "-456.789",
            "+456.789",
            "1.2e10",
            "-1.2e10",
            "+1.2e10",
            "1.2E10",
            "-1.2E10",
            "+1.2E10"
        })
        void testValidDecimalNumbers(String input) {
            assertTrue(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Valid hexadecimal number \"{0}\" should return true")
        @CsvSource({
            "0x1A",
            "0X1a",
            "#1A",
            "-0x1A",
            "+0X1A",
            "#1a"
        })
        void testValidHexadecimalNumbers(String input) {
            assertTrue(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Valid octal number \"{0}\" should return true")
        @CsvSource({
            "0777",
            "-0777",
            "+0777",
            "0"
        })
        void testValidOctalNumbers(String input) {
            assertTrue(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Invalid hexadecimal number \"{0}\" should return false")
        @CsvSource({
            "0x",
            "0xG1",
            "#",
            "#G1",
            "-0x",
            "+#",
            "0x1G"
        })
        void testInvalidHexadecimalNumbers(String input) {
            assertFalse(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Invalid octal number \"{0}\" should return false")
        @CsvSource({
            "08",
            "09",
            "-08",
            "+09",
            "08.1",
            "0778"
        })
        void testInvalidOctalNumbers(String input) {
            assertFalse(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Invalid number formats \"{0}\" should return false")
        @CsvSource({
            ".",
            "-.",
            "+.",
            "1.2.3",
            "1e",
            "1e+",
            "e10",
            "--123",
            "++123",
            "123LFF",
            "123DDF",
            "123..",
            "123e10e10",
            "123e10.5",
            "1.2e3.4",
            "abc",
            "123abc"
        })
        void testInvalidNumberFormats(String input) {
            assertFalse(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Valid type suffixes \"{0}\" should return true")
        @CsvSource({
            "123L",
            "-123L",
            "+123L",
            "123l",
            "123F",
            "-123F",
            "+123F",
            "123f",
            "123D",
            "-123D",
            "+123D",
            "123d"
        })
        void testValidTypeSuffixes(String input) {
            assertTrue(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Invalid type suffixes \"{0}\" should return false")
        @CsvSource({
            "123LF",
            "123FD",
            "123LD",
            "123L1",
            "123F1",
            "123D1",
            "123L.",
            "123F.",
            "123D."
        })
        void testInvalidTypeSuffixes(String input) {
            assertFalse(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Numbers with trailing decimal point \"{0}\" should return true")
        @CsvSource({
            "123.",
            "-123.",
            "+123.",
            "0.",
            ".123",
            "-.123",
            "+.123"
        })
        void testNumbersWithTrailingDecimalPoint(String input) {
            assertTrue(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Boundary values \"{0}\" should return true")
        @CsvSource({
            String.valueOf(Integer.MAX_VALUE),
            String.valueOf(Integer.MIN_VALUE),
            String.valueOf(Long.MAX_VALUE),
            String.valueOf(Long.MIN_VALUE),
            "3.4028235e38", // Float.MAX_VALUE
            "1.7976931348623157e308" // Double.MAX_VALUE
        })
        void testBoundaryValues(String input) {
            assertTrue(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Boundary values \"{0}\" should return false")
        @CsvSource({
            String.valueOf((long) Integer.MAX_VALUE + 1),
            String.valueOf((long) Integer.MIN_VALUE - 1),
            "0xFFFFFFFFFFFFFFFFF",
            "#FFFFFFFFFFFFFFFFF",
            "1.7976931348623157e309", // Double beyond max
            "3.4028236e38" // Float beyond max
        })
        void testBoundaryValuesExceedingLimits(String input) {
            // Even if exceeding Integer or Long, NumberUtils.isCreatable should return true
            // because it can create BigInteger or BigDecimal
            assertTrue(NumberUtils.isCreatable(input));
        }

        @Test
        @DisplayName("Single digit zero \"0\" should return true")
        void testSingleZero() {
            assertTrue(NumberUtils.isCreatable("0"));
        }

        @ParameterizedTest(name = "Leading zeros \"{0}\" should return true")
        @CsvSource({
            "000123",
            "-000123",
            "+000123",
            "000.123",
            "000e123",
            "000.000"
        })
        void testLeadingZeros(String input) {
            assertTrue(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Numbers with multiple signs \"{0}\" should return false")
        @CsvSource({
            "--123",
            "++123",
            "+-123",
            "-+123"
        })
        void testMultipleSigns(String input) {
            assertFalse(NumberUtils.isCreatable(input));
        }

        @ParameterizedTest(name = "Numbers with internal spaces \"{0}\" should return false")
        @CsvSource({
            "12 3",
            "1 23",
            "1.2 3",
            "1 e10",
            "0x1 A"
        })
        void testNumbersWithInternalSpaces(String input) {
            assertFalse(NumberUtils.isCreatable(input));
        }
    }
}