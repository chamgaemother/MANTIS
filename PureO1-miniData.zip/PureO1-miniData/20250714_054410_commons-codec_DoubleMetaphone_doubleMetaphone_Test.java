import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.language.DoubleMetaphone;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DoubleMetaphoneTest {

    private final DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

    @Test
    void testDoubleMetaphone_NullInput() {
        assertNull(doubleMetaphone.doubleMetaphone(null, false));
    }

    @Test
    void testDoubleMetaphone_EmptyString() {
        assertNull(doubleMetaphone.doubleMetaphone("", false));
    }

    @Test
    void testDoubleMetaphone_SilentStart_GN() {
        assertEquals("N", doubleMetaphone.doubleMetaphone("GNOME", false));
    }

    @Test
    void testDoubleMetaphone_SilentStart_KN() {
        assertEquals("N", doubleMetaphone.doubleMetaphone("KNIGHT", false));
    }

    @Test
    void testDoubleMetaphone_SilentStart_PN() {
        assertEquals("N", doubleMetaphone.doubleMetaphone("PNAME", false));
    }

    @Test
    void testDoubleMetaphone_SilentStart_WR() {
        assertEquals("R", doubleMetaphone.doubleMetaphone("WRAP", false));
    }

    @Test
    void testDoubleMetaphone_SilentStart_PS() {
        assertEquals("S", doubleMetaphone.doubleMetaphone("PSYCHO", false));
    }

    @Test
    void testDoubleMetaphone_VowelAtStart() {
        assertEquals("A123", doubleMetaphone.doubleMetaphone("AEIOUY", false).substring(0,1));
    }

    @Test
    void testDoubleMetaphone_SlavoGermanic_W() {
        assertTrue(doubleMetaphone.isSlavoGermanic("WITZ"));
    }

    @Test
    void testDoubleMetaphone_IsVowel_A() {
        assertTrue(doubleMetaphone.isVowel('A'));
    }

    @Test
    void testDoubleMetaphone_IsVowel_B() {
        assertFalse(doubleMetaphone.isVowel('B'));
    }

    @Test
    void testDoubleMetaphone_HandlePH() {
        assertEquals("F", doubleMetaphone.doubleMetaphone("PH", false));
    }

    @Test
    void testDoubleMetaphone_HandleSCH() {
        assertEquals("SK", doubleMetaphone.doubleMetaphone("SCHOLAR", false));
    }

    @Test
    void testDoubleMetaphone_HandleXAtStart() {
        assertEquals("S", doubleMetaphone.doubleMetaphone("Xavier", false).substring(0,1));
    }

    @Test
    void testDoubleMetaphone_HandleXMiddle() {
        assertTrue(doubleMetaphone.doubleMetaphone("Foxy", false).contains("KS"));
    }

    @Test
    void testDoubleMetaphone_HandleJ() {
        assertEquals("J", doubleMetaphone.doubleMetaphone("Jupiter", false).substring(0,1));
    }

    @Test
    void testDoubleMetaphone_HandleCH_Greek() {
        assertEquals("K", doubleMetaphone.doubleMetaphone("CHORUS", false));
    }

    @Test
    void testDoubleMetaphone_HandleCH_Scholar() {
        assertEquals("SK", doubleMetaphone.doubleMetaphone("SCHOLAR", false));
    }

    @Test
    void testDoubleMetaphone_HandleC_CIA() {
        assertTrue(doubleMetaphone.doubleMetaphone("Piazza", false).contains("X"));
    }

    @Test
    void testDoubleMetaphone_HandleGH_Laugh() {
        assertTrue(doubleMetaphone.doubleMetaphone("laugh", false).contains("F"));
    }

    @Test
    void testDoubleMetaphone_HandleTTION() {
        assertTrue(doubleMetaphone.doubleMetaphone("option", false).contains("X"));
    }

    @Test
    void testDoubleMetaphone_HandleZ_Slavic() {
        assertTrue(doubleMetaphone.doubleMetaphone("Zoltan", true).contains("TS"));
    }

    @Test
    void testDoubleMetaphone_HandleZ_HChinese() {
        assertTrue(doubleMetaphone.doubleMetaphone("Zhao", false).contains("J"));
    }

    @Test
    void testDoubleMetaphone_HandleDoubleLetters() {
        assertEquals("P", doubleMetaphone.doubleMetaphone("PP", false));
    }

    @Test
    void testDoubleMetaphone_HandleFinalH_Vowel() {
        assertTrue(doubleMetaphone.doubleMetaphone("AH", false).contains("H"));
    }

    @Test
    void testDoubleMetaphone_HandleFinalH_Consonant() {
        assertFalse(doubleMetaphone.doubleMetaphone("AHB", false).contains("H"));
    }

    @Test
    void testDoubleMetaphone_AlternateEncoding() {
        assertNotEquals(doubleMetaphone.doubleMetaphone("Smith", false), doubleMetaphone.doubleMetaphone("Smith", true));
    }

    @Test
    void testDoubleMetaphone_MaxCodeLen() {
        doubleMetaphone.setMaxCodeLen(6);
        assertTrue(doubleMetaphone.doubleMetaphone("Jackson", false).length() <= 6);
    }

    @Test
    void testDoubleMetaphone_IsDoubleMetaphoneEqual_True() {
        assertTrue(doubleMetaphone.isDoubleMetaphoneEqual("Smith", "Smyth"));
    }

    @Test
    void testDoubleMetaphone_IsDoubleMetaphoneEqual_False() {
        assertFalse(doubleMetaphone.isDoubleMetaphoneEqual("Rose", "Roes"));
    }

    @Test
    void testDoubleMetaphone_HandleT_TH() {
        assertTrue(doubleMetaphone.doubleMetaphone("Thomas", false).contains("T"));
    }

    @Test
    void testDoubleMetaphone_HandleT_TH_other() {
        assertTrue(doubleMetaphone.doubleMetaphone("Thomas", false).contains("0"));
    }

    @Test
    void testDoubleMetaphone_HandleD_GD() {
        assertTrue(doubleMetaphone.doubleMetaphone("Edge", false).contains("J"));
    }

    @Test
    void testDoubleMetaphone_HandleD_DT() {
        assertTrue(doubleMetaphone.doubleMetaphone("DUTCH", false).contains("T"));
    }

    @Test
    void testDoubleMetaphone_HandleC_CHIA() {
        assertTrue(doubleMetaphone.doubleMetaphone("CHIA", false).contains("X"));
    }

    @Test
    void testDoubleMetaphone_HandleC_CK() {
        assertTrue(doubleMetaphone.doubleMetaphone("ACKNOWLEDGE", false).contains("K"));
    }

    @Test
    void testDoubleMetaphone_HandleG_GN() {
        assertEquals("N", doubleMetaphone.doubleMetaphone("GNOME", false));
    }

    @Test
    void testDoubleMetaphone_HandleGLI() {
        assertTrue(doubleMetaphone.doubleMetaphone("GLIDE", false).contains("KL"));
    }

    @Test
    void testDoubleMetaphone_HandleGH_ParkerRule() {
        assertTrue(doubleMetaphone.doubleMetaphone("ough", false).contains("F"));
    }

    @Test
    void testDoubleMetaphone_HandleM_UMB() {
        assertTrue(doubleMetaphone.doubleMetaphone("UMBRA", false).contains("M"));
    }

    @Test
    void testDoubleMetaphone_HandleS_SC() {
        assertTrue(doubleMetaphone.doubleMetaphone("SCHOOL", false).contains("X"));
    }

    @Test
    void testDoubleMetaphone_HandleW_WR() {
        assertTrue(doubleMetaphone.doubleMetaphone("WRAP", false).contains("R"));
    }

    @Test
    void testDoubleMetaphone_HandleW_START_WH() {
        assertTrue(doubleMetaphone.doubleMetaphone("WHOA", false).contains("F"));
    }

    @Test
    void testDoubleMetaphone_HandleW_END_FollowedByVowel() {
        assertTrue(doubleMetaphone.doubleMetaphone("SAW", false).contains("S"));
    }

    @Test
    void testDoubleMetaphone_HandleW_POLISH() {
        assertTrue(doubleMetaphone.doubleMetaphone("WITZ", false).contains("FX"));
    }

    @Test
    void testDoubleMetaphone_HandleMultipleConditions() {
        assertEquals("PRSM", doubleMetaphone.doubleMetaphone("PRASSEN", false));
    }

    @Test
    void testDoubleMetaphone_HandleZH() {
        assertTrue(doubleMetaphone.doubleMetaphone("Zhou", false).contains("J"));
    }

    @Test
    void testDoubleMetaphone_HandleDoubleZ() {
        assertTrue(doubleMetaphone.doubleMetaphone("ZZTop", false).contains("S"));
    }

    @Test
    void testDoubleMetaphone_HandleSpecialChars() {
        assertEquals("S", doubleMetaphone.doubleMetaphone("Š", false));
    }

    @Test
    void testDoubleMetaphone_HandleNonEnglish() {
        assertEquals("X", doubleMetaphone.doubleMetaphone("Żubr", false).substring(0,1));
    }

    @Test
    void testDoubleMetaphone_HandleComplexWord() {
        assertTrue(doubleMetaphone.doubleMetaphone("Schwarzenegger", false).contains("SK"));
    }

    @Test
    void testEncode_ObjectValid() throws EncoderException {
        assertEquals("SM0", doubleMetaphone.encode("Smith"));
    }

    @Test
    void testEncode_ObjectInvalid() {
        assertThrows(EncoderException.class, () -> doubleMetaphone.encode(123));
    }

    @Test
    void testEncode_String() {
        assertEquals("SM0", doubleMetaphone.encode("Smith"));
    }
}