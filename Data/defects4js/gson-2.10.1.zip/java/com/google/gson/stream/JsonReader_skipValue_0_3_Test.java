package com.google.gson.stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.StringReader;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class JsonReader_skipValue_0_3_Test {

    @Test
    @DisplayName("skipValue() with PEEKED_NUMBER token")
    void TC11_skipValue_with_PEEKED_NUMBER_token() throws Exception {
        // Initialize JsonReader with a NUMBER token
        StringReader stringReader = new StringReader("123");
        JsonReader reader = new JsonReader(stringReader);

        // Access and set the private 'peeked' field to PEEKED_NUMBER
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 16); // Correct usage of constant

        // Access and set the private 'peekedNumberLength' field
        Field peekedNumberLengthField = JsonReader.class.getDeclaredField("peekedNumberLength");
        peekedNumberLengthField.setAccessible(true);
        peekedNumberLengthField.setInt(reader, 3); // Assuming the number length is 3 for '123'

        // Access and set the private 'pos' field
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        posField.setInt(reader, 0); // Initial position

        // Invoke skipValue()
        reader.skipValue();

        // Assert that 'pos' is incremented by 'peekedNumberLength'
        int expectedPos = 3;
        int actualPos = posField.getInt(reader);
        assertEquals(expectedPos, actualPos, "Position should be incremented by peekedNumberLength");
    }

    @Test
    @DisplayName("skipValue() with PEEKED_EOF token")
    void TC12_skipValue_with_PEEKED_EOF_token() throws Exception {
        // Initialize JsonReader with EOF token
        StringReader stringReader = new StringReader("");
        JsonReader reader = new JsonReader(stringReader);

        // Access and set the private 'peeked' field to PEEKED_EOF
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 17); // Correct usage of constant

        // Access and set the private 'pos' field
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        posField.setInt(reader, 0); // Initial position

        // Invoke skipValue()
        reader.skipValue();

        // Assert that 'pos' remains unchanged
        int expectedPos = 0;
        int actualPos = posField.getInt(reader);
        assertEquals(expectedPos, actualPos, "Position should remain unchanged when EOF is encountered");
    }

    @Test
    @DisplayName("skipValue() loop with count decrement leading to loop termination")
    void TC13_skipValue_loop_decrement() throws Exception {
        // Initialize JsonReader with BEGIN_ARRAY token and count = 1
        StringReader stringReader = new StringReader("[1]");
        JsonReader reader = new JsonReader(stringReader);

        // Access and set the private 'peeked' field to PEEKED_BEGIN_ARRAY
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 3); // Correct usage of constant

        // Access and set the private 'stackSize' field to 1
        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        stackSizeField.setInt(reader, 1);

        // Access and set the private 'pathNames' field
        Field pathNamesField = JsonReader.class.getDeclaredField("pathNames");
        pathNamesField.setAccessible(true);
        pathNamesField.set(reader, new String[]{"array"});

        // Access and set the private 'pos' field
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        posField.setInt(reader, 1); // Position after '['

        // Invoke skipValue()
        reader.skipValue();

        // Access and verify 'stackSize' is decremented to 0
        int expectedStackSize = 0;
        int actualStackSize = stackSizeField.getInt(reader);
        assertEquals(expectedStackSize, actualStackSize, "stackSize should be decremented to zero, terminating the loop");
    }

    @Test
    @DisplayName("skipValue() loop with multiple increments and decrements")
    void TC14_skipValue_multiple_iterations() throws Exception {
        // Initialize JsonReader with multiple BEGIN_ARRAY tokens and count = 2
        StringReader stringReader = new StringReader("[[1,2],3]");
        JsonReader reader = new JsonReader(stringReader);

        // Access and set the private 'peeked' field to PEEKED_BEGIN_ARRAY
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 3); // Correct usage of constant

        // Access and set the private 'stackSize' field to 2
        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        stackSizeField.setInt(reader, 2);

        // Access and set the private 'pathNames' field
        Field pathNamesField = JsonReader.class.getDeclaredField("pathNames");
        pathNamesField.setAccessible(true);
        pathNamesField.set(reader, new String[]{"outerArray", "innerArray"});

        // Access and set the private 'pos' field
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        posField.setInt(reader, 2); // Position after '[['

        // Invoke skipValue()
        reader.skipValue();

        // Access and verify 'stackSize' is decremented to 0 after multiple iterations
        int expectedStackSize = 0;
        int actualStackSize = stackSizeField.getInt(reader);
        assertEquals(expectedStackSize, actualStackSize, "stackSize should be decremented to zero after multiple iterations, terminating the loop");
    }

    @Test
    @DisplayName("skipValue() with peeked already set to PEEKED_BEGIN_OBJECT")
    void TC15_skipValue_with_pre_peeked_BEGIN_OBJECT() throws Exception {
        // Initialize JsonReader with a BEGIN_OBJECT token
        StringReader stringReader = new StringReader("{\"key\":\"value\"}");
        JsonReader reader = new JsonReader(stringReader);

        // Access and set the private 'peeked' field to PEEKED_BEGIN_OBJECT
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        peekedField.setInt(reader, 1); // Correct usage of constant

        // Access and set the private 'stackSize' field to 1
        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        stackSizeField.setInt(reader, 1);

        // Access and set the private 'pathNames' field
        Field pathNamesField = JsonReader.class.getDeclaredField("pathNames");
        pathNamesField.setAccessible(true);
        pathNamesField.set(reader, new String[]{"object"});

        // Access and set the private 'pos' field
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        posField.setInt(reader, 1); // Position after '{'

        // Invoke skipValue()
        reader.skipValue();

        // Access and verify 'peeked' is reset to PEEKED_NONE
        int expectedPeeked = 0; // PEEKED_NONE
        int actualPeeked = peekedField.getInt(reader);
        assertEquals(expectedPeeked, actualPeeked, "peeked should be reset to PEEKED_NONE after skipping BEGIN_OBJECT");
    }
}
