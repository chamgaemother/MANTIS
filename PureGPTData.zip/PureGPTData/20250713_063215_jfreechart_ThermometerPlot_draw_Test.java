import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.ThermometerPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;

import static org.junit.jupiter.api.Assertions.*;

class ThermometerPlotTest {

    @Test
    void testDrawWithValidParameters() {
        ThermometerPlot plot = new ThermometerPlot(new DefaultValueDataset(50.0));
        plot.setRange(0.0, 100.0);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0, 50, 0, 50);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50, 75, 50, 75);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75, 100, 75, 100);

        Graphics2D g2 = new BufferedImage(200, 400, BufferedImage.TYPE_INT_RGB).createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 400);
        Point2D anchor = new Point2D.Double(100, 200);

        plot.draw(g2, area, anchor, new PlotState(), new PlotRenderingInfo(null));

        // Assertions can be added here to verify certain drawing conditions if needed
    }

    @Test
    void testDrawWithNoDatasetValue() {
        ThermometerPlot plot = new ThermometerPlot();
        plot.setRange(0.0, 100.0);

        Graphics2D g2 = new BufferedImage(200, 400, BufferedImage.TYPE_INT_RGB).createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 400);

        plot.draw(g2, area, null, new PlotState(), new PlotRenderingInfo(null));
    }

    @Test
    void testDrawWithNullDataset() {
        ThermometerPlot plot = new ThermometerPlot(null);

        Graphics2D g2 = new BufferedImage(200, 400, BufferedImage.TYPE_INT_RGB).createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 400);

        plot.draw(g2, area, null, new PlotState(), new PlotRenderingInfo(null));
    }

    @Test
    void testDrawWithDifferentSubranges() {
        ThermometerPlot plot = new ThermometerPlot(new DefaultValueDataset(80.0));
        
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0, 50, 0, 50);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50, 75, 50, 75);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75, 100, 75, 100);

        Graphics2D g2 = new BufferedImage(200, 400, BufferedImage.TYPE_INT_RGB).createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 400);

        plot.draw(g2, area, null, new PlotState(), new PlotRenderingInfo(null));

        // Assertions for mercury color changes could be added if needed based on subrange
    }

    @Test
    void testDrawWithCustomAxis() {
        ValueDataset dataset = new DefaultValueDataset(20.0);
        ThermometerPlot plot = new ThermometerPlot(dataset);
        NumberAxis customAxis = new NumberAxis("Custom Axis");
        plot.setRangeAxis(customAxis);

        Graphics2D g2 = new BufferedImage(200, 400, BufferedImage.TYPE_INT_RGB).createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 400);

        plot.draw(g2, area, null, new PlotState(), new PlotRenderingInfo(null));

        // Additional assertions for custom axis could be added here
    }
    
    @Test
    void testDrawWithPadding() {
        ThermometerPlot plot = new ThermometerPlot(new DefaultValueDataset(50.0));
        plot.setPadding(new RectangleInsets(10, 10, 10, 10));

        Graphics2D g2 = new BufferedImage(200, 400, BufferedImage.TYPE_INT_RGB).createGraphics();
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 400);

        plot.draw(g2, area, null, new PlotState(), new PlotRenderingInfo(null));
    }
}