package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class Flat3Map_put_0_1_Test {

    @Test
    @DisplayName("Delegate map is not null, key is added to delegate map")
    void testDelegateMapNotNull() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Map<Object, Object> delegateMap = new HashMap<>();
        
        // Using reflection to access the private field 'delegateMap'
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegateMap);

        Object key = new Object();
        Object value = new Object();

        Object result = map.put(key, value);

        assertTrue(delegateMap.containsKey(key), "Key should be present in the delegate map");
        assertNull(result, "Result should be null as no previous value exists.");
    }

    @Test
    @DisplayName("Existing null key replaced in triple-case map without delegate")
    void testReplaceNullKey() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        
        // Using reflection to set private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        
        sizeField.setAccessible(true);
        key3Field.setAccessible(true);
        value3Field.setAccessible(true);
        
        sizeField.set(map, 3);
        key3Field.set(map, null);
        Object value = new Object();
        value3Field.set(map, value);

        Object newValue = new Object();
        Object result = map.put(null, newValue);

        assertEquals(value, result, "Returned value should be the old value for null key");
        assertEquals(newValue, value3Field.get(map), "The value for null key should be updated to the new value");
    }

    @Test
    @DisplayName("Existing key1 in map is replaced without delegate")
    void testReplaceKey1() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        Field value1Field = Flat3Map.class.getDeclaredField("value1");

        sizeField.setAccessible(true);
        key1Field.setAccessible(true);
        hash1Field.setAccessible(true);
        value1Field.setAccessible(true);

        sizeField.set(map, 1);
        Object key = new Object();
        Object value = new Object();
        key1Field.set(map, key);
        hash1Field.set(map, key.hashCode());
        value1Field.set(map, value);

        Object newValue = new Object();
        Object result = map.put(key, newValue);

        assertEquals(value, result, "Returned value should be the old value for key1");
        assertEquals(newValue, value1Field.get(map), "The value for key1 should be updated to the new value");
    }

    @Test
    @DisplayName("New key is added to empty map without delegate")
    void testAddToEmptyMap() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set the size field
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 0);

        Object key = new Object();
        Object value = new Object();

        Object result = map.put(key, value);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        key1Field.setAccessible(true);
        value1Field.setAccessible(true);

        assertEquals(key, key1Field.get(map), "Key should be added at position 1");
        assertEquals(value, value1Field.get(map), "Value should be added at position 1");
        assertNull(result, "Result should be null as the map was initially empty");
    }

    @Test
    @DisplayName("New key added, triggers conversion to delegate")
    void testConversionToDelegate() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set the size field
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        Object key4 = new Object();
        Object value4 = new Object();

        Object result = map.put(key4, value4);

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        Map<?, ?> delegateMap = (Map<?, ?>) delegateMapField.get(map);

        assertNotNull(delegateMap, "Delegate map should not be null after conversion");
        assertEquals(value4, delegateMap.get(key4), "Delegate map should contain the new key-value pair");
        assertNull(result, "Result should be null after conversion");
    }
}