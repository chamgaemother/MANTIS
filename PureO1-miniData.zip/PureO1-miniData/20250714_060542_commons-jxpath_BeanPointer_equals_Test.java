package org.apache.commons.jxpath.ri.model.beans;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.apache.commons.jxpath.JXPathBeanInfo;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Locale;

class BeanPointerTest {

    @Test
    void testEqualsSameInstance() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer = new BeanPointer(parent, qName, "bean", beanInfo);
        assertTrue(pointer.equals(pointer));
    }

    @Test
    void testEqualsNull() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer = new BeanPointer(parent, qName, "bean", beanInfo);
        assertFalse(pointer.equals(null));
    }

    @Test
    void testEqualsDifferentClass() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer = new BeanPointer(parent, qName, "bean", beanInfo);
        String other = "Not a BeanPointer";
        assertFalse(pointer.equals(other));
    }

    @Test
    void testEqualsDifferentParentBothNull() {
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(null, qName, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(null, qName, "bean", beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsDifferentParentOneNull() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(null, qName, "bean", beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsDifferentParentNotEqual() {
        NodePointer parent1 = mock(NodePointer.class);
        NodePointer parent2 = mock(NodePointer.class);
        when(parent1.equals(parent2)).thenReturn(false);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent1, qName, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent2, qName, "bean", beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsSameParent() {
        NodePointer parent = mock(NodePointer.class);
        when(parent.equals(parent)).thenReturn(true);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, "bean", beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsQNameBothNull() {
        NodePointer parent = mock(NodePointer.class);
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, null, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, null, "bean", beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsQNameOneNull() {
        NodePointer parent = mock(NodePointer.class);
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, null, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, new QName("test"), "bean", beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsQNameDifferent() {
        NodePointer parent = mock(NodePointer.class);
        QName qName1 = new QName("test1");
        QName qName2 = new QName("test2");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName1, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName2, "bean", beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsQNameEqual() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, "bean", beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, new QName("test"), "bean", beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsDifferentIndexWholeCollection() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, "bean", beanInfo);
        pointer1.setIndex(NodePointer.WHOLE_COLLECTION);
        BeanPointer pointer2 = new BeanPointer(parent, qName, "bean", beanInfo);
        pointer2.setIndex(0);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsDifferentIndexNotWholeCollection() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, "bean", beanInfo);
        pointer1.setIndex(1);
        BeanPointer pointer2 = new BeanPointer(parent, qName, "bean", beanInfo);
        pointer2.setIndex(2);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsSameIndex() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, "bean", beanInfo);
        pointer1.setIndex(1);
        BeanPointer pointer2 = new BeanPointer(parent, qName, "bean", beanInfo);
        pointer2.setIndex(1);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanNumberEqual() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        Number bean = 123;
        BeanPointer pointer1 = new BeanPointer(parent, qName, bean, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, 123, beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanNumberNotEqual() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, 123, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, 456, beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanStringEqual() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        String bean = "testBean";
        BeanPointer pointer1 = new BeanPointer(parent, qName, bean, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, "testBean", beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanStringNotEqual() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, "bean1", beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, "bean2", beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanBooleanEqual() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        Boolean bean = true;
        BeanPointer pointer1 = new BeanPointer(parent, qName, bean, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, Boolean.TRUE, beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanBooleanNotEqual() {
        NodePointer parent = mock(NodePointer.class);
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, true, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, false, beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanObjectSameInstance() {
        NodePointer parent = mock(NodePointer.class);
        Object bean = new Object();
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, bean, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, bean, beanInfo);
        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEqualsBeanObjectDifferentInstances() {
        NodePointer parent = mock(NodePointer.class);
        Object bean1 = new Object();
        Object bean2 = new Object();
        QName qName = new QName("test");
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);
        BeanPointer pointer1 = new BeanPointer(parent, qName, bean1, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent, qName, bean2, beanInfo);
        assertFalse(pointer1.equals(pointer2));
    }
}