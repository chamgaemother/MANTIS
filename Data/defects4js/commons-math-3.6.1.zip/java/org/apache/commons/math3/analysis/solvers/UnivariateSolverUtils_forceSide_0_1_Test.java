package org.apache.commons.math3.analysis.solvers;
import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class UnivariateSolverUtils_forceSide_0_1_Test {

    @Test
    @DisplayName("allowedSolution is ANY_SIDE, method returns baseRoot without further computation")
    void TC01() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
        int maxEval = 10;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        assertEquals(baseRoot, result, "The result should be equal to baseRoot when AllowedSolution is ANY_SIDE.");
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE and fLo and fHi are on opposite sides, bracketing.solve is called")
    void TC02() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 10;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        when(bracketing.solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(2.0), eq(allowedSolution))).thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        assertEquals(2.0, result, "The result should be the value returned by bracketing.solve.");
        verify(bracketing, times(1)).solve(eq(maxEval - 2), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE and fLo and fHi are not on opposite sides, throws NoBracketingException")
    void TC03() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
        int maxEval = 2;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN & THEN
        assertThrows(NoBracketingException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        }, "Expected NoBracketingException to be thrown when fLo and fHi have the same sign.");
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop iterates once and successfully brackets")
    void TC04() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 4;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        when(bracketing.solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(2.0), eq(allowedSolution))).thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        assertEquals(2.0, result, "The result should be the value returned by bracketing.solve after one iteration.");
        verify(bracketing, times(1)).solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop exhausts maxEval without finding bracketing, throws NoBracketingException")
    void TC05() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
        int maxEval = 6;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver<UnivariateFunction> bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN & THEN
        assertThrows(NoBracketingException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        }, "Expected NoBracketingException to be thrown after maxEval is exhausted without bracketing.");
    }
}