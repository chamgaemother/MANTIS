package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.DoubleMetaphone;

public class DoubleMetaphone_doubleMetaphone_0_4_Test {

    @Test
    @DisplayName("doubleMetaphone(\"ZZZZ\", false) handles double 'Z'")
    public void TC16_doubleMetaphone_double_Z() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "ZZZZ";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertTrue(result.equals("S") || result.equals("TS"), "Expected 'S' or 'TS'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"SCHOLAR\", false) handles 'SC' combination")
    public void TC17_doubleMetaphone_SC_combination() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "SCHOLAR";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertTrue(result.equals("SK") || result.equals("X"), "Expected 'SK' or 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"TION\", false) handles 'TION' ending")
    public void TC18_doubleMetaphone_TION_ending() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "TION";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertEquals("X", result, "Expected 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"THOMAS\", false) handles 'TH' combination with special cases")
    public void TC19_doubleMetaphone_TH_combination_special_case() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "THOMAS";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertTrue(result.equals("0") || result.equals("T"), "Expected '0' or 'T'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"WRONG\", false) handles silent prefix 'WR'")
    public void TC20_doubleMetaphone_silent_prefix_WR() {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "WRONG";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertEquals("R", result, "Expected 'R'");
    }

}