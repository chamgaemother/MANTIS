package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.Metaphone;

public class Metaphone_metaphone_0_1_Test {

    @Test
    @DisplayName("metaphone(null) returns empty string")
    public void TC01_metaphone_null_returns_empty_string() {
        Metaphone metaphone = new Metaphone();
        String input = null;
        String result = metaphone.metaphone(input);
        assertEquals("", result);
    }

    @Test
    @DisplayName("metaphone(\"\") returns empty string")
    public void TC02_metaphone_empty_string_returns_empty_string() {
        Metaphone metaphone = new Metaphone();
        String input = "";
        String result = metaphone.metaphone(input);
        assertEquals("", result);
    }

    @Test
    @DisplayName("metaphone single character 'a' returns 'A'")
    public void TC03_metaphone_single_character_a_returns_A() {
        Metaphone metaphone = new Metaphone();
        String input = "a";
        String result = metaphone.metaphone(input);
        assertEquals("A", result);
    }

    @Test
    @DisplayName("metaphone(\"knight\") processes initial 'kn' correctly")
    public void TC04_metaphone_knight_initial_kn() {
        Metaphone metaphone = new Metaphone();
        String input = "knight";
        String result = metaphone.metaphone(input);
        assertEquals("N0T", result);
    }

    @Test
    @DisplayName("metaphone(\"aeon\") processes initial 'ae' correctly")
    public void TC05_metaphone_aeon_initial_ae() {
        Metaphone metaphone = new Metaphone();
        String input = "aeon";
        String result = metaphone.metaphone(input);
        assertEquals("ON", result);
    }

}