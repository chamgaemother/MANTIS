import org.apache.commons.jxpath.util.ValueUtils;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ValueUtilsTest {

    @Test
    void testNullCollection() {
        Object result = ValueUtils.getValue(null, 0);
        assertNull(result);
    }

    @Test
    void testEmptyArray() {
        Object[] array = new Object[0];
        Object result = ValueUtils.getValue(array, 0);
        assertNull(result);
    }

    @Test
    void testValidArrayIndex() {
        Integer[] array = new Integer[]{1, 2, 3};
        Object result = ValueUtils.getValue(array, 1);
        assertEquals(2, result);
    }

    @Test
    void testInvalidArrayIndex() {
        Integer[] array = new Integer[]{1, 2, 3};
        Object result = ValueUtils.getValue(array, -1);
        assertNull(result);
        
        result = ValueUtils.getValue(array, 3);
        assertNull(result);
    }

    @Test
    void testEmptyList() {
        List<Object> list = new ArrayList<>();
        Object result = ValueUtils.getValue(list, 0);
        assertNull(result);
    }

    @Test
    void testValidListIndex() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        Object result = ValueUtils.getValue(list, 1);
        assertEquals(2, result);
    }

    @Test
    void testInvalidListIndex() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        Object result = ValueUtils.getValue(list, -1);
        assertNull(result);

        result = ValueUtils.getValue(list, 3);
        assertNull(result);
    }

    @Test
    void testNonCollectionObject() {
        String nonCollection = "test string";
        Object result = ValueUtils.getValue(nonCollection, 0);
        assertEquals(nonCollection, result);
        
        result = ValueUtils.getValue(nonCollection, 1);
        assertEquals(nonCollection, result);
    }
}