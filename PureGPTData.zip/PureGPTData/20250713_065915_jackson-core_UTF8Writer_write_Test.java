import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.UTF8Writer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

class UTF8WriterTest {

    private IOContext context;
    private ByteArrayOutputStream outputStream;
    private UTF8Writer writer;

    @BeforeEach
    void setUp() {
        context = Mockito.mock(IOContext.class);
        outputStream = new ByteArrayOutputStream();
        when(context.allocWriteEncodingBuffer()).thenReturn(new byte[512]);
        writer = new UTF8Writer(context, outputStream);
    }

    @Test
    void testWriteNullString() throws IOException {        
        assertThrows(NullPointerException.class, () -> writer.write((String) null, 0, 0));
    }

    @Test
    void testWriteEmptyString() throws IOException {
        writer.write("", 0, 0);
    }

    @Test
    void testWriteSingleAsciiCharacter() throws IOException {
        writer.write("A", 0, 1);
    }

    @Test
    void testWriteMultipleAsciiCharacters() throws IOException {
        writer.write("Hello", 0, 5);
    }

    @Test
    void testWriteSingleNonAsciiCharacter() throws IOException {
        writer.write("é", 0, 1);
    }

    @Test
    void testWriteMultipleNonAsciiCharacters() throws IOException {
        writer.write("éèê", 0, 3);
    }

    @Test
    void testWriteBoundaryAsciiNonAsciiTransition() throws IOException {
        writer.write("aé", 0, 2);
    }

    @Test
    void testWriteSingleValidSurrogatePair() throws IOException {
        String surrogatePair = new String(Character.toChars(0x1D11E));
        writer.write(surrogatePair, 0, 2);
    }

    @Test
    void testWriteUnmatchedFirstSurrogate() {
        assertThrows(IOException.class, () -> writer.write("\uD800", 0, 1));
    }

    @Test
    void testWriteUnmatchedSecondSurrogate() {
        assertThrows(IOException.class, () -> writer.write("\uDC00", 0, 1));
    }

    @Test
    void testWriteInvalidUnicodeCodepoint() {
        assertThrows(IOException.class, () -> writer.write(new String(Character.toChars(0x110000)), 0, 2));
    }
}