package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.util.Decimal64;
import org.apache.commons.math3.util.Decimal64Field;
import org.apache.commons.math3.Field;
import org.apache.commons.math3.ode.FieldExpandableODE;
import org.apache.commons.math3.ode.FieldODEState;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AdamsMoultonFieldIntegrator_integrate_0_1_Test {
//
//    // Simple ODE: dy/dt = y, with solution y(t) = y0 * e^(t - t0)
//    private static class SimpleFieldODE implements FieldExpandableODE<Decimal64> {
//        @Override
//        public Decimal64[] computeDerivatives(Decimal64 t, Decimal64[] y) {
//            Decimal64[] yDot = y.clone();
//            for (int i = 0; i < yDot.length; i++) {
//                yDot[i] = yDot[i]; // dy/dt = y
//            }
//            return yDot;
//        }
//    }
//
//    @Test
//    @DisplayName("Integrate with finalTime > initialTime to perform forward integration")
//    void TC01() throws Exception {
//        // GIVEN
//        Field<Decimal64> field = Decimal64Field.getInstance();
//        SimpleFieldODE equations = new SimpleFieldODE();
//        Decimal64 initialTime = field.getZero();
//        Decimal64 initialValue = field.getOne();
//        Decimal64[] y = new Decimal64[]{initialValue};
//        FieldODEState<Decimal64> initialState = new FieldODEState<>(initialTime, y);
//        Decimal64 finalTime = field.getOne();
//
//        AdamsMoultonFieldIntegrator<Decimal64> integrator = new AdamsMoultonFieldIntegrator<>(field, 4, 0.001, 1.0, 1.0e-10, 1.0e-10);
//
//        // WHEN
//        FieldODEStateAndDerivative<Decimal64> result = integrator.integrate(equations, initialState, finalTime);
//
//        // THEN
//        assertEquals(finalTime.getReal(), result.getTime().getReal(), 1.0e-8);
//        double expected = Math.exp(1.0); // e^1
//        assertEquals(expected, result.getPrimaryState()[0].getReal(), 1.0e-6);
//    }
//
//    @Test
//    @DisplayName("Integrate with finalTime < initialTime to perform backward integration")
//    void TC02() throws Exception {
//        // GIVEN
//        Field<Decimal64> field = Decimal64Field.getInstance();
//        SimpleFieldODE equations = new SimpleFieldODE();
//        Decimal64 initialTime = field.getOne();
//        Decimal64 initialValue = new Decimal64(Math.exp(1.0));
//        Decimal64[] y = new Decimal64[]{initialValue};
//        FieldODEState<Decimal64> initialState = new FieldODEState<>(initialTime, y);
//        Decimal64 finalTime = field.getZero();
//
//        AdamsMoultonFieldIntegrator<Decimal64> integrator = new AdamsMoultonFieldIntegrator<>(field, 4, 0.001, 1.0, 1.0e-10, 1.0e-10);
//
//        // WHEN
//        FieldODEStateAndDerivative<Decimal64> result = integrator.integrate(equations, initialState, finalTime);
//
//        // THEN
//        assertEquals(finalTime.getReal(), result.getTime().getReal(), 1.0e-8);
//        double expected = 1.0; // y(0) = y0
//        assertEquals(expected, result.getPrimaryState()[0].getReal(), 1.0e-6);
//    }
//
//    @Test
//    @DisplayName("Integrate with finalTime equal to initial time resulting in immediate return")
//    void TC03() throws Exception {
//        // GIVEN
//        Field<Decimal64> field = Decimal64Field.getInstance();
//        SimpleFieldODE equations = new SimpleFieldODE();
//        Decimal64 initialTime = field.getZero();
//        Decimal64 initialValue = field.getOne();
//        Decimal64[] y = new Decimal64[]{initialValue};
//        FieldODEState<Decimal64> initialState = new FieldODEState<>(initialTime, y);
//        Decimal64 finalTime = initialTime;
//
//        AdamsMoultonFieldIntegrator<Decimal64> integrator = new AdamsMoultonFieldIntegrator<>(field, 4, 0.001, 1.0, 1.0e-10, 1.0e-10);
//
//        // WHEN
//        FieldODEStateAndDerivative<Decimal64> result = integrator.integrate(equations, initialState, finalTime);
//
//        // THEN
//        assertEquals(initialState.getTime().getReal(), result.getTime().getReal(), 1.0e-8);
//        assertArrayEquals(initialState.getPrimaryState(), result.getPrimaryState());
//    }
//
//    @Test
//    @DisplayName("Integrate with minimal step size to test boundary step scaling")
//    void TC04() throws Exception {
//        // GIVEN
//        Field<Decimal64> field = Decimal64Field.getInstance();
//        SimpleFieldODE equations = new SimpleFieldODE();
//        Decimal64 initialTime = field.getZero();
//        Decimal64 initialValue = field.getOne();
//        Decimal64[] y = new Decimal64[]{initialValue};
//        FieldODEState<Decimal64> initialState = new FieldODEState<>(initialTime, y);
//        Decimal64 finalTime = field.getOne();
//
//        double minStep = 1.0e-6;
//        AdamsMoultonFieldIntegrator<Decimal64> integrator = new AdamsMoultonFieldIntegrator<>(field, 4, minStep, 1.0, 1.0e-10, 1.0e-10);
//
//        // WHEN
//        FieldODEStateAndDerivative<Decimal64> result = integrator.integrate(equations, initialState, finalTime);
//
//        // THEN
//        assertTrue(minStep <= integrator.getStepSize().getReal(), "Step size is below the minimal step size");
//    }
//
//    @Test
//    @DisplayName("Integrate with maximal step size to test boundary step scaling")
//    void TC05() throws Exception {
//        // GIVEN
//        Field<Decimal64> field = Decimal64Field.getInstance();
//        SimpleFieldODE equations = new SimpleFieldODE();
//        Decimal64 initialTime = field.getZero();
//        Decimal64 initialValue = field.getOne();
//        Decimal64[] y = new Decimal64[]{initialValue};
//        FieldODEState<Decimal64> initialState = new FieldODEState<>(initialTime, y);
//        Decimal64 finalTime = new Decimal64(10.0);
//
//        double maxStep = 0.5;
//        AdamsMoultonFieldIntegrator<Decimal64> integrator = new AdamsMoultonFieldIntegrator<>(field, 4, 0.001, maxStep, 1.0e-10, 1.0e-10);
//
//        // WHEN
//        FieldODEStateAndDerivative<Decimal64> result = integrator.integrate(equations, initialState, finalTime);
//
//        // THEN
//        assertTrue(integrator.getStepSize().getReal() <= maxStep, "Step size exceeds the maximal step size");
//    }
}