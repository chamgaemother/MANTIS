package org.apache.commons.compress.archivers.cpio;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class CpioArchiveInputStreamTest {

    @Test
    void testGetNextCPIOEntry_StreamClosed_ThrowsIOException() throws IOException {
        InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(emptyStream);
        cpioIn.close();
        Executable executable = () -> cpioIn.getNextEntry();
        assertThrows(IOException.class, executable, "Stream closed");
    }

    @Test
    void testGetNextCPIOEntry_NoPreviousEntry_ReadOldBinaryEntryFalse() throws IOException {
        byte[] magic = CpioUtil.long2byteArray(CpioArchiveInputStream.MAGIC_OLD_BINARY, false, 2);
        byte[] entryData = new byte[magic.length];
        System.arraycopy(magic, 0, entryData, 0, magic.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        CpioArchiveEntry entry = cpioIn.getNextEntry();
        assertNotNull(entry);
        assertEquals(CpioArchiveInputStream.MAGIC_OLD_BINARY, CpioUtil.byteArray2long(magic, false));
    }

    @Test
    void testGetNextCPIOEntry_NoPreviousEntry_ReadOldBinaryEntryTrue() throws IOException {
        byte[] magic = CpioUtil.long2byteArray(CpioArchiveInputStream.MAGIC_OLD_BINARY, true, 2);
        byte[] entryData = new byte[magic.length];
        System.arraycopy(magic, 0, entryData, 0, magic.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        CpioArchiveEntry entry = cpioIn.getNextEntry();
        assertNotNull(entry);
        assertEquals(CpioArchiveInputStream.MAGIC_OLD_BINARY, CpioUtil.byteArray2long(magic, true));
    }

    @Test
    void testGetNextCPIOEntry_ReadNewEntry() throws IOException {
        String magic = CpioArchiveInputStream.MAGIC_NEW;
        byte[] magicBytes = ArchiveUtils.toAsciiBytes(magic);
        byte[] entryData = new byte[magicBytes.length + 8 * 13]; // Incomplete but for branch coverage
        System.arraycopy(magicBytes, 0, entryData, 0, magicBytes.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        Executable executable = () -> cpioIn.getNextEntry();
        assertThrows(IOException.class, executable);
    }

    @Test
    void testGetNextCPIOEntry_ReadNewEntryWithCRC() throws IOException {
        String magic = CpioArchiveInputStream.MAGIC_NEW_CRC;
        byte[] magicBytes = ArchiveUtils.toAsciiBytes(magic);
        byte[] entryData = new byte[magicBytes.length + 8 * 13];
        System.arraycopy(magicBytes, 0, entryData, 0, magicBytes.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        Executable executable = () -> cpioIn.getNextEntry();
        assertThrows(IOException.class, executable);
    }

    @Test
    void testGetNextCPIOEntry_ReadOldAsciiEntry() throws IOException {
        String magic = CpioArchiveInputStream.MAGIC_OLD_ASCII;
        byte[] magicBytes = ArchiveUtils.toAsciiBytes(magic);
        byte[] entryData = new byte[magicBytes.length + 11 * 10]; // Incomplete but for branch coverage
        System.arraycopy(magicBytes, 0, entryData, 0, magicBytes.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        Executable executable = () -> cpioIn.getNextEntry();
        assertThrows(IOException.class, executable);
    }

    @Test
    void testGetNextCPIOEntry_UnknownMagic_ThrowsIOException() throws IOException {
        byte[] unknownMagic = ArchiveUtils.toAsciiBytes("999999");
        byte[] entryData = new byte[unknownMagic.length + 4];
        System.arraycopy(unknownMagic, 0, entryData, 0, unknownMagic.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        Executable executable = () -> cpioIn.getNextEntry();
        IOException exception = assertThrows(IOException.class, executable);
        assertTrue(exception.getMessage().contains("Unknown magic"));
    }

    @Test
    void testGetNextCPIOEntry_TrailerEntry_ReturnsNull() throws IOException {
        String magic = CpioArchiveInputStream.MAGIC_NEW;
        String trailerName = CPIO_TRAILER;
        byte[] magicBytes = ArchiveUtils.toAsciiBytes(magic);
        byte[] nameBytes = ArchiveUtils.toAsciiBytes(trailerName + "\0");
        byte[] entryData = new byte[magicBytes.length + 8 * 13 + nameBytes.length];
        System.arraycopy(magicBytes, 0, entryData, 0, magicBytes.length);
        System.arraycopy(nameBytes, 0, entryData, magicBytes.length + 8 * 12, nameBytes.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        CpioArchiveEntry entry = cpioIn.getNextEntry();
        // Assuming readNewEntry correctly sets the name to trailer
        // Since readNewEntry is not implemented, we simulate the behavior
        // Hence, expecting IOException due to incomplete data
        assertThrows(IOException.class, () -> {
            if ("TRAILER!!!".equals(entry.getName())) {
                return;
            }
        });
    }

    @Test
    void testGetNextCPIOEntry_WithPreviousEntry_CloseEntryCalled() throws IOException {
        byte[] magic = CpioUtil.long2byteArray(CpioArchiveInputStream.MAGIC_OLD_BINARY, false, 2);
        byte[] entryData = new byte[magic.length * 2];
        System.arraycopy(magic, 0, entryData, 0, magic.length);
        System.arraycopy(magic, 0, entryData, magic.length, magic.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(entryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        CpioArchiveEntry firstEntry = cpioIn.getNextEntry();
        assertNotNull(firstEntry);
        CpioArchiveEntry secondEntry = cpioIn.getNextEntry();
        assertNotNull(secondEntry);
    }

    @Test
    void testGetNextCPIOEntry_EmptyStream_ReturnsNull() throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(new byte[0]);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        CpioArchiveEntry entry = cpioIn.getNextEntry();
        assertNull(entry);
    }

    @Test
    void testGetNextCPIOEntry_IncompleteMagic_ReadFullyThrowsEOFException() throws IOException {
        byte[] incompleteMagic = new byte[] {0x07};
        ByteArrayInputStream bais = new ByteArrayInputStream(incompleteMagic);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        Executable executable = () -> cpioIn.getNextEntry();
        assertThrows(EOFException.class, executable);
    }

    @Test
    void testGetNextCPIOEntry_InvalidEntryData_ThrowsIOException() throws IOException {
        byte[] magic = CpioUtil.long2byteArray(CpioArchiveInputStream.MAGIC_NEW, false, 2);
        byte[] invalidEntryData = new byte[magic.length + 1];
        System.arraycopy(magic, 0, invalidEntryData, 0, magic.length);
        invalidEntryData[magic.length] = 0x00;
        ByteArrayInputStream bais = new ByteArrayInputStream(invalidEntryData);
        CpioArchiveInputStream cpioIn = new CpioArchiveInputStream(bais);
        Executable executable = () -> cpioIn.getNextEntry();
        assertThrows(IOException.class, executable);
    }
}