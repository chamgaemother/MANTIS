import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.apache.commons.compress.harmony.pack200.ClassBands;
import org.apache.commons.compress.harmony.pack200.MetadataBandGroup;
import org.apache.commons.compress.harmony.pack200.Segment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class ClassBandsTest {

    @Mock
    private Segment mockSegment;
    @Mock
    private MetadataBandGroup mockClassRVABand;
    @Mock
    private MetadataBandGroup mockClassRIABand;

    private ClassBands classBands;

    @BeforeEach
    void setUp() throws Exception {
        when(mockSegment.getSegmentHeader()).thenReturn(null);
        classBands = new ClassBands(mockSegment, 1, 1, false);
    }

    @ParameterizedTest
    @CsvSource({
        "true, 2097152, 2097152",    // Visible annotation with RVA already set
        "false, 4194304, 4194304",   // Invisible annotation with RIA already set
        "true, 0, 2097152",          // Visible annotation with RVA not set
        "false, 0, 4194304"          // Invisible annotation with RIA not set
    })
    void testAddAnnotationClassContext(boolean visible, long initialFlags, long expectedFlags) {
        classBands.class_flags[0] = initialFlags;
        if (visible) {
            classBands.class_RVA_bands = mockClassRVABand;
        } else {
            classBands.class_RIA_bands = mockClassRIABand;
        }
        
        classBands.addAnnotation(MetadataBandGroup.CONTEXT_CLASS, "desc", visible, 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

        assertEquals(expectedFlags, classBands.class_flags[0]);
        if (visible) {
            verify(mockClassRVABand).addAnnotation(anyString(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList());
            if (initialFlags == 0) {
                verify(mockClassRVABand).newEntryInAnnoN();
            } else {
                verify(mockClassRVABand).incrementAnnoN();
            }
        } else {
            verify(mockClassRIABand).addAnnotation(anyString(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList());
            if (initialFlags == 0) {
                verify(mockClassRIABand).newEntryInAnnoN();
            } else {
                verify(mockClassRIABand).incrementAnnoN();
            }
        }
    }

    @Test
    void testAddAnnotationFieldContext_Visible() {
        classBands.tempFieldFlags.add(0L);
        classBands.field_RVA_bands = mockClassRVABand;

        classBands.addAnnotation(MetadataBandGroup.CONTEXT_FIELD, "desc", true, 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

        verify(mockClassRVABand).addAnnotation(anyString(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList());
        verify(mockClassRVABand).newEntryInAnnoN();
    }

    @Test
    void testAddAnnotationFieldContext_Invisible() {
        classBands.tempFieldFlags.add(0L);
        classBands.field_RIA_bands = mockClassRIABand;

        classBands.addAnnotation(MetadataBandGroup.CONTEXT_FIELD, "desc", false, 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

        verify(mockClassRIABand).addAnnotation(anyString(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList());
        verify(mockClassRIABand).newEntryInAnnoN();
    }

    @Test
    void testAddAnnotationMethodContext_Visible() {
        classBands.tempMethodFlags.add(0L);
        classBands.method_RVA_bands = mockClassRVABand;

        classBands.addAnnotation(MetadataBandGroup.CONTEXT_METHOD, "desc", true, 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

        verify(mockClassRVABand).addAnnotation(anyString(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList());
        verify(mockClassRVABand).newEntryInAnnoN();
    }

    @Test
    void testAddAnnotationMethodContext_Invisible() {
        classBands.tempMethodFlags.add(0L);
        classBands.method_RIA_bands = mockClassRIABand;

        classBands.addAnnotation(MetadataBandGroup.CONTEXT_METHOD, "desc", false, 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), 
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

        verify(mockClassRIABand).addAnnotation(anyString(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList(), anyList());
        verify(mockClassRIABand).newEntryInAnnoN();
    }
}