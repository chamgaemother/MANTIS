import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

class ConversionTest {

    @Test
    void testBinaryBeMsb0ToHexDigitValidInput() {
        assertEquals('f', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, true, true, true}, 0));
        assertEquals('e', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, true, true, false}, 0));
        assertEquals('d', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, true, false, true}, 0));
        assertEquals('c', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, true, false, false}, 0));
        assertEquals('b', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, false, true, true}, 0));
        assertEquals('a', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, false, true, false}, 0));
        assertEquals('9', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, false, false, true}, 0));
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{true, false, false, false}, 0));
        assertEquals('7', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, true, true, true}, 0));
        assertEquals('6', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, true, true, false}, 0));
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, true, false, true}, 0));
        assertEquals('4', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, true, false, false}, 0));
        assertEquals('3', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, false, true, true}, 0));
        assertEquals('2', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, false, true, false}, 0));
        assertEquals('1', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, false, false, true}, 0));
        assertEquals('0', Conversion.binaryBeMsb0ToHexDigit(new boolean[]{false, false, false, false}, 0));
    }

    @Test
    void testBinaryBeMsb0ToHexDigitWithSrcPos() {
        boolean[] src = {false, true, false, true, false, true, false, true};
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(src, 3));
        assertEquals('a', Conversion.binaryBeMsb0ToHexDigit(src, 1));
    }

    @Test
    void testBinaryBeMsb0ToHexDigitEmptyArray() {
        Executable executable = () -> Conversion.binaryBeMsb0ToHexDigit(new boolean[]{}, 0);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, executable);
        assertEquals("Cannot convert an empty array.", exception.getMessage());
    }

    @Test
    void testBinaryBeMsb0ToHexDigitNullInput() {
        Executable executable = () -> Conversion.binaryBeMsb0ToHexDigit(null, 0);
        assertThrows(NullPointerException.class, executable);
    }

    @Test
    void testBinaryBeMsb0ToHexDigitIndexOutOfBounds() {
        boolean[] src = {true, false, true, false};
        Executable executable = () -> Conversion.binaryBeMsb0ToHexDigit(src, 5);
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, executable);
        assertEquals("5 is not within array length 4", exception.getMessage());
    }
}