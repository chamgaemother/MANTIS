package org.jfree.data.general;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.jfree.data.Range;
import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DatasetUtils_findStackedRangeBounds_1_2_Test {

    @Test
    @DisplayName("findStackedRangeBounds with a single column and multiple rows")
    public void TC11_findStackedRangeBounds_singleColumn_multipleRows() {
        // Arrange
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(15.0, "Row1", "Column1");
        dataset.addValue(-5.0, "Row2", "Column1");
        dataset.addValue(25.0, "Row3", "Column1");
        dataset.addValue(-10.0, "Row4", "Column1");
        double base = 5.0;

        // Act
        Range result = DatasetUtils.findStackedRangeBounds(dataset, base);

        // Assert
        double expectedLower = base + (-15.0); // Correct the aggregated negative value calculation
        double expectedUpper = base + 40.0;   // Correct the aggregated positive values calculation
        assertEquals(expectedLower, result.getLowerBound(), "Lower bound should reflect aggregated negative values with base offset");
        assertEquals(expectedUpper, result.getUpperBound(), "Upper bound should reflect aggregated positive values with base offset");
    }

    @Test
    @DisplayName("findStackedRangeBounds with a single row and multiple columns")
    public void TC12_findStackedRangeBounds_singleRow_multipleColumns() {
        // Arrange
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(20.0, "Row1", "Column1");
        dataset.addValue(-10.0, "Row1", "Column2");
        dataset.addValue(30.0, "Row1", "Column3");
        dataset.addValue(-15.0, "Row1", "Column4");
        double base = -5.0;

        // Act
        Range result = DatasetUtils.findStackedRangeBounds(dataset, base);

        // Assert
        double expectedLower = base + (-25.0); // Correct aggregated negative calculation
        double expectedUpper = base + 50.0;   // Correct the aggregated positive values calculation
        assertEquals(expectedLower, result.getLowerBound(), "Lower bound should reflect aggregated negative values with base offset");
        assertEquals(expectedUpper, result.getUpperBound(), "Upper bound should reflect aggregated positive values with base offset");
    }

}
