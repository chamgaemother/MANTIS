package org.jfree.chart.block;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.data.Range;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;

import org.jfree.chart.ui.Size2D;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class BorderArrangement_arrange_0_1_Test {

    @Test
    @DisplayName("arrange with width and height constraints as NONE, expects arrangeNN to be called and returns correct Size2D")
    public void TC01() throws Exception {
        // Given
        BlockContainer container = mock(BlockContainer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        RectangleConstraint constraint = new RectangleConstraint(
                Double.NaN, null, 
                LengthConstraintType.NONE, 
                Double.NaN, null, 
                LengthConstraintType.NONE
        );

        BorderArrangement arrangement = new BorderArrangement();
        BorderArrangement spyArrangement = Mockito.spy(arrangement);

        Size2D expectedSize = new Size2D(100.0, 200.0);
        doReturn(expectedSize).when(spyArrangement).arrangeNN(container, g2);

        // When
        Size2D result = spyArrangement.arrange(container, g2, constraint);

        // Then
        verify(spyArrangement, times(1)).arrangeNN(container, g2);
        assertNotNull(result);
        assertEquals(100.0, result.getWidth(), 0.001);
        assertEquals(200.0, result.getHeight(), 0.001);
    }

    @Test
    @DisplayName("arrange with width=NONE and height=FIXED, expects RuntimeException to be thrown")
    public void TC02() throws Exception {
        // Given
        BlockContainer container = mock(BlockContainer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        RectangleConstraint constraint = new RectangleConstraint(
                Double.NaN, null, 
                LengthConstraintType.NONE, 
                100.0, null, 
                LengthConstraintType.FIXED
        );

        BorderArrangement arrangement = new BorderArrangement();

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            arrangement.arrange(container, g2, constraint);
        });
        assertEquals("Not implemented.", exception.getMessage());
    }

    @Test
    @DisplayName("arrange with width=NONE and height=RANGE, expects RuntimeException to be thrown")
    public void TC03() throws Exception {
        // Given
        BlockContainer container = mock(BlockContainer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        RectangleConstraint constraint = new RectangleConstraint(
                Double.NaN, null, 
                LengthConstraintType.NONE, 
                100.0, new Range(50.0, 150.0), 
                LengthConstraintType.RANGE
        );

        BorderArrangement arrangement = new BorderArrangement();

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            arrangement.arrange(container, g2, constraint);
        });
        assertEquals("Not implemented.", exception.getMessage());
    }

    @Test
    @DisplayName("arrange with width=FIXED and height=NONE, expects arrangeFN to be called and returns correct Size2D")
    public void TC04() throws Exception {
        // Given
        BlockContainer container = mock(BlockContainer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        RectangleConstraint constraint = new RectangleConstraint(
                100.0, null, 
                LengthConstraintType.FIXED, 
                Double.NaN, null, 
                LengthConstraintType.NONE
        );

        BorderArrangement arrangement = new BorderArrangement();
        BorderArrangement spyArrangement = Mockito.spy(arrangement);

        Size2D expectedSize = new Size2D(150.0, 250.0);
        doReturn(expectedSize).when(spyArrangement).arrangeFN(container, g2, constraint.getWidth());

        // When
        Size2D result = spyArrangement.arrange(container, g2, constraint);

        // Then
        verify(spyArrangement, times(1)).arrangeFN(container, g2, constraint.getWidth());
        assertNotNull(result);
        assertEquals(150.0, result.getWidth(), 0.001);
        assertEquals(250.0, result.getHeight(), 0.001);
    }

    @Test
    @DisplayName("arrange with width=FIXED and height=FIXED, expects arrangeFF to be called and returns correct Size2D")
    public void TC05() throws Exception {
        // Given
        BlockContainer container = mock(BlockContainer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        RectangleConstraint constraint = new RectangleConstraint(
                200.0, null, 
                LengthConstraintType.FIXED, 
                300.0, null, 
                LengthConstraintType.FIXED
        );

        BorderArrangement arrangement = new BorderArrangement();
        BorderArrangement spyArrangement = Mockito.spy(arrangement);

        Size2D expectedSize = new Size2D(200.0, 300.0);
        doReturn(expectedSize).when(spyArrangement).arrangeFF(container, g2, constraint);

        // When
        Size2D result = spyArrangement.arrange(container, g2, constraint);

        // Then
        verify(spyArrangement, times(1)).arrangeFF(container, g2, constraint);
        assertNotNull(result);
        assertEquals(200.0, result.getWidth(), 0.001);
        assertEquals(300.0, result.getHeight(), 0.001);
    }
}