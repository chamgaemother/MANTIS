import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import java.util.Comparator;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.direct.NelderMeadSimplex;

public class NelderMeadSimplexTest {

    private NelderMeadSimplex simplex;
    private MultivariateFunction mockFunction;
    private Comparator<PointValuePair> mockComparator;

    @BeforeEach
    public void setUp() {
        mockFunction = Mockito.mock(MultivariateFunction.class);
        mockComparator = Mockito.mock(Comparator.class);
    }

    @Test
    public void testBasicReflection() {
        double[][] referenceSimplex = { { 1.0, 1.0 }, { 2.0, 1.0 }, { 1.0, 2.0 } };
        simplex = new NelderMeadSimplex(referenceSimplex);

        Mockito.when(mockFunction.value(Mockito.any(double[].class))).thenReturn(3.0);
        Mockito.when(mockComparator.compare(Mockito.any(), Mockito.any())).thenReturn(-1, 1, -1);

        simplex.iterate(mockFunction, mockComparator);

        // Expecting a reflection
        Mockito.verify(mockComparator, Mockito.atLeastOnce())
                .compare(Mockito.any(PointValuePair.class), Mockito.any(PointValuePair.class));
    }

    @Test
    public void testExpansion() {
        double[][] referenceSimplex = { { 1.0, 1.0 }, { 2.0, 1.0 }, { 1.0, 2.0 } };
        simplex = new NelderMeadSimplex(referenceSimplex);

        Mockito.when(mockFunction.value(Mockito.any(double[].class))).thenReturn(4.0, 5.0);
        Mockito.when(mockComparator.compare(Mockito.any(), Mockito.any())).thenReturn(-1, -1, -1);

        simplex.iterate(mockFunction, mockComparator);

        // Expecting an expansion
        Mockito.verify(mockFunction, Mockito.atLeastOnce()).value(Mockito.any(double[].class));
    }

    @Test
    public void testOutsideContraction() {
        double[][] referenceSimplex = { { 1.0, 1.0 }, { 2.0, 1.0 }, { 1.0, 2.0 } };
        simplex = new NelderMeadSimplex(referenceSimplex);

        Mockito.when(mockFunction.value(Mockito.any(double[].class))).thenReturn(3.0);
        Mockito.when(mockComparator.compare(Mockito.any(), Mockito.any())).thenReturn(1, 1, -1, 0);

        simplex.iterate(mockFunction, mockComparator);

        // Expecting an outside contraction
        Mockito.verify(mockComparator, Mockito.atLeastOnce())
                .compare(Mockito.any(PointValuePair.class), Mockito.any(PointValuePair.class));
    }

    @Test
    public void testInsideContraction() {
        double[][] referenceSimplex = { { 1.0, 1.0 }, { 2.0, 1.0 }, { 1.0, 2.0 } };
        simplex = new NelderMeadSimplex(referenceSimplex);

        Mockito.when(mockFunction.value(Mockito.any(double[].class))).thenReturn(5.0);
        Mockito.when(mockComparator.compare(Mockito.any(), Mockito.any())).thenReturn(1, 1, 1, -1);

        simplex.iterate(mockFunction, mockComparator);

        // Expecting an inside contraction
        Mockito.verify(mockFunction, Mockito.atLeastOnce()).value(Mockito.any(double[].class));
    }

    @Test
    public void testShrink() {
        double[][] referenceSimplex = { { 1.0, 1.0 }, { 2.0, 1.0 }, { 1.0, 2.0 } };
        simplex = new NelderMeadSimplex(referenceSimplex);

        Mockito.when(mockFunction.value(Mockito.any(double[].class))).thenReturn(5.0);
        Mockito.when(mockComparator.compare(Mockito.any(), Mockito.any())).thenReturn(1, 1, 1, 1);

        simplex.iterate(mockFunction, mockComparator);

        // Verify shrink operation
        Mockito.verify(mockFunction, Mockito.atLeast(3)).value(Mockito.any(double[].class));
    }

    @Test
    public void testNullFunction() {
        double[][] referenceSimplex = { { 1.0, 1.0 }, { 2.0, 1.0 }, { 1.0, 2.0 } };
        simplex = new NelderMeadSimplex(referenceSimplex);
        assertThrows(NullPointerException.class, () -> {
            simplex.iterate(null, mockComparator);
        });
    }

    @Test
    public void testNullComparator() {
        double[][] referenceSimplex = { { 1.0, 1.0 }, { 2.0, 1.0 }, { 1.0, 2.0 } };
        simplex = new NelderMeadSimplex(referenceSimplex);
        assertThrows(NullPointerException.class, () -> {
            simplex.iterate(mockFunction, null);
        });
    }
}