package org.apache.commons.math3.stat.descriptive.rank;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class PSquarePercentileTest {

    @Test
    void testEqualsSameObject() {
        PSquarePercentile p = new PSquarePercentile(50);
        assertTrue(p.equals(p));
    }

    @Test
    void testEqualsNull() {
        PSquarePercentile p = new PSquarePercentile(50);
        assertFalse(p.equals(null));
    }

    @Test
    void testEqualsDifferentClass() {
        PSquarePercentile p = new PSquarePercentile(50);
        String other = "NotAPSquarePercentile";
        assertFalse(p.equals(other));
    }

    @Test
    void testEqualsBothMarkersNullAndSameN() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        assertTrue(p1.equals(p2));
    }

    @Test
    void testEqualsBothMarkersNullAndDifferentN() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        p1.increment(10);
        PSquarePercentile p2 = new PSquarePercentile(50);
        assertFalse(p1.equals(p2));
    }

    @Test
    void testEqualsOneMarkersNullOtherNotNull() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        // Add less than 5 observations to keep p2.markers null
        p1.increment(10);
        p1.increment(20);
        p1.increment(30);
        p1.increment(40);
        assertFalse(p1.equals(p2));

        // Now p1.markers is null, p2.markers not null
        PSquarePercentile p3 = new PSquarePercentile(50);
        p3.increment(10);
        p3.increment(20);
        p3.increment(30);
        p3.increment(40);
        p3.increment(50);
        assertFalse(p1.equals(p3));
    }

    @Test
    void testEqualsMarkersNotNullEqual() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        double[] data = {10, 20, 30, 40, 50, 60, 70};
        for (double d : data) {
            p1.increment(d);
            p2.increment(d);
        }
        assertTrue(p1.equals(p2));
    }

    @Test
    void testEqualsMarkersNotNullDifferentMarkers() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        double[] data1 = {10, 20, 30, 40, 50, 60, 70};
        double[] data2 = {10, 20, 30, 40, 50, 60, 80};
        for (double d : data1) {
            p1.increment(d);
        }
        for (double d : data2) {
            p2.increment(d);
        }
        assertFalse(p1.equals(p2));
    }

    @Test
    void testEqualsMarkersNotNullSameMarkersDifferentN() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        double[] data = {10, 20, 30, 40, 50, 60, 70};
        for (double d : data) {
            p1.increment(d);
            p2.increment(d);
        }
        // p1 has one more increment
        p1.increment(80);
        assertFalse(p1.equals(p2));
    }

    @Test
    void testEqualsMarkersNotNullDifferentMarkersSameN() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        double[] data1 = {10, 20, 30, 40, 50, 60, 70};
        double[] data2 = {10, 20, 30, 40, 50, 60, 75};
        for (double d : data1) {
            p1.increment(d);
        }
        for (double d : data2) {
            p2.increment(d);
        }
        assertFalse(p1.equals(p2));
    }
}