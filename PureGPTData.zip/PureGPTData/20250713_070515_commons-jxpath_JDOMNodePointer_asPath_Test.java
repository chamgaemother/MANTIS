import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.jdom.CDATA;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class JDOMNodePointerTest {
    
    private NodePointer parent;
    private JDOMNodePointer pointer;
    private NamespaceResolver nsResolver;
    
    @BeforeEach
    public void setup() {
        parent = mock(NodePointer.class);
        nsResolver = mock(NamespaceResolver.class);
        when(parent.asPath()).thenReturn("/parent");
        when(parent.getNamespaceResolver()).thenReturn(nsResolver);
    }

    @Test
    public void testAsPathWithId() {
        pointer = new JDOMNodePointer(null, new Element("test"), null, "testId");

        assertEquals("id('testId')", pointer.asPath());
    }

    @Test
    public void testAsPathWithElementWithNamespaceNoParent() {
        when(nsResolver.getPrefix("http://example.com")).thenReturn("ex");

        Element element = new Element("test", "ex", "http://example.com");
        pointer = new JDOMNodePointer(null, element, null);

        assertEquals("/ex:test[1]", pointer.asPath());
    }

    @Test
    public void testAsPathWithElementWithoutNamespace() {
        Element element = new Element("test");
        pointer = new JDOMNodePointer(parent, element, null);

        assertEquals("/parent/test[1]", pointer.asPath());
    }

    @Test
    public void testAsPathWithElementWithNamespace() {
        when(nsResolver.getPrefix("http://example.com")).thenReturn("ex");

        Element element = new Element("test", Namespace.getNamespace("ex", "http://example.com"));
        pointer = new JDOMNodePointer(parent, element, null);

        assertEquals("/parent/ex:test[1]", pointer.asPath());
    }

    @Test
    public void testAsPathWithTextNode() {
        Text textNode = new Text("sample text");
        pointer = new JDOMNodePointer(parent, textNode, null);

        assertEquals("/parent/text()[1]", pointer.asPath());
    }

    @Test
    public void testAsPathWithCDATA() {
        CDATA cdataNode = new CDATA("sample cdata");
        pointer = new JDOMNodePointer(parent, cdataNode, null);

        assertEquals("/parent/text()[1]", pointer.asPath());
    }

    @Test
    public void testAsPathWithProcessingInstruction() {
        ProcessingInstruction pi = new ProcessingInstruction("target");

        pointer = new JDOMNodePointer(parent, pi, null);

        assertEquals("/parent/processing-instruction('target')[1]", pointer.asPath());
    }
}