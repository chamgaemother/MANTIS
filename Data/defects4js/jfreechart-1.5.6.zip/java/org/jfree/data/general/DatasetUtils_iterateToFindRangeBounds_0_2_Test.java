package org.jfree.data.general;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;

public class DatasetUtils_iterateToFindRangeBounds_0_2_Test {

    @Test
    @DisplayName("Handles IntervalCategoryDataset with NaN start and end values")
    public void TC06_iterateToFindRangeBounds_IntervalDataset_withNaN() {
        // GIVEN
        IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getRowIndex("Series1")).thenReturn(0);
        when(dataset.getStartValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndValue(0, 0)).thenReturn(8.0);
        when(dataset.getStartValue(0, 1)).thenReturn(3.0);
        when(dataset.getEndValue(0, 1)).thenReturn(Double.NaN);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertEquals(new Range(3.0, 8.0), result);
    }

    @Test
    @DisplayName("Handles MultiValueCategoryDataset with no values")
    public void TC07_iterateToFindRangeBounds_MultiValueDataset_noValues() {
        // GIVEN
        MultiValueCategoryDataset dataset = mock(MultiValueCategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getRowIndex("Series1")).thenReturn(0);
        when(dataset.getValues(0, 0)).thenReturn(Collections.emptyList());
        when(dataset.getValues(0, 1)).thenReturn(Collections.emptyList());
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertNull(result);
    }

    @Test
    @DisplayName("Handles StatisticalCategoryDataset with null mean values")
    public void TC08_iterateToFindRangeBounds_StatisticalDataset_nullMeans() {
        // GIVEN
        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getRowIndex("Series1")).thenReturn(0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        when(dataset.getMeanValue(0, 1)).thenReturn(5.0);
        when(dataset.getStdDevValue(0, 1)).thenReturn(1.0);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertEquals(new Range(4.0, 6.0), result);
    }

    @Test
    @DisplayName("Handles StatisticalCategoryDataset with NaN standard deviation")
    public void TC09_iterateToFindRangeBounds_StatisticalDataset_NaNStdDev() {
        // GIVEN
        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowIndex("Series1")).thenReturn(0);
        when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
        when(dataset.getStdDevValue(0, 0)).thenReturn(Double.NaN);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertEquals(new Range(10.0, 10.0), result);
    }

    @Test
    @DisplayName("Returns null when no valid values are found across all datasets")
    public void TC10_iterateToFindRangeBounds_noValidValues() {
        // GIVEN
        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(1);
        when(dataset.getRowIndex("Series1")).thenReturn(0);
        when(dataset.getMeanValue(0, 0)).thenReturn(null);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertNull(result);
    }
}