package org.apache.commons.jxpath.functions;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.Function;
import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.apache.commons.jxpath.util.TypeUtils;
import org.apache.commons.jxpath.util.ValueUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

public class MethodFunction_invoke_0_2_Test {

    @Test
    @DisplayName("Static method with empty parameters array")
    void testTC06_StaticMethodWithEmptyParametersArray() throws Exception {
        // GIVEN
        Method staticMethod = MethodFunction.class.getDeclaredMethod("invoke", ExpressionContext.class, Object[].class);
        staticMethod.setAccessible(true);
        MethodFunction function = new MethodFunction(staticMethod);
        ExpressionContext context = null;  // Fix: Properly mock or create a valid ExpressionContext instance if required
        Object[] parameters = new Object[0];

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
    }

    @Test
    @DisplayName("Non-static method with multiple parameters without ExpressionContext")
    void testTC07_NonStaticMethodWithMultipleParametersWithoutExpressionContext() throws Exception {
        // GIVEN
        Method nonStaticMethod = MethodFunction.class.getDeclaredMethod("invoke", ExpressionContext.class, Object[].class);
        nonStaticMethod.setAccessible(true);
        MethodFunction function = new MethodFunction(nonStaticMethod);
        ExpressionContext context = null;  // Fix: Properly mock or create a valid ExpressionContext instance if required
        Object targetObject = new Object();
        Object param1 = "param1";
        Object param2 = "param2";
        Object param3 = "param3";
        Object[] parameters = {targetObject, param1, param2, param3};

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
    }

    @Test
    @DisplayName("Method with parameter type requiring TypeUtils.convert")
    void testTC08_MethodWithParameterTypeRequiringTypeUtilsConvert() throws Exception {
        // GIVEN
        Method staticMethodWithConversion = MethodFunction.class.getDeclaredMethod("invoke", ExpressionContext.class, Object[].class);
        staticMethodWithConversion.setAccessible(true);
        MethodFunction function = new MethodFunction(staticMethodWithConversion);
        ExpressionContext context = null;  // Fix: Properly mock or create a valid ExpressionContext instance if required
        Object rawParam1 = "rawParam1";
        Object rawParam2 = "rawParam2";
        Object[] parameters = {rawParam1, rawParam2};

        // WHEN
        Object result = function.invoke(context, parameters);

        // THEN
        assertNotNull(result, "Result should not be null");
    }

    @Test
    @DisplayName("Method.invoke throws InvocationTargetException handled properly")
    void testTC09_MethodInvokeThrowsInvocationTargetExceptionHandledProperly() throws Exception {
        // GIVEN
        Method failingMethod = MethodFunction.class.getDeclaredMethod("invoke", ExpressionContext.class, Object[].class);
        failingMethod.setAccessible(true);
        MethodFunction function = new MethodFunction(failingMethod);
        ExpressionContext context = null;  // Fix: Properly mock or create a valid ExpressionContext instance if required
        Object[] parameters = {"param1", "param2"};

        // WHEN
        Executable executable = () -> function.invoke(context, parameters);

        // THEN
        assertThrows(JXPathInvalidAccessException.class, executable, "Expected JXPathInvalidAccessException to be thrown");
    }

    @Test
    @DisplayName("Method.invoke throws non-InvocationTargetException Throwable")
    void testTC10_MethodInvokeThrowsNonInvocationTargetExceptionThrowable() throws Exception {
        // GIVEN
        Method failingMethod = MethodFunction.class.getDeclaredMethod("invoke", ExpressionContext.class, Object[].class);
        failingMethod.setAccessible(true);
        MethodFunction function = new MethodFunction(failingMethod);
        ExpressionContext context = null;  // Fix: Properly mock or create a valid ExpressionContext instance if required
        Object[] parameters = {"param1", "param2"};

        // WHEN
        Executable executable = () -> function.invoke(context, parameters);

        // THEN
        assertThrows(JXPathInvalidAccessException.class, executable, "Expected JXPathInvalidAccessException to be thrown");
    }
}