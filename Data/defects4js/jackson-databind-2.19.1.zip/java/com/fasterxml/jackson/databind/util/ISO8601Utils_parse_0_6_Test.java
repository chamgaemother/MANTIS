package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

public class ISO8601Utils_parse_0_6_Test {

    @Test
    @DisplayName("Parse throws ParseException for non-digit characters in time components")
    void TC26_parseThrowsParseExceptionForNonDigitTimeComponents() {
        String date = "2023-10-05T14:3A:00Z";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "Expected parse to throw ParseException for non-digit time components");

        assertTrue(exception.getMessage().contains("Invalid number format") || exception.getMessage().contains("Failed to parse date"));
    }

    @Test
    @DisplayName("Parse successfully parses date string with minimal required fields and UTC timezone")
    void TC27_parseMinimalDateWithUTCTimezone() throws ParseException {
        String date = "2023-10-05Z";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);

        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        expectedCalendar.setLenient(false);
        expectedCalendar.set(Calendar.YEAR, 2023);
        expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER);
        expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
        expectedCalendar.set(Calendar.HOUR_OF_DAY, 0);
        expectedCalendar.set(Calendar.MINUTE, 0);
        expectedCalendar.set(Calendar.SECOND, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();

        assertEquals(expectedDate, result, "Parsed date does not match expected date");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index mismatch");
    }

    @Test
    @DisplayName("Parse throws ParseException when milliseconds are non-numeric")
    void TC28_parseThrowsParseExceptionForNonNumericMilliseconds() {
        String date = "2023-10-05T14:30:00.1A3Z";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "Expected parse to throw ParseException for non-numeric milliseconds");

        assertTrue(exception.getMessage().contains("Invalid number format") || exception.getMessage().contains("Failed to parse date"));
    }

    @Test
    @DisplayName("Parse throws ParseException when timezone offset hour is missing")
    void TC29_parseThrowsParseExceptionForMissingTimezoneOffsetHour() {
        String date = "2023-10-05T14:30:00+";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "Expected parse to throw ParseException for missing timezone offset hour");

        assertTrue(exception.getMessage().contains("Invalid time zone indicator") || exception.getMessage().contains("Failed to parse date"));
    }

    @Test
    @DisplayName("Parse successfully parses date with timezone offset without minutes")
    void TC30_parseSuccessfullyWithTimezoneOffsetWithoutMinutes() throws ParseException {
        String date = "2023-10-05T14:30:00+02";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);

        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"));
        expectedCalendar.setLenient(false);
        expectedCalendar.set(Calendar.YEAR, 2023);
        expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER);
        expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
        expectedCalendar.set(Calendar.HOUR_OF_DAY, 14);
        expectedCalendar.set(Calendar.MINUTE, 30);
        expectedCalendar.set(Calendar.SECOND, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();

        assertEquals(expectedDate, result, "Parsed date does not match expected date with GMT+02:00 timezone");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index mismatch");
    }
}