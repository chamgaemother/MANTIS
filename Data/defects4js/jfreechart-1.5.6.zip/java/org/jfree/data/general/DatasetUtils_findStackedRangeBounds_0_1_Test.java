package org.jfree.data.general;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.KeyToGroupMap;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DatasetUtils_findStackedRangeBounds_0_1_Test {

    @Test
    @DisplayName("Throws IllegalArgumentException when dataset is null")
    void test_TC01_nullDataset_throwsException() {
        // GIVEN
        CategoryDataset dataset = null;
        KeyToGroupMap map = new KeyToGroupMap();

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.findStackedRangeBounds(dataset, map);
        });
    }

    @Test
    @DisplayName("Returns null when dataset has no rows")
    void test_TC02_emptyDataset_noRows() {
        // GIVEN
        CategoryDataset dataset = new DefaultCategoryDataset();
        KeyToGroupMap map = new KeyToGroupMap();

        // WHEN
        Range result = DatasetUtils.findStackedRangeBounds(dataset, map);

        // THEN
        assertNull(result, "Expected null when dataset has no rows");
    }

    @Test
    @DisplayName("Handles dataset with one row and one column with positive value")
    void test_TC03_singleEntryPositive() {
        // GIVEN
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10.0, "Row1", "Column1");
        KeyToGroupMap map = new KeyToGroupMap();
        map.mapKeyToGroup("Row1", "Group1");

        // WHEN
        Range result = DatasetUtils.findStackedRangeBounds(dataset, map);

        // THEN
        Range expected = new Range(0.0, 10.0);
        assertEquals(expected, result, "The range should be from 0.0 to 10.0");
    }

    @Test
    @DisplayName("Processes multiple rows and columns with mixed positive and negative values")
    void test_TC04_multipleEntriesMixedValues() {
        // GIVEN
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10.0, "Row1", "Column1");
        dataset.addValue(-5.0, "Row1", "Column2");
        dataset.addValue(15.0, "Row2", "Column1");
        dataset.addValue(-10.0, "Row2", "Column2");
        dataset.addValue(20.0, "Row3", "Column1");
        dataset.addValue(-15.0, "Row3", "Column2");

        KeyToGroupMap map = new KeyToGroupMap();
        map.mapKeyToGroup("Row1", "Group1");
        map.mapKeyToGroup("Row2", "Group1");
        map.mapKeyToGroup("Row3", "Group2");

        // WHEN
        Range result = DatasetUtils.findStackedRangeBounds(dataset, map);

        // THEN
        Range expected = new Range(-15.0, 25.0);
        assertEquals(expected, result, "The range should combine minimum -15.0 and maximum 25.0");
    }

    @Test
    @DisplayName("Handles dataset with all null values")
    void test_TC05_allNullValues() {
        // GIVEN
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(null, "Row1", "Column1");
        dataset.addValue(null, "Row1", "Column2");
        dataset.addValue(null, "Row2", "Column1");
        dataset.addValue(null, "Row2", "Column2");

        KeyToGroupMap map = new KeyToGroupMap();
        map.mapKeyToGroup("Row1", "Group1");
        map.mapKeyToGroup("Row2", "Group2");

        // WHEN
        Range result = DatasetUtils.findStackedRangeBounds(dataset, map);

        // THEN
        assertNull(result, "Expected null when all dataset values are null");
    }
}