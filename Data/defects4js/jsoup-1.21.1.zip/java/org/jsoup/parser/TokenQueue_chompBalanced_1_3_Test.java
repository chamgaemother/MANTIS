package org.jsoup.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TokenQueue_chompBalanced_1_3_Test {

    @Test
    @DisplayName("ChompBalanced with multiple nested different open and close characters handles correctly")
    public void TC34_ChompBalanced_with_multiple_nested_different_open_and_close_characters_handles_correctly() {
        // GIVEN
        TokenQueue queue = new TokenQueue("{{}{}}");

        // WHEN
        String result = queue.chompBalanced('{', '}');

        // THEN
        assertEquals("{{}{}}", result);
    }
}