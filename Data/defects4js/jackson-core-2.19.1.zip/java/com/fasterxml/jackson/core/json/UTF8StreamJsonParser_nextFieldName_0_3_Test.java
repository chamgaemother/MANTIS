package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonParseException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class UTF8StreamJsonParser_nextFieldName_0_3_Test {

    @Test
    @DisplayName("Parses a field name followed by a string value")
    void TC11_ParsesFieldNameWithStringValue() throws Exception {
        // Initialize parser with a field name followed by a string value
        JsonFactory factory = new JsonFactory();
        String json = "{\"expectedFieldName\": \"someStringValue\"}";
        JsonParser parser = factory.createParser(new ByteArrayInputStream(json.getBytes()));

        // Cast to UTF8StreamJsonParser
        UTF8StreamJsonParser utf8Parser = (UTF8StreamJsonParser) parser;

        String fieldName = utf8Parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);

        // Access _tokenIncomplete field via reflection
        Field tokenIncompleteField = UTF8StreamJsonParser.class.getDeclaredField("_tokenIncomplete");
        tokenIncompleteField.setAccessible(true);
        boolean tokenIncomplete = tokenIncompleteField.getBoolean(utf8Parser);
        assertTrue(tokenIncomplete);

        parser.close();
    }

    @Test
    @DisplayName("Parses a field name followed by a negative number")
    void TC12_ParsesFieldNameWithNegativeNumber() throws Exception {
        // Initialize parser with a field name followed by a negative number
        JsonFactory factory = new JsonFactory();
        String json = "{\"expectedFieldName\": -123}";
        JsonParser parser = factory.createParser(new ByteArrayInputStream(json.getBytes()));

        // Cast to UTF8StreamJsonParser
        UTF8StreamJsonParser utf8Parser = (UTF8StreamJsonParser) parser;

        String fieldName = utf8Parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);

        JsonToken nextToken = utf8Parser.getCurrentToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, nextToken);

        parser.close();
    }

    @Test
    @DisplayName("Parses a field name followed by a positive number with leading plus when feature is enabled")
    void TC13_ParsesFieldNameWithPositiveNumberAndLeadingPlus() throws Exception {
        // Initialize parser with feature ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS enabled
        JsonFactory factory = JsonFactory.builder()
                .enable(com.fasterxml.jackson.core.json.JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS)
                .build();
        String json = "{\"expectedFieldName\": +123}";
        JsonParser parser = factory.createParser(new ByteArrayInputStream(json.getBytes()));

        // Cast to UTF8StreamJsonParser
        UTF8StreamJsonParser utf8Parser = (UTF8StreamJsonParser) parser;

        String fieldName = utf8Parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);

        JsonToken nextToken = utf8Parser.getCurrentToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, nextToken);

        parser.close();
    }

    @Test
    @DisplayName("Handles unexpected '+' sign when feature is disabled")
    void TC14_HandlesUnexpectedPlusSignWhenFeatureDisabled() throws Exception {
        // Initialize parser with feature ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS disabled
        JsonFactory factory = JsonFactory.builder()
                .disable(com.fasterxml.jackson.core.json.JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS)
                .build();
        String json = "{\"expectedFieldName\": +123}";
        JsonParser parser = factory.createParser(new ByteArrayInputStream(json.getBytes()));

        // Cast to UTF8StreamJsonParser
        UTF8StreamJsonParser utf8Parser = (UTF8StreamJsonParser) parser;

        // Expect an exception when parsing the leading plus
        assertThrows(JsonParseException.class, () -> {
            utf8Parser.nextFieldName();
        });

        parser.close();
    }

    @Test
    @DisplayName("Parses a field name followed by a decimal number starting with a period")
    void TC15_ParsesFieldNameWithFloatStartingWithPeriod() throws Exception {
        // Initialize parser with feature ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS enabled
        JsonFactory factory = JsonFactory.builder()
                .enable(com.fasterxml.jackson.core.json.JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS)
                .build();
        String json = "{\"expectedFieldName\": .5}";
        JsonParser parser = factory.createParser(new ByteArrayInputStream(json.getBytes()));

        // Cast to UTF8StreamJsonParser
        UTF8StreamJsonParser utf8Parser = (UTF8StreamJsonParser) parser;

        String fieldName = utf8Parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);

        JsonToken nextToken = utf8Parser.getCurrentToken();
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, nextToken);

        parser.close();
    }
}