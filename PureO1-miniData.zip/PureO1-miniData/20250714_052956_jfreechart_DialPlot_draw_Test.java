import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import org.jfree.chart.plot.dial.DialFrame;
import org.jfree.chart.plot.dial.DialLayer;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

class DialPlotTest {

    private DialPlot plot;
    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotState parentState;
    private PlotRenderingInfo info;
    private DialFrame dialFrame;

    @BeforeEach
    void setUp() {
        plot = new DialPlot();
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 100, 100);
        anchor = null;
        parentState = null;
        info = null;
        dialFrame = mock(DialFrame.class);
        plot.setDialFrame(dialFrame);
    }

    @Test
    void testDrawWithNullBackgroundAndCap() {
        plot.setBackground(null);
        plot.setCap(null);
        plot.draw(g2, area, anchor, parentState, info);
        verify(dialFrame, atLeastOnce()).isVisible();
    }

    @Test
    void testDrawWithVisibleBackgroundNotClipped() {
        DialLayer background = mock(DialLayer.class);
        when(background.isVisible()).thenReturn(true);
        when(background.isClippedToWindow()).thenReturn(false);
        plot.setBackground(background);
        plot.draw(g2, area, anchor, parentState, info);
        verify(background).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
    }

    @Test
    void testDrawWithVisibleBackgroundClipped() {
        DialLayer background = mock(DialLayer.class);
        Shape window = mock(Shape.class);
        when(background.isVisible()).thenReturn(true);
        when(background.isClippedToWindow()).thenReturn(true);
        when(dialFrame.getWindow(any(Rectangle2D.class))).thenReturn(window);
        plot.setBackground(background);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).clip(window);
        verify(background).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
        verify(g2).setClip(any(Shape.class));
    }

    @Test
    void testDrawWithInvisibleBackground() {
        DialLayer background = mock(DialLayer.class);
        when(background.isVisible()).thenReturn(false);
        plot.setBackground(background);
        plot.draw(g2, area, anchor, parentState, info);
        verify(background, never()).draw(any(), any(), any(), any());
    }

    @Test
    void testDrawWithVisibleLayerNotClipped() {
        DialLayer layer = mock(DialLayer.class);
        when(layer.isVisible()).thenReturn(true);
        when(layer.isClippedToWindow()).thenReturn(false);
        plot.addLayer(layer);
        plot.draw(g2, area, anchor, parentState, info);
        verify(layer).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
    }

    @Test
    void testDrawWithVisibleLayerClipped() {
        DialLayer layer = mock(DialLayer.class);
        Shape window = mock(Shape.class);
        when(layer.isVisible()).thenReturn(true);
        when(layer.isClippedToWindow()).thenReturn(true);
        when(dialFrame.getWindow(any(Rectangle2D.class))).thenReturn(window);
        plot.addLayer(layer);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).clip(window);
        verify(layer).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
        verify(g2).setClip(any(Shape.class));
    }

    @Test
    void testDrawWithInvisibleLayer() {
        DialLayer layer = mock(DialLayer.class);
        when(layer.isVisible()).thenReturn(false);
        plot.addLayer(layer);
        plot.draw(g2, area, anchor, parentState, info);
        verify(layer, never()).draw(any(), any(), any(), any());
    }

    @Test
    void testDrawWithVisiblePointerNotClipped() {
        DialPointer pointer = mock(DialPointer.class);
        when(pointer.isVisible()).thenReturn(true);
        when(pointer.isClippedToWindow()).thenReturn(false);
        plot.addPointer(pointer);
        plot.draw(g2, area, anchor, parentState, info);
        verify(pointer).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
    }

    @Test
    void testDrawWithVisiblePointerClipped() {
        DialPointer pointer = mock(DialPointer.class);
        Shape window = mock(Shape.class);
        when(pointer.isVisible()).thenReturn(true);
        when(pointer.isClippedToWindow()).thenReturn(true);
        when(dialFrame.getWindow(any(Rectangle2D.class))).thenReturn(window);
        plot.addPointer(pointer);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).clip(window);
        verify(pointer).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
        verify(g2).setClip(any(Shape.class));
    }

    @Test
    void testDrawWithInvisiblePointer() {
        DialPointer pointer = mock(DialPointer.class);
        when(pointer.isVisible()).thenReturn(false);
        plot.addPointer(pointer);
        plot.draw(g2, area, anchor, parentState, info);
        verify(pointer, never()).draw(any(), any(), any(), any());
    }

    @Test
    void testDrawWithVisibleCapNotClipped() {
        DialLayer cap = mock(DialLayer.class);
        when(cap.isVisible()).thenReturn(true);
        when(cap.isClippedToWindow()).thenReturn(false);
        plot.setCap(cap);
        plot.draw(g2, area, anchor, parentState, info);
        verify(cap).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
    }

    @Test
    void testDrawWithVisibleCapClipped() {
        DialLayer cap = mock(DialLayer.class);
        Shape window = mock(Shape.class);
        when(cap.isVisible()).thenReturn(true);
        when(cap.isClippedToWindow()).thenReturn(true);
        when(dialFrame.getWindow(any(Rectangle2D.class))).thenReturn(window);
        plot.setCap(cap);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).clip(window);
        verify(cap).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
        verify(g2).setClip(any(Shape.class));
    }

    @Test
    void testDrawWithInvisibleCap() {
        DialLayer cap = mock(DialLayer.class);
        when(cap.isVisible()).thenReturn(false);
        plot.setCap(cap);
        plot.draw(g2, area, anchor, parentState, info);
        verify(cap, never()).draw(any(), any(), any(), any());
    }

    @Test
    void testDrawWithVisibleDialFrame() {
        when(dialFrame.isVisible()).thenReturn(true);
        plot.draw(g2, area, anchor, parentState, info);
        verify(dialFrame).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
    }

    @Test
    void testDrawWithInvisibleDialFrame() {
        when(dialFrame.isVisible()).thenReturn(false);
        plot.draw(g2, area, anchor, parentState, info);
        verify(dialFrame, never()).draw(any(), any(), any(), any());
    }

    @Test
    void testDrawWithNullGraphics2D() {
        try {
            plot.draw(null, area, anchor, parentState, info);
        } catch (NullPointerException e) {
            // Expected
        }
    }

    @Test
    void testDrawWithNullArea() {
        try {
            plot.draw(g2, null, anchor, parentState, info);
        } catch (NullPointerException e) {
            // Expected
        }
    }

    @Test
    void testDrawWithEmptyLayersAndPointers() {
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setClip(area);
        verify(g2).setClip(any(Shape.class));
    }

    @Test
    void testDrawWithMultipleVisibleLayersAndPointers() {
        DialLayer layer1 = mock(DialLayer.class);
        DialLayer layer2 = mock(DialLayer.class);
        DialPointer pointer1 = mock(DialPointer.class);
        DialPointer pointer2 = mock(DialPointer.class);

        when(layer1.isVisible()).thenReturn(true);
        when(layer1.isClippedToWindow()).thenReturn(false);

        when(layer2.isVisible()).thenReturn(true);
        when(layer2.isClippedToWindow()).thenReturn(true);
        Shape window = mock(Shape.class);
        when(dialFrame.getWindow(any(Rectangle2D.class))).thenReturn(window);

        when(pointer1.isVisible()).thenReturn(true);
        when(pointer1.isClippedToWindow()).thenReturn(false);

        when(pointer2.isVisible()).thenReturn(true);
        when(pointer2.isClippedToWindow()).thenReturn(true);

        plot.addLayer(layer1);
        plot.addLayer(layer2);
        plot.addPointer(pointer1);
        plot.addPointer(pointer2);

        plot.draw(g2, area, anchor, parentState, info);

        // Verify layer1
        verify(layer1).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));

        // Verify layer2 with clipping
        verify(g2).clip(window);
        verify(layer2).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
        verify(g2).setClip(any(Shape.class));

        // Verify pointer1
        verify(pointer1).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));

        // Verify pointer2 with clipping
        verify(g2).clip(window);
        verify(pointer2).draw(eq(g2), eq(plot), any(Rectangle2D.class), eq(area));
        verify(g2, times(2)).setClip(any(Shape.class));
    }

    @Test
    void testDrawWithNullAnchorParentStateInfo() {
        plot.draw(g2, area, null, null, null);
        verify(g2).setClip(area);
    }

    @Test
    void testDrawRestoresOriginalClip() {
        Shape originalClip = mock(Shape.class);
        when(g2.getClip()).thenReturn(originalClip);
        plot.draw(g2, area, anchor, parentState, info);
        verify(g2).setClip(originalClip);
    }
}