// package org.apache.commons.math3.distribution.fitting;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // 
// // import org.apache.commons.math3.distribution.MixtureMultivariateNormalDistribution;
// // import org.apache.commons.math3.exception.DimensionMismatchException;
// // import org.apache.commons.math3.exception.NotStrictlyPositiveException;
// // import org.apache.commons.math3.linear.SingularMatrixException;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import static org.junit.jupiter.api.Assertions.assertThrows;
// // 
// // /**
// //  * This test class contains tests for the 'fit' method of 
// //  * MultivariateNormalMixtureExpectationMaximization class.
// //  */
// public class MultivariateNormalMixtureExpectationMaximization_fit_1_1_Test {
// // 
// //     @Test
// //     @DisplayName("fit with colinear data points causes SingularMatrixException during covariance computation")
// //     void TC21_fitWithColinearDataPointsThrowsSingularMatrixException() {
//         // Arrange
// //         double[] weights = {0.5, 0.5};
// //         double[][] means = {
// //             {0.0, 0.0},
// //             {1.0, 1.0}
// //         };
// //         double[][][] covariances = {
// //             {
// //                 {1.0, 0.0},
// //                 {0.0, 1.0}
// //             },
// //             {
// //                 {1.0, 0.0},
// //                 {0.0, 1.0}
// //             }
// //         };
// //         MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
// //         double[][] data = {
// //             {0.0, 0.0},
// //             {1.0, 1.0},
// //             {2.0, 2.0},
// //             {3.0, 3.0} // Colinear points
// //         };
// //         MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);
// // 
//         // Act & Assert
// //         assertThrows(SingularMatrixException.class, () -> {
// //             optimizer.fit(initialMixture, 100, 1e-5);
// //         }, "Expected a SingularMatrixException to be thrown");
// //     }
// // 
// //     @Test
// //     @DisplayName("fit with initial mixture having zero components throws NotStrictlyPositiveException")
// //     void TC22_fitWithZeroComponentsInInitialMixtureThrowsNotStrictlyPositiveException() {
//         // Fixed: Initialize with at least one zero-length array to avoid DimensionMismatchException in MixtureMultivariateNormalDistribution constructor
// // 
//         // Arrange
// //         double[] weights = {0.0}; // Previously was empty
// //         double[][] means = {{}; // At least one sub-array required
// //         double[][][] covariances = {{{}}}; // Similar fix applied here
// //         MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
// //         double[][] data = {
// //             {1.0, 2.0},
// //             {3.0, 4.0}
// //         };
// //         MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);
// // 
//         // Act & Assert
// //         assertThrows(NotStrictlyPositiveException.class, () -> {
// //             optimizer.fit(initialMixture, 100, 1e-5);
// //         }, "Expected a NotStrictlyPositiveException to be thrown due to zero components in initial mixture");
// //     }
// // }
// }