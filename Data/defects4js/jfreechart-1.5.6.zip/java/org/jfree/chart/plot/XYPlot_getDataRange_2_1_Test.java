package org.jfree.chart.plot;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.Range;

public class XYPlot_getDataRange_2_1_Test {

    @Test
    @DisplayName("TC13: getDataRange returns null when all subplots' getDataRange(axis) return null")
    public void testGetDataRange_AllSubplotsReturnNull() throws Exception {
        // GIVEN
        // Create a CombinedDomainXYPlot with a NumberAxis
        ValueAxis domainAxis = new NumberAxis();
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(domainAxis);
        
        // Create subplots that return null for getDataRange(axis)
        XYPlot subplot1 = new XYPlot() {
            @Override
            public Range getDataRange(ValueAxis axis) {
                return null;
            }
        };
        XYPlot subplot2 = new XYPlot() {
            @Override
            public Range getDataRange(ValueAxis axis) {
                return null;
            }
        };
        
        // Add subplots to the combined plot
        combinedPlot.add(subplot1);
        combinedPlot.add(subplot2);
        
        // Create a ValueAxis to pass to getDataRange
        ValueAxis testAxis = new NumberAxis();
        
        // WHEN
        Range result = combinedPlot.getDataRange(testAxis);
        
        // THEN
        assertNull(result, "CombinedDomainXYPlot.getDataRange should return null when all subplots return null");
    }

    @Test
    @DisplayName("TC14: getDataRange returns null when multiple subplots all have getDataRange(axis) returning null")
    public void testGetDataRange_MultipleSubplotsAllReturnNull() throws Exception {
        // GIVEN
        // Create a CombinedDomainXYPlot with a NumberAxis
        ValueAxis domainAxis = new NumberAxis();
        CombinedDomainXYPlot combinedPlot = new CombinedDomainXYPlot(domainAxis);
        
        // Create three subplots that return null for getDataRange(axis)
        XYPlot subplot1 = new XYPlot() {
            @Override
            public Range getDataRange(ValueAxis axis) {
                return null;
            }
        };
        XYPlot subplot2 = new XYPlot() {
            @Override
            public Range getDataRange(ValueAxis axis) {
                return null;
            }
        };
        XYPlot subplot3 = new XYPlot() {
            @Override
            public Range getDataRange(ValueAxis axis) {
                return null;
            }
        };
        
        // Add subplots to the combined plot
        combinedPlot.add(subplot1);
        combinedPlot.add(subplot2);
        combinedPlot.add(subplot3);
        
        // Create a ValueAxis to pass to getDataRange
        ValueAxis testAxis = new NumberAxis();
        
        // WHEN
        Range result = combinedPlot.getDataRange(testAxis);
        
        // THEN
        assertNull(result, "CombinedDomainXYPlot.getDataRange should return null when all multiple subplots return null");
    }
}