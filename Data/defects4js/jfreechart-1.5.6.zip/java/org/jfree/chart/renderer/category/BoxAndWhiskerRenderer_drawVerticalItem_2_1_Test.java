// package org.jfree.chart.renderer.category;
// 
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyDouble;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.spy;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;
// 
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// import java.util.Arrays;
// import java.util.Collections;
// import java.util.List;
// 
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.renderer.category.CategoryItemRendererState;
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.data.category.CategoryDataset;
// import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// public class BoxAndWhiskerRenderer_drawVerticalItem_2_1_Test {
// 
//     @Test
//     @DisplayName("drawVerticalItem returns early when item is not visible")
//     void TC06_drawVerticalItem_itemNotVisible() {
//         // GIVEN
//         BoxAndWhiskerRenderer renderer = spy(new BoxAndWhiskerRenderer());
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = Mockito.mock(CategoryPlot.class);
//         CategoryAxis domainAxis = Mockito.mock(CategoryAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         CategoryDataset dataset = Mockito.mock(CategoryDataset.class);
//         
//         int row = 0;
//         int column = 0;
//         
//         when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(false);
//         
//         // WHEN
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
//         
//         // THEN
//         verify(g2, never()).draw(any());
//         verify(g2, never()).fill(any());
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem throws IllegalArgumentException when dataset is invalid")
//     void TC07_drawVerticalItem_invalidDatasetThrowsException() {
//         // GIVEN
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = Mockito.mock(CategoryPlot.class);
//         CategoryAxis domainAxis = Mockito.mock(CategoryAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         CategoryDataset invalidDataset = Mockito.mock(CategoryDataset.class);
//         
//         when(plot.getDataset(anyInt())).thenReturn(invalidDataset);
//         
//         int row = 0;
//         int column = 0;
//         
//         // WHEN & THEN
//         assertThrows(IllegalArgumentException.class, () -> {
//             renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, invalidDataset, row, column);
//         });
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem skips mean drawing when meanVisible is true but meanValue is null")
//     void TC08_drawVerticalItem_meanVisibleTrueButMeanValueNull() {
//         // GIVEN
//         BoxAndWhiskerRenderer renderer = spy(new BoxAndWhiskerRenderer());
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = Mockito.mock(CategoryPlot.class);
//         CategoryAxis domainAxis = Mockito.mock(CategoryAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = Mockito.mock(BoxAndWhiskerCategoryDataset.class);
//         
//         int row = 0;
//         int column = 0;
//         
//         when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(null);
//         when(renderer.getItemVisible(row, column)).thenReturn(true);
//         
//         // WHEN
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
//         
//         // THEN
//         verify(g2, never()).fill(any());
//         verify(g2, never()).draw(Mockito.<java.awt.Shape>any());
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem skips median drawing when medianVisible is true but medianValue is null")
//     void TC09_drawVerticalItem_medianVisibleTrueButMedianValueNull() {
//         // GIVEN
//         BoxAndWhiskerRenderer renderer = spy(new BoxAndWhiskerRenderer());
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = Mockito.mock(CategoryPlot.class);
//         CategoryAxis domainAxis = Mockito.mock(CategoryAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = Mockito.mock(BoxAndWhiskerCategoryDataset.class);
//         
//         int row = 0;
//         int column = 0;
//         
//         when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(null);
//         when(renderer.getItemVisible(row, column)).thenReturn(true);
//         
//         // WHEN
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
//         
//         // THEN
//         verify(g2, never()).draw(Mockito.<java.awt.Shape>any());
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem handles outliers exactly on regular bounds without drawing far out indicators")
//     void TC10_drawVerticalItem_outliersOnRegularBounds() {
//         // GIVEN
//         BoxAndWhiskerRenderer renderer = spy(new BoxAndWhiskerRenderer());
//         renderer.setFillBox(true);
//         renderer.setUseOutlinePaintForWhiskers(false);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.setMaxOutlierVisible(true);
//         renderer.setMinOutlierVisible(true);
//         
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = Mockito.mock(CategoryPlot.class);
//         CategoryAxis domainAxis = Mockito.mock(CategoryAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = Mockito.mock(BoxAndWhiskerCategoryDataset.class);
//         
//         int row = 0;
//         int column = 0;
//         
//         Double maxRegular = 100.0;
//         Double minRegular = 50.0;
//         Double maxFarOut = 100.0;
//         Double minFarOut = 50.0;
//         
//         when(dataset.getOutliers(anyInt(), anyInt())).thenReturn(Arrays.asList(maxRegular, minRegular));
//         when(dataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(maxRegular);
//         when(dataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(minRegular);
//         when(dataset.getMaxOutlier(anyInt(), anyInt())).thenReturn(maxFarOut);
//         when(dataset.getMinOutlier(anyInt(), anyInt())).thenReturn(minFarOut);
//         when(renderer.getItemVisible(row, column)).thenReturn(true);
//         
//         // WHEN
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
//         
//         // THEN
//         verify(renderer, never()).drawHighFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//         verify(renderer, never()).drawLowFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//         verify(g2, atLeast(2)).draw(Mockito.<java.awt.Shape>any());
//     }
// }