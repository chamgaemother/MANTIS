package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.JFreeChart;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.GeneralPath;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class DeviationStepRenderer_drawItem_1_1_Test {

    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private IntervalXYDataset dataset;

    @BeforeEach
    void setUp() {
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(); // Changed to use a real instance
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(IntervalXYDataset.class);
    }

//     @Test
//     @DisplayName("drawItem correctly draws shading when intervalGood is false and lowerCoordinates.size >1")
//     void TC43_drawItem_ShadingWhenIntervalGoodFalseAndLowerCoordinatesSizeGreaterThanOne() throws Exception {
//         DeviationStepRenderer renderer = new DeviationStepRenderer();
//         int series = 0;
//         int item = 1;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
        // Mocking IntervalXYDataset to return NaN for getXValue
//         when(dataset.getXValue(series, item)).thenReturn(Double.NaN);
//         when(dataset.getStartYValue(series, item)).thenReturn(10.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(20.0);
// 
        // Mocking previous item's coordinates
//         when(dataset.getStartYValue(series, item - 1)).thenReturn(8.0);
//         when(dataset.getEndYValue(series, item - 1)).thenReturn(18.0);
//         when(rangeAxis.valueToJava2D(8.0, dataArea, RectangleEdge.LEFT)).thenReturn(8.0);
//         when(rangeAxis.valueToJava2D(18.0, dataArea, RectangleEdge.LEFT)).thenReturn(18.0);
// 
        // Mock orientation
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
        // Verify that fill is called indicating shading was drawn
//         verify(g2, atLeastOnce()).fill(any(GeneralPath.class));
//     }

    @Test
    @DisplayName("drawItem propagates RuntimeException when getItemFillPaint throws an exception")
    void TC44_drawItem_PropagatesRuntimeExceptionFromGetItemFillPaint() {
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Mocking IntervalXYDataset to return valid values
        when(dataset.getXValue(series, item)).thenReturn(5.0);
        when(dataset.getStartYValue(series, item)).thenReturn(10.0);
        when(dataset.getEndYValue(series, item)).thenReturn(20.0);

        // Make getItemFillPaint throw RuntimeException
        doThrow(new RuntimeException("Fill Paint Error")).when(renderer).getItemFillPaint(series, item);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        });
        assertEquals("Fill Paint Error", exception.getMessage());
    }

    @Test
    @DisplayName("drawItem does not draw shading when intervalGood is false and upperCoordinates.size <=1")
    void TC45_drawItem_NoShadingWhenIntervalGoodFalseAndUpperCoordinatesSizeLessOrEqualOne() throws Exception {
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Mocking IntervalXYDataset to return NaN for getXValue
        when(dataset.getXValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getStartYValue(series, item)).thenReturn(10.0);
        when(dataset.getEndYValue(series, item)).thenReturn(20.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that fill is not called
        verify(g2, never()).fill(any(GeneralPath.class));
    }

    @Test
    @DisplayName("drawItem gracefully handles pass values greater than 1 without errors")
    void TC46_drawItem_HandlePassValuesGreaterThanOne() {
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 2;

        // Mocking IntervalXYDataset to return valid values
        when(dataset.getXValue(series, item)).thenReturn(5.0);
        when(dataset.getStartYValue(series, item)).thenReturn(10.0);
        when(dataset.getEndYValue(series, item)).thenReturn(20.0);

        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("drawItem executes drawSecondaryPass correctly when isItemPass is true and entity collection is present")
    void TC47_drawItem_DrawSecondaryPassWithEntityCollection() throws Exception {
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        // Mocking IntervalXYDataset to return valid values
        when(dataset.getXValue(series, item)).thenReturn(5.0);
        when(dataset.getStartYValue(series, item)).thenReturn(10.0);
        when(dataset.getEndYValue(series, item)).thenReturn(20.0);

        // Mocking isItemPass to return true
        doReturn(true).when(renderer).isItemPass(pass);

        // Mocking entity collection
        EntityCollection entities = mock(EntityCollection.class);
        ChartRenderingInfo chartRenderingInfo = mock(ChartRenderingInfo.class);
        when(info.getOwner()).thenReturn(chartRenderingInfo);
        when(chartRenderingInfo.getEntityCollection()).thenReturn(entities);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that drawSecondaryPass is called with entity collection
        verify(renderer, times(1)).drawSecondaryPass(g2, plot, dataset, pass, series, item, domainAxis, dataArea, rangeAxis, crosshairState, entities);
    }
}