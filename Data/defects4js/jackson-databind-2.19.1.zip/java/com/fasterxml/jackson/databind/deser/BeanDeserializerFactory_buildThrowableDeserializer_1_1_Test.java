package com.fasterxml.jackson.databind.deser;
// import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
// 
// import com.fasterxml.jackson.databind.*;
// import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
// import com.fasterxml.jackson.databind.deser.impl.BeanDeserializerModifier;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import java.util.Arrays;
// 
// import static org.junit.jupiter.api.Assertions.assertSame;
// import static org.mockito.Mockito.*;
// 
public class BeanDeserializerFactory_buildThrowableDeserializer_1_1_Test {
// 
//     @Test
//     @DisplayName("TC15: buildThrowableDeserializer returns original deserializer when it is not a BeanDeserializer and no deserializer modifiers are present")
//     public void test_TC15_nonBeanDeserializer_noModifiers() throws Exception {
        // Arrange
//         DeserializationContext ctxt = mock(DeserializationContext.class);
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(ctxt.getConfig()).thenReturn(config);
//         JavaType javaType = mock(JavaType.class);
//         when(javaType.isThrowable()).thenReturn(true); // Mock isThrowable to ensure execution flow to target method
//         BeanDescription beanDesc = mock(BeanDescription.class);
//         JsonDeserializer<Object> originalDeserializer = mock(JsonDeserializer.class);
//         BeanDeserializerFactory factory = spy(new BeanDeserializerFactory(new DeserializerFactoryConfig()));
// 
        // Mock buildBeanDeserializer to return originalDeserializer
//         doReturn(originalDeserializer).when(factory).buildThrowableDeserializer(ctxt, javaType, beanDesc);
// 
        // Act
//         JsonDeserializer<Object> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);
// 
        // Assert
//         assertSame(originalDeserializer, deserializer, "Deserializer should be returned as is");
//     }
// 
//     @Test
//     @DisplayName("TC16: buildThrowableDeserializer modifies deserializer through modifiers when deserializer is not a BeanDeserializer")
//     public void test_TC16_nonBeanDeserializer_withModifiers() throws Exception {
        // Arrange
//         DeserializationContext ctxt = mock(DeserializationContext.class);
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(ctxt.getConfig()).thenReturn(config);
//         JavaType javaType = mock(JavaType.class);
//         when(javaType.isThrowable()).thenReturn(true); // Mock isThrowable to ensure execution flow to target method
//         BeanDescription beanDesc = mock(BeanDescription.class);
//         JsonDeserializer<Object> originalDeserializer = mock(JsonDeserializer.class);
//         JsonDeserializer<Object> modifiedDeserializer = mock(JsonDeserializer.class);
//         BeanDeserializerModifier modifier = mock(BeanDeserializerModifier.class);
//         DeserializerFactoryConfig factoryConfig = mock(DeserializerFactoryConfig.class);
//         when(factoryConfig.hasDeserializerModifiers()).thenReturn(true);
//         when(factoryConfig.deserializerModifiers()).thenReturn(Arrays.asList(modifier));
//         BeanDeserializerFactory factory = spy(new BeanDeserializerFactory(factoryConfig));
// 
        // Mock buildBeanDeserializer to return originalDeserializer
//         doReturn(originalDeserializer).when(factory).buildThrowableDeserializer(ctxt, javaType, beanDesc);
// 
        // Mock modifier to modify deserializer
//         when(modifier.modifyDeserializer(config, beanDesc, originalDeserializer)).thenReturn(modifiedDeserializer);
// 
        // Act
//         JsonDeserializer<Object> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);
// 
        // Assert
//         assertSame(modifiedDeserializer, deserializer, "Deserializer should be modified and returned");
//         verify(modifier, times(1)).modifyDeserializer(config, beanDesc, originalDeserializer);
//     }
// }
}