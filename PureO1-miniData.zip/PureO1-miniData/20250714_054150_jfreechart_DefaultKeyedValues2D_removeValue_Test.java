package org.jfree.data;

import static org.junit.jupiter.api.Assertions.*;

import org.jfree.chart.util.Args;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DefaultKeyedValues2DTest {

    private DefaultKeyedValues2D data;

    @BeforeEach
    public void setUp() {
        data = new DefaultKeyedValues2D();
    }

    @Test
    public void testRemoveValue_NullRowKey_ThrowsException() {
        Comparable columnKey = "Column1";
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            data.removeValue(null, columnKey);
        });
        assertTrue(exception.getMessage().contains("rowKey"));
    }

    @Test
    public void testRemoveValue_NullColumnKey_ThrowsException() {
        Comparable rowKey = "Row1";
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            data.removeValue(rowKey, null);
        });
        assertTrue(exception.getMessage().contains("columnKey"));
    }

    @Test
    public void testRemoveValue_RowAndColumnExist_ValueRemoved() {
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        data.addValue(10, rowKey, columnKey);
        data.removeValue(rowKey, columnKey);
        assertNull(data.getValue(rowKey, columnKey));
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_RowExists_OtherValuesPresent_RowNotRemoved() {
        Comparable rowKey = "Row1";
        Comparable columnKey1 = "Column1";
        Comparable columnKey2 = "Column2";
        data.addValue(10, rowKey, columnKey1);
        data.addValue(20, rowKey, columnKey2);
        data.removeValue(rowKey, columnKey1);
        assertNull(data.getValue(rowKey, columnKey1));
        assertNotNull(data.getValue(rowKey, columnKey2));
        assertEquals(1, data.getRowCount());
        assertEquals(2, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_ColumnExists_OtherValuesPresent_ColumnNotRemoved() {
        Comparable rowKey1 = "Row1";
        Comparable rowKey2 = "Row2";
        Comparable columnKey = "Column1";
        data.addValue(10, rowKey1, columnKey);
        data.addValue(20, rowKey2, columnKey);
        data.removeValue(rowKey1, columnKey);
        assertNull(data.getValue(rowKey1, columnKey));
        assertNotNull(data.getValue(rowKey2, columnKey));
        assertEquals(2, data.getRowCount());
        assertEquals(1, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_RowBecomesEmpty_RowRemoved() {
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        data.addValue(10, rowKey, columnKey);
        data.removeValue(rowKey, columnKey);
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_ColumnBecomesEmpty_ColumnRemoved() {
        Comparable rowKey1 = "Row1";
        Comparable rowKey2 = "Row2";
        Comparable columnKey = "Column1";
        data.addValue(10, rowKey1, columnKey);
        data.addValue(20, rowKey2, columnKey);
        data.removeValue(rowKey1, columnKey);
        data.removeValue(rowKey2, columnKey);
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_RowAndColumnBecomeEmpty_RowAndColumnRemoved() {
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        data.addValue(10, rowKey, columnKey);
        data.removeValue(rowKey, columnKey);
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_ValueDoesNotExist_NoChanges() {
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        data.addValue(null, rowKey, columnKey);
        data.removeValue(rowKey, columnKey);
        assertNull(data.getValue(rowKey, columnKey));
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_RowKeyDoesNotExist_NoRowsAfterRemoval() {
        Comparable rowKey = "NonExistentRow";
        Comparable columnKey = "Column1";
        data.removeValue(rowKey, columnKey);
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_ColumnKeyDoesNotExist_NoColumnsAfterRemoval() {
        Comparable rowKey = "Row1";
        Comparable columnKey = "NonExistentColumn";
        data.removeValue(rowKey, columnKey);
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_RowAndColumnKeyDoNotExist_NoRowsOrColumns() {
        Comparable rowKey = "NonExistentRow";
        Comparable columnKey = "NonExistentColumn";
        data.removeValue(rowKey, columnKey);
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_MultipleRowsAndColumns_RowRemoved_ColumnRemains() {
        Comparable rowKey1 = "Row1";
        Comparable rowKey2 = "Row2";
        Comparable columnKey1 = "Column1";
        Comparable columnKey2 = "Column2";
        data.addValue(10, rowKey1, columnKey1);
        data.addValue(20, rowKey1, columnKey2);
        data.addValue(30, rowKey2, columnKey1);
        data.removeValue(rowKey1, columnKey1);
        assertNull(data.getValue(rowKey1, columnKey1));
        assertNotNull(data.getValue(rowKey1, columnKey2));
        assertNotNull(data.getValue(rowKey2, columnKey1));
        assertEquals(2, data.getRowCount());
        assertEquals(2, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_MultipleRowsAndColumns_ColumnRemoved_RowRemains() {
        Comparable rowKey1 = "Row1";
        Comparable rowKey2 = "Row2";
        Comparable columnKey1 = "Column1";
        Comparable columnKey2 = "Column2";
        data.addValue(10, rowKey1, columnKey1);
        data.addValue(20, rowKey2, columnKey1);
        data.addValue(30, rowKey1, columnKey2);
        data.removeValue(rowKey1, columnKey2);
        assertNull(data.getValue(rowKey1, columnKey2));
        assertNotNull(data.getValue(rowKey1, columnKey1));
        assertNotNull(data.getValue(rowKey2, columnKey1));
        assertEquals(2, data.getRowCount());
        assertEquals(2, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_AllRelatedRowsAndColumnsRemoved() {
        Comparable rowKey1 = "Row1";
        Comparable rowKey2 = "Row2";
        Comparable columnKey1 = "Column1";
        Comparable columnKey2 = "Column2";
        data.addValue(10, rowKey1, columnKey1);
        data.addValue(20, rowKey2, columnKey2);
        data.removeValue(rowKey1, columnKey1);
        assertNull(data.getValue(rowKey1, columnKey1));
        assertNotNull(data.getValue(rowKey2, columnKey2));
        assertEquals(1, data.getRowCount());
        assertEquals(1, data.getColumnCount());
        data.removeValue(rowKey2, columnKey2);
        assertNull(data.getValue(rowKey2, columnKey2));
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_MultipleValuesInRowAndColumn() {
        Comparable rowKey = "Row1";
        Comparable columnKey1 = "Column1";
        Comparable columnKey2 = "Column2";
        Comparable columnKey3 = "Column3";
        data.addValue(10, rowKey, columnKey1);
        data.addValue(20, rowKey, columnKey2);
        data.addValue(30, rowKey, columnKey3);
        data.removeValue(rowKey, columnKey2);
        assertNull(data.getValue(rowKey, columnKey2));
        assertNotNull(data.getValue(rowKey, columnKey1));
        assertNotNull(data.getValue(rowKey, columnKey3));
        assertEquals(1, data.getRowCount());
        assertEquals(3, data.getColumnCount());
    }

    @Test
    public void testRemoveValue_RemoveLastValueInColumnAndRow() {
        Comparable rowKey1 = "Row1";
        Comparable rowKey2 = "Row2";
        Comparable columnKey1 = "Column1";
        data.addValue(10, rowKey1, columnKey1);
        data.addValue(20, rowKey2, columnKey1);
        data.removeValue(rowKey1, columnKey1);
        data.removeValue(rowKey2, columnKey1);
        assertEquals(0, data.getRowCount());
        assertEquals(0, data.getColumnCount());
    }
}