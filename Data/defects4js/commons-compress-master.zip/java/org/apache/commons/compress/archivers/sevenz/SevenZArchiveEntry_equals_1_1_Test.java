package org.apache.commons.compress.archivers.sevenz;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.attribute.FileTime;
import java.util.Collections;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class SevenZArchiveEntry_equals_1_1_Test {

    @Test
    @DisplayName("equals(obj) returns true when comparing the same instance")
    public void equals_same_instance_returns_true() {
        // GIVEN
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        
        // WHEN
        boolean result = entry.equals(entry);
        
        // THEN
        assertTrue(result);
    }
    
    @Test
    @DisplayName("equals(null) returns false when obj is null")
    public void equals_null_obj_returns_false() {
        // GIVEN
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        Object obj = null;
        
        // WHEN
        boolean result = entry.equals(obj);
        
        // THEN
        assertFalse(result);
    }
    
    @Test
    @DisplayName("equals(obj) returns false when obj is of a different class")
    public void equals_different_class_returns_false() {
        // GIVEN
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        Object obj = new Object();
        
        // WHEN
        boolean result = entry.equals(obj);
        
        // THEN
        assertFalse(result);
    }
    
    @Test
    @DisplayName("equals(obj) returns false when name fields are different")
    public void equals_different_name_returns_false() throws Exception {
        // GIVEN
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName("file1.txt");
        
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName("file2.txt");
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertFalse(result);
    }
    
    @Test
    @DisplayName("equals(obj) returns true when all fields are identical")
    public void equals_identical_fields_returns_true() throws Exception {
        // GIVEN
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName("file.txt");
        entry1.setHasStream(true);
        entry1.setDirectory(false);
        entry1.setAntiItem(false);
        entry1.setHasCreationDate(true);
        entry1.setHasLastModifiedDate(true);
        entry1.setHasAccessDate(true);
        entry1.setCreationTime(FileTime.fromMillis(1000));
        entry1.setLastModifiedTime(FileTime.fromMillis(2000));
        entry1.setAccessTime(FileTime.fromMillis(3000));
        entry1.setHasWindowsAttributes(true);
        entry1.setWindowsAttributes(1234);
        entry1.setHasCrc(true);
        entry1.setCrcValue(5678);
        entry1.setCompressedCrcValue(91011);
        entry1.setSize(1024);
        entry1.setCompressedSize(512);
        entry1.setContentMethods(Collections.emptyList());
        
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName("file.txt");
        entry2.setHasStream(true);
        entry2.setDirectory(false);
        entry2.setAntiItem(false);
        entry2.setHasCreationDate(true);
        entry2.setHasLastModifiedDate(true);
        entry2.setHasAccessDate(true);
        entry2.setCreationTime(FileTime.fromMillis(1000));
        entry2.setLastModifiedTime(FileTime.fromMillis(2000));
        entry2.setAccessTime(FileTime.fromMillis(3000));
        entry2.setHasWindowsAttributes(true);
        entry2.setWindowsAttributes(1234);
        entry2.setHasCrc(true);
        entry2.setCrcValue(5678);
        entry2.setCompressedCrcValue(91011);
        entry2.setSize(1024);
        entry2.setCompressedSize(512);
        entry2.setContentMethods(Collections.emptyList());
        
        // WHEN
        boolean result = entry1.equals(entry2);
        
        // THEN
        assertTrue(result);
    }
}