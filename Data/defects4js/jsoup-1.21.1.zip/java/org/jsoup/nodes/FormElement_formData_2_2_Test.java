package org.jsoup.nodes;

import org.jsoup.parser.Tag;
import org.jsoup.nodes.FormElement;
import org.jsoup.nodes.Element;
import org.jsoup.Connection;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

public class FormElement_formData_2_2_Test {

    @Test
    @DisplayName("formData processes input elements with type 'email' and valid value")
    public void TC26_formData_processes_email_input_with_valid_value() {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element emailInput = new Element(Tag.valueOf("input"), "")
                                .attr("type", "email")
                                .attr("name", "user_email")
                                .attr("value", "user@example.com");
        form.addElement(emailInput);
        
        // Act
        List<Connection.KeyVal> data = form.formData();
        
        // Assert
        Assertions.assertEquals(1, data.size(), "Data list size should be 1");
        Assertions.assertEquals("user_email", data.get(0).key(), "Key should be 'user_email'");
        Assertions.assertEquals("user@example.com", data.get(0).value(), "Value should be 'user@example.com'");
    }

    @Test
    @DisplayName("formData processes input elements with type 'email' and empty value")
    public void TC27_formData_processes_email_input_with_empty_value() {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element emailInput = new Element(Tag.valueOf("input"), "")
                                .attr("type", "email")
                                .attr("name", "user_email")
                                .attr("value", "");
        form.addElement(emailInput);
        
        // Act
        List<Connection.KeyVal> data = form.formData();
        
        // Assert
        Assertions.assertEquals(1, data.size(), "Data list size should be 1");
        Assertions.assertEquals("user_email", data.get(0).key(), "Key should be 'user_email'");
        // Corrected assertion that expects an empty string
        Assertions.assertEquals("", data.get(0).value(), "Value should be empty");
    }
}