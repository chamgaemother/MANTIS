package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

public class LineUtils_clipLine_0_1_Test {

    @Test
    @DisplayName("Clip line with both endpoints inside the rectangle")
    public void TC01_clipLine_both_endpoints_inside() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(1.0, 1.0, 4.0, 4.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 5.0, 5.0);
        Line2D.Double originalLine = (Line2D.Double) line.clone();

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(originalLine.getX1(), line.getX1(), "x1 should remain unchanged");
        assertEquals(originalLine.getY1(), line.getY1(), "y1 should remain unchanged");
        assertEquals(originalLine.getX2(), line.getX2(), "x2 should remain unchanged");
        assertEquals(originalLine.getY2(), line.getY2(), "y2 should remain unchanged");
    }

    @Test
    @DisplayName("Clip line with both endpoints outside and not intersecting the rectangle")
    public void TC02_clipLine_both_endpoints_outside_no_intersection() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(-1.0, -1.0, -2.0, -2.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 5.0, 5.0);
        Line2D.Double originalLine = (Line2D.Double) line.clone();

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertFalse(result, "Expected clipLine to return false");
        assertEquals(originalLine.getX1(), line.getX1(), "x1 should remain unchanged");
        assertEquals(originalLine.getY1(), line.getY1(), "y1 should remain unchanged");
        assertEquals(originalLine.getX2(), line.getX2(), "x2 should remain unchanged");
        assertEquals(originalLine.getY2(), line.getY2(), "y2 should remain unchanged");
    }

    @Test
    @DisplayName("Clip line with one endpoint inside and one outside the rectangle")
    public void TC03_clipLine_one_endpoint_outside() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(2.0, 2.0, 6.0, 6.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 5.0, 5.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(2.0, line.getX1(), "x1 should remain unchanged");
        assertEquals(2.0, line.getY1(), "y1 should remain unchanged");
        assertEquals(5.0, line.getX2(), "x2 should be clipped to rectangle boundary");
        assertEquals(5.0, line.getY2(), "y2 should be clipped to rectangle boundary");
    }

    @Test
    @DisplayName("Clip line with non-finite x1 coordinate")
    public void TC04_clipLine_non_finite_x1() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(Double.NaN, 1.0, 4.0, 4.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 5.0, 5.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertFalse(result, "Expected clipLine to return false");
    }

    @Test
    @DisplayName("Clip line with non-finite y2 coordinate")
    public void TC05_clipLine_non_finite_y2() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(1.0, 1.0, 4.0, Double.POSITIVE_INFINITY);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 5.0, 5.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertFalse(result, "Expected clipLine to return false");
    }
}