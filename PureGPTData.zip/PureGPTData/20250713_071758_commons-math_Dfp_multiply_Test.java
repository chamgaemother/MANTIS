import org.junit.jupiter.api.Test;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import static org.junit.jupiter.api.Assertions.*;

class DfpTest {

    private final DfpField field = new DfpField(5);
    private final Dfp zero = field.newDfp(0);
    private final Dfp one = field.newDfp(1);
    private final Dfp nan = field.newDfp(1, Dfp.QNAN);
    private final Dfp inf = field.newDfp(1, Dfp.INFINITE);
    private final Dfp negInf = field.newDfp(-1, Dfp.INFINITE);

    @Test
    void testMultiplyWithSamePrecision() {
        Dfp a = field.newDfp(2);
        Dfp b = field.newDfp(3);
        Dfp result = a.multiply(b);
        assertEquals(field.newDfp(6), result);
    }

    @Test
    void testMultiplyWithDifferentPrecision() {
        DfpField differentField = new DfpField(10);
        Dfp a = field.newDfp(2);
        Dfp b = differentField.newDfp(3);
        Dfp result = a.multiply(b);
        assertTrue(result.isNaN());
    }

    @Test
    void testMultiplyWithNaN() {
        Dfp a = nan;
        Dfp b = field.newDfp(3);
        Dfp result = a.multiply(b);
        assertTrue(result.isNaN());
    }

    @Test
    void testMultiplyWithInfinite() {
        Dfp a = inf;
        Dfp b = field.newDfp(3);
        Dfp result = a.multiply(b);
        assertTrue(result.isInfinite());
    }

    @Test
    void testMultiplyZeroAndInfinite() {
        Dfp a = zero;
        Dfp b = inf;
        Dfp result = a.multiply(b);
        assertTrue(result.isNaN());
    }

    @Test
    void testMultiplyWithInfinityBothSides() {
        Dfp a = inf;
        Dfp b = negInf;
        Dfp result = a.multiply(b);
        assertTrue(result.isInfinite());
        assertEquals(-1, result.sign);

        result = b.multiply(a);
        assertTrue(result.isInfinite());
        assertEquals(-1, result.sign);
    }

    @Test
    void testMultiplyWithNegativeZero() {
        Dfp negativeZero = zero.negate();
        Dfp b = field.newDfp(3);
        Dfp result = negativeZero.multiply(b);
        assertEquals(zero, result);
        assertEquals(-1, result.sign);
    }

    @Test
    void testMultiplyZeroResult() {
        Dfp a = zero;
        Dfp b = one;
        Dfp result = a.multiply(b);
        assertEquals(zero, result);
        assertEquals(1, result.sign);
    }
}