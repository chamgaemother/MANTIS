package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.lang.StringBuilder;

public class FormatUtils_appendPaddedInteger_0_3_Test {

    @Test
    @DisplayName("Append zero with size equal to 1, expecting single '0'")
    void TC11() throws IOException {
        // Given
        Appendable appendable = new StringBuilder();
        int value = 0;
        int size = 1;

        // When
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // Then
        assertEquals("0", appendable.toString());
    }

    @Test
    @DisplayName("Append negative integer not Integer.MIN_VALUE with size sufficient for '-', digit count, and padding")
    void TC12() throws IOException {
        // Given
        Appendable appendable = new StringBuilder();
        int value = -7;
        int size = 3;

        // When
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // Then
        assertEquals("-07", appendable.toString());
    }

    @Test
    @DisplayName("Append Integer.MIN_VALUE with size equal to 10, expecting '-2147483648'")
    void TC13() throws IOException {
        // Given
        Appendable appendable = new StringBuilder();
        int value = Integer.MIN_VALUE;
        int size = 10;

        // When
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // Then
        assertEquals("-2147483648", appendable.toString());
    }

    @Test
    @DisplayName("Append Integer.MIN_VALUE with size greater than 10, expecting leading zeros before '-2147483648'")
    void TC14() throws IOException {
        // Given
        Appendable appendable = new StringBuilder();
        int value = Integer.MIN_VALUE;
        int size = 12;

        // When
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // Then
        assertEquals("00-2147483648", appendable.toString());
    }

    @Test
    @DisplayName("Append negative single-digit integer with size equal to 2, expecting '-' and '3'")
    void TC15() throws IOException {
        // Given
        Appendable appendable = new StringBuilder();
        int value = -3;
        int size = 2;

        // When
        FormatUtils.appendPaddedInteger(appendable, value, size);

        // Then
        assertEquals("-3", appendable.toString());
    }

}
