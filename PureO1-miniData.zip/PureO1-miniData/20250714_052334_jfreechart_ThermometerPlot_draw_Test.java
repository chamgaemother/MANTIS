import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.general.DefaultValueDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class ThermometerPlotTest {

    private ThermometerPlot plot;
    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotRenderingInfo info;
    private NumberAxis rangeAxis;

    @BeforeEach
    public void setUp() {
        plot = new ThermometerPlot();
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 200, 400);
        anchor = null;
        info = mock(PlotRenderingInfo.class);
        rangeAxis = new NumberAxis();
        plot.setRangeAxis(rangeAxis);
    }

    @Test
    public void testDrawWithNullInfo() {
        plot.draw(g2, area, anchor, null, null);
        verify(info, never()).setPlotArea(any());
    }

    @Test
    public void testDrawWithNonNullInfo() {
        plot.draw(g2, area, anchor, null, info);
        verify(info).setPlotArea(area);
    }

    @Test
    public void testDrawWithNullDataset() {
        plot.setDataset(null);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).draw(any());
    }

    @Test
    public void testDrawWithDatasetValueNull() {
        DefaultValueDataset dataset = new DefaultValueDataset();
        dataset.setValue(null);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).draw(any());
    }

    @Test
    public void testDrawWithValueInNormalSubrange() {
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.setRangeAxis(new NumberAxis());
        plot.setFollowDataInSubranges(true);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 50.0, 0.0, 50.0);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 75.0, 50.0, 75.0);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75.0, 100.0, 75.0, 100.0);
        plot.setUseSubrangePaint(true);
        plot.setSubrangeIndicatorsVisible(true);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    public void testDrawWithValueInWarningSubrange() {
        DefaultValueDataset dataset = new DefaultValueDataset(60.0);
        plot.setDataset(dataset);
        plot.setRangeAxis(new NumberAxis());
        plot.setFollowDataInSubranges(true);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 50.0, 0.0, 50.0);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 75.0, 50.0, 75.0);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75.0, 100.0, 75.0, 100.0);
        plot.setUseSubrangePaint(true);
        plot.setSubrangeIndicatorsVisible(true);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    public void testDrawWithValueInCriticalSubrange() {
        DefaultValueDataset dataset = new DefaultValueDataset(85.0);
        plot.setDataset(dataset);
        plot.setRangeAxis(new NumberAxis());
        plot.setFollowDataInSubranges(true);
        plot.setSubrangeInfo(ThermometerPlot.NORMAL, 0.0, 50.0, 0.0, 50.0);
        plot.setSubrangeInfo(ThermometerPlot.WARNING, 50.0, 75.0, 50.0, 75.0);
        plot.setSubrangeInfo(ThermometerPlot.CRITICAL, 75.0, 100.0, 75.0, 100.0);
        plot.setUseSubrangePaint(true);
        plot.setSubrangeIndicatorsVisible(true);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    public void testDrawWithValueOutOfSubranges() {
        DefaultValueDataset dataset = new DefaultValueDataset(150.0);
        plot.setDataset(dataset);
        plot.setRangeAxis(new NumberAxis());
        plot.setFollowDataInSubranges(false);
        plot.setUseSubrangePaint(false);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    public void testDrawWithSubrangeIndicatorsVisibleFalse() {
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.setSubrangeIndicatorsVisible(false);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, never()).draw(any());
    }

    @Test
    public void testDrawWithAxisLocationNone() {
        plot.setAxisLocation(ThermometerPlot.NONE);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, never()).draw(any());
    }

    @Test
    public void testDrawWithAxisLocationLeft() {
        plot.setAxisLocation(ThermometerPlot.LEFT);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawWithAxisLocationRight() {
        plot.setAxisLocation(ThermometerPlot.RIGHT);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawWithValueLocationNone() {
        plot.setValueLocation(ThermometerPlot.NONE);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        // No string drawn
        verify(g2, never()).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithValueLocationRight() {
        plot.setValueLocation(ThermometerPlot.RIGHT);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithValueLocationLeft() {
        plot.setValueLocation(ThermometerPlot.LEFT);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithValueLocationBulb() {
        plot.setValueLocation(ThermometerPlot.BULB);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithUnitsNone() {
        plot.setUnits(ThermometerPlot.UNITS_NONE);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        // Units string should be empty, so no string drawn for units
        verify(g2, never()).drawString(eq(""), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithUnitsFahrenheit() {
        plot.setUnits(ThermometerPlot.UNITS_FAHRENHEIT);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(eq("\u00B0F"), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithUnitsCelcius() {
        plot.setUnits(ThermometerPlot.UNITS_CELCIUS);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(eq("\u00B0C"), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithUnitsKelvin() {
        plot.setUnits(ThermometerPlot.UNITS_KELVIN);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(eq("\u00B0K"), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithShowValueLinesTrue() {
        plot.setShowValueLines(true);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        // Assuming that showValueLines affects drawWidth, but not directly verifiable
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawWithShowValueLinesFalse() {
        plot.setShowValueLines(false);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawWithTickX1GreaterThanAreaMinX() {
        plot.setUnits(ThermometerPlot.UNITS_CELCIUS);
        plot.setValueFont(new Font("Arial", Font.PLAIN, 12));
        Graphics2D mockedG2 = mock(Graphics2D.class);
        plot.draw(mockedG2, new Rectangle2D.Double(0, 0, 200, 400), anchor, null, info);
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        verify(mockedG2, atLeastOnce()).drawString(captor.capture(), anyInt(), anyInt());
        assertTrue(captor.getAllValues().contains("\u00B0C"));
    }

    @Test
    public void testDrawWithTickX1LessThanAreaMinX() {
        plot.setUnits(ThermometerPlot.UNITS_CELCIUS);
        plot.setValueFont(new Font("Arial", Font.PLAIN, 100));
        Graphics2D mockedG2 = mock(Graphics2D.class);
        plot.draw(mockedG2, new Rectangle2D.Double(0, 0, 200, 400), anchor, null, info);
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        verify(mockedG2, atLeastOnce()).drawString(captor.capture(), anyInt(), anyInt());
        // Check that units are not drawn if tickX1 <= area.minX
        // Depending on implementation, this might vary
    }

    @Test
    public void testDrawWithMercuryPaintChangingWithSubrange() {
        plot.setUseSubrangePaint(true);
        plot.setSubrangePaint(ThermometerPlot.NORMAL, Color.GREEN);
        plot.setSubrangePaint(ThermometerPlot.WARNING, Color.ORANGE);
        plot.setSubrangePaint(ThermometerPlot.CRITICAL, Color.RED);

        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        // Verify fill is called with GREEN
        verify(g2, atLeastOnce()).setPaint(Color.GREEN);

        dataset.setValue(60.0);
        plot.draw(g2, area, anchor, null, info);
        // Verify fill is called with ORANGE
        verify(g2, atLeastOnce()).setPaint(Color.ORANGE);

        dataset.setValue(85.0);
        plot.draw(g2, area, anchor, null, info);
        // Verify fill is called with RED
        verify(g2, atLeastOnce()).setPaint(Color.RED);
    }

    @Test
    public void testDrawWithUseSubrangePaintFalse() {
        plot.setUseSubrangePaint(false);
        plot.setMercuryPaint(Color.BLUE);
        DefaultValueDataset dataset = new DefaultValueDataset(85.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setPaint(Color.BLUE);
    }

    @Test
    public void testDrawWithDefaultConfiguration() {
        DefaultValueDataset dataset = new DefaultValueDataset(50.0);
        plot.setDataset(dataset);
        plot.setUnits(ThermometerPlot.UNITS_NONE);
        plot.setValueLocation(ThermometerPlot.NONE);
        plot.setAxisLocation(ThermometerPlot.NONE);
        plot.setSubrangeIndicatorsVisible(false);
        plot.setUseSubrangePaint(false);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
        verify(g2, never()).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithNullGraphics2D() {
        assertThrows(NullPointerException.class, () -> {
            plot.draw(null, area, anchor, null, info);
        });
    }

    @Test
    public void testDrawWithNegativeValue() {
        DefaultValueDataset dataset = new DefaultValueDataset(-10.0);
        plot.setDataset(dataset);
        plot.setFollowDataInSubranges(false);
        plot.setUseSubrangePaint(false);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    public void testDrawWithBoundaryValueNormalToWarning() {
        DefaultValueDataset dataset = new DefaultValueDataset(50.0);
        plot.setDataset(dataset);
        plot.setUseSubrangePaint(true);
        plot.setSubrangePaint(ThermometerPlot.NORMAL, Color.GREEN);
        plot.setSubrangePaint(ThermometerPlot.WARNING, Color.ORANGE);
        plot.setSubrangePaint(ThermometerPlot.CRITICAL, Color.RED);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setPaint(Color.ORANGE);
    }

    @Test
    public void testDrawWithBoundaryValueWarningToCritical() {
        DefaultValueDataset dataset = new DefaultValueDataset(75.0);
        plot.setDataset(dataset);
        plot.setUseSubrangePaint(true);
        plot.setSubrangePaint(ThermometerPlot.WARNING, Color.ORANGE);
        plot.setSubrangePaint(ThermometerPlot.CRITICAL, Color.RED);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setPaint(Color.RED);
    }

    @Test
    public void testDrawWithHighPrecisionValue() {
        DefaultValueDataset dataset = new DefaultValueDataset(50.12345);
        plot.setDataset(dataset);
        plot.setValueFormat(new java.text.DecimalFormat("#.##"));
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(eq("50.12"), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithCustomFonts() {
        Font customFont = new Font("Courier", Font.ITALIC, 14);
        plot.setValueFont(customFont);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).setFont(customFont);
    }

    @Test
    public void testDrawWithCustomStroke() {
        Stroke customStroke = new BasicStroke(2.0f);
        plot.setThermometerStroke(customStroke);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).setStroke(customStroke);
    }

    @Test
    public void testDrawWithCustomPaint() {
        Paint customPaint = Color.MAGENTA;
        plot.setThermometerPaint(customPaint);
        DefaultValueDataset dataset = new DefaultValueDataset(25.0);
        plot.setDataset(dataset);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).setPaint(customPaint);
    }
}