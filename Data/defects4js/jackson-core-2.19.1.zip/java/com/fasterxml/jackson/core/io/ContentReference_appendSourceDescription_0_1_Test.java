package com.fasterxml.jackson.core.io;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import com.fasterxml.jackson.core.ErrorReportConfiguration;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class ContentReference_appendSourceDescription_0_1_Test {

    private ContentReference createInstance() throws Exception {
        // Updated method to ensure creation of a valid instance
        ErrorReportConfiguration errorReportConfiguration = ErrorReportConfiguration.defaults();
        return ContentReference.construct(false, null, errorReportConfiguration);
    }

    @Test
    @DisplayName("srcRef is null and instance is REDACTED_CONTENT, appends redacted message")
    public void TC01_srcRef_null_and_REDACTED_CONTENT() throws Exception {
        // GIVEN
        ContentReference instance;

        // Set instance to REDACTED_CONTENT via reflection
        Field redactedContentField = ContentReference.class.getDeclaredField("REDACTED_CONTENT");
        redactedContentField.setAccessible(true);
        instance = (ContentReference) redactedContentField.get(null);

        StringBuilder sb = new StringBuilder();

        // WHEN
        StringBuilder result = instance.appendSourceDescription(sb);

        // THEN
        assertEquals("REDACTED (`StreamReadFeature.INCLUDE_SOURCE_IN_LOCATION` disabled)", sb.toString());
        assertSame(sb, result);
    }

    @Test
    @DisplayName("srcRef is null and instance is not REDACTED_CONTENT, appends \"UNKNOWN\"")
    public void TC02_srcRef_null_and_not_REDACTED_CONTENT() throws Exception {
        // GIVEN
        ContentReference instance = createInstance();

        // Set _rawContent to null via reflection
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        rawContentField.set(instance, null);

        StringBuilder sb = new StringBuilder();

        // WHEN
        StringBuilder result = instance.appendSourceDescription(sb);

        // THEN
        assertEquals("UNKNOWN", sb.toString());
        assertSame(sb, result);
    }

    @Test
    @DisplayName("srcRef is instance of Class, tn starts with \"java.\", appends simplified class name")
    public void TC03_srcRef_is_Class_with_java_package() throws Exception {
        // GIVEN
        ContentReference instance = createInstance();

        // Set _rawContent to a Class<?> instance with name starting with "java."
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        rawContentField.set(instance, java.util.List.class);

        StringBuilder sb = new StringBuilder();

        // WHEN
        StringBuilder result = instance.appendSourceDescription(sb);

        // THEN
        assertEquals("(List)", sb.toString());
        assertSame(sb, result);
    }

    @Test
    @DisplayName("srcRef is not Class, tn does not start with \"java.\", and srcRef is byte[], appends \"byte[]\"")
    public void TC04_srcRef_is_byte_array_and_non_java_package() throws Exception {
        // GIVEN
        ContentReference instance = createInstance();

        // Set _rawContent to a byte[] instance
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        rawContentField.set(instance, new byte[10]);

        StringBuilder sb = new StringBuilder();

        // WHEN
        StringBuilder result = instance.appendSourceDescription(sb);

        // THEN
        assertEquals("(byte[])", sb.toString());
        assertSame(sb, result);
    }

    @Test
    @DisplayName("srcRef is not Class, tn does not start with \"java.\", and srcRef is char[], appends \"char[]\"")
    public void TC05_srcRef_is_char_array_and_non_java_package() throws Exception {
        // GIVEN
        ContentReference instance = createInstance();

        // Set _rawContent to a char[] instance
        Field rawContentField = ContentReference.class.getDeclaredField("_rawContent");
        rawContentField.setAccessible(true);
        rawContentField.set(instance, new char[10]);

        StringBuilder sb = new StringBuilder();

        // WHEN
        StringBuilder result = instance.appendSourceDescription(sb);

        // THEN
        assertEquals("(char[])", sb.toString());
        assertSame(sb, result);
    }
}