package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Field;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public class ConcurrentReferenceHashMap_size_1_2_Test {

    @Test
    @DisplayName("TC16_sizeWithMultipleConcurrentModifications_MultipleRetriesAndLocking")
    void TC16_sizeWithMultipleConcurrentModifications_MultipleRetriesAndLocking() throws Exception {
        // GIVEN
        // Initialize ConcurrentReferenceHashMap with multiple segments
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.<Object, Object>builder()
                .setInitialCapacity(16)
                .setLoadFactor(0.75f)
                .setConcurrencyLevel(4)
                .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
                .get();

        // Populate the map with 200 entries (50 per segment)
        for (int i = 0; i < 200; i++) {
            map.put("Key" + i, "Value" + i);
        }

        // Use reflection to access the segments field
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set the initial count and modCount for each segment via reflection
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.setInt(segment, 50);

            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            modCountField.setInt(segment, 1);
        }

        // Prepare to simulate concurrent modifications
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean modificationOccurred = new AtomicBoolean(false);

        // Start a thread that continuously modifies modCount during size computation
        Thread modifier = new Thread(() -> {
            try {
                // Wait until size computation starts
                latch.await();
                for (Object segment : segments) {
                    Field modCountField = segment.getClass().getDeclaredField("modCount");
                    modCountField.setAccessible(true);
                    int currentModCount = modCountField.getInt(segment);
                    modCountField.setInt(segment, currentModCount + 1);
                    modificationOccurred.set(true);
                    // Sleep briefly to simulate continuous modifications
                    Thread.sleep(10);
                }
            } catch (Exception e) {
                // Handle exceptions
                e.printStackTrace();
            }
        });
        modifier.start();

        // WHEN
        // Start size computation and release the modifier thread
        latch.countDown();
        int size = map.size();
        modifier.join();

        // THEN
        // Assert that size is correctly computed after locking
        assertEquals(200, size, "Size should be accurately computed after resorting to locking all segments.");
    }
}