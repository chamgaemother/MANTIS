package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.Image;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.util.UnitType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class StandardXYItemRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem with info as null and item is visible")
    void TC01_drawItem_with_null_info_and_visible_item() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), null, null, null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(dataset.getYValue(0, 0)).thenReturn(20.0);
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        // Mock renderer behavior
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(renderer.getPlotLines()).thenReturn(true);
        when(renderer.lookupSeriesStroke(0)).thenReturn(mock(Stroke.class));
        when(renderer.lookupSeriesPaint(0)).thenReturn(mock(Paint.class));
        when(renderer.getBaseShapesVisible()).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);

        // Assert
        // Verify that setPaint and setStroke are called
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));

        // Verify that draw methods are called appropriately
        verify(g2).draw(any(Shape.class));
    }

//     @Test
//     @DisplayName("drawItem with non-null info and item is not visible due to NaN x1")
//     void TC02_drawItem_with_non_null_info_and_NaN_x1() throws Exception {
        // Arrange
//         StandardXYItemRenderer renderer = new StandardXYItemRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), null, null, null);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(XYPlot.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
//         when(dataset.getYValue(0, 0)).thenReturn(20.0);
//         CrosshairState crosshairState = new CrosshairState();
//         int pass = 0;
// 
        // Mock renderer behavior
//         when(renderer.getItemVisible(0, 0)).thenReturn(true);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
// 
        // Assert
        // Verify that no drawing occurs due to NaN x1
//         verify(g2, never()).setPaint(any(Paint.class));
//         verify(g2, never()).draw(any(Shape.class));
//     }

    @Test
    @DisplayName("drawItem with plotLines disabled and baseShapesVisible true")
    void TC03_drawItem_with_plotLines_disabled_and_shapes_visible() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        renderer.setPlotLines(false);
        renderer.setBaseShapesVisible(true);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), null, null, null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(dataset.getYValue(0, 0)).thenReturn(20.0);
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        // Mock renderer behavior
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(renderer.getBaseShapesVisible()).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);

        // Assert
        // Verify that shapes are drawn without plotting lines
        verify(g2).setPaint(any(Paint.class));
        verify(g2).draw(any(Shape.class));
        verify(g2, never()).setStroke(any(Stroke.class));
    }

//     @Test
//     @DisplayName("drawItem with plotImages enabled and image is present")
//     void TC04_drawItem_with_plotImages_enabled_and_image_present() throws Exception {
        // Arrange
//         StandardXYItemRenderer renderer = new StandardXYItemRenderer();
//         renderer.setPlotImages(true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), null, null, null);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(XYPlot.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(10.0);
//         when(dataset.getYValue(0, 0)).thenReturn(20.0);
//         CrosshairState crosshairState = new CrosshairState();
//         int pass = 0;
// 
//         Image image = mock(Image.class);
//         when(renderer.getImage(any(), anyInt(), anyInt(), anyDouble(), anyDouble())).thenReturn(image);
//         when(image.getWidth(null)).thenReturn(10);
//         when(image.getHeight(null)).thenReturn(10);
//         when(renderer.getImageHotspot(any(), anyInt(), anyInt(), anyDouble(), anyDouble(), any(Image.class)))
//             .thenReturn(new java.awt.Point(5, 5));
// 
        // Mock renderer behavior
//         when(renderer.getItemVisible(0, 0)).thenReturn(true);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
// 
        // Assert
        // Verify that image is drawn at the correct hotspot position
//         ArgumentCaptor<Integer> xCaptor = ArgumentCaptor.forClass(Integer.class);
//         ArgumentCaptor<Integer> yCaptor = ArgumentCaptor.forClass(Integer.class);
//         verify(g2).drawImage(eq(image), xCaptor.capture(), yCaptor.capture(), isNull());
//         assertEquals(5, xCaptor.getValue());
//         assertEquals(15, yCaptor.getValue());
//     }

    @Test
    @DisplayName("drawItem with plotDiscontinuous enabled and gapThreshold exceeded")
    void TC05_drawItem_with_plotDiscontinuous_enabled_and_gapThreshold_exceeded() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();
        renderer.setPlotDiscontinuous(true);
        renderer.setGapThreshold(5.0);
        renderer.setGapThresholdType(UnitType.ABSOLUTE);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), null, null, null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(dataset.getYValue(0, 0)).thenReturn(20.0);
        when(dataset.getXValue(0, 1)).thenReturn(20.0); // Gap of 10 > threshold 5
        when(dataset.getYValue(0, 1)).thenReturn(30.0);
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        // Mock renderer behavior
        when(renderer.getItemVisible(0, 1)).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, pass);

        // Assert
        // Verify that line is not drawn due to gap threshold exceeded
        verify(g2, never()).draw(any(Shape.class));
    }
}