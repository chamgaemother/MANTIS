package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.Pannable;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.Zoomable;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * JUnit 5 test class for testing the mousePressed method of ChartPanel.
 */
public class ChartPanel_mousePressed_1_1_Test {

    /**
     * Helper method to set a private field using reflection.
     */
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    /**
     * Helper method to get a private field using reflection.
     */
    private Object getPrivateField(Object target, String fieldName) throws Exception {
        java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(target);
    }

//     @Test
//     @DisplayName("TC13: mousePressed does not initiate panning when panMask is matched but plot is Pannable with neither domain nor range pannable")
//     void TC13_mousePressed_NoPanningWhenPannableButNotDomainOrRange() throws Exception {
        // Arrange
//         Pannable mockPlot = mock(Pannable.class);
//         when(mockPlot.isDomainPannable()).thenReturn(false);
//         when(mockPlot.isRangePannable()).thenReturn(false);
// 
//         JFreeChart mockChart = mock(JFreeChart.class);
//         when(mockChart.getPlot()).thenReturn(mockPlot);
// 
//         ChartPanel chartPanel = new ChartPanel(mockChart);
// 
        // Set panMask to CTRL_DOWN_MASK
//         setPrivateField(chartPanel, "panMask", InputEvent.CTRL_DOWN_MASK);
// 
        // Mock MouseEvent
//         MouseEvent mockEvent = mock(MouseEvent.class);
//         when(mockEvent.getModifiers()).thenReturn(InputEvent.CTRL_DOWN_MASK);
//         when(mockEvent.getX()).thenReturn(150);
//         when(mockEvent.getY()).thenReturn(150);
//         Point mousePoint = new Point(150, 150);
//         when(mockEvent.getPoint()).thenReturn(mousePoint);
// 
        // Act
//         chartPanel.mousePressed(mockEvent);
// 
        // Assert
//         assertNull(getPrivateField(chartPanel, "panLast"), "panLast should be null");
//         assertEquals(0.0, getPrivateField(chartPanel, "panW"), "panW should be 0.0");
//         assertEquals(0.0, getPrivateField(chartPanel, "panH"), "panH should be 0.0");
//         assertEquals(Cursor.getDefaultCursor(), chartPanel.getCursor(), "Cursor should remain default");
//     }

    @Test
    @DisplayName("TC14: mousePressed does not initiate panning when panMask is matched and plot is not Pannable")
    void TC14_mousePressed_NoPanningWhenPlotNotPannable() throws Exception {
        // Arrange
        Plot mockPlot = mock(Plot.class); // Not an instance of Pannable

        JFreeChart mockChart = mock(JFreeChart.class);
        when(mockChart.getPlot()).thenReturn(mockPlot);

        ChartPanel chartPanel = new ChartPanel(mockChart);

        // Set panMask to CTRL_DOWN_MASK
        setPrivateField(chartPanel, "panMask", InputEvent.CTRL_DOWN_MASK);

        // Mock MouseEvent
        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getModifiers()).thenReturn(InputEvent.CTRL_DOWN_MASK);
        when(mockEvent.getX()).thenReturn(150);
        when(mockEvent.getY()).thenReturn(150);
        Point mousePoint = new Point(150, 150);
        when(mockEvent.getPoint()).thenReturn(mousePoint);

        // Act
        chartPanel.mousePressed(mockEvent);

        // Assert
        assertNull(getPrivateField(chartPanel, "panLast"), "panLast should be null");
        assertEquals(0.0, getPrivateField(chartPanel, "panW"), "panW should be 0.0");
        assertEquals(0.0, getPrivateField(chartPanel, "panH"), "panH should be 0.0");
        assertEquals(Cursor.getDefaultCursor(), chartPanel.getCursor(), "Cursor should remain default");
    }

//     @Test
//     @DisplayName("TC15: mousePressed does not set zoomPoint and does not display popup when panMask is not matched and zoomRectangle is not null with popup trigger true")
//     void TC15_mousePressed_NoZoomPointOrPopupWhenZoomRectangleNotNullAndPopupTriggerTrue() throws Exception {
        // Arrange
//         JFreeChart mockChart = mock(JFreeChart.class);
//         Plot mockPlot = mock(Plot.class);
//         when(mockChart.getPlot()).thenReturn(mockPlot);
//         ChartPanel chartPanel = new ChartPanel(mockChart);
// 
        // Set zoomRectangle to a non-null value
//         setPrivateField(chartPanel, "zoomRectangle", new Rectangle2D.Double(100, 100, 50, 50));
// 
        // Mock MouseEvent with popup trigger
//         MouseEvent mockEvent = mock(MouseEvent.class);
//         when(mockEvent.getModifiers()).thenReturn(0);
//         when(mockEvent.getX()).thenReturn(150);
//         when(mockEvent.getY()).thenReturn(150);
//         when(mockEvent.isPopupTrigger()).thenReturn(true);
// 
        // Mock popup menu
//         JPopupMenu mockPopup = mock(JPopupMenu.class);
//         setPrivateField(chartPanel, "popup", mockPopup);
// 
        // Act
//         chartPanel.mousePressed(mockEvent);
// 
        // Assert
//         assertNull(getPrivateField(chartPanel, "zoomPoint"), "zoomPoint should be null");
//         verify(mockPopup, never()).show(any(), anyInt(), anyInt());
//     }

//     @Test
//     @DisplayName("TC16: mousePressed does not set zoomPoint and does not display popup when panMask is not matched and zoomRectangle is not null with popup trigger false")
//     void TC16_mousePressed_NoZoomPointOrPopupWhenZoomRectangleNotNullAndPopupTriggerFalse() throws Exception {
        // Arrange
//         JFreeChart mockChart = mock(JFreeChart.class);
//         Plot mockPlot = mock(Plot.class);
//         when(mockChart.getPlot()).thenReturn(mockPlot);
//         ChartPanel chartPanel = new ChartPanel(mockChart);
// 
        // Set zoomRectangle to a non-null value
//         setPrivateField(chartPanel, "zoomRectangle", new Rectangle2D.Double(200, 200, 100, 100));
// 
        // Mock MouseEvent without popup trigger
//         MouseEvent mockEvent = mock(MouseEvent.class);
//         when(mockEvent.getModifiers()).thenReturn(0);
//         when(mockEvent.getX()).thenReturn(250);
//         when(mockEvent.getY()).thenReturn(250);
//         when(mockEvent.isPopupTrigger()).thenReturn(false);
// 
        // Mock popup menu
//         JPopupMenu mockPopup = mock(JPopupMenu.class);
//         setPrivateField(chartPanel, "popup", mockPopup);
// 
        // Act
//         chartPanel.mousePressed(mockEvent);
// 
        // Assert
//         assertNull(getPrivateField(chartPanel, "zoomPoint"), "zoomPoint should be null");
//         verify(mockPopup, never()).show(any(), anyInt(), anyInt());
//     }

//     @Test
//     @DisplayName("TC17: mousePressed sets zoomPoint and displays popup when panMask is not matched, zoomRectangle is null and popup trigger is true with popup available")
//     void TC17_mousePressed_SetsZoomPointAndDisplaysPopupWhenConditionsMet() throws Exception {
        // Arrange
//         Plot mockPlot = mock(Plot.class);
// 
//         JFreeChart mockChart = mock(JFreeChart.class);
//         when(mockChart.getPlot()).thenReturn(mockPlot);
// 
//         ChartPanel chartPanel = new ChartPanel(mockChart);
// 
        // Ensure zoomRectangle is null
//         setPrivateField(chartPanel, "zoomRectangle", null);
// 
        // Mock MouseEvent with popup trigger
//         MouseEvent mockEvent = mock(MouseEvent.class);
//         when(mockEvent.getModifiers()).thenReturn(0);
//         when(mockEvent.getX()).thenReturn(150);
//         when(mockEvent.getY()).thenReturn(150);
//         when(mockEvent.isPopupTrigger()).thenReturn(true);
//         Point mousePoint = new Point(150, 150);
//         when(mockEvent.getPoint()).thenReturn(mousePoint);
// 
        // Mock displayPopupMenu method
//         ChartPanel spyChartPanel = spy(chartPanel);
//         doNothing().when(spyChartPanel).displayPopupMenu(anyInt(), anyInt());
// 
        // Mock getScreenDataArea and getPointInRectangle
//         Rectangle2D mockScreenDataArea = new Rectangle2D.Double(100, 100, 200, 200);
//         when(spyChartPanel.getScreenDataArea(150, 150)).thenReturn(mockScreenDataArea);
//         when(spyChartPanel.getPointInRectangle(150, 150, mockScreenDataArea))
//                 .thenReturn(new Point2D.Double(150, 150));
// 
        // Act
//         spyChartPanel.mousePressed(mockEvent);
// 
        // Assert
//         Point2D zoomPoint = (Point2D) getPrivateField(spyChartPanel, "zoomPoint");
//         assertNotNull(zoomPoint, "zoomPoint should be set");
//         assertEquals(150, zoomPoint.getX(), "zoomPoint X should be 150");
//         assertEquals(150, zoomPoint.getY(), "zoomPoint Y should be 150");
//         verify(spyChartPanel, times(1)).displayPopupMenu(150, 150);
//     }
}