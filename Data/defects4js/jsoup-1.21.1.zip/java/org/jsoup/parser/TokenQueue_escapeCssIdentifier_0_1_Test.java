package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jsoup.parser.TokenQueue;

public class TokenQueue_escapeCssIdentifier_0_1_Test {

    @Test
    @DisplayName("Input string is empty, method returns the input as is")
    void TC01_escapeCssIdentifier_empty_input() {
        // GIVEN
        String input = "";
        TokenQueue tokenQueue = new TokenQueue(input);
        // WHEN
        String result = tokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("", result);
    }

    @Test
    @DisplayName("Input starts with '-', followed by no characters, escapes '-'")
    void TC02_escapeCssIdentifier_single_hyphen() {
        // GIVEN
        String input = "-";
        TokenQueue tokenQueue = new TokenQueue(input);
        // WHEN
        String result = tokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("\\- ", result);
    }

    @Test
    @DisplayName("Input starts with '-', followed by a digit, escapes digit codepoint")
    void TC03_escapeCssIdentifier_hyphen_digit() {
        // GIVEN
        String input = "-5";
        TokenQueue tokenQueue = new TokenQueue(input);
        // WHEN
        String result = tokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("-\\35 ", result);
    }

    @Test
    @DisplayName("Input starts with a digit, escapes the digit as codepoint")
    void TC04_escapeCssIdentifier_starts_with_digit() {
        // GIVEN
        String input = "3abc";
        TokenQueue tokenQueue = new TokenQueue(input);
        // WHEN
        String result = tokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("\\33 abc", result);
    }

    @Test
    @DisplayName("Input contains NULL character, replaces with replacement character")
    void TC05_escapeCssIdentifier_contains_null() {
        // GIVEN
        String input = "abc\0def";
        TokenQueue tokenQueue = new TokenQueue(input);
        // WHEN
        String result = tokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("abcï¿½def", result);
    }
}