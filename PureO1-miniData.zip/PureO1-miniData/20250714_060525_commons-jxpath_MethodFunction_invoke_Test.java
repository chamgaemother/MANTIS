package org.apache.commons.jxpath.functions;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.apache.commons.jxpath.functions.MethodFunction;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class MethodFunctionTest {

    private static Method staticMethodNoContext;
    private static Method staticMethodWithContext;
    private static Method instanceMethodNoContext;
    private static Method instanceMethodWithContext;
    private static Method methodThrowsException;
    private static Method methodWithPrimitive;

    @BeforeAll
    static void setup() throws NoSuchMethodException {
        staticMethodNoContext = TestMethods.class.getMethod("staticMethod", String.class);
        staticMethodWithContext = TestMethods.class.getMethod("staticMethodWithContext", ExpressionContext.class, String.class);
        instanceMethodNoContext = TestMethods.class.getMethod("instanceMethod", Integer.class);
        instanceMethodWithContext = TestMethods.class.getMethod("instanceMethodWithContext", ExpressionContext.class, Integer.class);
        methodThrowsException = TestMethods.class.getMethod("methodThrowsException");
        methodWithPrimitive = TestMethods.class.getMethod("methodWithPrimitive", int.class);
    }

    @Test
    void testInvokeStaticMethodNoContextWithValidParameters() {
        MethodFunction mf = new MethodFunction(staticMethodNoContext);
        Object result = mf.invoke(null, new Object[]{"test"});
        assertEquals("staticMethod called with: test", result);
    }

    @Test
    void testInvokeStaticMethodNoContextWithNullParameters() {
        MethodFunction mf = new MethodFunction(staticMethodNoContext);
        Object result = mf.invoke(null, null);
        assertEquals("staticMethod called with: null", result);
    }

    @Test
    void testInvokeStaticMethodWithContextWithValidParameters() {
        MethodFunction mf = new MethodFunction(staticMethodWithContext);
        ExpressionContext context = new DummyExpressionContext();
        Object result = mf.invoke(context, new Object[]{"test"});
        assertEquals("staticMethodWithContext called with context and: test", result);
    }

    @Test
    void testInvokeStaticMethodWithContextWithNullParameters() {
        MethodFunction mf = new MethodFunction(staticMethodWithContext);
        ExpressionContext context = new DummyExpressionContext();
        Object result = mf.invoke(context, null);
        assertEquals("staticMethodWithContext called with context and: null", result);
    }

    @Test
    void testInvokeInstanceMethodNoContextWithValidParameters() {
        MethodFunction mf = new MethodFunction(instanceMethodNoContext);
        Object target = new TestMethods();
        Object result = mf.invoke(null, new Object[]{target, 42});
        assertEquals("instanceMethod called with: 42", result);
    }

    @Test
    void testInvokeInstanceMethodNoContextWithNullTarget() {
        MethodFunction mf = new MethodFunction(instanceMethodNoContext);
        assertThrows(JXPathInvalidAccessException.class, () -> {
            mf.invoke(null, new Object[]{null, 42});
        });
    }

    @Test
    void testInvokeInstanceMethodWithContextWithValidParameters() {
        MethodFunction mf = new MethodFunction(instanceMethodWithContext);
        ExpressionContext context = new DummyExpressionContext();
        Object target = new TestMethods();
        Object result = mf.invoke(context, new Object[]{target, 100});
        assertEquals("instanceMethodWithContext called with context and: 100", result);
    }

    @Test
    void testInvokeInstanceMethodWithContextWithNullParameters() {
        MethodFunction mf = new MethodFunction(instanceMethodWithContext);
        ExpressionContext context = new DummyExpressionContext();
        Object target = new TestMethods();
        Object result = mf.invoke(context, new Object[]{target, null});
        assertEquals("instanceMethodWithContext called with context and: null", result);
    }

    @Test
    void testInvokeMethodThrowsException() {
        MethodFunction mf = new MethodFunction(methodThrowsException);
        JXPathInvalidAccessException ex = assertThrows(JXPathInvalidAccessException.class, () -> {
            mf.invoke(null, null);
        });
        assertTrue(ex.getCause() instanceof RuntimeException);
        assertEquals("Intentional Exception", ex.getCause().getMessage());
    }

    @Test
    void testInvokeMethodWithPrimitiveParameter() {
        MethodFunction mf = new MethodFunction(methodWithPrimitive);
        Object result = mf.invoke(null, new Object[]{10});
        assertEquals("methodWithPrimitive called with: 10", result);
    }

    @Test
    void testInvokeMethodWithPrimitiveParameterWithNull() {
        MethodFunction mf = new MethodFunction(methodWithPrimitive);
        JXPathInvalidAccessException ex = assertThrows(JXPathInvalidAccessException.class, () -> {
            mf.invoke(null, new Object[]{null});
        });
        assertTrue(ex.getCause() instanceof IllegalArgumentException);
    }

    @Test
    void testInvokeStaticMethodWithInsufficientParameters() {
        MethodFunction mf = new MethodFunction(staticMethodNoContext);
        JXPathInvalidAccessException ex = assertThrows(JXPathInvalidAccessException.class, () -> {
            mf.invoke(null, new Object[]{});
        });
        assertTrue(ex.getCause() instanceof IllegalArgumentException);
    }

    @Test
    void testInvokeInstanceMethodWithInsufficientParameters() {
        MethodFunction mf = new MethodFunction(instanceMethodNoContext);
        Object target = new TestMethods();
        JXPathInvalidAccessException ex = assertThrows(JXPathInvalidAccessException.class, () -> {
            mf.invoke(null, new Object[]{target});
        });
        assertTrue(ex.getCause() instanceof ArrayIndexOutOfBoundsException);
    }

    // Dummy ExpressionContext implementation for testing
    static class DummyExpressionContext implements ExpressionContext {
        @Override
        public Object getContextBean() {
            return this;
        }
    }

    // Helper class with methods to be invoked
    public static class TestMethods {
        public static String staticMethod(String param) {
            return "staticMethod called with: " + param;
        }

        public static String staticMethodWithContext(ExpressionContext context, String param) {
            return "staticMethodWithContext called with context and: " + param;
        }

        public String instanceMethod(Integer param) {
            return "instanceMethod called with: " + param;
        }

        public String instanceMethodWithContext(ExpressionContext context, Integer param) {
            return "instanceMethodWithContext called with context and: " + param;
        }

        public static void methodThrowsException() {
            throw new RuntimeException("Intentional Exception");
        }

        public static String methodWithPrimitive(int param) {
            return "methodWithPrimitive called with: " + param;
        }
    }
}