package org.apache.commons.math3.geometry.euclidean.twod.hull;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class AklToussaintHeuristic_reducePoints_1_2_Test {

    @Test
    @DisplayName("reducePoints with empty collection and additional boundary conditions")
    public void TC19() {
        // Given
        Collection<Vector2D> points = Collections.emptyList();

        // When
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // Then
        assertTrue(result.isEmpty(), "Expected the result to be an empty collection.");
    }

    @Test
    @DisplayName("reducePoints with null collection input throws NullPointerException")
    public void TC20() {
        // Given
        Collection<Vector2D> points = null;

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            AklToussaintHeuristic.reducePoints(points);
        }, "Expected reducePoints to throw NullPointerException when input is null.");
    }

    @Test
    @DisplayName("reducePoints with collection containing null points throws NullPointerException")
    public void TC21() {
        // Given
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = null;
        Collection<Vector2D> points = Arrays.asList(p1, p2);

        // When & Then
        assertThrows(NullPointerException.class, () -> {
            AklToussaintHeuristic.reducePoints(points);
        }, "Expected reducePoints to throw NullPointerException when collection contains null elements.");
    }
}