package org.apache.commons.math3.fitting.leastsquares;

import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.apache.commons.math3.util.Incrementor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class LevenbergMarquardtOptimizer_optimize_0_3_Test {

//    @Test
//    @DisplayName("Optimize with orthogonal function vector below tolerance leading to convergence")
//    void TC11_optimizeOrthogonalFunctionVectorConvergence() throws Exception {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);
//        Incrementor iterationCounter = new Incrementor();
//        Incrementor evaluationCounter = new Incrementor();
//
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Evaluation evaluation = mock(Evaluation.class);
//        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(new double[10]));
//        when(evaluation.getCost()).thenReturn(1.0);
//        when(evaluation.getPoint()).thenReturn(new ArrayRealVector(new double[5]));
//        when(problem.evaluate(any(ArrayRealVector.class))).thenReturn(evaluation);
//
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        assertNotNull(result, "OptimumImpl should not be null");
//
//        java.lang.reflect.Field qrRankingThresholdField = optimizer.getClass().getDeclaredField("qrRankingThreshold");
//        qrRankingThresholdField.setAccessible(true);
//        double qrRankingThreshold = qrRankingThresholdField.getDouble(optimizer);
//
//        java.lang.reflect.Field orthoToleranceField = optimizer.getClass().getDeclaredField("orthoTolerance");
//        orthoToleranceField.setAccessible(true);
//        double orthoTolerance = orthoToleranceField.getDouble(optimizer);
//
//        assertTrue(qrRankingThreshold <= orthoTolerance, "QR Ranking Threshold should be below orthoTolerance");
//    }
//
//    @Test
//    @DisplayName("Optimize with lmPar reaching upper bound leads to parameter update")
//    void TC12_optimizeLmParUpperBoundAdjustment() throws Exception {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);
//        Incrementor iterationCounter = new Incrementor();
//        Incrementor evaluationCounter = new Incrementor();
//
//        when(problem.getObservationSize()).thenReturn(15);
//        when(problem.getParameterSize()).thenReturn(7);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Evaluation evaluation = mock(Evaluation.class);
//        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(new double[15]));
//        when(evaluation.getCost()).thenReturn(2.0);
//        when(evaluation.getPoint()).thenReturn(new ArrayRealVector(new double[7]));
//        when(problem.evaluate(any(ArrayRealVector.class))).thenReturn(evaluation);
//
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        assertNotNull(result, "OptimumImpl should not be null");
//    }
//
//    @Test
//    @DisplayName("Optimize with currentCost set to zero leads to immediate convergence")
//    void TC13_optimizeZeroInitialCostConvergence() throws Exception {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);
//        Incrementor iterationCounter = new Incrementor();
//        Incrementor evaluationCounter = new Incrementor();
//
//        when(problem.getObservationSize()).thenReturn(8);
//        when(problem.getParameterSize()).thenReturn(4);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Evaluation evaluation = mock(Evaluation.class);
//        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(new double[8]));
//        when(evaluation.getCost()).thenReturn(0.0);
//        when(evaluation.getPoint()).thenReturn(new ArrayRealVector(new double[4]));
//        when(problem.evaluate(any(ArrayRealVector.class))).thenReturn(evaluation);
//
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        assertNotNull(result, "OptimumImpl should not be null");
//        assertEquals(0.0, result.getResiduals().getNorm(), "Cost should be zero");
//    }
//
//    @Test
//    @DisplayName("Optimize with initial xNorm set to zero initializes delta correctly")
//    void TC14_optimizeZeroInitialNorm() throws Exception {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        ConvergenceChecker<Evaluation> checker = mock(ConvergenceChecker.class);
//        Incrementor iterationCounter = new Incrementor();
//        Incrementor evaluationCounter = new Incrementor();
//
//        when(problem.getObservationSize()).thenReturn(12);
//        when(problem.getParameterSize()).thenReturn(6);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Evaluation evaluation = mock(Evaluation.class);
//        ArrayRealVector zeroPoint = new ArrayRealVector(new double[6]);
//        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(new double[12]));
//        when(evaluation.getCost()).thenReturn(1.0);
//        when(evaluation.getPoint()).thenReturn(zeroPoint);
//        when(problem.evaluate(any(ArrayRealVector.class))).thenReturn(evaluation);
//
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        assertNotNull(result, "OptimumImpl should not be null");
//
//        java.lang.reflect.Field initialStepBoundFactorField = optimizer.getClass().getDeclaredField("initialStepBoundFactor");
//        initialStepBoundFactorField.setAccessible(true);
//        double initialStepBoundFactor = initialStepBoundFactorField.getDouble(optimizer);
//
//        assertEquals(initialStepBoundFactor, optimizer.getInitialStepBoundFactor(), "Delta should be initialized using initialStepBoundFactor directly");
//    }
//
//    @Test
//    @DisplayName("Optimize with weightedResiduals adjusted correctly after QR decomposition")
//    void TC15_optimizeWeightedResidualsAfterQR() throws Exception {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        ConvergenceChecker<LevenbergMarquardtOptimizer_optimize_0_1_Test.Evaluation> checker = mock(ConvergenceChecker.class);
//        Incrementor iterationCounter = new Incrementor();
//        Incrementor evaluationCounter = new Incrementor();
//
//        when(problem.getObservationSize()).thenReturn(20);
//        when(problem.getParameterSize()).thenReturn(10);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        LevenbergMarquardtOptimizer_optimize_0_1_Test.Evaluation evaluation = mock(LevenbergMarquardtOptimizer_optimize_0_1_Test.Evaluation.class);
//        double[] specificResiduals = new double[20];
//        for (int i = 0; i < 20; i++) {
//            specificResiduals[i] = i % 2 == 0 ? 1.0 : -1.0;
//        }
//        when(evaluation.getResiduals()).thenReturn(new ArrayRealVector(specificResiduals));
//        when(evaluation.getCost()).thenReturn(5.0);
//        ArrayRealVector specificPoint = new ArrayRealVector(new double[10]);
//        when(evaluation.getPoint()).thenReturn(specificPoint);
//        when(problem.evaluate(any(ArrayRealVector.class))).thenReturn(evaluation);
//
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        assertNotNull(result, "OptimumImpl should not be null");
//
//        double[] resultingResiduals = result.getResiduals().toArray();
//        assertEquals(20, resultingResiduals.length, "Weighted residuals length should match observation size");
//    }
}