package org.apache.commons.jxpath.ri.model.jdom;

import org.jdom.CDATA;
import org.jdom.Comment;
import org.jdom.Element;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class JDOMNodePointer_setValue_0_3_Test {

    @Test
    @DisplayName("node is Element and value is convertible to null String, does not add content")
    void TC11_setValue_Element_withNullStringConversion() throws Exception {
        // Arrange
        Element node = new Element("parent");
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);
        Object newValue = null; // Conversion returns null

        // Act
        pointer.setValue(newValue);

        // Assert
        assertTrue(node.getContent().isEmpty(), "No new content should be added to the node");
    }

    @Test
    @DisplayName("node is Element and value is convertible to empty String, does not add content")
    void TC12_setValue_Element_withEmptyStringConversion() throws Exception {
        // Arrange
        Element node = new Element("parent");
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);
        Object newValue = ""; // Conversion results in empty string

        // Act
        pointer.setValue(newValue);

        // Assert
        assertTrue(node.getContent().isEmpty(), "No new content should be added to the node");
    }

    @Test
    @DisplayName("node is Element and addContent is called with multiple mixed content types")
    void TC13_setValue_Element_withMultipleContentTypes() throws Exception {
        // Arrange
        Element node = new Element("parent");
        Element child1 = new Element("child1");
        Text child2 = new Text("Text Content");
        CDATA child3 = new CDATA("CDATA Content");
        ProcessingInstruction child4 = new ProcessingInstruction("target", "data");
        Comment child5 = new Comment("Sample Comment");

        Element newValue = new Element("newElement");
        newValue.addContent(child1);
        newValue.addContent(child2);
        newValue.addContent(child3);
        newValue.addContent(child4);
        newValue.addContent(child5);

        JDOMNodePointer pointer = new JDOMNodePointer(node, null);

        // Act
        pointer.setValue(newValue);

        // Assert
        // Ensure that contents are properly added to the node
        assertTrue(node.getContent().containsAll(Arrays.asList(child1, child2, child3, child4, child5)),
                "All mixed content types should be added correctly to the node");
    }
}