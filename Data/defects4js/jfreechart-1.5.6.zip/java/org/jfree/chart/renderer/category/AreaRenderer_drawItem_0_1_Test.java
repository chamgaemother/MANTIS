package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AreaRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem returns immediately when the item is not visible")
    public void TC01_drawItem_ItemNotVisible() throws Exception {
        AreaRenderer renderer = spy(new AreaRenderer()); // Use spy instead of mock
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;

        when(renderer.getItemVisible(row, column)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
        verify(renderer, never()).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("drawItem returns immediately when the dataset value is null")
    public void TC02_drawItem_NullDatasetValue() throws Exception {
        AreaRenderer renderer = spy(new AreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;

        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
        verify(renderer, never()).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

//     @Test
//     @DisplayName("drawItem proceeds with TRUNCATE endType when column is the first column")
//     public void TC03_drawItem_TRUNCATE_FirstColumn() throws Exception {
//         AreaRenderer renderer = spy(new AreaRenderer());
//         renderer.setEndType(AreaRendererEndType.TRUNCATE);
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         int row = 0;
//         int column = 0;
// 
//         when(renderer.getItemVisible(row, column)).thenReturn(true);
//         when(dataset.getValue(row, column)).thenReturn(10);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(domainAxis.getCategoryStart(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);
//         when(domainAxis.getCategoryMiddle(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
//         when(domainAxis.getCategoryEnd(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(0f);
//         when(state.getCrosshairState()).thenReturn(null);
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// 
//         ArgumentCaptor<GeneralPath> pathCaptor = ArgumentCaptor.forClass(GeneralPath.class);
//         verify(g2).fill(pathCaptor.capture());
//     }

//     @Test
//     @DisplayName("drawItem proceeds with TRUNCATE endType when column is the last column")
//     public void TC04_drawItem_TRUNCATE_LastColumn() throws Exception {
//         AreaRenderer renderer = spy(new AreaRenderer());
//         renderer.setEndType(AreaRendererEndType.TRUNCATE);
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         int row = 0;
//         int column = 4; // Adjusted to match test's assumption about column count
// 
//         when(renderer.getItemVisible(row, column)).thenReturn(true);
//         when(dataset.getValue(row, column)).thenReturn(20);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(domainAxis.getCategoryStart(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(200.0);
//         when(domainAxis.getCategoryMiddle(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(250.0);
//         when(domainAxis.getCategoryEnd(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(300.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(0f);
//         when(state.getCrosshairState()).thenReturn(null);
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// 
//         ArgumentCaptor<GeneralPath> pathCaptor = ArgumentCaptor.forClass(GeneralPath.class);
//         verify(g2).fill(pathCaptor.capture());
//     }

//     @Test
//     @DisplayName("drawItem proceeds with TRUNCATE endType when column is neither first nor last")
//     public void TC05_drawItem_TRUNCATE_MiddleColumn() throws Exception {
//         AreaRenderer renderer = spy(new AreaRenderer());
//         renderer.setEndType(AreaRendererEndType.TRUNCATE);
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         int row = 0;
//         int column = 2;
// 
//         when(renderer.getItemVisible(row, column)).thenReturn(true);
//         when(dataset.getValue(row, column)).thenReturn(30);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(domainAxis.getCategoryStart(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);
//         when(domainAxis.getCategoryMiddle(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);
//         when(domainAxis.getCategoryEnd(column, 5, dataArea, plot.getDomainAxisEdge())).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(0f);
//         when(state.getCrosshairState()).thenReturn(null);
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// 
//         ArgumentCaptor<GeneralPath> pathCaptor = ArgumentCaptor.forClass(GeneralPath.class);
//         verify(g2).fill(pathCaptor.capture());
//     }
}