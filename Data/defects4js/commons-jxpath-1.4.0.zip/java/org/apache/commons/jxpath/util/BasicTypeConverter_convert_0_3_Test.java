package org.apache.commons.jxpath.util;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.JXPathTypeConversionException;

public class BasicTypeConverter_convert_0_3_Test {

    @Test
    @DisplayName("Testing conversion of Boolean to Number (object instanceof Boolean, useType is Number.class)")
    void TC11_boolean_to_number() {
        // Initialize the converter
        BasicTypeConverter converter = new BasicTypeConverter();

        // Given
        Object object = Boolean.TRUE;
        // Ensure the target type is correct as Integer.class confirms to the logic in the method
        Class<?> toType = Integer.class;

        // When
        Object result = converter.convert(object, toType);

        // Then
        assertEquals(1, result, "The number equivalent of Boolean.TRUE should be 1");
    }

    @Test
    @DisplayName("Testing conversion when no converter is found for the given type, expecting JXPathTypeConversionException")
    void TC12_converter_missing_exception() {
        // Initialize the converter
        BasicTypeConverter converter = new BasicTypeConverter();

        // Given
        Object object = new Object();
        Class<?> toType = CustomType.class;

        // When & Then
        assertThrows(JXPathTypeConversionException.class, () -> {
            converter.convert(object, toType);
        }, "Expected JXPathTypeConversionException to be thrown when no converter is available for the target type");
    }

    // Inner class to explicitly define the CustomType used in the test
    private static class CustomType {
        // The class structure remains empty since it only serves as a type marker for the test.
    }
}