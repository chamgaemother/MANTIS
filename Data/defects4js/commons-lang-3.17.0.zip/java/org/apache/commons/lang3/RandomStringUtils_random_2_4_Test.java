package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Random;
import org.apache.commons.lang3.RandomStringUtils;

public class RandomStringUtils_random_2_4_Test {

    @Test
    @DisplayName("random(count=20, start=0, end=0, letters=false, numbers=false, chars=null, random) generates maximum length string within full Unicode range")
    public void TC21_maximum_length_unicode() {
        // GIVEN
        int count = 20;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(20, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> (c >= 0 && c <= Character.MAX_CODE_POINT)), "All characters should be within full Unicode range");
        assertTrue(result.chars().allMatch(c -> {
            int type = Character.getType(c);
            return type != Character.UNASSIGNED && type != Character.PRIVATE_USE && type != Character.SURROGATE;
        }), "All characters should not be unassigned, private use, or surrogate");
    }

    @Test
    @DisplayName("random(count=3, start=65, end=90, letters=true, numbers=true, chars={A, B, C, 1, 2, 3}, random) generates string with only specified letters and numbers")
    public void TC22_custom_alphanumerical_chars() {
        // GIVEN
        int count = 3;
        int start = 65;
        int end = 90;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = { 'A', 'B', 'C', '1', '2', '3' };
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(3, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> (Character.isLetterOrDigit(c) && new String(chars).indexOf(c) >= 0)), "All characters should be alphanumerical and from the provided chars array");
    }

    @Test
    @DisplayName("random(count=0, start=0, end=0, letters=false, numbers=false, chars=null, random) returns empty string")
    public void TC23_return_empty_string_when_count_zero() {
        // GIVEN
        int count = 0;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals("", result, "Result should be an empty string");
    }

    @Test
    @DisplayName("random(count=5, start=70, end=75, letters=true, numbers=false, chars=null, random) generates string with letters only within specified sub-range")
    public void TC24_letters_only_subrange() {
        // GIVEN
        int count = 5;
        int start = 70;
        int end = 75;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(5, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> (Character.isLetter(c) && c >= 70 && c < 75)), "All characters should be letters within the specified range");
    }

    @Test
    @DisplayName("random(count=10, start=33, end=126, letters=false, numbers=false, chars=null, random) generates string with printable characters excluding letters and numbers")
    public void TC25_printable_excluding_letters_numbers() {
        // GIVEN
        int count = 10;
        int start = 33;
        int end = 126;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(10, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> (c >= 33 && c <= 126) && !Character.isLetterOrDigit(c)), "All characters should be printable and exclude letters and numbers within the specified range");
    }

}