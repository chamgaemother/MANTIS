package com.fasterxml.jackson.databind.type;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JavaType;

import java.util.Collection;
import java.util.TreeSet;

public class TypeFactory_constructSpecializedType_1_2_Test {

    @Test
    @DisplayName("Creates specialized type for TreeSet when baseType is Collection-like and subclass is TreeSet")
    public void TC11() {
        // GIVEN
        TypeFactory typeFactory = TypeFactory.defaultInstance();
        JavaType baseType = typeFactory.constructCollectionType(Collection.class, Float.class);
        Class<?> subclass = TreeSet.class;
        boolean relaxedCompatibilityCheck = true;

        // WHEN
        JavaType result = typeFactory.constructSpecializedType(baseType, subclass, relaxedCompatibilityCheck);

        // THEN
        assertNotNull(result);
        assertEquals(TreeSet.class, result.getRawClass(), "The specialized type should have a raw class of TreeSet.");
    }
}