package com.fasterxml.jackson.databind.util;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import java.io.IOException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializable;

/**
 * Generated JUnit 5 test class for TokenBuffer#serialize method.
 */
public class TokenBuffer_serialize_2_1_Test {

    @Test
    @DisplayName("Serialize with JsonGenerator throwing IOException when writing a string token, expecting exception propagation")
    void TC44_Serialize_IOException_Propagation() throws Exception {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeFieldName("testField");
        buffer.writeString("testValue");
        
        JsonGenerator gen = mock(JsonGenerator.class);
        doThrow(new IOException("Gen failure")).when(gen).writeString("testValue");
        
        // Act & Assert
        assertThrows(IOException.class, () -> buffer.serialize(gen),
                "Expected serialize to throw IOException when JsonGenerator.writeString fails");
    }

    @Test
    @DisplayName("Serialize multiple VALUE_EMBEDDED_OBJECT tokens as JsonSerializable, ensuring each is serialized correctly")
    void TC45_Serialize_Multiple_JsonSerializable_EmbeddedObjects() throws Exception {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, false);
        
        JsonSerializable obj1 = mock(JsonSerializable.class);
        JsonSerializable obj2 = mock(JsonSerializable.class);
        
        buffer.writeObject(obj1);
        buffer.writeObject(obj2);
        
        JsonGenerator gen = mock(JsonGenerator.class);
        
        // Act
        buffer.serialize(gen);
        
        // Assert
        verify(obj1, times(1)).serialize(gen, null);
        verify(obj2, times(1)).serialize(gen, null);
        verifyNoMoreInteractions(gen);
    }
}