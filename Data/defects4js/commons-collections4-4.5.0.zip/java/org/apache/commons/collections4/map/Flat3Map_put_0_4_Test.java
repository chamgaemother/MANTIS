package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Flat3Map_put_0_4_Test {

    @Test
    @DisplayName("put when delegateMap is null and key is non-null with size 0 adds new key1")
    public void TC16() throws Exception {
        Flat3Map map = new Flat3Map();

        // Set 'delegateMap' to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set 'size' to 0
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        // Define key and value
        Object key = "key1";
        Object value = "value1";

        // Invoke the 'put' method
        Object result = map.put(key, value);

        // Access 'key1' and 'value1' via reflection
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object key1 = key1Field.get(map);

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = value1Field.get(map);

        // Assertions
        assertEquals("key1", key1, "key1 should be set to 'key1'");
        assertEquals("value1", value1, "value1 should be set to 'value1'");
        assertNull(result, "Result should be null");
    }

    @Test
    @DisplayName("put with null key when existing null key1 updates value1")
    public void TC17() throws Exception {
        Flat3Map map = new Flat3Map();

        // Set 'delegateMap' to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set 'size' to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Set 'key1' to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // Set 'value1' to 'oldValue1'
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "oldValue1");

        // Define key and value
        Object key = null;
        Object value = "newValue1";

        // Invoke the 'put' method
        Object result = map.put(key, value);

        // Access 'value1' via reflection
        Object value1 = value1Field.get(map);

        // Assertions
        assertEquals("newValue1", value1, "value1 should be updated to 'newValue1'");
        assertEquals("oldValue1", result, "Result should be 'oldValue1'");
    }

    @Test
    @DisplayName("put with non-null key when delegateMap is null and no matching keys adds new key")
    public void TC18() throws Exception {
        Flat3Map map = new Flat3Map();

        // Set 'delegateMap' to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set 'size' to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Set 'key1' and 'key2'
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        // Define key and value
        Object key = "keyNew";
        Object value = "valueNew";

        // Invoke the 'put' method
        Object result = map.put(key, value);

        // Access 'key3' and 'value3' via reflection
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object key3 = key3Field.get(map);

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object value3 = value3Field.get(map);

        // Assertions
        assertEquals("keyNew", key3, "key3 should be set to 'keyNew'");
        assertEquals("valueNew", value3, "value3 should be set to 'valueNew'");
        assertNull(result, "Result should be null");
    }
}