package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.io.CharConversionException;
import java.io.IOException;

public class UTF32Reader_read_0_3_Test {

    private UTF32Reader createReaderWithBuffer(byte[] buffer, boolean bigEndian) throws Exception {
        // Create UTF32Reader instance with necessary parameters
        UTF32Reader reader = new UTF32Reader(null, null, buffer, 0, buffer.length, bigEndian);

        // Use reflection to set private fields
        Field surrogateField = UTF32Reader.class.getDeclaredField("_surrogate");
        surrogateField.setAccessible(true);
        surrogateField.setChar(reader, UTF32Reader.NC);

        Field lengthField = UTF32Reader.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.setInt(reader, buffer.length);

        Field ptrField = UTF32Reader.class.getDeclaredField("_ptr");
        ptrField.setAccessible(true);
        ptrField.setInt(reader, 0);

        return reader;
    }

    @Test
    @DisplayName("read method with loop executing multiple iterations reading multiple characters")
    void TC11_readMultipleCharacters() throws Exception {
        char[] cbuf = new char[10];
        int start = 0;
        int len = 8;

        byte[] buffer = new byte[]{
            0x00, 0x00, 0x00, 0x41, // 'A'
            0x00, 0x00, 0x00, 0x42  // 'B'
        };

        UTF32Reader reader = createReaderWithBuffer(buffer, false);

        int result = reader.read(cbuf, start, len);

        assertEquals(2, result, "Expected to read 2 characters");
        assertEquals('A', cbuf[0], "First character should be 'A'");
        assertEquals('B', cbuf[1], "Second character should be 'B'");
        for (int i = 2; i < len; i++) {
            assertEquals('\u0000', cbuf[i], "Unused buffer positions should be null characters");
        }
    }

    @Test
    @DisplayName("read method with bigEndian true processes bytes as big endian")
    void TC12_readBigEndian() throws Exception {
        char[] cbuf = new char[4];
        int start = 0;
        int len = 4;

        byte[] buffer = new byte[]{
            0x00, 0x00, 0x00, 0x43, // 'C'
            0x00, 0x00, 0x00, 0x44  // 'D'
        };

        UTF32Reader reader = createReaderWithBuffer(buffer, true);

        int result = reader.read(cbuf, start, len);

        assertEquals(2, result, "Expected to read 2 characters");
        assertEquals('C', cbuf[0], "First character should be 'C'");
        assertEquals('D', cbuf[1], "Second character should be 'D'");
        for (int i = 2; i < len; i++) {
            assertEquals('\u0000', cbuf[i], "Unused buffer positions should be null characters");
        }
    }

    @Test
    @DisplayName("read method with hi > 0x10FFFF should report invalid character")
    void TC13_readInvalidHighSurrogate() throws Exception {
        char[] cbuf = new char[6];
        int start = 0;
        int len = 6;

        byte[] buffer = new byte[]{
            0x00, 0x11, (byte) 0x00, 0x00 // Represents a hi value > 0x10FFFF
        };

        UTF32Reader reader = createReaderWithBuffer(buffer, true);

        CharConversionException exception = assertThrows(CharConversionException.class, () -> {
            reader.read(cbuf, start, len);
        }, "Expected CharConversionException for invalid high surrogate");
        
        assertTrue(exception.getMessage().contains("Invalid UTF-32 character"), "Exception message should indicate invalid UTF-32 character");
    }
}