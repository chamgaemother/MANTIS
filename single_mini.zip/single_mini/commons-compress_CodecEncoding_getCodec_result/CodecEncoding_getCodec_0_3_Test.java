package org.apache.commons.compress.harmony.pack200;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.compress.harmony.pack200.Codec;
import org.apache.commons.compress.harmony.pack200.DefaultCodec;
import org.apache.commons.compress.harmony.pack200.RunCodec;
import org.apache.commons.compress.harmony.pack200.PopulationCodec;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;

public class CodecEncoding_getCodec_0_3_Test {

    @Test
    @DisplayName("Returns RunCodec when value is between 117-140, adef=false, bdef=true, and kbflag=true")
    void TC11_ReturnsRunCodec_117_140_adef_false_bdef_true_kbflag_true() throws Exception {
        // GIVEN
        int value = 130;
        byte[] data = { 0x09, 0x0A, 0x0B };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        Assertions.assertInstanceOf(RunCodec.class, result);
        // Additional assertions for RunCodec parameters can be added
    }

    @Test
    @DisplayName("Returns RunCodec when value is between 117-140, adef=false, bdef=true, and kbflag=false")
    void TC12_ReturnsRunCodec_117_140_adef_false_bdef_true_kbflag_false() throws Exception {
        // GIVEN
        int value = 125;
        byte[] data = { 0x0C };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        Assertions.assertInstanceOf(RunCodec.class, result);
        // Verify k is calculated using kb=3
    }

    @Test
    @DisplayName("Returns RunCodec when value is between 117-140, adef=false, bdef=false, and kbflag=true")
    void TC13_ReturnsRunCodec_117_140_adef_false_bdef_false_kbflag_true() throws Exception {
        // GIVEN
        int value = 119;
        byte[] data = { 0x0D, 0x0E, 0x0F };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        Assertions.assertInstanceOf(RunCodec.class, result);
        // Additional assertions for RunCodec parameters can be added
    }

    @Test
    @DisplayName("Throws Pack200Exception when value is less than 141 and greater than 188")
    void TC14_ThrowsPack200Exception_value_out_of_range() {
        // GIVEN
        int value = 200;
        byte[] data = {};
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN & THEN
        Pack200Exception exception = Assertions.assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        Assertions.assertEquals("Invalid codec encoding byte (200) found", exception.getMessage());
    }

    @Test
    @DisplayName("Returns PopulationCodec when value is between 141-188 and tdef is true")
    void TC15_ReturnsPopulationCodec_141_188_tdef_true() throws Exception {
        // GIVEN
        int value = 150;
        byte[] data = { 0x10, 0x11, 0x12 };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        Assertions.assertInstanceOf(PopulationCodec.class, result);
        // Additional assertions for PopulationCodec parameters can be added
    }
}