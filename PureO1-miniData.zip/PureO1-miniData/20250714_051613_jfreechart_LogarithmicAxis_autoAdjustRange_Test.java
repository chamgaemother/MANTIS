import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.data.Range;
import org.jfree.chart.axis.LogarithmicAxis;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LogarithmicAxisTest {

    private LogarithmicAxis axis;

    @Mock
    private ValueAxisPlot mockPlot;

    @BeforeEach
    void setUp() {
        axis = new LogarithmicAxis("Test Axis");
        axis.setAutoRange(false);
    }

    @Test
    void autoAdjustRange_PlotIsNull_NoAction() {
        axis.setPlot(null);
        assertDoesNotThrow(() -> axis.autoAdjustRange());
        // No range should be set
        assertNull(axis.getRange());
    }

    @Test
    void autoAdjustRange_PlotNotValueAxisPlot_NoAction() {
        Plot mockNonValuePlot = mock(Plot.class);
        axis.setPlot(mockNonValuePlot);
        assertDoesNotThrow(() -> axis.autoAdjustRange());
        // No range should be set
        assertNull(axis.getRange());
    }

    @Test
    void autoAdjustRange_DataRangeIsNull_SetsDefaultAutoRange() {
        when(mockPlot.getDataRange(axis)).thenReturn(null);
        axis.setPlot(mockPlot);
        axis.autoAdjustRange();
        Range expected = axis.getDefaultAutoRange();
        verify(mockPlot).getDataRange(axis);
        assertEquals(expected, axis.getRange());
    }

    @Test
    void autoAdjustRange_StrictValuesFlagTrue_AllowNegativesFalse_LowerBoundLessThanOrEqualZero_ThrowsException() {
        Range dataRange = new Range(-10.0, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setStrictValuesFlag(true);
        axis.setAllowNegativesFlag(false);
        RuntimeException exception = assertThrows(RuntimeException.class, () -> axis.autoAdjustRange());
        assertTrue(exception.getMessage().contains("Values less than or equal to zero not allowed with logarithmic axis"));
    }

    @Test
    void autoAdjustRange_StrictValuesFlagFalse_AllowNegativesFalse_LowerBoundLessThanOrEqualZero_AdjustsRange() {
        Range dataRange = new Range(-10.0, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setStrictValuesFlag(false);
        axis.setAllowNegativesFlag(false);
        axis.autoAdjustRange();
        // Since allowNegativesFlag is false, it should adjust lower bound
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getLowerBound() >= 0.0);
    }

    @Test
    void autoAdjustRange_AllowNegativesTrue_AdjustsRangeWithNegativeValues() {
        Range dataRange = new Range(-100.0, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(true);
        axis.setStrictValuesFlag(false);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertEquals(-100.0, adjustedRange.getLowerBound());
        assertEquals(100.0, adjustedRange.getUpperBound());
    }

    @Test
    void autoAdjustRange_AutoRangeNextLogFlagTrue_ComputesLogFloorAndLogCeil() {
        Range dataRange = new Range(5.0, 500.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAutoRangeNextLogFlag(true);
        axis.autoAdjustRange();
        ArgumentCaptor<Range> rangeCaptor = ArgumentCaptor.forClass(Range.class);
        verify(axis, times(1)).setRange(rangeCaptor.capture());
        Range capturedRange = rangeCaptor.getValue();
        assertEquals(1.0, capturedRange.getLowerBound());
        assertEquals(1000.0, capturedRange.getUpperBound());
    }

    @Test
    void autoAdjustRange_AutoRangeNextLogFlagFalse_UsesCeilAndFloor() {
        Range dataRange = new Range(15.0, 150.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAutoRangeNextLogFlag(false);
        axis.autoAdjustRange();
        ArgumentCaptor<Range> rangeCaptor = ArgumentCaptor.forClass(Range.class);
        verify(axis, times(1)).setRange(rangeCaptor.capture());
        Range capturedRange = rangeCaptor.getValue();
        assertEquals(10.0, capturedRange.getLowerBound());
        assertEquals(200.0, capturedRange.getUpperBound());
    }

    @Test
    void autoAdjustRange_LowerMarginAppliedCorrectly() {
        Range dataRange = new Range(20.0, 200.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setLowerMargin(0.1);
        axis.setAutoRangeNextLogFlag(false);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getLowerBound() < 20.0);
    }

    @Test
    void autoAdjustRange_UpperMarginAppliedCorrectly() {
        Range dataRange = new Range(20.0, 200.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setUpperMargin(0.1);
        axis.setAutoRangeNextLogFlag(false);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getUpperBound() > 200.0);
    }

    @Test
    void autoAdjustRange_MinRangeEnforcedWhenRangeTooSmall() {
        Range dataRange = new Range(100.0, 100.5);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAutoRangeMinimumSize(1.0);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getUpperBound() - adjustedRange.getLowerBound() >= 1.0);
    }

    @Test
    void autoAdjustRange_MinRangeAdjustedWithSmallAdjustmentWhenNeeded() {
        Range dataRange = new Range(0.0, 0.001);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(false);
        axis.setAutoRangeMinimumSize(0.01);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getUpperBound() - adjustedRange.getLowerBound() >= 0.01);
    }

    @Test
    void autoAdjustRange_SmallLogFlagTrue_AdjustsLowerBound() {
        Range dataRange = new Range(1.0, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.autoAdjustRange();
        // smallLogFlag should be false because lower bound is 1.0, not between 0 and 10
        assertFalse(axis.smallLogFlag);
    }

    @Test
    void autoAdjustRange_SmallLogFlagFalse_LowerBoundNotAdjustedForSmallValues() {
        Range dataRange = new Range(0.5, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(false);
        axis.autoAdjustRange();
        // smallLogFlag should be true because lower bound is between 0 and 10
        assertTrue(axis.smallLogFlag);
    }

    @Test
    void autoAdjustRange_AllowNegativesFalse_LowerBoundLessThanSmallLogValue_NotAdjusted() {
        Range dataRange = new Range(0.0000001, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(false);
        axis.autoAdjustRange();
        // Should set lower to original lower bound since it's already below SMALL_LOG_VALUE
        assertEquals(0.0000001, axis.getRange().getLowerBound());
    }

    @Test
    void autoAdjustRange_AllowNegativesTrue_LowerBoundNegative_AdjustsCorrectly() {
        Range dataRange = new Range(-100.0, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(true);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertEquals(-100.0, adjustedRange.getLowerBound());
        assertEquals(100.0, adjustedRange.getUpperBound());
    }

    @Test
    void autoAdjustRange_ZeroIncludedAndAllowNegativesFalse_AdjustsZeroCorrectly() {
        Range dataRange = new Range(0.0, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(false);
        axis.setStrictValuesFlag(false);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getLowerBound() >= 0.0);
    }

    @Test
    void autoAdjustRange_AutoRangeMinimumSizeVerySmall_AdjustsRangeProperly() {
        Range dataRange = new Range(1.0, 1.000001);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAutoRangeMinimumSize(1e-7);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getUpperBound() - adjustedRange.getLowerBound() >= 1e-7);
    }

    @Test
    void autoAdjustRange_LowerBoundExactlySmallLogValue_DoesNotAdjust() {
        Range dataRange = new Range(1e-100, 100.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(false);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertEquals(1e-100, adjustedRange.getLowerBound());
    }

    @Test
    void autoAdjustRange_UpperBoundLessThanOneAndAllowNegativesFalse_AdjustsUpperBoundCorrectly() {
        Range dataRange = new Range(0.1, 0.9);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAllowNegativesFlag(false);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertTrue(adjustedRange.getUpperBound() >= 0.9);
    }

    @Test
    void autoAdjustRange_AutoRangeNextLogFlagTrue_AdjustsUpperBoundWithComputeLogCeil() {
        Range dataRange = new Range(5.0, 50.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAutoRangeNextLogFlag(true);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertEquals(1.0, adjustedRange.getLowerBound());
        assertEquals(100.0, adjustedRange.getUpperBound());
    }

    @Test
    void autoAdjustRange_AutoRangeNextLogFlagFalse_AdjustsUpperBoundWithCeil() {
        Range dataRange = new Range(15.0, 150.0);
        when(mockPlot.getDataRange(axis)).thenReturn(dataRange);
        axis.setPlot(mockPlot);
        axis.setAutoRangeNextLogFlag(false);
        axis.autoAdjustRange();
        Range adjustedRange = axis.getRange();
        assertEquals(10.0, adjustedRange.getLowerBound());
        assertEquals(200.0, adjustedRange.getUpperBound());
    }
}