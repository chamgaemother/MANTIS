package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;

public class NumberInput_parseInt_0_2_Test {

    @Test
    @DisplayName("parseInt with more than 10 characters including '-' defers to Integer.parseInt")
    void testTC06() throws Exception {
        // Arrange
        String s = "-1234567890";
        Method parseIntMethod = NumberInput.class.getDeclaredMethod("parseInt", String.class);
        parseIntMethod.setAccessible(true);

        // Act
        int result = (int) parseIntMethod.invoke(null, s);
        int expected = Integer.parseInt(s);

        // Assert
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("parseInt with non-digit character at the start defers to Integer.parseInt")
    void testTC07() throws Exception {
        // Arrange
        String s = "a123";
        Method parseIntMethod = NumberInput.class.getDeclaredMethod("parseInt", String.class);
        parseIntMethod.setAccessible(true);

        // Act & Assert
        assertThrows(NumberFormatException.class, () -> {
            parseIntMethod.invoke(null, s);
        });
    }

    @Test
    @DisplayName("parseInt with non-digit character in the middle defers to Integer.parseInt")
    void testTC08() throws Exception {
        // Arrange
        String s = "12a4";
        Method parseIntMethod = NumberInput.class.getDeclaredMethod("parseInt", String.class);
        parseIntMethod.setAccessible(true);

        // Act & Assert
        assertThrows(NumberFormatException.class, () -> {
            parseIntMethod.invoke(null, s);
        });
    }

    @Test
    @DisplayName("parseInt with non-digit character at the end defers to Integer.parseInt")
    void testTC09() throws Exception {
        // Arrange
        String s = "123a";
        Method parseIntMethod = NumberInput.class.getDeclaredMethod("parseInt", String.class);
        parseIntMethod.setAccessible(true);

        // Act & Assert
        assertThrows(NumberFormatException.class, () -> {
            parseIntMethod.invoke(null, s);
        });
    }

    @Test
    @DisplayName("parseInt with empty string defers to Integer.parseInt")
    void testTC10() throws Exception {
        // Arrange
        String s = "";
        Method parseIntMethod = NumberInput.class.getDeclaredMethod("parseInt", String.class);
        parseIntMethod.setAccessible(true);

        // Act & Assert
        assertThrows(NumberFormatException.class, () -> {
            parseIntMethod.invoke(null, s);
        });
    }
}