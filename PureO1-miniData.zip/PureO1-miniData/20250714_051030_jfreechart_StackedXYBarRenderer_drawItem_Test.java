import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class StackedXYBarRendererTest {

    private StackedXYBarRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;
    private EntityCollection entities;

    @BeforeEach
    public void setUp() {
        renderer = new StackedXYBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(IntervalXYDataset.class, TableXYDataset.class);
        crosshairState = mock(CrosshairState.class);
        entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM)))
            .thenAnswer(invocation -> {
                double val = invocation.getArgument(0);
                return val;
            });
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenAnswer(invocation -> {
                double val = invocation.getArgument(0);
                return val;
            });
    }

    @Test
    public void testDrawItem_ItemNotVisible() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItem_InvalidDataset_NotIntervalXYDataset() {
        XYDataset invalidDataset = mock(XYDataset.class);
        assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, invalidDataset, 0, 0, crosshairState, 1);
        });
    }

    @Test
    public void testDrawItem_InvalidDataset_NotTableXYDataset() {
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        XYDataset invalidDataset = mock(XYDataset.class, withSettings().extraInterfaces(IntervalXYDataset.class));
        when(((IntervalXYDataset) invalidDataset).getYValue(anyInt(), anyInt())).thenReturn(1.0);
        assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, invalidDataset, 0, 0, crosshairState, 1);
        });
    }

    @Test
    public void testDrawItem_YValueNaN() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        verifyNoInteractions(g2);
    }

    @Test
    public void testDrawItem_RenderAsPercentagesTrue() {
        renderer.setRenderAsPercentages(true);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(2.0);
        when(((TableXYDataset) dataset).getYValue(anyInt(), anyInt())).thenReturn(2.0, 3.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
        verify(dataset, atLeastOnce()).getYValue(anyInt(), anyInt());
    }

    @Test
    public void testDrawItem_RenderAsPercentagesFalse() {
        renderer.setRenderAsPercentages(false);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(2.0);
        when(((TableXYDataset) dataset).getYValue(anyInt(), anyInt())).thenReturn(2.0, 3.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
        verify(dataset, atLeastOnce()).getYValue(anyInt(), anyInt());
    }

    @Test
    public void testDrawItem_VerticalOrientation_PositiveValue_NotInverted() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(5.0);
        when(((TableXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        verify(dataset).getYValue(0, 0);
    }

    @Test
    public void testDrawItem_HorizontalOrientation_NegativeValue_Inverted() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(-3.0);
        when(((TableXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
        verify(dataset).getYValue(0, 0);
    }

    @Test
    public void testDrawItem_Pass0_ShadowsVisible() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(renderer.getShadowsVisible()).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(4.0);
        when(((TableXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2).draw(any());
    }

    @Test
    public void testDrawItem_Pass1_BarsVisible() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(4.0);
        when(((TableXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        verify(g2).fill(any());
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_Pass2_ItemLabelVisible() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        renderer.setDefaultItemLabelGenerator(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(4.0);
        when(((TableXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 2);
        verify(renderer).drawItemLabel(any(), any(), anyInt(), anyInt(), any(), any(), anyBoolean());
    }

    @Test
    public void testDrawItem_FullyStackedSeries() {
        renderer.setRenderAsPercentages(true);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(1.0);
        when(((IntervalXYDataset) dataset).getYValue(1, 0)).thenReturn(2.0);
        when(((TableXYDataset) dataset).getYValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getYValue(1, 0)).thenReturn(2.0);
        when(((TableXYDataset) dataset).getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
        verify(dataset, atLeastOnce()).getYValue(anyInt(), anyInt());
    }

    @Test
    public void testDrawItem_MarginApplied() {
        renderer.setMargin(0.1);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(3.0);
        when(((TableXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        verify(dataset).getYValue(0, 0);
    }

    @Test
    public void testDrawItem_SeriesInvisible() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(renderer.isSeriesVisible(1)).thenReturn(false);
        when(((IntervalXYDataset) dataset).getYValue(1, 0)).thenReturn(5.0);
        when(((TableXYDataset) dataset).getStartXValue(1, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(1, 0)).thenReturn(2.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
        verify(dataset).getYValue(1, 0);
    }

    @Test
    public void testEquals_Symmetric() {
        StackedXYBarRenderer other = new StackedXYBarRenderer();
        assertEquals(renderer, other);
        renderer.setRenderAsPercentages(true);
        assertNotEquals(renderer, other);
        other.setRenderAsPercentages(true);
        assertEquals(renderer, other);
    }

    @Test
    public void testHashCode_Consistency() {
        int hash1 = renderer.hashCode();
        int hash2 = renderer.hashCode();
        assertEquals(hash1, hash2);
        renderer.setRenderAsPercentages(true);
        int hash3 = renderer.hashCode();
        assertNotEquals(hash1, hash3);
    }

    @Test
    public void testDrawItem_NullGraphics() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(null, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        });
    }

    @Test
    public void testDrawItem_NullDataset() {
        assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, crosshairState, 1);
        });
    }

    @Test
    public void testDrawItem_PassInvalid() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(((IntervalXYDataset) dataset).getYValue(0, 0)).thenReturn(4.0);
        when(((TableXYDataset) dataset).getStartXValue(0, 0)).thenReturn(1.0);
        when(((TableXYDataset) dataset).getEndXValue(0, 0)).thenReturn(2.0);
        assertThrows(IllegalStateException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 3);
        });
    }
}