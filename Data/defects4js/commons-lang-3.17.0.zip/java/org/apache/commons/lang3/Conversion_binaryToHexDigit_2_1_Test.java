package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.lang3.Conversion;

public class Conversion_binaryToHexDigit_2_1_Test {

    @Test
    @DisplayName("Throws ArrayIndexOutOfBoundsException when srcPos is negative")
    void testTC25_binaryToHexDigit_withNegativeSrcPos() {
        boolean[] src = {true, true, true, true};
        int srcPos = -1;
        Assertions.assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            Conversion.binaryToHexDigit(src, srcPos);
        });
    }

    @Test
    @DisplayName("Returns '0' when src.length equals srcPos and the single bit is false")
    void testTC26_binaryToHexDigit_withSrcLengthEqualsSrcPosAndFalseBit() {
        boolean[] src = {false};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        Assertions.assertEquals('0', result);
    }
}