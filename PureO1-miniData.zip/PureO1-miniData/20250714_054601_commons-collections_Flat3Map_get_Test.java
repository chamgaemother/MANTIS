import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Flat3MapTest {

    private Flat3Map<String, String> map;

    @BeforeEach
    void setUp() {
        map = new Flat3Map<>();
    }

    @Test
    void testGetDelegateMapNotNullKeyPresent() {
        map.put("key1", "value1");
        map.put("key2", "value2");
   	 	map.put("key3", "value3");
   	 	map.put("key4", "value4"); // Triggers delegateMap
        assertEquals("value4", map.get("key4"));
    }

    @Test
    void testGetDelegateMapNotNullKeyAbsent() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4"); // Triggers delegateMap
        assertNull(map.get("key5"));
    }

    @Test
    void testGetNullKeySize1KeyNull() {
        map.put(null, "nullValue");
        assertEquals("nullValue", map.get(null));
    }

    @Test
    void testGetNullKeySize1KeyNotNull() {
        map.put("key1", "value1");
        assertNull(map.get(null));
    }

    @Test
    void testGetNullKeySize2Key2Null() {
        map.put("key1", "value1");
        map.put(null, "nullValue2");
        assertEquals("nullValue2", map.get(null));
    }

    @Test
    void testGetNullKeySize2Key2NotNullKey1Null() {
        map.put(null, "nullValue1");
        map.put("key2", "value2");
        assertEquals("nullValue1", map.get(null));
    }

    @Test
    void testGetNullKeySize3Key3Null() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put(null, "nullValue3");
        assertEquals("nullValue3", map.get(null));
    }

    @Test
    void testGetNullKeySize3Key3NotNullKey2Null() {
        map.put("key1", "value1");
        map.put(null, "nullValue2");
        map.put("key3", "value3");
        assertEquals("nullValue2", map.get(null));
    }

    @Test
    void testGetNullKeySize3AllKeysNotNull() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertNull(map.get(null));
    }

    @Test
    void testGetNonNullKeySize1KeyMatches() {
        map.put("key1", "value1");
        assertEquals("value1", map.get("key1"));
    }

    @Test
    void testGetNonNullKeySize1KeyDoesNotMatch() {
        map.put("key1", "value1");
        assertNull(map.get("key2"));
    }

    @Test
    void testGetNonNullKeySize2Key2Matches() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testGetNonNullKeySize2Key1Matches() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        assertEquals("value1", map.get("key1"));
    }

    @Test
    void testGetNonNullKeySize2NoMatch() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        assertNull(map.get("key3"));
    }

    @Test
    void testGetNonNullKeySize3Key3Matches() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertEquals("value3", map.get("key3"));
    }

    @Test
    void testGetNonNullKeySize3Key2Matches() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testGetNonNullKeySize3Key1Matches() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertEquals("value1", map.get("key1"));
    }

    @Test
    void testGetNonNullKeySize3NoMatch() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertNull(map.get("key4"));
    }

    @Test
    void testGetWhenEmpty() {
        assertNull(map.get("anyKey"));
        assertNull(map.get(null));
    }

    @Test
    void testGetWithDelegateMapNullAfterClear() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4"); // Triggers delegateMap
        map.clear();
        assertNull(map.get("key1"));
        assertNull(map.get(null));
    }

    @Test
    void testGetAfterConvertToMap() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4"); // Triggers delegateMap
        map.put("key5", "value5");
        assertEquals("value4", map.get("key4"));
        assertEquals("value5", map.get("key5"));
        assertNull(map.get("key1"));
    }

    @Test
    void testGetWithNullKeyInDelegateMap() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put(null, "nullValue");
        map.put("key4", "value4"); // Triggers delegateMap
        assertEquals("nullValue", map.get(null));
    }

    @Test
    void testGetWithHashCollision() {
        String key1 = "FB"; // "FB".hashCode() == "Ea".hashCode()
        String key2 = "Ea";
        map.put(key1, "value1");
        map.put(key2, "value2");
        assertEquals("value1", map.get(key1));
        assertEquals("value2", map.get(key2));
    }

    @Test
    void testGetWithDifferentObjectTypes() {
        map.put("key1", "value1");
        map.put(123, "numberValue");
        map.put(null, "nullValue");
        assertEquals("numberValue", map.get(123));
        assertEquals("value1", map.get("key1"));
        assertEquals("nullValue", map.get(null));
        assertNull(map.get(456));
    }

    @Test
    void testGetWithDuplicateKeys() {
        map.put("key1", "value1");
        map.put("key1", "value2");
        assertEquals("value2", map.get("key1"));
    }

    @Test
    void testGetWithNullAndNonNullKeys() {
        map.put(null, "nullValue");
        map.put("key1", "value1");
        assertEquals("nullValue", map.get(null));
        assertEquals("value1", map.get("key1"));
    }

    @Test
    void testGetAfterRemovingKey() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.remove("key1");
        assertNull(map.get("key1"));
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testGetAfterUpdatingValue() {
        map.put("key1", "value1");
        map.put("key1", "valueUpdated");
        assertEquals("valueUpdated", map.get("key1"));
    }

    @Test
    void testGetWithMultipleNullValues() {
        map.put(null, "nullValue1");
        map.put("key1", "value1");
        map.put(null, "nullValue2");
        assertEquals("nullValue2", map.get(null));
    }

    @Test
    void testGetWithKeysHavingSameHashCode() {
        String key1 = "Aa";
        String key2 = "BB";
        assertEquals(key1.hashCode(), key2.hashCode());
        map.put(key1, "value1");
        map.put(key2, "value2");
        assertEquals("value1", map.get(key1));
        assertEquals("value2", map.get(key2));
    }
}