package org.apache.commons.compress.archivers.sevenz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.Collections;

public class SevenZArchiveEntry_equals_0_4_Test {

    @Test
    @DisplayName("equals called with different windowsAttributes value returns false")
    public void test_TC16_equals_different_windowsAttributes_returns_false() {
        // GIVEN
        String name = "entryName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.from(Instant.now());
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.from(Instant.now());
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.from(Instant.now());
        boolean hasWindowsAttributes = true;
        int windowsAttributes1 = 0x1A2B;
        int windowsAttributes2 = 0x1A2C;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc = 11111L;
        long size = 1000L;
        long compressedSize = 500L;
        Iterable<SevenZMethodConfiguration> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName(name);
        entry1.setHasStream(hasStream);
        entry1.setDirectory(isDirectory);
        entry1.setAntiItem(isAntiItem);
        entry1.setHasCreationDate(hasCreationDate);
        entry1.setCreationTime(creationDate);
        entry1.setHasLastModifiedDate(hasLastModifiedDate);
        entry1.setLastModifiedTime(lastModifiedDate);
        entry1.setHasAccessDate(hasAccessDate);
        entry1.setAccessTime(accessDate);
        entry1.setHasWindowsAttributes(hasWindowsAttributes);
        entry1.setWindowsAttributes(windowsAttributes1);
        entry1.setHasCrc(hasCrc);
        entry1.setCrcValue(crc);
        entry1.setCompressedCrcValue(compressedCrc);
        entry1.setSize(size);
        entry1.setCompressedSize(compressedSize);
        entry1.setContentMethods(contentMethods);

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName(name);
        entry2.setHasStream(hasStream);
        entry2.setDirectory(isDirectory);
        entry2.setAntiItem(isAntiItem);
        entry2.setHasCreationDate(hasCreationDate);
        entry2.setCreationTime(creationDate);
        entry2.setHasLastModifiedDate(hasLastModifiedDate);
        entry2.setLastModifiedTime(lastModifiedDate);
        entry2.setHasAccessDate(hasAccessDate);
        entry2.setAccessTime(accessDate);
        entry2.setHasWindowsAttributes(hasWindowsAttributes);
        entry2.setWindowsAttributes(windowsAttributes2);
        entry2.setHasCrc(hasCrc);
        entry2.setCrcValue(crc);
        entry2.setCompressedCrcValue(compressedCrc);
        entry2.setSize(size);
        entry2.setCompressedSize(compressedSize);
        entry2.setContentMethods(contentMethods);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different hasCrc field returns false")
    public void test_TC17_equals_different_hasCrc_returns_false() {
        // GIVEN
        String name = "entryName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.from(Instant.now());
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.from(Instant.now());
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.from(Instant.now());
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0x1A2B;
        boolean hasCrc1 = true;
        long crc1 = 12345L;
        boolean hasCrc2 = false;
        long crc2 = 67890L;
        long compressedCrc = 22222L;
        long size = 2000L;
        long compressedSize = 1000L;
        Iterable<SevenZMethodConfiguration> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName(name);
        entry1.setHasStream(hasStream);
        entry1.setDirectory(isDirectory);
        entry1.setAntiItem(isAntiItem);
        entry1.setHasCreationDate(hasCreationDate);
        entry1.setCreationTime(creationDate);
        entry1.setHasLastModifiedDate(hasLastModifiedDate);
        entry1.setLastModifiedTime(lastModifiedDate);
        entry1.setHasAccessDate(hasAccessDate);
        entry1.setAccessTime(accessDate);
        entry1.setHasWindowsAttributes(hasWindowsAttributes);
        entry1.setWindowsAttributes(windowsAttributes);
        entry1.setHasCrc(hasCrc1);
        entry1.setCrcValue(crc1);
        entry1.setCompressedCrcValue(compressedCrc);
        entry1.setSize(size);
        entry1.setCompressedSize(compressedSize);
        entry1.setContentMethods(contentMethods);

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName(name);
        entry2.setHasStream(hasStream);
        entry2.setDirectory(isDirectory);
        entry2.setAntiItem(isAntiItem);
        entry2.setHasCreationDate(hasCreationDate);
        entry2.setCreationTime(creationDate);
        entry2.setHasLastModifiedDate(hasLastModifiedDate);
        entry2.setLastModifiedTime(lastModifiedDate);
        entry2.setHasAccessDate(hasAccessDate);
        entry2.setAccessTime(accessDate);
        entry2.setHasWindowsAttributes(hasWindowsAttributes);
        entry2.setWindowsAttributes(windowsAttributes);
        entry2.setHasCrc(hasCrc2);
        entry2.setCrcValue(crc2);
        entry2.setCompressedCrcValue(compressedCrc);
        entry2.setSize(size);
        entry2.setCompressedSize(compressedSize);
        entry2.setContentMethods(contentMethods);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different crc value returns false")
    public void test_TC18_equals_different_crc_returns_false() {
        // GIVEN
        String name = "entryName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.from(Instant.now());
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.from(Instant.now());
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.from(Instant.now());
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0x1A2B;
        boolean hasCrc = true;
        long crc1 = 12345L;
        long crc2 = 67890L;
        long compressedCrc = 33333L;
        long size = 3000L;
        long compressedSize = 1500L;
        Iterable<SevenZMethodConfiguration> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName(name);
        entry1.setHasStream(hasStream);
        entry1.setDirectory(isDirectory);
        entry1.setAntiItem(isAntiItem);
        entry1.setHasCreationDate(hasCreationDate);
        entry1.setCreationTime(creationDate);
        entry1.setHasLastModifiedDate(hasLastModifiedDate);
        entry1.setLastModifiedTime(lastModifiedDate);
        entry1.setHasAccessDate(hasAccessDate);
        entry1.setAccessTime(accessDate);
        entry1.setHasWindowsAttributes(hasWindowsAttributes);
        entry1.setWindowsAttributes(windowsAttributes);
        entry1.setHasCrc(hasCrc);
        entry1.setCrcValue(crc1);
        entry1.setCompressedCrcValue(compressedCrc);
        entry1.setSize(size);
        entry1.setCompressedSize(compressedSize);
        entry1.setContentMethods(contentMethods);

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName(name);
        entry2.setHasStream(hasStream);
        entry2.setDirectory(isDirectory);
        entry2.setAntiItem(isAntiItem);
        entry2.setHasCreationDate(hasCreationDate);
        entry2.setCreationTime(creationDate);
        entry2.setHasLastModifiedDate(hasLastModifiedDate);
        entry2.setLastModifiedTime(lastModifiedDate);
        entry2.setHasAccessDate(hasAccessDate);
        entry2.setAccessTime(accessDate);
        entry2.setHasWindowsAttributes(hasWindowsAttributes);
        entry2.setWindowsAttributes(windowsAttributes);
        entry2.setHasCrc(hasCrc);
        entry2.setCrcValue(crc2);
        entry2.setCompressedCrcValue(compressedCrc);
        entry2.setSize(size);
        entry2.setCompressedSize(compressedSize);
        entry2.setContentMethods(contentMethods);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different compressedCrc value returns false")
    public void test_TC19_equals_different_compressedCrc_returns_false() {
        // GIVEN
        String name = "entryName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.from(Instant.now());
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.from(Instant.now());
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.from(Instant.now());
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0x1A2B;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc1 = 11111L;
        long compressedCrc2 = 22222L;
        long size = 4000L;
        long compressedSize = 2000L;
        Iterable<SevenZMethodConfiguration> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName(name);
        entry1.setHasStream(hasStream);
        entry1.setDirectory(isDirectory);
        entry1.setAntiItem(isAntiItem);
        entry1.setHasCreationDate(hasCreationDate);
        entry1.setCreationTime(creationDate);
        entry1.setHasLastModifiedDate(hasLastModifiedDate);
        entry1.setLastModifiedTime(lastModifiedDate);
        entry1.setHasAccessDate(hasAccessDate);
        entry1.setAccessTime(accessDate);
        entry1.setHasWindowsAttributes(hasWindowsAttributes);
        entry1.setWindowsAttributes(windowsAttributes);
        entry1.setHasCrc(hasCrc);
        entry1.setCrcValue(crc);
        entry1.setCompressedCrcValue(compressedCrc1);
        entry1.setSize(size);
        entry1.setCompressedSize(compressedSize);
        entry1.setContentMethods(contentMethods);

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName(name);
        entry2.setHasStream(hasStream);
        entry2.setDirectory(isDirectory);
        entry2.setAntiItem(isAntiItem);
        entry2.setHasCreationDate(hasCreationDate);
        entry2.setCreationTime(creationDate);
        entry2.setHasLastModifiedDate(hasLastModifiedDate);
        entry2.setLastModifiedTime(lastModifiedDate);
        entry2.setHasAccessDate(hasAccessDate);
        entry2.setAccessTime(accessDate);
        entry2.setHasWindowsAttributes(hasWindowsAttributes);
        entry2.setWindowsAttributes(windowsAttributes);
        entry2.setHasCrc(hasCrc);
        entry2.setCrcValue(crc);
        entry2.setCompressedCrcValue(compressedCrc2);
        entry2.setSize(size);
        entry2.setCompressedSize(compressedSize);
        entry2.setContentMethods(contentMethods);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different size value returns false")
    public void test_TC20_equals_different_size_returns_false() {
        // GIVEN
        String name = "entryName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.from(Instant.now());
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.from(Instant.now());
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.from(Instant.now());
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0x1A2B;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc = 33333L;
        long size1 = 1000L;
        long size2 = 2000L;
        long compressedSize = 2500L;
        Iterable<SevenZMethodConfiguration> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName(name);
        entry1.setHasStream(hasStream);
        entry1.setDirectory(isDirectory);
        entry1.setAntiItem(isAntiItem);
        entry1.setHasCreationDate(hasCreationDate);
        entry1.setCreationTime(creationDate);
        entry1.setHasLastModifiedDate(hasLastModifiedDate);
        entry1.setLastModifiedTime(lastModifiedDate);
        entry1.setHasAccessDate(hasAccessDate);
        entry1.setAccessTime(accessDate);
        entry1.setHasWindowsAttributes(hasWindowsAttributes);
        entry1.setWindowsAttributes(windowsAttributes);
        entry1.setHasCrc(hasCrc);
        entry1.setCrcValue(crc);
        entry1.setCompressedCrcValue(compressedCrc);
        entry1.setSize(size1);
        entry1.setCompressedSize(compressedSize);
        entry1.setContentMethods(contentMethods);

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName(name);
        entry2.setHasStream(hasStream);
        entry2.setDirectory(isDirectory);
        entry2.setAntiItem(isAntiItem);
        entry2.setHasCreationDate(hasCreationDate);
        entry2.setCreationTime(creationDate);
        entry2.setHasLastModifiedDate(hasLastModifiedDate);
        entry2.setLastModifiedTime(lastModifiedDate);
        entry2.setHasAccessDate(hasAccessDate);
        entry2.setAccessTime(accessDate);
        entry2.setHasWindowsAttributes(hasWindowsAttributes);
        entry2.setWindowsAttributes(windowsAttributes);
        entry2.setHasCrc(hasCrc);
        entry2.setCrcValue(crc);
        entry2.setCompressedCrcValue(compressedCrc);
        entry2.setSize(size2);
        entry2.setCompressedSize(compressedSize);
        entry2.setContentMethods(contentMethods);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }
}
