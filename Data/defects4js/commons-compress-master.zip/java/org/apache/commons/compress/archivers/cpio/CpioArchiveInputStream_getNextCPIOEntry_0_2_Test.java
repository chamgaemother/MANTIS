package org.apache.commons.compress.archivers.cpio;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Field;

import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveEntry;

public class CpioArchiveInputStream_getNextCPIOEntry_0_2_Test {

    @Test
    @DisplayName("Processes MAGIC_OLD_ASCII signature")
    public void TC06_processes_MAGIC_OLD_ASCII_signature() throws Exception {
        // Given
        byte[] magicOldAscii = "070707".getBytes(); // Replace with actual MAGIC_OLD_ASCII bytes
        ByteArrayInputStream bais = new ByteArrayInputStream(magicOldAscii);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(bais);

        // When
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Then
        assertNotNull(entry, "Entry should not be null");
        assertEquals("070707", entry.getFormat(), "Entry format should be MAGIC_OLD_ASCII");

        // Verify entryEOF via reflection
        Field entryEOFField = CpioArchiveInputStream.class.getDeclaredField("entryEOF");
        entryEOFField.setAccessible(true);
        boolean entryEOF = entryEOFField.getBoolean(cpioInputStream);
        assertFalse(entryEOF, "entryEOF should be false");
    }

    @Test
    @DisplayName("Throws IOException for unknown magic string")
    public void TC07_throws_IOException_for_unknown_magic_string() throws Exception {
        // Given
        byte[] unknownMagic = "UNKNOWN".getBytes(); // Replace with actual unknown magic bytes
        ByteArrayInputStream bais = new ByteArrayInputStream(unknownMagic);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(bais);

        // When & Then
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        }, "Expected getNextCPIOEntry() to throw IOException for unknown magic string");
        assertTrue(exception.getMessage().contains("Unknown magic"), "Exception message should indicate unknown magic");
    }

    @Test
    @DisplayName("Handles entry name equal to CPIO_TRAILER by setting entryEOF and returning null")
    public void TC08_handles_CPIO_TRAILER_entry_name() throws Exception {
        // Given
        byte[] magicNew = "070701".getBytes(); // Replace with actual MAGIC_NEW bytes
        ByteArrayInputStream bais = new ByteArrayInputStream(magicNew);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(bais);

        // Mock the read methods to return a CPIO_TRAILER entry
        // This may require additional setup or mocking frameworks like Mockito

        // When
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Then
        // Verify entryEOF via reflection
        Field entryEOFField = CpioArchiveInputStream.class.getDeclaredField("entryEOF");
        entryEOFField.setAccessible(true);
        boolean entryEOF = entryEOFField.getBoolean(cpioInputStream);
        assertTrue(entryEOF, "entryEOF should be true when entry name is CPIO_TRAILER");
        assertNull(entry, "Entry should be null when entry name is CPIO_TRAILER");
    }

    @Test
    @DisplayName("Throws IOException when entry size is negative in new entry")
    public void TC09_throws_IOException_for_negative_entry_size() throws Exception {
        // Given
        byte[] magicNewWithNegativeSize = "070701".getBytes(); // Replace with actual bytes for MAGIC_NEW with negative size
        ByteArrayInputStream bais = new ByteArrayInputStream(magicNewWithNegativeSize);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(bais);

        // Mock the read methods to return a negative size
        // This may require additional setup or mocking frameworks like Mockito

        // When & Then
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        }, "Expected getNextCPIOEntry() to throw IOException for negative entry size");
        assertTrue(exception.getMessage().contains("negative length"), "Exception message should indicate negative entry size");
    }

    @Test
    @DisplayName("Throws IOException when skipping header pad count mismatches")
    public void TC10_throws_IOException_for_header_pad_count_mismatch() throws Exception {
        // Given
        byte[] magicNewWithBadPad = "070701".getBytes(); // Replace with actual bytes for MAGIC_NEW with bad header pad count
        ByteArrayInputStream bais = new ByteArrayInputStream(magicNewWithBadPad);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(bais);

        // Mock the skip method to cause a header pad count mismatch
        // This may require additional setup or mocking frameworks like Mockito

        // When & Then
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        }, "Expected getNextCPIOEntry() to throw IOException for header pad count mismatch");
        assertTrue(exception.getMessage().contains("Header pad count mismatch"), "Exception message should indicate header pad count mismatch");
    }
}