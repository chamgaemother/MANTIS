// package org.jfree.chart.entity;
// 
// import org.jfree.chart.imagemap.ToolTipTagFragmentGenerator;
// import org.jfree.chart.imagemap.URLTagFragmentGenerator;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import java.awt.Shape;
// import java.awt.geom.Ellipse2D;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// public class ChartEntity_getImageMapAreaTag_0_3_Test {
// 
// //     @Test
// //     @DisplayName("When area is not Rectangle2D, urlText and toolTipText are non-null and not empty, generate area tag with shape=\"poly\"")
// //     void TC11() throws Exception {
//         // GIVEN
// //         String urlText = "http://example.com";
// //         String toolTipText = "Tooltip text";
// //         Shape area = new Ellipse2D.Double();
//         // Corrected the order of constructor arguments
// //         ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);
// // 
// //         ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
// //             @Override
// //             public String generateToolTipFragment(String toolTipText) {
// //                 return "title=\"tooltip_fragment\"";
// //             }
// //         };
// //         URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
// //             @Override
// //             public String generateURLFragment(String urlText) {
// //                 return "href=\"http://example.com\"";
// //             }
// //         };
// // 
//         // WHEN
// //         String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);
// // 
//         // THEN
// //         assertAll("TC11 Assertions",
// //             () -> assertTrue(result.contains("shape=\"poly\""), "Shape should be poly"),
// //             () -> assertTrue(result.contains("coords=\""), "Coords should be present"),
// //             () -> assertTrue(result.contains("title=\"tooltip_fragment\""), "Tooltip fragment should be present"),
// //             () -> assertTrue(result.contains("href=\"http://example.com\""), "URL fragment should be present"),
// //             () -> assertFalse(result.contains("alt=\""), "Alt attribute should not be present")
// //         );
// //     }
// 
// //     @Test
// //     @DisplayName("When toolTipTagFragmentGenerator generates an empty fragment, alt attribute is added")
// //     void TC12() throws Exception {
//         // GIVEN
// //         String urlText = "http://example.com";
// //         String toolTipText = "Display text";
// //         Shape area = new Ellipse2D.Double();
//         // Corrected the order of constructor arguments
// //         ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);
// // 
// //         ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
// //             @Override
// //             public String generateToolTipFragment(String toolTipText) {
// //                 return ""; // Empty fragment to test alt attribute
// //             }
// //         };
// //         URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
// //             @Override
// //             public String generateURLFragment(String urlText) {
// //                 return "href=\"http://example.com\"";
// //             }
// //         };
// // 
//         // WHEN
// //         String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);
// // 
//         // THEN
// //         assertAll("TC12 Assertions",
// //             () -> assertTrue(result.contains("shape=\"poly\""), "Shape should be present"),
// //             () -> assertTrue(result.contains("coords=\""), "Coords should be present"),
// //             () -> assertTrue(result.contains("href=\"http://example.com\""), "URL fragment should be present"),
// //             () -> assertTrue(result.contains("alt=\"\""), "Alt attribute should be present"),
// //             () -> assertFalse(result.contains("title=\"tooltip_fragment\""), "Tooltip fragment should not be present")
// //         );
// //     }
// }