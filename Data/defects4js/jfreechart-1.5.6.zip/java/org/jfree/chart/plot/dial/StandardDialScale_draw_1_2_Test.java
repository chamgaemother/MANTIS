package org.jfree.chart.plot.dial;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.dial.DialPlot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class StandardDialScale_draw_1_2_Test {

    @Test
    @DisplayName("draw with minorTickCount greater than zero and minorTickLength set to zero, ensuring no minor ticks are drawn")
    void TC17() throws Exception {
        // Given
        StandardDialScale scale = new StandardDialScale(0, 100, 0, 360, 10.0, 3);
        scale.setMinorTickLength(0.0);
        Graphics2D g2 = mock(Graphics2D.class);
        DialPlot plot = new DialPlot();
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 200, 200);

        // When
        scale.draw(g2, plot, frame, frame);

        // Then
        // Verify that only major ticks are drawn (11 major ticks for range 0-100 inclusive with increment 10)
        verify(g2, times(11)).draw(any(Line2D.class));
    }
}