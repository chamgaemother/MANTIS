package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.language.ColognePhonetic;

import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_3_Test {

    @Test
    @DisplayName("colognePhonetic handles 'X' after 'C' correctly by mapping to '48'")
    void TC11_colognePhonetic_XAfterC() throws EncoderException {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "CX";

        // Act
        String result = colognePhonetic.colognePhonetic(input);

        // Assert
        assertEquals("48", result, "Expected 'CX' to be encoded as '48'");
    }

    @Test
    @DisplayName("colognePhonetic throws EncoderException when input is non-string object")
    void TC12_encode_NonStringInput() {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        Object input = new Object();

        // Act & Assert
        assertThrows(EncoderException.class, () -> {
            colognePhonetic.encode(input);
        }, "Expected EncoderException to be thrown for non-string input");
    }
}