package org.apache.commons.collections4.iterators;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class PermutationIterator_next_0_3_Test {

    @Test
    @DisplayName("next() updates direction to 1 when $z1 == 0 in B15")
    void TC11_nextUpdatesDirectionTo1_when_z1_is_0() throws Exception {
        // Initialize PermutationIterator instance
        PermutationIterator<Integer> iterator = createInstance();

        // Set up keys with $z1 == 0
        int[] keys = {3, 2, 1};
        boolean[] direction = {false, false, false};
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        List<Integer> nextPermutation = new ArrayList<>(Arrays.asList(1, 2, 3));

        setField(iterator, "keys", keys);
        setField(iterator, "direction", direction);
        setField(iterator, "objectMap", objectMap);
        setField(iterator, "nextPermutation", nextPermutation);

        // Invoke next()
        List<Integer> result = iterator.next();

        // Assertions
        boolean[] updatedDirection = (boolean[]) getField(iterator, "direction");
        assertTrue(updatedDirection[0], "Direction at index 0 should be set to true (1)");
        assertEquals(Arrays.asList(2, 1, 3), result, "Keys should be swapped correctly");
    }

    @Test
    @DisplayName("next() updates direction to -1 when $z1 != 0 in B15")
    void TC12_nextUpdatesDirectionToMinus1_when_z1_is_not_0() throws Exception {
        // Initialize PermutationIterator instance
        PermutationIterator<Integer> iterator = createInstance();

        // Set up keys with $z1 != 0
        int[] keys = {1, 3, 2};
        boolean[] direction = {true, true, true};
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        List<Integer> nextPermutation = new ArrayList<>(Arrays.asList(1, 2, 3));

        setField(iterator, "keys", keys);
        setField(iterator, "direction", direction);
        setField(iterator, "objectMap", objectMap);
        setField(iterator, "nextPermutation", nextPermutation);

        // Invoke next()
        List<Integer> result = iterator.next();

        // Assertions
        boolean[] updatedDirection = (boolean[]) getField(iterator, "direction");
        assertFalse(updatedDirection[0], "Direction at index 0 should be set to false (-1)");
        assertEquals(Arrays.asList(3, 1, 2), result, "Keys should be swapped correctly");
    }

    @Test
    @DisplayName("next() handles multiple iterations with direction updates and returns final permutation")
    void TC13_nextHandlesMultipleIterations_andReturnsFinalPermutation() throws Exception {
        // Initialize PermutationIterator instance
        PermutationIterator<Integer> iterator = createInstance();

        // Set up complex keys and directions requiring multiple iterations
        int[] keys = {1, 2, 3};
        boolean[] direction = {true, true, true};
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        List<Integer> nextPermutation = new ArrayList<>(Arrays.asList(1, 2, 3));

        setField(iterator, "keys", keys);
        setField(iterator, "direction", direction);
        setField(iterator, "objectMap", objectMap);
        setField(iterator, "nextPermutation", nextPermutation);

        // Invoke next() multiple times
        List<Integer> firstResult = iterator.next();
        List<Integer> secondResult = iterator.next();

        // Assertions
        assertEquals(Arrays.asList(2, 3, 1), firstResult, "First iteration should handle direction updates correctly");
        assertEquals(Arrays.asList(3, 1, 2), secondResult, "Second iteration should return the final permutation correctly");
    }

    @Test
    @DisplayName("next() processes when keys[i22] > i19 and adds to nextPermutation")
    void TC14_nextAddsToNextPermutation_when_keys_i22_greater_than_i19() throws Exception {
        // Initialize PermutationIterator instance
        PermutationIterator<Integer> iterator = createInstance();

        // Set up keys where keys[i22] > i19
        int[] keys = {4, 3, 2, 1};
        boolean[] direction = {false, false, false, false};
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        objectMap.put(4, 4);
        List<Integer> nextPermutation = new ArrayList<>(Arrays.asList(1, 2, 3, 4));

        setField(iterator, "keys", keys);
        setField(iterator, "direction", direction);
        setField(iterator, "objectMap", objectMap);
        setField(iterator, "nextPermutation", nextPermutation);

        // Invoke next()
        List<Integer> result = iterator.next();

        // Assertions
        List<Integer> updatedNextPermutation = (List<Integer>) getField(iterator, "nextPermutation");
        assertTrue(updatedNextPermutation.contains(4), "nextPermutation should contain the element 4");
        assertEquals(Arrays.asList(3, 4, 2, 1), result, "Element should be added to nextPermutation correctly");
    }

    @Test
    @DisplayName("next() processes when keys[i22] <= i19 and updates direction correctly")
    void TC15_nextUpdatesDirectionCorrectly_when_keys_i22_less_than_or_equal_to_i19() throws Exception {
        // Initialize PermutationIterator instance
        PermutationIterator<Integer> iterator = createInstance();

        // Set up keys where keys[i22] <= i19
        int[] keys = {1, 2, 3};
        boolean[] direction = {true, true, true};
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        List<Integer> nextPermutation = new ArrayList<>(Arrays.asList(1, 2, 3));

        setField(iterator, "keys", keys);
        setField(iterator, "direction", direction);
        setField(iterator, "objectMap", objectMap);
        setField(iterator, "nextPermutation", nextPermutation);

        // Invoke next()
        List<Integer> result = iterator.next();

        // Assertions
        boolean[] updatedDirection = (boolean[]) getField(iterator, "direction");
        assertFalse(updatedDirection[2], "Direction at index 2 should be updated to false (-1)");
        assertTrue(updatedDirection[0], "Direction at index 0 should remain true");
        assertTrue(updatedDirection[1], "Direction at index 1 should remain true");
        assertTrue(updatedDirection[2] == false, "Direction should be updated correctly when keys[i22] <= i19");
        assertFalse(result.isEmpty(), "Result should not be empty even when keys[i22] <= i19");
    }

    /**
     * Utility method to create an instance of PermutationIterator via reflection.
     */
    private PermutationIterator<Integer> createInstance() throws Exception {
        // PermutationIterator requires a collection for initialization
        return new PermutationIterator<>(Arrays.asList(1, 2, 3));
    }

    /**
     * Utility method to set a private field via reflection.
     */
    private void setField(Object obj, String fieldName, Object value) throws Exception {
        Field field = PermutationIterator.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(obj, value);
    }

    /**
     * Utility method to get a private field via reflection.
     */
    private Object getField(Object obj, String fieldName) throws Exception {
        Field field = PermutationIterator.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(obj);
    }
}
