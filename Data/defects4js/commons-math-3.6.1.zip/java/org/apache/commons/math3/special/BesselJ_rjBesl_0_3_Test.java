package org.apache.commons.math3.special;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class BesselJ_rjBesl_0_3_Test {

    @Test
    @DisplayName("Loop with zero iterations when nb <= 0")
    public void testTC11() throws Exception {
        // Given
        double x = 5.0;
        double alpha = 0.2;
        int nb = -1;
        // Instance should match constructor signature
        BesselJ besselJ = new BesselJ(0);

        // When
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);

        // Then
        assertEquals(0, result.getVals().length, "b array length should be 0");
        assertEquals(-1, result.getnVals(), "ncalc should be -1");
    }

    @Test
    @DisplayName("Loop with multiple iterations for complex calculation")
    public void testTC12() throws Exception {
        // Given
        double x = 20.0;
        double alpha = 0.6;
        int nb = 7;
        BesselJ besselJ = new BesselJ(0);

        // When
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);

        // Then
        assertEquals(7, result.getVals().length, "b array length should be 7");
        assertEquals(7, result.getnVals(), "ncalc should be 7");
    }

    @Test
    @DisplayName("Exception path when gamma(alpha) causes overflow")
    public void testTC13() throws Exception {
        // Given
        double x = 100.0;
        double alpha = Double.MAX_VALUE;
        int nb = 3;
        BesselJ besselJ = new BesselJ(0);

        // When
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);

        // Then
        assertEquals(0, result.getVals().length, "b array length should be 0 due to overflow");
        assertEquals(-1, result.getnVals(), "ncalc should be -1 due to overflow");
    }

    @Test
    @DisplayName("Boundary case with nb=1 and maximum valid x")
    public void testTC14() throws Exception {
        // Given
        double alpha = 0.4;
        int nb = 1;
        BesselJ besselJ = new BesselJ(0);

        // Retrieve X_MAX via reflection
        Field xMaxField = BesselJ.class.getDeclaredField("X_MAX");
        xMaxField.setAccessible(true);
        double xMax = xMaxField.getDouble(null); // Accessing the static field
        double x = xMax;

        // When
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);

        // Then
        assertEquals(1, result.getVals().length, "b array length should be 1");
        assertEquals(1, result.getnVals(), "ncalc should be 1");
    }

    @Test
    @DisplayName("Loop with one iteration where i0=1")
    public void testTC15() throws Exception {
        // Given
        double x = 12.0;
        double alpha = 0.3;
        int nb = 1;
        BesselJ besselJ = new BesselJ(0);

        // When
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);

        // Then
        assertEquals(1, result.getVals().length, "b array length should be 1");
        assertEquals(1, result.getnVals(), "ncalc should be 1");
    }
}
