package com.fasterxml.jackson.databind.util;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ISO8601Utils_parse_0_7_Test {

    @Test
    @DisplayName("Parse throws ParseException when date string has extra characters")
    void TC31_parseWithExtraCharacters() {
        String date = "2023-10-05T14:30:00Zextra";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("extra characters"));
    }

    @Test
    @DisplayName("Parse successfully handles date string with single-digit month")
    void TC32_parseSingleDigitMonth() throws ParseException {
        String date = "2023-1-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);

        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        expectedCalendar.setLenient(false);
        expectedCalendar.set(Calendar.YEAR, 2023);
        expectedCalendar.set(Calendar.MONTH, Calendar.JANUARY);
        expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
        expectedCalendar.set(Calendar.HOUR_OF_DAY, 14);
        expectedCalendar.set(Calendar.MINUTE, 30);
        expectedCalendar.set(Calendar.SECOND, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();

        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse throws ParseException for invalid 'T' character")
    void TC33_parseInvalidTCharacter() {
        String date = "2023-10-05X14:30:00Z";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("Invalid 'T' character"));
    }

    @Test
    @DisplayName("Parse successfully parses date with single-digit day")
    void TC34_parseSingleDigitDay() throws ParseException {
        String date = "2023-10-5T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);

        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        expectedCalendar.setLenient(false);
        expectedCalendar.set(Calendar.YEAR, 2023);
        expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER);
        expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
        expectedCalendar.set(Calendar.HOUR_OF_DAY, 14);
        expectedCalendar.set(Calendar.MINUTE, 30);
        expectedCalendar.set(Calendar.SECOND, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();

        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse throws ParseException when year is incomplete")
    void TC35_parseIncompleteYear() {
        String date = "202-10-05";
        ParsePosition pos = new ParsePosition(0);

        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertTrue(exception.getMessage().contains("incomplete year"));
    }
}