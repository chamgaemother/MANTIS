package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.mock;
import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.category.CategoryToPieDataset;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.PieDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

public class MultiplePiePlot_draw_0_2_Test {

    @Test
    @DisplayName("displayCols > displayRows and area width < height, swap columns and rows")
    void TC06_swapColumnsAndRows() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        CategoryDataset dataset = createDatasetWithMoreColumns();
        plot.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 200);
        Point2D point = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        plot.draw(g2, area, point, state, info);
    }

    @Test
    @DisplayName("displayCols > displayRows but area width >= height, no swapping")
    void TC07_noSwapColumnsAndRows() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        CategoryDataset dataset = createDatasetWithMoreColumns();
        plot.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 100);
        Point2D point = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        plot.draw(g2, area, point, state, info);
    }

    @Test
    @DisplayName("limit > 0.0, create consolidated pie dataset")
    void TC08_consolidatePieDataset() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setLimit(10.0);
        plot.setAggregatedItemsKey("Others");

        CategoryDataset dataset = createSampleDataset();
        plot.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        plot.draw(g2, area, point, state, info);
        // Using reflection to check the internal piedataset is not compatible, as draw reuses local variable `piedataset`
    }

    @Test
    @DisplayName("limit is <= 0.0, use original dataset")
    void TC09_useOriginalDataset() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setLimit(0.0);

        CategoryDataset dataset = createSampleDataset();
        plot.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        plot.draw(g2, area, point, state, info);
        // Original dataset usage can't be verified because draw doesn't expose or set a `piedataset` field
    }

    @Test
    @DisplayName("info is null, should not collect rendering info")
    void TC10_infoIsNull() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        CategoryDataset dataset = createSampleDataset();
        plot.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = new Point2D.Double(50, 50);
        PlotState state = null;

        plot.draw(g2, area, point, state, null);

        // Check using mock verification or result validation for info collection
    }

    // Helper methods
    private CategoryDataset createSampleDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(2.0, "Row1", "Col2");
        return dataset;
    }

    private CategoryDataset createDatasetWithMoreColumns() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(2.0, "Row1", "Col2");
        dataset.addValue(3.0, "Row1", "Col3");
        return dataset;
    }
}