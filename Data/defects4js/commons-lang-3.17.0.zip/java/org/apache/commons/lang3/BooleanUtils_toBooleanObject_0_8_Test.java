package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BooleanUtils_toBooleanObject_0_8_Test {

    @Test
    @DisplayName("Input string contains non-matching single character, returns null")
    void TC36_toBooleanObject_ReturnsNullForZ() {
        // GIVEN
        String input = "z";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertNull(result, "Expected result to be null for input 'z'");
    }

    @Test
    @DisplayName("Input string is five characters 'TrUeS', returns null")
    void TC37_toBooleanObject_ReturnsNullForTrUeS() {
        // GIVEN
        String input = "TrUeS";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertNull(result, "Expected result to be null for input 'TrUeS'");
    }

    @Test
    @DisplayName("Input string is two characters 'oN', returns Boolean.TRUE")
    void TC38_toBooleanObject_ReturnsTrueForOn() {
        // GIVEN
        String input = "oN";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertEquals(Boolean.TRUE, result, "Expected result to be Boolean.TRUE for input 'oN'");
    }

    @Test
    @DisplayName("Input string is two characters 'No', returns Boolean.FALSE")
    void TC39_toBooleanObject_ReturnsFalseForNo() {
        // GIVEN
        String input = "No";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertEquals(Boolean.FALSE, result, "Expected result to be Boolean.FALSE for input 'No'");
    }
}