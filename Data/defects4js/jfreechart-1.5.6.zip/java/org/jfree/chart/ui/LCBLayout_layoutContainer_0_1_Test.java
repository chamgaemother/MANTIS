package org.jfree.chart.ui;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.lang.reflect.Field;
import java.awt.Rectangle;

public class LCBLayout_layoutContainer_0_1_Test {

    @Test
    @DisplayName("layoutContainer with no components in the parent container")
    public void TC01_layoutContainer_noComponents() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        assertEquals(0, parent.getComponentCount(), "Parent container should have zero components.");
    }

    @Test
    @DisplayName("layoutContainer with exactly three components forming one row")
    public void TC02_layoutContainer_threeComponentsOneRow() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();
        
        // Create and add three components with preferred sizes
        Component comp1 = new Component() {};
        comp1.setPreferredSize(new Dimension(100, 50));
        Component comp2 = new Component() {};
        comp2.setPreferredSize(new Dimension(150, 60));
        Component comp3 = new Component() {};
        comp3.setPreferredSize(new Dimension(120, 55));
        
        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        // Verify bounds of each component
        for (Component comp : parent.getComponents()) {
            assertNotNull(comp.getBounds(), "Component bounds should be set.");
            Rectangle bounds = comp.getBounds();
            assertTrue(bounds.width > 0 && bounds.height > 0, "Component should have positive width and height.");
        }
    }

    @Test
    @DisplayName("layoutContainer with fewer than three components in the parent container")
    public void TC03_layoutContainer_fewerThanThreeComponents() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();
        
        // Create and add two components with preferred sizes
        Component comp1 = new Component() {};
        comp1.setPreferredSize(new Dimension(100, 50));
        Component comp2 = new Component() {};
        comp2.setPreferredSize(new Dimension(150, 60));
        
        parent.add(comp1);
        parent.add(comp2);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        // Verify bounds of each component
        for (Component comp : parent.getComponents()) {
            assertNotNull(comp.getBounds(), "Component bounds should be set.");
            Rectangle bounds = comp.getBounds();
            assertTrue(bounds.width > 0 && bounds.height > 0, "Component should have positive width and height.");
        }
    }

    @Test
    @DisplayName("layoutContainer with multiple rows of components")
    public void TC04_layoutContainer_multipleRows() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(2);
        Container parent = new Container();
        
        // Create and add six components with preferred sizes
        for (int i = 0; i < 6; i++) {
            Component comp = new Component() {};
            comp.setPreferredSize(new Dimension(100 + i * 10, 50 + i * 5));
            parent.add(comp);
        }
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        // Verify bounds of each component
        for (Component comp : parent.getComponents()) {
            assertNotNull(comp.getBounds(), "Component bounds should be set.");
            Rectangle bounds = comp.getBounds();
            assertTrue(bounds.width > 0 && bounds.height > 0, "Component should have positive width and height.");
        }
    }

    @Test
    @DisplayName("layoutContainer where some components have larger preferred widths")
    public void TC05_layoutContainer_variableComponentWidths() throws Exception {
        // Arrange
        LCBLayout layout = new LCBLayout(1);
        Container parent = new Container();
        
        // Create and add three components with varying preferred widths
        Component comp1 = new Component() {};
        comp1.setPreferredSize(new Dimension(100, 50));
        Component comp2 = new Component() {};
        comp2.setPreferredSize(new Dimension(200, 60)); // Larger width
        Component comp3 = new Component() {};
        comp3.setPreferredSize(new Dimension(120, 55));
        
        parent.add(comp1);
        parent.add(comp2);
        parent.add(comp3);
        
        // Act
        layout.layoutContainer(parent);
        
        // Assert
        // Verify that the second column has adjusted width
        // This requires accessing the private colWidth field via reflection
        Field colWidthField = LCBLayout.class.getDeclaredField("colWidth");
        colWidthField.setAccessible(true);
        int[] colWidth = (int[]) colWidthField.get(layout);
        
        assertTrue(colWidth[1] >= 200, "Second column width should accommodate the larger component.");
    }
}