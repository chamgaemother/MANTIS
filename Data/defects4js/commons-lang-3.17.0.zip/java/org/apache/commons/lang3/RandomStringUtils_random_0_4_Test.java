package org.apache.commons.lang3;

// JUnit 5 test class for RandomStringUtils.random
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.lang3.RandomStringUtils;
import java.util.Random;
import static org.junit.jupiter.api.Assertions.*;

public class RandomStringUtils_random_0_4_Test {

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=null, random) adjusts to full alphanumerical range")
    void TC16() {
        // GIVEN
        int count = 9;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(9, result.length(), "The length of the result should be 9");
        assertTrue(result.chars().allMatch(Character::isLetterOrDigit), "All characters should be alphanumerical");
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=null, random) throws exception when range is insufficient for letters")
    void TC17() {
        // GIVEN
        int count = 5;
        int start = 40;
        int end = 60;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        }, "Expected IllegalArgumentException due to insufficient range for letters");

        assertTrue(exception.getMessage().contains("must be greater then"), "Exception message should indicate insufficient range for letters");
    }

    @Test
    @DisplayName("random(count, start=32, end=123, letters=true, numbers=true, chars=null, random) generates string with letters and numbers within adjusted range")
    void TC18() {
        // GIVEN
        int count = 10;
        int start = 32;
        int end = 123;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(10, result.length(), "The length of the result should be 10");
        assertTrue(result.chars().allMatch(c -> (c >= 32 && c < 123) && (Character.isLetterOrDigit(c))), "All characters should be letters or digits within the specified range");
    }

    @Test
    @DisplayName("random(count, start=65, end=90, letters=true, numbers=false, chars=null, random) generates string with uppercase letters")
    void TC19() {
        // GIVEN
        int count = 7;
        int start = 65;
        int end = 90;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(7, result.length(), "The length of the result should be 7");
        assertTrue(result.chars().allMatch(Character::isUpperCase), "All characters should be uppercase letters between 'A' and 'Z'");
    }

    @Test
    @DisplayName("random(count, start=48, end=58, letters=false, numbers=true, chars=null, random) handles boundary values for digits")
    void TC20() {
        // GIVEN
        int count = 6;
        int start = 48;
        int end = 58;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(6, result.length(), "The length of the result should be 6");
        assertTrue(result.chars().allMatch(c -> c >= 48 && c < 58 && Character.isDigit(c)), "All characters should be digits between '0' and '9'");
    }
}