package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class WordUtils_wrap_1_1_Test {

    @Test
    @DisplayName("wrap with wrapOn pattern matching the first character to trigger immediate skip over delimiter")
    public void TC21() {
        String str = ",start with delimiter,followed by text";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ",";
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        String expected = "start with\ndelimiter,\nfollowed by\ntext";
        assertEquals(expected, result, "Wrapping should skip the initial delimiter and wrap correctly.");
    }

    @Test
    @DisplayName("wrap with wrapOn pattern that does not match any characters and wrapLongWords=true to trigger word breaking")
    public void TC22() {
        String str = "ThisIsALongWordWithoutAnyDelimiters";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "@";
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        String expected = "ThisIsALon\ngWordWithou\ntAnyDelimi\nters";
        assertEquals(expected, result, "The long word should be broken at every 10 characters.");
    }

    @Test
    @DisplayName("wrap with wrapOn pattern that does not match any characters and wrapLongWords=false to avoid word breaking")
    public void TC23() {
        String str = "AnotherLongWordWithoutDelimiters";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = false;
        String wrapOn = "#";
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        String expected = "AnotherLongWordWithoutDelimiters";
        assertEquals(expected, result, "The string should not be wrapped as no delimiters are found and wrapLongWords is false.");
    }

    @Test
    @DisplayName("wrap with wrapOn pattern matching multiple consecutive delimiters to ensure no empty lines")
    public void TC24() {
        String str = "word1,,word2;;;word3..word4";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "[,;.]+";
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        String expected = "word1,,\nword2;;;\nword3..\nword4";
        assertEquals(expected, result, "Wrapping should occur correctly at each delimiter without adding empty lines.");
    }

    @Test
    @DisplayName("wrap with wrapOn pattern matching at the end of the string to ensure no trailing newline")
    public void TC25() {
        String str = "word1,word2,word3,";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ",";
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        String expected = "word1\nword2\nword3,";
        assertEquals(expected, result, "Wrapping should occur correctly before the final delimiter without adding an extra newline.");
    }

}