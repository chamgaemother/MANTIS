package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_remove_0_1_Test {

    @Test
    @DisplayName("Remove from delegateMap when delegateMap is not null")
    void test_TC01() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set delegateMap
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        HashMap<Object, Object> delegate = new HashMap<>();
        Object key = "key1";
        Object value = "value1";
        delegate.put(key, value);
        delegateMapField.set(map, delegate);

        // WHEN
        Object result = map.remove(key);

        // THEN
        assertEquals(value, result, "delegateMap.remove(key) should return the removed value");
    }

    @Test
    @DisplayName("Remove from empty Flat3Map when delegateMap is null and size is 0")
    void test_TC02() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set delegateMap and size
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        Object someKey = "nonexistentKey";

        // WHEN
        Object result = map.remove(someKey);

        // THEN
        assertNull(result, "Removing from empty Flat3Map should return null");
    }

    @Test
    @DisplayName("Remove null key from Flat3Map with size 3 and key3 is null")
    void test_TC03() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object someValue3 = "value3";
        value3Field.set(map, someValue3);

        // WHEN
        Object result = map.remove(null);

        // THEN
        assertEquals(someValue3, result, "remove(null) should return value3");
        assertNull(key3Field.get(map), "key3 should be set to null after removal");
        assertEquals(2, sizeField.getInt(map), "size should be decremented to 2");
    }

    @Test
    @DisplayName("Remove null key from Flat3Map with size 3 and key2 is null")
    void test_TC04() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object someKey3 = "key3";
        key3Field.set(map, someKey3);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object someValue2 = "value2";
        value2Field.set(map, someValue2);

        // WHEN
        Object result = map.remove(null);

        // THEN
        assertEquals(someValue2, result, "remove(null) should return value2");
        assertNull(key2Field.get(map), "key2 should be set to null after removal");
        assertEquals(1, sizeField.getInt(map), "size should be decremented to 1");
    }

    @Test
    @DisplayName("Remove null key from Flat3Map with size 3 and key1 is null")
    void test_TC05() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object someKey3 = "key3";
        key3Field.set(map, someKey3);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object someKey2 = "key2";
        key2Field.set(map, someKey2);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object someValue1 = "value1";
        value1Field.set(map, someValue1);

        // WHEN
        Object result = map.remove(null);

        // THEN
        assertEquals(someValue1, result, "remove(null) should return value1");
        assertNull(key1Field.get(map), "key1 should be set to null after removal");
        assertEquals(0, sizeField.getInt(map), "size should be decremented to 0");
    }
}