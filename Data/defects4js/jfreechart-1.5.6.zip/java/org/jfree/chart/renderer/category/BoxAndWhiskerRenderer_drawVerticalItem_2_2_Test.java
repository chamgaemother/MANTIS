// package org.jfree.chart.renderer.category;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
// import org.jfree.chart.renderer.category.CategoryItemRendererState;
// import org.jfree.data.category.CategoryDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.MockedStatic;
// import org.mockito.Mockito;
// 
// public class BoxAndWhiskerRenderer_drawVerticalItem_2_2_Test {
// 
//     @Test
//     @DisplayName("drawVerticalItem with entityCollection null skips entity addition")
//     void TC11_drawVerticalItem_entityCollection_null_skips_entity_addition() throws Exception {
//         // Arrange
//         BoxAndWhiskerRenderer renderer = Mockito.spy(new BoxAndWhiskerRenderer());
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// 
//         // Mock methods
//         when(state.getInfo()).thenReturn(null);
//         when(state.getEntityCollection()).thenReturn(null);
//         when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
//         when(domainAxis.getCategoryEnd(anyInt(), anyInt(), eq(dataArea), any())).thenReturn(100.0);
//         when(domainAxis.getCategoryStart(anyInt(), anyInt(), eq(dataArea), any())).thenReturn(50.0);
//         when(renderer.getRowCount()).thenReturn(1);
//         when(renderer.getColumnCount()).thenReturn(1);
//         when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(java.awt.Color.BLACK);
//         when(renderer.getItemStroke(anyInt(), anyInt())).thenReturn(new java.awt.BasicStroke());
//         when(dataset.getQ1Value(anyInt(), anyInt())).thenReturn(10);
//         when(dataset.getQ3Value(anyInt(), anyInt())).thenReturn(20);
//         when(dataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(25);
//         when(dataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(5);
//         when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(15.0);
//         when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(15.0);
//         when(dataset.getOutliers(anyInt(), anyInt())).thenReturn(null);
// 
//         // Act
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         // Verify that addItemEntity is never called
//         verify(renderer, never()).addItemEntity(any(), any(), anyInt(), anyInt(), any());
//     }
// 
//     @Test
//     @DisplayName("drawVerticalItem throws exception when whiskerWidth is out of range")
//     void TC12_drawVerticalItem_whiskerWidth_out_of_range_throws_exception() {
//         // Arrange
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
// 
//         // Act & Assert
//         IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
//             renderer.setWhiskerWidth(-0.1);
//         });
//         assertEquals("Value for whisker width out of range", exception.getMessage());
// 
//         // Additionally, test for whiskerWidth > 1
//         IllegalArgumentException exception2 = assertThrows(IllegalArgumentException.class, () -> {
//             renderer.setWhiskerWidth(1.1);
//         });
//         assertEquals("Value for whisker width out of range", exception2.getMessage());
//     }
// }