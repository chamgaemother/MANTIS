package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class GradientBarPainter_paintBar_0_2_Test {

    @Mock
    private Graphics2D g2;

    @Mock
    private BarRenderer renderer;

    @InjectMocks
    private GradientBarPainter painter = new GradientBarPainter();

    @Test
    @DisplayName("itemPaint is GradientPaint, alpha != 0, base is LEFT, isDrawBarOutline is true, outline stroke and paint are not null")
    void TC06_paintBar_GradientPaint_Left_Base_DrawOutline() throws Exception {
        // Arrange
        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 50, 100);
        RectangleEdge base = RectangleEdge.LEFT;

        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.BLUE);
        when(renderer.getItemPaint(row, column)).thenReturn(gradientPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        Stroke outlineStroke = mock(Stroke.class);
        Paint outlinePaint = Color.BLACK;
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(outlineStroke);
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(outlinePaint);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2).setStroke(outlineStroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(bar);
    }

    @Test
    @DisplayName("itemPaint is GradientPaint, alpha != 0, base is LEFT, isDrawBarOutline is true, outline stroke is null")
    void TC07_paintBar_GradientPaint_Left_Base_OutlineStrokeNull() throws Exception {
        // Arrange
        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 50, 100);
        RectangleEdge base = RectangleEdge.LEFT;

        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.BLUE);
        when(renderer.getItemPaint(row, column)).thenReturn(gradientPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(null);
        Paint outlinePaint = Color.BLACK;
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(outlinePaint);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("itemPaint is GradientPaint, alpha != 0, base is LEFT, isDrawBarOutline is false")
    void TC08_paintBar_GradientPaint_Left_Base_NoOutline() throws Exception {
        // Arrange
        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 50, 100);
        RectangleEdge base = RectangleEdge.LEFT;

        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.BLUE);
        when(renderer.getItemPaint(row, column)).thenReturn(gradientPaint);
        when(renderer.isDrawBarOutline()).thenReturn(false);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("itemPaint is neither Color nor GradientPaint, alpha != 0, base is BOTTOM, isDrawBarOutline is false")
    void TC09_paintBar_DefaultPaint_Bottom_Base_NoOutline() throws Exception {
        // Arrange
        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 50, 100);
        RectangleEdge base = RectangleEdge.BOTTOM;

        Paint defaultPaint = Color.BLUE;
        when(renderer.getItemPaint(row, column)).thenReturn(defaultPaint);
        when(renderer.isDrawBarOutline()).thenReturn(false);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("itemPaint is neither Color nor GradientPaint, alpha != 0, base is RIGHT, isDrawBarOutline is true, outline stroke and paint are null")
    void TC10_paintBar_DefaultPaint_Right_Base_OutlineStrokePaintNull() throws Exception {
        // Arrange
        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 50, 100);
        RectangleEdge base = RectangleEdge.RIGHT;

        Paint defaultPaint = Color.BLUE;
        when(renderer.getItemPaint(row, column)).thenReturn(defaultPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(null);
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(null);

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }
}