package org.apache.commons.compress.archivers.cpio;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class CpioArchiveInputStream_getNextCPIOEntry_0_1_Test {

    @Test
    @DisplayName("Handles null entry by not closing any existing entry")
    void TC01_handles_null_entry_by_not_closing_any_existing_entry() throws Exception {
        // Initialize input stream with MAGIC_NEW signature
        byte[] magicNewBytes = "07070100000000000000000000000000000000000000000000000000000014".getBytes(); // example hex data converted to bytes
        InputStream inputStream = new ByteArrayInputStream(magicNewBytes);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Ensure 'entry' is null
        Field entryField = CpioArchiveInputStream.class.getDeclaredField("entry");
        entryField.setAccessible(true);
        entryField.set(cpioInputStream, null);

        // Invoke the method under test
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Assert the entry is of type MAGIC_NEW
        assertNotNull(entry, "Entry should not be null");
        assertEquals(CpioArchiveEntry.FORMAT_NEW, entry.getFormat(), "Entry format should be MAGIC_NEW");
    }

    @Test
    @DisplayName("Closes existing entry when entry is not null")
    void TC02_closes_existing_entry_when_entry_is_not_null() throws Exception {
        // Initialize input stream with MAGIC_NEW signature
        byte[] magicNewBytes = "07070100000000000000000000000000000000000000000000000000000014".getBytes(); // example hex data converted to bytes
        InputStream inputStream = new ByteArrayInputStream(magicNewBytes);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Set an existing entry
        CpioArchiveEntry existingEntry = new CpioArchiveEntry(CpioArchiveEntry.FORMAT_NEW);
        Field closedField = CpioArchiveEntry.class.getDeclaredField("closed");
        closedField.setAccessible(true);
        closedField.set(existingEntry, false);  // Since `setClosed` does not exist, use reflection

        Field entryField = CpioArchiveInputStream.class.getDeclaredField("entry");
        entryField.setAccessible(true);
        entryField.set(cpioInputStream, existingEntry);

        // Invoke the method under test
        CpioArchiveEntry newEntry = cpioInputStream.getNextCPIOEntry();

        // Assert the new entry is of type MAGIC_NEW
        assertNotNull(newEntry, "New entry should not be null");
        assertEquals(CpioArchiveEntry.FORMAT_NEW, newEntry.getFormat(), "New entry format should be MAGIC_NEW");
    }

    @Test
    @DisplayName("Processes MAGIC_OLD_BINARY without byte swap")
    void TC03_processes_MAGIC_OLD_BINARY_without_byte_swap() throws Exception {
        // Initialize input stream with MAGIC_OLD_BINARY signature without byte swap
        byte[] magicOldBinaryBytes = {(byte)0x71, (byte)0xc7};  // Correct binary sequence
        InputStream inputStream = new ByteArrayInputStream(magicOldBinaryBytes);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Invoke the method under test
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Assert the entry is of type MAGIC_OLD_BINARY without byte swap
        assertNotNull(entry, "Entry should not be null");
        assertEquals(CpioArchiveEntry.FORMAT_OLD_BINARY, entry.getFormat(), "Entry format should be MAGIC_OLD_BINARY");
    }

    @Test
    @DisplayName("Processes MAGIC_OLD_BINARY with byte swap")
    void TC04_processes_MAGIC_OLD_BINARY_with_byte_swap() throws Exception {
        // Initialize input stream with MAGIC_OLD_BINARY signature with byte swap
        byte[] magicOldBinaryBytesSwapped = {(byte)0xc7, 0x71};  // Swapped binary sequence
        InputStream inputStream = new ByteArrayInputStream(magicOldBinaryBytesSwapped);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Invoke the method under test
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Assert the entry is of type MAGIC_OLD_BINARY with byte swap
        assertNotNull(entry, "Entry should not be null");
        assertEquals(CpioArchiveEntry.FORMAT_OLD_BINARY, entry.getFormat(), "Entry format should be MAGIC_OLD_BINARY");
    }

    @Test
    @DisplayName("Processes MAGIC_NEW_CRC signature")
    void TC05_processes_MAGIC_NEW_CRC_signature() throws Exception {
        // Initialize input stream with MAGIC_NEW_CRC signature
        byte[] magicNewCrcBytes = "07070200000000000000000000000000000000000000000000000000000014".getBytes(); // example hex data converted to bytes
        InputStream inputStream = new ByteArrayInputStream(magicNewCrcBytes);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Invoke the method under test
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Assert the entry is of type MAGIC_NEW_CRC
        assertNotNull(entry, "Entry should not be null");
        assertEquals(CpioArchiveEntry.FORMAT_NEW_CRC, entry.getFormat(), "Entry format should be MAGIC_NEW_CRC");
    }
}
