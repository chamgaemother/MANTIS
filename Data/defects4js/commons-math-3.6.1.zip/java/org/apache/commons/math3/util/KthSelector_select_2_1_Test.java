package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

public class KthSelector_select_2_1_Test {
    
    @Test
    @DisplayName("Select with r1 as non-null, array size > MIN_SELECT_SIZE, z0 false, and i10 < length of r1")
    void TC19_Select_with_pivotsHeap_non_null_array_size_greater_MIN_SELECT_SIZE_z0_false_i10_less_than_length_pivotsHeap() {
        // GIVEN
        double[] work = {12.0, 7.9, 3.3, 5.5, 9.1, 2.2, 8.8, 4.4, 6.6, 1.1, 10.0, 11.0, 14.4, 13.3, 15.5, 16.6, 17.7};
        int[] pivotsHeap = {2, 5, 8, 11, 14};
        int k = 10;
        
        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, pivotsHeap, k);
        
        // THEN
        double[] sorted = Arrays.stream(work).sorted().toArray();
        double expected = sorted[k];
        assertEquals(expected, result, "The k-th element should be correctly selected.");
    }
    
    @Test
    @DisplayName("Select with r1 as non-null, array size > MIN_SELECT_SIZE, z0 false, and i10 >= length of r1")
    void TC20_Select_with_pivotsHeap_non_null_array_size_greater_MIN_SELECT_SIZE_z0_false_i10_greater_equals_length_pivotsHeap() {
        // GIVEN
        double[] work = {20.0, 15.0, 25.0, 10.0, 30.0, 5.0, 35.0, 40.0, 45.0, 50.0, 55.0, 60.0, 65.0, 70.0, 75.0, 80.0, 85.0};
        int[] pivotsHeap = {2, 4, 6};
        int k = 12;
        
        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, pivotsHeap, k);
        
        // THEN
        double[] sorted = Arrays.stream(work).sorted().toArray();
        double expected = sorted[k];
        assertEquals(expected, result, "The k-th element should be correctly selected.");
    }
    
    @Test
    @DisplayName("Select with r1 as non-null, array size > MIN_SELECT_SIZE, z0 true, and i0 equals i12")
    void TC21_Select_with_pivotsHeap_non_null_array_size_greater_MIN_SELECT_SIZE_z0_true_i0_equals_i12() {
        // GIVEN
        double[] work = {5.0, 3.0, 8.0, 6.0, 2.0, 7.0, 4.0, 1.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0};
        int[] pivotsHeap = {1, 3, 5, 7};
        int k = 5;
        
        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, pivotsHeap, k);
        
        // THEN
        double expected = work[k];
        assertEquals(expected, result, "The k-th element should be returned immediately when i0 equals i12.");
    }
    
    @Test
    @DisplayName("Select with r1 as non-null, array size <= MIN_SELECT_SIZE, triggering Arrays.sort")
    void TC22_Select_with_pivotsHeap_non_null_array_size_less_equals_MIN_SELECT_SIZE_triggering_sort() {
        // GIVEN
        double[] work = {4.0, 2.0, 5.0, 1.0, 3.0};
        int[] pivotsHeap = {0, 1};
        int k = 2;
        
        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, pivotsHeap, k);
        
        // THEN
        double[] sorted = Arrays.stream(work).sorted().toArray();
        double expected = sorted[k];
        assertEquals(expected, result, "The k-th element should be correctly selected after sorting.");
    }
    
    @Test
    @DisplayName("Select with r1 null and array size <= MIN_SELECT_SIZE, triggering Arrays.sort")
    void TC23_Select_with_pivotsHeap_null_array_size_less_equals_MIN_SELECT_SIZE_triggering_sort() {
        // GIVEN
        double[] work = {7.0, 3.0, 5.0, 2.0, 4.0};
        int[] pivotsHeap = null;
        int k = 3;
        
        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, pivotsHeap, k);
        
        // THEN
        double[] sorted = Arrays.stream(work).sorted().toArray();
        double expected = sorted[k];
        assertEquals(expected, result, "The k-th element should be correctly selected after sorting with null pivotsHeap.");
    }
}