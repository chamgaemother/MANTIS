import org.apache.commons.compress.harmony.unpack200.CpBands;
import org.apache.commons.compress.harmony.unpack200.MetadataBandGroup;
import org.apache.commons.compress.harmony.unpack200.bytecode.Attribute;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPUTF8;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPInteger;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPDouble;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPFloat;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPLong;
import org.apache.commons.compress.harmony.unpack200.bytecode.AnnotationDefaultAttribute;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

class MetadataBandGroupTest {

    private CpBands cpBands;

    @BeforeEach
    void setup() {
        cpBands = new CpBands();
    }

    @Test
    void testGetAttributesTypeAD() {
        MetadataBandGroup metadataBandGroup = new MetadataBandGroup("AD", cpBands);
        metadataBandGroup.T = new int[]{'I', 'D'};
        metadataBandGroup.caseI_KI = new CPInteger[]{new CPInteger(1)};
        metadataBandGroup.caseD_KD = new CPDouble[]{new CPDouble(2.0)};
        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertEquals(2, attributes.size());
        assertTrue(attributes.get(0) instanceof AnnotationDefaultAttribute);
        assertTrue(attributes.get(1) instanceof AnnotationDefaultAttribute);
    }

    @Test
    void testGetAttributesTypeRVA() {
        MetadataBandGroup metadataBandGroup = new MetadataBandGroup("RVA", cpBands);
        CPUTF8 type = new CPUTF8("Type");
        MetadataBandGroup.setRvaAttributeName(type);
        metadataBandGroup.anno_N = new int[]{1};
        metadataBandGroup.type_RS = new CPUTF8[][]{new CPUTF8[]{new CPUTF8("AnnotationType")}};
        metadataBandGroup.pair_N = new int[][]{{1}};
        metadataBandGroup.name_RU = new CPUTF8[]{new CPUTF8("elementName")};
        metadataBandGroup.T = new int[]{'s'};
        metadataBandGroup.cases_RU = new CPUTF8[]{new CPUTF8("elementValue")};
        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertEquals(1, attributes.size());
    }

    @Test
    void testGetAttributesTypeRIA() {
        MetadataBandGroup metadataBandGroup = new MetadataBandGroup("RIA", cpBands);
        CPUTF8 type = new CPUTF8("Type");
        MetadataBandGroup.setRiaAttributeName(type);
        metadataBandGroup.anno_N = new int[]{1};
        metadataBandGroup.type_RS = new CPUTF8[][]{new CPUTF8[]{new CPUTF8("AnnotationType")}};
        metadataBandGroup.pair_N = new int[][]{{1}};
        metadataBandGroup.name_RU = new CPUTF8[]{new CPUTF8("elementName")};
        metadataBandGroup.T = new int[]{'s'};
        metadataBandGroup.cases_RU = new CPUTF8[]{new CPUTF8("elementValue")};
        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertEquals(1, attributes.size());
    }

    @Test
    void testGetAttributesTypeRVPA() {
        MetadataBandGroup metadataBandGroup = new MetadataBandGroup("RVPA", cpBands);
        CPUTF8 type = new CPUTF8("Type");
        MetadataBandGroup.setRvpaAttributeName(type);
        metadataBandGroup.param_NB = new int[]{1};
        metadataBandGroup.anno_N = new int[]{1};
        metadataBandGroup.type_RS = new CPUTF8[][]{new CPUTF8[]{new CPUTF8("AnnotationType")}};
        metadataBandGroup.pair_N = new int[][]{{1}};
        metadataBandGroup.name_RU = new CPUTF8[]{new CPUTF8("elementName")};
        metadataBandGroup.T = new int[]{'s'};
        metadataBandGroup.cases_RU = new CPUTF8[]{new CPUTF8("elementValue")};
        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertEquals(1, attributes.size());
    }

    @Test
    void testGetAttributesTypeRIPA() {
        MetadataBandGroup metadataBandGroup = new MetadataBandGroup("RIPA", cpBands);
        CPUTF8 type = new CPUTF8("Type");
        MetadataBandGroup.setRipaAttributeName(type);
        metadataBandGroup.param_NB = new int[]{1};
        metadataBandGroup.anno_N = new int[]{1};
        metadataBandGroup.type_RS = new CPUTF8[][]{new CPUTF8[]{new CPUTF8("AnnotationType")}};
        metadataBandGroup.pair_N = new int[][]{{1}};
        metadataBandGroup.name_RU = new CPUTF8[]{new CPUTF8("elementName")};
        metadataBandGroup.T = new int[]{'s'};
        metadataBandGroup.cases_RU = new CPUTF8[]{new CPUTF8("elementValue")};
        List<Attribute> attributes = metadataBandGroup.getAttributes();

        assertEquals(1, attributes.size());
    }
}