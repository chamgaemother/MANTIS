package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class IntList_add_0_3_Test {

    @Test
    @DisplayName("Add at middle location when location >= size/2 and lastIndex != array length")
    public void TC11() throws Exception {
        // Initialize IntList with firstIndex=0, lastIndex=5, array length=10
        IntList list = new IntList();
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 0);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 5);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        arrayField.set(list, new int[10]);

        // Set location and object
        int location = 3;
        int object = 1100;

        // Perform add
        list.add(location, object);

        // Assertions
        int[] array = (int[]) arrayField.get(list);
        assertEquals(1100, array[location + firstIndexField.getInt(list)]);
        assertEquals(6, lastIndexField.getInt(list));
    }

    @Test
    @DisplayName("Add at front when firstIndex == 0 and array needs to growAtFront")
    public void TC12() throws Exception {
        // Initialize IntList with firstIndex=0, lastIndex=5, array length=5
        IntList list = new IntList();
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 0);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 5);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        arrayField.set(list, new int[5]);

        // Set location and object
        int location = 0;
        int object = 1200;

        // Perform add
        list.add(location, object);

        // Assertions
        int firstIndex = firstIndexField.getInt(list);
        int[] array = (int[]) arrayField.get(list);
        assertTrue(firstIndex < 0);
        assertEquals(1200, array[firstIndex]);
        assertTrue(array.length > 5);
    }

    @Test
    @DisplayName("Add multiple objects to trigger multiple array growths")
    public void TC13() throws Exception {
        // Initialize IntList with firstIndex=0, lastIndex=3, array length=5
        IntList list = new IntList();
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 0);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 3);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        arrayField.set(list, new int[5]);

        // Add multiple objects
        for(int i = 0; i < 5; i++) {
            int location = lastIndexField.getInt(list) - firstIndexField.getInt(list);
            int object = 1300 + i;
            list.add(location, object);
        }

        // Assertions
        int size = lastIndexField.getInt(list) - firstIndexField.getInt(list);
        assertEquals(8, size);
        int[] array = (int[]) arrayField.get(list);
        assertTrue(array.length >= 8);
    }

    @Test
    @DisplayName("Add at boundary location equal to size")
    public void TC14() throws Exception {
        // Initialize IntList with firstIndex=0, lastIndex=5, array length=10
        IntList list = new IntList();
        Class<?> clazz = list.getClass();

        Field firstIndexField = clazz.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        firstIndexField.setInt(list, 0);

        Field lastIndexField = clazz.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);
        lastIndexField.setInt(list, 5);

        Field arrayField = clazz.getDeclaredField("array");
        arrayField.setAccessible(true);
        arrayField.set(list, new int[10]);

        // Set location and object
        int location = 5;
        int object = 1400;

        // Perform add
        list.add(location, object);

        // Assertions
        int[] array = (int[]) arrayField.get(list);
        assertEquals(1400, array[location + firstIndexField.getInt(list)]);
        assertEquals(6, lastIndexField.getInt(list));
    }
}