package org.apache.commons.math3.dfp;

import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.exception.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DfpMath_pow_0_4_Test {

//    @Test
//    @DisplayName("pow(1, +Infinity) throws FLAG_INVALID and returns NaN")
//    void TC16_powOneInfinity_ShouldReturnNaNAndSetFlagInvalid() {
//        // Initialize Dfp instances
//        DfpField field = new DfpField(10);
//        Dfp x = field.getOne();
//        Dfp y = field.newInstance(0); // Create a dummy Dfp instance for testing
//        y = y.newInstance((byte) 1, Dfp.INFINITE); // Properly set y to +Infinity
//
//        // Invoke the pow method
//        Dfp result = DfpMath.pow(x, y);
//
//        // Assertions
//        assertTrue(result.isNaN(), "Result should be NaN");
//        assertEquals(DfpField.FLAG_INVALID, x.getField().getIEEEFlagsBits(), "FLAG_INVALID should be set");
//    }

    @Test
    @DisplayName("pow(x, y) returns exp(log(x) * y) for finite x and y within range")
    void TC17_powFiniteInputsWithinRange_ShouldReturnExpLogXTimesY() {
        // Initialize Dfp instances
        DfpField field = new DfpField(10);
        Dfp x = field.newDfp("2.5"); // Example finite x > 0
        Dfp y = field.newDfp("1000"); // Example finite y within |y| < 1e8

        // Invoke the pow method
        Dfp result = DfpMath.pow(x, y);

        // Expected result
        Dfp expected = DfpMath.exp(DfpMath.log(x).multiply(y));

        // Assertions
        assertEquals(expected, result, "pow(x, y) should return exp(log(x) * y)");
    }

    @Test
    @DisplayName("pow(x<0, y odd integer) returns -pow(|x|, y)")
    void TC18_powNegativeXOddIntegerY_ShouldReturnNegativePower() {
        // Initialize Dfp instances
        DfpField field = new DfpField(10);
        Dfp x = field.newDfp("-3"); // Negative x
        Dfp y = field.newDfp("5"); // Odd integer y

        // Invoke the pow method
        Dfp result = DfpMath.pow(x, y);

        // Expected result
        Dfp expected = DfpMath.pow(x.negate(), y).negate();

        // Assertions
        assertEquals(expected, result, "pow(x, y) should return -pow(|x|, y)");
    }

//    @Test
//    @DisplayName("pow(x<0, y non-integer) returns NaN with FLAG_INVALID")
//    void TC19_powNegativeXNonIntegerY_ShouldReturnNaNAndSetFlagInvalid() {
//        // Initialize Dfp instances
//        DfpField field = new DfpField(10);
//        Dfp x = field.newDfp("-2"); // Negative x
//        Dfp y = field.newDfp("2.5"); // Non-integer y
//
//        // Invoke the pow method
//        Dfp result = DfpMath.pow(x, y);
//
//        // Assertions
//        assertTrue(result.isNaN(), "Result should be NaN");
//        assertEquals(DfpField.FLAG_INVALID, x.getField().getIEEEFlagsBits(), "FLAG_INVALID should be set");
//    }

    @Test
    @DisplayName("pow(x=1, y finite) returns 1")
    void TC20_powOneFiniteY_ShouldReturnOne() {
        // Initialize Dfp instances
        DfpField field = new DfpField(10);
        Dfp x = field.getOne();
        Dfp y = field.newDfp("12345.6789"); // Any finite y

        // Invoke the pow method
        Dfp result = DfpMath.pow(x, y);

        // Assertions
        assertEquals(field.getOne(), result, "pow(1, y) should return 1");
    }
}