package org.apache.commons.jxpath.ri.model.dom;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class DOMNodePointer_getNamespaceURI_0_2_Test {

    @Test
    @DisplayName("TC06: getNamespaceURI with existing prefix in namespaces map")
    void test_TC06_getNamespaceURI_with_existing_prefix_in_namespaces_map() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        document.appendChild(root);

        DOMNodePointer pointer = new DOMNodePointer(document, null);

        // Access 'namespaces' field via reflection
        Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
        namespacesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
        if (namespaces == null) {
            namespaces = new HashMap<>();
            namespacesField.set(pointer, namespaces);
        }
        namespaces.put("existingPrefix", "http://example.com/namespace");

        // WHEN
        String result = pointer.getNamespaceURI("existingPrefix");

        // THEN
        assertEquals("http://example.com/namespace", result);
    }

    @Test
    @DisplayName("TC07: getNamespaceURI with prefix not in map and namespace found in DOM")
    void test_TC07_getNamespaceURI_with_prefix_not_in_map_and_namespace_found_in_DOM() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        root.setAttribute("xmlns:newPrefix", "http://example.com/newnamespace");
        document.appendChild(root);

        DOMNodePointer pointer = new DOMNodePointer(document, null);

        // WHEN
        String result = pointer.getNamespaceURI("newPrefix");

        // THEN
        assertEquals("http://example.com/newnamespace", result);

        // Verify that the namespace was added to the map
        Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
        namespacesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
        assertEquals("http://example.com/newnamespace", namespaces.get("newPrefix"));
    }

    @Test
    @DisplayName("TC08: getNamespaceURI with prefix not in map and namespace not found in DOM")
    void test_TC08_getNamespaceURI_with_prefix_not_in_map_and_namespace_not_found_in_DOM() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        // No xmlns:missingPrefix attribute
        document.appendChild(root);

        DOMNodePointer pointer = new DOMNodePointer(document, null);

        // WHEN
        String result = pointer.getNamespaceURI("missingPrefix");

        // THEN
        assertNull(result);

        // Verify that the namespace was added as unknown
        Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
        namespacesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
        assertEquals(DOMNodePointer.UNKNOWN_NAMESPACE, namespaces.get("missingPrefix"));
    }

    @Test
    @DisplayName("TC09: getNamespaceURI with prefix resolved to unknown namespace")
    void test_TC09_getNamespaceURI_with_prefix_resolved_to_unknown_namespace() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        root.setAttribute("xmlns:unknownPrefix", "");
        document.appendChild(root);

        DOMNodePointer pointer = new DOMNodePointer(document, null);

        // WHEN
        String result = pointer.getNamespaceURI("unknownPrefix");

        // THEN
        assertNull(result);

        // Verify that the namespace was added as unknown
        Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
        namespacesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
        assertEquals(DOMNodePointer.UNKNOWN_NAMESPACE, namespaces.get("unknownPrefix"));
    }

    @Test
    @DisplayName("TC10: getNamespaceURI traverses multiple parent nodes to find namespace")
    void test_TC10_getNamespaceURI_traverses_multiple_parent_nodes_to_find_namespace() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();

        // Create ancestor element with xmlns:ancestorPrefix
        Element ancestor = document.createElement("ancestor");
        ancestor.setAttribute("xmlns:ancestorPrefix", "http://example.com/ancestornamespace");
        document.appendChild(ancestor);

        // Create child element under ancestor
        Element child = document.createElement("child");
        ancestor.appendChild(child);

        DOMNodePointer pointer = new DOMNodePointer(child, null);

        // WHEN
        String result = pointer.getNamespaceURI("ancestorPrefix");

        // THEN
        assertEquals("http://example.com/ancestornamespace", result);
    }

}