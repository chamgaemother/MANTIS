package org.jfree.chart.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.ui.RectangleAnchor;

public class RectangleAnchor_getAnchorPoint_0_3_Test {

    @Test
    @DisplayName("Handles rectangle with zero width and height for CENTER anchor")
    void TC11() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 0, 0);
        RectangleAnchor anchor = RectangleAnchor.CENTER;
        Point2D point = anchor.getAnchorPoint(rect);
        
        assertAll(
            () -> assertEquals(0.0, point.getX()),
            () -> assertEquals(0.0, point.getY())
        );
    }
}