package org.jfree.chart;

import static org.mockito.Mockito.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JPopupMenu;

import org.jfree.chart.plot.Pannable;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.Zoomable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class ChartPanelTest {

    private ChartPanel chartPanel;

    @Mock
    private JFreeChart mockChart;

    @Mock
    private Plot mockPlot;

    @Mock
    private Zoomable mockZoomable;

    @Mock
    private Pannable mockPannable;

    @Mock
    private JPopupMenu mockPopupMenu;

    @Mock
    private Graphics mockGraphics;

    @Mock
    private Graphics2D mockGraphics2D;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(mockChart.getPlot()).thenReturn(mockPlot);
        chartPanel = new ChartPanel(mockChart);
    }

    @Test
    void testMouseDragged_PopupShowing() {
        chartPanel.setPopupMenu(mockPopupMenu);
        when(mockPopupMenu.isShowing()).thenReturn(true);

        MouseEvent mockEvent = mock(MouseEvent.class);
        chartPanel.mouseDragged(mockEvent);

        verify(mockPopupMenu, times(1)).isShowing();
        // No further interactions expected
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNull() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(null);

        MouseEvent mockEvent = mock(MouseEvent.class);
        chartPanel.mouseDragged(mockEvent);

        // No interactions expected
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNotNull_DxDyZero() {
        chartPanel.setPopupMenu(null);
        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(100);
        when(mockEvent.getY()).thenReturn(100);
        Point2D panLast = new Point2D.Double(100, 100);
        chartPanel.setPanLast(panLast);

        chartPanel.mouseDragged(mockEvent);

        // Since dx and dy are zero, no panning should occur
        verify(mockPlot, never()).setNotify(anyBoolean());
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNotNull_DxDyNonZero_VerticalOrientation() {
        chartPanel.setPopupMenu(null);
        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(150);
        when(mockEvent.getY()).thenReturn(150);
        Point2D panLast = new Point2D.Double(100, 100);
        chartPanel.setPanLast(panLast);

        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot instanceof Zoomable).thenReturn(false);
        when(mockPlot.getClass()).thenReturn(mockPannable.getClass());
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot.getClass()).thenReturn(mockPannable.getClass());
        when(mockPlot.getClass()).thenReturn(mockPannable.getClass());
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.isNotify()).thenReturn(true);

        chartPanel.setPlot(mockPlot);
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.isNotify()).thenReturn(true);
        when(((Pannable) mockPlot).isDomainPannable()).thenReturn(true);
        when(((Pannable) mockPlot).isRangePannable()).thenReturn(true);

        chartPanel.mouseDragged(mockEvent);

        verify(mockPlot).setNotify(false);
        verify(mockPlot).panDomainAxes(anyDouble(), any(), any());
        verify(mockPlot).panRangeAxes(anyDouble(), any(), any());
        verify(mockPlot).setNotify(true);
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNotNull_DxDyNonZero_HorizontalOrientation() {
        chartPanel.setPopupMenu(null);
        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(80);
        when(mockEvent.getY()).thenReturn(120);
        Point2D panLast = new Point2D.Double(100, 100);
        chartPanel.setPanLast(panLast);

        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(mockPlot.isNotify()).thenReturn(true);

        chartPanel.setPlot(mockPlot);
        when(((Pannable) mockPlot).isDomainPannable()).thenReturn(true);
        when(((Pannable) mockPlot).isRangePannable()).thenReturn(true);

        chartPanel.mouseDragged(mockEvent);

        verify(mockPlot).setNotify(false);
        verify(mockPlot).panDomainAxes(anyDouble(), any(), any());
        verify(mockPlot).panRangeAxes(anyDouble(), any(), any());
        verify(mockPlot).setNotify(true);
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNotNull_DxDyNonZero_PanningNotPossible() {
        chartPanel.setPopupMenu(null);
        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(150);
        when(mockEvent.getY()).thenReturn(150);
        Point2D panLast = new Point2D.Double(100, 100);
        chartPanel.setPanLast(panLast);

        when(mockPlot instanceof Pannable).thenReturn(false);

        chartPanel.mouseDragged(mockEvent);

        // No panning should occur
        verify(mockPlot, never()).setNotify(anyBoolean());
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNull() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(null);
        MouseEvent mockEvent = mock(MouseEvent.class);
        chartPanel.mouseDragged(mockEvent);

        // No actions should be performed
        verify(mockGraphics, never()).dispose();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferTrue_HZoomVZoomTrue() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(100, 100));
        chartPanel.setUseBuffer(true);
        chartPanel.setOrientation(PlotOrientation.VERTICAL);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(200);
        when(mockEvent.getY()).thenReturn(200);

        chartPanel.mouseDragged(mockEvent);

        // Expect repaint to be called
        verify(chartPanel, times(1)).repaint();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferTrue_HZoomTrue_VZoomFalse() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(50, 50));
        chartPanel.setUseBuffer(true);
        chartPanel.setOrientation(PlotOrientation.VERTICAL);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(false);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(150);
        when(mockEvent.getY()).thenReturn(100);

        chartPanel.mouseDragged(mockEvent);

        // Expect repaint to be called
        verify(chartPanel, times(1)).repaint();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferTrue_HZoomFalse_VZoomTrue() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(75, 75));
        chartPanel.setUseBuffer(true);
        chartPanel.setOrientation(PlotOrientation.VERTICAL);
        chartPanel.setDomainZoomable(false);
        chartPanel.setRangeZoomable(true);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(100);
        when(mockEvent.getY()).thenReturn(150);

        chartPanel.mouseDragged(mockEvent);

        // Expect repaint to be called
        verify(chartPanel, times(1)).repaint();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferTrue_HZoomFalse_VZoomFalse() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(60, 60));
        chartPanel.setUseBuffer(true);
        chartPanel.setOrientation(PlotOrientation.VERTICAL);
        chartPanel.setDomainZoomable(false);
        chartPanel.setRangeZoomable(false);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(70);
        when(mockEvent.getY()).thenReturn(80);

        chartPanel.mouseDragged(mockEvent);

        // No zoom rectangle should be set, but repaint should be called
        verify(chartPanel, times(1)).repaint();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferFalse_HZoomVZoomTrue() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(100, 100));
        chartPanel.setUseBuffer(false);
        chartPanel.setOrientation(PlotOrientation.HORIZONTAL);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);

        Graphics2D spyGraphics = mock(Graphics2D.class);
        when(mockGraphics.create()).thenReturn(spyGraphics);
        when(chartPanel.getGraphics()).thenReturn(mockGraphics);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(200);
        when(mockEvent.getY()).thenReturn(200);

        chartPanel.mouseDragged(mockEvent);

        // Expect drawZoomRectangle to be called twice (erase and draw)
        verify(spyGraphics, times(2)).setXORMode(any());
        verify(spyGraphics, times(2)).draw(any());
        verify(spyGraphics, times(1)).dispose();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferFalse_HZoomTrue_VZoomFalse() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(50, 50));
        chartPanel.setUseBuffer(false);
        chartPanel.setOrientation(PlotOrientation.HORIZONTAL);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(false);

        Graphics2D spyGraphics = mock(Graphics2D.class);
        when(mockGraphics.create()).thenReturn(spyGraphics);
        when(chartPanel.getGraphics()).thenReturn(mockGraphics);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(150);
        when(mockEvent.getY()).thenReturn(100);

        chartPanel.mouseDragged(mockEvent);

        // Expect drawZoomRectangle to be called twice (erase and draw)
        verify(spyGraphics, times(2)).setXORMode(any());
        verify(spyGraphics, times(2)).draw(any());
        verify(spyGraphics, times(1)).dispose();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferFalse_HZoomFalse_VZoomTrue() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(75, 75));
        chartPanel.setUseBuffer(false);
        chartPanel.setOrientation(PlotOrientation.HORIZONTAL);
        chartPanel.setDomainZoomable(false);
        chartPanel.setRangeZoomable(true);

        Graphics2D spyGraphics = mock(Graphics2D.class);
        when(mockGraphics.create()).thenReturn(spyGraphics);
        when(chartPanel.getGraphics()).thenReturn(mockGraphics);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(100);
        when(mockEvent.getY()).thenReturn(150);

        chartPanel.mouseDragged(mockEvent);

        // Expect drawZoomRectangle to be called twice (erase and draw)
        verify(spyGraphics, times(2)).setXORMode(any());
        verify(spyGraphics, times(2)).draw(any());
        verify(spyGraphics, times(1)).dispose();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_UseBufferFalse_HZoomFalse_VZoomFalse() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(60, 60));
        chartPanel.setUseBuffer(false);
        chartPanel.setOrientation(PlotOrientation.VERTICAL);
        chartPanel.setDomainZoomable(false);
        chartPanel.setRangeZoomable(false);

        Graphics2D spyGraphics = mock(Graphics2D.class);
        when(mockGraphics.create()).thenReturn(spyGraphics);
        when(chartPanel.getGraphics()).thenReturn(mockGraphics);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(70);
        when(mockEvent.getY()).thenReturn(80);

        chartPanel.mouseDragged(mockEvent);

        // Even if hZoom and vZoom are false, drawZoomRectangle should be called twice
        verify(spyGraphics, times(2)).setXORMode(any());
        verify(spyGraphics, times(2)).draw(any());
        verify(spyGraphics, times(1)).dispose();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_InvalidMouseEvent() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(-10, -10));
        chartPanel.setUseBuffer(true);
        chartPanel.setOrientation(PlotOrientation.VERTICAL);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(-20);
        when(mockEvent.getY()).thenReturn(-20);

        chartPanel.mouseDragged(mockEvent);

        // Expect repaint to be called even if coordinates are invalid
        verify(chartPanel, times(1)).repaint();
    }

    @Test
    void testMouseDragged_PopupNotShowing_PanLastNull_ZoomPointNotNull_ScaledDataAreaNull() {
        chartPanel.setPopupMenu(null);
        chartPanel.setPanLast(null);
        chartPanel.setZoomPoint(new Point2D.Double(100, 100));
        chartPanel.setUseBuffer(true);
        chartPanel.setOrientation(PlotOrientation.VERTICAL);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);

        // Mock getScreenDataArea to return null
        ChartRenderingInfo mockInfo = mock(ChartRenderingInfo.class);
        when(mockInfo.getPlotInfo()).thenReturn(mock(PlotRenderingInfo.class));
        chartPanel.setChartRenderingInfo(mockInfo);
        when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(null);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getX()).thenReturn(200);
        when(mockEvent.getY()).thenReturn(200);

        chartPanel.mouseDragged(mockEvent);

        // Expect repaint to be called even if scaledDataArea is null
        verify(chartPanel, times(1)).repaint();
    }

    // Helper methods to set private fields using reflection
    private void setPanLast(ChartPanel panel, Point2D panLast) {
        try {
            java.lang.reflect.Field field = ChartPanel.class.getDeclaredField("panLast");
            field.setAccessible(true);
            field.set(panel, panLast);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setZoomPoint(ChartPanel panel, Point2D zoomPoint) {
        try {
            java.lang.reflect.Field field = ChartPanel.class.getDeclaredField("zoomPoint");
            field.setAccessible(true);
            field.set(panel, zoomPoint);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setPanLast(Point2D panLast) {
        setPanLast(chartPanel, panLast);
    }

    private void setZoomPoint(Point2D zoomPoint) {
        setZoomPoint(chartPanel, zoomPoint);
    }

    private void setUseBuffer(boolean useBuffer) {
        try {
            java.lang.reflect.Field field = ChartPanel.class.getDeclaredField("useBuffer");
            field.setAccessible(true);
            field.setBoolean(chartPanel, useBuffer);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setOrientation(PlotOrientation orientation) {
        try {
            java.lang.reflect.Field field = ChartPanel.class.getDeclaredField("orientation");
            field.setAccessible(true);
            field.set(chartPanel, orientation);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setDomainZoomable(boolean domainZoomable) {
        try {
            java.lang.reflect.Field field = ChartPanel.class.getDeclaredField("domainZoomable");
            field.setAccessible(true);
            field.setBoolean(chartPanel, domainZoomable);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setRangeZoomable(boolean rangeZoomable) {
        try {
            java.lang.reflect.Field field = ChartPanel.class.getDeclaredField("rangeZoomable");
            field.setAccessible(true);
            field.setBoolean(chartPanel, rangeZoomable);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setPlot(Plot plot) {
        try {
            java.lang.reflect.Method method = ChartPanel.class.getDeclaredMethod("setChart", JFreeChart.class);
            method.setAccessible(true);
            method.invoke(chartPanel, mockChart);
            // Already mocked getPlot to return mockPlot
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}