package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class Base64Variant_decode_0_2_Test {

    @Test
    @DisplayName("decode encounters invalid character in first base64 character and throws IllegalArgumentException")
    void TC06_decodeInvalidFirstBase64Character() {
        // GIVEN
        String str = "@WFu";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = new Base64Variant("CustomVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", false, '=',  Integer.MAX_VALUE);

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> variant.decode(str, builder));
    }

    @Test
    @DisplayName("decode encounters unexpected end of input after first base64 character and throws IllegalArgumentException")
    void TC07_decodeUnexpectedEOFAfterFirstCharacter() {
        // GIVEN
        String str = "T";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = new Base64Variant("CustomVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", false, '=',  Integer.MAX_VALUE);

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> variant.decode(str, builder));
    }

    @Test
    @DisplayName("decode encounters invalid character in second base64 character and throws IllegalArgumentException")
    void TC08_decodeInvalidSecondBase64Character() {
        // GIVEN
        String str = "T@Fu";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = new Base64Variant("CustomVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", false, '=',  Integer.MAX_VALUE);

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> variant.decode(str, builder));
    }

    @Test
    @DisplayName("decode encounters unexpected padding when padding is not accepted and throws IllegalArgumentException")
    void TC09_decodeUnexpectedPaddingWhenNotAccepted() throws Exception {
        // GIVEN
        String str = "TWE=";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = new Base64Variant("CustomVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", false, '=', Integer.MAX_VALUE);

        // Using reflection to set acceptsPaddingOnRead to false
        Field paddingReadBehaviourField = Base64Variant.class.getDeclaredField("_paddingReadBehaviour");
        paddingReadBehaviourField.setAccessible(true);
        paddingReadBehaviourField.set(variant, Base64Variant.PaddingReadBehaviour.PADDING_FORBIDDEN);

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> variant.decode(str, builder));
    }

    @Test
    @DisplayName("decode encounters unexpected EOF when padding is required and throws IllegalArgumentException")
    void TC10_decodeUnexpectedEOFWhenPaddingRequired() throws Exception {
        // GIVEN
        String str = "TWE";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = new Base64Variant("CustomVariant", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", false, '=', Integer.MAX_VALUE);

        // Using reflection to set requiresPaddingOnRead to true
        Field paddingReadBehaviourField = Base64Variant.class.getDeclaredField("_paddingReadBehaviour");
        paddingReadBehaviourField.setAccessible(true);
        paddingReadBehaviourField.set(variant, Base64Variant.PaddingReadBehaviour.PADDING_REQUIRED);

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> variant.decode(str, builder));
    }
}
