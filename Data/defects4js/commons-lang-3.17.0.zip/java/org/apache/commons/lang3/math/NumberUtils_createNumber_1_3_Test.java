package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_createNumber_1_3_Test {

    @Test
    @DisplayName("Input string with prefix '#' followed by invalid hex digit, should throw NumberFormatException")
    void TC47_createNumber_invalidHex() {
        String input = "#1G";
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input), "Expected NumberFormatException for input: " + input);
    }

    @Test
    @DisplayName("Input string with type suffix 'fd', should throw NumberFormatException due to multiple suffixes")
    void TC48_createNumber_multipleSuffixes() {
        String input = "123.45fd";
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input), "Expected NumberFormatException for input: " + input);
    }

    @Test
    @DisplayName("Input string with type suffix 'L' on a decimal number, should throw NumberFormatException")
    void TC49_createNumber_decimalWithLSuffix() {
        String input = "123.45L";
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input), "Expected NumberFormatException for input: " + input);
    }

    @Test
    @DisplayName("Input string with hexadecimal prefix '0x' and single leading zero, should return Integer with value 0")
    void TC50_createNumber_hexPrefixSingleZero() {
        String input = "0x0";
        Number result = NumberUtils.createNumber(input);
        assertTrue(result instanceof Integer, "Expected result to be an Integer");
        assertEquals(0, result.intValue(), "Expected Integer value to be 0");
    }

    @Test
    @DisplayName("Input string with leading '+' and hexadecimal prefix '0x', valid, should return Integer")
    void TC51_createNumber_positiveHexPrefix() {
        String input = "+0x1A";
        Number result = NumberUtils.createNumber(input);
        assertTrue(result instanceof Integer, "Expected result to be an Integer");
        assertEquals(26, result.intValue(), "Expected Integer value to be 26");
    }
}