package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.util.FastMath;

public class FastMath_pow_0_4_Test {

    @Test
    @DisplayName("pow(x, y) handles general case with positive x and non-integer y")
    void TC16_pow_positive_x_non_integer_y() {
        double x = 2.5;
        double y = 3.5;
        double result = FastMath.pow(x, y);
        assertEquals(Math.pow(x, y), result, 1e-10, "Result should accurately be x raised to y");
    }

    @Test
    @DisplayName("pow(x, y) returns +0.0 when x < 1 and y approaches +infinity")
    void TC17_pow_small_x_y_positive_infinite() {
        double x = 0.5;
        double y = Double.MAX_VALUE;
        double result = FastMath.pow(x, y);
        assertEquals(+0.0, result, "Result should be +0.0");
    }

    @Test
    @DisplayName("pow(x, y) returns Double.POSITIVE_INFINITY when x > 1 and y approaches +infinity")
    void TC18_pow_large_x_y_positive_infinite() {
        double x = 10.0;
        double y = Double.MAX_VALUE;
        double result = FastMath.pow(x, y);
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be Double.POSITIVE_INFINITY");
    }

    @Test
    @DisplayName("pow(x, y) returns Double.NaN when x is negative infinity and y is non-integer")
    void TC19_pow_negative_infty_x_non_integer_y() {
        double x = Double.NEGATIVE_INFINITY;
        double y = 2.5;
        double result = FastMath.pow(x, y);
        assertTrue(Double.isNaN(result), "Result should be Double.NaN");
    }

    @Test
    @DisplayName("pow(x, y) returns 1.0 when y is an even integer and x is negative")
    void TC20_pow_negative_x_even_integer_y() {
        double x = -3.0;
        double y = 4.0;
        double result = FastMath.pow(x, y);
        assertEquals(1.0, result, "Result should be 1.0");
    }

}