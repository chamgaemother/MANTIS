package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class ClassBands_addAnnotation_0_2_Test {

    private ClassBands classBands;
    private List<String> mockList;

    @BeforeEach
    void setup() {
        classBands = new ClassBands(mock(ClassBands.Segment.class), 0, 0, false);
        mockList = new ArrayList<>();
    }

    @Test
    @DisplayName("Add a visible field annotation with RVA bit set in the last flag.")
    void test_visibleFieldAnnotation_withRVABitSet() throws Exception {
        MetadataBandGroup field_RVA_bands = mock(MetadataBandGroup.class);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlags.add(2097152L);  // RVA bit set

        int context = MetadataBandGroup.CONTEXT_FIELD;
        boolean visible = true;

        classBands.field_RVA_bands = field_RVA_bands;
        classBands.tempFieldFlags = tempFieldFlags;

        classBands.addAnnotation(context, "desc", visible, mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);

        verify(field_RVA_bands, times(1)).addAnnotation("desc", mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);
        verify(field_RVA_bands, times(1)).incrementAnnoN();
    }

    @Test
    @DisplayName("Add an invisible field annotation without RIA bit in the last flag.")
    void test_invisibleFieldAnnotation_withoutRIABit() throws Exception {
        MetadataBandGroup field_RIA_bands = mock(MetadataBandGroup.class);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlags.add(0L);  // RIA bit not set

        int context = MetadataBandGroup.CONTEXT_FIELD;
        boolean visible = false;

        classBands.field_RIA_bands = field_RIA_bands;
        classBands.tempFieldFlags = tempFieldFlags;

        classBands.addAnnotation(context, "desc", visible, mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);

        verify(field_RIA_bands, times(1)).addAnnotation("desc", mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);
        verify(field_RIA_bands, times(1)).newEntryInAnnoN();
    }

    @Test
    @DisplayName("Add an invisible field annotation with RIA bit set in the last flag.")
    void test_invisibleFieldAnnotation_withRIABitSet() throws Exception {
        MetadataBandGroup field_RIA_bands = mock(MetadataBandGroup.class);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlags.add(4194304L);  // RIA bit set

        int context = MetadataBandGroup.CONTEXT_FIELD;
        boolean visible = false;

        classBands.field_RIA_bands = field_RIA_bands;
        classBands.tempFieldFlags = tempFieldFlags;

        classBands.addAnnotation(context, "desc", visible, mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);

        verify(field_RIA_bands, times(1)).addAnnotation("desc", mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);
        verify(field_RIA_bands, times(1)).incrementAnnoN();
    }

    @Test
    @DisplayName("Add a visible method annotation with no RVA bit set in the last flag.")
    void test_visibleMethodAnnotation_withNoRVABitSet() throws Exception {
        MetadataBandGroup method_RVA_bands = mock(MetadataBandGroup.class);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add(0L);  // RVA bit not set

        int context = MetadataBandGroup.CONTEXT_METHOD;
        boolean visible = true;

        classBands.method_RVA_bands = method_RVA_bands;
        classBands.tempMethodFlags = tempMethodFlags;

        classBands.addAnnotation(context, "desc", visible, mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);

        verify(method_RVA_bands, times(1)).addAnnotation("desc", mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);
        verify(method_RVA_bands, times(1)).newEntryInAnnoN();
    }

    @Test
    @DisplayName("Add a visible method annotation with RVA bit set in the last flag.")
    void test_visibleMethodAnnotation_withRVABitSet() throws Exception {
        MetadataBandGroup method_RVA_bands = mock(MetadataBandGroup.class);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlags.add(2097152L);  // RVA bit set

        int context = MetadataBandGroup.CONTEXT_METHOD;
        boolean visible = true;

        classBands.method_RVA_bands = method_RVA_bands;
        classBands.tempMethodFlags = tempMethodFlags;

        classBands.addAnnotation(context, "desc", visible, mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);

        verify(method_RVA_bands, times(1)).addAnnotation("desc", mockList, mockList, 
                mockList, mockList, mockList, mockList, mockList);
        verify(method_RVA_bands, times(1)).incrementAnnoN();
    }

}
