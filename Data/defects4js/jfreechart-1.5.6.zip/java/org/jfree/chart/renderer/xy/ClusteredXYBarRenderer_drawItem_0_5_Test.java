package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClusteredXYBarRenderer_drawItem_0_5_Test {

    @Test
    @DisplayName("drawItem does not add entity when PlotRenderingInfo is null")
    void TC21_drawItem_with_null_PlotRenderingInfo() throws Exception {
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(false).when(renderer).getUseYInterval();
        doReturn(0.0).when(renderer).getBase();
        doReturn(false).when(renderer).getShadowsVisible();
        doReturn(0.0).when(renderer).getMargin();
        doReturn(false).when(renderer).isItemLabelVisible(series, item);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, never()).addEntity(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    @DisplayName("drawItem does not add entity when entity collection is null")
    void TC22_drawItem_with_null_entity_collection() throws Exception {
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        XYPlot plot = mock(XYPlot.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = null;
        when(info.getOwner()).thenReturn(null); // Added to fix potential NPE
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 1;

        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(false).when(renderer).getUseYInterval();
        doReturn(0.0).when(renderer).getBase();
        doReturn(false).when(renderer).getShadowsVisible();
        doReturn(0.0).when(renderer).getMargin();
        doReturn(false).when(renderer).isItemLabelVisible(series, item);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer, never()).addEntity(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

//     @Test
//     @DisplayName("drawItem handles positive y1 with inverted range axis")
//     void TC23_drawItem_with_positive_y1_and_inverted_range_axis() {
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         int series = 2;
//         int item = 2;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 1;
// 
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
//         when(renderer.getUseYInterval()).thenReturn(true);
//         when(renderer.getBase()).thenReturn(0.0);
//         when(dataset.getStartYValue(series, item)).thenReturn(10.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(20.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(renderer.getMargin()).thenReturn(0.1);
//         when(renderer.isSeriesVisible(series)).thenReturn(true);
//         BarPainter painterMock = mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(painterMock);
//         when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
// 
//         when(rangeAxis.isInverted()).thenReturn(true);
// 
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         assertTrue(true);
//     }

//     @Test
//     @DisplayName("drawItem handles negative y1 with non-inverted range axis")
//     void TC24_drawItem_with_negative_y1_and_non_inverted_range_axis() {
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         int series = 3;
//         int item = 3;
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 1;
// 
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
//         when(renderer.getUseYInterval()).thenReturn(false);
//         when(renderer.getBase()).thenReturn(5.0);
//         when(dataset.getYValue(series, item)).thenReturn(-15.0);
//         when(rangeAxis.valueToJava2D(-15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(70.0);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(renderer.getMargin()).thenReturn(0.05);
//         when(renderer.isSeriesVisible(series)).thenReturn(true);
//         BarPainter painterMock = mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(painterMock);
//         when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
// 
//         when(rangeAxis.isInverted()).thenReturn(false);
// 
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         assertTrue(true);
//     }

//     @Test
//     @DisplayName("drawItem handles multiple passes with shadows and labels")
//     void TC25_drawItem_with_multiple_passes_shadows_and_labels() {
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         int series = 4;
//         int item = 4;
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         List<Integer> passes = List.of(0, 1);
//         for (int pass : passes) {
//             when(renderer.getItemVisible(series, item)).thenReturn(true);
//             when(renderer.getUseYInterval()).thenReturn(true);
//             when(renderer.getBase()).thenReturn(10.0);
//             when(dataset.getStartYValue(series, item)).thenReturn(20.0);
//             when(dataset.getEndYValue(series, item)).thenReturn(30.0);
//             when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(40.0);
//             when(rangeAxis.valueToJava2D(30.0, dataArea, RectangleEdge.LEFT)).thenReturn(60.0);
//             when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//             when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//             when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//             when(renderer.getMargin()).thenReturn(0.1);
//             when(renderer.isSeriesVisible(series)).thenReturn(true);
//             BarPainter painterMock = mock(BarPainter.class);
//             when(renderer.getBarPainter()).thenReturn(painterMock);
//             when(renderer.isItemLabelVisible(series, item)).thenReturn(true);
//             XYItemLabelGenerator labelGeneratorMock = mock(XYItemLabelGenerator.class);
//             when(renderer.getItemLabelGenerator(series, item)).thenReturn(labelGeneratorMock);
//             doNothing().when(renderer).drawItemLabel(any(), any(), anyInt(), anyInt(), any(), any(), anyDouble(), anyBoolean());
// 
//             doReturn(true).when(renderer).getShadowsVisible();
// 
//             renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//             if (pass == 0) {
//                 verify(painterMock).paintBarShadow(any(), any(), eq(series), eq(item), any(), any(), anyBoolean());
//             } else if (pass == 1) {
//                 verify(painterMock).paintBar(any(), any(), eq(series), eq(item), any(), any());
//                 verify(renderer).drawItemLabel(any(), any(), eq(series), eq(item), any(), any(), anyDouble(), anyBoolean());
//                 verify(renderer).addEntity(any(), any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//             }
//         }
//     }
}