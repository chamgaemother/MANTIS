package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class LineUtils_clipLine_0_3_Test {

    @Test
    @DisplayName("Clip line with both endpoints outside but intersecting the rectangle")
    public void TC11_clipLine_both_endpoints_outside_intersecting() {
        // GIVEN
        Line2D line = new Line2D.Double(-1.0, -1.0, 5.0, 5.0);
        Rectangle2D rect = new Rectangle2D.Double(0.0, 0.0, 4.0, 4.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result);
        // After clipping, the line should start and end at the intersection points with the rectangle
        assertEquals(0.0, line.getX1(), 1e-6);
        assertEquals(0.0, line.getY1(), 1e-6);
        assertEquals(4.0, line.getX2(), 1e-6);
        assertEquals(4.0, line.getY2(), 1e-6);
    }

    @Test
    @DisplayName("Clip line with infinite slope (dx = 0)")
    public void TC12_clipLine_infinite_slope_vertical() {
        // GIVEN
        Line2D line = new Line2D.Double(2.0, -5.0, 2.0, 10.0);
        Rectangle2D rect = new Rectangle2D.Double(0.0, 0.0, 4.0, 4.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result);
        // After clipping, the line should be between the top and bottom boundaries of the rectangle
        assertEquals(2.0, line.getX1(), 1e-6);
        assertEquals(0.0, line.getY1(), 1e-6);
        assertEquals(2.0, line.getX2(), 1e-6);
        assertEquals(4.0, line.getY2(), 1e-6);
    }

    @Test
    @DisplayName("Clip line with zero length inside the rectangle")
    public void TC13_clipLine_zero_length_inside() {
        // GIVEN
        Line2D line = new Line2D.Double(2.0, 2.0, 2.0, 2.0);
        Rectangle2D rect = new Rectangle2D.Double(0.0, 0.0, 4.0, 4.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result);
        // Line endpoints should remain unchanged
        assertEquals(2.0, line.getX1(), 1e-6);
        assertEquals(2.0, line.getY1(), 1e-6);
        assertEquals(2.0, line.getX2(), 1e-6);
        assertEquals(2.0, line.getY2(), 1e-6);
    }

    @Test
    @DisplayName("Clip line with both endpoints on the boundary but not intersecting the rectangle")
    public void TC14_clipLine_endpoints_on_boundary_no_intersection() {
        // GIVEN
        Line2D line = new Line2D.Double(0.0, 0.0, 4.0, 4.0);
        Rectangle2D rect = new Rectangle2D.Double(1.0, 1.0, 2.0, 2.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result);
        // Line should remain unchanged
        assertEquals(0.0, line.getX1(), 1e-6);
        assertEquals(0.0, line.getY1(), 1e-6);
        assertEquals(4.0, line.getX2(), 1e-6);
        assertEquals(4.0, line.getY2(), 1e-6);
    }

    @Test
    @DisplayName("Clip line with one endpoint outside and non-finite y1 coordinate")
    public void TC15_clipLine_non_finite_y1() {
        // GIVEN
        Line2D line = new Line2D.Double(2.0, Double.NEGATIVE_INFINITY, 3.0, 3.0);
        Rectangle2D rect = new Rectangle2D.Double(0.0, 0.0, 4.0, 4.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertFalse(result);
        // Line should remain unchanged
        assertEquals(2.0, line.getX1(), 1e-6);
        assertEquals(Double.NEGATIVE_INFINITY, line.getY1(), 1e-6);
        assertEquals(3.0, line.getX2(), 1e-6);
        assertEquals(3.0, line.getY2(), 1e-6);
    }
}