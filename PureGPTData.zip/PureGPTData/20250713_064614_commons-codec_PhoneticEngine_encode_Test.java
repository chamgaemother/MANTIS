import org.apache.commons.codec.language.bm.*;
import org.apache.commons.codec.language.bm.Languages.LanguageSet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

class PhoneticEngineTest {

    @Test
    void testEncodeWithNullInput() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.APPROX, true);
        assertThrows(NullPointerException.class, () -> engine.encode(null));
    }

    @Test
    void testEncodeWithEmptyString() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.APPROX, true);
        assertEquals("", engine.encode(""));
    }

    @Test
    void testEncodeWithSingleWord() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.APPROX, true);
        assertEquals("ash", engine.encode("ash"));
    }

    @Test
    void testEncodeWithDPrefix() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.APPROX, true);
        String result = engine.encode("d'artagnan");
        assertTrue(result.contains("(artagnan)") && result.contains("(dartagnan)"));
    }

    @Test
    void testEncodeWithKnownPrefixSephardic() {
        PhoneticEngine engine = new PhoneticEngine(NameType.SEPHARDIC, RuleType.APPROX, true);
        String result = engine.encode("do re").trim();
        assertTrue(result.equals("re") || result.endsWith("-re"));
    }

    @Test
    void testEncodeWithKnownPrefixButInvalidWord() {
        PhoneticEngine engine = new PhoneticEngine(NameType.ASHKENAZI, RuleType.APPROX, true);
        assertEquals("", engine.encode("von abc"));
    }

    @Test
    void testEncodeWithConcatenation() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.APPROX, true);
        String encoded = engine.encode("abra kadabra");
        assertNotNull(encoded);
        assertFalse(encoded.isEmpty());
    }

    @Test
    void testEncodeWithoutConcatenation() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.APPROX, false);
        String encoded = engine.encode("abra kadabra");
        assertNotNull(encoded);
        assertFalse(encoded.isEmpty());
    }

    @Test
    void testEncodeForUnknownPrefixAndConcat() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, true);
        String encoded = engine.encode("xanadu");
        assertNotNull(encoded);
    }

    @Test
    void testEncodeForSymbolsAndSpaces() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, true);
        String encoded = engine.encode("xanadu !!!");
        assertEquals("", encoded.trim());
    }

    @Test
    void testEncodeMultipleWordsNoConcat() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.APPROX, false);
        String encoded = engine.encode("multiple words");
        assertTrue(encoded.contains("-"));
    }

    @Test
    void testEncodeEmptyLanguageSet() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, true);
        LanguageSet emptySet = Languages.NO_LANGUAGES;
        assertEquals("", engine.encode("xanadu", emptySet));
    }

    @Test
    void testEncodeCertainLanguageSet() {
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.EXACT, true);
        List<String> langs = Arrays.asList("english");
        LanguageSet certainSet = Languages.LanguageSet.from(langs);
        String result = engine.encode("abc", certainSet);
        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
}