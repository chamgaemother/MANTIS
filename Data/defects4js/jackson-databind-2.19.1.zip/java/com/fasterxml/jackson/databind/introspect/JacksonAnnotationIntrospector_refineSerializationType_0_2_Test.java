package com.fasterxml.jackson.databind.introspect;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.introspect.Annotated;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class JacksonAnnotationIntrospector_refineSerializationType_0_2_Test {

//     @Test
//     @DisplayName("serClass is primitive wrapper of baseType's raw class, apply static typing")
//     public void TC06_serClassIsPrimitiveWrapper_shouldApplyStaticTyping() throws Exception {
        // GIVEN
//         MapperConfig<?> config = mock(MapperConfig.class);
//         Annotated annotated = mock(Annotated.class);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.getRawClass()).thenReturn(int.class);
// 
//         JacksonAnnotationIntrospector introspector = spy(new JacksonAnnotationIntrospector());
//         doReturn(Integer.class).when(introspector)._classIfExplicit(any());
// 
        // WHEN
//         JavaType result = introspector.refineSerializationType(config, annotated, baseType);
// 
        // THEN
//         verify(baseType, atLeastOnce()).withStaticTyping();
//         assertNotNull(result);
//     }

    @Test
    @DisplayName("serClass is null after _classIfExplicit, no refinement applied")
    public void TC07_serClassIsNull_shouldReturnOriginalType() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        Annotated annotated = mock(Annotated.class);

        JavaType baseType = mock(JavaType.class);
        when(baseType.equals(baseType)).thenReturn(true);

        JacksonAnnotationIntrospector introspector = spy(new JacksonAnnotationIntrospector());
        doReturn(null).when(introspector)._classIfExplicit(any());

        // WHEN
        JavaType result = introspector.refineSerializationType(config, annotated, baseType);

        // THEN
        assertEquals(baseType, result);
    }

//     @Test
//     @DisplayName("type is map-like, keyClass is specified and matches keyType's raw class")
//     public void TC08_mapLikeType_withMatchingKeyClass_shouldApplyStaticTypingOnKey() throws Exception {
        // GIVEN
//         MapperConfig<?> config = mock(MapperConfig.class);
//         Annotated annotated = mock(Annotated.class);
// 
//         JavaType keyType = mock(JavaType.class);
//         when(keyType.getRawClass()).thenReturn(String.class);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.isMapLikeType()).thenReturn(true);
//         when(baseType.getKeyType()).thenReturn(keyType);
// 
//         JacksonAnnotationIntrospector introspector = spy(new JacksonAnnotationIntrospector());
//         doReturn(String.class).when(introspector)._classIfExplicit(any());
// 
        // WHEN
//         JavaType result = introspector.refineSerializationType(config, annotated, baseType);
// 
        // THEN
//         verify(keyType, atLeastOnce()).withStaticTyping();
//         assertNotNull(result);
//     }

//     @Test
//     @DisplayName("type is map-like, keyClass is a superclass of keyType's raw class")
//     public void TC09_mapLikeType_withSuperClassKey_shouldGeneralizeKeyType() throws Exception {
        // GIVEN
//         MapperConfig<?> config = mock(MapperConfig.class);
//         Annotated annotated = mock(Annotated.class);
// 
//         JavaType keyType = mock(JavaType.class);
//         when(keyType.getRawClass()).thenReturn(Integer.class);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.isMapLikeType()).thenReturn(true);
//         when(baseType.getKeyType()).thenReturn(keyType);
// 
//         JacksonAnnotationIntrospector introspector = spy(new JacksonAnnotationIntrospector());
//         doReturn(Number.class).when(introspector)._classIfExplicit(any());
// 
        // Set expectation for TypeFactory
//         JavaType generalizedKeyType = mock(JavaType.class);
//         when(config.getTypeFactory().constructGeneralizedType(keyType, Number.class)).thenReturn(generalizedKeyType);
//         when(baseType.withKeyType(generalizedKeyType)).thenReturn(baseType);
// 
        // WHEN
//         JavaType result = introspector.refineSerializationType(config, annotated, baseType);
// 
        // THEN
//         assertEquals(generalizedKeyType, result.getKeyType());
//     }

//     @Test
//     @DisplayName("type is map-like, keyClass is subclass of keyType's raw class")
//     public void TC10_mapLikeType_withSubClassKey_shouldSpecializeKeyType() throws Exception {
        // GIVEN
//         MapperConfig<?> config = mock(MapperConfig.class);
//         Annotated annotated = mock(Annotated.class);
// 
//         JavaType keyType = mock(JavaType.class);
//         when(keyType.getRawClass()).thenReturn(Number.class);
// 
//         JavaType baseType = mock(JavaType.class);
//         when(baseType.isMapLikeType()).thenReturn(true);
//         when(baseType.getKeyType()).thenReturn(keyType);
// 
//         JacksonAnnotationIntrospector introspector = spy(new JacksonAnnotationIntrospector());
//         doReturn(Integer.class).when(introspector)._classIfExplicit(any());
// 
        // Set expectation for TypeFactory
//         JavaType specializedKeyType = mock(JavaType.class);
//         when(config.getTypeFactory().constructSpecializedType(keyType, Integer.class)).thenReturn(specializedKeyType);
//         when(baseType.withKeyType(specializedKeyType)).thenReturn(baseType);
// 
        // WHEN
//         JavaType result = introspector.refineSerializationType(config, annotated, baseType);
// 
        // THEN
//         assertEquals(specializedKeyType, result.getKeyType());
//     }
}