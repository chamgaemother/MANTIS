import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;
import java.lang.reflect.Field;

public class ConcurrentReferenceHashMap_size_1_1_Test {

    @Test
    @DisplayName("Size computation with i16 exactly equal to 2 triggering the retry mechanism")
    public void TC11_sizeWith_i16EqualTo2_Retry() throws Exception {
        // Initialize ConcurrentReferenceHashMap with 2 segments
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
            .setInitialCapacity(2)
            .setLoadFactor(0.75f)
            .setConcurrencyLevel(2)
            .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
            .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
            .get();

        // Use reflection to set segment counts and modCounts
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Class<?> segmentClass = segment.getClass();

            Field countField = segmentClass.getDeclaredField("count");
            countField.setAccessible(true);
            Field modCountField = segmentClass.getDeclaredField("modCount");
            modCountField.setAccessible(true);

            if (i == 0) {
                countField.setInt(segment, 2);
                modCountField.setInt(segment, 1);
            } else if (i == 1) {
                countField.setInt(segment, 2);
                modCountField.setInt(segment, 2);
            }
        }

        // Call size()
        int size = map.size();

        // Assert that size is 4
        assertEquals(4, size);
    }

    @Test
    @DisplayName("Size computation with i17 exceeding threshold causing rehash and reducing the sum")
    public void TC12_sizeWith_i17ExceedingThreshold_Rehash() throws Exception {
        // Initialize ConcurrentReferenceHashMap with 4 segments
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
            .setInitialCapacity(16)
            .setLoadFactor(0.5f)
            .setConcurrencyLevel(4)
            .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
            .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
            .get();

        // Use reflection to set segment counts and modCounts
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Class<?> segmentClass = segment.getClass();

            Field countField = segmentClass.getDeclaredField("count");
            countField.setAccessible(true);
            Field modCountField = segmentClass.getDeclaredField("modCount");
            modCountField.setAccessible(true);

            countField.setInt(segment, 10);
            modCountField.setInt(segment, 1);
        }

        // Call size()
        int size = map.size();

        // Assert that size is 40
        assertEquals(40, size);
    }

    @Test
    @DisplayName("Size computation with i19 exactly equal to i23 triggering boundary condition in inner loop")
    public void TC13_sizeWith_i19EqualTo_i23_BoundaryCondition() throws Exception {
        // Initialize ConcurrentReferenceHashMap with 4 segments
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
            .setInitialCapacity(8)
            .setLoadFactor(0.75f)
            .setConcurrencyLevel(4)
            .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
            .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
            .get();

        // Use reflection to set segment counts and modCounts
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Class<?> segmentClass = segment.getClass();

            Field countField = segmentClass.getDeclaredField("count");
            countField.setAccessible(true);
            Field modCountField = segmentClass.getDeclaredField("modCount");
            modCountField.setAccessible(true);

            countField.setInt(segment, 5);
            modCountField.setInt(segment, 1);
        }

        // Call size()
        int size = map.size();

        // Assert that size is 20
        assertEquals(20, size);
    }

    @Test
    @DisplayName("Size computation with l14 exceeding Integer.MAX_VALUE, expecting capping at Integer.MAX_VALUE")
    public void TC14_sizeExceedsIntegerMaxValue_Capping() throws Exception {
        // Initialize ConcurrentReferenceHashMap with 8 segments
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
            .setInitialCapacity(32)
            .setLoadFactor(0.75f)
            .setConcurrencyLevel(8)
            .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
            .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
            .get();

        // Use reflection to set segment counts and modCounts
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        int largeCount = Integer.MAX_VALUE / 8 + 1;

        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Class<?> segmentClass = segment.getClass();

            Field countField = segmentClass.getDeclaredField("count");
            countField.setAccessible(true);
            Field modCountField = segmentClass.getDeclaredField("modCount");
            modCountField.setAccessible(true);

            countField.setInt(segment, largeCount);
            modCountField.setInt(segment, 1);
        }

        // Call size()
        int size = map.size();

        // Assert that size is capped at Integer.MAX_VALUE
        assertEquals(Integer.MAX_VALUE, size);
    }

    @Test
    @DisplayName("Size computation with zero iterations in inner loops ensuring no additions")
    public void TC15_sizeWithZeroIterations_InnerLoops() throws Exception {
        // Initialize ConcurrentReferenceHashMap with 2 segments
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
            .setInitialCapacity(4)
            .setLoadFactor(0.75f)
            .setConcurrencyLevel(2)
            .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
            .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
            .get();

        // Use reflection to set segment counts and modCounts
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        for (int i = 0; i < segments.length; i++) {
            Object segment = segments[i];
            Class<?> segmentClass = segment.getClass();

            Field countField = segmentClass.getDeclaredField("count");
            countField.setAccessible(true);
            Field modCountField = segmentClass.getDeclaredField("modCount");
            modCountField.setAccessible(true);

            countField.setInt(segment, 0);
            modCountField.setInt(segment, 1);
        }

        // Call size()
        int size = map.size();

        // Assert that size is 0
        assertEquals(0, size);
    }

}