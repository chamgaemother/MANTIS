package org.apache.commons.math3.dfp;

import org.apache.commons.math3.dfp.DfpField;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_multiply_0_4_Test {

    @Test
    @DisplayName("Multiplying Dfp numbers with one operand having infinite exponent and the other finite")
    public void testTC16() throws Exception {
        // Initialize DfpField with default radix digits
        DfpField field = new DfpField(10);

        // Create finite Dfp instance 'a'
        Dfp a = new Dfp(field, 12345);

        // Create infinite Dfp instance 'b' using reflection
        Dfp b = new Dfp(field, 0);
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(b, Dfp.INFINITE); // Correct constant for INFINITE

        // Set the sign of b
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(b, (byte) 1);
        
        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertEquals(a.sign * b.sign, result.sign, "Sign should be correct"); // Check if the sign field is used correctly
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where both operands have infinite mantissas")
    public void testTC17() throws Exception {
        // Initialize DfpField with default radix digits
        DfpField field = new DfpField(10);

        // Create infinite Dfp instances 'a' and 'b' using reflection
        Dfp a = new Dfp(field, 0);
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        nansField.setByte(a, Dfp.INFINITE);

        Dfp b = new Dfp(field, 0);
        nansField.setByte(b, Dfp.INFINITE);

        // Set the sign of a and b
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(a, (byte) -1);
        signField.setByte(b, (byte) 1);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertEquals(a.sign * b.sign, result.sign, "Sign should be correct");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where one operand becomes zero after rounding")
    public void testTC18() throws Exception {
        // Initialize DfpField with default radix digits
        DfpField field = new DfpField(10);

        // Create very small Dfp instances 'a' and 'b'
        Dfp a = new Dfp(field, 1e-10);
        Dfp b = new Dfp(field, 1e-10);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        assertTrue(result.isZero(), "Result should be zero after rounding");
        
        // Check if FLAG_UNDERFLOW is set, using reflection on DfpField
        Field ieeeFlagsField = DfpField.class.getDeclaredField("ieeeFlags");
        ieeeFlagsField.setAccessible(true);
        int flags = ieeeFlagsField.getInt(field);
        assertTrue((flags & DfpField.FLAG_UNDERFLOW) != 0, "FLAG_UNDERFLOW should be set");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where exponent needs adjustment after multiplication")
    public void testTC19() throws Exception {
        // Initialize DfpField with default radix digits
        DfpField field = new DfpField(10);

        // Create Dfp instances 'a' and 'b' with specific exponents
        Dfp a = new Dfp(field, 1e5);
        Dfp b = new Dfp(field, 1e5);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Expected exponent adjustment
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        int expA = expField.getInt(a);
        int expB = expField.getInt(b);

        int expectedExp = expA + expB + 1; // Corrected due to method body logic

        // Assertions
        assertEquals(expectedExp, expField.getInt(result), "Exponent should be correctly adjusted");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers with zero iterations in the multiplication loop")
    public void testTC20() throws Exception {
        // Initialize DfpField with default radix digits
        DfpField field = new DfpField(10);

        // Create Dfp instances 'a' and 'b' as zero
        Dfp a = new Dfp(field, 0);
        Dfp b = new Dfp(field, 0);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        assertTrue(result.isZero(), "Result should be zero");
    }
}
