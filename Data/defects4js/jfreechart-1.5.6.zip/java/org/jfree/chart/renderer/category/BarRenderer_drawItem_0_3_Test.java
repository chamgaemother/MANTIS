package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.RectangleEdge;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BarRenderer_drawItem_0_3_Test {

    private static final RectangleEdge EDGE_BOTTOM = RectangleEdge.BOTTOM;

//     @Test
//     @DisplayName("TC11: drawItem submits crosshair values correctly")
//     void test_TC11_drawItem_submitsCrosshairValuesCorrectly() throws Exception {
//         BarRenderer renderer = spy(new BarRenderer());
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
//         when(dataset.getValue(row, column)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(renderer.calculateBarW0(plot, PlotOrientation.VERTICAL, dataArea, domainAxis, state, row, column)).thenReturn(50.0);
//         when(renderer.calculateBarL0L1(10.0)).thenReturn(new double[] {0.0, 10.0});
//         when(plot.getRangeAxisEdge()).thenReturn(EDGE_BOTTOM);
//         when(state.getBarWidth()).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(0.0, dataArea, EDGE_BOTTOM)).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, EDGE_BOTTOM)).thenReturn(10.0);
//         when(state.getCrosshairState()).thenReturn(mock(CrosshairState.class));
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
//         verify(renderer, times(1)).updateCrosshairValues(any(), any(), any(), eq(10.0), anyInt(), eq(50.0), eq(0.0), eq(PlotOrientation.VERTICAL));
//     }

//     @Test
//     @DisplayName("TC12: drawItem adds item entity when EntityCollection is present")
//     void test_TC12_drawItem_addsItemEntityWhenEntityCollectionIsPresent() throws Exception {
//         BarRenderer renderer = spy(new BarRenderer());
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
//         when(dataset.getValue(row, column)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(renderer.calculateBarW0(plot, PlotOrientation.VERTICAL, dataArea, domainAxis, state, row, column)).thenReturn(50.0);
//         when(renderer.calculateBarL0L1(10.0)).thenReturn(new double[] {0.0, 10.0});
//         when(plot.getRangeAxisEdge()).thenReturn(EDGE_BOTTOM);
//         when(state.getBarWidth()).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(0.0, dataArea, EDGE_BOTTOM)).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, EDGE_BOTTOM)).thenReturn(10.0);
//         when(state.getCrosshairState()).thenReturn(mock(CrosshairState.class));
//         when(state.getEntityCollection()).thenReturn(entities);
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
//         verify(renderer, times(1)).addItemEntity(eq(entities), eq(dataset), eq(row), eq(column), any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("TC13: drawItem does not add item entity when EntityCollection is null")
//     void test_TC13_drawItem_doesNotAddItemEntityWhenEntityCollectionIsNull() throws Exception {
//         BarRenderer renderer = spy(new BarRenderer());
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
//         when(dataset.getValue(row, column)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(renderer.calculateBarW0(plot, PlotOrientation.VERTICAL, dataArea, domainAxis, state, row, column)).thenReturn(50.0);
//         when(renderer.calculateBarL0L1(10.0)).thenReturn(new double[] {0.0, 10.0});
//         when(plot.getRangeAxisEdge()).thenReturn(EDGE_BOTTOM);
//         when(state.getBarWidth()).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(0.0, dataArea, EDGE_BOTTOM)).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, EDGE_BOTTOM)).thenReturn(10.0);
//         when(state.getCrosshairState()).thenReturn(mock(CrosshairState.class));
//         when(state.getEntityCollection()).thenReturn(null);
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
//         verify(renderer, never()).addItemEntity(any(), any(), anyInt(), anyInt(), any());
//     }

//     @Test
//     @DisplayName("TC14: drawItem handles shadow drawing when shadows are visible")
//     void test_TC14_drawItem_handlesShadowDrawingWhenShadowsVisible() throws Exception {
//         BarRenderer renderer = spy(new BarRenderer());
//         renderer.setShadowsVisible(true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
//         when(dataset.getValue(row, column)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(renderer.calculateBarW0(plot, PlotOrientation.VERTICAL, dataArea, domainAxis, state, row, column)).thenReturn(50.0);
//         when(renderer.calculateBarL0L1(10.0)).thenReturn(new double[] {0.0, 10.0});
//         when(plot.getRangeAxisEdge()).thenReturn(EDGE_BOTTOM);
//         when(state.getBarWidth()).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(0.0, dataArea, EDGE_BOTTOM)).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, EDGE_BOTTOM)).thenReturn(10.0);
//         when(state.getCrosshairState()).thenReturn(mock(CrosshairState.class));
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
//         verify(renderer.getBarPainter(), times(1)).paintBarShadow(eq(g2), eq(renderer), eq(row), eq(column), any(Rectangle2D.class), eq(EDGE_BOTTOM), eq(true));
//         verify(renderer.getBarPainter(), times(1)).paintBar(eq(g2), eq(renderer), eq(row), eq(column), any(Rectangle2D.class), eq(EDGE_BOTTOM));
//     }

//     @Test
//     @DisplayName("TC15: drawItem skips shadow drawing when shadows are not visible")
//     void test_TC15_drawItem_skipsShadowDrawingWhenShadowsNotVisible() throws Exception {
//         BarRenderer renderer = spy(new BarRenderer());
//         renderer.setShadowsVisible(false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
//         when(dataset.getValue(row, column)).thenReturn(10.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(renderer.calculateBarW0(plot, PlotOrientation.VERTICAL, dataArea, domainAxis, state, row, column)).thenReturn(50.0);
//         when(renderer.calculateBarL0L1(10.0)).thenReturn(new double[] {0.0, 10.0});
//         when(plot.getRangeAxisEdge()).thenReturn(EDGE_BOTTOM);
//         when(state.getBarWidth()).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(0.0, dataArea, EDGE_BOTTOM)).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, EDGE_BOTTOM)).thenReturn(10.0);
//         when(state.getCrosshairState()).thenReturn(mock(CrosshairState.class));
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
//         verify(renderer.getBarPainter(), never()).paintBarShadow(any(), any(), anyInt(), anyInt(), any(), any(), anyBoolean());
//         verify(renderer.getBarPainter(), times(1)).paintBar(eq(g2), eq(renderer), eq(row), eq(column), any(Rectangle2D.class), eq(EDGE_BOTTOM));
//     }
}