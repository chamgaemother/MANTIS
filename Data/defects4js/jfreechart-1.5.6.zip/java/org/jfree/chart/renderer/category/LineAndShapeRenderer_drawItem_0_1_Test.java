package org.jfree.chart.renderer.category;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import static org.mockito.Mockito.*;

public class LineAndShapeRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem returns early when the item is not visible")
    void TC01_drawItem_ItemNotVisible() throws Exception {
        // Given
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 0;
        int pass = 0;

        // Spy the renderer to mock getItemVisible
        LineAndShapeRenderer spyRenderer = spy(renderer);
        doReturn(false).when(spyRenderer).getItemVisible(row, column);

        // When
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that no drawing methods are called
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("drawItem returns early when both line and shape are not visible")
    void TC02_drawItem_LineAndShapeNotVisible() throws Exception {
        // Given
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 0;
        int pass = 0;

        // Spy the renderer to mock visibility methods
        LineAndShapeRenderer spyRenderer = spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(row, column);
        doReturn(false).when(spyRenderer).getItemLineVisible(row, column);
        doReturn(false).when(spyRenderer).getItemShapeVisible(row, column);

        // When
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that no drawing methods are called
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("drawItem returns early when dataset value is null")
    void TC03_drawItem_DatasetValueNull() throws Exception {
        // Given
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 0;
        int pass = 0;

        // Spy the renderer to mock methods
        LineAndShapeRenderer spyRenderer = spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(row, column);
        doReturn(true).when(spyRenderer).getItemLineVisible(row, column);
        doReturn(true).when(spyRenderer).getItemShapeVisible(row, column);
        when(dataset.getValue(row, column)).thenReturn(null);

        // When
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that no drawing methods are called
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("drawItem returns early when visible series index is negative")
    void TC04_drawItem_NegativeVisibleSeriesIndex() throws Exception {
        // Given
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 0;
        int pass = 0;

        // Spy the renderer to mock methods
        LineAndShapeRenderer spyRenderer = spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(row, column);
        doReturn(true).when(spyRenderer).getItemLineVisible(row, column);
        doReturn(true).when(spyRenderer).getItemShapeVisible(row, column);
        when(dataset.getValue(row, column)).thenReturn(10);
        when(state.getVisibleSeriesIndex(row)).thenReturn(-1);

        // When
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that no drawing methods are called
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("drawItem calculates x1 using series offset when useSeriesOffset is true")
    void TC05_drawItem_UseSeriesOffsetTrue() throws Exception {
        // Given
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 1;
        int column = 1;
        int pass = 0;

        // Spy the renderer to mock methods
        LineAndShapeRenderer spyRenderer = spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(row, column);
        doReturn(true).when(spyRenderer).getItemLineVisible(row, column);
        doReturn(true).when(spyRenderer).getItemShapeVisible(row, column);
        when(dataset.getValue(row, column)).thenReturn(20);
        when(state.getVisibleSeriesIndex(row)).thenReturn(1);
        when(state.getVisibleSeriesCount()).thenReturn(5);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        spyRenderer.setUseSeriesOffset(true);  // updated usage to appropriate setter method
        when(domainAxis.getCategorySeriesMiddle(
                eq(column),
                anyInt(),
                eq(1),
                eq(5),
                anyDouble(),
                eq(dataArea),
                any()
        )).thenReturn(50.0);

        // When
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that getCategorySeriesMiddle was called
        verify(domainAxis, times(1)).getCategorySeriesMiddle(
                eq(column),
                anyInt(),
                eq(1),
                eq(5),
                anyDouble(),
                eq(dataArea),
                any()
        );
    }
}
