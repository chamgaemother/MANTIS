import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.axes.DescendantContext;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Stack;

class DescendantContextTest {

    private EvalContext parentContext;
    private NodePointer initialNodePointer;
    private NodeTest nodeTest;

    @BeforeEach
    void setUp() {
        parentContext = mock(EvalContext.class);
        initialNodePointer = mock(NodePointer.class);
        nodeTest = mock(NodeTest.class);
        when(parentContext.getCurrentNodePointer()).thenReturn(initialNodePointer);
    }

    @Test
    void testNextNode_WithLeafNodeAndIncludeSelf() {
        when(initialNodePointer.isLeaf()).thenReturn(true);
        when(initialNodePointer.testNode(nodeTest)).thenReturn(true);

        DescendantContext context = new DescendantContext(parentContext, true, nodeTest);

        assertTrue(context.nextNode(), "Should find the initial node since includeSelf is true and node test passes");
    }

    @Test
    void testNextNode_WithoutIncludeSelf_AndNodeIsLeaf() {
        when(initialNodePointer.isLeaf()).thenReturn(true);
        when(initialNodePointer.testNode(nodeTest)).thenReturn(false);

        DescendantContext context = new DescendantContext(parentContext, false, nodeTest);

        assertFalse(context.nextNode(), "Should not find any node since includeSelf is false and node is a leaf");
    }

    @Test
    void testNextNode_RecursionDetected() {
        when(initialNodePointer.isLeaf()).thenReturn(false);
        
        NodeIterator nodeIterator = mock(NodeIterator.class);
        when(initialNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(nodeIterator);
        when(nodeIterator.setPosition(anyInt())).thenReturn(true);
        
        NodePointer recursiveNodePointer = mock(NodePointer.class);
        when(recursiveNodePointer.getNode()).thenReturn(new Object());
        when(nodeIterator.getNodePointer()).thenReturn(recursiveNodePointer);
        
        Stack<NodeIterator> stack = new Stack<>();
        stack.push(nodeIterator);
                
        DescendantContext context = new DescendantContext(parentContext, false, nodeTest);
        
        context.nextNode(); // Initializes context and stack
        when(initialNodePointer.getNode()).thenReturn(new Object());

        assertFalse(context.nextNode(), "Should not proceed with next node due to recursion detection");
    }

    @Test
    void testNextNode_WithNonLeafChildNodes() {
        when(initialNodePointer.isLeaf()).thenReturn(false);

        NodeIterator nodeIterator = mock(NodeIterator.class);
        when(nodeIterator.setPosition(anyInt())).thenReturn(true);
        NodePointer childNodePointer = mock(NodePointer.class);
        when(childNodePointer.isLeaf()).thenReturn(true);
        when(childNodePointer.testNode(nodeTest)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(childNodePointer);
        when(initialNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(nodeIterator);

        DescendantContext context = new DescendantContext(parentContext, false, nodeTest);

        assertTrue(context.nextNode(), "Should find a child node that meets the node test");
    }

    @Test
    void testNextNode_NoChildNodeMatches() {
        when(initialNodePointer.isLeaf()).thenReturn(false);
        
        NodeIterator initialIterator = mock(NodeIterator.class);
        when(initialIterator.setPosition(anyInt())).thenReturn(false);
        when(initialNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(initialIterator);
        
        DescendantContext context = new DescendantContext(parentContext, false, nodeTest);

        assertFalse(context.nextNode(), "Should not find any node since child iteration does not match");
    }
}