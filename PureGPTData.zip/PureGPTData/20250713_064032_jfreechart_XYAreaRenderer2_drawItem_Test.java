import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYAreaRenderer2;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

class XYAreaRenderer2Test {

    private XYAreaRenderer2 renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYAreaRenderer2();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
        
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(anyInt())).thenReturn(3);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> (double) invocation.getArgument(0));
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> (double) invocation.getArgument(0));
    }

    @Test
    void testDrawItemWithVisibleItem() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0, 0.0, 2.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0, 0.0, 1.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any());
        verify(g2).setPaint(any());
        verify(g2).setStroke(any());
    }

    @Test
    void testDrawItemWithInvisibleItem() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2, never()).fill(any());
    }

    @Test
    void testDrawItemWithNaNYValue() {
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(Double.NaN);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).fill(any());
    }

    @Test
    void testDrawItemWithOutline() {
        renderer.setOutline(true);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).draw(any());
    }

    @Test
    void testDrawItemHorizontalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0, 0.0, 2.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0, 0.0, 1.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any());
        verify(g2).setPaint(any());
        verify(g2).setStroke(any());
    }
}