package org.jfree.chart.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;

public class RectangleAnchor_getAnchorPoint_1_1_Test {

    @Test
    @DisplayName("getAnchorPoint correctly calculates center point for rectangle with negative width and positive height when anchor is CENTER")
    void TC12() {
        // Given
        Rectangle2D rectangle = new Rectangle2D.Double(100.0, 100.0, -50.0, 100.0);
        RectangleAnchor anchor = RectangleAnchor.CENTER;

        // When
        Point2D result = anchor.getAnchorPoint(rectangle);

        // Then
        double expectedX = 75.0; // 100 + (-50)/2
        double expectedY = 150.0; // 100 + 100/2
        assertEquals(expectedX, result.getX(), 0.0001, "Center X coordinate mismatch");
        assertEquals(expectedY, result.getY(), 0.0001, "Center Y coordinate mismatch");
    }

    @Test
    @DisplayName("getAnchorPoint correctly calculates anchor point for rectangle with floating-point dimensions when anchor is TOP_LEFT")
    void TC13() {
        // Given
        Rectangle2D rectangle = new Rectangle2D.Double(100.5, 200.75, 300.25, 400.125);
        RectangleAnchor anchor = RectangleAnchor.TOP_LEFT;

        // When
        Point2D result = anchor.getAnchorPoint(rectangle);

        // Then
        double expectedX = 100.5;
        double expectedY = 200.75;
        assertEquals(expectedX, result.getX(), 0.0001, "Top-Left X coordinate mismatch");
        assertEquals(expectedY, result.getY(), 0.0001, "Top-Left Y coordinate mismatch");
    }
}