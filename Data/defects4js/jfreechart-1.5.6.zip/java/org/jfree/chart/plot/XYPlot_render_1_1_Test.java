package org.jfree.chart.plot;

import java.io.*;
import java.util.*;
import org.jfree.data.xy.DefaultXYDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.CrosshairState;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class XYPlot_render_1_1_Test {

    @Test
    @DisplayName("Render method processes dataset with present xAxis but null yAxis and renderer is present")
    public void TC16() throws Exception {
        // Create the plot
        XYPlot plot = new XYPlot();

        // Set dataset
        XYDataset dataset = new DefaultXYDataset();
        plot.setDataset(0, dataset);

        // Set domain axis
        ValueAxis xAxis = new NumberAxis("X-Axis");
        plot.setDomainAxis(0, xAxis);

        // Set range axis to null
        plot.setRangeAxis(0, null);

        // Mock the renderer
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(0, renderer);

        // Mock other dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0); // non-null mocked dataArea
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Execute the render method
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);

        // Assert the render method returns true
        assertTrue(result);

        // Verify that renderer.drawItem was never called
        verify(renderer, never()).drawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

    @Test
    @DisplayName("Render method processes dataset with null xAxis and yAxis, and renderer is null but default renderer is present")
    public void TC17() throws Exception {
        // Create the plot
        XYPlot plot = new XYPlot();

        // Set dataset
        XYDataset dataset = new DefaultXYDataset();
        plot.setDataset(0, dataset);

        // Set domain axis to null
        plot.setDomainAxis(0, null);

        // Set range axis to null
        plot.setRangeAxis(0, null);

        // Set renderer to null
        plot.setRenderer(0, null);

        // Set default renderer
        XYItemRenderer defaultRenderer = new StandardXYItemRenderer();
        plot.setRenderer(defaultRenderer);

        // Spy on the default renderer
        XYItemRenderer spyRenderer = spy(defaultRenderer);
        plot.setRenderer(0, spyRenderer);

        // Mock other dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0); // non-null mocked dataArea
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Execute the render method
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);

        // Assert the render method returns true
        assertTrue(result);

        // Verify that renderer.drawItem was never called
        verify(spyRenderer, never()).drawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
    }

}