package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ConcurrentReferenceHashMap_containsValue_0_1_Test {

    @Test
    @DisplayName("containsValue(null) throws NullPointerException due to null input")
    public void TC01_containsValue_nullInput_throwsNullPointerException() {
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.<String, String>builder().build();
        Object value = null;
        assertThrows(NullPointerException.class, () -> map.containsValue(value));
    }

    @Test
    @DisplayName("containsValue returns true when value is present in the first segment on first retry")
    public void TC02_containsValue_valuePresent_returnsTrue() {
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.<String, String>builder().build();
        String value = "testValue";
        map.put("key1", value);
        boolean result = map.containsValue(value);
        assertTrue(result);
    }

    @Test
    @DisplayName("containsValue returns false when value is not present after all retries with clean sweep")
    public void TC03_containsValue_valueNotPresent_returnsFalse() {
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.<String, String>builder().build();
        map.put("key1", "value1");
        Object value = "nonExistentValue";
        boolean result = map.containsValue(value);
        assertFalse(result);
    }

    @Test
    @DisplayName("containsValue retries and returns false when map is modified during retries")
    public void TC04_containsValue_concurrentModification_returnsFalse() throws InterruptedException {
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.<String, String>builder().build();
        Object value = "testValue";
        map.put("key1", "value1");

        ConcurrentModificationThread modifier = new ConcurrentModificationThread(map, "key2", "value2");
        modifier.start();
        boolean result = map.containsValue(value);
        assertFalse(result);
        modifier.join();
    }

    @Test
    @DisplayName("containsValue returns true during locked phase when value is present")
    public void TC05_containsValue_presentDuringLockedPhase_returnsTrue() throws InterruptedException {
        ConcurrentReferenceHashMap<String, String> map = ConcurrentReferenceHashMap.<String, String>builder().build();
        String value = "testValue";

        ConcurrentAdditionThread adder = new ConcurrentAdditionThread(map, "key1", value);
        adder.start();
        boolean result = map.containsValue(value);
        assertTrue(result);
        adder.join();
    }

    // Helper thread classes for concurrent operations
    private static class ConcurrentModificationThread extends Thread {
        private final ConcurrentReferenceHashMap<String, String> map;
        private final String key;
        private final String value;

        public ConcurrentModificationThread(ConcurrentReferenceHashMap<String, String> map, String key, String value) {
            this.map = map;
            this.key = key;
            this.value = value;
        }

        @Override
        public void run() {
            map.put(key, value);
        }
    }

    private static class ConcurrentAdditionThread extends Thread {
        private final ConcurrentReferenceHashMap<String, String> map;
        private final String key;
        private final String value;

        public ConcurrentAdditionThread(ConcurrentReferenceHashMap<String, String> map, String key, String value) {
            this.map = map;
            this.key = key;
            this.value = value;
        }

        @Override
        public void run() {
            map.put(key, value);
        }
    }
}