package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.util.FastMath;

public class FastMath_atan2_0_4_Test {

    @Test
    @DisplayName("atan2(x=Infinity, y=Infinity) returns Math.PI/4 when both x and y are positive infinity")
    void TC16() {
        double x = Double.POSITIVE_INFINITY;
        double y = Double.POSITIVE_INFINITY;
        double result = FastMath.atan2(x, y);
        assertEquals(Math.PI / 4, result, "Expected Math.PI / 4");
    }

    @Test
    @DisplayName("atan2(x=-Infinity, y=Infinity) returns Math.PI*3/4 when x is negative infinity and y is positive infinity")
    void TC17() {
        double x = Double.NEGATIVE_INFINITY;
        double y = Double.POSITIVE_INFINITY;
        double result = FastMath.atan2(x, y);
        assertEquals(Math.PI * 3 / 4, result, "Expected Math.PI * 3 / 4");
    }

    @Test
    @DisplayName("atan2(x=Finite, y=0.0) returns correct result when invx is not zero and x is positive")
    void TC18() {
        double x = 10.0;
        double y = 0.0;
        double result = FastMath.atan2(x, y);
        assertEquals(0.0, result, "Expected 0.0");
    }

    @Test
    @DisplayName("atan2(x=Finite, y=Finite) processes general case with finite r")
    void TC19() {
        double x = 3.0;
        double y = 4.0;
        double result = FastMath.atan2(x, y);
        assertTrue(Math.abs(result - Math.atan2(y, x)) < 1e-10, "Result is not within the expected tolerance");
    }

    @Test
    @DisplayName("atan2(x=Finite, y=Infinity) returns Math.PI/2 when y is positive infinity")
    void TC20() {
        double x = 1.0;
        double y = Double.POSITIVE_INFINITY;
        double result = FastMath.atan2(x, y);
        assertEquals(Math.PI / 2, result, "Expected Math.PI / 2");
    }
}