package org.apache.commons.math3.linear;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealMatrixFormat;
import java.text.ParsePosition;

public class RealMatrixFormat_parse_0_3_Test {

    @Test
    @DisplayName("parse with empty string")
    void TC11_parse_empty_string() {
        RealMatrixFormat realMatrixFormat = new RealMatrixFormat();
        String source = "";
        ParsePosition pos = new ParsePosition(0);
        RealMatrix result = realMatrixFormat.parse(source, pos);
        assertNull(result);
        assertEquals(0, pos.getIndex());
    }

    @Test
    @DisplayName("parse with null ParsePosition")
    void TC12_parse_with_null_ParsePosition() {
        RealMatrixFormat realMatrixFormat = new RealMatrixFormat();
        String source = "[1.0]";
        ParsePosition pos = null;
        assertThrows(NullPointerException.class, () -> {
            realMatrixFormat.parse(source, pos);
        });
    }

    @Test
    @DisplayName("parse with missing row prefix")
    void TC13_parse_missing_row_prefix() {
        RealMatrixFormat realMatrixFormat = new RealMatrixFormat();
        String source = "[1.0,2.0], [3.0,4.0]]";
        ParsePosition pos = new ParsePosition(0);
        RealMatrix result = realMatrixFormat.parse(source, pos);
        assertNull(result);
        assertEquals(8, pos.getIndex());
    }

    @Test
    @DisplayName("parse with missing row suffix")
    void TC14_parse_missing_row_suffix() {
        RealMatrixFormat realMatrixFormat = new RealMatrixFormat();
        String source = "[[1.0,2.0,3.0";
        ParsePosition pos = new ParsePosition(0);
        RealMatrix result = realMatrixFormat.parse(source, pos);
        assertNull(result);
        assertEquals(10, pos.getIndex());
    }

    @Test
    @DisplayName("parse with extra characters after valid matrix")
    void TC15_parse_with_extra_characters_after_matrix() {
        RealMatrixFormat realMatrixFormat = new RealMatrixFormat();
        String source = "[[1.0,2.0],[3.0,4.0]] extra";
        ParsePosition pos = new ParsePosition(0);
        RealMatrix result = realMatrixFormat.parse(source, pos);
        assertNotNull(result);
        assertEquals(16, pos.getIndex());
        assertEquals(2, result.getRowDimension());
        assertEquals(2, result.getColumnDimension());
    }
}