package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.Shape;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DeviationStepRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("drawItem handles NaN yHigh gracefully, skipping shading")
    public void TC06_drawItem_handles_NaN_yHigh_gracefully() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = new XYItemRendererState(new PlotRenderingInfo(null));
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getStartYValue(series, item)).thenReturn(2.0);
        when(dataset.getEndYValue(series, item)).thenReturn(Double.NaN);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(Double.NaN, dataArea, RectangleEdge.LEFT)).thenReturn(Double.NaN);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(series)).thenReturn(1);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    @DisplayName("drawItem handles plot orientation horizontal in pass=0")
    public void TC07_drawItem_handles_plot_orientation_horizontal() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = new XYItemRendererState(new PlotRenderingInfo(null));
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 1;
        int pass = 0;

        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(2.0);
        when(dataset.getStartYValue(series, item)).thenReturn(3.0);
        when(dataset.getEndYValue(series, item)).thenReturn(4.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, RectangleEdge.LEFT)).thenReturn(350.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(series)).thenReturn(2);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Shape> captor = ArgumentCaptor.forClass(Shape.class);
        verify(g2).fill(captor.capture());
        // Additional assertions can be added here to verify the correctness of the shading
        Shape filledShape = captor.getValue();
        assertNotNull(filledShape);
    }

    @Test
    @DisplayName("drawItem handles plot orientation vertical in pass=0")
    public void TC08_drawItem_handles_plot_orientation_vertical() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = new XYItemRendererState(new PlotRenderingInfo(null));
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 1;
        int item = 2;
        int pass = 0;

        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.TOP);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.RIGHT);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(3.0);
        when(dataset.getStartYValue(series, item)).thenReturn(4.0);
        when(dataset.getEndYValue(series, item)).thenReturn(5.0);
        when(domainAxis.valueToJava2D(3.0, dataArea, RectangleEdge.TOP)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, RectangleEdge.RIGHT)).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.RIGHT)).thenReturn(400.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(series)).thenReturn(3);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Shape> captor = ArgumentCaptor.forClass(Shape.class);
        verify(g2).fill(captor.capture());
        // Additional assertions can be added here to verify the correctness of the shading
        Shape filledShape = captor.getValue();
        assertNotNull(filledShape);
    }

    @Test
    @DisplayName("drawItem throws ClassCastException when dataset is not IntervalXYDataset in pass=0")
    public void TC09_drawItem_throws_ClassCastException_on_invalid_dataset_type() {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = new XYItemRendererState(new PlotRenderingInfo(null));
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class); // Not an IntervalXYDataset
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        // Act & Assert
        assertThrows(ClassCastException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("drawItem processes multiple shading regions with varying iteration counts")
    public void TC10_drawItem_handles_multiple_shading_regions() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = new XYItemRendererState(new PlotRenderingInfo(null));
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int totalItems = 5;
        when(dataset.getItemCount(series)).thenReturn(totalItems);

        for (int item = 0; item < totalItems; item++) {
            when(renderer.getItemVisible(series, item)).thenReturn(true);
            when(dataset.getXValue(series, item)).thenReturn((double) (item + 1));
            when(dataset.getStartYValue(series, item)).thenReturn((double) (item + 2));
            when(dataset.getEndYValue(series, item)).thenReturn((double) (item + 3));
            when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
            when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
            when(domainAxis.valueToJava2D((double) (item + 1), dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0 + item * 10);
            when(rangeAxis.valueToJava2D((double) (item + 2), dataArea, RectangleEdge.LEFT)).thenReturn(200.0 + item * 10);
            when(rangeAxis.valueToJava2D((double) (item + 3), dataArea, RectangleEdge.LEFT)).thenReturn(300.0 + item * 10);
            when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

            // Act
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
        }

        // Assert
        // Verify that fill was called the expected number of times
        verify(g2, times(totalItems)).fill(any(Shape.class));
    }
}
