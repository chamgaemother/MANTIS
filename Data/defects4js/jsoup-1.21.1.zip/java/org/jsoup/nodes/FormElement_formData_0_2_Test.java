package org.jsoup.nodes;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.jsoup.Connection;
import org.jsoup.parser.Tag;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class FormElement_formData_0_2_Test {
    
    @Test
    @DisplayName("formData skips elements of type image")
    void test_TC06_formData_skips_elements_of_type_image() {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null); // Correct constructor usage
        Element image = new Element(Tag.valueOf("input"), "").attr("type", "image");
        form.addElement(image); // Use addElement instead of appendChild

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty(), "Expected the returned data list to be empty");
    }

    @Test
    @DisplayName("formData processes select elements with selected options")
    void test_TC07_formData_processes_select_elements_with_selected_options() {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element select = new Element(Tag.valueOf("select"), "").attr("name", "country");
        Element option1 = new Element(Tag.valueOf("option"), "").attr("value", "US").attr("selected", "selected");
        Element option2 = new Element(Tag.valueOf("option"), "").attr("value", "CA");
        select.appendChild(option1).appendChild(option2);
        form.addElement(select);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertEquals(1, data.size(), "Expected data list size to be 1");
        assertEquals("country", data.get(0).key(), "Expected key to be 'country'");
        assertEquals("US", data.get(0).value(), "Expected value to be 'US'");
    }

    @Test
    @DisplayName("formData processes select elements without selected options")
    void test_TC08_formData_processes_select_elements_without_selected_options() {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element select = new Element(Tag.valueOf("select"), "").attr("name", "language");
        Element option1 = new Element(Tag.valueOf("option"), "").attr("value", "Java");
        Element option2 = new Element(Tag.valueOf("option"), "").attr("value", "Python");
        select.appendChild(option1).appendChild(option2);
        form.addElement(select);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertEquals(1, data.size(), "Expected data list size to be 1");
        assertEquals("language", data.get(0).key(), "Expected key to be 'language'");
        assertEquals("Java", data.get(0).value(), "Expected value to be 'Java'");
    }

    @Test
    @DisplayName("formData processes checkbox element with checked attribute")
    void test_TC09_formData_processes_checkbox_element_with_checked_attribute() {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element checkbox = new Element(Tag.valueOf("input"), "")
                .attr("type", "checkbox")
                .attr("name", "subscribe")
                .attr("value", "yes")
                .attr("checked", "checked");
        form.addElement(checkbox);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertEquals(1, data.size(), "Expected data list size to be 1");
        assertEquals("subscribe", data.get(0).key(), "Expected key to be 'subscribe'");
        assertEquals("yes", data.get(0).value(), "Expected value to be 'yes'");
    }

    @Test
    @DisplayName("formData processes checkbox element without checked attribute")
    void test_TC10_formData_processes_checkbox_element_without_checked_attribute() {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element checkbox = new Element(Tag.valueOf("input"), "")
                .attr("type", "checkbox")
                .attr("name", "subscribe")
                .attr("value", "yes");
        form.addElement(checkbox);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty(), "Expected the returned data list to be empty");
    }
}