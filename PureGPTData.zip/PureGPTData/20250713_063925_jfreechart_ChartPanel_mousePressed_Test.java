import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.Zoomable;
import org.jfree.chart.panel.Overlay;
import org.jfree.chart.panel.OverlayChangeEvent;
import org.jfree.chart.panel.OverlayChangeListener;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ChartPanelTest {

    private ChartPanel chartPanel;
    private JFreeChart chart;
    private Plot plot;
    private MouseEvent mockEvent;

    @BeforeEach
    void setUp() {
        // Mock the necessary objects for the tests
        plot = mock(Plot.class);
        chart = mock(JFreeChart.class);
        when(chart.getPlot()).thenReturn(plot);
        chartPanel = new ChartPanel(chart, true, true, true, true, true);
        
        // Set up a basic mouse event
        mockEvent = new MouseEvent(chartPanel, 0, 0, 0, 100, 100, 1, false, MouseEvent.BUTTON1);
    }

    @Test
    void testMousePressedPanWithControlMask_PannablePlot() {
        plot = mock(Zoomable.class);
        when(((Zoomable) plot).isDomainZoomable()).thenReturn(true);
        when(((Zoomable) plot).isRangeZoomable()).thenReturn(true);
        when(chart.getPlot()).thenReturn(plot);
        
        // Simulate pressing mouse with control mask
        mockEvent = new MouseEvent(chartPanel, 0, 0, InputEvent.CTRL_DOWN_MASK, 100, 100, 1, false, MouseEvent.BUTTON1);

        chartPanel.mousePressed(mockEvent);

        // Check if panLast has been set and cursor changed
        assertNotNull(chartPanel.panLast);
        assertEquals(Cursor.MOVE_CURSOR, chartPanel.getCursor().getType());
    }

    @Test
    void testMousePressedZoomRectangleInitialized() {
        // Set up a zoomable plot
        when(plot instanceof Zoomable).thenReturn(true);

        Rectangle2D screenDataArea = new Rectangle2D.Double(50, 50, 200, 200);
        when(chartPanel.getScreenDataArea(mockEvent.getX(), mockEvent.getY())).thenReturn(screenDataArea);

        // Trigger mouse press event
        chartPanel.mousePressed(mockEvent);

        // Ensure zoomPoint is not null, indicating initiation of zoom rectangle
        assertNotNull(chartPanel.zoomPoint);
    }

    @Test
    void testMousePressedDisplayPopupTrigger() {
        mockEvent = new MouseEvent(chartPanel, 0, 0, 0, 100, 100, 1, true, MouseEvent.BUTTON3);

        JPopupMenu mockPopup = mock(JPopupMenu.class);
        chartPanel.setPopupMenu(mockPopup);

        chartPanel.mousePressed(mockEvent);

        // Verify the popup was shown
        verify(mockPopup, times(1)).show(chartPanel, 100, 100);
    }

    @Test
    void testMousePressedNoActionWithNullPlot() {
        when(chart.getPlot()).thenReturn(null);

        chartPanel.mousePressed(mockEvent);

        // Ensure no actions taken with null plot
        assertNull(chartPanel.panLast);
        assertNull(chartPanel.zoomPoint);
    }

    @Test
    void testMousePressedInteractionOnNonPannablePlot() {
        plot = mock(Plot.class);
        when(chart.getPlot()).thenReturn(plot);

        // Simulate pressing mouse with control mask
        mockEvent = new MouseEvent(chartPanel, 0, 0, InputEvent.CTRL_DOWN_MASK, 100, 100, 1, false, MouseEvent.BUTTON1);

        chartPanel.mousePressed(mockEvent);

        // Ensure panLast is null due to non-pannable plot
        assertNull(chartPanel.panLast);
    }

    @Test
    void testMousePressedEdgeCaseOutsideDataArea() {
        // Set plot to be a Zoomable type
        when(plot instanceof Zoomable).thenReturn(true);

        Rectangle2D screenDataArea = new Rectangle2D.Double(50, 50, 200, 200);
        when(chartPanel.getScreenDataArea(mockEvent.getX(), mockEvent.getY())).thenReturn(screenDataArea);

        // Create a mouse event outside the data area
        mockEvent = new MouseEvent(chartPanel, 0, 0, 0, 300, 300, 1, false, MouseEvent.BUTTON1);
        chartPanel.mousePressed(mockEvent);

        // Ensure zoomPoint is null, as click was outside data area
        assertNull(chartPanel.zoomPoint);
    }

    @Test
    void testMousePressedNoPopupWithoutTrigger() {
        JPopupMenu mockPopup = mock(JPopupMenu.class);
        chartPanel.setPopupMenu(mockPopup);

        chartPanel.mousePressed(mockEvent);

        // Since it's not a popup trigger, the popup should not be shown
        verify(mockPopup, times(0)).show(chartPanel, 100, 100);
    }
}