package com.fasterxml.jackson.core;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;

public class JsonPointer_forPath_1_1_Test {

    @Test
    @DisplayName("Context has a property name containing '/' which should be escaped to '~1'")
    public void TC16_PropertyNameWithSlash() {
        // Arrange
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        Mockito.when(context.inObject()).thenReturn(true);
        Mockito.when(context.hasPathSegment()).thenReturn(true);
        Mockito.when(context.getCurrentName()).thenReturn("section/part");
        Mockito.when(context.getParent()).thenReturn(null);
        boolean includeRoot = false;

        // Act
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // Assert
        assertNotNull(result);
        assertEquals("/section~1part", result.toString());
    }

    @Test
    @DisplayName("Context has a property name containing '~' which should be escaped to '~0'")
    public void TC17_PropertyNameWithTilde() {
        // Arrange
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        Mockito.when(context.inObject()).thenReturn(true);
        Mockito.when(context.hasPathSegment()).thenReturn(true);
        Mockito.when(context.getCurrentName()).thenReturn("version~1");
        Mockito.when(context.getParent()).thenReturn(null);
        boolean includeRoot = false;

        // Act
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // Assert
        assertNotNull(result);
        assertEquals("/version~01", result.toString());
    }

    @Test
    @DisplayName("Context has a property name containing both '/' and '~' which should be correctly escaped")
    public void TC18_PropertyNameWithSlashAndTilde() {
        // Arrange
        JsonStreamContext context = Mockito.mock(JsonStreamContext.class);
        Mockito.when(context.inObject()).thenReturn(true);
        Mockito.when(context.hasPathSegment()).thenReturn(true);
        Mockito.when(context.getCurrentName()).thenReturn("path~/segment");
        Mockito.when(context.getParent()).thenReturn(null);
        boolean includeRoot = false;

        // Act
        JsonPointer result = JsonPointer.forPath(context, includeRoot);

        // Assert
        assertNotNull(result);
        assertEquals("/path~0~/segment~1", result.toString());
    }
}