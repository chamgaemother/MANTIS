import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipException;
import org.apache.commons.compress.archivers.zip.UnsupportedZipFeatureException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

class ZipArchiveInputStreamTest {

    @Test
    void testGetNextZipEntry_EmptyStream() throws IOException {
        ByteArrayInputStream bis = new ByteArrayInputStream(new byte[0]);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(bis);
        assertNull(zis.getNextZipEntry());
    }

    @Test
    void testGetNextZipEntry_SingleValidEntry() throws IOException {
        byte[] zipData = {
            // Local file header
            0x50, 0x4b, 0x03, 0x04, 0x14, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x0a, 0x00, // File name length
            0x00, 0x00, // Extra field length
            't', 'e', 's', 't', '.', 't', 'x', 't',
            // Data with random content
            'h', 'e', 'l', 'l', 'o'
        };
        
        ByteArrayInputStream bis = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(bis);
        ZipArchiveEntry entry = zis.getNextZipEntry();
        assertNotNull(entry);
        assertEquals("test.txt", entry.getName());
    }

    @Test
    void testGetNextZipEntry_InvalidSignature() {
        byte[] invalidZipData = {0x00, 0x00, 0x00, 0x00};
        ByteArrayInputStream bis = new ByteArrayInputStream(invalidZipData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(bis);
        assertThrows(ZipException.class, zis::getNextZipEntry);
    }

    @Test
    void testGetNextZipEntry_NullInputStream() {
        assertThrows(NullPointerException.class, () -> {
            new ZipArchiveInputStream((InputStream) null);
        });
    }

    @Test
    void testGetNextZipEntry_StreamWithCentralDirectorySignature() throws IOException {
        byte[] zipData = {
            // Central directory header signature
            0x50, 0x4b, 0x01, 0x02
        };
        ByteArrayInputStream bis = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(bis);
        assertNull(zis.getNextZipEntry());
    }

    @Test
    void testGetNextZipEntry_SkipSplitSignature() throws IOException {
        byte[] zipData = {
            // Split ZIP signature
            0x50, 0x4b, 0x07, 0x08,
            // Local file header
            0x50, 0x4b, 0x03, 0x04, 0x14, 0x00
        };
        ByteArrayInputStream bis = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(bis, null, true, true, true);
        assertNull(zis.getNextZipEntry());
    }

    @Test
    void testGetNextZipEntry_UnsupportedZipFeature() {
        byte[] zipData = {
            // Local file header for an unsupported method (e.g., method > 14)
            0x50, 0x4b, 0x03, 0x04, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x0a, 0x00, 0x00, 0x00, 't', 'e', 's', 't', '.', 't', 'x', 't'
        };
        ByteArrayInputStream bis = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(bis);
        assertThrows(UnsupportedZipFeatureException.class, zis::getNextZipEntry);
    }
}