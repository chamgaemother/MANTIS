package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.GradientPaintTransformer;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.WaterfallBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.ui.GradientPaintTransformType;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.ui.StandardGradientPaintTransformer;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.event.RendererChangeEvent;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class WaterfallBarRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem with column not last and dataset value is negative, triggering getNegativeBarPaint()")
    public void TC16_drawItem_negativeValue_nonLastColumn() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(-5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setNegativeBarPaint(Color.RED);
        
        when(state.getSeriesRunningTotal()).thenReturn(10.0);
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        verify(g2).setPaint(Color.RED);
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(5.0);
    }

    @Test
    @DisplayName("drawItem with gradientPaintTransformer present and seriesPaint is GradientPaint")
    public void TC17_drawItem_withGradientPaintTransformer_and_GradientPaint() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        GradientPaintTransformer transformer = mock(GradientPaintTransformer.class);
        renderer.setGradientPaintTransformer(transformer);
        
        GradientPaint gp = new GradientPaint(0, 0, Color.BLUE, 1, 1, Color.CYAN);
        renderer.setPositiveBarPaint(gp);
        
        Rectangle2D bar = new Rectangle2D.Double();
        when(transformer.transform(gp, any(Rectangle2D.class))).thenReturn(gp);
        
        when(state.getSeriesRunningTotal()).thenReturn(0.0);
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        verify(transformer).transform(gp, any(Rectangle2D.class));
        verify(g2).setPaint(gp);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem with drawBarOutline enabled and barWidth exceeds threshold, drawing outline")
    public void TC18_drawItem_withDrawBarOutline_enabled_and_barWidth_exceeds_threshold() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setDrawBarOutline(true);
        
        // Use reflection to set minimumBarLength to exceed threshold
        Field minBarLengthField = WaterfallBarRenderer.class.getDeclaredField("minimumBarLength");
        minBarLengthField.setAccessible(true);
        minBarLengthField.setDouble(renderer, 10.0);
        
        Stroke stroke = new BasicStroke(2.0f);
        Paint outlinePaint = Color.BLACK;
        
        // Mock getItemOutlineStroke and getItemOutlinePaint using a spy
        WaterfallBarRenderer spyRenderer = Mockito.spy(renderer);
        doReturn(stroke).when(spyRenderer).getItemOutlineStroke(1, 1);
        doReturn(outlinePaint).when(spyRenderer).getItemOutlinePaint(1, 1);
        
        when(state.getSeriesRunningTotal()).thenReturn(0.0);
        
        // Act
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        verify(g2).setStroke(stroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem with itemLabelGenerator present but label not visible")
    public void TC19_drawItem_withItemLabelGenerator_present_but_label_not_visible() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        
        // Use reflection to set private methods if necessary
        WaterfallBarRenderer spyRenderer = Mockito.spy(renderer);
        doReturn(generator).when(spyRenderer).getItemLabelGenerator(1, 1);
        doReturn(false).when(spyRenderer).isItemLabelVisible(1, 1);
        
        when(state.getSeriesRunningTotal()).thenReturn(0.0);
        
        // Act
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        verify(spyRenderer, never()).drawItemLabel(any(), any(), anyInt(), anyInt(), any(), any(), any(), anyBoolean());
    }

    @Test
    @DisplayName("drawItem with column index equal to zero, triggering getFirstBarPaint()")
    public void TC20_drawItem_withColumnIndexZero_triggers_getFirstBarPaint() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setFirstBarPaint(Color.MAGENTA);
        
        when(state.getSeriesRunningTotal()).thenReturn(0.0);
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        
        // Assert
        verify(g2).setPaint(Color.MAGENTA);
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(10.0);
    }
}