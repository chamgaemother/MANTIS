package org.jfree.chart.plot;

import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.jfree.data.general.PieDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class PiePlot3D_draw_0_2_Test {

    @Test
    @DisplayName("When Dataset is null, drawNoDataMessage is invoked")
    public void test_TC06_Draw_With_Null_Dataset() throws Exception {
        PiePlot3D piePlot3D = new PiePlot3D();
        piePlot3D.setDataset(null);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D anchor = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class, RETURNS_DEEP_STUBS);

        piePlot3D.draw(g2, plotArea, anchor, state, info);

        verify(g2, times(1)).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("When Dataset is empty, drawNoDataMessage is invoked")
    public void test_TC07_Draw_With_Empty_Dataset() throws Exception {
        PiePlot3D piePlot3D = new PiePlot3D();
        PieDataset emptyDataset = mock(PieDataset.class);
        when(emptyDataset.getKeys()).thenReturn(new java.util.ArrayList<>());
        piePlot3D.setDataset(emptyDataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D anchor = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class, RETURNS_DEEP_STUBS);

        piePlot3D.draw(g2, plotArea, anchor, state, info);

        verify(g2, times(1)).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("When Dataset has more keys than plotArea width, displays " +
    "'Too_many_elements' message")
    public void test_TC08_Draw_With_Excessive_Dataset_Keys() throws Exception {
        PiePlot3D piePlot3D = new PiePlot3D();
        PieDataset dataset = mock(PieDataset.class);
        java.util.List<Comparable> keys = new java.util.ArrayList<>();
        keys.add("Key1");
        keys.add("Key2");
        keys.add("Key3");
        when(dataset.getKeys()).thenReturn(keys);
        piePlot3D.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 2, 100); // width less than keys.size()
        Point2D anchor = new Point2D.Double(1, 50);
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class, RETURNS_DEEP_STUBS);

        piePlot3D.draw(g2, plotArea, anchor, state, info);

        verify(g2, times(1)).drawString(eq("Too_many_elements"), anyInt(), anyInt());
        verify(g2, never()).drawString(eq("No data to display"), anyInt(), anyInt());
    }

    @Test
    @DisplayName("When start angle leads to negligible arc, arc is not drawn")
    public void test_TC09_Draw_With_Negligible_Arc_Angle() throws Exception {
        PiePlot3D piePlot3D = new PiePlot3D();
        PieDataset dataset = mock(PieDataset.class);
        java.util.List<Comparable> keys = new java.util.ArrayList<>();
        keys.add("Key1");
        keys.add("Key2");
        when(dataset.getKeys()).thenReturn(keys);
        when(dataset.getValue("Key1")).thenReturn(0.1);
        when(dataset.getValue("Key2")).thenReturn(0.1);
        piePlot3D.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D anchor = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class, RETURNS_DEEP_STUBS);

        piePlot3D.draw(g2, plotArea, anchor, state, info);

        verify(g2, never()).fill(any(Arc2D.class));
        verify(g2, never()).draw(any(Arc2D.class));
    }

    @Test
    @DisplayName("When depth factor is negative, method exits early without drawing")
    public void test_TC10_Draw_With_Negative_DepthFactor() throws Exception {
        PiePlot3D piePlot3D = new PiePlot3D();
        piePlot3D.setDepthFactor(-0.5); // Negative depth factor

        PieDataset dataset = mock(PieDataset.class);
        java.util.List<Comparable> keys = new java.util.ArrayList<>();
        keys.add("Key1");
        keys.add("Key2");
        when(dataset.getKeys()).thenReturn(keys);
        piePlot3D.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D anchor = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = mock(PlotRenderingInfo.class, RETURNS_DEEP_STUBS);

        piePlot3D.draw(g2, plotArea, anchor, state, info);

        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }
}