package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.HashMap;
import org.apache.commons.collections4.map.Flat3Map;

public class Flat3Map_containsKey_0_1_Test {

    @Test
    @DisplayName("containsKey returns true when delegateMap is not null and contains the key")
    public void TC01() throws Exception {
        // Initialize Flat3Map
        Flat3Map flat3Map = new Flat3Map<>();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        HashMap<Object, Object> delegateMap = new HashMap<>();
        Object key = "testKey";
        delegateMap.put(key, "value");
        delegateMapField.set(flat3Map, delegateMap);

        // Invoke containsKey
        boolean result = flat3Map.containsKey(key);

        // Assert
        assertTrue(result);
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is not null but does not contain the key")
    public void TC02() throws Exception {
        // Initialize Flat3Map
        Flat3Map flat3Map = new Flat3Map<>();

        // Set delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        HashMap<Object, Object> delegateMap = new HashMap<>();
        Object key = "testKey";
        delegateMap.put("otherKey", "value");
        delegateMapField.set(flat3Map, delegateMap);

        // Invoke containsKey
        boolean result = flat3Map.containsKey(key);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is null, size is 3, and key3 is null")
    public void TC03() throws Exception {
        // Initialize Flat3Map
        Flat3Map flat3Map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(flat3Map, 3);

        // Set key3 to null
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(flat3Map, null);

        // Invoke containsKey with key = null
        Object key = null;
        boolean result = flat3Map.containsKey(key);

        // Assert
        assertTrue(result);
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is null, size is 3, and key3 is not null")
    public void TC04() throws Exception {
        // Initialize Flat3Map
        Flat3Map flat3Map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(flat3Map, 3);

        // Set key3 to non-null
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object key3 = "key3";
        key3Field.set(flat3Map, key3);

        // Invoke containsKey with key = null
        Object key = null;
        boolean result = flat3Map.containsKey(key);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is null, size is 2, and key2 is null")
    public void TC05() throws Exception {
        // Initialize Flat3Map
        Flat3Map flat3Map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(flat3Map, 2);

        // Set key2 to null
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(flat3Map, null);

        // Invoke containsKey with key = null
        Object key = null;
        boolean result = flat3Map.containsKey(key);

        // Assert
        assertTrue(result);
    }
}