package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class NumberInput_parseInt_1_3_Test {

    @Test
    @DisplayName("parseInt with '+' sign and invalid digit throws NumberFormatException")
    void TC28() {
        char[] input = new char[] {'+', 'a'};
        int off = 0;
        int len = 2;

        assertThrows(NumberFormatException.class, () -> {
            NumberInput.parseInt(input, off, len);
        });
    }
}