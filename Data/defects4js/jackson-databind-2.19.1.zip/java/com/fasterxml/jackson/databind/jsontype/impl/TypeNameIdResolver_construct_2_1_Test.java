package com.fasterxml.jackson.databind.jsontype.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import java.util.Arrays;
import java.util.Collection;

public class TypeNameIdResolver_construct_2_1_Test {

    @Test
    @DisplayName("construct throws NullPointerException when subtypes collection contains a null NamedType")
    void TC15_construct_null_namedtype_in_subtypes() {
        // GIVEN
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        JavaType baseType = Mockito.mock(JavaType.class);
        Collection<NamedType> subtypes = Arrays.asList(new NamedType(null, "NullType"), null);
        boolean forSer = false;
        boolean forDeser = true;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
        });
    }

    @Test
    @DisplayName("construct throws NullPointerException when a NamedType in subtypes has a null type")
    void TC16_construct_namedtype_with_null_type() {
        // GIVEN
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        JavaType baseType = Mockito.mock(JavaType.class);
        NamedType invalidSubtype = new NamedType(null, "InvalidType");
        Collection<NamedType> subtypes = Arrays.asList(invalidSubtype);
        boolean forSer = false;
        boolean forDeser = true;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
        });
    }
}