package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ClassBands_removeCurrentClass_0_2_Test {

    @Test
    @DisplayName("Does not remove from classSignature when class_flags[index] has bit 19 not set")
    public void TC06() throws Exception {
        // Initialize mocked CpBands
        CpBands cpBands = mock(CpBands.class);
        when(cpBands.getCPClass(Mockito.anyString())).thenAnswer(invocation -> new CPClass(invocation.getArgument(0)));
        when(cpBands.getCPNameAndType(Mockito.anyString(), Mockito.anyString())).thenAnswer(invocation -> new CPNameAndType(invocation.getArgument(0), invocation.getArgument(1)));
        when(cpBands.getCPSignature(Mockito.anyString())).thenAnswer(invocation -> new CPSignature(invocation.getArgument(0)));
        when(cpBands.getCPUtf8(Mockito.anyString())).thenAnswer(invocation -> new CPUTF8(invocation.getArgument(0)));
        when(cpBands.getConstant(Mockito.any())).thenAnswer(invocation -> new CPConstant<>(invocation.getArgument(0)));

        // Initialize mocked AttributeDefinitionBands
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);

        // Initialize mocked Segment
        Segment segment = mock(Segment.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(mock(SegmentHeader.class));
        when(segment.getCurrentClassReader()).thenReturn(mock(ClassReader.class));

        int numClasses = 1;
        int effort = 10; // Example value
        boolean stripDebug = false;
        ClassBands classBands = new ClassBands(segment, numClasses, effort, stripDebug);

        // Access and set the 'index' field to 0
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        // Access and modify the 'class_flags' array to ensure bit 19 is not set
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L}; // Bit 19 not set
        classFlagsField.set(classBands, classFlags);

        // Access and initialize 'classSignature' list with a CPSignature instance
        Field classSignatureField = ClassBands.class.getDeclaredField("classSignature");
        classSignatureField.setAccessible(true);
        List<CPSignature> classSignature = new ArrayList<>();
        classSignature.add(new CPSignature("InitialSignature"));
        classSignatureField.set(classBands, classSignature);

        // Invoke removeCurrentClass
        classBands.removeCurrentClass();

        // Assert that classSignature remains unchanged
        assertEquals(1, classSignature.size(), "classSignature should remain unchanged when bit 19 is not set");
    }

    @Test
    @DisplayName("Removes the latest entry from class_RVA_bands when class_flags[index] has bit 21 set")
    public void TC07() throws Exception {
        // Initialize mocked CpBands
        CpBands cpBands = mock(CpBands.class);
        when(cpBands.getCPClass(Mockito.anyString())).thenAnswer(invocation -> new CPClass(invocation.getArgument(0)));
        when(cpBands.getCPNameAndType(Mockito.anyString(), Mockito.anyString())).thenAnswer(invocation -> new CPNameAndType(invocation.getArgument(0), invocation.getArgument(1)));
        when(cpBands.getCPSignature(Mockito.anyString())).thenAnswer(invocation -> new CPSignature(invocation.getArgument(0)));
        when(cpBands.getCPUtf8(Mockito.anyString())).thenAnswer(invocation -> new CPUTF8(invocation.getArgument(0)));
        when(cpBands.getConstant(Mockito.any())).thenAnswer(invocation -> new CPConstant<>(invocation.getArgument(0)));

        // Initialize mocked AttributeDefinitionBands
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);

        // Initialize mocked Segment
        Segment segment = mock(Segment.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(mock(SegmentHeader.class));
        when(segment.getCurrentClassReader()).thenReturn(mock(ClassReader.class));

        int numClasses = 1;
        int effort = 10; // Example value
        boolean stripDebug = false;
        ClassBands classBands = new ClassBands(segment, numClasses, effort, stripDebug);

        // Access and set the 'index' field to 0
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        // Access and modify the 'class_flags' array to set bit 21
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{1L << 21}; // Bit 21 set
        classFlagsField.set(classBands, classFlags);

        // Mock MetadataBandGroup and set it to 'class_RVA_bands'
        MetadataBandGroup classRVABandsMock = mock(MetadataBandGroup.class);
        Field classRVABandsField = ClassBands.class.getDeclaredField("class_RVA_bands");
        classRVABandsField.setAccessible(true);
        classRVABandsField.set(classBands, classRVABandsMock);

        // Invoke removeCurrentClass
        classBands.removeCurrentClass();

        // Verify that removeLatest was called on class_RVA_bands
        Mockito.verify(classRVABandsMock, Mockito.times(1)).removeLatest();
    }

    @Test
    @DisplayName("Does not remove from class_RVA_bands when class_flags[index] has bit 21 not set")
    public void TC08() throws Exception {
        // Initialize mocked CpBands
        CpBands cpBands = mock(CpBands.class);
        when(cpBands.getCPClass(Mockito.anyString())).thenAnswer(invocation -> new CPClass(invocation.getArgument(0)));
        when(cpBands.getCPNameAndType(Mockito.anyString(), Mockito.anyString())).thenAnswer(invocation -> new CPNameAndType(invocation.getArgument(0), invocation.getArgument(1)));
        when(cpBands.getCPSignature(Mockito.anyString())).thenAnswer(invocation -> new CPSignature(invocation.getArgument(0)));
        when(cpBands.getCPUtf8(Mockito.anyString())).thenAnswer(invocation -> new CPUTF8(invocation.getArgument(0)));
        when(cpBands.getConstant(Mockito.any())).thenAnswer(invocation -> new CPConstant<>(invocation.getArgument(0)));

        // Initialize mocked AttributeDefinitionBands
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);

        // Initialize mocked Segment
        Segment segment = mock(Segment.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(mock(SegmentHeader.class));
        when(segment.getCurrentClassReader()).thenReturn(mock(ClassReader.class));

        int numClasses = 1;
        int effort = 10; // Example value
        boolean stripDebug = false;
        ClassBands classBands = new ClassBands(segment, numClasses, effort, stripDebug);

        // Access and set the 'index' field to 0
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        // Access and modify the 'class_flags' array to ensure bit 21 is not set
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L}; // Bit 21 not set
        classFlagsField.set(classBands, classFlags);

        // Mock MetadataBandGroup and set it to 'class_RVA_bands'
        MetadataBandGroup classRVABandsMock = mock(MetadataBandGroup.class);
        Field classRVABandsField = ClassBands.class.getDeclaredField("class_RVA_bands");
        classRVABandsField.setAccessible(true);
        classRVABandsField.set(classBands, classRVABandsMock);

        // Invoke removeCurrentClass
        classBands.removeCurrentClass();

        // Verify that removeLatest was not called on class_RVA_bands
        Mockito.verify(classRVABandsMock, Mockito.never()).removeLatest();
    }

    @Test
    @DisplayName("Removes the latest entry from class_RIA_bands when class_flags[index] has bit 22 set")
    public void TC09() throws Exception {
        // Initialize mocked CpBands
        CpBands cpBands = mock(CpBands.class);
        when(cpBands.getCPClass(Mockito.anyString())).thenAnswer(invocation -> new CPClass(invocation.getArgument(0)));
        when(cpBands.getCPNameAndType(Mockito.anyString(), Mockito.anyString())).thenAnswer(invocation -> new CPNameAndType(invocation.getArgument(0), invocation.getArgument(1)));
        when(cpBands.getCPSignature(Mockito.anyString())).thenAnswer(invocation -> new CPSignature(invocation.getArgument(0)));
        when(cpBands.getCPUtf8(Mockito.anyString())).thenAnswer(invocation -> new CPUTF8(invocation.getArgument(0)));
        when(cpBands.getConstant(Mockito.any())).thenAnswer(invocation -> new CPConstant<>(invocation.getArgument(0)));

        // Initialize mocked AttributeDefinitionBands
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);

        // Initialize mocked Segment
        Segment segment = mock(Segment.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(mock(SegmentHeader.class));
        when(segment.getCurrentClassReader()).thenReturn(mock(ClassReader.class));

        int numClasses = 1;
        int effort = 10; // Example value
        boolean stripDebug = false;
        ClassBands classBands = new ClassBands(segment, numClasses, effort, stripDebug);

        // Access and set the 'index' field to 0
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        // Access and modify the 'class_flags' array to set bit 22
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{1L << 22}; // Bit 22 set
        classFlagsField.set(classBands, classFlags);

        // Mock MetadataBandGroup and set it to 'class_RIA_bands'
        MetadataBandGroup classRIABandsMock = mock(MetadataBandGroup.class);
        Field classRIABandsField = ClassBands.class.getDeclaredField("class_RIA_bands");
        classRIABandsField.setAccessible(true);
        classRIABandsField.set(classBands, classRIABandsMock);

        // Invoke removeCurrentClass
        classBands.removeCurrentClass();

        // Verify that removeLatest was called on class_RIA_bands
        Mockito.verify(classRIABandsMock, Mockito.times(1)).removeLatest();
    }

    @Test
    @DisplayName("Does not remove from class_RIA_bands when class_flags[index] has bit 22 not set")
    public void TC10() throws Exception {
        // Initialize mocked CpBands
        CpBands cpBands = mock(CpBands.class);
        when(cpBands.getCPClass(Mockito.anyString())).thenAnswer(invocation -> new CPClass(invocation.getArgument(0)));
        when(cpBands.getCPNameAndType(Mockito.anyString(), Mockito.anyString())).thenAnswer(invocation -> new CPNameAndType(invocation.getArgument(0), invocation.getArgument(1)));
        when(cpBands.getCPSignature(Mockito.anyString())).thenAnswer(invocation -> new CPSignature(invocation.getArgument(0)));
        when(cpBands.getCPUtf8(Mockito.anyString())).thenAnswer(invocation -> new CPUTF8(invocation.getArgument(0)));
        when(cpBands.getConstant(Mockito.any())).thenAnswer(invocation -> new CPConstant<>(invocation.getArgument(0)));

        // Initialize mocked AttributeDefinitionBands
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);

        // Initialize mocked Segment
        Segment segment = mock(Segment.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);
        when(segment.getSegmentHeader()).thenReturn(mock(SegmentHeader.class));
        when(segment.getCurrentClassReader()).thenReturn(mock(ClassReader.class));

        int numClasses = 1;
        int effort = 10; // Example value
        boolean stripDebug = false;
        ClassBands classBands = new ClassBands(segment, numClasses, effort, stripDebug);

        // Access and set the 'index' field to 0
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        // Access and modify the 'class_flags' array to ensure bit 22 is not set
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L}; // Bit 22 not set
        classFlagsField.set(classBands, classFlags);

        // Mock MetadataBandGroup and set it to 'class_RIA_bands'
        MetadataBandGroup classRIABandsMock = mock(MetadataBandGroup.class);
        Field classRIABandsField = ClassBands.class.getDeclaredField("class_RIA_bands");
        classRIABandsField.setAccessible(true);
        classRIABandsField.set(classBands, classRIABandsMock);

        // Invoke removeCurrentClass
        classBands.removeCurrentClass();

        // Verify that removeLatest was not called on class_RIA_bands
        Mockito.verify(classRIABandsMock, Mockito.never()).removeLatest();
    }
}

// Mocked CPSignature class for testing purposes
class CPSignature {
    private String signature;

    public CPSignature(String signature) {
        this.signature = signature;
    }

    @Override
    public String toString() {
        return signature;
    }
}

// Mocked CPClass class for testing purposes
class CPClass {
    private String className;

    public CPClass(String className) {
        this.className = className;
    }

    @Override
    public String toString() {
        return className;
    }
}

// Mocked CPNameAndType class for testing purposes
class CPNameAndType {
    private String name;
    private String type;

    public CPNameAndType(String name, String type) {
        this.name = name;
        this.type = type;
    }

    @Override
    public String toString() {
        return name + ":" + type;
    }
}

// Mocked CPUTF8 class for testing purposes
class CPUTF8 {
    private String value;

    public CPUTF8(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}

// Mocked CPConstant class for testing purposes
class CPConstant<T> {
    private T value;

    public CPConstant(T value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value.toString();
    }
}

// Mocked SegmentHeader class for testing purposes
class SegmentHeader {
    public boolean have_class_flags_hi() {
        return false;
    }

    public boolean have_field_flags_hi() {
        return false;
    }

    public boolean have_method_flags_hi() {
        return false;
    }

    public boolean have_code_flags_hi() {
        return false;
    }
}

// Mocked Segment class for testing purposes
class Segment {
    public CpBands getCpBands() {
        return null;
    }

    public AttributeDefinitionBands getAttrBands() {
        return null;
    }

    public SegmentHeader getSegmentHeader() {
        return null;
    }

    public ClassReader getCurrentClassReader() {
        return null;
    }
}

// Mocked ClassReader class for testing purposes
class ClassReader {
    public boolean hasSyntheticAttributes() {
        return false;
    }
}

// Mocked AttributeDefinitionBands class for testing purposes
class AttributeDefinitionBands {
    // Add necessary methods and fields if needed for testing
}

// Mocked MetadataBandGroup class for testing purposes
class MetadataBandGroup {
    // Assuming necessary methods are present in the actual class
    public void addAnnotation(String desc, List<String> nameRU, List<String> tags, List<Object> values,
                              List<Integer> caseArrayN, List<String> nestTypeRS, List<String> nestNameRU,
                              List<Integer> nestPairN) {}

    public void removeLatest() {}

    public int getAnnotationCount() { return 0; }

    public boolean containsAnnotation(String annotation) { return false; }
}
