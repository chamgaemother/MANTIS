package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

public class UTF8DataInputJsonParser_nextToken_1_3_Test {

    @Test
    @DisplayName("nextToken() handles strings with escaped quotes correctly")
    public void parse_string_with_escaped_quotes() throws Exception {
        // Arrange
        String json = "\"He said, \\\"Hello\\\"\"";  // Correct the JSON format
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = (bytes.length > 0) ? bytes[0] : -1;
        byte[] remainingBytes = (bytes.length > 1) ? java.util.Arrays.copyOfRange(bytes, 1, bytes.length) : new byte[0];
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor();
        ioContextCtor.setAccessible(true);
        IOContext ioContext = ioContextCtor.newInstance();

        // Instantiate ByteQuadsCanonicalizer via reflection
        Constructor<ByteQuadsCanonicalizer> symCtor = ByteQuadsCanonicalizer.class.getDeclaredConstructor(int.class, boolean.class);
        symCtor.setAccessible(true);
        ByteQuadsCanonicalizer sym = symCtor.newInstance(0, true);

        // Instantiate the parser
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, inputData, null, sym, firstByte);

        // Act
        JsonToken result = parser.nextToken();
        String text = parser.getText();

        // Assert
        assertEquals(JsonToken.VALUE_STRING, result, "Expected token to be VALUE_STRING");
        assertEquals("He said, \"Hello\"", text, "Expected unescaped string value");
    }

    @Test
    @DisplayName("nextToken() handles multiple tokens in sequence correctly")
    public void parse_multiple_tokens_in_sequence() throws Exception {
        // Arrange
        String json = "{\"name\":\"John\",\"age\":30}";
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = (bytes.length > 0) ? bytes[0] : -1;
        byte[] remainingBytes = (bytes.length > 1) ? java.util.Arrays.copyOfRange(bytes, 1, bytes.length) : new byte[0];
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor();
        ioContextCtor.setAccessible(true);
        IOContext ioContext = ioContextCtor.newInstance();

        // Instantiate ByteQuadsCanonicalizer via reflection
        Constructor<ByteQuadsCanonicalizer> symCtor = ByteQuadsCanonicalizer.class.getDeclaredConstructor(int.class, boolean.class);
        symCtor.setAccessible(true);
        ByteQuadsCanonicalizer sym = symCtor.newInstance(0, true);

        // Instantiate the parser
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, inputData, null, sym, firstByte);

        // Act & Assert
        JsonToken token = parser.nextToken();
        assertEquals(JsonToken.START_OBJECT, token, "Expected START_OBJECT token");

        token = parser.nextToken();
        assertEquals(JsonToken.FIELD_NAME, token, "Expected FIELD_NAME token for 'name'");
        assertEquals("name", parser.getCurrentName(), "Expected field name 'name'");

        token = parser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, token, "Expected VALUE_STRING token for 'John'");
        assertEquals("John", parser.getText(), "Expected value 'John'");

        token = parser.nextToken();
        assertEquals(JsonToken.FIELD_NAME, token, "Expected FIELD_NAME token for 'age'");
        assertEquals("age", parser.getCurrentName(), "Expected field name 'age'");

        token = parser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token, "Expected VALUE_NUMBER_INT token for 30");
        assertEquals(30, parser.getIntValue(), "Expected integer value 30");

        token = parser.nextToken();
        assertEquals(JsonToken.END_OBJECT, token, "Expected END_OBJECT token");

        token = parser.nextToken();
        assertNull(token, "Expected null token after END_OBJECT");
    }

    @Test
    @DisplayName("nextToken() correctly handles invalid number format by throwing exception")
    public void parse_invalid_number_throws_exception() throws Exception {
        // Arrange
        String json = "123abc";
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = (bytes.length > 0) ? bytes[0] : -1;
        byte[] remainingBytes = (bytes.length > 1) ? java.util.Arrays.copyOfRange(bytes, 1, bytes.length) : new byte[0];
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor();
        ioContextCtor.setAccessible(true);
        IOContext ioContext = ioContextCtor.newInstance();

        // Instantiate ByteQuadsCanonicalizer via reflection
        Constructor<ByteQuadsCanonicalizer> symCtor = ByteQuadsCanonicalizer.class.getDeclaredConstructor(int.class, boolean.class);
        symCtor.setAccessible(true);
        ByteQuadsCanonicalizer sym = symCtor.newInstance(0, true);

        // Instantiate the parser
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, inputData, null, sym, firstByte);

        // Act & Assert
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        }, "Expected JsonParseException due to invalid number format");
        assertTrue(exception.getMessage().contains("expected digit"), "Exception message should indicate expected digit");
    }

    @Test
    @DisplayName("nextToken() handles leading plus sign in number when ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS is disabled by throwing exception")
    public void parse_number_with_leading_plus_throws_exception() throws Exception {
        // Arrange
        String json = "+123";
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = (bytes.length > 0) ? bytes[0] : -1;
        byte[] remainingBytes = (bytes.length > 1) ? java.util.Arrays.copyOfRange(bytes, 1, bytes.length) : new byte[0];
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor();
        ioContextCtor.setAccessible(true);
        IOContext ioContext = ioContextCtor.newInstance();

        // Instantiate ByteQuadsCanonicalizer via reflection
        Constructor<ByteQuadsCanonicalizer> symCtor = ByteQuadsCanonicalizer.class.getDeclaredConstructor(int.class, boolean.class);
        symCtor.setAccessible(true);
        ByteQuadsCanonicalizer sym = symCtor.newInstance(0, true);

        // Configure features: ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS disabled (default)
        int features = 0;

        // Instantiate the parser
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, features, inputData, null, sym, firstByte);

        // Act & Assert
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        }, "Expected JsonParseException due to leading plus sign");
        assertTrue(exception.getMessage().contains("expected digit"), "Exception message should indicate expected digit");
    }

    @Test
    @DisplayName("nextToken() handles strings with unicode characters correctly")
    public void parse_string_with_unicode_characters() throws Exception {
        // Arrange
        String json = "\"Hello, \u4e16\u754c\""; // Correct the JSON format
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = (bytes.length > 0) ? bytes[0] : -1;
        byte[] remainingBytes = (bytes.length > 1) ? java.util.Arrays.copyOfRange(bytes, 1, bytes.length) : new byte[0];
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor();
        ioContextCtor.setAccessible(true);
        IOContext ioContext = ioContextCtor.newInstance();

        // Instantiate ByteQuadsCanonicalizer via reflection
        Constructor<ByteQuadsCanonicalizer> symCtor = ByteQuadsCanonicalizer.class.getDeclaredConstructor(int.class, boolean.class);
        symCtor.setAccessible(true);
        ByteQuadsCanonicalizer sym = symCtor.newInstance(0, true);

        // Instantiate the parser
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, 0, inputData, null, sym, firstByte);

        // Act
        JsonToken result = parser.nextToken();
        String text = parser.getText();

        // Assert
        assertEquals(JsonToken.VALUE_STRING, result, "Expected token to be VALUE_STRING");
        assertEquals("Hello, 世界", text, "Expected string to correctly parse unicode characters");
    }
}