package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.DisplayName;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.jfree.data.general.DatasetUtils;

public class StackedXYBarRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("TC27: drawItem processes with renderAsPercentages=true and both positive and negative Y values in series")
    public void TC27_drawItem_with_percentages_and_mixed_Y_values() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        
        // Use reflection to set private field renderAsPercentages to true
        Field field = StackedXYBarRenderer.class.getDeclaredField("renderAsPercentages");
        field.setAccessible(true);
        field.set(renderer, true);
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Setup dataset to have both positive and negative Y values
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(10.0, -5.0);
        
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenReturn(50.0, 100.0, 100.0, 50.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM)))
            .thenReturn(10.0, 20.0);
        
        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
        });
    }

    @Test
    @DisplayName("TC28: drawItem handles renderAsPercentages=true with total stack zero, avoiding division by zero")
    public void TC28_drawItem_with_percentages_and_zero_total_stack() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        
        // Use reflection to set private field renderAsPercentages to true
        Field field = StackedXYBarRenderer.class.getDeclaredField("renderAsPercentages");
        field.setAccessible(true);
        field.set(renderer, true);
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Setup dataset Y values summing to zero
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(5.0, -5.0);
        
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenReturn(50.0, 50.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM)))
            .thenReturn(10.0, 20.0);
        
        // Mock DatasetUtils.calculateStackTotal to return zero
        try (MockedStatic<DatasetUtils> mocked = Mockito.mockStatic(DatasetUtils.class)) {
            mocked.when(() -> DatasetUtils.calculateStackTotal(any(TableXYDataset.class), anyInt()))
                   .thenReturn(0.0);
            
            // Act & Assert
            assertDoesNotThrow(() -> {
                renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
            });
        }
    }

    @Test
    @DisplayName("TC29: drawItem processes renderAsPercentages=true with multiple series iterations")
    public void TC29_drawItem_with_percentages_and_multiple_series() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        
        // Use reflection to set private field renderAsPercentages to true
        Field field = StackedXYBarRenderer.class.getDeclaredField("renderAsPercentages");
        field.setAccessible(true);
        field.set(renderer, true);
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Setup dataset with multiple series
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(10.0, 20.0, 30.0);
        
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
        
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenReturn(50.0, 100.0, 150.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM)))
            .thenReturn(10.0, 20.0);
        
        // Act & Assert
        assertDoesNotThrow(() -> {
            for (int series = 0; series < 3; series++) {
                renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, 0, crosshairState, 1);
            }
        });
    }

    @Test
    @DisplayName("TC30: drawItem throws IllegalStateException for unsupported plot orientation")
    public void TC30_drawItem_with_unsupported_plot_orientation() throws Exception {
        // Arrange
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        
        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Setup plot with unsupported orientation
        when(plot.getOrientation()).thenReturn(null);
        
        // Act & Assert
        Exception exception = assertThrows(IllegalStateException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 1);
        });
        
        assertNotNull(exception);
    }

}
