package org.apache.commons.math3.geometry.euclidean.threed;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.geometry.euclidean.threed.FieldRotation;
import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FieldRotation_getAngles_0_1_Test {

//    @Test
//    @DisplayName("TC01: getAngles called with RotationOrder.XYZ and RotationConvention.VECTOR_OPERATOR, v2.getZ() within bounds")
//    public void testTC01() {
//        // GIVEN
//        RotationOrder order = RotationOrder.XYZ;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Creating FieldRotation with test values
//        FieldRotation<Double> fieldRotation = new FieldRotation<>(0.9238795325112867, 0.0, 0.3826834323650898, 0.0, false);
//
//        // WHEN
//        Double[] angles = fieldRotation.getAngles(order, convention);
//
//        // THEN
//        assertNotNull(angles, "Angles array should not be null");
//        assertEquals(3, angles.length, "Angles array should have length 3");
//        // Additional assertions can be added based on expected angle values
//    }
//
//    @Test
//    @DisplayName("TC02: getAngles called with RotationOrder.XYZ and RotationConvention.VECTOR_OPERATOR, v2.getZ() out of bounds triggering exception")
//    public void testTC02() {
//        // GIVEN
//        RotationOrder order = RotationOrder.XYZ;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Creating a FieldRotation that will cause v2.getZ() to be greater than 0.9999999999
//        FieldRotation<Double> fieldRotation = new FieldRotation<>(
//            0.0,
//            1.0,
//            0.0,
//            0.0,
//            false
//        );
//
//        // WHEN & THEN
//        assertThrows(CardanEulerSingularityException.class, () -> {
//            fieldRotation.getAngles(order, convention);
//        }, "Expected CardanEulerSingularityException to be thrown");
//    }
//
//    @Test
//    @DisplayName("TC03: getAngles called with RotationOrder.XZY and RotationConvention.VECTOR_OPERATOR, v2.getY() within bounds")
//    public void testTC03() {
//        // GIVEN
//        RotationOrder order = RotationOrder.XZY;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        FieldRotation<Double> fieldRotation = new FieldRotation<>(
//            0.9238795325112867,
//            0.0,
//            0.0,
//            0.3826834323650898,
//            false
//        );
//
//        // WHEN
//        Double[] angles = fieldRotation.getAngles(order, convention);
//
//        // THEN
//        assertNotNull(angles, "Angles array should not be null");
//        assertEquals(3, angles.length, "Angles array should have length 3");
//        // Additional assertions can be added based on expected angle values
//    }
//
//    @Test
//    @DisplayName("TC04: getAngles called with RotationOrder.XZY and RotationConvention.VECTOR_OPERATOR, v2.getY() out of bounds triggering exception")
//    public void testTC04() {
//        // GIVEN
//        RotationOrder order = RotationOrder.XZY;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Creating a FieldRotation that will cause v2.getY() to be greater than 0.9999999999
//        FieldRotation<Double> fieldRotation = new FieldRotation<>(
//            0.0,
//            0.0,
//            1.0,
//            0.0,
//            false
//        );
//
//        // WHEN & THEN
//        assertThrows(CardanEulerSingularityException.class, () -> {
//            fieldRotation.getAngles(order, convention);
//        }, "Expected CardanEulerSingularityException to be thrown");
//    }
//
//    @Test
//    @DisplayName("TC05: getAngles called with RotationOrder.YXZ and RotationConvention.VECTOR_OPERATOR, v2.getZ() within bounds")
//    public void testTC05() {
//        // GIVEN
//        RotationOrder order = RotationOrder.YXZ;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        FieldRotation<Double> fieldRotation = new FieldRotation<>(
//            0.9238795325112867,
//            0.3826834323650898,
//            0.0,
//            0.0,
//            false
//        );
//
//        // WHEN
//        Double[] angles = fieldRotation.getAngles(order, convention);
//
//        // THEN
//        assertNotNull(angles, "Angles array should not be null");
//        assertEquals(3, angles.length, "Angles array should have length 3");
//        // Additional assertions can be added based on expected angle values
//    }
}
