package org.jfree.chart.renderer.xy;
import org.jfree.chart.ui.RectangleEdge;

import org.jfree.chart.ChartRenderingInfo;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.IntervalXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;

public class DeviationStepRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem returns immediately when the item is not visible")
    public void TC01_drawItem_itemNotVisible() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        // Mock getItemVisible to return false
        DeviationStepRenderer spyRenderer = Mockito.spy(renderer);
        doReturn(false).when(spyRenderer).getItemVisible(series, item);

        // Act
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that the method returns early without performing further actions
        verify(spyRenderer, times(1)).getItemVisible(series, item);
        verifyNoMoreInteractions(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, crosshairState);
    }

    @Test
    @DisplayName("drawItem processes the first pass with item visible and pass=0")
    public void TC02_drawItem_firstPass_itemVisible_pass0() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 1;
        int pass = 0;

        // Mock getItemVisible to return true
        DeviationStepRenderer spyRenderer = Mockito.spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(series, item);

        // Mock dataset values
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getStartYValue(series, item)).thenReturn(5.0);
        when(dataset.getEndYValue(series, item)).thenReturn(15.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Additional mock for State instance inside drawItem
        DeviationStepRenderer.State drState = mock(DeviationStepRenderer.State.class);
        spyRenderer.drawItem(g2, drState, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(spyRenderer, times(1)).getItemVisible(series, item);
        verify(dataset, times(1)).getXValue(series, item);
        verify(dataset, times(1)).getStartYValue(series, item);
        verify(dataset, times(1)).getEndYValue(series, item);
        verify(domainAxis, times(1)).valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM);
        verify(rangeAxis, times(1)).valueToJava2D(5.0, dataArea, RectangleEdge.LEFT);
        verify(rangeAxis, times(1)).valueToJava2D(15.0, dataArea, RectangleEdge.LEFT);
        // Additional verifications can be added based on what shading entails
    }

    @Test
    @DisplayName("drawItem processes pass=0 with item index > 0")
    public void TC03_drawItem_pass0_itemIndexGreaterThan0() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 2;
        int pass = 0;

        // Mock getItemVisible to return true
        DeviationStepRenderer spyRenderer = Mockito.spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(series, item);
        doReturn(true).when(spyRenderer).getItemVisible(series, item - 1);

        // Mock dataset values for current and previous items
        when(dataset.getXValue(series, item)).thenReturn(20.0);
        when(dataset.getStartYValue(series, item)).thenReturn(10.0);
        when(dataset.getEndYValue(series, item)).thenReturn(30.0);
        when(dataset.getXValue(series, item - 1)).thenReturn(15.0);
        when(dataset.getStartYValue(series, item - 1)).thenReturn(8.0);
        when(dataset.getEndYValue(series, item - 1)).thenReturn(25.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(30.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, RectangleEdge.LEFT)).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(25.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Additional mock for State instance inside drawItem
        DeviationStepRenderer.State drState = mock(DeviationStepRenderer.State.class);
        spyRenderer.drawItem(g2, drState, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(spyRenderer, times(1)).getItemVisible(series, item);
        verify(spyRenderer, times(1)).getItemVisible(series, item - 1);
        verify(dataset, times(1)).getXValue(series, item);
        verify(dataset, times(1)).getStartYValue(series, item);
        verify(dataset, times(1)).getEndYValue(series, item);
        verify(dataset, times(1)).getXValue(series, item - 1);
        verify(dataset, times(1)).getStartYValue(series, item - 1);
        verify(dataset, times(1)).getEndYValue(series, item - 1);
        // Additional verifications can be added based on shading updates
    }

    @Test
    @DisplayName("drawItem handles NaN x-value in pass=0")
    public void TC04_drawItem_pass0_nanXValue() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 3;
        int pass = 0;

        // Mock getItemVisible to return true
        DeviationStepRenderer spyRenderer = Mockito.spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(series, item);

        // Mock dataset values with NaN x-value
        when(dataset.getXValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getStartYValue(series, item)).thenReturn(12.0);
        when(dataset.getEndYValue(series, item)).thenReturn(22.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(Double.NaN, dataArea, RectangleEdge.BOTTOM)).thenReturn(Double.NaN);
        when(rangeAxis.valueToJava2D(12.0, dataArea, RectangleEdge.LEFT)).thenReturn(120.0);
        when(rangeAxis.valueToJava2D(22.0, dataArea, RectangleEdge.LEFT)).thenReturn(220.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Additional mock for State instance inside drawItem
        DeviationStepRenderer.State drState = mock(DeviationStepRenderer.State.class);
        spyRenderer.drawItem(g2, drState, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(spyRenderer, times(1)).getItemVisible(series, item);
        verify(dataset, times(1)).getXValue(series, item);
        // Since x-value is NaN, shading should not be drawn
        verify(g2, never()).fill(any());
    }

    @Test
    @DisplayName("drawItem handles NaN yLow in pass=0")
    public void TC05_drawItem_pass0_nanYLow() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 4;
        int pass = 0;

        // Mock getItemVisible to return true
        DeviationStepRenderer spyRenderer = Mockito.spy(renderer);
        doReturn(true).when(spyRenderer).getItemVisible(series, item);

        // Mock dataset values with NaN yLow
        when(dataset.getXValue(series, item)).thenReturn(25.0);
        when(dataset.getStartYValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(series, item)).thenReturn(35.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(25.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(250.0);
        when(rangeAxis.valueToJava2D(Double.NaN, dataArea, RectangleEdge.LEFT)).thenReturn(Double.NaN);
        when(rangeAxis.valueToJava2D(35.0, dataArea, RectangleEdge.LEFT)).thenReturn(350.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Additional mock for State instance inside drawItem
        DeviationStepRenderer.State drState = mock(DeviationStepRenderer.State.class);
        spyRenderer.drawItem(g2, drState, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(spyRenderer, times(1)).getItemVisible(series, item);
        verify(dataset, times(1)).getXValue(series, item);
        verify(dataset, times(1)).getStartYValue(series, item);
        verify(rangeAxis, times(1)).valueToJava2D(Double.NaN, dataArea, RectangleEdge.LEFT);
        // Since yLow is NaN, shading should not be drawn
        verify(g2, never()).fill(any());
    }
}