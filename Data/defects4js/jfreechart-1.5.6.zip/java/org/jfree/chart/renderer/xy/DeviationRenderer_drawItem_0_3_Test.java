package org.jfree.chart.renderer.xy;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;

import java.awt.geom.Rectangle2D;
import java.awt.Graphics2D;

import org.jfree.data.xy.XYDataset;

public class DeviationRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("Pass is not 0, not a line pass nor item pass")
    public void TC11_invalidPassDoesNothing() throws Exception {
        // GIVEN
        DeviationRenderer renderer = Mockito.spy(new DeviationRenderer());
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
        Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        XYDataset dataset = Mockito.mock(XYDataset.class);
        CrosshairState crosshairState = Mockito.mock(CrosshairState.class);

        int series = 0;
        int item = 1;
        int pass = 3;

        Mockito.doReturn(true).when(renderer).getItemVisible(series, item);
        Mockito.doReturn(false).when(renderer).isLinePass(pass);
        Mockito.doReturn(false).when(renderer).isItemPass(pass);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that drawPrimaryLineAsPath and drawSecondaryPass are never called
        Mockito.verify(renderer, Mockito.never()).drawPrimaryLineAsPath(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.verify(renderer, Mockito.never()).drawSecondaryPass(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
    }

    @Test
    @DisplayName("Pass is not 0, is item pass, item is first in series")
    public void TC12_itemPassWithFirstItemInSeries() throws Exception {
        // GIVEN
        DeviationRenderer renderer = Mockito.spy(new DeviationRenderer());
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        TestXYItemRendererState state = Mockito.mock(TestXYItemRendererState.class);
        Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        XYDataset dataset = Mockito.mock(XYDataset.class);
        CrosshairState crosshairState = Mockito.mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 2;

        Mockito.doReturn(true).when(renderer).getItemVisible(series, item);
        Mockito.doReturn(true).when(renderer).isItemPass(pass);
        Mockito.doReturn(1).when(dataset).getItemCount(series);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that drawSecondaryPass is called
        Mockito.verify(renderer).drawSecondaryPass(Mockito.eq(g2), Mockito.eq(plot), Mockito.eq(dataset), Mockito.eq(pass), Mockito.eq(series), Mockito.eq(item), Mockito.eq(domainAxis), Mockito.eq(dataArea), Mockito.eq(rangeAxis), Mockito.eq(crosshairState), Mockito.any());
        // Verify that state.reset() is called to reset the series path
        Mockito.verify(state).reset();
    }

    // Private stub class to substitute the actual XYItemRendererState as it requires special implementation for resetting
    private static class TestXYItemRendererState extends XYItemRendererState {
        public TestXYItemRendererState(PlotRenderingInfo info) {
            super(info);
        }

        public void reset() {
            // reset logic here
        }
    }
}