import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.renderer.xy.GradientXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class GradientXYBarPainterTest {

    private GradientXYBarPainter painter;
    private Graphics2D g2;
    private XYBarRenderer renderer;
    private Rectangle2D bar;

    @BeforeEach
    public void setUp() {
        painter = new GradientXYBarPainter();
        g2 = mock(Graphics2D.class);
        renderer = mock(XYBarRenderer.class);
        bar = new Rectangle2D.Double(0, 0, 100, 50);
    }

    @Test
    public void testNullGraphics2D() {
        assertThrows(NullPointerException.class, () -> 
            painter.paintBar(null, renderer, 0, 0, bar, RectangleEdge.BOTTOM)
        );
    }

    @Test
    public void testNullRenderer() {
        assertThrows(NullPointerException.class, () -> 
            painter.paintBar(g2, null, 0, 0, bar, RectangleEdge.BOTTOM)
        );
    }

    @Test
    public void testNullBar() {
        assertThrows(NullPointerException.class, () -> 
            painter.paintBar(g2, renderer, 0, 0, null, RectangleEdge.BOTTOM)
        );
    }

    @Test
    public void testNullRectangleEdge() {
        assertThrows(NullPointerException.class, () -> 
            painter.paintBar(g2, renderer, 0, 0, bar, null)
        );
    }

    @Test
    public void testValidPaintBarBottomEdgeWithColor() {
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.RED);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        verify(g2, atLeastOnce()).setPaint(any(GradientPaint.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
    }

    @Test
    public void testValidPaintBarBottomEdgeWithGradientPaint() {
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.BLUE);
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(gradientPaint);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        verify(g2, atLeastOnce()).setPaint(any(GradientPaint.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
    }

    @Test
    public void testPaintBarTopEdge() {
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.GREEN);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.TOP);
        verify(g2, atLeastOnce()).setPaint(any(GradientPaint.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
    }

    @Test
    public void testPaintBarLeftEdge() {
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.BLUE);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.LEFT);
        verify(g2, atLeastOnce()).setPaint(any(GradientPaint.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
    }

    @Test
    public void testPaintBarRightEdge() {
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.ORANGE);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.RIGHT);
        verify(g2, atLeastOnce()).setPaint(any(GradientPaint.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
    }

    @Test
    public void testAlphaZeroColor() {
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(new Color(0, 0, 0, 0));
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).fill(any(Rectangle2D.class));
    }

    @Test
    public void testDrawBarOutline() {
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.RED);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(anyInt(), anyInt())).thenReturn(new BasicStroke(1.0f));
        when(renderer.getItemOutlinePaint(anyInt(), anyInt())).thenReturn(Color.BLACK);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        verify(g2, times(1)).draw(bar);
    }

    @Test
    public void testDoNotDrawBarOutline() {
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.RED);
        when(renderer.isDrawBarOutline()).thenReturn(false);
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.BOTTOM);
        verify(g2, never()).draw(any(Rectangle2D.class));
    }
}