package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

public class JsonStringEncoder_quoteAsUTF8_0_4_Test {

    @Test
    @DisplayName("quoteAsUTF8 with string containing high Unicode characters")
    void TC16() {
        String text = "ðð«ð¦ð ð¬ð¡ð¢";
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.quoteAsUTF8(text);
        byte[] expectedBytes = new byte[] {
            (byte)0xF0, (byte)0x9D, (byte)0x94, (byte)0x98, // ð
            (byte)0xF0, (byte)0x9D, (byte)0x94, (byte)0xAB, // ð«
            (byte)0xF0, (byte)0x9D, (byte)0x94, (byte)0xA6, // ð¦
            (byte)0xF0, (byte)0x9D, (byte)0x94, (byte)0xA0, // ð 
            (byte)0xF0, (byte)0x9D, (byte)0x94, (byte)0xAC, // ð¬
            (byte)0xF0, (byte)0x9D, (byte)0x94, (byte)0xA1, // ð¡
            (byte)0xF0, (byte)0x9D, (byte)0x94, (byte)0xA2  // ð¢
        };
        assertArrayEquals(expectedBytes, result, "The byte array should correctly encode high Unicode characters.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with string requiring multiple buffer resizes")
    void TC17() {
        // Generate a very long string requiring multiple buffer resizes
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 10000; i++) {
            sb.append("a");
        }
        String text = sb.toString();
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.quoteAsUTF8(text);
        int expectedLength = 10000; // Each 'a' is 1 byte in UTF-8
        assertEquals(expectedLength, result.length, "The byte array should have the expected length after multiple buffer resizes.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with string containing mixed ASCII and non-ASCII characters")
    void TC18() {
        String text = "Helloæ¼¢å­World";
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.quoteAsUTF8(text);
        byte[] expected = new byte[] {
            72, 101, 108, 108, 111, 
            (byte)0xE6, (byte)0xBC, (byte)0xA2, 
            (byte)0xE5, (byte)0xAD, (byte)0x97, 
            87, 111, 114, 108, 100
        };
        assertTrue(Arrays.equals(expected, result), "The byte array should correctly encode mixed ASCII and non-ASCII characters.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with string containing only escapable characters")
    void TC19() {
        String text = "\n\t\r";
        JsonStringEncoder encoder = new JsonStringEncoder();
        byte[] result = encoder.quoteAsUTF8(text);
        byte[] expected = new byte[] {92, 110, 92, 116, 92, 114};
        assertArrayEquals(expected, result, "The byte array should correctly encode a string with only escapable characters.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with string containing mixed surrogate pairs and invalid escapes")
    void TC20() {
        String text = "Test\n\uD83D\uDE00Invalid\\x";
        JsonStringEncoder encoder = new JsonStringEncoder();
        assertThrows(IllegalArgumentException.class, () -> {
            encoder.quoteAsUTF8(text);
        }, "An IllegalArgumentException should be thrown for invalid surrogate pairs and escapes.");
    }
}