package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;

public class DfpMath_pow_0_1_Test {

//    @Test
//    @DisplayName("pow(x, y) returns NaN when x and y have different radix digits")
//    public void TC01() {
//        DfpField fieldX = new DfpField(10);
//        Dfp x = new Dfp(fieldX, "2.0");
//        DfpField fieldY = new DfpField(12);
//        Dfp y = new Dfp(fieldY, "3.0");
//        Dfp result = DfpMath.pow(x, y);
//        assertTrue(result.isNaN(), "Result should be NaN.");
//        assertEquals(DfpField.FLAG_INVALID, x.getField().getIEEEFlagsBits(), "FLAG_INVALID should be set.");
//    }

    @Test
    @DisplayName("pow(x, 0) returns 1 for any x")
    public void TC02() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "2.0");
        Dfp y = x.getZero();
        Dfp result = DfpMath.pow(x, y);
        assertEquals(x.getOne(), result, "pow(x, 0) should return 1.");
    }

    @Test
    @DisplayName("pow(x, 1) returns x when x is not NaN")
    public void TC03() {
        DfpField field = new DfpField(10);
        Dfp x = new Dfp(field, "2.0");
        Dfp y = x.getOne();
        Dfp result = DfpMath.pow(x, y);
        assertEquals(x, result, "pow(x, 1) should return x.");
    }

//    @Test
//    @DisplayName("pow(x, 1) returns NaN when x is NaN")
//    public void TC04() {
//        DfpField field = new DfpField(10);
//        Dfp x = field.newDfp(DfpField.QNAN); // Corrected instantiation for NaN
//        Dfp y = x.getOne();
//        Dfp result = DfpMath.pow(x, y);
//        assertTrue(result.isNaN(), "Result should be NaN.");
//        assertEquals(DfpField.FLAG_INVALID, x.getField().getIEEEFlagsBits(), "FLAG_INVALID should be set.");
//    }
//
//    @Test
//    @DisplayName("pow(x, NaN) returns NaN when y is NaN")
//    public void TC05() {
//        DfpField field = new DfpField(10);
//        Dfp x = new Dfp(field, "2.0");
//        Dfp y = field.newDfp(DfpField.QNAN); // Corrected instantiation for NaN
//        Dfp result = DfpMath.pow(x, y);
//        assertTrue(result.isNaN(), "Result should be NaN.");
//        assertEquals(DfpField.FLAG_INVALID, x.getField().getIEEEFlagsBits(), "FLAG_INVALID should be set.");
//    }

}