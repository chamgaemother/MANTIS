package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class XYBoxAndWhiskerRenderer_drawHorizontalItem_0_5_Test {

    @Test
    @DisplayName("dataset casts successfully to BoxAndWhiskerXYDataset with all required values")
    void TC21_drawHorizontalItem_withValidBoxAndWhiskerXYDataset() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        BoxAndWhiskerXYDataset boxAndWhiskerDataset = mock(BoxAndWhiskerXYDataset.class);
        when(boxAndWhiskerDataset.getX(series, item)).thenReturn(10);
        when(boxAndWhiskerDataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(boxAndWhiskerDataset.getMinRegularValue(series, item)).thenReturn(5);
        when(boxAndWhiskerDataset.getMedianValue(series, item)).thenReturn(12);
        when(boxAndWhiskerDataset.getMeanValue(series, item)).thenReturn(11);
        when(boxAndWhiskerDataset.getQ1Value(series, item)).thenReturn(9);
        when(boxAndWhiskerDataset.getQ3Value(series, item)).thenReturn(15);
        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        when((BoxAndWhiskerXYDataset) dataset).thenReturn(boxAndWhiskerDataset);

        Paint itemPaint = mock(Paint.class);
        when(renderer.getItemPaint(series, item)).thenReturn(itemPaint);

        Stroke itemStroke = mock(Stroke.class);
        when(renderer.getItemStroke(series, item)).thenReturn(itemStroke);

        // Act
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);

        // Assert
        verify(g2).setPaint(itemPaint);
        verify(g2).setStroke(itemStroke);
        // Additional verifications can be added here to ensure all drawing methods are called correctly
    }

    @Test
    @DisplayName("dataset is not an instance of BoxAndWhiskerXYDataset leading to ClassCastException")
    void TC22_drawHorizontalItem_withInvalidDatasetType() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class); // Not a BoxAndWhiskerXYDataset
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(false);

        // Act & Assert
        assertThrows(ClassCastException.class, () -> {
            renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
        });
    }

    @Test
    @DisplayName("rangeAxis conversion fails resulting in invalid coordinates")
    void TC23_drawHorizontalItem_withInvalidRangeAxisConversion() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        XYDataset datasetProxy = dataset;
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;

        when(dataset.getX(series, item)).thenReturn(10);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(dataset.getMinRegularValue(series, item)).thenReturn(5);
        when(dataset.getMedianValue(series, item)).thenReturn(12);
        when(dataset.getMeanValue(series, item)).thenReturn(11);
        when(dataset.getQ1Value(series, item)).thenReturn(9);
        when(dataset.getQ3Value(series, item)).thenReturn(15);

        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(Double.NaN);

        Paint itemPaint = mock(Paint.class);
        when(renderer.getItemPaint(series, item)).thenReturn(itemPaint);

        Stroke itemStroke = mock(Stroke.class);
        when(renderer.getItemStroke(series, item)).thenReturn(itemStroke);

        // Act
        Executable executable = () -> renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, datasetProxy, series, item, crosshairState, rendererIndex);

        // Assert
        // Assuming that the method handles NaN gracefully without throwing an exception
        assertDoesNotThrow(executable);
        // Additional verifications can be added here to ensure the method handled NaN as expected
    }
}