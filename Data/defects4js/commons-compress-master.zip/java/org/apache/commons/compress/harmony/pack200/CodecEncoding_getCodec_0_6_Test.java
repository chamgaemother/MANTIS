package org.apache.commons.compress.harmony.pack200;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CodecEncoding_getCodec_0_6_Test {

    @Test
    @DisplayName("Throws EOFException when value is exactly 116 and InputStream has insufficient data")
    public void TC26() throws Exception {
        // Arrange
        int value = 116;
        byte[] inputData = { 0x01 }; // Insufficient data
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = new BHSDCodec(1, 256); // Provide a concrete implementation

        // Act & Assert
        EOFException exception = assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(value, inputStream, defaultCodec);
        });
        assertEquals("End of buffer read whilst trying to decode codec", exception.getMessage());
    }

    @Test
    @DisplayName("Throws EOFException when reading uCodec in PopulationCodec with tdef=true")
    public void TC27() throws Exception {
        // Arrange
        int value = 160; // Value leading to tdef=true
        byte[] inputData = { 0x00, 0x00 }; // Insufficient data for uCodec
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = new BHSDCodec(1, 256);

        // Act & Assert
        EOFException exception = assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(value, inputStream, defaultCodec);
        });
        assertEquals("End of buffer read whilst trying to decode codec", exception.getMessage());
    }

    @Test
    @DisplayName("Handles minimum valid value for RunCodec (117)")
    public void TC28() throws Exception {
        // Arrange
        int value = 117;
        byte[] inputData = { 0x02, 0x03, 0x04, 0x05, 0x06, 0x07 }; // Sufficient data
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = new BHSDCodec(1, 256);

        // Act
        Codec result = CodecEncoding.getCodec(value, inputStream, defaultCodec);

        // Assert
        assertTrue(result instanceof RunCodec);
        RunCodec runCodec = (RunCodec) result;
        assertEquals((3 + 1) * (int) Math.pow(16, 2), runCodec.getK());
        assertEquals(defaultCodec, runCodec.getACodec());
        assertEquals(defaultCodec, runCodec.getBCodec());
    }

    @Test
    @DisplayName("Handles maximum valid value for RunCodec (140)")
    public void TC29() throws Exception {
        // Arrange
        int value = 140;
        byte[] inputData = { 0x02, 0x03, 0x04, 0x05, 0x06, 0x07 }; // Sufficient data
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = new BHSDCodec(1, 256);

        // Act
        Codec result = CodecEncoding.getCodec(value, inputStream, defaultCodec);

        // Assert
        assertTrue(result instanceof RunCodec);
        RunCodec runCodec = (RunCodec) result;
        assertEquals((3 + 1) * (int) Math.pow(16, 2), runCodec.getK());
        assertEquals(defaultCodec, runCodec.getACodec());
        assertEquals(defaultCodec, runCodec.getBCodec());
    }

    @Test
    @DisplayName("Returns PopulationCodec with tdef=false and all defaults")
    public void TC30() throws Exception {
        // Arrange
        int value = 170;
        byte[] inputData = { 0x01, 0x02, 0x03, 0x04 }; // Sufficient data
        InputStream inputStream = new ByteArrayInputStream(inputData);
        Codec defaultCodec = new BHSDCodec(1, 256);

        // Act
        Codec result = CodecEncoding.getCodec(value, inputStream, defaultCodec);

        // Assert
        assertTrue(result instanceof PopulationCodec);
        PopulationCodec populationCodec = (PopulationCodec) result;
        assertEquals(defaultCodec, populationCodec.getFavouredCodec());
        assertEquals(defaultCodec, populationCodec.getTokenCodec());
        assertEquals(defaultCodec, populationCodec.getUnfavouredCodec());
    }
}