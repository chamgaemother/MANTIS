import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

public class NumberInputTest {

    @Test
    public void testParseInt_NullInput() {
        char[] ch = null;
        assertThrows(NullPointerException.class, () -> NumberInput.parseInt(ch, 0, 1));
    }

    @Test
    public void testParseInt_ZeroLength() {
        char[] ch = {'1'};
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> NumberInput.parseInt(ch, 0, 0));
    }

    @Test
    public void testParseInt_SingleDigit_NoPlus() {
        char[] ch = {'5'};
        int result = NumberInput.parseInt(ch, 0, 1);
        assertEquals(5, result);
    }

    @Test
    public void testParseInt_SingleDigit_WithPlus() {
        char[] ch = {'+', '7'};
        int result = NumberInput.parseInt(ch, 0, 2);
        assertEquals(7, result);
    }

    @Test
    public void testParseInt_SinglePlus() {
        char[] ch = {'+'};
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> NumberInput.parseInt(ch, 0, 1));
    }

    @ParameterizedTest
    @CsvSource({
        "123, 0, 3, 123",
        "+123, 0, 4, 123",
        "012345678, 0, 9, 12345678",
        "+012345678, 0, 10, 12345678",
        "987654321, 0, 9, 987654321",
        "+987654321, 0, 10, 987654321"
    })
    public void testParseInt_ValidInputs(String input, int off, int len, int expected) {
        char[] ch = input.toCharArray();
        int result = NumberInput.parseInt(ch, off, len);
        assertEquals(expected, result);
    }

    @ParameterizedTest
    @CsvSource({
        "1a3, 0, 3, 1a3",
        "+12b3, 0, 5, 12b3",
        "++123, 0, 5, ++123",
        "+-123, 0, 5, +-123",
        "12+3, 0, 4, 12+3",
        "1 23, 0, 4, 1 23"
    })
    public void testParseInt_InvalidDigits(String input, int off, int len, String original) {
        char[] ch = input.toCharArray();
        int result = NumberInput.parseInt(ch, off, len);
        // The method does not validate digits, it just computes based on char values
        // So we can compute expected manually or just ensure it runs
        // Here, we'll compute expected manually
        int expected = 0;
        for(int i = off; i < off + len; i++) {
            expected = expected * 10 + (ch[i] - '0');
        }
        assertEquals(expected, result);
    }

    @Test
    public void testParseInt_LengthGreaterThanNine() {
        char[] ch = "1234567890".toCharArray();
        // According to method, it will process as len=10, no switch case, num = '0' - '0' = 0
        int result = NumberInput.parseInt(ch, 0, 10);
        assertEquals(0, result);
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "0", "9"
    })
    public void testParseInt_BoundaryDigits(String digit) {
        char[] ch = digit.toCharArray();
        int result = NumberInput.parseInt(ch, 0, 1);
        assertEquals(Character.getNumericValue(digit.charAt(0)), result);
    }

    @Test
    public void testParseInt_MaxLength() {
        char[] ch = {'9','9','9','9','9','9','9','9','9'};
        int result = NumberInput.parseInt(ch, 0, 9);
        assertEquals(999999999, result);
    }

    @Test
    public void testParseInt_MinLengthPlus() {
        char[] ch = {'+','1'};
        int result = NumberInput.parseInt(ch, 0, 2);
        assertEquals(1, result);
    }

    @Test
    public void testParseInt_MinLengthWithoutPlus() {
        char[] ch = {'1'};
        int result = NumberInput.parseInt(ch, 0, 1);
        assertEquals(1, result);
    }

    @Test
    public void testParseInt_AllNinesWithPlus() {
        char[] ch = {'+','9','9','9','9','9','9','9','9','9'};
        int result = NumberInput.parseInt(ch, 0, 10);
        // len-1=9, ch[9]-'0' = 9
        // switch(len-1)=10, no case
        // num = 9
        assertEquals(9, result);
    }

    @Test
    public void testParseInt_AllNinesWithoutPlus() {
        char[] ch = {'9','9','9','9','9','9','9','9','9'};
        int result = NumberInput.parseInt(ch, 0, 9);
        assertEquals(999999999, result);
    }

    @Test
    public void testParseInt_WithOffset() {
        char[] ch = {'a', '+', '1', '2', '3'};
        int result = NumberInput.parseInt(ch, 1, 4);
        assertEquals(123, result);
    }

    @Test
    public void testParseInt_WithOffsetPlus() {
        char[] ch = {'a', '+', '1'};
        int result = NumberInput.parseInt(ch, 1, 2);
        assertEquals(1, result);
    }

    @Test
    public void testParseInt_InvalidOffset() {
        char[] ch = {'1','2','3'};
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> NumberInput.parseInt(ch, 2, 2));
    }

    @Test
    public void testParseInt_NegativeDigits() {
        char[] ch = {'-', '1', '2'};
        int result = NumberInput.parseInt(ch, 0, 3);
        // ch[0] is '-', not '+', so len=3
        // num = ch[2]-'0' = 2
        // switch len=3:
        // case 3: num += (ch[0]-'0') * 100 = (-3) * 100 = -300 + 2 = -298
        assertEquals((-3) * 100 + 2, result);
    }
}