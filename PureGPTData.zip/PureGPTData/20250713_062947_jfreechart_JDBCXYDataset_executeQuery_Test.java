import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.jfree.data.jdbc.JDBCXYDataset;
import org.junit.jupiter.api.*;
import java.sql.*;
import java.util.Date;
import java.util.ArrayList;

public class JDBCXYDatasetTest {

    @Test
    public void testExecuteQueryWithNullConnection() {
        JDBCXYDataset dataset = new JDBCXYDataset();
        Exception exception = assertThrows(SQLException.class, () -> {
            dataset.executeQuery(null, "SELECT * FROM test");
        });
        assertEquals("There is no database to execute the query.", exception.getMessage());
    }

    @Test
    public void testExecuteQueryWithNotEnoughColumns() throws Exception {
        Connection mockConnection = mock(Connection.class);
        Statement mockStatement = mock(Statement.class);
        ResultSet mockResultSet = mock(ResultSet.class);
        ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);

        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(1);
        when(mockMetaData.getColumnType(1)).thenReturn(Types.INTEGER);

        JDBCXYDataset dataset = new JDBCXYDataset(mockConnection);

        assertThrows(SQLException.class, () -> {
            dataset.executeQuery(mockConnection, "SELECT * FROM test");
        });

        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    public void testExecuteQueryWithValidColumns() throws Exception {
        Connection mockConnection = mock(Connection.class);
        Statement mockStatement = mock(Statement.class);
        ResultSet mockResultSet = mock(ResultSet.class);
        ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);

        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(3);
        when(mockMetaData.getColumnType(1)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(2)).thenReturn(Types.DOUBLE);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.TIMESTAMP);
        when(mockMetaData.getColumnLabel(2)).thenReturn("Column2");
        when(mockMetaData.getColumnLabel(3)).thenReturn("Column3");
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getObject(1)).thenReturn(1);
        when(mockResultSet.getObject(2)).thenReturn(10.5);
        when(mockResultSet.getObject(3)).thenReturn(new Date());

        JDBCXYDataset dataset = new JDBCXYDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM test");

        assertEquals(1, dataset.getSeriesCount());
        assertEquals("Column2", dataset.getSeriesKey(0));
        assertEquals(1, dataset.getItemCount(0));

        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    public void testExecuteQueryWithUnknownDataType() throws Exception {
        Connection mockConnection = mock(Connection.class);
        Statement mockStatement = mock(Statement.class);
        ResultSet mockResultSet = mock(ResultSet.class);
        ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);

        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockMetaData.getColumnType(1)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(2)).thenReturn(Types.VARCHAR); // Unknown for numeric data
        when(mockMetaData.getColumnLabel(2)).thenReturn("Column2");
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getObject(1)).thenReturn(1);
        when(mockResultSet.getObject(2)).thenReturn("test");

        JDBCXYDataset dataset = new JDBCXYDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM test");

        assertEquals(0, dataset.getSeriesCount());

        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    public void testExecuteQueryWithNoRows() throws Exception {
        Connection mockConnection = mock(Connection.class);
        Statement mockStatement = mock(Statement.class);
        ResultSet mockResultSet = mock(ResultSet.class);
        ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);

        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockMetaData.getColumnType(1)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(2)).thenReturn(Types.DOUBLE);
        when(mockMetaData.getColumnLabel(2)).thenReturn("Column2");
        when(mockResultSet.next()).thenReturn(false);

        JDBCXYDataset dataset = new JDBCXYDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM test");

        assertEquals(1, dataset.getSeriesCount());
        assertEquals(1, dataset.getItemCount(0));

        verify(mockResultSet).close();
        verify(mockStatement).close();
    }
}