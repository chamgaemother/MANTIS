package org.apache.commons.jxpath.ri.parser;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Vector;

public class XPathParser_generateParseException_0_2_Test {

    @Test
    @DisplayName("la1tokens has multiple true entries leading to multiple jj_expentries")
    public void TC06_generateParseException_multipleTokens() throws Exception {
        // Initialize XPathParser instance
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and modify 'jj_expentries' field
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<?> jjExpentries = (Vector<?>) jjExpentriesField.get(parser);
        jjExpentries.removeAllElements();

        // Access and set 'jj_kind' field to -1
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, -1);

        // Access and set 'jj_la1' related fields to trigger multiple tokens
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jjLa1 = new int[39];
        // Assuming jj_gen is 1 for the test
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjLa1[0] = jjGenField.getInt(parser);
        jjLa1Field.set(parser, jjLa1);

        // Access and set 'jj_la1_0', 'jj_la1_1', 'jj_la1_2' fields
        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        jjLa1_0Field.set(parser, new int[]{1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        jjLa1_1Field.set(parser, new int[]{2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        jjLa1_2Field.set(parser, new int[]{4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        // Invoke generateParseException
        ParseException exception = parser.generateParseException();

        // Access 'exptokseq' from ParseException
        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(exception);

        // Assertions
        assertNotNull(exptokseq, "exptokseq should not be null");
        assertTrue(exptokseq.length > 1, "exptokseq should contain multiple entries");
    }

    @Test
    @DisplayName("jj_expentries initially contains existing entries before adding new ones")
    public void TC07_generateParseException_existingEntries() throws Exception {
        // Initialize XPathParser instance
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and modify 'jj_expentries' field with pre-existing entries
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<Object> jjExpentries = (Vector<Object>) jjExpentriesField.get(parser);
        jjExpentries.addElement(new int[]{5});
        jjExpentries.addElement(new int[]{10});

        // Set 'jj_kind' to trigger adding new tokens
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, -1);

        // Access and set 'jj_la1' related fields to add new unique tokens
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jjLa1 = new int[39];
        // Assuming jj_gen is 2 for the test
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjLa1[1] = jjGenField.getInt(parser);
        jjLa1Field.set(parser, jjLa1);

        // Access and set 'jj_la1_0', 'jj_la1_1', 'jj_la1_2' fields for new tokens
        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        jjLa1_0Field.set(parser, new int[]{0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        jjLa1_1Field.set(parser, new int[]{0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        jjLa1_2Field.set(parser, new int[]{0, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        // Invoke generateParseException
        ParseException exception = parser.generateParseException();

        // Access 'exptokseq' from ParseException
        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(exception);

        // Assertions
        assertNotNull(exptokseq, "exptokseq should not be null");
        assertEquals(4, exptokseq.length, "exptokseq should contain existing and new unique entries");
    }

    @Test
    @DisplayName("jj_rescan_token and jj_add_error_token are called during exception generation")
    public void TC08_generateParseException_methodCalls() throws Exception {
        // Initialize XPathParser instance
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Set parser state to require rescanning
        Field jjRescanField = XPathParser.class.getDeclaredField("jj_rescan");
        jjRescanField.setAccessible(true);
        jjRescanField.setBoolean(parser, true);

        // Access and set 'jj_kind' to trigger error token addition
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, 0);

        // Invoke generateParseException
        ParseException exception = parser.generateParseException();

        // Verify that 'jj_rescan_token' was called
        Method jjRescanTokenMethod = XPathParser.class.getDeclaredMethod("jj_rescan_token");
        jjRescanTokenMethod.setAccessible(true);
        boolean rescanCalled = (boolean) jjRescanTokenMethod.invoke(parser);
        assertFalse(rescanCalled, "jj_rescan_token should have been invoked and reset");

        // Verify that 'jj_add_error_token' was called with parameters (0,0)
        Method jjAddErrorTokenMethod = XPathParser.class.getDeclaredMethod("jj_add_error_token", int.class, int.class);
        jjAddErrorTokenMethod.setAccessible(true);
        jjAddErrorTokenMethod.invoke(parser, 0, 0);

        // Access 'jj_expentries' to ensure error token was added
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<?> jjExpentries = (Vector<?>) jjExpentriesField.get(parser);
        assertFalse(jjExpentries.isEmpty(), "jj_expentries should have error tokens added");
    }

    @Test
    @DisplayName("la1tokens has no true entries, resulting in empty jj_expentries")
    public void TC09_generateParseException_noTokens() throws Exception {
        // Initialize XPathParser instance
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Ensure 'jj_kind' is less than 0
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, -1);

        // Access and modify 'jj_expentries' field
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<?> jjExpentries = (Vector<?>) jjExpentriesField.get(parser);
        jjExpentries.removeAllElements();

        // Access and set 'la1tokens' to all false
        Field la1tokensField = XPathParser.class.getDeclaredField("la1tokens");
        la1tokensField.setAccessible(true);
        boolean[] la1tokens = new boolean[90];
        la1tokensField.set(parser, la1tokens);

        // Access and set 'jj_la1' related fields to not set any tokens
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jjLa1 = new int[39];
        // Assuming jj_gen is 3 for the test
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjLa1[2] = jjGenField.getInt(parser);
        jjLa1Field.set(parser, jjLa1);

        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        jjLa1_0Field.set(parser, new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        jjLa1_1Field.set(parser, new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        jjLa1_2Field.set(parser, new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        // Invoke generateParseException
        ParseException exception = parser.generateParseException();

        // Access 'exptokseq' from ParseException
        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(exception);

        // Assertions
        assertNotNull(exptokseq, "exptokseq should not be null");
        assertEquals(0, exptokseq.length, "exptokseq should be empty when no tokens are set");
    }

    @Test
    @DisplayName("jj_la1_2[i] has all bits unset, ensuring no tokens set from jj_la1_2")
    public void TC10_generateParseException_la1_2Unset() throws Exception {
        // Initialize XPathParser instance
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and set 'jj_kind' to trigger token setting
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, 1);

        // Access and set 'jj_la1' related fields
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jjLa1 = new int[39];
        // Assuming jj_gen is 4 for the test
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjLa1[3] = jjGenField.getInt(parser);
        jjLa1Field.set(parser, jjLa1);

        // Set 'jj_la1_0' and 'jj_la1_1' with some tokens
        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        jjLa1_0Field.set(parser, new int[]{1 << 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        jjLa1_1Field.set(parser, new int[]{1 << 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        // Set 'jj_la1_2' with all bits unset
        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        jjLa1_2Field.set(parser, new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0});

        // Invoke generateParseException
        ParseException exception = parser.generateParseException();

        // Access 'exptokseq' from ParseException
        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(exception);

        // Assertions
        assertNotNull(exptokseq, "exptokseq should not be null");
        // Calculate expected number of tokens from jj_la1_0 and jj_la1_1 only
        int expectedTokens = 2; // Tokens from jj_la1_0[0] and jj_la1_1[0]
        assertEquals(expectedTokens, exptokseq.length, "exptokseq should contain tokens only from jj_la1_0 and jj_la1_1");
    }
}