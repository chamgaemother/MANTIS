import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.renderer.category.StackedAreaRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DefaultKeyedValues2DDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class StackedAreaRendererTest {

    private StackedAreaRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;

    @BeforeEach
    public void setUp() {
        renderer = new StackedAreaRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = new DefaultKeyedValues2DDataset();
        ((DefaultKeyedValues2DDataset) dataset).addValue(1.0, "Row 1", "Col 1");
        ((DefaultKeyedValues2DDataset) dataset).addValue(2.0, "Row 1", "Col 2");
        ((DefaultKeyedValues2DDataset) dataset).addValue(3.0, "Row 2", "Col 1");
        ((DefaultKeyedValues2DDataset) dataset).addValue(-1.0, "Row 2", "Col 2");
        ((DefaultKeyedValues2DDataset) dataset).addValue(5.0, "Row 3", "Col 1");
        ((DefaultKeyedValues2DDataset) dataset).addValue(1.0, "Row 3", "Col 2");

        when(state.getEntityCollection()).thenReturn(mock(EntityCollection.class));
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any())).thenReturn(50.0);
    }

    @Test
    public void testDrawItemWithNullDataset() {
        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, 0, 0, 0));
    }

    @Test
    public void testDrawItemWithNoSeriesVisible() {
        // Assuming all series visibility can be controlled, we simulate none visible
        StackedAreaRenderer noVisibleRenderer = spy(new StackedAreaRenderer());
        doReturn(false).when(noVisibleRenderer).isSeriesVisible(anyInt());

        assertDoesNotThrow(() -> noVisibleRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0));
        verify(g2, never()).fill(any());
    }

    @Test
    public void testDrawItemWithValidInputsPassZero() {
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    public void testDrawItemWithValidInputsPassOne() {
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        // Label drawing would involve other methods, ensure it's called
        verify(g2, atLeastOnce()).getPaint();
    }

    @ParameterizedTest
    @CsvSource({
        "0, 0, 0", // First series, first column
        "0, 0, 1", // First series, first column, pass 1
        "1, 1, 0", // Second series, first column
        "1, 1, 1", // Second series, first column, pass 1
        "2, 0, 0", // Third series, second column
        "2, 0, 1"  // Third series, second column, pass 1
    })
    public void testDrawItemVariousScenarios(int row, int column, int pass) {
        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass));
    }

    @Test
    public void testDrawItemRenderAsPercentages() {
        renderer.setRenderAsPercentages(true);
        when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(), any())).thenReturn(10.0);
        when(domainAxis.getCategoryEnd(anyInt(), anyInt(), any(), any())).thenReturn(90.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2, atLeastOnce()).fill(any());
    }

    @Test
    public void testDrawItemNegativeValues() {
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        verify(g2, atLeastOnce()).fill(any());
    }
}