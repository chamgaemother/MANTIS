package org.apache.commons.compress.archivers.sevenz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.nio.file.attribute.FileTime;

import static org.junit.jupiter.api.Assertions.*;

public class SevenZArchiveEntry_equals_1_3_Test {

    @Test
    @DisplayName("equals(obj) returns false when hasAccessDate fields differ")
    void TC11_equals_different_hasAccessDate_returns_false() throws Exception {
        // Arrange
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Use reflection to set hasAccessDate field
        Field hasAccessDateField = SevenZArchiveEntry.class.getDeclaredField("hasAccessDate");
        hasAccessDateField.setAccessible(true);
        hasAccessDateField.set(entry1, true);
        hasAccessDateField.set(entry2, false);

        // Act
        boolean result = entry1.equals(entry2);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when creationDate fields differ")
    void TC12_equals_different_creationDate_returns_false() throws Exception {
        // Arrange
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Use reflection to set creationTime field
        Field creationTimeField = SevenZArchiveEntry.class.getDeclaredField("creationDate");
        creationTimeField.setAccessible(true);
        creationTimeField.set(entry1, FileTime.fromMillis(1000));
        creationTimeField.set(entry2, FileTime.fromMillis(2000));

        // Use reflection to set hasCreationDate field
        Field hasCreationDateField = SevenZArchiveEntry.class.getDeclaredField("hasCreationDate");
        hasCreationDateField.setAccessible(true);
        hasCreationDateField.set(entry1, true);
        hasCreationDateField.set(entry2, true);

        // Act
        boolean result = entry1.equals(entry2);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when lastModifiedDate fields differ")
    void TC13_equals_different_lastModifiedDate_returns_false() throws Exception {
        // Arrange
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Use reflection to set lastModifiedTime field
        Field lastModifiedTimeField = SevenZArchiveEntry.class.getDeclaredField("lastModifiedDate");
        lastModifiedTimeField.setAccessible(true);
        lastModifiedTimeField.set(entry1, FileTime.fromMillis(3000));
        lastModifiedTimeField.set(entry2, FileTime.fromMillis(4000));

        // Use reflection to set hasLastModifiedDate field
        Field hasLastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate");
        hasLastModifiedDateField.setAccessible(true);
        hasLastModifiedDateField.set(entry1, true);
        hasLastModifiedDateField.set(entry2, true);

        // Act
        boolean result = entry1.equals(entry2);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when accessDate fields differ")
    void TC14_equals_different_accessDate_returns_false() throws Exception {
        // Arrange
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Use reflection to set accessTime field
        Field accessTimeField = SevenZArchiveEntry.class.getDeclaredField("accessDate");
        accessTimeField.setAccessible(true);
        accessTimeField.set(entry1, FileTime.fromMillis(5000));
        accessTimeField.set(entry2, FileTime.fromMillis(6000));

        // Use reflection to set hasAccessDate field
        Field hasAccessDateField = SevenZArchiveEntry.class.getDeclaredField("hasAccessDate");
        hasAccessDateField.setAccessible(true);
        hasAccessDateField.set(entry1, true);
        hasAccessDateField.set(entry2, true);

        // Act
        boolean result = entry1.equals(entry2);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when hasWindowsAttributes fields differ")
    void TC15_equals_different_hasWindowsAttributes_returns_false() throws Exception {
        // Arrange
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Use reflection to set hasWindowsAttributes field
        Field hasWindowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("hasWindowsAttributes");
        hasWindowsAttributesField.setAccessible(true);
        hasWindowsAttributesField.set(entry1, true);
        hasWindowsAttributesField.set(entry2, false);

        // Act
        boolean result = entry1.equals(entry2);

        // Assert
        assertFalse(result);
    }
}