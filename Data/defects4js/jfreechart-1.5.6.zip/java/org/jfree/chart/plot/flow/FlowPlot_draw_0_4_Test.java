package org.jfree.chart.plot.flow;

import org.jfree.chart.text.TextUtils;
import java.lang.reflect.*;
import org.jfree.chart.ui.TextAnchor;
import org.jfree.data.flow.FlowKey;
import org.jfree.data.flow.NodeKey;
import org.jfree.data.flow.FlowDataset;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.ui.VerticalAlignment;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.List;

public class FlowPlot_draw_0_4_Test {

    @Test
    @DisplayName("Verifies draw method handles nodes with selected and unselected states")
    public void TC16_draw_handlesSelectedAndUnselectedNodes() throws Exception {
        // GIVEN
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = Mockito.mock(PlotState.class);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);

        // Instantiate FlowPlot
        FlowPlot flowPlot = new FlowPlot(null);

        // Use reflection to set the dataset field
        Field datasetField = FlowPlot.class.getDeclaredField("dataset");
        datasetField.setAccessible(true);
        FlowDataset dataset = Mockito.mock(FlowDataset.class);
        datasetField.set(flowPlot, dataset);

        // Mock dataset behavior
        Mockito.when(dataset.getStageCount()).thenReturn(1);
        List<Comparable> sources = Arrays.asList("Source1", "Source2");
        Mockito.when(dataset.getSources(0)).thenReturn(sources);

        // Mark nodes as selected/unselected
        Mockito.when(dataset.getNodeProperty(new NodeKey<>(0, "Source1"), NodeKey.SELECTED_PROPERTY_KEY)).thenReturn(Boolean.TRUE);
        Mockito.when(dataset.getNodeProperty(new NodeKey<>(0, "Source2"), NodeKey.SELECTED_PROPERTY_KEY)).thenReturn(Boolean.FALSE);

        // Mock lookupNodeColor method
        Mockito.doReturn(Color.RED).when(flowPlot).lookupNodeColor(new NodeKey<>(0, "Source1"));
        Mockito.doReturn(Color.GRAY).when(flowPlot).lookupNodeColor(new NodeKey<>(0, "Source2"));

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        // Capture the colors used in g2.setPaint
        ArgumentCaptor<Color> colorCaptor = ArgumentCaptor.forClass(Color.class);
        Mockito.verify(g2, Mockito.atLeast(2)).setPaint(colorCaptor.capture());

        List<Color> capturedColors = colorCaptor.getAllValues();

        // Verify that selected nodes are rendered with their specific colors
        assertTrue(capturedColors.contains(Color.RED), "Selected node color not applied correctly.");

        // Verify that unselected nodes are rendered in grayscale
        assertTrue(capturedColors.contains(Color.GRAY), "Unselected node color not applied correctly.");
    }

    @Test
    @DisplayName("Verifies draw method handles flows with selected and unselected states")
    public void TC17_draw_handlesSelectedAndUnselectedFlows() throws Exception {
        // GIVEN
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = Mockito.mock(PlotState.class);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);

        // Instantiate FlowPlot
        FlowPlot flowPlot = new FlowPlot(null);

        // Use reflection to set the dataset field
        Field datasetField = FlowPlot.class.getDeclaredField("dataset");
        datasetField.setAccessible(true);
        FlowDataset dataset = Mockito.mock(FlowDataset.class);
        datasetField.set(flowPlot, dataset);

        // Mock dataset behavior
        Mockito.when(dataset.getStageCount()).thenReturn(1);
        List<Comparable> sources = Arrays.asList("Source1");
        List<Comparable> destinations = Arrays.asList("Destination1");
        Mockito.when(dataset.getSources(0)).thenReturn(sources);
        Mockito.when(dataset.getDestinations(0)).thenReturn(destinations);
        Mockito.when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(100);

        // Mark flows as selected/unselected
        FlowKey flowKey = new FlowKey<>(0, "Source1", "Destination1");
        Mockito.when(dataset.getFlowProperty(flowKey, FlowKey.SELECTED_PROPERTY_KEY)).thenReturn(Boolean.TRUE);

        // Mock lookupNodeColor method
        Mockito.doReturn(Color.BLUE).when(flowPlot).lookupNodeColor(new NodeKey<>(0, "Source1"));
        Mockito.doReturn(new Color(255, 0, 0, 128)).when(flowPlot).lookupNodeColor(new NodeKey<>(0, "Destination1"));

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        // Capture the colors used in g2.setPaint
        ArgumentCaptor<Color> colorCaptor = ArgumentCaptor.forClass(Color.class);
        Mockito.verify(g2, Mockito.atLeast(2)).setPaint(colorCaptor.capture());

        List<Color> capturedColors = colorCaptor.getAllValues();

        // Verify that selected flows are rendered with GradientPaint
        assertTrue(capturedColors.contains(Color.BLUE), "Selected flow color not applied correctly.");
        assertTrue(capturedColors.contains(new Color(255, 0, 0, 128)), "Unselected flow opacity not applied correctly.");
    }

//     @Test
//     @DisplayName("Verifies draw method handles nodes with overlapping flows correctly")
//     public void TC18_draw_overlappingFlows_renderedCorrectly() throws Exception {
        // GIVEN
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
//         Point2D point = new Point2D.Double(400, 300);
//         PlotState state = Mockito.mock(PlotState.class);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
// 
        // Instantiate FlowPlot
//         FlowPlot flowPlot = new FlowPlot(null);
// 
        // Use reflection to set the dataset field
//         Field datasetField = FlowPlot.class.getDeclaredField("dataset");
//         datasetField.setAccessible(true);
//         FlowDataset dataset = Mockito.mock(FlowDataset.class);
//         datasetField.set(flowPlot, dataset);
// 
        // Mock dataset behavior with overlapping flows
//         Mockito.when(dataset.getStageCount()).thenReturn(2);
//         List<Comparable> sourcesStage0 = Arrays.asList("Source1");
//         List<Comparable> destinationsStage0 = Arrays.asList("Destination1", "Destination2");
//         Mockito.when(dataset.getSources(0)).thenReturn(sourcesStage0);
//         Mockito.when(dataset.getDestinations(0)).thenReturn(destinationsStage0);
//         Mockito.when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(50);
//         Mockito.when(dataset.getFlow(0, "Source1", "Destination2")).thenReturn(50);
// 
        // WHEN
//         flowPlot.draw(g2, area, point, state, info);
// 
        // THEN
        // Verify that flows are rendered without visual artifacts
//         Mockito.verify(g2, Mockito.times(2)).fill(Mockito.any(Path2D.class));
//     }

//     @Test
//     @DisplayName("Verifies draw method correctly handles negative flow values by ignoring them")
//     public void TC19_draw_negativeFlowValues_ignored() throws Exception {
        // GIVEN
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
//         Point2D point = new Point2D.Double(400, 300);
//         PlotState state = Mockito.mock(PlotState.class);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
// 
        // Instantiate FlowPlot
//         FlowPlot flowPlot = new FlowPlot(null);
// 
        // Use reflection to set the dataset field
//         Field datasetField = FlowPlot.class.getDeclaredField("dataset");
//         datasetField.setAccessible(true);
//         FlowDataset dataset = Mockito.mock(FlowDataset.class);
//         datasetField.set(flowPlot, dataset);
// 
        // Mock dataset behavior with negative flows
//         Mockito.when(dataset.getStageCount()).thenReturn(1);
//         List<Comparable> sources = Arrays.asList("Source1");
//         List<Comparable> destinations = Arrays.asList("Destination1");
//         Mockito.when(dataset.getSources(0)).thenReturn(sources);
//         Mockito.when(dataset.getDestinations(0)).thenReturn(destinations);
//         Mockito.when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(-100);
// 
        // WHEN
//         flowPlot.draw(g2, area, point, state, info);
// 
        // THEN
        // Verify that negative flows are not rendered
//         Mockito.verify(g2, Mockito.never()).fill(Mockito.any(Path2D.class));
//     }

//     @Test
//     @DisplayName("Verifies draw method correctly renders labels aligned to the left for source nodes")
//     public void TC20_draw_labelsAlignedLeftForSourceNodes() throws Exception {
        // GIVEN
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
//         Point2D point = new Point2D.Double(400, 300);
//         PlotState state = Mockito.mock(PlotState.class);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
// 
        // Instantiate FlowPlot
//         FlowPlot flowPlot = new FlowPlot(null);
// 
        // Use reflection to set the dataset and label alignment fields
//         Field datasetField = FlowPlot.class.getDeclaredField("dataset");
//         datasetField.setAccessible(true);
//         FlowDataset dataset = Mockito.mock(FlowDataset.class);
//         datasetField.set(flowPlot, dataset);
// 
        // Mock dataset behavior
//         Mockito.when(dataset.getStageCount()).thenReturn(1);
//         List<Comparable> sources = Arrays.asList("Source1");
//         Mockito.when(dataset.getSources(0)).thenReturn(sources);
// 
        // WHEN
//         flowPlot.draw(g2, area, point, state, info);
// 
        // THEN
        // Capture the text drawn
//         ArgumentCaptor<String> textCaptor = ArgumentCaptor.forClass(String.class);
//         ArgumentCaptor<Float> xCaptor = ArgumentCaptor.forClass(Float.class);
//         ArgumentCaptor<Float> yCaptor = ArgumentCaptor.forClass(Float.class);
//         ArgumentCaptor<TextAnchor> anchorCaptor = ArgumentCaptor.forClass(TextAnchor.class);
// 
//         Mockito.verify(TextUtils.class, Mockito.times(1)).drawAlignedString(
//             textCaptor.capture(),
//             Mockito.eq(g2),
//             xCaptor.capture(),
//             yCaptor.capture(),
//             anchorCaptor.capture()
//         );
// 
        // Verify that labels are drawn aligned to CENTER
//         assertEquals(TextAnchor.CENTER_LEFT, anchorCaptor.getValue(), "Label alignment is not CENTER_LEFT.");
//     }
}