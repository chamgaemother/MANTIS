package org.apache.commons.lang3.reflect;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

public class MethodUtils_getMatchingAccessibleMethod_0_3_Test {

    @Test
    @DisplayName("Handles scenario with multiple methods where accessibleMethod is null for some iterations")
    public void TC11_handlesMultipleMethodsWithMixedAccessibility() throws Exception {
        // Arrange
        Class<?> cls = MixedAccessibilityClass.class;
        String methodName = "mixedMethod";
        Class<?>[] parameterTypes = {String.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertEquals("mixedMethod", result.getName(), "Method name should be 'mixedMethod'");
    }

    @Test
    @DisplayName("Handles scenario where getAccessibleMethod fails to find an accessible method")
    public void TC12_handlesGetAccessibleMethodFailure() throws Exception {
        // Arrange
        Class<?> cls = InaccessibleMethodsClass.class;
        String methodName = "inaccessibleMethod";
        Class<?>[] parameterTypes = {String.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNull(result, "Result should be null as no accessible methods are found");
    }

    @Test
    @DisplayName("Handles scenario with multiple iterations and selecting the method with the lowest fit value")
    public void TC13_selectsMethodWithLowestFitValue() throws Exception {
        // Arrange
        Class<?> cls = FitValueClass.class;
        String methodName = "fitMethod";
        Class<?>[] parameterTypes = {Number.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertEquals(Integer.class, result.getParameterTypes()[0], "First parameter type should be Integer.class");
    }

    @Test
    @DisplayName("Handles scenario where parameter type superclass does not match component type in varargs")
    public void TC14_varargsSuperclassMismatch() throws Exception {
        // Arrange
        Class<?> cls = VarargsSuperclassMismatchClass.class;
        String methodName = "varargsSuperclassMismatchMethod";
        Class<?>[] parameterTypes = {CustomSubclass.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNull(result, "Result should be null due to superclass mismatch");
    }

    @Test
    @DisplayName("Handles scenario where getAccessibleMethod retrieves a method from an interface")
    public void TC15_accessibleMethodFromInterface() throws Exception {
        // Arrange
        Class<?> cls = InterfaceImplementingClass.class;
        String methodName = "interfaceMethod";
        Class<?>[] parameterTypes = {String.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertTrue(result.getDeclaringClass().isInterface(), "Declaring class should be an interface");
    }

    // Helper classes for testing

    static class MixedAccessibilityClass {
        public void mixedMethod(String param) {}
        protected void mixedMethod(Integer param) {}
        private void mixedMethod(Double param) {}
    }

    static class InaccessibleMethodsClass {
        private void inaccessibleMethod(String param) {}
        protected void inaccessibleMethod(Integer param) {}
    }

    static class FitValueClass {
        public void fitMethod(Number param) {}
        public void fitMethod(Integer param) {}
        public void fitMethod(Double param) {}
    }

    static class VarargsSuperclassMismatchClass {
        public void varargsSuperclassMismatchMethod(CustomSubclass... params) {}
    }

    static class InterfaceImplementingClass implements TestInterface {
        @Override
        public void interfaceMethod(String param) {}
    }

    interface TestInterface {
        void interfaceMethod(String param);
    }

    static class CustomSubclass extends CustomSuperclass {}

    static class CustomSuperclass {}
}