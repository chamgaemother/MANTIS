package org.jfree.chart.renderer.xy;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Shape;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.AxisEdge;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.XYItemRendererState;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
public class XYShapeRenderer_drawItem_0_3_Test {
// 
//     @Test
//     @DisplayName("info is provided, pass=1, orientation is HORIZONTAL, shape intersects, drawOutlines=false, entities is not null")
//     void TC11() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = Mockito.spy(new XYShapeRenderer());
//         renderer.setDrawOutlines(false);
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         XYDataset dataset = Mockito.mock(XYDataset.class);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         Mockito.when(info.getOwner()).thenReturn(plot);
//         Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         Mockito.when(plot.indexOf(dataset)).thenReturn(0);
// 
//         Mockito.when(dataset.getXValue(0, 0)).thenReturn(10.0);
//         Mockito.when(dataset.getYValue(0, 0)).thenReturn(20.0);
// 
//         Shape shape = new Rectangle2D.Double(5, 5, 10, 10);
//         Mockito.doReturn(shape).when(renderer).getItemShape(0, 0);
// 
//         Paint itemPaint = Mockito.mock(Paint.class);
//         Mockito.doReturn(itemPaint).when(renderer).getPaint(dataset, 0, 0);
// 
//         Mockito.when(plot.getDomainAxisEdge()).thenReturn(AxisEdge.BOTTOM);
//         Mockito.when(plot.getRangeAxisEdge()).thenReturn(AxisEdge.LEFT);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         Mockito.verify(g2).fill(shape);
//         Mockito.verify(g2, Mockito.never()).draw(Mockito.any(Shape.class));
//     }
// 
//     @Test
//     @DisplayName("info is provided, pass=1, useOutlinePaint=true, entities is not null")
//     void TC12() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = Mockito.spy(new XYShapeRenderer());
//         renderer.setDrawOutlines(true);
//         renderer.setUseOutlinePaint(true);
// 
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         XYDataset dataset = Mockito.mock(XYDataset.class);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         Mockito.when(info.getOwner()).thenReturn(plot);
//         Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         Mockito.when(plot.indexOf(dataset)).thenReturn(0);
// 
//         Mockito.when(dataset.getXValue(0, 0)).thenReturn(15.0);
//         Mockito.when(dataset.getYValue(0, 0)).thenReturn(25.0);
// 
//         Shape shape = new Rectangle2D.Double(10, 10, 15, 15);
//         Mockito.doReturn(shape).when(renderer).getItemShape(0, 0);
// 
//         Paint itemPaint = Mockito.mock(Paint.class);
//         Mockito.doReturn(itemPaint).when(renderer).getPaint(dataset, 0, 0);
// 
//         Paint outlinePaint = Mockito.mock(Paint.class);
//         Mockito.doReturn(outlinePaint).when(renderer).getItemOutlinePaint(0, 0);
// 
//         Mockito.when(plot.getDomainAxisEdge()).thenReturn(AxisEdge.BOTTOM);
//         Mockito.when(plot.getRangeAxisEdge()).thenReturn(AxisEdge.LEFT);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         Mockito.verify(g2).fill(shape);
//         Mockito.verify(g2).draw(shape);
//     }
// 
//     @Test
//     @DisplayName("info is provided, pass=1, useOutlinePaint=false, entities is not null")
//     void TC13() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = Mockito.spy(new XYShapeRenderer());
//         renderer.setDrawOutlines(true);
//         renderer.setUseOutlinePaint(false);
// 
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         XYDataset dataset = Mockito.mock(XYDataset.class);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         Mockito.when(info.getOwner()).thenReturn(plot);
//         Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         Mockito.when(plot.indexOf(dataset)).thenReturn(0);
// 
//         Mockito.when(dataset.getXValue(0, 0)).thenReturn(20.0);
//         Mockito.when(dataset.getYValue(0, 0)).thenReturn(30.0);
// 
//         Shape shape = new Rectangle2D.Double(15, 15, 20, 20);
//         Mockito.doReturn(shape).when(renderer).getItemShape(0, 0);
// 
//         Paint itemPaint = Mockito.mock(Paint.class);
//         Mockito.doReturn(itemPaint).when(renderer).getPaint(dataset, 0, 0);
// 
//         Mockito.when(plot.getDomainAxisEdge()).thenReturn(AxisEdge.BOTTOM);
//         Mockito.when(plot.getRangeAxisEdge()).thenReturn(AxisEdge.LEFT);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         Mockito.verify(g2).fill(shape);
//         Mockito.verify(g2).draw(shape);
//     }
// 
//     @Test
//     @DisplayName("info is provided, pass=1, shape intersects, drawOutlines=true, entities is null")
//     void TC14() throws Exception {
        // Arrange
//         XYShapeRenderer renderer = Mockito.spy(new XYShapeRenderer());
//         renderer.setDrawOutlines(true);
// 
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         XYDataset dataset = Mockito.mock(XYDataset.class);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         Mockito.when(info.getOwner()).thenReturn(plot);
//         Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         Mockito.when(plot.indexOf(dataset)).thenReturn(0);
// 
//         Mockito.when(dataset.getXValue(0, 0)).thenReturn(25.0);
//         Mockito.when(dataset.getYValue(0, 0)).thenReturn(35.0);
// 
//         Shape shape = new Rectangle2D.Double(20, 20, 25, 25);
//         Mockito.doReturn(shape).when(renderer).getItemShape(0, 0);
// 
//         Paint itemPaint = Mockito.mock(Paint.class);
//         Mockito.doReturn(itemPaint).when(renderer).getPaint(dataset, 0, 0);
// 
//         Paint outlinePaint = Mockito.mock(Paint.class);
//         Mockito.doReturn(outlinePaint).when(renderer).getItemOutlinePaint(0, 0);
// 
//         Mockito.when(plot.getDomainAxisEdge()).thenReturn(AxisEdge.BOTTOM);
//         Mockito.when(plot.getRangeAxisEdge()).thenReturn(AxisEdge.LEFT);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // Assert
//         Mockito.verify(g2).fill(shape);
//         Mockito.verify(g2).draw(shape);
//     }
// }
}