package org.jfree.data;

import org.jfree.data.DefaultKeyedValues2D;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DefaultKeyedValues2D_removeValue_0_2_Test {

    @Test
    @DisplayName("Remove a value from an existing rowKey but with a columnKey not present in the row")
    public void TC06_removeValue_missingColumnInRow() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(70, "Row4", "Col1");
        
        // WHEN
        data.removeValue("Row4", "Col3");
        
        // THEN
        assertNull(data.getValue("Row4", "Col3"), "Value at 'Row4', 'Col3' should be null");
        assertEquals(1, data.getRowCount(), "Row count should be 1");
        assertEquals(1, data.getColumnCount(), "Column count should be 1");
    }

    @Test
    @DisplayName("Remove a value from the first row and first column")
    public void TC07_removeValue_firstRowFirstColumn() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(80, "Row1", "Col1");
        data.addValue(90, "Row2", "Col1");
        
        // WHEN
        data.removeValue("Row1", "Col1");
        
        // THEN
        assertNull(data.getValue("Row1", "Col1"), "Value at 'Row1', 'Col1' should be null");
        assertEquals(1, data.getRowCount(), "Row count should be 1");
        assertEquals(1, data.getColumnCount(), "Column count should be 1");
    }

    @Test
    @DisplayName("Remove a value from the last row and last column")
    public void TC08_removeValue_lastRowLastColumn() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(100, "Row5", "Col5");
        
        // WHEN
        data.removeValue("Row5", "Col5");
        
        // THEN
        assertNull(data.getValue("Row5", "Col5"), "Value at 'Row5', 'Col5' should be null");
        assertEquals(0, data.getRowCount(), "Row count should be 0");
        assertEquals(0, data.getColumnCount(), "Column count should be 0");
    }

    @Test
    @DisplayName("Remove a value when rowKeys are sorted, ensuring correct row identification")
    public void TC09_removeValue_sortedRowKeys() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D(true); // sorted
        data.addValue(110, "RowA", "Col2");
        data.addValue(120, "RowB", "Col2");
        data.addValue(130, "RowC", "Col2");
        
        // WHEN
        data.removeValue("RowB", "Col2");
        
        // THEN
        assertNull(data.getValue("RowB", "Col2"), "Value at 'RowB', 'Col2' should be null");
        assertEquals(2, data.getRowCount(), "Row count should be 2");
        assertEquals(1, data.getColumnCount(), "Column count should be 1");
    }

    // Removed the erroneous sorted column keys test. The DefaultKeyedValues2D constructor accepts only one boolean argument for sorting row keys.
}