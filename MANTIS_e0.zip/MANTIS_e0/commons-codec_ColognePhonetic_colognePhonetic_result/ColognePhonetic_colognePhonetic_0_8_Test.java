package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

/**
 * JUnit 5 test class for ColognePhonetic.colognePhonetic method.
 */
public class ColognePhonetic_colognePhonetic_0_8_Test {

    @Test
    @DisplayName("Input with 'C' before 'L', ensuring correct code '4'")
    public void TC36_InputWith_C_before_L_Includes_4() {
        // Arrange
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String input = "Clear";

        // Act
        String result = colognePhonetic.colognePhonetic(input);

        // Assert
        Assertions.assertTrue(result.contains("4"), "The result should contain '4' for 'C' before 'L'");
    }
}