package org.apache.commons.math3.analysis.interpolation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.DimensionMismatchException;

public class SmoothingPolynomialBicubicSplineInterpolator_interpolate_0_2_Test {

    @Test
    @DisplayName("Valid input arrays with multiple iterations in x and y loops for normal interpolation")
    void TC06() {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[][] fval = {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0},
            {7.0, 8.0, 9.0}
        };
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();

        // WHEN
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The interpolated function should not be null.");
    }

    @Test
    @DisplayName("Valid input with single element in xval and yval, leading to single iterations in loops")
    void TC07() {
        // GIVEN
        double[] xval = {1.0};
        double[] yval = {1.0};
        double[][] fval = {
            {1.0}
        };
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();

        // WHEN
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The interpolated function should not be null for single data point.");
    }

    @Test
    @DisplayName("Input arrays with large numeric values to test interpolation under high magnitude data")
    void TC08() {
        // GIVEN
        double[] xval = {1e10, 2e10, 3e10};
        double[] yval = {1e10, 2e10, 3e10};
        double[][] fval = {
            {1e10, 2e10, 3e10},
            {4e10, 5e10, 6e10},
            {7e10, 8e10, 9e10}
        };
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();

        // WHEN
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The interpolated function should handle large numeric values.");
    }

    @Test
    @DisplayName("Input arrays with negative values to verify interpolation handles negative coordinates")
    void TC09() {
        // GIVEN
        double[] xval = {-3.0, -2.0, -1.0};
        double[] yval = {-3.0, -2.0, -1.0};
        double[][] fval = {
            {-3.0, -2.0, -1.0},
            {-6.0, -5.0, -4.0},
            {-9.0, -8.0, -7.0}
        };
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();

        // WHEN
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The interpolated function should handle negative values.");
    }

    @Test
    @DisplayName("Input arrays with negative values to verify interpolation handles negative coordinates")
    void TC10() {
        // GIVEN
        double[] xval = {-3.0, -2.0, -1.0};
        double[] yval = {-3.0, -2.0, -1.0};
        double[][] fval = {
            {-3.0, -2.0, -1.0},
            {-6.0, -5.0, -4.0},
            {-9.0, -8.0, -7.0}
        };
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator();

        // WHEN
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The interpolated function should handle negative values.");
    }
}