package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for Metaphone.metaphone method.
 */
public class Metaphone_metaphone_0_7_Test {

    @Test
    @DisplayName("metaphone(\"SIGHT\") converts 'SIGHT' correctly")
    public void TC31() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String input = "sight";

        // Act
        String result = metaphone.metaphone(input);

        // Assert
        assertTrue(result.contains("XT"), "The metaphone code should contain 'XT'");
    }

    @Test
    @DisplayName("metaphone(\"BOOM\") handles duplicate 'O's correctly")
    public void TC32() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String input = "boom";

        // Act
        String result = metaphone.metaphone(input);

        // Assert
        long mCount = result.chars().filter(c -> c == 'M').count();
        assertEquals(1, mCount, "The metaphone code should contain a single 'M'");
    }

    @Test
    @DisplayName("metaphone(\"YELLOW\") handles 'Y' followed by vowel")
    public void TC33() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String input = "yellow";

        // Act
        String result = metaphone.metaphone(input);

        // Assert
        assertTrue(result.contains("Y"), "The metaphone code should contain 'Y'");
    }

    @Test
    @DisplayName("metaphone(\"RHINO\") handles 'R' at end")
    public void TC34() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String input = "rhino";

        // Act
        String result = metaphone.metaphone(input);

        // Assert
        assertTrue(result.endsWith("N"), "The metaphone code should end with 'N'");
    }

    @Test
    @DisplayName("metaphone(\"CMYK\") handles 'C' before non-vowel")
    public void TC35() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String input = "CMYK";

        // Act
        String result = metaphone.metaphone(input);

        // Assert
        assertFalse(result.contains("C"), "The metaphone code should omit 'C' before non-vowel");
    }
}