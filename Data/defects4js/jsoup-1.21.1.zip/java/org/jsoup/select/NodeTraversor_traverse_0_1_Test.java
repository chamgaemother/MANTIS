package org.jsoup.select;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jsoup.nodes.Node;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class NodeTraversor_traverse_0_1_Test {

    @Test
    @DisplayName("Traverse method handles null root node by throwing IllegalArgumentException")
    void TC01_traverse_null_root_throws_exception() {
        // GIVEN
        NodeVisitor visitor = mock(NodeVisitor.class);
        Node root = null;

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            NodeTraversor.traverse(visitor, root);
        });
        assertEquals("Root node must not be null", exception.getMessage());
    }

    @Test
    @DisplayName("Traverse method does not traverse when root node is null and visitor is null")
    void TC02_traverse_null_visitor_and_root_throws_exception() {
        // GIVEN
        NodeVisitor visitor = null;
        Node root = null;

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            NodeTraversor.traverse(visitor, root);
        });
        assertEquals("Visitor and root node must not be null", exception.getMessage());
    }

    @Test
    @DisplayName("Traverse with valid visitor and root, single node with no children")
    void TC03_traverse_single_node_no_children() throws Exception {
        // GIVEN
        NodeVisitor visitor = mock(NodeVisitor.class);
        Node root = mock(Node.class);
        when(root.hasParent()).thenReturn(false);
        when(root.childNodeSize()).thenReturn(0);
        when(root.nextSibling()).thenReturn(null);
        when(root.parentNode()).thenReturn(null);

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        verify(visitor, times(1)).head(root, 0);
        verify(visitor, times(1)).tail(root, 0);
    }

    @Test
    @DisplayName("Traverse with multiple sibling nodes")
    void TC04_traverse_multiple_siblings() throws Exception {
        // GIVEN
        NodeVisitor visitor = mock(NodeVisitor.class);
        Node root = mock(Node.class);
        Node child1 = mock(Node.class);
        Node child2 = mock(Node.class);
        Node child3 = mock(Node.class);

        when(root.hasParent()).thenReturn(false);
        when(root.childNodeSize()).thenReturn(3);
        when(root.nextSibling()).thenReturn(null);
        when(root.parentNode()).thenReturn(null);

        when(child1.hasParent()).thenReturn(true);
        when(child1.parentNode()).thenReturn(root);
        when(child1.childNodeSize()).thenReturn(0);
        when(child1.nextSibling()).thenReturn(child2);
        when(child1.parentNode()).thenReturn(root);

        when(child2.hasParent()).thenReturn(true);
        when(child2.parentNode()).thenReturn(root);
        when(child2.childNodeSize()).thenReturn(0);
        when(child2.nextSibling()).thenReturn(child3);

        when(child3.hasParent()).thenReturn(true);
        when(child3.parentNode()).thenReturn(root);
        when(child3.childNodeSize()).thenReturn(0);
        when(child3.nextSibling()).thenReturn(null);

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        verify(visitor, times(1)).head(root, 0);
        verify(visitor, times(1)).head(child1, 1);
        verify(visitor, times(1)).tail(child1, 1);
        verify(visitor, times(1)).head(child2, 1);
        verify(visitor, times(1)).tail(child2, 1);
        verify(visitor, times(1)).head(child3, 1);
        verify(visitor, times(1)).tail(child3, 1);
        verify(visitor, times(1)).tail(root, 0);
    }

    @Test
    @DisplayName("Traverse with nested child nodes increasing depth")
    void TC05_traverse_nested_children_increasing_depth() throws Exception {
        // GIVEN
        NodeVisitor visitor = mock(NodeVisitor.class);
        Node root = mock(Node.class);
        Node child1 = mock(Node.class);
        Node child2 = mock(Node.class);
        Node grandChild = mock(Node.class);

        when(root.hasParent()).thenReturn(false);
        when(root.childNodeSize()).thenReturn(1);
        when(root.nextSibling()).thenReturn(null);
        when(root.parentNode()).thenReturn(null);

        when(child1.hasParent()).thenReturn(true);
        when(child1.parentNode()).thenReturn(root);
        when(child1.childNodeSize()).thenReturn(1);
        when(child1.nextSibling()).thenReturn(null);

        when(child2.hasParent()).thenReturn(true);
        when(child2.parentNode()).thenReturn(child1);
        when(child2.childNodeSize()).thenReturn(0);
        when(child2.nextSibling()).thenReturn(null);

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        verify(visitor).head(root, 0);
        verify(visitor).head(child1, 1);
        verify(visitor).head(child2, 2);
        verify(visitor).tail(child2, 2);
        verify(visitor).tail(child1, 1);
        verify(visitor).tail(root, 0);
    }
}