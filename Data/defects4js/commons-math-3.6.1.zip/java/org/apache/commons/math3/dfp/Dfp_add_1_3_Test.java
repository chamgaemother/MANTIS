package org.apache.commons.math3.dfp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;

/**
 * JUnit 5 test class for the add method of the Dfp class.
 */
public class Dfp_add_1_3_Test {

    @Test
    @DisplayName("Adding Dfp negative infinity and a finite positive Dfp number returns negative infinity")
    void test_TC16_AddNegativeInfinityAndFinitePositive() throws Exception {
        // Initialize DfpField with radix digits
        DfpField field = new DfpField(10);
        
        // Create Dfp negative infinity
        Dfp a = new Dfp(field, (byte)-1, Dfp.INFINITE);
        
        // Create a finite positive Dfp number
        Dfp b = new Dfp(field, 300.0);
        
        // Perform addition
        Dfp result = a.add(b);
        
        // Assert that the result is infinite
        assertTrue(result.isInfinite(), "Result should be Infinity");
        
        // Use reflection to access the sign field
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte sign = signField.getByte(result);
        
        // Assert that the sign is negative
        assertEquals(-1, sign, "Result should be negative Infinity");
    }

    @Test
    @DisplayName("Adding two Dfp numbers where both have zero mantissa but different exponents")
    void test_TC17_AddTwoZerosWithDifferentExponents() throws Exception {
        // Initialize DfpField with radix digits
        DfpField field = new DfpField(10);
        
        // Create first zero with exponent -100
        Dfp a = new Dfp(field, 0.0);
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(a, -100);
        
        // Create second zero with exponent 50
        Dfp b = new Dfp(field, 0.0);
        expField.setInt(b, 50);
        
        // Perform addition
        Dfp result = a.add(b);
        
        // Assert that the result is zero
        assertTrue(result.isZero(), "Result should be zero");
        
        // Use reflection to access the exponent field
        Field resultExpField = Dfp.class.getDeclaredField("exp");
        resultExpField.setAccessible(true);
        int resultExp = resultExpField.getInt(result);
        
        // Assert that the exponent is aligned to the operand with higher magnitude exponent
        assertEquals(50, resultExp, "Exponent should be aligned to the operand with higher magnitude exponent");
    }

    @Test
    @DisplayName("Adding a finite Dfp number to a signaling NaN (SNAN) triggers FLAG_INVALID and returns QNAN")
    void test_TC18_AddFiniteWithSignalingNaN() throws Exception {
        // Initialize DfpField with radix digits
        DfpField field = new DfpField(10);
        
        // Create a finite Dfp number
        Dfp a = new Dfp(field, 75.0);
        
        // Create a signaling NaN (SNAN)
        Dfp b = new Dfp(field, (byte)1, Dfp.SNAN);
        
        // Perform addition
        Dfp result = a.add(b);
        
        // Use reflection to access the 'field' field in Dfp
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);
        
        // Use reflection to access the 'flags' field in DfpField
        Field flagsField = DfpField.class.getDeclaredField("flags");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(resultField);
        
        // Assert that FLAG_INVALID is set
        assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");
        
        // Use reflection to access the 'nans' field in Dfp
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte nans = nansField.getByte(result);
        
        // Assert that the result is QNAN
        assertTrue(result.isNaN(), "Result should be NaN");
        assertEquals(Dfp.QNAN, nans, "Result should be QNAN");
    }
}