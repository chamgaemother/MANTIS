package org.apache.commons.lang3.time;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

public class DurationFormatUtils_formatPeriod_0_3_Test {

    @Test
    @DisplayName("Duration with negative milliseconds resulting in exception")
    void TC11_formatPeriod_withNegativeMilliseconds_throwsException() {
        // GIVEN
        long startMillis = 1609459201000L;
        long endMillis = 1609459200999L; // -1 millisecond
        String format = "s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        });
        assertEquals("startMillis must not be greater than endMillis", exception.getMessage());
    }

    @Test
    @DisplayName("Duration with timezone affecting hour calculation")
    void TC12_formatPeriod_withTimezone_affectsHourCalculation() {
        // GIVEN
        long startMillis = 1609455600000L; // Dec 31, 2020 23:00 GMT-1
        long endMillis = 1609459200000L;   // Jan 1, 2021 00:00 GMT
        String format = "H:m:s";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT-1");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        assertEquals("1:0:0", result);
    }

    @Test
    @DisplayName("Duration with single iteration loops")
    void TC13_formatPeriod_withSingleIterationLoops() {
        // GIVEN
        long startMillis = 1609459200000L;
        long endMillis = 1609459260000L; // +1 minute
        String format = "m:s";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        assertEquals("1:0", result);
    }

    @Test
    @DisplayName("Duration with multiple iterations in loops")
    void TC14_formatPeriod_withMultipleIterationsInLoops() {
        // GIVEN
        long startMillis = 1609459200000L;
        long endMillis = 1609462800000L; // +1 hour
        String format = "H:m:s";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        assertEquals("1:0:0", result);
    }

    @Test
    @DisplayName("Duration with missing 's' token, ensuring seconds are not included")
    void TC15_formatPeriod_withoutSToken_excludesSeconds() {
        // GIVEN
        long startMillis = 1609459200000L;
        long endMillis = 1609459260000L; // +1 minute
        String format = "m";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // WHEN
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // THEN
        assertEquals("1", result);
    }
}