package org.apache.commons.math3.optim.univariate;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

public class BracketFinder_search_0_1_Test {

    @Test
    @DisplayName("search method with GoalType MINIMIZE and fA < fB, leading to swapping xA and xB")
    void TC01() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.618034;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(xA)).thenReturn(1.0);
        when(func.value(xB)).thenReturn(2.0);

        BracketFinder finder = new BracketFinder();

        // WHEN
        finder.search(func, goal, xA, growLimit);

        // THEN
        // Access private fields using reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        Field fLoField = BracketFinder.class.getDeclaredField("fLo");
        Field fMidField = BracketFinder.class.getDeclaredField("fMid");
        Field fHiField = BracketFinder.class.getDeclaredField("fHi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        fLoField.setAccessible(true);
        fMidField.setAccessible(true);
        fHiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        double fLo = fLoField.getDouble(finder);
        double fMid = fMidField.getDouble(finder);
        double fHi = fHiField.getDouble(finder);

        // Assertions
        assertEquals(2.0, lo, 1e-6, "lo should be updated to xB after swap");
        assertEquals(1.0, mid, 1e-6, "mid should be updated to xA after swap");
        // hi is calculated based on xB and growLimit; exact value depends on implementation
        assertTrue(hi > mid, "hi should be greater than mid");
        assertEquals(2.0, fLo, 1e-6, "fLo should be fB after swap");
        assertEquals(1.0, fMid, 1e-6, "fMid should be fA after swap");
        // fHi depends on the function evaluation at hi
    }

    @Test
    @DisplayName("search method with GoalType MAXIMIZE and fA > fB, leading to swapping xA and xB")
    void TC02() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 3.0;
        double xB = 2.0;
        double growLimit = 1.618034;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(xA)).thenReturn(3.0);
        when(func.value(xB)).thenReturn(2.0);

        BracketFinder finder = new BracketFinder();

        // WHEN
        finder.search(func, goal, xA, growLimit);

        // THEN
        // Access private fields using reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        Field fLoField = BracketFinder.class.getDeclaredField("fLo");
        Field fMidField = BracketFinder.class.getDeclaredField("fMid");
        Field fHiField = BracketFinder.class.getDeclaredField("fHi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        fLoField.setAccessible(true);
        fMidField.setAccessible(true);
        fHiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        double fLo = fLoField.getDouble(finder);
        double fMid = fMidField.getDouble(finder);
        double fHi = fHiField.getDouble(finder);

        // Assertions
        assertEquals(2.0, lo, 1e-6, "lo should be updated to xB after swap");
        assertEquals(3.0, mid, 1e-6, "mid should be updated to xA after swap");
        // hi is calculated based on xB and growLimit; exact value depends on implementation
        assertTrue(hi > mid, "hi should be greater than mid");
        assertEquals(2.0, fLo, 1e-6, "fLo should be fB after swap");
        assertEquals(3.0, fMid, 1e-6, "fMid should be fA after swap");
        // fHi depends on the function evaluation at hi
    }

    @Test
    @DisplayName("search method with GoalType MINIMIZE and fA >= fB, no swapping of xA and xB")
    void TC03() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 4.0;
        double xB = 4.0;
        double growLimit = 1.618034;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(xA)).thenReturn(4.0);
        when(func.value(xB)).thenReturn(4.0);

        BracketFinder finder = new BracketFinder();

        // WHEN
        finder.search(func, goal, xA, growLimit);

        // THEN
        // Access private fields using reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        Field fLoField = BracketFinder.class.getDeclaredField("fLo");
        Field fMidField = BracketFinder.class.getDeclaredField("fMid");
        Field fHiField = BracketFinder.class.getDeclaredField("fHi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        fLoField.setAccessible(true);
        fMidField.setAccessible(true);
        fHiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        double fLo = fLoField.getDouble(finder);
        double fMid = fMidField.getDouble(finder);
        double fHi = fHiField.getDouble(finder);

        // Assertions
        assertEquals(4.0, lo, 1e-6, "lo should remain unchanged");
        assertEquals(4.0, mid, 1e-6, "mid should remain unchanged");
        // hi is calculated based on xB and growLimit; exact value depends on implementation
        assertTrue(hi > mid, "hi should be greater than mid");
        assertEquals(4.0, fLo, 1e-6, "fLo should remain unchanged");
        assertEquals(4.0, fMid, 1e-6, "fMid should remain unchanged");
        // fHi depends on the function evaluation at hi
    }

    @Test
    @DisplayName("search method with GoalType MAXIMIZE and fA <= fB, no swapping of xA and xB")
    void TC04() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 5.0;
        double xB = 5.0;
        double growLimit = 1.618034;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(xA)).thenReturn(5.0);
        when(func.value(xB)).thenReturn(5.0);

        BracketFinder finder = new BracketFinder();

        // WHEN
        finder.search(func, goal, xA, growLimit);

        // THEN
        // Access private fields using reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        Field fLoField = BracketFinder.class.getDeclaredField("fLo");
        Field fMidField = BracketFinder.class.getDeclaredField("fMid");
        Field fHiField = BracketFinder.class.getDeclaredField("fHi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        fLoField.setAccessible(true);
        fMidField.setAccessible(true);
        fHiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        double fLo = fLoField.getDouble(finder);
        double fMid = fMidField.getDouble(finder);
        double fHi = fHiField.getDouble(finder);

        // Assertions
        assertEquals(5.0, lo, 1e-6, "lo should remain unchanged");
        assertEquals(5.0, mid, 1e-6, "mid should remain unchanged");
        // hi is calculated based on xB and growLimit; exact value depends on implementation
        assertTrue(hi > mid, "hi should be greater than mid");
        assertEquals(5.0, fLo, 1e-6, "fLo should remain unchanged");
        assertEquals(5.0, fMid, 1e-6, "fMid should remain unchanged");
        // fHi depends on the function evaluation at hi
    }

    @Test
    @DisplayName("search method where initial evaluation fC is not better, exiting loop immediately")
    void TC05() throws Exception {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 0.1;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(xA)).thenReturn(1.0);
        when(func.value(xB)).thenReturn(2.0);
        // Assuming fC is evaluated as 2.0 which is not better than fB=2.0 for MINIMIZE
        when(func.value(xB + 1.618034 * (xB - xA))).thenReturn(2.0);

        BracketFinder finder = new BracketFinder();

        // WHEN
        finder.search(func, goal, xA, growLimit);

        // THEN
        // Access private fields using reflection
        Field loField = BracketFinder.class.getDeclaredField("lo");
        Field midField = BracketFinder.class.getDeclaredField("mid");
        Field hiField = BracketFinder.class.getDeclaredField("hi");
        Field fLoField = BracketFinder.class.getDeclaredField("fLo");
        Field fMidField = BracketFinder.class.getDeclaredField("fMid");
        Field fHiField = BracketFinder.class.getDeclaredField("fHi");
        loField.setAccessible(true);
        midField.setAccessible(true);
        hiField.setAccessible(true);
        fLoField.setAccessible(true);
        fMidField.setAccessible(true);
        fHiField.setAccessible(true);

        double lo = loField.getDouble(finder);
        double mid = midField.getDouble(finder);
        double hi = hiField.getDouble(finder);
        double fLo = fLoField.getDouble(finder);
        double fMid = fMidField.getDouble(finder);
        double fHi = fHiField.getDouble(finder);

        // Assertions
        assertEquals(1.0, lo, 1e-6, "lo should remain as xA");
        assertEquals(2.0, mid, 1e-6, "mid should remain as xB");
        // hi is calculated based on xB and growLimit; exact value depends on implementation
        assertTrue(hi > mid, "hi should be greater than mid");
        assertEquals(1.0, fLo, 1e-6, "fLo should remain as fA");
        assertEquals(2.0, fMid, 1e-6, "fMid should remain as fB");
        assertEquals(2.0, fHi, 1e-6, "fHi should be equal to fC and not better, exiting loop");
    }

}