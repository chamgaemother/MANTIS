package org.jfree.chart.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.Color;
import java.awt.Paint;
import java.awt.PaintContext;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Generated JUnit 5 tests for PaintUtils.equal method.
 */
public class PaintUtils_equal_1_1_Test {

    /**
     * CustomPaint class for testing purposes.
     */
    private static class CustomPaint implements Paint {
        private final Color color;
        private final float opacity;

        public CustomPaint(Color color, float opacity) {
            this.color = color;
            this.opacity = opacity;
        }

        public Color getColor() {
            return color;
        }

        public float getOpacity() {
            return opacity;
        }

        @Override
        public PaintContext createContext(ColorModel cm, Rectangle deviceBounds, Rectangle2D userBounds,
                AffineTransform xform, java.awt.RenderingHints hints) {
            return null; // Dummy implementation
        }

        @Override
        public int getTransparency() {
            return color.getAlpha() * Math.round(opacity);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (!(obj instanceof CustomPaint))
                return false;
            CustomPaint other = (CustomPaint) obj;
            return this.color.equals(other.color) && Float.compare(this.opacity, other.opacity) == 0;
        }
    }

    /**
     * SubCustomPaint class inheriting from CustomPaint.
     */
    private static class SubCustomPaint extends CustomPaint {
        public SubCustomPaint(Color color, float opacity) {
            super(color, opacity);
        }
    }

    /**
     * AnotherSubCustomPaint class inheriting from CustomPaint.
     */
    private static class AnotherSubCustomPaint extends CustomPaint {
        public AnotherSubCustomPaint(Color color, float opacity) {
            super(color, opacity);
        }
    }

    @Test
    @DisplayName("Both p1 and p2 are CustomPaint instances with identical properties, expect true")
    public void TC36() {
        // Arrange
        Paint p1 = new CustomPaint(Color.RED, 0.5f);
        Paint p2 = new CustomPaint(Color.RED, 0.5f);

        // Act
        boolean result = PaintUtils.equal(p1, p2);

        // Assert
        assertTrue(result, "Expected PaintUtils.equal to return true for identical CustomPaint instances");
    }

    @Test
    @DisplayName("Both p1 and p2 are CustomPaint instances with different properties, expect false")
    public void TC37() {
        // Arrange
        Paint p1 = new CustomPaint(Color.RED, 0.5f);
        Paint p2 = new CustomPaint(Color.BLUE, 0.7f);

        // Act
        boolean result = PaintUtils.equal(p1, p2);

        // Assert
        assertFalse(result, "Expected PaintUtils.equal to return false for different CustomPaint instances");
    }

    @Test
    @DisplayName("p1 is a CustomPaint and p2 is a different CustomPaint with same properties via inheritance, expect true")
    public void TC38() {
        // Arrange
        Paint p1 = new SubCustomPaint(Color.GREEN, 0.3f);
        Paint p2 = new AnotherSubCustomPaint(Color.GREEN, 0.3f);

        // Act
        boolean result = PaintUtils.equal(p1, p2);

        // Assert
        assertTrue(result, "Expected PaintUtils.equal to return true for inherited CustomPaint instances with identical properties");
    }

    @Test
    @DisplayName("p1 is a CustomPaint and p2 is a different CustomPaint with different properties via inheritance, expect false")
    public void TC39() {
        // Arrange
        Paint p1 = new SubCustomPaint(Color.GREEN, 0.3f);
        Paint p2 = new AnotherSubCustomPaint(Color.YELLOW, 0.6f);

        // Act
        boolean result = PaintUtils.equal(p1, p2);

        // Assert
        assertFalse(result, "Expected PaintUtils.equal to return false for inherited CustomPaint instances with different properties");
    }
}