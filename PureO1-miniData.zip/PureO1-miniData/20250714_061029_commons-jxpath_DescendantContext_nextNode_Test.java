import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.axes.DescendantContext;
import org.apache.commons.jxpath.ri.EvalContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import java.util.Stack;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DescendantContextTest {

    private EvalContext parentContext;
    private NodePointer parentNodePointer;
    private NodeTest nodeTest;
    private DescendantContext descendantContext;
    private NodeIterator childIterator;
    private NodePointer childNodePointer;

    @BeforeEach
    public void setUp() {
        parentContext = mock(EvalContext.class);
        parentNodePointer = mock(NodePointer.class);
        when(parentContext.getCurrentNodePointer()).thenReturn(parentNodePointer);
        nodeTest = new NodeTypeTest(NodeTest.NODE_TYPE_NODE);
        childIterator = mock(NodeIterator.class);
        childNodePointer = mock(NodePointer.class);
    }

    @Test
    public void testNextNode_FirstCallIncludeSelfAndMatches() {
        descendantContext = new DescendantContext(parentContext, true, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        assertEquals(1, descendantContext.getPosition());
        verify(parentNodePointer).testNode(nodeTest);
        verify(parentNodePointer).childIterator(any(), anyBoolean(), any());
    }

    @Test
    public void testNextNode_FirstCallIncludeSelfButDoesNotMatch() {
        descendantContext = new DescendantContext(parentContext, true, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.testNode(nodeTest)).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true);
        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
        when(childNodePointer.isLeaf()).thenReturn(true);
        when(childNodePointer.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        assertEquals(1, descendantContext.getPosition());
        verify(parentNodePointer).testNode(nodeTest);
        verify(childIterator).setPosition(1);
    }

    @Test
    public void testNextNode_FirstCallExcludeSelf() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true);
        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
        when(childNodePointer.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        assertEquals(1, descendantContext.getPosition());
        verify(parentNodePointer, never()).testNode(nodeTest);
    }

    @Test
    public void testNextNode_NoChildrenButIncludeSelfMatches() {
        descendantContext = new DescendantContext(parentContext, true, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(true);
        when(parentNodePointer.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        assertEquals(1, descendantContext.getPosition());
        verify(parentNodePointer, never()).childIterator(any(), anyBoolean(), any());
    }

    @Test
    public void testNextNode_NoChildrenAndIncludeSelfDoesNotMatch() {
        descendantContext = new DescendantContext(parentContext, true, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(true);
        when(parentNodePointer.testNode(nodeTest)).thenReturn(false);

        assertFalse(descendantContext.nextNode());
        assertEquals(0, descendantContext.getPosition());
    }

    @Test
    public void testNextNode_RecursiveDetection() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true);
        when(childIterator.getNodePointer()).thenReturn(parentNodePointer); // Recursive
        when(parentNodePointer.testNode(nodeTest)).thenReturn(false);

        assertFalse(descendantContext.nextNode());
        assertEquals(0, descendantContext.getPosition());
    }

    @Test
    public void testNextNode_MultipleChildren() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true);
        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
        when(childNodePointer.isLeaf()).thenReturn(true);
        when(childNodePointer.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        assertTrue(descendantContext.nextNode());
        assertFalse(descendantContext.nextNode());
        assertEquals(2, descendantContext.getPosition());
    }

    @Test
    public void testNextNode_IteratorExhausted() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(anyInt())).thenReturn(false);

        assertFalse(descendantContext.nextNode());
        assertEquals(0, descendantContext.getPosition());
    }

    @Test
    public void testNextNode_SetPositionResetsWhenLower() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true);
        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
        when(childNodePointer.isLeaf()).thenReturn(true);
        when(childNodePointer.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        assertTrue(descendantContext.setPosition(1));
        assertEquals(1, descendantContext.getPosition());

        assertFalse(descendantContext.setPosition(0));
        assertEquals(1, descendantContext.getPosition());
    }

    @Test
    public void testNextNode_Reset() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true);
        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
        when(childNodePointer.isLeaf()).thenReturn(true);
        when(childNodePointer.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        descendantContext.reset();
        assertFalse(descendantContext.nextNode());
    }

    @Test
    public void testNextNode_NullCurrentNodePointer() {
        when(parentContext.getCurrentNodePointer()).thenReturn(null);
        descendantContext = new DescendantContext(parentContext, true, nodeTest);

        assertFalse(descendantContext.nextNode());
        assertEquals(0, descendantContext.getPosition());
    }

    @Test
    public void testNextNode_MultipleLevels() {
        NodeIterator childIterator2 = mock(NodeIterator.class);
        NodePointer childNodePointer2 = mock(NodePointer.class);

        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true).thenReturn(true).thenReturn(false);
        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
        when(childNodePointer.isLeaf()).thenReturn(false);
        when(childNodePointer.testNode(nodeTest)).thenReturn(false);
        when(childNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator2);
        when(childIterator2.setPosition(1)).thenReturn(true);
        when(childIterator2.getNodePointer()).thenReturn(childNodePointer2);
        when(childNodePointer2.isLeaf()).thenReturn(true);
        when(childNodePointer2.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode()); // childNodePointer2
        assertFalse(descendantContext.nextNode());
        assertEquals(1, descendantContext.getPosition());
    }

    @Test
    public void testNextNode_PositionIncrementedCorrectly() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(anyInt())).thenReturn(true).thenReturn(true).thenReturn(false);
        NodePointer firstChild = mock(NodePointer.class);
        NodePointer secondChild = mock(NodePointer.class);
        when(childIterator.getNodePointer()).thenReturn(firstChild).thenReturn(secondChild);
        when(firstChild.isLeaf()).thenReturn(true);
        when(firstChild.testNode(nodeTest)).thenReturn(true);
        when(secondChild.isLeaf()).thenReturn(true);
        when(secondChild.testNode(nodeTest)).thenReturn(true);

        assertTrue(descendantContext.nextNode());
        assertEquals(1, descendantContext.getPosition());
        assertTrue(descendantContext.nextNode());
        assertEquals(2, descendantContext.getPosition());
        assertFalse(descendantContext.nextNode());
    }

    @Test
    public void testNextNode_WithRecursiveAndNonRecursiveNodes() {
        descendantContext = new DescendantContext(parentContext, false, nodeTest);
        when(parentNodePointer.isLeaf()).thenReturn(false);
        NodeIterator parentIterator = mock(NodeIterator.class);
        NodePointer child1 = mock(NodePointer.class);
        NodePointer child2 = mock(NodePointer.class);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(childIterator);
        when(childIterator.setPosition(1)).thenReturn(true).thenReturn(true).thenReturn(false);
        when(childIterator.getNodePointer()).thenReturn(child1).thenReturn(child2);
        when(child1.isLeaf()).thenReturn(true);
        when(child1.testNode(nodeTest)).thenReturn(true);
        when(child2.isLeaf()).thenReturn(false);
        when(child2.testNode(nodeTest)).thenReturn(true;
        ).thenReturn(false);
        NodeIterator child2Iterator = mock(NodeIterator.class);
        when(child2.childIterator(any(), anyBoolean(), any())).thenReturn(child2Iterator);
        when(child2Iterator.setPosition(1)).thenReturn(true);
        when(child2Iterator.getNodePointer()).thenReturn(parentNodePointer); // Recursive

        assertTrue(descendantContext.nextNode()); // child1
        assertTrue(descendantContext.nextNode()); // child2, but its child is recursive
        assertEquals(2, descendantContext.getPosition());
    }
}