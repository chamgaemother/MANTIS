package org.jfree.chart;

import org.jfree.chart.plot.Plot;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.jfree.chart.ChartRenderingInfo;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class JFreeChart_draw_1_1_Test {

    @Test
    @DisplayName("Draw method with borderVisible true and borderPaint set to null")
    public void TC26_draw_WithBorderVisibleTrueAndBorderPaintNull() {
        Plot mockPlot = mock(Plot.class);
        JFreeChart chart = new JFreeChart(mockPlot);
        chart.setBorderVisible(true);
        chart.setBorderPaint(null);

        Graphics2D mockG2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();

        chart.draw(mockG2, chartArea, anchor, info);

        verify(mockG2, never()).setPaint(any(Paint.class));
        verify(mockG2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("Draw method with borderVisible true and borderStroke set to null")
    public void TC27_draw_WithBorderVisibleTrueAndBorderStrokeNull() {
        Plot mockPlot = mock(Plot.class);
        JFreeChart chart = new JFreeChart(mockPlot);
        chart.setBorderVisible(true);
        chart.setBorderStroke(null);

        Graphics2D mockG2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();

        chart.draw(mockG2, chartArea, anchor, info);

        verify(mockG2, never()).setStroke(null);
        verify(mockG2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("Draw method with title set to null")
    public void TC28_draw_WithTitleSetToNull() {
        Plot mockPlot = mock(Plot.class);
        JFreeChart chart = new JFreeChart(mockPlot);
        chart.setTitle((TextTitle) null);

        Graphics2D mockG2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();

        chart.draw(mockG2, chartArea, anchor, info);

        // Ensure that no draw operations for the title happen since the title is null
        verify(mockG2, atLeast(0)).setPaint(any(Paint.class));
        verify(mockG2, atLeast(0)).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("Draw method with title present but isVisible set to false")
    public void TC29_draw_WithTitlePresentButIsVisibleFalse() {
        Plot mockPlot = mock(Plot.class);
        JFreeChart chart = new JFreeChart(mockPlot);
        TextTitle mockTitle = mock(TextTitle.class);
        when(mockTitle.isVisible()).thenReturn(false);
        chart.setTitle(mockTitle);

        Graphics2D mockG2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();

        chart.draw(mockG2, chartArea, anchor, info);

        verify(mockTitle, never()).draw(any(Graphics2D.class), any(Rectangle2D.class), any());
    }

    @Test
    @DisplayName("Draw method with subtitles list containing both visible and invisible subtitles")
    public void TC30_draw_WithMixedVisibilitySubtitles() {
        Plot mockPlot = mock(Plot.class);
        JFreeChart chart = new JFreeChart(mockPlot);

        Title mockVisibleSubtitle = mock(Title.class);
        when(mockVisibleSubtitle.isVisible()).thenReturn(true);

        Title mockInvisibleSubtitle = mock(Title.class);
        when(mockInvisibleSubtitle.isVisible()).thenReturn(false);

        chart.addSubtitle(mockVisibleSubtitle);
        chart.addSubtitle(mockInvisibleSubtitle);

        Graphics2D mockG2 = mock(Graphics2D.class);
        Rectangle2D chartArea = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D anchor = new Point2D.Double(400, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();

        chart.draw(mockG2, chartArea, anchor, info);

        verify(mockVisibleSubtitle, times(1)).draw(any(Graphics2D.class), any(Rectangle2D.class), any());
        verify(mockInvisibleSubtitle, never()).draw(any(Graphics2D.class), any(Rectangle2D.class), any());
    }
}