package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class XPathParser_NCName_0_7_Test {

    @Test
    @DisplayName("NCName() processes kind FUNCTION_FALSE and returns token image")
    void TC31_NCName_FunctionFalse_ReturnsTokenImage() throws Exception {
        // Initialize XPathParser instance
        Class<?> clazz = Class.forName("org.apache.commons.jxpath.ri.parser.XPathParser");
        Object parser = clazz.getDeclaredConstructor().newInstance();

        // Set 'jj_nt.kind' to FUNCTION_FALSE
        Field jj_ntField = clazz.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Class<?> jjntClass = jj_nt.getClass();
        Field kindField = jjntClass.getDeclaredField("kind");
        kindField.setAccessible(true);

        // Retrieve FUNCTION_FALSE value
        Field functionFalseField = clazz.getDeclaredField("FUNCTION_FALSE");
        functionFalseField.setAccessible(true);
        int functionFalse = functionFalseField.getInt(null);

        kindField.setInt(jj_nt, functionFalse);

        // Set 'token.image' to "expectedImage"
        Field tokenField = clazz.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Class<?> tokenClass = token.getClass();
        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedImage");

        // Invoke NCName()
        Method ncNameMethod = clazz.getDeclaredMethod("NCName");
        ncNameMethod.setAccessible(true);
        String result = (String) ncNameMethod.invoke(parser);

        // Assert
        assertEquals("expectedImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_NULL and returns token image")
    void TC32_NCName_FunctionNull_ReturnsTokenImage() throws Exception {
        // Initialize XPathParser instance
        Class<?> clazz = Class.forName("org.apache.commons.jxpath.ri.parser.XPathParser");
        Object parser = clazz.getDeclaredConstructor().newInstance();

        // Set 'jj_nt.kind' to FUNCTION_NULL
        Field jj_ntField = clazz.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Class<?> jjntClass = jj_nt.getClass();
        Field kindField = jjntClass.getDeclaredField("kind");
        kindField.setAccessible(true);

        // Retrieve FUNCTION_NULL value
        Field functionNullField = clazz.getDeclaredField("FUNCTION_NULL");
        functionNullField.setAccessible(true);
        int functionNull = functionNullField.getInt(null);

        kindField.setInt(jj_nt, functionNull);

        // Set 'token.image' to "expectedImage"
        Field tokenField = clazz.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Class<?> tokenClass = token.getClass();
        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedImage");

        // Invoke NCName()
        Method ncNameMethod = clazz.getDeclaredMethod("NCName");
        ncNameMethod.setAccessible(true);
        String result = (String) ncNameMethod.invoke(parser);

        // Assert
        assertEquals("expectedImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_LANG and returns token image")
    void TC33_NCName_FunctionLang_ReturnsTokenImage() throws Exception {
        // Initialize XPathParser instance
        Class<?> clazz = Class.forName("org.apache.commons.jxpath.ri.parser.XPathParser");
        Object parser = clazz.getDeclaredConstructor().newInstance();

        // Set 'jj_nt.kind' to FUNCTION_LANG
        Field jj_ntField = clazz.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Class<?> jjntClass = jj_nt.getClass();
        Field kindField = jjntClass.getDeclaredField("kind");
        kindField.setAccessible(true);

        // Retrieve FUNCTION_LANG value
        Field functionLangField = clazz.getDeclaredField("FUNCTION_LANG");
        functionLangField.setAccessible(true);
        int functionLang = functionLangField.getInt(null);

        kindField.setInt(jj_nt, functionLang);

        // Set 'token.image' to "expectedImage"
        Field tokenField = clazz.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Class<?> tokenClass = token.getClass();
        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedImage");

        // Invoke NCName()
        Method ncNameMethod = clazz.getDeclaredMethod("NCName");
        ncNameMethod.setAccessible(true);
        String result = (String) ncNameMethod.invoke(parser);

        // Assert
        assertEquals("expectedImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_NUMBER and returns token image")
    void TC34_NCName_FunctionNumber_ReturnsTokenImage() throws Exception {
        // Initialize XPathParser instance
        Class<?> clazz = Class.forName("org.apache.commons.jxpath.ri.parser.XPathParser");
        Object parser = clazz.getDeclaredConstructor().newInstance();

        // Set 'jj_nt.kind' to FUNCTION_NUMBER
        Field jj_ntField = clazz.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Class<?> jjntClass = jj_nt.getClass();
        Field kindField = jjntClass.getDeclaredField("kind");
        kindField.setAccessible(true);

        // Retrieve FUNCTION_NUMBER value
        Field functionNumberField = clazz.getDeclaredField("FUNCTION_NUMBER");
        functionNumberField.setAccessible(true);
        int functionNumber = functionNumberField.getInt(null);

        kindField.setInt(jj_nt, functionNumber);

        // Set 'token.image' to "expectedImage"
        Field tokenField = clazz.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Class<?> tokenClass = token.getClass();
        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedImage");

        // Invoke NCName()
        Method ncNameMethod = clazz.getDeclaredMethod("NCName");
        ncNameMethod.setAccessible(true);
        String result = (String) ncNameMethod.invoke(parser);

        // Assert
        assertEquals("expectedImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_SUM and returns token image")
    void TC35_NCName_FunctionSum_ReturnsTokenImage() throws Exception {
        // Initialize XPathParser instance
        Class<?> clazz = Class.forName("org.apache.commons.jxpath.ri.parser.XPathParser");
        Object parser = clazz.getDeclaredConstructor().newInstance();

        // Set 'jj_nt.kind' to FUNCTION_SUM
        Field jj_ntField = clazz.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Class<?> jjntClass = jj_nt.getClass();
        Field kindField = jjntClass.getDeclaredField("kind");
        kindField.setAccessible(true);

        // Retrieve FUNCTION_SUM value
        Field functionSumField = clazz.getDeclaredField("FUNCTION_SUM");
        functionSumField.setAccessible(true);
        int functionSum = functionSumField.getInt(null);

        kindField.setInt(jj_nt, functionSum);

        // Set 'token.image' to "expectedImage"
        Field tokenField = clazz.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Class<?> tokenClass = token.getClass();
        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedImage");

        // Invoke NCName()
        Method ncNameMethod = clazz.getDeclaredMethod("NCName");
        ncNameMethod.setAccessible(true);
        String result = (String) ncNameMethod.invoke(parser);

        // Assert
        assertEquals("expectedImage", result);
    }
}