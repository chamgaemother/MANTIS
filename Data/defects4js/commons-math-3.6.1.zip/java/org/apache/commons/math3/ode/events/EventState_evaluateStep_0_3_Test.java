package org.apache.commons.math3.ode.events;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.solvers.UnivariateSolver;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class EventState_evaluateStep_0_3_Test {

    @Test
    @DisplayName("evaluateStep sets pendingEvent when root is valid and not near previous event")
    public void TC11_evaluateStep_setsPendingEventForValidRoot() throws Exception {
        // Arrange
        StepInterpolator interpolator = mock(StepInterpolator.class);
        EventHandler handler = mock(EventHandler.class);
        UnivariateSolver solver = mock(UnivariateSolver.class);

        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getCurrentTime()).thenReturn(2.0);

        double convergence = 1e-6;
        double maxCheckInterval = 1.0;
        int maxIterationCount = 100;

        EventState eventState = new EventState(handler, maxCheckInterval, convergence, maxIterationCount, solver);

        double root = 1.0;
        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0, 1.0);
        when(solver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble())).thenReturn(root);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertTrue(result);

        // Use reflection to verify pendingEventTime
        Field pendingEventTimeField = EventState.class.getDeclaredField("pendingEventTime");
        pendingEventTimeField.setAccessible(true);
        double pendingEventTime = pendingEventTimeField.getDouble(eventState);
        assertEquals(root, pendingEventTime, 1e-9);
    }

    @Test
    @DisplayName("evaluateStep retries when root is too close to previous event time")
    public void TC12_evaluateStep_retriesWhenRootTooClose() throws Exception {
        // Arrange
        StepInterpolator interpolator = mock(StepInterpolator.class);
        EventHandler handler = mock(EventHandler.class);
        UnivariateSolver solver = mock(UnivariateSolver.class);

        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getCurrentTime()).thenReturn(2.0);

        double convergence = 1e-6;
        double maxCheckInterval = 1.0;
        int maxIterationCount = 100;

        // Set previousEventTime close to root to trigger retry
        EventState eventState = new EventState(handler, maxCheckInterval, convergence, maxIterationCount, solver);
        Field previousEventTimeField = EventState.class.getDeclaredField("previousEventTime");
        previousEventTimeField.setAccessible(true);
        previousEventTimeField.setDouble(eventState, 0.999999);

        double root = 1.0;
        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0, 1.0);
        when(solver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble())).thenReturn(root);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        // Since the root is too close, it should retry and not set pendingEventTime
        assertFalse(result);
    }

    @Test
    @DisplayName("evaluateStep handles multiple close roots and sets pendingEvent after retries")
    public void TC13_evaluateStep_handlesMultipleCloseRoots() throws Exception {
        // Arrange
        StepInterpolator interpolator = mock(StepInterpolator.class);
        EventHandler handler = mock(EventHandler.class);
        UnivariateSolver solver = mock(UnivariateSolver.class);

        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getCurrentTime()).thenReturn(3.0);

        double convergence = 1e-6;
        double maxCheckInterval = 1.0;
        int maxIterationCount = 100;

        EventState eventState = new EventState(handler, maxCheckInterval, convergence, maxIterationCount, solver);

        double root1 = 1.0;
        double root2 = 1.000001;
        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0, 1.0, -1.0, 1.0);
        when(solver.solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble())).thenReturn(root1, root2);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertTrue(result);

        // Use reflection to verify pendingEventTime is set to the latest root
        Field pendingEventTimeField = EventState.class.getDeclaredField("pendingEventTime");
        pendingEventTimeField.setAccessible(true);
        double pendingEventTime = pendingEventTimeField.getDouble(eventState);
        assertEquals(root2, pendingEventTime, 1e-9);
    }
//
//    @Test
//    @DisplayName("evaluateStep propagates LocalMaxCountExceededException from handler.g")
//    public void TC14_evaluateStep_propagatesLocalMaxCountExceededException() throws Exception {
//        // Arrange
//        StepInterpolator interpolator = mock(StepInterpolator.class);
//        EventHandler handler = mock(EventHandler.class);
//        UnivariateSolver solver = mock(UnivariateSolver.class);
//
//        when(interpolator.isForward()).thenReturn(true);
//        when(interpolator.getCurrentTime()).thenReturn(2.0);
//
//        double convergence = 1e-6;
//        double maxCheckInterval = 1.0;
//        int maxIterationCount = 100;
//
//        EventState eventState = new EventState(handler, maxCheckInterval, convergence, maxIterationCount, solver);
//
//        when(handler.g(anyDouble(), any(double[].class))).thenThrow(new EventState.LocalMaxCountExceededException(new MaxCountExceededException(100, 0)));
//
//        // Act & Assert
//        assertThrows(EventState.LocalMaxCountExceededException.class, () -> {
//            eventState.evaluateStep(interpolator);
//        });
//    }

    @Test
    @DisplayName("evaluateStep completes loop without detecting any events")
    public void TC15_evaluateStep_completesLoopWithoutEvents() throws Exception {
        // Arrange
        StepInterpolator interpolator = mock(StepInterpolator.class);
        EventHandler handler = mock(EventHandler.class);
        UnivariateSolver solver = mock(UnivariateSolver.class);

        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getCurrentTime()).thenReturn(5.0);

        double convergence = 1e-6;
        double maxCheckInterval = 1.0;
        int maxIterationCount = 100;

        EventState eventState = new EventState(handler, maxCheckInterval, convergence, maxIterationCount, solver);

        when(handler.g(anyDouble(), any(double[].class))).thenReturn(-1.0);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertFalse(result);
    }

}
