package com.google.gson.internal.bind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class ISO8601Utils_parse_1_1_Test {

    @Test
    @DisplayName("parse date with timezone offset providing only hours without minutes (e.g., '+02')")
    void TC26_parseDateWithTimezoneOffsetOnlyHours() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00+02";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        assertNotNull(result, "Parsed date should not be null");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be equal to date length");

        // Create expected date using Calendar with GMT+02:00 timezone
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"), Locale.US);
        calendar.setLenient(false);
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.OCTOBER);
        calendar.set(Calendar.DAY_OF_MONTH, 5);
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 30);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date expected = calendar.getTime();

        assertEquals(expected, result, "Parsed date should match the expected date with GMT+02:00 timezone");
    }

    @Test
    @DisplayName("parse date with timezone offset without colon (e.g., '+0200')")
    void TC27_parseDateWithTimezoneOffsetWithoutColon() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00+0200";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        assertNotNull(result, "Parsed date should not be null");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be equal to date length");

        // Create expected date using Calendar with GMT+02:00 timezone
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"), Locale.US);
        calendar.setLenient(false);
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.OCTOBER);
        calendar.set(Calendar.DAY_OF_MONTH, 5);
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 30);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date expected = calendar.getTime();

        assertEquals(expected, result, "Parsed date should match the expected date with GMT+02:00 timezone");
    }

    @Test
    @DisplayName("parse date with invalid timezone offset hours exceeding valid range (e.g., '+25:00')")
    void TC28_parseDateWithInvalidTimezoneOffsetHours() {
        // GIVEN
        String date = "2023-10-05T14:30:00+25:00";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "Expected parse to throw IndexOutOfBoundsException for invalid timezone offset hours");

        assertEquals(0, pos.getIndex(), "ParsePosition index should remain unchanged on exception");
    }

    @Test
    @DisplayName("parse date with two-digit milliseconds (e.g., '.12Z')")
    void TC29_parseDateWithTwoDigitMilliseconds() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00.12Z";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        assertNotNull(result, "Parsed date should not be null");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be equal to date length");

        // Create expected date using Calendar with UTC timezone
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.US);
        calendar.setLenient(false);
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.OCTOBER);
        calendar.set(Calendar.DAY_OF_MONTH, 5);
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 30);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 120);
        Date expected = calendar.getTime();

        assertEquals(expected, result, "Parsed date should have 120 milliseconds");
    }

    @Test
    @DisplayName("parse date with invalid character in timezone offset (e.g., '+02:X0')")
    void TC30_parseDateWithInvalidCharacterInTimezoneOffset() {
        // GIVEN
        String date = "2023-10-05T14:30:00+02:X0";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "Expected parse to throw IndexOutOfBoundsException for invalid character in timezone offset");

        assertEquals(0, pos.getIndex(), "ParsePosition index should remain unchanged on exception");
    }

}