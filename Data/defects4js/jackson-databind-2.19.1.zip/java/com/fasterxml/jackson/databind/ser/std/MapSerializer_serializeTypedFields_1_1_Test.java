package com.fasterxml.jackson.databind.ser.std;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class MapSerializer_serializeTypedFields_1_1_Test {

    /**
     * Helper method to create an instance of MapSerializer with specified parameters using reflection.
     */
    private MapSerializer createMapSerializer(TypeSerializer valueTypeSerializer,
                                              JsonSerializer<Object> keySerializer,
                                              JsonSerializer<Object> valueSerializer,
                                              boolean suppressNulls,
                                              IgnorePropertiesUtil.Checker inclusionChecker) throws Exception {
        // Access the protected constructor of MapSerializer
        Constructor<MapSerializer> constructor = MapSerializer.class.getDeclaredConstructor(
                Set.class, Set.class, com.fasterxml.jackson.databind.JavaType.class,
                com.fasterxml.jackson.databind.JavaType.class, boolean.class,
                TypeSerializer.class, JsonSerializer.class, JsonSerializer.class);
        constructor.setAccessible(true);
        
        // Create a new instance of MapSerializer with the provided parameters
        return constructor.newInstance(
                null, // ignoredEntries
                null, // includedEntries
                null, // keyType
                null, // valueType
                false, // valueTypeIsStatic
                valueTypeSerializer,
                keySerializer,
                valueSerializer
        );
    }

    /**
     * Helper method to set private fields using reflection.
     */
    private void setPrivateField(Object instance, String fieldName, Object value) throws Exception {
        Field field = MapSerializer.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(instance, value);
    }

    @Test
    @DisplayName("serializeTypedFields serializes entries with _valueTypeSerializer present")
    public void TC03_serializeTypedFields_withValueTypeSerializer() throws Exception {
        // Arrange
        Map<Object, Object> map = new HashMap<>();
        map.put("key1", "value1");

        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        TypeSerializer valueTypeSerializer = mock(TypeSerializer.class);
        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);

        MapSerializer mapSerializer = createMapSerializer(
                valueTypeSerializer,
                keySerializer,
                valueSerializer,
                false, // suppressNulls
                null // inclusionChecker
        );

        // Act
        mapSerializer.serializeTypedFields(map, gen, provider, MapSerializer.MARKER_FOR_EMPTY);

        // Assert
        verify(keySerializer).serialize("key1", gen, provider);
        verify(valueSerializer).serializeWithType("value1", gen, provider, valueTypeSerializer);
    }

    @Test
    @DisplayName("serializeTypedFields skips entries where valueSer.isEmpty returns true under checkEmpty")
    public void TC04_serializeTypedFields_skipsEmptyValuesWhenCheckEmpty() throws Exception {
        // Arrange
        Map<Object, Object> map = new HashMap<>();
        map.put("key1", "emptyValue");

        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        TypeSerializer valueTypeSerializer = null; // Not used in this test
        JsonSerializer<Object> keySerializer = mock(JsonSerializer.class);
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);

        // Configure the valueSerializer to return true for isEmpty
        when(valueSerializer.isEmpty(provider, "emptyValue")).thenReturn(true);

        MapSerializer mapSerializer = createMapSerializer(
                valueTypeSerializer,
                keySerializer,
                valueSerializer,
                false, // suppressNulls
                null // inclusionChecker
        );

        // Set the _suppressableValue field to MARKER_FOR_EMPTY using reflection
        setPrivateField(mapSerializer, "_suppressableValue", MapSerializer.MARKER_FOR_EMPTY);

        // Act
        mapSerializer.serializeTypedFields(map, gen, provider, MapSerializer.MARKER_FOR_EMPTY);

        // Assert
        verify(keySerializer, never()).serialize(any(), any(), any());
        verify(valueSerializer, never()).serializeWithType(any(), any(), any(), any());
    }
}