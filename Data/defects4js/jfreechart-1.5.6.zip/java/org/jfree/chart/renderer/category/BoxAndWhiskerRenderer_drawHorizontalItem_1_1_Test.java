package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.awt.geom.Ellipse2D;
import java.lang.reflect.Field;
import java.util.Arrays;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.chart.entity.EntityCollection;

/**
 * JUnit 5 test class for BoxAndWhiskerRenderer.drawHorizontalItem method.
 */
public class BoxAndWhiskerRenderer_drawHorizontalItem_1_1_Test {

    @Test
    @DisplayName("TC26: drawHorizontalItem throws IllegalArgumentException when dataset is not BoxAndWhiskerCategoryDataset")
    void TC26_drawHorizontalItem_InvalidDataset_ThrowsException() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset invalidDataset = mock(CategoryDataset.class);

        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, invalidDataset, 0, 0);
        });
    }

    @Test
    @DisplayName("TC27: drawHorizontalItem handles scenario where Q1 equals Q3 resulting in a zero-width box")
    void TC27_drawHorizontalItem_Q1EqualsQ3_DrawsZeroWidthBox() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);

        when(dataset.getQ1Value(0, 0)).thenReturn(5.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(5.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(0.0);
        when(state.getBarWidth()).thenReturn(2.0);
        when(domainAxis.getCategoryEnd(0, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(domainAxis.getCategoryStart(0, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);

        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Act
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // Assert
        verify(g2, atLeastOnce()).draw(argThat(shape ->
            shape instanceof Line2D.Double &&
            ((Line2D.Double) shape).getX1() == ((Line2D.Double) shape).getX2()
        ));
    }

    @Test
    @DisplayName("TC28: drawHorizontalItem handles whiskerWidth set to 0 ensuring whiskers have zero horizontal length")
    void TC28_drawHorizontalItem_WhiskerWidthZero_WhiskersHaveZeroLength() throws NoSuchFieldException, IllegalAccessException {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);

        when(dataset.getQ1Value(1, 1)).thenReturn(3.0);
        when(dataset.getQ3Value(1, 1)).thenReturn(7.0);
        when(dataset.getMaxRegularValue(1, 1)).thenReturn(10.0);
        when(dataset.getMinRegularValue(1, 1)).thenReturn(1.0);
        when(state.getBarWidth()).thenReturn(2.0);
        when(domainAxis.getCategoryEnd(1, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(domainAxis.getCategoryStart(1, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(5.0);

        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        // Use reflection to set whiskerWidth to 0
        Field whiskerWidthField = BoxAndWhiskerRenderer.class.getDeclaredField("whiskerWidth");
        whiskerWidthField.setAccessible(true);
        whiskerWidthField.setDouble(renderer, 0.0);

        // Act
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);

        // Assert
        verify(g2, atLeastOnce()).draw(argThat(shape ->
            shape instanceof Line2D.Double &&
            ((Line2D.Double) shape).getX1() == ((Line2D.Double) shape).getX2()
        ));
    }

    @Test
    @DisplayName("TC29: drawHorizontalItem handles BoxAndWhiskerCategoryDataset with multiple outliers correctly")
    void TC29_drawHorizontalItem_MultipleOutliers_DrawsAllOutliers() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);

        when(dataset.getQ1Value(2, 2)).thenReturn(4.0);
        when(dataset.getQ3Value(2, 2)).thenReturn(8.0);
        when(dataset.getMaxRegularValue(2, 2)).thenReturn(12.0);
        when(dataset.getMinRegularValue(2, 2)).thenReturn(2.0);
        when(dataset.getOutliers(2, 2)).thenReturn(Arrays.asList(13.0, 14.0, 1.5, 1.0));
        when(dataset.getMinOutlier(2, 2)).thenReturn(1.0);
        when(dataset.getMaxOutlier(2, 2)).thenReturn(15.0);
        when(state.getBarWidth()).thenReturn(2.0);
        when(domainAxis.getCategoryEnd(2, 2, dataArea, plot.getDomainAxisEdge())).thenReturn(15.0);
        when(domainAxis.getCategoryStart(2, 2, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);

        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();

        // Act
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 2);

        // Assert
        verify(g2, atLeast(4)).draw(any(java.awt.Shape.class));
        // Additional verifications can be added to check specific shapes for outliers
    }
}