package org.jfree.chart.renderer.category;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.entity.EntityCollection;
import static org.mockito.Mockito.*;

public class LineAndShapeRenderer_drawItem_2_2_Test {

    @Test
    @DisplayName("drawItem does not draw shape when shape is not visible")
    void TC11_drawItem_doesNotDrawShapeWhenShapeNotVisible() {
        // GIVEN
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setUseSeriesOffset(false);
        renderer.setSeriesShapesVisible(0, false);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up mock behaviors
        // Fixed: Corrected usage. Now we directly set behavior properly using renderer itself.
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);

        // THEN
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

//     @Test
//     @DisplayName("drawItem adds item entity when entity collection is present")
//     void TC12_drawItem_addsItemEntityWhenEntityCollectionIsPresent() {
        // GIVEN
//         LineAndShapeRenderer renderer = new LineAndShapeRenderer();
//         renderer.setUseSeriesOffset(false);
//         renderer.setSeriesShapesVisible(0, true);
//         renderer.setSeriesShapesFilled(0, true);
//         renderer.setDrawOutlines(true);
// 
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         Shape shape = mock(Shape.class);
// 
        // Set up mock behaviors
//         when(renderer.getItemVisible(0, 0)).thenReturn(true);
//         when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
//         when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
//         when(dataset.getValue(0, 0)).thenReturn(10.0);
//         when(state.getVisibleSeriesIndex(0)).thenReturn(0);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(state.getEntityCollection()).thenReturn(entityCollection);
// 
        // Fix: Mock the behavior for getItemShape
//         when(renderer.getItemShape(0, 0)).thenReturn(shape);
// 
        // WHEN
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
// 
        // THEN
        // Realistically use addItemEntity for simulation
//         verify(entityCollection).addEntity(any(), eq(shape), eq(dataset), eq(0), eq(0));
//     }

    @Test
    @DisplayName("drawItem draws labeled item when item label is visible")
    void TC13_drawItem_drawsItemLabelWhenLabelIsVisible() {
        // GIVEN
        LineAndShapeRenderer renderer = spy(new LineAndShapeRenderer());
        renderer.setUseSeriesOffset(false);
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesShapesFilled(0, true);
        renderer.setDrawOutlines(true);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up mock behaviors
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Fix: Mock the behavior for getItemShape and color methods
        when(renderer.getItemShape(0, 0)).thenReturn(mock(Shape.class));
        when(renderer.getItemPaint(0, 0)).thenReturn(java.awt.Color.BLACK);
        when(renderer.getItemFillPaint(0, 0)).thenReturn(java.awt.Color.BLUE);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);

        // THEN
        verify(renderer).drawItemLabel(eq(g2), eq(PlotOrientation.VERTICAL), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble(), eq(false));
    }

    @Test
    @DisplayName("drawItem handles exception path gracefully")
    void TC14_drawItem_handlesExceptionPathGracefully() {
        // GIVEN
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setUseSeriesOffset(false);
        renderer.setSeriesLinesVisible(0, true);
        renderer.setSeriesShapesVisible(0, true);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up mock behaviors
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenThrow(new RuntimeException("Drawing error"));

        // WHEN & THEN
        Assertions.assertThrows(RuntimeException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }
}