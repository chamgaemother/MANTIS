package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_2_1_Test {

    @Test
    @DisplayName("metaphone word with 'DG' not followed by front vowel converts 'D' to 'T'")
    public void TC53() {
        // GIVEN
        String txt = "dog";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("TK", result);
    }

    @Test
    @DisplayName("metaphone word with 'GH' before a vowel converts correctly")
    public void TC54() {
        // GIVEN
        String txt = "ghoul";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("KL", result);
    }

    @Test
    @DisplayName("metaphone word with 'Y' followed by a consonant is silent")
    public void TC55() {
        // GIVEN
        String txt = "myth";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("M0", result);
    }

    @Test
    @DisplayName("metaphone word with 'Y' followed by a vowel is retained")
    public void TC56() {
        // GIVEN
        String txt = "year";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("YR", result);
    }

    @Test
    @DisplayName("metaphone word with multiple 'C's converts correctly without duplication")
    public void TC57() {
        // GIVEN
        String txt = "success";
        Metaphone metaphone = new Metaphone();

        // WHEN
        String result = metaphone.metaphone(txt);

        // THEN
        assertEquals("SKS", result);
    }
}