package org.apache.commons.math3.special;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Beta_regularizedBeta_0_1_Test {

    @Test
    @DisplayName("Input x is NaN, should return Double.NaN")
    public void TC01() {
        // GIVEN
        double x = Double.NaN;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("Input a is NaN, should return Double.NaN")
    public void TC02() {
        // GIVEN
        double x = 0.5;
        double a = Double.NaN;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("Input b is NaN, should return Double.NaN")
    public void TC03() {
        // GIVEN
        double x = 0.5;
        double a = 2.0;
        double b = Double.NaN;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("Input x is less than 0, should return Double.NaN")
    public void TC04() {
        // GIVEN
        double x = -0.1;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("Input x is greater than 1, should return Double.NaN")
    public void TC05() {
        // GIVEN
        double x = 1.1;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }
}