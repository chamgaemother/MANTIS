import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Stroke;
import java.util.Arrays;
import java.util.Collections;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.AbstractXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.Range;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.annotations.XYAnnotation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class XYPlotTest {

    @Mock
    private ValueAxis domainAxis0;

    @Mock
    private ValueAxis domainAxis1;

    @Mock
    private ValueAxis rangeAxis0;

    @Mock
    private ValueAxis rangeAxis1;

    @Mock
    private XYDataset dataset0;

    @Mock
    private XYDataset dataset1;

    @Mock
    private XYItemRenderer renderer0;

    @Mock
    private XYItemRenderer renderer1;

    @Mock
    private XYAnnotation annotationInclude;

    @Mock
    private XYAnnotation annotationExclude;

    @Mock
    private AbstractXYItemRenderer abstractRenderer;

    private XYPlot plot;

    @BeforeEach
    public void setUp() {
        plot = new XYPlot();
        plot.setDomainAxis(0, domainAxis0);
        plot.setDomainAxis(1, domainAxis1);
        plot.setRangeAxis(0, rangeAxis0);
        plot.setRangeAxis(1, rangeAxis1);
        plot.setDataset(0, dataset0);
        plot.setDataset(1, dataset1);
        plot.setRenderer(0, renderer0);
        plot.setRenderer(1, renderer1);
    }

    @Test
    public void testGetDataRange_NullAxis() {
        Range range = plot.getDataRange(null);
        assertNull(range);
    }

    @Test
    public void testGetDataRange_DomainAxis_Index0_WithAnnotations_Include() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        when(annotationInclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationInclude.getIncludeInDataBounds()).thenReturn(true);
        when(annotationInclude.getXRange()).thenReturn(new Range(2.0, 6.0));
        plot.addAnnotation(annotationInclude);
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 6.0), range);
    }

    @Test
    public void testGetDataRange_DomainAxis_Index0_WithAnnotations_Exclude() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        when(annotationExclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationExclude.getIncludeInDataBounds()).thenReturn(false);
        plot.addAnnotation(annotationExclude);
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 5.0), range);
    }

    @Test
    public void testGetDataRange_DomainAxis_Index0_NoAnnotations() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 5.0), range);
    }

    @Test
    public void testGetDataRange_DomainAxis_Index1_NoAnnotations() {
        when(domainAxis1.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis1)).thenReturn(1);
        when(plot.getDatasetsMappedToDomainAxis(1)).thenReturn(Arrays.asList(dataset1));
        when(renderer1.findDomainBounds(dataset1)).thenReturn(new Range(10.0, 20.0));
        
        Range range = plot.getDataRange(domainAxis1);
        assertNotNull(range);
        assertEquals(new Range(10.0, 20.0), range);
    }

    @Test
    public void testGetDataRange_RangeAxis_Index0_WithAnnotations_Include() {
        when(rangeAxis0.equals(any())).thenReturn(true);
        when(plot.getRangeAxisIndex(rangeAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToRangeAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findRangeBounds(dataset0)).thenReturn(new Range(100.0, 200.0));
        when(annotationInclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationInclude.getIncludeInDataBounds()).thenReturn(true);
        when(annotationInclude.getYRange()).thenReturn(new Range(150.0, 250.0));
        plot.addAnnotation(annotationInclude);
        
        Range range = plot.getDataRange(rangeAxis0);
        assertNotNull(range);
        assertEquals(new Range(100.0, 250.0), range);
    }

    @Test
    public void testGetDataRange_RangeAxis_Index0_WithAnnotations_Exclude() {
        when(rangeAxis0.equals(any())).thenReturn(true);
        when(plot.getRangeAxisIndex(rangeAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToRangeAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findRangeBounds(dataset0)).thenReturn(new Range(100.0, 200.0));
        when(annotationExclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationExclude.getIncludeInDataBounds()).thenReturn(false);
        plot.addAnnotation(annotationExclude);
        
        Range range = plot.getDataRange(rangeAxis0);
        assertNotNull(range);
        assertEquals(new Range(100.0, 200.0), range);
    }

    @Test
    public void testGetDataRange_RangeAxis_Index1_NoAnnotations() {
        when(rangeAxis1.equals(any())).thenReturn(true);
        when(plot.getRangeAxisIndex(rangeAxis1)).thenReturn(1);
        when(plot.getDatasetsMappedToRangeAxis(1)).thenReturn(Arrays.asList(dataset1));
        when(renderer1.findRangeBounds(dataset1)).thenReturn(new Range(300.0, 400.0));
        
        Range range = plot.getDataRange(rangeAxis1);
        assertNotNull(range);
        assertEquals(new Range(300.0, 400.0), range);
    }

    @Test
    public void testGetDataRange_AxisIsBothDomainAndRange() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(rangeAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getRangeAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(plot.getDatasetsMappedToRangeAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        when(renderer0.findRangeBounds(dataset0)).thenReturn(new Range(10.0, 50.0));
        when(annotationInclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationInclude.getIncludeInDataBounds()).thenReturn(true);
        when(annotationInclude.getXRange()).thenReturn(new Range(2.0, 6.0));
        when(annotationInclude.getYRange()).thenReturn(new Range(20.0, 60.0));
        plot.addAnnotation(annotationInclude);
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        // Since axis is treated as range axis last
        assertEquals(new Range(10.0, 60.0), range);
    }

    @Test
    public void testGetDataRange_RendererNull() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        plot.setRenderer(0, null);
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 5.0), range);
    }

    @Test
    public void testGetDataRange_RendererNotAbstract() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(renderer0.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        when(renderer0 instanceof AbstractXYItemRenderer).thenReturn(false);
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 5.0), range);
    }

    @Test
    public void testGetDataRange_RendererAbstract_WithAnnotations_Include() {
        plot.setRenderer(0, abstractRenderer);
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(abstractRenderer.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        when(abstractRenderer.getAnnotations()).thenReturn(Collections.singletonList(annotationInclude));
        when(annotationInclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationInclude.getIncludeInDataBounds()).thenReturn(true);
        when(annotationInclude.getXRange()).thenReturn(new Range(2.0, 6.0));
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 6.0), range);
    }

    @Test
    public void testGetDataRange_RendererAbstract_WithAnnotations_Exclude() {
        plot.setRenderer(0, abstractRenderer);
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(abstractRenderer.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        when(abstractRenderer.getAnnotations()).thenReturn(Arrays.asList(annotationInclude, annotationExclude));
        when(annotationInclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationInclude.getIncludeInDataBounds()).thenReturn(true);
        when(annotationInclude.getXRange()).thenReturn(new Range(2.0, 6.0));
        when(annotationExclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(true);
        when(annotationExclude.getIncludeInDataBounds()).thenReturn(false);
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 6.0), range);
    }

    @Test
    public void testGetDataRange_WithNullDataset() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList((XYDataset)null));
        
        Range range = plot.getDataRange(domainAxis0);
        assertNull(range);
    }

    @Test
    public void testGetDataRange_WithMultipleDatasets() {
        when(domainAxis0.equals(any())).thenReturn(true);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(0);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0, dataset1));
        when(renderer0.findDomainBounds(dataset0)).thenReturn(new Range(1.0, 5.0));
        when(renderer0.findDomainBounds(dataset1)).thenReturn(new Range(3.0, 7.0));
        plot.addAnnotation(annotationInclude);
        when(annotationInclude instanceof org.jfree.chart.annotations.XYAnnotationBoundsInfo).thenReturn(false);
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(1.0, 7.0), range);
    }

    @Test
    public void testGetDataRange_WithAxisNotMapped() {
        when(domainAxis0.equals(any())).thenReturn(false);
        when(rangeAxis0.equals(any())).thenReturn(false);
        when(plot.getDomainAxisIndex(domainAxis0)).thenReturn(-1);
        when(plot.getRangeAxisIndex(domainAxis0)).thenReturn(-1);
        when(plot.getDatasetsMappedToDomainAxis(0)).thenReturn(Arrays.asList(dataset0));
        when(plot.getDatasetsMappedToRangeAxis(0)).thenReturn(Arrays.asList(dataset0));
        
        Range range = plot.getDataRange(domainAxis0);
        assertNotNull(range);
        assertEquals(new Range(-1.0, 1.0), Range.combine(null, null));
    }

}