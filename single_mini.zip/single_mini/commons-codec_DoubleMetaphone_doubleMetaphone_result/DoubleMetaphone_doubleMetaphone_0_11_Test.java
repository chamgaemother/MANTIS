package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_11_Test {

    @Test
    @DisplayName("doubleMetaphone handles 'DD' sequence in 'WADDE'")
    public void TC51() {
        String value = "WADDE";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        assertTrue(result.contains("T"), "Expected encoded result to contain 'T'");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'H' between vowels in 'AHOY'")
    public void TC52() {
        String value = "AHOY";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        assertTrue(result.contains("H"), "Expected encoded result to contain 'H'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'G' followed by 'LI' in 'GLIECK'")
    public void TC53() {
        String value = "GLIECK";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        assertTrue(result.contains("KL") || result.contains("L"), "Expected encoded result to contain 'KL' or 'L'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'GY' sequence in 'GYM'")
    public void TC54() {
        String value = "GYM";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        assertTrue(result.contains("J"), "Expected encoded result to contain 'J'");
    }
}