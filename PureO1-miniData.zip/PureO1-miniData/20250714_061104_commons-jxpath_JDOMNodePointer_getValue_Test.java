import static org.junit.jupiter.api.Assertions.*;

import java.util.Locale;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer;
import org.jdom2.Comment;
import org.jdom2.CDATA;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.ProcessingInstruction;
import org.jdom2.Text;
import org.junit.jupiter.api.Test;

public class JDOMNodePointerTest {

    @Test
    void testGetValue_ElementWithNoChildren_ReturnsEmptyString() {
        Element element = new Element("root");
        JDOMNodePointer pointer = new JDOMNodePointer(element, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithTextChild_ReturnsTextContent() {
        Element parent = new Element("parent");
        Text text = new Text("Hello World");
        parent.addContent(text);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("Hello World", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithElementChild_ReturnsConcatenatedChildValues() {
        Element parent = new Element("parent");
        Element child1 = new Element("child1");
        child1.addContent(new Text("Child1Text"));
        Element child2 = new Element("child2");
        child2.addContent(new Text("Child2Text"));
        parent.addContent(child1);
        parent.addContent(child2);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("Child1TextChild2Text", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithMixedChildren_ReturnsCombinedText() {
        Element parent = new Element("parent");
        Element child1 = new Element("child1");
        child1.addContent(new Text("Child1"));
        Text text = new Text(" Some text ");
        CDATA cdata = new CDATA("CDATA content");
        parent.addContent(child1);
        parent.addContent(text);
        parent.addContent(cdata);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("Child1 Some text CDATA content", pointer.getValue());
    }

    @Test
    void testGetValue_CommentWithText_ReturnsTrimmedText() {
        Comment comment = new Comment("  This is a comment  ");
        JDOMNodePointer pointer = new JDOMNodePointer(comment, Locale.ENGLISH);
        assertEquals("This is a comment", pointer.getValue());
    }

    @Test
    void testGetValue_CommentWithNullText_ReturnsNull() {
        Comment comment = new Comment(null);
        JDOMNodePointer pointer = new JDOMNodePointer(comment, Locale.ENGLISH);
        assertNull(pointer.getValue());
    }

    @Test
    void testGetValue_TextWithTrim_ReturnsTrimmedText() {
        Element parent = new Element("parent");
        Text text = new Text("  Trimmed Text  ");
        parent.addContent(text);
        JDOMNodePointer pointer = new JDOMNodePointer(text, Locale.ENGLISH);
        assertEquals("Trimmed Text", pointer.getValue());
    }

    @Test
    void testGetValue_TextWithPreserveSpace_ReturnsUntrimmedText() {
        Element parent = new Element("parent");
        parent.setAttribute("space", "preserve", Namespace.XML_NAMESPACE);
        Text text = new Text("  Untrimmed Text  ");
        parent.addContent(text);
        JDOMNodePointer pointer = new JDOMNodePointer(text, Locale.ENGLISH);
        assertEquals("  Untrimmed Text  ", pointer.getValue());
    }

    @Test
    void testGetValue_ProcessingInstructionWithData_ReturnsTrimmedData() {
        Element parent = new Element("parent");
        ProcessingInstruction pi = new ProcessingInstruction("target", "  PI Data  ");
        parent.addContent(pi);
        JDOMNodePointer pointer = new JDOMNodePointer(pi, Locale.ENGLISH);
        assertEquals("PI Data", pointer.getValue());
    }

    @Test
    void testGetValue_ProcessingInstructionWithPreserveSpace_ReturnsUntrimmedData() {
        Element parent = new Element("parent");
        parent.setAttribute("space", "preserve", Namespace.XML_NAMESPACE);
        ProcessingInstruction pi = new ProcessingInstruction("target", "  Preserved PI Data  ");
        parent.addContent(pi);
        JDOMNodePointer pointer = new JDOMNodePointer(pi, Locale.ENGLISH);
        assertEquals("  Preserved PI Data  ", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithCDATAChild_ReturnsCDATAContent() {
        Element parent = new Element("parent");
        CDATA cdata = new CDATA("Some CDATA content");
        parent.addContent(cdata);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("Some CDATA content", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithMultipleTextChildren_ReturnsConcatenatedText() {
        Element parent = new Element("parent");
        Text text1 = new Text("First ");
        Text text2 = new Text("Second ");
        Text text3 = new Text("Third");
        parent.addContent(text1);
        parent.addContent(text2);
        parent.addContent(text3);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("First Second Third", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithNonTextualChildren_IgnoresNonTextual() {
        Element parent = new Element("parent");
        Element child = new Element("child");
        child.addContent(new Text("ChildText"));
        parent.addContent(child);
        parent.addContent(new Comment("Should be ignored"));
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("ChildText", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithEmptyTextChild_ReturnsEmptyString() {
        Element parent = new Element("parent");
        Text text = new Text("");
        parent.addContent(text);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithNullTextChild_ReturnsEmptyString() {
        Element parent = new Element("parent");
        Text text = new Text(null);
        parent.addContent(text);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithProcessingInstructionChild_ReturnsEmptyString() {
        Element parent = new Element("parent");
        ProcessingInstruction pi = new ProcessingInstruction("target", "Data");
        parent.addContent(pi);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithMixedContentAndPreserveSpace_ReturnsUntrimmedText() {
        Element parent = new Element("parent");
        parent.setAttribute("space", "preserve", Namespace.XML_NAMESPACE);
        Text text1 = new Text("  Text1  ");
        CDATA cdata = new CDATA("  CDATA Content  ");
        parent.addContent(text1);
        parent.addContent(cdata);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("  Text1  " + "  CDATA Content  ", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithMixedContentAndNonPreserveSpace_ReturnsTrimmedText() {
        Element parent = new Element("parent");
        parent.setAttribute("space", "default", Namespace.XML_NAMESPACE);
        Text text1 = new Text("  Text1  ");
        CDATA cdata = new CDATA("  CDATA Content  ");
        parent.addContent(text1);
        parent.addContent(cdata);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("Text1CDATA Content", pointer.getValue());
    }

    @Test
    void testGetValue_TextWithEmptyString_ReturnsEmptyString() {
        Text text = new Text("");
        JDOMNodePointer pointer = new JDOMNodePointer(text, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_TextWithOnlySpaces_ReturnsTrimmedEmptyString() {
        Text text = new Text("   ");
        JDOMNodePointer pointer = new JDOMNodePointer(text, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ProcessingInstructionWithEmptyData_ReturnsEmptyString() {
        ProcessingInstruction pi = new ProcessingInstruction("target", "");
        JDOMNodePointer pointer = new JDOMNodePointer(pi, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ProcessingInstructionWithOnlySpaces_ReturnsTrimmedEmptyString() {
        ProcessingInstruction pi = new ProcessingInstruction("target", "   ");
        JDOMNodePointer pointer = new JDOMNodePointer(pi, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithNestedElements_ReturnsConcatenatedNestedValues() {
        Element parent = new Element("parent");
        Element child1 = new Element("child1");
        child1.addContent(new Text("Child1 "));
        Element child2 = new Element("child2");
        child2.addContent(new Text("Child2"));
        parent.addContent(child1);
        parent.addContent(child2);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("Child1 Child2", pointer.getValue());
    }

    @Test
    void testGetValue_DocumentNodeWithRoot_ReturnsRootValue() {
        Element root = new Element("root");
        root.addContent(new Text("RootText"));
        Document doc = new Document(root);
        JDOMNodePointer pointer = new JDOMNodePointer(doc, Locale.ENGLISH);
        assertEquals("RootText", pointer.getValue());
    }

    @Test
    void testGetValue_DocumentNodeWithNoChildren_ReturnsEmptyString() {
        Document doc = new Document();
        JDOMNodePointer pointer = new JDOMNodePointer(doc, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithMultipleMixedChildren_ReturnsCombinedTrimmedText() {
        Element parent = new Element("parent");
        parent.setAttribute("space", "default", Namespace.XML_NAMESPACE);
        Element child1 = new Element("child1");
        child1.addContent(new Text(" Child1 "));
        Text text = new Text(" Text ");
        CDATA cdata = new CDATA(" CDATA ");
        parent.addContent(child1);
        parent.addContent(text);
        parent.addContent(cdata);
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("Child1 TextCDATA", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithNoRelevantChildren_ReturnsEmptyString() {
        Element parent = new Element("parent");
        parent.addContent(new Comment("A comment"));
        parent.addContent(new ProcessingInstruction("target", "data"));
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }

    @Test
    void testGetValue_ElementWithOnlyNonElementOrTextChildren_ReturnsEmptyString() {
        Element parent = new Element("parent");
        parent.addContent(new Comment("Comment"));
        parent.addContent(new ProcessingInstruction("pi", "data"));
        JDOMNodePointer pointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        assertEquals("", pointer.getValue());
    }
}