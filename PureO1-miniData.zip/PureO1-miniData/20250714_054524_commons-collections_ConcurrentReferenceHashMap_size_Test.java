import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;

import java.lang.ref.WeakReference;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.junit.jupiter.api.Assertions.*;

class ConcurrentReferenceHashMapTest {

    private ConcurrentReferenceHashMap<String, String> map;

    @BeforeEach
    void setUp() {
        map = ConcurrentReferenceHashMap.builder()
                .setInitialCapacity(16)
                .setLoadFactor(0.75f)
                .setConcurrencyLevel(16)
                .build();
    }

    @Test
    void testSizeEmptyMap() {
        assertEquals(0, map.size(), "Size of empty map should be 0");
        assertTrue(map.isEmpty(), "Map should be empty");
    }

    @Test
    void testSizeSingleElement() {
        map.put("key1", "value1");
        assertEquals(1, map.size(), "Size should be 1 after adding one element");
        assertFalse(map.isEmpty(), "Map should not be empty");
    }

    @Test
    void testSizeMultipleElements() {
        for (int i = 1; i <= 10; i++) {
            map.put("key" + i, "value" + i);
        }
        assertEquals(10, map.size(), "Size should be 10 after adding ten elements");
    }

    @Test
    void testSizeAfterRemovals() {
        for (int i = 1; i <= 5; i++) {
            map.put("key" + i, "value" + i);
        }
        assertEquals(5, map.size(), "Size should be 5 after adding five elements");
        map.remove("key1");
        map.remove("key2");
        assertEquals(3, map.size(), "Size should be 3 after removing two elements");
    }

    @Test
    void testSizeWithSoftKeys() {
        ConcurrentReferenceHashMap<String, String> softKeyMap = ConcurrentReferenceHashMap.builder()
                .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.SOFT)
                .build();
        softKeyMap.put(new String("softKey1"), "value1");
        softKeyMap.put(new String("softKey2"), "value2");
        assertEquals(2, softKeyMap.size(), "Size should be 2 after adding two soft keys");
    }

    @Test
    void testSizeWithWeakKeys() {
        ConcurrentReferenceHashMap<String, String> weakKeyMap = ConcurrentReferenceHashMap.builder()
                .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                .build();
        String key1 = new String("weakKey1");
        String key2 = new String("weakKey2");
        weakKeyMap.put(key1, "value1");
        weakKeyMap.put(key2, "value2");
        assertEquals(2, weakKeyMap.size(), "Size should be 2 after adding two weak keys");

        key1 = null;
        System.gc();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            // Ignore
        }
        weakKeyMap.purgeStaleEntries();
        assertEquals(1, weakKeyMap.size(), "Size should be 1 after GC and purging stale entries");
    }

    @Test
    void testSizeAfterPurgeStaleEntries() {
        ConcurrentReferenceHashMap<Object, String> purgingMap = ConcurrentReferenceHashMap.builder()
                .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
                .build();
        Object key1 = new Object();
        Object key2 = new Object();
        purgingMap.put(key1, "value1");
        purgingMap.put(key2, "value2");
        assertEquals(2, purgingMap.size(), "Size should be 2 after adding two entries");

        WeakReference<Object> ref1 = new WeakReference<>(key1);
        WeakReference<Object> ref2 = new WeakReference<>(key2);
        key1 = null;
        key2 = null;
        System.gc();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            // Ignore
        }
        purgingMap.purgeStaleEntries();
        int size = purgingMap.size();
        assertTrue(size <= 2 && size >= 0, "Size should be between 0 and 2 after GC and purging");
    }

    @Test
    void testSizeWithIdentityComparisons() {
        ConcurrentReferenceHashMap<String, String> identityMap = ConcurrentReferenceHashMap.builder()
                .setOptions(EnumSet.of(ConcurrentReferenceHashMap.Option.IDENTITY_COMPARISONS))
                .build();
        String key1a = new String("key1");
        String key1b = new String("key1");
        identityMap.put(key1a, "value1");
        identityMap.put(key1b, "value2");
        assertEquals(2, identityMap.size(), "Size should be 2 when using identity comparisons with identical keys");
    }

    @Test
    void testSizeWithConcurrency() throws InterruptedException {
        int threadCount = 10;
        int operationsPerThread = 1000;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);
        ConcurrentReferenceHashMap<Integer, Integer> concurrentMap = ConcurrentReferenceHashMap.builder()
                .setConcurrencyLevel(16)
                .build();

        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.execute(() -> {
                for (int j = 0; j < operationsPerThread; j++) {
                    concurrentMap.put(threadId * operationsPerThread + j, j);
                }
                latch.countDown();
            });
        }

        latch.await();
        executor.shutdown();
        assertEquals(threadCount * operationsPerThread, concurrentMap.size(),
                "Size should be equal to total number of put operations");
    }

    @Test
    void testSizeAfterConcurrentModifications() throws InterruptedException {
        int initialSize = 1000;
        for (int i = 0; i < initialSize; i++) {
            map.put("key" + i, "value" + i);
        }
        assertEquals(initialSize, map.size(), "Initial size should be 1000");

        ExecutorService executor = Executors.newFixedThreadPool(2);
        CountDownLatch latch = new CountDownLatch(2);

        // Thread 1 removes elements
        executor.execute(() -> {
            for (int i = 0; i < initialSize / 2; i++) {
                map.remove("key" + i);
            }
            latch.countDown();
        });

        // Thread 2 adds elements
        executor.execute(() -> {
            for (int i = initialSize; i < initialSize + 500; i++) {
                map.put("key" + i, "value" + i);
            }
            latch.countDown();
        });

        latch.await();
        executor.shutdown();
        assertEquals(initialSize - (initialSize / 2) + 500, map.size(),
                "Size should reflect removals and additions");
    }
}