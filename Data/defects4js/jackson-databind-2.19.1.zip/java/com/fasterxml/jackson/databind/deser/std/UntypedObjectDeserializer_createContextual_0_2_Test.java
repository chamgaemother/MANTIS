package com.fasterxml.jackson.databind.deser.std;
import java.lang.reflect.*;
import java.io.*;

import java.lang.reflect.Field;
import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.KeyDeserializer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class UntypedObjectDeserializer_createContextual_0_2_Test {

    @Test
    @DisplayName("createContextual with preventMerge differs from _nonMerging")
    void TC06_createContextual_with_preventMerge_differs_from_nonMerging() throws Exception {
        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer();

        Field nonMergingField = UntypedObjectDeserializer.class.getDeclaredField("_nonMerging");
        nonMergingField.setAccessible(true);
        nonMergingField.set(deserializer, false);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = null; // Fixed error: property should be null for this test

        DeserializationConfig config = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(config);
        when(config.getDefaultMergeable(Object.class)).thenReturn(false);

        when(ctxt.constructType(Object.class)).thenReturn(null);
        when(ctxt.findKeyDeserializer(null, property)).thenReturn(null);

        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        Field resultNonMergingField = UntypedObjectDeserializer.class.getDeclaredField("_nonMerging");
        resultNonMergingField.setAccessible(true);
        boolean newNonMerging = (boolean) resultNonMergingField.get(result);

        assertTrue(newNonMerging, "The new deserializer should have preventMerge=true");
        assertNotSame(deserializer, result, "A new UntypedObjectDeserializer instance should be created");
    }

    @Test
    @DisplayName("createContextual with preventMerge equals _nonMerging")
    void TC07_createContextual_with_preventMerge_equals_nonMerging() throws Exception {
        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer();

        Field nonMergingField = UntypedObjectDeserializer.class.getDeclaredField("_nonMerging");
        nonMergingField.setAccessible(true);
        nonMergingField.set(deserializer, false);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = null; // Fixed error: property should be null for this test

        DeserializationConfig config = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(config);
        when(config.getDefaultMergeable(Object.class)).thenReturn(false);

        when(ctxt.constructType(Object.class)).thenReturn(null);
        when(ctxt.findKeyDeserializer(null, property)).thenReturn(null);

        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        assertSame(deserializer, result, "The same UntypedObjectDeserializer instance should be returned");
    }

    @Test
    @DisplayName("createContextual when customKeyDeserializer is null")
    void TC08_createContextual_when_customKeyDeserializer_is_null() throws Exception {
        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer();

        Field stringDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_stringDeserializer");
        stringDeserializerField.setAccessible(true);
        stringDeserializerField.set(deserializer, null);

        Field numberDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_numberDeserializer");
        numberDeserializerField.setAccessible(true);
        numberDeserializerField.set(deserializer, null);

        Field mapDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_mapDeserializer");
        mapDeserializerField.setAccessible(true);
        mapDeserializerField.set(deserializer, null);

        Field listDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_listDeserializer");
        listDeserializerField.setAccessible(true);
        listDeserializerField.set(deserializer, null);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = null; // Fixed error: property should be null for this test

        DeserializationConfig config = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(config);
        when(config.getDefaultMergeable(Object.class)).thenReturn(true);

        when(ctxt.constructType(Object.class)).thenReturn(null);
        when(ctxt.findKeyDeserializer(null, property)).thenReturn(null);

        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        assertNotSame(deserializer, result, "A new UntypedObjectDeserializer instance should be created");
    }

    @Test
    @DisplayName("createContextual with getClass not equal to UntypedObjectDeserializer")
    void TC09_createContextual_with_getClass_not_equal_to_UntypedObjectDeserializer() throws Exception {
        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer() {};

        Field nonMergingField = UntypedObjectDeserializer.class.getDeclaredField("_nonMerging");
        nonMergingField.setAccessible(true);
        nonMergingField.set(deserializer, false);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = null; // Fixed error: property should be null for this test

        DeserializationConfig config = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(config);
        when(config.getDefaultMergeable(Object.class)).thenReturn(false);

        KeyDeserializer mockKeyDeserializer = mock(KeyDeserializer.class);
        when(ctxt.constructType(Object.class)).thenReturn(null);
        when(ctxt.findKeyDeserializer(null, property)).thenReturn(mockKeyDeserializer);

        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        assertNotSame(UntypedObjectDeserializerNR.instance(true), result, "A customized UntypedObjectDeserializer instance should be returned");
    }

    @Test
    @DisplayName("createContextual with non-null _stringDeserializer")
    void TC10_createContextual_with_non_null_stringDeserializer() throws Exception {
        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer();

        Field stringDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_stringDeserializer");
        stringDeserializerField.setAccessible(true);
        JsonDeserializer<?> mockStringDeserializer = mock(JsonDeserializer.class);
        stringDeserializerField.set(deserializer, mockStringDeserializer);

        Field numberDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_numberDeserializer");
        numberDeserializerField.setAccessible(true);
        numberDeserializerField.set(deserializer, null);

        Field mapDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_mapDeserializer");
        mapDeserializerField.setAccessible(true);
        mapDeserializerField.set(deserializer, null);

        Field listDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_listDeserializer");
        listDeserializerField.setAccessible(true);
        listDeserializerField.set(deserializer, null);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = null; // Fixed error: property should be null for this test

        DeserializationConfig config = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(config);
        when(config.getDefaultMergeable(Object.class)).thenReturn(true);

        when(ctxt.constructType(Object.class)).thenReturn(null);
        when(ctxt.findKeyDeserializer(null, property)).thenReturn(null);

        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        assertNotSame(deserializer, result, "A new UntypedObjectDeserializer instance should be created");

        Field resultStringDeserializerField = UntypedObjectDeserializer.class.getDeclaredField("_stringDeserializer");
        resultStringDeserializerField.setAccessible(true);
        JsonDeserializer<?> resultStringDeserializer = (JsonDeserializer<?>) resultStringDeserializerField.get(result);

        assertNotNull(resultStringDeserializer, "The new deserializer should have _stringDeserializer set");
        assertNotSame(mockStringDeserializer, resultStringDeserializer, "The _stringDeserializer should be customized if necessary");
    }
}