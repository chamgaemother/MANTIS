package org.apache.commons.math3.ode.nonstiff;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.linear.Array2DRowFieldMatrix;
import org.apache.commons.math3.util.Decimal64;
import org.apache.commons.math3.util.Decimal64Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AdamsNordsieckFieldTransformer_initializeHighOrderDerivatives_0_1_Test {

    @Test
    @DisplayName("initializeHighOrderDerivatives with typical positive step size and multiple time steps")
    public void TC01_typical_initialization() {
        // GIVEN
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 h = field.getOne(); // h = 1.0
        Decimal64 t0 = field.getZero(); // t0 = 0.0
        Decimal64 t1 = field.getOne().add(field.getOne()); // t1 = 2.0
        Decimal64 t2 = field.getOne().add(t1); // t2 = 3.0
        Decimal64[] t = new Decimal64[] { t0, t1, t2 };

        Decimal64 y0 = field.getZero(); // y0 = 0.0
        Decimal64 y1 = field.getOne();  // y1 = 1.0
        Decimal64 y2 = field.getOne().add(field.getOne()); // y2 = 2.0
        Decimal64[][] y = new Decimal64[][] { { y0 }, { y1 }, { y2 } };

        Decimal64 yDot0 = field.getOne(); // yDot0 = 1.0
        Decimal64 yDot1 = field.getOne().add(field.getOne()); // yDot1 = 2.0
        Decimal64 yDot2 = field.getOne().add(yDot1); // yDot2 = 3.0
        Decimal64[][] yDot = new Decimal64[][] { { yDot0 }, { yDot1 }, { yDot2 } };

        AdamsNordsieckFieldTransformer<Decimal64> transformer = AdamsNordsieckFieldTransformer.getInstance(field, 2);

        // WHEN
        Array2DRowFieldMatrix<Decimal64> result = transformer.initializeHighOrderDerivatives(h, t, y, yDot);

        // THEN
        assertNotNull(result, "Resulting high order derivatives matrix should not be null.");
        // Additional assertions can be added here to verify the correctness of the matrix.
    }

    @Test
    @DisplayName("initializeHighOrderDerivatives with zero step size h resulting in division by zero")
    public void TC02_zero_step_size() {
        // GIVEN
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 h = field.getZero(); // h = 0.0
        Decimal64 t0 = field.getZero();
        Decimal64 t1 = field.getOne();
        Decimal64[] t = new Decimal64[] { t0, t1 };

        Decimal64 y0 = field.getZero();
        Decimal64 y1 = field.getOne();
        Decimal64[][] y = new Decimal64[][] { { y0 }, { y1 } };

        Decimal64 yDot0 = field.getOne();
        Decimal64 yDot1 = field.getOne().add(field.getOne());
        Decimal64[][] yDot = new Decimal64[][] { { yDot0 }, { yDot1 } };

        AdamsNordsieckFieldTransformer<Decimal64> transformer = AdamsNordsieckFieldTransformer.getInstance(field, 1);

        // WHEN & THEN
        assertThrows(MathArithmeticException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected ArithmeticException due to division by zero when step size h is zero.");
    }

    @Test
    @DisplayName("initializeHighOrderDerivatives with empty time array t leading to invalid computation")
    public void TC03_empty_time_array() {
        // GIVEN
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 h = field.getOne(); // h = 1.0
        Decimal64[] t = new Decimal64[] {}; // Empty time array

        Decimal64[][] y = new Decimal64[][] {};
        Decimal64[][] yDot = new Decimal64[][] {};

        AdamsNordsieckFieldTransformer<Decimal64> transformer = AdamsNordsieckFieldTransformer.getInstance(field, 0);

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected IllegalArgumentException due to empty time array t.");
    }

    @Test
    @DisplayName("initializeHighOrderDerivatives with mismatched y and yDot array lengths")
    public void TC04_mismatched_y_yDot_lengths() {
        // GIVEN
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 h = field.getOne(); // h = 1.0
        Decimal64 t0 = field.getZero();
        Decimal64 t1 = field.getOne();
        Decimal64 t2 = field.getOne().add(field.getOne());
        Decimal64[] t = new Decimal64[] { t0, t1, t2 };

        Decimal64 y0 = field.getZero();
        Decimal64 y1 = field.getOne();
        Decimal64 y2 = field.getOne().add(field.getOne());
        Decimal64[][] y = new Decimal64[][] { { y0 }, { y1 }, { y2 } };

        Decimal64 yDot0 = field.getOne();
        Decimal64 yDot1 = field.getOne().add(field.getOne());
        Decimal64[][] yDot = new Decimal64[][] { { yDot0 }, { yDot1 } }; // Mismatched length

        AdamsNordsieckFieldTransformer<Decimal64> transformer = AdamsNordsieckFieldTransformer.getInstance(field, 2);

        // WHEN & THEN
        assertThrows(DimensionMismatchException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected DimensionMismatchException due to mismatched lengths of y and yDot arrays.");
    }

    @Test
    @DisplayName("initializeHighOrderDerivatives with single time step resulting in minimal iteration")
    public void TC05_single_time_step() {
        // GIVEN
        Decimal64Field field = Decimal64Field.getInstance();
        Decimal64 h = field.getOne(); // h = 1.0
        Decimal64 t0 = field.getZero(); // t0 = 0.0
        Decimal64 t1 = field.getOne();  // t1 = 1.0
        Decimal64[] t = new Decimal64[] { t0, t1 }; // Single time step

        Decimal64 y0 = field.getZero(); // y0 = 0.0
        Decimal64 y1 = field.getOne();  // y1 = 1.0
        Decimal64[][] y = new Decimal64[][] { { y0 }, { y1 } };

        Decimal64 yDot0 = field.getOne(); // yDot0 = 1.0
        Decimal64 yDot1 = field.getOne().add(field.getOne()); // yDot1 = 2.0
        Decimal64[][] yDot = new Decimal64[][] { { yDot0 }, { yDot1 } };

        AdamsNordsieckFieldTransformer<Decimal64> transformer = AdamsNordsieckFieldTransformer.getInstance(field, 1);

        // WHEN
        Array2DRowFieldMatrix<Decimal64> result = transformer.initializeHighOrderDerivatives(h, t, y, yDot);

        // THEN
        assertNotNull(result, "Resulting high order derivatives matrix should not be null.");
        // Additional assertions can be added here to verify the matrix contents with minimal iterations.
    }
}