package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.awt.geom.Ellipse2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

public class XYBoxAndWhiskerRenderer_drawHorizontalItem_0_1_Test {

    @Test
    @DisplayName("TC01: r0 is null and yAverage is null, fillBox is true, and box width defaults to minimum")
    void TC01_drawHorizontalItem_nullInfo_nullYAverage_fillBoxTrue_minWidth() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = null;
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 0;
        
        // Mock dataset behavior
        BoxAndWhiskerXYDataset boxDataset = (BoxAndWhiskerXYDataset) dataset;
        when(boxDataset.getX(series, item)).thenReturn(10);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(5);
        when(boxDataset.getMedianValue(series, item)).thenReturn(12);
        when(boxDataset.getMeanValue(series, item)).thenReturn(null);
        when(boxDataset.getQ1Value(series, item)).thenReturn(8);
        when(boxDataset.getQ3Value(series, item)).thenReturn(16);
        when(boxDataset.getItemCount(series)).thenReturn(10);
        
        // Set renderer properties
        renderer.setFillBox(true);
        
        // WHEN
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
        
        // THEN
        // Verify that setPaint and setStroke are called with expected values
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        
        // Additional verifications can be added based on the method's behavior
        // Since drawing operations are graphical, we can verify that certain draw methods are called
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
        verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
        
        // Ensure method completes without exceptions
    }

    @Test
    @DisplayName("TC02: r0 is not null, yAverage is provided, fillBox is false, and box width is within limits")
    void TC02_drawHorizontalItem_nonNullInfo_yAverage_present_fillBoxFalse_boxWidthWithinLimits() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 1;
        
        // Mock dataset behavior
        BoxAndWhiskerXYDataset boxDataset = (BoxAndWhiskerXYDataset) dataset;
        when(boxDataset.getX(series, item)).thenReturn(15);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(25);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(10);
        when(boxDataset.getMedianValue(series, item)).thenReturn(18);
        when(boxDataset.getMeanValue(series, item)).thenReturn(17);
        when(boxDataset.getQ1Value(series, item)).thenReturn(14);
        when(boxDataset.getQ3Value(series, item)).thenReturn(20);
        when(boxDataset.getItemCount(series)).thenReturn(10);
        
        // Mock axis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);
        
        // Mock PlotRenderingInfo behavior
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(mock(org.jfree.chart.entity.EntityCollection.class));
        
        // Set renderer properties
        renderer.setFillBox(false);
        
        // WHEN
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
        
        // THEN
        // Verify that setPaint and setStroke are called with expected values
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        
        // Verify that average marker is drawn
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).draw(any(Ellipse2D.class));
        
        // Verify that box is not filled
        verify(g2, never()).fill(any(Rectangle2D.class));
        
        // Ensure method completes without exceptions
    }

    @Test
    @DisplayName("TC03: r0 is not null, yAverage is provided but outside data area, fillBox is true")
    void TC03_drawHorizontalItem_yAverageOutsideDataArea_fillBoxTrue() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 2;
        int item = 2;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 2;
        
        // Mock dataset behavior
        BoxAndWhiskerXYDataset boxDataset = (BoxAndWhiskerXYDataset) dataset;
        when(boxDataset.getX(series, item)).thenReturn(20);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(30);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(15);
        when(boxDataset.getMedianValue(series, item)).thenReturn(22);
        when(boxDataset.getMeanValue(series, item)).thenReturn(21);
        when(boxDataset.getQ1Value(series, item)).thenReturn(18);
        when(boxDataset.getQ3Value(series, item)).thenReturn(24);
        when(boxDataset.getItemCount(series)).thenReturn(10);
        
        // Mock axis behavior to place yAverage outside dataArea
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(eq(21.0), eq(dataArea), any())).thenReturn(-50.0); // Outside dataArea
        
        // Mock PlotRenderingInfo behavior
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(mock(org.jfree.chart.entity.EntityCollection.class));
        
        // Mock dataArea bounds
        when(dataArea.getMinX()).thenReturn(0.0);
        when(dataArea.getMaxX()).thenReturn(100.0);
        
        // Set renderer properties
        renderer.setFillBox(true);
        
        // WHEN
        renderer.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
        
        // THEN
        // Verify that setPaint and setStroke are called
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        
        // Verify that average marker is not drawn
        verify(g2, never()).fill(any(Ellipse2D.class));
        verify(g2, never()).draw(any(Ellipse2D.class));
        
        // Verify that box is filled
        verify(g2).fill(any(Rectangle2D.class));
        
        // Ensure method completes without exceptions
    }

    @Test
    @DisplayName("TC04: r0 is not null, yAverage is not null, fillBox is true, exactBoxWidth exceeds max limit")
    void TC04_drawHorizontalItem_boxWidthExceeds_maxLimit() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 3;
        int item = 3;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 3;
        
        // Mock dataset behavior
        BoxAndWhiskerXYDataset boxDataset = (BoxAndWhiskerXYDataset) dataset;
        when(boxDataset.getX(series, item)).thenReturn(25);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(35);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(20);
        when(boxDataset.getMedianValue(series, item)).thenReturn(28);
        when(boxDataset.getMeanValue(series, item)).thenReturn(27);
        when(boxDataset.getQ1Value(series, item)).thenReturn(23);
        when(boxDataset.getQ3Value(series, item)).thenReturn(30);
        when(boxDataset.getItemCount(series)).thenReturn(10);
        
        // Mock axis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(250.0);
        
        // Mock PlotRenderingInfo behavior
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(mock(org.jfree.chart.entity.EntityCollection.class));
        
        // Mock dataArea dimensions to simulate maxBoxWidth
        when(dataArea.getHeight()).thenReturn(100.0);
        
        // Mock getBoxWidth to return a value exceeding maxBoxWidth
        XYBoxAndWhiskerRenderer rendererSpy = spy(renderer);
        doReturn(20.0).when(rendererSpy).getBoxWidth(); // Assume maxBoxWidth is 10.0
        
        // Set renderer properties
        rendererSpy.setFillBox(true);
        
        // WHEN
        rendererSpy.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
        
        // THEN
        // Verify that box width is capped at maxBoxWidth
        // Since exactBoxWidth is mocked to 20 and maxBoxWidth is 10 (dataAreaX * 0.1 = 10), width should be 10
        // Cannot directly verify width, but can verify that drawing methods are called with expected parameters
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
        verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).fill(any(Ellipse2D.class));
        verify(g2).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("TC05: r0 is not null, yAverage is null, fillBox is false, exactBoxWidth is zero leading to default width")
    void TC05_drawHorizontalItem_exactBoxWidthZero_yAverageNull_fillBoxFalse_defaultWidth() throws Exception {
        // GIVEN
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 4;
        int item = 4;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int rendererIndex = 4;
        
        // Mock dataset behavior
        BoxAndWhiskerXYDataset boxDataset = (BoxAndWhiskerXYDataset) dataset;
        when(boxDataset.getX(series, item)).thenReturn(30);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(40);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(25);
        when(boxDataset.getMedianValue(series, item)).thenReturn(32);
        when(boxDataset.getMeanValue(series, item)).thenReturn(null);
        when(boxDataset.getQ1Value(series, item)).thenReturn(28);
        when(boxDataset.getQ3Value(series, item)).thenReturn(35);
        when(boxDataset.getItemCount(series)).thenReturn(10);
        
        // Mock axis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(250.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(300.0);
        
        // Mock PlotRenderingInfo behavior
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(mock(org.jfree.chart.entity.EntityCollection.class));
        
        // Mock getBoxWidth to return zero
        XYBoxAndWhiskerRenderer rendererSpy = spy(renderer);
        doReturn(0.0).when(rendererSpy).getBoxWidth();
        
        // Set renderer properties
        rendererSpy.setFillBox(false);
        
        // WHEN
        rendererSpy.drawHorizontalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, rendererIndex);
        
        // THEN
        // Verify that default width is set (expected to be 3)
        // Verify that box outline is drawn
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
        verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
        verify(g2, never()).fill(any(Ellipse2D.class));
        verify(g2, never()).fill(any(Rectangle2D.class));
    }
}