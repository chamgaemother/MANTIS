package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class MathArrays_safeNorm_1_1_Test {

    @Test
    @DisplayName("safeNorm with array containing NaN results in NaN norm")
    public void TC21_safeNorm_with_NaN_in_array() {
        // GIVEN
        double[] v = {1.0, Double.NaN, 3.0};
        // WHEN
        double result = MathArrays.safeNorm(v);
        // THEN
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("safeNorm with array containing positive Infinity results in Infinity norm")
    public void TC22_safeNorm_with_Positive_Infinity_in_array() {
        // GIVEN
        double[] v = {1.0, Double.POSITIVE_INFINITY, 3.0};
        // WHEN
        double result = MathArrays.safeNorm(v);
        // THEN
        assertTrue(Double.isInfinite(result) && result > 0);
    }

    @Test
    @DisplayName("safeNorm with array containing negative Infinity results in Infinity norm")
    public void TC23_safeNorm_with_Negative_Infinity_in_array() {
        // GIVEN
        double[] v = {1.0, Double.NEGATIVE_INFINITY, 3.0};
        // WHEN
        double result = MathArrays.safeNorm(v);
        // THEN
        assertTrue(Double.isInfinite(result) && result < 0);
    }
}