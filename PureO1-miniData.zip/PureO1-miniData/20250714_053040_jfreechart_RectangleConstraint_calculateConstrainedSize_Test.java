package org.jfree.chart.block;

import static org.junit.jupiter.api.Assertions.*;

import org.jfree.chart.ui.Size2D;
import org.jfree.data.Range;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class RectangleConstraintTest {

    @Test
    public void testCalculateConstrainedSize_NoConstraints() {
        RectangleConstraint constraint = RectangleConstraint.NONE;
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(100.0, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_FixedWidthFixedHeight() {
        RectangleConstraint constraint = new RectangleConstraint(150.0, 250.0);
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(150.0, result.width, 0.0001);
        assertEquals(250.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_FixedWidth_NoHeightConstraint() {
        RectangleConstraint constraint = new RectangleConstraint(150.0, new Range(0.0, null), LengthConstraintType.FIXED, 0.0, null, LengthConstraintType.NONE);
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(constraint.toFixedWidth(150.0).calculateConstrainedSize(base));
        assertEquals(150.0, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_NoWidthConstraint_FixedHeight() {
        RectangleConstraint constraint = RectangleConstraint.NONE.toFixedHeight(300.0);
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(100.0, result.width, 0.0001);
        assertEquals(300.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_RangeWidth_WithinRange_NoHeightConstraint() {
        Range widthRange = new Range(50.0, 150.0);
        RectangleConstraint constraint = new RectangleConstraint(widthRange, RectangleConstraint.NONE.getHeightRange());
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(100.0, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_RangeWidth_BelowRange_NoHeightConstraint() {
        Range widthRange = new Range(50.0, 150.0);
        RectangleConstraint constraint = new RectangleConstraint(widthRange, RectangleConstraint.NONE.getHeightRange());
        Size2D base = new Size2D(30.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(50.0, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_RangeWidth_AboveRange_NoHeightConstraint() {
        Range widthRange = new Range(50.0, 150.0);
        RectangleConstraint constraint = new RectangleConstraint(widthRange, RectangleConstraint.NONE.getHeightRange());
        Size2D base = new Size2D(200.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(150.0, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_NoWidthConstraint_RangeHeight_WithinRange() {
        Range heightRange = new Range(100.0, 300.0);
        RectangleConstraint constraint = new RectangleConstraint(RectangleConstraint.NONE.getWidthRange(), heightRange, LengthConstraintType.RANGE);
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(100.0, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_NoWidthConstraint_RangeHeight_BelowRange() {
        Range heightRange = new Range(100.0, 300.0);
        RectangleConstraint constraint = new RectangleConstraint(RectangleConstraint.NONE.getWidthRange(), heightRange, LengthConstraintType.RANGE);
        Size2D base = new Size2D(100.0, 50.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(100.0, result.width, 0.0001);
        assertEquals(100.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_NoWidthConstraint_RangeHeight_AboveRange() {
        Range heightRange = new Range(100.0, 300.0);
        RectangleConstraint constraint = new RectangleConstraint(RectangleConstraint.NONE.getWidthRange(), heightRange, LengthConstraintType.RANGE);
        Size2D base = new Size2D(100.0, 400.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(100.0, result.width, 0.0001);
        assertEquals(300.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_FixedWidth_RangeHeight() {
        Range heightRange = new Range(100.0, 300.0);
        RectangleConstraint constraint = new RectangleConstraint(150.0, heightRange, LengthConstraintType.FIXED, LengthConstraintType.RANGE);
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(150.0, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_FixedWidth_RangeHeight_Below() {
        Range heightRange = new Range(100.0, 300.0);
        RectangleConstraint constraint = new RectangleConstraint(150.0, heightRange, LengthConstraintType.FIXED, LengthConstraintType.RANGE);
        Size2D base = new Size2D(100.0, 50.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(150.0, result.width, 0.0001);
        assertEquals(100.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_FixedWidth_RangeHeight_Above() {
        Range heightRange = new Range(100.0, 300.0);
        RectangleConstraint constraint = new RectangleConstraint(150.0, heightRange, LengthConstraintType.FIXED, LengthConstraintType.RANGE);
        Size2D base = new Size2D(100.0, 400.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(150.0, result.width, 0.0001);
        assertEquals(300.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_FixedWidth_FixedHeight() {
        RectangleConstraint constraint = new RectangleConstraint(150.0, 250.0);
        Size2D base = new Size2D(100.0, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(150.0, result.width, 0.0001);
        assertEquals(250.0, result.height, 0.0001);
    }

    @Test
    public void testCalculateConstrainedSize_NullBase() {
        RectangleConstraint constraint = RectangleConstraint.NONE;
        assertThrows(NullPointerException.class, () -> {
            constraint.calculateConstrainedSize(null);
        });
    }

    @ParameterizedTest
    @ValueSource(doubles = {50.0, 150.0})
    public void testCalculateConstrainedSize_RangeWidth_BoundaryValues(double width) {
        Range widthRange = new Range(50.0, 150.0);
        RectangleConstraint constraint = new RectangleConstraint(widthRange, RectangleConstraint.NONE.getHeightRange());
        Size2D base = new Size2D(width, 200.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(width, result.width, 0.0001);
        assertEquals(200.0, result.height, 0.0001);
    }

    @ParameterizedTest
    @ValueSource(doubles = {100.0, 300.0})
    public void testCalculateConstrainedSize_RangeHeight_BoundaryValues(double height) {
        Range heightRange = new Range(100.0, 300.0);
        RectangleConstraint constraint = new RectangleConstraint(RectangleConstraint.NONE.getWidthRange(), heightRange, LengthConstraintType.RANGE);
        Size2D base = new Size2D(100.0, height);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(100.0, result.width, 0.0001);
        assertEquals(height, result.height, 0.0001);
    }
}