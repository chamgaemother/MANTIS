package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseReleased_0_6_Test {

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, zoomTrigger1 true, zoomTrigger2 true, but z6 false leading to no restoreAutoBounds")
    public void TC26_mouseReleased_Horizontal_ZoomTrigger1_True_ZoomTrigger2_True_Z6_False() throws Exception {
        // Arrange
        ChartPanel panel = Mockito.spy(new ChartPanel(null));

        // Set private fields via reflection
        setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(10, 10, 100, 100));
        setPrivateField(panel, "orientation", PlotOrientation.HORIZONTAL);
        setPrivateField(panel, "rangeZoomable", true);
        setPrivateField(panel, "domainZoomable", true);
        setPrivateField(panel, "zoomTriggerDistance", 5);

        // Mock MouseEvent
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(20);
        when(event.getY()).thenReturn(20);
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock zoomPoint
        setPrivateField(panel, "zoomPoint", new Point2D.Double(10, 10));

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that restoreAutoBounds is not called
        verify(panel, never()).restoreAutoBounds();

        // Verify that zoom is performed
        verify(panel, times(1)).zoom(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, all conditions false leading to no actions")
    public void TC27_mouseReleased_All_Zoom_Conditions_False() throws Exception {
        // Arrange
        ChartPanel panel = Mockito.spy(new ChartPanel(null));

        // Set private fields via reflection
        setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(10, 10, 100, 100));
        setPrivateField(panel, "orientation", PlotOrientation.HORIZONTAL);
        setPrivateField(panel, "rangeZoomable", false);
        setPrivateField(panel, "domainZoomable", false);
        setPrivateField(panel, "zoomTriggerDistance", 5);

        // Mock MouseEvent
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(12);
        when(event.getY()).thenReturn(12);
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock zoomPoint
        setPrivateField(panel, "zoomPoint", new Point2D.Double(10, 10));

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that restoreAutoBounds is not called
        verify(panel, never()).restoreAutoBounds();

        // Verify that zoom is not performed
        verify(panel, never()).zoom(any(Rectangle2D.class));

        // Verify that zoomRectangle is erased by checking repaint is called
        verify(panel, times(1)).repaint();
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, zoomTrigger1 true, but hZoom false leading to restoreAutoBounds not called")
    public void TC28_mouseReleased_Horizontal_Orientation_HZoom_False() throws Exception {
        // Arrange
        ChartPanel panel = Mockito.spy(new ChartPanel(null));

        // Set private fields via reflection
        setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(10, 10, 100, 100));
        setPrivateField(panel, "orientation", PlotOrientation.HORIZONTAL);
        setPrivateField(panel, "rangeZoomable", false);
        setPrivateField(panel, "domainZoomable", true);
        setPrivateField(panel, "zoomTriggerDistance", 5);

        // Mock MouseEvent
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(20);
        when(event.getY()).thenReturn(20);
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock zoomPoint
        setPrivateField(panel, "zoomPoint", new Point2D.Double(10, 10));

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that restoreAutoBounds is not called
        verify(panel, never()).restoreAutoBounds();

        // Verify that zoom is performed
        verify(panel, times(1)).zoom(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation VERTICAL, zoomTrigger1 false, zoomTrigger2 true, hZoom false")
    public void TC29_mouseReleased_Vertical_Orientation_VZoom_Only() throws Exception {
        // Arrange
        ChartPanel panel = Mockito.spy(new ChartPanel(null));

        // Set private fields via reflection
        setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(10, 10, 100, 100));
        setPrivateField(panel, "orientation", PlotOrientation.VERTICAL);
        setPrivateField(panel, "zoomTriggerDistance", 5);

        // Set zoomable fields
        setPrivateField(panel, "rangeZoomable", true); // vZoom
        setPrivateField(panel, "domainZoomable", true); // hZoom set to false later

        // Mock MouseEvent
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(12); // zoomTrigger1 = false
        when(event.getY()).thenReturn(20); // zoomTrigger2 = true
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock zoomPoint
        setPrivateField(panel, "zoomPoint", new Point2D.Double(10, 10));

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoom is performed based on Y-axis only
        verify(panel, times(1)).zoom(any(Rectangle2D.class));

        // Verify that restoreAutoBounds is not called
        verify(panel, never()).restoreAutoBounds();
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, both zoomable true, zoomTrigger1 false, zoomTrigger2 true")
    public void TC30_mouseReleased_Horizontal_Orientation_VZoom_Only() throws Exception {
        // Arrange
        ChartPanel panel = Mockito.spy(new ChartPanel(null));

        // Set private fields via reflection
        setPrivateField(panel, "zoomRectangle", new Rectangle2D.Double(10, 10, 100, 100));
        setPrivateField(panel, "orientation", PlotOrientation.HORIZONTAL);
        setPrivateField(panel, "rangeZoomable", true);
        setPrivateField(panel, "domainZoomable", true);
        setPrivateField(panel, "zoomTriggerDistance", 5);

        // Mock MouseEvent
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(12); // zoomTrigger1 = false
        when(event.getY()).thenReturn(20); // zoomTrigger2 = true
        when(event.isPopupTrigger()).thenReturn(false);

        // Mock zoomPoint
        setPrivateField(panel, "zoomPoint", new Point2D.Double(10, 10));

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoom is performed based on Y-axis only
        verify(panel, times(1)).zoom(any(Rectangle2D.class));

        // Verify that restoreAutoBounds is not called
        verify(panel, never()).restoreAutoBounds();
    }

    // Helper method to set private field values
    private void setPrivateField(ChartPanel panel, String fieldName, Object value) throws Exception {
        Field field = ChartPanel.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(panel, value);
    }
}