import org.junit.jupiter.api.Test;
import org.apache.commons.compress.compressors.gzip.GzipParameters;
import org.apache.commons.compress.compressors.gzip.GzipParameters.OS;

import java.nio.charset.StandardCharsets;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

class GzipParametersTest {

    private GzipParameters createFullParams() {
        GzipParameters params = new GzipParameters();
        params.setBufferSize(1024);
        params.setComment("Test Comment");
        params.setCompressionLevel(5);
        params.setDeflateStrategy(1);
        params.setExtraField(new GzipParameters.ExtraField() {});
        params.setFileName("test.txt");
        params.setFileNameCharset(StandardCharsets.UTF_8);
        params.setHeaderCRC(true);
        params.setModificationInstant(Instant.now());
        params.setOperatingSystem(OS.UNIX.type());
        params.setTrailerCrc(12345L);
        params.setTrailerISize(67890L);
        return params;
    }

    @Test
    void testEqualsSameObject() {
        GzipParameters params = createFullParams();
        assertTrue(params.equals(params));
    }

    @Test
    void testEqualsNullObject() {
        GzipParameters params = createFullParams();
        assertFalse(params.equals(null));
    }

    @Test
    void testEqualsDifferentClass() {
        GzipParameters params = createFullParams();
        assertFalse(params.equals("A String"));
    }

    @Test
    void testEqualsDefaultObjects() {
        GzipParameters params1 = new GzipParameters();
        GzipParameters params2 = new GzipParameters();
        assertTrue(params1.equals(params2));
    }

    @Test
    void testEqualsFullyPopulatedObjects() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        assertTrue(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentBufferSize() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setBufferSize(2048);
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentComment() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setComment("Different Comment");
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentCompressionLevel() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setCompressionLevel(9);
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentDeflateStrategy() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setDeflateStrategy(Deflater.BEST_SPEED);
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentFileName() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setFileName("different.txt");
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentOS() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setOS(OS.UNKNOWN);
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentHeaderCRC() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setHeaderCRC(false);
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentTrailerCrc() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setTrailerCrc(54321L);
        assertFalse(params1.equals(params2));
    }

    @Test
    void testEqualsDifferentTrailerISize() {
        GzipParameters params1 = createFullParams();
        GzipParameters params2 = createFullParams();
        params2.setTrailerISize(98765L);
        assertFalse(params1.equals(params2));
    }
}