package org.apache.commons.math3.stat.regression;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.exception.ModelSpecificationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MillerUpdatingRegressionTest {

    private MillerUpdatingRegression regressionWithIntercept;
    private MillerUpdatingRegression regressionWithoutIntercept;

    @BeforeEach
    void setUp() throws ModelSpecificationException {
        regressionWithIntercept = new MillerUpdatingRegression(2, true);
        regressionWithoutIntercept = new MillerUpdatingRegression(2, false);
        
        // Add sufficient observations for regressionWithIntercept
        regressionWithIntercept.addObservation(new double[]{1.0, 2.0}, 5.0);
        regressionWithIntercept.addObservation(new double[]{2.0, 3.0}, 7.0);
        regressionWithIntercept.addObservation(new double[]{3.0, 4.0}, 9.0);
        
        // Add sufficient observations for regressionWithoutIntercept
        regressionWithoutIntercept.addObservation(new double[]{1.0, 2.0}, 5.0);
        regressionWithoutIntercept.addObservation(new double[]{2.0, 3.0}, 7.0);
        regressionWithoutIntercept.addObservation(new double[]{3.0, 4.0}, 9.0);
    }

    @Test
    void testRegressWithNullInput() {
        assertThrows(NullPointerException.class, () -> {
            regressionWithIntercept.regress(null);
        });
    }

    @Test
    void testRegressWithEmptyVariables() throws ModelSpecificationException {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, true);
        regression.addObservation(new double[]{1.0, 2.0}, 5.0);
        regression.addObservation(new double[]{2.0, 3.0}, 7.0);
        regression.addObservation(new double[]{3.0, 4.0}, 9.0);
        
        RegressionResults results = regression.regress(new int[]{});
        assertNotNull(results);
        assertEquals(0, results.getBeta().length);
    }

    @Test
    void testRegressWithTooManyRegressors() {
        int[] variables = {0, 1, 2};
        ModelSpecificationException exception = assertThrows(ModelSpecificationException.class, () -> {
            regressionWithIntercept.regress(variables);
        });
        assertTrue(exception.getMessage().contains("TOO_MANY_REGRESSORS"));
    }

    @Test
    void testRegressWithInsufficientObservations() throws ModelSpecificationException {
        MillerUpdatingRegression regression = new MillerUpdatingRegression(2, true);
        regression.addObservation(new double[]{1.0, 2.0}, 5.0);
        regression.addObservation(new double[]{2.0, 3.0}, 7.0);
        
        ModelSpecificationException exception = assertThrows(ModelSpecificationException.class, () -> {
            regression.regress();
        });
        assertTrue(exception.getMessage().contains("NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS"));
    }

    @Test
    void testRegressWithDuplicateVariables() throws ModelSpecificationException {
        int[] variables = {0, 1, 1};
        RegressionResults results = regressionWithIntercept.regress(variables);
        assertNotNull(results);
        assertEquals(2, results.getBeta().length);
    }

    @Test
    void testRegressWithInvalidVariableIndex() {
        int[] variables = {0, 3};
        ModelSpecificationException exception = assertThrows(ModelSpecificationException.class, () -> {
            regressionWithIntercept.regress(variables);
        });
        assertTrue(exception.getMessage().contains("INDEX_LARGER_THAN_MAX"));
    }

    @Test
    void testRegressWithoutReordering() throws ModelSpecificationException {
        int[] variables = {0, 1};
        RegressionResults results = regressionWithIntercept.regress(variables);
        assertNotNull(results);
        assertEquals(2, results.getBeta().length);
    }

    @Test
    void testRegressWithReordering() throws ModelSpecificationException {
        int[] variables = {1, 0};
        RegressionResults results = regressionWithIntercept.regress(variables);
        assertNotNull(results);
        assertEquals(2, results.getBeta().length);
    }

    @Test
    void testRegressWithAllBranchesCovered() throws ModelSpecificationException {
        // Test with no duplicates and valid indices
        int[] variables = {0, 1};
        RegressionResults results = regressionWithIntercept.regress(variables);
        assertNotNull(results);
        assertEquals(2, results.getBeta().length);

        // Test with duplicates
        int[] duplicateVariables = {0, 1, 1};
        results = regressionWithIntercept.regress(duplicateVariables);
        assertNotNull(results);
        assertEquals(2, results.getBeta().length);

        // Test with variablesToInclude.length > nvars
        int[] tooManyVariables = {0, 1, 2};
        assertThrows(ModelSpecificationException.class, () -> {
            regressionWithIntercept.regress(tooManyVariables);
        });

        // Test with variablesToInclude containing invalid index
        int[] invalidVariable = {0, 3};
        assertThrows(ModelSpecificationException.class, () -> {
            regressionWithIntercept.regress(invalidVariable);
        });

        // Test with insufficient observations
        MillerUpdatingRegression smallRegression = new MillerUpdatingRegression(2, true);
        smallRegression.addObservation(new double[]{1.0, 2.0}, 5.0);
        smallRegression.addObservation(new double[]{2.0, 3.0}, 7.0);
        assertThrows(ModelSpecificationException.class, () -> {
            smallRegression.regress();
        });
    }
}