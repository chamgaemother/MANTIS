package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_createNumber_0_6_Test {

    @Test
    @DisplayName("Input string with negative exponent and valid Float, should return Float")
    void TC26_createNumber_negativeExponentFloat() {
        // GIVEN
        String input = "1.23e-10F";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof Float, "Result should be an instance of Float");
        assertEquals(1.23e-10F, result.floatValue(), "Float value does not match expected");
    }
    
    @Test
    @DisplayName("Input string with type suffix 'F' but invalid Float, should return Double")
    void TC27_createNumber_suffixFOverflow() {
        // GIVEN
        String input = "3.4028236e38F";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof Double, "Result should be an instance of Double");
        assertEquals(3.4028236e38D, result.doubleValue(), "Double value does not match expected");
    }
    
    @Test
    @DisplayName("Input string with type suffix 'f' and Mantissa zero, should return Float with value 0.0")
    void TC28_createNumber_suffixfZeroFloat() {
        // GIVEN
        String input = "0.0f";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof Float, "Result should be an instance of Float");
        assertEquals(0.0F, result.floatValue(), "Float value should be 0.0F");
    }
    
    @Test
    @DisplayName("Input string with only sign character, should throw NumberFormatException")
    void TC29_createNumber_signOnly() {
        // GIVEN
        String input = "+";
        
        // WHEN & THEN
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input), "Expected NumberFormatException for input with only sign character");
    }
    
    @Test
    @DisplayName("Input string with type suffix 'D' and non-zero mantissa, should return Double")
    void TC30_createNumber_suffixDNonZeroMantissaDouble() {
        // GIVEN
        String input = "123.456D";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof Double, "Result should be an instance of Double");
        assertEquals(123.456D, result.doubleValue(), "Double value does not match expected");
    }
}