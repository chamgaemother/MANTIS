package com.fasterxml.jackson.databind.util;

import com.fasterxml.jackson.core.JsonGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.mockito.Mockito.*;

/**
 * JUnit 5 test class for TokenBuffer.serialize method.
 */
public class TokenBuffer_serialize_1_2_Test {

    @Test
    @DisplayName("serialize with VALUE_NUMBER_INT as Short type")
    void TC42() throws Exception {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNumber((short) 7);
        JsonGenerator gen = mock(JsonGenerator.class);

        // Act
        buffer.serialize(gen);

        // Assert
        verify(gen).writeNumber((short) 7);
        verifyNoMoreInteractions(gen);
    }

    @Test
    @DisplayName("serialize with VALUE_NUMBER_FLOAT as String representing a number")
    void TC43() throws Exception {
        // Arrange
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNumber("123.456");
        JsonGenerator gen = mock(JsonGenerator.class);

        // Act
        buffer.serialize(gen);

        // Assert
        verify(gen).writeNumber("123.456");
        verifyNoMoreInteractions(gen);
    }
}