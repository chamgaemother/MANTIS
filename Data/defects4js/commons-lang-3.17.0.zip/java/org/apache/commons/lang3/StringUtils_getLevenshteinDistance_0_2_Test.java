package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.apache.commons.lang3.StringUtils;

public class StringUtils_getLevenshteinDistance_0_2_Test {

    @Test
    @DisplayName("getLevenshteinDistance(\"kitten\", \"sitting\", 3) returns 3 for distance within threshold")
    public void TC06() {
        // GIVEN
        CharSequence s = "kitten";
        CharSequence t = "sitting";
        int threshold = 3;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(3, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"flaw\", \"lawn\", 2) returns -1 when distance exceeds threshold")
    public void TC07() {
        // GIVEN
        CharSequence s = "flaw";
        CharSequence t = "lawn";
        int threshold = 2;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(-1, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"\", \"test\", 5) returns 4 when first string is empty")
    public void TC08() {
        // GIVEN
        CharSequence s = "";
        CharSequence t = "test";
        int threshold = 5;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(4, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"test\", \"\", 5) returns 4 when second string is empty")
    public void TC09() {
        // GIVEN
        CharSequence s = "test";
        CharSequence t = "";
        int threshold = 5;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(4, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"short\", \"longerstring\", 5) returns -1 when length difference exceeds threshold")
    public void TC10() {
        // GIVEN
        CharSequence s = "short";
        CharSequence t = "longerstring";
        int threshold = 5;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(-1, result);
    }
}