package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Collections;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class XYBoxAndWhiskerRendererTest {

    private XYBoxAndWhiskerRenderer renderer;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private int series;
    private int item;
    private CrosshairState crosshairState;
    private int pass;

    @BeforeEach
    void setUp() {
        renderer = new XYBoxAndWhiskerRenderer();
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(BoxAndWhiskerXYDataset.class);
        series = 0;
        item = 0;
        crosshairState = mock(CrosshairState.class);
        pass = 0;
    }

    @Test
    void testDrawVerticalItem_InfoNull() {
        when(info.getOwner()).thenReturn(null);
        renderer.drawVerticalItem(g2, dataArea, null, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_BoxWidthNegative() {
        renderer.setBoxWidth(-1.0);
        when(dataset.getItemCount(series)).thenReturn(10);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(75.0);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(domainAxis).valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge());
    }

    @Test
    void testDrawVerticalItem_FillBoxTrue() {
        renderer.setFillBox(true);
        Paint boxPaint = Color.BLUE;
        renderer.setBoxPaint(boxPaint);

        when(dataset.getItemCount(series)).thenReturn(5);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(35.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(16.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(60.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
        verify(g2).setPaint(paintCaptor.capture());
        assert(paintCaptor.getValue().equals(boxPaint));
    }

    @Test
    void testDrawVerticalItem_FillBoxFalse() {
        renderer.setFillBox(false);

        when(dataset.getItemCount(series)).thenReturn(5);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(35.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(16.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(60.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_YQ1GreaterThanYQ3() {
        when(dataset.getItemCount(series)).thenReturn(5);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(18.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(18.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(90.0);
        when(rangeAxis.valueToJava2D(16.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(35.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Additional verification can be added here
    }

    @Test
    void testDrawVerticalItem_YAverageNull() {
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(null);

        when(dataset.getItemCount(series)).thenReturn(5);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(16.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(60.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_YAverageVisible() {
        renderer.setFillBox(true);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(dataset.getItemCount(series)).thenReturn(5);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(35.0);
        when(rangeAxis.getUpperBound()).thenReturn(100.0);
        when(rangeAxis.getLowerBound()).thenReturn(0.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_YAverageNotVisible() {
        renderer.setFillBox(true);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(dataset.getItemCount(series)).thenReturn(5);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, renderer.getPlot().getRangeAxisEdge())).thenReturn(-10.0);
        when(rangeAxis.getUpperBound()).thenReturn(100.0);
        when(rangeAxis.getLowerBound()).thenReturn(0.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_WithOutliers() {
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item))
                .thenReturn(Arrays.asList(4.0, 21.0));
        when(((BoxAndWhiskerXYDataset) dataset).getMinOutlier(series, item)).thenReturn(3.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxOutlier(series, item)).thenReturn(22.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(10.0);
        when(rangeAxis.valueToJava2D(21.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(90.0);
        when(rangeAxis.getUpperBound()).thenReturn(100.0);
        when(rangeAxis.getLowerBound()).thenReturn(0.0);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(dataset.getItemCount(series)).thenReturn(5);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_FarOutHigh() {
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item))
                .thenReturn(Collections.singletonList(25.0));
        when(((BoxAndWhiskerXYDataset) dataset).getMinOutlier(series, item)).thenReturn(3.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxOutlier(series, item)).thenReturn(22.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(25.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(110.0);
        when(rangeAxis.getUpperBound()).thenReturn(100.0);
        when(rangeAxis.getLowerBound()).thenReturn(0.0);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(dataset.getItemCount(series)).thenReturn(5);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, atLeast(1)).draw(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_BoxDoesNotIntersectDataArea() {
        when(dataset.getItemCount(series)).thenReturn(5);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge()))
                .thenReturn(150.0); // Outside dataArea
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(200.0); // Outside dataArea
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(-50.0); // Outside dataArea
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(40.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(35.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(25.0);
        when(rangeAxis.valueToJava2D(16.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(60.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(entities, never()).add(any());
    }

    @Test
    void testDrawVerticalItem_InfoWithEntity() {
        EntityCollection entities = mock(EntityCollection.class);
        org.jfree.chart.ChartRenderingInfo chartInfo = mock(org.jfree.chart.ChartRenderingInfo.class);
        when(info.getOwner()).thenReturn(chartInfo);
        when(chartInfo.getEntityCollection()).thenReturn(entities);

        when(dataset.getItemCount(series)).thenReturn(5);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(80.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(20.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(40.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(35.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(25.0);
        when(rangeAxis.valueToJava2D(16.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(60.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(entities).add(any());
    }

    @Test
    void testDrawVerticalItem_YOutliersNull() {
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item)).thenReturn(null);

        when(dataset.getItemCount(series)).thenReturn(5);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item)).thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item)).thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item)).thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item)).thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(16.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    void testDrawVerticalItem_BoxWidthEdgeCases() {
        // Box width exactly 3
        renderer.setBoxWidth(-1.0);
        when(dataset.getItemCount(series)).thenReturn(100);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item))
                .thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item))
                .thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item))
                .thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item))
                .thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item))
                .thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item))
                .thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item))
                .thenReturn(16.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item))
                .thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Additional assertions can be made here
    }

    @Test
    void testDrawVerticalItem_EdgeBoxWidth() {
        // Box width exceeds maxBoxWidth
        renderer.setBoxWidth(-1.0);
        when(dataset.getItemCount(series)).thenReturn(1);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(((BoxAndWhiskerXYDataset) dataset).getX(series, item))
                .thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item))
                .thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item))
                .thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item))
                .thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item))
                .thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item))
                .thenReturn(8.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item))
                .thenReturn(16.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item))
                .thenReturn(Collections.emptyList());

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Additional assertions can be made here
    }

    @Test
    void testDrawVerticalItem_YQ1EqualsYQ3() {
        when(((BoxAndWhiskerXYDataset) dataset).getQ1Value(series, item)).thenReturn(10.0);
        when(((BoxAndWhiskerXYDataset) dataset).getQ3Value(series, item)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getDomainAxisEdge()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, renderer.getPlot().getRangeAxisEdge()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMaxRegularValue(series, item))
                .thenReturn(20.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMinRegularValue(series, item))
                .thenReturn(5.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMedianValue(series, item))
                .thenReturn(12.0);
        when(((BoxAndWhiskerXYDataset) dataset).getMeanValue(series, item))
                .thenReturn(11.0);
        when(((BoxAndWhiskerXYDataset) dataset).getOutliers(series, item))
                .thenReturn(Collections.emptyList());
        when(dataset.getItemCount(series)).thenReturn(5);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }
}