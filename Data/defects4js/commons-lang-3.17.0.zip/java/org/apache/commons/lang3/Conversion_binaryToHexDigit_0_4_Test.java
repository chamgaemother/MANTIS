package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryToHexDigit_0_4_Test {

    @Test
    @DisplayName("Returns '1' when src.length <= srcPos +1 and src[srcPos] is true")
    void TC16() {
        boolean[] src = new boolean[] {true};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('1', result);
    }

    @Test
    @DisplayName("Returns '0' when src.length <= srcPos +1 and src[srcPos] is false")
    void TC17() {
        boolean[] src = new boolean[] {false};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('0', result);
    }

    @Test
    @DisplayName("Returns 'f' when using srcPos offset within array bounds")
    void TC18() {
        boolean[] src = new boolean[] {true, true, true, true, true};
        int srcPos = 1;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('f', result);
    }

    @Test
    @DisplayName("Returns 'a' when src.length > srcPos +3 and src[srcPos+3]=true, src[srcPos+2]=false, src[srcPos+1]=true, src[srcPos]=false")
    void TC19() {
        boolean[] src = new boolean[] {false, true, false, true, true};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('a', result);
    }

    @Test
    @DisplayName("Throws NullPointerException when src array is null")
    void TC20() {
        boolean[] src = null;
        int srcPos = 0;
        assertThrows(NullPointerException.class, () -> {
            Conversion.binaryToHexDigit(src, srcPos);
        });
    }
}