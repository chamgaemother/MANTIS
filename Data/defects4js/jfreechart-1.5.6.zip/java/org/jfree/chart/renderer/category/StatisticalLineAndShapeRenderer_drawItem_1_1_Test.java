package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.util.ShapeUtils;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class StatisticalLineAndShapeRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("Dataset is StatisticalCategoryDataset with pass=0 and series offset disabled, item line is visible, previous value exists")
    void TC07_drawItem_pass0_noSeriesOffset_lineVisible_previousValueExists() throws Exception {
        StatisticalLineAndShapeRenderer renderer = new StatisticalLineAndShapeRenderer(false, false);
        Field useSeriesOffsetField = StatisticalLineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
        useSeriesOffsetField.setAccessible(true);
        useSeriesOffsetField.setBoolean(renderer, false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);

        when(dataset.getMeanValue(0, 1)).thenReturn(10.0);
        when(dataset.getStdDevValue(0, 1)).thenReturn(2.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(8.0);

        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);

        when(domainAxis.getCategoryMiddle(1, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.getCategoryMiddle(0, 1, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, RectangleEdge.LEFT)).thenReturn(80.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
        verify(g2, times(1)).draw(lineCaptor.capture());
        java.awt.geom.Line2D drawnLine = lineCaptor.getValue();
        assertEquals(40.0, drawnLine.getX1());
        assertEquals(80.0, drawnLine.getY1());
        assertEquals(50.0, drawnLine.getX2());
        assertEquals(100.0, drawnLine.getY2());
    }

    @Test
    @DisplayName("Dataset is StatisticalCategoryDataset with pass=0 and series offset enabled, item line is visible, previous value exists")
    void TC08_drawItem_pass0_seriesOffset_enabled_lineVisible_previousValueExists() throws Exception {
        StatisticalLineAndShapeRenderer renderer = new StatisticalLineAndShapeRenderer(false, false);
        Field useSeriesOffsetField = StatisticalLineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
        useSeriesOffsetField.setAccessible(true);
        useSeriesOffsetField.setBoolean(renderer, true);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);

        when(dataset.getMeanValue(0, 1)).thenReturn(15.0);
        when(dataset.getStdDevValue(0, 1)).thenReturn(3.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(12.0);

        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(2);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);

        when(domainAxis.getCategorySeriesMiddle(1, 1, 0, 2, 0.2, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(domainAxis.getCategorySeriesMiddle(0, 1, 0, 2, 0.2, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(12.0, dataArea, RectangleEdge.LEFT)).thenReturn(120.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
        verify(g2, times(1)).draw(lineCaptor.capture());
        java.awt.geom.Line2D drawnLine = lineCaptor.getValue();
        assertEquals(50.0, drawnLine.getX1());
        assertEquals(120.0, drawnLine.getY1());
        assertEquals(60.0, drawnLine.getX2());
        assertEquals(150.0, drawnLine.getY2());
    }

//     @Test
//     @DisplayName("Item shape is visible, filled with fill paint, and outlines are drawn")
//     void TC09_drawItem_itemShapeVisible_filled_withOutlines() throws Exception {
//         StatisticalLineAndShapeRenderer renderer = new StatisticalLineAndShapeRenderer(true, true);
//         Field useFillPaintField = StatisticalLineAndShapeRenderer.class.getDeclaredField("useFillPaint");
//         useFillPaintField.setAccessible(true);
//         useFillPaintField.setBoolean(renderer, true);
// 
//         Field itemShapeFilledField = StatisticalLineAndShapeRenderer.class.getDeclaredField("itemShapeFilled");
//         itemShapeFilledField.setAccessible(true);
//         itemShapeFilledField.setBoolean(renderer, true);
// 
//         Field drawOutlinesField = StatisticalLineAndShapeRenderer.class.getDeclaredField("drawOutlines");
//         drawOutlinesField.setAccessible(true);
//         drawOutlinesField.setBoolean(renderer, true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double();
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
// 
//         when(dataset.getMeanValue(1, 2)).thenReturn(20.0);
//         when(dataset.getStdDevValue(1, 2)).thenReturn(4.0);
// 
//         when(state.getVisibleSeriesIndex(1)).thenReturn(1);
//         when(state.getVisibleSeriesCount()).thenReturn(3);
// 
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.RIGHT);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
// 
//         when(domainAxis.getCategorySeriesMiddle(2, 2, 1, 3, 0.2, dataArea, RectangleEdge.BOTTOM)).thenReturn(70.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.RIGHT)).thenReturn(200.0);
// 
//         Shape mockShape = ShapeUtils.createTranslatedShape(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10), 70.0, 200.0);
//         when(renderer.getItemShape(1, 2)).thenReturn(mockShape);
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 2, 1);
// 
//         ArgumentCaptor<Shape> fillShapeCaptor = ArgumentCaptor.forClass(Shape.class);
//         verify(g2, times(1)).fill(fillShapeCaptor.capture());
//         Shape filledShape = fillShapeCaptor.getValue();
//         assertEquals(mockShape, filledShape);
// 
//         ArgumentCaptor<Shape> drawShapeCaptor = ArgumentCaptor.forClass(Shape.class);
//         verify(g2, times(1)).draw(drawShapeCaptor.capture());
//         Shape drawnShape = drawShapeCaptor.getValue();
//         assertEquals(mockShape, drawnShape);
// 
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 2, 1);
//         verify(entities, times(1)).add(any(), eq(mockShape), eq(dataset), eq(1), eq(2), anyDouble(), anyDouble());
//     }

//     @Test
//     @DisplayName("Item shape is visible, not filled, and outlines are not drawn")
//     void TC10_drawItem_itemShapeVisible_notFilled_noOutlines() throws Exception {
//         StatisticalLineAndShapeRenderer renderer = new StatisticalLineAndShapeRenderer(true, true);
//         Field useFillPaintField = StatisticalLineAndShapeRenderer.class.getDeclaredField("useFillPaint");
//         useFillPaintField.setAccessible(true);
//         useFillPaintField.setBoolean(renderer, false);
// 
//         Field itemShapeFilledField = StatisticalLineAndShapeRenderer.class.getDeclaredField("itemShapeFilled");
//         itemShapeFilledField.setAccessible(true);
//         itemShapeFilledField.setBoolean(renderer, false);
// 
//         Field drawOutlinesField = StatisticalLineAndShapeRenderer.class.getDeclaredField("drawOutlines");
//         drawOutlinesField.setAccessible(true);
//         drawOutlinesField.setBoolean(renderer, false);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double();
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
// 
//         when(dataset.getMeanValue(2, 3)).thenReturn(25.0);
//         when(dataset.getStdDevValue(2, 3)).thenReturn(5.0);
// 
//         when(state.getVisibleSeriesIndex(2)).thenReturn(2);
//         when(state.getVisibleSeriesCount()).thenReturn(4);
// 
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
// 
//         when(domainAxis.getCategoryMiddle(3, 3, dataArea, RectangleEdge.BOTTOM)).thenReturn(80.0);
//         when(rangeAxis.valueToJava2D(25.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);
// 
//         Shape mockShape = ShapeUtils.createTranslatedShape(new java.awt.geom.Ellipse2D.Double(0, 0, 10, 10), 80.0, 250.0);
//         when(renderer.getItemShape(2, 3)).thenReturn(mockShape);
// 
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 3, 1);
// 
//         verify(g2, never()).fill(any());
//         verify(g2, never()).draw(any());
// 
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 3, 1);
//         verify(entities, times(1)).add(any(), eq(mockShape), eq(dataset), eq(2), eq(3), anyDouble(), anyDouble());
//     }

    @Test
    @DisplayName("Entity collection is null, no entity is added")
    void TC11_drawItem_entityCollectionNull_noEntityAdded() throws Exception {
        StatisticalLineAndShapeRenderer renderer = new StatisticalLineAndShapeRenderer(true, true);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);

        when(dataset.getMeanValue(3, 4)).thenReturn(30.0);
        when(dataset.getStdDevValue(3, 4)).thenReturn(6.0);

        when(state.getVisibleSeriesIndex(3)).thenReturn(3);
        when(state.getVisibleSeriesCount()).thenReturn(5);

        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.RIGHT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);

        when(domainAxis.getCategoryMiddle(4, 4, dataArea, RectangleEdge.BOTTOM)).thenReturn(90.0);
        when(rangeAxis.valueToJava2D(30.0, dataArea, RectangleEdge.RIGHT)).thenReturn(300.0);

        Shape mockShape = ShapeUtils.createTranslatedShape(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10), 90.0, 300.0);
        when(renderer.getItemShape(3, 4)).thenReturn(mockShape);

        when(state.getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 3, 4, 1);

        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).draw(any());
    }
}