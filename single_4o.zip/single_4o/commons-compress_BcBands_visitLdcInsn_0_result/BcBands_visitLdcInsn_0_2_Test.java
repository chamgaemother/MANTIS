package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BcBands_visitLdcInsn_0_2_Test {

    @Test
    @DisplayName("Verify handling a class constant with wide index")
    public void testVisitLdcInsn_TC06() throws Exception {
        // Prepare the object and necessary fields
        CpBands cpBands = mock(CpBands.class);
        Segment segment = mock(Segment.class);
        BcBands bcBands = new BcBands(cpBands, segment, 5);
        CPClass cpClassConstant = new CPClass();

        // Mock the necessary method
        when(segment.lastConstantHadWideIndex()).thenReturn(true);
        when(cpBands.getConstant(cpClassConstant)).thenReturn(cpClassConstant);

        // Reflectively get and invoke the private method
        Method visitLdcInsnMethod = BcBands.class.getDeclaredMethod("visitLdcInsn", Object.class);
        visitLdcInsnMethod.setAccessible(true);
        visitLdcInsnMethod.invoke(bcBands, cpClassConstant);

        // Reflectively access and verify state
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(236));

        Field bcClassRefField = BcBands.class.getDeclaredField("bcClassRef");
        bcClassRefField.setAccessible(true);
        List<CPClass> bcClassRef = (List<CPClass>) bcClassRefField.get(bcBands);
        assertTrue(bcClassRef.contains(cpClassConstant));
    }

    @Test
    @DisplayName("Verify exception throwing on unsupported constant")
    public void testVisitLdcInsn_TC07() {
        // Prepare the object and unsupported constant
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(cpBands, segment, 5);
        Object unsupportedConstant = new Object();

        // Reflectively get and invoke the private method
        assertThrows(IllegalArgumentException.class, () -> {
            Method visitLdcInsnMethod = BcBands.class.getDeclaredMethod("visitLdcInsn", Object.class);
            visitLdcInsnMethod.setAccessible(true);
            visitLdcInsnMethod.invoke(bcBands, unsupportedConstant);
        });
    }

    @Test
    @DisplayName("Verify handling an integer constant with non-wide index")
    public void testVisitLdcInsn_TC08() throws Exception {
        // Prepare the object and necessary fields
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();

        BcBands bcBands = new BcBands(cpBands, segment, 5);
        CPInt cpIntConstant = new CPInt();

        // Mock method to return correct constant
        when(cpBands.getConstant(cpIntConstant)).thenReturn(cpIntConstant);

        // Reflectively get and invoke the private method
        Method visitLdcInsnMethod = BcBands.class.getDeclaredMethod("visitLdcInsn", Object.class);
        visitLdcInsnMethod.setAccessible(true);
        visitLdcInsnMethod.invoke(bcBands, cpIntConstant);

        // Reflectively access and verify state
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(234));

        Field bcIntrefField = BcBands.class.getDeclaredField("bcIntref");
        bcIntrefField.setAccessible(true);
        List<CPInt> bcIntref = (List<CPInt>) bcIntrefField.get(bcBands);
        assertTrue(bcIntref.contains(cpIntConstant));
    }

    @Test
    @DisplayName("Verify handling a string constant with non-wide index")
    public void testVisitLdcInsn_TC09() throws Exception {
        // Prepare the object and necessary fields
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();

        BcBands bcBands = new BcBands(cpBands, segment, 5);
        CPString cpStringConstant = new CPString();

        // Mock method to return correct constant
        when(cpBands.getConstant(cpStringConstant)).thenReturn(cpStringConstant);

        // Reflectively get and invoke the private method
        Method visitLdcInsnMethod = BcBands.class.getDeclaredMethod("visitLdcInsn", Object.class);
        visitLdcInsnMethod.setAccessible(true);
        visitLdcInsnMethod.invoke(bcBands, cpStringConstant);

        // Reflectively access and verify state
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(18));

        Field bcStringRefField = BcBands.class.getDeclaredField("bcStringRef");
        bcStringRefField.setAccessible(true);
        List<CPString> bcStringRef = (List<CPString>) bcStringRefField.get(bcBands);
        assertTrue(bcStringRef.contains(cpStringConstant));
    }

}