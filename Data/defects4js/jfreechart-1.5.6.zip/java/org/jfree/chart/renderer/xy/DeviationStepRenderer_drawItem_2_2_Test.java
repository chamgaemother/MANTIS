package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DeviationStepRenderer_drawItem_2_2_Test {

    @Test
    @DisplayName("drawItem processes item pass with entity collection present")
    void TC11_drawItemProcessesItemPassWithEntityCollection() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Mock behavior
        when(renderer.getItemVisible(Mockito.anyInt(), Mockito.anyInt())).thenReturn(true);
        when(renderer.isItemPass(Mockito.anyInt())).thenReturn(true);
        when(info.getOwner()).thenReturn(Mockito.mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(Mockito.mock(org.jfree.chart.entity.EntityCollection.class));

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // Assert
        // Since drawSecondaryPass is a protected method, we can verify interactions indirectly if possible
        // Alternatively, use reflection to ensure it was called
        Method drawSecondaryPassMethod = DeviationStepRenderer.class.getDeclaredMethod("drawSecondaryPass", Graphics2D.class, XYPlot.class, XYDataset.class, int.class, int.class, int.class, ValueAxis.class, Rectangle2D.class, ValueAxis.class, CrosshairState.class, org.jfree.chart.entity.EntityCollection.class);
        drawSecondaryPassMethod.setAccessible(true);
        verify(renderer, times(1)).drawSecondaryPass(g2, plot, dataset, 1, 0, 0, domainAxis, dataArea, rangeAxis, crosshairState, info.getOwner().getEntityCollection());
    }

    @Test
    @DisplayName("drawItem handles NaN yLow gracefully, skipping shading")
    void TC12_drawItemHandlesNaNYLowGracefully() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Mock behavior
        when(renderer.getItemVisible(Mockito.anyInt(), Mockito.anyInt())).thenReturn(true);
        when(dataset.getStartYValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Double.NaN);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        // Verify that fill operation is not called due to NaN yLow
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    @DisplayName("drawItem skips shading when both x and y values are NaN")
    void TC13_drawItemSkipsShadingWhenBothXAndYValuesAreNaN() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Mock behavior
        when(renderer.getItemVisible(Mockito.anyInt(), Mockito.anyInt())).thenReturn(true);
        when(dataset.getXValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Double.NaN);
        when(dataset.getStartYValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Double.NaN);
        when(dataset.getEndYValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Double.NaN);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Assert
        // Verify that fill operation is not called due to NaN x and y values
        verify(g2, never()).fill(any(Shape.class));
    }
}