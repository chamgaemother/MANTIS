package org.apache.commons.math3.stat.descriptive.rank;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

public class PSquarePercentile_equals_2_1_Test {

    @Test
    @DisplayName("equals returns false when this object has null markers and the other object has non-null markers")
    void TC09_equals_NullMarkersThis_ReturnsFalse() throws Exception {
        // GIVEN
        PSquarePercentile obj1 = new PSquarePercentile(50.0);
        obj1.clear(); // Ensures markers are null

        PSquarePercentile obj2 = new PSquarePercentile(50.0);
        // Initialize obj2 with non-null markers
        List<Double> initialFive = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        PSquarePercentile.PSquareMarkers markers = PSquarePercentile.newMarkers(initialFive, 0.5);

        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(obj2, markers);
        markersField.setAccessible(false);

        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(obj1, 10L);
        countField.setLong(obj2, 10L);
        countField.setAccessible(false);

        // WHEN
        boolean result = obj1.equals(obj2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when this object has non-null markers and the other object has null markers")
    void TC10_equals_NullMarkersOther_ReturnsFalse() throws Exception {
        // GIVEN
        PSquarePercentile obj1 = new PSquarePercentile(50.0);
        // Initialize obj1 with non-null markers
        List<Double> initialFive = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        PSquarePercentile.PSquareMarkers markers = PSquarePercentile.newMarkers(initialFive, 0.5);

        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(obj1, markers);
        markersField.setAccessible(false);

        PSquarePercentile obj2 = new PSquarePercentile(50.0);
        obj2.clear(); // Ensures markers are null

        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(obj1, 10L);
        countField.setLong(obj2, 10L);
        countField.setAccessible(false);

        // WHEN
        boolean result = obj1.equals(obj2);

        // THEN
        assertFalse(result);
    }
}