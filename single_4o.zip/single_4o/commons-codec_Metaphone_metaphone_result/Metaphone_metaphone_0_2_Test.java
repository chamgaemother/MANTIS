package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Metaphone_metaphone_0_2_Test {

    @Test
    @DisplayName("metaphone('Art') handles initial 'A', 'R', and 'T' without change because it starts with a vowel")
    public void testMetaphoneInitialVowel() throws Exception {
        Metaphone instance = new Metaphone();
        String input = "Art";
        String expected = "ART";
        
        Method metaphoneMethod = Metaphone.class.getDeclaredMethod("metaphone", String.class);
        metaphoneMethod.setAccessible(true);
        String result = (String) metaphoneMethod.invoke(instance, input);

        assertEquals(expected, result);
    }

    @Test
    @DisplayName("metaphone('Tch') skips the 'T' in 'TCH'")
    public void testMetaphoneSkipTCH() throws Exception {
        Metaphone instance = new Metaphone();
        String input = "Tch";
        String expected = "X";

        Method metaphoneMethod = Metaphone.class.getDeclaredMethod("metaphone", String.class);
        metaphoneMethod.setAccessible(true);
        String result = (String) metaphoneMethod.invoke(instance, input);

        assertEquals(expected, result);
    }

    @Test
    @DisplayName("metaphone('Gut') will return 'KT' for typical consonant transformation")
    public void testMetaphoneTypicalConsonant() throws Exception {
        Metaphone instance = new Metaphone();
        String input = "Gut";
        String expected = "KT";

        Method metaphoneMethod = Metaphone.class.getDeclaredMethod("metaphone", String.class);
        metaphoneMethod.setAccessible(true);
        String result = (String) metaphoneMethod.invoke(instance, input);

        assertEquals(expected, result);
    }

    @Test
    @DisplayName("metaphone('Whale') skips the initial 'WH' conversion with 'H' followed")
    public void testMetaphoneInitialWH() throws Exception {
        Metaphone instance = new Metaphone();
        String input = "Whale";
        String expected = "WL";

        Method metaphoneMethod = Metaphone.class.getDeclaredMethod("metaphone", String.class);
        metaphoneMethod.setAccessible(true);
        String result = (String) metaphoneMethod.invoke(instance, input);

        assertEquals(expected, result);
    }

    @Test
    @DisplayName("metaphone handles typical double characters correctly; like 'Letter'")
    public void testMetaphoneDoubleCharacters() throws Exception {
        Metaphone instance = new Metaphone();
        instance.setMaxCodeLen(6); // Precondition setup
        String input = "Letter";
        String expected = "LTR";

        Method metaphoneMethod = Metaphone.class.getDeclaredMethod("metaphone", String.class);
        metaphoneMethod.setAccessible(true);
        String result = (String) metaphoneMethod.invoke(instance, input);

        assertEquals(expected, result);
    }
}