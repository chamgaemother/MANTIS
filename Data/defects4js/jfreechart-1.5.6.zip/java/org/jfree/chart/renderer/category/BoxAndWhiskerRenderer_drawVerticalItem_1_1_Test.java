// package org.jfree.chart.renderer.category;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// import org.jfree.chart.renderer.Outlier;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
// 
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.awt.geom.Ellipse2D;
// import java.awt.geom.Line2D;
// import java.awt.geom.Rectangle2D;
// import java.util.Arrays;
// import java.util.List;
// 
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.ui.RectangleEdge;
// import org.jfree.chart.renderer.category.BoxAndWhiskerCategoryDataset;
// import org.jfree.chart.renderer.category.CategoryItemRendererState;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.ArgumentMatchers;
// 
// /**
//  * Test class for BoxAndWhiskerRenderer#drawVerticalItem.
//  */
// public class BoxAndWhiskerRenderer_drawVerticalItem_1_1_Test {
// 
//     @Test
//     @DisplayName("TC01: drawVerticalItem with single series and all values present, filled box")
//     public void TC01_drawVerticalItem_singleSeries_allValuesFilledBox() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(dataset.getQ1Value(0, 0)).thenReturn(10);
//         when(dataset.getQ3Value(0, 0)).thenReturn(20);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(25);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(5);
//         when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(null);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         verify(g2).fill(any(Rectangle2D.class));
//         verify(g2, atLeastOnce()).draw(any(Line2D.class));
//         verify(g2).fill(any(Ellipse2D.class));
//         verify(g2).draw(any(Ellipse2D.class));
//     }
// 
//     @Test
//     @DisplayName("TC02: drawVerticalItem with multiple series and outline paint for whiskers")
//     public void TC02_drawVerticalItem_multipleSeries_outlineWhiskers_withOutliers() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(1, 1)).thenReturn(15);
//         when(dataset.getQ3Value(1, 1)).thenReturn(25);
//         when(dataset.getMaxRegularValue(1, 1)).thenReturn(30);
//         when(dataset.getMinRegularValue(1, 1)).thenReturn(10);
//         when(dataset.getMeanValue(1, 1)).thenReturn(20.0);
//         when(dataset.getMedianValue(1, 1)).thenReturn(20.0);
//         List<Double> outliers = Arrays.asList(35.0, 40.0);
//         when(dataset.getOutliers(1, 1)).thenReturn(outliers);
//         when(dataset.getMinOutlier(1, 1)).thenReturn(5.0);
//         when(dataset.getMaxOutlier(1, 1)).thenReturn(45.0);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setUseOutlinePaintForWhiskers(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.setMaxOutlierVisible(true);
//         renderer.setMinOutlierVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
// 
//         // Assert
//         verify(g2).setPaint(any(Paint.class));
//         verify(g2, times(2)).draw(any(Shape.class));
//         verify(g2).fill(any(Rectangle2D.class));
//         verify(g2).draw(any(Ellipse2D.class));
//         verify(g2).draw(any(Line2D.class));
//     }
// 
//     @Test
//     @DisplayName("TC03: drawVerticalItem with null Q1 value, skipping box drawing")
//     public void TC03_drawVerticalItem_nullQ1_skipsBox() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(0, 0)).thenReturn(null);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         verify(g2, never()).fill(any(Rectangle2D.class));
//         verify(g2, never()).draw(any(Ellipse2D.class));
//     }
// 
//     @Test
//     @DisplayName("TC04: drawVerticalItem with filled box disabled")
//     public void TC04_drawVerticalItem_filledBoxDisabled() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(0, 0)).thenReturn(10);
//         when(dataset.getQ3Value(0, 0)).thenReturn(20);
//         when(dataset.getMaxRegularValue(0, 0)).thenReturn(25);
//         when(dataset.getMinRegularValue(0, 0)).thenReturn(5);
//         when(dataset.getMeanValue(0, 0)).thenReturn(15.0);
//         when(dataset.getMedianValue(0, 0)).thenReturn(15.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(null);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(false);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
// 
//         // Assert
//         verify(g2, never()).fill(any(Rectangle2D.class));
//         verify(g2).draw(any(Rectangle2D.class));
//         verify(g2).draw(any(Ellipse2D.class));
//     }
// 
//     @Test
//     @DisplayName("TC05: drawVerticalItem with outliers present and far out visible")
//     public void TC05_drawVerticalItem_withFarOutOutliers() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
// 
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDataset(0)).thenReturn(dataset);
//         when(dataset.getQ1Value(1, 1)).thenReturn(15);
//         when(dataset.getQ3Value(1, 1)).thenReturn(25);
//         when(dataset.getMaxRegularValue(1, 1)).thenReturn(30);
//         when(dataset.getMinRegularValue(1, 1)).thenReturn(10);
//         when(dataset.getMeanValue(1, 1)).thenReturn(20.0);
//         when(dataset.getMedianValue(1, 1)).thenReturn(20.0);
//         List<Double> outliers = Arrays.asList(35.0, 40.0, 5.0);
//         when(dataset.getOutliers(1, 1)).thenReturn(outliers);
//         when(dataset.getMinOutlier(1, 1)).thenReturn(5.0);
//         when(dataset.getMaxOutlier(1, 1)).thenReturn(45.0);
// 
//         // Act
//         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
//         renderer.setFillBox(true);
//         renderer.setUseOutlinePaintForWhiskers(true);
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
//         renderer.setMaxOutlierVisible(true);
//         renderer.setMinOutlierVisible(true);
//         renderer.drawVerticalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
// 
//         // Assert
//         verify(g2, atLeastOnce()).draw(any(Shape.class));
//         verify(g2).draw(ArgumentMatchers.<Line2D>any());
//         verify(g2).drawHighFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//         verify(g2).drawLowFarOut(anyDouble(), any(Graphics2D.class), anyDouble(), anyDouble());
//     }
// }