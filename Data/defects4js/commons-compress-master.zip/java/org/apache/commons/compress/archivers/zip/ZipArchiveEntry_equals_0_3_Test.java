package org.apache.commons.compress.archivers.zip;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class ZipArchiveEntry_equals_0_3_Test {

    @Test
    @DisplayName("equals() returns false when platform differs")
    public void TC11_equalsWithDifferentPlatform() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");

        // Setting platform using reflection
        Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
        platformField.setAccessible(true);
        platformField.setInt(entry1, 1);
        platformField.setInt(entry2, 2);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals() returns false when externalAttributes differ")
    public void TC12_equalsWithDifferentExternalAttributes() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");

        // Setting externalAttributes using reflection
        Field externalAttributesField = ZipArchiveEntry.class.getDeclaredField("externalAttributes");
        externalAttributesField.setAccessible(true);
        externalAttributesField.setLong(entry1, 12345L);
        externalAttributesField.setLong(entry2, 54321L);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals() returns false when method differs")
    public void TC13_equalsWithDifferentMethod() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");

        // Setting method using reflection
        Field methodField = ZipArchiveEntry.class.getDeclaredField("method");
        methodField.setAccessible(true);
        methodField.setInt(entry1, 0);
        methodField.setInt(entry2, 1);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals() returns false when size differs")
    public void TC14_equalsWithDifferentSize() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");

        // Setting size using reflection
        Field sizeField = ZipArchiveEntry.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setLong(entry1, 1024L);
        sizeField.setLong(entry2, 2048L);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("equals() returns false when crc differs")
    public void TC15_equalsWithDifferentCrc() throws Exception {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");

        // Setting crc using reflection
        Field crcField = ZipArchiveEntry.class.getDeclaredField("crc");
        crcField.setAccessible(true);
        crcField.setLong(entry1, 123456789L);
        crcField.setLong(entry2, 987654321L);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result);
    }
}