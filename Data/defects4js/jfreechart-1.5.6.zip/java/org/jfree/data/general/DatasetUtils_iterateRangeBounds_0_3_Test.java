package org.jfree.data.general;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNull;

public class DatasetUtils_iterateRangeBounds_0_3_Test {

//     @Test
//     @DisplayName("includeInterval=true with OHLCDataset having all low and high values as NaN, expecting null return")
//     public void TC11_includeIntervalTrue_OHLCDataset_AllNaN_ShouldReturnNull() {
        // GIVEN
//         OHLCDataset dataset = new OHLCDataset() {
//             @Override
//             public int getSeriesCount() {
//                 return 1;
//             }
// 
//             @Override
//             public Comparable<?> getSeriesKey(int series) {
//                 return "Series1";
//             }
// 
//             @Override
//             public int getItemCount(int series) {
//                 return 2;
//             }
// 
//             @Override
//             public Number getX(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getXValue(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public Number getY(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getYValue(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public Number getLow(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getLowValue(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public Number getHigh(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getHighValue(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public Number getOpen(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getOpenValue(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public Number getClose(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getCloseValue(int series, int item) {
//                 return Double.NaN;
//             }
//         };
// 
//         boolean includeInterval = true;
// 
        // WHEN
//         Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
// 
        // THEN
//         assertNull(result);
//     }

//     @Test
//     @DisplayName("includeInterval=false with standard XYDataset having all Y values as NaN, expecting null return")
//     public void TC12_includeIntervalFalse_StandardXYDataset_AllYNaN_ShouldReturnNull() {
        // GIVEN
//         XYDataset dataset = new XYDataset() {
//             @Override
//             public int getSeriesCount() {
//                 return 1;
//             }
// 
//             @Override
//             public Comparable<?> getSeriesKey(int series) {
//                 return "Series1";
//             }
// 
//             @Override
//             public int getItemCount(int series) {
//                 return 2;
//             }
// 
//             @Override
//             public Number getX(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getXValue(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public Number getY(int series, int item) {
//                 return Double.NaN;
//             }
// 
//             @Override
//             public double getYValue(int series, int item) {
//                 return Double.NaN;
//             }
//         };
// 
//         boolean includeInterval = false;
// 
        // WHEN
//         Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
// 
        // THEN
//         assertNull(result);
//     }
}