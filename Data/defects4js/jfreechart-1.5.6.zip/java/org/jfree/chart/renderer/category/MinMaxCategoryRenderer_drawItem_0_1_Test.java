package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MinMaxCategoryRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem is called with dataset value as null, leading to early return")
    void TC01_drawItem_null_dataset_value() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(null);

        // Use reflection to set private fields if necessary
        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.set(renderer, column);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        // Since value is null, no drawing should occur. Verify that g2 was not interacted with.
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("drawItem is called with vertical orientation and valid dataset value")
    void TC02_drawItem_vertical_orientation_with_valid_value() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(10);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getRowCount()).thenReturn(row + 1);

        // Use reflection to set private fields if necessary
        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.set(renderer, column);

        Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
        minField.setAccessible(true);
        minField.setDouble(renderer, 10.0);

        Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
        maxField.setAccessible(true);
        maxField.setDouble(renderer, 10.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        // Verify that vertical drawing methods are called
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        // Additional verifications can be added based on implementation details
    }

    @Test
    @DisplayName("drawItem is called with horizontal orientation and valid dataset value")
    void TC03_drawItem_horizontal_orientation_with_valid_value() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 2;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(15);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getRowCount()).thenReturn(row + 1);

        // Use reflection to set private fields if necessary
        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.set(renderer, column);

        Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
        minField.setAccessible(true);
        minField.setDouble(renderer, 15.0);

        Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
        maxField.setAccessible(true);
        maxField.setDouble(renderer, 15.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        // Verify that horizontal drawing methods are called
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        // Additional verifications can be added based on implementation details
    }

    @Test
    @DisplayName("drawItem updates min when new value is less than current min")
    void TC04_drawItem_updates_min_when_new_value_is_lower() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 1;
        int column = 3;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(5);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getRowCount()).thenReturn(row + 1);

        // Use reflection to set private fields
        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.setInt(renderer, column);

        Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
        minField.setAccessible(true);
        minField.setDouble(renderer, 10.0);

        Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
        maxField.setAccessible(true);
        maxField.setDouble(renderer, 15.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        assertEquals(5.0, minField.getDouble(renderer), "Min should be updated to 5.0");
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    @DisplayName("drawItem updates max when new value is greater than current max")
    void TC05_drawItem_updates_max_when_new_value_is_higher() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 2;
        int column = 4;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(20);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getRowCount()).thenReturn(row + 1);

        // Use reflection to set private fields
        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.setInt(renderer, column);

        Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
        minField.setAccessible(true);
        minField.setDouble(renderer, 10.0);

        Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
        maxField.setAccessible(true);
        maxField.setDouble(renderer, 15.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        assertEquals(20.0, maxField.getDouble(renderer), "Max should be updated to 20.0");
        verify(g2, atLeastOnce()).draw(any());
    }
}