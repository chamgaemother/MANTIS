package org.apache.commons.math3.geometry.euclidean.threed;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Rotation_getAngles_1_1_Test {

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and XYZ order where v2.getZ() is within bounds")
    public void testTC04_getAngles_FRAME_TRANSFORM_XYZ_within_bounds() {
        // Arrange
        Rotation rotation = new Rotation(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM, Math.PI / 6, Math.PI / 4, Math.PI / 3);

        // Act
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        // Additional assertions for specific angle values can be added here
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and XYZ order where v2.getZ() exceeds upper boundary, throwing exception")
    public void testTC05_getAngles_FRAME_TRANSFORM_XYZ_exceeds_upper_boundary() {
        // Arrange
        // Angles are set to create a scenario where v2.getZ() exceeds 0.9999999999
        Rotation rotation = new Rotation(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM, Math.PI / 2 + 1e-10, Math.PI / 2, Math.PI / 2);

        // Act & Assert
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and YXZ order where v2.getZ() is within bounds")
    public void testTC06_getAngles_FRAME_TRANSFORM_YXZ_within_bounds() {
        // Arrange
        Rotation rotation = new Rotation(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM, Math.PI / 6, Math.PI / 4, Math.PI / 3);

        // Act
        double[] angles = rotation.getAngles(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        // Additional assertions for specific angle values can be added here
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and YXZ order where v2.getZ() exceeds upper boundary, throwing exception")
    public void testTC07_getAngles_FRAME_TRANSFORM_YXZ_exceeds_upper_boundary() {
        // Arrange
        // Angles are set to create a scenario where v2.getZ() exceeds 0.9999999999
        Rotation rotation = new Rotation(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM, Math.PI / 2 + 1e-10, Math.PI / 2, Math.PI / 2);

        // Act & Assert
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and ZYX order where rotation angles are zero")
    public void testTC08_getAngles_FRAME_TRANSFORM_ZYX_zero_rotation() {
        // Arrange
        Rotation rotation = new Rotation(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM, 0.0, 0.0, 0.0);

        // Act
        double[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        assertEquals(0.0, angles[0], 1e-10, "First angle should be zero");
        assertEquals(0.0, angles[1], 1e-10, "Second angle should be zero");
        assertEquals(0.0, angles[2], 1e-10, "Third angle should be zero");
    }
}