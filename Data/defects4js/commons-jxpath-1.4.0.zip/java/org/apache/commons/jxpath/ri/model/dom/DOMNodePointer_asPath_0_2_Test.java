package org.apache.commons.jxpath.ri.model.dom;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;

public class DOMNodePointer_asPath_0_2_Test {

    @Test
    @DisplayName("asPath constructs path for TEXT_NODE")
    void TC06_asPath_ConstructsPathForTextNode() throws Exception {
        // Arrange
        // Mock Node
        Node mockNode = org.mockito.Mockito.mock(Node.class);
        org.mockito.Mockito.when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
        
        // Create DOMNodePointer using constructor
        DOMNodePointer pointer = new DOMNodePointer(mockNode, null);

        // Act
        String path = pointer.asPath();

        // Assert
        assertEquals("/text()[1]", path);
    }

    @Test
    @DisplayName("asPath constructs path for CDATA_SECTION_NODE")
    void TC07_asPath_ConstructsPathForCDATASectionNode() throws Exception {
        // Arrange
        // Mock CDATASection Node
        CDATASection mockNode = org.mockito.Mockito.mock(CDATASection.class);
        org.mockito.Mockito.when(mockNode.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);

        // Create DOMNodePointer using constructor
        DOMNodePointer pointer = new DOMNodePointer(mockNode, null);

        // Act
        String path = pointer.asPath();

        // Assert
        assertEquals("/text()[1]", path);
    }

    @Test
    @DisplayName("asPath constructs path for PROCESSING_INSTRUCTION_NODE")
    void TC08_asPath_ConstructsPathForProcessingInstructionNode() throws Exception {
        // Arrange
        // Mock ProcessingInstruction Node
        ProcessingInstruction mockNode = org.mockito.Mockito.mock(ProcessingInstruction.class);
        org.mockito.Mockito.when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
        org.mockito.Mockito.when(mockNode.getTarget()).thenReturn("target");

        // Create DOMNodePointer using constructor
        DOMNodePointer pointer = new DOMNodePointer(mockNode, null);

        // Act
        String path = pointer.asPath();

        // Assert
        assertEquals("/processing-instruction('target')[1]", path);
    }

    @Test
    @DisplayName("asPath handles DOCUMENT_NODE resulting in empty path")
    void TC09_asPath_HandlesDocumentNode() throws Exception {
        // Arrange
        // Mock Document Node
        Document mockNode = org.mockito.Mockito.mock(Document.class);
        org.mockito.Mockito.when(mockNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);

        // Create DOMNodePointer using constructor
        DOMNodePointer pointer = new DOMNodePointer(mockNode, null);

        // Act
        String path = pointer.asPath();

        // Assert
        assertEquals("", path);
    }

    @Test
    @DisplayName("asPath handles unknown node type by returning current buffer")
    void TC10_asPath_HandlesUnknownNodeType() throws Exception {
        // Arrange
        // Mock Unknown Node Type (e.g., COMMENT_NODE)
        Node mockNode = org.mockito.Mockito.mock(Node.class);
        org.mockito.Mockito.when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);

        // Create DOMNodePointer using constructor
        DOMNodePointer pointer = new DOMNodePointer(mockNode, null);

        // Act
        String path = pointer.asPath();

        // Assert
        assertEquals("", path);
    }
}