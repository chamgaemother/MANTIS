package org.jfree.chart.title;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.chart.ui.RectangleEdge;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PaintScaleLegend_draw_0_4_Test {

    @Test
    @DisplayName("draw method with maximum subdivisions, stress testing strip drawing")
    public void TC16_draw_with_maximum_subdivisions() {
        // Arrange
        PaintScale paintScale = mock(PaintScale.class);
        ValueAxis valueAxis = mock(ValueAxis.class);
        when(valueAxis.getLowerBound()).thenReturn(0.0);
        when(valueAxis.getUpperBound()).thenReturn(10.0);
        PaintScaleLegend legend = new PaintScaleLegend(paintScale, valueAxis);

        // Replaced setAxisLocation with setAxisLocation to use AxisLocation enum directly
        legend.setAxisLocation(org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT);

        legend.setSubdivisionCount(10); // Changed from setSubdivisions to setSubdivisionCount to match the available method
        legend.setBackgroundPaint(null);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Object param = null;

        // Act
        Object result = legend.draw(g2, area, param);

        // Assert
        assertNull(result, "The draw method should return null.");
        // Verify that the fill method was called 10 times
        verify(g2, times(10)).fill(any(Rectangle2D.class));
    }
}