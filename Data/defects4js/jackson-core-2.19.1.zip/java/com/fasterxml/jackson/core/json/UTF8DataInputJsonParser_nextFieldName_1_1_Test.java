package com.fasterxml.jackson.core.json;

import java.io.*;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;

import static org.junit.jupiter.api.Assertions.*;

public class UTF8DataInputJsonParser_nextFieldName_1_1_Test {

    @Test
    @DisplayName("Parses a field name containing Unicode characters successfully")
    public void TC31_ParsesUnicodeFieldNameSuccessfully() throws IOException {
        String json = "{\"\u00FCn\u00EEC\u00F8d\u00EAField\":\"value\"}";
        byte[] jsonBytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = jsonBytes[0] & 0xFF;
        byte[] remainingBytes = new byte[jsonBytes.length - 1];
        System.arraycopy(jsonBytes, 1, remainingBytes, 0, remainingBytes.length);
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, 0, inputData, null, sym, firstByte);

        String fieldName = parser.nextFieldName();
        assertEquals("Ã¼nÃ®cÃ¸dÃªField", fieldName);
        assertEquals(JsonToken.FIELD_NAME, parser.getCurrentToken());
    }

    @Test
    @DisplayName("Parses an empty field name and returns an empty string")
    public void TC32_ParsesEmptyFieldName() throws IOException {
        String json = "{\"\":\"emptyValue\"}";
        byte[] jsonBytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = jsonBytes[0] & 0xFF;
        byte[] remainingBytes = new byte[jsonBytes.length - 1];
        System.arraycopy(jsonBytes, 1, remainingBytes, 0, remainingBytes.length);
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, 0, inputData, null, sym, firstByte);

        String fieldName = parser.nextFieldName();
        assertEquals("", fieldName);
        assertEquals(JsonToken.FIELD_NAME, parser.getCurrentToken());
    }

    @Test
    @DisplayName("Parses a field name followed by an unexpected character, throwing JsonParseException")
    public void TC33_FieldNameFollowedByUnexpectedChar_ThrowsException() throws IOException {
        String json = "{\"validField\"@:\"value\"}";
        byte[] jsonBytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = jsonBytes[0] & 0xFF;
        byte[] remainingBytes = new byte[jsonBytes.length - 1];
        System.arraycopy(jsonBytes, 1, remainingBytes, 0, remainingBytes.length);
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, 0, inputData, null, sym, firstByte);

        parser.nextFieldName();
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("expected a value"));
    }

    @Test
    @DisplayName("Parses a field name followed by a field with escaped characters")
    public void TC34_FieldNameWithEscapedCharacters() throws IOException {
        String json = "{\"escaped\\\"Field\":\"escapedValue\"}";
        byte[] jsonBytes = json.getBytes(StandardCharsets.UTF_8);
        int firstByte = jsonBytes[0] & 0xFF;
        byte[] remainingBytes = new byte[jsonBytes.length - 1];
        System.arraycopy(jsonBytes, 1, remainingBytes, 0, remainingBytes.length);
        DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));

        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, 0, inputData, null, sym, firstByte);

        String fieldName = parser.nextFieldName();
        assertEquals("escaped\"Field", fieldName);
        assertEquals(JsonToken.FIELD_NAME, parser.getCurrentToken());
    }

//     @Test
//     @DisplayName("Parses a field name followed by a number with leading plus sign when feature is enabled")
//     public void TC35_FieldNameWithLeadingPlusNumber() throws IOException {
//         String json = "{\"positiveNumber\":+123}";
//         byte[] jsonBytes = json.getBytes(StandardCharsets.UTF_8);
//         int firstByte = jsonBytes[0] & 0xFF;
//         byte[] remainingBytes = new byte[jsonBytes.length - 1];
//         System.arraycopy(jsonBytes, 1, remainingBytes, 0, remainingBytes.length);
//         DataInput inputData = new DataInputStream(new ByteArrayInputStream(remainingBytes));
// 
//         int features = com.fasterxml.jackson.core.json.JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature();
// 
//         IOContext ctxt = new IOContext(null, null, false);
//         ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
//         UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, features, inputData, null, sym, firstByte);
// 
//         String fieldName = parser.nextFieldName();
//         assertEquals("positiveNumber", fieldName);
//         assertEquals(JsonToken.FIELD_NAME, parser.getCurrentToken());
// 
//         JsonToken nextToken = parser.nextToken();
//         assertEquals(JsonToken.VALUE_NUMBER_INT, nextToken);
//         assertEquals(123, parser.getIntValue());
//     }
}