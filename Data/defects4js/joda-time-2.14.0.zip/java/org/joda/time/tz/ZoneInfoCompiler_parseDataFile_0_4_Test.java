package org.joda.time.tz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ZoneInfoCompiler_parseDataFile_0_4_Test {

    @Test
    @DisplayName("parseDataFile processes multiple zones and rules in one input")
    public void TC16_parseDataFile_multipleZonesAndRules() throws Exception {
        // Given
        String input = "summer start\nEurope/London GMT0\nwinter end\nAmerica/New_York GMT-5\n";
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean z9 = false;

        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // When
        compiler.parseDataFile(in, z9);

        // Then
        Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
        iRuleSetsField.setAccessible(true);
        Map<String, Object> iRuleSets = (Map<String, Object>) iRuleSetsField.get(compiler);
        
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<Object> iZones = (List<Object>) iZonesField.get(compiler);

        assertAll("Verify rules and zones",
            () -> assertTrue(iRuleSets.containsKey("summer"), "RULE_LOOKUP should contain 'summer'"),
            () -> assertTrue(iRuleSets.containsKey("winter"), "RULE_LOOKUP should contain 'winter'"),
            () -> assertEquals(2, iRuleSets.size(), "There should be 2 rule sets"),
            () -> assertEquals(2, iZones.size(), "There should be 2 zones"),
            () -> {
                Object londonZone = iZones.get(0);
                Method getName = londonZone.getClass().getDeclaredMethod("getName");
                getName.setAccessible(true);
                String name = (String) getName.invoke(londonZone);
                assertEquals("Europe/London", name, "First zone should be Europe/London");
            },
            () -> {
                Object newYorkZone = iZones.get(1);
                Method getName = newYorkZone.getClass().getDeclaredMethod("getName");
                getName.setAccessible(true);
                String name = (String) getName.invoke(newYorkZone);
                assertEquals("America/New_York", name, "Second zone should be America/New_York");
            }
        );
    }

    @Test
    @DisplayName("parseDataFile handles continuation of a zone with multiple tokens")
    public void TC17_parseDataFile_zoneContinuation_multipleTokens() throws Exception {
        // Given
        String input = "Europe/London GMT0\n  DST1 start end\n";
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean z9 = false;

        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // When
        compiler.parseDataFile(in, z9);

        // Then
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<Object> iZones = (List<Object>) iZonesField.get(compiler);

        assertEquals(1, iZones.size(), "There should be 1 zone");
        Object londonZone = iZones.get(0);
        Method getChainedRules = londonZone.getClass().getDeclaredMethod("getChainedRules");
        getChainedRules.setAccessible(true);
        List<String> chainedRules = (List<String>) getChainedRules.invoke(londonZone);
        assertTrue(chainedRules.contains("DST1 start end"), "DST1 start end should be chained to Europe/London zone");
    }

    @Test
    @DisplayName("parseDataFile with BufferedReader throwing IOException")
    public void TC18_parseDataFile_bufferedReader_throwsIOException() throws Exception {
        // Given
        BufferedReader in = Mockito.mock(BufferedReader.class);
        Mockito.when(in.readLine()).thenThrow(new IOException("Read error"));
        boolean z9 = false;

        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // When & Then
        assertThrows(IOException.class, () -> {
            compiler.parseDataFile(in, z9);
        }, "IOException should be thrown when BufferedReader.readLine() fails");
    }

    @Test
    @DisplayName("parseDataFile processes lines with multiple '#' characters")
    public void TC19_parseDataFile_multipleComments() throws Exception {
        // Given
        String input = "Europe/London ## GMT0#comment\n";
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean z9 = false;

        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // When
        compiler.parseDataFile(in, z9);

        // Then
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<Object> iZones = (List<Object>) iZonesField.get(compiler);

        assertEquals(1, iZones.size(), "There should be 1 zone");
        Object londonZone = iZones.get(0);
        Method getName = londonZone.getClass().getDeclaredMethod("getName");
        getName.setAccessible(true);
        String name = (String) getName.invoke(londonZone);
        assertEquals("Europe/London", name, "Zone name should be Europe/London");

        // Further assertions can be added to verify 'GMT0' is correctly set
    }

    @Test
    @DisplayName("parseDataFile handles lines containing only a single '#'")
    public void TC20_parseDataFile_singleCommentLines() throws Exception {
        // Given
        String input = "#\n# Comment Line\n";
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean z9 = false;

        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // When
        compiler.parseDataFile(in, z9);

        // Then
        Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
        iZonesField.setAccessible(true);
        List<Object> iZones = (List<Object>) iZonesField.get(compiler);

        assertTrue(iZones.isEmpty(), "There should be no zones added");

        Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
        iRuleSetsField.setAccessible(true);
        Map<String, Object> iRuleSets = (Map<String, Object>) iRuleSetsField.get(compiler);

        assertTrue(iRuleSets.isEmpty(), "There should be no rule sets added");
    }
}