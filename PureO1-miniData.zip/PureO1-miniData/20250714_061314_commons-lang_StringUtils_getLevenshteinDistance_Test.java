package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StringUtilsTest {

    @Test
    void testGetLevenshteinDistance_BothNull_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            StringUtils.getLevenshteinDistance(null, null, 1)
        );
    }

    @Test
    void testGetLevenshteinDistance_SNull_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            StringUtils.getLevenshteinDistance(null, "abc", 1)
        );
    }

    @Test
    void testGetLevenshteinDistance_TNull_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            StringUtils.getLevenshteinDistance("abc", null, 1)
        );
    }

    @Test
    void testGetLevenshteinDistance_ThresholdNegative_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> 
            StringUtils.getLevenshteinDistance("abc", "abc", -1)
        );
    }

    @Test
    void testGetLevenshteinDistance_SEmpty_TEmpty_ThresholdZero() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", "", 0));
    }

    @Test
    void testGetLevenshteinDistance_SEmpty_TEmpty_ThresholdPositive() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", "", 1));
    }

    @Test
    void testGetLevenshteinDistance_SEmpty_TWithinThreshold() {
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc", 3));
    }

    @Test
    void testGetLevenshteinDistance_SEmpty_TExceedsThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("", "abcd", 3));
    }

    @Test
    void testGetLevenshteinDistance_TEmpty_SWithinThreshold() {
        assertEquals(3, StringUtils.getLevenshteinDistance("abc", "", 3));
    }

    @Test
    void testGetLevenshteinDistance_TEmpty_SExceedsThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("abcd", "", 3));
    }

    @Test
    void testGetLevenshteinDistance_LengthDifferenceWithinThreshold() {
        assertEquals(2, StringUtils.getLevenshteinDistance("abc", "abxyc", 2));
    }

    @Test
    void testGetLevenshteinDistance_LengthDifferenceExceedsThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "abxyzc", 1));
    }

    @Test
    void testGetLevenshteinDistance_SLongerThan_TWithinThreshold() {
        assertEquals(3, StringUtils.getLevenshteinDistance("abcdef", "abcxyz", 3));
    }

    @Test
    void testGetLevenshteinDistance_SLongerThan_TExceedsThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("abcdef", "abcxyz", 2));
    }

    @Test
    void testGetLevenshteinDistance_SShorter_TWithinThreshold() {
        assertEquals(3, StringUtils.getLevenshteinDistance("abc", "abcxyz", 3));
    }

    @Test
    void testGetLevenshteinDistance_SShorter_TExceedsThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "abcxyz", 2));
    }

    @Test
    void testGetLevenshteinDistance_IdenticalStrings() {
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abc", 1));
    }

    @Test
    void testGetLevenshteinDistance_SingleSubstitutionWithinThreshold() {
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "axc", 1));
    }

    @Test
    void testGetLevenshteinDistance_SingleSubstitutionExceedsThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "axc", 0));
    }

    @Test
    void testGetLevenshteinDistance_MultipleSubstitutionsWithinThreshold() {
        assertEquals(3, StringUtils.getLevenshteinDistance("kitten", "sitting", 3));
    }

    @Test
    void testGetLevenshteinDistance_MultipleSubstitutionsExceedsThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("kitten", "sitting", 2));
    }

    @Test
    void testGetLevenshteinDistance_LengthDifferenceEqualsThreshold() {
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abcd", 1));
    }

    @Test
    void testGetLevenshteinDistance_LengthDifferenceOneBelowThreshold() {
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abxd", 2));
    }

    @Test
    void testGetLevenshteinDistance_LengthDifferenceExactlyThreshold() {
        assertEquals(2, StringUtils.getLevenshteinDistance("abcde", "abxyzc", 2));
    }

}