import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.dfp.DfpField.RoundingMode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class DfpTest {

    private DfpField field;
    private Dfp zero;
    private Dfp one;
    private Dfp negativeOne;
    private Dfp infinity;
    private Dfp nan;

    @BeforeEach
    void setup() {
        field = new DfpField(4);
        zero = field.getZero();
        one = field.getOne();
        negativeOne = zero.newInstance(-1);
        infinity = zero.newInstance(Dfp.INFINITE);
        nan = zero.newInstance(Dfp.QNAN);
    }

    @Test
    void testDotrapInvalid() {
        Dfp result = zero.dotrap(DfpField.FLAG_INVALID, "someMethod", null, zero);
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testDotrapDivZeroFiniteNonZero() {
        Dfp result = one.dotrap(DfpField.FLAG_DIV_ZERO, "someMethod", zero, one);
        assertEquals(Dfp.INFINITE, result.classify());
        assertEquals(1, result.sign);
    }

    @Test
    void testDotrapDivZeroFiniteZero() {
        Dfp zeroNum = zero.newInstance(zero);
        Dfp result = zeroNum.dotrap(DfpField.FLAG_DIV_ZERO, "someMethod", zero, zeroNum);
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testDotrapDivZeroInfinite() {
        Dfp result = infinity.dotrap(DfpField.FLAG_DIV_ZERO, "someMethod", zero, infinity);
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testDotrapDivZeroSNAN() {
        Dfp sNan = zero.newInstance(Dfp.SNAN);
        Dfp result = sNan.dotrap(DfpField.FLAG_DIV_ZERO, "someMethod", zero, sNan);
        assertEquals(Dfp.QNAN, result.classify());
    }

    @Test
    void testDotrapUnderflowRegular() {
        Dfp exp = zero.newInstance(1);
        exp.exp = Dfp.MIN_EXP - 10;
        Dfp result = exp.dotrap(DfpField.FLAG_UNDERFLOW, "someMethod", null, exp);
        assertEquals(0, result.intValue());
    }

    @Test
    void testDotrapUnderflowGradual() {
        Dfp exp = zero.newInstance(1);
        exp.exp = Dfp.MIN_EXP + 10;
        Dfp result = exp.dotrap(DfpField.FLAG_UNDERFLOW, "someMethod", null, exp);
        assertEquals(exp.exp, result.exp);
    }

    @Test
    void testDotrapOverflow() {
        Dfp exp = zero.newInstance(1);
        exp.exp = Dfp.MAX_EXP + 10;
        Dfp result = exp.dotrap(DfpField.FLAG_OVERFLOW, "someMethod", null, exp);
        assertEquals(Dfp.INFINITE, result.classify());
    }

    @Test
    void testDotrapDefault() {
        int type = -1;
        Dfp result = zero.dotrap(type, "someMethod", null, one);
        assertEquals(one, result);
    }
}