package org.jfree.chart.renderer.xy;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CandlestickRenderer_drawItem_2_2_Test {

    @Test
    @DisplayName("drawItem uses item paint when downPaint is null and yClose < yOpen")
    public void TC26_drawItem_downPaintNull_yCloseLessThanYOpen() {
        // Arrange
        CandlestickRenderer renderer = new CandlestickRenderer();
        renderer.setUseOutlinePaint(false);
        renderer.setDownPaint(null); // downPaint is null
        renderer.setDrawVolume(false);
        
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        OHLCDataset dataset = mock(OHLCDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getHighValue(0, 0)).thenReturn(2.0);
        when(dataset.getLowValue(0, 0)).thenReturn(0.5);
        when(dataset.getOpenValue(0, 0)).thenReturn(2.0);
        when(dataset.getCloseValue(0, 0)).thenReturn(1.0); // yClose < yOpen
        
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        when(dataArea.getWidth()).thenReturn(800.0);
        when(dataArea.getHeight()).thenReturn(600.0);
        
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(400.0);
        
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(300.0);
        
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        // Assert
        // Verify that item paint is used instead of downPaint
        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).fill(any(Rectangle2D.class));
    }
}