package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_get_0_2_Test {

    @Test
    @DisplayName("delegateMap is null, key is null, size is 2, key2 is not null")
    public void TC06_delegateMapNull_keyNull_size2_key2NotNull() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field keyField = Flat3Map.class.getDeclaredField("key");
        keyField.setAccessible(true);
        keyField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2Value");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2Value");

        // Invoke the target method
        Object result = map.get(null);

        // Assert the expected result
        assertNull(result);
    }

    @Test
    @DisplayName("delegateMap is null, key is null, size is 3, key3 is null")
    public void TC07_delegateMapNull_keyNull_size3_key3Null() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field keyField = Flat3Map.class.getDeclaredField("key");
        keyField.setAccessible(true);
        keyField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3Value");

        // Invoke the target method
        Object result = map.get(null);

        // Assert the expected result
        assertEquals("value3Value", result);
    }

    @Test
    @DisplayName("delegateMap is null, key is null, size is 3, key3 is not null")
    public void TC08_delegateMapNull_keyNull_size3_key3NotNull() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field keyField = Flat3Map.class.getDeclaredField("key");
        keyField.setAccessible(true);
        keyField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3Value");

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, "key3Value".hashCode());

        Field keyFieldToCompare = Flat3Map.class.getDeclaredField("key3");
        keyFieldToCompare.setAccessible(true);
        keyFieldToCompare.set(map, "differentKey3Value");

        // Invoke the target method
        Object result = map.get(null);

        // Assert the expected result
        assertNull(result);
    }

    @Test
    @DisplayName("delegateMap is null, key is not null, size is 0")
    public void TC09_delegateMapNull_keyNotNull_size0() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        String someKey = "someKey";
        Field keyField = Flat3Map.class.getDeclaredField("key");
        keyField.setAccessible(true);
        keyField.set(map, someKey);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        // Invoke the target method
        Object result = map.get(someKey);

        // Assert the expected result
        assertNull(result);
    }

    @Test
    @DisplayName("delegateMap is null, key is not null, size is 1, hash matches and keys are equal")
    public void TC10_delegateMapNull_keyNotNull_size1_hashMatch_keyEqual() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map map = new Flat3Map();

        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        String targetKey = "targetKey";
        Field keyField = Flat3Map.class.getDeclaredField("key");
        keyField.setAccessible(true);
        keyField.set(map, targetKey);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, targetKey);

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, targetKey.hashCode());

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1Value");

        // Invoke the target method
        Object result = map.get(targetKey);

        // Assert the expected result
        assertEquals("value1Value", result);
    }
}