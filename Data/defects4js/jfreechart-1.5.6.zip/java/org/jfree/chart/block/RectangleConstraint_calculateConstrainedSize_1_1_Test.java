package org.jfree.chart.block;

import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RectangleConstraint_calculateConstrainedSize_1_1_Test {

    @Test
    @DisplayName("calculateConstrainedSize with null base Size2D throws NullPointerException")
    void TC15() {
        RectangleConstraint constraint = RectangleConstraint.NONE;
        Size2D base = null;
        assertThrows(NullPointerException.class, () -> {
            constraint.calculateConstrainedSize(base);
        });
    }

    @Test
    @DisplayName("calculateConstrainedSize with negative base width and height")
    void TC16() {
        RectangleConstraint constraint = RectangleConstraint.NONE;
        Size2D base = new Size2D(-100.0, -50.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(-100.0, result.getWidth(), "Width should be -100.0");
        assertEquals(-50.0, result.getHeight(), "Height should be -50.0");
    }

    @Test
    @DisplayName("calculateConstrainedSize with zero base width and fixed height is returned")
    void TC17() {
        double fixedHeight = 50.0;
        RectangleConstraint constraint = new RectangleConstraint(
                0.0, null, LengthConstraintType.NONE,
                fixedHeight, null, LengthConstraintType.FIXED);
        Size2D base = new Size2D(0.0, 50.0);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(0.0, result.getWidth(), "Width should be 0.0");
        assertEquals(fixedHeight, result.getHeight(), "Height should be fixed at 50.0");
    }

    @Test
    @DisplayName("calculateConstrainedSize with extremely large base Size2D is returned")
    void TC18() {
        double fixedWidth = Double.MAX_VALUE;
        double fixedHeight = Double.MAX_VALUE;
        RectangleConstraint constraint = new RectangleConstraint(
                fixedWidth, null, LengthConstraintType.FIXED,
                fixedHeight, null, LengthConstraintType.FIXED);
        Size2D base = new Size2D(Double.MAX_VALUE, Double.MAX_VALUE);
        Size2D result = constraint.calculateConstrainedSize(base);
        assertEquals(fixedWidth, result.getWidth(), "Width should be Double.MAX_VALUE");
        assertEquals(fixedHeight, result.getHeight(), "Height should be Double.MAX_VALUE");
    }
}