package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.*;

public class Base64Variant_decode_0_3_Test {

    @Test
    @DisplayName("decode with multiple iterations processes entire string correctly")
    void TC11() throws Exception {
        // GIVEN
        String str = "TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        // Instantiate Base64Variant using reflection if necessary
        Base64Variant variant = instantiateBase64Variant();
        
        // WHEN
        variant.decode(str, builder);
        
        // THEN
        byte[] expected = "Man is distinguishing, not only".getBytes();
        assertArrayEquals(expected, builder.toByteArray());
    }

    @Test
    @DisplayName("decode encounters invalid padding character and throws IllegalArgumentException")
    void TC12() throws Exception {
        // GIVEN
        String str = "TWE!";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        Base64Variant variant = instantiateBase64Variant();
        
        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> variant.decode(str, builder));
    }

    @Test
    @DisplayName("decode with padding when padding is required appends correctly")
    void TC13() throws Exception {
        // GIVEN
        String str = "TWE=";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        // Instantiate Base64Variant with requiresPaddingOnRead=true using reflection
        Base64Variant variant = instantiateBase64VariantWithPaddingRequired();
        
        // WHEN
        variant.decode(str, builder);
        
        // THEN
        byte[] expected = {77, 97};
        assertArrayEquals(expected, builder.toByteArray());
    }

    @Test
    @DisplayName("decode with non-padded input when padding is not required appends correctly")
    void TC14() throws Exception {
        // GIVEN
        String str = "TQ";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        // Instantiate Base64Variant with requiresPaddingOnRead=false using reflection
        Base64Variant variant = instantiateBase64VariantWithoutPaddingRequired();
        
        // WHEN
        variant.decode(str, builder);
        
        // THEN
        byte[] expected = {77};
        assertArrayEquals(expected, builder.toByteArray());
    }

    @Test
    @DisplayName("decode with whitespace within base64 string is ignored and decodes correctly")
    void TC15() throws Exception {
        // GIVEN
        String str = "T WF uI A0==";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        Base64Variant variant = instantiateBase64Variant();
        
        // WHEN
        variant.decode(str, builder);
        
        // THEN
        byte[] expected = "ManI4".getBytes();
        assertArrayEquals(expected, builder.toByteArray());
    }

    // Helper methods to instantiate Base64Variant with specific configurations using reflection
    private Base64Variant instantiateBase64Variant() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        return constructor.newInstance();
    }
    
    private Base64Variant instantiateBase64VariantWithPaddingRequired() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor(boolean.class);
        constructor.setAccessible(true);
        return constructor.newInstance(true);
    }
    
    private Base64Variant instantiateBase64VariantWithoutPaddingRequired() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor(boolean.class);
        constructor.setAccessible(true);
        return constructor.newInstance(false);
    }
}