package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.plot.Plot;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ChartPanel_mousePressed_0_3_Test {

    @Test
    @DisplayName("mousePressed does not show popup menu when popup trigger is true but popup is null")
    public void TC11_mousePressed_popupTriggeredButPopupIsNull() throws Exception {
        // GIVEN
        // Mock the JFreeChart and Plot objects
        JFreeChart chartMock = mock(JFreeChart.class);
        Plot plotMock = mock(Plot.class);
        when(chartMock.getPlot()).thenReturn(plotMock);

        // Create an instance of ChartPanel with the mocked chart
        ChartPanel chartPanel = new ChartPanel(chartMock);

        // Using reflection to set 'popup' to null
        Field popupField = ChartPanel.class.getDeclaredField("popup");
        popupField.setAccessible(true);
        popupField.set(chartPanel, null);

        // Mock the MouseEvent
        MouseEvent e = mock(MouseEvent.class);
        when(e.getModifiers()).thenReturn(0);
        when(e.getX()).thenReturn(300);
        when(e.getY()).thenReturn(300);
        when(e.isPopupTrigger()).thenReturn(true);

        // Mock the getScreenDataArea method using reflection
        Method getScreenDataAreaMethod = ChartPanel.class.getDeclaredMethod("getScreenDataArea", int.class, int.class);
        getScreenDataAreaMethod.setAccessible(true);
        Rectangle2D screenDataArea = new Rectangle2D.Double(250, 250, 300, 300);
        when((Rectangle2D) getScreenDataAreaMethod.invoke(chartPanel, 300, 300)).thenReturn(screenDataArea);

        // WHEN
        chartPanel.mousePressed(e);

        // THEN
        // Since popup is null, no popup should be displayed. Verify that 'setCursor' is not called.
        // Alternatively, if 'setCursor' is expected to be called elsewhere, adjust the verification accordingly.
        // Here, we assume no action is taken regarding the popup.
        // No exception means the test passes.
        assertTrue(true, "No popup menu should be displayed when popup is null and popup trigger is true.");
    }

    @Test
    @DisplayName("mousePressed does not show popup menu when popup trigger is false")
    public void TC12_mousePressed_popupNotTriggered() throws Exception {
        // GIVEN
        // Mock the JFreeChart and Plot objects
        JFreeChart chartMock = mock(JFreeChart.class);
        Plot plotMock = mock(Plot.class);
        when(chartMock.getPlot()).thenReturn(plotMock);

        // Create an instance of ChartPanel with the mocked chart
        ChartPanel chartPanel = new ChartPanel(chartMock);

        // Mock the MouseEvent
        MouseEvent e = mock(MouseEvent.class);
        when(e.getModifiers()).thenReturn(0);
        when(e.getX()).thenReturn(350);
        when(e.getY()).thenReturn(350);
        when(e.isPopupTrigger()).thenReturn(false);

        // Mock the getScreenDataArea method using reflection
        Method getScreenDataAreaMethod = ChartPanel.class.getDeclaredMethod("getScreenDataArea", int.class, int.class);
        getScreenDataAreaMethod.setAccessible(true);
        Rectangle2D screenDataArea = new Rectangle2D.Double(300, 300, 300, 300);
        when((Rectangle2D) getScreenDataAreaMethod.invoke(chartPanel, 350, 350)).thenReturn(screenDataArea);

        // WHEN
        chartPanel.mousePressed(e);

        // THEN
        // Since popup trigger is false, no popup should be displayed. Verify that 'displayPopupMenu' is not called.
        // This can be done by spying on the ChartPanel instance.
        ChartPanel spyChartPanel = spy(chartPanel);
        verify(spyChartPanel, times(0)).displayPopupMenu(anyInt(), anyInt());
    }
}