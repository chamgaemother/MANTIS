package org.joda.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.lang.reflect.Field;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class PeriodType_forFields_0_3_Test {

    /**
     * Utility method to access private static fields via reflection.
     */
    private Map<PeriodType, Object> getCTypes() throws NoSuchFieldException, IllegalAccessException {
        Field cTypesField = PeriodType.class.getDeclaredField("cTypes");
        cTypesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<PeriodType, Object> cTypes = (Map<PeriodType, Object>) cTypesField.get(null);
        return cTypes;
    }

    /**
     * Utility method to reset the cTypes cache before each test.
     */
    private void resetCTypes() throws NoSuchFieldException, IllegalAccessException {
        Map<PeriodType, Object> cTypes = getCTypes();
        cTypes.clear();
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when unsupported fields remain after removal")
    public void TC11_forFields_unsupportedFieldsAfterRemoval() throws Exception {
        // Reset cache
        resetCTypes();

        // Given
        DurationFieldType[] types = new DurationFieldType[] {
            DurationFieldType.years(),
            DurationFieldType.months(),
            DurationFieldType.centuries() // Unsupported field
        };

        // When & Then
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            PeriodType.forFields(types);
        });
        assertEquals("PeriodType does not support fields: [centuries]", exception.getMessage());
    }

    @Test
    @DisplayName("Returns PeriodType after rechecking cache with reordered types")
    public void TC12_forFields_cacheRecheck() throws Exception {
        // Reset cache
        resetCTypes();

        // Given
        DurationFieldType[] types = new DurationFieldType[] {
            DurationFieldType.days(),
            DurationFieldType.years()
        };
        PeriodType processedType = PeriodType.standard().withYearsRemoved(); // Correct method to remove years

        // Access cTypes and put the precondition
        Map<PeriodType, Object> cTypes = getCTypes();
        PeriodType key = new PeriodType(null, types, null);
        cTypes.put(key, processedType);

        // When
        PeriodType result = PeriodType.forFields(types);

        // Then
        assertEquals(processedType, result);
    }

    @Test
    @DisplayName("Handles single iteration in types array without removing any fields")
    public void TC13_forFields_singleIterationAllSupported() throws Exception {
        // Reset cache
        resetCTypes();

        // Given
        DurationFieldType[] types = new DurationFieldType[] {
            DurationFieldType.years(),
            DurationFieldType.months(),
            DurationFieldType.weeks(),
            DurationFieldType.days(),
            DurationFieldType.hours(),
            DurationFieldType.minutes(),
            DurationFieldType.seconds(),
            DurationFieldType.millis()
        };

        // When
        PeriodType result = PeriodType.forFields(types);

        // Then
        assertEquals(PeriodType.standard(), result);
    }
}
