package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryToHexDigit_0_1_Test {

    @Test
    @DisplayName("Throws IllegalArgumentException when src is empty")
    void TC01_empty_src_throws_exception() {
        // GIVEN
        boolean[] src = new boolean[] {};
        int srcPos = 0;

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            Conversion.binaryToHexDigit(src, srcPos);
        });
        assertEquals("Cannot convert an empty array.", exception.getMessage());
    }

    @Test
    @DisplayName("Returns 'f' when src.length > srcPos + 3 and src[srcPos+3], src[srcPos+2], src[srcPos+1], src[srcPos] are all true")
    void TC02_returns_f_for_all_true_higher_bits() {
        // GIVEN
        boolean[] src = new boolean[] {true, true, true, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('f', result);
    }

    @Test
    @DisplayName("Returns 'e' when src.length > srcPos + 3 and src[srcPos+3], src[srcPos+2], src[srcPos+1] are true and src[srcPos] is false")
    void TC03_returns_e_when_src_pos_is_false() {
        // GIVEN
        boolean[] src = new boolean[] {false, true, true, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('e', result);
    }

    @Test
    @DisplayName("Returns 'd' when src.length > srcPos + 3 and src[srcPos+3], src[srcPos+2] are true, src[srcPos+1] is false, src[srcPos] is true")
    void TC04_returns_d_when_src_pos1_false_and_src_pos_true() {
        // GIVEN
        boolean[] src = new boolean[] {true, false, true, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('d', result);
    }

    @Test
    @DisplayName("Returns 'c' when src.length > srcPos + 3 and src[srcPos+3], src[srcPos+2] are true, src[srcPos+1], src[srcPos] are false")
    void TC05_returns_c_when_src_pos1_and_src_pos_false() {
        // GIVEN
        boolean[] src = new boolean[] {false, false, true, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryToHexDigit(src, srcPos);

        // THEN
        assertEquals('c', result);
    }
}