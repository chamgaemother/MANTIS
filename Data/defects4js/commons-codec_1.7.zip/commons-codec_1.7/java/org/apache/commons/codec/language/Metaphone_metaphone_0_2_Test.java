package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.Metaphone;

/**
 * JUnit 5 tests for the Metaphone.metaphone method.
 */
public class Metaphone_metaphone_0_2_Test {

    @Test
    @DisplayName("metaphone word starting with 'PH' converts to 'F'")
    public void testTC06_metaphone_PH_prefix() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String txt = "phone";
        String expected = "FN";

        // Act
        String result = metaphone.metaphone(txt);

        // Assert
        assertEquals(expected, result, "PH-prefix should be converted to 'F'");
    }

    @Test
    @DisplayName("metaphone word starting with 'WR' removes initial 'W'")
    public void testTC07_metaphone_WR_prefix() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String txt = "write";
        String expected = "RT";

        // Act
        String result = metaphone.metaphone(txt);

        // Assert
        assertEquals(expected, result, "Initial 'W' should be removed for 'WR' prefix");
    }

    @Test
    @DisplayName("metaphone word starting with 'X' converts initial 'X' to 'S'")
    public void testTC08_metaphone_X_prefix() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String txt = "xylophone";
        String expected = "SLPHN";

        // Act
        String result = metaphone.metaphone(txt);

        // Assert
        assertEquals(expected, result, "Initial 'X' should be converted to 'S'");
    }

    @Test
    @DisplayName("metaphone word with silent 'B' at end (e.g., 'lamb')")
    public void testTC09_metaphone_silent_B() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String txt = "lamb";
        String expected = "LMF";

        // Act
        String result = metaphone.metaphone(txt);

        // Assert
        assertEquals(expected, result, "Silent 'B' at the end should be ignored");
    }

    @Test
    @DisplayName("metaphone word with 'CIA' converts to 'X'")
    public void testTC10_metaphone_CIA_sequence() {
        // Arrange
        Metaphone metaphone = new Metaphone();
        String txt = "specialia";
        String expected = "SPLX";

        // Act
        String result = metaphone.metaphone(txt);

        // Assert
        assertEquals(expected, result, "'CIA' sequence should be converted to 'X'");
    }
}