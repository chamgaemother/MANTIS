package org.apache.commons.math3.fitting.leastsquares;

import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer.Optimum;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.apache.commons.math3.util.Incrementor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class LevenbergMarquardtOptimizer_optimize_0_5_Test {

//    @Test
//    @DisplayName("Optimize with maxCosine exceeding orthoTolerance throws ConvergenceException")
//    void TC21_Optimize_MaxCosineExceedsOrthoTolerance_ThrowsConvergenceException() {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        Incrementor iterationCounter = Mockito.spy(new Incrementor()); // Fixed: use mock/spied Incremetor
//        Incrementor evaluationCounter = Mockito.spy(new Incrementor());
//        ConvergenceChecker<Optimum> checker = mock(ConvergenceChecker.class);
//
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Optimum currentOptimum = mock(Optimum.class);
//        when(currentOptimum.getCost()).thenReturn(1000.0);
//        when(currentOptimum.getPoint()).thenReturn(new ArrayRealVector(new double[]{1, 2, 3, 4, 5}));
//
//        when(problem.evaluate(any(RealVector.class))).thenReturn(currentOptimum);
//        when(checker.converged(anyInt(), any(), any())).thenReturn(false);
//
//        Assertions.assertThrows(ConvergenceException.class, () -> {
//            optimizer.optimize(problem);
//        });
//    }
//
//    @Test
//    @DisplayName("Optimize correctly handles parameter updates when lmPar is zero")
//    void TC22_Optimize_LmParZero_HandlesParameterUpdatesCorrectly() {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        Incrementor iterationCounter = Mockito.spy(new Incrementor()); // Fixed: use mock/spied Incremetor
//        Incrementor evaluationCounter = Mockito.spy(new Incrementor());
//        ConvergenceChecker<Optimum> checker = mock(ConvergenceChecker.class);
//
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        when(problem.evaluate(any(RealVector.class))).thenAnswer(invocation -> {
//            RealVector vector = invocation.getArgument(0);
//            return new OptimumImpl(new ArrayRealVector(vector.toArray()), 0, 0);
//        });
//
//        when(checker.converged(anyInt(), any(), any())).thenReturn(true);
//
//        Optimum optimum = optimizer.optimize(problem);
//
//        Assertions.assertNotNull(optimum);
//        Assertions.assertEquals(0.0, optimum.getCost(), 1e-6);
//        Assertions.assertArrayEquals(new double[]{1, 2, 3, 4, 5}, optimum.getPoint().toArray(), 1e-6);
//    }
//
//    @Test
//    @DisplayName("Optimize detects insufficient cost reduction and throws ConvergenceException")
//    void TC23_Optimize_InsufficientCostReduction_ThrowsConvergenceException() {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        Incrementor iterationCounter = Mockito.spy(new Incrementor()); // Fixed: use mock/spied Incremetor
//        Incrementor evaluationCounter = Mockito.spy(new Incrementor());
//        ConvergenceChecker<Optimum> checker = mock(ConvergenceChecker.class);
//
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Optimum currentOptimum = mock(Optimum.class);
//        when(currentOptimum.getCost()).thenReturn(1e-10);
//        when(currentOptimum.getPoint()).thenReturn(new ArrayRealVector(new double[]{1, 2, 3, 4, 5}));
//
//        when(problem.evaluate(any(RealVector.class))).thenReturn(currentOptimum);
//        when(checker.converged(anyInt(), any(), any())).thenReturn(false);
//
//        Assertions.assertThrows(ConvergenceException.class, () -> {
//            optimizer.optimize(problem);
//        });
//    }
//
//    @Test
//    @DisplayName("Optimize with valid LeastSquaresProblem resulting in successful convergence")
//    void TC24_Optimize_ValidProblem_SuccessfulConvergence() {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        Incrementor iterationCounter = Mockito.spy(new Incrementor()); // Fixed: use mock/spied Incremetor
//        Incrementor evaluationCounter = Mockito.spy(new Incrementor());
//        ConvergenceChecker<Optimum> checker = mock(ConvergenceChecker.class);
//
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Optimum currentOptimum = mock(Optimum.class);
//        when(currentOptimum.getCost()).thenReturn(1e-6);
//        when(currentOptimum.getPoint()).thenReturn(new ArrayRealVector(new double[]{1, 2, 3, 4, 5}));
//
//        when(problem.evaluate(any(RealVector.class))).thenReturn(currentOptimum);
//        when(checker.converged(anyInt(), any(), any())).thenReturn(true);
//
//        Optimum optimum = optimizer.optimize(problem);
//
//        Assertions.assertNotNull(optimum);
//        Assertions.assertEquals(1e-6, optimum.getCost(), 1e-8);
//        Assertions.assertArrayEquals(new double[]{1, 2, 3, 4, 5}, optimum.getPoint().toArray(), 1e-6);
//    }
//
//    @Test
//    @DisplayName("Optimize adjusts delta correctly when actual reduction is negative")
//    void TC25_Optimize_NegativeActualReduction_AdjustsDeltaCorrectly() {
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = mock(LeastSquaresProblem.class);
//        Incrementor iterationCounter = Mockito.spy(new Incrementor()); // Fixed: use mock/spied Incremetor
//        Incrementor evaluationCounter = Mockito.spy(new Incrementor());
//        ConvergenceChecker<Optimum> checker = mock(ConvergenceChecker.class);
//
//        when(problem.getObservationSize()).thenReturn(10);
//        when(problem.getParameterSize()).thenReturn(5);
//        when(problem.getIterationCounter()).thenReturn(iterationCounter);
//        when(problem.getEvaluationCounter()).thenReturn(evaluationCounter);
//        when(problem.getConvergenceChecker()).thenReturn(checker);
//
//        Optimum currentOptimum = mock(Optimum.class);
//        when(currentOptimum.getCost()).thenReturn(500.0);
//        when(currentOptimum.getPoint()).thenReturn(new ArrayRealVector(new double[]{1, 2, 3, 4, 5}));
//
//        when(problem.evaluate(any(RealVector.class))).thenReturn(currentOptimum);
//        when(checker.converged(anyInt(), any(), any())).thenReturn(false);
//
//        Optimum optimum = optimizer.optimize(problem);
//
//        Assertions.assertNotNull(optimum);
//        Assertions.assertEquals(500.0, optimum.getCost(), 1e-6);
//        Assertions.assertArrayEquals(new double[]{1, 2, 3, 4, 5}, optimum.getPoint().toArray(), 1e-6);
//    }

}