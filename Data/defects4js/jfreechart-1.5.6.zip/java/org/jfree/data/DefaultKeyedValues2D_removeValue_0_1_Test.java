package org.jfree.data;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DefaultKeyedValues2D_removeValue_0_1_Test {

    @Test
    @DisplayName("Successfully remove a value from an existing row and column without removing the row or column")
    void TC01_successfulRemovalWithoutRowOrColumnDeletion() throws Exception {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(10, "Row1", "Col1");
        data.addValue(20, "Row1", "Col2");

        // WHEN
        data.removeValue("Row1", "Col1");

        // THEN
        assertNull(data.getValue("Row1", "Col1"), "Value at 'Row1', 'Col1' should be null");
        assertEquals(1, data.getRowCount(), "Row count should remain 1");
        assertEquals(2, data.getColumnCount(), "Column count should remain 2");
    }

    @Test
    @DisplayName("Remove a value resulting in the row becoming empty and the row being removed")
    void TC02_removalLeadingToRowDeletion() throws Exception {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(30, "Row2", "Col1");

        // WHEN
        data.removeValue("Row2", "Col1");

        // THEN
        assertNull(data.getValue("Row2", "Col1"), "Value at 'Row2', 'Col1' should be null");
        assertEquals(0, data.getRowCount(), "Row count should be 0 after removal");
        assertEquals(0, data.getColumnCount(), "Column count should be 0 after removal");
    }

    @Test
    @DisplayName("Attempt to remove a value from a non-existing rowKey, expecting no changes")
    void TC03_removalFromNonExistingRow() throws Exception {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();

        // WHEN
        data.removeValue("Row3", "Col1");

        // THEN
        assertEquals(0, data.getRowCount(), "Row count should remain 0");
        assertEquals(1, data.getColumnCount(), "Column count should remain 1");
    }

    @Test
    @DisplayName("Remove a value from a non-existing columnKey, leading to column being removed if applicable")
    void TC04_removalFromNonExistingColumn() throws Exception {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(40, "Row1", "Col1");

        // WHEN
        data.removeValue("Row1", "Col3");

        // THEN
        assertNull(data.getValue("Row1", "Col3"), "Value at 'Row1', 'Col3' should be null");
        assertEquals(1, data.getColumnCount(), "Column count should remain 1");
    }

    @Test
    @DisplayName("Remove a value from a column existing in multiple rows, resulting in column removal when all values are null")
    void TC05_removalLeadingToColumnDeletionAcrossMultipleRows() throws Exception {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();
        data.addValue(50, "Row1", "Col2");
        data.addValue(60, "Row2", "Col2");

        // WHEN
        data.removeValue("Row1", "Col2");
        data.removeValue("Row2", "Col2");

        // THEN
        assertNull(data.getValue("Row1", "Col2"), "Value at 'Row1', 'Col2' should be null");
        assertNull(data.getValue("Row2", "Col2"), "Value at 'Row2', 'Col2' should be null");
        assertEquals(0, data.getColumnCount(), "Column count should be 0 after all removals");
    }
}