package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class BcBands_visitMethodInsn_0_3_Test {

    static class CpBands {
        // Simulating the method call
        public CPMethodOrField getCPMethod(String owner, String name, String desc) {
            return new CPMethodOrField();
        }

        public CPConstant<?> getConstant(Object cst) {
            return new CPConstant<>();
        }

        public CPMethodOrField getCPField(String owner, String name, String desc) {
            return new CPMethodOrField();
        }

        public CPMethodOrField getCPIMethod(String owner, String name, String desc) {
            return new CPMethodOrField();
        }

        public CPClass getCPClass(String desc) {
            return new CPClass();
        }
    }

    static class Segment {
        public boolean lastConstantHadWideIndex() { return false; }
        public ClassBands getClassBands() { return new ClassBands(); }
    }

    static class CPMethodOrField {}
    static class CPConstant<T> {}
    static class CPClass {}
    static class ClassBands {
        public void doBciRenumbering(IntList bciRenumbering, Map<Label, Integer> labelsToOffsets) {}
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), owner equals currentNewClass and name is <init>")
    void TC11() throws Exception {
        // GIVEN
        int opcode = 183;
        String owner = "currentNewClass";
        String name = "<init>";
        String desc = "()V";
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(cpBands, segment, 0);

        // Access and set private fields via reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        bcCodesField.set(bcBands, new ArrayList<>());

        Field currentNewClassField = BcBands.class.getDeclaredField("currentNewClass");
        currentNewClassField.setAccessible(true);
        currentNewClassField.set(bcBands, "currentNewClass");

        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        bcInitRefField.set(bcBands, new ArrayList<>());

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Assert bcInitRef contains the method reference
        List<?> bcInitRef = (List<?>) bcInitRefField.get(bcBands);
        assertFalse(bcInitRef.isEmpty(), "bcInitRef should contain the method reference");

        // Assert ALOAD_0 is added back to bcCodes
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(42), "ALOAD_0 should be added back to bcCodes");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), name is not <init> and owner matches currentNewClass")
    void TC12() throws Exception {
        // GIVEN
        int opcode = 183;
        String owner = "currentNewClass";
        String name = "newMethod";
        String desc = "(I)V";
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(cpBands, segment, 0);

        // Access and set private fields via reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        bcCodesField.set(bcBands, new ArrayList<>());

        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        bcMethodRefField.set(bcBands, new ArrayList<>());

        Field currentNewClassField = BcBands.class.getDeclaredField("currentNewClass");
        currentNewClassField.setAccessible(true);
        currentNewClassField.set(bcBands, "currentNewClass");

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Assert bcMethodRef contains the method reference
        List<?> bcMethodRef = (List<?>) bcMethodRefField.get(bcBands);
        assertFalse(bcMethodRef.isEmpty(), "bcMethodRef should contain the method reference");

        // Assert ALOAD_0 is not added
        List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
        assertFalse(bcCodes.contains(42), "ALOAD_0 should not be added to bcCodes");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), z1 is true")
    void TC13() throws Exception {
        // GIVEN
        int opcode = 183;
        String owner = "anotherClass";
        String name = "anotherMethod";
        String desc = "(Ljava/lang/String;)V";
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(cpBands, segment, 0);

        // Access and set private fields via reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = new ArrayList<>();
        bcCodes.add(42); // Simulating existing ALOAD_0
        bcCodesField.set(bcBands, bcCodes);

        Field currentClassField = BcBands.class.getDeclaredField("currentClass");
        currentClassField.setAccessible(true);
        currentClassField.set(bcBands, "currentClass");

        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        bcMethodRefField.set(bcBands, new ArrayList<>());

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Assert bcMethodRef contains the method reference
        List<?> bcMethodRef = (List<?>) bcMethodRefField.get(bcBands);
        assertFalse(bcMethodRef.isEmpty(), "bcMethodRef should contain the method reference");

        // Assert ALOAD_0 is not added back
        assertFalse(bcCodes.contains(42), "ALOAD_0 should not be added back to bcCodes");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokespecial (183), owner is currentClass and name is <init>")
    void TC14() throws Exception {
        // GIVEN
        int opcode = 183;
        String owner = "currentClass";
        String name = "<init>";
        String desc = "()V";
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(cpBands, segment, 0);

        // Access and set private fields via reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = new ArrayList<>();
        bcCodes.add(42); // Simulating existing ALOAD_0
        bcCodesField.set(bcBands, bcCodes);

        Field currentClassField = BcBands.class.getDeclaredField("currentClass");
        currentClassField.setAccessible(true);
        currentClassField.set(bcBands, "currentClass");

        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        bcInitRefField.set(bcBands, new ArrayList<>());

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Assert bcInitRef contains the method reference
        List<?> bcInitRef = (List<?>) bcInitRefField.get(bcBands);
        assertFalse(bcInitRef.isEmpty(), "bcInitRef should contain the method reference");
    }

    @Test
    @DisplayName("visitMethodInsn with opcode invokevirtual (182) and bcCodes has last code ALOAD_0")
    void TC15() throws Exception {
        // GIVEN
        int opcode = 182;
        String owner = "externalClass";
        String name = "externalMethod";
        String desc = "(I)V";
        CpBands cpBands = new CpBands();
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(cpBands, segment, 0);

        // Access and set private fields via reflection
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = new ArrayList<>();
        bcCodes.add(42); // ALOAD_0 at the end
        bcCodesField.set(bcBands, bcCodes);

        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        bcMethodRefField.set(bcBands, new ArrayList<>());

        // WHEN
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // THEN
        // Assert ALOAD_0 is removed from bcCodes
        List<Integer> updatedBcCodes = (List<Integer>) bcCodesField.get(bcBands);
        assertFalse(updatedBcCodes.contains(42), "ALOAD_0 should be removed from bcCodes");

        // Assert bcMethodRef contains the method reference
        List<?> bcMethodRef = (List<?>) bcMethodRefField.get(bcBands);
        assertFalse(bcMethodRef.isEmpty(), "bcMethodRef should contain the method reference");
    }
}
