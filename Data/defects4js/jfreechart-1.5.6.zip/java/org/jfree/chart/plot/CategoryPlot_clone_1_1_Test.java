package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.CategoryAxis;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class CategoryPlot_clone_1_1_Test {
    
    @Test
    @DisplayName("TC01: Clone CategoryPlot with empty domainAxes and rangeAxes")
    public void testCloneWithEmptyAxes() throws Exception {
        // GIVEN
        CategoryPlot original = new CategoryPlot();
        original.clearDomainAxes();
        original.clearRangeAxes();
        
        // WHEN
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        // THEN
        assertTrue(clone.getDomainAxes().isEmpty(), "Cloned domainAxes should be empty");
        assertTrue(clone.getRangeAxes().isEmpty(), "Cloned rangeAxes should be empty");

        // Verify that domainAxisLocations are correctly copied
        Field domainAxisLocationsField = CategoryPlot.class.getDeclaredField("domainAxisLocations");
        domainAxisLocationsField.setAccessible(true);
        Map<?, ?> originalDomainLocations = (Map<?, ?>) domainAxisLocationsField.get(original);
        Map<?, ?> clonedDomainLocations = (Map<?, ?>) domainAxisLocationsField.get(clone);
        assertEquals(originalDomainLocations, clonedDomainLocations, "DomainAxisLocations should be equal");

        // Verify that rangeAxisLocations are correctly copied
        Field rangeAxisLocationsField = CategoryPlot.class.getDeclaredField("rangeAxisLocations");
        rangeAxisLocationsField.setAccessible(true);
        Map<?, ?> originalRangeLocations = (Map<?, ?>) rangeAxisLocationsField.get(original);
        Map<?, ?> clonedRangeLocations = (Map<?, ?>) rangeAxisLocationsField.get(clone);
        assertEquals(originalRangeLocations, clonedRangeLocations, "RangeAxisLocations should be equal");
    }
    
    @Test
    @DisplayName("TC02: Clone CategoryPlot with non-null domainAxes and rangeAxes")
    public void testCloneWithNonNullAxes() throws Exception {
        // GIVEN
        CategoryPlot original = new CategoryPlot();
        CategoryAxis domainAxis = new CategoryAxis("Domain Axis");
        ValueAxis rangeAxis = new NumberAxis("Range Axis");
        original.setDomainAxis(domainAxis);
        original.setRangeAxis(rangeAxis);
        
        // WHEN
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        // THEN
        assertNotNull(clone.getDomainAxis(0), "Cloned domainAxis should not be null");
        assertNotNull(clone.getRangeAxis(0), "Cloned rangeAxis should not be null");
        assertNotSame(original.getDomainAxis(0), clone.getDomainAxis(0), "Cloned domainAxis should be a different instance");
        assertNotSame(original.getRangeAxis(0), clone.getRangeAxis(0), "Cloned rangeAxis should be a different instance");
        
        // Verify that cloned axes are linked to the clone plot
        Field domainAxisField = CategoryPlot.class.getDeclaredField("domainAxes");
        domainAxisField.setAccessible(true);
        Map<?, ?> clonedDomainAxes = (Map<?, ?>) domainAxisField.get(clone);
        CategoryAxis clonedDomainAxis = (CategoryAxis) clonedDomainAxes.get(0);
        assertEquals(clone, clonedDomainAxis.getPlot(), "Cloned domainAxis should be linked to the cloned plot");
        
        Field rangeAxisField = CategoryPlot.class.getDeclaredField("rangeAxes");
        rangeAxisField.setAccessible(true);
        Map<?, ?> clonedRangeAxes = (Map<?, ?>) rangeAxisField.get(clone);
        ValueAxis clonedRangeAxis = (ValueAxis) clonedRangeAxes.get(0);
        assertEquals(clone, clonedRangeAxis.getPlot(), "Cloned rangeAxis should be linked to the cloned plot");
    }
    
    @Test
    @DisplayName("TC03: Clone CategoryPlot with some null domainAxes")
    public void testCloneWithPartialNullDomainAxes() throws Exception {
        // GIVEN
        CategoryPlot original = new CategoryPlot();
        CategoryAxis domainAxis1 = new CategoryAxis("Domain Axis 1");
        CategoryAxis domainAxis3 = new CategoryAxis("Domain Axis 3");
        original.setDomainAxis(0, domainAxis1);
        original.setDomainAxis(1, null);
        original.setDomainAxis(2, domainAxis3);
        
        // WHEN
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        // THEN
        assertNotNull(clone.getDomainAxis(0), "Clone should have non-null domainAxis at index 0");
        assertNull(clone.getDomainAxis(1), "Clone should have null domainAxis at index 1");
        assertNotNull(clone.getDomainAxis(2), "Clone should have non-null domainAxis at index 2");
        
        // Verify that non-null domainAxes are linked to the clone plot
        Field domainAxisLocationsField = CategoryPlot.class.getDeclaredField("domainAxisLocations");
        domainAxisLocationsField.setAccessible(true);
        Map<?, ?> clonedDomainLocations = (Map<?, ?>) domainAxisLocationsField.get(clone);
        
        Field domainAxesField = CategoryPlot.class.getDeclaredField("domainAxes");
        domainAxesField.setAccessible(true);
        Map<?, ?> clonedDomainAxes = (Map<?, ?>) domainAxesField.get(clone);
        CategoryAxis clonedDomainAxis1 = (CategoryAxis) clonedDomainAxes.get(0);
        CategoryAxis clonedDomainAxis3 = (CategoryAxis) clonedDomainAxes.get(2);
        assertEquals(clone, clonedDomainAxis1.getPlot(), "Cloned domainAxis1 should be linked to the cloned plot");
        assertEquals(clone, clonedDomainAxis3.getPlot(), "Cloned domainAxis3 should be linked to the cloned plot");
    }
    
    @Test
    @DisplayName("TC04: Clone CategoryPlot with some null rangeAxes")
    public void testCloneWithPartialNullRangeAxes() throws Exception {
        // GIVEN
        CategoryPlot original = new CategoryPlot();
        ValueAxis rangeAxis1 = new NumberAxis("Range Axis 1");
        ValueAxis rangeAxis3 = new NumberAxis("Range Axis 3");
        original.setRangeAxis(0, rangeAxis1);
        original.setRangeAxis(1, null);
        original.setRangeAxis(2, rangeAxis3);
        
        // WHEN
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        // THEN
        assertNotNull(clone.getRangeAxis(0), "Clone should have non-null rangeAxis at index 0");
        assertNull(clone.getRangeAxis(1), "Clone should have null rangeAxis at index 1");
        assertNotNull(clone.getRangeAxis(2), "Clone should have non-null rangeAxis at index 2");
        
        // Verify that non-null rangeAxes are linked to the clone plot
        Field rangeAxisLocationsField = CategoryPlot.class.getDeclaredField("rangeAxisLocations");
        rangeAxisLocationsField.setAccessible(true);
        Map<?, ?> clonedRangeLocations = (Map<?, ?>) rangeAxisLocationsField.get(clone);
        
        Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
        rangeAxesField.setAccessible(true);
        Map<?, ?> clonedRangeAxes = (Map<?, ?>) rangeAxesField.get(clone);
        ValueAxis clonedRangeAxis1 = (ValueAxis) clonedRangeAxes.get(0);
        ValueAxis clonedRangeAxis3 = (ValueAxis) clonedRangeAxes.get(2);
        assertEquals(clone, clonedRangeAxis1.getPlot(), "Cloned rangeAxis1 should be linked to the cloned plot");
        assertEquals(clone, clonedRangeAxis3.getPlot(), "Cloned rangeAxis3 should be linked to the cloned plot");
    }
    
    @Test
    @DisplayName("TC05: Clone CategoryPlot when fixedDomainAxisSpace is null")
    public void testCloneWithNullFixedDomainAxisSpace() throws Exception {
        // GIVEN
        CategoryPlot original = new CategoryPlot();
        original.setFixedDomainAxisSpace(null);
        
        // WHEN
        CategoryPlot clone = (CategoryPlot) original.clone();
        
        // THEN
        assertNull(clone.getFixedDomainAxisSpace(), "Cloned fixedDomainAxisSpace should be null");
    }
}