package org.jfree.chart.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;

public class DirectionalGradientPaintTransformer_transform_0_2_Test {

    @Test
    @DisplayName("Transform with start point (0,0), end point (0,bh), isCyclic=true for vertical gradient with offset")
    public void TC06() {
        // GIVEN
        float bx = 10f;
        float by = 20f;
        float bw = 30f;
        float bh = 40f;
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 0, bh, Color.BLUE, true);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();

        // WHEN
        GradientPaint result = transformer.transform(paint, target);

        // THEN
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 does not match expected value.");
        assertEquals(new Point2D.Float(bx, by + bh / 2), result.getPoint2(), "Point2 does not match expected value.");
        assertTrue(result.isCyclic(), "Cyclic flag should be true.");
    }

    @Test
    @DisplayName("Transform with start point non-zero, isCyclic=false for diagonal gradient")
    public void TC07() {
        // GIVEN
        float bx = 10f;
        float by = 20f;
        float bw = 30f;
        float bh = 40f;
        GradientPaint paint = new GradientPaint(5, 5, Color.RED, 10, 10, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();

        // WHEN
        GradientPaint result = transformer.transform(paint, target);

        // THEN
        assertEquals(new Point2D.Float(bx, by + bh), result.getPoint1(), "Point1 does not match expected value.");
        float expectedRx2 = bx + (bw + bh) / 2;
        float expectedRy2 = by + bh - (bw + bh) / 2;
        assertEquals(new Point2D.Float(expectedRx2, expectedRy2), result.getPoint2(), "Point2 does not match expected value.");
        assertFalse(result.isCyclic(), "Cyclic flag should be false.");
    }

    @Test
    @DisplayName("Transform with start point non-zero, isCyclic=true for diagonal gradient with offset")
    public void TC08() {
        // GIVEN
        float bx = 10f;
        float by = 20f;
        float bw = 30f;
        float bh = 40f;
        GradientPaint paint = new GradientPaint(5, 5, Color.RED, 10, 10, Color.BLUE, true);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();

        // WHEN
        GradientPaint result = transformer.transform(paint, target);

        // THEN
        assertEquals(new Point2D.Float(bx, by + bh), result.getPoint1(), "Point1 does not match expected value.");
        float expectedRx2 = bx + (bw + bh) / 4;
        float expectedRy2 = by + bh - (bw + bh) / 4;
        assertEquals(new Point2D.Float(expectedRx2, expectedRy2), result.getPoint2(), "Point2 does not match expected value.");
        assertTrue(result.isCyclic(), "Cyclic flag should be true.");
    }

    @Test
    @DisplayName("Transform with start point (0,0), end point (0,0), isCyclic=false resulting in same start and end points")
    public void TC09() {
        // GIVEN
        float bx = 10f;
        float by = 20f;
        float bw = 30f;
        float bh = 40f;
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 0, 0, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();

        // WHEN
        GradientPaint result = transformer.transform(paint, target);

        // THEN
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 does not match expected value.");
        assertEquals(new Point2D.Float(bx, by), result.getPoint2(), "Point2 does not match expected value.");
        assertFalse(result.isCyclic(), "Cyclic flag should be false.");
    }

    @Test
    @DisplayName("Transform with start point (0,0), end point (0,0), isCyclic=true resulting in same start and end points with cyclic=true")
    public void TC10() {
        // GIVEN
        float bx = 10f;
        float by = 20f;
        float bw = 30f;
        float bh = 40f;
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 0, 0, Color.BLUE, true);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();

        // WHEN
        GradientPaint result = transformer.transform(paint, target);

        // THEN
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 does not match expected value.");
        assertEquals(new Point2D.Float(bx, by), result.getPoint2(), "Point2 does not match expected value.");
        assertTrue(result.isCyclic(), "Cyclic flag should be true.");
    }
}