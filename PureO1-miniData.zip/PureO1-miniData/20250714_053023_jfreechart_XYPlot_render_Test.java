package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.renderers.xy.XYItemRenderer;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.axis.ValueAxis;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class XYPlotTest {

    private XYPlot plot;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        plot = new XYPlot();
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        crosshairState = new CrosshairState();
    }

    @Test
    void render_NullDataset_ReturnsFalse() {
        plot.setDataset(null);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }

    @Test
    void render_EmptyDataset_ReturnsFalse() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(0);
        plot.setDataset(dataset);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }

    @Test
    void render_NullXAxis_ReturnsFalse() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        plot.setDomainAxis(null);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setRangeAxis(yAxis);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }

    @Test
    void render_NullYAxis_ReturnsFalse() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        plot.setDomainAxis(xAxis);
        plot.setRangeAxis(null);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }

    @Test
    void render_NullRendererAndDefaultRendererNull_ReturnsFalse() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setRangeAxis(yAxis);
        plot.setRenderer(null);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }

    @Test
    void render_NullRendererAndDefaultRendererNotNull_ReturnsTrue() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.isSeriesVisible(anyInt())).thenReturn(true);
        when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
        when(renderer.getLegendItem(anyInt(), anyInt())).thenReturn(null);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
    }

    @Test
    void render_RendererReturnsTrueForFoundData() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(0.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(0.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.isSeriesVisible(anyInt())).thenReturn(true);
        when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
        when(renderer.getLegendItem(anyInt(), anyInt())).thenReturn(null);
        when(renderer.initialise(any(Graphics2D.class), any(Rectangle2D.class), any(Plot.class),
                any(XYDataset.class), any(PlotRenderingInfo.class))).thenReturn(null);
        when(renderer.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
    }

    @Test
    void render_RendererReturnsFalseForNoData() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(0);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(0.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(0.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.isSeriesVisible(anyInt())).thenReturn(false);
        when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(false);
        when(renderer.getLegendItem(anyInt(), anyInt())).thenReturn(null);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }

    @Test
    void render_WithShadowGeneratorAndSuppressShadowFalse() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(-5.0);
        when(xAxis.getUpperBound()).thenReturn(5.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-5.0);
        when(yAxis.getUpperBound()).thenReturn(5.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        ShadowGenerator shadow = mock(ShadowGenerator.class);
        plot.setShadowGenerator(shadow);
        when(shadow.createDropShadow(any())).thenReturn(null);
        when(g2.getRenderingHint(any())).thenReturn(false);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
        verify(shadow).createDropShadow(any());
    }

    @Test
    void render_WithShadowGeneratorAndSuppressShadowTrue() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(-5.0);
        when(xAxis.getUpperBound()).thenReturn(5.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-5.0);
        when(yAxis.getUpperBound()).thenReturn(5.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        ShadowGenerator shadow = mock(ShadowGenerator.class);
        plot.setShadowGenerator(shadow);
        when(g2.getRenderingHint(any())).thenReturn(true);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
        verify(shadow, never()).createDropShadow(any());
    }

    @Test
    void render_WithOrientationHorizontal() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        plot.setOrientation(PlotOrientation.HORIZONTAL);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(0.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-10.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
    }

    @Test
    void render_WithCrosshairVisible() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(0.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(0.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        plot.setDomainCrosshairVisible(true);
        plot.setDomainCrosshairValue(5.0);
        plot.setRangeCrosshairVisible(true);
        plot.setRangeCrosshairValue(5.0);
        when(renderer.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
    }

    @Test
    void render_WithMultipleDatasetsAndRenderersReverseOrder() {
        XYDataset dataset1 = mock(XYDataset.class);
        when(dataset1.getSeriesCount()).thenReturn(1);
        XYDataset dataset2 = mock(XYDataset.class);
        when(dataset2.getSeriesCount()).thenReturn(1);
        plot.setDataset(0, dataset1);
        plot.setDataset(1, dataset2);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(-10.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-10.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer1 = mock(XYItemRenderer.class);
        XYItemRenderer renderer2 = mock(XYItemRenderer.class);
        plot.setRenderer(0, renderer1);
        plot.setRenderer(1, renderer2);
        plot.setDatasetRenderingOrder(DatasetRenderingOrder.REVERSE);
        when(renderer1.getPassCount()).thenReturn(1);
        when(renderer2.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 1, info, crosshairState);
        assertTrue(result);
    }

    @Test
    void render_WithFixedDomainAxisSpace() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(0.0);
        when(xAxis.getUpperBound()).thenReturn(100.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(0.0);
        when(yAxis.getUpperBound()).thenReturn(100.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        plot.setFixedDomainAxisSpace(null);
        when(renderer.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
    }

    @Test
    void render_WithAnnotations() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(-100.0);
        when(xAxis.getUpperBound()).thenReturn(100.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-100.0);
        when(yAxis.getUpperBound()).thenReturn(100.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        XYAnnotation annotation = mock(XYAnnotation.class);
        plot.addAnnotation(annotation);
        when(renderer.getPassCount()).thenReturn(1);
        doNothing().when(annotation).draw(any(Graphics2D.class), any(Plot.class),
                any(Rectangle2D.class), any(ValueAxis.class), any(ValueAxis.class),
                anyInt(), any(PlotRenderingInfo.class));
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
        verify(annotation).draw(any(Graphics2D.class), any(Plot.class),
                any(Rectangle2D.class), any(ValueAxis.class), any(ValueAxis.class),
                anyInt(), any(PlotRenderingInfo.class));
    }

    @Test
    void render_RendererThrowsException_DoesNotCrash() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(0.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(0.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.getPassCount()).thenReturn(1);
        doThrow(new RuntimeException()).when(renderer).drawItem(any(), any(), any(),
                any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());
        assertThrows(RuntimeException.class, () -> {
            plot.render(g2, dataArea, 0, info, crosshairState);
        });
    }

    @Test
    void render_WithNullCrosshairState_ReturnsTrue() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(-10.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-10.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 0, info, null);
        assertTrue(result);
    }

    @Test
    void render_WithNoSeriesVisible_ReturnsFalse() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(-5.0);
        when(xAxis.getUpperBound()).thenReturn(5.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-5.0);
        when(yAxis.getUpperBound()).thenReturn(5.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.isSeriesVisible(0)).thenReturn(false);
        when(renderer.isSeriesVisible(1)).thenReturn(false);
        when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(false);
        when(renderer.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertFalse(result);
    }

    @Test
    void render_WithMixedSeriesVisibility_ReturnsTrue() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        plot.setDataset(dataset);
        ValueAxis xAxis = mock(ValueAxis.class);
        when(xAxis.getLowerBound()).thenReturn(-10.0);
        when(xAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(xAxis);
        ValueAxis yAxis = mock(ValueAxis.class);
        when(yAxis.getLowerBound()).thenReturn(-10.0);
        when(yAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(yAxis);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setRenderer(renderer);
        when(renderer.isSeriesVisible(0)).thenReturn(true);
        when(renderer.isSeriesVisible(1)).thenReturn(false);
        when(renderer.isSeriesVisibleInLegend(0)).thenReturn(true);
        when(renderer.isSeriesVisibleInLegend(1)).thenReturn(false);
        when(renderer.getPassCount()).thenReturn(1);
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);
        assertTrue(result);
    }

}