package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.lang.reflect.Method;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MethodUtils_getMatchingAccessibleMethod_1_1_Test {
    
    // Scenario TC17
    @Test
    @DisplayName("Returns null when getMethodObject finds a method but setAccessibleWorkaround fails to make it accessible")
    void TC17_ReturnsNull_WhenSetAccessibleWorkaroundFails() {
        // Arrange
        Class<?> cls = InaccessibleMethodClass.class;
        String methodName = "inaccessibleMethod";
        Class<?>[] parameterTypes = { String.class };
        
        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);
        
        // Assert
        assertNull(result, "Expected null when setAccessibleWorkaround fails");
    }
    
    // Scenario TC18
    @Test
    @DisplayName("Throws IllegalStateException when multiple best matching accessible methods with the same declaring class are found")
    void TC18_ThrowsIllegalStateException_OnAmbiguousMethods() {
        // Arrange
        Class<?> cls = AmbiguousMethodClass.class;
        String methodName = "ambiguousMethod";
        Class<?>[] parameterTypes = { String.class };
        
        // Act & Assert
        assertThrows(IllegalStateException.class, () -> {
            MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);
        }, "Expected IllegalStateException due to ambiguous methods");
    }
    
    // Helper Classes for Testing
    
    // Class with a private method to simulate inaccessible method for TC17
    private static class InaccessibleMethodClass {
        private void inaccessibleMethod(String param) {
            // Inaccessible method
        }
    }
    
    // Class with ambiguous methods to simulate multiple best matches for TC18
    private static class AmbiguousMethodClass implements InterfaceA, InterfaceB {
        @Override
        public void ambiguousMethod(String param) {
            // Implementation
        }
    }
    
    // Interfaces with the same method signature to create ambiguity
    private interface InterfaceA {
        void ambiguousMethod(String param);
    }
    
    private interface InterfaceB {
        void ambiguousMethod(String param);
    }
}