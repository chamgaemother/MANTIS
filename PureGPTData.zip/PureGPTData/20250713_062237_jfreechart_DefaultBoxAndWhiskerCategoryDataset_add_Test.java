import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerItem;
import org.jfree.data.statistics.BoxAndWhiskerCalculator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DefaultBoxAndWhiskerCategoryDatasetTest {

    private DefaultBoxAndWhiskerCategoryDataset dataset;
    private BoxAndWhiskerItem mockItem;

    @BeforeEach
    void setUp() {
        dataset = new DefaultBoxAndWhiskerCategoryDataset();
        mockItem = mock(BoxAndWhiskerItem.class);
    }

    @Test
    void testAddWithNullItem() {
        assertThrows(NullPointerException.class, () -> dataset.add(null, "Row1", "Column1"));
    }

    @Test
    void testAddWithNullRowKey() {
        assertThrows(NullPointerException.class, () -> dataset.add(mockItem, null, "Column1"));
    }

    @Test
    void testAddWithNullColumnKey() {
        assertThrows(NullPointerException.class, () -> dataset.add(mockItem, "Row1", null));
    }

    @Test
    void testAddWithValidValuesUpdatesMaxMin() {
        when(mockItem.getMinOutlier()).thenReturn(1.0);
        when(mockItem.getMaxOutlier()).thenReturn(5.0);

        dataset.add(mockItem, "Row1", "Column1");

        assertEquals(1.0, dataset.getRangeLowerBound(true));
        assertEquals(5.0, dataset.getRangeUpperBound(true));
    }

    @Test
    void testAddWithMultipleValuesUpdatesMaxMin() {
        BoxAndWhiskerItem item1 = new BoxAndWhiskerItem(null, null, null, null, null, 1.0, 10.0, null, null, null);
        BoxAndWhiskerItem item2 = new BoxAndWhiskerItem(null, null, null, null, null, 2.0, 8.0, null, null, null);

        dataset.add(item1, "Row1", "Column1");
        dataset.add(item2, "Row2", "Column2");

        assertEquals(1.0, dataset.getRangeLowerBound(true));
        assertEquals(10.0, dataset.getRangeUpperBound(true));
    }

    @Test
    void testAddUpdatesBoundsIfExistingCell() {
        when(mockItem.getMinOutlier()).thenReturn(2.0);
        when(mockItem.getMaxOutlier()).thenReturn(6.0);

        dataset.add(new BoxAndWhiskerItem(null, null, null, null, null, 1.0, 5.0, null, null, null), "Row1", "Column1");
        dataset.add(mockItem, "Row1", "Column1");

        assertEquals(2.0, dataset.getRangeLowerBound(true));
        assertEquals(6.0, dataset.getRangeUpperBound(true));
    }

    @Test
    void testAddWithBoxesHavingNoValidMinsOrMaxes() {
        BoxAndWhiskerItem emptyItem = new BoxAndWhiskerItem(null, null, null, null, null, null, null, null, null, null);

        dataset.add(emptyItem, "Row1", "Column1");

        assertTrue(Double.isNaN(dataset.getRangeLowerBound(true)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(true)));
    }
}