package org.apache.commons.lang3.reflect;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

public class MethodUtils_getMatchingAccessibleMethod_0_4_Test {

    @Test
    @DisplayName("Handles scenario where the last parameter type is a superclass and matches component type")
    public void TC16() throws Exception {
        // Arrange
        Class<?> cls = VarargsSuperclassMatchClass.class;
        String methodName = "varargsSuperclassMatchMethod";
        Class<?>[] parameterTypes = {CustomSuperclass.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNotNull(result, "The result should not be null");
        assertTrue(result.isVarArgs(), "The method should be varargs");
    }

    // Helper classes for testing
    public static class VarargsSuperclassMatchClass {
        public void varargsSuperclassMatchMethod(CustomSubclass... args) {
            // Method implementation
        }
    }

    public static class CustomSuperclass {
        // Superclass implementation
    }

    public static class CustomSubclass extends CustomSuperclass {
        // Subclass implementation
    }
}