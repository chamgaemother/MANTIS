// package org.jfree.chart.plot;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.util.ShadowGenerator;
// import java.lang.reflect.Field;
// 
// public class CategoryPlot_clone_1_5_Test {
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with non-null shadowGenerator")
//     void TC21_cloneWithNonNullShadowGenerator() throws Exception {
//         // Create original CategoryPlot
//         CategoryPlot original = new CategoryPlot();
// 
//         // Use reflection to set the private field 'shadowGenerator' to a new ShadowGenerator
//         Field shadowField = CategoryPlot.class.getDeclaredField("shadowGenerator");
//         shadowField.setAccessible(true);
//         ShadowGenerator shadow = new ShadowGenerator();
//         shadowField.set(original, shadow);
// 
//         // Clone the original plot
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // Use reflection to get 'shadowGenerator' from clone
//         ShadowGenerator cloneShadow = (ShadowGenerator) shadowField.get(clone);
// 
//         // Assertions
//         assertNotNull(cloneShadow, "Cloned shadowGenerator should not be null");
//         assertNotSame(shadow, cloneShadow, "Cloned shadowGenerator should be a different instance");
//         assertEquals(shadow, cloneShadow, "Cloned shadowGenerator should be equal to original");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with null shadowGenerator")
//     void TC22_cloneWithNullShadowGenerator() throws Exception {
//         // Create original CategoryPlot
//         CategoryPlot original = new CategoryPlot();
// 
//         // Use reflection to set the private field 'shadowGenerator' to null
//         Field shadowField = CategoryPlot.class.getDeclaredField("shadowGenerator");
//         shadowField.setAccessible(true);
//         shadowField.set(original, null);
// 
//         // Clone the original plot
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // Use reflection to get 'shadowGenerator' from clone
//         ShadowGenerator cloneShadow = (ShadowGenerator) shadowField.get(clone);
// 
//         // Assertions
//         assertNull(cloneShadow, "Cloned shadowGenerator should be null");
//     }
// }