package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class KthSelector_select_1_1_Test {

    @Test
    @DisplayName("select method with work array size exactly MIN_SELECT_SIZE (15) and z0 is false")
    public void TC13() throws Exception {
        // GIVEN
        double[] work = {5.0, 3.1, 4.2, 7.4, 1.5, 9.6, 2.7, 8.8, 6.9, 0.0, 11.0, 13.1, 12.2, 10.3, 14.4};
        int[] pivotsHeap = {2, 4, 6};
        int k = 7;
        double expectedValue = 9.6;
        
        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, pivotsHeap, k);
        
        // THEN
        assertEquals(expectedValue, result, "The Kth element should be 9.6");
    }

    @Test
    @DisplayName("select method with work array size less than MIN_SELECT_SIZE and z0 is false")
    public void TC14() throws Exception {
        // GIVEN
        double[] work = {4.5, 2.3, 5.1, 3.3, 1.2, 6.4, 7.5, 0.8, 9.9, 8.7, 10.0, 11.1, 12.2, 13.3};
        int[] pivotsHeap = {1, 3};
        int k = 5;
        double expectedSortedValue = 6.4;
        
        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, pivotsHeap, k);
        
        // THEN
        assertEquals(expectedSortedValue, result, "The Kth sorted element should be 6.4");
    }

    @Test
    @DisplayName("select method with k as a negative index, expecting ArrayIndexOutOfBoundsException")
    public void TC15() throws Exception {
        // GIVEN
        double[] work = {3.0, 1.0, 2.0, 5.0, 4.0};
        int[] pivotsHeap = {0, 2};
        int k = -1;
        
        // WHEN & THEN
        KthSelector selector = new KthSelector();
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            selector.select(work, pivotsHeap, k);
        }, "Expected ArrayIndexOutOfBoundsException for negative k");
    }

    @Test
    @DisplayName("select method with k exceeding work array length, expecting ArrayIndexOutOfBoundsException")
    public void TC16() throws Exception {
        // GIVEN
        double[] work = {2.2, 4.4, 6.6, 8.8, 10.0, 12.2, 14.4, 16.6, 18.8, 20.0};
        int[] pivotsHeap = {1, 3, 5};
        int k = 10;
        
        // WHEN & THEN
        KthSelector selector = new KthSelector();
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            selector.select(work, pivotsHeap, k);
        }, "Expected ArrayIndexOutOfBoundsException for k exceeding work length");
    }

    @Test
    @DisplayName("select method with empty work array, expecting ArrayIndexOutOfBoundsException")
    public void TC17() throws Exception {
        // GIVEN
        double[] work = {};
        int[] pivotsHeap = {0};
        int k = 0;
        
        // WHEN & THEN
        KthSelector selector = new KthSelector();
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            selector.select(work, pivotsHeap, k);
        }, "Expected ArrayIndexOutOfBoundsException for empty work array");
    }
}