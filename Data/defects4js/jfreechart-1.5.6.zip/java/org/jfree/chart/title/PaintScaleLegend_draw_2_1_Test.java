package org.jfree.chart.title;
// 
// import static org.junit.jupiter.api.Assertions.assertNull;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyDouble;
// import static org.mockito.Mockito.mock;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;
// 
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.renderer.PaintScale;
// import org.jfree.chart.renderer.StandardPaintScale;
// import org.jfree.data.Range;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// /**
//  * Test class for PaintScaleLegend#draw method.
//  */
public class PaintScaleLegend_draw_2_1_Test {
// 
//     @Test
//     @DisplayName("draw method with axis range length zero and subdivisions set to 5")
//     void test_TC19_drawWithZeroRangeAndSubdivisions() throws Exception {
        // Arrange
//         PaintScale scale = new StandardPaintScale(50.0, 50.0, Color.BLUE);
//         ValueAxis axis = mock(ValueAxis.class);
//         when(axis.getLowerBound()).thenReturn(50.0);
//         when(axis.getUpperBound()).thenReturn(50.0);
//         when(axis.getRange()).thenReturn(new Range(50.0, 50.0));
//         PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
//         legend.setSubdivisionCount(5);
//         legend.setBackgroundPaint(null);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
//         Object param = new Object();
// 
        // Act
//         Object result = legend.draw(g2, area, param);
// 
        // Assert
//         assertNull(result, "Draw method should return null");
        // Verify that no strips are filled due to zero range length
//         verify(g2, never()).fill(any(Rectangle2D.class));
        // Verify that axis.draw is still called once
//         verify(axis, times(1)).draw(any(Graphics2D.class), anyDouble(), any(Rectangle2D.class), any(Rectangle2D.class), any(), any()); 
//     }
// 
//     @Test
//     @DisplayName("draw method with stripWidth set to zero and subdivisions set to 5")
//     void test_TC20_drawWithZeroStripWidthAndSubdivisions() throws Exception {
        // Arrange
//         PaintScale scale = new StandardPaintScale(0.0, 100.0, Color.RED);
//         ValueAxis axis = mock(ValueAxis.class);
//         when(axis.getLowerBound()).thenReturn(0.0);
//         when(axis.getUpperBound()).thenReturn(100.0);
//         when(axis.getRange()).thenReturn(new Range(0.0, 100.0));
//         PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
//         legend.setSubdivisionCount(5);
//         legend.setStripWidth(0.0);
//         legend.setBackgroundPaint(Color.WHITE);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
//         Object param = new Object();
// 
        // Act
//         Object result = legend.draw(g2, area, param);
// 
        // Assert
//         assertNull(result, "Draw method should return null");
        // Verify that background is filled
//         verify(g2, times(1)).setPaint(Color.WHITE);
//         verify(g2, times(1)).fill(any(Rectangle2D.class));
        // Verify that strips are not drawn due to zero width
//         verify(g2, never()).draw(any(Rectangle2D.class));
        // Verify that axis.draw is called once
//         verify(axis, times(1)).draw(any(Graphics2D.class), anyDouble(), any(Rectangle2D.class), any(Rectangle2D.class), any(), any()); 
//     }
// }
}