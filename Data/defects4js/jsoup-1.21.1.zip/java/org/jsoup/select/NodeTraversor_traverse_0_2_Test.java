package org.jsoup.select;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jsoup.nodes.Node;
import org.jsoup.nodes.Element;
import org.jsoup.select.NodeTraversor;
import org.jsoup.select.NodeVisitor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class NodeTraversor_traverse_0_2_Test {

    @Test
    @DisplayName("Traverse handles node replacement via workaround as direct replaceChild access is forbidden")
    public void TC06_traverse_node_replacement_same_parent_size() throws Exception {
        // GIVEN
        // Create a root node with a child that will be replaced without changing parent size
        Element root = new Element("div");
        Element originalChild = new Element("span");
        Element replacementChild = new Element("a");
        root.appendChild(originalChild);
        root.appendChild(new Element("p")); // Maintains the original parent size

        // Workaround: remove by setting a new node list
        root.getAllElements().get(0).childNodes().set(0, replacementChild);

        // Create a CustomNodeVisitor to record traversal
        CustomNodeVisitor visitor = new CustomNodeVisitor();

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        // Verify that the replacement occurred and traversal continued
        assertTrue(visitor.headCalled.contains(replacementChild), "Replacement node should have been visited in head.");
        assertTrue(visitor.tailCalled.contains(replacementChild), "Replacement node should have been visited in tail.");
        assertTrue(visitor.headCalled.contains(root), "Root node should have been visited.");
    }

    @Test
    @DisplayName("Traverse handles node removal via workaround as direct removeChild access is forbidden")
    public void TC07_traverse_node_removal_ascends_tree() throws Exception {
        // GIVEN
        // Create a root node with a child that will be removed
        Element root = new Element("div");
        Element child = new Element("span");
        root.appendChild(child);
        root.appendChild(new Element("p"));

        // Workaround: remove by resetting the node list without the child
        root.getAllElements().get(0).childNodes().remove(0);

        // Create a CustomNodeVisitor to record traversal
        CustomNodeVisitor visitor = new CustomNodeVisitor();

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        // Verify that the removed node was not visited and traversal ascended
        assertFalse(visitor.headCalled.contains(child), "Removed node should not have been visited.");
        assertTrue(visitor.headCalled.contains(root), "Root node should have been visited.");
    }

    @Test
    @DisplayName("Traverse visits nodes with children, descending into child nodes")
    public void TC08_traverse_descending_into_children() throws Exception {
        // GIVEN
        // Create a root node with child nodes
        Element root = new Element("div");
        Element child1 = new Element("span");
        Element child2 = new Element("p");
        Element grandChild = new Element("a");
        child1.appendChild(grandChild);
        root.appendChild(child1);
        root.appendChild(child2);

        // Create a CustomNodeVisitor to record traversal
        CustomNodeVisitor visitor = new CustomNodeVisitor();

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        // Verify that all nodes were visited in the correct order
        assertTrue(visitor.headCalled.contains(root), "Root node should have been visited in head.");
        assertTrue(visitor.headCalled.contains(child1), "Child1 node should have been visited in head.");
        assertTrue(visitor.headCalled.contains(grandChild), "Grandchild node should have been visited in head.");
        assertTrue(visitor.tailCalled.contains(grandChild), "Grandchild node should have been visited in tail.");
        assertTrue(visitor.tailCalled.contains(child1), "Child1 node should have been visited in tail.");
        assertTrue(visitor.headCalled.contains(child2), "Child2 node should have been visited in head.");
        assertTrue(visitor.tailCalled.contains(child2), "Child2 node should have been visited in tail.");
        assertTrue(visitor.tailCalled.contains(root), "Root node should have been visited in tail.");
    }

    @Test
    @DisplayName("Traverse handles assertion disabled, skipping assertion check")
    public void TC09_traverse_assertions_disabled() throws Exception {
        // GIVEN
        // Create a simple root node
        Element root = new Element("div");
        root.appendChild(new Element("span"));

        // Create a CustomNodeVisitor to record traversal
        CustomNodeVisitor visitor = new CustomNodeVisitor();

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        // Verify that traversal completes without assertion errors
        assertTrue(visitor.headCalled.contains(root), "Root node should have been visited.");
    }

    @Test
    @DisplayName("Traverse encounters node with no next sibling and ascends to root")
    public void TC10_traverse_no_next_sibling_ascends_to_root() throws Exception {
        // GIVEN
        // Create a root node with a single child
        Element root = new Element("div");
        Element child = new Element("span");
        root.appendChild(child);

        // Create a CustomNodeVisitor to record traversal
        CustomNodeVisitor visitor = new CustomNodeVisitor();

        // WHEN
        NodeTraversor.traverse(visitor, root);

        // THEN
        // Verify that traversal ascends to root after visiting the child
        assertTrue(visitor.headCalled.contains(child), "Child node should have been visited in head.");
        assertTrue(visitor.tailCalled.contains(child), "Child node should have been visited in tail.");
        assertTrue(visitor.tailCalled.contains(root), "Root node should have been visited in tail.");
    }

    // Custom NodeVisitor implementation to record traversal events
    private class CustomNodeVisitor implements NodeVisitor {
        public List<Node> headCalled = new ArrayList<>();
        public List<Node> tailCalled = new ArrayList<>();

        @Override
        public void head(Node node, int depth) {
            headCalled.add(node);
        }

        @Override
        public void tail(Node node, int depth) {
            tailCalled.add(node);
        }
    }
}