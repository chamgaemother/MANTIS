import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYStepRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class XYStepRendererTest {

    private XYStepRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;
    private EntityCollection entities;

    @BeforeEach
    void setUp() {
        renderer = new XYStepRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
        entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verifyNoInteractions(g2);
        verifyNoInteractions(dataset);
    }

    @Test
    void testDrawItem_Pass0_ItemZero() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verifyNoInteractions(dataset);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_Pass0_Horizontal_SameY() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(5.0);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(5.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(1)).draw(lineCaptor.capture());
        Line2D line = lineCaptor.getValue();
        assertEquals(20.0, line.getY1());
        assertEquals(10.0, line.getX1());
        assertEquals(20.0, line.getY2());
        assertEquals(30.0, line.getX2());
    }

    @Test
    void testDrawItem_Pass0_Horizontal_DifferentY() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(6.0);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(5.0);
        when(renderer.getStepPoint()).thenReturn(0.5);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(6.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2, times(3)).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_Pass0_Vertical_SameY() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(1)).draw(lineCaptor.capture());
        Line2D line = lineCaptor.getValue();
        assertEquals(40.0, line.getX1());
        assertEquals(50.0, line.getY1());
        assertEquals(60.0, line.getX2());
        assertEquals(50.0, line.getY2());
    }

    @Test
    void testDrawItem_Pass0_Vertical_DifferentY() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(11.0);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(renderer.getStepPoint()).thenReturn(0.3);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(11.0, dataArea, RectangleEdge.LEFT)).thenReturn(60.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(70.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2, times(3)).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_Pass0_WithNaN() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_Pass0_UpdateCrosshair() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(crosshairState).updateCrosshairValues(eq(10.0), eq(5.0), eq(0), eq(60.0), eq(50.0), eq(PlotOrientation.VERTICAL));
    }

    @Test
    void testDrawItem_Pass0_AddEntity_Horizontal() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(5.0);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(5.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(entities).add(any(), eq(dataset), eq(0), eq(1), eq(20.0), eq(30.0));
    }

    @Test
    void testDrawItem_Pass0_AddEntity_Vertical() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(entities).add(any(), eq(dataset), eq(0), eq(1), eq(60.0), eq(50.0));
    }

    @Test
    void testDrawItem_Pass1_LabelVisible() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 1);

        verify(renderer).drawItemLabel(g2, PlotOrientation.VERTICAL, dataset, 0, 1, 60.0, 50.0, false);
    }

    @Test
    void testDrawItem_Pass1_LabelNotVisible() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 1)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 1);

        verify(renderer, never()).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    void testDrawItem_Pass1_Horizontal_LabelVisible() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(renderer.isItemLabelVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(5.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 1);

        verify(renderer).drawItemLabel(g2, PlotOrientation.HORIZONTAL, dataset, 0, 1, 20.0, 30.0, false);
    }

    @Test
    void testDrawItem_NullEntities() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(state.getEntityCollection()).thenReturn(null);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(state).getEntityCollection();
        verifyNoMoreInteractions(entities);
    }

    @Test
    void testDrawItem_InvalidStepPoint() {
        assertThrows(IllegalArgumentException.class, () -> renderer.setStepPoint(-0.1));
        assertThrows(IllegalArgumentException.class, () -> renderer.setStepPoint(1.1));
    }

    @Test
    void testDrawItem_SetAndGetStepPoint() {
        renderer.setStepPoint(0.3);
        assertEquals(0.3, renderer.getStepPoint(), 0.0001);
    }

    @Test
    void testDrawItem_NullDataset() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 1, crosshairState, 0));
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_NaNValues() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_Clone() throws CloneNotSupportedException {
        XYStepRenderer clone = (XYStepRenderer) renderer.clone();
        assertNotSame(renderer, clone);
        assertEquals(renderer, clone);
    }

    @Test
    void testDrawItem_Equals() {
        XYStepRenderer other = new XYStepRenderer();
        assertEquals(renderer, other);

        other.setStepPoint(0.5);
        assertNotEquals(renderer, other);

        renderer.setStepPoint(0.5);
        assertEquals(renderer, other);
    }

    @Test
    void testDrawItem_HashCode() {
        XYStepRenderer other = new XYStepRenderer();
        assertEquals(renderer.hashCode(), other.hashCode());

        other.setStepPoint(0.5);
        assertNotEquals(renderer.hashCode(), other.hashCode());

        renderer.setStepPoint(0.5);
        assertEquals(renderer.hashCode(), other.hashCode());
    }

    @Test
    void testDrawItem_DrawLineWithClipping() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getYValue(0, 1)).thenReturn(10.0);
        when(dataset.getXValue(0, 0)).thenReturn(4.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(4.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);

        renderer.setStepPoint(1.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2, times(1)).draw(lineCaptor.capture());
        Line2D line = lineCaptor.getValue();
        assertEquals(40.0, line.getX1());
        assertEquals(50.0, line.getY1());
        assertEquals(60.0, line.getX2());
        assertEquals(50.0, line.getY2());
    }
}