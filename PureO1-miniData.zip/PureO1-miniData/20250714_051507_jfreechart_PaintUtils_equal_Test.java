package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.LinearGradientPaint;
import java.awt.Paint;
import java.awt.RadialGradientPaint;
import java.awt.geom.Point2D;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

public class PaintUtilsTest {

    @Test
    public void testEqual_SameReference() {
        Paint paint = Color.RED;
        assertTrue(PaintUtils.equal(paint, paint));
    }

    @Test
    public void testEqual_BothNull() {
        assertTrue(PaintUtils.equal(null, null));
    }

    @Test
    public void testEqual_FirstNull() {
        Paint paint = Color.BLUE;
        assertFalse(PaintUtils.equal(null, paint));
    }

    @Test
    public void testEqual_SecondNull() {
        Paint paint = Color.GREEN;
        assertFalse(PaintUtils.equal(paint, null));
    }

    @Test
    public void testEqual_GradientPaintEqual() {
        GradientPaint gp1 = new GradientPaint(
                new Point2D.Double(0, 0), Color.RED,
                new Point2D.Double(1, 1), Color.BLUE, true);
        GradientPaint gp2 = new GradientPaint(
                new Point2D.Double(0, 0), Color.RED,
                new Point2D.Double(1, 1), Color.BLUE, true);
        assertTrue(PaintUtils.equal(gp1, gp2));
    }

    @Test
    public void testEqual_GradientPaintNotEqual_Color() {
        GradientPaint gp1 = new GradientPaint(
                new Point2D.Double(0, 0), Color.RED,
                new Point2D.Double(1, 1), Color.BLUE, true);
        GradientPaint gp2 = new GradientPaint(
                new Point2D.Double(0, 0), Color.GREEN,
                new Point2D.Double(1, 1), Color.BLUE, true);
        assertFalse(PaintUtils.equal(gp1, gp2));
    }

    @Test
    public void testEqual_GradientPaintNotEqual_Point() {
        GradientPaint gp1 = new GradientPaint(
                new Point2D.Double(0, 0), Color.RED,
                new Point2D.Double(1, 1), Color.BLUE, true);
        GradientPaint gp2 = new GradientPaint(
                new Point2D.Double(0, 1), Color.RED,
                new Point2D.Double(1, 1), Color.BLUE, true);
        assertFalse(PaintUtils.equal(gp1, gp2));
    }

    @Test
    public void testEqual_LinearGradientPaintEqual() {
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        LinearGradientPaint lgp1 = new LinearGradientPaint(
                new Point2D.Double(0, 0), new Point2D.Double(1, 1),
                fractions, colors);
        LinearGradientPaint lgp2 = new LinearGradientPaint(
                new Point2D.Double(0, 0), new Point2D.Double(1, 1),
                fractions, colors);
        assertTrue(PaintUtils.equal(lgp1, lgp2));
    }

    @Test
    public void testEqual_LinearGradientPaintNotEqual_Fractions() {
        float[] fractions1 = {0.0f, 1.0f};
        float[] fractions2 = {0.0f, 0.5f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        LinearGradientPaint lgp1 = new LinearGradientPaint(
                new Point2D.Double(0, 0), new Point2D.Double(1, 1),
                fractions1, colors);
        LinearGradientPaint lgp2 = new LinearGradientPaint(
                new Point2D.Double(0, 0), new Point2D.Double(1, 1),
                fractions2, colors);
        assertFalse(PaintUtils.equal(lgp1, lgp2));
    }

    @Test
    public void testEqual_RadialGradientPaintEqual() {
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        RadialGradientPaint rgp1 = new RadialGradientPaint(
                new Point2D.Double(0, 0), 1.0f,
                new Point2D.Double(0, 0), fractions, colors);
        RadialGradientPaint rgp2 = new RadialGradientPaint(
                new Point2D.Double(0, 0), 1.0f,
                new Point2D.Double(0, 0), fractions, colors);
        assertTrue(PaintUtils.equal(rgp1, rgp2));
    }

    @Test
    public void testEqual_RadialGradientPaintNotEqual_Radius() {
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        RadialGradientPaint rgp1 = new RadialGradientPaint(
                new Point2D.Double(0, 0), 1.0f,
                new Point2D.Double(0, 0), fractions, colors);
        RadialGradientPaint rgp2 = new RadialGradientPaint(
                new Point2D.Double(0, 0), 2.0f,
                new Point2D.Double(0, 0), fractions, colors);
        assertFalse(PaintUtils.equal(rgp1, rgp2));
    }

    @Test
    public void testEqual_DifferentPaintTypes_Equals() {
        Paint color1 = Color.RED;
        Paint color2 = Color.RED;
        assertTrue(PaintUtils.equal(color1, color2));
    }

    @Test
    public void testEqual_DifferentPaintTypes_NotEquals() {
        Paint color = Color.RED;
        GradientPaint gp = new GradientPaint(0, 0, Color.RED, 1, 1, Color.RED);
        assertFalse(PaintUtils.equal(color, gp));
    }

    @Test
    public void testEqual_CustomPaintEquals() {
        Paint p1 = new CustomPaint("test");
        Paint p2 = new CustomPaint("test");
        assertTrue(PaintUtils.equal(p1, p2));
    }

    @Test
    public void testEqual_CustomPaintNotEquals() {
        Paint p1 = new CustomPaint("test1");
        Paint p2 = new CustomPaint("test2");
        assertFalse(PaintUtils.equal(p1, p2));
    }

    // Custom Paint class for testing fallback equals
    private static class CustomPaint implements Paint {
        private String name;

        public CustomPaint(String name) {
            this.name = name;
        }

        @Override
        public int getTransparency() {
            return 0;
        }

        @Override
        public PaintContext createContext(java.awt.image.ColorModel cm, java.awt.Rectangle deviceBounds,
                java.awt.geom.Rectangle2D userBounds, java.awt.geom.AffineTransform xform,
                java.awt.RenderingHints hints) {
            return null;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (!(obj instanceof CustomPaint))
                return false;
            CustomPaint other = (CustomPaint) obj;
            return Objects.equals(this.name, other.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name);
        }
    }
}