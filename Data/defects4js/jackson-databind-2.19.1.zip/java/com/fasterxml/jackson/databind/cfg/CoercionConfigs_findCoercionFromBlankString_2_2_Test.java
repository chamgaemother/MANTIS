package com.fasterxml.jackson.databind.cfg;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Constructor;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.cfg.CoercionAction;
import com.fasterxml.jackson.databind.cfg.CoercionConfigs;
import com.fasterxml.jackson.databind.cfg.MutableCoercionConfig;
import com.fasterxml.jackson.databind.type.LogicalType;

public class CoercionConfigs_findCoercionFromBlankString_2_2_Test {

    @Test
    @DisplayName("When _perClassCoercions is null, _perTypeCoercions is null, and ACCEPT_EMPTY_STRING_AS_NULL_OBJECT is enabled with targetType non-scalar")
    public void TC26_handle_all_defaults_with_feature_enabled_non_scalar() throws Exception {
        // Arrange
        // Create defaultCoercions
        MutableCoercionConfig defaultCoercions = new MutableCoercionConfig();

        // Use reflection to access the protected constructor
        Constructor<CoercionConfigs> constructor = CoercionConfigs.class.getDeclaredConstructor(
                CoercionAction.class,
                MutableCoercionConfig.class,
                MutableCoercionConfig[].class,
                Map.class
        );
        constructor.setAccessible(true);

        // Instantiate CoercionConfigs with _perTypeCoercions and _perClassCoercions as null
        CoercionConfigs coercionConfigs = constructor.newInstance(
                CoercionAction.TryConvert,
                defaultCoercions,
                null,
                null
        );

        // Create DeserializationConfig with ACCEPT_EMPTY_STRING_AS_NULL_OBJECT enabled
        DeserializationConfig config = createDeserializationConfig(true, false);

        // Define targetType as non-scalar
        LogicalType targetType = LogicalType.OtherScalar;

        // Define targetClass as Object.class
        Class<?> targetClass = Object.class;

        // Define actionIfBlankNotAllowed
        CoercionAction actionIfBlankNotAllowed = CoercionAction.Fail;

        // Act
        CoercionAction result = coercionConfigs.findCoercionFromBlankString(
                config,
                targetType,
                targetClass,
                actionIfBlankNotAllowed
        );

        // Assert
        assertEquals(CoercionAction.AsNull, result, "Expected CoercionAction.AsNull based on ACCEPT_EMPTY_STRING_AS_NULL_OBJECT being enabled");
    }

//     @Test
//     @DisplayName("When _perTypeCoercions is not null, targetType is scalar, and no specific coercion defined with ALLOW_COERCION_OF_SCALARS disabled")
//     public void TC27_handle_scalar_perTypeCoercion_with_coeff_disabled() throws Exception {
        // Arrange
        // Initialize perTypeCoercions without specific coercion for targetType
//         MutableCoercionConfig[] perTypeCoercions = new MutableCoercionConfig[LogicalType.values().length];
// 
        // No specific coercion defined for LogicalType.Integer
//         LogicalType targetTypeEnum = LogicalType.Integer;
// 
        // Initialize defaultCoercions
//         MutableCoercionConfig defaultCoercions = new MutableCoercionConfig();
//         defaultCoercions.setAcceptBlankAsEmpty(false);
//         defaultCoercions.setAction(CoercionInputShape.EmptyString, CoercionAction.AsNull);
// 
        // perClassCoercions is null
//         Map<Class<?>, MutableCoercionConfig> perClassCoercions = null;
// 
        // Use reflection to access the protected constructor
//         Constructor<CoercionConfigs> constructor = CoercionConfigs.class.getDeclaredConstructor(
//                 CoercionAction.class,
//                 MutableCoercionConfig.class,
//                 MutableCoercionConfig[].class,
//                 Map.class
//         );
//         constructor.setAccessible(true);
// 
        // Instantiate CoercionConfigs
//         CoercionConfigs coercionConfigs = constructor.newInstance(
//                 CoercionAction.Fail,
//                 defaultCoercions,
//                 perTypeCoercions,
//                 perClassCoercions
//         );
// 
        // Create DeserializationConfig with ALLOW_COERCION_OF_SCALARS disabled
//         DeserializationConfig config = createDeserializationConfig(false, false);
// 
        // Define targetType as scalar
//         LogicalType targetType = LogicalType.Integer;
// 
        // Define targetClass as Integer.class
//         Class<?> targetClass = Integer.class;
// 
        // Define actionIfBlankNotAllowed
//         CoercionAction actionIfBlankNotAllowed = CoercionAction.Fail;
// 
        // Act
//         CoercionAction result = coercionConfigs.findCoercionFromBlankString(
//                 config,
//                 targetType,
//                 targetClass,
//                 actionIfBlankNotAllowed
//         );
// 
        // Assert
//         assertEquals(CoercionAction.Fail, result, "Expected CoercionAction.Fail due to ALLOW_COERCION_OF_SCALARS being disabled");
//     }

    /**
     * Helper method to create DeserializationConfig with specified features.
     */
    private DeserializationConfig createDeserializationConfig(boolean acceptEmptyStringAsNull, boolean allowCoercionOfScalars) {
        // Use ObjectMapper to configure DeserializationConfig
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, acceptEmptyStringAsNull);
        mapper.configure(MapperFeature.ALLOW_COERCION_OF_SCALARS, allowCoercionOfScalars);
        return mapper.getDeserializationConfig();
    }
}