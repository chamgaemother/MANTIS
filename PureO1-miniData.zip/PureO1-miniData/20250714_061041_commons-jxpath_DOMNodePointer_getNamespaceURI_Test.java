import static org.junit.jupiter.api.Assertions.*;

import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DOMNodePointerTest {

    private DocumentBuilder builder;

    @BeforeEach
    public void setUp() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        builder = factory.newDocumentBuilder();
    }

    @Test
    public void testGetNamespaceURINullPrefix() throws Exception {
        Document doc = builder.newDocument();
        DOMNodePointer pointer = new DOMNodePointer(doc, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI(null);
        assertNull(ns);
    }

    @Test
    public void testGetNamespaceUIEmptyPrefix() throws Exception {
        Document doc = builder.newDocument();
        DOMNodePointer pointer = new DOMNodePointer(doc, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("");
        assertNull(ns);
    }

    @Test
    public void testGetNamespaceURIXmlPrefix() throws Exception {
        Document doc = builder.newDocument();
        DOMNodePointer pointer = new DOMNodePointer(doc, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("xml");
        assertEquals("http://www.w3.org/XML/1998/namespace", ns);
    }

    @Test
    public void testGetNamespaceURIXmlnsPrefix() throws Exception {
        Document doc = builder.newDocument();
        DOMNodePointer pointer = new DOMNodePointer(doc, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("xmlns");
        assertEquals("http://www.w3.org/2000/xmlns/", ns);
    }

    @Test
    public void testGetNamespaceURIPrefixFoundInAttributes() throws Exception {
        Document doc = builder.newDocument();
        Element root = doc.createElementNS("http://example.com/ns", "ns:root");
        root.setAttribute("xmlns:ex", "http://example.com/ex");
        doc.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(root, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("ex");
        assertEquals("http://example.com/ex", ns);
    }

    @Test
    public void testGetNamespaceURIPrefixFoundInParentAttributes() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElementNS("http://example.com/ns", "ns:parent");
        parent.setAttribute("xmlns:ex", "http://example.com/ex");
        Element child = doc.createElement("child");
        parent.appendChild(child);
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(child, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("ex");
        assertEquals("http://example.com/ex", ns);
    }

    @Test
    public void testGetNamespaceURIPrefixAlreadyInCache() throws Exception {
        Document doc = builder.newDocument();
        Element root = doc.createElement("root");
        root.setAttribute("xmlns:ex", "http://example.com/ex");
        doc.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(root, Locale.ENGLISH);
        // First call to populate the cache
        String ns1 = pointer.getNamespaceURI("ex");
        assertEquals("http://example.com/ex", ns1);
        // Modify the attribute after caching
        root.setAttribute("xmlns:ex", "http://example.org/ex");
        // Second call should return cached value
        String ns2 = pointer.getNamespaceURI("ex");
        assertEquals("http://example.com/ex", ns2);
    }

    @Test
    public void testGetNamespaceURIPrefixNotFound() throws Exception {
        Document doc = builder.newDocument();
        Element root = doc.createElement("root");
        doc.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(root, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("unknown");
        assertNull(ns);
    }

    @Test
    public void testGetNamespaceURIPrefixEmptyNamespace() throws Exception {
        Document doc = builder.newDocument();
        Element root = doc.createElement("root");
        root.setAttribute("xmlns:ex", "");
        doc.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(root, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("ex");
        assertNull(ns);
    }

    @Test
    public void testGetNamespaceURIPrefixUnknownNamespace() throws Exception {
        Document doc = builder.newDocument();
        Element root = doc.createElement("root");
        doc.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(root, Locale.ENGLISH);
        String ns = pointer.getNamespaceURI("unknown");
        assertNull(ns);
    }

    @Test
    public void testGetNamespaceURIPrefixAfterUnknown() throws Exception {
        Document doc = builder.newDocument();
        Element root = doc.createElement("root");
        root.setAttribute("xmlns:ex", "http://example.com/ex");
        doc.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(root, Locale.ENGLISH);
        // First call with unknown prefix
        String ns1 = pointer.getNamespaceURI("unknown");
        assertNull(ns1);
        // Now call with known prefix
        String ns2 = pointer.getNamespaceURI("ex");
        assertEquals("http://example.com/ex", ns2);
    }
}