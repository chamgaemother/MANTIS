package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClusteredXYBarRenderer_drawItem_1_1_Test {

    BarPainter barPainterMock;
    ClusteredXYBarRenderer renderer;

    @BeforeEach
    void setUp() throws Exception {
        barPainterMock = mock(BarPainter.class);
        renderer = new ClusteredXYBarRenderer();
        Field barPainterField = XYBarRenderer.class.getDeclaredField("barPainter");
        barPainterField.setAccessible(true);
        barPainterField.set(renderer, barPainterMock);
    }

//     @Test
//     @DisplayName("TC06: drawItem centers bars correctly when centerBarAtStartValue is false and margin is greater than zero")
//     public void TC06_drawItem_centerBarAtStartValue_false_with_margin() throws Exception {
        // GIVEN
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer(0.1, false));
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(2);
//         when(dataset.getItemCount(anyInt())).thenReturn(1);
//         when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(20.0);
//         when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(15.0);
//         Graphics2D graphics = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        // WHEN
//         renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        // THEN
//         ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
//         verify(barPainterMock, times(1)).paintBar(eq(graphics), eq(renderer), eq(0), eq(0), rectCaptor.capture(), any());
//         Rectangle2D paintedBar = rectCaptor.getValue();
//         assertNotNull(paintedBar);
        // Additional assertions can be added to verify the position and size of the bar
//     }

//     @Test
//     @DisplayName("TC07: drawItem handles margin zero correctly with centerBarAtStartValue false")
//     public void TC07_drawItem_centerBarAtStartValue_false_with_zero_margin() throws Exception {
        // GIVEN
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer(0.0, false));
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(2);
//         when(dataset.getItemCount(anyInt())).thenReturn(1);
//         when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(20.0);
//         when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(15.0);
//         Graphics2D graphics = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        // WHEN
//         renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        // THEN
//         ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
//         verify(barPainterMock, times(1)).paintBar(eq(graphics), eq(renderer), eq(0), eq(0), rectCaptor.capture(), any());
//         Rectangle2D paintedBar = rectCaptor.getValue();
//         assertNotNull(paintedBar);
//     }

    @Test
    @DisplayName("TC08: drawItem does not paint any bars when all series are not visible")
    public void TC08_drawItem_all_series_not_visible() throws Exception {
        // GIVEN
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        when(dataset.getItemCount(anyInt())).thenReturn(1);
        Graphics2D graphics = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(20.0);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(15.0);

        doReturn(false).when(renderer).isSeriesVisible(anyInt());

        // WHEN
        renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // THEN
        verify(barPainterMock, never()).paintBar(any(), any(), anyInt(), anyInt(), any(), any());
        verify(barPainterMock, never()).paintBarShadow(any(), any(), anyInt(), anyInt(), any(), any(), anyBoolean());
    }

    @Test
    @DisplayName("TC09: drawItem throws IllegalStateException for unsupported PlotOrientation")
    public void TC09_drawItem_unsupported_plot_orientation() throws Exception {
        // GIVEN
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(anyInt())).thenReturn(1);
        when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(20.0);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(15.0);
        Graphics2D graphics = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        when(plot.getOrientation()).thenReturn(null); // Unsupported orientation

        // THEN
        assertThrows(IllegalStateException.class, () -> {
            // WHEN
            renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        });
    }

//     @Test
//     @DisplayName("TC10: drawItem adds entities correctly when PlotRenderingInfo and EntityCollection are provided")
//     public void TC10_drawItem_adds_entities_correctly() throws Exception {
        // GIVEN
//         ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(2);
//         when(dataset.getItemCount(anyInt())).thenReturn(1);
//         when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(20.0);
//         when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(15.0);
// 
//         Graphics2D graphics = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.plot.Plot.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
// 
        // WHEN
//         renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
        // THEN
//         ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
//         ArgumentCaptor<XYDataset> datasetCaptor = ArgumentCaptor.forClass(XYDataset.class);
//         ArgumentCaptor<Integer> seriesCaptor = ArgumentCaptor.forClass(Integer.class);
//         ArgumentCaptor<Integer> itemCaptor = ArgumentCaptor.forClass(Integer.class);
//         ArgumentCaptor<Double> xCaptor = ArgumentCaptor.forClass(Double.class);
//         ArgumentCaptor<Double> yCaptor = ArgumentCaptor.forClass(Double.class);
//         verify(entities, times(1)).addEntity(rectCaptor.capture(), datasetCaptor.capture(), seriesCaptor.capture(), itemCaptor.capture(), xCaptor.capture(), yCaptor.capture());
// 
//         Rectangle2D addedEntity = rectCaptor.getValue();
//         assertNotNull(addedEntity);
//         assertEquals(50.0, addedEntity.getX(), 0.01);
//         assertEquals(50.0, addedEntity.getY(), 0.01);
//     }
}