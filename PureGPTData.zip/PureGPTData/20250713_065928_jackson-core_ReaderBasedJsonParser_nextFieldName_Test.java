import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.json.ReaderBasedJsonParser;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ReaderBasedJsonParserTest {

    private IOContext ioContext;
    private Reader reader;
    private ObjectCodec codec;
    private CharsToNameCanonicalizer symbols;

    @BeforeEach
    void setup() {
        ioContext = mock(IOContext.class);
        codec = mock(ObjectCodec.class);
        symbols = CharsToNameCanonicalizer.createRoot();
    }

    @Test
    void testNextFieldNameWithQuotedName() throws IOException {
        String json = "{\"fieldName\":\"value\"}";
        reader = new StringReader(json);
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, 0, reader, codec, symbols);
        parser.nextToken(); // StartObject
        String result = parser.nextFieldName();
        assertEquals("fieldName", result);
    }

    @Test
    void testNextFieldNameWithCommaAndTrailingCommaDisallowed() throws IOException {
        String json = "{\"field1\":\"value1\", \"field2\":\"value2\"}";
        reader = new StringReader(json);
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, 0, reader, codec, symbols);
        parser.nextToken(); // StartObject
        parser.nextFieldName(); // field1
        String result = parser.nextFieldName(); // field2
        assertEquals("field2", result);
    }

    @Test
    void testNextFieldNameWithCommaAndTrailingCommaAllowed() throws IOException {
        String json = "{\"field1\":\"value1\", }";
        reader = new StringReader(json);
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, ReaderBasedJsonParser.FEAT_MASK_TRAILING_COMMA, reader, codec, symbols);
        parser.nextToken(); // StartObject
        parser.nextFieldName(); // field1
        String result = parser.nextFieldName(); // should handle trailing comma gracefully
        assertEquals(null, result);
    }

    @Test
    void testNextFieldNameWhenNotInObject() throws IOException {
        String json = "[\"value1\", \"value2\"]";
        reader = new StringReader(json);
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, 0, reader, codec, symbols);
        parser.nextToken(); // StartArray
        String result = parser.nextFieldName(); // Not in an object, should return null
        assertEquals(null, result);
    }

    @Test
    void testNextFieldNameAtEndOfInput() throws IOException {
        String json = "{\"field1\":\"value1\"}";
        reader = new StringReader(json);
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, 0, reader, codec, symbols);
        parser.nextToken(); // StartObject
        parser.nextFieldName(); // field1
        parser.nextToken(); // value1
        parser.nextToken(); // EndObject
        String result = parser.nextFieldName(); // End of input, should return null
        assertEquals(null, result);
    }

    @Test
    void testNextFieldNameWithSkipString() throws IOException {
        String json = "{ \"stringField\": \"st\\\"ring\" }";
        reader = new StringReader(json);
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, 0, reader, codec, symbols);
        parser.nextToken(); // StartObject
        parser.nextFieldName(); // stringField
        parser.nextToken(); // VALUE_STRING
        parser.finishToken(); // ensures _tokenIncomplete is reset
        String result = parser.nextFieldName(); // null
        assertEquals(null, result);
    }

    @Test
    void testNextFieldNameWithInvalidField() throws IOException {
        String json = "{ invalidField: \"value\" }";
        reader = new StringReader(json);
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, ReaderBasedJsonParser.FEAT_MASK_ALLOW_UNQUOTED_NAMES, reader, codec, symbols);
        parser.nextToken(); // StartObject
        String result = parser.nextFieldName(); // Should parse 'invalidField'
        assertEquals("invalidField", result);
    }
}