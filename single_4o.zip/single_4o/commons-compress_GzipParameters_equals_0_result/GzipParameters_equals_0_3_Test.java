package org.apache.commons.compress.compressors.gzip;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GzipParameters_equals_0_3_Test {

    @Test
    @DisplayName("Different headerCrc values yield false.")
    public void testHeaderCrcDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setHeaderCRC(true);
        GzipParameters params2 = new GzipParameters();
        params2.setHeaderCRC(false);

        boolean result = params1.equals(params2);

        assertEquals(false, result);
    }

    @Test
    @DisplayName("Different modificationInstant values yield false.")
    public void testModificationInstantDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setModificationInstant(Instant.now());
        GzipParameters params2 = new GzipParameters();
        params2.setModificationInstant(Instant.now().minusSeconds(60));

        boolean result = params1.equals(params2);

        assertEquals(false, result);
    }

    @Test
    @DisplayName("Different operatingSystem values yield false.")
    public void testOperatingSystemDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setOperatingSystem(GzipParameters.OS.UNIX.type()); // Use type() method instead of ordinal()
        GzipParameters params2 = new GzipParameters();
        params2.setOperatingSystem(GzipParameters.OS.UNKNOWN.type()); // Use type() method instead of ordinal()

        boolean result = params1.equals(params2);

        assertEquals(false, result);
    }

    @Test
    @DisplayName("Different trailerCrc values yield false.")
    public void testTrailerCrcDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setTrailerCrc(123456789);
        GzipParameters params2 = new GzipParameters();
        params2.setTrailerCrc(987654321);

        boolean result = params1.equals(params2);

        assertEquals(false, result);
    }

    @Test
    @DisplayName("Different trailerISize values yield false.")
    public void testTrailerISizeDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setTrailerISize(256);
        GzipParameters params2 = new GzipParameters();
        params2.setTrailerISize(512);

        boolean result = params1.equals(params2);

        assertEquals(false, result);
    }
}