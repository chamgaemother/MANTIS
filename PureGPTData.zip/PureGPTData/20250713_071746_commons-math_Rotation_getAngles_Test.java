import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.exception.MathIllegalStateException;
import org.apache.commons.math3.geometry.euclidean.threed.Rotation;
import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
import org.junit.jupiter.api.Test;

class RotationTest {

    @Test
    void testGetAnglesXYZVectorOperator() {
        // Test the XYZ order with Vector Operator convention
        Rotation rotation = new Rotation(RotationOrder.XYZ, 0.1, 0.2, 0.3);
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAnglesXYZFrameTransform() {
        // Test the XYZ order with Frame Transform convention
        Rotation rotation = new Rotation(RotationOrder.XYZ, 0.1, 0.2, 0.3);
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAnglesSingularityXYZVectorOperator() {
        // Test for singularity in XYZ order with Vector Operator convention
        Rotation rotation = new Rotation(Vector3D.PLUS_K, Math.PI / 2, RotationConvention.VECTOR_OPERATOR);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);
        });
    }
    
    @Test
    void testGetAnglesSingularityXYZFrameTransform() {
        // Test for singularity in XYZ order with Frame Transform convention
        Rotation rotation = new Rotation(Vector3D.PLUS_K, Math.PI / 2, RotationConvention.FRAME_TRANSFORM);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    void testGetAnglesZYXVectorOperator() {
        // Test the ZYX order with Vector Operator convention
        Rotation rotation = new Rotation(RotationOrder.ZYX, 0.1, 0.2, 0.3);
        double[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAnglesZYXFrameTransform() {
        // Test the ZYX order with Frame Transform convention
        Rotation rotation = new Rotation(RotationOrder.ZYX, 0.1, 0.2, 0.3);
        double[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM);
        assertNotNull(angles);
        assertEquals(3, angles.length);
    }

    @Test
    void testGetAnglesSingularityZYXVectorOperator() {
        // Test for singularity in ZYX order with Vector Operator convention
        Rotation rotation = new Rotation(Vector3D.MINUS_K, Math.PI / 2, RotationConvention.VECTOR_OPERATOR);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
        });
    }
    
    @Test
    void testGetAnglesSingularityZYXFrameTransform() {
        // Test for singularity in ZYX order with Frame Transform convention
        Rotation rotation = new Rotation(Vector3D.MINUS_K, Math.PI / 2, RotationConvention.FRAME_TRANSFORM);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    void testGetAnglesDifferentOrdersAndConventions() {
        // Test different rotation orders and conventions
        for (RotationOrder order : RotationOrder.values()) {
            Rotation rotation = new Rotation(order, 0.5, 1.0, 1.5);
            double[] anglesVO = rotation.getAngles(order, RotationConvention.VECTOR_OPERATOR);
            double[] anglesFT = rotation.getAngles(order, RotationConvention.FRAME_TRANSFORM);
            assertNotNull(anglesVO);
            assertEquals(3, anglesVO.length);
            assertNotNull(anglesFT);
            assertEquals(3, anglesFT.length);
        }
    }
}