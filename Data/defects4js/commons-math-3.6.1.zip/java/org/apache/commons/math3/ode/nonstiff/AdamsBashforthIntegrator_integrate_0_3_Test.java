package org.apache.commons.math3.ode.nonstiff;

import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class AdamsBashforthIntegrator_integrate_0_3_Test {

//    @Test
//    @DisplayName("Integration with error estimation returning 1.0")
//    public void TC11_integrationWithErrorEstimationOne() throws Exception {
//        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.0, 1.0, 1e-10, 1e-10);
//
//        ExpandableStatefulODE equations = new ExpandableStatefulODE(null);
//        equations.setTime(0.0);
//        double[] initialState = {1.0, 0.0};
//        equations.setCompleteState(initialState);
//
//        double targetTime = 3.0;
//
//        integrator.integrate(equations, targetTime);
//
//        assertEquals(3.0, equations.getTime(), 1e-6, "Equations time should be exactly 3.0");
//    }

    @Test
    @DisplayName("Integration exceeding maximum iterations")
    public void TC12_integrationExceedingMaxIterations() throws Exception {
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.0, 1.0, 1e-10, 1e-10);

        ExpandableStatefulODE equations = new ExpandableStatefulODE(null);
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState);

        double targetTime = 100.0;

        Exception exception = assertThrows(MaxCountExceededException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                integrator.integrate(equations, targetTime);
            }
        });

        assertTrue(exception.getMessage().contains("iterations exceeded"));
    }

    @Test
    @DisplayName("Backward integration direction")
    public void TC13_integrationBackwardDirection() throws Exception {
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.0, 1.0, 1e-10, 1e-10);

        ExpandableStatefulODE equations = new ExpandableStatefulODE(null);
        equations.setTime(10.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState);

        double targetTime = 5.0;

        integrator.integrate(equations, targetTime);

        assertEquals(5.0, equations.getTime(), 1e-6, "Equations time should be exactly 5.0");
    }

    @Test
    @DisplayName("Integration with step size reduced to zero")
    public void TC14_integrationStepSizeReducedToZero() throws Exception {
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.0, 1.0, 1e-10, 1e-10);

        ExpandableStatefulODE equations = new ExpandableStatefulODE(null);
        equations.setTime(0.0);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState);

        double targetTime = 5.0;

        Exception exception = assertThrows(MaxCountExceededException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                integrator.integrate(equations, targetTime);
            }
        });

        assertTrue(exception.getMessage().contains("step size"));
    }

    @Test
    @DisplayName("Integration adjusts step size to reach target time")
    public void TC15_integrationAdjustsStepSizeToReachTargetTime() throws Exception {
        AdamsBashforthIntegrator integrator = new AdamsBashforthIntegrator(4, 0.0, 1.0, 1e-10, 1e-10);

        ExpandableStatefulODE equations = new ExpandableStatefulODE(null);
        equations.setTime(4.5);
        double[] initialState = {1.0, 0.0};
        equations.setCompleteState(initialState);

        double targetTime = 5.0;

        integrator.integrate(equations, targetTime);

        assertEquals(5.0, equations.getTime(), 1e-6, "Equations time should be exactly 5.0");
    }
}
