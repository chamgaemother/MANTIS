// package org.apache.commons.compress.harmony.pack200;
// 
// import org.apache.commons.compress.harmony.pack200.ClassBands;
// import org.apache.commons.compress.harmony.pack200.Segment;
// import org.apache.commons.compress.harmony.pack200.SegmentHeader;
// import org.apache.commons.compress.harmony.pack200.CPClass;
// import org.apache.commons.compress.harmony.pack200.IcBands;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// import java.lang.reflect.*;
// import java.util.*;
// 
// public class ClassBands_finaliseBands_2_1_Test {
// 
//     @Test
//     @DisplayName("finaliseBands updates class_flags and adds to version lists when multiple classes have major_versions differing from defaultMajorVersion")
//     public void TC14_finaliseBands_multiple_differing_class_versions() throws Exception {
//         // Arrange
//         // Initialize ClassBands with mocked dependencies
//         Segment mockSegment = mock(Segment.class);
//         SegmentHeader mockSegmentHeader = mock(SegmentHeader.class);
//         when(mockSegment.getSegmentHeader()).thenReturn(mockSegmentHeader);
//         when(mockSegmentHeader.getDefaultMajorVersion()).thenReturn(52); // example defaultMajorVersion
// 
//         ClassBands classBands = new ClassBands(mockSegment, 3, 0, false); // 3 classes
// 
//         // Use reflection to set major_versions and class_flags
//         Field majorVersionsField = ClassBands.class.getDeclaredField("major_versions");
//         majorVersionsField.setAccessible(true);
//         int[] majorVersions = (int[]) majorVersionsField.get(classBands);
//         majorVersions[0] = 52; // default, same as defaultMajorVersion
//         majorVersions[1] = 53; // differs
//         majorVersions[2] = 54; // differs
// 
//         Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
//         classFlagsField.setAccessible(true);
//         long[] classFlags = (long[]) classFlagsField.get(classBands);
//         classFlags[0] = 0L;
//         classFlags[1] = 0L;
//         classFlags[2] = 0L;
// 
//         // Act
//         classBands.finaliseBands();
// 
//         // Assert
//         // Verify class_flags[1] and class_flags[2] have 1<<24 set
//         assertTrue((classFlags[1] & (1L << 24)) != 0, "class_flags[1] should have 1<<24 set");
//         assertTrue((classFlags[2] & (1L << 24)) != 0, "class_flags[2] should have 1<<24 set");
// 
//         // Access classFileVersionMajor and classFileVersionMinor via reflection
//         Field classFileVersionMajorField = ClassBands.class.getDeclaredField("classFileVersionMajor");
//         classFileVersionMajorField.setAccessible(true);
//         List<Integer> classFileVersionMajor = (List<Integer>) classFileVersionMajorField.get(classBands);
// 
//         Field classFileVersionMinorField = ClassBands.class.getDeclaredField("classFileVersionMinor");
//         classFileVersionMinorField.setAccessible(true);
//         List<Integer> classFileVersionMinor = (List<Integer>) classFileVersionMinorField.get(classBands);
// 
//         assertEquals(2, classFileVersionMajor.size(), "classFileVersionMajor should have 2 entries");
//         assertEquals(2, classFileVersionMinor.size(), "classFileVersionMinor should have 2 entries");
// 
//         assertTrue(classFileVersionMajor.contains(53), "classFileVersionMajor should contain 53");
//         assertTrue(classFileVersionMajor.contains(54), "classFileVersionMajor should contain 54");
//         assertTrue(classFileVersionMinor.stream().allMatch(i -> i == 0), "classFileVersionMinor should contain only 0s");
//     }
// 
//     @Test
//     @DisplayName("finaliseBands ignores anonymous inner classes and does not add them to icLocal entries")
//     public void TC15_finaliseBands_ignores_anonymous_inner_classes() throws Exception {
//         // Arrange
//         Segment mockSegment = mock(Segment.class);
//         SegmentHeader mockSegmentHeader = mock(SegmentHeader.class);
//         when(mockSegment.getSegmentHeader()).thenReturn(mockSegmentHeader);
// 
//         ClassBands classBands = new ClassBands(mockSegment, 2, 0, false); // 2 classes
// 
//         // Set up inner classes, including an anonymous inner class
//         Field classReferencesInnerClassField = ClassBands.class.getDeclaredField("classReferencesInnerClass");
//         classReferencesInnerClassField.setAccessible(true);
//         Map<CPClass, Set<CPClass>> classReferencesInnerClass = (Map<CPClass, Set<CPClass>>) classReferencesInnerClassField.get(classBands);
// 
//         CPClass outerClass = mock(CPClass.class);
//         CPClass innerClass = mock(CPClass.class);
//         CPClass anonymousInnerClass = mock(CPClass.class);
//         when(outerClass.toString()).thenReturn("org.example.OuterClass");
//         when(innerClass.toString()).thenReturn("org.example.OuterClass$InnerClass");
//         when(anonymousInnerClass.toString()).thenReturn("org.example.OuterClass$1");
// 
//         classReferencesInnerClass.put(outerClass, new HashSet<>(Arrays.asList(innerClass, anonymousInnerClass)));
// 
//         // Mock IcBands behavior
//         IcBands mockIcBands = mock(IcBands.class);
//         when(mockSegment.getIcBands()).thenReturn(mockIcBands);
// 
//         List<IcBands.IcTuple> existingInnerClasses = Arrays.asList(
//                 new IcBands.IcTuple(innerClass, null, 0)
//         );
//         when(mockIcBands.getInnerClassesForOuter("org.example.OuterClass")).thenReturn(existingInnerClasses);
//         when(mockIcBands.getIcTuple(innerClass)).thenReturn(new IcBands.IcTuple(innerClass, null, 0));
//         when(mockIcBands.getIcTuple(anonymousInnerClass)).thenReturn(new IcBands.IcTuple(anonymousInnerClass, null, 0));
// 
//         // Use reflection to set class_this
//         Field classThisField = ClassBands.class.getDeclaredField("class_this");
//         classThisField.setAccessible(true);
//         CPClass[] classThis = (CPClass[]) classThisField.get(classBands);
//         classThis[0] = outerClass;
// 
//         // Act
//         classBands.finaliseBands();
// 
//         // Assert
//         // Access inner class fields via reflection
//         Field classInnerClassesRCField = ClassBands.class.getDeclaredField("class_InnerClasses_RC");
//         classInnerClassesRCField.setAccessible(true);
//         CPClass[] class_InnerClasses_RC = (CPClass[]) classInnerClassesRCField.get(classBands);
// 
//         assertNotNull(class_InnerClasses_RC, "class_InnerClasses_RC should not be null");
//         assertEquals(1, class_InnerClasses_RC.length, "Only non-anonymous inner classes should be added");
//         assertEquals(innerClass, class_InnerClasses_RC[0], "Only non-anonymous innerClass should be added");
//     }
// 
//     @Test
//     @DisplayName("finaliseBands adds all non-anonymous inner classes to icLocal entries")
//     public void TC16_finaliseBands_processes_multiple_non_anonymous_inner_classes() throws Exception {
//         // Arrange
//         Segment mockSegment = mock(Segment.class);
//         SegmentHeader mockSegmentHeader = mock(SegmentHeader.class);
//         when(mockSegment.getSegmentHeader()).thenReturn(mockSegmentHeader);
// 
//         ClassBands classBands = new ClassBands(mockSegment, 3, 0, false); // 3 classes
// 
//         // Set up inner classes, all non-anonymous
//         Field classReferencesInnerClassField = ClassBands.class.getDeclaredField("classReferencesInnerClass");
//         classReferencesInnerClassField.setAccessible(true);
//         Map<CPClass, Set<CPClass>> classReferencesInnerClass = (Map<CPClass, Set<CPClass>>) classReferencesInnerClassField.get(classBands);
// 
//         CPClass outerClass1 = mock(CPClass.class);
//         CPClass innerClass1 = mock(CPClass.class);
//         CPClass innerClass2 = mock(CPClass.class);
//         when(outerClass1.toString()).thenReturn("org.example.OuterClass1");
//         when(innerClass1.toString()).thenReturn("org.example.OuterClass1$InnerClass1");
//         when(innerClass2.toString()).thenReturn("org.example.OuterClass1$InnerClass2");
// 
//         classReferencesInnerClass.put(outerClass1, new HashSet<>(Arrays.asList(innerClass1, innerClass2)));
// 
//         // Mock IcBands behavior
//         IcBands mockIcBands = mock(IcBands.class);
//         when(mockSegment.getIcBands()).thenReturn(mockIcBands);
// 
//         List<IcBands.IcTuple> existingInnerClasses = Arrays.asList(
//                 new IcBands.IcTuple(innerClass1, null, 0),
//                 new IcBands.IcTuple(innerClass2, null, 0)
//         );
//         when(mockIcBands.getInnerClassesForOuter("org.example.OuterClass1")).thenReturn(existingInnerClasses);
//         when(mockIcBands.getIcTuple(innerClass1)).thenReturn(new IcBands.IcTuple(innerClass1, null, 0));
//         when(mockIcBands.getIcTuple(innerClass2)).thenReturn(new IcBands.IcTuple(innerClass2, null, 0));
// 
//         // Use reflection to set class_this
//         Field classThisField = ClassBands.class.getDeclaredField("class_this");
//         classThisField.setAccessible(true);
//         CPClass[] classThis = (CPClass[]) classThisField.get(classBands);
//         classThis[0] = outerClass1;
// 
//         // Act
//         classBands.finaliseBands();
// 
//         // Assert
//         // Access inner class fields via reflection
//         Field classInnerClassesRCField = ClassBands.class.getDeclaredField("class_InnerClasses_RC");
//         classInnerClassesRCField.setAccessible(true);
//         CPClass[] class_InnerClasses_RC = (CPClass[]) classInnerClassesRCField.get(classBands);
// 
//         assertNotNull(class_InnerClasses_RC, "class_InnerClasses_RC should not be null");
//         assertEquals(2, class_InnerClasses_RC.length, "All non-anonymous inner classes should be added");
//         assertTrue(Arrays.asList(class_InnerClasses_RC).contains(innerClass1), "InnerClass1 should be added");
//         assertTrue(Arrays.asList(class_InnerClasses_RC).contains(innerClass2), "InnerClass2 should be added");
// 
//         // Also verify class_flags are updated
//         Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
//         classFlagsField.setAccessible(true);
//         long[] classFlags = (long[]) classFlagsField.get(classBands);
//         assertTrue((classFlags[0] & (1L << 23)) != 0, "class_flags[0] should have 1<<23 set for inner classes");
//     }
// 
//     @Test
//     @DisplayName("finaliseBands correctly sets codeHeaders when header is exactly 144")
//     public void TC17_finaliseBands_sets_codeHeaders_at_boundary_144() throws Exception {
//         // Arrange
//         Segment mockSegment = mock(Segment.class);
//         SegmentHeader mockSegmentHeader = mock(SegmentHeader.class);
//         when(mockSegment.getSegmentHeader()).thenReturn(mockSegmentHeader);
//         when(mockSegmentHeader.have_all_code_flags()).thenReturn(false);
// 
//         ClassBands classBands = new ClassBands(mockSegment, 1, 0, false); // 1 class
// 
//         // Set codeHandlerCount to 0, codeMaxLocals to 12, codeMaxStack to 0
//         Field codeHandlerCountField = ClassBands.class.getDeclaredField("codeHandlerCount");
//         codeHandlerCountField.setAccessible(true);
//         IntList codeHandlerCount = (IntList) codeHandlerCountField.get(classBands);
//         codeHandlerCount.add(0);
// 
//         Field codeMaxLocalsField = ClassBands.class.getDeclaredField("codeMaxLocals");
//         codeMaxLocalsField.setAccessible(true);
//         IntList codeMaxLocals = (IntList) codeMaxLocalsField.get(classBands);
//         codeMaxLocals.add(12);
// 
//         Field codeMaxStackField = ClassBands.class.getDeclaredField("codeMaxStack");
//         codeMaxStackField.setAccessible(true);
//         IntList codeMaxStack = (IntList) codeMaxStackField.get(classBands);
//         codeMaxStack.add(0);
// 
//         // Act
//         classBands.finaliseBands();
// 
//         // Assert
//         // Access codeHeaders via reflection
//         Field codeHeadersField = ClassBands.class.getDeclaredField("codeHeaders");
//         codeHeadersField.setAccessible(true);
//         int[] codeHeaders = (int[]) codeHeadersField.get(classBands);
// 
//         assertEquals(1, codeHeaders.length, "There should be one codeHeader entry");
//         assertEquals(144, codeHeaders[0], "codeHeaders[0] should be set to 144");
// 
//         // Verify codeHandlerCount, codeMaxLocals, and codeMaxStack are removed
//         assertEquals(0, codeHandlerCount.size(), "codeHandlerCount should be removed");
//         assertEquals(0, codeMaxLocals.size(), "codeMaxLocals should be removed");
//         assertEquals(0, codeMaxStack.size(), "codeMaxStack should be removed");
// 
//         // Verify codeFlags are updated
//         Field codeFlagsField = ClassBands.class.getDeclaredField("codeFlags");
//         codeFlagsField.setAccessible(true);
//         List<Long> codeFlags = (List<Long>) codeFlagsField.get(classBands);
//         assertEquals(1, codeFlags.size(), "There should be one codeFlag entry");
//         assertEquals(0L, codeFlags.get(0).longValue(), "codeFlags[0] should be set to 0");
//     }
// 
//     @Test
//     @DisplayName("finaliseBands does not set codeHeaders when header is exactly 145")
//     public void TC18_finaliseBands_does_not_set_codeHeaders_at_boundary_145() throws Exception {
//         // Arrange
//         Segment mockSegment = mock(Segment.class);
//         SegmentHeader mockSegmentHeader = mock(SegmentHeader.class);
//         when(mockSegment.getSegmentHeader()).thenReturn(mockSegmentHeader);
//         when(mockSegmentHeader.have_all_code_flags()).thenReturn(false);
// 
//         ClassBands classBands = new ClassBands(mockSegment, 1, 0, false); // 1 class
// 
//         // Set codeHandlerCount to 0, codeMaxLocals to 12, codeMaxStack to 1
//         Field codeHandlerCountField = ClassBands.class.getDeclaredField("codeHandlerCount");
//         codeHandlerCountField.setAccessible(true);
//         IntList codeHandlerCount = (IntList) codeHandlerCountField.get(classBands);
//         codeHandlerCount.add(0);
// 
//         Field codeMaxLocalsField = ClassBands.class.getDeclaredField("codeMaxLocals");
//         codeMaxLocalsField.setAccessible(true);
//         IntList codeMaxLocals = (IntList) codeMaxLocalsField.get(classBands);
//         codeMaxLocals.add(12);
// 
//         Field codeMaxStackField = ClassBands.class.getDeclaredField("codeMaxStack");
//         codeMaxStackField.setAccessible(true);
//         IntList codeMaxStack = (IntList) codeMaxStackField.get(classBands);
//         codeMaxStack.add(1);
// 
//         // Act
//         classBands.finaliseBands();
// 
//         // Assert
//         // Access codeHeaders via reflection
//         Field codeHeadersField = ClassBands.class.getDeclaredField("codeHeaders");
//         codeHeadersField.setAccessible(true);
//         int[] codeHeaders = (int[]) codeHeadersField.get(classBands);
// 
//         // Since header is exactly 145, and not less than, codeHeaders[i] should not be set
//         assertEquals(1, codeHeaders.length, "There should be one codeHeader entry");
//         assertEquals(0, codeHeaders[0], "codeHeaders[0] should not be set (remain as 0)");
// 
//         // Verify codeHandlerCount, codeMaxLocals, and codeMaxStack are removed because codeHeaders[i] was not set
//         assertEquals(0, codeHandlerCount.size(), "codeHandlerCount should be removed");
//         assertEquals(0, codeMaxLocals.size(), "codeMaxLocals should be removed");
//         assertEquals(0, codeMaxStack.size(), "codeMaxStack should be removed");
// 
//         // Verify codeFlags are updated accordingly
//         Field codeFlagsField = ClassBands.class.getDeclaredField("codeFlags");
//         codeFlagsField.setAccessible(true);
//         List<Long> codeFlags = (List<Long>) codeFlagsField.get(classBands);
//         assertEquals(1, codeFlags.size(), "There should be one codeFlag entry");
//         assertEquals(0L, codeFlags.get(0).longValue(), "codeFlags[0] should be set to 0");
//     }
// }