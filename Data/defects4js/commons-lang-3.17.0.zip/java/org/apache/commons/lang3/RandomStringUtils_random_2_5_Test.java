package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class RandomStringUtils_random_2_5_Test {

    @Test
    @DisplayName("random(count=8, start=0, end=0, letters=true, numbers=true, chars={a, b, c, 1, 2, 3}, random) generates alphanumerical string from limited chars")
    public void TC26_limited_alphanumerical_chars() {
        // Initialize inputs
        int count = 8;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = { 'a', 'b', 'c', '1', '2', '3' };
        Random random = new Random();
        
        // Call method under test
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // Assertions
        assertEquals(8, result.length(), "Result string length should be 8");
        assertTrue(result.chars().allMatch(c -> (Character.isLetterOrDigit(c) && new String(chars).indexOf(c) >= 0)), 
            "All characters should be alphanumerical and from the provided chars array");
    }
}