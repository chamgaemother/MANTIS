package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_get_0_3_Test {

    @Test
    @DisplayName("Delegate map is null, key is not null, size=1, hash matches and keys are equal")
    void test_TC11() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Create key and value
        Object key = "key1";
        Object value = "value1";

        // Set key1, hash1, value1
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key);

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, key.hashCode());

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, value);

        // Act
        Object result = map.get(key);

        // Assert
        assertEquals(value, result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=1, hash matches but keys are not equal")
    void test_TC12() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Create keys and value
        Object key = "key1";
        Object nonMatchingKey = "key2"; // Different key
        Object value = "value1";

        // Set key1, hash1, value1
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key);

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, key.hashCode());

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, value);

        // Act
        Object result = map.get(nonMatchingKey);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=2, hash2 matches and keys are equal")
    void test_TC13() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Create key and value
        Object key = "key2";
        Object value = "value2";

        // Set key2, hash2, value2
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key);

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, key.hashCode());

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, value);

        // Act
        Object result = map.get(key);

        // Assert
        assertEquals(value, result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=2, hash2 matches but keys are not equal")
    void test_TC14() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Create keys and value
        Object key = "key2";
        Object nonMatchingKey = "key3"; // Different key
        Object value = "value2";

        // Set key2, hash2, value2
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key);

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, key.hashCode());

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, value);

        // Act
        Object result = map.get(nonMatchingKey);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=3, hash3 matches and keys are equal")
    void test_TC15() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Create key and value
        Object key = "key3";
        Object value = "value3";

        // Set key3, hash3, value3
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, key);

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, key.hashCode());

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, value);

        // Act
        Object result = map.get(key);

        // Assert
        assertEquals(value, result);
    }
}