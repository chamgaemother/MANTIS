package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Generated JUnit 5 test class for ColognePhonetic.colognePhonetic.
 */
public class ColognePhonetic_colognePhonetic_0_4_Test {

    @Test
    @DisplayName("Input with 'M' and 'N' should assign code '6'")
    public void TC16_inputWithMAndN_shouldAssignCode6() {
        // GIVEN
        String input = "Mann, Monica";
        // WHEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        // THEN
        assertTrue(result.contains("6"), "Result should contain '6' for 'M' and 'N'");
    }

    @Test
    @DisplayName("Input with 'R' should assign code '7'")
    public void TC17_inputWithR_shouldAssignCode7() {
        // GIVEN
        String input = "Robert";
        // WHEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        // THEN
        assertTrue(result.contains("7"), "Result should contain '7' for 'R'");
    }

    @Test
    @DisplayName("Input with repeating codes, should collapse multiple consecutive digits")
    public void TC18_inputWithRepeatingCodes_shouldCollapseConsecutiveDigits() {
        // GIVEN
        String input = "Sassafras";
        // WHEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        // THEN
        assertAll("Result should handle collapsing of repeating codes",
            () -> assertTrue(result.contains("8"), "Result should contain '8'"),
            () -> assertFalse(result.contains("88"), "Result should not contain consecutive '8's")
        );
    }

    @Test
    @DisplayName("Input with non-alphabetic characters, should ignore them after preprocessing")
    public void TC19_inputWithNonAlphabeticCharacters_shouldIgnoreThem() {
        // GIVEN
        String input = "Hello, World! 123";
        // WHEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        // THEN
        assertAll("Result should ignore non-alphabetic characters",
            () -> assertFalse(result.contains(","), "Result should not contain ','"),
            () -> assertFalse(result.contains("!"), "Result should not contain '!'"),
            () -> assertFalse(result.contains("1"), "Result should not contain '1'"),
            () -> assertFalse(result.contains("2"), "Result should not contain '2'"),
            () -> assertFalse(result.contains("3"), "Result should not contain '3'")
        );
    }

    @Test
    @DisplayName("Input with Germanic umlauts, should preprocess correctly")
    public void TC20_inputWithGermanicUmlauts_shouldPreprocessCorrectly() {
        // GIVEN
        // The input string must correctly represent characters. The incorrect escaped sequence in the input should be fixed.
        String input = "Ãpfel ÃbermÃ¤Ãig Ãl";
        // WHEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);
        // THEN
        assertAll("Result should have umlaut characters replaced appropriately",
            () -> assertTrue(result.contains("A"), "Result should contain 'A'"),
            () -> assertTrue(result.contains("U"), "Result should contain 'U'"),
            () -> assertTrue(result.contains("O"), "Result should contain 'O'")
        );
    }
}
