package org.apache.commons.collections4.functors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.util.Comparator;

public class ComparatorPredicate_test_0_2_Test {

    @Test
    @DisplayName("Criterion LESS with comparison not less than zero returns false")
    public void testTC06() {
        // GIVEN
        Comparator<Object> comparator = (o1, o2) -> 0;
        Object target = new Object();
        // Instantiating correctly using the correct constructor
        ComparatorPredicate<Object> predicate = 
            new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.LESS);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        Assertions.assertEquals(false, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL with comparison greater than zero returns true")
    public void testTC07() {
        // GIVEN
        Comparator<Object> comparator = (o1, o2) -> 1;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = 
            new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.GREATER_OR_EQUAL);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        Assertions.assertEquals(true, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL with comparison equal to zero returns true")
    public void testTC08() {
        // GIVEN
        Comparator<Object> comparator = (o1, o2) -> 0;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = 
            new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.GREATER_OR_EQUAL);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        Assertions.assertEquals(true, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL with comparison less than zero returns false")
    public void testTC09() {
        // GIVEN
        Comparator<Object> comparator = (o1, o2) -> -1;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = 
            new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.GREATER_OR_EQUAL);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        Assertions.assertEquals(false, result);
    }

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL with comparison less than zero returns true")
    public void testTC10() {
        // GIVEN
        Comparator<Object> comparator = (o1, o2) -> -1;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = 
            new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.LESS_OR_EQUAL);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        Assertions.assertEquals(true, result);
    }
}