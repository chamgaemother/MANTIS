package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MeterPlot_draw_0_4_Test {

    @Test
    @DisplayName("draw method with data value outside range")
    public void TC16_draw_with_data_value_outside_range() throws Exception {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        // Using reflection to set private fields if necessary
        Method setDataset = MeterPlot.class.getDeclaredMethod("setDataset", ValueDataset.class);
        setDataset.setAccessible(true);
        ValueDataset dataset = new DefaultValueDataset(150);
        setDataset.invoke(plot, dataset);

        Method setRange = MeterPlot.class.getDeclaredMethod("setRange", Range.class);
        setRange.setAccessible(true);
        setRange.invoke(plot, new Range(0, 100));

        Method setValueVisible = MeterPlot.class.getDeclaredMethod("setValueVisible", boolean.class);
        setValueVisible.setAccessible(true);
        setValueVisible.invoke(plot, true);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        PlotState state = new PlotState();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        
        // WHEN
        plot.draw(g2, area, new Point2D.Double(100, 100), state, info);

        // THEN
        // Verify that needle is not drawn. Assuming there is a method 'fill' called for drawing the needle.
        verify(g2, never()).fill(any(Polygon.class));
        // Verify that value label indicates out of range. Assuming 'drawValueLabel' sets a specific string.
        // This would require accessing the private fields or methods. Using reflection to verify.
        Method drawValueLabel = MeterPlot.class.getDeclaredMethod("drawValueLabel", Graphics2D.class, Rectangle2D.class);
        drawValueLabel.setAccessible(true);
        // Since we cannot directly verify the internal state, we assume that if needle is not drawn, 
        // the label indicates out of range.
    }

    @Test
    @DisplayName("draw method throws IllegalStateException for unrecognized DialShape")
    public void TC17_draw_with_unrecognized_DialShape() throws Exception {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        Method setShape = MeterPlot.class.getDeclaredMethod("setDialShape", DialShape.class);
        setShape.setAccessible(true);
        setShape.invoke(plot, (DialShape) null); // Assuming null is unrecognized

        Method setDataset = MeterPlot.class.getDeclaredMethod("setDataset", ValueDataset.class);
        setDataset.setAccessible(true);
        ValueDataset dataset = new DefaultValueDataset(50);
        setDataset.invoke(plot, dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        PlotState state = new PlotState();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN & THEN
        assertThrows(IllegalStateException.class, () -> {
            plot.draw(g2, area, new Point2D.Double(50, 50), state, info);
        });
    }

    @Test
    @DisplayName("draw method with multiple branches leading to full coverage")
    public void TC18_draw_with_multiple_branches_full_coverage() throws Exception {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        Method setDrawBorder = MeterPlot.class.getDeclaredMethod("setDrawBorder", boolean.class);
        setDrawBorder.setAccessible(true);
        setDrawBorder.invoke(plot, true);

        Method setMeterAngle = MeterPlot.class.getDeclaredMethod("setMeterAngle", int.class);
        setMeterAngle.setAccessible(true);
        setMeterAngle.invoke(plot, 200); // meterAngle > 180

        Method setShape = MeterPlot.class.getDeclaredMethod("setDialShape", DialShape.class);
        setShape.setAccessible(true);
        setShape.invoke(plot, DialShape.CIRCLE);

        Method setDataset = MeterPlot.class.getDeclaredMethod("setDataset", ValueDataset.class);
        setDataset.setAccessible(true);
        ValueDataset dataset = new DefaultValueDataset(75);
        setDataset.invoke(plot, dataset);

        Method setRange = MeterPlot.class.getDeclaredMethod("setRange", Range.class);
        setRange.setAccessible(true);
        setRange.invoke(plot, new Range(0, 100));

        Method setValueVisible = MeterPlot.class.getDeclaredMethod("setValueVisible", boolean.class);
        setValueVisible.setAccessible(true);
        setValueVisible.invoke(plot, true);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        PlotState state = new PlotState();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // WHEN
        plot.draw(g2, area, new Point2D.Double(100, 100), state, info);

        // THEN
        // Verify that all branches are executed. This is complex to verify directly.
        // Instead, verify that key methods are called indicating different branches.
        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).fill(any(Shape.class));
        verify(g2, atLeastOnce()).draw(any(Shape.class));
        // Additional verifications can be added based on the actual implementation details.
    }
}
