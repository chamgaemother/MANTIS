import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.renderer.category.GroupedStackedBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class GroupedStackedBarRendererTest {

    private GroupedStackedBarRenderer renderer;
    private Graphics2D g2;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private KeyToGroupMap map;
    private DefaultCategoryDataset dataset;

    @BeforeEach
    public void setUp() {
        renderer = new GroupedStackedBarRenderer();
        g2 = mock(Graphics2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        map = new KeyToGroupMap("Default");
        map.mapKeyToGroup("Series1", "Group1");
        map.mapKeyToGroup("Series2", "Group2");
        dataset = new DefaultCategoryDataset();
        dataset.addValue(10.0, "Series1", "Category1");
        dataset.addValue(-5.0, "Series1", "Category2");
        dataset.addValue(7.0, "Series2", "Category1");
        dataset.addValue(null, "Series2", "Category2");
        renderer.setSeriesToGroupMap(map);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisForDataset(anyInt())).thenReturn(domainAxis);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getDataset(anyInt())).thenReturn(dataset);
    }

    @Test
    public void testDrawItem_NullValue() {
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        verifyNoMoreInteractions(g2);
    }

    @Test
    public void testDrawItem_PositiveValue_NoInversion() {
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).draw(any(Shape.class)); // assuming the bar painter uses g2.draw
    }

    @Test
    public void testDrawItem_PositiveValue_WithInversion() {
        when(rangeAxis.isInverted()).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_NegativeValue_NoInversion() {
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_NegativeValue_WithInversion() {
        when(rangeAxis.isInverted()).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_HorizontalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).draw(any(Shape.class));
    }
}