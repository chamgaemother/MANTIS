package org.apache.commons.collections4;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.HashMap;
import java.util.Map;

public class MapUtils_putAll_0_3_Test {

    @Test
    @DisplayName("TC11: putAll throws IllegalArgumentException when Object[] sub-array has less than two elements")
    void TC11_putAll_throwsIllegalArgumentException_WhenSubArrayHasLessThanTwoElements() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        Object[] kv = new Object[] { "key1" };
        Object[] array = new Object[] { kv };

        // WHEN & THEN
        IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            MapUtils.putAll(map, array);
        });
        Assertions.assertTrue(exception.getMessage().contains("Invalid array element: 0"));
    }

    @Test
    @DisplayName("TC12: putAll adds key-value pairs with even number of elements in array")
    void TC12_putAll_addsKeyValuePairs_WithEvenNumberOfElements() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        String key1 = "key1";
        String value1 = "value1";
        String key2 = "key2";
        String value2 = "value2";
        Object[] array = new Object[] { key1, value1, key2, value2 };

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        Assertions.assertEquals(2, result.size(), "Map size should be 2");
        Assertions.assertEquals(value1, result.get(key1), "Value for key1 should match");
        Assertions.assertEquals(value2, result.get(key2), "Value for key2 should match");
    }

    @Test
    @DisplayName("TC13: putAll ignores the last element when array has odd number of elements")
    void TC13_putAll_ignoresLastElement_WithOddNumberOfElements() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        String key1 = "key1";
        String value1 = "value1";
        String key2 = "key2";
        Object[] array = new Object[] { key1, value1, key2 };

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        Assertions.assertEquals(1, result.size(), "Map size should be 1");
        Assertions.assertEquals(value1, result.get(key1), "Value for key1 should match");
        Assertions.assertFalse(result.containsKey(key2), "Map should not contain key2");
    }

    @Test
    @DisplayName("TC14: putAll handles array with mixed types but first element is not recognized")
    void TC14_putAll_handlesMixedTypes_FirstElementNotRecognized() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        String key1 = "key1";
        String value1 = "value1";
        String key2 = "key2";
        String value2 = "value2";
        Object[] array = new Object[] { key1, value1, key2, value2 };

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        Assertions.assertEquals(2, result.size(), "Map size should be 2");
        Assertions.assertEquals(value1, result.get(key1), "Value for key1 should match");
        Assertions.assertEquals(value2, result.get(key2), "Value for key2 should match");
    }

    @Test
    @DisplayName("TC15: putAll does not add entries when array is empty after null check")
    void TC15_putAll_doesNotAddEntries_WithEmptyArray_AfterNullCheck() {
        // GIVEN
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[0];

        // WHEN
        Map<String, String> result = MapUtils.putAll(map, array);

        // THEN
        Assertions.assertTrue(result.isEmpty(), "Map should remain empty");
    }
}