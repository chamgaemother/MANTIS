package org.apache.commons.codec.digest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.codec.Charsets;
import org.apache.commons.codec.digest.Md5Crypt;

import static org.junit.jupiter.api.Assertions.*;

public class Md5Crypt_md5Crypt_0_1_Test {

    @Test
    @DisplayName("md5Crypt with null salt uses randomly generated salt and processes normally")
    void TC01() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = null;
        String prefix = "$1$";
        
        // WHEN
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertNotNull(result, "Result should not be null");
        assertTrue(result.startsWith("$1$"), "Hash should start with $1$");
        assertTrue(result.length() >= 34, "Hash length should be at least 34 characters");
    }

    @Test
    @DisplayName("md5Crypt with valid salt starting with prefix and pattern matches")
    void TC02() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$salt1234";
        String prefix = "$1$";
        
        // WHEN
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertNotNull(result, "Result should not be null");
        assertTrue(result.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        assertEquals(34, result.length(), "Hash length should be exactly 34 characters");
    }

    @Test
    @DisplayName("md5Crypt with salt not starting with prefix but valid after prefixing")
    void TC03() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "salt1234";
        String prefix = "$1$";
        
        // WHEN
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        
        // THEN
        assertNotNull(result, "Result should not be null");
        assertTrue(result.startsWith("$1$salt1234$"), "Hash should start with '$1$salt1234$'");
        assertEquals(34, result.length(), "Hash length should be exactly 34 characters");
    }

    @Test
    @DisplayName("md5Crypt with invalid salt starting with prefix")
    void TC04() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "$1$invalid*salt";
        String prefix = "$1$";
        
        // WHEN & THEN
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        }, "Should throw IllegalArgumentException due to invalid salt");
        
        assertTrue(exception.getMessage().contains("Invalid salt value"), "Exception message should indicate invalid salt");
    }

    @Test
    @DisplayName("md5Crypt with invalid salt without prefix")
    void TC05() {
        // GIVEN
        byte[] keyBytes = "password".getBytes(Charsets.UTF_8);
        String salt = "inval!d";
        String prefix = "$1$";
        
        // WHEN & THEN
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        }, "Should throw IllegalArgumentException due to invalid salt");
        
        assertTrue(exception.getMessage().contains("Invalid salt value"), "Exception message should indicate invalid salt");
    }
}