import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.io.StringReader;
import org.apache.commons.jxpath.ri.parser.ParseException;
import org.apache.commons.jxpath.ri.parser.XPathParser;
import org.apache.commons.jxpath.ri.Compiler;

public class XPathParserTest {

    @Test
    public void testCoreFunctionName_FunctionLast() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("last()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_LAST, code);
    }

    @Test
    public void testCoreFunctionName_FunctionPosition() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("position()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_POSITION, code);
    }

    @Test
    public void testCoreFunctionName_FunctionCount() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("count()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_COUNT, code);
    }

    @Test
    public void testCoreFunctionName_FunctionId() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("id('x')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_ID, code);
    }

    @Test
    public void testCoreFunctionName_FunctionKey() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("key('keyName', 'value')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_KEY, code);
    }

    @Test
    public void testCoreFunctionName_FunctionLocalName() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("local-name()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_LOCAL_NAME, code);
    }

    @Test
    public void testCoreFunctionName_FunctionNamespaceURI() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("namespace-uri()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_NAMESPACE_URI, code);
    }

    @Test
    public void testCoreFunctionName_FunctionName() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("name()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_NAME, code);
    }

    @Test
    public void testCoreFunctionName_FunctionString() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("string()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_STRING, code);
    }

    @Test
    public void testCoreFunctionName_FunctionConcat() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("concat('a', 'b')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_CONCAT, code);
    }

    @Test
    public void testCoreFunctionName_FunctionStartsWith() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("starts-with('abc', 'a')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_STARTS_WITH, code);
    }

    @Test
    public void testCoreFunctionName_FunctionEndsWith() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("ends-with('abc', 'c')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_ENDS_WITH, code);
    }

    @Test
    public void testCoreFunctionName_FunctionContains() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("contains('abc', 'b')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_CONTAINS, code);
    }

    @Test
    public void testCoreFunctionName_FunctionSubstringBefore() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("substring-before('abc', 'b')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_SUBSTRING_BEFORE, code);
    }

    @Test
    public void testCoreFunctionName_FunctionSubstringAfter() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("substring-after('abc', 'b')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_SUBSTRING_AFTER, code);
    }

    @Test
    public void testCoreFunctionName_FunctionSubstring() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("substring('abc', 1, 2)"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_SUBSTRING, code);
    }

    @Test
    public void testCoreFunctionName_FunctionStringLength() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("string-length('abc')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_STRING_LENGTH, code);
    }

    @Test
    public void testCoreFunctionName_FunctionNormalizeSpace() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("normalize-space(' a b ')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_NORMALIZE_SPACE, code);
    }

    @Test
    public void testCoreFunctionName_FunctionTranslate() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("translate('abc', 'a', 'x')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_TRANSLATE, code);
    }

    @Test
    public void testCoreFunctionName_FunctionBoolean() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("boolean(true)"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_BOOLEAN, code);
    }

    @Test
    public void testCoreFunctionName_FunctionNot() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("not(false)"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_NOT, code);
    }

    @Test
    public void testCoreFunctionName_FunctionTrue() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("true()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_TRUE, code);
    }

    @Test
    public void testCoreFunctionName_FunctionFalse() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("false()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_FALSE, code);
    }

    @Test
    public void testCoreFunctionName_FunctionNull() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("null()"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_NULL, code);
    }

    @Test
    public void testCoreFunctionName_FunctionLang() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("lang('en')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_LANG, code);
    }

    @Test
    public void testCoreFunctionName_FunctionNumber() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("number('123')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_NUMBER, code);
    }

    @Test
    public void testCoreFunctionName_FunctionSum() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("sum((1,2,3))"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_SUM, code);
    }

    @Test
    public void testCoreFunctionName_FunctionFloor() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("floor(1.5)"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_FLOOR, code);
    }

    @Test
    public void testCoreFunctionName_FunctionCeiling() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("ceiling(1.2)"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_CEILING, code);
    }

    @Test
    public void testCoreFunctionName_FunctionRound() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("round(1.4)"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_ROUND, code);
    }

    @Test
    public void testCoreFunctionName_FunctionFormatNumber() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("format-number(1234.567, '#,###.00')"));
        parser.setCompiler(new Compiler());
        int code = parser.CoreFunctionName();
        Assertions.assertEquals(Compiler.FUNCTION_FORMAT_NUMBER, code);
    }

    @Test
    public void testCoreFunctionName_InvalidFunction() {
        XPathParser parser = new XPathParser(new StringReader("invalidFunction()"));
        parser.setCompiler(new Compiler());
        Assertions.assertThrows(ParseException.class, () -> {
            parser.CoreFunctionName();
        });
    }
}