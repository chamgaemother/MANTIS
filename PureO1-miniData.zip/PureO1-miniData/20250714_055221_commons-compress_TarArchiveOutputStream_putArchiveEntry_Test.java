package org.apache.commons.compress.archivers.tar;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class TarArchiveOutputStreamTest {

    private ByteArrayOutputStream baos;
    private TarArchiveOutputStream tarOut;
    private TarArchiveEntry mockEntry;

    @BeforeEach
    public void setUp() throws IOException {
        baos = new ByteArrayOutputStream();
        tarOut = new TarArchiveOutputStream(baos);
        mockEntry = mock(TarArchiveEntry.class);
    }

    @Test
    public void testPutArchiveEntry_NullEntry() {
        assertThrows(NullPointerException.class, () -> {
            tarOut.putArchiveEntry(null);
        });
    }

    @Test
    public void testPutArchiveEntry_GlobalPaxHeader() throws IOException {
        when(mockEntry.isGlobalPaxHeader()).thenReturn(true);
        Map<String, String> extraHeaders = new HashMap<>();
        extraHeaders.put("header1", "value1");
        when(mockEntry.getExtraPaxHeaders()).thenReturn(extraHeaders);
        when(mockEntry.getName()).thenReturn("global.pax");
        when(mockEntry.getSize()).thenReturn(20L);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        assertTrue(output.length > 0);
    }

    @Test
    public void testPutArchiveEntry_HandleLongName_POSIX() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
        String longName = "a".repeat(TarConstants.NAMELEN + 1);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(longName);
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(100L);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        assertTrue(output.length > 0);
    }

    @Test
    public void testPutArchiveEntry_HandleLongName_GNU() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR);
        String longName = "b".repeat(TarConstants.NAMELEN + 10);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(longName);
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(200L);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        assertTrue(output.length > 0);
    }

    @Test
    public void testPutArchiveEntry_HandleLongName_Truncate() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        String longName = "c".repeat(TarConstants.NAMELEN + 5);
        String truncatedName = longName.substring(0, TarConstants.NAMELEN - 1);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(longName);
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(300L);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        String outputString = new String(output, StandardCharsets.UTF_8);
        assertTrue(outputString.contains(truncatedName));
    }

    @Test
    public void testPutArchiveEntry_HandleLongName_Error() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        String longName = "d".repeat(TarConstants.NAMELEN + 2);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(longName);
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(400L);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            tarOut.putArchiveEntry(mockEntry);
        });
        assertTrue(exception.getMessage().contains("is too long"));
    }

    @Test
    public void testPutArchiveEntry_BigNumber_POSIX() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("file.txt");
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(TarConstants.MAXSIZE + 1L);
        when(mockEntry.getLongGroupId()).thenReturn(TarConstants.MAXID + 1L);
        when(mockEntry.getLastModifiedTime()).thenReturn(FileTime.from(Instant.now());
        when(mockEntry.getLongUserId()).thenReturn(TarConstants.MAXID + 2L);
        when(mockEntry.getMode()).thenReturn((long) TarConstants.MAXID + 3L);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        assertTrue(output.length > 0);
    }

    @Test
    public void testPutArchiveEntry_BigNumber_STAR() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("gnu_file.txt");
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(TarConstants.MAXSIZE + 1000L);
        when(mockEntry.getLongGroupId()).thenReturn(TarConstants.MAXID + 100L);
        when(mockEntry.getLastModifiedTime()).thenReturn(FileTime.from(Instant.now());
        when(mockEntry.getLongUserId()).thenReturn(TarConstants.MAXID + 200L);
        when(mockEntry.getMode()).thenReturn((long) TarConstants.MAXID + 300L);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        assertTrue(output.length > 0);
    }

    @Test
    public void testPutArchiveEntry_BigNumber_Error() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("error_file.txt");
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(TarConstants.MAXSIZE + 10L);

        assertThrows(IllegalArgumentException.class, () -> {
            tarOut.putArchiveEntry(mockEntry);
        });
    }

    @Test
    public void testPutArchiveEntry_NonAsciiName_PaxHeaderEnabled() throws IOException {
        tarOut.setAddPaxHeadersForNonAsciiNames(true);
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        String nonAsciiName = "文件.txt";
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(nonAsciiName);
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(500L);
        when(mockEntry.getExtraPaxHeaders()).thenReturn(new HashMap<>());

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        String outputString = new String(output, StandardCharsets.UTF_8);
        assertTrue(outputString.contains("path=" + nonAsciiName));
    }

    @Test
    public void testPutArchiveEntry_NonAsciiName_PaxHeaderDisabled() throws IOException {
        tarOut.setAddPaxHeadersForNonAsciiNames(false);
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        String nonAsciiName = "文件.txt";
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(nonAsciiName);
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(600L);
        when(mockEntry.getExtraPaxHeaders()).thenReturn(new HashMap<>());

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            tarOut.putArchiveEntry(mockEntry);
        });
        assertTrue(exception.getMessage().contains("is too long"));
    }

    @Test
    public void testPutArchiveEntry_SymbolicLink_NonAsciiLinkname_PaxHeaderEnabled() throws IOException {
        tarOut.setAddPaxHeadersForNonAsciiNames(true);
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        String nonAsciiLinkName = "链接名";
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("symlink");
        when(mockEntry.getLinkName()).thenReturn(nonAsciiLinkName);
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.isLink()).thenReturn(true);
        when(mockEntry.isSymbolicLink()).thenReturn(true);
        when(mockEntry.getSize()).thenReturn(0L);
        when(mockEntry.getExtraPaxHeaders()).thenReturn(new HashMap<>());

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        String outputString = new String(output, StandardCharsets.UTF_8);
        assertTrue(outputString.contains("linkpath=" + nonAsciiLinkName));
    }

    @Test
    public void testPutArchiveEntry_SymbolicLink_NonAsciiLinkname_PaxHeaderDisabled() throws IOException {
        tarOut.setAddPaxHeadersForNonAsciiNames(false);
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        String nonAsciiLinkName = "链接名";
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("symlink");
        when(mockEntry.getLinkName()).thenReturn(nonAsciiLinkName);
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.isLink()).thenReturn(true);
        when(mockEntry.isSymbolicLink()).thenReturn(true);
        when(mockEntry.getSize()).thenReturn(0L);
        when(mockEntry.getExtraPaxHeaders()).thenReturn(new HashMap<>());

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            tarOut.putArchiveEntry(mockEntry);
        });
        assertTrue(exception.getMessage().contains("is too long"));
    }

    @Test
    public void testPutArchiveEntry_WithExtraPaxHeaders() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("file_with_pax.txt");
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(700L);
        Map<String, String> extraHeaders = new HashMap<>();
        extraHeaders.put("key1", "value1");
        extraHeaders.put("key2", "value2");
        when(mockEntry.getExtraPaxHeaders()).thenReturn(extraHeaders);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        String outputString = new String(output, StandardCharsets.UTF_8);
        assertTrue(outputString.contains("key1=value1"));
        assertTrue(outputString.contains("key2=value2"));
    }

    @Test
    public void testPutArchiveEntry_DirectoryEntry() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("directory/");
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(true);
        when(mockEntry.getSize()).thenReturn(0L);
        when(mockEntry.getExtraPaxHeaders()).thenReturn(new HashMap<>());

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        String outputString = new String(output, StandardCharsets.UTF_8);
        assertTrue(outputString.contains("directory/"));
    }

    @Test
    public void testPutArchiveEntry_UnclosedEntry() throws IOException {
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn("unclosed_file.txt");
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(800L);
        when(mockEntry.getExtraPaxHeaders()).thenReturn(new HashMap<>());

        tarOut.putArchiveEntry(mockEntry);
        // Not closing the archive entry

        IOException exception = assertThrows(IOException.class, () -> {
            tarOut.finish();
        });
        assertTrue(exception.getMessage().contains("unclosed entries"));
    }

    @Test
    public void testPutArchiveEntry_AddPaxHeaderForNonAscii() throws IOException {
        tarOut.setAddPaxHeadersForNonAsciiNames(true);
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        String nonAsciiName = "ñandú.txt";
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(nonAsciiName);
        when(mockEntry.getLinkName()).thenReturn("");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(900L);
        when(mockEntry.getExtraPaxHeaders()).thenReturn(new HashMap<>());

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        String outputString = new String(output, StandardCharsets.UTF_8);
        assertTrue(outputString.contains("path=" + nonAsciiName));
    }

    @Test
    public void testPutArchiveEntry_ExtraPaxAndNonAscii() throws IOException {
        tarOut.setAddPaxHeadersForNonAsciiNames(true);
        tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);
        tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
        String nonAsciiName = "føø.txt";
        when(mockEntry.isGlobalPaxHeader()).thenReturn(false);
        when(mockEntry.getName()).thenReturn(nonAsciiName);
        when(mockEntry.getLinkName()).thenReturn("şylіnk");
        when(mockEntry.isDirectory()).thenReturn(false);
        when(mockEntry.getSize()).thenReturn(1000L);
        Map<String, String> extraHeaders = new HashMap<>();
        extraHeaders.put("customKey", "customValue");
        when(mockEntry.getExtraPaxHeaders()).thenReturn(extraHeaders);

        tarOut.putArchiveEntry(mockEntry);
        tarOut.closeArchiveEntry();

        byte[] output = baos.toByteArray();
        String outputString = new String(output, StandardCharsets.UTF_8);
        assertTrue(outputString.contains("path=" + nonAsciiName));
        assertTrue(outputString.contains("linkpath=şylіnk"));
        assertTrue(outputString.contains("customKey=customValue"));
    }
}