import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringUtilsTest {

    @Test
    void testIndexOfDifferenceWithNullArray() {
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
    }

    @Test
    void testIndexOfDifferenceWithEmptyArray() {
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[]{}));
    }

    @Test
    void testIndexOfDifferenceWithSingleNull() {
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[]{null}));
    }

    @Test
    void testIndexOfDifferenceWithSingleEmptyString() {
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[]{""}));
    }

    @Test
    void testIndexOfDifferenceWithAllNulls() {
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[]{null, null, null}));
    }

    @Test
    void testIndexOfDifferenceWithAllEmptyStrings() {
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[]{"", "", ""}));
    }

    @Test
    void testIndexOfDifferenceWithDifferentLengthStrings() {
        assertEquals(3, StringUtils.indexOfDifference(new CharSequence[]{"abcd", "ab", "abxyz"}));
    }

    @Test
    void testIndexOfDifferenceWithIdenticalStrings() {
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[]{"abc", "abc"}));
    }

    @Test
    void testIndexOfDifferenceWithNoInitialDifference() {
        assertEquals(3, StringUtils.indexOfDifference(new CharSequence[]{"abcde", "abxyz"}));
    }

    @Test
    void testIndexOfDifferenceWithLeadingNull() {
        assertEquals(0, StringUtils.indexOfDifference(new CharSequence[]{null, "abc"}));
    }

    @Test
    void testIndexOfDifferenceWithTrailingNull() {
        assertEquals(0, StringUtils.indexOfDifference(new CharSequence[]{"abc", null}));
    }

    @Test
    void testIndexOfDifferenceWithEmptyStringAndNonEmpty() {
        assertEquals(0, StringUtils.indexOfDifference(new CharSequence[]{"", "abc"}));
    }

    @Test
    void testIndexOfDifferenceWithPartialOverlap() {
        assertEquals(1, StringUtils.indexOfDifference(new CharSequence[]{"abc", "aXYZ"}));
    }

    @Test
    void testIndexOfDifferenceWithOneNonNull() {
        assertEquals(0, StringUtils.indexOfDifference(new CharSequence[]{null, "null"}));
    }

    @Test
    void testIndexOfDifferenceWithSimilarStrings() {
        assertEquals(7, StringUtils.indexOfDifference(new CharSequence[]{"i am a machine", "i am a robot"}));
    }
}