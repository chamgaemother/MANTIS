import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.general.DefaultKeyedValues2DDataset;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.util.TableOrder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

class StackedBarRendererTest {

    private StackedBarRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;

    @BeforeEach
    void setUp() {
        renderer = new StackedBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = new DefaultKeyedValues2DDataset();
    }

    @Test
    void testDrawItem_NullDatasetValue() {
        // Setup
        dataset = Mockito.mock(CategoryDataset.class);
        when(dataset.getValue(0, 0)).thenReturn(null);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_PositiveValue_HorizontalOrientation() {
        // Setup
        plot = Mockito.mock(CategoryPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(rangeAxis.isInverted()).thenReturn(false);

        dataset = new DefaultKeyedValues2DDataset();
        ((DefaultKeyedValues2DDataset) dataset).addValue(5.0, "Row1", "Col1");

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);

        // Assert
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItem_NegativeValue_VerticalOrientation_Inverted() {
        // Setup
        plot = Mockito.mock(CategoryPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(true);

        dataset = new DefaultKeyedValues2DDataset();
        ((DefaultKeyedValues2DDataset) dataset).addValue(-5.0, "Row1", "Col1");

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);

        // Assert
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItem_RenderAsPercentages() {
        // Setup
        renderer.setRenderAsPercentages(true);

        dataset = new DefaultKeyedValues2DDataset();
        ((DefaultKeyedValues2DDataset) dataset).addValue(50.0, "Row1", "Col1");
        ((DefaultKeyedValues2DDataset) dataset).addValue(50.0, "Row2", "Col1");

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);

        // Assert
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItem_WithVisibleSeries() {
        // Setup
        renderer.setRenderAsPercentages(false);

        dataset = new DefaultKeyedValues2DDataset();
        ((DefaultKeyedValues2DDataset) dataset).addValue(10.0, "Row1", "Col1");
        ((DefaultKeyedValues2DDataset) dataset).addValue(15.0, "Row2", "Col1");

        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0, 1});

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0, 1);

        // Assert
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItem_FirstPassWithShadow() {
        // Setup
        renderer.setShadowVisible(true);
        dataset = new DefaultKeyedValues2DDataset();
        ((DefaultKeyedValues2DDataset) dataset).addValue(10.0, "Row1", "Col1");

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // Assert
        verify(g2, atLeastOnce()).setPaint(any());
    }
}