package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Test class for GradientXYBarPainter.paintBar method.
 */
public class GradientXYBarPainter_paintBar_1_1_Test {

    @Test
    @DisplayName("paintBar with Color paint and isDrawBarOutline() = true, but both outline stroke and outline paint are null, resulting in no outline drawing")
    void TC13() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        Color color = new Color(100, 150, 200, 255);
        when(renderer.getItemPaint(0, 0)).thenReturn(color);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(0, 0)).thenReturn(null);
        when(renderer.getItemOutlinePaint(0, 0)).thenReturn(null);
        int row = 0;
        int column = 0;
        Rectangle2D bar = new Rectangle2D.Double(10, 10, 20, 20);
        RectangleEdge base = RectangleEdge.TOP;
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("paintBar with GradientPaint and isDrawBarOutline() = true, but both outline stroke and outline paint are null, resulting in no outline drawing")
    void TC14() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 10f, 10f, Color.BLUE);
        when(renderer.getItemPaint(1, 1)).thenReturn(gradientPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlineStroke(1, 1)).thenReturn(null);
        when(renderer.getItemOutlinePaint(1, 1)).thenReturn(null);
        int row = 1;
        int column = 1;
        Rectangle2D bar = new Rectangle2D.Double(20, 20, 30, 30);
        RectangleEdge base = RectangleEdge.BOTTOM;
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any());
    }
}