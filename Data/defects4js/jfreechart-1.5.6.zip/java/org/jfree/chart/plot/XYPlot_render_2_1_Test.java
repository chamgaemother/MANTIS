package org.jfree.chart.plot;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.data.xy.XYDataset;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYPlot_render_2_1_Test {

    @Test
    @DisplayName("TC04: Render method throws RuntimeException when renderer.drawItem throws an exception")
    void testRenderThrowsRuntimeException_whenRendererDrawItemThrows() {
        // Arrange
        XYPlot plot = new XYPlot();
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);

        plot.setDataset(0, mockDataset);

        ValueAxis mockDomainAxis = mock(ValueAxis.class);
        ValueAxis mockRangeAxis = mock(ValueAxis.class);
        plot.setDomainAxis(0, mockDomainAxis);
        plot.setRangeAxis(0, mockRangeAxis);

        XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
        when(mockRenderer.getPassCount()).thenReturn(1);

        XYItemRendererState mockState = mock(XYItemRendererState.class);
        when(mockRenderer.initialise(any(), any(), eq(plot), eq(mockDataset), any())).thenReturn(mockState);

        doThrow(new RuntimeException("Rendering error"))
            .when(mockRenderer).drawItem(any(), any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), any(), anyInt());

        plot.setRenderer(0, mockRenderer);

        Graphics2D mockGraphics2D = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        CrosshairState mockCrosshairState = mock(CrosshairState.class);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            plot.render(mockGraphics2D, dataArea, 0, mockInfo, mockCrosshairState);
        });
        assertEquals("Rendering error", exception.getMessage());
    }

    @Test
    @DisplayName("TC05: Render method processes visible items only with some items visible and some not")
    void testRenderProcessesVisibleItemsOnly_withPartialVisibility() {
        // Arrange
        XYPlot plot = new XYPlot();
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getSeriesCount()).thenReturn(1);
        when(mockDataset.getItemCount(0)).thenReturn(4); // 4 items

        plot.setDataset(0, mockDataset);

        ValueAxis mockDomainAxis = mock(ValueAxis.class);
        when(mockDomainAxis.getLowerBound()).thenReturn(0.0);
        when(mockDomainAxis.getUpperBound()).thenReturn(10.0);
        plot.setDomainAxis(0, mockDomainAxis);

        ValueAxis mockRangeAxis = mock(ValueAxis.class);
        when(mockRangeAxis.getLowerBound()).thenReturn(0.0);
        when(mockRangeAxis.getUpperBound()).thenReturn(10.0);
        plot.setRangeAxis(0, mockRangeAxis);

        XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
        when(mockRenderer.getPassCount()).thenReturn(1);

        XYItemRendererState mockState = mock(XYItemRendererState.class);
        when(mockState.getProcessVisibleItemsOnly()).thenReturn(true);

        when(mockRenderer.initialise(any(), any(), eq(plot), eq(mockDataset), any()))
            .thenReturn(mockState);

        // Since RendererUtils.findLiveItems is a static method, we cannot mock it without additional frameworks like PowerMockito.
        // Instead, we'll assume that the renderer will call drawItem correctly based on the mocked state.

        // Simulate that only items 0 and 2 are visible by verifying the renderer interactions.
        plot.setRenderer(0, mockRenderer);

        Graphics2D mockGraphics2D = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        CrosshairState mockCrosshairState = mock(CrosshairState.class);

        // Act
        boolean result = plot.render(mockGraphics2D, dataArea, 0, mockInfo, mockCrosshairState);

        // Assert
        assertTrue(result, "Expected render to return true");
        // Verify that drawItem is called twice (for items 0 and 2)
        verify(mockRenderer, times(2)).drawItem(any(), eq(mockState), eq(dataArea), eq(mockInfo), eq(plot),
                eq(mockDomainAxis), eq(mockRangeAxis), eq(mockDataset), eq(0), anyInt(),
                eq(mockCrosshairState), anyInt());
    }

}