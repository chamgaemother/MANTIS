package org.apache.commons.collections4;

import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class MapUtils_putAll_0_2_Test {

    // Define a simple KeyValue interface for testing purposes
    private interface KeyValue<K, V> {
        K getKey();
        V getValue();
    }

    // Implementation of the KeyValue interface
    private static class KeyValueImpl<K, V> implements KeyValue<K, V> {
        private final K key;
        private final V value;

        public KeyValueImpl(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public K getKey() {
            return key;
        }

        @Override
        public V getValue() {
            return value;
        }
    }

    @Test
    @DisplayName("putAll adds a single KeyValue to the map")
    public void TC06_putAll_singleKeyValue() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        KeyValue<Object, Object> kv = new KeyValueImpl<>("key1", "value1");
        Object[] array = new Object[] { kv };

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertEquals(1, result.size(), "Map should contain one entry");
        assertEquals("value1", result.get("key1"), "Value for 'key1' should be 'value1'");
    }

    @Test
    @DisplayName("putAll adds multiple KeyValue objects to the map")
    public void TC07_putAll_multipleKeyValues() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        KeyValue<Object, Object> kv1 = new KeyValueImpl<>("key1", "value1");
        KeyValue<Object, Object> kv2 = new KeyValueImpl<>("key2", "value2");
        Object[] array = new Object[] { kv1, kv2 };

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertEquals(2, result.size(), "Map should contain two entries");
        assertEquals("value1", result.get("key1"), "Value for 'key1' should be 'value1'");
        assertEquals("value2", result.get("key2"), "Value for 'key2' should be 'value2'");
    }

    @Test
    @DisplayName("putAll adds a single valid Object[] to the map")
    public void TC08_putAll_singleValidObjectArray() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        Object[] kv = new Object[] { "key1", "value1" };
        Object[] array = new Object[] { kv };

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertEquals(1, result.size(), "Map should contain one entry");
        assertEquals("value1", result.get("key1"), "Value for 'key1' should be 'value1'");
    }

    @Test
    @DisplayName("putAll adds multiple valid Object[] to the map")
    public void TC09_putAll_multipleValidObjectArrays() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        Object[] kv1 = new Object[] { "key1", "value1" };
        Object[] kv2 = new Object[] { "key2", "value2" };
        Object[] array = new Object[] { kv1, kv2 };

        // WHEN
        Map<Object, Object> result = MapUtils.putAll(map, array);

        // THEN
        assertEquals(2, result.size(), "Map should contain two entries");
        assertEquals("value1", result.get("key1"), "Value for 'key1' should be 'value1'");
        assertEquals("value2", result.get("key2"), "Value for 'key2' should be 'value2'");
    }

    @Test
    @DisplayName("putAll throws IllegalArgumentException when Object[] element is null")
    public void TC10_putAll_ObjectArrayElementNull() {
        // GIVEN
        Map<Object, Object> map = new HashMap<>();
        Object[] kv1 = null;
        Object[] array = new Object[] { kv1 };

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            MapUtils.putAll(map, array);
        }, "Expected putAll to throw IllegalArgumentException");
        assertTrue(exception.getMessage().contains("Invalid array element: 0"), "Exception message should contain 'Invalid array element: 0'");
    }
}