package org.jfree.chart.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;

public class RectangleAnchor_createRectangle_0_1_Test {

    @Test
    @DisplayName("createRectangle with RectangleAnchor.CENTER sets rectangle centered at (anchorX, anchorY)")
    void TC01_createRectangle_with_CENTER_anchor() {
        // GIVEN
        Size2D dimensions = new Size2D(50.0, 100.0);
        double anchorX = 100.0;
        double anchorY = 200.0;
        RectangleAnchor anchor = RectangleAnchor.CENTER;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        double expectedX = anchorX - dimensions.getWidth() / 2.0;
        double expectedY = anchorY - dimensions.getHeight() / 2.0;
        assertEquals(expectedX, result.getX(), 1e-6, "Incorrect X coordinate");
        assertEquals(expectedY, result.getY(), 1e-6, "Incorrect Y coordinate");
    }

    @Test
    @DisplayName("createRectangle with RectangleAnchor.TOP sets rectangle top-centered at (anchorX, anchorY)")
    void TC02_createRectangle_with_TOP_anchor() {
        // GIVEN
        Size2D dimensions = new Size2D(60.0, 120.0);
        double anchorX = 150.0;
        double anchorY = 250.0;
        RectangleAnchor anchor = RectangleAnchor.TOP;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        double expectedX = anchorX - dimensions.getWidth() / 2.0;
        double expectedY = anchorY;
        assertEquals(expectedX, result.getX(), 1e-6, "Incorrect X coordinate");
        assertEquals(expectedY, result.getY(), 1e-6, "Incorrect Y coordinate");
    }

    @Test
    @DisplayName("createRectangle with RectangleAnchor.BOTTOM sets rectangle bottom-centered at (anchorX, anchorY)")
    void TC03_createRectangle_with_BOTTOM_anchor() {
        // GIVEN
        Size2D dimensions = new Size2D(70.0, 140.0);
        double anchorX = 200.0;
        double anchorY = 300.0;
        RectangleAnchor anchor = RectangleAnchor.BOTTOM;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        double expectedX = anchorX - dimensions.getWidth() / 2.0;
        double expectedY = anchorY - dimensions.getHeight();
        assertEquals(expectedX, result.getX(), 1e-6, "Incorrect X coordinate");
        assertEquals(expectedY, result.getY(), 1e-6, "Incorrect Y coordinate");
    }

    @Test
    @DisplayName("createRectangle with RectangleAnchor.LEFT sets rectangle left-centered at (anchorX, anchorY)")
    void TC04_createRectangle_with_LEFT_anchor() {
        // GIVEN
        Size2D dimensions = new Size2D(80.0, 160.0);
        double anchorX = 250.0;
        double anchorY = 350.0;
        RectangleAnchor anchor = RectangleAnchor.LEFT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        double expectedX = anchorX;
        double expectedY = anchorY - dimensions.getHeight() / 2.0;
        assertEquals(expectedX, result.getX(), 1e-6, "Incorrect X coordinate");
        assertEquals(expectedY, result.getY(), 1e-6, "Incorrect Y coordinate");
    }

    @Test
    @DisplayName("createRectangle with RectangleAnchor.RIGHT sets rectangle right-centered at (anchorX, anchorY)")
    void TC05_createRectangle_with_RIGHT_anchor() {
        // GIVEN
        Size2D dimensions = new Size2D(90.0, 180.0);
        double anchorX = 300.0;
        double anchorY = 400.0;
        RectangleAnchor anchor = RectangleAnchor.RIGHT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        double expectedX = anchorX - dimensions.getWidth();
        double expectedY = anchorY - dimensions.getHeight() / 2.0;
        assertEquals(expectedX, result.getX(), 1e-6, "Incorrect X coordinate");
        assertEquals(expectedY, result.getY(), 1e-6, "Incorrect Y coordinate");
    }

}