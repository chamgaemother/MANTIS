import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.general.DatasetUtils;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DatasetUtilsTest {

    @Test
    void testIterateRangeBoundsWithNullDataset() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateRangeBounds(null, true);
        });
    }

    @Test
    void testIterateRangeBoundsWithNoDataIncludeInterval() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNull(range);
    }

    @Test
    void testIterateRangeBoundsWithNoDataExcludeInterval() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNull(range);
    }

    @Test
    void testIterateRangeBoundsWithNonIntervalData() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Row1", "Column1");
        dataset.addValue(10.0, "Row2", "Column2");

        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNotNull(range);
        assertEquals(5.0, range.getLowerBound());
        assertEquals(10.0, range.getUpperBound());
    }

    @Test
    void testIterateRangeBoundsWithIntervalData() {
        IntervalCategoryDataset dataset = new MockIntervalCategoryDataset();

        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(0.0, range.getLowerBound());
        assertEquals(20.0, range.getUpperBound());
    }

    @Test
    void testIterateRangeBoundsWithNullValues() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(null, "Row1", "Column1");
        dataset.addValue(10.0, "Row2", "Column2");

        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNotNull(range);
        assertEquals(10.0, range.getLowerBound());
        assertEquals(10.0, range.getUpperBound());
    }

    private static class MockIntervalCategoryDataset extends DefaultCategoryDataset implements IntervalCategoryDataset {
        @Override
        public Number getStartValue(int row, int column) {
            return 0.0;
        }

        @Override
        public Number getEndValue(int row, int column) {
            return 20.0;
        }
    }
}