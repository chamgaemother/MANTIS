package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_1_1_Test {

    @Test
    @DisplayName("cls is primitive (int) and toClass is assignable primitive (long) with autoboxing=false")
    public void TC06() {
        // GIVEN
        Class<?> cls = int.class;
        Class<?> toClass = long.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result, "Expected isAssignable to return true for cls=int.class and toClass=long.class with autoboxing=false");
    }

    @Test
    @DisplayName("cls is primitive (boolean) and toClass is non-assignable primitive (int) with autoboxing=false")
    public void TC07() {
        // GIVEN
        Class<?> cls = boolean.class;
        Class<?> toClass = int.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result, "Expected isAssignable to return false for cls=boolean.class and toClass=int.class with autoboxing=false");
    }

    @Test
    @DisplayName("cls is primitive (byte) and toClass is non-primitive (String) with autoboxing=true")
    public void TC08() {
        // GIVEN
        Class<?> cls = byte.class;
        Class<?> toClass = String.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result, "Expected isAssignable to return false for cls=byte.class and toClass=String.class with autoboxing=true");
    }

    @Test
    @DisplayName("cls is primitive (int) and toClass is assignable non-primitive (Number) with autoboxing=true")
    public void TC09() {
        // GIVEN
        Class<?> cls = int.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result, "Expected isAssignable to return true for cls=int.class and toClass=Number.class with autoboxing=true");
    }

    @Test
    @DisplayName("cls is primitive (short) and toClass is non-primitive (Number) with autoboxing=true")
    public void TC10() {
        // GIVEN
        Class<?> cls = short.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result, "Expected isAssignable to return true for cls=short.class and toClass=Number.class with autoboxing=true");
    }
}