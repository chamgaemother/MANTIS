package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_isCreatable_2_4_Test {

    @Test
    @DisplayName("isCreatable(\"1E10d\") returns true for double type qualifier with exponent")
    void TC56() {
        // GIVEN
        String input = "1E10d";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"1E10d\") to return true");
    }

    @Test
    @DisplayName("isCreatable(\"1.0L\") returns false for invalid type qualifier 'L' with decimal")
    void TC57() {
        // GIVEN
        String input = "1.0L";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertFalse(result, "Expected isCreatable(\"1.0L\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"0x1A3f\") returns true for lowercase hexadecimal number")
    void TC58() {
        // GIVEN
        String input = "0x1A3f";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"0x1A3f\") to return true");
    }

    @Test
    @DisplayName("isCreatable(\"#1A3F\") returns true for valid hexadecimal number with '#' prefix")
    void TC59() {
        // GIVEN
        String input = "#1A3F";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"#1A3F\") to return true");
    }

    @Test
    @DisplayName("isCreatable(\"+0x1A3F\") returns true for uppercase hexadecimal with '+' sign")
    void TC60() {
        // GIVEN
        String input = "+0x1A3F";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"+0x1A3F\") to return true");
    }
}