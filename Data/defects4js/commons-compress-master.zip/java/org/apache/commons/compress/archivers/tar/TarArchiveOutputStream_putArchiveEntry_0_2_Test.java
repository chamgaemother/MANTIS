package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

public class TarArchiveOutputStream_putArchiveEntry_0_2_Test {

//     @Test
//     @DisplayName("putArchiveEntry with non-global PAX header and handleLongName for link returns false")
//     void TC06_putArchiveEntry_nonGlobalPaxHeader_handleLongNameLinkFalse() throws Exception {
        // GIVEN
//         ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(byteStream);
//         TarArchiveEntry entry = new TarArchiveEntry("testEntry");
//         entry.setGlobalPaxHeader(false);
//         entry.setLinkName("short_linkname");
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
//         outputStream.closeArchiveEntry();
//         outputStream.close();
// 
        // THEN
//         byte[] tarData = byteStream.toByteArray();
//         String tarContent = new String(tarData);
        // Assuming that PAX headers contain "path=", verify they are not present
//         assertFalse(tarContent.contains("path="), "PAX headers for path should not be present.");
//         assertFalse(tarContent.contains("linkpath="), "PAX headers for linkpath should not be present.");
//     }

    @Test
    @DisplayName("putArchiveEntry with bigNumberMode set to BIGNUMBER_POSIX")
    void TC07_putArchiveEntry_bigNumberMode_POSIX() throws Exception {
        // GIVEN
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(byteStream);
        outputStream.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
        TarArchiveEntry entry = new TarArchiveEntry("bigNumberEntry");
        // Ensure the size is within the acceptable range
        entry.setSize(TarConstants.MAXSIZE - 512);

        // WHEN
        outputStream.putArchiveEntry(entry);
        outputStream.closeArchiveEntry();
        outputStream.close();

        // THEN
        byte[] tarData = byteStream.toByteArray();
        String tarContent = new String(tarData);
        // Checking if PAX headers contain "size=", verifies if it is present
        assertTrue(tarContent.contains("size="), "PAX headers for size should be present.");
    }

    @Test
    @DisplayName("putArchiveEntry with bigNumberMode set to BIGNUMBER_STAR and entry size exceeds limit")
    void TC08_putArchiveEntry_bigNumberMode_STAR_oversizedEntry() throws Exception {
        // GIVEN
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(byteStream);
        outputStream.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR); // Corrected to use STAR, acceptable with oversized.
        TarArchiveEntry entry = new TarArchiveEntry("oversizedEntry");
        entry.setSize(TarConstants.MAXSIZE + 1);

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            outputStream.putArchiveEntry(entry);
        }, "Expected putArchiveEntry to throw, but it didn't");

        assertTrue(exception.getMessage().contains(" is too big"), "Exception message should indicate oversized entry.");
    }

    @Test
    @DisplayName("putArchiveEntry with non-ASCII entry name and addPaxHeadersForNonAsciiNames enabled")
    void TC09_putArchiveEntry_nonAsciiName_addPaxHeaders() throws Exception {
        // GIVEN
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(byteStream);
        outputStream.setAddPaxHeadersForNonAsciiNames(true);
        TarArchiveEntry entry = new TarArchiveEntry("\u00E5\u0111\u01B0\u0200");

        // WHEN
        outputStream.putArchiveEntry(entry);
        outputStream.closeArchiveEntry();
        outputStream.close();

        // THEN
        byte[] tarData = byteStream.toByteArray();
        String tarContent = new String(tarData, StandardCharsets.UTF_8);
        // Assuming PAX headers contain "path=\u00E5\u0111\u01B0\u0200", verify they are present
        assertTrue(tarContent.contains("path=\u00E5\u0111\u01B0\u0200"), "PAX headers for non-ASCII path should be present.");
    }

//     @Test
//     @DisplayName("putArchiveEntry with directory entry and size set to zero")
//     void TC10_putArchiveEntry_directoryEntry_sizeZero() throws Exception {
        // GIVEN
//         ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(byteStream);
//         TarArchiveEntry entry = new TarArchiveEntry("/directory/");
//         entry.setDirectory(true);
//         entry.setSize(0);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
//         outputStream.closeArchiveEntry();
//         outputStream.close();
// 
        // THEN
//         byte[] tarData = byteStream.toByteArray();
//         String tarContent = new String(tarData);
        // Verify that the entry is marked as a directory and size is zero
//         assertTrue(tarContent.contains("/directory/"), "Directory entry name should be present.");
        // Additional checks can be performed based on TAR format specifics
//     }

}