package org.apache.commons.csv;

import org.apache.commons.csv.QuoteMode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CSVFormat_toString_0_1_Test {

    @Test
    @DisplayName("toString() with only delimiter set")
    void TC01_toString_with_only_delimiter_set() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',');

        // WHEN
        String result = format.toString();

        // THEN
        assertAll("Delimiter is set and others are unset",
            () -> assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be present"),
            () -> assertFalse(result.contains("Escape=<"), "Escape should be absent"),
            () -> assertFalse(result.contains("QuoteChar=<"), "QuoteChar should be absent"),
            () -> assertFalse(result.contains("QuoteMode=<"), "QuoteMode should be absent"),
            () -> assertFalse(result.contains("CommentStart=<"), "CommentStart should be absent"),
            () -> assertFalse(result.contains("NullString=<"), "NullString should be absent"),
            () -> assertFalse(result.contains("RecordSeparator=<"), "RecordSeparator should be absent"),
            () -> assertFalse(result.contains("EmptyLines:ignored"), "EmptyLines should be absent"),
            () -> assertFalse(result.contains("SurroundingSpaces:ignored"), "SurroundingSpaces should be absent"),
            () -> assertFalse(result.contains("IgnoreHeaderCase:ignored"), "IgnoreHeaderCase should be absent"),
            () -> assertTrue(result.contains("SkipHeaderRecord:false"), "SkipHeaderRecord should be false"),
            () -> assertFalse(result.contains("HeaderComments:"), "HeaderComments should be absent"),
            () -> assertFalse(result.contains("Header:"), "Header should be absent")
        );
    }

    @Test
    @DisplayName("toString() with delimiter and escape character set")
    void TC02_toString_with_delimiter_and_escape_character_set() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .withDelimiter(',')
                .withEscape('\\');

        // WHEN
        String result = format.toString();

        // THEN
        assertAll("Delimiter and Escape are set, others are unset",
            () -> assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be present"),
            () -> assertTrue(result.contains("Escape=<\\>"), "Escape should be present"),
            () -> assertFalse(result.contains("QuoteChar=<"), "QuoteChar should be absent"),
            () -> assertFalse(result.contains("QuoteMode=<"), "QuoteMode should be absent"),
            () -> assertFalse(result.contains("CommentStart=<"), "CommentStart should be absent"),
            () -> assertFalse(result.contains("NullString=<"), "NullString should be absent"),
            () -> assertFalse(result.contains("RecordSeparator=<"), "RecordSeparator should be absent"),
            () -> assertFalse(result.contains("EmptyLines:ignored"), "EmptyLines should be absent"),
            () -> assertFalse(result.contains("SurroundingSpaces:ignored"), "SurroundingSpaces should be absent"),
            () -> assertFalse(result.contains("IgnoreHeaderCase:ignored"), "IgnoreHeaderCase should be absent"),
            () -> assertTrue(result.contains("SkipHeaderRecord:false"), "SkipHeaderRecord should be false"),
            () -> assertFalse(result.contains("HeaderComments:"), "HeaderComments should be absent"),
            () -> assertFalse(result.contains("Header:"), "Header should be absent")
        );
    }

    @Test
    @DisplayName("toString() with delimiter, escape, and quote character set")
    void TC03_toString_with_delimiter_escape_and_quote_character_set() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .withDelimiter(',')
                .withEscape('\\')
                .withQuote('"');

        // WHEN
        String result = format.toString();

        // THEN
        assertAll("Delimiter, Escape, and QuoteChar are set, others are unset",
            () -> assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be present"),
            () -> assertTrue(result.contains("Escape=<\\>"), "Escape should be present"),
            () -> assertTrue(result.contains("QuoteChar=<\">"), "QuoteChar should be present"),
            () -> assertFalse(result.contains("QuoteMode=<"), "QuoteMode should be absent"),
            () -> assertFalse(result.contains("CommentStart=<"), "CommentStart should be absent"),
            () -> assertFalse(result.contains("NullString=<"), "NullString should be absent"),
            () -> assertFalse(result.contains("RecordSeparator=<"), "RecordSeparator should be absent"),
            () -> assertFalse(result.contains("EmptyLines:ignored"), "EmptyLines should be absent"),
            () -> assertFalse(result.contains("SurroundingSpaces:ignored"), "SurroundingSpaces should be absent"),
            () -> assertFalse(result.contains("IgnoreHeaderCase:ignored"), "IgnoreHeaderCase should be absent"),
            () -> assertTrue(result.contains("SkipHeaderRecord:false"), "SkipHeaderRecord should be false"),
            () -> assertFalse(result.contains("HeaderComments:"), "HeaderComments should be absent"),
            () -> assertFalse(result.contains("Header:"), "Header should be absent")
        );
    }

    @Test
    @DisplayName("toString() with all optional fields set")
    void TC04_toString_with_all_optional_fields_set() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .withDelimiter(',')
                .withEscape('\\')
                .withQuote('"')
                .withQuoteMode(QuoteMode.MINIMAL)
                .withCommentMarker('#')
                .withNullString("NULL")
                .withRecordSeparator("\n")
                .withIgnoreEmptyLines(true)
                .withIgnoreSurroundingSpaces(true)
                .withIgnoreHeaderCase(true)
                .withSkipHeaderRecord(true)
                .withHeaderComments((Object) new String[]{"Comment1", "Comment2"})
                .withHeader("Header1", "Header2");

        // WHEN
        String result = format.toString();

        // THEN
        assertAll("All optional fields are set",
            () -> assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be present"),
            () -> assertTrue(result.contains("Escape=<\\>"), "Escape should be present"),
            () -> assertTrue(result.contains("QuoteChar=<\">"), "QuoteChar should be present"),
            () -> assertTrue(result.contains("QuoteMode=<MINIMAL>"), "QuoteMode should be present"),
            () -> assertTrue(result.contains("CommentStart=<#>"), "CommentStart should be present"),
            () -> assertTrue(result.contains("NullString=<NULL>"), "NullString should be present"),
            () -> assertTrue(result.contains("RecordSeparator=<\n>"), "RecordSeparator should be present"),
            () -> assertTrue(result.contains("EmptyLines:ignored"), "EmptyLines should be ignored"),
            () -> assertTrue(result.contains("SurroundingSpaces:ignored"), "SurroundingSpaces should be ignored"),
            () -> assertTrue(result.contains("IgnoreHeaderCase:ignored"), "IgnoreHeaderCase should be ignored"),
            () -> assertTrue(result.contains("SkipHeaderRecord:true"), "SkipHeaderRecord should be true"),
            () -> assertTrue(result.contains("HeaderComments:[Comment1, Comment2]"), "HeaderComments should be present"),
            () -> assertTrue(result.contains("Header:[Header1, Header2]"), "Header should be present")
        );
    }

    @Test
    @DisplayName("toString() with quoteMode unset")
    void TC05_toString_with_quoteMode_unset() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .withDelimiter(',')
                .withEscape('\\')
                .withQuote('"')
                .withQuoteMode(null);

        // WHEN
        String result = format.toString();

        // THEN
        assertAll("QuoteMode is unset",
            () -> assertTrue(result.contains("Delimiter=<,>"), "Delimiter should be present"),
            () -> assertTrue(result.contains("Escape=<\\>"), "Escape should be present"),
            () -> assertTrue(result.contains("QuoteChar=<\">"), "QuoteChar should be present"),
            () -> assertFalse(result.contains("QuoteMode=<"), "QuoteMode should be absent"),
            () -> assertFalse(result.contains("CommentStart=<"), "CommentStart should be absent"),
            () -> assertFalse(result.contains("NullString=<"), "NullString should be absent"),
            () -> assertFalse(result.contains("RecordSeparator=<"), "RecordSeparator should be absent"),
            () -> assertFalse(result.contains("EmptyLines:ignored"), "EmptyLines should be absent"),
            () -> assertFalse(result.contains("SurroundingSpaces:ignored"), "SurroundingSpaces should be absent"),
            () -> assertFalse(result.contains("IgnoreHeaderCase:ignored"), "IgnoreHeaderCase should be absent"),
            () -> assertTrue(result.contains("SkipHeaderRecord:false"), "SkipHeaderRecord should be false"),
            () -> assertFalse(result.contains("HeaderComments:"), "HeaderComments should be absent"),
            () -> assertFalse(result.contains("Header:"), "Header should be absent")
        );
    }
}