package org.apache.commons.compress.archivers.sevenz;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class SevenZArchiveEntry_equals_0_1_Test {

    @Test
    @DisplayName("Self-comparison returns true for any instance")
    void testSelfComparison() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        assertTrue(entry1.equals(entry1));
    }

    @Test
    @DisplayName("Comparison with null object returns false")
    void testComparisonWithNull() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        assertFalse(entry1.equals(null));
    }

    @Test
    @DisplayName("Comparison with a different class object returns false")
    void testComparisonWithDifferentClass() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        Object obj = new Object();
        assertFalse(entry1.equals(obj));
    }

    @Test
    @DisplayName("Comparison between two identical SevenZArchiveEntry instances returns true")
    void testComparisonEqualInstances() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        // Assuming all fields are identical
        assertTrue(entry1.equals(entry2));
    }

    @Test
    @DisplayName("Comparison with different name returns false")
    void testComparisonDifferentName() {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry1.setName("entry1");
        entry2.setName("entry2");
        assertFalse(entry1.equals(entry2));
    }
}