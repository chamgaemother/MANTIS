package org.apache.commons.jxpath.util;
import org.apache.commons.jxpath.JXPathException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 test class for MethodLookupUtils.lookupMethod covering multiple scenarios.
 */
public class MethodLookupUtils_lookupMethod_2_1_Test {

    @Test
    @DisplayName("lookupMethod returns null when no matching methods are found after type conversion")
    public void TC24_lookupMethod_NoMatchingMethodsAfterTypeConversion() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "nonMatchingMethod";
        Object[] parameters = new Object[]{ new UnconvertibleObject(), "param1", "param2" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNull(result, "Expected lookupMethod to return null when no matching methods are found after type conversion");
    }

    @Test
    @DisplayName("lookupMethod processes parameters with multiple null values and sets z3 to false")
    public void TC25_lookupMethod_MultipleNullParameters() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "methodWithNullParams";
        Object[] parameters = new Object[]{ new ConvertibleObject(), null, "param2" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected lookupMethod to return a matching method even with null parameters");
        assertEquals("methodWithNullParams", result.getName(), "Method name should match 'methodWithNullParams'");
    }

    @Test
    @DisplayName("lookupMethod throws JXPathException when methods with same match priority are found after type conversion")
    public void TC26_lookupMethod_AmbiguousMethodCall() {
        // GIVEN
        Class<?> targetClass = AmbiguousClass.class;
        String name = "ambiguousMethod";
        Object[] parameters = new Object[]{ new ConvertibleObject(), "param1", "param2" };

        // WHEN & THEN
        JXPathException exception = assertThrows(JXPathException.class, () -> {
            MethodLookupUtils.lookupMethod(targetClass, name, parameters);
        }, "Expected JXPathException to be thrown for ambiguous method calls after type conversion");

        assertTrue(exception.getMessage().contains("Ambiguous method call"), "Exception message should indicate ambiguous method call");
    }

    @Test
    @DisplayName("lookupMethod successfully finds a method when parameters include subclass instances")
    public void TC27_lookupMethod_SubclassParameters() {
        // GIVEN
        Class<?> targetClass = SomeClass.class;
        String name = "desiredMethod";
        ConvertibleObject convertible = new SubConvertibleObject();
        Object[] parameters = new Object[]{ convertible, "param1", "param2" };

        // WHEN
        Method result = MethodLookupUtils.lookupMethod(targetClass, name, parameters);

        // THEN
        assertNotNull(result, "Expected lookupMethod to return a matching method when parameters are subclasses");
        assertEquals("desiredMethod", result.getName(), "Method name should match 'desiredMethod'");
    }

    // Helper Classes
    static class SomeClass {
        public void methodWithNullParams(Object param1, Object param2) {
            // Method implementation not required for testing
        }

        public void desiredMethod(ConvertibleObject obj, String param1, String param2) {
            // Method implementation not required for testing
        }
    }

    static class AmbiguousClass {
        public void ambiguousMethod(ConvertibleObject obj, String param1, String param2) {
            // First method implementation
        }

        public void ambiguousMethod(Number obj, String param1, String param2) {
            // Second method implementation to create ambiguity
        }
    }

    static class ConvertibleObject {
        // ConvertibleObject implementation
    }

    static class SubConvertibleObject extends ConvertibleObject {
        // Subclass of ConvertibleObject
    }

    static class UnconvertibleObject {
        // UnconvertibleObject implementation
    }
}