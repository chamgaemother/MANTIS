package com.fasterxml.jackson.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Base64Variant_decode_2_1_Test {
    // Create an instance of Base64Variant for use in tests
    private Base64Variant createVariant() {
        return new Base64Variant("TEST", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", true, '=', 76);
    }

    @Test
    @DisplayName("decodeBase64Char with a valid Base64 character 'A' (c <= 127) returns 0")
    public void TC36() {
        Base64Variant variant = createVariant();
        int result = variant.decodeBase64Char('A');
        assertEquals(0, result);
    }
    
    @Test
    @DisplayName("decodeBase64Char with a padding character '=' (c <= 127) returns -2")
    public void TC37() {
        Base64Variant variant = createVariant();
        int result = variant.decodeBase64Char('=');
        assertEquals(Base64Variant.BASE64_VALUE_PADDING, result);
    }
    
    @Test
    @DisplayName("decodeBase64Char with an invalid Base64 character '!' (c <= 127) returns -1")
    public void TC38() {
        Base64Variant variant = createVariant();
        int result = variant.decodeBase64Char('!');
        assertEquals(Base64Variant.BASE64_VALUE_INVALID, result);
    }
    
    @Test
    @DisplayName("decodeBase64Char with a non-ASCII character '€' (c > 127) returns -1")
    public void TC39() {
        Base64Variant variant = createVariant();
        int result = variant.decodeBase64Char('\u20AC'); // Corrected to use Unicode escape sequence
        assertEquals(Base64Variant.BASE64_VALUE_INVALID, result);
    }
}