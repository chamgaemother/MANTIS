package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;

public class XPathParser_NCName_2_1_Test {

    @Test
    @DisplayName("NCName() throws ParseException for undefined token kind 999")
    public void TC41() throws Exception {
        // Initialize parser with a dummy InputStream
        InputStream inputStream = new ByteArrayInputStream(new byte[0]);
        XPathParser parser = new XPathParser(inputStream);

        // Access the private field 'jj_nt' using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object token = jj_ntField.get(parser);

        // Access the 'kind' field of the Token class
        Class<?> tokenClass = token.getClass();
        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);

        // Set 'kind' to an undefined value 999
        kindField.setInt(token, 999);

        // Assert that ParseException is thrown
        assertThrows(ParseException.class, () -> {
            parser.NCName();
        });
    }

    @Test
    @DisplayName("NCName() throws ParseException for undefined token kind -100")
    public void TC42() throws Exception {
        // Initialize parser with a dummy InputStream
        InputStream inputStream = new ByteArrayInputStream(new byte[0]);
        XPathParser parser = new XPathParser(inputStream);

        // Access the private field 'jj_nt' using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object token = jj_ntField.get(parser);

        // Access the 'kind' field of the Token class
        Class<?> tokenClass = token.getClass();
        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);

        // Set 'kind' to an undefined value -100
        kindField.setInt(token, -100);

        // Assert that ParseException is thrown
        assertThrows(ParseException.class, () -> {
            parser.NCName();
        });
    }
}