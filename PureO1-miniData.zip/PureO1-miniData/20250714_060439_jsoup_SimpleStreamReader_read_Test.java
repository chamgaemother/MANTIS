package org.jsoup.internal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SimpleStreamReaderTest {

    private InputStream mockInputStream;
    private Charset charset;
    private SimpleStreamReader reader;

    @BeforeEach
    void setUp() {
        mockInputStream = mock(InputStream.class);
        charset = Charset.forName("UTF-8");
        reader = new SimpleStreamReader(mockInputStream, charset);
    }

    @Test
    void testRead_SuccessfulRead() throws IOException {
        byte[] inputBytes = "Hello, World!".getBytes(charset);
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenAnswer(invocation -> {
            byte[] buffer = invocation.getArgument(0);
            int offset = invocation.getArgument(1);
            System.arraycopy(inputBytes, 0, buffer, offset, inputBytes.length);
            return inputBytes.length;
        }).thenReturn(-1);

        char[] buffer = new char[20];
        int read = reader.read(buffer, 0, buffer.length);
        assertEquals("Hello, World!".length(), read);
        assertArrayEquals("Hello, World!".toCharArray(), java.util.Arrays.copyOf(buffer, read));
    }

    @Test
    void testRead_ReadZeroLength() throws IOException {
        char[] buffer = new char[10];
        int read = reader.read(buffer, 0, 0);
        assertEquals(0, read);
        verify(mockInputStream, never()).read(any(byte[].class), anyInt(), anyInt());
    }

    @Test
    void testRead_NullCharArray() {
        assertThrows(NullPointerException.class, () -> reader.read(null, 0, 10));
    }

    @Test
    void testRead_InvalidOffset_Negative() {
        char[] buffer = new char[10];
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buffer, -1, 5));
    }

    @Test
    void testRead_InvalidLength_Negative() {
        char[] buffer = new char[10];
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buffer, 0, -5));
    }

    @Test
    void testRead_InvalidOffsetPlusLength() {
        char[] buffer = new char[10];
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buffer, 6, 5));
    }

    @Test
    void testRead_AfterClose() throws IOException {
        reader.close();
        char[] buffer = new char[10];
        assertThrows(IllegalStateException.class, () -> reader.read(buffer, 0, 5));
    }

    @Test
    void testRead_BufferUpReturnsNegative() throws IOException {
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
        char[] buffer = new char[10];
        int read = reader.read(buffer, 0, buffer.length);
        assertEquals(-1, read);
    }

    @Test
    void testRead_BufferUpReturnsZero() throws IOException {
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
        char[] buffer = new char[10];
        IOException exception = assertThrows(IOException.class, () -> reader.read(buffer, 0, buffer.length));
        assertEquals("Underlying input stream returned zero bytes", exception.getMessage());
    }

    @Test
    void testRead_ResultOverflow() throws IOException {
        byte[] inputBytes = "Hello, World!".getBytes(charset);
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(inputBytes.length).thenReturn(-1);

        char[] buffer = new char[5]; // Small buffer to cause overflow
        int read = reader.read(buffer, 0, buffer.length);
        assertEquals(buffer.length, read);
        assertArrayEquals("Hello".toCharArray(), java.util.Arrays.copyOf(buffer, read));
    }

    @Test
    void testRead_DecodeException() throws IOException {
        CharsetDecoder mockDecoder = mock(CharsetDecoder.class);
        SimpleStreamReader customReader = new SimpleStreamReader(mockInputStream, charset) {
            @Override
            public int read(char[] charArray, int off, int len) throws IOException {
                throw new IOException("Decode error");
            }
        };
        char[] buffer = new char[10];
        IOException exception = assertThrows(IOException.class, () -> customReader.read(buffer, 0, buffer.length));
        assertEquals("Decode error", exception.getMessage());
    }

    @Test
    void testRead_ReadFullyAfterEnd() throws IOException {
        byte[] inputBytes = "Hi".getBytes(charset);
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenAnswer(invocation -> {
                    byte[] buffer = invocation.getArgument(0);
                    System.arraycopy(inputBytes, 0, buffer, invocation.getArgument(1), inputBytes.length);
                    return inputBytes.length;
                })
                .thenReturn(-1);

        char[] buffer = new char[5];
        int read = reader.read(buffer, 0, buffer.length);
        assertEquals(2, read);
        assertArrayEquals("Hi".toCharArray(), java.util.Arrays.copyOf(buffer, read));
    }

    @Test
    void testRead_ReturnsMinusOneWhenNoData() throws IOException {
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
        char[] buffer = new char[10];
        int read = reader.read(buffer, 0, buffer.length);
        assertEquals(-1, read);
    }

    @Test
    void testRead_MultipleReads() throws IOException {
        byte[] firstPart = "Hello, ".getBytes(charset);
        byte[] secondPart = "World!".getBytes(charset);
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())
        ).thenReturn(firstPart.length)
         .thenReturn(secondPart.length)
         .thenReturn(-1);

        char[] buffer = new char[10];
        int read1 = reader.read(buffer, 0, buffer.length);
        assertEquals(7, read1);
        assertArrayEquals("Hello, ".toCharArray(), java.util.Arrays.copyOf(buffer, read1));

        int read2 = reader.read(buffer, 0, buffer.length);
        assertEquals(6, read2);
        assertArrayEquals("World!".toCharArray(), java.util.Arrays.copyOf(buffer, read2));

        int read3 = reader.read(buffer, 0, buffer.length);
        assertEquals(-1, read3);
    }

    @Test
    void testRead_CharBufferPositionNotZero() throws IOException {
        byte[] inputBytes = "Hello".getBytes(charset);
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenReturn(inputBytes.length)
                .thenReturn(-1);

        char[] buffer = new char[10];
        buffer[2] = 'X'; // Set position != 0
        int read = reader.read(buffer, 2, 5);
        assertEquals(5, read);
        assertArrayEquals(new char[]{'X', 'X', 'H', 'e', 'l', 'l', 'o', '\0', '\0', '\0'}, buffer);
    }
}