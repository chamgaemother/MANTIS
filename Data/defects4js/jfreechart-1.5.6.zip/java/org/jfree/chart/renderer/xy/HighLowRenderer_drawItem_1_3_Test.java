// package org.jfree.chart.renderer.xy;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// import org.jfree.chart.ChartRenderingInfo;
// 
// import static org.mockito.Mockito.*;
// 
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.awt.geom.Line2D;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.data.Range;
// import org.jfree.data.xy.OHLCDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.ArgumentCaptor;
// 
// public class HighLowRenderer_drawItem_1_3_Test {
// 
//     @Test
//     @DisplayName("DrawItem draws close ticks when drawCloseTicks is enabled and yClose is valid")
//     public void TC11_drawItem_doesCloseTicksWhenEnabledAndValid() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 1;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(22.0, dataArea, RectangleEdge.LEFT)).thenReturn(220.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(dataset instanceof OHLCDataset).thenReturn(true);
//         when(dataset.getHighValue(series, item)).thenReturn(25.0);
//         when(dataset.getLowValue(series, item)).thenReturn(15.0);
//         when(dataset.getCloseValue(series, item)).thenReturn(22.0);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawCloseTicks(true);
//         renderer.setCloseTickPaint(Color.BLUE);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2).setPaint(Color.BLUE);
//         ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
//         verify(g2).draw(lineCaptor.capture());
//         Line2D drawnLine = lineCaptor.getValue();
//         // Verify that the close tick line was drawn correctly
//         // Since orientation is VERTICAL, the line should be horizontal in drawing
//         // from (xx, yyClose) to (xx + delta, yyClose)
//         // Assuming delta = tickLength = 2.0
//         // Therefore, from (150.0, 220.0) to (152.0, 220.0)
//         // However, tickLength may be adjusted if domain is inverted, but not in this test
//         // So we expect the line from (150.0, 220.0) to (152.0, 220.0)
//         // But checking the method:
//         // g2.draw(new Line2D.Double(xx, yyClose, xx + delta, yyClose));
//         // xx = 150.0, yyClose = 220.0, delta = 2.0
//         // So Line2D.Double(150.0, 220.0, 152.0, 220.0)
//         assert(drawnLine.getX1() == 150.0);
//         assert(drawnLine.getY1() == 220.0);
//         assert(drawnLine.getX2() == 152.0);
//         assert(drawnLine.getY2() == 220.0);
//     }
// 
//     @Test
//     @DisplayName("DrawItem does not draw close ticks when drawCloseTicks is disabled")
//     public void TC12_drawItem_doesNotDrawCloseTicksWhenDisabled() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 1;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(22.0, dataArea, RectangleEdge.LEFT)).thenReturn(220.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(dataset instanceof OHLCDataset).thenReturn(true);
//         when(dataset.getHighValue(series, item)).thenReturn(25.0);
//         when(dataset.getLowValue(series, item)).thenReturn(15.0);
//         when(dataset.getCloseValue(series, item)).thenReturn(22.0);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawCloseTicks(false);
//         renderer.setCloseTickPaint(Color.BLUE);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2, never()).setPaint(Color.BLUE);
//         verify(g2, never()).draw(any(Line2D.class));
//     }
// 
//     @Test
//     @DisplayName("DrawItem processes non-OHLCDataset and draws line when previous item exists")
//     public void TC13_drawItem_drawsLineForNonOHLCDatasetWithValidPreviousItem() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 1;
//         int pass = 0;
// 
//         when(dataset instanceof OHLCDataset).thenReturn(false);
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(dataset.getXValue(series, item - 1)).thenReturn(14.0);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
//         when(dataset.getYValue(series, item - 1)).thenReturn(18.0);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
//         when(domainAxis.valueToJava2D(14.0, dataArea, RectangleEdge.LEFT)).thenReturn(140.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(18.0, dataArea, RectangleEdge.LEFT)).thenReturn(180.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         when(dataset.getXValue(series, item - 1)).thenReturn(14.0);
//         when(dataset.getYValue(series, item - 1)).thenReturn(18.0);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
//         verify(g2).draw(lineCaptor.capture());
//         Line2D drawnLine = lineCaptor.getValue();
//         // Verify that the line was drawn between previous and current item
//         // From (140.0, 180.0) to (150.0, 200.0)
//         assert(drawnLine.getX1() == 140.0);
//         assert(drawnLine.getY1() == 180.0);
//         assert(drawnLine.getX2() == 150.0);
//         assert(drawnLine.getY2() == 200.0);
//     }
// 
//     @Test
//     @DisplayName("DrawItem does not draw line for non-OHLCDataset when previous x value is NaN")
//     public void TC14_drawItem_doesNotDrawLineForNonOHLCDatasetWithNaNPreviousX() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 1;
//         int pass = 0;
// 
//         when(dataset instanceof OHLCDataset).thenReturn(false);
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(dataset.getXValue(series, item - 1)).thenReturn(Double.NaN);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
//         when(dataset.getYValue(series, item - 1)).thenReturn(18.0);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(18.0, dataArea, RectangleEdge.LEFT)).thenReturn(180.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2, never()).draw(any(Line2D.class));
//     }
// 
//     @Test
//     @DisplayName("DrawItem processes OHLCDataset with inverted domain axis")
//     public void TC15_drawItem_OHLCDatasetWithInvertedDomainAxis() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 1;
//         int pass = 0;
// 
//         when(dataset instanceof OHLCDataset).thenReturn(true);
//         when(dataset.getHighValue(series, item)).thenReturn(25.0);
//         when(dataset.getLowValue(series, item)).thenReturn(15.0);
//         when(dataset.getOpenValue(series, item)).thenReturn(20.0);
//         when(dataset.getCloseValue(series, item)).thenReturn(22.0);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(domainAxis.isInverted()).thenReturn(true);
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
//         when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(domainAxis.valueToJava2D(25.0, dataArea, RectangleEdge.LEFT)).thenReturn(250.0);
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
//         when(domainAxis.valueToJava2D(22.0, dataArea, RectangleEdge.LEFT)).thenReturn(220.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setTickLength(3.0);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         // Verify that tick lengths are inverted based on domain axis
//         // Since domain is inverted, delta = -3.0
//         // Verify that open tick is drawn with default paint (itemPaint)
//         ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
//         verify(g2, atLeastOnce()).draw(lineCaptor.capture());
//         // Further assertions can be added based on the exact drawing logic
//         // For simplicity, verify that setPaint was called with item paint
//         verify(g2, atLeastOnce()).setPaint(any(Paint.class));
//     }
// }