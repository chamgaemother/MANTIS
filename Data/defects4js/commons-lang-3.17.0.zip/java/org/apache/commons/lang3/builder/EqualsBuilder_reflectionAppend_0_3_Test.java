package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.builder.EqualsBuilder;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EqualsBuilder_reflectionAppend_0_3_Test {

    @Test
    @DisplayName("Returns false when classes are not related")
    public void tc11_returnsFalseWhenClassesAreNotRelated() throws Exception {
        // Instantiate EqualsBuilder
        EqualsBuilder builder = new EqualsBuilder();

        // Set isEquals to true via reflection
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        isEqualsField.setBoolean(builder, true);

        // Create lhs and rhs objects of unrelated classes
        Object lhs = new String("test");
        Object rhs = new Integer(5);

        // Invoke reflectionAppend
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // Access isEquals via reflection
        boolean isEquals = isEqualsField.getBoolean(builder);

        // Assertions
        assertFalse(isEquals, "isEquals should be set to false when classes are not related");
        assertSame(builder, result, "The returned EqualsBuilder instance should be the same as the builder");
    }

    @Test
    @DisplayName("Handles bypassReflectionClasses as empty list")
    public void tc12_handlesBypassReflectionClassesEmptyList() throws Exception {
        // Instantiate EqualsBuilder
        EqualsBuilder builder = new EqualsBuilder();

        // Create lhs and rhs as instances of CustomClass
        CustomClass lhs = new CustomClass();
        CustomClass rhs = new CustomClass();

        // Invoke setBypassReflectionClasses with an empty list
        builder.setBypassReflectionClasses(new ArrayList<>());

        // Invoke reflectionAppend
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // Access isEquals via reflection
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);

        // Assertions
        assertTrue(isEquals, "isEquals should remain true when bypassReflectionClasses is empty and objects are equal");
        assertSame(builder, result, "The returned EqualsBuilder instance should be the same as the builder");
    }

    @Test
    @DisplayName("Handles bypassReflectionClasses containing both lhs and rhs classes")
    public void tc13_handlesBypassReflectionClassesContainingBothLhsAndRhsClasses() throws Exception {
        // Instantiate EqualsBuilder
        EqualsBuilder builder = new EqualsBuilder();

        // Create lhs and rhs as Strings
        String lhs = "test";
        String rhs = "test";

        // Invoke setBypassReflectionClasses with String.class
        builder.setBypassReflectionClasses(Arrays.asList(String.class));

        // Invoke reflectionAppend
        EqualsBuilder result = builder.reflectionAppend(lhs, rhs);

        // Access isEquals via reflection
        Field isEqualsField = EqualsBuilder.class.getDeclaredField("isEquals");
        isEqualsField.setAccessible(true);
        boolean isEquals = isEqualsField.getBoolean(builder);

        // Assertions
        assertTrue(isEquals, "isEquals should remain true when bypassReflectionClasses contains the classes being compared and objects are equal");
        assertSame(builder, result, "The returned EqualsBuilder instance should be the same as the builder");
    }

    // Helper class for testing
    private static class CustomClass {
        // Add fields or methods if necessary for more comprehensive tests
    }
}