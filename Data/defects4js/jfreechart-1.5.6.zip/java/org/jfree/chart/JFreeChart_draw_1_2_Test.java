package org.jfree.chart;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.ChartChangeListener;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.title.Title;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class JFreeChart_draw_1_2_Test {

    @Test
    @DisplayName("draw method with backgroundPaint set to null")
    void TC31_draw_with_backgroundPaint_set_to_null() throws Exception {
        JFreeChart chart = new JFreeChart((Plot) Mockito.mock(Plot.class));
        Field backgroundPaintField = JFreeChart.class.getDeclaredField("backgroundPaint");
        backgroundPaintField.setAccessible(true);
        backgroundPaintField.set(chart, null);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = mock(Rectangle2D.class);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        chart.draw(g2, chartArea, null, info);

        verify(g2, never()).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("draw method with backgroundImage set to null")
    void TC32_draw_with_backgroundImage_set_to_null() throws Exception {
        JFreeChart chart = new JFreeChart((Plot) Mockito.mock(Plot.class));
        Field backgroundImageField = JFreeChart.class.getDeclaredField("backgroundImage");
        backgroundImageField.setAccessible(true);
        backgroundImageField.set(chart, null);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = mock(Rectangle2D.class);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        chart.draw(g2, chartArea, null, info);

        verify(g2, never()).drawImage(any(Image.class), anyInt(), anyInt(), anyInt(), anyInt(), any());
    }

    @Test
    @DisplayName("draw method with all optional features disabled")
    void TC33_draw_with_all_optional_features_disabled() throws Exception {
        JFreeChart chart = new JFreeChart((Plot) Mockito.mock(Plot.class));
        Field elementHintingField = JFreeChart.class.getDeclaredField("elementHinting");
        elementHintingField.setAccessible(true);
        elementHintingField.set(chart, false);

        Field idField = JFreeChart.class.getDeclaredField("id");
        idField.setAccessible(true);
        idField.set(chart, null);

        Field borderVisibleField = JFreeChart.class.getDeclaredField("borderVisible");
        borderVisibleField.setAccessible(true);
        borderVisibleField.set(chart, false);

        Field titleField = JFreeChart.class.getDeclaredField("title");
        titleField.setAccessible(true);
        titleField.set(chart, null);

        Field backgroundPaintField = JFreeChart.class.getDeclaredField("backgroundPaint");
        backgroundPaintField.setAccessible(true);
        backgroundPaintField.set(chart, null);

        Field backgroundImageField = JFreeChart.class.getDeclaredField("backgroundImage");
        backgroundImageField.setAccessible(true);
        backgroundImageField.set(chart, null);

        Field subtitlesField = JFreeChart.class.getDeclaredField("subtitles");
        subtitlesField.setAccessible(true);
        subtitlesField.set(chart, new ArrayList<>());

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = mock(Rectangle2D.class);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        chart.draw(g2, chartArea, null, info);

        verify(g2, never()).setRenderingHint(eq(RenderingHints.KEY_ANTIALIASING), any());
        verify(g2, never()).setPaint(any());
        verify(g2, never()).setStroke(any());
        verify(g2, never()).draw(any(Rectangle2D.class));
        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(g2, never()).drawImage(any(Image.class), anyInt(), anyInt(), anyInt(), anyInt(), any());
    }

    @Test
    @DisplayName("draw method handling drawTitle returning null")
    void TC34_draw_with_drawTitle_returning_null() throws Exception {
        JFreeChart chart = new JFreeChart((Plot) Mockito.mock(Plot.class));
        TextTitle mockTitle = mock(TextTitle.class);
        when(mockTitle.isVisible()).thenReturn(true);

        Field titleField = JFreeChart.class.getDeclaredField("title");
        titleField.setAccessible(true);
        titleField.set(chart, mockTitle);

        JFreeChart chartSpy = Mockito.spy(chart);

        // Corrected the invocation to use the expected returns null in the spy as intended
        doAnswer(invocation -> {
            // Simply return null instead of actual logic within spy
            return null;
        }).when(chartSpy).drawTitle(any(Title.class), any(Graphics2D.class), any(Rectangle2D.class), anyBoolean());

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = mock(Rectangle2D.class);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        chartSpy.draw(g2, chartArea, null, info);

        verify(chartSpy).drawTitle(eq(mockTitle), eq(g2), eq(chartArea), anyBoolean());
        verify(entities, never()).add(any());
    }

    @Test
    @DisplayName("draw method with subtitles loop covering zero, one, and many iterations")
    void TC35_draw_with_subtitles_loop_covering_various_iterations() throws Exception {
        JFreeChart chart = new JFreeChart((Plot) Mockito.mock(Plot.class));

        List<Title> subtitles = new ArrayList<>();
        Title visibleSubtitle = mock(Title.class);
        when(visibleSubtitle.isVisible()).thenReturn(true);
        subtitles.add(visibleSubtitle);

        Title invisibleSubtitle = mock(Title.class);
        when(invisibleSubtitle.isVisible()).thenReturn(false);
        Title visibleSubtitle2 = mock(Title.class);
        when(visibleSubtitle2.isVisible()).thenReturn(true);
        subtitles.add(invisibleSubtitle);
        subtitles.add(visibleSubtitle2);

        Field subtitlesField = JFreeChart.class.getDeclaredField("subtitles");
        subtitlesField.setAccessible(true);
        subtitlesField.set(chart, subtitles);

        JFreeChart chartSpy = Mockito.spy(chart);
        doAnswer(invocation -> {
            Title subtitle = invocation.getArgument(0);
            return subtitle.isVisible();
        }).when(chartSpy).drawTitle(any(Title.class), any(Graphics2D.class), any(Rectangle2D.class), anyBoolean());

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D chartArea = mock(Rectangle2D.class);
        ChartRenderingInfo info = mock(ChartRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getEntityCollection()).thenReturn(entities);

        chartSpy.draw(g2, chartArea, null, info);

        verify(chartSpy).drawTitle(eq(visibleSubtitle), eq(g2), any(Rectangle2D.class), anyBoolean());
        verify(chartSpy).drawTitle(eq(visibleSubtitle2), eq(g2), any(Rectangle2D.class), anyBoolean());
    }
}
