package org.apache.commons.lang3;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_0_2_Test {

    @Test
    @DisplayName("cls is primitive and toClass is assignable primitive; expect true")
    void TC06_cls_primitive_assignable_toClass_primitive() {
        // GIVEN
        Class<?> cls = int.class;
        Class<?> toClass = long.class;
        boolean autoboxing = false;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertEquals(true, result);
    }

    @Test
    @DisplayName("cls is primitive and toClass is non-assignable primitive; expect false")
    void TC07_cls_primitive_nonAssignable_toClass_primitive() {
        // GIVEN
        Class<?> cls = boolean.class;
        Class<?> toClass = int.class;
        boolean autoboxing = false;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertEquals(false, result);
    }

    @Test
    @DisplayName("cls is primitive and toClass is non-primitive with autoboxing=true; expect false")
    void TC08_cls_primitive_toClass_nonPrimitive_autoboxing_true_not_assignable() {
        // GIVEN
        Class<?> cls = byte.class;
        Class<?> toClass = String.class;
        boolean autoboxing = true;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertEquals(false, result);
    }

    @Test
    @DisplayName("cls is non-primitive, toClass is primitive with autoboxing=true and assignable; expect true")
    void TC09_cls_nonPrimitive_toClass_primitive_autoboxing_true_assignable() {
        // GIVEN
        Class<?> cls = Integer.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertEquals(true, result);
    }

    @Test
    @DisplayName("cls is non-primitive, toClass is primitive with autoboxing=true but conversion returns null; expect false")
    void TC10_cls_nonPrimitive_toClass_primitive_autoboxing_true_conversion_null() {
        // GIVEN
        Class<?> cls = Void.class;
        Class<?> toClass = boolean.class;
        boolean autoboxing = true;
        
        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        
        // THEN
        assertEquals(false, result);
    }
}