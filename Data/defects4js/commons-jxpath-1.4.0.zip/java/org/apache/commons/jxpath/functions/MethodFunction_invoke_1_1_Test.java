package org.apache.commons.jxpath.functions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import org.apache.commons.jxpath.functions.MethodFunction;
import org.apache.commons.jxpath.ExpressionContext;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

public class MethodFunction_invoke_1_1_Test {

    // Helper classes for testing
    public static class ClassWithStaticMethod {
        public static String staticMethodWithParams(ExpressionContext context, String param1) {
            return "Static Method with Params: " + param1;
        }
        
        public static String staticMethodWithParams(String param1, String param2) {
            return "Static Method with Params: " + param1 + ", " + param2;
        }
    }

    public static class ClassWithNonStaticMethod {
        public String nonStaticMethodWithParams(ExpressionContext context, String param1) {
            return "Non-Static Method with Params: " + param1;
        }
        
        public String nonStaticMethodWithParams(String param1, String param2) {
            return "Non-Static Method with Params: " + param1 + param2;
        }
        
        public String nonStaticMethod() {
            return "Non-Static Method Invoked";
        }
    }
    
    @Test
    @DisplayName("invoke static method with ExpressionContext as the first parameter")
    public void TC13_invoke_static_with_ExpressionContext() throws Exception {
        // Given
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        Object[] parameters = new Object[]{"param1"};
        Method method = ClassWithStaticMethod.class.getMethod("staticMethodWithParams", ExpressionContext.class, String.class);
        MethodFunction methodFunction = new MethodFunction(method);
        
        // When
        Object result = methodFunction.invoke(context, parameters);
        
        // Then
        assertNotNull(result);
        assertEquals("Static Method with Params: param1", result);
    }
    
    @Test
    @DisplayName("invoke static method without ExpressionContext as the first parameter")
    public void TC14_invoke_static_without_ExpressionContext() throws Exception {
        // Given
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        Object[] parameters = new Object[]{"param1", "param2"};
        Method method = ClassWithStaticMethod.class.getMethod("staticMethodWithParams", String.class, String.class);
        MethodFunction methodFunction = new MethodFunction(method);
        
        // When
        Object result = methodFunction.invoke(context, parameters);
        
        // Then
        assertNotNull(result);
        assertEquals("Static Method with Params: param1, param2", result);
    }
    
    @Test
    @DisplayName("invoke non-static method with ExpressionContext as the first parameter")
    public void TC15_invoke_nonStatic_with_ExpressionContext() throws Exception {
        // Given
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        ClassWithNonStaticMethod targetObject = new ClassWithNonStaticMethod();
        Object[] parameters = new Object[]{targetObject, "param1"};
        Method method = ClassWithNonStaticMethod.class.getMethod("nonStaticMethodWithParams", ExpressionContext.class, String.class);
        MethodFunction methodFunction = new MethodFunction(method);
        
        // When
        Object result = methodFunction.invoke(context, parameters);
        
        // Then
        assertNotNull(result);
        assertEquals("Non-Static Method with Params: param1", result);
    }
    
    @Test
    @DisplayName("invoke non-static method without ExpressionContext as the first parameter")
    public void TC16_invoke_nonStatic_without_ExpressionContext() throws Exception {
        // Given
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        ClassWithNonStaticMethod targetObject = new ClassWithNonStaticMethod();
        Object[] parameters = new Object[]{targetObject, "param1", "param2"};
        Method method = ClassWithNonStaticMethod.class.getMethod("nonStaticMethodWithParams", String.class, String.class);
        MethodFunction methodFunction = new MethodFunction(method);
        
        // When
        Object result = methodFunction.invoke(context, parameters);
        
        // Then
        assertNotNull(result);
        assertEquals("Non-Static Method with Params: param1param2", result);
    }
    
    @Test
    @DisplayName("invoke method with loop executing zero times when parameters array is empty after conversion")
    public void TC17_invoke_method_with_zero_loop_iterations() throws Exception {
        // Given
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        ClassWithNonStaticMethod targetObject = new ClassWithNonStaticMethod();
        Object[] parameters = new Object[]{targetObject};
        Method method = ClassWithNonStaticMethod.class.getMethod("nonStaticMethod");
        MethodFunction methodFunction = new MethodFunction(method);
        
        // When
        Object result = methodFunction.invoke(context, parameters);
        
        // Then
        assertNotNull(result);
        assertEquals("Non-Static Method Invoked", result);
    }
}