package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_1_2_Test {

    @Test
    @DisplayName("doubleMetaphone(\"GHOST\", false) handles 'GH' after a vowel")
    public void TC46_doubleMetaphone_handles_GH_after_vowel() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GHOST";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertEquals("GFST", result, "'GH' after a vowel should be encoded as 'F'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"PHRASE\", false) handles 'PH' combination")
    public void TC47_doubleMetaphone_handles_PH_combination() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "PHRASE";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertEquals("FRS", result, "'PH' should be encoded as 'F'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"SCHMUCK\", false) handles 'SCH' combination")
    public void TC48_doubleMetaphone_handles_SCH_combination() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "SCHMUCK";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertEquals("SKMK", result, "'SCH' should be encoded as 'SK'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"DIPLOMAT\", false) handles 'DIP' combination")
    public void TC49_doubleMetaphone_handles_DIP_combination() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "DIPLOMAT";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertEquals("TPLMT", result, "'DIP' should be encoded as 'TP'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"GHANA\", false) handles 'GH' after consonant")
    public void TC50_doubleMetaphone_handles_GH_after_consonant() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GHANA";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertEquals("KNNA", result, "'GH' after consonant should be encoded as 'K'");
    }

}