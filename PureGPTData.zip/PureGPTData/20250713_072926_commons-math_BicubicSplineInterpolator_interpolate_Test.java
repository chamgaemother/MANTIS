import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolatingFunction;
import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolator;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import static org.junit.jupiter.api.Assertions.*;

public class BicubicSplineInterpolatorTest {

    @Test
    void testInterpolateValidInput() {
        double[] xval = {0, 1, 2};
        double[] yval = {0, 1, 2};
        double[][] fval = {
                {0, 1, 2},
                {1, 2, 3},
                {2, 3, 4}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertDoesNotThrow(() -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    void testInterpolateEmptyArrays() {
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        double[] xval = {};
        double[] yval = {};
        double[][] fval = {};

        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    void testInterpolateXValLengthMismatch() {
        double[] xval = {0, 1};
        double[] yval = {0, 1, 2};
        double[][] fval = {
                {0, 1},
                {1, 2},
                {2, 3}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();

        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    void testInterpolateIncorrectFValInnerLength() {
        double[] xval = {0, 1, 2};
        double[] yval = {0, 1, 2};
        double[][] fval = {
                {0, 1},
                {1, 2, 3},
                {2, 3, 4}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();

        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    void testInterpolateNonMonotonicXVal() {
        double[] xval = {1, 0, 2};
        double[] yval = {0, 1, 2};
        double[][] fval = {
                {0, 1, 2},
                {1, 2, 3},
                {2, 3, 4}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();

        assertThrows(NonMonotonicSequenceException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    void testInterpolateNonMonotonicYVal() {
        double[] xval = {0, 1, 2};
        double[] yval = {1, 0, 2};
        double[][] fval = {
                {0, 1, 2},
                {1, 2, 3},
                {2, 3, 4}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();

        assertThrows(NonMonotonicSequenceException.class, () -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    void testInterpolateMinimumInputSize() {
        double[] xval = {0, 1};
        double[] yval = {0, 1};
        double[][] fval = {
                {0, 1},
                {1, 2}
        };
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();

        assertDoesNotThrow(() -> interpolator.interpolate(xval, yval, fval));
    }

    @Test
    void testInterpolateDerivativesInitializationToggle() {
        double[] xval = {0, 1, 2};
        double[] yval = {0, 1, 2};
        double[][] fval = {
                {0, 1, 2},
                {1, 2, 3},
                {2, 3, 4}
        };
        BicubicSplineInterpolator interpolator1 = new BicubicSplineInterpolator(true);
        BicubicSplineInterpolator interpolator2 = new BicubicSplineInterpolator(false);

        assertDoesNotThrow(() -> interpolator1.interpolate(xval, yval, fval));
        assertDoesNotThrow(() -> interpolator2.interpolate(xval, yval, fval));
    }
}