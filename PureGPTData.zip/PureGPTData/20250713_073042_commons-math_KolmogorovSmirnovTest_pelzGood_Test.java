import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.apache.commons.math3.exception.TooManyIterationsException;

public class KolmogorovSmirnovTestTest {

    @Test
    public void testPelzGoodStandardInput() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(0.5, 100);
        assertTrue(result >= 0 && result <= 1, "Result should be a valid probability");
    }

    @Test
    public void testPelzGoodTinyStatistic() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(1e-10, 100);
        assertTrue(result >= 0 && result <= 1, "Result should be a valid probability");
    }

    @Test
    public void testPelzGoodLargeStatistic() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(0.9, 100);
        assertTrue(result >= 0 && result <= 1, "Result should be a valid probability");
    }

    @Test
    public void testPelzGoodLargeSampleSize() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(0.5, 1000);
        assertTrue(result >= 0 && result <= 1, "Result should be a valid probability");
    }

    @Test
    public void testPelzGoodSmallSampleSize() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(0.5, 10);
        assertTrue(result >= 0 && result <= 1, "Result should be a valid probability");
    }

    @Test
    public void testPelzGoodBoundaryZero() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(0.0, 100);
        assertTrue(result == 0.0, "Result should be 0 when statistic is 0");
    }

    @Test
    public void testPelzGoodBoundaryOne() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(1.0, 100);
        assertTrue(result == 1.0, "Result should be 1 when statistic is 1");
    }

    @Test
    public void testPelzGoodConvergenceException() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        assertThrows(TooManyIterationsException.class, () -> {
            ksTest.pelzGood(0.5, Integer.MAX_VALUE);
        }, "Should throw TooManyIterationsException for very large n");
    }
}