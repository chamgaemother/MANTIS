package org.jfree.chart.plot;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

public class ThermometerPlot_draw_2_1_Test {

    @Test
    @DisplayName("Draw method with useSubrangePaint=true and value within NORMAL subrange sets mercury color to green")
    public void TC11_draw_useSubrangePaintTrue_ValueInNormalSubrange() throws Exception {
        // GIVEN
        ValueDataset dataset = new DefaultValueDataset(25.0);
        ThermometerPlot plot = new ThermometerPlot(dataset);

        // Use reflection to set 'useSubrangePaint' to true
        Field useSubrangePaintField = ThermometerPlot.class.getDeclaredField("useSubrangePaint");
        useSubrangePaintField.setAccessible(true);
        useSubrangePaintField.set(plot, true);

        // Use reflection to set subrangeInfo for NORMAL subrange: 0-50
        Field subrangeInfoField = ThermometerPlot.class.getDeclaredField("subrangeInfo");
        subrangeInfoField.setAccessible(true);
        double[][] subrangeInfo = (double[][]) subrangeInfoField.get(plot);
        subrangeInfo[ThermometerPlot.NORMAL][ThermometerPlot.RANGE_LOW] = 0.0;
        subrangeInfo[ThermometerPlot.NORMAL][ThermometerPlot.RANGE_HIGH] = 50.0;
        subrangeInfoField.set(plot, subrangeInfo);

        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(any(Area.class));
    }

    @Test
    @DisplayName("Draw method with useSubrangePaint=true and value within WARNING subrange sets mercury color to orange")
    public void TC12_draw_useSubrangePaintTrue_ValueInWarningSubrange() throws Exception {
        // GIVEN
        ValueDataset dataset = new DefaultValueDataset(60.0);
        ThermometerPlot plot = new ThermometerPlot(dataset);

        // Use reflection to set 'useSubrangePaint' to true
        Field useSubrangePaintField = ThermometerPlot.class.getDeclaredField("useSubrangePaint");
        useSubrangePaintField.setAccessible(true);
        useSubrangePaintField.set(plot, true);

        // Use reflection to set subrangeInfo for WARNING subrange: 50-75
        Field subrangeInfoField = ThermometerPlot.class.getDeclaredField("subrangeInfo");
        subrangeInfoField.setAccessible(true);
        double[][] subrangeInfo = (double[][]) subrangeInfoField.get(plot);
        subrangeInfo[ThermometerPlot.WARNING][ThermometerPlot.RANGE_LOW] = 50.0;
        subrangeInfo[ThermometerPlot.WARNING][ThermometerPlot.RANGE_HIGH] = 75.0;
        subrangeInfoField.set(plot, subrangeInfo);

        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(g2).setPaint(Color.ORANGE);
        verify(g2).fill(any(Area.class));
    }

    @Test
    @DisplayName("Draw method with useSubrangePaint=true and value within CRITICAL subrange sets mercury color to red")
    public void TC13_draw_useSubrangePaintTrue_ValueInCriticalSubrange() throws Exception {
        // GIVEN
        ValueDataset dataset = new DefaultValueDataset(85.0);
        ThermometerPlot plot = new ThermometerPlot(dataset);

        // Use reflection to set 'useSubrangePaint' to true
        Field useSubrangePaintField = ThermometerPlot.class.getDeclaredField("useSubrangePaint");
        useSubrangePaintField.setAccessible(true);
        useSubrangePaintField.set(plot, true);

        // Use reflection to set subrangeInfo for CRITICAL subrange: 75-100
        Field subrangeInfoField = ThermometerPlot.class.getDeclaredField("subrangeInfo");
        subrangeInfoField.setAccessible(true);
        double[][] subrangeInfo = (double[][]) subrangeInfoField.get(plot);
        subrangeInfo[ThermometerPlot.CRITICAL][ThermometerPlot.RANGE_LOW] = 75.0;
        subrangeInfo[ThermometerPlot.CRITICAL][ThermometerPlot.RANGE_HIGH] = 100.0;
        subrangeInfoField.set(plot, subrangeInfo);

        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(g2).setPaint(Color.RED);
        verify(g2).fill(any(Area.class));
    }

    @Test
    @DisplayName("Draw method with useSubrangePaint=true and value outside all subranges uses default mercury paint")
    public void TC14_draw_useSubrangePaintTrue_ValueOutsideAllSubranges() throws Exception {
        // GIVEN
        ValueDataset dataset = new DefaultValueDataset(150.0);
        ThermometerPlot plot = new ThermometerPlot(dataset);

        // Use reflection to set 'useSubrangePaint' to true
        Field useSubrangePaintField = ThermometerPlot.class.getDeclaredField("useSubrangePaint");
        useSubrangePaintField.setAccessible(true);
        useSubrangePaintField.set(plot, true);

        // Ensure subrangeInfo is set to default ranges: 0-50, 50-75, 75-100
        Field subrangeInfoField = ThermometerPlot.class.getDeclaredField("subrangeInfo");
        subrangeInfoField.setAccessible(true);
        double[][] subrangeInfo = (double[][]) subrangeInfoField.get(plot);
        subrangeInfo[ThermometerPlot.NORMAL][ThermometerPlot.RANGE_LOW] = 0.0;
        subrangeInfo[ThermometerPlot.NORMAL][ThermometerPlot.RANGE_HIGH] = 50.0;
        subrangeInfo[ThermometerPlot.WARNING][ThermometerPlot.RANGE_LOW] = 50.0;
        subrangeInfo[ThermometerPlot.WARNING][ThermometerPlot.RANGE_HIGH] = 75.0;
        subrangeInfo[ThermometerPlot.CRITICAL][ThermometerPlot.RANGE_LOW] = 75.0;
        subrangeInfo[ThermometerPlot.CRITICAL][ThermometerPlot.RANGE_HIGH] = 100.0;
        subrangeInfoField.set(plot, subrangeInfo);

        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Access the default mercuryPaint via reflection
        Field mercuryPaintField = ThermometerPlot.class.getDeclaredField("mercuryPaint");
        mercuryPaintField.setAccessible(true);
        Paint defaultMercuryPaint = (Paint) mercuryPaintField.get(plot);

        verify(g2).setPaint(defaultMercuryPaint);
        verify(g2).fill(any(Area.class));
    }

    @Test
    @DisplayName("Draw method with valueLocation=NONE ensures no value label is drawn on thermometer")
    public void TC15_draw_valueLocationNone_NoValueLabelDrawn() throws Exception {
        // GIVEN
        ValueDataset dataset = new DefaultValueDataset(50.0);
        ThermometerPlot plot = new ThermometerPlot(dataset);

        // Use reflection to set 'valueLocation' to NONE
        Field valueLocationField = ThermometerPlot.class.getDeclaredField("valueLocation");
        valueLocationField.setAccessible(true);
        valueLocationField.set(plot, ThermometerPlot.NONE);

        // WHEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D anchor = mock(Point2D.class);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        plot.draw(g2, area, anchor, state, info);

        // THEN
        verify(g2, never()).drawString(anyString(), anyInt(), anyInt());
    }
}