package org.apache.commons.jxpath.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class BasicTypeConverter_convert_0_2_Test {

    @Test
    @DisplayName("Testing when useType is assignable from fromType (useType.isAssignableFrom(fromType) == true)")
    void TC06_useTypeAssignableFromFromType() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object object = new Integer(10);
        Class<?> toType = Number.class;

        // WHEN
        Object result = converter.convert(object, toType);

        // THEN
        assertSame(object, result, "The returned object should be the same as the input object.");
    }

    @Test
    @DisplayName("Testing conversion of array to array type with zero length (fromType.isArray() == true, useType.isArray() == true, length=0)")
    void TC07_arrayToArrayZeroLength() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object object = new int[0];
        Class<?> toType = int[].class;

        // WHEN
        Object result = converter.convert(object, toType);

        // THEN
        assertTrue(result.getClass().isArray(), "Result should be an array.");
        assertEquals(0, Array.getLength(result), "The array length should be 0.");
    }

    @Test
    @DisplayName("Testing conversion of array to array type with one element (useType.isArray() == true, array length=1)")
    void TC08_arrayToArraySingleElement() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object object = new String[]{"test"};
        Class<?> toType = String[].class;

        // WHEN
        Object result = converter.convert(object, toType);

        // THEN
        assertTrue(result.getClass().isArray(), "Result should be an array.");
        assertEquals(1, Array.getLength(result), "The array length should be 1.");
        assertEquals("test", Array.get(result, 0), "The first element should be 'test'.");
    }

    @Test
    @DisplayName("Testing conversion of array to array type with multiple elements (useType.isArray() == true, array length=3)")
    void TC09_arrayToArrayMultipleElements() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object object = new String[]{"one", "two", "three"};
        Class<?> toType = String[].class;

        // WHEN
        Object result = converter.convert(object, toType);

        // THEN
        assertTrue(result.getClass().isArray(), "Result should be an array.");
        assertEquals(3, Array.getLength(result), "The array length should be 3.");
        assertEquals("one", Array.get(result, 0), "First element should be 'one'.");
        assertEquals("two", Array.get(result, 1), "Second element should be 'two'.");
        assertEquals("three", Array.get(result, 2), "Third element should be 'three'.");
    }

    @Test
    @DisplayName("Testing conversion of Collection to another Collection type (useType is a Collection)")
    void TC10_collectionToCollection() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Collection<String> object = Arrays.asList("alpha", "beta", "gamma");
        Class<?> toType = List.class;

        // WHEN
        Object result = converter.convert(object, toType);

        // THEN
        assertTrue(result instanceof Collection, "Result should be an instance of Collection.");
        Collection<?> resultCollection = (Collection<?>) result;
        assertEquals(3, resultCollection.size(), "Collection should contain 3 elements.");
        assertTrue(resultCollection.containsAll(object), "Collection should contain all original elements.");
    }

}