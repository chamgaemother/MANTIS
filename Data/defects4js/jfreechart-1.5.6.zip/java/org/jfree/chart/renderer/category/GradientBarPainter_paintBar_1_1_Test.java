package org.jfree.chart.renderer.category;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.RectangularShape;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Test class for GradientBarPainter.paintBar method.
 */
public class GradientBarPainter_paintBar_1_1_Test {

    @Test
    @DisplayName("TC12: itemPaint is GradientPaint with Color1 alpha == 0, rendering is skipped")
    public void test_TC12_ItemPaintGradientPaint_Color1AlphaZero_ReturnsEarly() throws Exception {
        // Arrange
        // Create a GradientPaint with Color1 alpha == 0
        GradientPaint itemPaint = new GradientPaint(
                0f, 0f, new Color(255, 0, 0, 0),
                1f, 1f, Color.BLUE
        );

        // Mock Graphics2D and BarRenderer
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(0, 0)).thenReturn(itemPaint);

        // Create a simple RectangularShape mock
        RectangularShape bar = mock(RectangularShape.class);

        // Instantiate the painter
        GradientBarPainter painter = new GradientBarPainter();

        // Act
        painter.paintBar(g2, renderer, 0, 0, bar, RectangleEdge.TOP);

        // Assert
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("TC13: itemPaint is GradientPaint with Color1 alpha == 0, rendering is skipped for LEFT base")
    public void test_TC13_ItemPaintGradientPaint_Color1AlphaZero_LeftBase_ReturnsEarly() throws Exception {
        // Arrange
        // Create a GradientPaint with Color1 alpha == 0
        GradientPaint itemPaint = new GradientPaint(
                0f, 0f, new Color(0, 255, 0, 0),
                1f, 1f, Color.YELLOW
        );

        // Mock Graphics2D and BarRenderer
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        when(renderer.getItemPaint(1, 1)).thenReturn(itemPaint);

        // Create a simple RectangularShape mock
        RectangularShape bar = mock(RectangularShape.class);

        // Instantiate the painter
        GradientBarPainter painter = new GradientBarPainter();

        // Act
        painter.paintBar(g2, renderer, 1, 1, bar, RectangleEdge.LEFT);

        // Assert
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }
}
