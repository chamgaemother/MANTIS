// package org.jfree.chart.plot;
// 
// import java.awt.Graphics2D;
// import java.awt.geom.Point2D;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.renderer.category.CategoryItemRenderer;
// import org.jfree.data.category.CategoryDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.Mockito.anyDouble;
// import static org.mockito.Mockito.mock;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;
// 
// public class CategoryPlot_draw_2_2_Test {
//     
//     @Test
//     @DisplayName("Draw method handles iterator-count variations in domain gridlines loops")
//     void TC31_drawHandlesDomainGridlinesWithVaryingColumnCounts() throws Exception {
//         // Initialize the CategoryPlot
//         CategoryPlot plot = new CategoryPlot();
//         plot.setDomainGridlinesVisible(true);
// 
//         // Mock CategoryItemRenderer
//         CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
//         plot.setRenderer(renderer);
// 
//         // Mock Graphics2D
//         Graphics2D g2 = mock(Graphics2D.class);
// 
//         // PlotRenderingInfo (assume non-null since it's used in the method)
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getDataArea()).thenReturn(new Rectangle2D.Double(0, 0, 500, 500));
// 
//         // Test Scenario 1: Dataset with zero columns
//         CategoryDataset emptyDataset = mock(CategoryDataset.class);
//         when(emptyDataset.getColumnCount()).thenReturn(0);
//         plot.setDataset(emptyDataset);
// 
//         // Invoke method under test
//         plot.draw(g2, new Rectangle2D.Double(0, 0, 500, 500), new Point2D.Double(250, 250), null, info);
// 
//         // Verify drawDomainGridline was never called
//         verify(renderer, times(0)).drawDomainGridline(any(Graphics2D.class), any(CategoryPlot.class), anyDouble(), any(Rectangle2D.class));
// 
//         // Test Scenario 2: Dataset with one column
//         CategoryDataset singleColumnDataset = mock(CategoryDataset.class);
//         when(singleColumnDataset.getColumnCount()).thenReturn(1);
//         plot.setDataset(singleColumnDataset);
// 
//         // Invoke method under test
//         plot.draw(g2, new Rectangle2D.Double(0, 0, 500, 500), new Point2D.Double(250, 250), null, info);
// 
//         // Verify drawDomainGridline is called once
//         verify(renderer, times(1)).drawDomainGridline(any(Graphics2D.class), any(CategoryPlot.class), anyDouble(), any(Rectangle2D.class));
// 
//         // Test Scenario 3: Dataset with three columns
//         CategoryDataset multiColumnDataset = mock(CategoryDataset.class);
//         when(multiColumnDataset.getColumnCount()).thenReturn(3);
//         plot.setDataset(multiColumnDataset);
// 
//         // Invoke method under test
//         plot.draw(g2, new Rectangle2D.Double(0, 0, 500, 500), new Point2D.Double(250, 250), null, info);
// 
//         // Verify drawDomainGridline is called three times
//         verify(renderer, times(3)).drawDomainGridline(any(Graphics2D.class), any(CategoryPlot.class), anyDouble(), any(Rectangle2D.class));
//     }
// }