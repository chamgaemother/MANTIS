import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.io.IOException;
import java.io.StringReader;

import static org.junit.jupiter.api.Assertions.*;

public class JsonReaderTest {

    @Test
    void skipPrimitiveString() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("\"Hello World\""));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipPrimitiveNumber() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("12345"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipPrimitiveBooleanTrue() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("true"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipPrimitiveBooleanFalse() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("false"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipPrimitiveNull() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("null"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipEmptyArray() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipNonEmptyArray() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1, 2, 3]"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipNestedArray() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1, [2, 3], 4]"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipEmptyObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{}"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipNonEmptyObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1, \"b\":2}"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipNestedObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1, \"b\":{\"c\":2}}"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipMixedJson() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1, \"b\":[true, false, null], \"c\":\"text\"}"));
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipMultipleValues() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1, 2, 3, 4, 5]"));
        reader.beginArray();
        reader.skipValue();
        assertEquals(JsonToken.NUMBER, reader.peek());
        reader.skipValue();
        assertEquals(JsonToken.NUMBER, reader.peek());
        reader.skipValue();
        assertEquals(JsonToken.NUMBER, reader.peek());
        reader.skipValue();
        assertEquals(JsonToken.NUMBER, reader.peek());
        reader.skipValue();
        assertEquals(JsonToken.END_ARRAY, reader.peek());
    }

    @Test
    void skipValueInObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1, \"b\":2, \"c\":3}"));
        reader.beginObject();
        reader.nextName();
        reader.skipValue();
        reader.nextName();
        reader.skipValue();
        reader.nextName();
        reader.skipValue();
        reader.endObject();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipValueAtEndOfDocument() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("false"));
        reader.skipValue();
        reader.skipValue(); // Skipping beyond end
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipValueWithMalformedJson() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1, \"b\":2,,}"));
        reader.beginObject();
        reader.nextName();
        reader.skipValue();
        reader.nextName();
        Executable executable = () -> reader.skipValue();
        assertThrows(IOException.class, executable);
    }

    @Test
    void skipValueWithUnexpectedEnd() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1, 2, "));
        reader.beginArray();
        reader.skipValue();
        reader.skipValue();
        Executable executable = () -> reader.skipValue();
        assertThrows(IOException.class, executable);
    }

    @Test
    void skipValueWithSingleQuotedStrings() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{'a':'value', 'b': 'another'}"));
        reader.setLenient(true);
        reader.beginObject();
        reader.nextName();
        reader.skipValue();
        reader.nextName();
        reader.skipValue();
        reader.endObject();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipValueWithNonExecutePrefix() throws IOException {
        JsonReader reader = new JsonReader(new StringReader(")]}'\n{\"a\":1}"));
        reader.setLenient(true);
        reader.skipValue();
        assertEquals(JsonToken.BEGIN_OBJECT, reader.peek());
    }

    @Test
    void skipValueWithComments() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{/*comment*/\"a\"/*comment*/: 1 // comment\n, \"b\": 2}"));
        reader.setLenient(true);
        reader.beginObject();
        reader.nextName();
        reader.skipValue();
        reader.nextName();
        reader.skipValue();
        reader.endObject();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipValueOnClosedReader() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("null"));
        reader.close();
        Executable executable = () -> reader.skipValue();
        assertThrows(IllegalStateException.class, executable);
    }

    @Test
    void skipValueOnEmptyDocument() throws IOException {
        JsonReader reader = new JsonReader(new StringReader(""));
        Executable executable = () -> reader.skipValue();
        assertThrows(IOException.class, executable);
    }

    @Test
    void skipValueWithNumbersAfterObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1} 123"));
        reader.beginObject();
        reader.nextName();
        reader.skipValue();
        reader.endObject();
        assertEquals(JsonToken.NUMBER, reader.peek());
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipValueWithMultipleTopLevelValues() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("true false null"));
        reader.skipValue();
        assertEquals(JsonToken.BOOLEAN, reader.peek());
        reader.skipValue();
        assertEquals(JsonToken.NULL, reader.peek());
        reader.skipValue();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }

    @Test
    void skipValueWithUnquotedNamesAndStrings() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{name: unquotedValue, age: 30}"));
        reader.setLenient(true);
        reader.beginObject();
        reader.nextName();
        reader.skipValue();
        reader.nextName();
        reader.skipValue();
        reader.endObject();
        assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    }
}