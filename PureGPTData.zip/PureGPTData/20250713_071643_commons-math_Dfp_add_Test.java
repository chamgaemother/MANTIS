import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.dfp.DfpField.RoundingMode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DfpTest {

    private DfpField field;

    @BeforeEach
    void setUp() {
        // Set radix digits and rounding mode as needed for testing
        field = new DfpField(10, RoundingMode.ROUND_HALF_EVEN);
    }

    @Test
    void testAddDifferentPrecision() {
        Dfp a = new Dfp(field, 1.0);
        DfpField otherField = new DfpField(5);  // Different precision
        Dfp b = new Dfp(otherField, 1.0);
        Dfp result = a.add(b);
        assertTrue(result.isNaN());
    }

    @Test
    void testAddWithNaN() {
        Dfp a = new Dfp(field, Double.NaN);
        Dfp b = new Dfp(field, 1.0);
        Dfp result = a.add(b);
        assertTrue(result.isNaN());

        result = b.add(a);
        assertTrue(result.isNaN());
    }

    @Test
    void testAddWithInfinite() {
        Dfp a = new Dfp(field, Double.POSITIVE_INFINITY);
        Dfp b = new Dfp(field, 1.0);
        Dfp result = a.add(b);
        assertTrue(result.isInfinite());

        a = new Dfp(field, Double.NEGATIVE_INFINITY);
        result = a.add(b.negate());
        assertTrue(result.isInfinite());
    }

    @Test
    void testAddWithZeroExponents() {
        Dfp a = new Dfp(field, 0.0);
        Dfp b = new Dfp(field, 5.0);
        // Zero exponent adjustment, addition should work normally
        Dfp result = a.add(b);
        assertEquals(b, result);

        result = b.add(a);
        assertEquals(b, result);
    }

    @Test
    void testAddSameSign() {
        Dfp a = new Dfp(field, 5.0);
        Dfp b = new Dfp(field, 5.0);
        Dfp result = a.add(b);
        assertEquals(new Dfp(field, 10.0), result);
    }

    @Test
    void testAddDifferentSign() {
        Dfp a = new Dfp(field, 5.0);
        Dfp b = new Dfp(field, -3.0);
        Dfp result = a.add(b);
        assertEquals(new Dfp(field, 2.0), result);

        b = new Dfp(field, 3.0);
        a = new Dfp(field, -5.0);
        result = a.add(b);
        assertEquals(new Dfp(field, -2.0), result);
    }

    @Test
    void testAddDifferentExponents() {
        Dfp a = new Dfp(field, 1000.0);
        Dfp b = new Dfp(field, 1.0);
        Dfp result = a.add(b);
        assertEquals(new Dfp(field, 1001.0), result);
    }

    @Test
    void testEdgeCases() {
        // Overflow should propagate infinity
        Dfp a = new Dfp(field, Double.MAX_VALUE);
        Dfp b = new Dfp(field, Double.MAX_VALUE);
        Dfp result = a.add(b);
        assertTrue(result.isInfinite());

        // Addition leading to zero
        a = new Dfp(field, 5.0);
        b = new Dfp(field, -5.0);
        result = a.add(b);
        assertTrue(result.isZero());

        // Zero addition with different signs
        a = new Dfp(field, 0.0);
        b = new Dfp(field, 0.0);
        b = b.negate();
        result = a.add(b);
        assertTrue(result.isZero());
        assertEquals(1, result.sign);  // Sign should be positive per IEEE standard
    }
}