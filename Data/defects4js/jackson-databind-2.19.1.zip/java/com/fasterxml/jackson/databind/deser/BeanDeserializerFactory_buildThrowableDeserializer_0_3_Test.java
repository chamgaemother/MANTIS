package com.fasterxml.jackson.databind.deser;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
import com.fasterxml.jackson.databind.deser.std.ThrowableDeserializer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BeanDeserializerFactory_buildThrowableDeserializer_0_3_Test {

    @Test
    @DisplayName("buildThrowableDeserializer handles absence of deserializer modifiers")
    public void TC11_buildThrowableDeserializer_handlesAbsenceOfDeserializerModifiers() throws Exception {
        DeserializerFactoryConfig factoryConfig = new DeserializerFactoryConfig();
        BeanDeserializerFactory factory = new BeanDeserializerFactory(factoryConfig);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        DeserializationConfig deserializationConfig = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(deserializationConfig);
        when(deserializationConfig.getPropertyNamingStrategy()).thenReturn(null);

        JavaType javaType = mock(JavaType.class);

        BeanDescription beanDesc = mock(BeanDescription.class);
        when(beanDesc.findMethod(eq("initCause"), any(Class[].class))).thenReturn(null);
        when(beanDesc.findProperties()).thenReturn(Collections.emptyList());

        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, ctxt);
        Iterator<SettableBeanProperty> propertyIterator = Collections.emptyIterator();
        when(builder.getProperties()).thenReturn(propertyIterator);

        JsonDeserializer<?> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        assertNotNull(deserializer, "Deserializer should not be null");
    }

    @Test
    @DisplayName("buildThrowableDeserializer correctly handles Builder without 'cause' property")
    public void TC12_buildThrowableDeserializer_handlesBuilderWithoutCauseProperty() throws Exception {
        DeserializerFactoryConfig factoryConfig = new DeserializerFactoryConfig();
        BeanDeserializerFactory factory = new BeanDeserializerFactory(factoryConfig);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        DeserializationConfig deserializationConfig = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(deserializationConfig);
        when(deserializationConfig.getPropertyNamingStrategy()).thenReturn(null);

        JavaType javaType = mock(JavaType.class);

        BeanDescription beanDesc = mock(BeanDescription.class);
        when(beanDesc.findMethod(eq("initCause"), any(Class[].class))).thenReturn(null);
        when(beanDesc.findProperties()).thenReturn(Collections.emptyList());

        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, ctxt);
        Iterator<SettableBeanProperty> propertyIterator = Collections.emptyIterator();
        when(builder.getProperties()).thenReturn(propertyIterator);

        JsonDeserializer<?> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        assertNotNull(deserializer, "Deserializer should not be null");
    }

    @Test
    @DisplayName("buildThrowableDeserializer processes builder properties with multiple iterations")
    public void TC13_buildThrowableDeserializer_processesBuilderPropertiesWithMultipleIterations() throws Exception {
        DeserializerFactoryConfig factoryConfig = new DeserializerFactoryConfig();
        BeanDeserializerFactory factory = new BeanDeserializerFactory(factoryConfig);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        DeserializationConfig deserializationConfig = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(deserializationConfig);
        when(deserializationConfig.getPropertyNamingStrategy()).thenReturn(null);

        JavaType javaType = mock(JavaType.class);

        BeanDescription beanDesc = mock(BeanDescription.class);
        when(beanDesc.findMethod(eq("initCause"), any(Class[].class))).thenReturn(null);

        BeanPropertyDefinition prop1 = mock(BeanPropertyDefinition.class);
        when(prop1.getName()).thenReturn("property1");
        when(prop1.hasSetter()).thenReturn(true);
        AnnotatedMethod setter1 = mock(AnnotatedMethod.class);
        when(prop1.getSetter()).thenReturn(setter1);
        BeanPropertyDefinition prop2 = mock(BeanPropertyDefinition.class);
        when(prop2.getName()).thenReturn("setCause");
        when(prop2.hasSetter()).thenReturn(true);
        AnnotatedMethod setter2 = mock(AnnotatedMethod.class);
        when(prop2.getSetter()).thenReturn(setter2);
        when(beanDesc.findProperties()).thenReturn(Arrays.asList(prop1, prop2));

        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, ctxt);

        SettableBeanProperty propA = mock(SettableBeanProperty.class);
        AnnotatedMember memberA = mock(AnnotatedMember.class);
        when(propA.getMember()).thenReturn(memberA);
        when(memberA.getName()).thenReturn("property1");

        SettableBeanProperty propB = mock(SettableBeanProperty.class);
        AnnotatedMember memberB = mock(AnnotatedMember.class);
        when(propB.getMember()).thenReturn(memberB);
        when(memberB.getName()).thenReturn("setCause");

        Iterator<SettableBeanProperty> propertyIterator = Arrays.asList(propA, propB).iterator();
        when(builder.getProperties()).thenReturn(propertyIterator);

        JsonDeserializer<?> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        assertNotNull(deserializer, "Deserializer should not be null");
    }

    @Test
    @DisplayName("buildThrowableDeserializer throws exception when no mutator is available")
    public void TC14_buildThrowableDeserializer_throwsExceptionWhenNoMutatorAvailable() throws Exception {
        DeserializerFactoryConfig factoryConfig = new DeserializerFactoryConfig();
        BeanDeserializerFactory factory = new BeanDeserializerFactory(factoryConfig);

        DeserializationContext ctxt = mock(DeserializationContext.class);
        DeserializationConfig deserializationConfig = mock(DeserializationConfig.class);
        when(ctxt.getConfig()).thenReturn(deserializationConfig);
        when(deserializationConfig.getPropertyNamingStrategy()).thenReturn(null);

        JavaType javaType = mock(JavaType.class);

        BeanDescription beanDesc = mock(BeanDescription.class);
        when(beanDesc.findMethod(eq("initCause"), any(Class[].class))).thenReturn(null);

        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getName()).thenReturn("propertyWithoutMutator");
        when(prop.hasSetter()).thenReturn(false);
        when(prop.hasField()).thenReturn(false);
        when(prop.hasGetter()).thenReturn(true);
        AnnotatedMethod getter = mock(AnnotatedMethod.class);
        when(prop.getGetter()).thenReturn(getter);
        when(beanDesc.findProperties()).thenReturn(Arrays.asList(prop));

        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, ctxt);
        Iterator<SettableBeanProperty> propertyIterator = Collections.emptyIterator();
        when(builder.getProperties()).thenReturn(propertyIterator);

        JsonDeserializer<?> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        verify(ctxt).reportBadPropertyDefinition(eq(beanDesc), eq(prop), anyString(), any());

        assertNotNull(deserializer, "Deserializer should not be null");
    }
}