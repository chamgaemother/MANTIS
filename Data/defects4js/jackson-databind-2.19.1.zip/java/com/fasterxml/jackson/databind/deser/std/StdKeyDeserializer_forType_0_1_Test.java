package com.fasterxml.jackson.databind.deser.std;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer;
import com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer.StringKD;
import java.util.UUID;
import java.lang.reflect.Field;
import java.io.Serializable;

public class StdKeyDeserializer_forType_0_1_Test {

    @Test
    @DisplayName("forType(String.class) returns StringKD instance")
    void TC01() {
        // GIVEN
        Class<?> raw = String.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertInstanceOf(StringKD.class, result);
    }

    @Test
    @DisplayName("forType(Object.class) returns StringKD instance")
    void TC02() {
        // GIVEN
        Class<?> raw = Object.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertInstanceOf(StringKD.class, result);
    }

    @Test
    @DisplayName("forType(CharSequence.class) returns StringKD instance")
    void TC03() {
        // GIVEN
        Class<?> raw = CharSequence.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertInstanceOf(StringKD.class, result);
    }

    @Test
    @DisplayName("forType(Serializable.class) returns StringKD instance")
    void TC04() {
        // GIVEN
        Class<?> raw = Serializable.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertInstanceOf(StringKD.class, result);
    }

    @Test
    @DisplayName("forType(UUID.class) returns StdKeyDeserializer with TYPE_UUID")
    void TC05() throws Exception {
        // GIVEN
        Class<?> raw = UUID.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access 'kind' field via reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        int kind = (int) kindField.get(result);

        // Access 'raw' field via reflection
        Field rawField = StdKeyDeserializer.class.getDeclaredField("raw");
        rawField.setAccessible(true);
        Class<?> resultRaw = (Class<?>) rawField.get(result);

        // Assertions
        assertAll(
            () -> assertEquals(StdKeyDeserializer.TYPE_UUID, kind),
            () -> assertEquals(UUID.class, resultRaw)
        );
    }
}