package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.codec.language.DoubleMetaphone;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_5_Test {

    @Test
    @DisplayName("doubleMetaphone(\"XENON\", false) handles 'X' at start")
    void TC21_doubleMetaphone_X_at_start() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "XENON";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertTrue(result.startsWith("S") || result.startsWith("KS"), "'X' at start is encoded as 'S' or 'KS'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"ZEBRA\", false) handles 'Z' at start")
    void TC22_doubleMetaphone_Z_at_start() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "ZEBRA";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertTrue(result.startsWith("S") || result.startsWith("TS"), "'Z' is encoded as 'S' or 'TS'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"CIVIC\", false) handles 'CI'")
    void TC23_doubleMetaphone_CI_combination() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "CIVIC";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertTrue(result.contains("S"), "'CI' is encoded as 'S'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"CAT\", false) handles simple 'C'")
    void TC24_doubleMetaphone_single_C() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "CAT";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        assertTrue(result.startsWith("K"), "'C' is encoded as 'K'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"DANGER\", false) handles 'G' before 'E'")
    void TC25_doubleMetaphone_G_before_E() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "DANGER";

        // WHEN
        String result = encoder.doubleMetaphone(input, false);

        // THEN
        // Assuming 'G' before 'E' is encoded as 'K' or 'J'
        assertTrue(result.contains("K") || result.contains("J"), "'G' before 'E' is encoded correctly");
    }
}