package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_1_7_Test {

    // Custom classes for testing
    static class CustomClass {}

    static class CustomWrapper {}

    @Test
    @DisplayName("cls is wrapper (Short) and toClass is primitive (int) with autoboxing=true")
    void TC36() {
        Class<?> cls = Short.class;
        Class<?> toClass = int.class;
        boolean autoboxing = true;
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Byte) and toClass is non-assignable primitive (boolean) with autoboxing=true")
    void TC37() {
        Class<?> cls = Byte.class;
        Class<?> toClass = boolean.class;
        boolean autoboxing = true;
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is non-primitive (CustomClass) and toClass is CustomWrapper class with autoboxing=true")
    void TC38() {
        Class<?> cls = CustomClass.class;
        Class<?> toClass = CustomWrapper.class;
        boolean autoboxing = true;
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is wrapper (Integer) and toClass is Number with autoboxing=true")
    void TC39() {
        Class<?> cls = Integer.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Integer) and toClass is non-assignable (String) with autoboxing=true")
    void TC40() {
        Class<?> cls = Integer.class;
        Class<?> toClass = String.class;
        boolean autoboxing = true;
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);
        assertFalse(result);
    }
}