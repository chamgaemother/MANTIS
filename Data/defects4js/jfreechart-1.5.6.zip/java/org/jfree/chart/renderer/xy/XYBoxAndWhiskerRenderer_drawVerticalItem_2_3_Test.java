package org.jfree.chart.renderer.xy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.mockito.Mockito;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.renderer.xy.XYBoxAndWhiskerRenderer;
import org.jfree.chart.ui.RectangleEdge;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_2_3_Test {

    @Test
    @DisplayName("drawVerticalItem with exception thrown by addEntity")
    public void TC36_drawVerticalItem_withExceptionThrownByAddEntity() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = Mockito.spy(new XYBoxAndWhiskerRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(dataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
        when(dataset.getMeanValue(0, 0)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        
        // Make addEntity throw RuntimeException using reflection
        Method addEntityMethod = XYBoxAndWhiskerRenderer.class.getDeclaredMethod("addEntity", EntityCollection.class, Rectangle2D.class, XYDataset.class, int.class, int.class, double.class, double.class);
        addEntityMethod.setAccessible(true);
        doThrow(new RuntimeException("Test addEntity exception")).when(renderer).addEntity(any(EntityCollection.class), any(Rectangle2D.class), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble());

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        });
    }

    @Test
    @DisplayName("drawVerticalItem with yQ1Median > yQ3Median, ensuring box is drawn correctly")
    public void TC37_drawVerticalItem_yQ1MedianGreaterThanYQ3Median() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(dataset.getOutliers(0, 0)).thenReturn(Collections.emptyList());
        when(dataset.getQ1Value(0, 0)).thenReturn(10.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(5.0); // Q1 > Q3
        when(dataset.getX(0, 0)).thenReturn(10.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(5.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        // Assert
        // Verify that fill and draw are called on Rectangle2D.Double with inverted dimensions
        verify(g2, times(1)).fill(any(Rectangle2D.Double.class));
        verify(g2, times(1)).draw(any(Rectangle2D.Double.class));
    }

    @Test
    @DisplayName("drawVerticalItem with overlapping outliers requiring multiple ellipses")
    public void TC38_drawVerticalItem_overlappingOutliers() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = Mockito.spy(new XYBoxAndWhiskerRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(15.0, 15.0));
        when(dataset.getMaxOutlier(0, 0)).thenReturn(80.0);
        when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
        when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(50.0);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        // Assert
        // Verify that drawEllipse is called twice for overlapping outliers
        verify(renderer, times(2)).drawEllipse(any(Point2D.class), anyDouble(), eq(g2));
    }

    @Test
    @DisplayName("drawVerticalItem with exception during outliers processing loop")
    public void TC39_drawVerticalItem_exceptionDuringOutliersProcessingLoop() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = Mockito.spy(new XYBoxAndWhiskerRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(25.0));
        when(dataset.getMaxOutlier(0, 0)).thenReturn(80.0);
        when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
        when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(70.0);

        // Make addEntity throw RuntimeException during loop processing
        Method addEntityMethod = XYBoxAndWhiskerRenderer.class.getDeclaredMethod("addEntity", EntityCollection.class, Rectangle2D.class, XYDataset.class, int.class, int.class, double.class, double.class);
        addEntityMethod.setAccessible(true);
        doThrow(new RuntimeException("Loop processing exception")).when(renderer).addEntity(any(EntityCollection.class), any(Rectangle2D.class), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble());

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
        });
    }

    @Test
    @DisplayName("drawVerticalItem with loop iterating multiple times and processing multiple outliers")
    public void TC40_drawVerticalItem_loopWithMultipleOutliers() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(25.0, 30.0, 35.0));
        when(dataset.getMaxOutlier(0, 0)).thenReturn(30.0);
        when(dataset.getMinOutlier(0, 0)).thenReturn(20.0);
        when(dataset.getQ1Value(0, 0)).thenReturn(30.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(70.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(50.0);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        // Assert
        // Verify that drawEllipse is called three times for multiple outliers
        verify(g2, times(3)).draw(any(Ellipse2D.Double.class));
    }
}