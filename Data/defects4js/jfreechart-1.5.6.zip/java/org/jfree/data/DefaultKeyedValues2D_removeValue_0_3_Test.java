package org.jfree.data;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DefaultKeyedValues2D_removeValue_0_3_Test {

    @Test
    @DisplayName("Attempt to remove a value when rows and columns are initially empty")
    void TC11_removeValue_onEmptyDataStructure() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();

        // WHEN
        data.removeValue("RowX", "ColX");

        // THEN
        assertEquals(0, data.getRowCount(), "Row count should remain 0");
        assertEquals(0, data.getColumnCount(), "Column count should remain 0");
    }

    @Test
    @DisplayName("Attempt to remove a value with null rowKey, expecting IllegalArgumentException")
    void TC12_removeValue_withNullRowKey() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            data.removeValue(null, "Col1");
        }, "Removing with null rowKey should throw IllegalArgumentException");
    }

    @Test
    @DisplayName("Attempt to remove a value with null columnKey, expecting IllegalArgumentException")
    void TC13_removeValue_withNullColumnKey() {
        // GIVEN
        DefaultKeyedValues2D data = new DefaultKeyedValues2D();

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            data.removeValue("Row1", null);
        }, "Removing with null columnKey should throw IllegalArgumentException");
    }
}