package org.apache.commons.compress.harmony.pack200;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClassBands_removeCurrentClass_0_1_Test {

    // Helper method to set private fields using reflection
    private void setPrivateField(Object instance, String fieldName, Object value) throws Exception {
        Field field = instance.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(instance, value);
    }

    @Test
    @DisplayName("Class with flag bit 17 set executes the conditional block and removes item from classSourceFile")
    void testRemoveCurrentClass_TC01() throws Exception {
        // GIVEN
        List<CPUTF8> classSourceFile = new ArrayList<>();
        classSourceFile.add(new CPUTF8("item1"));
        classSourceFile.add(new CPUTF8("item2"));

        long[] class_flags = new long[1];
        class_flags[0] = 1 << 17; // Set 17th bit
        int index = 0;

        // ClassBands object with segmentation adjusted (using null as placeholder for real objects)
        ClassBands classBands = new ClassBands(null, 1, 0, false);

        // Use reflection to set the private fields
        setPrivateField(classBands, "class_flags", class_flags);
        setPrivateField(classBands, "index", index);
        setPrivateField(classBands, "classSourceFile", classSourceFile);

        // WHEN
        classBands.removeCurrentClass();

        // THEN
        assertEquals(1, classSourceFile.size());
        assertEquals("item1", classSourceFile.get(0).toString());
    }

    @Test
    @DisplayName("Class with flag bit 18 set removes items from classEnclosingMethodClass and classEnclosingMethodDesc")
    void testRemoveCurrentClass_TC02() throws Exception {
        // GIVEN
        List<ConstantPoolEntry> classEnclosingMethodClass = new ArrayList<>();
        classEnclosingMethodClass.add(new CPClass("enclosingClass1"));
        classEnclosingMethodClass.add(new CPClass("enclosingClass2"));

        List<ConstantPoolEntry> classEnclosingMethodDesc = new ArrayList<>();
        classEnclosingMethodDesc.add(new CPNameAndType("desc1", "desc"));
        classEnclosingMethodDesc.add(new CPNameAndType("desc2", "desc"));

        long[] class_flags = new long[1];
        class_flags[0] = 1 << 18; // Set 18th bit
        int index = 0;

        // ClassBands object with segmentation adjusted (using null as placeholder for real objects)
        ClassBands classBands = new ClassBands(null, 1, 0, false);

        // Use reflection to set the private fields
        setPrivateField(classBands, "class_flags", class_flags);
        setPrivateField(classBands, "index", index);
        setPrivateField(classBands, "classEnclosingMethodClass", classEnclosingMethodClass);
        setPrivateField(classBands, "classEnclosingMethodDesc", classEnclosingMethodDesc);

        // WHEN
        classBands.removeCurrentClass();

        // THEN
        assertEquals(1, classEnclosingMethodClass.size());
        assertEquals("enclosingClass1", classEnclosingMethodClass.get(0).toString());
        assertEquals(1, classEnclosingMethodDesc.size());
        assertEquals("desc1", classEnclosingMethodDesc.get(0).toString());
    }

    @Test
    @DisplayName("Class with flag bit 19 set removes item from classSignature")
    void testRemoveCurrentClass_TC03() throws Exception {
        // GIVEN
        List<CPSignature> classSignature = new ArrayList<>();
        classSignature.add(new CPSignature("signature1"));
        classSignature.add(new CPSignature("signature2"));

        long[] class_flags = new long[1];
        class_flags[0] = 1 << 19; // Set 19th bit
        int index = 0;

        // ClassBands object with segmentation adjusted (using null as placeholder for real objects)
        ClassBands classBands = new ClassBands(null, 1, 0, false);

        // Use reflection to set the private fields
        setPrivateField(classBands, "class_flags", class_flags);
        setPrivateField(classBands, "index", index);
        setPrivateField(classBands, "classSignature", classSignature);

        // WHEN
        classBands.removeCurrentClass();

        // THEN
        assertEquals(1, classSignature.size());
        assertEquals("signature1", classSignature.get(0).toString());
    }

    @Test
    @DisplayName("Class with flag bit 21 set removes the latest item from class_RVA_bands")
    void testRemoveCurrentClass_TC04() throws Exception {
        // GIVEN
        MetadataBandGroup class_RVA_bands = new MetadataBandGroup("classRVA", MetadataBandGroup.CONTEXT_CLASS, null, null, 1);
        class_RVA_bands.addEntry(new MetadataBandGroup.Entry());
        class_RVA_bands.addEntry(new MetadataBandGroup.Entry());

        long[] class_flags = new long[1];
        class_flags[0] = 1 << 21; // Set 21st bit
        int index = 0;

        // ClassBands object with segmentation adjusted (using null as placeholder for realism)
        ClassBands classBands = new ClassBands(null, 1, 0, false);

        // Use reflection to set the private fields
        setPrivateField(classBands, "class_flags", class_flags);
        setPrivateField(classBands, "index", index);
        setPrivateField(classBands, "class_RVA_bands", class_RVA_bands);

        // WHEN
        classBands.removeCurrentClass();

        // THEN
        assertEquals(1, class_RVA_bands.getEntries().size());
    }

    @Test
    @DisplayName("Class with flag bit 22 set removes the latest item from class_RIA_bands")
    void testRemoveCurrentClass_TC05() throws Exception {
        // GIVEN
        MetadataBandGroup class_RIA_bands = new MetadataBandGroup("classRIA", MetadataBandGroup.CONTEXT_CLASS, null, null, 1);
        class_RIA_bands.addEntry(new MetadataBandGroup.Entry());
        class_RIA_bands.addEntry(new MetadataBandGroup.Entry());

        long[] class_flags = new long[1];
        class_flags[0] = 1 << 22; // Set 22nd bit
        int index = 0;

        // ClassBands object with segmentation adjusted (using null as placeholder for realism)
        ClassBands classBands = new ClassBands(null, 1, 0, false);

        // Use reflection to set the private fields
        setPrivateField(classBands, "class_flags", class_flags);
        setPrivateField(classBands, "index", index);
        setPrivateField(classBands, "class_RIA_bands", class_RIA_bands);

        // WHEN
        classBands.removeCurrentClass();

        // THEN
        assertEquals(1, class_RIA_bands.getEntries().size());
    }

}
