package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_containsKey_0_1_Test {

    @Test
    @DisplayName("Check containsKey when delegateMap is non-null and key is present in delegateMap.")
    public void testContainsKeyInDelegateMapPresent() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Map<Object, Object> delegateMap = new HashMap<>();
        Object key = new Object();
        delegateMap.put(key, new Object());

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegateMap);

        assertTrue(map.containsKey(key));
    }

    @Test
    @DisplayName("Return false when delegateMap is non-null but does not contain the key.")
    public void testContainsKeyInDelegateMapAbsent() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Map<Object, Object> delegateMap = new HashMap<>();

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegateMap);

        assertFalse(map.containsKey(new Object()));
    }

    @Test
    @DisplayName("Check containsKey with null key and null key3 in an un-delegated map of size 3.")
    public void testContainsKeyNullKey3Size3() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);

        assertTrue(map.containsKey(null));
    }

    @Test
    @DisplayName("Check containsKey with null key and null key2 in an un-delegated map of size 2.")
    public void testContainsKeyNullKey2Size2() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        assertTrue(map.containsKey(null));
    }

    @Test
    @DisplayName("Check containsKey with null key and all key slots null in an un-delegated map of size 1.")
    public void testContainsKeyNullAllKeySize1() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        assertTrue(map.containsKey(null));
    }
}