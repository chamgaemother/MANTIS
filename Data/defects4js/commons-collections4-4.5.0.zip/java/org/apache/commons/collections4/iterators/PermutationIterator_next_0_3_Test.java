package org.apache.commons.collections4.iterators;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.*;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class PermutationIterator_next_0_3_Test {

     @Test
     @DisplayName("next() correctly sets nextPermutation to null after last permutation")
     void test_TC11() throws Exception {
         //Initialize elements
         String element1 = "element1";
         String element2 = "element2";

         //Create a collection
         Collection<String> collection = Arrays.asList(element1, element2);

         //Instantiate PermutationIterator with the given collection
         PermutationIterator<String> iterator = new PermutationIterator<>(collection);

         //First permutation
         List<String> firstPermutation = iterator.next();

         //Second permutation
         List<String> secondPermutation = iterator.next();

         //When: Attempt to get next permutation, which should throw exception
         Exception exception = assertThrows(NoSuchElementException.class, () -> {
             iterator.next();
         });

         //Access nextPermutation via reflection
         Field nextPermField = PermutationIterator.class.getDeclaredField("nextPermutation");
         nextPermField.setAccessible(true); // Make private fields accessible
         Object nextPermutation = nextPermField.get(iterator);
         assertNull(nextPermutation, "nextPermutation should be null after the last permutation");
     }

     @Test
     @DisplayName("next() handles empty keys array")
     void test_TC12() throws Exception {
         //Define empty collection
         Collection<String> collection = Collections.emptyList();

         //Instantiate PermutationIterator with empty collection
         PermutationIterator<String> iterator = new PermutationIterator<>(collection);

        // When
         List<String> result = iterator.next();

         //Then
         assertTrue(result.isEmpty(), "The returned list should be empty");

         //Access nextPermutation via reflection
         Field nextPermField = PermutationIterator.class.getDeclaredField("nextPermutation");
         nextPermField.setAccessible(true); // Make private fields accessible
         Object nextPermutation = nextPermField.get(iterator);
         assertNull(nextPermutation, "nextPermutation should be null when keys array is empty");
     }

     @Test
     @DisplayName("next() handles keys with duplicate values")
     void test_TC13() throws Exception {
         //Initialize elements
         String element1 = "element1";
         String element2 = "element2";
         String element3 = "element1"; // Duplicate element

        // Create a collection with duplicates
         Collection<String> collection = Arrays.asList(element1, element3, element2);

         //Instantiate PermutationIterator with the given collection
         PermutationIterator<String> iterator = new PermutationIterator<>(collection);

         //First permutation
         List<String> firstPermutation = iterator.next();

         //When
         List<String> result = iterator.next();

         //Then
         assertEquals(Arrays.asList(element1, element2, element1), result, "The returned permutation should be [element1, element2, element1]");

         //Access nextPermutation via reflection
         Field nextPermField = PermutationIterator.class.getDeclaredField("nextPermutation");
         nextPermField.setAccessible(true); // Make private fields accessible
         Object nextPermutation = nextPermField.get(iterator);
         //Additional assertions on nextPermutation can be added here if needed
     }

     @Test
     @DisplayName("next() handles multiple direction reversals and swaps")
     void test_TC14() throws Exception {
         //Initialize elements
         String element1 = "element1";
         String element2 = "element2";
         String element3 = "element3";
         String element4 = "element4";

         //Create a collection with elements
         Collection<String> collection = Arrays.asList(element4, element3, element2, element1);

         //Instantiate PermutationIterator with the given collection
         PermutationIterator<String> iterator = new PermutationIterator<>(collection);

         //When
         List<String> result = iterator.next();

        // Then
         assertEquals(Arrays.asList(element3, element4, element2, element1), result, "The returned permutation should be [element3, element4, element2, element1]");

         //Access direction via reflection to verify direction changes
         Field directionField = PermutationIterator.class.getDeclaredField("direction");
         directionField.setAccessible(true); // Make private fields accessible
         boolean[] updatedDirection = (boolean[]) directionField.get(iterator);
         assertFalse(updatedDirection[0], "Direction of first element should be false after reversal");
         assertFalse(updatedDirection[1], "Direction of second element should be false after reversal");

         //Access nextPermutation via reflection if needed
         Field nextPermField = PermutationIterator.class.getDeclaredField("nextPermutation");
         nextPermField.setAccessible(true); // Make private fields accessible
         Object nextPermutation = nextPermField.get(iterator);
         //Additional assertions on nextPermutation can be added here if needed
     }
}