java
package org.jfree.data.general;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.category.BoxAndWhiskerCategoryDataset;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.category.DefaultIntervalCategoryDataset;
import org.jfree.data.category.MultiValueCategoryDataset;
import org.jfree.data.category.DefaultMultiValueCategoryDataset;
import org.jfree.data.category.StatisticalCategoryDataset;
import org.jfree.data.category.DefaultStatisticalCategoryDataset;
import org.junit.jupiter.api.Test;

public class DatasetUtilsTest {

    @Test
    public void testIterateToFindRangeBounds_NullDataset_ThrowsException() {
        List<Comparable> visibleSeries = Arrays.asList("Series1");
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(null, visibleSeries, true);
        });
    }

    @Test
    public void testIterateToFindRangeBounds_NullVisibleSeriesKeys_ThrowsException() {
        CategoryDataset dataset = new DefaultCategoryDataset();
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(dataset, null, true);
        });
    }

    @Test
    public void testIterateToFindRangeBounds_EmptyDataset_ReturnsNull() {
        CategoryDataset dataset = new DefaultCategoryDataset();
        List<Comparable> visibleSeries = Collections.emptyList();
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        assertNull(range);
    }

    @Test
    public void testIterateToFindRangeBounds_AllValuesNull_ReturnsNull() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(null, "Series1", "Category1");
        dataset.addValue(null, "Series1", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        assertNull(range);
    }

    @Test
    public void testIterateToFindRangeBounds_PlainCategoryDataset_NoInterval() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Series1", "Category1");
        dataset.addValue(10.0, "Series1", "Category2");
        dataset.addValue(15.0, "Series2", "Category1");
        dataset.addValue(20.0, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        assertEquals(new Range(5.0, 20.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_PlainCategoryDataset_WithInterval() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Series1", "Category1");
        dataset.addValue(10.0, "Series1", "Category2");
        dataset.addValue(15.0, "Series2", "Category1");
        dataset.addValue(20.0, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        assertEquals(new Range(5.0, 20.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_BoxAndWhiskerDataset_WithInterval() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(5, 4, 6, 3, 7), "Series1", "Category1");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(10, 9, 11, 8, 12), "Series1", "Category2");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(15, 14, 16, 13, 17), "Series2", "Category1");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(20, 19, 21, 18, 22), "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        assertEquals(new Range(3.0, 22.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_BoxAndWhiskerDataset_WithoutInterval() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(5, 4, 6, 3, 7), "Series1", "Category1");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(10, 9, 11, 8, 12), "Series1", "Category2");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(15, 14, 16, 13, 17), "Series2", "Category1");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(20, 19, 21, 18, 22), "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        // Without interval, it should consider the mean values: 5,10,15,20
        assertEquals(new Range(5.0, 20.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_IntervalCategoryDataset_WithInterval() {
        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset();
        dataset.addInterval(4.0, 6.0, 5.0, "Series1", "Category1");
        dataset.addInterval(9.0, 11.0, 10.0, "Series1", "Category2");
        dataset.addInterval(14.0, 16.0, 15.0, "Series2", "Category1");
        dataset.addInterval(19.0, 21.0, 20.0, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        assertEquals(new Range(4.0, 21.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_IntervalCategoryDataset_WithoutInterval() {
        DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset();
        dataset.addInterval(4.0, 6.0, 5.0, "Series1", "Category1");
        dataset.addInterval(9.0, 11.0, 10.0, "Series1", "Category2");
        dataset.addInterval(14.0, 16.0, 15.0, "Series2", "Category1");
        dataset.addInterval(19.0, 21.0, 20.0, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        // Without interval, it should consider the y values: 5,10,15,20
        assertEquals(new Range(5.0, 20.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_MultiValueCategoryDataset_WithInterval() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        dataset.add(new double[] {4.0, 5.0, 6.0}, "Series1", "Category1");
        dataset.add(new double[] {9.0, 10.0, 11.0}, "Series1", "Category2");
        dataset.add(new double[] {14.0, 15.0, 16.0}, "Series2", "Category1");
        dataset.add(new double[] {19.0, 20.0, 21.0}, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        // Should consider all values: 4,5,6,9,10,11,14,15,16,19,20,21
        assertEquals(new Range(4.0, 21.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_MultiValueCategoryDataset_WithoutInterval() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        dataset.add(new double[] {4.0, 5.0, 6.0}, "Series1", "Category1");
        dataset.add(new double[] {9.0, 10.0, 11.0}, "Series1", "Category2");
        dataset.add(new double[] {14.0, 15.0, 16.0}, "Series2", "Category1");
        dataset.add(new double[] {19.0, 20.0, 21.0}, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        // Without interval, still should consider all values
        assertEquals(new Range(4.0, 21.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_StatisticalCategoryDataset_WithInterval() {
        DefaultStatisticalCategoryDataset dataset = new DefaultStatisticalCategoryDataset();
        dataset.add(5.0, 1.0, "Series1", "Category1"); // mean=5, std=1 -> range=4 to 6
        dataset.add(10.0, 2.0, "Series1", "Category2"); // range=8 to 12
        dataset.add(15.0, 3.0, "Series2", "Category1"); // range=12 to 18
        dataset.add(20.0, 4.0, "Series2", "Category2"); // range=16 to 24
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        // The ranges: Series1 Category1:4-6, Series1 Category2:8-12, Series2 Category1:12-18, Series2 Category2:16-24
        // Overall min=4, max=24
        assertEquals(new Range(4.0, 24.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_StatisticalCategoryDataset_WithoutInterval() {
        DefaultStatisticalCategoryDataset dataset = new DefaultStatisticalCategoryDataset();
        dataset.add(5.0, 1.0, "Series1", "Category1");
        dataset.add(10.0, 2.0, "Series1", "Category2");
        dataset.add(15.0, 3.0, "Series2", "Category1");
        dataset.add(20.0, 4.0, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        // Without interval, consider mean - std and mean + std
        // Series1 Category1:4-6, Series1 Category2:8-12, Series2 Category1:12-18, Series2 Category2:16-24
        assertEquals(new Range(4.0, 24.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_PartialVisibleSeries() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Series1", "Category1");
        dataset.addValue(10.0, "Series1", "Category2");
        dataset.addValue(15.0, "Series2", "Category1");
        dataset.addValue(20.0, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        assertEquals(new Range(5.0, 10.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_WithSomeNullValues() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(null, "Series1", "Category1");
        dataset.addValue(10.0, "Series1", "Category2");
        dataset.addValue(15.0, "Series2", "Category1");
        dataset.addValue(null, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        assertEquals(new Range(10.0, 15.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_WithNaNValues() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Double.NaN, "Series1", "Category1");
        dataset.addValue(10.0, "Series1", "Category2");
        dataset.addValue(15.0, "Series2", "Category1");
        dataset.addValue(Double.NaN, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1", "Series2");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, false);
        assertEquals(new Range(10.0, 15.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_BoxAndWhiskerDataset_NoVisibleSeries() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(5, 4, 6, 3, 7), "Series1", "Category1");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(10, 9, 11, 8, 12), "Series1", "Category2");
        List<Comparable> visibleSeries = Collections.emptyList();
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        assertNull(range);
    }

    @Test
    public void testIterateToFindRangeBounds_MultiValueCategoryDataset_PartialVisibleSeries() {
        DefaultMultiValueCategoryDataset dataset = new DefaultMultiValueCategoryDataset();
        dataset.add(new double[] {4.0, 5.0, 6.0}, "Series1", "Category1");
        dataset.add(new double[] {9.0, 10.0, 11.0}, "Series1", "Category2");
        dataset.add(new double[] {14.0, 15.0, 16.0}, "Series2", "Category1");
        dataset.add(new double[] {19.0, 20.0, 21.0}, "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        // Should consider values: 4,5,6,9,10,11
        assertEquals(new Range(4.0, 11.0), range);
    }

    @Test
    public void testIterateToFindRangeBounds_BoxAndWhiskerDataset_PartialVisibleSeries() {
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(5, 4, 6, 3, 7), "Series1", "Category1");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(10, 9, 11, 8, 12), "Series1", "Category2");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(15, 14, 16, 13, 17), "Series2", "Category1");
        dataset.add(BoxAndWhiskerCategoryDatasetTestHelper.createBox(20, 19, 21, 18, 22), "Series2", "Category2");
        List<Comparable> visibleSeries = Arrays.asList("Series1");
        Range range = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeries, true);
        // Series1 ranges: 3-7 and 8-12, overall 3 to 12
        assertEquals(new Range(3.0, 12.0), range);
    }

    // Helper class to create BoxAndWhisker data
    static class BoxAndWhiskerCategoryDatasetTestHelper {
        static org.jfree.data.statistics.BoxAndWhiskerCategoryDataset createBox(double mean, double min, double max, double lowerQuartile, double upperQuartile) {
            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
            dataset.add(new org.jfree.data.statistics.BoxAndWhiskerItem(mean, min, max, lowerQuartile, upperQuartile, null, null), "Series", "Category");
            return dataset;
        }
    }
}