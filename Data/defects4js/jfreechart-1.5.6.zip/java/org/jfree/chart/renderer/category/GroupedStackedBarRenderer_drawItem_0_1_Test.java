package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.RectangleEdge;

import org.jfree.chart.renderer.category.BarPainter;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;

import static org.mockito.Mockito.*;

public class GroupedStackedBarRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem returns immediately when dataset value is null")
    void TC01_drawItem_Returns_Immediately_When_DatasetValue_Null() {
        // Given
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(null);

        GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());

        // When
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that getBarPainter is not called since dataset value is null
        verify(renderer, never()).getBarPainter();
    }

    @Test
    @DisplayName("drawItem processes positive value with HORIZONTAL orientation and non-inverted axis")
    void TC02_drawItem_PositiveValue_HorizontalOrientation_NonInvertedAxis() {
        // Given
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 1;
        int column = 1;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(false);

        GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());

        // Mock dependencies
        BarPainter barPainter = mock(BarPainter.class);
        doReturn(barPainter).when(renderer).getBarPainter();
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(generator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);

        // When
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that paintBar is called with RectangleEdge.RIGHT
        verify(barPainter, atLeastOnce()).paintBar(eq(g2), eq(renderer), eq(row), eq(column), any(Rectangle2D.class), eq(RectangleEdge.RIGHT));
    }

    @Test
    @DisplayName("drawItem processes negative value with VERTICAL orientation and inverted axis")
    void TC03_drawItem_NegativeValue_VerticalOrientation_InvertedAxis() {
        // Given
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 2;
        int column = 2;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(-3.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(true);

        GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());

        // Mock dependencies
        BarPainter barPainter = mock(BarPainter.class);
        doReturn(barPainter).when(renderer).getBarPainter();
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(generator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);

        // When
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that paintBar is called with RectangleEdge.TOP
        verify(barPainter, atLeastOnce()).paintBar(eq(g2), eq(renderer), eq(row), eq(column), any(Rectangle2D.class), eq(RectangleEdge.TOP));
    }

    @Test
    @DisplayName("drawItem with zero iterations in the loop (row = 0)")
    void TC04_drawItem_ZeroLoopIterations_RowZero() {
        // Given
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 3;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);

        GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());

        // Mock dependencies
        BarPainter barPainter = mock(BarPainter.class);
        doReturn(barPainter).when(renderer).getBarPainter();
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(generator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);

        // When
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that paintBar is called correctly without accumulation
        verify(barPainter, atLeastOnce()).paintBar(eq(g2), eq(renderer), eq(row), eq(column), any(Rectangle2D.class), any(RectangleEdge.class));
    }

    @Test
    @DisplayName("drawItem with one iteration in the loop and positive value accumulation")
    void TC05_drawItem_OneLoopIteration_PositiveAccumulation() {
        // Given
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 1;
        int column = 1;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(4.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(false);

        GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());

        // Mock dependencies
        BarPainter barPainter = mock(BarPainter.class);
        doReturn(barPainter).when(renderer).getBarPainter();
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(generator);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);

        // When
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Then
        // Verify that positiveBase accumulates correctly and paintBar is called
        verify(barPainter, atLeastOnce()).paintBar(eq(g2), eq(renderer), eq(row), eq(column), any(Rectangle2D.class), any(RectangleEdge.class));
    }
}