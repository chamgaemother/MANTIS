package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601Utils_parse_0_5_Test {
    
    @Test
    @DisplayName("Parse throws IndexOutOfBoundsException for invalid timezone sign after 'Z'")
    void TC21_parseThrowsIndexOutOfBoundsExceptionForInvalidTimezoneSign() {
        // GIVEN
        String date = "2023-10-05T14:30:00Z+";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN & THEN
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("Invalid time zone indicator"));
    }
    
    @Test
    @DisplayName("Parse successfully handles timezone offset with missing minutes")
    void TC22_parseHandlesTimezoneOffsetWithMissingMinutes() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00+02";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN
        Date result = ISO8601Utils.parse(date, pos);
        
        // THEN
        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"));
        expectedCalendar.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();
        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }
    
    @Test
    @DisplayName("Parse throws ParseException when additional unexpected characters are present after timezone")
    void TC23_parseThrowsParseExceptionForUnexpectedCharactersAfterTimezone() {
        // GIVEN
        String date = "2023-10-05T14:30:00Zabc";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("unexpected characters"));
    }
    
    @Test
    @DisplayName("Parse successfully handles timezone offset without colon and with single digit hour")
    void TC24_parseHandlesTimezoneOffsetWithoutColonAndSingleDigitHour() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00+2";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN
        Date result = ISO8601Utils.parse(date, pos);
        
        // THEN
        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"));
        expectedCalendar.set(2023, Calendar.OCTOBER, 5, 14, 30, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();
        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }
    
    @Test
    @DisplayName("Parse throws ParseException when input string is empty")
    void TC25_parseThrowsParseExceptionForEmptyInput() {
        // GIVEN
        String date = "";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("empty input"));
    }
}