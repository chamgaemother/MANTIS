package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import java.util.ArrayList;

public class BcBands_visitMethodInsn_0_2_Test {

    class MockCpBands extends CpBands {
        public CPMethodOrField getCPMethod(String owner, String name, String desc) {
            return new CPMethodOrField(owner, name, desc);
        }

        public CPMethodOrField getCPIMethod(String owner, String name, String desc) {
            return new CPMethodOrField(owner, "interfaceMethod", "interfaceDesc");
        }
    }

    @Test
    @DisplayName("Test with empty bcCodes list and opcode 182")
    public void testEmptyBcCodesAndOpcode182() {
        // Setup
        MockCpBands cpBands = new MockCpBands();
        BcBands bcBands = new BcBands(cpBands, null, 0);
        bcBands.byteCodeOffset = 0;
        List<Integer> bcCodes = new ArrayList<>();
        bcBands.bcCodes = bcCodes;

        int opcode = 182;
        String owner = "otherClass";
        String name = "methodName";
        String desc = "methodDesc";

        // Action
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assertions
        assertEquals(182, bcCodes.get(0), "Modified opcode should be in bcCodes");
        assertTrue(bcBands.bcMethodRef.contains(cpBands.getCPMethod(owner, name, desc)),
                   "The correct cpMethod should be added");
    }

    @Test
    @DisplayName("Test with aload_0 adjustment and opcode 183")
    public void testAload0AdjustmentAndOpcode183() {
        // Setup
        MockCpBands cpBands = new MockCpBands();
        BcBands bcBands = new BcBands(cpBands, null, 0);
        bcBands.byteCodeOffset = 0;
        List<Integer> bcCodes = new ArrayList<>();
        bcCodes.add(42); // ALOAD_0
        bcBands.bcCodes = bcCodes;

        int opcode = 183;
        String owner = "otherClass";
        String name = "methodName";
        String desc = "methodDesc";

        // Action
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assertions
        assertEquals(183, bcCodes.get(1), "Opcode should be adjusted correctly");
        assertTrue(bcBands.bcMethodRef.contains(cpBands.getCPMethod(owner, name, desc)),
                   "The correct cpMethod should be added to bcMethodRef");
    }

    @Test
    @DisplayName("Test with opcode 183 and name not <init> or currentNewClass")
    public void testOpcode183AndNotCurrentNewClass() {
        // Setup
        MockCpBands cpBands = new MockCpBands();
        BcBands bcBands = new BcBands(cpBands, null, 0);
        bcBands.byteCodeOffset = 0;
        List<Integer> bcCodes = new ArrayList<>();
        bcBands.bcCodes = bcCodes;

        int opcode = 183;
        String owner = "otherClass";
        String name = "methodName";
        String desc = "methodDesc";

        // Action
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assertions
        assertTrue(bcBands.bcMethodRef.contains(cpBands.getCPMethod(owner, name, desc)),
                   "The correct cpMethod should be added to bcMethodRef");
        assertEquals(183, (int) bcCodes.get(0), "Modified opcode should be in bcCodes");
    }

    @Test
    @DisplayName("Test impossible opcode (not in switch cases)")
    public void testImpossibleOpcode() {
        // Setup
        MockCpBands cpBands = new MockCpBands();
        BcBands bcBands = new BcBands(cpBands, null, 0);
        bcBands.byteCodeOffset = 0;
        List<Integer> bcCodes = new ArrayList<>();
        bcBands.bcCodes = bcCodes;

        int opcode = 999;
        String owner = "anyClass";
        String name = "method";
        String desc = "desc";

        // Clone lists to check no modification later
        List<Integer> originalBcCodes = new ArrayList<>(bcCodes);
        List<Object> originalBcMethodRef = new ArrayList<>(bcBands.bcMethodRef);

        // Action
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assertions
        assertEquals(originalBcCodes, bcBands.bcCodes, "bcCodes should remain unchanged");
        assertEquals(originalBcMethodRef, bcBands.bcMethodRef, "Method lists should remain unchanged");
    }

    @Test
    @DisplayName("Switch default case where opcode is not handled")
    public void testSwitchDefaultCase() {
        // Setup
        MockCpBands cpBands = new MockCpBands();
        BcBands bcBands = new BcBands(cpBands, null, 0);
        bcBands.byteCodeOffset = 0;
        List<Integer> bcCodes = new ArrayList<>();
        bcBands.bcCodes = bcCodes;

        int opcode = 999;
        String owner = "ownerClass";
        String name = "unknownMethod";
        String desc = "unknownDesc";

        // Clone lists to check no modification later
        List<Integer> originalBcCodes = new ArrayList<>(bcCodes);
        List<Object> originalBcMethodRef = new ArrayList<>(bcBands.bcMethodRef);

        // Action
        bcBands.visitMethodInsn(opcode, owner, name, desc);

        // Assertions
        assertEquals(originalBcCodes, bcBands.bcCodes, "bcCodes should remain unchanged");
        assertEquals(originalBcMethodRef, bcBands.bcMethodRef, "Method lists should remain unchanged");
    }

}