package org.jfree.chart.labels;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ItemLabelAnchor_isInternal_0_1_Test {
    
    @Test
    @DisplayName("isInternal() returns true when the anchor is CENTER")
    void test_TC01_isInternal_CENTER() {
        // GIVEN
        ItemLabelAnchor anchor = ItemLabelAnchor.CENTER;
        
        // WHEN
        boolean result = anchor.isInternal();
        
        // THEN
        assertTrue(result);
    }
    
    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE1")
    void test_TC02_isInternal_INSIDE1() {
        // GIVEN
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE1;
        
        // WHEN
        boolean result = anchor.isInternal();
        
        // THEN
        assertTrue(result);
    }
    
    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE2")
    void test_TC03_isInternal_INSIDE2() {
        // GIVEN
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE2;
        
        // WHEN
        boolean result = anchor.isInternal();
        
        // THEN
        assertTrue(result);
    }
    
    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE3")
    void test_TC04_isInternal_INSIDE3() {
        // GIVEN
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE3;
        
        // WHEN
        boolean result = anchor.isInternal();
        
        // THEN
        assertTrue(result);
    }
    
    @Test
    @DisplayName("isInternal() returns true when the anchor is INSIDE4")
    void test_TC05_isInternal_INSIDE4() {
        // GIVEN
        ItemLabelAnchor anchor = ItemLabelAnchor.INSIDE4;
        
        // WHEN
        boolean result = anchor.isInternal();
        
        // THEN
        assertTrue(result);
    }
}