package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.io.SerializedString;

public class UTF8StreamJsonParserTest {

    @Test
    void testNextFieldName_MatchingField() throws IOException {
        String json = "{\"name\":\"value\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("name", parser.currentName());
        assertEquals("value", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_NonMatchingField() throws IOException {
        String json = "{\"age\":30}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertFalse(parser.nextFieldName(ss));
        assertEquals("age", parser.currentName());
        assertEquals(30, parser.getIntValue());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_EmptyObject() throws IOException {
        String json = "{}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertNull(parser.nextToken());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_EndOfObject() throws IOException {
        String json = "{\"name\":\"value\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertFalse(parser.nextFieldName(ss));
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    void testNextFieldName_NestedObject_MatchingField() throws IOException {
        String json = "{\"user\":{\"name\":\"Alice\"}}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(new SerializedString("user")));
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_TrailingCommaAllowed() throws IOException {
        String json = "{\"name\":\"value\",}";
        JsonFactory factory = new JsonFactory();
        factory.enable(JsonFactory.Feature.ALLOW_TRAILING_COMMA);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertFalse(parser.nextFieldName(ss));
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    void testNextFieldName_TrailingCommaDisallowed() throws IOException {
        String json = "{\"name\":\"value\",}";
        JsonFactory factory = new JsonFactory();
        factory.disable(JsonFactory.Feature.ALLOW_TRAILING_COMMA);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertThrows(JsonParseException.class, () -> parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_MultipleFields_MatchingAndNonMatching() throws IOException {
        String json = "{\"name\":\"Alice\",\"age\":30,\"city\":\"Wonderland\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ssName = new SerializedString("name");
        SerializableString ssCity = new SerializedString("city");
        SerializableString ssCountry = new SerializedString("country");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ssName));
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ssCountry));
        assertTrue(parser.nextFieldName(ssCity));
        assertEquals("Wonderland", parser.getText());
        assertFalse(parser.nextFieldName(ssCountry));
        assertNull(parser.nextToken());
        parser.close();
    }

    @Test
    void testNextFieldName_SingleQuoteNameAllowed() throws IOException {
        String json = "{'name':'Alice'}";
        JsonFactory factory = new JsonFactory();
        factory.enable(JsonFactory.Feature.ALLOW_SINGLE_QUOTES);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_SingleQuoteNameDisallowed() throws IOException {
        String json = "{'name':'Alice'}";
        JsonFactory factory = new JsonFactory();
        factory.disable(JsonFactory.Feature.ALLOW_SINGLE_QUOTES);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertThrows(JsonParseException.class, () -> parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_UnquotedNameAllowed() throws IOException {
        String json = "{name:\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        factory.enable(JsonFactory.Feature.ALLOW_UNQUOTED_FIELD_NAMES);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_UnquotedNameDisallowed() throws IOException {
        String json = "{name:\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        factory.disable(JsonFactory.Feature.ALLOW_UNQUOTED_FIELD_NAMES);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertThrows(JsonParseException.class, () -> parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_NullSerializableString() throws IOException {
        String json = "{\"name\":\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = null;
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertThrows(NullPointerException.class, () -> parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_InvalidJSON() throws IOException {
        String json = "{name:\"Alice\""; // Missing closing brace
        JsonFactory factory = new JsonFactory();
        factory.enable(JsonFactory.Feature.ALLOW_UNQUOTED_FIELD_NAMES);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertThrows(JsonParseException.class, () -> parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_SpecialCharactersInName_Matching() throws IOException {
        String json = "{\"na\\u006De\":\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_SpecialCharactersInName_NonMatching() throws IOException {
        String json = "{\"na\\u006De\":\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("naMe");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertFalse(parser.nextFieldName(ss));
        assertEquals("name", parser.currentName());
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_MalformedName() throws IOException {
        String json = "{\"na\\u00ZZe\":\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        factory.enable(JsonFactory.Feature.ALLOW_UNQUOTED_FIELD_NAMES);
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertThrows(JsonParseException.class, () -> parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_MultipleMatchingFields() throws IOException {
        String json = "{\"name\":\"Alice\",\"name\":\"Bob\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("name");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Bob", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_FieldNameWithEscapeCharacters() throws IOException {
        String json = "{\"na\\\"me\":\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        factory.enable(JsonFactory.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER);
        SerializableString ss = new SerializedString("na\"me");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }

    @Test
    void testNextFieldName_FieldNameWithUnicode() throws IOException {
        String json = "{\"na\u00DFme\":\"Alice\"}";
        JsonFactory factory = new JsonFactory();
        SerializableString ss = new SerializedString("na\u00DFme");
        UTF8StreamJsonParser parser = (UTF8StreamJsonParser) factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        
        assertTrue(parser.nextFieldName(ss));
        assertEquals("Alice", parser.getText());
        assertFalse(parser.nextFieldName(ss));
        parser.close();
    }
}