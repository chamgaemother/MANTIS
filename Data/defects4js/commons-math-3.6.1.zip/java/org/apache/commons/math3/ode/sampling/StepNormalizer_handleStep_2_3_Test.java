package org.apache.commons.math3.ode.sampling;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.math3.exception.MaxCountExceededException;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class StepNormalizer_handleStep_2_3_Test {

    @Test
    @DisplayName("handleStep boundary value test with h just below the step size threshold")
    void TC27_handleStep_h_just_below_threshold() throws MaxCountExceededException {
        // GIVEN
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.499, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);
        
        // Simulating StepInterpolator
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0, 1.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.0, 0.1});
        
        // WHEN
        normalizer.handleStep(interpolator, false);
        
        // THEN
        verify(handler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), anyBoolean());
    }

    @Test
    @DisplayName("handleStep boundary value test with h exactly matching the step size")
    void TC28_handleStep_h_exactly_matching_threshold() throws MaxCountExceededException {
        // GIVEN
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizer normalizer = new StepNormalizer(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.BOTH);
        
        // Simulating StepInterpolator
        StepInterpolator interpolator = mock(StepInterpolator.class);
        when(interpolator.getPreviousTime()).thenReturn(0.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0, 1.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.0, 0.1});
        
        // WHEN
        normalizer.handleStep(interpolator, true);
        
        // THEN
        verify(handler).handleStep(eq(1.0), any(double[].class), any(double[].class), eq(true));
    }
}