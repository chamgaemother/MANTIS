package com.fasterxml.jackson.databind.deser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

public class BeanDeserializerBuilder_buildBuilderBased_0_3_Test {

    @Test
    @DisplayName("ANY views are enabled and properties have views")
    public void TC11_anyViewsEnabled_withPropertyViews() throws Exception {
        // Arrange
        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mock(BeanDescription.class), mock(DeserializationContext.class));

        // Set up _buildMethod
        Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
        buildMethodField.setAccessible(true);
        buildMethodField.set(builder, mock(AnnotatedMethod.class));

        // Set up _config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION) to return false
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)).thenReturn(false);
        Field configField = BeanDeserializerBuilder.class.getDeclaredField("_config");
        configField.setAccessible(true);
        configField.set(builder, config);

        // Mock SettableBeanProperty with views
        SettableBeanProperty propWithViews = mock(SettableBeanProperty.class);
        when(propWithViews.hasViews()).thenReturn(true);
        Field propertiesField = BeanDeserializerBuilder.class.getDeclaredField("_properties");
        propertiesField.setAccessible(true);
        propertiesField.set(builder, Collections.singletonMap("propWithViews", propWithViews));

        // Act
        JavaType valueType = mock(JavaType.class);
        JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");

        // Assert
        assertNotNull(deserializer);
    }

    @Test
    @DisplayName("ANY views are disabled and no properties have views")
    public void TC12_anyViewsDisabled_noPropertyViews() throws Exception {
        // Arrange
        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mock(BeanDescription.class), mock(DeserializationContext.class));

        // Set up _buildMethod
        Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
        buildMethodField.setAccessible(true);
        buildMethodField.set(builder, mock(AnnotatedMethod.class));

        // Set up _config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION) to return false
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)).thenReturn(false);
        Field configField = BeanDeserializerBuilder.class.getDeclaredField("_config");
        configField.setAccessible(true);
        configField.set(builder, config);

        // Mock SettableBeanProperty without views
        SettableBeanProperty prop = mock(SettableBeanProperty.class);
        when(prop.hasViews()).thenReturn(false);
        Field propertiesField = BeanDeserializerBuilder.class.getDeclaredField("_properties");
        propertiesField.setAccessible(true);
        propertiesField.set(builder, Collections.singletonMap("prop", prop));

        // Act
        JavaType valueType = mock(JavaType.class);
        JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");

        // Assert
        assertNotNull(deserializer);
    }

    @Test
    @DisplayName("ObjectIdReader is null, no ObjectIdValueProperty is added")
    public void TC13_objectIdReaderNull_noObjectIdValueProperty() throws Exception {
        // Arrange
        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mock(BeanDescription.class), mock(DeserializationContext.class));

        // Set up _buildMethod
        Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
        buildMethodField.setAccessible(true);
        buildMethodField.set(builder, mock(AnnotatedMethod.class));

        // Set ObjectIdReader to null
        Field objectIdReaderField = BeanDeserializerBuilder.class.getDeclaredField("_objectIdReader");
        objectIdReaderField.setAccessible(true);
        objectIdReaderField.set(builder, null);

        // Act
        JavaType valueType = mock(JavaType.class);
        JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");

        // Assert
        assertNotNull(deserializer);
    }

    @Test
    @DisplayName("ObjectIdReader is present, ObjectIdValueProperty is added")
    public void TC14_objectIdReaderPresent_objectIdValuePropertyAdded() throws Exception {
        // Arrange
        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(mock(BeanDescription.class), mock(DeserializationContext.class));

        // Set up _buildMethod
        Field buildMethodField = BeanDeserializerBuilder.class.getDeclaredField("_buildMethod");
        buildMethodField.setAccessible(true);
        buildMethodField.set(builder, mock(AnnotatedMethod.class));

        // Set ObjectIdReader
        ObjectIdReader objectIdReader = mock(ObjectIdReader.class);
        Field objectIdReaderField = BeanDeserializerBuilder.class.getDeclaredField("_objectIdReader");
        objectIdReaderField.setAccessible(true);
        objectIdReaderField.set(builder, objectIdReader);

        // Act
        JavaType valueType = mock(JavaType.class);
        JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");

        // Assert
        assertNotNull(deserializer);
    }
}