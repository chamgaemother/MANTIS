import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.renderer.GrayPaintScale;
import org.jfree.chart.title.PaintScaleLegend;
import org.jfree.chart.ui.RectangleEdge;
import java.awt.*;
import java.awt.geom.Rectangle2D;

class PaintScaleLegendTest {

    private PaintScaleLegend legend;
    private Graphics2D g2;
    private Rectangle2D area;

    @BeforeEach
    void setUp() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);
        NumberAxis axis = new NumberAxis("Scale");
        legend = new PaintScaleLegend(scale, axis);
        g2 = (Graphics2D) new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB).getGraphics();
        area = new Rectangle2D.Double(0, 0, 200, 50);
    }

    @Test
    void testDrawBottomAxis() {
        legend.setPosition(RectangleEdge.BOTTOM);
        legend.draw(g2, area, null);
    }

    @Test
    void testDrawTopAxis() {
        legend.setPosition(RectangleEdge.TOP);
        legend.draw(g2, area, null);
    }

    @Test
    void testDrawLeftAxis() {
        legend.setPosition(RectangleEdge.LEFT);
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        legend.draw(g2, new Rectangle2D.Double(0, 0, 50, 200), null);
    }

    @Test
    void testDrawRightAxis() {
        legend.setPosition(RectangleEdge.RIGHT);
        legend.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        legend.draw(g2, new Rectangle2D.Double(0, 0, 50, 200), null);
    }

    @Test
    void testDrawWithNullGraphics() {
        assertThrows(NullPointerException.class, () -> {
            legend.draw(null, area, null);
        });
    }

    @Test
    void testDrawWithNullArea() {
        assertThrows(NullPointerException.class, () -> {
            legend.draw(g2, null, null);
        });
    }

    @Test
    void testStripOutlineInvisible() {
        legend.setStripOutlineVisible(false);
        legend.draw(g2, area, null);
    }
}