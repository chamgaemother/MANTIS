package org.jfree.chart;

import static org.mockito.Mockito.*;

import java.awt.event.ActionEvent;
import java.io.IOException;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class ChartPanelTest {

    private JFreeChart mockChart;
    private ChartPanel chartPanel;

    @BeforeEach
    void setUp() {
        mockChart = mock(JFreeChart.class);
        chartPanel = Mockito.spy(new ChartPanel(mockChart));
        chartPanel.setZoomPoint(null);
    }

    @Test
    void testActionPerformedPropertiesCommand_nullZoomPoint() {
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.PROPERTIES_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).doEditChartProperties();
    }

    @Test
    void testActionPerformedCopyCommand_nullZoomPoint() {
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.COPY_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).doCopy();
    }

    @Test
    void testActionPerformedSaveAsPngCommand_success() throws IOException {
        doNothing().when(chartPanel).doSaveAs();
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.SAVE_AS_PNG_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).doSaveAs();
        verifyNoInteractions((JOptionPane)null);
    }

    @Test
    void testActionPerformedSaveAsPngCommand_ioException() throws IOException {
        doThrow(new IOException()).when(chartPanel).doSaveAs();
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.SAVE_AS_PNG_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).doSaveAs();
        verifyStatic(JOptionPane.class, times(1));
        JOptionPane.showMessageDialog(eq(chartPanel), eq("I/O error occurred."),
                eq("Save_as_PNG"), eq(JOptionPane.WARNING_MESSAGE));
    }

    @Test
    void testActionPerformedSaveAsSvgCommand_success() throws IOException {
        doNothing().when(chartPanel).saveAsSVG(null);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.SAVE_AS_SVG_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).saveAsSVG(null);
        verifyNoInteractions((JOptionPane)null);
    }

    @Test
    void testActionPerformedSaveAsSvgCommand_ioException() throws IOException {
        doThrow(new IOException()).when(chartPanel).saveAsSVG(null);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.SAVE_AS_SVG_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).saveAsSVG(null);
        verifyStatic(JOptionPane.class, times(1));
        JOptionPane.showMessageDialog(eq(chartPanel), eq("I/O error occurred."),
                eq("Save_as_SVG"), eq(JOptionPane.WARNING_MESSAGE));
    }

    @Test
    void testActionPerformedSaveAsPdfCommand_nullZoomPoint() {
        doNothing().when(chartPanel).saveAsPDF(null);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.SAVE_AS_PDF_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).saveAsPDF(null);
    }

    @Test
    void testActionPerformedPrintCommand_nullZoomPoint() {
        doNothing().when(chartPanel).createChartPrintJob();
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.PRINT_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).createChartPrintJob();
    }

    @Test
    void testActionPerformedZoomInBothCommand_nullZoomPoint() {
        doNothing().when(chartPanel).zoomInBoth(-1.0, -1.0);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_IN_BOTH_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).zoomInBoth(-1.0, -1.0);
    }

    @Test
    void testActionPerformedZoomInDomainCommand_withZoomPoint() {
        Point2D mockPoint = mock(Point2D.class);
        when(mockPoint.getX()).thenReturn(100.0);
        when(mockPoint.getY()).thenReturn(150.0);
        chartPanel.setZoomPoint(mockPoint);
        
        doNothing().when(chartPanel).zoomInDomain(100.0, 150.0);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_IN_DOMAIN_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).zoomInDomain(100.0, 150.0);
    }

    @Test
    void testActionPerformedZoomInRangeCommand_withZoomPoint() {
        Point2D mockPoint = mock(Point2D.class);
        when(mockPoint.getX()).thenReturn(200.0);
        when(mockPoint.getY()).thenReturn(250.0);
        chartPanel.setZoomPoint(mockPoint);
        
        doNothing().when(chartPanel).zoomInRange(200.0, 250.0);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_IN_RANGE_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).zoomInRange(200.0, 250.0);
    }

    @Test
    void testActionPerformedZoomOutBothCommand_withZoomPoint() {
        Point2D mockPoint = mock(Point2D.class);
        when(mockPoint.getX()).thenReturn(300.0);
        when(mockPoint.getY()).thenReturn(350.0);
        chartPanel.setZoomPoint(mockPoint);
        
        doNothing().when(chartPanel).zoomOutBoth(300.0, 350.0);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_OUT_BOTH_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).zoomOutBoth(300.0, 350.0);
    }

    @Test
    void testActionPerformedZoomOutDomainCommand_withZoomPoint() {
        Point2D mockPoint = mock(Point2D.class);
        when(mockPoint.getX()).thenReturn(400.0);
        when(mockPoint.getY()).thenReturn(450.0);
        chartPanel.setZoomPoint(mockPoint);
        
        doNothing().when(chartPanel).zoomOutDomain(400.0, 450.0);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_OUT_DOMAIN_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).zoomOutDomain(400.0, 450.0);
    }

    @Test
    void testActionPerformedZoomOutRangeCommand_withZoomPoint() {
        Point2D mockPoint = mock(Point2D.class);
        when(mockPoint.getX()).thenReturn(500.0);
        when(mockPoint.getY()).thenReturn(550.0);
        chartPanel.setZoomPoint(mockPoint);
        
        doNothing().when(chartPanel).zoomOutRange(500.0, 550.0);
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_OUT_RANGE_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).zoomOutRange(500.0, 550.0);
    }

    @Test
    void testActionPerformedZoomResetBothCommand_nullZoomPoint() {
        doNothing().when(chartPanel).restoreAutoBounds();
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_RESET_BOTH_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).restoreAutoBounds();
    }

    @Test
    void testActionPerformedZoomResetDomainCommand_nullZoomPoint() {
        doNothing().when(chartPanel).restoreAutoDomainBounds();
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_RESET_DOMAIN_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).restoreAutoDomainBounds();
    }

    @Test
    void testActionPerformedZoomResetRangeCommand_nullZoomPoint() {
        doNothing().when(chartPanel).restoreAutoRangeBounds();
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_RESET_RANGE_COMMAND);
        chartPanel.actionPerformed(event);
        verify(chartPanel, times(1)).restoreAutoRangeBounds();
    }

    @Test
    void testActionPerformedUnknownCommand() {
        doNothing().when(chartPanel).doEditChartProperties();
        doNothing().when(chartPanel).doCopy();
        doNothing().when(chartPanel).doSaveAs();
        doNothing().when(chartPanel).saveAsSVG(null);
        doNothing().when(chartPanel).saveAsPDF(null);
        doNothing().when(chartPanel).createChartPrintJob();
        doNothing().when(chartPanel).zoomInBoth(-1.0, -1.0);
        doNothing().when(chartPanel).zoomInDomain(-1.0, -1.0);
        doNothing().when(chartPanel).zoomInRange(-1.0, -1.0);
        doNothing().when(chartPanel).zoomOutBoth(-1.0, -1.0);
        doNothing().when(chartPanel).zoomOutDomain(-1.0, -1.0);
        doNothing().when(chartPanel).zoomOutRange(-1.0, -1.0);
        doNothing().when(chartPanel).restoreAutoBounds();
        doNothing().when(chartPanel).restoreAutoDomainBounds();
        doNothing().when(chartPanel).restoreAutoRangeBounds();
        
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "UNKNOWN_COMMAND");
        chartPanel.actionPerformed(event);
        verify(chartPanel, never()).doEditChartProperties();
        verify(chartPanel, never()).doCopy();
        verify(chartPanel, never()).doSaveAs();
        verify(chartPanel, never()).saveAsSVG(null);
        verify(chartPanel, never()).saveAsPDF(null);
        verify(chartPanel, never()).createChartPrintJob();
        verify(chartPanel, never()).zoomInBoth(-1.0, -1.0);
        verify(chartPanel, never()).zoomInDomain(-1.0, -1.0);
        verify(chartPanel, never()).zoomInRange(-1.0, -1.0);
        verify(chartPanel, never()).zoomOutBoth(-1.0, -1.0);
        verify(chartPanel, never()).zoomOutDomain(-1.0, -1.0);
        verify(chartPanel, never()).zoomOutRange(-1.0, -1.0);
        verify(chartPanel, never()).restoreAutoBounds();
        verify(chartPanel, never()).restoreAutoDomainBounds();
        verify(chartPanel, never()).restoreAutoRangeBounds();
    }

    @Test
    void testActionPerformed_nullEvent() {
        // Expect NullPointerException
        assertThrows(NullPointerException.class, () -> {
            chartPanel.actionPerformed(null);
        });
    }
    
    // Helper method to mock static methods if needed
    private static void verifyStatic(Class<?> clazz, int times) {
        // This method would require using Mockito's inline mocking or similar
        // which is beyond the simple example. It's left as a placeholder.
    }
}