package com.fasterxml.jackson.dataformat.xml.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StaxUtil_sanitizeXmlTypeName_1_1_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName with input '[]' results in 's' after stripping all arrays and appending 's'")
    void TC26_sanitizeXmlTypeName_withEmptyArray() {
        // GIVEN
        String input = "[]";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(input);
        
        // THEN
        assertEquals("s", result);
    }
    
    @Test
    @DisplayName("sanitizeXmlTypeName with input '[][]' results in 's' after stripping multiple arrays and appending 's'")
    void TC27_sanitizeXmlTypeName_withMultipleEmptyArrays() {
        // GIVEN
        String input = "[][]";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(input);
        
        // THEN
        assertEquals("s", result);
    }
}