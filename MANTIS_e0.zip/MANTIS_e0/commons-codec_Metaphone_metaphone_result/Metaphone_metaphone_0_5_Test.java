package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_5_Test {

    @Test
    @DisplayName("metaphone word with 'TCH' makes 'T' silent")
    public void testTC21() {
        Metaphone metaphone = new Metaphone();
        String txt = "watch";
        String result = metaphone.metaphone(txt);
        assertEquals("WCH", result);
    }

    @Test
    @DisplayName("metaphone word with 'SIO' converts to 'X'")
    public void testTC22() {
        Metaphone metaphone = new Metaphone();
        String txt = "sion";
        String result = metaphone.metaphone(txt);
        assertEquals("XN", result);
    }

    @Test
    @DisplayName("metaphone word with 'SIA' converts to 'S'")
    public void testTC23() {
        Metaphone metaphone = new Metaphone();
        String txt = "asia";
        String result = metaphone.metaphone(txt);
        assertEquals("SX", result);
    }

    @Test
    @DisplayName("metaphone word with 'S' followed by 'H' converts to 'X'")
    public void testTC24() {
        Metaphone metaphone = new Metaphone();
        String txt = "shop";
        String result = metaphone.metaphone(txt);
        assertEquals("XP", result);
    }

    @Test
    @DisplayName("metaphone word with 'Z' converts to 'S'")
    public void testTC25() {
        Metaphone metaphone = new Metaphone();
        String txt = "zoo";
        String result = metaphone.metaphone(txt);
        assertEquals("S", result);
    }
}