import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.KeyedObjects2D;
import org.jfree.data.UnknownKeyException;
import org.jfree.data.KeyedObjects;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class KeyedObjects2DTest {

    private KeyedObjects2D data;

    @BeforeEach
    public void setUp() {
        data = new KeyedObjects2D();
        data.setObject("Value1", "Row1", "Col1");
        data.setObject("Value2", "Row1", "Col2");
        data.setObject("Value3", "Row2", "Col1");
        data.setObject("Value4", "Row2", "Col2");
        data.setObject("Value5", "Row3", "Col3");
    }

    @Test
    public void testRemoveObject_NonExistingRowKey_ThrowsUnknownKeyException() {
        assertThrows(UnknownKeyException.class, () -> {
            data.removeObject("NonExistingRow", "Col1");
        });
    }

    @Test
    public void testRemoveObject_NonExistingColumnKey_ThrowsUnknownKeyException() {
        assertThrows(UnknownKeyException.class, () -> {
            data.removeObject("Row1", "NonExistingCol");
        });
    }

    @Test
    public void testRemoveObject_ObjectExists_RowNotEmpty_ColumnNotEmpty() {
        data.removeObject("Row1", "Col1");
        assertNull(data.getObject("Row1", "Col1"));
        assertEquals("Value2", data.getObject("Row1", "Col2"));
        assertTrue(data.getRowKeys().contains("Row1"));
        assertTrue(data.getColumnKeys().contains("Col1"));
    }

    @Test
    public void testRemoveObject_ObjectExists_RowBecomesEmpty_RowRemoved() {
        data.setObject(null, "Row3", "Col3"); // Ensure Row3 has only one object
        data.removeObject("Row3", "Col3");
        assertFalse(data.getRowKeys().contains("Row3"));
        assertNull(data.getObject("Row3", "Col3"));
    }

    @Test
    public void testRemoveObject_ObjectExists_ColumnBecomesEmpty_ColumnRemoved() {
        data.removeObject("Row1", "Col2");
        data.removeObject("Row2", "Col2");
        assertFalse(data.getColumnKeys().contains("Col2"));
        assertNull(data.getObject("Row1", "Col2"));
        assertNull(data.getObject("Row2", "Col2"));
    }

    @Test
    public void testRemoveObject_ObjectExists_ColumnNotEmpty_ColumnRemains() {
        data.removeObject("Row1", "Col1");
        assertTrue(data.getColumnKeys().contains("Col1"));
        assertNull(data.getObject("Row1", "Col1"));
        assertEquals("Value3", data.getObject("Row2", "Col1"));
    }

    @Test
    public void testRemoveObject_ObjectAlreadyNull_NoEffect() {
        data.removeObject("Row1", "Col1");
        data.removeObject("Row1", "Col1"); // Remove again
        assertNull(data.getObject("Row1", "Col1"));
        assertTrue(data.getRowKeys().contains("Row1"));
        assertTrue(data.getColumnKeys().contains("Col1"));
    }

    @Test
    public void testRemoveObject_LastObjectInRowAndColumn_RowAndColumnRemoved() {
        data.setObject(null, "Row3", "Col3"); // Ensure Row3 has only one object
        data.removeObject("Row3", "Col3");
        assertFalse(data.getRowKeys().contains("Row3"));
        assertFalse(data.getColumnKeys().contains("Col3"));
    }

    @Test
    public void testRemoveObject_NullRowKey_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> {
            data.removeObject(null, "Col1");
        });
    }

    @Test
    public void testRemoveObject_NullColumnKey_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> {
            data.removeObject("Row1", null);
        });
    }

    @Test
    public void testRemoveObject_NullRowAndColumnKeys_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> {
            data.removeObject(null, null);
        });
    }

    @Test
    public void testRemoveObject_SingleRowSingleColumn_RowAndColumnRemoved() {
        KeyedObjects2D singleData = new KeyedObjects2D();
        singleData.setObject("OnlyValue", "OnlyRow", "OnlyCol");
        singleData.removeObject("OnlyRow", "OnlyCol");
        assertFalse(singleData.getRowKeys().contains("OnlyRow"));
        assertFalse(singleData.getColumnKeys().contains("OnlyCol"));
    }

    @Test
    public void testRemoveObject_MultipleRemovals_AffectsRowAndColumnProperly() {
        // Remove "Row1", "Col1"
        data.removeObject("Row1", "Col1");
        assertNull(data.getObject("Row1", "Col1"));
        assertTrue(data.getRowKeys().contains("Row1"));
        assertTrue(data.getColumnKeys().contains("Col1"));

        // Remove "Row2", "Col1" which should make "Col1" empty
        data.removeObject("Row2", "Col1");
        assertNull(data.getObject("Row2", "Col1"));
        assertFalse(data.getColumnKeys().contains("Col1"));
        assertTrue(data.getRowKeys().contains("Row1"));
        assertTrue(data.getRowKeys().contains("Row2"));
    }
}