package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_1_2_Test {

    @Test
    @DisplayName("metaphone word with 'CH' before consonant converts to 'K'")
    public void test_TC36() {
        Metaphone metaphone = new Metaphone();
        String txt = "church";
        String result = metaphone.metaphone(txt);
        assertEquals("KRS", result, "'CH' followed by a consonant should be converted to 'K'");
    }

    @Test
    @DisplayName("metaphone word with 'GH' at the end is silent")
    public void test_TC37() {
        Metaphone metaphone = new Metaphone();
        String txt = "light";
        String result = metaphone.metaphone(txt);
        assertEquals("LT", result, "'GH' at the end should be silent and omitted");
    }

    @Test
    @DisplayName("metaphone word with 'GH' before a consonant is silent")
    public void test_TC38() {
        Metaphone metaphone = new Metaphone();
        String txt = "ghost";
        String result = metaphone.metaphone(txt);
        assertEquals("KST", result, "'GH' followed by a consonant should be silent and omitted");
    }

    @Test
    @DisplayName("metaphone word with 'GH' before a vowel converts accordingly")
    public void test_TC39() {
        Metaphone metaphone = new Metaphone();
        String txt = "ghostly";
        String result = metaphone.metaphone(txt);
        assertEquals("KSTL", result, "'GH' before a vowel should be processed correctly");
    }

    @Test
    @DisplayName("metaphone word with 'SCI' sequence")
    public void test_TC40() {
        Metaphone metaphone = new Metaphone();
        String txt = "science";
        String result = metaphone.metaphone(txt);
        assertEquals("SNS", result, "'SCI' sequence should not convert 'C' to 'S'");
    }
}