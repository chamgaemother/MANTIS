package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_createNumber_0_3_Test {

    @Test
    @DisplayName("Input string with type suffix 'F', valid Float, should return Float")
    void TC11_createNumber_suffix_F_float() {
        // Given
        String input = "123.45F";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertInstanceOf(Float.class, result, "Result should be an instance of Float");
        assertEquals(123.45F, result.floatValue(), "Float value should match the input");
    }

    @Test
    @DisplayName("Input string with type suffix 'D', valid Double, should return Double")
    void TC12_createNumber_suffix_D_double() {
        // Given
        String input = "123.45D";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertInstanceOf(Double.class, result, "Result should be an instance of Double");
        assertEquals(123.45D, result.doubleValue(), "Double value should match the input");
    }

    @Test
    @DisplayName("Input string with multiple exponents, should throw NumberFormatException")
    void TC13_createNumber_multiple_exponents() {
        // Given
        String input = "1e2e3";

        // When & Then
        NumberFormatException exception = assertThrows(NumberFormatException.class, () -> {
            NumberUtils.createNumber(input);
        }, "Expected NumberFormatException to be thrown");
        assertEquals("1e2e3 is not a valid number.", exception.getMessage(), "Exception message should match the expected message");
    }

    @Test
    @DisplayName("Input string with decimal point and exponent, valid Double, should return Double")
    void TC14_createNumber_decimal_exponent_double() {
        // Given
        String input = "123.45e6";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertInstanceOf(Double.class, result, "Result should be an instance of Double");
        assertEquals(123.45e6, result.doubleValue(), "Double value should match the input");
    }

    @Test
    @DisplayName("Input string with decimal point only, valid Float, should return Float")
    void TC15_createNumber_decimal_float() {
        // Given
        String input = "123.45";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertInstanceOf(Float.class, result, "Result should be an instance of Float");
        assertEquals(123.45F, result.floatValue(), "Float value should match the input");
    }
}