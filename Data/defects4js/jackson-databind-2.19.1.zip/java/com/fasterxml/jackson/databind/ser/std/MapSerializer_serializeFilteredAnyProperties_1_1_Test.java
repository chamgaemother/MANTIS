package com.fasterxml.jackson.databind.ser.std;

import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.core.JsonGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class MapSerializer_serializeFilteredAnyProperties_1_1_Test {

    @Test
    @DisplayName("TC11: Suppress entry when suppressableValue != MARKER_FOR_EMPTY and value is empty")
    void TC11_suppressEntryWhenValueIsEmptyAndSuppressableValueNotMarkerForEmpty() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", ""); // Empty value

        PropertyFilter filter = mock(PropertyFilter.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        Object bean = new Object();

        // Instantiate MapSerializer with suppressableValue != MARKER_FOR_EMPTY
        JsonSerializer<Object> valueSerializer = (JsonSerializer<Object>) mock(JsonSerializer.class);
        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, valueSerializer);

        // Use reflection to set _suppressableValue
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, "customSuppress");

        // WHEN
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, "customSuppress");

        // THEN
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
    }

    @Test
    @DisplayName("TC12: Serialize entry when suppressableValue != MARKER_FOR_EMPTY and value is not empty")
    void TC12_serializeEntryWhenValueIsNotEmptyAndSuppressableValueNotMarkerForEmpty() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1"); // Non-empty value

        PropertyFilter filter = mock(PropertyFilter.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        Object bean = new Object();

        // Mock serializer behavior
        JsonSerializer<Object> mockSerializer = mock(JsonSerializer.class);
        when(mockSerializer.isEmpty(any(), eq("value1"))).thenReturn(false);

        // Instantiate MapSerializer with suppressableValue != MARKER_FOR_EMPTY and non-suppressing
        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, mockSerializer);

        // Use reflection to set _suppressableValue and _suppressNulls
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, "customSuppress");

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.setBoolean(mapSerializer, false);

        // WHEN
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, "customSuppress");

        // THEN
        verify(filter, times(1)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("TC13: Suppress entry when suppressableValue == MARKER_FOR_EMPTY and value equals MARKER_FOR_EMPTY")
    void TC13_suppressEntryWhenValueEqualsMarkerForEmptyAndSuppressableValueIsMarkerForEmpty() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", MapSerializer.MARKER_FOR_EMPTY); // Value equals MARKER_FOR_EMPTY

        PropertyFilter filter = mock(PropertyFilter.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        Object bean = new Object();

        // Instantiate MapSerializer with suppressableValue == MARKER_FOR_EMPTY
        JsonSerializer<Object> valueSerializer = (JsonSerializer<Object>) mock(JsonSerializer.class);
        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, valueSerializer);

        // Use reflection to set _suppressableValue to MARKER_FOR_EMPTY and _suppressNulls
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, MapSerializer.MARKER_FOR_EMPTY);

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.setBoolean(mapSerializer, true);

        // WHEN
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, MapSerializer.MARKER_FOR_EMPTY);

        // THEN
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
    }

    @Test
    @DisplayName("TC14: Serialize entry when suppressableValue == MARKER_FOR_EMPTY and value does not equal MARKER_FOR_EMPTY")
    void TC14_serializeEntryWhenValueDoesNotEqualMarkerForEmptyAndSuppressableValueIsMarkerForEmpty() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1"); // Value does not equal MARKER_FOR_EMPTY

        PropertyFilter filter = mock(PropertyFilter.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        JsonGenerator gen = mock(JsonGenerator.class);
        Object bean = new Object();

        // Mock serializer behavior
        JsonSerializer<Object> mockSerializer = mock(JsonSerializer.class);
        when(mockSerializer.isEmpty(any(), eq("value1"))).thenReturn(false);

        // Instantiate MapSerializer with suppressableValue == MARKER_FOR_EMPTY
        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, mockSerializer);

        // Use reflection to set _suppressableValue to MARKER_FOR_EMPTY and _suppressNulls
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, MapSerializer.MARKER_FOR_EMPTY);

        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.setBoolean(mapSerializer, false);

        // WHEN
        mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, MapSerializer.MARKER_FOR_EMPTY);

        // THEN
        verify(filter, times(1)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
    }

//     @Test
//     @DisplayName("TC15: Serialize multiple entries with some suppressed and some serialized")
//     void TC15_serializeMultipleEntriesWithSomeSuppressedAndSomeSerialized() throws Exception {
        // GIVEN
//         Map<Object, Object> value = new HashMap<>();
//         value.put("key1", "value1"); // Should be serialized
//         value.put("key2", "");// Should be suppressed
//         value.put("key3", "value3"); // Should be serialized
// 
//         PropertyFilter filter = mock(PropertyFilter.class);
//         SerializerProvider provider = mock(SerializerProvider.class);
//         JsonGenerator gen = mock(JsonGenerator.class);
//         Object bean = new Object();
// 
        // Mock serializer behavior
//         JsonSerializer<Object> mockSerializer = mock(JsonSerializer.class);
//         when(mockSerializer.isEmpty(any(), eq(""))).thenReturn(true);
//         when(mockSerializer.isEmpty(any(), eq("value1"))).thenReturn(false);
//         when(mockSerializer.isEmpty(any(), eq("value3"))).thenReturn(false);
// 
        // Instantiate MapSerializer with suppressableValue != MARKER_FOR_EMPTY and suppressNulls = true
//         MapSerializer mapSerializer = new MapSerializer(
//                 null, // ignoredEntries
//                 null, // includedEntries
//                 null, // keyType
//                 null, // valueType
//                 false, // valueTypeIsStatic
//                 null, // valueTypeSerializer
//                 null, // keySerializer
//                 mockSerializer // valueSerializer
//         );
// 
        // Use reflection to set _suppressableValue and _suppressNulls
//         Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
//         suppressableValueField.setAccessible(true);
//         suppressableValueField.set(mapSerializer, "customSuppress");
// 
//         Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
//         suppressNullsField.setAccessible(true);
//         suppressNullsField.setBoolean(mapSerializer, true);
// 
        // WHEN
//         mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, value, filter, "customSuppress");
// 
        // THEN
//         verify(filter, times(2)).serializeAsField(eq(bean), eq(gen), eq(provider), any());
//         verify(filter, never()).serializeAsField(eq(bean), eq(gen), eq(provider), eq("key2"));
//     }
}