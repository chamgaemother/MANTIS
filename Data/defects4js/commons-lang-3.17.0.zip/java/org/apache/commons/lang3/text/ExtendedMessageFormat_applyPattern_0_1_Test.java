package org.apache.commons.lang3.text;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;
import java.text.Format;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class ExtendedMessageFormat_applyPattern_0_1_Test {

    @Test
    @DisplayName("applyPattern with registry as null, ensuring super.applyPattern is invoked")
    void TC01_applyPattern_registryNull() throws Exception {
        // Arrange
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Some pattern");

        // Act
        emf.applyPattern("Some pattern");

        // Assert
        // Access the private field 'toPattern' using reflection
        Field toPatternField = ExtendedMessageFormat.class.getDeclaredField("toPattern");
        toPatternField.setAccessible(true);
        String toPattern = (String) toPatternField.get(emf);

        // Access the superclass's 'toPattern'
        String superToPattern = emf.toPattern();

        Assertions.assertEquals(superToPattern, toPattern, "toPattern should match super.toPattern");
    }

    @Test
    @DisplayName("applyPattern with registry not null and empty pattern, ensuring no loop iterations")
    void TC02_applyPattern_registryNotNull_emptyPattern() throws Exception {
        // Arrange
        Map<String, FormatFactory> registryMock = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.getDefault(), registryMock);

        // Act
        emf.applyPattern("");

        // Assert
        // Access the private field 'toPattern' using reflection
        Field toPatternField = ExtendedMessageFormat.class.getDeclaredField("toPattern");
        toPatternField.setAccessible(true);
        String toPattern = (String) toPatternField.get(emf);

        Assertions.assertEquals("", toPattern, "toPattern should be an empty string");
    }

    @Test
    @DisplayName("applyPattern with registry not null and pattern without format elements, ensuring entire pattern is processed")
    void TC03_applyPattern_registryNotNull_literalOnly() throws Exception {
        // Arrange
        Map<String, FormatFactory> registryMock = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("This is a test pattern.", Locale.getDefault(), registryMock);

        // Act
        emf.applyPattern("This is a test pattern.");

        // Assert
        // Access the private field 'toPattern' using reflection
        Field toPatternField = ExtendedMessageFormat.class.getDeclaredField("toPattern");
        toPatternField.setAccessible(true);
        String toPattern = (String) toPatternField.get(emf);

        Assertions.assertEquals("This is a test pattern.", toPattern, "toPattern should match the original pattern");
    }

    @Test
    @DisplayName("applyPattern with one format element without format description, ensuring format is null")
    void TC04_applyPattern_oneFormatElement_noDescription() throws Exception {
        // Arrange
        Map<String, FormatFactory> registryMock = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0}", Locale.getDefault(), registryMock);

        // Act
        emf.applyPattern("Value: {0}");

        // Assert
        // Access the private field 'getFormats' using reflection
        Format[] formats = emf.getFormats();

        Assertions.assertNotNull(formats, "Formats should not be null");
        Assertions.assertEquals(1, formats.length, "There should be one format");
        Assertions.assertNull(formats[0], "The format should be null");
    }

    @Test
    @DisplayName("applyPattern with one format element with valid format description, ensuring format is set")
    void TC05_applyPattern_oneFormatElement_withDescription() throws Exception {
        // Arrange
        Map<String, FormatFactory> registryMock = new HashMap<>();
        FormatFactory formatFactory = (name, args, locale) -> null; // Substitute with proper Format
        registryMock.put("date", formatFactory);

        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,date}", Locale.getDefault(), registryMock);

        // Act
        emf.applyPattern("Value: {0,date}");

        // Assert
        // Access the private field 'getFormats' using reflection
        Format[] formats = emf.getFormats();

        Assertions.assertNotNull(formats, "Formats should not be null");
        Assertions.assertEquals(1, formats.length, "There should be one format");
    }
}