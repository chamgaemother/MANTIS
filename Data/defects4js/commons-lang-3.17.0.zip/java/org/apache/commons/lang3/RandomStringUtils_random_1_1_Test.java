package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.RandomStringUtils;
import java.util.Random;

public class RandomStringUtils_random_1_1_Test {

    @Test
    @DisplayName("random(count, start, end, letters=true, numbers=false, chars non-alphanumerical, random) generates string with only letters from provided chars")
    public void testTC36() {
        // GIVEN
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = {'a', '1', '@', 'b', '!', 'c'};
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(5, result.length(), "The length of the result should be 5.");
        for(char c : result.toCharArray()) {
            assertTrue(new String(chars).indexOf(c) >= 0 && Character.isLetter(c),
                "Character " + c + " is not a letter from the provided chars array");
        }
    }

    @Test
    @DisplayName("random(count, start, end, letters=false, numbers=true, chars non-numeric, random) generates string with only numbers from provided chars")
    public void testTC37() {
        // GIVEN
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = {'1', 'a', '#', '2', '!', '3'};
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(5, result.length(), "The length of the result should be 5.");
        for(char c : result.toCharArray()) {
            assertTrue(new String(chars).indexOf(c) >= 0 && Character.isDigit(c),
                "Character " + c + " is not a digit from the provided chars array");
        }
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=null, random) generates alphanumerical string with boundary character values")
    public void testTC38() {
        // GIVEN
        int count = 10;
        int start = '0'; // 48
        int end = 'z' + 1; // 123
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(10, result.length(), "The length of the result should be 10.");
        assertTrue(result.chars().allMatch(c -> (Character.isLetterOrDigit(c) && c >= '0' && c < 'z' + 1)),
            "All characters should be letters or digits within the specified range");
    }

    @Test
    @DisplayName("random(count, start=65, end=91, letters=true, numbers=false, chars=null, random) generates string with uppercase letters")
    public void testTC39() {
        // GIVEN
        int count = 7;
        int start = 'A'; // 65
        int end = 'Z' + 1; // 91
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(7, result.length(), "The length of the result should be 7.");
        assertTrue(result.chars().allMatch(c -> Character.isUpperCase(c) && c >= 'A' && c < 'Z' + 1),
            "All characters should be uppercase letters between 'A' and 'Z'");
    }
}