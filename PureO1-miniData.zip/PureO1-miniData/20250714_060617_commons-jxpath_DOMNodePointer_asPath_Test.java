package org.apache.commons.jxpath.ri.model.dom;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.jxpath.JXPathContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

class DOMNodePointerTest {

    private Document document;
    private Element root;
    private Element child1;
    private Element child2;
    private Text textNode;
    private CDATASection cdataSection;
    private ProcessingInstruction pi;
    private Comment comment;
    private Element nsElement;
    private Document docWithNamespace;

    @BeforeEach
    void setUp() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        document = builder.newDocument();
        root = document.createElement("root");
        document.appendChild(root);

        child1 = document.createElement("child");
        child1.setAttribute("id", "child1");
        root.appendChild(child1);

        child2 = document.createElement("child");
        root.appendChild(child2);

        textNode = document.createTextNode("Sample text");
        child1.appendChild(textNode);

        cdataSection = document.createCDATASection("Sample CDATA");
        child1.appendChild(cdataSection);

        pi = document.createProcessingInstruction("target", "data");
        root.appendChild(pi);

        comment = document.createComment("Sample comment");
        root.appendChild(comment);

        docWithNamespace = builder.newDocument();
        nsElement = docWithNamespace.createElementNS("http://example.com/ns", "ns:element");
        docWithNamespace.appendChild(nsElement);
    }

    @Test
    void testAsPath_ElementWithId() {
        DOMNodePointer pointer = new DOMNodePointer(child1, Locale.ENGLISH, "child1");
        String path = pointer.asPath();
        assertEquals("id('child1')", path);
    }

    @Test
    void testAsPath_RootElement() {
        DOMNodePointer pointer = new DOMNodePointer(root, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root[1]", path);
    }

    @Test
    void testAsPath_ElementWithoutNamespace() {
        DOMNodePointer pointer = new DOMNodePointer(child2, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/child[2]", path);
    }

    @Test
    void testAsPath_ElementWithNamespace() {
        DOMNodePointer pointer = new DOMNodePointer(nsElement, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/ns:element[1]", path);
    }

    @Test
    void testAsPath_TextNode() {
        DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/child[1]/text()[1]", path);
    }

    @Test
    void testAsPath_CDATASectionNode() {
        DOMNodePointer pointer = new DOMNodePointer(cdataSection, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/child[1]/text()[2]", path);
    }

    @Test
    void testAsPath_ProcessingInstructionNode() {
        DOMNodePointer pointer = new DOMNodePointer(pi, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/processing-instruction('target')[1]", path);
    }

    @Test
    void testAsPath_CommentNode() {
        DOMNodePointer pointer = new DOMNodePointer(comment, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("", path); // Comments are not handled specifically, returns empty or default path
    }

    @Test
    void testAsPath_DocumentNode() {
        DOMNodePointer pointer = new DOMNodePointer(document, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("", path); // Document node path is empty
    }

    @Test
    void testAsPath_ElementWithMultipleSiblings() throws Exception {
        Element sibling1 = document.createElement("child");
        root.appendChild(sibling1);
        Element sibling2 = document.createElement("child");
        root.appendChild(sibling2);
        DOMNodePointer pointer = new DOMNodePointer(sibling2, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/child[3]", path);
    }

    @Test
    void testAsPath_NamespaceElementWithPrefix() {
        DOMNodePointer pointer = new DOMNodePointer(nsElement, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/ns:element[1]", path);
    }

    @Test
    void testAsPath_ElementWithParentNotDOMNodePointer() throws Exception {
        // Create a wrapper node that is not a DOMNodePointer
        Element parent = document.createElement("parent");
        root.appendChild(parent);
        Element child = document.createElement("child");
        parent.appendChild(child);
        DOMNodePointer parentPointer = new DOMNodePointer(parent, Locale.ENGLISH);
        DOMNodePointer childPointer = new DOMNodePointer(parentPointer, child);
        String path = childPointer.asPath();
        assertEquals("/parent[1]/child[1]", path);
    }

    @Test
    void testAsPath_ElementWithNamespaceAndMultipleNamespaces() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.newDocument();
        Element rootNs = doc.createElementNS("http://example.com/root", "root");
        doc.appendChild(rootNs);
        Element childNs1 = doc.createElementNS("http://example.com/ns1", "ns1:child");
        rootNs.appendChild(childNs1);
        Element childNs2 = doc.createElementNS("http://example.com/ns1", "ns1:child");
        rootNs.appendChild(childNs2);
        DOMNodePointer pointer = new DOMNodePointer(childNs2, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root[1]/ns1:child[2]", path);
    }

    @Test
    void testAsPath_ElementWithUnknownNamespace() throws Exception {
        Element unknownNsElement = document.createElementNS("", "unknown");
        root.appendChild(unknownNsElement);
        DOMNodePointer pointer = new DOMNodePointer(unknownNsElement, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/unknown[1]", path);
    }

    @Test
    void testAsPath_TextNodeWithMultipleTexts() {
        Text text1 = document.createTextNode("First text");
        child1.appendChild(text1);
        Text text2 = document.createTextNode("Second text");
        child1.appendChild(text2);
        DOMNodePointer pointer = new DOMNodePointer(text2, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/child[1]/text()[3]", path);
    }

    @Test
    void testAsPath_ProcessingInstructionMultiple() throws Exception {
        ProcessingInstruction pi1 = document.createProcessingInstruction("target", "data1");
        ProcessingInstruction pi2 = document.createProcessingInstruction("target", "data2");
        root.appendChild(pi1);
        root.appendChild(pi2);
        DOMNodePointer pointer = new DOMNodePointer(pi2, Locale.ENGLISH);
        String path = pointer.asPath();
        assertEquals("/root/processing-instruction('target')[2]", path);
    }
}