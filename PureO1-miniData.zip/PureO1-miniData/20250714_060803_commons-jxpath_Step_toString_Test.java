package org.apache.commons.jxpath.ri.compiler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.compiler.Expression;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class StepTest {

    @Test
    public void testToString_AxisChild_NoPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("node");
        Step step = new Step(Compiler.AXIS_CHILD, nodeTest, null);
        assertEquals("node", step.toString());
    }

    @Test
    public void testToString_AxisChild_WithPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("node");
        Expression predicate1 = mock(Expression.class);
        when(predicate1.toString()).thenReturn("predicate1");
        Expression predicate2 = mock(Expression.class);
        when(predicate2.toString()).thenReturn("predicate2");
        Step step = new Step(Compiler.AXIS_CHILD, nodeTest, new Expression[]{predicate1, predicate2});
        assertEquals("node[predicate1][predicate2]", step.toString());
    }

    @Test
    public void testToString_AxisAttribute_NoPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("attr");
        Step step = new Step(Compiler.AXIS_ATTRIBUTE, nodeTest, null);
        assertEquals("@attr", step.toString());
    }

    @Test
    public void testToString_AxisAttribute_WithPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("attr");
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_ATTRIBUTE, nodeTest, new Expression[]{predicate});
        assertEquals("@attr[predicate]", step.toString());
    }

    @Test
    public void testToString_AxisSelf_NodeTypeTest_NoPredicates() {
        NodeTypeTest nodeTest = mock(NodeTypeTest.class);
        when(nodeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Step step = new Step(Compiler.AXIS_SELF, nodeTest, null);
        assertEquals(".", step.toString());
    }

    @Test
    public void testToString_AxisSelf_NodeTypeTest_WithPredicates() {
        NodeTypeTest nodeTest = mock(NodeTypeTest.class);
        when(nodeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_SELF, nodeTest, new Expression[]{predicate});
        assertEquals(".[predicate]", step.toString());
    }

    @Test
    public void testToString_AxisParent_NodeTypeTest_NoPredicates() {
        NodeTypeTest nodeTest = mock(NodeTypeTest.class);
        when(nodeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Step step = new Step(Compiler.AXIS_PARENT, nodeTest, null);
        assertEquals("..", step.toString());
    }

    @Test
    public void testToString_AxisParent_NodeTypeTest_WithPredicates() {
        NodeTypeTest nodeTest = mock(NodeTypeTest.class);
        when(nodeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_PARENT, nodeTest, new Expression[]{predicate});
        assertEquals("..[predicate]", step.toString());
    }

    @Test
    public void testToString_AxisDescendantOrSelf_NodeTypeTest_NoPredicates() {
        NodeTypeTest nodeTest = mock(NodeTypeTest.class);
        when(nodeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Step step = new Step(Compiler.AXIS_DESCENDANT_OR_SELF, nodeTest, null);
        assertEquals("", step.toString());
    }

    @Test
    public void testToString_AxisDescendantOrSelf_NodeTypeTest_WithPredicates() {
        NodeTypeTest nodeTest = mock(NodeTypeTest.class);
        when(nodeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_DESCENDANT_OR_SELF, nodeTest, new Expression[]{predicate});
        assertEquals("descendant-or-self::node[predicate]", step.toString());
    }

    @Test
    public void testToString_Default_AxisWithUnknownAxis_NoPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("unknown");
        Step step = new Step(999, nodeTest, null);
        assertEquals("UNKNOWN::unknown", step.toString());
    }

    @Test
    public void testToString_Default_AxisWithUnknownAxis_WithPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("unknown");
        Expression predicate1 = mock(Expression.class);
        when(predicate1.toString()).thenReturn("predicate1");
        Expression predicate2 = mock(Expression.class);
        when(predicate2.toString()).thenReturn("predicate2");
        Step step = new Step(999, nodeTest, new Expression[]{predicate1, predicate2});
        assertEquals("UNKNOWN::unknown[predicate1][predicate2]", step.toString());
    }

    @Test
    public void testToString_AxisSelf_NotNodeTypeTest_NoPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("customNode");
        Step step = new Step(Compiler.AXIS_SELF, nodeTest, null);
        assertEquals("self::customNode", step.toString());
    }

    @Test
    public void testToString_AxisSelf_NotNodeTypeTest_WithPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("customNode");
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_SELF, nodeTest, new Expression[]{predicate});
        assertEquals("self::customNode[predicate]", step.toString());
    }

    @Test
    public void testToString_AxisParent_NotNodeTypeTest_NoPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("customParent");
        Step step = new Step(Compiler.AXIS_PARENT, nodeTest, null);
        assertEquals("parent::customParent", step.toString());
    }

    @Test
    public void testToString_AxisParent_NotNodeTypeTest_WithPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("customParent");
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_PARENT, nodeTest, new Expression[]{predicate});
        assertEquals("parent::customParent[predicate]", step.toString());
    }

    @Test
    public void testToString_AxisDescendantOrSelf_NotNodeTypeTest_WithPredicates() {
        NodeTest nodeTest = mock(NodeTest.class);
        when(nodeTest.toString()).thenReturn("descendant");
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_DESCENDANT_OR_SELF, nodeTest, new Expression[]{predicate});
        assertEquals("descendant-or-self::descendant[predicate]", step.toString());
    }

    @Test
    public void testToString_AxisUnknown_NodeTestNull_NoPredicates() {
        Step step = new Step(999, null, null);
        assertEquals("UNKNOWN::null", step.toString());
    }

    @Test
    public void testToString_AxisChild_NodeTestNull_WithPredicates() {
        Expression predicate = mock(Expression.class);
        when(predicate.toString()).thenReturn("predicate");
        Step step = new Step(Compiler.AXIS_CHILD, null, new Expression[]{predicate});
        assertEquals("null[predicate]", step.toString());
    }
}