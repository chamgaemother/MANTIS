package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_1_Test {

    @Test
    @DisplayName("doubleMetaphone(null, false) returns null when input is null")
    void TC01_doubleMetaphone_null_input() throws Exception {
        // Given
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = null;

        // When
        String result = encoder.doubleMetaphone(input, false);

        // Then
        assertNull(result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"\", false) returns null when input is empty string")
    void TC02_doubleMetaphone_empty_string() throws Exception {
        // Given
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "";

        // When
        String result = encoder.doubleMetaphone(input, false);

        // Then
        assertNull(result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"KNIGHT\", false) handles silent prefix 'KN'")
    void TC03_doubleMetaphone_silent_prefix_KN() throws Exception {
        // Given
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "KNIGHT";
        String expected = "NHT"; // Expected metaphone value for "KNIGHT"

        // When
        String result = encoder.doubleMetaphone(input, false);

        // Then
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"GNOME\", false) handles silent prefix 'GN'")
    void TC04_doubleMetaphone_silent_prefix_GN() throws Exception {
        // Given
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GNOME";
        String expected = "NMM"; // Expected metaphone value for "GNOME"

        // When
        String result = encoder.doubleMetaphone(input, false);

        // Then
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"PSYCHO\", false) handles silent prefix 'PS'")
    void TC05_doubleMetaphone_silent_prefix_PS() throws Exception {
        // Given
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "PSYCHO";
        String expected = "SK0"; // Expected metaphone value for "PSYCHO"

        // When
        String result = encoder.doubleMetaphone(input, false);

        // Then
        assertEquals(expected, result);
    }

}