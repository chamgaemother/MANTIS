package com.fasterxml.jackson.core.io;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.io.NumberInput;

public class NumberInput_parseInt_0_3_Test {

    @Test
    @DisplayName("parseInt with null string throws NullPointerException")
    void TC11() {
        String s = null;
        assertThrows(NullPointerException.class, () -> NumberInput.parseInt(s));
    }

    @Test
    @DisplayName("parseInt with leading zeros")
    void TC12() {
        String s = "000123";
        int result = NumberInput.parseInt(s);
        assertEquals(123, result);
    }

    @Test
    @DisplayName("parseInt with maximum integer value")
    void TC13() {
        String s = "2147483647";
        int result = NumberInput.parseInt(s);
        assertEquals(Integer.MAX_VALUE, result);
    }

    @Test
    @DisplayName("parseInt with minimum integer value")
    void TC14() {
        String s = "-2147483648";
        int result = NumberInput.parseInt(s);
        assertEquals(Integer.MIN_VALUE, result);
    }

    @Test
    @DisplayName("parseInt with zero")
    void TC15() {
        String s = "0";
        int result = NumberInput.parseInt(s);
        assertEquals(0, result);
    }
}