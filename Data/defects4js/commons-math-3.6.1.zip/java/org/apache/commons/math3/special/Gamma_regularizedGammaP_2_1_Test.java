package org.apache.commons.math3.special;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Gamma_regularizedGammaP_2_1_Test {

    @Test
    @DisplayName("regularizedGammaP with a = 1.0 and x = 1.0 verifies correct computation via series")
    void TC17() {
        // GIVEN
        double a = 1.0;
        double x = 1.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        double expected = 0.6321205588285577;
        assertEquals(expected, result, 1e-10, "regularizedGammaP(1.0, 1.0) should be approximately 0.6321205588");
    }

    @Test
    @DisplayName("regularizedGammaP with a = 0.5 and x = 0.4 tests series convergence with a < 1")
    void TC18() {
        // GIVEN
        double a = 0.5;
        double x = 0.4;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        double expected = 0.329340387; // Known value
        assertEquals(expected, result, 1e-9, "regularizedGammaP(0.5, 0.4) should be approximately 0.329340387");
    }

    @Test
    @DisplayName("regularizedGammaP with a = 10.0 and x = 5.0 verifies computation for larger a and x < a + 1")
    void TC19() {
        // GIVEN
        double a = 10.0;
        double x = 5.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        double expected = 0.022810373; // Known value
        assertEquals(expected, result, 1e-9, "regularizedGammaP(10.0, 5.0) should be approximately 0.022810373");
    }

    @Test
    @DisplayName("regularizedGammaP with a = 2.0 and x = 1.5 tests intermediate values within series convergence")
    void TC20() {
        // GIVEN
        double a = 2.0;
        double x = 1.5;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        double expected = 0.559506429; // Known value
        assertEquals(expected, result, 1e-9, "regularizedGammaP(2.0, 1.5) should be approximately 0.559506429");
    }

    @Test
    @DisplayName("regularizedGammaP with a = 1e-10 and x approaching 0 tests behavior near lower boundaries")
    void TC21() {
        // GIVEN
        double a = 1e-10;
        double x = 1e-10;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        double expected = 1.0;
        assertEquals(expected, result, 1e-9, "regularizedGammaP(1e-10, 1e-10) should approach 1.0");
    }
}