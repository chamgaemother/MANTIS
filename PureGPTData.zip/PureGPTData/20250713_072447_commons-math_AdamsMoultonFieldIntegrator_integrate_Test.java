import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
import java.util.Arrays;
import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.ode.FieldExpandableODE;
import org.apache.commons.math3.ode.FieldODEState;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.apache.commons.math3.ode.nonstiff.AdamsMoultonFieldIntegrator;
import org.apache.commons.math3.ode.AbstractFieldIntegrator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.apache.commons.math3.linear.Array2DRowFieldMatrix;
import org.mockito.Mockito;

class AdamsMoultonFieldIntegratorTest {

    private DfpField dfpField;
    private Dfp[] emptyArray;
    
    @BeforeEach
    void setUp() {
        dfpField = new DfpField(20);
        emptyArray = new Dfp[0];
    }

    @Test
    void testIntegrateNullEquations() {
        AdamsMoultonFieldIntegrator<Dfp> integrator = 
            new AdamsMoultonFieldIntegrator<>(dfpField, 3, 0.1, 1.0, 1e-4, 1e-4);
        FieldODEState<Dfp> initialState = new FieldODEState<>(dfpField.newDfp(0.0), emptyArray);

        assertThrows(NullPointerException.class, () -> 
            integrator.integrate(null, initialState, dfpField.newDfp(1.0)));
    }

    @Test
    void testIntegrateNullInitialState() {
        AdamsMoultonFieldIntegrator<Dfp> integrator = 
            new AdamsMoultonFieldIntegrator<>(dfpField, 3, 0.1, 1.0, 1e-4, 1e-4);
        FieldExpandableODE<Dfp> equationsMock = mock(FieldExpandableODE.class);

        assertThrows(NullPointerException.class, () -> 
            integrator.integrate(equationsMock, null, dfpField.newDfp(1.0)));
    }

    @Test
    void testIntegrateZeroSteps() {
        assertThrows(NumberIsTooSmallException.class, () -> 
            new AdamsMoultonFieldIntegrator<>(dfpField, 1, 0.1, 1.0, 1e-4, 1e-4));
    }

    @ParameterizedTest
    @CsvSource({
        "1.0, 10.0, 5.0, forward",
        "-1.0, -10.0, -5.0, backward"
    })
    void testIntegrateValidForwardAndBackward(double initialTime, double finalTime, double stepSize, String direction) throws Exception {
        AdamsMoultonFieldIntegrator<Dfp> integrator = 
            new AdamsMoultonFieldIntegrator<>(dfpField, 3, 0.1, 1.0, 1e-4, 1e-4);
        FieldExpandableODE<Dfp> equationsMock = mock(FieldExpandableODE.class);
        FieldODEState<Dfp> initialState = new FieldODEState<>(dfpField.newDfp(initialTime), emptyArray);
        when(equationsMock.getMapper()).thenReturn(new AbstractFieldIntegrator.DummyFieldStateMapper<>());
        when(equationsMock.getPrimaryMapper()).thenReturn(new AbstractFieldIntegrator.DummyFieldStateMapper<>());
        
        Dfp[] yDotArray = Arrays.stream(new double[]{0.1, 0.2, 0.3})
                                .mapToObj(dfpField::newDfp)
                                .toArray(Dfp[]::new);
        doReturn(yDotArray).when(equationsMock).computeDerivatives(any(), any());
        
        integrator.integrate(equationsMock, initialState, dfpField.newDfp(finalTime));
        
        verify(equationsMock, atLeastOnce()).computeDerivatives(any(), any());
    }

    @Test
    void testIntegrateStepRejection() throws NumberIsTooSmallException, DimensionMismatchException, MaxCountExceededException, NoBracketingException {
        AdamsMoultonFieldIntegrator<Dfp> integrator = 
            new AdamsMoultonFieldIntegrator<>(dfpField, 3, 0.1, 1.0, 1e-4, 1e-4);
        Dfp initialTime = dfpField.newDfp(0.0);
        Dfp finalTime = dfpField.newDfp(2.0);
        Dfp stepSize = dfpField.newDfp(0.5);
        
        FieldExpandableODE<Dfp> equationsMock = mock(FieldExpandableODE.class);
        FieldODEState<Dfp> initialStateMock = mock(FieldODEState.class);
        when(initialStateMock.getTime()).thenReturn(initialTime);
        when(initialStateMock.getPrimaryState()).thenReturn(emptyArray);
        when(equationsMock.getMapper()).thenReturn(new AbstractFieldIntegrator.DummyFieldStateMapper<>());
        when(equationsMock.getPrimaryMapper()).thenReturn(new AbstractFieldIntegrator.DummyFieldStateMapper<>());
        Dfp[] yDotArray = Arrays.stream(new double[]{5.0, -5.0, 0.0})
                                .mapToObj(dfpField::newDfp)
                                .toArray(Dfp[]::new);
        doReturn(yDotArray).when(equationsMock).computeDerivatives(any(), any());
        
        FieldODEStateAndDerivative<Dfp> result = integrator.integrate(equationsMock, initialStateMock, finalTime);
        
        assertTrue(finalTime.subtract(result.getTime()).abs().getReal() < 1e-3, "Final time not reached within error margins.");
    }
}