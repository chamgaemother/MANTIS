package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// 
// import org.apache.commons.math3.exception.CardanEulerSingularityException;
// import org.apache.commons.math3.util.Decimal64;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import static org.junit.jupiter.api.Assertions.*;
// 
public class FieldRotation_getAngles_1_3_Test {
// 
//     @Test
//     @DisplayName("getAngles called with RotationOrder.YXY and RotationConvention.FRAME_TRANSFORM on Identity Quaternion")
//     void TC36() {
        // GIVEN
//         RotationOrder order = RotationOrder.YXY;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
        // Correct setup for identity quaternion
//         Decimal64 q0 = new Decimal64(1.0); // Identity quaternion
//         Decimal64 q1 = new Decimal64(0.0);
//         Decimal64 q2 = new Decimal64(0.0);
//         Decimal64 q3 = new Decimal64(0.0);
// 
//         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// 
        // WHEN
//         Decimal64[] angles = rotation.getAngles(order, convention);
// 
        // THEN
//         assertNotNull(angles, "Angles should not be null");
//         assertEquals(3, angles.length, "Angles array should have length 3");
// 
        // For an identity rotation, all angles should be 0
//         assertEquals(Decimal64.ZERO, angles[0], "First angle should be 0");
//         assertEquals(Decimal64.ZERO, angles[1], "Second angle should be 0");
//         assertEquals(Decimal64.ZERO, angles[2], "Third angle should be 0");
//     }
// 
//     @Test
//     @DisplayName("getAngles called with RotationOrder.YXY and RotationConvention.FRAME_TRANSFORM causing Singularity Exception")
//     void TC37() {
        // GIVEN
//         RotationOrder order = RotationOrder.YXY;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
        // Initialize FieldRotation with parameters that cause singularity (invalid quaternion state)
//         Decimal64 q0 = new Decimal64(0.0);
//         Decimal64 q1 = new Decimal64(1.0);
//         Decimal64 q2 = new Decimal64(0.0);
//         Decimal64 q3 = new Decimal64(0.0);
//         FieldRotation<Decimal64> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// 
        // WHEN + THEN
//         assertThrows(CardanEulerSingularityException.class, () -> {
//             rotation.getAngles(order, convention);
//         }, "CardanEulerSingularityException should be thrown when v2.getY() is out of bounds");
//     }
// }
}