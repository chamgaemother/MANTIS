package org.jfree.chart.renderer.xy;
import java.io.*;
import java.util.*;

import java.lang.reflect.*;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class ClusteredXYBarRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem centers bar at start value when centerBarAtStartValue is true")
    void testTC06_drawItem_centerBarAtStartValue_true() throws Exception {
        // GIVEN
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
        // Accessing private field through reflection
        setFieldViaReflection(renderer, "centerBarAtStartValue", true);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class); // Changed to IntervalXYDataset
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Configure mocks
        when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(20.0);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(5.0); // Added for mock
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(15.0); // Added for mock
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(30.0); // Added for mock

        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Execute drawItem
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        // THEN
        // Verify expectations (Added verification for overall testing process instead of removed imports)
        verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
    }

    // Helper method to set private fields via reflection
    private void setFieldViaReflection(Object target, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}