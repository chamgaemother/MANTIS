package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.QRDecomposition;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for AdamsNordsieckTransformer.initializeHighOrderDerivatives method.
 */
public class AdamsNordsieckTransformer_initializeHighOrderDerivatives_1_1_Test {

    @Test
    @DisplayName("Initialize with h negative, verifying correct handling of negative step size")
    void test_TC16() {
        // GIVEN
        double h = -0.1;
        double[] t = {0.0, -0.1};
        double[][] y = { {1.0, 2.0} };
        double[][] yDot = { {0.5, 1.0} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(1);

        // WHEN
        Array2DRowRealMatrix result = transformer.initializeHighOrderDerivatives(h, t, y, yDot);

        // THEN
        assertNotNull(result, "Nordsieck vector should be initialized correctly with negative h.");
        // Additional assertions can be added here to verify the correctness of the scaled derivatives
    }

    @Test
    @DisplayName("Initialize with null time array t, expecting NullPointerException")
    void test_TC17() {
        // GIVEN
        double h = 0.1;
        double[] t = null;
        double[][] y = { {1.0, 2.0} };
        double[][] yDot = { {0.5, 1.0} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(1);

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected NullPointerException when time array t is null");
    }

    @Test
    @DisplayName("Initialize with null state array y, expecting NullPointerException")
    void test_TC18() {
        // GIVEN
        double h = 0.1;
        double[] t = {0.0, 0.1};
        double[][] y = null;
        double[][] yDot = { {0.5, 1.0} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(1);

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected NullPointerException when state array y is null");
    }

    @Test
    @DisplayName("Initialize with null derivative array yDot, expecting NullPointerException")
    void test_TC19() {
        // GIVEN
        double h = 0.1;
        double[] t = {0.0, 0.1};
        double[][] y = { {1.0, 2.0} };
        double[][] yDot = null;
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(1);

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected NullPointerException when derivative array yDot is null");
    }

    @Test
    @DisplayName("Initialize with inconsistent lengths of t and y arrays, expecting ArrayIndexOutOfBoundsException")
    void test_TC20() {
        // GIVEN
        double h = 0.1;
        double[] t = {0.0};
        double[][] y = { {1.0, 2.0}, {1.1, 2.1} };
        double[][] yDot = { {0.5, 1.0}, {0.55, 1.05} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(2);

        // WHEN & THEN
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            transformer.initializeHighOrderDerivatives(h, t, y, yDot);
        }, "Expected ArrayIndexOutOfBoundsException when lengths of t and y arrays are inconsistent");
    }
}