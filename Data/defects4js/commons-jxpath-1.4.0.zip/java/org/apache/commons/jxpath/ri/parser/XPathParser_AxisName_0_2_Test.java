package org.apache.commons.jxpath.ri.parser;

import org.apache.commons.jxpath.ri.Compiler;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class XPathParser_AxisName_0_2_Test {

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_NAMESPACE returns Compiler.AXIS_NAMESPACE")
    public void TC06() throws Exception {
        // Initialize XPathParser with a Reader to resolve the constructor error
        XPathParser parser = new XPathParser(new java.io.StringReader(""));

        // Access and set the 'jj_nt' field
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        // Access and set the 'kind' field within 'jj_nt'
        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParserConstants.AXIS_NAMESPACE);

        // Invoke AxisName
        int axis = parser.AxisName();

        // Assert the result
        assertEquals(Compiler.AXIS_NAMESPACE, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_PRECEDING returns Compiler.AXIS_PRECEDING")
    public void TC07() throws Exception {
        // Initialize XPathParser with a Reader to resolve the constructor error
        XPathParser parser = new XPathParser(new java.io.StringReader(""));

        // Access and set the 'jj_nt' field
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        // Access and set the 'kind' field within 'jj_nt'
        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParserConstants.AXIS_PRECEDING);

        // Invoke AxisName
        int axis = parser.AxisName();

        // Assert the result
        assertEquals(Compiler.AXIS_PRECEDING, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_FOLLOWING returns Compiler.AXIS_FOLLOWING")
    public void TC08() throws Exception {
        // Initialize XPathParser with a Reader to resolve the constructor error
        XPathParser parser = new XPathParser(new java.io.StringReader(""));

        // Access and set the 'jj_nt' field
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        // Access and set the 'kind' field within 'jj_nt'
        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParserConstants.AXIS_FOLLOWING);

        // Invoke AxisName
        int axis = parser.AxisName();

        // Assert the result
        assertEquals(Compiler.AXIS_FOLLOWING, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_DESCENDANT returns Compiler.AXIS_DESCENDANT")
    public void TC09() throws Exception {
        // Initialize XPathParser with a Reader to resolve the constructor error
        XPathParser parser = new XPathParser(new java.io.StringReader(""));

        // Access and set the 'jj_nt' field
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        // Access and set the 'kind' field within 'jj_nt'
        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParserConstants.AXIS_DESCENDANT);

        // Invoke AxisName
        int axis = parser.AxisName();

        // Assert the result
        assertEquals(Compiler.AXIS_DESCENDANT, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_ANCESTOR_OR_SELF returns Compiler.AXIS_ANCESTOR_OR_SELF")
    public void TC10() throws Exception {
        // Initialize XPathParser with a Reader to resolve the constructor error
        XPathParser parser = new XPathParser(new java.io.StringReader(""));

        // Access and set the 'jj_nt' field
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        // Access and set the 'kind' field within 'jj_nt'
        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParserConstants.AXIS_ANCESTOR_OR_SELF);

        // Invoke AxisName
        int axis = parser.AxisName();

        // Assert the result
        assertEquals(Compiler.AXIS_ANCESTOR_OR_SELF, axis);
    }
}