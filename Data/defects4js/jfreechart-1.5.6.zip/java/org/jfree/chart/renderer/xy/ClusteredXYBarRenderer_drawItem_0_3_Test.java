package org.jfree.chart.renderer.xy;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ClusteredXYBarRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem handles zero visible series in the dataset")
    public void TC11_drawItem_with_zero_visible_series() throws Exception {
        // Arrange
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(0); // No visible series

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, mock(ValueAxis.class),
                          mock(ValueAxis.class), dataset, 0, 0, crosshairState, 1);

        // Assert
        // Verify that no painting methods are called since no series are visible
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("drawItem throws IllegalStateException for unsupported orientation")
    public void TC12_drawItem_with_unsupported_orientation() throws Exception {
        // Arrange
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();

        XYPlot plot = mock(XYPlot.class);
        // Mock 'XYPlot.getOrientation()' to return 'null' will still throw IllegalStateException
        doReturn(null).when(plot).getOrientation(); // Correct approach for unsupported orientation

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYDataset dataset = mock(XYDataset.class);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Act & Assert
        assertThrows(IllegalStateException.class, () ->
            renderer.drawItem(g2, state, dataArea, info, plot, mock(ValueAxis.class),
                              mock(ValueAxis.class), dataset, 0, 0, crosshairState, 1)
        );
    }

    @Test
    @DisplayName("drawItem processes item with orientation HORIZONTAL")
    public void TC13_drawItem_with_HORIZONTAL_orientation() throws Exception {
        // Arrange
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // Act
        renderer.drawItem(g2, state, new Rectangle2D.Double(0, 0, 100, 100), info, plot,
                mock(ValueAxis.class), mock(ValueAxis.class), dataset, 0, 0, crosshairState, 1);

        // Assert
        // Verify that paintBar is called with correct parameters
        verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem processes item with orientation VERTICAL")
    public void TC14_drawItem_with_VERTICAL_orientation() throws Exception {
        // Arrange
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(3);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // Act
        renderer.drawItem(g2, state, new Rectangle2D.Double(0, 0, 100, 100), info, plot,
                mock(ValueAxis.class), mock(ValueAxis.class), dataset, 0, 0, crosshairState, 1);

        // Assert
        // Verify that paintBar is called with correct parameters
        verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles getShadowsVisible true and pass is 0")
    public void TC15_drawItem_with_shadows_visible_and_pass_0() throws Exception {
        // Arrange
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
        ClusteredXYBarRenderer rendererSpy = spy(renderer);

        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // Act
        rendererSpy.drawItem(g2, state, new Rectangle2D.Double(0, 0, 100, 100), info, plot,
                mock(ValueAxis.class), mock(ValueAxis.class), dataset, 0, 0, crosshairState, 0);

        // Assert
        // Verify that paint method is invoked using graphics context
        verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
    }
}