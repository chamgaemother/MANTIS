package org.apache.commons.codec.digest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class Md5CryptTest {

    @Test
    void testMd5Crypt_NullSalt() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String result = Md5Crypt.md5Crypt(keyBytes, null, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith(prefix));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_ValidSaltWithPrefix() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String salt = "$1$salt1234";
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith("$1$salt1234$"));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_ValidSaltWithDifferentPrefix() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$apr1$";
        String salt = "$apr1$salt5678";
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith("$apr1$salt5678$"));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_SaltWithoutPrefix() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String salt = "salt1234";
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith("$1$salt1234$"));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_InvalidSalt_NoPrefix() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String salt = "invalidSalt";
        String invalidSalt = "invalidSalt";
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, invalidSalt, prefix);
        });
        assertTrue(exception.getMessage().contains("Invalid salt value"));
    }

    @Test
    void testMd5Crypt_InvalidSalt_WrongPattern() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String salt = "$1$invalid_salt!";
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        });
        assertTrue(exception.getMessage().contains("Invalid salt value"));
    }

    @Test
    void testMd5Crypt_EmptyKey() {
        byte[] keyBytes = new byte[0];
        String prefix = "$1$";
        String salt = "$1$salt1234";
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith("$1$salt1234$"));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_MaxSaltLength() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String salt = "$1$12345678";
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith("$1$12345678$"));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_SaltLongerThan8() {
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String salt = "$1$1234567890";
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith("$1$12345678$"));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_NullKeyBytes() {
        byte[] keyBytes = null;
        String prefix = "$1$";
        String salt = "$1$salt1234";
        assertThrows(NullPointerException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        });
    }

    @ParameterizedTest
    @ValueSource(strings = {"$1$salt1234", "$apr1$salt5678", "$1$abcdefg", "$apr1$ABCDEFG"})
    void testMd5Crypt_VariousValidSalts(String salt) {
        byte[] keyBytes = "password".getBytes();
        String prefix = salt.startsWith("$apr1$") ? "$apr1$" : "$1$";
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith(prefix + salt.substring(prefix.length(), prefix.length() + 8) + "$"));
        assertEquals(34, result.length());
    }

    @Test
    void testMd5Crypt_AllBranchesCovered() {
        // This test is to ensure that all branches are executed.
        byte[] keyBytes = "password".getBytes();
        String prefix = "$1$";
        String salt = "$1$salt1234";

        // Since branches inside loops are difficult to cover individually,
        // this test ensures the method executes fully without exceptions.
        String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(result);
        assertTrue(result.startsWith("$1$salt1234$"));
        assertEquals(34, result.length());
    }
}