package org.apache.commons.math3.optim.nonlinear.scalar.noderiv;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optim.PointValuePair;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Comparator;
import org.mockito.Mockito;

public class NelderMeadSimplex_iterate_0_5_Test {

    @Test
    @DisplayName("iterate with sigma set to zero, affecting shrink")
    void TC21_iterateWithSigmaSetToZeroAffectingShrink() throws Exception {
        // Initialize NelderMeadSimplex with valid points
        NelderMeadSimplex simplex = new NelderMeadSimplex(2);

        // Use reflection to set sigma to zero
        Field sigmaField = NelderMeadSimplex.class.getDeclaredField("sigma");
        sigmaField.setAccessible(true);
        sigmaField.setDouble(simplex, 0.0);

        // Provide a valid MultivariateFunction
        MultivariateFunction function = Mockito.mock(MultivariateFunction.class);
        Mockito.when(function.value(Mockito.any(double[].class))).thenReturn(0.0);

        // Provide a valid Comparator
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Invoke the iterate method
        simplex.iterate(function, comparator);

        // Assert all points collapse to the smallest point
        PointValuePair smallest = simplex.getPoint(0);
        for (int i = 1; i <= simplex.getDimension(); i++) {
            PointValuePair point = simplex.getPoint(i);
            assertArrayEquals(smallest.getPointRef(), point.getPointRef(), "All points should collapse to the smallest point");
        }
    }

    @Test
    @DisplayName("iterate with negative scaling factor leading to invalid centroid")
    void TC22_iterateWithNegativeScalingFactor() throws Exception {
        // Initialize NelderMeadSimplex with valid points
        NelderMeadSimplex simplex = new NelderMeadSimplex(2);

        // Use reflection to set scaling factor to a negative value
        Field scalingField = NelderMeadSimplex.class.getDeclaredField("scaling");
        scalingField.setAccessible(true);
        scalingField.setDouble(simplex, -1.0);

        // Provide a valid MultivariateFunction
        MultivariateFunction function = Mockito.mock(MultivariateFunction.class);
        Mockito.when(function.value(Mockito.any(double[].class))).thenReturn(0.0);

        // Provide a valid Comparator
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Assert that IllegalArgumentException is thrown
        assertThrows(IllegalArgumentException.class, () -> {
            simplex.iterate(function, comparator);
        }, "IllegalArgumentException should be thrown due to invalid centroid calculation");
    }

    @Test
    @DisplayName("iterate with comparator always equal leading to shrink")
    void TC23_iterateWithComparatorAlwaysEqualLeadingToShrink() throws Exception {
        // Initialize NelderMeadSimplex with valid points
        NelderMeadSimplex simplex = new NelderMeadSimplex(2);

        // Provide a Comparator that always returns zero
        Comparator<PointValuePair> comparator = (p1, p2) -> 0;

        // Provide a valid MultivariateFunction
        MultivariateFunction function = Mockito.mock(MultivariateFunction.class);
        Mockito.when(function.value(Mockito.any(double[].class))).thenReturn(0.0);

        // Invoke the iterate method
        simplex.iterate(function, comparator);

        // Assert shrink operation is performed
        PointValuePair smallest = simplex.getPoint(0);
        for (int i = 1; i <= simplex.getDimension(); i++) {
            PointValuePair point = simplex.getPoint(i);
            assertArrayEquals(smallest.getPointRef(), point.getPointRef(), "Shrink operation should collapse points to the smallest point");
        }
    }

    @Test
    @DisplayName("iterate with getDimension returning zero")
    void TC24_iterateWithGetDimensionReturningZero() throws Exception {
        // Initialize NelderMeadSimplex where getDimension() returns 0
        NelderMeadSimplex simplex = new NelderMeadSimplex(0);

        // Provide a valid MultivariateFunction
        MultivariateFunction function = Mockito.mock(MultivariateFunction.class);
        Mockito.when(function.value(Mockito.any(double[].class))).thenReturn(0.0);

        // Provide a valid Comparator
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Invoke the iterate method
        simplex.iterate(function, comparator);

        // Assert no iterations are performed and method completes
        // Since dimension is zero, we can check that no points were modified
        PointValuePair smallest = simplex.getPoint(0);
        assertNotNull(smallest, "Smallest point should exist even if dimension is zero");
    }

    @Test
    @DisplayName("iterate with comparator throwing exception")
    void TC25_iterateWithComparatorThrowingException() throws Exception {
        // Initialize NelderMeadSimplex with valid points
        NelderMeadSimplex simplex = new NelderMeadSimplex(2);

        // Mock Comparator to throw an exception during comparison
        Comparator<PointValuePair> comparator = Mockito.mock(Comparator.class);
        Mockito.when(comparator.compare(Mockito.any(PointValuePair.class), Mockito.any(PointValuePair.class))).thenThrow(new RuntimeException("Comparator exception"));

        // Provide a valid MultivariateFunction
        MultivariateFunction function = Mockito.mock(MultivariateFunction.class);
        Mockito.when(function.value(Mockito.any(double[].class))).thenReturn(0.0);

        // Assert that the specific exception is thrown
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            simplex.iterate(function, comparator);
        }, "RuntimeException should be propagated from the comparator");
        assertEquals("Comparator exception", exception.getMessage(), "Exception message should match");
    }
}