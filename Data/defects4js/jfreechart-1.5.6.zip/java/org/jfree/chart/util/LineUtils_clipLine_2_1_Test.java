package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.util.LineUtils;

/**
 * JUnit 5 test class for LineUtils.clipLine covering additional scenarios.
 */
public class LineUtils_clipLine_2_1_Test {

    @Test
    @DisplayName("Clip line with one endpoint on the top-left corner and the other endpoint outside the rectangle")
    public void TC23_clipLine_endpoint_on_corner_and_outside() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(0.0, 0.0, -5.0, 5.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 10.0, 10.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(0.0, line.getX1(), 0.0001, "x1 should remain on top-left boundary");
        assertEquals(0.0, line.getY1(), 0.0001, "y1 should remain on top-left boundary");
        assertEquals(5.0, line.getX2(), 0.0001, "x2 should be clipped to right boundary");
        assertEquals(5.0, line.getY2(), 0.0001, "y2 should remain inside the rectangle");
    }

    @Test
    @DisplayName("Clip line with both endpoints on the same boundary but extending outside the rectangle")
    public void TC24_clipLine_both_endpoints_on_same_boundary_extending_outside() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(0.0, 0.0, 15.0, 0.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 10.0, 10.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(0.0, line.getX1(), 0.0001, "x1 should remain on top boundary");
        assertEquals(0.0, line.getY1(), 0.0001, "y1 should remain on top boundary");
        assertEquals(15.0, line.getX2(), 0.0001, "x2 should remain on top boundary");
        assertEquals(0.0, line.getY2(), 0.0001, "y2 should remain on top boundary");
    }

    @Test
    @DisplayName("Clip line with both endpoints outside but intersecting at non-axis-aligned boundaries")
    public void TC25_clipLine_both_endpoints_outside_intersecting_non_axis_aligned() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(-5.0, 5.0, 5.0, -5.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 10.0, 10.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(0.0, line.getX1(), 0.0001, "x1 should be clipped to left boundary");
        assertEquals(5.0, line.getY1(), 0.0001, "y1 should remain on left boundary");
        assertEquals(5.0, line.getX2(), 0.0001, "x2 should remain inside the rectangle");
        assertEquals(0.0, line.getY2(), 0.0001, "y2 should be clipped to top boundary");
    }

    @Test
    @DisplayName("Clip line with one endpoint having maximum double values")
    public void TC26_clipLine_endpoint_with_max_double_values() {
        // GIVEN
        Line2D.Double line = new Line2D.Double(Double.MAX_VALUE, Double.MAX_VALUE, 5.0, 5.0);
        Rectangle2D.Double rect = new Rectangle2D.Double(0.0, 0.0, 10.0, 10.0);

        // WHEN
        boolean result = LineUtils.clipLine(line, rect);

        // THEN
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(10.0, line.getX1(), 0.0001, "x1 should be clipped to right boundary");
        assertEquals(10.0, line.getY1(), 0.0001, "y1 should be clipped to bottom boundary");
        assertEquals(5.0, line.getX2(), 0.0001, "x2 should remain inside the rectangle");
        assertEquals(5.0, line.getY2(), 0.0001, "y2 should remain inside the rectangle");
    }
}