import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.apache.commons.math3.util.Incrementor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class LevenbergMarquardtOptimizerTest {

    @Test
    void optimize_NullProblem_ThrowsNullPointerException() {
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        assertThrows(NullPointerException.class, () -> optimizer.optimize(null));
    }

    @Test
    void optimize_ZeroObservations_ReturnsOptimum() {
        LeastSquaresProblem problem = mockProblem(0, 2, new double[0][0], new double[2], 0.0, new RealMatrix[0]);
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);
        assertNotNull(optimum);
    }

    @Test
    void optimize_ZeroParameters_ReturnsOptimum() {
        LeastSquaresProblem problem = mockProblem(2, 0, new double[2][0], new double[0], 0.0, new RealMatrix[0]);
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);
        assertNotNull(optimum);
    }

    @Test
    void optimize_RankDeficientJacobian_ContinuesOptimization() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 2},
                {2, 4}
        });
        double[] residuals = {1, 2};
        LeastSquaresProblem problem = mockProblem(2, 2, jacobian.getData(), residuals, 0.0, new RealMatrix[]{jacobian});
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);
        assertNotNull(optimum);
    }

    @Test
    void optimize_ConvergesByOrthogonality_ReturnsOptimum() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 0},
                {0, 1}
        });
        double[] residuals = {0, 0};
        LeastSquaresProblem problem = mockProblem(2, 2, jacobian.getData(), residuals, 0.0, new RealMatrix[]{jacobian});
        ConvergenceChecker<LeastSquaresOptimizer.Evaluation> checker = Mockito.mock(ConvergenceChecker.class);
        Mockito.when(checker.converged(Mockito.anyInt(), Mockito.any(), Mockito.any())).thenReturn(true);
        LeastSquaresProblem problemWithChecker = mockProblemWithChecker(2, 2, jacobian.getData(), residuals, 0.0, new RealMatrix[]{jacobian}, checker);
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problemWithChecker);
        assertNotNull(optimum);
    }

    @Test
    void optimize_ConvergesByCostTolerance_ReturnsOptimum() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 2},
                {3, 4}
        });
        double[] residuals = {0.001, 0.001};
        LeastSquaresProblem problem = mockProblem(2, 2, jacobian.getData(), residuals, 1e-10, new RealMatrix[]{jacobian});
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);
        assertNotNull(optimum);
    }

    @Test
    void optimize_ConvergesByParameterTolerance_ReturnsOptimum() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 0},
                {0, 1}
        });
        double[] residuals = {0, 0};
        LeastSquaresProblem problem = mockProblem(2, 2, jacobian.getData(), residuals, 1e-10, new RealMatrix[]{jacobian});
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresOptimizer.Optimum optimum = optimizer.optimize(problem);
        assertNotNull(optimum);
    }

    @Test
    void optimize_TooSmallCostTolerance_ThrowsConvergenceException() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 0},
                {0, 1}
        });
        double[] residuals = {1e-20, 1e-20};
        LeastSquaresProblem problem = mockProblem(2, 2, jacobian.getData(), residuals, 1e-10, new RealMatrix[]{jacobian});
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        Executable executable = () -> optimizer.optimize(problem);
        assertThrows(ConvergenceException.class, executable);
    }

    @Test
    void optimize_TooSmallParameterTolerance_ThrowsConvergenceException() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 0},
                {0, 1}
        });
        double[] residuals = {0, 0};
        LeastSquaresProblem problem = mockProblem(2, 2, jacobian.getData(), residuals, 1e-20, new RealMatrix[]{jacobian});
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        Executable executable = () -> optimizer.optimize(problem);
        assertThrows(ConvergenceException.class, executable);
    }

    @Test
    void optimize_TooSmallOrthoTolerance_ThrowsConvergenceException() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 0},
                {0, 1}
        });
        double[] residuals = {0, 0};
        ConvergenceChecker<LeastSquaresOptimizer.Evaluation> checker = Mockito.mock(ConvergenceChecker.class);
        Mockito.when(checker.converged(Mockito.anyInt(), Mockito.any(), Mockito.any())).thenReturn(false);
        LeastSquaresProblem problem = mockProblemWithChecker(2, 2, jacobian.getData(), residuals, 1e-10, new RealMatrix[]{jacobian}, checker);
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        // Modify orthoTolerance to a very small value to trigger exception
        optimizer = optimizer.withOrthoTolerance(1e-20);
        Executable executable = () -> optimizer.optimize(problem);
        assertThrows(ConvergenceException.class, executable);
    }

    @Test
    void optimize_InvalidJacobian_ThrowsConvergenceException() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {Double.NaN, 1},
                {1, Double.POSITIVE_INFINITY}
        });
        double[] residuals = {1, 2};
        LeastSquaresProblem problem = mockProblem(2, 2, jacobian.getData(), residuals, 1e-10, new RealMatrix[]{jacobian});
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        Executable executable = () -> optimizer.optimize(problem);
        assertThrows(ConvergenceException.class, executable);
    }

    @Test
    void optimize_MaxIterationsExceeded_ThrowsConvergenceException() {
        RealMatrix jacobian = new Array2DRowRealMatrix(new double[][]{
                {1, 1},
                {1, 1}
        });
        double[] residuals = {1, 1};
        ConvergenceChecker<LeastSquaresOptimizer.Evaluation> checker = Mockito.mock(ConvergenceChecker.class);
        Mockito.when(checker.converged(Mockito.anyInt(), Mockito.any(), Mockito.any())).thenReturn(false);
        Mockito.when(checker.converged(Mockito.anyInt(), Mockito.any(), Mockito.any())).thenReturn(false);
        LeastSquaresProblem problem = mockProblemWithChecker(2, 2, jacobian.getData(), residuals, 1e-10, new RealMatrix[]{jacobian}, checker);
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        // Simulate max iterations by allowing the loop to run without convergence
        // This might require setting initial conditions that prevent convergence
        Executable executable = () -> optimizer.optimize(problem);
        assertThrows(StackOverflowError.class, executable); // As a placeholder
    }

    // Helper methods to create mock problems

    private LeastSquaresProblem mockProblem(int observations, int parameters, double[][] jacobianData, double[] residuals, double parRelTol, RealMatrix[] matrices) {
        LeastSquaresProblem problem = Mockito.mock(LeastSquaresProblem.class);
        Mockito.when(problem.getObservationSize()).thenReturn(observations);
        Mockito.when(problem.getParameterSize()).thenReturn(parameters);
        Mockito.when(problem.getStart()).thenReturn(new ArrayRealVector(new double[parameters]));
        LeastSquaresProblem.Evaluation evaluation = mockEvaluation(residuals, matrices.length > 0 ? matrices[0] : new Array2DRowRealMatrix(parameters, observations));
        Mockito.when(problem.evaluate(Mockito.any())).thenReturn(evaluation);
        Mockito.when(problem.getIterationCounter()).thenReturn(new Incrementor());
        Mockito.when(problem.getEvaluationCounter()).thenReturn(new Incrementor());
        Mockito.when(problem.getConvergenceChecker()).thenReturn(null);
        return problem;
    }

    private LeastSquaresProblem mockProblemWithChecker(int observations, int parameters, double[][] jacobianData, double[] residuals, double parRelTol, RealMatrix[] matrices, ConvergenceChecker<LeastSquaresOptimizer.Evaluation> checker) {
        LeastSquaresProblem problem = Mockito.mock(LeastSquaresProblem.class);
        Mockito.when(problem.getObservationSize()).thenReturn(observations);
        Mockito.when(problem.getParameterSize()).thenReturn(parameters);
        Mockito.when(problem.getStart()).thenReturn(new ArrayRealVector(new double[parameters]));
        LeastSquaresProblem.Evaluation evaluation = mockEvaluation(residuals, matrices.length > 0 ? matrices[0] : new Array2DRowRealMatrix(parameters, observations));
        Mockito.when(problem.evaluate(Mockito.any())).thenReturn(evaluation);
        Mockito.when(problem.getIterationCounter()).thenReturn(new Incrementor());
        Mockito.when(problem.getEvaluationCounter()).thenReturn(new Incrementor());
        Mockito.when(problem.getConvergenceChecker()).thenReturn(checker);
        return problem;
    }

    private LeastSquaresProblem.Evaluation mockEvaluation(double[] residuals, RealMatrix jacobian) {
        LeastSquaresProblem.Evaluation eval = Mockito.mock(LeastSquaresProblem.Evaluation.class);
        Mockito.when(eval.getResiduals()).thenReturn(new ArrayRealVector(residuals));
        Mockito.when(eval.getCost()).thenReturn(arrayNorm(residuals));
        Mockito.when(eval.getPoint()).thenReturn(new ArrayRealVector(residuals.length));
        Mockito.when(eval.getJacobian()).thenReturn(jacobian);
        return eval;
    }

    private double arrayNorm(double[] array) {
        double sum = 0.0;
        for (double v : array) {
            sum += v * v;
        }
        return Math.sqrt(sum);
    }
}