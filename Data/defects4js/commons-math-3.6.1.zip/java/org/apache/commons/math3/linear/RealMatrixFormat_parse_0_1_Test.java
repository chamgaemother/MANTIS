package org.apache.commons.math3.linear;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.text.ParsePosition;

import static org.junit.jupiter.api.Assertions.*;

public class RealMatrixFormat_parse_0_1_Test {

    @Test
    @DisplayName("parse with correct prefix, suffix, single row and single element")
    public void TC01() {
        // Given
        String source = "[[1.0]]";
        ParsePosition pos = new ParsePosition(0);

        // When
        RealMatrixFormat format = new RealMatrixFormat("[", "]", "[", "]", ",", ",");
        RealMatrix result = format.parse(source, pos);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getRowDimension(), "Row count should be 1");
        assertEquals(1, result.getColumnDimension(), "Column count should be 1");
        assertEquals(1.0, result.getEntry(0, 0), "Matrix entry should be 1.0");
    }

    @Test
    @DisplayName("parse with multiple rows and multiple elements")
    public void TC02() {
        // Given
        String source = "[[1.0,2.0],[3.0,4.0]]";
        ParsePosition pos = new ParsePosition(0);

        // When
        RealMatrixFormat format = new RealMatrixFormat("[", "]", "[", "]", ",", ",");
        RealMatrix result = format.parse(source, pos);

        // Then
        assertNotNull(result);
        assertEquals(2, result.getRowDimension(), "Row count should be 2");
        assertEquals(2, result.getColumnDimension(), "Column count should be 2");
        assertEquals(1.0, result.getEntry(0, 0), "Matrix entry (0,0) should be 1.0");
        assertEquals(2.0, result.getEntry(0, 1), "Matrix entry (0,1) should be 2.0");
        assertEquals(3.0, result.getEntry(1, 0), "Matrix entry (1,0) should be 3.0");
        assertEquals(4.0, result.getEntry(1, 1), "Matrix entry (1,1) should be 4.0");
    }

    @Test
    @DisplayName("parse fails due to incorrect prefix")
    public void TC03() {
        // Given
        String source = "{1.0]";
        ParsePosition pos = new ParsePosition(0);

        // When
        RealMatrixFormat format = new RealMatrixFormat("[", "]", "[", "]", ",", ",");
        RealMatrix result = format.parse(source, pos);

        // Then
        assertNull(result, "Result should be null due to incorrect prefix");
        assertEquals(0, pos.getIndex(), "Parse position should remain at 0");
    }

    @Test
    @DisplayName("parse fails due to incorrect suffix")
    public void TC04() {
        // Given
        String source = "[[1.0,2.0], [3.0,4.0}";
        ParsePosition pos = new ParsePosition(0);

        // When
        RealMatrixFormat format = new RealMatrixFormat("[", "]", "[", "]", ",", ",");
        RealMatrix result = format.parse(source, pos);

        // Then
        assertNull(result, "Result should be null due to incorrect suffix");
        assertEquals(13, pos.getIndex(), "Parse position should be at index 13");
    }

    @Test
    @DisplayName("parse with empty matrix")
    public void TC05() {
        // Given
        String source = "[][]";
        ParsePosition pos = new ParsePosition(0);

        // When
        RealMatrixFormat format = new RealMatrixFormat("[", "]", "[", "]", ",", ",");
        RealMatrix result = format.parse(source, pos);

        // Then
        assertNull(result, "Result should be null for empty matrix");
        assertEquals(0, pos.getIndex(), "Parse position should remain at 0");
    }
}
