package org.jfree.chart.renderer;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.GeneralPath;
import java.util.List;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PolarPlot;
import org.jfree.chart.util.ShapeUtils;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class DefaultPolarItemRenderer_drawSeries_1_1_Test {

    @Test
    @DisplayName("drawSeries handles null paint from lookupSeriesPaint without throwing exceptions")
    void TC19_drawSeries_with_null_lookupSeriesPaint() {
        try {
            DefaultPolarItemRenderer renderer = org.mockito.Mockito.spy(new DefaultPolarItemRenderer());

            // Mock dependencies
            XYDataset dataset = mock(XYDataset.class);
            int seriesIndex = 0;
            when(dataset.getItemCount(seriesIndex)).thenReturn(2);

            PolarPlot plot = mock(PolarPlot.class);
            when(plot.indexOf(dataset)).thenReturn(0);

            org.jfree.chart.axis.ValueAxis axis = mock(org.jfree.chart.axis.ValueAxis.class);
            when(plot.getAxisForDataset(0)).thenReturn(axis);

            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D dataArea = new Rectangle2D.Double();

            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
            EntityCollection entities = mock(EntityCollection.class);
            when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
            when(info.getOwner().getEntityCollection()).thenReturn(entities);

            // Stub lookupSeriesPaint to return null
            doReturn(null).when(renderer).lookupSeriesPaint(seriesIndex);

            // Execute the method under test
            assertDoesNotThrow(() -> {
                renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);
            });

            // Verify methods expected to be invoked
            verify(g2).fill(any(Shape.class));
            verify(g2).draw(any(Shape.class));

        } catch (Exception e) {
            fail("Exception should not have been thrown: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("drawSeries does not add entities when getItemCreateEntity(series, item) returns false")
    void TC20_drawSeries_with_getItemCreateEntity_false() {
        try {
            DefaultPolarItemRenderer renderer = org.mockito.Mockito.spy(new DefaultPolarItemRenderer());

            // Mock dependencies
            XYDataset dataset = mock(XYDataset.class);
            int seriesIndex = 0;
            when(dataset.getItemCount(seriesIndex)).thenReturn(2);

            PolarPlot plot = mock(PolarPlot.class);
            when(plot.indexOf(dataset)).thenReturn(0);

            org.jfree.chart.axis.ValueAxis axis = mock(org.jfree.chart.axis.ValueAxis.class);
            when(plot.getAxisForDataset(0)).thenReturn(axis);

            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D dataArea = new Rectangle2D.Double();

            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
            EntityCollection entities = mock(EntityCollection.class);
            when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
            when(info.getOwner().getEntityCollection()).thenReturn(entities);

            // Stub getItemCreateEntity to return false
            doReturn(false).when(renderer).getItemCreateEntity(eq(seriesIndex), anyInt());

            // Execute the method under test
            renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);

            // Verify methods expected to be invoked
            verify(g2).fill(any(Shape.class));
            verify(g2).draw(any(Shape.class));
            verify(entities, org.mockito.Mockito.never()).add(any());
        } catch (Exception e) {
            fail("Exception should not have been thrown: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("drawSeries handles exception thrown by addEntity without interrupting rendering")
    void TC21_drawSeries_with_addEntity_exception() {
        try {
            DefaultPolarItemRenderer renderer = org.mockito.Mockito.spy(new DefaultPolarItemRenderer());

            // Mock dependencies
            XYDataset dataset = mock(XYDataset.class);
            int seriesIndex = 0;
            when(dataset.getItemCount(seriesIndex)).thenReturn(2);

            PolarPlot plot = mock(PolarPlot.class);
            when(plot.indexOf(dataset)).thenReturn(0);

            org.jfree.chart.axis.ValueAxis axis = mock(org.jfree.chart.axis.ValueAxis.class);
            when(plot.getAxisForDataset(0)).thenReturn(axis);

            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D dataArea = new Rectangle2D.Double();

            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
            EntityCollection entities = mock(EntityCollection.class);
            when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
            when(info.getOwner().getEntityCollection()).thenReturn(entities);

            // Stub addEntity to throw RuntimeException
            doThrow(new RuntimeException("Entity addition failed")).when(renderer).addEntity(eq(entities), any(Shape.class), eq(dataset), eq(seriesIndex), anyInt(), anyDouble(), anyDouble());

            // Execute the method under test
            assertDoesNotThrow(() -> {
                renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);
            });

            // Verify methods expected to be invoked
            verify(g2).fill(any(Shape.class));
            verify(g2).draw(any(Shape.class));

        } catch (Exception e) {
            fail("Exception should not have been thrown: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("drawSeries with shapes outside dataArea are not added to entities")
    void TC22_drawSeries_shapes_outside_dataArea_not_added_to_entities() {
        try {
            DefaultPolarItemRenderer renderer = org.mockito.Mockito.spy(new DefaultPolarItemRenderer());

            // Mock dependencies
            XYDataset dataset = mock(XYDataset.class);
            int seriesIndex = 0;
            when(dataset.getItemCount(seriesIndex)).thenReturn(2);

            PolarPlot plot = mock(PolarPlot.class);
            when(plot.indexOf(dataset)).thenReturn(0);

            org.jfree.chart.axis.ValueAxis axis = mock(org.jfree.chart.axis.ValueAxis.class);
            when(plot.getAxisForDataset(0)).thenReturn(axis);

            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);

            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
            EntityCollection entities = mock(EntityCollection.class);
            when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
            when(info.getOwner().getEntityCollection()).thenReturn(entities);

            // Mock ShapeUtils.isPointInRect to return false
            try (org.mockito.MockedStatic<ShapeUtils> mockedShapeUtils = org.mockito.Mockito.mockStatic(ShapeUtils.class)) {
                mockedShapeUtils.when(() -> ShapeUtils.isPointInRect(any(Rectangle2D.class), anyDouble(), anyDouble())).thenReturn(false);

                // Execute the method under test
                renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);

                // Verify methods expected to be invoked
                verify(g2).fill(any(Shape.class));
                verify(g2).draw(any(Shape.class));
                verify(entities, org.mockito.Mockito.never()).add(any());
            }

        } catch (Exception e) {
            fail("Exception should not have been thrown: " + e.getMessage());
        }
    }
}