import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.apache.commons.jxpath.functions.MethodFunction;
import org.apache.commons.jxpath.util.TypeUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

class MethodFunctionTest {

    public static class TestClass {
        public static String staticMethod(ExpressionContext ctx, String param) {
            return param.toUpperCase();
        }

        public String instanceMethod(String param) {
            return param.toLowerCase();
        }

        public String contextMethod(ExpressionContext ctx) {
            return "Context Method";
        }

        public static void staticVoidMethod() {
            // void method
        }

        public void instanceVoidMethod() {
            // void method
        }

        public static void staticExceptionMethod() {
            throw new RuntimeException("Static Exception");
        }

        public void instanceExceptionMethod() {
            throw new RuntimeException("Instance Exception");
        }
    }

    private static class MockExpressionContext implements ExpressionContext {
        @Override
        public Object getContextNodePointer() {
            return null;
        }

        @Override
        public Object getJXPathContext() {
            return null;
        }

        @Override
        public Object getPosition() {
            return null;
        }
    }

    @Test
    void testStaticMethodInvocation() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("staticMethod", ExpressionContext.class, String.class);
        MethodFunction function = new MethodFunction(method);
        Object result = function.invoke(new MockExpressionContext(), new Object[]{"test"});
        assertEquals("TEST", result);
    }

    @Test
    void testInstanceMethodInvocation() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("instanceMethod", String.class);
        MethodFunction function = new MethodFunction(method);
        Object result = function.invoke(null, new Object[]{new TestClass(), "TEST"});
        assertEquals("test", result);
    }

    @Test
    void testContextMethod() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("contextMethod", ExpressionContext.class);
        MethodFunction function = new MethodFunction(method);
        Object result = function.invoke(new MockExpressionContext(), new Object[]{new TestClass()});
        assertEquals("Context Method", result);
    }

    @Test
    void testStaticVoidMethod() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("staticVoidMethod");
        MethodFunction function = new MethodFunction(method);
        Object result = function.invoke(null, null);
        assertNull(result);  // void method returns null
    }

    @Test
    void testInstanceVoidMethod() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("instanceVoidMethod");
        MethodFunction function = new MethodFunction(method);
        Object result = function.invoke(null, new Object[]{new TestClass()});
        assertNull(result);
    }

    @Test
    void testStaticMethodException() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("staticExceptionMethod");
        MethodFunction function = new MethodFunction(method);
        Executable executable = () -> function.invoke(null, null);
        assertThrows(JXPathInvalidAccessException.class, executable);
    }

    @Test
    void testInstanceMethodException() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("instanceExceptionMethod");
        MethodFunction function = new MethodFunction(method);
        Executable executable = () -> function.invoke(null, new Object[]{new TestClass()});
        assertThrows(JXPathInvalidAccessException.class, executable);
    }

    @Test
    void testNullParameters() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("staticMethod", ExpressionContext.class, String.class);
        MethodFunction function = new MethodFunction(method);
        Object result = function.invoke(null, null);
        assertEquals("", result);
    }

    @Test
    void testIncompatibleParameters() {
        Method method;
        try {
            method = TestClass.class.getMethod("instanceMethod", String.class);
            MethodFunction function = new MethodFunction(method);
            Executable executable = () -> function.invoke(null, new Object[]{new TestClass(), 123});
            assertThrows(JXPathInvalidAccessException.class, executable);
        } catch (NoSuchMethodException ignored) {
        }
    }

    @Test
    void testMissingInstanceParameter() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("instanceMethod", String.class);
        MethodFunction function = new MethodFunction(method);
        Executable executable = () -> function.invoke(null, new Object[]{});
        assertThrows(JXPathInvalidAccessException.class, executable);
    }

    @Test
    void testStaticMethodWithNullContext() throws NoSuchMethodException {
        Method method = TestClass.class.getMethod("staticMethod", ExpressionContext.class, String.class);
        MethodFunction function = new MethodFunction(method);
        Object result = function.invoke(null, new Object[]{"test"});
        assertEquals("TEST", result);
    }
}