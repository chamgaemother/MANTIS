package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

public class PopulationCodecTest {

    private Codec favouredCodec;
    private Codec tokenCodec;
    private Codec unfavouredCodec;
    private PopulationCodec populationCodec;
    private InputStream inputStream;

    @BeforeEach
    public void setUp() {
        favouredCodec = mock(Codec.class);
        tokenCodec = mock(Codec.class);
        unfavouredCodec = mock(Codec.class);
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        inputStream = mock(InputStream.class);
    }

    @Test
    public void decodeInts_nullInputStream_throwsNullPointerException() {
        assertThrows(NullPointerException.class, () -> populationCodec.decodeInts(10, null));
    }

    @Test
    public void decodeInts_zeroElements_returnsEmptyArray() throws IOException, Pack200Exception {
        when(favouredCodec.decode(any(InputStream.class), anyInt())).thenThrow(new Pack200Exception("Terminate"));
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        populationCodec = Mockito.spy(populationCodec);
        doReturn(0).when(populationCodec).check(0, inputStream);
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> populationCodec.decodeInts(0, inputStream));
        assertEquals("Population encoding does not work unless the number of elements are known", exception.getMessage());
    }

    @Test
    public void decodeInts_kLessThan256_tokenCodecSetToBYTE1() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(10).thenReturn(10);
        doReturn(1).when(populationCodec).check(10, inputStream);
        populationCodec = new PopulationCodec(favouredCodec, null, unfavouredCodec);
        populationCodec.decodeInts(10, inputStream);
        verify(favouredCodec, times(2)).decode(inputStream, anyInt());
        assertEquals(1, populationCodec.getLastBandLength());
        assertNotNull(populationCodec.getTokenCodec());
    }

    @Test
    public void decodeInts_kGreaterOrEqual256_tokenCodecDerivedSuccessfully() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(1000).thenReturn(1000);
        doReturn(300).when(populationCodec).check(300, inputStream);
        BHSDCodec mockCodec = mock(BHSDCodec.class);
        when(mockCodec.encodes(300)).thenReturn(true);
        populationCodec = new PopulationCodec(favouredCodec, null, unfavouredCodec);
        // Mock BYTE1 is already set
        populationCodec.decodeInts(300, inputStream);
        verify(favouredCodec, times(2)).decode(inputStream, anyInt());
        assertEquals(1, populationCodec.getLastBandLength());
        assertNotNull(populationCodec.getTokenCodec());
    }

    @Test
    public void decodeInts_kGreaterOrEqual256_noValidTokenCodec_throwsException() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(1000).thenReturn(1000);
        doReturn(300).when(populationCodec).check(300, inputStream);
        populationCodec = new PopulationCodec(favouredCodec, null, unfavouredCodec);
        // Mock BHSDCodec.encodes to return false
        Codec originalTokenCodec = populationCodec.getTokenCodec();
        populationCodec.setTokenCodec(null);
        BHSDCodec codec = mock(BHSDCodec.class);
        when(codec.encodes(300)).thenReturn(false);
        // Assume PopulationCodec tries to set tokenCodec and fails
        assertThrows(Pack200Exception.class, () -> populationCodec.decodeInts(300, inputStream));
    }

    @Test
    public void decodeInts_withTokenCodec_notNull() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(1).thenReturn(2).thenReturn(1);
        doReturn(2).when(populationCodec).check(2, inputStream);
        when(tokenCodec.decodeInts(2, inputStream)).thenReturn(new int[] {0, 1});
        when(unfavouredCodec.decode(inputStream, 0)).thenReturn(100);
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        int[] result = populationCodec.decodeInts(2, inputStream);
        assertArrayEquals(new int[] {100, 1}, result);
    }

    @Test
    public void decodeInts_indexZero_unfavouredDecoded() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(5).thenReturn(5);
        doReturn(1).when(populationCodec).check(2, inputStream);
        when(tokenCodec.decodeInts(2, inputStream)).thenReturn(new int[] {0, 1});
        when(unfavouredCodec.decode(inputStream, 0)).thenReturn(50);
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        int[] result = populationCodec.decodeInts(2, inputStream);
        assertArrayEquals(new int[] {50, 5}, result);
    }

    @Test
    public void decodeInts_indexNonZero_favouredDecoded() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(5).thenReturn(5);
        doReturn(1).when(populationCodec).check(2, inputStream);
        when(tokenCodec.decodeInts(2, inputStream)).thenReturn(new int[] {1, 1});
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        // Assuming favoured[0] =5
        int[] result = populationCodec.decodeInts(2, inputStream);
        assertArrayEquals(new int[] {5, 5}, result);
    }

    @Test
    public void decodeInts_decodeThrowsPack200Exception() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenThrow(new Pack200Exception("Decode error"));
        doReturn(1).when(populationCodec).check(1, inputStream);
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> populationCodec.decodeInts(1, inputStream));
        assertEquals("Decode error", exception.getMessage());
    }

    @Test
    public void decodeInts_decodeThrowsIOException() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenThrow(new IOException("IO error"));
        doReturn(1).when(populationCodec).check(1, inputStream);
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        IOException exception = assertThrows(IOException.class, () -> populationCodec.decodeInts(1, inputStream));
        assertEquals("IO error", exception.getMessage());
    }

    @Test
    public void decodeInts_favouredCodecUpdatesSmallestCorrectly() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(10).thenReturn(5).thenReturn(5);
        doReturn(2).when(populationCodec).check(2, inputStream);
        when(tokenCodec.decodeInts(2, inputStream)).thenReturn(new int[] {1, 1});
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        populationCodec.decodeInts(2, inputStream);
        assertEquals(1, populationCodec.getLastBandLength());
    }

    @Test
    public void decodeInts_favouredCodecHandlesNegativeValues() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(-10).thenReturn(-10);
        doReturn(1).when(populationCodec).check(1, inputStream);
        when(tokenCodec.decodeInts(1, inputStream)).thenReturn(new int[] {1});
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        int[] result = populationCodec.decodeInts(1, inputStream);
        assertArrayEquals(new int[] {-10}, result);
    }

    @Test
    public void decodeInts_multipleBranches_coverage() throws IOException, Pack200Exception {
        when(favouredCodec.decode(inputStream, 0)).thenReturn(3).thenReturn(7).thenReturn(3);
        doReturn(2).when(populationCodec).check(3, inputStream);
        when(tokenCodec.decodeInts(3, inputStream)).thenReturn(new int[] {0, 1, 2});
        when(unfavouredCodec.decode(inputStream, 0)).thenReturn(100);
        when(unfavouredCodec.decode(inputStream, 100)).thenReturn(200);
        populationCodec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        int[] result = populationCodec.decodeInts(3, inputStream);
        assertArrayEquals(new int[] {100, 3, 7}, result);
    }
}