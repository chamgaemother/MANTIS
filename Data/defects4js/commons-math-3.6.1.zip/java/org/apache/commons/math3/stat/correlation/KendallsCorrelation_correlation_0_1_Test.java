package org.apache.commons.math3.stat.correlation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.exception.DimensionMismatchException;

public class KendallsCorrelation_correlation_0_1_Test {

    @Test
    @DisplayName("correlation throws DimensionMismatchException when xArray and yArray have different lengths")
    public void TC01_correlationDifferentLengthArrays() {
        double[] xArray = {1.0, 2.0};
        double[] yArray = {1.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        
        Assertions.assertThrows(DimensionMismatchException.class, () -> {
            kc.correlation(xArray, yArray);
        });
    }

    @Test
    @DisplayName("correlation throws ArrayIndexOutOfBoundsException when both xArray and yArray are empty")
    public void TC02_correlationEmptyArrays() {
        double[] xArray = {};
        double[] yArray = {};
        KendallsCorrelation kc = new KendallsCorrelation();
        
        Assertions.assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            kc.correlation(xArray, yArray);
        });
    }

    @Test
    @DisplayName("correlation correctly computes correlation for single-element arrays")
    public void TC03_correlationSingleElementArrays() {
        double[] xArray = {2.0};
        double[] yArray = {3.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        
        double result = kc.correlation(xArray, yArray);
        Assertions.assertEquals(1.0, result, 1e-10, "Correlation should be 1.0 for single-element arrays.");
    }

    @Test
    @DisplayName("correlation correctly computes correlation for multiple elements with no ties")
    public void TC04_correlationMultipleElementsNoTies() {
        double[] xArray = {1.0, 2.0, 3.0};
        double[] yArray = {1.0, 2.0, 3.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        
        double result = kc.correlation(xArray, yArray);
        Assertions.assertEquals(1.0, result, 1e-10, "Correlation should be 1.0 for perfectly increasing sequences.");
    }

    @Test
    @DisplayName("correlation correctly handles multiple elements with tied x values")
    public void TC05_correlationMultipleElementsTiedX() {
        double[] xArray = {1.0, 1.0, 2.0};
        double[] yArray = {1.0, 2.0, 3.0};
        KendallsCorrelation kc = new KendallsCorrelation();
        
        double result = kc.correlation(xArray, yArray);
        Assertions.assertEquals(0.3333333333333333, result, 1e-10, "Correlation should account for tied x values.");
    }
}