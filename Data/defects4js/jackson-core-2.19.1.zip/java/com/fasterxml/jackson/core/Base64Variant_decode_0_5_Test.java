package com.fasterxml.jackson.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import java.util.Arrays;

public class Base64Variant_decode_0_5_Test {

    private Base64Variant createBase64Variant() {
        String base64Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        return new Base64Variant("MIME", base64Alphabet, true, '=', Integer.MAX_VALUE);
    }

    @Test
    @DisplayName("decode with all possible padding scenarios processes correctly")
    void TC21_decode_with_all_possible_padding_scenarios() {
        // GIVEN
        String str = "TWFuTWE=TQ==";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = createBase64Variant();

        // WHEN
        variant.decode(str, builder);

        // THEN
        byte[] expected = "ManMaM".getBytes();
        assertTrue(Arrays.equals(builder.toByteArray(), expected), "Decoded bytes do not match expected result.");
    }

    @Test
    @DisplayName("decode with maximum allowed padding appends correctly")
    void TC22_decode_with_maximum_allowed_padding() {
        // GIVEN
        String str = "TQ==";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = createBase64Variant();

        // WHEN
        variant.decode(str, builder);

        // THEN
        byte[] expected = new byte[]{77};
        assertTrue(Arrays.equals(builder.toByteArray(), expected), "Decoded bytes do not match expected single byte result.");
    }

    @Test
    @DisplayName("decode with non-ASCII characters in input throws IllegalArgumentException")
    void TC23_decode_with_non_ASCII_characters() {
        // GIVEN
        String str = "TÃÂ¿Vu";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = createBase64Variant();

        // WHEN & THEN
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            variant.decode(str, builder);
        }, "Expected decode() to throw IllegalArgumentException for non-ASCII characters.");
        assertTrue(exception.getMessage().contains("Illegal character"), "Exception message does not contain expected text.");
    }

    @Test
    @DisplayName("decode with characters above ASCII range are treated as invalid and throw IllegalArgumentException")
    void TC24_decode_with_high_ASCII_characters() {
        // GIVEN
        String str = "TWÃ¯Â¿Â¿u";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = createBase64Variant();

        // WHEN & THEN
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            variant.decode(str, builder);
        }, "Expected decode() to throw IllegalArgumentException for high ASCII characters.");
        assertTrue(exception.getMessage().contains("Illegal character"), "Exception message does not contain expected text.");
    }

    @Test
    @DisplayName("decode with all valid base64 characters processes correctly")
    void TC25_decode_with_all_valid_base64_characters() {
        // GIVEN
        String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        Base64Variant variant = createBase64Variant();

        // WHEN
        variant.decode(str, builder);

        // THEN
        // The expected byte array should be the decoded form of the input string.
        // Replace the following line with the actual expected bytes.
        byte[] expected = new byte[]{0, 16, 22, 9, 34, 71, -106, -63, 33, 69, -103, 38, 73, 46, -95, 97, 101, -87, 98, 105, 46};
        assertTrue(Arrays.equals(builder.toByteArray(), expected), "Decoded bytes do not match expected result for all valid characters.");
    }
}