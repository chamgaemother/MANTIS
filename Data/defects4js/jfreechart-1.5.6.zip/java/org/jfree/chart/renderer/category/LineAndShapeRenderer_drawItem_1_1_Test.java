package org.jfree.chart.renderer.category;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.awt.geom.Line2D;
import java.awt.Shape;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import org.mockito.ArgumentCaptor;

public class LineAndShapeRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem calculates x1 with series offset and draws line when line visibility is true")
    public void test_TC06_drawItem_withSeriesOffset_andLineVisible() {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setUseSeriesOffset(true);
        renderer.setSeriesLinesVisible(0, true);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Mock dataset values
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, 1)).thenReturn(20.0);

        // Mock plot orientation
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock domainAxis calculations
        when(domainAxis.getCategorySeriesMiddle(0, 2, 0, 2, 0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(domainAxis.getCategorySeriesMiddle(1, 2, 0, 2, 0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);

        // Mock rangeAxis calculations
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                          dataset, 0, 1, 0);

        // Assert
        Line2D expectedLine = new Line2D.Double(50.0, 100.0, 150.0, 200.0);
        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2).setPaint(renderer.getItemPaint(0, 1));
        verify(g2).setStroke(renderer.getItemStroke(0, 1));
        verify(g2).draw(lineCaptor.capture());
        Line2D actualLine = lineCaptor.getValue();
        assertEquals(expectedLine.getX1(), actualLine.getX1(), 0.01);
        assertEquals(expectedLine.getY1(), actualLine.getY1(), 0.01);
        assertEquals(expectedLine.getX2(), actualLine.getX2(), 0.01);
        assertEquals(expectedLine.getY2(), actualLine.getY2(), 0.01);
    }

    @Test
    @DisplayName("drawItem calculates x1 with series offset but does not draw line when line visibility is false")
    public void test_TC07_drawItem_withSeriesOffset_andLineNotVisible() {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setUseSeriesOffset(true);
        renderer.setSeriesLinesVisible(0, false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Mock dataset values
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, 1)).thenReturn(20.0);

        // Mock plot orientation
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock domainAxis calculations
        when(domainAxis.getCategorySeriesMiddle(0, 2, 0, 2, 0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(domainAxis.getCategorySeriesMiddle(1, 2, 0, 2, 0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);

        // Mock rangeAxis calculations
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                          dataset, 0, 1, 0);

        // Assert
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("drawItem draws filled shape when shape is visible and filled")
    public void test_TC08_drawItem_shapeVisibleAndFilled() {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setUseSeriesOffset(true);
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesShapesFilled(0, true);
        renderer.setUseFillPaint(true);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        // Mock dataset values
        when(dataset.getValue(0, 0)).thenReturn(15.0);

        // Mock plot orientation
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock domainAxis calculations
        when(domainAxis.getCategorySeriesMiddle(0, 1, 0, 1, 0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);

        // Mock rangeAxis calculations
        when(rangeAxis.valueToJava2D(15.0, dataArea, plot.getRangeAxisEdge())).thenReturn(150.0);

        // Mock state methods
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(state.getEntityCollection()).thenReturn(entities);

        // Mock shape
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                          dataset, 0, 0, 1);

        // Assert
        verify(g2).setPaint(renderer.getItemFillPaint(0, 0));
        verify(g2).fill(shape);
        verify(g2).setPaint(renderer.getItemOutlinePaint(0, 0));
        verify(g2).setStroke(renderer.getItemOutlineStroke(0, 0));
        verify(g2).draw(shape);
    }

    @Test
    @DisplayName("drawItem draws unfilled shape when shape is visible but not filled")
    public void test_TC09_drawItem_shapeVisibleButNotFilled() {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setUseSeriesOffset(true);
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesShapesFilled(0, false);
        renderer.setUseFillPaint(false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        // Mock dataset values
        when(dataset.getValue(0, 0)).thenReturn(25.0);

        // Mock plot orientation
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock domainAxis calculations
        when(domainAxis.getCategorySeriesMiddle(0, 1, 0, 1, 0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);

        // Mock rangeAxis calculations
        when(rangeAxis.valueToJava2D(25.0, dataArea, plot.getRangeAxisEdge())).thenReturn(250.0);

        // Mock state methods
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(state.getEntityCollection()).thenReturn(entities);

        // Mock shape
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                          dataset, 0, 0, 1);

        // Assert
        verify(g2, never()).fill(any(Shape.class));
        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).setStroke(renderer.getItemOutlineStroke(0, 0));
        verify(g2).draw(shape);
    }

    @Test
    @DisplayName("drawItem adds item entity when entity collection is present")
    public void test_TC10_drawItem_addsItemEntity_whenEntityCollectionPresent() {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        renderer.setUseSeriesOffset(true);
        renderer.setSeriesShapesVisible(0, true);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        // Mock dataset values
        when(dataset.getValue(0, 0)).thenReturn(30.0);

        // Mock plot orientation
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Mock domainAxis calculations
        when(domainAxis.getCategorySeriesMiddle(0, 1, 0, 1, 0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);

        // Mock rangeAxis calculations
        when(rangeAxis.valueToJava2D(30.0, dataArea, plot.getRangeAxisEdge())).thenReturn(300.0);

        // Mock state methods
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(state.getEntityCollection()).thenReturn(entities);

        // Mock shape
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                          dataset, 0, 0, 1);

        // Assert
        verify(entities).add(any());
    }

}
