import org.apache.commons.compress.harmony.unpack200.BcBands;
import org.apache.commons.compress.harmony.unpack200.Segment;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.apache.commons.compress.harmony.unpack200.bytecode.Attribute;
import org.apache.commons.compress.harmony.unpack200.bytecode.CodeAttribute;
import org.apache.commons.compress.harmony.unpack200.bytecode.ExceptionTableEntry;
import org.apache.commons.compress.harmony.unpack200.bytecode.CPClass;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BcBandsTest {

    private BcBands bcBands;
    private Segment segment;

    @BeforeEach
    void setUp() throws IOException, Pack200Exception {
        segment = mock(Segment.class);
        when(segment.getCpBands()).thenReturn(mock(Segment.CpBands.class));
        when(segment.getClassBands()).thenReturn(mock(Segment.ClassBands.class));
        when(segment.getAttrDefinitionBands()).thenReturn(mock(Segment.AttrDefinitionBands.class));
        when(segment.getSegmentHeader()).thenReturn(mock(Segment.SegmentHeader.class));
        when(segment.getClassBands().getCodeMaxNALocals()).thenReturn(new int[]{1});
        when(segment.getClassBands().getCodeMaxStack()).thenReturn(new int[]{1});
        when(segment.getCpBands().getCpClass()).thenReturn(new String[]{"Test"});
        when(segment.getClassBands().getClassThisInts()).thenReturn(new int[]{0});
        when(segment.getClassBands().getClassSuperInts()).thenReturn(new int[]{0});
        when(segment.getClassBands().getMethodFlags()).thenReturn(new long[][]{{0}});
        when(segment.getClassBands().getClassThisInts()).thenReturn(new int[]{0});
        when(segment.getClassBands().getClassSuperInts()).thenReturn(new int[]{0});
        bcBands = new BcBands(segment);
    }

    @Test
    void testUnpack_noHandlers_noCodeFlags() throws Pack200Exception {
        when(segment.getSegmentHeader().getOptions().hasAllCodeFlags()).thenReturn(false);
        when(segment.getClassBands().getCodeHasAttributes()).thenReturn(new boolean[]{false});
        when(segment.getClassBands().getOrderedCodeAttributes()).thenReturn(new ArrayList<>(Collections.singletonList(Collections.emptyList())));
        bcBands.unpack();
    }

    @Test
    void testUnpack_noHandlers_withCodeFlags() throws Pack200Exception {
        when(segment.getSegmentHeader().getOptions().hasAllCodeFlags()).thenReturn(false);
        when(segment.getClassBands().getCodeHasAttributes()).thenReturn(new boolean[]{true});
        List<List<Attribute>> orderedAttributesList = new ArrayList<>();
        orderedAttributesList.add(Collections.emptyList());
        when(segment.getClassBands().getOrderedCodeAttributes()).thenReturn(orderedAttributesList);
        bcBands.unpack();
    }

    @Test
    void testUnpack_withHandlers() throws Pack200Exception {
        when(segment.getClassBands().getCodeHandlerCount()).thenReturn(new int[]{1});
        when(segment.getClassBands().getCodeHandlerStartP()).thenReturn(new int[][]{{0}});
        when(segment.getClassBands().getCodeHandlerEndPO()).thenReturn(new int[][]{{1}});
        when(segment.getClassBands().getCodeHandlerCatchPO()).thenReturn(new int[][]{{2}});
        when(segment.getClassBands().getCodeHandlerClassRCN()).thenReturn(new int[][]{{1}});
        when(segment.getCpBands().cpClassValue(anyInt())).thenReturn(mock(CPClass.class));
        bcBands.unpack();
    }

    @Test
    void testUnpack_withoutStaticModifier() throws Pack200Exception {
        when(segment.getClassBands().getMethodFlags()).thenReturn(new long[][]{{0}});
        when(segment.getClassBands().getMethodDescr()).thenReturn(new String[][]{{"()V"}});
        bcBands.unpack();
    }
}