package org.apache.commons.jxpath.util;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

import org.apache.commons.jxpath.JXPathTypeConversionException;
import org.apache.commons.jxpath.NodeSet;
import org.apache.commons.jxpath.Pointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class BasicTypeConverterTest {

    private BasicTypeConverter converter;

    @BeforeEach
    public void setUp() {
        converter = new BasicTypeConverter();
    }

    @Test
    public void testConvertNullToPrimitive() {
        Object result = converter.convert(null, int.class);
        assertEquals(0, result);
        
        result = converter.convert(null, boolean.class);
        assertEquals(Boolean.FALSE, result);
        
        result = converter.convert(null, char.class);
        assertEquals('\0', result);
    }

    @Test
    public void testConvertNullToNonPrimitive() {
        Object result = converter.convert(null, Integer.class);
        assertNull(result);
        
        result = converter.convert(null, String.class);
        assertNull(result);
    }

    @Test
    public void testConvertToObjectWithNodeSet() {
        NodeSet nodeSet = Mockito.mock(NodeSet.class);
        List<Object> values = Arrays.asList("value1", "value2");
        Mockito.when(nodeSet.getValues()).thenReturn(values);
        
        Object result = converter.convert(nodeSet, Object.class);
        assertEquals(values, result);
    }

    @Test
    public void testConvertToObjectWithPointer() {
        Pointer pointer = Mockito.mock(Pointer.class);
        Mockito.when(pointer.getValue()).thenReturn("pointerValue");
        
        Object result = converter.convert(pointer, Object.class);
        assertEquals("pointerValue", result);
    }

    @Test
    public void testConvertToObjectWithOther() {
        String obj = "testObject";
        Object result = converter.convert(obj, Object.class);
        assertSame(obj, result);
    }

    @Test
    public void testConvertAssignableTypes() {
        String str = "assignable";
        Object result = converter.convert(str, String.class);
        assertSame(str, result);
        
        Integer integer = 10;
        result = converter.convert(integer, Number.class);
        assertSame(integer, result);
    }

    @Test
    public void testConvertArrayToArray() {
        Integer[] source = {1, 2, 3};
        Object result = converter.convert(source, Number[].class);
        assertArrayEquals(source, (Number[]) result);
        
        Double[] converted = (Double[]) converter.convert(source, Double[].class);
        assertArrayEquals(new Double[]{1.0, 2.0, 3.0}, converted);
    }

    @Test
    public void testConvertArrayToCollection() {
        String[] source = {"a", "b", "c"};
        Collection<?> result = (Collection<?>) converter.convert(source, List.class);
        assertEquals(Arrays.asList(source), result);
        
        result = (Collection<?>) converter.convert(source, Set.class);
        assertEquals(new HashSet<>(Arrays.asList(source)), result);
    }

    @Test
    public void testConvertArrayToOtherTypeWithNonEmptyArray() {
        Integer[] source = {1, 2, 3};
        Object result = converter.convert(source, Integer.class);
        assertEquals(1, result);
    }

    @Test
    public void testConvertArrayToOtherTypeWithEmptyArray() {
        String[] source = {};
        Object result = converter.convert(source, String.class);
        assertEquals("", result);
    }

    @Test
    public void testConvertCollectionToArray() {
        List<Integer> source = Arrays.asList(4, 5, 6);
        Object result = converter.convert(source, Integer[].class);
        assertArrayEquals(new Integer[]{4, 5, 6}, (Integer[]) result);
        
        Set<Double> doubleSet = new HashSet<>(Arrays.asList(1.1, 2.2));
        result = converter.convert(doubleSet, Double[].class);
        assertArrayEquals(new Double[]{1.1, 2.2}, (Double[]) result);
    }

    @Test
    public void testConvertCollectionToCollection() {
        List<String> source = Arrays.asList("x", "y");
        Collection<?> result = (Collection<?>) converter.convert(source, Set.class);
        assertEquals(new HashSet<>(source), result);
        
        result = (Collection<?>) converter.convert(source, List.class);
        assertEquals(source, result);
    }

    @Test
    public void testConvertCollectionToOtherTypeWithNonEmpty() {
        List<String> source = Arrays.asList("hello", "world");
        Object result = converter.convert(source, String.class);
        assertEquals("hello", result);
    }

    @Test
    public void testConvertCollectionToOtherTypeWithEmpty() {
        List<String> source = Collections.emptyList();
        Object result = converter.convert(source, String.class);
        assertEquals("", result);
    }

    @Test
    public void testConvertToString() {
        Object obj = 123;
        Object result = converter.convert(obj, String.class);
        assertEquals("123", result);
        
        obj = true;
        result = converter.convert(obj, String.class);
        assertEquals("true", result);
    }

    @Test
    public void testConvertBooleanToNumber() {
        Object result = converter.convert(Boolean.TRUE, Integer.class);
        assertEquals(Integer.valueOf(1), result);
        
        result = converter.convert(Boolean.FALSE, Double.class);
        assertEquals(Double.valueOf(0.0), result);
    }

    @Test
    public void testConvertBooleanToAtomicBoolean() {
        try {
            Object result = converter.convert(Boolean.TRUE, java.util.concurrent.atomic.AtomicBoolean.class);
            assertTrue(((java.util.concurrent.atomic.AtomicBoolean) result).get());
            
            result = converter.convert(Boolean.FALSE, java.util.concurrent.atomic.AtomicBoolean.class);
            assertFalse(((java.util.concurrent.atomic.AtomicBoolean) result).get());
        } catch (Exception e) {
            fail("Exception should not be thrown for AtomicBoolean conversion");
        }
    }

    @Test
    public void testConvertNumberToBoolean() {
        Object result = converter.convert(0, Boolean.class);
        assertEquals(Boolean.FALSE, result);
        
        result = converter.convert(10, Boolean.class);
        assertEquals(Boolean.TRUE, result);
        
        result = converter.convert(-1.5, Boolean.class);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    public void testConvertNumberToNumber() {
        Object result = converter.convert(5, Double.class);
        assertEquals(Double.valueOf(5.0), result);
        
        result = converter.convert(3.14, Integer.class);
        assertEquals(Integer.valueOf(3), result);
        
        result = converter.convert(2L, BigInteger.class);
        assertEquals(BigInteger.valueOf(2), result);
    }

    @Test
    public void testConvertStringToPrimitiveSuccess() {
        Object result = converter.convert("true", Boolean.class);
        assertEquals(Boolean.TRUE, result);
        
        result = converter.convert("123", Integer.class);
        assertEquals(Integer.valueOf(123), result);
        
        result = converter.convert("3.14", Double.class);
        assertEquals(Double.valueOf(3.14), result);
        
        result = converter.convert("A", Character.class);
        assertEquals(Character.valueOf('A'), result);
    }

    @Test
    public void testConvertStringToPrimitiveFailure() {
        Object result = converter.convert("notANumber", Integer.class);
        assertThrows(NumberFormatException.class, () -> {
            Integer.parseInt((String) "notANumber");
        });
    }

    @Test
    public void testConvertWithConverterExists() {
        // Assuming Date converter is registered in ConvertUtils
        // For the purpose of this test, we'll mock a converter
        Converter mockConverter = Mockito.mock(Converter.class);
        Mockito.when(mockConverter.convert(Date.class, "2023-01-01")).thenReturn(new Date(1672531200000L));
        org.apache.commons.beanutils.ConvertUtils.register(mockConverter, Date.class);
        
        Object result = converter.convert("2023-01-01", Date.class);
        assertEquals(new Date(1672531200000L), result);
        
        org.apache.commons.beanutils.ConvertUtils.deregister(Date.class);
    }

    @Test
    public void testConvertWithNoConverterThrowsException() {
        Object obj = new Object();
        assertThrows(JXPathTypeConversionException.class, () -> {
            converter.convert(obj, Date.class);
        });
    }

    @Test
    public void testConvertWithArrayContainingNulls() {
        String[] source = {"a", null, "c"};
        Object result = converter.convert(source, String[].class);
        assertArrayEquals(source, (String[]) result);
    }

    @Test
    public void testConvertToAtomicInteger() {
        try {
            Object result = converter.convert(5, java.util.concurrent.atomic.AtomicInteger.class);
            assertEquals(5, ((java.util.concurrent.atomic.AtomicInteger) result).get());
        } catch (Exception e) {
            fail("Exception should not be thrown for AtomicInteger conversion");
        }
    }

    @Test
    public void testConvertToAtomicLong() {
        try {
            Object result = converter.convert(10L, java.util.concurrent.atomic.AtomicLong.class);
            assertEquals(10L, ((java.util.concurrent.atomic.AtomicLong) result).get());
        } catch (Exception e) {
            fail("Exception should not be thrown for AtomicLong conversion");
        }
    }

    @Test
    public void testConvertNodeSetToArray() {
        NodeSet nodeSet = Mockito.mock(NodeSet.class);
        List<Object> values = Arrays.asList("1", "2", "3");
        Mockito.when(nodeSet.getValues()).thenReturn(values);
        
        Object result = converter.convert(nodeSet, String[].class);
        assertArrayEquals(new String[]{"1", "2", "3"}, (String[]) result);
    }

    @Test
    public void testConvertPointerToArray() {
        Pointer pointer = Mockito.mock(Pointer.class);
        Mockito.when(pointer.getValue()).thenReturn(new String[]{"x", "y"});
        
        Object result = converter.convert(pointer, String[].class);
        assertArrayEquals(new String[]{"x", "y"}, (String[]) result);
    }

    @Test
    public void testConvertUnsupportedTypeThrowsException() {
        Object obj = new ArrayList<>();
        assertThrows(JXPathTypeConversionException.class, () -> {
            converter.convert(obj, Map.class);
        });
    }

    @Test
    public void testConvertEmptyStringToPrimitive() {
        Object result = converter.convert("", Integer.class);
        assertThrows(NumberFormatException.class, () -> {
            Integer.parseInt("");
        });
    }

    @Test
    public void testConvertEmptyCollectionToOtherType() {
        List<String> source = Collections.emptyList();
        Object result = converter.convert(source, String.class);
        assertEquals("", result);
    }

    @Test
    public void testConvertEmptyArrayToOtherType() {
        Integer[] source = {};
        Object result = converter.convert(source, String.class);
        assertEquals("", result);
    }

    @Test
    public void testConvertArrayWithInconvertibleElement() {
        Object[] source = {1, "two", 3};
        assertThrows(JXPathTypeConversionException.class, () -> {
            converter.convert(source, Integer[].class);
        });
    }

    @Test
    public void testConvertCollectionWithInconvertibleElement() {
        List<Object> source = Arrays.asList(1, "two", 3);
        assertThrows(NumberFormatException.class, () -> {
            converter.convert(source, Integer.class);
        });
    }

    @Test
    public void testConvertUnsupportedCollectionType() {
        // Define an abstract collection type
        class AbstractCollectionImpl<E> extends AbstractCollection<E> {
            @Override
            public Iterator<E> iterator() {
                return Collections.emptyIterator();
            }

            @Override
            public int size() {
                return 0;
            }
        }
        Collection<Integer> source = new AbstractCollectionImpl<>();
        assertThrows(JXPathInvalidAccessException.class, () -> {
            converter.convert(source, AbstractCollectionImpl.class);
        });
    }

    @Test
    public void testConvertToImmutableCollection() {
        List<String> source = Arrays.asList("a", "b");
        Collection<?> result = (Collection<?>) converter.convert(source, List.class);
        assertThrows(UnsupportedOperationException.class, () -> {
            ((List<?>) result).add("c");
        });
    }
}