package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jsoup.parser.TokenQueue;

public class TokenQueue_escapeCssIdentifier_2_1_Test {

    @Test
    @DisplayName("Input contains multiple consecutive NULL characters, each replaced with the replacement character")
    void TC22_escapeCssIdentifier_multiple_null_characters() {
        // GIVEN
        String input = "abc\u0000\u0000def";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("abc\uFFFD\uFFFDdef", result);
    }

    @Test
    @DisplayName("Input ends with a hyphen followed by a non-digit, non-hyphen character, ensuring hyphen is appended and final character is escaped")
    void TC23_escapeCssIdentifier_hyphen_followed_by_non_digit_non_hyphen() {
        // GIVEN
        String input = "-a!";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("-a\\!", result);
    }

    @Test
    @DisplayName("Input contains characters that require multiple different escape sequences, ensuring each is correctly escaped")
    void TC24_escapeCssIdentifier_multiple_special_escapes() {
        // GIVEN
        String input = "a@b#c$";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("a\\@b\\#c\\$", result);
    }

    @Test
    @DisplayName("Input starts with a non-hyphen, non-digit character followed by a control character, ensuring proper escaping")
    void TC25_escapeCssIdentifier_start_non_hyphen_non_digit_followed_by_control() {
        // GIVEN
        String input = "a\u0001b";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("a\\001b", result);
    }

    @Test
    @DisplayName("Input contains only non-identifier special characters, ensuring all are escaped")
    void TC26_escapeCssIdentifier_all_special_characters() {
        // GIVEN
        String input = "@#!$";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("\\@\\#\\!\\$", result);
    }
}