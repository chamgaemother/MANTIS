package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_1_1_Test {

    @Test
    @DisplayName("metaphone word starting with 'AE' removes initial 'A'")
    void TC31() {
        // GIVEN
        String txt = "aether";
        Metaphone metaphone = new Metaphone();
        // WHEN
        String result = metaphone.metaphone(txt);
        // THEN
        assertEquals("ITHER", result, "Initial 'A' should be removed when followed by 'E'");
    }

    @Test
    @DisplayName("metaphone word starting with 'A' not followed by 'E'")
    void TC32() {
        // GIVEN
        String txt = "apple";
        Metaphone metaphone = new Metaphone();
        // WHEN
        String result = metaphone.metaphone(txt);
        // THEN
        assertEquals("APL", result, "Initial 'A' should be retained when not followed by 'E'");
    }

    @Test
    @DisplayName("metaphone word starting with 'W' not followed by 'R' or 'H'")
    void TC33() {
        // GIVEN
        String txt = "west";
        Metaphone metaphone = new Metaphone();
        // WHEN
        String result = metaphone.metaphone(txt);
        // THEN
        assertEquals("WST", result, "Initial 'W' should be retained when not followed by 'R' or 'H'");
    }

    @Test
    @DisplayName("metaphone word with 'SCI' sequence does not convert to 'S'")
    void TC34() {
        // GIVEN
        String txt = "science";
        Metaphone metaphone = new Metaphone();
        // WHEN
        String result = metaphone.metaphone(txt);
        // THEN
        assertEquals("SNS", result, "'SCI' sequence should not be converted to 'S'");
    }

    @Test
    @DisplayName("metaphone word with 'CH' before vowel to 'X'")
    void TC35() {
        // GIVEN
        String txt = "chase";
        Metaphone metaphone = new Metaphone();
        // WHEN
        String result = metaphone.metaphone(txt);
        // THEN
        assertEquals("XSS", result, "'CH' followed by a vowel should be converted to 'X'");
    }
}