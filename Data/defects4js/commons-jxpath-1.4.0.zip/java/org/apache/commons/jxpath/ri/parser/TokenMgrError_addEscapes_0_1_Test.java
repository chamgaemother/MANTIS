package org.apache.commons.jxpath.ri.parser;

import org.apache.commons.jxpath.ri.parser.TokenMgrError;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TokenMgrError_addEscapes_0_1_Test {

    @Test
    @DisplayName("addEscapes with empty string returns empty string")
    void TC01_addEscapes_empty_string_returns_empty_string() {
        // GIVEN
        String input = "";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("", result);
    }

    @Test
    @DisplayName("addEscapes with string containing only normal printable characters")
    void TC02_addEscapes_printable_characters() {
        // GIVEN
        String input = "HelloWorld";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("HelloWorld", result);
    }

    @Test
    @DisplayName("addEscapes with null input throws NullPointerException")
    void TC03_addEscapes_null_input_throws_NullPointerException() {
        // GIVEN
        String input = null;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> TokenMgrError.addEscapes(input));
    }

    @Test
    @DisplayName("addEscapes with single null character (char 0)")
    void TC04_addEscapes_single_null_char() {
        // GIVEN
        String input = "\0";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("", result);
    }

    @Test
    @DisplayName("addEscapes with single backspace character")
    void TC05_addEscapes_single_backspace_character() {
        // GIVEN
        String input = "\b";

        // WHEN
        String result = TokenMgrError.addEscapes(input);

        // THEN
        assertEquals("\\b", result);
    }
}