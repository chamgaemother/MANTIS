package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CyclicXYItemRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("drawItem with getPlotLines() true, only rangeAxis is CyclicNumberAxis, and cycle splitting occurs")
    public void TC11_drawItem_withPlotLinesTrue_RangeAxisCyclic_CycleSplittingOccurs() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = spy(new CyclicXYItemRenderer());
        
        // Mock methods using reflection if necessary
        // Assuming getPlotLines() is public; otherwise, use reflection to access it
        when(renderer.getPlotLines()).thenReturn(true);
        
        CyclicNumberAxis mockRangeAxis = mock(CyclicNumberAxis.class);
        when(mockRangeAxis.getCycleBound()).thenReturn(100.0);
        when(mockRangeAxis.isBoundMappedToLastCycle()).thenReturn(false);
        
        ValueAxis mockDomainAxis = mock(ValueAxis.class); // Not cyclic
        
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getXValue(0, 0)).thenReturn(90.0);
        when(mockDataset.getYValue(0, 0)).thenReturn(50.0);
        when(mockDataset.getXValue(0, 1)).thenReturn(110.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(60.0);
        
        Graphics2D mockG2 = mock(Graphics2D.class);
        XYItemRendererState mockState = mock(XYItemRendererState.class);
        Rectangle2D mockDataArea = mock(Rectangle2D.class);
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        XYPlot mockPlot = mock(XYPlot.class);
        CrosshairState mockCrosshairState = mock(CrosshairState.class);
        
        // WHEN
        renderer.drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                         mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
        
        // THEN
        // Verify that super.drawItem is called twice due to cycle splitting
        verify(renderer, times(2)).drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                                           mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
    }

    @Test
    @DisplayName("drawItem with getPlotLines() true, only rangeAxis is CyclicNumberAxis, cycle splitting occurs multiple times")
    public void TC12_drawItem_withPlotLinesTrue_RangeAxisCyclic_MultipleCycleSplits() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = spy(new CyclicXYItemRenderer());
        when(renderer.getPlotLines()).thenReturn(true);
        
        CyclicNumberAxis mockRangeAxis = mock(CyclicNumberAxis.class);
        when(mockRangeAxis.getCycleBound()).thenReturn(100.0);
        when(mockRangeAxis.isBoundMappedToLastCycle()).thenReturn(false, true);
        
        ValueAxis mockDomainAxis = mock(ValueAxis.class); // Not cyclic
        
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getXValue(0, 1)).thenReturn(190.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(190.0);
        when(mockDataset.getXValue(0, 2)).thenReturn(210.0);
        when(mockDataset.getYValue(0, 2)).thenReturn(210.0);
        
        Graphics2D mockG2 = mock(Graphics2D.class);
        XYItemRendererState mockState = mock(XYItemRendererState.class);
        Rectangle2D mockDataArea = mock(Rectangle2D.class);
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        XYPlot mockPlot = mock(XYPlot.class);
        CrosshairState mockCrosshairState = mock(CrosshairState.class);
        
        // WHEN
        renderer.drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                         mockDomainAxis, mockRangeAxis, mockDataset, 0, 2, mockCrosshairState, 0);
        
        // THEN
        // Verify that super.drawItem is called three times due to multiple cycle splittings
        verify(renderer, times(3)).drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                                           mockDomainAxis, mockRangeAxis, mockDataset, 0, 2, mockCrosshairState, 0);
    }

    @Test
    @DisplayName("drawItem with getPlotLines() true, only rangeAxis is CyclicNumberAxis, and cycle splitting does not occur")
    public void TC13_drawItem_withPlotLinesTrue_RangeAxisCyclic_NoCycleSplitting() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = spy(new CyclicXYItemRenderer());
        when(renderer.getPlotLines()).thenReturn(true);
        
        CyclicNumberAxis mockRangeAxis = mock(CyclicNumberAxis.class);
        when(mockRangeAxis.getCycleBound()).thenReturn(100.0);
        when(mockRangeAxis.isBoundMappedToLastCycle()).thenReturn(false);
        
        ValueAxis mockDomainAxis = mock(ValueAxis.class); // Not cyclic
        
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getXValue(0, 0)).thenReturn(90.0);
        when(mockDataset.getYValue(0, 0)).thenReturn(50.0);
        when(mockDataset.getXValue(0, 1)).thenReturn(95.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(60.0);
        
        Graphics2D mockG2 = mock(Graphics2D.class);
        XYItemRendererState mockState = mock(XYItemRendererState.class);
        Rectangle2D mockDataArea = mock(Rectangle2D.class);
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        XYPlot mockPlot = mock(XYPlot.class);
        CrosshairState mockCrosshairState = mock(CrosshairState.class);
        
        // WHEN
        renderer.drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                         mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
        
        // THEN
        // Verify that super.drawItem is called once without cycle splitting
        verify(renderer, times(1)).drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                                           mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
    }

    @Test
    @DisplayName("drawItem with getPlotLines() true, only rangeAxis is CyclicNumberAxis, and cycleBound is exactly matched by a y-value")
    public void TC14_drawItem_withPlotLinesTrue_RangeAxisCyclic_YValueEqualsCycleBound() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = spy(new CyclicXYItemRenderer());
        when(renderer.getPlotLines()).thenReturn(true);
        
        CyclicNumberAxis mockRangeAxis = mock(CyclicNumberAxis.class);
        when(mockRangeAxis.getCycleBound()).thenReturn(100.0);
        when(mockRangeAxis.isBoundMappedToLastCycle()).thenReturn(false);
        
        ValueAxis mockDomainAxis = mock(ValueAxis.class); // Not cyclic
        
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getXValue(0, 0)).thenReturn(90.0);
        when(mockDataset.getYValue(0, 0)).thenReturn(100.0); // Y equals cycleBound
        when(mockDataset.getXValue(0, 1)).thenReturn(110.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(100.0); // Y equals cycleBound
        
        Graphics2D mockG2 = mock(Graphics2D.class);
        XYItemRendererState mockState = mock(XYItemRendererState.class);
        Rectangle2D mockDataArea = mock(Rectangle2D.class);
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        XYPlot mockPlot = mock(XYPlot.class);
        CrosshairState mockCrosshairState = mock(CrosshairState.class);
        
        // WHEN
        renderer.drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                         mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
        
        // THEN
        // Verify that super.drawItem is called twice due to cycle splitting at exact bound
        verify(renderer, times(2)).drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                                           mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
    }

    @Test
    @DisplayName("drawItem with getPlotLines() true, only rangeAxis is CyclicNumberAxis, and cycleBound is not matched by any y-value")
    public void TC15_drawItem_withPlotLinesTrue_RangeAxisCyclic_NoCycleBoundMatch() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = spy(new CyclicXYItemRenderer());
        when(renderer.getPlotLines()).thenReturn(true);
        
        CyclicNumberAxis mockRangeAxis = mock(CyclicNumberAxis.class);
        when(mockRangeAxis.getCycleBound()).thenReturn(100.0);
        when(mockRangeAxis.isBoundMappedToLastCycle()).thenReturn(false);
        
        ValueAxis mockDomainAxis = mock(ValueAxis.class); // Not cyclic
        
        XYDataset mockDataset = mock(XYDataset.class);
        when(mockDataset.getXValue(0, 0)).thenReturn(90.0);
        when(mockDataset.getYValue(0, 0)).thenReturn(90.0); // Y does not equal cycleBound
        when(mockDataset.getXValue(0, 1)).thenReturn(110.0);
        when(mockDataset.getYValue(0, 1)).thenReturn(90.0); // Y does not equal cycleBound
        
        Graphics2D mockG2 = mock(Graphics2D.class);
        XYItemRendererState mockState = mock(XYItemRendererState.class);
        Rectangle2D mockDataArea = mock(Rectangle2D.class);
        PlotRenderingInfo mockInfo = mock(PlotRenderingInfo.class);
        XYPlot mockPlot = mock(XYPlot.class);
        CrosshairState mockCrosshairState = mock(CrosshairState.class);
        
        // WHEN
        renderer.drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                         mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
        
        // THEN
        // Verify that super.drawItem is called once without cycle splitting
        verify(renderer, times(1)).drawItem(mockG2, mockState, mockDataArea, mockInfo, mockPlot,
                                           mockDomainAxis, mockRangeAxis, mockDataset, 0, 1, mockCrosshairState, 0);
    }
}