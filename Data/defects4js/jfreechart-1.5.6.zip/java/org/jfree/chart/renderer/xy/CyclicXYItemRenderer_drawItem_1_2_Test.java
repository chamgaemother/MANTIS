package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CyclicXYItemRenderer_drawItem_1_2_Test {

    @Test
    @DisplayName("drawItem with getPlotLines() true, CyclicXYItemRenderer receives a null dataset, throws NullPointerException")
    void TC16_drawItem_nullDataset_throwsNPE() {
        // Arrange
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);

        CyclicNumberAxis mockRangeAxis = mock(CyclicNumberAxis.class);
        when(mockRangeAxis.getCycleBound()).thenReturn(100.0);
        when(mockRangeAxis.isBoundMappedToLastCycle()).thenReturn(false);

        ValueAxis mockDomainAxis = mock(ValueAxis.class);
        // Assuming getPlotLines() returns true by default

        XYDataset dataset = null;
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, mockDomainAxis, mockRangeAxis, dataset, series, item, crosshairState, pass);
        });
    }
}