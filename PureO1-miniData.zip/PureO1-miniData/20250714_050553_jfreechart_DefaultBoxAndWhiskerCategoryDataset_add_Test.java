package org.jfree.data.statistics;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jfree.data.Range;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DefaultBoxAndWhiskerCategoryDatasetTest {

    private DefaultBoxAndWhiskerCategoryDataset dataset;

    @BeforeEach
    public void setUp() {
        dataset = new DefaultBoxAndWhiskerCategoryDataset();
    }

    @Test
    public void testAddFirstItemSetsMinAndMax() {
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(5.0, 3.0, 4.0, 2.0, 6.0, Arrays.asList());
        dataset.add(item, "Row1", "Col1");
        assertEquals(2.0, dataset.getRangeLowerBound(false));
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemWithNewMaxUpdatesMaximum() {
        BoxAndWhiskerItem firstItem = new BoxAndWhiskerItem(5.0, 3.0, 4.0, 2.0, 6.0, Arrays.asList());
        dataset.add(firstItem, "Row1", "Col1");
        BoxAndWhiskerItem secondItem = new BoxAndWhiskerItem(7.0, 4.0, 5.0, 3.0, 8.0, Arrays.asList());
        dataset.add(secondItem, "Row2", "Col2");
        assertEquals(2.0, dataset.getRangeLowerBound(false));
        assertEquals(8.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemWithNewMinUpdatesMinimum() {
        BoxAndWhiskerItem firstItem = new BoxAndWhiskerItem(5.0, 3.0, 4.0, 2.0, 6.0, Arrays.asList());
        dataset.add(firstItem, "Row1", "Col1");
        BoxAndWhiskerItem secondItem = new BoxAndWhiskerItem(5.0, 1.0, 3.0, null, 5.0, Arrays.asList());
        dataset.add(secondItem, "Row2", "Col2");
        assertEquals(1.0, dataset.getRangeLowerBound(false));
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemWithoutChangingMinOrMax() {
        BoxAndWhiskerItem firstItem = new BoxAndWhiskerItem(5.0, 2.0, 3.0, 1.0, 6.0, Arrays.asList());
        dataset.add(firstItem, "Row1", "Col1");
        BoxAndWhiskerItem secondItem = new BoxAndWhiskerItem(4.0, 3.0, 4.0, 2.0, 5.0, Arrays.asList());
        dataset.add(secondItem, "Row2", "Col2");
        assertEquals(1.0, dataset.getRangeLowerBound(false));
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemWithNullMinOutlierDoesNotUpdateMinimum() {
        BoxAndWhiskerItem firstItem = new BoxAndWhiskerItem(5.0, null, 4.0, null, 6.0, Arrays.asList());
        dataset.add(firstItem, "Row1", "Col1");
        BoxAndWhiskerItem secondItem = new BoxAndWhiskerItem(5.0, null, 4.0, null, 6.0, Arrays.asList());
        dataset.add(secondItem, "Row2", "Col2");
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemWithNullMaxOutlierDoesNotUpdateMaximum() {
        BoxAndWhiskerItem firstItem = new BoxAndWhiskerItem(5.0, 2.0, 4.0, 1.0, null, Arrays.asList());
        dataset.add(firstItem, "Row1", "Col1");
        BoxAndWhiskerItem secondItem = new BoxAndWhiskerItem(5.0, 3.0, 5.0, 2.0, null, Arrays.asList());
        dataset.add(secondItem, "Row2", "Col2");
        assertEquals(1.0, dataset.getRangeLowerBound(false));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
    }

    @Test
    public void testAddItemToCellHoldingCurrentMinCallsUpdateBounds() {
        BoxAndWhiskerItem firstItem = new BoxAndWhiskerItem(5.0, 2.0, 4.0, 1.0, 6.0, Arrays.asList());
        dataset.add(firstItem, "Row1", "Col1");
        BoxAndWhiskerItem secondItem = new BoxAndWhiskerItem(5.0, 1.5, 3.5, null, 5.5, Arrays.asList());
        dataset.add(secondItem, "Row1", "Col1");
        assertEquals(1.5, dataset.getRangeLowerBound(false));
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemToCellHoldingCurrentMaxCallsUpdateBounds() {
        BoxAndWhiskerItem firstItem = new BoxAndWhiskerItem(5.0, 2.0, 4.0, 1.0, 6.0, Arrays.asList());
        dataset.add(firstItem, "Row1", "Col1");
        BoxAndWhiskerItem secondItem = new BoxAndWhiskerItem(5.0, 2.5, 4.5, null, 7.0, Arrays.asList());
        dataset.add(secondItem, "Row1", "Col1");
        assertEquals(1.0, dataset.getRangeLowerBound(false));
        assertEquals(7.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemWithBothMinAndMaxOutliersNull() {
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(5.0, null, 4.0, null, null, Arrays.asList());
        dataset.add(item, "Row1", "Col1");
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
    }

    @Test
    public void testAddItemWithNaNMinAndMaxOutliers() {
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(5.0, Double.NaN, 4.0, Double.NaN, Double.NaN, Arrays.asList());
        dataset.add(item, "Row1", "Col1");
        assertTrue(Double.isNaN(dataset.getRangeLowerBound(false)));
        assertTrue(Double.isNaN(dataset.getRangeUpperBound(false)));
    }

    @Test
    public void testAddItemWithInfiniteMinOutlier() {
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(5.0, Double.NEGATIVE_INFINITY, 4.0, null, 6.0, Arrays.asList());
        dataset.add(item, "Row1", "Col1");
        assertEquals(Double.NEGATIVE_INFINITY, dataset.getRangeLowerBound(false));
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddItemWithInfiniteMaxOutlier() {
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(5.0, 2.0, 4.0, 1.0, Double.POSITIVE_INFINITY, Arrays.asList());
        dataset.add(item, "Row1", "Col1");
        assertEquals(1.0, dataset.getRangeLowerBound(false));
        assertEquals(Double.POSITIVE_INFINITY, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddNullItemThrowsException() {
        assertThrows(NullPointerException.class, () -> {
            dataset.add(null, "Row1", "Col1");
        });
    }

    @Test
    public void testAddItemWithNullRowKeyThrowsException() {
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(5.0, 2.0, 4.0, 1.0, 6.0, Arrays.asList());
        assertThrows(NullPointerException.class, () -> {
            dataset.add(item, null, "Col1");
        });
    }

    @Test
    public void testAddItemWithNullColumnKeyThrowsException() {
        BoxAndWhiskerItem item = new BoxAndWhiskerItem(5.0, 2.0, 4.0, 1.0, 6.0, Arrays.asList());
        assertThrows(NullPointerException.class, () -> {
            dataset.add(item, "Row1", null);
        });
    }

    @Test
    public void testAddItemWithSameMinAndMaxDoesNotDuplicateBounds() {
        BoxAndWhiskerItem item1 = new BoxAndWhiskerItem(5.0, 3.0, 4.0, 3.0, 5.0, Arrays.asList());
        dataset.add(item1, "Row1", "Col1");
        BoxAndWhiskerItem item2 = new BoxAndWhiskerItem(5.0, 3.0, 4.0, 3.0, 5.0, Arrays.asList());
        dataset.add(item2, "Row2", "Col2");
        assertEquals(3.0, dataset.getRangeLowerBound(false));
        assertEquals(5.0, dataset.getRangeUpperBound(false));
    }

    @Test
    public void testAddMultipleItemsUpdatesBoundsCorrectly() {
        BoxAndWhiskerItem item1 = new BoxAndWhiskerItem(5.0, 1.0, 3.0, 1.0, 4.0, Arrays.asList());
        BoxAndWhiskerItem item2 = new BoxAndWhiskerItem(6.0, 0.5, 2.5, 0.5, 5.5, Arrays.asList());
        BoxAndWhiskerItem item3 = new BoxAndWhiskerItem(7.0, 2.0, 4.0, null, 6.0, Arrays.asList());
        dataset.add(item1, "Row1", "Col1");
        dataset.add(item2, "Row2", "Col2");
        dataset.add(item3, "Row3", "Col3");
        assertEquals(0.5, dataset.getRangeLowerBound(false));
        assertEquals(6.0, dataset.getRangeUpperBound(false));
    }

}