package org.apache.commons.math3.geometry.euclidean.twod.hull;

import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class AklToussaintHeuristic_reducePoints_0_1_Test {

    @Test
    @DisplayName("reducePoints with an empty collection returns an empty collection")
    void TC01_reducePoints_empty_collection() throws Exception {
        // GIVEN
        Collection<Vector2D> points = Collections.emptyList();

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertTrue(result.isEmpty(), "The result should be an empty collection");
    }

    @Test
    @DisplayName("reducePoints with exactly three points returns the original collection")
    void TC02_reducePoints_three_points() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(1, 1);
        Vector2D p3 = new Vector2D(2, 2);
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertEquals(points, result, "The result should be equal to the original collection of three points");
    }

    @Test
    @DisplayName("reducePoints with four points forming a valid quadrilateral")
    void TC03_reducePoints_four_valid_points() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(1, 0);
        Vector2D p3 = new Vector2D(1, 1);
        Vector2D p4 = new Vector2D(0, 1);
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertEquals(points, result, "The result should be equal to the original collection of four valid points forming a quadrilateral");
    }

    @Test
    @DisplayName("reducePoints with four points resulting in an invalid quadrilateral")
    void TC04_reducePoints_four_invalid_points() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(1, 1);
        Vector2D p3 = new Vector2D(2, 2);
        Vector2D p4 = new Vector2D(3, 3);
        Collection<Vector2D> points = Arrays.asList(p1, p2, p3, p4);
        // Assuming buildQuadrilateral will result in size < 3 for these points

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertEquals(points, result, "The result should be equal to the original collection as quadrilateral size is less than 3");
    }

    @Test
    @DisplayName("reducePoints with a single point returns the original collection")
    void TC05_reducePoints_single_point() throws Exception {
        // GIVEN
        Vector2D p1 = new Vector2D(0, 0);
        Collection<Vector2D> points = Collections.singletonList(p1);

        // WHEN
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // THEN
        assertEquals(points, result, "The result should be equal to the original collection containing the single point");
    }
}