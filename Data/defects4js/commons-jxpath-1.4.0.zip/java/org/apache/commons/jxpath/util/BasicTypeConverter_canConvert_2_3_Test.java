package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.Collection;

public class BasicTypeConverter_canConvert_2_3_Test {

    @Test
    @DisplayName("object is Collection with all elements convertible to useType array, should return true")
    public void TC44_CollectionAllElementsConvertibleToArray() {
        // Initialize the converter
        BasicTypeConverter converter = new BasicTypeConverter();

        // Given
        Collection<Object> collection = Arrays.asList(1, 2, 3);
        Class<?> toType = Number[].class;

        // When
        boolean result = converter.canConvert(collection, toType);

        // Then
        assertTrue(result, "Expected canConvert to return true when all elements in Collection are convertible to array");
    }

    @Test
    @DisplayName("object is Collection with some elements not convertible to useType array, should return false")
    public void TC45_CollectionSomeElementsNotConvertibleToArray() {
        // Initialize the converter
        BasicTypeConverter converter = new BasicTypeConverter();

        // Given
        Collection<Object> collection = Arrays.asList(1, "two", 3);
        Class<?> toType = Number[].class;

        // When
        boolean result = converter.canConvert(collection, toType);

        // Then
        assertFalse(result, "Expected canConvert to return false when some elements in Collection are not convertible to array");
    }
}