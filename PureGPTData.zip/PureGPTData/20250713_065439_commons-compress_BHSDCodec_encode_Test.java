import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.apache.commons.compress.harmony.pack200.BHSDCodec;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import static org.junit.jupiter.api.Assertions.*;

class BHSDCodecTest {

    private BHSDCodec unsignedCodec;
    private BHSDCodec signed1sComplementCodec;
    private BHSDCodec signed2sComplementCodec;
    private BHSDCodec deltaCodec;

    @BeforeEach
    void setUp() {
        unsignedCodec = new BHSDCodec(2, 128);
        signed1sComplementCodec = new BHSDCodec(2, 128, 1);
        signed2sComplementCodec = new BHSDCodec(2, 128, 2);
        deltaCodec = new BHSDCodec(2, 128, 0, 1);
    }

    @Test
    void testEncodeUnsignedWithinBounds() throws Pack200Exception {
        byte[] result = unsignedCodec.encode(100, 0);
        assertNotNull(result);
    }

    @Test
    void testEncodeUnsignedOutOfBoundsNegative() {
        Exception exception = assertThrows(Pack200Exception.class, () ->
            unsignedCodec.encode(-1, 0));
        assertEquals("The codec (2,128) does not encode the value -1", exception.getMessage());
    }

    @Test
    void testEncodeUnsignedOutOfBoundsPositive() {
        Exception exception = assertThrows(Pack200Exception.class, () ->
            unsignedCodec.encode(Integer.MAX_VALUE, 0));
        assertEquals("The codec (2,128) does not encode the value 2147483647", exception.getMessage());
    }

    @Test
    void testEncodeSigned1sComplementNegative() throws Pack200Exception {
        byte[] result = signed1sComplementCodec.encode(-100, 0);
        assertNotNull(result);
    }

    @Test
    void testEncodeSigned2sComplementNegative() throws Pack200Exception {
        byte[] result = signed2sComplementCodec.encode(-100, 0);
        assertNotNull(result);
    }

    @Test
    void testEncodeSigned1sComplementPositive() throws Pack200Exception {
        byte[] result = signed1sComplementCodec.encode(100, 0);
        assertNotNull(result);
    }

    @Test
    void testEncodeSigned2sComplementPositive() throws Pack200Exception {
        byte[] result = signed2sComplementCodec.encode(100, 0);
        assertNotNull(result);
    }

    @Test
    void testEncodeDeltaCodec() throws Pack200Exception {
        byte[] result = deltaCodec.encode(100, 50);
        assertNotNull(result);
    }

    @Test
    void testEncodeDeltaBoundary() throws Pack200Exception {
        long largest = deltaCodec.largest();
        byte[] result = deltaCodec.encode((int) largest, (int) largest - 1);
        assertNotNull(result);
    }

    @Test
    void testEncodeDeltaException() {
        long largest = deltaCodec.largest();
        Exception exception = assertThrows(Pack200Exception.class, () ->
            deltaCodec.encode((int) largest + 1, 0));
        assertEquals("The codec (2,128,,1) does not encode the value 2147483648", exception.getMessage());
    }

    @Test
    void testEncodeSignedNegativeEdge() {
        long smallest = signed2sComplementCodec.smallest();
        Exception exception = assertThrows(Pack200Exception.class, () ->
            signed2sComplementCodec.encode((int) smallest - 1, 0));
        assertEquals("The codec (2,128,2) does not encode the value -2147483648", exception.getMessage());
    }
}