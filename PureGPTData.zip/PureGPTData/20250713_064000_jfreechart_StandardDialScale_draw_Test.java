import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.jfree.chart.plot.dial.DialLayerChangeEvent;
import org.jfree.chart.util.Args;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.text.NumberFormat;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

class StandardDialScaleTest {

    private StandardDialScale scale;
    private Graphics2D g2;
    private DialPlot plot;

    @BeforeEach
    void setUp() {
        scale = new StandardDialScale();
        g2 = Mockito.mock(Graphics2D.class);
        plot = Mockito.mock(DialPlot.class);
    }

    @Test
    void testDrawWithDefaultValues() {
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
        scale.draw(g2, plot, frame, view);
        // Assuming no exceptions occur, we cover the method's execution,
        // including checking lines in draw method
    }

    @Test
    void testDrawWithTickLabelsNotVisible() {
        scale.setTickLabelsVisible(false);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
        scale.draw(g2, plot, frame, view);
        // Test checks when tick labels are not visible
    }

    @Test
    void testDrawWithNegativeExtent() {
        scale.setExtent(-170);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
        scale.draw(g2, plot, frame, view);
        // Covers negative extent handling
    }

    @Test
    void testDrawWithMinorTicks() {
        scale.setMinorTickCount(2);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
        scale.draw(g2, plot, frame, view);
        // Covers presence of minor ticks
    }

    @Test
    void testDrawWithFirstTickLabelNotVisible() {
        scale.setFirstTickLabelVisible(false);
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
        scale.draw(g2, plot, frame, view);
        // Covers first tick label visibility
    }

    @Test
    void testDrawWithCustomTickLabelFormatter() {
        scale.setTickLabelFormatter(NumberFormat.getInstance(Locale.GERMAN));
        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
        scale.draw(g2, plot, frame, view);
        // Covers custom tick label formatter
    }

    @Test
    void testDrawWithNullGraphics() {
        assertThrows(NullPointerException.class, () -> {
            Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
            Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
            scale.draw(null, plot, frame, view);
        });
    }

    @Test
    void testDrawWithNullPlot() {
        assertThrows(NullPointerException.class, () -> {
            Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
            Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
            scale.draw(g2, null, frame, view);
        });
    }

    @Test
    void testDrawWithNullFrame() {
        assertThrows(NullPointerException.class, () -> {
            Rectangle2D view = new Rectangle2D.Double(0, 0, 100, 100);
            scale.draw(g2, plot, null, view);
        });
    }

    @Test
    void testDrawWithNullView() {
        assertThrows(NullPointerException.class, () -> {
            Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
            scale.draw(g2, plot, frame, null);
        });
    }
}