package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import java.awt.Paint;
import java.awt.GradientPaint;
import java.awt.LinearGradientPaint;
import java.awt.RadialGradientPaint;
import java.awt.Point;
import java.awt.Color;
import java.util.Arrays;

public class PaintUtils_equal_0_1_Test {

    @Test
    @DisplayName("Both p1 and p2 refer to the same Paint instance, expect true")
    void TC01() {
        // Given
        Paint p = new GradientPaint(0f, 0f, Color.RED, 10f, 10f, Color.BLUE, false);
        // When
        boolean result = PaintUtils.equal(p, p);
        // Then
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are null, expect true")
    void TC02() {
        // Given
        Paint p1 = null;
        Paint p2 = null;
        // When
        boolean result = PaintUtils.equal(p1, p2);
        // Then
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("p1 is null and p2 is not null, expect false")
    void TC03() {
        // Given
        Paint p1 = null;
        Paint p2 = new GradientPaint(0f, 0f, Color.RED, 10f, 10f, Color.BLUE, false);
        // When
        boolean result = PaintUtils.equal(p1, p2);
        // Then
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("p1 is not null and p2 is null, expect false")
    void TC04() {
        // Given
        Paint p1 = new LinearGradientPaint(
            new Point(0, 0), 
            new Point(10, 10), 
            new float[] {0f, 1f}, 
            new Color[] {Color.RED, Color.BLUE}
        );
        Paint p2 = null;
        // When
        boolean result = PaintUtils.equal(p1, p2);
        // Then
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("Both p1 and p2 are GradientPaint instances with identical properties, expect true")
    void TC05() {
        // Given
        GradientPaint gp1 = new GradientPaint(
            0f, 0f, Color.RED, 
            10f, 10f, Color.BLUE, 
            false
        );
        GradientPaint gp2 = new GradientPaint(
            0f, 0f, Color.RED, 
            10f, 10f, Color.BLUE, 
            false
        ); // identical to gp1
        // When
        boolean result = PaintUtils.equal(gp1, gp2);
        // Then
        Assertions.assertTrue(result);
    }

}