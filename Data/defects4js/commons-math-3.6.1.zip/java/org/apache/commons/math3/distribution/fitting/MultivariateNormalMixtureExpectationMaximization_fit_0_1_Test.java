package org.apache.commons.math3.distribution.fitting;

import org.apache.commons.math3.distribution.MixtureMultivariateNormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class MultivariateNormalMixtureExpectationMaximization_fit_0_1_Test {

    @Test
    @DisplayName("fit with maxIterations less than 1 throws NotStrictlyPositiveException")
    void TC01_fit_throws_exception_for_maxIterations_less_than_1() throws Exception {
        // GIVEN
        double[] weights = {1.0};
        double[][] means = {{0.0, 0.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}};
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        int maxIterations = 0;
        double threshold = 1e-6;

        double[][] data = {{0.0, 0.0}};
        MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN & THEN
        assertThrows(NotStrictlyPositiveException.class, () -> {
            optimizer.fit(initialMixture, maxIterations, threshold);
        });
    }

    @Test
    @DisplayName("fit with threshold less than Double.MIN_VALUE throws NotStrictlyPositiveException")
    void TC02_fit_throws_exception_for_threshold_less_than_Double_MIN_VALUE() throws Exception {
        // GIVEN
        double[] weights = {1.0};
        double[][] means = {{0.0, 0.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}};
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        int maxIterations = 10;
        double threshold = 0.0;

        double[][] data = {{0.0, 0.0}};
        MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN & THEN
        assertThrows(NotStrictlyPositiveException.class, () -> {
            optimizer.fit(initialMixture, maxIterations, threshold);
        });
    }

    @Test
    @DisplayName("fit with mismatched mean columns and data columns throws DimensionMismatchException")
    void TC03_fit_throws_DimensionMismatchException_for_mismatched_dimensions() throws Exception {
        // GIVEN
        double[] weights = {1.0};
        double[][] means = {{0.0, 0.0, 0.0}}; // 3 mean columns
        double[][][] covariances = {{{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}}};
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        int maxIterations = 10;
        double threshold = 1e-6;

        double[][] data = {{0.0, 0.0}}; // 2 data columns
        MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN & THEN
        assertThrows(DimensionMismatchException.class, () -> {
            optimizer.fit(initialMixture, maxIterations, threshold);
        });
    }

    @Test
    @DisplayName("fit with valid inputs where loop does not execute due to immediate convergence throws ConvergenceException")
    void TC04_fit_throws_ConvergenceException_due_to_immediate_convergence() throws Exception {
        // GIVEN
        double[] weights = {1.0};
        double[][] means = {{0.0, 0.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}};
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        int maxIterations = 10;
        double threshold = 1e-6;

        double[][] data = {{0.0, 0.0}}; // Single data point to cause immediate convergence
        MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN & THEN
        assertThrows(ConvergenceException.class, () -> {
            optimizer.fit(initialMixture, maxIterations, threshold);
        });
    }

    @Test
    @DisplayName("fit executes one iteration and converges successfully")
    void TC05_fit_converges_after_one_iteration() throws Exception {
        // GIVEN
        double[] weights = {0.6, 0.4};
        double[][] means = {{1.0, 1.0}, {5.0, 5.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}, {{1.0, 0.0}, {0.0, 1.0}}};
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        int maxIterations = 10;
        double threshold = 1e-6;

        double[][] data = {{1.1, 0.9}, {5.2, 4.8}, {1.0, 1.0}, {5.0, 5.0}};
        MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN
        optimizer.fit(initialMixture, maxIterations, threshold);

        // THEN
        // Access 'fittedModel' via reflection to verify updates
        Field fittedModelField = optimizer.getClass().getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(optimizer);

        assertNotNull(fittedModel, "fittedModel should not be null after fitting.");

        // Example assertions (these would need to be adjusted based on expected results)
        assertEquals(2, fittedModel.getComponents().size(), "Number of components should remain the same.");

        // Further assertions can be added here to verify the means and covariances have been updated appropriately
    }
}
