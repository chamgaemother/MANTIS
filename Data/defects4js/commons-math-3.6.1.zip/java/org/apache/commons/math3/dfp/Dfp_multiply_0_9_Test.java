package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;

import java.lang.reflect.Field;

public class Dfp_multiply_0_9_Test {

    @Test
    @DisplayName("Multiplying Dfp numbers where one operand is negative infinity and the other is finite")
    public void TC41_multiply_negative_infinity_with_finite() throws Exception {
        // Initialize field
        DfpField field = new DfpField(20); // Set up field with valid radix digits

        // Initialize operands
        Dfp a = new Dfp(field, (byte) -1, Dfp.INFINITE);
        Dfp b = new Dfp(field, 1.0); // finite value

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        Assertions.assertTrue(result.isInfinite(), "Result should be infinite");

        // Access 'sign' field via reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte sign = signField.getByte(result);
        Assertions.assertEquals(-1, sign, "Result sign should be -1");
    }

//    @Test
//    @DisplayName("Multiplying Dfp numbers where one operand is infinite and the other is finite zero")
//    public void TC42_multiply_infinite_with_finite_zero() throws Exception {
//        // Initialize field
//        DfpField field = new DfpField(20); // Set up field with valid radix digits
//
//        // Initialize operands
//        Dfp a = new Dfp(field, (byte) 1, Dfp.INFINITE); // corrected infinite initialization
//        Dfp b = new Dfp(field, 0.0); // finite zero
//
//        // Perform multiplication
//        Dfp result = a.multiply(b);
//
//        // Assertions
//        Assertions.assertTrue(result.isNaN(), "Result should be NaN");
//
//        // Access 'IEEEFlagsBits' via public method
//        int flags = field.getIEEEFlagsBits();
//        Assertions.assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");
//    }

    @Test
    @DisplayName("Multiplying Dfp numbers where both operands have non-zero mantissas leading to non-zero product")
    public void TC43_multiply_two_non_zero_finite_Dfp_numbers() throws Exception {
        // Initialize field
        DfpField field = new DfpField(20); // Set up field with valid radix digits

        // Initialize operands
        Dfp a = new Dfp(field, 2.0); // non-zero finite
        Dfp b = new Dfp(field, 3.0); // non-zero finite

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        Assertions.assertFalse(result.isZero(), "Result should not be zero");

        Dfp expectedProduct = new Dfp(field, 6.0);
        Assertions.assertEquals(expectedProduct, result, "Result should be equal to expected product");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where one operand is the multiplicative identity one")
    public void TC44_multiply_with_multiplicative_identity() throws Exception {
        // Initialize field
        DfpField field = new DfpField(20); // Set up field with valid radix digits

        // Initialize operands
        Dfp a = new Dfp(field, 5.0); // sample value
        Dfp one = new Dfp(field, 1.0); // multiplicative identity

        // Perform multiplication
        Dfp result = a.multiply(one);

        // Assertions
        Assertions.assertEquals(a, result, "Result should be equal to the original Dfp 'a'");
    }

}
