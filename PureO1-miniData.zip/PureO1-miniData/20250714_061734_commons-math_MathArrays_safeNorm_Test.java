package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

class MathArraysTest {

    @Test
    @DisplayName("Test safeNorm with null input")
    void testSafeNorm_NullInput() {
        assertThrows(NullPointerException.class, () -> MathArrays.safeNorm(null));
    }

    @Test
    @DisplayName("Test safeNorm with empty array")
    void testSafeNorm_EmptyArray() {
        double[] v = new double[0];
        double norm = MathArrays.safeNorm(v);
        assertEquals(0.0, norm, 1e-12);
    }

    @Test
    @DisplayName("Test safeNorm with all zeros")
    void testSafeNorm_AllZeros() {
        double[] v = {0.0, 0.0, 0.0};
        double norm = MathArrays.safeNorm(v);
        assertEquals(0.0, norm, 1e-12);
    }

    @Test
    @DisplayName("Test safeNorm with small values < rdwarf")
    void testSafeNorm_SmallValues() {
        double[] v = {1e-21, 2e-22, 3e-23};
        double norm = MathArrays.safeNorm(v);
        // s3 should accumulate the normalized small values
        // norm should be sqrt(s3) * x3max where x3max is 3e-23
        // s3 = 1 + (s3 * r * r) or s3 += r * r
        // This is complex to calculate manually, but we can ensure it's >0 and finite
        assertTrue(norm > 0.0);
        assertTrue(Double.isFinite(norm));
    }

    @Test
    @DisplayName("Test safeNorm with large values > agiant")
    void testSafeNorm_LargeValues() {
        double[] v = {1e+20, 2e+21, 3e+22};
        double norm = MathArrays.safeNorm(v);
        // Expected Euclidean norm: sqrt(1e40 + 4e+42 + 9e+44) ≈ 3e+22
        assertEquals(3e+22, norm, 1e+16);
    }

    @Test
    @DisplayName("Test safeNorm with mix of normal, small, and large values")
    void testSafeNorm_MixedValues() {
        double[] v = {3.0, 4.0};
        double norm = MathArrays.safeNorm(v);
        assertEquals(5.0, norm, 1e-12);
    }

    @Test
    @DisplayName("Test safeNorm with one element")
    void testSafeNorm_SingleElement() {
        double[] v = {5.0};
        double norm = MathArrays.safeNorm(v);
        assertEquals(5.0, norm, 1e-12);
    }

    @Test
    @DisplayName("Test safeNorm with negative values")
    void testSafeNorm_NegativeValues() {
        double[] v = {-3.0, -4.0};
        double norm = MathArrays.safeNorm(v);
        assertEquals(5.0, norm, 1e-12);
    }

    @Test
    @DisplayName("Test safeNorm with mixed positive and negative values")
    void testSafeNorm_MixedSignValues() {
        double[] v = {-3.0, 4.0};
        double norm = MathArrays.safeNorm(v);
        assertEquals(5.0, norm, 1e-12);
    }

    @Test
    @DisplayName("Test safeNorm with infinity")
    void testSafeNorm_Infinity() {
        double[] v = {Double.POSITIVE_INFINITY, 1.0};
        double norm = MathArrays.safeNorm(v);
        assertTrue(Double.isInfinite(norm));
    }

    @Test
    @DisplayName("Test safeNorm with NaN")
    void testSafeNorm_NaN() {
        double[] v = {Double.NaN, 1.0};
        double norm = MathArrays.safeNorm(v);
        assertTrue(Double.isNaN(norm));
    }

    @Test
    @DisplayName("Test safeNorm with agiant very small")
    void testSafeNorm_AgiantVerySmall() {
        double[] v = {1e-10, 2e-10, 3e-10};
        double norm = MathArrays.safeNorm(v);
        double expected = Math.sqrt(1e-20 + 4e-20 + 9e-20);
        assertEquals(expected, norm, 1e-30);
    }

    @Test
    @DisplayName("Test safeNorm with agiant very large")
    void testSafeNorm_AgiantVeryLarge() {
        double[] v = {1e+10, 2e+10, 3e+10};
        double norm = MathArrays.safeNorm(v);
        double expected = Math.sqrt(1e+20 + 4e+20 + 9e+20);
        assertEquals(expected, norm, 1e+10);
    }

    @Test
    @DisplayName("Test safeNorm with one very small and one very large value")
    void testSafeNorm_OneSmallOneLarge() {
        double[] v = {1e-21, 1e+22};
        double norm = MathArrays.safeNorm(v);
        double expected = 1e+22;
        assertEquals(expected, norm, 1e+16);
    }

    @Test
    @DisplayName("Test safeNorm with subnormal numbers")
    void testSafeNorm_SubnormalNumbers() {
        double[] v = {Double.MIN_VALUE / 2, Double.MIN_VALUE / 3};
        double norm = MathArrays.safeNorm(v);
        double expected = Math.sqrt((Double.MIN_VALUE / 2) * (Double.MIN_VALUE / 2) +
                                    (Double.MIN_VALUE / 3) * (Double.MIN_VALUE / 3));
        assertEquals(expected, norm, 1e-323);
    }

    @Test
    @DisplayName("Test safeNorm with maximum double values")
    void testSafeNorm_MaxDoubleValues() {
        double[] v = {Double.MAX_VALUE, Double.MAX_VALUE};
        double norm = MathArrays.safeNorm(v);
        // This should overflow to infinity
        assertTrue(Double.isInfinite(norm));
    }

    @Test
    @DisplayName("Test safeNorm with a mix including zero")
    void testSafeNorm_MixIncludingZero() {
        double[] v = {0.0, 3.0, 4.0};
        double norm = MathArrays.safeNorm(v);
        assertEquals(5.0, norm, 1e-12);
    }
}