package org.jsoup.nodes;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jsoup.Connection;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.FormElement;
import org.jsoup.parser.Tag;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class FormElement_formData_0_3_Test {

    @Test
    @DisplayName("formData processes radio element with checked attribute")
    public void TC11() throws Exception {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element radio = new Element(Tag.valueOf("input"), "")
                .attr("type", "radio")
                .attr("name", "gender")
                .attr("value", "male")
                .attr("checked", "checked");
        form.addElement(radio);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertEquals(1, data.size());
        assertEquals("gender", data.get(0).key());
        assertEquals("male", data.get(0).value());
    }

    @Test
    @DisplayName("formData processes radio element without checked attribute")
    public void TC12() throws Exception {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element radio = new Element(Tag.valueOf("input"), "")
                .attr("type", "radio")
                .attr("name", "gender")
                .attr("value", "male");
        form.addElement(radio);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertTrue(data.isEmpty());
    }

    @Test
    @DisplayName("formData processes input element with non-empty value")
    public void TC13() throws Exception {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element input = new Element(Tag.valueOf("input"), "")
                .attr("type", "text")
                .attr("name", "username")
                .attr("value", "john_doe");
        form.addElement(input);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertEquals(1, data.size());
        assertEquals("username", data.get(0).key());
        assertEquals("john_doe", data.get(0).value());
    }

    @Test
    @DisplayName("formData processes input element with empty value")
    public void TC14() throws Exception {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);
        Element input = new Element(Tag.valueOf("input"), "")
                .attr("type", "text")
                .attr("name", "email")
                .attr("value", "");
        form.addElement(input);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertEquals(1, data.size());
        assertEquals("email", data.get(0).key());
        assertEquals("", data.get(0).value());
    }

    @Test
    @DisplayName("formData processes multiple form elements including various types")
    public void TC15() throws Exception {
        // GIVEN
        FormElement form = new FormElement(Tag.valueOf("form"), "", null);

        // Text input
        Element textInput = new Element(Tag.valueOf("input"), "")
                .attr("type", "text")
                .attr("name", "username")
                .attr("value", "john_doe");
        form.addElement(textInput);

        // Checkbox
        Element checkbox = new Element(Tag.valueOf("input"), "")
                .attr("type", "checkbox")
                .attr("name", "subscribe")
                .attr("value", "yes")
                .attr("checked", "checked");
        form.addElement(checkbox);

        // Select
        Element select = new Element(Tag.valueOf("select"), "")
                .attr("name", "country");
        Element option = new Element(Tag.valueOf("option"), "")
                .attr("value", "US")
                .attr("selected", "selected");
        select.appendChild(option);
        form.addElement(select);

        // Radio
        Element radio = new Element(Tag.valueOf("input"), "")
                .attr("type", "radio")
                .attr("name", "gender")
                .attr("value", "male")
                .attr("checked", "checked");
        form.addElement(radio);

        // Disabled input
        Element disabledInput = new Element(Tag.valueOf("input"), "")
                .attr("type", "text")
                .attr("name", "disabledField")
                .attr("value", "should_skip")
                .attr("disabled", "disabled");
        form.addElement(disabledInput);

        // WHEN
        List<Connection.KeyVal> data = form.formData();

        // THEN
        assertEquals(3, data.size());
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("username") && kv.value().equals("john_doe")));
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("subscribe") && kv.value().equals("yes")));
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("country") && kv.value().equals("US")));
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("gender") && kv.value().equals("male")));
        // Ensure disabledField is not included
        assertFalse(data.stream().anyMatch(kv -> kv.key().equals("disabledField")));
    }
}