package com.fasterxml.jackson.databind.deser;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonTokenId;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class BeanDeserializer_deserializeFromObject_0_6_Test {

    @Test
    @DisplayName("deserializeFromObject with _beanProperties.find returning a valid SettableBeanProperty")
    public void TC26_deserializeWithValidSettableBeanProperty() throws Exception {
        // Arrange
        JsonParser mockParser = mock(JsonParser.class);
        DeserializationContext mockContext = mock(DeserializationContext.class);

        when(mockParser.hasTokenId(JsonTokenId.ID_FIELD_NAME)).thenReturn(true);
        when(mockParser.currentName()).thenReturn("validProperty");
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.canReadObjectId()).thenReturn(false);

        SettableBeanProperty mockProperty = mock(SettableBeanProperty.class);

        // Initialize BeanDeserializer with the required parameters
        BeanDeserializer beanDeserializer = new BeanDeserializer(null, null, null, null, null, false, null, false);

        Field beanPropertiesField = BeanDeserializer.class.getDeclaredField("_beanProperties");
        beanPropertiesField.setAccessible(true);
        BeanPropertyMap mockBeanPropertyMap = mock(BeanPropertyMap.class);
        when(mockBeanPropertyMap.find("validProperty")).thenReturn(mockProperty);

        beanPropertiesField.set(beanDeserializer, mockBeanPropertyMap);

        // Act
        Object result = beanDeserializer.deserializeFromObject(mockParser, mockContext);

        // Assert
        verify(mockProperty, times(1)).deserializeAndSet(mockParser, mockContext, result);
    }
}
