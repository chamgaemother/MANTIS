package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.Conversion;

public class Conversion_binaryToHexDigit_0_3_Test {

    @Test
    @DisplayName("Returns '6' when src.length > srcPos + 2 and src[srcPos+3] is false, src[srcPos+2] is true, src[srcPos+1] is true, src[srcPos] is false")
    void TC11_Returns6_WhenConditions() {
        boolean[] src = new boolean[] {false, true, true, false};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('6', result);
    }

    @Test
    @DisplayName("Returns '5' when src.length > srcPos + 2 and src[srcPos+3] is false, src[srcPos+2] is true, src[srcPos+1] is false, src[srcPos] is true")
    void TC12_Returns5_WhenConditions() {
        boolean[] src = new boolean[] {true, false, true, false};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('5', result);
    }

    @Test
    @DisplayName("Returns '4' when src.length > srcPos + 2 and src[srcPos+3] is false, src[srcPos+2] is true, src[srcPos+1] is false, src[srcPos] is false")
    void TC13_Returns4_WhenConditions() {
        boolean[] src = new boolean[] {false, false, true, false};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('4', result);
    }

    @Test
    @DisplayName("Returns '3' when src.length > srcPos +1 and src[srcPos+1], src[srcPos] are true")
    void TC14_Returns3_WhenConditions() {
        boolean[] src = new boolean[] {true, true, false};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('3', result);
    }

    @Test
    @DisplayName("Returns '2' when src.length > srcPos +1 and src[srcPos+1] is true, src[srcPos] is false")
    void TC15_Returns2_WhenConditions() {
        boolean[] src = new boolean[] {false, true, false};
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('2', result);
    }
}