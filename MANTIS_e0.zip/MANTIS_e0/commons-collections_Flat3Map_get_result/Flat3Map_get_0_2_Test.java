package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.collections4.map.Flat3Map;

import java.lang.reflect.Field;

public class Flat3Map_get_0_2_Test {

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 3, hash3 matches and keys are equal")
    void TC06() throws Exception {
        Flat3Map map = new Flat3Map();

        // Reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Object key = "existingKey3";
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, key);

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, key.hashCode());

        // Set value3
        Object value3 = "value3";
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, value3);

        Object result = map.get(key);
        assertEquals(value3, result);
    }

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 3, hash3 does not match")
    void TC07() throws Exception {
        Flat3Map map = new Flat3Map();

        // Reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Object key = "nonMatchingKey3";
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "existingKey3"); // key3 is "existingKey3"

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, key.hashCode() + 1); // hash3 does not match key's hashCode

        // Set value2
        Object value2 = "value2";
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, value2);

        Object result = map.get(key);
        assertEquals(value2, result);
    }

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 3, hash3 matches but keys are not equal")
    void TC08() throws Exception {
        Flat3Map map = new Flat3Map();

        // Reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Object key = "nonEqualKey3";
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "differentKey3"); // key3 is "differentKey3"

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, key.hashCode());

        // Set value1
        Object value1 = "value1";
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, value1);

        Object result = map.get(key);
        assertEquals(value1, result);
    }

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 2, hash2 matches and keys are equal")
    void TC09() throws Exception {
        Flat3Map map = new Flat3Map();

        // Reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Object key = "existingKey2";
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key);

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, key.hashCode());

        // Set value2
        Object value2 = "value2";
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, value2);

        Object result = map.get(key);
        assertEquals(value2, result);
    }

    @Test
    @DisplayName("get with delegateMap null, key not null, size is 2, hash2 does not match")
    void TC10() throws Exception {
        Flat3Map map = new Flat3Map();

        // Reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Object key = "nonMatchingKey2";
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "existingKey2");

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, key.hashCode() + 1);

        // Set value1
        Object value1 = "value1";
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, value1);

        Object result = map.get(key);
        assertEquals(value1, result);
    }
}