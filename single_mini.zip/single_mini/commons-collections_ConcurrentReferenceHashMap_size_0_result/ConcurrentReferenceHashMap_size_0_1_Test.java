package org.apache.commons.collections4.map;

import java.lang.reflect.Field;
import java.util.Objects;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

public class ConcurrentReferenceHashMap_size_0_1_Test {

    @Test
    @DisplayName("size() returns 0 when ConcurrentReferenceHashMap is empty")
    public void TC01_size_empty_map() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        
        // WHEN
        int result = map.size();
        
        // THEN
        Assertions.assertEquals(0, result);
    }
    
    @Test
    @DisplayName("size() returns correct count when all segments have consistent modCounts on first attempt")
    public void TC02_size_consistent_modCounts_first_attempt() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        // Add entries to map ensuring modCounts are consistent
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        int expectedCount = 3;
        
        // WHEN
        int result = map.size();
        
        // THEN
        Assertions.assertEquals(expectedCount, result);
    }
    
    @Test
    @DisplayName("size() retries and succeeds on second attempt with consistent modCounts")
    public void TC03_size_retries_succeeds_on_second_attempt() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        // Add entries to map
        map.put("key1", "value1");
        map.put("key2", "value2");
        int expectedCount = 2;
        
        // Using reflection to get segments and simulate modCount inconsistency
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);
        
        for (Object segment : segments) {
            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            int currentModCount = modCountField.getInt(segment);
            modCountField.setInt(segment, currentModCount + 1);
        }
        
        // WHEN
        int result = map.size();
        
        // THEN
        Assertions.assertEquals(expectedCount, result);
    }
    
    @Test
    @DisplayName("size() resorts to locking after maximum retries due to continuous modCount changes")
    public void TC04_size_resorts_to_locking_after_retries() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        // Add entries to map
        map.put("key1", "value1");
        map.put("key2", "value2");
        int expectedCount = 2;
        
        // Using reflection to get segments and simulate continuous modCount changes
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);
        
        int retriesBeforeLock = 2; // Adjust based on RETRIES_BEFORE_LOCK if known
        for (int i = 0; i < retriesBeforeLock; i++) {
            for (Object segment : segments) {
                Field modCountField = segment.getClass().getDeclaredField("modCount");
                modCountField.setAccessible(true);
                int currentModCount = modCountField.getInt(segment);
                modCountField.setInt(segment, currentModCount + 1);
            }
        }
        
        // WHEN
        int result = map.size();
        
        // THEN
        Assertions.assertEquals(expectedCount, result);
    }
    
    @Test
    @DisplayName("size() handles single segment correctly without retries")
    public void TC05_size_single_segment() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
            .setConcurrencyLevel(1)
            .build();
        // Add entries to single segment
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        int expectedCount = 3;
        
        // WHEN
        int result = map.size();
        
        // THEN
        Assertions.assertEquals(expectedCount, result);
    }
}