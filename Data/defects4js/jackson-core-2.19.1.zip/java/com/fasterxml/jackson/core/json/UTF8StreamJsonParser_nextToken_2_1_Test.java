package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

public class UTF8StreamJsonParser_nextToken_2_1_Test {

    @Test
    @DisplayName("Parses a string with valid Unicode escape sequences correctly")
    public void TC39() throws Exception {
        // Arrange
        String json = "\"Hello\\u0041World\"";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Using reflection to instantiate IOContext
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor(JsonFactory.class, InputStream.class);
        ioContextCtor.setAccessible(true);
        IOContext ctxt = ioContextCtor.newInstance(new JsonFactory(), input);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser using reflection
        Constructor<UTF8StreamJsonParser> parserCtor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class,
                ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserCtor.setAccessible(true);
        UTF8StreamJsonParser parser = parserCtor.newInstance(ctxt, 0, input, null, sym, new byte[0], 0, json.getBytes(StandardCharsets.UTF_8).length, 0, true);

        // Act
        JsonToken token = parser.nextToken();

        // Assert
        assertEquals(JsonToken.VALUE_STRING, token, "Token should be VALUE_STRING");
        assertEquals("HelloAWorld", parser.getText(), "Parsed string does not match expected value");
    }

    @Test
    @DisplayName("Throws exception on malformed Unicode escape sequence in string")
    public void TC40() throws Exception {
        // Arrange
        String json = "\"Invalid\\u004G\"";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Using reflection to instantiate IOContext
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor(JsonFactory.class, InputStream.class);
        ioContextCtor.setAccessible(true);
        IOContext ctxt = ioContextCtor.newInstance(new JsonFactory(), input);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser using reflection
        Constructor<UTF8StreamJsonParser> parserCtor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class,
                ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserCtor.setAccessible(true);
        UTF8StreamJsonParser parser = parserCtor.newInstance(ctxt, 0, input, null, sym, new byte[0], 0, json.getBytes(StandardCharsets.UTF_8).length, 0, true);

        // Act & Assert
        assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        }, "Expected JsonParseException due to malformed Unicode escape sequence");
    }

    @Test
    @DisplayName("Throws exception when parsing a number with incomplete exponent")
    public void TC41() throws Exception {
        // Arrange
        String json = "1.23e";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Using reflection to instantiate IOContext
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor(JsonFactory.class, InputStream.class);
        ioContextCtor.setAccessible(true);
        IOContext ctxt = ioContextCtor.newInstance(new JsonFactory(), input);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser using reflection
        Constructor<UTF8StreamJsonParser> parserCtor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class,
                ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserCtor.setAccessible(true);
        UTF8StreamJsonParser parser = parserCtor.newInstance(ctxt, 0, input, null, sym, new byte[0], 0, json.getBytes(StandardCharsets.UTF_8).length, 0, true);

        // Act & Assert
        parser.nextToken(); // Parses the number
        assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        }, "Expected JsonParseException due to incomplete exponent in number");
    }

    @Test
    @DisplayName("Parses a deeply nested JSON object correctly")
    public void TC42() throws Exception {
        // Arrange
        String json = "{\"a\":{\"b\":{\"c\":{\"d\":1}}}}";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Using reflection to instantiate IOContext
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor(JsonFactory.class, InputStream.class);
        ioContextCtor.setAccessible(true);
        IOContext ctxt = ioContextCtor.newInstance(new JsonFactory(), input);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser using reflection
        Constructor<UTF8StreamJsonParser> parserCtor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class,
                ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserCtor.setAccessible(true);
        UTF8StreamJsonParser parser = parserCtor.newInstance(ctxt, 0, input, null, sym, new byte[0], 0, json.getBytes(StandardCharsets.UTF_8).length, 0, true);

        // Act
        JsonToken token;
        int count = 0;
        while ((token = parser.nextToken()) != JsonToken.END_OBJECT) {
            if (token == JsonToken.FIELD_NAME && "d".equals(parser.getCurrentName())) {
                parser.nextToken(); // Move to value
                count = parser.getIntValue();
            }
        }

        // Assert
        assertEquals(1, count, "Parsed value of 'd' should be 1");
    }

    @Test
    @DisplayName("Parses a very large array spanning multiple buffer loads")
    public void TC43() throws Exception {
        // Arrange
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 1; i <= 10000; i++) {
            sb.append(i).append(",");
        }
        sb.deleteCharAt(sb.length() - 1); // Remove last comma
        sb.append("]");
        String json = sb.toString();
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Using reflection to instantiate IOContext
        Constructor<IOContext> ioContextCtor = IOContext.class.getDeclaredConstructor(JsonFactory.class, InputStream.class);
        ioContextCtor.setAccessible(true);
        IOContext ctxt = ioContextCtor.newInstance(new JsonFactory(), input);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser using reflection
        Constructor<UTF8StreamJsonParser> parserCtor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class,
                ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserCtor.setAccessible(true);
        UTF8StreamJsonParser parser = parserCtor.newInstance(ctxt, 0, input, null, sym, new byte[0], 0, json.getBytes(StandardCharsets.UTF_8).length, 0, true);

        // Act
        JsonToken token;
        int count = 0;
        while ((token = parser.nextToken()) != JsonToken.END_ARRAY) {
            if (token == JsonToken.VALUE_NUMBER_INT) {
                count++;
            }
        }

        // Assert
        assertEquals(10000, count, "Parser should iterate through all 10,000 elements");
    }
}