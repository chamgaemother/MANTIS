package org.apache.commons.jxpath.ri.model.jdom;

import org.jdom.CDATA;
import org.jdom.Comment;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class JDOMNodePointer_setValue_0_1_Test {

    @Test
    @DisplayName("node is Text and converted string is non-null and not empty, sets text content")
    void TC01_setValue_With_Text_Node_NonEmpty_String() {
        // Arrange
        Text node = new Text("Old Value");
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);
        String newValue = "New Value";

        // Act
        pointer.setValue(newValue);

        // Assert
        assertEquals("New Value", node.getText(), "Text content should be updated to the new value");
    }

    @Test
    @DisplayName("node is Text and converted string is null, removes text content")
    void TC02_setValue_With_Text_Node_Null_String() {
        // Arrange
        Text node = new Text("Old Value");
        Element parent = new Element("parent");
        parent.addContent(node);
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);
        Object newValue = null;

        // Act
        pointer.setValue(newValue);

        // Assert
        assertFalse(parent.getContent().contains(node), "Text node should be removed from its parent");
    }

    @Test
    @DisplayName("node is Text and converted string is empty, removes text content")
    void TC03_setValue_With_Text_Node_Empty_String() {
        // Arrange
        Text node = new Text("Old Value");
        Element parent = new Element("parent");
        parent.addContent(node);
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);
        String newValue = "";

        // Act
        pointer.setValue(newValue);

        // Assert
        assertFalse(parent.getContent().contains(node), "Text node should be removed from its parent");
    }

    @Test
    @DisplayName("node is Element and value is an Element, adds child Element content")
    void TC04_setValue_With_Element_Node_Element_Value() {
        // Arrange
        Element node = new Element("parent");
        Element child = new Element("child");
        node.addContent(child);
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);
        Element newValue = new Element("newChild");

        // Act
        pointer.setValue(newValue);

        // Assert
        assertTrue(node.getContent().contains(newValue), "New child Element should be added to the node");
    }

    @Test
    @DisplayName("node is Element and value is a Document, adds Document content")
    void TC05_setValue_With_Element_Node_Document_Value() {
        // Arrange
        Element node = new Element("parent");
        Document doc = new Document(new Element("docChild"));
        node.addContent(doc.getRootElement());
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);
        Document newValue = new Document(new Element("newDocChild"));

        // Act
        pointer.setValue(newValue);

        // Assert
        assertTrue(node.getContent().contains(newValue.getRootElement()), "Document's root Element should be added to the node");
    }
}
