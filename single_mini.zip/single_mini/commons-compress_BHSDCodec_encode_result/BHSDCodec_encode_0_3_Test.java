package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.compress.pack200.Pack200Exception;

import java.lang.reflect.Field;
import java.util.Arrays;

public class BHSDCodec_encode_0_3_Test {

    @Test
    @DisplayName("encode throws Pack200Exception when unsigned adjustment results in negative z")
    void TC11_encodeThrowsExceptionWhenUnsignedAdjustmentResultsInNegativeZ() throws Exception {
        // Initialize BHSDCodec with arbitrary valid parameters
        BHSDCodec codec = new BHSDCodec(5, 100, 0, 0);

        // Set isSigned to false
        Field isSignedField = BHSDCodec.class.getDeclaredField("s");
        isSignedField.setAccessible(true);
        isSignedField.setInt(codec, 0);

        // Set isDelta to false
        Field isDeltaField = BHSDCodec.class.getDeclaredField("d");
        isDeltaField.setAccessible(true);
        isDeltaField.setInt(codec, 0);

        // Set smallest to -200
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, -200L);

        // Set largest to 200
        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 200L);

        // Set b, l, h, cardinality to arbitrary valid values
        Field bField = BHSDCodec.class.getDeclaredField("b");
        bField.setAccessible(true);
        bField.setInt(codec, 5);

        Field lField = BHSDCodec.class.getDeclaredField("l");
        lField.setAccessible(true);
        lField.setInt(codec, 10);

        Field hField = BHSDCodec.class.getDeclaredField("h");
        hField.setAccessible(true);
        hField.setInt(codec, 100);

        Field cardinalityField = BHSDCodec.class.getDeclaredField("cardinality");
        cardinalityField.setAccessible(true);
        cardinalityField.setLong(codec, 5000L);

        int value = -100;
        int p1 = 5;

        Pack200Exception exception = Assertions.assertThrows(Pack200Exception.class, () -> {
            codec.encode(value, p1);
        });

        Assertions.assertEquals("unable to encode", exception.getMessage());
    }

    @Test
    @DisplayName("encode handles zero iterations in the encoding loop when b is 0")
    void TC12_encodeHandlesZeroIterationsWhenBIsZero() throws Exception {
        // Initialize BHSDCodec with b=1 to satisfy constructor constraints
        BHSDCodec codec = new BHSDCodec(1, 100, 0, 0);

        // Set b to 0
        Field bField = BHSDCodec.class.getDeclaredField("b");
        bField.setAccessible(true);
        bField.setInt(codec, 0);

        // Set isSigned to false
        Field isSignedField = BHSDCodec.class.getDeclaredField("s");
        isSignedField.setAccessible(true);
        isSignedField.setInt(codec, 0);

        // Set isDelta to false
        Field isDeltaField = BHSDCodec.class.getDeclaredField("d");
        isDeltaField.setAccessible(true);
        isDeltaField.setInt(codec, 0);

        // Set smallest and largest to include the value
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, -1000L);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 1000L);

        // Set l and h to arbitrary valid values
        Field lField = BHSDCodec.class.getDeclaredField("l");
        lField.setAccessible(true);
        lField.setInt(codec, 10);

        Field hField = BHSDCodec.class.getDeclaredField("h");
        hField.setAccessible(true);
        hField.setInt(codec, 100);

        Field cardinalityField = BHSDCodec.class.getDeclaredField("cardinality");
        cardinalityField.setAccessible(true);
        cardinalityField.setLong(codec, 5000L);

        int value = 50;
        int p1 = 0;

        byte[] result = codec.encode(value, p1);

        Assertions.assertArrayEquals(new byte[0], result);
    }

    @Test
    @DisplayName("encode processes single iteration when b is 1 and z is less than l")
    void TC13_encodeSingleIterationWhenBIsOneAndZLessThanL() throws Exception {
        // Initialize BHSDCodec with b=1
        BHSDCodec codec = new BHSDCodec(1, 100, 0, 0);

        // Set isSigned to false
        Field isSignedField = BHSDCodec.class.getDeclaredField("s");
        isSignedField.setAccessible(true);
        isSignedField.setInt(codec, 0);

        // Set isDelta to false
        Field isDeltaField = BHSDCodec.class.getDeclaredField("d");
        isDeltaField.setAccessible(true);
        isDeltaField.setInt(codec, 0);

        // Set smallest and largest to include the value
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, -1000L);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 1000L);

        // Set l to a value greater than z (value=10)
        Field lField = BHSDCodec.class.getDeclaredField("l");
        lField.setAccessible(true);
        lField.setInt(codec, 20);

        Field hField = BHSDCodec.class.getDeclaredField("h");
        hField.setAccessible(true);
        hField.setInt(codec, 100);

        Field cardinalityField = BHSDCodec.class.getDeclaredField("cardinality");
        cardinalityField.setAccessible(true);
        cardinalityField.setLong(codec, 5000L);

        int value = 10;
        int p1 = 1;

        byte[] result = codec.encode(value, p1);

        Assertions.assertArrayEquals(new byte[] {10}, result);
    }

    @Test
    @DisplayName("encode processes multiple iterations when b > 1 and z requires multiple bytes")
    void TC14_encodeMultipleIterationsWhenBGreaterThanOneAndZRequiresMultipleBytes() throws Exception {
        // Initialize BHSDCodec with b=3
        BHSDCodec codec = new BHSDCodec(3, 100, 0, 0);

        // Set isSigned to false
        Field isSignedField = BHSDCodec.class.getDeclaredField("s");
        isSignedField.setAccessible(true);
        isSignedField.setInt(codec, 0);

        // Set isDelta to false
        Field isDeltaField = BHSDCodec.class.getDeclaredField("d");
        isDeltaField.setAccessible(true);
        isDeltaField.setInt(codec, 0);

        // Set smallest and largest to include the value
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, -1000L);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 1000L);

        // Set l and h to values that require multiple bytes for z=300
        Field lField = BHSDCodec.class.getDeclaredField("l");
        lField.setAccessible(true);
        lField.setInt(codec, 50);

        Field hField = BHSDCodec.class.getDeclaredField("h");
        hField.setAccessible(true);
        hField.setInt(codec, 100);

        Field cardinalityField = BHSDCodec.class.getDeclaredField("cardinality");
        cardinalityField.setAccessible(true);
        cardinalityField.setLong(codec, 5000L);

        int value = 300;
        int p1 = 3;

        byte[] result = codec.encode(value, p1);

        // Expected bytes: {0}
        Assertions.assertArrayEquals(new byte[] {0}, result);
    }

    @Test
    @DisplayName("encode processes loop with break when byteN is less than l")
    void TC15_encodeLoopBreaksWhenByteNLessThanL() throws Exception {
        // Initialize BHSDCodec with b=5
        BHSDCodec codec = new BHSDCodec(5, 100, 0, 0);

        // Set isSigned to false
        Field isSignedField = BHSDCodec.class.getDeclaredField("s");
        isSignedField.setAccessible(true);
        isSignedField.setInt(codec, 0);

        // Set isDelta to false
        Field isDeltaField = BHSDCodec.class.getDeclaredField("d");
        isDeltaField.setAccessible(true);
        isDeltaField.setInt(codec, 0);

        // Set smallest and largest to include the value
        Field smallestField = BHSDCodec.class.getDeclaredField("smallest");
        smallestField.setAccessible(true);
        smallestField.setLong(codec, -1000L);

        Field largestField = BHSDCodec.class.getDeclaredField("largest");
        largestField.setAccessible(true);
        largestField.setLong(codec, 1000L);

        // Set l to a value greater than byteN to ensure break after first iteration
        Field lField = BHSDCodec.class.getDeclaredField("l");
        lField.setAccessible(true);
        lField.setInt(codec, 20);

        Field hField = BHSDCodec.class.getDeclaredField("h");
        hField.setAccessible(true);
        hField.setInt(codec, 100);

        Field cardinalityField = BHSDCodec.class.getDeclaredField("cardinality");
        cardinalityField.setAccessible(true);
        cardinalityField.setLong(codec, 5000L);

        int value = 15;
        int p1 = 5;

        byte[] result = codec.encode(value, p1);

        Assertions.assertArrayEquals(new byte[] {15}, result);
    }
}