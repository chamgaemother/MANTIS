package org.joda.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;
import java.util.Map;
import org.joda.time.DurationFieldType;

/**
 * JUnit 5 test class for the PeriodType.forFields method.
 */
public class PeriodType_forFields_1_1_Test {

    @Test
    @DisplayName("forFields with a single supported field (minutes) creates a PeriodType supporting only minutes")
    public void TC14_forFieldsSingleSupportedField() throws Exception {
        // Arrange
        DurationFieldType[] types = { DurationFieldType.minutes() };

        // Use reflection to access and clear the private static cache cTypes
        Field cacheField = PeriodType.class.getDeclaredField("cTypes");
        cacheField.setAccessible(true);
        Map<?, ?> cache = (Map<?, ?>) cacheField.get(null);
        cache.clear();

        // Act
        PeriodType result = PeriodType.forFields(types);

        // Assert
        Assertions.assertTrue(result.isSupported(DurationFieldType.minutes()), "Minutes should be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.years()), "Years should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.months()), "Months should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.weeks()), "Weeks should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.days()), "Days should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.hours()), "Hours should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.seconds()), "Seconds should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.millis()), "Millis should not be supported");
    }

    @Test
    @DisplayName("forFields with duplicate supported fields (years) creates a PeriodType supporting years without duplication")
    public void TC15_forFieldsDuplicateSupportedFields() throws Exception {
        // Arrange
        DurationFieldType[] types = { DurationFieldType.years(), DurationFieldType.years() };

        // Use reflection to access and clear the private static cache cTypes
        Field cacheField = PeriodType.class.getDeclaredField("cTypes");
        cacheField.setAccessible(true);
        Map<?, ?> cache = (Map<?, ?>) cacheField.get(null);
        cache.clear();

        // Act
        PeriodType result = PeriodType.forFields(types);

        // Assert
        Assertions.assertTrue(result.isSupported(DurationFieldType.years()), "Years should be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.months()), "Months should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.weeks()), "Weeks should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.days()), "Days should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.hours()), "Hours should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.minutes()), "Minutes should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.seconds()), "Seconds should not be supported");
        Assertions.assertFalse(result.isSupported(DurationFieldType.millis()), "Millis should not be supported");
        Assertions.assertEquals(1, result.size(), "PeriodType should contain only one field (years)");
    }
}