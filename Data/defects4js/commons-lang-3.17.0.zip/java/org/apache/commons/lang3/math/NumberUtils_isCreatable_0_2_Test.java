package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_isCreatable_0_2_Test {

    @Test
    @DisplayName("isCreatable(\"0xGHI\") returns false for invalid hexadecimal characters")
    void test_TC06() {
        // Given
        String input = "0xGHI";
        
        // When
        boolean result = NumberUtils.isCreatable(input);
        
        // Then
        assertFalse(result, "Expected isCreatable to return false for input '0xGHI'");
    }

    @Test
    @DisplayName("isCreatable(\"123.45\") returns true for a valid decimal number")
    void test_TC07() {
        // Given
        String input = "123.45";
        
        // When
        boolean result = NumberUtils.isCreatable(input);
        
        // Then
        assertTrue(result, "Expected isCreatable to return true for input '123.45'");
    }

    @Test
    @DisplayName("isCreatable(\"1.2.3\") returns false for multiple decimal points")
    void test_TC08() {
        // Given
        String input = "1.2.3";
        
        // When
        boolean result = NumberUtils.isCreatable(input);
        
        // Then
        assertFalse(result, "Expected isCreatable to return false for input '1.2.3'");
    }

    @Test
    @DisplayName("isCreatable(\"6.022e23\") returns true for a valid scientific notation")
    void test_TC09() {
        // Given
        String input = "6.022e23";
        
        // When
        boolean result = NumberUtils.isCreatable(input);
        
        // Then
        assertTrue(result, "Expected isCreatable to return true for input '6.022e23'");
    }

    @Test
    @DisplayName("isCreatable(\"1e\") returns false when exponent lacks digits")
    void test_TC10() {
        // Given
        String input = "1e";
        
        // When
        boolean result = NumberUtils.isCreatable(input);
        
        // Then
        assertFalse(result, "Expected isCreatable to return false for input '1e'");
    }

}