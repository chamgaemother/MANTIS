package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

public class StackedAreaRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("Early return when the series is not visible")
    void TC01_EarlyReturn_SeriesNotVisible() throws Exception {
        // Arrange
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        int row = 0;
        int column = 0;
        invokeSetSeriesVisible(renderer, row, false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int pass = 0;

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
        verify(state, never()).getEntityCollection();
    }

    @Test
    @DisplayName("Draw item when series is visible and dataset value is null without rendering as percentages")
    void TC02_DrawItem_NullValue_NoPercentage() throws Exception {
        // Arrange
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        int row = 1;
        int column = 1;
        invokeSetSeriesVisible(renderer, row, true);
        renderer.setRenderAsPercentages(false);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(null);
        when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(null);
        when(dataset.getColumnCount()).thenReturn(5);
        when(dataset.getValue(row, Math.min(column + 1, dataset.getColumnCount() - 1))).thenReturn(null);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(rangeAxis, times(0)).valueToJava2D(anyDouble(), eq(dataArea), any());
        verify(g2, times(2)).fill(any());
    }

//     @Test
//     @DisplayName("Draw item when series is visible and dataset value is null with rendering as percentages")
//     void TC03_DrawItem_NullValue_WithPercentage() throws Exception {
        // Arrange
//         StackedAreaRenderer renderer = new StackedAreaRenderer();
//         int row = 2;
//         int column = 2;
//         invokeSetSeriesVisible(renderer, row, true);
//         renderer.setRenderAsPercentages(true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         int pass = 0;
// 
//         when(dataset.getValue(row, column)).thenReturn(null);
//         when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(null);
//         when(dataset.getColumnCount()).thenReturn(5);
//         when(dataset.getValue(row, Math.min(column + 1, dataset.getColumnCount() - 1))).thenReturn(null);
// 
//         when(DataUtils.calculateColumnTotal(dataset, column, state.getVisibleSeriesArray())).thenReturn(100.0);
//         when(DataUtils.calculateColumnTotal(dataset, Math.max(column - 1, 0), state.getVisibleSeriesArray())).thenReturn(100.0);
//         when(DataUtils.calculateColumnTotal(dataset, Math.min(column + 1, dataset.getColumnCount() - 1), state.getVisibleSeriesArray())).thenReturn(100.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
        // Assert
//         verify(rangeAxis, times(0)).valueToJava2D(anyDouble(), eq(dataArea), any());
//         verify(g2, times(2)).fill(any());
//     }

//     @Test
//     @DisplayName("Draw item with visible series, non-null dataset value, render as percentages, and positive y1")
//     void TC04_DrawItem_PositiveY1_WithPercentage() throws Exception {
        // Arrange
//         StackedAreaRenderer renderer = new StackedAreaRenderer();
//         int row = 3;
//         int column = 3;
//         invokeSetSeriesVisible(renderer, row, true);
//         renderer.setRenderAsPercentages(true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         int pass = 0;
// 
//         when(dataset.getValue(row, column)).thenReturn(50);
//         when(DataUtils.calculateColumnTotal(dataset, column, state.getVisibleSeriesArray())).thenReturn(100.0);
//         when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(30);
//         when(DataUtils.calculateColumnTotal(dataset, Math.max(column - 1, 0), state.getVisibleSeriesArray())).thenReturn(60.0);
//         when(dataset.getColumnCount()).thenReturn(5);
//         when(dataset.getValue(row, Math.min(column + 1, dataset.getColumnCount() - 1))).thenReturn(20);
//         when(DataUtils.calculateColumnTotal(dataset, Math.min(column + 1, dataset.getColumnCount() - 1), state.getVisibleSeriesArray())).thenReturn(80.0);
// 
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> (Double) invocation.getArgument(0) * 10.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
        // Assert
//         ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
//         verify(g2, times(2)).fill(shapeCaptor.capture());
//         assertNotNull(shapeCaptor.getAllValues().get(0));
//         assertNotNull(shapeCaptor.getAllValues().get(1));
//     }

//     @Test
//     @DisplayName("Draw item with visible series, non-null dataset value, render as percentages, and negative y1")
//     void TC05_DrawItem_NegativeY1_WithPercentage() throws Exception {
        // Arrange
//         StackedAreaRenderer renderer = new StackedAreaRenderer();
//         int row = 4;
//         int column = 4;
//         invokeSetSeriesVisible(renderer, row, true);
//         renderer.setRenderAsPercentages(true);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         int pass = 0;
// 
//         when(dataset.getValue(row, column)).thenReturn(-50);
//         when(DataUtils.calculateColumnTotal(dataset, column, state.getVisibleSeriesArray())).thenReturn(100.0);
//         when(dataset.getValue(row, Math.max(column - 1, 0))).thenReturn(-30);
//         when(DataUtils.calculateColumnTotal(dataset, Math.max(column - 1, 0), state.getVisibleSeriesArray())).thenReturn(60.0);
//         when(dataset.getColumnCount()).thenReturn(5);
//         when(dataset.getValue(row, Math.min(column + 1, dataset.getColumnCount() - 1))).thenReturn(-20);
//         when(DataUtils.calculateColumnTotal(dataset, Math.min(column + 1, dataset.getColumnCount() - 1), state.getVisibleSeriesArray())).thenReturn(80.0);
// 
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> (Double) invocation.getArgument(0) * 10.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
        // Assert
//         ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
//         verify(g2, times(2)).fill(shapeCaptor.capture());
//         assertNotNull(shapeCaptor.getAllValues().get(0));
//         assertNotNull(shapeCaptor.getAllValues().get(1));
//     }

    // Helper method to mimic private method for setting series visibility
    private void invokeSetSeriesVisible(StackedAreaRenderer renderer, int series, boolean visible) {
        try {
            java.lang.reflect.Method method = StackedAreaRenderer.class.getDeclaredMethod("setSeriesVisible", int.class, boolean.class);
            method.setAccessible(true);
            method.invoke(renderer, series, visible);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}