package org.apache.commons.compress.harmony.unpack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.jar.JarOutputStream;
import java.util.zip.GZIPOutputStream;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class Archive_unpack_0_1_Test {

    @Test
    @DisplayName("Verify that unpack throws IllegalStateException when input stream does not support mark")
    void testThrowsIllegalStateExceptionWhenMarkNotSupported() throws Exception {
        // Use InputStream without mark support
        InputStream inputStream = new ByteArrayInputStream(new byte[]{0, 1, 2}) {
            @Override
            public boolean markSupported() {
                return false;
            }
        };
        OutputStream outputStream = new ByteArrayOutputStream();

        assertThrows(IllegalStateException.class, () -> {
            try (JarOutputStream jarOutputStream = new JarOutputStream(outputStream)) {
                Archive archive = new Archive(inputStream, jarOutputStream);
                archive.unpack();
            }
        });
    }

    @Test
    @DisplayName("Handle GZIP compressed stream and decompress correctly")
    void testGzipDecompress() throws Exception {
        // Prepare GZIP compressed data
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try (GZIPOutputStream gzipOutputStream = new GZIPOutputStream(byteArrayOutputStream)) {
            gzipOutputStream.write(new byte[]{0x50, 0x4B, 0x03, 0x04}); // Simulated compressed data
        }

        InputStream inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        OutputStream outputStream = new ByteArrayOutputStream();

        assertDoesNotThrow(() -> {
            try (JarOutputStream jarOutputStream = new JarOutputStream(outputStream)) {
                Archive archive = new Archive(inputStream, jarOutputStream);
                archive.unpack();
            }
        });
    }

    @Test
    @DisplayName("Process uncompressed input without GZIP magic number")
    void testUncompressedWithoutGzipMagic() throws Exception {
        InputStream inputStream = new ByteArrayInputStream(new byte[]{0x50, 0x4B, 0x03, 0x04}); // Simulated uncompressed JAR data
        OutputStream outputStream = new ByteArrayOutputStream();

        assertDoesNotThrow(() -> {
            try (JarOutputStream jarOutputStream = new JarOutputStream(outputStream)) {
                Archive archive = new Archive(inputStream, jarOutputStream);
                archive.unpack();
            }
        });
    }

    @Test
    @DisplayName("Ensure correct unpacking with MAGIC match and segments")
    void testMagicMatch() throws Exception {
        InputStream inputStream = new ByteArrayInputStream(new byte[]{(byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D, 0x00}); // MAGIC number data
        OutputStream outputStream = new ByteArrayOutputStream();

        assertDoesNotThrow(() -> {
            try (JarOutputStream jarOutputStream = new JarOutputStream(outputStream)) {
                Archive archive = new Archive(inputStream, jarOutputStream);
                archive.unpack();
            }
        });
    }

    @Test
    @DisplayName("Test no segments are unpacked (zero iterations)")
    void testNoSegmentsUnpacked() throws Exception {
        InputStream inputStream = new ByteArrayInputStream(new byte[]{(byte) 0xCA, (byte) 0xFE, (byte) 0xD0, (byte) 0x0D}); // MAGIC but no additional data
        OutputStream outputStream = new ByteArrayOutputStream();

        assertDoesNotThrow(() -> {
            try (JarOutputStream jarOutputStream = new JarOutputStream(outputStream)) {
                Archive archive = new Archive(inputStream, jarOutputStream);
                archive.unpack();
            }
        });
    }
}