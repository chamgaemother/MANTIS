package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryToHexDigit_1_1_Test {

    @Test
    @DisplayName("Returns '1' when src.length > srcPos +1, src[srcPos+1] is true, src[srcPos] is false, and srcPos is 2")
    public void TC23_Returns1_When_SrcLengthGreaterThanSrcPosPlus1_SrcSrcPosPlus1True_SrcSrcPosFalse_SrcPos2() {
        boolean[] src = {false, false, false, true, false};
        int srcPos = 2;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('1', result);
    }

    @Test
    @DisplayName("Returns '0' when src.length <= srcPos +1 and src[srcPos] is false with srcPos=1")
    public void TC24_Returns0_When_SrcLengthLessThanOrEqualSrcPosPlus1_SrcSrcPosFalse_SrcPos1() {
        boolean[] src = {true, false};
        int srcPos = 1;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('0', result);
    }
}