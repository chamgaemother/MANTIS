package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.exception.MathArithmeticException;

public class ArithmeticUtils_gcd_0_2_Test {

    @Test
    @DisplayName("gcd(25, 15) returns 5 with both operands positive and odd")
    public void test_TC06() {
        // Given
        long p = 25L;
        long q = 15L;

        // When
        long result = ArithmeticUtils.gcd(p, q);

        // Then
        Assertions.assertEquals(5L, result);
    }

    @Test
    @DisplayName("gcd(48, 18) returns 6 after one iteration of power of 2 reduction")
    public void test_TC07() {
        // Given
        long p = 48L;
        long q = 18L;

        // When
        long result = ArithmeticUtils.gcd(p, q);

        // Then
        Assertions.assertEquals(6L, result);
    }

    @Test
    @DisplayName("gcd(1024, 256) returns 256 after multiple iterations of power of 2 reduction")
    public void test_TC08() {
        // Given
        long p = 1024L;
        long q = 256L;

        // When
        long result = ArithmeticUtils.gcd(p, q);

        // Then
        Assertions.assertEquals(256L, result);
    }

    @Test
    @DisplayName("gcd(0, Long.MIN_VALUE) throws MathArithmeticException due to overflow")
    public void test_TC09() {
        // Given
        long p = 0L;
        long q = Long.MIN_VALUE;

        // When & Then
        Assertions.assertThrows(MathArithmeticException.class, () -> {
            ArithmeticUtils.gcd(p, q);
        });
    }

    @Test
    @DisplayName("gcd(Long.MAX_VALUE, Long.MAX_VALUE) returns Long.MAX_VALUE")
    public void test_TC10() {
        // Given
        long p = Long.MAX_VALUE;
        long q = Long.MAX_VALUE;

        // When
        long result = ArithmeticUtils.gcd(p, q);

        // Then
        Assertions.assertEquals(Long.MAX_VALUE, result);
    }
}