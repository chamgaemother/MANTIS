package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class XYErrorRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem with pass != 0 should skip custom drawing and call super.drawItem")
    void TC01_drawItem_passNotZero_callsSuperDrawItem() {
        int pass = 1;
        XYDataset dataset = mock(XYDataset.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Ensure correct usage of spy
        XYErrorRenderer renderer = spy(new XYErrorRenderer());

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Then
        verify(renderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
    }

    @Test
    @DisplayName("drawItem with pass == 0 but dataset is not an instance of IntervalXYDataset")
    void TC02_drawItem_nonIntervalDataset_callsSuperDrawItem() {
        int pass = 0;
        XYDataset dataset = mock(XYDataset.class);
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);

        XYErrorRenderer renderer = spy(new XYErrorRenderer());

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Then
        verify(renderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
    }

    @Test
    @DisplayName("drawItem with pass == 0 and dataset is IntervalXYDataset but getItemVisible returns false")
    void TC03_drawItem_itemNotVisible_callsSuperDrawItem() {
        int pass = 0;
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(0.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);

        XYErrorRenderer renderer = spy(new XYErrorRenderer());

        when(renderer.getItemVisible(series, item)).thenReturn(false); // Critical Visibility Result

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Then
        verify(renderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
    }

    @Test
    @DisplayName("drawItem with drawXError and drawYError set to false, no error bars should be drawn")
    void TC04_drawItem_noErrorBars_callsSuperDrawItem() {
        int pass = 0;
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(0.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);

        XYErrorRenderer renderer = spy(new XYErrorRenderer());
        renderer.setDrawXError(false);
        renderer.setDrawYError(false);

        // When
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Then
        verify(renderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
    }

//     @Test
//     @DisplayName("drawItem with drawXError=true, errorPaint and errorStroke not null, orientation VERTICAL")
//     void TC05_drawItem_drawXErrorVertical_customPaintAndStroke() {
//         int pass = 0;
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(20.0);
//         when(dataset.getYValue(anyInt(), anyInt())).thenReturn(15.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         Paint customErrorPaint = mock(Paint.class);
//         Stroke customErrorStroke = mock(Stroke.class);
// 
//         XYErrorRenderer renderer = spy(new XYErrorRenderer());
//         renderer.setDrawXError(true);
//         renderer.setDrawYError(false);
//         renderer.setErrorPaint(customErrorPaint);
//         renderer.setErrorStroke(customErrorStroke);
// 
        // Assume method checks for visibility
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
// 
        // When
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Then
//         verify(g2).setPaint(customErrorPaint);
//         verify(g2).setStroke(customErrorStroke);
//         ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
//         verify(g2, times(3)).draw(any());
//     }
}