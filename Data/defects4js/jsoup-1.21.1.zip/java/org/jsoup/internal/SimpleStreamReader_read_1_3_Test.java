package org.jsoup.internal;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class SimpleStreamReader_read_1_3_Test {

    @Test
    @DisplayName("read with byteBuf having remaining data, ensuring no additional bufferUp calls")
    public void TC27() throws IOException {
        // GIVEN
        char[] buffer = new char[5];
        int off = 0;
        int len = 5;
        byte[] inputBytes = "Hello".getBytes(StandardCharsets.UTF_8);
        InputStream in = Mockito.mock(InputStream.class);
        Mockito.when(in.available()).thenReturn(5);
        Mockito.when(in.read(Mockito.any(byte[].class), Mockito.anyInt(), Mockito.anyInt())).thenReturn(5);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
        
        // WHEN
        int firstRead = reader.read(buffer, off, len);
        
        // THEN
        Assertions.assertEquals(5, firstRead);
        Assertions.assertEquals("Hello", new String(buffer));
        
        // Verify bufferUp is not called again
        Mockito.verify(in, Mockito.times(1)).read(Mockito.any(byte[].class), Mockito.anyInt(), Mockito.anyInt());
    }
}