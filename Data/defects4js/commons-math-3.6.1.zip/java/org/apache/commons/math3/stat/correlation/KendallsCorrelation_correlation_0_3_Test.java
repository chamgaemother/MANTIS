package org.apache.commons.math3.stat.correlation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.stat.correlation.KendallsCorrelation;
import org.apache.commons.math3.exception.DimensionMismatchException;

public class KendallsCorrelation_correlation_0_3_Test {

    @Test
    @DisplayName("correlation correctly computes correlation with negative values")
    void TC11() {
        // GIVEN
        double[] xArray = {-1.0, -2.0, -3.0};
        double[] yArray = {-1.0, -2.0, -3.0};
        
        // WHEN
        KendallsCorrelation kendallsCorrelation = new KendallsCorrelation();
        double result = kendallsCorrelation.correlation(xArray, yArray);
        
        // THEN
        assertEquals(1.0, result, "Correlation should be 1.0 for identical negative value arrays");
    }

    @Test
    @DisplayName("correlation handles arrays with mixed positive and negative values")
    void TC12() {
        // GIVEN
        double[] xArray = {-1.0, 2.0, -3.0};
        double[] yArray = {3.0, -2.0, 1.0};
        
        // WHEN
        KendallsCorrelation kendallsCorrelation = new KendallsCorrelation();
        double result = kendallsCorrelation.correlation(xArray, yArray);
        
        // THEN
        assertEquals(-0.3333333333333333, result, "Correlation should be -0.3333333333333333 for mixed-sign datasets");
    }

    @Test
    @DisplayName("correlation handles duplicate pairs in arrays")
    void TC13() {
        // GIVEN
        double[] xArray = {1.0, 1.0, 2.0, 2.0};
        double[] yArray = {1.0, 1.0, 2.0, 2.0};
        
        // WHEN
        KendallsCorrelation kendallsCorrelation = new KendallsCorrelation();
        double result = kendallsCorrelation.correlation(xArray, yArray);
        
        // THEN
        assertEquals(1.0, result, "Correlation should be 1.0 for arrays with duplicate pairs");
    }

    @Test
    @DisplayName("correlation handles arrays with all identical pairs")
    void TC14() {
        // GIVEN
        double[] xArray = {2.0, 2.0, 2.0};
        double[] yArray = {3.0, 3.0, 3.0};
        
        // WHEN
        KendallsCorrelation kendallsCorrelation = new KendallsCorrelation();
        double result = kendallsCorrelation.correlation(xArray, yArray);
        
        // THEN
        assertEquals(1.0, result, "Correlation should be 1.0 when all pairs are identical");
    }

    @Test
    @DisplayName("correlation handles maximum integer array sizes without overflow")
    void TC15() {
        // GIVEN
        int size = Integer.MAX_VALUE / 1000000; // Adjust to fit memory constraints
        double[] xArray = new double[size];
        double[] yArray = new double[size];
        for(int i = 0; i < size; i++) {
            xArray[i] = (double)i;
            yArray[i] = (double)i;
        }
        
        // WHEN
        KendallsCorrelation kendallsCorrelation = new KendallsCorrelation();
        double result = kendallsCorrelation.correlation(xArray, yArray);
        
        // THEN
        assertEquals(1.0, result, "Correlation should be 1.0 for maximum integer array sizes without overflow");
    }
}