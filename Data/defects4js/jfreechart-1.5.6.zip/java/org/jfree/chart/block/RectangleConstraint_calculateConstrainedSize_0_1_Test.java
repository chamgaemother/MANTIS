package org.jfree.chart.block;

import org.jfree.chart.ui.Size2D;
import org.jfree.chart.util.Args;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class RectangleConstraint_calculateConstrainedSize_0_1_Test {

    @Test
    @DisplayName("WidthConstraintType is NONE and HeightConstraintType is NONE")
    void TC01() throws Exception {
        // Instantiate RectangleConstraint with default values
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.NONE, 0.0, null, LengthConstraintType.NONE);

        // Instantiate base Size2D
        Size2D base = new Size2D(100.0, 50.0);

        // Invoke calculateConstrainedSize
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assertions
        Assertions.assertEquals(base.getWidth(), result.getWidth(), "Width should equal base width");
        Assertions.assertEquals(base.getHeight(), result.getHeight(), "Height should equal base height");
    }

    @Test
    @DisplayName("WidthConstraintType is NONE and HeightConstraintType is RANGE")
    void TC02() throws Exception {
        // Set heightRange, simulate setting via constructor
        Range heightRange = new Range(40.0, 60.0);
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.NONE, 0.0, heightRange, LengthConstraintType.RANGE);

        // Instantiate base Size2D
        Size2D base = new Size2D(100.0, 50.0);

        // Invoke calculateConstrainedSize
        Size2D result = constraint.calculateConstrainedSize(base);

        // Expected constrained height
        double expectedHeight = heightRange.constrain(base.getHeight());

        // Assertions
        Assertions.assertEquals(base.getWidth(), result.getWidth(), "Width should equal base width");
        Assertions.assertEquals(expectedHeight, result.getHeight(), "Height should be constrained by heightRange");
    }

    @Test
    @DisplayName("WidthConstraintType is NONE and HeightConstraintType is FIXED")
    void TC03() throws Exception {
        // Set fixed height, simulate setting via constructor
        double fixedHeight = 55.0;
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.NONE, fixedHeight, null, LengthConstraintType.FIXED);

        // Instantiate base Size2D
        Size2D base = new Size2D(100.0, 50.0);

        // Invoke calculateConstrainedSize
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assertions
        Assertions.assertEquals(base.getWidth(), result.getWidth(), "Width should equal base width");
        Assertions.assertEquals(fixedHeight, result.getHeight(), "Height should be fixed to the specified value");
    }

    @Test
    @DisplayName("WidthConstraintType is RANGE and HeightConstraintType is NONE")
    void TC04() throws Exception {
        // Set widthRange, simulate setting via constructor
        Range widthRange = new Range(80.0, 120.0);
        RectangleConstraint constraint = new RectangleConstraint(0.0, widthRange, LengthConstraintType.RANGE, 0.0, null, LengthConstraintType.NONE);

        // Instantiate base Size2D
        Size2D base = new Size2D(100.0, 50.0);

        // Invoke calculateConstrainedSize
        Size2D result = constraint.calculateConstrainedSize(base);

        // Expected constrained width
        double expectedWidth = widthRange.constrain(base.getWidth());

        // Assertions
        Assertions.assertEquals(expectedWidth, result.getWidth(), "Width should be constrained by widthRange");
        Assertions.assertEquals(base.getHeight(), result.getHeight(), "Height should equal base height");
    }

    @Test
    @DisplayName("WidthConstraintType is RANGE and HeightConstraintType is RANGE")
    void TC05() throws Exception {
        // Set widthRange and heightRange, simulate setting via constructor
        Range heightRange = new Range(40.0, 60.0);
        Range widthRange = new Range(80.0, 120.0);
        RectangleConstraint constraint = new RectangleConstraint(0.0, widthRange, LengthConstraintType.RANGE, 0.0, heightRange, LengthConstraintType.RANGE);

        // Instantiate base Size2D
        Size2D base = new Size2D(100.0, 50.0);

        // Invoke calculateConstrainedSize
        Size2D result = constraint.calculateConstrainedSize(base);

        // Expected constrained width and height
        double expectedWidth = widthRange.constrain(base.getWidth());
        double expectedHeight = heightRange.constrain(base.getHeight());

        // Assertions
        Assertions.assertEquals(expectedWidth, result.getWidth(), "Width should be constrained by widthRange");
        Assertions.assertEquals(expectedHeight, result.getHeight(), "Height should be constrained by heightRange");
    }
}