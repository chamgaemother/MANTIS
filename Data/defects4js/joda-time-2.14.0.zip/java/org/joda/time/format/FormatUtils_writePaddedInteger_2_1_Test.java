package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.io.StringWriter;
import java.io.Writer;

public class FormatUtils_writePaddedInteger_2_1_Test {

    @Test
    @DisplayName("writePaddedInteger with positive value equal to 100 and size equals digit count (no padding needed)")
    void TC16() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 100;
        int size = 3;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("100", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value equal to 100 and size greater than digit count (with one padding iteration)")
    void TC17() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 100;
        int size = 4;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("0100", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value equal to 100 and size less than digit count (size ignored, no padding)")
    void TC18() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 100;
        int size = 2;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("100", writer.toString());
    }
}