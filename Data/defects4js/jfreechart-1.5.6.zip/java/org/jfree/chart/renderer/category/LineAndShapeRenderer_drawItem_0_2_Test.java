package org.jfree.chart.renderer.category;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class LineAndShapeRenderer_drawItem_0_2_Test {

    private LineAndShapeRenderer initializeRenderer(boolean useSeriesOffset) throws Exception {
        // Initialize renderer
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();

        // Reflectively set useSeriesOffset field
        Field useSeriesOffsetField = LineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
        useSeriesOffsetField.setAccessible(true);
        useSeriesOffsetField.set(renderer, useSeriesOffset);
        return renderer;
    }

//     @Test
//     @DisplayName("drawItem calculates x1 without series offset when useSeriesOffset is false")
//     public void TC06_drawItem_with_useSeriesOffset_false() throws Exception {
//         LineAndShapeRenderer renderer = initializeRenderer(false);
// 
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
        // Setup preconditions
//         when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
//         when(renderer.getItemLineVisible(anyInt(), anyInt())).thenReturn(true);
//         when(renderer.getItemShapeVisible(anyInt(), anyInt())).thenReturn(true);
//         when(dataset.getValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(state.getVisibleSeriesIndex(anyInt())).thenReturn(1);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), anyInt(), anyInt(), anyDouble(), any(Rectangle2D.class), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
// 
        // Pass parameter
//         int pass = 0;
// 
        // Invoke method
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, pass);
// 
        // Verify x1 was calculated using getCategoryMiddle
//         verify(domainAxis).getCategoryMiddle(0, 1, 1, 1, renderer.getItemMargin(), dataArea, plot.getDomainAxisEdge());
//         verify(domainAxis, never()).getCategorySeriesMiddle(anyInt(), anyInt(), anyInt(), anyInt(), anyDouble(), any(), any());
//     }

//     @Test
//     @DisplayName("drawItem draws line when pass is 0 and line is visible")
//     public void TC07_drawItem_pass0_with_line_visibility() throws Exception {
//         LineAndShapeRenderer renderer = initializeRenderer(true);
// 
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
        // Set up preconditions
//         when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
//         when(renderer.getItemLineVisible(anyInt(), anyInt())).thenReturn(true);
//         when(renderer.getItemShapeVisible(anyInt(), anyInt())).thenReturn(true);
//         when(dataset.getValue(0, 1)).thenReturn(20.0);
//         when(dataset.getValue(0, 0)).thenReturn(10.0);
//         when(state.getVisibleSeriesIndex(0)).thenReturn(0);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getCategoryMiddle(1, 1, 0, 1, renderer.getItemMargin(), dataArea, plot.getDomainAxisEdge())).thenReturn(60.0);
//         when(domainAxis.getCategoryMiddle(0, 1, 0, 1, renderer.getItemMargin(), dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
// 
        // Pass parameter
//         int pass = 0;
// 
        // Invoke method
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, pass);
// 
        // Verify that a line is drawn between data points (0,0) and (0,1)
//         ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
//         verify(g2).draw(lineCaptor.capture());
// 
//         Line2D drawnLine = lineCaptor.getValue();
//         assertEquals(50.0, drawnLine.getX1(), 0.001);
//         assertEquals(100.0, drawnLine.getY1(), 0.001);
//         assertEquals(60.0, drawnLine.getX2(), 0.001);
//         assertEquals(200.0, drawnLine.getY2(), 0.001);
//     }

    @Test
    @DisplayName("drawItem does not draw line when pass is 0 and line is not visible")
    public void TC08_drawItem_pass0_without_line_visibility() throws Exception {
        LineAndShapeRenderer renderer = initializeRenderer(true);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up preconditions
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(renderer.getItemLineVisible(anyInt(), anyInt())).thenReturn(false);
        when(renderer.getItemShapeVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(10.0);
        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(1);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Pass parameter
        int pass = 0;

        // Invoke method
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, pass);

        // Verify that no line is drawn
        verify(g2, never()).draw(any(Line2D.class));
    }

//     @Test
//     @DisplayName("drawItem draws shape when pass is 1 and shape is visible")
//     public void TC09_drawItem_pass1_with_shape_visibility() throws Exception {
//         LineAndShapeRenderer renderer = initializeRenderer(true);
// 
        // Mock dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
        // Mock Shape
//         Shape shape = mock(Shape.class);
// 
        // Set up preconditions
//         when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
//         when(renderer.getItemLineVisible(anyInt(), anyInt())).thenReturn(true);
//         when(renderer.getItemShapeVisible(anyInt(), anyInt())).thenReturn(true);
//         when(renderer.getItemShapeFilled(anyInt(), anyInt())).thenReturn(true);
//         when(dataset.getValue(anyInt(), anyInt())).thenReturn(15.0);
//         when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), anyInt(), anyInt(), anyDouble(), any(Rectangle2D.class), any())).thenReturn(70.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(150.0);
//         when(renderer.getItemShape(anyInt(), anyInt())).thenReturn(shape);
// 
        // Pass parameter
//         int pass = 1;
// 
        // Invoke method
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, pass);
// 
        // Verify that shape is filled and outlined
//         verify(g2).fill(shape);
//         verify(g2).draw(shape);
//     }

    @Test
    @DisplayName("drawItem does not draw shape when pass is 1 and shape is not visible")
    public void TC10_drawItem_pass1_without_shape_visibility() throws Exception {
        LineAndShapeRenderer renderer = initializeRenderer(true);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up preconditions
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(renderer.getItemLineVisible(anyInt(), anyInt())).thenReturn(true);
        when(renderer.getItemShapeVisible(anyInt(), anyInt())).thenReturn(false);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(15.0);
        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Pass parameter
        int pass = 1;

        // Invoke method
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, pass);

        // Verify that no shape is drawn
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }
}