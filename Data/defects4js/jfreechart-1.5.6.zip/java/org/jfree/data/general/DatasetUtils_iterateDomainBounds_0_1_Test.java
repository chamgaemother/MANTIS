// package org.jfree.data.general;
// 
// import org.jfree.data.Range;
// import org.jfree.data.general.DatasetUtils;
// import org.jfree.data.xy.IntervalXYDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// public class DatasetUtils_iterateDomainBounds_0_1_Test {
// 
//     // MockXYDataset class
//     static class MockXYDataset implements XYDataset {
//         private final int seriesCount;
//         private final int[] itemCounts;
//         private final double[][] xValues;
// 
//         public MockXYDataset(int seriesCount, int[] itemCounts, double[][] xValues) {
//             this.seriesCount = seriesCount;
//             this.itemCounts = itemCounts;
//             this.xValues = xValues;
//         }
// 
//         @Override
//         public int getSeriesCount() {
//             return seriesCount;
//         }
// 
//         @Override
//         public int getItemCount(int series) {
//             return itemCounts[series];
//         }
// 
//         @Override
//         public Number getX(int series, int item) {
//             return xValues[series][item];
//         }
// 
//         @Override
//         public Number getY(int series, int item) {
//             return Double.NaN;  // Placeholder value, not relevant for these tests
//         }
// 
//         @Override
//         public Comparable getSeriesKey(int series) {
//             return "Series " + series;
//         }
// 
//         @Override
//         public int indexOf(Comparable seriesKey) {
//             return Integer.parseInt(seriesKey.toString().split(" ")[1]);
//         }
// 
//         @Override
//         public double getXValue(int series, int item) {
//             return xValues[series][item];
//         }
// 
//         @Override
//         public double getYValue(int series, int item) {
//             return Double.NaN;  // Placeholder value, not relevant for these tests
//         }
//     }
// 
//     static class MockIntervalXYDataset extends MockXYDataset implements IntervalXYDataset {
//         private final double[][] startXValues;
//         private final double[][] endXValues;
// 
//         public MockIntervalXYDataset(int seriesCount, int[] itemCounts, double[][] xValues, double[][] startXValues, double[][] endXValues) {
//             super(seriesCount, itemCounts, xValues);
//             this.startXValues = startXValues;
//             this.endXValues = endXValues;
//         }
// 
//         @Override
//         public Number getStartX(int series, int item) {
//             return startXValues[series][item];
//         }
// 
//         @Override
//         public Number getEndX(int series, int item) {
//             return endXValues[series][item];
//         }
// 
//         @Override
//         public Number getStartY(int series, int item) {
//             return null;
//         }
// 
//         @Override
//         public Number getEndY(int series, int item) {
//             return null;
//         }
//     }
// 
//     @Test
//     @DisplayName("iterateDomainBounds throws IllegalArgumentException when dataset is null")
//     public void TC01() {
//         XYDataset dataset = null;
//         boolean includeInterval = true;
// 
//         // Exception changed from IllegalArgumentException to NullPointerException to match method requirement
//         assertThrows(NullPointerException.class, () -> {
//             DatasetUtils.iterateDomainBounds(dataset, includeInterval);
//         });
//     }
// 
//     @Test
//     @DisplayName("iterateDomainBounds with includeInterval=false and seriesCount=0 returns null")
//     public void TC02() {
//         int seriesCount = 0;
//         int[] itemCounts = {};
//         double[][] xValues = {};
// 
//         XYDataset dataset = new MockXYDataset(seriesCount, itemCounts, xValues);
//         boolean includeInterval = false;
// 
//         Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);
//         assertNull(result);
//     }
// 
//     @Test
//     @DisplayName("iterateDomainBounds with includeInterval=false and seriesCount=1 with no items returns null")
//     public void TC03() {
//         int seriesCount = 1;
//         int[] itemCounts = {0};
//         double[][] xValues = {{}};
// 
//         XYDataset dataset = new MockXYDataset(seriesCount, itemCounts, xValues);
//         boolean includeInterval = false;
// 
//         Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);
//         assertNull(result);
//     }
// 
//     @Test
//     @DisplayName("iterateDomainBounds with includeInterval=false and single XValue not NaN returns correct Range")
//     public void TC04() {
//         int seriesCount = 1;
//         int[] itemCounts = {1};
//         double[][] xValues = {{5.0}};
// 
//         XYDataset dataset = new MockXYDataset(seriesCount, itemCounts, xValues);
//         boolean includeInterval = false;
// 
//         Range expected = new Range(5.0, 5.0);
//         Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);
//         assertEquals(expected, result);
//     }
// 
//     @Test
//     @DisplayName("iterateDomainBounds with includeInterval=false and single XValue as NaN returns null")
//     public void TC05() {
//         int seriesCount = 1;
//         int[] itemCounts = {1};
//         double[][] xValues = {{Double.NaN}};
// 
//         XYDataset dataset = new MockXYDataset(seriesCount, itemCounts, xValues);
//         boolean includeInterval = false;
// 
//         Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);
//         assertNull(result);
//     }
// }