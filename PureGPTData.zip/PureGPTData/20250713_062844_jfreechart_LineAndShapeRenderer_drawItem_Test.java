import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LineAndShapeRendererTest {

    private LineAndShapeRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;
    private int row = 0;
    private int column = 0;
    
    @BeforeEach
    void setUp() {
        renderer = new LineAndShapeRenderer(true, true);
        g2 = Mockito.mock(Graphics2D.class);
        state = Mockito.mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 400, 300);
        plot = Mockito.mock(CategoryPlot.class);
        domainAxis = Mockito.mock(CategoryAxis.class);
        rangeAxis = Mockito.mock(ValueAxis.class);
        dataset = Mockito.mock(CategoryDataset.class);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any())).thenReturn(200.0);
        when(domainAxis.getCategorySeriesMiddle(anyInt(), anyInt(), anyInt(), anyInt(), anyDouble(), any(), any())).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(150.0);

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
    }

    @Test
    void testDrawItemWithNullItemValue() {
        when(dataset.getValue(row, column)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawItemWithNonNullItemValueAndVisibleLine() {
        when(dataset.getValue(row, column)).thenReturn(10);
        when(dataset.getValue(row, column - 1)).thenReturn(8);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        verify(g2).draw(any());
    }

    @Test
    void testDrawItemWithNonNullItemValueAndInvisibleLine() {
        when(dataset.getValue(row, column)).thenReturn(10);
        when(dataset.getValue(row, column - 1)).thenReturn(null);
        renderer.setSeriesLinesVisible(row, false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawItemWithNonNullItemValueAndVisibleShape() {
        when(dataset.getValue(row, column)).thenReturn(10);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 1);
        verify(g2).fill(any());
    }

    @Test
    void testDrawItemWithNonNullItemValueAndInvisibleShape() {
        when(dataset.getValue(row, column)).thenReturn(10);
        renderer.setSeriesShapesVisible(row, false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 1);
        verify(g2, never()).fill(any());
    }

    @Test
    void testDrawItemWithNullPreviousItemValue() {
        when(dataset.getValue(row, column)).thenReturn(10);
        when(dataset.getValue(row, column - 1)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawItemWithSeriesOffset() {
        renderer.setUseSeriesOffset(true);
        when(dataset.getValue(row, column)).thenReturn(10);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 1);
        verify(g2).fill(any());
    }

    @Test
    void testDrawItemWithShapeOutline() {
        when(dataset.getValue(row, column)).thenReturn(10);
        renderer.setDrawOutlines(true);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 1);
        verify(g2).draw(any()); // since outlines are drawn
    }

    @Test
    void testDrawItemWithoutShapeOutline() {
        when(dataset.getValue(row, column)).thenReturn(10);
        renderer.setDrawOutlines(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 1);
        verify(g2, times(1)).fill(any());
        verify(g2, never()).draw(any()); // since outlines are not drawn
    }

    @Test
    void testDrawItemWithLabel() {
        when(dataset.getValue(row, column)).thenReturn(10);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 1);
    }

}