package org.apache.commons.math3.special;

import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Gamma_regularizedGammaP_0_3_Test {

    @Test
    @DisplayName("regularizedGammaP with x < a + 1 and sum becomes infinite returns 1.0")
    void TC11_regularizedGammaP_sumInfinite_returnsOne() {
        // GIVEN
        double a = 1e-10;
        double x = 1.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        assertEquals(1.0, result, 1e-9, "The result should be 1.0 when sum becomes infinite.");
    }

    @Test
    @DisplayName("regularizedGammaP with x < a + 1 and normal convergence")
    void TC12_regularizedGammaP_normalConvergence() {
        // GIVEN
        double a = 3.0;
        double x = 4.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;
        // Expected value can be computed using known mathematical properties or a trusted library
        double expectedValue = Gamma.regularizedGammaP(a, x, epsilon, maxIterations); // Placeholder for actual expected value

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        assertEquals(expectedValue, result, 1e-9, "The result should match the expected value after convergence.");
    }

    @Test
    @DisplayName("regularizedGammaP with a just above 0 and x just below a +1")
    void TC13_regularizedGammaP_boundaryValues() {
        // GIVEN
        double a = 1e-10;
        double x = a + 0.9999999;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double q = Gamma.regularizedGammaQ(a, x, epsilon, maxIterations);
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        assertEquals(1.0 - q, result, 1e-9, "The result should be equal to 1.0 minus regularizedGammaQ.");
    }

    @Test
    @DisplayName("regularizedGammaP with iterations reaching maxIterations")
    void TC14_regularizedGammaP_maxIterations() {
        // GIVEN
        double a = 2.0;
        double x = 3.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;
        // Expected value can be computed using known mathematical properties or a trusted library
        double expectedValue = Gamma.regularizedGammaP(a, x, epsilon, maxIterations); // Placeholder for actual expected value

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        assertEquals(expectedValue, result, 1e-9, "The result should match the expected value at max iterations.");
    }
}