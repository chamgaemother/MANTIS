package com.fasterxml.jackson.core.io;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.ErrorReportConfiguration;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class ContentReference_appendSourceDescription_0_3_Test {

    // Helper method to create an instance using reflection, since no public constructor exists
    private ContentReference createInstance(boolean isContentTextual, Object rawContent) throws Exception {
        Constructor<ContentReference> constructor = ContentReference.class
                .getDeclaredConstructor(boolean.class, Object.class, int.class, int.class, ErrorReportConfiguration.class);
        constructor.setAccessible(true);
        return constructor.newInstance(isContentTextual, rawContent, -1, -1, ErrorReportConfiguration.defaults());
    }

    @Test
    @DisplayName("hasTextualContent is false with srcRef as byte[], contentLength < 0, appends total byte array length")
    void TC11() throws Exception {
        // Create instance of ContentReference with reflection helper
        ContentReference instance = createInstance(false, new byte[]{1, 2, 3});

        // Set private field _length to -1
        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, -1);

        // Initialize StringBuilder
        StringBuilder sb = new StringBuilder();

        // Invoke the target method
        instance.appendSourceDescription(sb);

        // Assert the expected result
        assertEquals("[3 bytes]", sb.toString());
    }

    @Test
    @DisplayName("hasTextualContent is false with srcRef not as byte[], does not append binary length")
    void TC12() throws Exception {
        // Create instance of ContentReference with reflection helper
        ContentReference instance = createInstance(false, "TestString");

        // Initialize StringBuilder
        StringBuilder sb = new StringBuilder();

        // Invoke the target method
        instance.appendSourceDescription(sb);

        // Assert the expected result
        assertEquals("(java.lang.String)", sb.toString());
    }

    @Test
    @DisplayName("hasTextualContent is true but srcRef type does not support truncation, no content appended")
    void TC13() throws Exception {
        // Create instance of ContentReference with reflection helper
        ContentReference instance = createInstance(true, new Object());

        // Set private fields _offset and _length
        Field offsetField = ContentReference.class.getDeclaredField("_offset");
        offsetField.setAccessible(true);
        offsetField.set(instance, 0);

        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, 50);

        // Initialize StringBuilder
        StringBuilder sb = new StringBuilder();

        // Invoke the target method
        instance.appendSourceDescription(sb);

        // Assert the expected result
        assertEquals("(java.lang.Object)", sb.toString());
    }

    @Test
    @DisplayName("hasTextualContent is true with srcRef as byte[], contentLength exactly maxRawContentLength, no truncation notice")
    void TC14() throws Exception {
        // Create instance of ContentReference with reflection helper
        ContentReference instance = createInstance(true, new byte[50]);

        // Set private fields _offset and _length
        Field offsetField = ContentReference.class.getDeclaredField("_offset");
        offsetField.setAccessible(true);
        offsetField.set(instance, 0);

        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, 50);

        // Initialize StringBuilder
        StringBuilder sb = new StringBuilder();

        // Invoke the target method
        instance.appendSourceDescription(sb);

        // Assert the expected result
        assertEquals("(byte[])", sb.toString());
    }

    @Test
    @DisplayName("hasTextualContent is true with srcRef as CharSequence, contentLength > maxRawContentLength, appends truncated chars notice")
    void TC15() throws Exception {
        // Create instance of ContentReference with reflection helper
        ContentReference instance = createInstance(true, "This is a very long string that should be truncated.");

        // Set private fields _offset and _length
        Field offsetField = ContentReference.class.getDeclaredField("_offset");
        offsetField.setAccessible(true);
        offsetField.set(instance, 0);

        Field lengthField = ContentReference.class.getDeclaredField("_length");
        lengthField.setAccessible(true);
        lengthField.set(instance, 30);

        // Initialize StringBuilder
        StringBuilder sb = new StringBuilder();

        // Invoke the target method
        instance.appendSourceDescription(sb);

        // Assert the expected result
        // Expected to contain truncated content and truncation notice
        assertTrue(sb.toString().contains("[truncated 10 chars]"));
    }

}