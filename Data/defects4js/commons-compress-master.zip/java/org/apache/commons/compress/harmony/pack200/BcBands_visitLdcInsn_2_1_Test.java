package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BcBands_visitLdcInsn_2_1_Test {

//     @Test
//     @DisplayName("segment.lastConstantHadWideIndex=false and CPInt positive")
//     void TC06() throws Exception {
        // GIVEN
//         Segment segment = mock(Segment.class);
//         when(segment.lastConstantHadWideIndex()).thenReturn(false);
//         
//         CpBands cpBands = mock(CpBands.class);
//         CPInt cpInt = mock(CPInt.class);
//         when(cpBands.getConstant("cst")).thenReturn(cpInt);
//         
//         BcBands bcBands = new BcBands(cpBands, segment, 0);
// 
        // WHEN
//         bcBands.visitLdcInsn("cst");
// 
        // THEN
        // Access private field byteCodeOffset
//         Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
//         byteCodeOffsetField.setAccessible(true);
//         int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
//         assertEquals(2, byteCodeOffset);
// 
        // Access private field bcCodes
//         Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
//         bcCodesField.setAccessible(true);
//         List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
//         assertTrue(bcCodes.contains(234));
// 
        // Access private field bcIntref
//         Field bcIntrefField = BcBands.class.getDeclaredField("bcIntref");
//         bcIntrefField.setAccessible(true);
//         List<CPInt> bcIntref = (List<CPInt>) bcIntrefField.get(bcBands);
//         assertTrue(bcIntref.contains(cpInt));
//     }

//     @Test
//     @DisplayName("segment.lastConstantHadWideIndex=false and CPInt zero")
//     void TC07() throws Exception {
        // GIVEN
//         Segment segment = mock(Segment.class);
//         when(segment.lastConstantHadWideIndex()).thenReturn(false);
//         
//         CpBands cpBands = mock(CpBands.class);
//         CPInt cpInt = mock(CPInt.class);
//         when(cpBands.getConstant("cst")).thenReturn(cpInt);
//         
//         BcBands bcBands = new BcBands(cpBands, segment, 0);
// 
        // WHEN
//         bcBands.visitLdcInsn("cst");
// 
        // THEN
        // Access private field byteCodeOffset
//         Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
//         byteCodeOffsetField.setAccessible(true);
//         int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
//         assertEquals(2, byteCodeOffset);
// 
        // Access private field bcCodes
//         Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
//         bcCodesField.setAccessible(true);
//         List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
//         assertTrue(bcCodes.contains(234));
// 
        // Access private field bcIntref
//         Field bcIntrefField = BcBands.class.getDeclaredField("bcIntref");
//         bcIntrefField.setAccessible(true);
//         List<CPInt> bcIntref = (List<CPInt>) bcIntrefField.get(bcBands);
//         assertTrue(bcIntref.contains(cpInt));
//     }

//     @Test
//     @DisplayName("segment.lastConstantHadWideIndex=false and CPFloat positive")
//     void TC08() throws Exception {
        // GIVEN
//         Segment segment = mock(Segment.class);
//         when(segment.lastConstantHadWideIndex()).thenReturn(false);
//         
//         CpBands cpBands = mock(CpBands.class);
//         CPFloat cpFloat = mock(CPFloat.class);
//         when(cpBands.getConstant("cst")).thenReturn(cpFloat);
//         
//         BcBands bcBands = new BcBands(cpBands, segment, 0);
// 
        // WHEN
//         bcBands.visitLdcInsn("cst");
// 
        // THEN
        // Access private field byteCodeOffset
//         Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
//         byteCodeOffsetField.setAccessible(true);
//         int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
//         assertEquals(2, byteCodeOffset);
// 
        // Access private field bcCodes
//         Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
//         bcCodesField.setAccessible(true);
//         List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
//         assertTrue(bcCodes.contains(235));
// 
        // Access private field bcFloatRef
//         Field bcFloatRefField = BcBands.class.getDeclaredField("bcFloatRef");
//         bcFloatRefField.setAccessible(true);
//         List<CPFloat> bcFloatRef = (List<CPFloat>) bcFloatRefField.get(bcBands);
//         assertTrue(bcFloatRef.contains(cpFloat));
//     }

//     @Test
//     @DisplayName("segment.lastConstantHadWideIndex=false and CPFloat zero")
//     void TC09() throws Exception {
        // GIVEN
//         Segment segment = mock(Segment.class);
//         when(segment.lastConstantHadWideIndex()).thenReturn(false);
//         
//         CpBands cpBands = mock(CpBands.class);
//         CPFloat cpFloat = mock(CPFloat.class);
//         when(cpBands.getConstant("cst")).thenReturn(cpFloat);
//         
//         BcBands bcBands = new BcBands(cpBands, segment, 0);
// 
        // WHEN
//         bcBands.visitLdcInsn("cst");
// 
        // THEN
        // Access private field byteCodeOffset
//         Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
//         byteCodeOffsetField.setAccessible(true);
//         int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
//         assertEquals(2, byteCodeOffset);
// 
        // Access private field bcCodes
//         Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
//         bcCodesField.setAccessible(true);
//         List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
//         assertTrue(bcCodes.contains(235));
// 
        // Access private field bcFloatRef
//         Field bcFloatRefField = BcBands.class.getDeclaredField("bcFloatRef");
//         bcFloatRefField.setAccessible(true);
//         List<CPFloat> bcFloatRef = (List<CPFloat>) bcFloatRefField.get(bcBands);
//         assertTrue(bcFloatRef.contains(cpFloat));
//     }

//     @Test
//     @DisplayName("segment.lastConstantHadWideIndex=false and CPString non-empty")
//     void TC10() throws Exception {
        // GIVEN
//         Segment segment = mock(Segment.class);
//         when(segment.lastConstantHadWideIndex()).thenReturn(false);
//         
//         CpBands cpBands = mock(CpBands.class);
//         CPString cpString = mock(CPString.class);
//         when(cpBands.getConstant("cst")).thenReturn(cpString);
//         
//         BcBands bcBands = new BcBands(cpBands, segment, 0);
// 
        // WHEN
//         bcBands.visitLdcInsn("cst");
// 
        // THEN
        // Access private field byteCodeOffset
//         Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
//         byteCodeOffsetField.setAccessible(true);
//         int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
//         assertEquals(2, byteCodeOffset);
// 
        // Access private field bcCodes
//         Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
//         bcCodesField.setAccessible(true);
//         List<Integer> bcCodes = (List<Integer>) bcCodesField.get(bcBands);
//         assertTrue(bcCodes.contains(18));
// 
        // Access private field bcStringRef
//         Field bcStringRefField = BcBands.class.getDeclaredField("bcStringRef");
//         bcStringRefField.setAccessible(true);
//         List<CPString> bcStringRef = (List<CPString>) bcStringRefField.get(bcBands);
//         assertTrue(bcStringRef.contains(cpString));
//     }
}