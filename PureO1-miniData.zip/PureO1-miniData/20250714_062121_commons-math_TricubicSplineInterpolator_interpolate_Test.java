package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

public class TricubicSplineInterpolatorTest {

    private final TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

    @Test
    public void testInterpolate_AllEmptyArrays_ShouldThrowNoDataException() {
        double[] xval = {};
        double[] yval = {};
        double[] zval = {};
        double[][][] fval = {};
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @Test
    public void testInterpolate_EmptyXval_ShouldThrowNoDataException() {
        double[] xval = {};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = new double[0][0][0];
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @Test
    public void testInterpolate_EmptyYval_ShouldThrowNoDataException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {};
        double[] zval = {1.0, 2.0};
        double[][][] fval = new double[2][0][0];
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @Test
    public void testInterpolate_EmptyZval_ShouldThrowNoDataException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {};
        double[][][] fval = new double[2][2][0];
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @Test
    public void testInterpolate_EmptyFval_ShouldThrowNoDataException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {};
        assertThrows(NoDataException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @Test
    public void testInterpolate_XvalLengthMismatch_ShouldThrowDimensionMismatchException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = new double[3][2][2];
        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @ParameterizedTest
    @MethodSource("fvalLengthMismatchProvider")
    public void testInterpolate_FvalYLengthMismatch_ShouldThrowDimensionMismatchException(double[] xval, double[] yval, double[] zval, double[][][] fval) {
        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    private static Stream<Arguments> fvalLengthMismatchProvider() {
        return Stream.of(
                Arguments.of(
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0},
                        new double[][][]{
                                {
                                        {1.0, 2.0},
                                        {3.0}
                                },
                                {
                                        {4.0, 5.0},
                                        {6.0, 7.0}
                                }
                        }
                ),
                Arguments.of(
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0, 3.0},
                        new double[]{1.0, 2.0},
                        new double[][][]{
                                {
                                        {1.0, 2.0},
                                        {3.0, 4.0},
                                        {5.0, 6.0}
                                },
                                {
                                        {7.0, 8.0},
                                        {9.0, 10.0}
                                }
                        }
                )
        );
    }

    @ParameterizedTest
    @MethodSource("fvalZLengthMismatchProvider")
    public void testInterpolate_FvalZLengthMismatch_ShouldThrowDimensionMismatchException(double[] xval, double[] yval, double[] zval, double[][][] fval) {
        assertThrows(DimensionMismatchException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    private static Stream<Arguments> fvalZLengthMismatchProvider() {
        return Stream.of(
                Arguments.of(
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0},
                        new double[][][]{
                                {
                                        {1.0, 2.0, 3.0},
                                        {4.0, 5.0}
                                },
                                {
                                        {6.0, 7.0},
                                        {8.0, 9.0}
                                }
                        }
                )
        );
    }

    @ParameterizedTest
    @MethodSource("nonMonotonicSequenceProvider")
    public void testInterpolate_NonMonotonicSequences_ShouldThrowNonMonotonicSequenceException(double[] xval, double[] yval, double[] zval) {
        double[][][] fval = {
                {
                        {1.0, 2.0},
                        {3.0, 4.0}
                },
                {
                        {5.0, 6.0},
                        {7.0, 8.0}
                }
        };
        assertThrows(NonMonotonicSequenceException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    private static Stream<Arguments> nonMonotonicSequenceProvider() {
        return Stream.of(
                Arguments.of(
                        new double[]{2.0, 1.0},
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0}
                ),
                Arguments.of(
                        new double[]{1.0, 2.0},
                        new double[]{2.0, 1.0},
                        new double[]{1.0, 2.0}
                ),
                Arguments.of(
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0},
                        new double[]{2.0, 1.0}
                )
        );
    }

    @ParameterizedTest
    @MethodSource("tooSmallSequenceProvider")
    public void testInterpolate_TooSmallSequences_ShouldThrowNumberIsTooSmallException(double[] xval, double[] yval, double[] zval) {
        double[][][] fval = { { {1.0} } };
        assertThrows(NumberIsTooSmallException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    private static Stream<Arguments> tooSmallSequenceProvider() {
        return Stream.of(
                Arguments.of(
                        new double[]{1.0},
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0}
                ),
                Arguments.of(
                        new double[]{1.0, 2.0},
                        new double[]{1.0},
                        new double[]{1.0, 2.0}
                ),
                Arguments.of(
                        new double[]{1.0, 2.0},
                        new double[]{1.0, 2.0},
                        new double[]{1.0}
                )
        );
    }

    @Test
    public void testInterpolate_NullInputs_ShouldThrowNullPointerException() {
        double[] xval = null;
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = { { {1.0, 2.0}, {3.0, 4.0} } };
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, zval, fval));

        xval = new double[]{1.0, 2.0};
        yval = null;
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, zval, fval));

        yval = new double[]{1.0, 2.0};
        zval = null;
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, zval, fval));

        zval = new double[]{1.0, 2.0};
        fval = null;
        assertThrows(NullPointerException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @Test
    public void testInterpolate_ValidInput_ShouldReturnInterpolatingFunction() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {
                {
                        {1.0, 2.0},
                        {3.0, 4.0}
                },
                {
                        {5.0, 6.0},
                        {7.0, 8.0}
                }
        };
        assertDoesNotThrow(() -> {
            TricubicSplineInterpolatingFunction func = interpolator.interpolate(xval, yval, zval, fval);
            assertNotNull(func);
            double value = func.value(1.5, 1.5, 1.5);
            // Since it's a test, we can check if value is within expected range
            assertTrue(value >= 1.0 && value <= 8.0);
        });
    }

    @Test
    public void testInterpolate_SinglePointInAllDimensions_ShouldThrowNumberIsTooSmallException() {
        double[] xval = {1.0};
        double[] yval = {1.0};
        double[] zval = {1.0};
        double[][][] fval = { { {1.0} } };
        assertThrows(NumberIsTooSmallException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }

    @Test
    public void testInterpolate_SinglePointInOneDimension_ShouldThrowNumberIsTooSmallException() {
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {
                { {1.0, 2.0} },
                { {3.0, 4.0} }
        };
        assertThrows(NumberIsTooSmallException.class, () -> interpolator.interpolate(xval, yval, zval, fval));
    }
}