package org.apache.commons.math3.ode.sampling;

import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.sampling.StepNormalizer;
import org.apache.commons.math3.ode.sampling.StepNormalizerMode;
import org.apache.commons.math3.ode.sampling.StepNormalizerBounds;
import org.apache.commons.math3.ode.sampling.FixedStepHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StepNormalizerTest {

    private FixedStepHandler mockHandler;
    private StepInterpolator mockInterpolator;

    @BeforeEach
    void setUp() {
        mockHandler = mock(FixedStepHandler.class);
        mockInterpolator = mock(StepInterpolator.class);
    }

    @Test
    void handleStep_FirstCall_ForwardIncrementMode_FirstBounds() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        normalizer.handleStep(mockInterpolator, false);
        normalizer.handleStep(mockInterpolator, true);

        ArgumentCaptor<Double> timeCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<double[]> stateCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<double[]> derivCaptor = ArgumentCaptor.forClass(double[].class);
        ArgumentCaptor<Boolean> lastCaptor = ArgumentCaptor.forClass(Boolean.class);

        verify(mockHandler, atLeastOnce()).handleStep(timeCaptor.capture(), stateCaptor.capture(), derivCaptor.capture(), lastCaptor.capture());

        // Additional assertions can be added here based on captured values
    }

    @Test
    void handleStep_FirstCall_BackwardIncrementMode_LastBounds() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(3.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{-0.1});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.LAST);

        normalizer.handleStep(mockInterpolator, false);
        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_ModeMultiples_PrecisionEqualsTrue() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.5);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.5);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.2});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.NEITHER);

        when(mockInterpolator.getInterpolatedTime()).thenReturn(1.0);
        normalizer.handleStep(mockInterpolator, false);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_ModeMultiples_PrecisionEqualsFalse() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.3);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.3);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.3});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.3});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.BOTH);

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_IsLast_AddLastTrue() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(2.5);
        when(mockInterpolator.getCurrentTime()).thenReturn(3.1);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{3.1});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.31});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.LAST);

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), eq(true));
    }

    @Test
    void handleStep_IsLast_AddLastFalse() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(3.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{3.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.3});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), eq(false));
    }

    @Test
    void handleStep_NextInStepForward() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);

        normalizer.handleStep(mockInterpolator, false);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_NextInStepBackward() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(3.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(2.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{2.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{-0.2});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        normalizer.handleStep(mockInterpolator, false);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_NullInterpolator() {
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler);
        assertThrows(NullPointerException.class, () -> normalizer.handleStep(null, false));
    }

    @Test
    void handleStep_ZeroStepSize() {
        assertThrows(IllegalArgumentException.class, () -> new StepNormalizer(0.0, mockHandler));
    }

    @Test
    void handleStep_FirstStepNotIncluded() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);

        normalizer.handleStep(mockInterpolator, false);

        verify(mockHandler, never()).handleStep(eq(0.0), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_FirstStepIncluded() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(1.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.1});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        normalizer.handleStep(mockInterpolator, false);

        verify(mockHandler, atLeastOnce()).handleStep(eq(0.0), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_ModeIncrement_NotMultiples() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.3);
        when(mockInterpolator.getCurrentTime()).thenReturn(3.1);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{3.1});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.31});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void handleStep_ModeMultiples_FirstAndLastIncluded() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(3.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{3.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.3});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.BOTH);

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(eq(0.0), any(), any(), anyBoolean());
        verify(mockHandler, atLeastOnce()).handleStep(eq(3.0), any(), any(), eq(true));
    }

    @Test
    void handleStep_ModeMultiples_FirstIncluded_LastNotIncluded() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(2.7);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{2.7});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.27});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.FIRST);

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(eq(0.0), any(), any(), anyBoolean());
        verify(mockHandler, never()).handleStep(eq(2.7), any(), any(), eq(true));
    }

    @Test
    void handleStep_ModeIncrement_BackwardDirection() throws MaxCountExceededException {
        when(mockInterpolator.getPreviousTime()).thenReturn(3.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.0);
        when(mockInterpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
        when(mockInterpolator.getInterpolatedDerivatives()).thenReturn(new double[]{-0.3});
        StepNormalizer normalizer = new StepNormalizer(0.5, mockHandler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);

        normalizer.handleStep(mockInterpolator, true);

        verify(mockHandler, atLeastOnce()).handleStep(anyDouble(), any(), any(), anyBoolean());
    }
}