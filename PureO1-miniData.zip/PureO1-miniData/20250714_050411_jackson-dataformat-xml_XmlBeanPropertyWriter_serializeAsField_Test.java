package com.fasterxml.jackson.dataformat.xml.ser;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import javax.xml.namespace.QName;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.ser.PropertySerializerMap;
import com.fasterxml.jackson.databind.ser.std.NullSerializer;

class XmlBeanPropertyWriterTest {

    @Mock
    private BeanPropertyWriter mockedWrapped;

    @Mock
    private JsonGenerator mockJsonGenerator;

    @Mock
    private SerializerProvider mockProvider;

    @Mock
    private JsonSerializer<Object> mockSerializer;

    @Mock
    private PropertySerializerMap mockSerializerMap;

    @Mock
    private ToXmlGenerator mockToXmlGenerator;

    @InjectMocks
    private XmlBeanPropertyWriter propertyWriter;

    private PropertyName wrapperName = new PropertyName("wrapper");
    private PropertyName wrappedName = new PropertyName("wrapped");

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(mockedWrapped.getName()).thenReturn(new SerializedString("fieldName"));
        when(mockedWrapped.get(bean())).thenReturn(null);
        when(mockProvider.findValueSerializer(any(Class.class), any(BeanPropertyWriter.class)))
                .thenReturn(mockSerializer);
        when(mockSerializer.isEmpty(any(SerializerProvider.class), any())).thenReturn(false);
        propertyWriter = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName);
    }

    private Object bean() {
        return new Object();
    }

    @Test
    void serializeAsField_nullValue_shouldReturnWithoutAction() throws Exception {
        when(mockedWrapped.get(bean())).thenReturn(null);
        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);
        verify(mockJsonGenerator, never()).writeFieldName(any());
        verify(mockSerializer, never()).serialize(any(), any(), any());
    }

    @Test
    void serializeAsField_nonNullValue_withSerializer_noSuppression_noCycle_noXmlGen_noTypeSerializer()
            throws Exception {
        Object value = "testValue";
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.isEmpty(mockProvider, value)).thenReturn(false);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
        verifyNoMoreInteractions(mockJsonGenerator, mockSerializer);
    }

    @Test
    void serializeAsField_nonNullValue_withSuppressableValue_MARKER_FOR_EMPTY_empty_shouldReturn() throws Exception {
        Object value = "emptyValue";
        propertyWriter = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName, mockSerializer);
        propertyWriter._suppressableValue = BeanPropertyWriter.MARKER_FOR_EMPTY;
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.isEmpty(mockProvider, value)).thenReturn(true);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockSerializer).isEmpty(mockProvider, value);
        verify(mockJsonGenerator, never()).writeFieldName(any());
    }

    @Test
    void serializeAsField_nonNullValue_withSuppressableValue_MARKER_FOR_EMPTY_notEmpty_shouldSerialize() throws Exception {
        Object value = "nonEmptyValue";
        propertyWriter = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName, mockSerializer);
        propertyWriter._suppressableValue = BeanPropertyWriter.MARKER_FOR_EMPTY;
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.isEmpty(mockProvider, value)).thenReturn(false);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockSerializer).isEmpty(mockProvider, value);
        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
    }

    @Test
    void serializeAsField_nonNullValue_withSuppressableValue_equalsValue_shouldReturn() throws Exception {
        Object value = "suppressValue";
        propertyWriter = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName, mockSerializer);
        propertyWriter._suppressableValue = value;
        when(mockedWrapped.get(bean())).thenReturn(value);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockJsonGenerator, never()).writeFieldName(any());
        verify(mockSerializer, never()).serialize(any(), any(), any());
    }

    @Test
    void serializeAsField_nonNullValue_withSuppressableValue_notEqualsValue_shouldSerialize() throws Exception {
        Object value = "differentValue";
        propertyWriter = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName, mockSerializer);
        propertyWriter._suppressableValue = "otherValue";
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
    }

    @Test
    void serializeAsField_valueIsBean_handleSelfReferenceReturnsTrue_shouldReturn() throws Exception {
        Object value = bean();
        propertyWriter = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName, mockSerializer);
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(propertyWriter._handleSelfReference(bean(), mockJsonGenerator, mockProvider, mockSerializer))
                .thenReturn(true);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(propertyWriter)._handleSelfReference(bean(), mockJsonGenerator, mockProvider, mockSerializer);
        verify(mockSerializer, never()).serialize(any(), any(), any());
    }

    @Test
    void serializeAsField_valueIsBean_handleSelfReferenceReturnsFalse_shouldSerialize() throws Exception {
        Object value = bean();
        propertyWriter = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName, mockSerializer);
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(propertyWriter._handleSelfReference(bean(), mockJsonGenerator, mockProvider, mockSerializer))
                .thenReturn(false);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(propertyWriter)._handleSelfReference(bean(), mockJsonGenerator, mockProvider, mockSerializer);
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
    }

    @Test
    void serializeAsField_jgenIsToXmlGenerator_withWrappedValue_noTypeSerializer() throws Exception {
        Object value = "xmlValue";
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);
        when(mockJsonGenerator instanceof ToXmlGenerator).thenReturn(true);
        when(mockJsonGenerator).thenReturn(mockToXmlGenerator);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockToXmlGenerator).startWrappedValue(any(QName.class), any(QName.class));
        verify(mockToXmlGenerator).finishWrappedValue(any(QName.class), any(QName.class));
        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
    }

    @Test
    void serializeAsField_jgenIsToXmlGenerator_withWrappedValue_withTypeSerializer() throws Exception {
        Object value = "xmlValue";
        TypeSerializer mockTypeSerializer = mock(TypeSerializer.class);
        propertyWriter._typeSerializer = mockTypeSerializer;
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.serializeWithType(value, mockJsonGenerator, mockProvider, mockTypeSerializer))
                .thenReturn(null);
        when(mockJsonGenerator instanceof ToXmlGenerator).thenReturn(true);
        when(mockJsonGenerator).thenReturn(mockToXmlGenerator);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockToXmlGenerator).startWrappedValue(any(QName.class), any(QName.class));
        verify(mockToXmlGenerator).finishWrappedValue(any(QName.class), any(QName.class));
        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serializeWithType(value, mockJsonGenerator, mockProvider, mockTypeSerializer);
    }

    @Test
    void serializeAsField_jgenIsNotToXmlGenerator_shouldSerializeNormally() throws Exception {
        Object value = "normalValue";
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);
        when(mockJsonGenerator instanceof ToXmlGenerator).thenReturn(false);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
        verify(mockToXmlGenerator, never()).startWrappedValue(any(QName.class), any(QName.class));
        verify(mockToXmlGenerator, never()).finishWrappedValue(any(QName.class), any(QName.class));
    }

    @Test
    void serializeAsField_serializerIsNull_shouldFindAndAddDynamicSerializer() throws Exception {
        XmlBeanPropertyWriter writer = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName);
        when(mockedWrapped.get(bean())).thenReturn("dynamicValue");
        when(writer._dynamicSerializers).thenReturn(mockSerializerMap);
        when(mockSerializerMap.serializerFor(any(Class.class))).thenReturn(null);
        JsonSerializer<Object> dynamicSerializer = mock(JsonSerializer.class);
        when(writer._findAndAddDynamic(mockSerializerMap, String.class, mockProvider)).thenReturn(dynamicSerializer);
        when(dynamicSerializer.serialize("dynamicValue", mockJsonGenerator, mockProvider)).thenReturn(null);

        writer.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(writer)._findAndAddDynamic(mockSerializerMap, String.class, mockProvider);
        verify(dynamicSerializer).serialize("dynamicValue", mockJsonGenerator, mockProvider);
    }

    @Test
    void serializeAsField_handleValueNotEqualToBean_noSelfReference() throws Exception {
        Object value = new Object();
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(propertyWriter._handleSelfReference(bean(), mockJsonGenerator, mockProvider, mockSerializer))
                .thenReturn(false);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(propertyWriter)._handleSelfReference(bean(), mockJsonGenerator, mockProvider, mockSerializer);
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
    }

    @Test
    void serializeAsField_suppressableValueNull_shouldSerialize() throws Exception {
        Object value = "someValue";
        propertyWriter._suppressableValue = null;
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.isEmpty(mockProvider, value)).thenReturn(false);
        when(mockSerializer.serialize(value, mockJsonGenerator, mockProvider)).thenReturn(null);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockSerializer, never()).isEmpty(any(), any());
        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serialize(value, mockJsonGenerator, mockProvider);
    }

    @Test
    void serializeAsField_withTypeSerializer_shouldSerializeWithType() throws Exception {
        Object value = "typedValue";
        TypeSerializer mockTypeSerializer = mock(TypeSerializer.class);
        propertyWriter._typeSerializer = mockTypeSerializer;
        when(mockedWrapped.get(bean())).thenReturn(value);
        when(mockSerializer.serializeWithType(value, mockJsonGenerator, mockProvider, mockTypeSerializer))
                .thenReturn(null);
        when(mockJsonGenerator instanceof ToXmlGenerator).thenReturn(false);

        propertyWriter.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockJsonGenerator).writeFieldName("fieldName");
        verify(mockSerializer).serializeWithType(value, mockJsonGenerator, mockProvider, mockTypeSerializer);
    }

    @Test
    void serializeAsField_withNullSerializerAndNoDynamicSerializer_shouldUseNullSerializer() throws Exception {
        XmlBeanPropertyWriter writer = new XmlBeanPropertyWriter(mockedWrapped, wrapperName, wrappedName);
        when(mockedWrapped.get(bean())).thenReturn(null);
        writer.assignSerializer(NullSerializer.instance);

        writer.serializeAsField(bean(), mockJsonGenerator, mockProvider);

        verify(mockJsonGenerator, never()).writeFieldName(any());
        verifyNoInteractions(mockJsonGenerator);
    }
}