import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.language.Metaphone;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class MetaphoneTest {

    Metaphone metaphone = new Metaphone();

    @Test
    public void testEmptyInput() {
        assertEquals("", metaphone.metaphone(""));
    }

    @Test
    public void testNullInput() {
        assertEquals("", metaphone.metaphone(null));
    }

    @Test
    public void testSingleCharacter() {
        assertEquals("A", metaphone.metaphone("a"));
    }

    @ParameterizedTest
    @CsvSource({
        "knight, NIT",
        "gnome, NM",
        "pneumonia, NMN",
        "aero, ARO",
        "whale, WL",
        "whirl, WRL",
        "xenon, SN",
        "gel, JL",
        "ghost, KST",
        "gnaw, N"
    })
    public void testSpecialCases(String input, String expected) {
        assertEquals(expected, metaphone.metaphone(input));
    }

    @Test
    public void testConsonants() {
        assertEquals("CNSNNT", metaphone.metaphone("Consonant"));
    }

    @Test
    public void testVowels() {
        assertEquals("A", metaphone.metaphone("AEIOU"));
    }

    @ParameterizedTest
    @CsvSource({
        "bottle, BTL",
        "chedder, XTR",
        "fudge, FJ",
        "laugh, LF",
        "wright, R",
        "queen, KN",
        "match, MX",
        "phase, FS",
        "sugar, XR",
        "thumb, 0M"
    })
    public void testVariousWords(String input, String expected) {
        assertEquals(expected, metaphone.metaphone(input));
    }

    @Test
    public void testMaxCodeLen() {
        metaphone.setMaxCodeLen(10);
        assertEquals("VWL", metaphone.metaphone("vowel"));
    }

    @Test
    public void testMaxCodeLenApplied() {
        metaphone.setMaxCodeLen(3);
        assertEquals(3, metaphone.getMaxCodeLen());
        assertEquals("KL", metaphone.metaphone("knuckle"));
    }
    
    @Test
    public void testEncoderException() {
        assertThrows(EncoderException.class, () -> metaphone.encode(new Object()));
    }
}