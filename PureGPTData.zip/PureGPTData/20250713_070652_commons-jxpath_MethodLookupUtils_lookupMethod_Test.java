import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

class MethodLookupUtilsTest {

    public static class TestClass {
        public void doSomething(int a) {}
        public void doSomethingExact(int a) {}
        public void doSomethingApproximate(Number a) {}
        public static void staticMethod(int a) {}
    }

    @Test
    void testLookupMethodWithNullParameters() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "doSomething", null);
        assertNull(method);
    }

    @Test
    void testLookupMethodWithEmptyParameters() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "doSomething", new Object[]{});
        assertNull(method);
    }

    @Test
    void testLookupMethodNonMatchingMethodName() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "nonExistingMethod", new Object[]{1});
        assertNull(method);
    }

    @Test
    void testLookupMethodExactMatch() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "doSomethingExact", new Object[]{1});
        assertNotNull(method);
        assertEquals("doSomethingExact", method.getName());
    }

    @Test
    void testLookupMethodApproximateMatch() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "doSomethingApproximate", new Object[]{1});
        assertNotNull(method);
        assertEquals("doSomethingApproximate", method.getName());
    }

    @Test
    void testLookupMethodNoMatchOnTargetClass() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "doSomething", new Object[]{new Object()});
        assertNull(method);
    }

    @Test
    void testLookupMethodStaticMethodWithNonStaticRequested() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "staticMethod", new Object[]{1});
        assertNull(method);
    }

    @Test
    void testLookupMethodAmbiguous() {
        class TestAmbiguous {
            public void ambiguousMethod(int a) {}
            public void ambiguousMethod(Number a) {}
        }
        Executable executable = () -> MethodLookupUtils.lookupMethod(TestAmbiguous.class, "ambiguousMethod", new Object[]{1});
        assertThrows(JXPathException.class, executable, "Ambiguous method call: ambiguousMethod");
    }

    @Test
    void testLookupMethodWithNullObjectParameter() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "doSomething", new Object[]{null});
        assertNull(method);
    }
}