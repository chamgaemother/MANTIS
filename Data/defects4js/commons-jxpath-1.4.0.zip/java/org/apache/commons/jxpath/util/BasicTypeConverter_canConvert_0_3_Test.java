package org.apache.commons.jxpath.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class BasicTypeConverter_canConvert_0_3_Test {

    @Test
    @DisplayName("object is String and useType is Character, should return true")
    void TC11() {
        Object object = "c";
        Class<?> toType = Character.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        boolean result = converter.canConvert(object, toType);
        assertTrue(result);
    }

    @Test
    @DisplayName("object is String and useType is Byte, should return true")
    void TC12() {
        Object object = "127";
        Class<?> toType = Byte.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        boolean result = converter.canConvert(object, toType);
        assertTrue(result);
    }

    @Test
    @DisplayName("object is String and useType is Short, should return true")
    void TC13() {
        Object object = "32767";
        Class<?> toType = Short.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        boolean result = converter.canConvert(object, toType);
        assertTrue(result);
    }

    @Test
    @DisplayName("object is String and useType is Integer, should return true")
    void TC14() {
        Object object = "2147483647";
        Class<?> toType = Integer.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        boolean result = converter.canConvert(object, toType);
        assertTrue(result);
    }

    @Test
    @DisplayName("object is String and useType is Long, should return true")
    void TC15() {
        Object object = "9223372036854775807";
        Class<?> toType = Long.class;
        BasicTypeConverter converter = new BasicTypeConverter();
        boolean result = converter.canConvert(object, toType);
        assertTrue(result);
    }

}