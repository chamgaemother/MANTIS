package com.fasterxml.jackson.databind.ser;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.BeanDescription;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;

public class BeanSerializerBuilder_build_0_3_Test {

    @Test
    @DisplayName("_filteredProperties is null, _properties is not empty, expecting BeanSerializer creation")
    public void TC11() throws Exception {
        // Create a mock BeanDescription or provide a real instance if possible
        BeanDescription mockBeanDesc = createMockBeanDescription(); // This depends on your context
        
        // Instantiate BeanSerializerBuilder
        BeanSerializerBuilder builder = new BeanSerializerBuilder(mockBeanDesc);

        // Set _properties via reflection
        Field propertiesField = BeanSerializerBuilder.class.getDeclaredField("_properties");
        propertiesField.setAccessible(true);
        BeanPropertyWriter propertyWriter = createBeanPropertyWriter(); // Assume a method to create a BeanPropertyWriter
        propertiesField.set(builder, Arrays.asList(propertyWriter));

        // Set _filteredProperties to null via reflection
        Field filteredPropertiesField = BeanSerializerBuilder.class.getDeclaredField("_filteredProperties");
        filteredPropertiesField.setAccessible(true);
        filteredPropertiesField.set(builder, null);

        // Invoke the build method
        JsonSerializer<?> serializer = builder.build();

        // Assert that the serializer is an instance of BeanSerializer
        assertInstanceOf(BeanSerializer.class, serializer);
    }

    // Helper method to create a BeanPropertyWriter instance
    private BeanPropertyWriter createBeanPropertyWriter() throws Exception {
        // Implement this method based on how BeanPropertyWriter needs to be created
        return BeanPropertyWriter.class.getDeclaredConstructor().newInstance();
    }

    // Mock or real implementation depending on context
    private BeanDescription createMockBeanDescription() {
        // Implement this based on the actual use case
        return null; // Placeholder for the actual implementation
    }
}