package org.apache.commons.math3.stat.ranking;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.stat.ranking.NaturalRanking;
import org.apache.commons.math3.stat.ranking.NaNStrategy;
import org.apache.commons.math3.stat.ranking.TiesStrategy;

public class NaturalRanking_rank_0_3_Test {

    @Test
    @DisplayName("rank resolves ties using MINIMUM strategy")
    void TC11_rank_resolves_ties_with_MINIMUM_strategy() {
        // GIVEN
        double[] data = new double[]{2.0, 2.0, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.REMOVED, TiesStrategy.MINIMUM);

        // WHEN
        double[] result = ranking.rank(data);

        // THEN
        assertAll("Tied ranks are assigned the minimum rank",
            () -> assertEquals(1.0, result[0]),
            () -> assertEquals(1.0, result[1]),
            () -> assertEquals(3.0, result[2])
        );
    }

    @Test
    @DisplayName("rank resolves ties using RANDOM strategy")
    void TC12_rank_resolves_ties_with_RANDOM_strategy() {
        // GIVEN
        double[] data = new double[]{2.0, 2.0, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.REMOVED, TiesStrategy.RANDOM);

        // WHEN
        double[] result = ranking.rank(data);

        // THEN
        assertAll("Tied ranks are assigned random ranks within the valid range",
            () -> assertTrue((result[0] == 1.0 || result[0] == 2.0), "result[0] should be 1.0 or 2.0"),
            () -> assertTrue((result[1] == 1.0 || result[1] == 2.0), "result[1] should be 1.0 or 2.0"),
            () -> assertEquals(3.0, result[2], "result[2] should be 3.0")
        );
    }

    @Test
    @DisplayName("rank resolves ties using SEQUENTIAL strategy")
    void TC13_rank_resolves_ties_with_SEQUENTIAL_strategy() {
        // GIVEN
        double[] data = new double[]{2.0, 2.0, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.REMOVED, TiesStrategy.SEQUENTIAL);

        // WHEN
        double[] result = ranking.rank(data);

        // THEN
        assertAll("Tied ranks are assigned sequential ranks",
            () -> assertEquals(1.0, result[0]),
            () -> assertEquals(2.0, result[1]),
            () -> assertEquals(3.0, result[2])
        );
    }

    @Test
    @DisplayName("rank with multiple iterations and no ties")
    void TC14_rank_multiple_distinct_elements() {
        // GIVEN
        double[] data = new double[]{3.0, 1.0, 4.0, 2.0};
        NaturalRanking ranking = new NaturalRanking();

        // WHEN
        double[] result = ranking.rank(data);

        // THEN
        assertAll("All elements are correctly ranked without ties",
            () -> assertEquals(3.0, result[0]),
            () -> assertEquals(1.0, result[1]),
            () -> assertEquals(4.0, result[2]),
            () -> assertEquals(2.0, result[3])
        );
    }
}