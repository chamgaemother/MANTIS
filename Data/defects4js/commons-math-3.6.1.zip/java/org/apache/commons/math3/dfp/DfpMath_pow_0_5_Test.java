package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.dfp.DfpMath;
import java.lang.reflect.Field;

public class DfpMath_pow_0_5_Test {

    @Test
    @DisplayName("pow(x, y) handles x = Infinity and y > 0")
    public void TC21() throws Exception {
        DfpField field = new DfpField(10);
        Dfp x = field.newDfp(Dfp.INFINITE);
        Dfp y = new Dfp(field, "2");
        Dfp result = DfpMath.pow(x, y);
        assertEquals(x, result);
    }

    @Test
    @DisplayName("pow(x, y) handles x = Infinity and y < 0")
    public void TC22() throws Exception {
        DfpField field = new DfpField(10);
        Dfp x = field.newDfp(Dfp.INFINITE);
        Dfp y = new Dfp(field, "-2");
        Dfp result = DfpMath.pow(x, y);
        Dfp expected = field.getZero();
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("pow(x, y) handles x = Infinity and y = 0")
    public void TC23() throws Exception {
        DfpField field = new DfpField(10);
        Dfp x = field.newDfp(Dfp.INFINITE);
        Dfp y = field.getZero();
        Dfp result = DfpMath.pow(x, y);
        Dfp expected = field.getOne();
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("pow(x, y) handles large exponents y > 1e8")
    public void TC24() throws Exception {
        DfpField field = new DfpField(20);
        Dfp x = new Dfp(field, "2");
        Dfp y = new Dfp(field, "100000001");
        Dfp result = DfpMath.pow(x, y);
        Dfp expected = DfpMath.exp(DfpMath.log(x).multiply(y));
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("pow(x, y) handles x = 1 and y = +Infinity")
    public void TC25() throws Exception {
        DfpField field = new DfpField(10);
        Dfp x = field.getOne();
        Dfp y = field.newDfp(Dfp.INFINITE);
        Dfp result = DfpMath.pow(x, y);
        assertTrue(result.isNaN());

        // Using reflection to access FLAG_INVALID correctly
        Field ieeeFlagsField = DfpField.class.getDeclaredField("flags");
        ieeeFlagsField.setAccessible(true);
        int flags = ieeeFlagsField.getInt(x.getField());
        Field flagInvalidField = DfpField.class.getDeclaredField("FLAG_INVALID");
        flagInvalidField.setAccessible(true);
        int FLAG_INVALID = flagInvalidField.getInt(null);
        assertEquals(FLAG_INVALID, flags & FLAG_INVALID);
    }

}
