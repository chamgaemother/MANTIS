// package org.jfree.chart.renderer.xy;
// 
// import java.awt.Graphics2D;
// import java.awt.Point;
// import java.awt.Polygon;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.entity.XYItemEntity;
// import org.jfree.chart.labels.XYToolTipGenerator;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.StackedXYAreaRenderer.StackedXYAreaRendererState;
// import org.jfree.data.xy.TableXYDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.ArgumentCaptor;
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// public class StackedXYAreaRenderer_drawItem_2_2_Test {
// 
//     @Test
//     @DisplayName("drawItem with getToolTipGenerator returns tooltip for item")
//     void TC11() throws Exception {
//         // Arrange
//         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
//         XYToolTipGenerator toolTipGenerator = mock(XYToolTipGenerator.class);
//         when(toolTipGenerator.generateToolTip(any(XYDataset.class), eq(0), eq(0))).thenReturn("Tooltip");
//         renderer.setDefaultToolTipGenerator(toolTipGenerator);
// 
//         XYDataset dataset = mock(TableXYDataset.class); // Use TableXYDataset to avoid ClassCastException
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
//         when(dataset.getXValue(0, 0)).thenReturn(5.0);
//         when(dataset.getYValue(0, 0)).thenReturn(10.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getEntityCollection()).thenReturn(entityCollection);
// 
//         XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), plot, dataset, info);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         // Act
//         renderer.drawItem(g2, state, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// 
//         // Assert
//         ArgumentCaptor<XYItemEntity> captor = ArgumentCaptor.forClass(XYItemEntity.class);
//         verify(entityCollection).add(captor.capture());
//         XYItemEntity entity = captor.getValue();
//         assertEquals("Tooltip", entity.getToolTipText());
//     }
// 
//     @Test
//     @DisplayName("drawItem with plotArea=true and last item adds fill and outline correctly")
//     void TC12() throws Exception {
//         // Arrange
//         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
//         TableXYDataset dataset = mock(TableXYDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
//         when(dataset.getXValue(0, 0)).thenReturn(20.0);
//         when(dataset.getYValue(0, 0)).thenReturn(30.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getEntityCollection()).thenReturn(entityCollection);
// 
//         XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), plot, dataset, info);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         // Act
//         renderer.drawItem(g2, state, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// 
//         // Assert
//         // Check fill and draw of shapes using the mocks
//         verify(g2).fill(any(Polygon.class));
//         verify(g2).draw(any(Polygon.class));
//     }
// 
//     @Test
//     @DisplayName("drawItem handles multiple iterations in loops for series area construction")
//     void TC13() throws Exception {
//         // Arrange
//         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
// 
//         TableXYDataset dataset = mock(TableXYDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(3);
//         when(dataset.getXValue(0, 0)).thenReturn(1.0);
//         when(dataset.getYValue(0, 0)).thenReturn(2.0);
//         when(dataset.getXValue(0, 1)).thenReturn(2.0);
//         when(dataset.getYValue(0, 1)).thenReturn(4.0);
//         when(dataset.getXValue(0, 2)).thenReturn(3.0);
//         when(dataset.getYValue(0, 2)).thenReturn(6.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(20.0);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getEntityCollection()).thenReturn(mock(EntityCollection.class));
// 
//         XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), plot, dataset, info);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         // Act
//         for (int i = 0; i < 3; i++) {
//             renderer.drawItem(g2, state, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, dataset, 0, i, crosshairState, 0);
//         }
// 
//         // Assert
//         verify(g2, atLeastOnce()).fill(any(Polygon.class));
//         verify(g2, atLeastOnce()).draw(any(Point.class));
//         verify(g2, atLeastOnce()).draw(any(Polygon.class));
//     }
// 
//     @Test
//     @DisplayName("drawItem throws exception when dataset is not an instance of TableXYDataset")
//     void TC14() throws Exception {
//         // Arrange
//         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
//         XYDataset invalidDataset = mock(XYDataset.class); // Not a TableXYDataset
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         XYItemRendererState state = renderer.initialise(g2, new Rectangle2D.Double(), plot, invalidDataset, info);
// 
//         // Act & Assert
//         assertThrows(ClassCastException.class, () -> {
//             renderer.drawItem(g2, state, new Rectangle2D.Double(), info, plot, domainAxis, rangeAxis, invalidDataset, 0, 0, crosshairState, 0);
//         });
//     }
// }