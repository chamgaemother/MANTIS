package org.apache.commons.collections4.map;

import java.lang.reflect.Field;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ConcurrentReferenceHashMap_size_0_1_Test {

    @Test
    @DisplayName("size() returns 0 when the map is empty without any retries")
    void TC01_sizeReturns0ForEmptyMap() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().get();

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("size() correctly counts elements without concurrent modifications on first attempt")
    void TC02_sizeCountsElementsWithoutConcurrency() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().get();
        // Adding predefined elements
        int expectedTotalCount = 10;
        for (int i = 0; i < expectedTotalCount; i++) {
            map.put("key" + i, "value" + i);
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(expectedTotalCount, result);
    }

    @Test
    @DisplayName("size() retries counting when a single segment is modified during the first attempt")
    void TC03_sizeRetriesOnSingleSegmentModification() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().get();
        // Adding predefined elements
        int expectedTotalCount = 10;
        for (int i = 0; i < expectedTotalCount; i++) {
            map.put("key" + i, "value" + i);
        }

        // Using reflection to modify modCount of one segment
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Assuming the Segment class has a field 'modCount'
        Class<?> segmentClass = segments[0].getClass();
        Field modCountField = segmentClass.getDeclaredField("modCount");
        modCountField.setAccessible(true);

        // Simulate a modification after first count
        modCountField.setInt(segments[0], modCountField.getInt(segments[0]) + 1);

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(expectedTotalCount, result);
    }

    @Test
    @DisplayName("size() retries up to RETRIES_BEFORE_LOCK before locking all segments")
    void TC04_sizeRetriesUpToMaxBeforeLocking() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().get();
        // Adding predefined elements
        int expectedTotalCount = 10;
        for (int i = 0; i < expectedTotalCount; i++) {
            map.put("key" + i, "value" + i);
        }

        // Using reflection to continuously modify modCount of all segments
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Assuming the Segment class has a field 'modCount'
        Class<?> segmentClass = segments[0].getClass();
        Field modCountField = segmentClass.getDeclaredField("modCount");
        modCountField.setAccessible(true);

        // Simulate continuous modifications
        int RETRIES_BEFORE_LOCK = 2; // Adjusted according to the method's RETRIES_BEFORE_LOCK setting
        for (int i = 0; i < RETRIES_BEFORE_LOCK; i++) {
            for (Object segment : segments) {
                modCountField.setInt(segment, modCountField.getInt(segment) + 1);
            }
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(expectedTotalCount, result);
    }

    @Test
    @DisplayName("size() returns Integer.MAX_VALUE when the total count exceeds its maximum value")
    void TC05_sizeReturnsMaxValueWhenCountExceedsLimit() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().get();

        // Using reflection to simulate a total count exceeding Integer.MAX_VALUE
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Assuming the Segment class has a field 'count'
        Class<?> segmentClass = segments[0].getClass();
        Field countField = segmentClass.getDeclaredField("count");
        countField.setAccessible(true);

        // Simulate large counts
        for (Object segment : segments) {
            countField.setInt(segment, Integer.MAX_VALUE);
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(Integer.MAX_VALUE, result);
    }
}