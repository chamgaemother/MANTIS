
package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_atan2_1_2_Test {

    @Test
    @DisplayName("atan2(y=1e308, x=1e-308) returns approximately Math.PI/2 when y is extremely large and x is extremely small")
    public void TC36_atan2_largeY_smallX() {
        // Given
        double y = 1e308;
        double x = 1e-308;

        // When
        double result = FastMath.atan2(y, x);

        // Then
        assertEquals(Math.PI / 2, result, 1e-10, "Expected result close to Math.PI/2");
    }

    @Test
    @DisplayName("atan2(y=1e-308, x=1e308) returns approximately 0.0 when y is extremely small and x is extremely large")
    public void TC37_atan2_smallY_largeX() {
        // Given
        double y = 1e-308;
        double x = 1e308;

        // When
        double result = FastMath.atan2(y, x);

        // Then
        assertEquals(0.0, result, 1e-10, "Expected result close to 0.0");
    }

}