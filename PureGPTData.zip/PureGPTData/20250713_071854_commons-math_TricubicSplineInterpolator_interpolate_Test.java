import org.apache.commons.math3.analysis.interpolation.TricubicSplineInterpolator;
import org.apache.commons.math3.analysis.interpolation.TricubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

public class TricubicSplineInterpolatorTest {

    @Test
    void testInterpolateNoDataException() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] emptyArray = new double[0];
        double[][][] fval = new double[0][0][0];

        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(emptyArray, emptyArray, emptyArray, fval);
        });
    }

    @Test
    void testInterpolateDimensionMismatchException() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = new double[]{1.0, 2.0};
        double[] yval = new double[]{1.0, 2.0};
        double[] zval = new double[]{1.0, 2.0};
        double[][][] fval = new double[3][2][2]; // Should be [2][2][2]

        assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    void testInterpolateNonMonotonicSequenceException() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = new double[]{2.0, 1.0}; // Non-monotonic
        double[] yval = new double[]{1.0, 2.0};
        double[] zval = new double[]{1.0, 2.0};
        double[][][] fval = new double[2][2][2];

        assertThrows(NonMonotonicSequenceException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    void testInterpolateSuccessful() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = new double[]{1.0, 2.0};
        double[] yval = new double[]{1.0, 2.0};
        double[] zval = new double[]{1.0, 2.0};
        double[][][] fval = new double[2][2][2];

        assertDoesNotThrow(() -> {
            TricubicSplineInterpolatingFunction function = interpolator.interpolate(xval, yval, zval, fval);
            assertNotNull(function);
        });
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2})
    void testNextIndex(int index) {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        int max = 3;
        int next = interpolator.nextIndex(index, max);
        assertTrue(next >= 0 && next < max);
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2})
    void testPreviousIndex(int index) {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        int prev = interpolator.previousIndex(index);
        assertTrue(prev >= 0 && prev <= index);
    }
}