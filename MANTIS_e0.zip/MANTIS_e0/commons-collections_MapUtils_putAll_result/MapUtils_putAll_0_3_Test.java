package org.apache.commons.collections4;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.collections4.MapUtils;
import java.util.HashMap;
import java.util.Map;

public class MapUtils_putAll_0_3_Test {

    @Test
    @DisplayName("putAll processes key-value pairs with even number of elements correctly")
    public void TC11_putAll_evenKeyValuePairs() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[] { "key1", 1, "key2", 2 };
        Map<String, Integer> result = MapUtils.putAll(map, array);
        
        assertAll("Map contains all key-value pairs from the array",
            () -> assertTrue(result.containsKey("key1"), "Map should contain key1"),
            () -> assertEquals(1, result.get("key1"), "Value for key1 should be 1"),
            () -> assertTrue(result.containsKey("key2"), "Map should contain key2"),
            () -> assertEquals(2, result.get("key2"), "Value for key2 should be 2")
        );
    }

    @Test
    @DisplayName("putAll processes key-value pairs with odd number of elements, ignoring the last key")
    public void TC12_putAll_oddKeyValuePairs() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[] { "key1", 1, "key2" };
        Map<String, Integer> result = MapUtils.putAll(map, array);
        
        assertAll("Map contains complete key-value pairs, last key is ignored",
            () -> assertTrue(result.containsKey("key1"), "Map should contain key1"),
            () -> assertEquals(1, result.get("key1"), "Value for key1 should be 1"),
            () -> assertFalse(result.containsKey("key2"), "Map should not contain key2")
        );
    }
}