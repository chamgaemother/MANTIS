import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.Range;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class StackedXYAreaRenderer2Test {

    private StackedXYAreaRenderer2 renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private TableXYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    public void setUp() {
        renderer = new StackedXYAreaRenderer2();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(TableXYDataset.class);
        crosshairState = mock(CrosshairState.class);
    }

    @Test
    public void testDrawItem_NullInfo() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        renderer.drawItem(g2, state, dataArea, null, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).fill(any());
    }

    @Test
    public void testDrawItem_NaNYValue_Y1NaN() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);
        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).fill(any());
    }

    @Test
    public void testDrawItem_YPositive_Vertical_RoundTrue_Pass0() {
        renderer.setRoundXCoordinates(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(20.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(30.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.5f, 20.5f, 30.5f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 110.0f, 120.0f, 130.0f, 140.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(domainAxis, times(3)).valueToJava2D(anyDouble(), eq(dataArea), any());
        verify(rangeAxis, atLeastOnce()).valueToJava2D(anyDouble(), eq(dataArea), any());
        verify(g2).fill(any());
        verify(entities).add(any(), eq(dataset), eq(0), eq(1), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_YNegative_Horizontal_RoundFalse_Pass0() {
        renderer.setRoundXCoordinates(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(-10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(-20.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(-30.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0f, 20.0f, 30.0f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 90.0f, 80.0f, 70.0f, 60.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(domainAxis, times(3)).valueToJava2D(anyDouble(), eq(dataArea), any());
        verify(rangeAxis, atLeastOnce()).valueToJava2D(anyDouble(), eq(dataArea), any());
        verify(g2).fill(any());
        verify(entities).add(any(), eq(dataset), eq(0), eq(1), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_YPositive_Horizontal_RoundTrue_Pass0() {
        renderer.setRoundXCoordinates(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(20.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(30.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.4f, 20.6f, 30.2f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 110.0f, 120.0f, 130.0f, 140.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(domainAxis, times(3)).valueToJava2D(anyDouble(), eq(dataArea), any());
        verify(rangeAxis, atLeastOnce()).valueToJava2D(anyDouble(), eq(dataArea), any());
        verify(g2).fill(any());
        verify(entities).add(any(), eq(dataset), eq(0), eq(1), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_YNegative_Vertical_RoundFalse_Pass1() {
        renderer.setRoundXCoordinates(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(-10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(-20.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(-30.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0f, 20.0f, 30.0f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 90.0f, 80.0f, 70.0f, 60.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 1);

        verify(g2, never()).fill(any());
        verify(entities, never()).add(any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_OrientationNull() {
        when(plot.getOrientation()).thenReturn(null);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 110.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));

        verify(g2, never()).fill(any());
        verify(entities, never()).add(any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_SeriesZero_StackValues() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 110.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);
        
        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0));
        
        verify(g2).fill(any());
        verify(entities).add(any(), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_RoundXCoordinatesFalse() {
        renderer.setRoundXCoordinates(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(5.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.3f, 20.7f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 105.0f, 110.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        ArgumentCaptor<java.awt.Shape> shapeCaptor = ArgumentCaptor.forClass(java.awt.Shape.class);
        verify(g2, times(2)).fill(shapeCaptor.capture());
        verify(entities).add(any(), eq(dataset), eq(0), eq(1), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_PassNotZero() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 110.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, never()).fill(any());
        verify(entities, never()).add(any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_DatasetNull() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, crosshairState, 0);
        });
    }

    @Test
    public void testDrawItem_SeriesOutOfBounds() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        // Series index out of bounds
        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 1, 0, crosshairState, 0);

        verify(g2, never()).fill(any());
        verify(entities, never()).add(any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_ItemOutOfBounds() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        // Item index out of bounds
        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2, never()).fill(any());
        verify(entities, never()).add(any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_EntityCollectionNull() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 110.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).fill(any());
    }

    @Test
    public void testDrawItem_Y0Negative_Y1Positive() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getSeriesCount()).thenReturn(2);
        // Series 0
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(-15.0);
        // Series 1
        when(dataset.getXValue(1, 1)).thenReturn(2.0);
        when(dataset.getYValue(1, 1)).thenReturn(25.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(20.0f);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0f, 120.0f, 140.0f);
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(plotInfo.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 0);

        verify(g2).fill(any());
        verify(entities).add(any(), eq(dataset), eq(1), eq(1), anyDouble(), anyDouble());
    }
}