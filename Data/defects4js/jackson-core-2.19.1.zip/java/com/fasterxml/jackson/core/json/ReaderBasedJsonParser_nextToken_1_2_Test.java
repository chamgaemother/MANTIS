package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Constructor;

import static org.junit.jupiter.api.Assertions.*;

public class ReaderBasedJsonParser_nextToken_1_2_Test {

    @Test
    @DisplayName("TC46: nextToken() correctly parses strings with escaped characters")
    public void TC46_nextToken_parsesStringsWithEscapedCharacters() throws Exception {
        // Arrange
        String json = "{\"message\": \"Hello\\nWorld\"}";
        ReaderBasedJsonParser parser = createParser(json);

        // Act
        JsonToken token1 = parser.nextToken(); // START_OBJECT
        JsonToken token2 = parser.nextToken(); // FIELD_NAME
        JsonToken token3 = parser.nextToken(); // VALUE_STRING

        // Assert
        assertEquals(JsonToken.START_OBJECT, token1, "First token should be START_OBJECT");
        assertEquals(JsonToken.FIELD_NAME, token2, "Second token should be FIELD_NAME");
        assertEquals("message", parser.getCurrentName(), "Field name should be 'message'");
        assertEquals(JsonToken.VALUE_STRING, token3, "Third token should be VALUE_STRING");
        assertEquals("Hello\nWorld", parser.getText(), "Parsed string should contain escaped newline");
    }

    @Test
    @DisplayName("TC47: nextToken() correctly skips and handles comments within object when comments are allowed")
    public void TC47_nextToken_skipsCommentsWithinObject() throws Exception {
        // Arrange
        String json = "{ /* comment */ \"key\": \"value\" }";
        ReaderBasedJsonParser parser = createParserWithComments(json);

        // Act
        JsonToken token1 = parser.nextToken(); // START_OBJECT
        JsonToken token2 = parser.nextToken(); // FIELD_NAME
        JsonToken token3 = parser.nextToken(); // VALUE_STRING
        JsonToken token4 = parser.nextToken(); // END_OBJECT

        // Assert
        assertEquals(JsonToken.START_OBJECT, token1, "First token should be START_OBJECT");
        assertEquals(JsonToken.FIELD_NAME, token2, "Second token should be FIELD_NAME");
        assertEquals("key", parser.getCurrentName(), "Field name should be 'key'");
        assertEquals(JsonToken.VALUE_STRING, token3, "Third token should be VALUE_STRING");
        assertEquals("value", parser.getText(), "Field value should be 'value'");
        assertEquals(JsonToken.END_OBJECT, token4, "Fourth token should be END_OBJECT");
    }

    @Test
    @DisplayName("TC48: nextToken() correctly parses binary values encoded in base64")
    public void TC48_nextToken_parsesBinaryBase64Values() throws Exception {
        // Arrange
        String base64String = "SGVsbG8="; // "Hello" in base64
        String json = "{\"data\": \"" + base64String + "\"}";
        ReaderBasedJsonParser parser = createParser(json);

        // Act
        JsonToken token1 = parser.nextToken(); // START_OBJECT
        JsonToken token2 = parser.nextToken(); // FIELD_NAME
        JsonToken token3 = parser.nextToken(); // VALUE_STRING (binary)
        byte[] binaryData = parser.getBinaryValue();

        JsonToken token4 = parser.nextToken(); // END_OBJECT

        // Assert
        assertEquals(JsonToken.START_OBJECT, token1, "First token should be START_OBJECT");
        assertEquals(JsonToken.FIELD_NAME, token2, "Second token should be FIELD_NAME");
        assertEquals("data", parser.getCurrentName(), "Field name should be 'data'");
        assertEquals(JsonToken.VALUE_STRING, token3, "Third token should be VALUE_STRING for binary data");
        assertArrayEquals("Hello".getBytes(), binaryData, "Binary data should decode to 'Hello'");
        assertEquals(JsonToken.END_OBJECT, token4, "Fourth token should be END_OBJECT");
    }

    @Test
    @DisplayName("TC49: nextToken() handles tokens that span across buffer boundaries correctly")
    public void TC49_nextToken_handlesTokensAcrossBufferBoundaries() throws Exception {
        // Arrange
        // Simulate a long string that spans buffer boundaries by repeating a character multiple times
        StringBuilder longStringBuilder = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            longStringBuilder.append('a');
        }
        String longString = longStringBuilder.toString();
        String json = "{\"longString\": \"" + longString + "\"}";
        ReaderBasedJsonParser parser = createParser(json);

        // Act
        JsonToken token1 = parser.nextToken(); // START_OBJECT
        JsonToken token2 = parser.nextToken(); // FIELD_NAME
        JsonToken token3 = parser.nextToken(); // VALUE_STRING
        JsonToken token4 = parser.nextToken(); // END_OBJECT

        // Assert
        assertEquals(JsonToken.START_OBJECT, token1, "First token should be START_OBJECT");
        assertEquals(JsonToken.FIELD_NAME, token2, "Second token should be FIELD_NAME");
        assertEquals("longString", parser.getCurrentName(), "Field name should be 'longString'");
        assertEquals(JsonToken.VALUE_STRING, token3, "Third token should be VALUE_STRING");
        assertEquals(longString, parser.getText(), "Parsed long string should match the input");
        assertEquals(JsonToken.END_OBJECT, token4, "Fourth token should be END_OBJECT");
    }

    @Test
    @DisplayName("TC50: nextToken() throws exception when unexpected characters follow a field value")
    public void TC50_nextToken_throwsExceptionOnUnexpectedCharacter() throws Exception {
        // Arrange
        String json = "{\"key\": \"value\"@}";
        ReaderBasedJsonParser parser = createParser(json);

        // Act & Assert
        parser.nextToken(); // START_OBJECT
        parser.nextToken(); // FIELD_NAME
        parser.nextToken(); // VALUE_STRING
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken(); // Unexpected '@'
        }, "Expected JsonParseException due to unexpected character");
        assertTrue(exception.getMessage().contains("expected a value"), "Exception message should indicate expected a value");
    }

    // Helper method to create ReaderBasedJsonParser without comments
    private ReaderBasedJsonParser createParser(String json) throws Exception {
        // Use reflection to access the constructor
        Constructor<ReaderBasedJsonParser> constructor = ReaderBasedJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, Reader.class, ObjectCodec.class, CharsToNameCanonicalizer.class);
        constructor.setAccessible(true);

        IOContext context = new IOContext(null, null, false);
        ObjectCodec codec = null;
        CharsToNameCanonicalizer canonicalizer = CharsToNameCanonicalizer.createRoot();
        Reader reader = new StringReader(json);

        return constructor.newInstance(context, 0, reader, codec, canonicalizer);
    }

    // Helper method to create ReaderBasedJsonParser with comments enabled
    private ReaderBasedJsonParser createParserWithComments(String json) throws Exception {
        // Use reflection to access the constructor
        Constructor<ReaderBasedJsonParser> constructor = ReaderBasedJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, Reader.class, ObjectCodec.class, CharsToNameCanonicalizer.class);
        constructor.setAccessible(true);

        IOContext context = new IOContext(null, null, false);
        ObjectCodec codec = null;
        CharsToNameCanonicalizer canonicalizer = CharsToNameCanonicalizer.createRoot();
        Reader reader = new StringReader(json);

        // Enable comments feature by setting feature flags (assuming FEAT_MASK_ALLOW_COMMENTS = 0x1)
        int features = 0x1; // Example feature flag for allowing comments

        return constructor.newInstance(context, features, reader, codec, canonicalizer);
    }
}
