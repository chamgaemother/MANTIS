// package org.apache.commons.compress.archivers.sevenz;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
// import org.apache.commons.compress.archivers.sevenz.SevenZMethod;
// import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration;
// import java.util.Arrays;
// 
// public class SevenZArchiveEntry_equals_1_6_Test {
// 
//     @Test
//     @DisplayName("equals(obj) returns false when contentMethods lists have different elements")
//     void TC26_equals_different_contentMethods_elements_returns_false() {
//         // GIVEN
//         SevenZMethodConfiguration method1 = new SevenZMethodConfiguration(SevenZMethod.LZMA2, 1, null);
//         SevenZMethodConfiguration method2 = new SevenZMethodConfiguration(SevenZMethod.DEFLATE, 2, null);
//         SevenZArchiveEntry entry3 = new SevenZArchiveEntry();
//         entry3.setContentMethods(Arrays.asList(method1, method2));
//         SevenZArchiveEntry entry4 = new SevenZArchiveEntry();
//         entry4.setContentMethods(Arrays.asList(method2, method1));
// 
//         // WHEN
//         boolean result1 = entry3.equals(entry4);
// 
//         // THEN
//         assertFalse(result1);
//     }
// 
//     @Test
//     @DisplayName("equals(obj) handles one contentMethods list longer than the other")
//     void TC27_equals_contentMethods_one_longer_returns_false() {
//         // GIVEN
//         SevenZMethodConfiguration method1 = new SevenZMethodConfiguration(SevenZMethod.LZMA2, 1, null);
//         SevenZMethodConfiguration method2 = new SevenZMethodConfiguration(SevenZMethod.DEFLATE, 2, null);
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         entry1.setContentMethods(Arrays.asList(method1, method2));
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         entry2.setContentMethods(Arrays.asList(method1, method2, method1));
// 
//         // WHEN
//         boolean result = entry1.equals(entry2);
// 
//         // THEN
//         assertFalse(result);
//     }
// 
//     @Test
//     @DisplayName("equals(obj) returns true when contentMethods lists are identical")
//     void TC28_equals_identical_contentMethods_returns_true() {
//         // GIVEN
//         SevenZMethodConfiguration method = new SevenZMethodConfiguration(SevenZMethod.LZMA2, 1, null);
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         entry1.setContentMethods(Arrays.asList(method));
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         entry2.setContentMethods(Arrays.asList(method));
// 
//         // WHEN
//         boolean result = entry1.equals(entry2);
// 
//         // THEN
//         assertTrue(result);
//     }
// 
//     @Test
//     @DisplayName("equals(obj) returns false when name is null in one entry")
//     void TC29_equals_one_name_null_returns_false() {
//         // GIVEN
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         entry1.setName(null);
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         entry2.setName("file.txt");
// 
//         // WHEN
//         boolean result = entry1.equals(entry2);
// 
//         // THEN
//         assertFalse(result);
//     }
// 
//     @Test
//     @DisplayName("equals(obj) returns true when both names are null")
//     void TC30_equals_both_names_null_returns_true() {
//         // GIVEN
//         SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
//         entry1.setName(null);
//         SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
//         entry2.setName(null);
// 
//         // WHEN
//         boolean result = entry1.equals(entry2);
// 
//         // THEN
//         assertTrue(result);
//     }
// }