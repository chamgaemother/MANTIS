package org.jsoup.nodes;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jsoup.Connection;
import org.jsoup.helper.HttpConnection;
import org.jsoup.parser.Tag;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FormElement_formData_1_1_Test {

    @Test
    @DisplayName("formData processes select element with no options, ensuring no KeyVal is added")
    public void TC16_formDataProcessesSelectWithNoOptions() throws Exception {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element select = new Element(Tag.valueOf("select"), "").attr("name", "emptySelect");
        form.addElement(select);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertTrue(data.isEmpty(), "Expected the data list to be empty when no options are present in the select element.");
    }

    @Test
    @DisplayName("formData processes linked elements, ensuring linked submittable elements are included")
    public void TC17_formDataIncludesLinkedElsSubmittableElements() throws Exception {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element input = new Element(Tag.valueOf("input"), "")
                        .attr("type", "text")
                        .attr("name", "username")
                        .attr("value", "alice");
        form.addElement(input);
        Element linkedInput = new Element(Tag.valueOf("input"), "")
                            .attr("type", "hidden")
                            .attr("name", "token")
                            .attr("value", "abc123");
        form.addElement(linkedInput); // Add to linkedEls

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(2, data.size(), "Expected two KeyVal entries from both DOM and linkedEls.");
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("username") && kv.value().equals("alice")), "Expected KeyVal for username=alice.");
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("token") && kv.value().equals("abc123")), "Expected KeyVal for token=abc123.");
    }

    @Test
    @DisplayName("formData processes select element with multiple selected options")
    public void TC18_formDataProcessesSelectWithMultipleSelectedOptions() throws Exception {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element select = new Element(Tag.valueOf("select"), "")
                          .attr("name", "colors");
        Element option1 = new Element(Tag.valueOf("option"), "")
                          .attr("value", "red")
                          .attr("selected", "selected");
        Element option2 = new Element(Tag.valueOf("option"), "")
                          .attr("value", "green")
                          .attr("selected", "selected");
        Element option3 = new Element(Tag.valueOf("option"), "")
                          .attr("value", "blue");
        select.appendChild(option1).appendChild(option2).appendChild(option3);
        form.addElement(select);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(2, data.size(), "Expected two KeyVal entries for selected colors.");
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("colors") && kv.value().equals("red")), "Expected KeyVal for colors=red.");
        assertTrue(data.stream().anyMatch(kv -> kv.key().equals("colors") && kv.value().equals("green")), "Expected KeyVal for colors=green.");
    }

    @Test
    @DisplayName("formData processes elements with empty value attributes, ensuring empty strings are captured")
    public void TC19_formDataProcessesInputWithEmptyValue() throws Exception {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        Element input = new Element(Tag.valueOf("input"), "")
                        .attr("type", "text")
                        .attr("name", "emptyField")
                        .attr("value", "");
        form.addElement(input);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(1, data.size(), "Expected one KeyVal entry for the empty field.");
        assertEquals("emptyField", data.get(0).key(), "Expected the key to be 'emptyField'.");
        assertEquals("", data.get(0).value(), "Expected the value to be an empty string.");
    }

    @Test
    @DisplayName("formData handles form with multiple linkedEls elements, some disabled and some active")
    public void TC20_formDataIncludesActiveLinkedElsAndExcludesDisabledOnes() throws Exception {
        // Arrange
        Tag formTag = Tag.valueOf("form");
        FormElement form = new FormElement(formTag, "", null);
        // Active linked element
        Element activeInput = new Element(Tag.valueOf("input"), "")
                              .attr("type", "text")
                              .attr("name", "activeField")
                              .attr("value", "activeValue");
        form.addElement(activeInput);
        // Disabled linked element
        Element disabledInput = new Element(Tag.valueOf("input"), "")
                                .attr("type", "text")
                                .attr("name", "disabledField")
                                .attr("value", "shouldSkip")
                                .attr("disabled", "disabled");
        form.addElement(disabledInput);

        // Act
        List<Connection.KeyVal> data = form.formData();

        // Assert
        assertEquals(1, data.size(), "Expected only one KeyVal entry from active linkedEls.");
        assertEquals("activeField", data.get(0).key(), "Expected the key to be 'activeField'.");
        assertEquals("activeValue", data.get(0).value(), "Expected the value to be 'activeValue'.");
    }
}