package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

public class Flat3Map_remove_0_1_Test {

    @Test
    @DisplayName("Remove key when delegateMap is present and delegates removal")
    void TC01_removeDelegatesToDelegateMap() throws Exception {
        // Initialize Flat3Map
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Mock delegateMap
        AbstractHashedMap<Object, Object> mockDelegateMap = mock(AbstractHashedMap.class);
        Object key = "existingKey";
        Object expectedValue = "expectedValue";
        when(mockDelegateMap.remove(key)).thenReturn(expectedValue);

        // Use reflection to set delegateMap
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, mockDelegateMap);

        // Invoke remove
        Object result = map.remove(key);

        // Verify delegateMap.remove was called
        verify(mockDelegateMap).remove(key);

        // Assert the result
        assertEquals(expectedValue, result);
    }

    @Test
    @DisplayName("Remove key when delegateMap is null and size is zero")
    void TC02_removeFromEmptyFlat3Map() throws Exception {
        // Initialize Flat3Map
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Ensure delegateMap is null and size is zero using reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        // Invoke remove
        Object result = map.remove(null);

        // Assert the result
        assertNull(result);
    }

    @Test
    @DisplayName("Remove null key when size is one and key1 is null")
    void TC03_removeNullKeyWhenSizeOne() throws Exception {
        // Initialize Flat3Map
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object expectedValue1 = "value1";
        value1Field.set(map, expectedValue1);

        // Invoke remove
        Object result = map.remove(null);

        // Assert the result and state
        assertEquals(expectedValue1, result);
        assertNull(key1Field.get(map));
        assertEquals(0, sizeField.getInt(map));
    }

    @Test
    @DisplayName("Attempt to remove null key when size is one but key1 is not null")
    void TC04_removeNullKeyWhenSizeOneKey1NotNull() throws Exception {
        // Initialize Flat3Map
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object nonNullKey = "nonNullKey";
        key1Field.set(map, nonNullKey);

        // Invoke remove
        Object result = map.remove(null);

        // Assert the result and state
        assertNull(result);
        assertEquals(1, sizeField.getInt(map));
    }

    @Test
    @DisplayName("Remove null key when size is two and key2 is null")
    void TC05_removeNullKeyWhenSizeTwoKey2Null() throws Exception {
        // Initialize Flat3Map
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object expectedValue2 = "value2";
        value2Field.set(map, expectedValue2);

        // Invoke remove
        Object result = map.remove(null);

        // Assert the result and state
        assertEquals(expectedValue2, result);
        assertNull(key2Field.get(map));
        assertEquals(1, sizeField.getInt(map));
    }
}