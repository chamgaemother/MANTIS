package org.jfree.data.time;

import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.time.RegularTimePeriod;
import org.junit.jupiter.api.Test;

public class MovingAverageTest {

    @Test
    void testCreateMovingAverage_NullSource_ShouldThrowException() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            MovingAverage.createMovingAverage(null, "MA", 3, 0);
        });
        assertEquals("Null 'source' argument.", exception.getMessage());
    }

    @Test
    void testCreateMovingAverage_InvalidPeriodCount_ShouldThrowException() {
        TimeSeries source = new TimeSeries("Source");
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            MovingAverage.createMovingAverage(source, "MA", 0, 0);
        });
        assertEquals("periodCount must be greater than or equal to 1.", exception.getMessage());
    }
    
    @Test
    void testCreateMovingAverage_EmptySource_ShouldReturnEmptySeries() {
        TimeSeries source = new TimeSeries("Source");
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 3, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertTrue(result.isEmpty());
    }

    @Test
    void testCreateMovingAverage_SingleItem_ShouldReturnEmptyOrSingleMA() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 10.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 3, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertTrue(result.isEmpty());
    }

    @Test
    void testCreateMovingAverage_ValidInput_NoSkip() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 10.0);
        source.add(new Day(2, 1, 2020), 20.0);
        source.add(new Day(3, 1, 2020), 30.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 2, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertEquals(2, result.getItemCount());
        assertEquals(15.0, result.getValue(new Day(2, 1, 2020)));
        assertEquals(25.0, result.getValue(new Day(3, 1, 2020)));
    }

    @Test
    void testCreateMovingAverage_ValidInput_WithSkip() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 10.0);
        source.add(new Day(2, 1, 2020), 20.0);
        source.add(new Day(3, 1, 2020), 30.0);
        source.add(new Day(4, 1, 2020), 40.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 2, 1);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertEquals(2, result.getItemCount());
        assertEquals(25.0, result.getValue(new Day(3, 1, 2020)));
        assertEquals(35.0, result.getValue(new Day(4, 1, 2020)));
    }

    @Test
    void testCreateMovingAverage_PeriodCountGreaterThanItems() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 10.0);
        source.add(new Day(2, 1, 2020), 20.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 5, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertEquals(2, result.getItemCount());
        assertEquals(10.0, result.getValue(new Day(1, 1, 2020)));
        assertEquals(15.0, result.getValue(new Day(2, 1, 2020)));
    }

    @Test
    void testCreateMovingAverage_WithNullValues() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 10.0);
        source.add(new Day(2, 1, 2020), null);
        source.add(new Day(3, 1, 2020), 30.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 2, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertEquals(2, result.getItemCount());
        assertEquals(10.0, result.getValue(new Day(2, 1, 2020)));
        assertEquals(30.0, result.getValue(new Day(3, 1, 2020)));
    }

    @Test
    void testCreateMovingAverage_AllValuesNull() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), null);
        source.add(new Day(2, 1, 2020), null);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 2, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertEquals(0, result.getItemCount());
    }

    @Test
    void testCreateMovingAverage_SkipExceedsSeries() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 10.0);
        source.add(new Day(2, 1, 2020), 20.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 2, 3);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertTrue(result.isEmpty());
    }

    @Test
    void testCreateMovingAverage_PeriodCountOne() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 5.0);
        source.add(new Day(2, 1, 2020), 15.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 1, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertEquals(2, result.getItemCount());
        assertEquals(5.0, result.getValue(new Day(1, 1, 2020)));
        assertEquals(15.0, result.getValue(new Day(2, 1, 2020)));
    }

    @Test
    void testCreateMovingAverage_SkipZero_PeriodCountValid() {
        TimeSeries source = new TimeSeries("Source");
        source.add(new Day(1, 1, 2020), 10.0);
        source.add(new Day(2, 1, 2020), 20.0);
        source.add(new Day(3, 1, 2020), 30.0);
        source.add(new Day(4, 1, 2020), 40.0);
        TimeSeries result = MovingAverage.createMovingAverage(source, "MA", 3, 0);
        assertNotNull(result);
        assertEquals("SourceMA", result.getKey());
        assertEquals(2, result.getItemCount());
        assertEquals(20.0, result.getValue(new Day(3, 1, 2020)));
        assertEquals(30.0, result.getValue(new Day(4, 1, 2020)));
    }

}