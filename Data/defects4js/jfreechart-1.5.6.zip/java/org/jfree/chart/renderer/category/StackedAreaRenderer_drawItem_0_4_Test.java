package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.StackedAreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.GeneralPath;

import static org.mockito.Mockito.*;

public class StackedAreaRenderer_drawItem_0_4_Test {

    @Test
    @DisplayName("Draw item with pass value beyond expected range")
    public void TC16() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);

        int row = 0;
        int column = 1;
        int pass = 2; // Invalid pass value

        StackedAreaRenderer renderer = spy(new StackedAreaRenderer());
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        renderer.setRenderAsPercentages(false);

        when(dataset.getValue(row, column)).thenReturn(50);
        when(dataset.getValue(row, column - 1)).thenReturn(30);
        when(dataset.getValue(row, anyInt())).thenReturn(20);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        verify(g2, never()).fill(any(GeneralPath.class));
    }

    @Test
    @DisplayName("Draw item at maximum column index")
    public void TC17() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);

        int row = 0;
        int maxColumn = 4;
        int pass = 0;

        StackedAreaRenderer renderer = spy(new StackedAreaRenderer());
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        renderer.setRenderAsPercentages(false);

        when(dataset.getColumnCount()).thenReturn(5);
        when(dataset.getValue(row, maxColumn)).thenReturn(50);
        when(dataset.getValue(row, maxColumn - 1)).thenReturn(30);
        when(dataset.getValue(row, anyInt())).thenReturn(20);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, maxColumn, pass);

        verify(g2, atLeastOnce()).fill(any(GeneralPath.class));
    }

    @Test
    @DisplayName("Draw item at minimum column index")
    public void TC18() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);

        int row = 0;
        int minColumn = 0;
        int pass = 0;

        StackedAreaRenderer renderer = spy(new StackedAreaRenderer());
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        renderer.setRenderAsPercentages(false);

        when(dataset.getValue(row, minColumn)).thenReturn(50);
        when(dataset.getValue(row, Math.max(minColumn - 1, 0))).thenReturn(null);
        when(dataset.getValue(row, minColumn + 1)).thenReturn(20);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, minColumn, pass);

        verify(g2, atLeastOnce()).fill(any(GeneralPath.class));
    }

    @Test
    @DisplayName("Draw item with renderAsPercentages enabled and total column value is zero")
    public void TC19() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);

        int row = 0;
        int column = 1;
        int pass = 0;

        StackedAreaRenderer renderer = spy(new StackedAreaRenderer());
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        renderer.setRenderAsPercentages(true);

        when(dataset.getValue(row, column)).thenReturn(0);
        when(dataset.getValue(row, column - 1)).thenReturn(0);
        when(dataset.getValue(row, column + 1)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        verify(g2, never()).fill(any(GeneralPath.class));
    }

    @Test
    @DisplayName("Draw item with dataset.getValue(row, column) returning NaN")
    public void TC20() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);

        int row = 0;
        int column = 1;
        int pass = 0;

        StackedAreaRenderer renderer = spy(new StackedAreaRenderer());
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        renderer.setRenderAsPercentages(false);

        when(dataset.getValue(row, column)).thenReturn(Double.NaN);
        when(dataset.getValue(row, column - 1)).thenReturn(30);
        when(dataset.getValue(row, column + 1)).thenReturn(20);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        verify(g2, atLeastOnce()).fill(any(GeneralPath.class));
    }

}