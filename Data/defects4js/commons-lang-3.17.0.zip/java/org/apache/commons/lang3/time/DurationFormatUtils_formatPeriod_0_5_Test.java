package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.util.TimeZone;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DurationFormatUtils_formatPeriod_0_5_Test {

    @Test
    @DisplayName("Duration with invalid format leading to IllegalArgumentException")
    void TC21_formatPeriod_withInvalidFormat_throwsIllegalArgumentException() {
        // Arrange
        long startMillis = 1609459200000L;
        long endMillis = 1609462800000L;
        String format = "invalid_format";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        });
        
        assertTrue(exception.getMessage().contains("Invalid format"));
    }

    @Test
    @DisplayName("Duration with null timezone, expecting default GMT behavior")
    void TC22_formatPeriod_withNullTimezone_returnsFormattedStringUsingGMT() throws Exception {
        // Arrange
        long startMillis = 1609459200000L;
        long endMillis = 1609462800000L;
        String format = "H:m:s";
        boolean padWithZeros = true;
        TimeZone timezone = null;
        
        // Act
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // Assert
        assertEquals("1:0:0", result);
    }

    @Test
    @DisplayName("Duration with maximum long values, testing boundary limits")
    void TC23_formatPeriod_withMaximumLongValues_handlesWithoutOverflow() throws Exception {
        // Arrange
        long startMillis = 0L;
        long endMillis = Long.MAX_VALUE;
        String format = "y:M:d:H:m:s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // Act
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // Assert
        assertNotNull(result);
        assertFalse(result.isEmpty());
    }

    @Test
    @DisplayName("Duration with zero duration and specific format tokens")
    void TC24_formatPeriod_withZeroDurationAndSpecificTokens_returnsFormattedZeros() throws Exception {
        // Arrange
        long startMillis = 1609459200000L;
        long endMillis = 1609459200000L;
        String format = "H:m";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // Act
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // Assert
        assertEquals("0:0", result);
    }

    @Test
    @DisplayName("Duration with only 'y' token, ensuring years are calculated correctly")
    void TC25_formatPeriod_withOnlyYToken_returnsCorrectYears() throws Exception {
        // Arrange
        long startMillis = 1577836800000L; // Jan 1, 2020
        long endMillis = 1609459200000L;   // Jan 1, 2021
        String format = "y";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        
        // Act
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        
        // Assert
        assertEquals("1", result);
    }
}