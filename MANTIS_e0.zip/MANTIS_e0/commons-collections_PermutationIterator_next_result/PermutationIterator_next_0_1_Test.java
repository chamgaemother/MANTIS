package org.apache.commons.collections4.iterators;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

public class PermutationIterator_next_0_1_Test {

    @Test
    void testSingleElementPermutation() {
        PermutationIterator<String> iterator = new PermutationIterator<>(List.of("A"));
        assertTrue(iterator.hasNext(), "Iterator should have next permutation");
        assertEquals(Arrays.asList("A"), iterator.next(), "Single element permutation should return the element itself.");
        assertFalse(iterator.hasNext(), "Iterator should have no more permutations");
    }

    @Test
    void testMultipleElementsPermutation() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(List.of(1, 2));
        assertTrue(iterator.hasNext(), "Iterator should have next permutation");
        assertEquals(Arrays.asList(1, 2), iterator.next(), "First permutation should be [1, 2]");
        assertTrue(iterator.hasNext(), "Iterator should have another permutation");
        assertEquals(Arrays.asList(2, 1), iterator.next(), "Second permutation should be [2, 1]");
        assertFalse(iterator.hasNext(), "Iterator should have no more permutations");
    }

    @Test
    void testEmptyCollectionPermutation() {
        PermutationIterator<Object> iterator = new PermutationIterator<>(List.of());
        assertTrue(iterator.hasNext(), "Iterator should have one empty permutation");
        assertEquals(List.of(), iterator.next(), "Only permutation of an empty collection should be an empty list");
        assertFalse(iterator.hasNext(), "Iterator should have no more permutations");
    }

    @Test
    void testNoSuchElementException() {
        PermutationIterator<Integer> iterator = new PermutationIterator<>(List.of(1));
        iterator.next();
        assertThrows(NoSuchElementException.class, iterator::next, "Calling next() without next permutation should throw NoSuchElementException");
    }
}