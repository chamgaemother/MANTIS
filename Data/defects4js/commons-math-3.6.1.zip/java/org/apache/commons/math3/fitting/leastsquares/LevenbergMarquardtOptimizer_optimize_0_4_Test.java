package org.apache.commons.math3.fitting.leastsquares;

import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.optim.ConvergenceChecker;
import org.apache.commons.math3.optim.OptimizationData;
import org.apache.commons.math3.util.Incrementor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LevenbergMarquardtOptimizer_optimize_0_4_Test {

//    @Test
//    @DisplayName("Optimize terminates when delta falls below parameter relative tolerance")
//    void TC16_optimizeTerminatesDeltaBelowTolerance() throws Exception {
//        // Arrange
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = createProblemWithDeltaBelowTolerance();
//
//        // Act
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        // Assert
//        assertNotNull(result, "OptimumImpl should not be null");
//    }
//
//    @Test
//    @DisplayName("Optimize handles maximum number of iterations without convergence")
//    void TC17_optimizeHandlesMaxIterations() throws Exception {
//        // Arrange
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = createProblemExceedingIterationLimit();
//
//        // Act & Assert
//        assertThrows(ConvergenceException.class, () -> {
//            optimizer.optimize(problem);
//        }, "ConvergenceException should be thrown after exceeding maximum iterations");
//    }
//
//    @Test
//    @DisplayName("Optimize with iterative updates correctly modify currentPoint")
//    void TC18_optimizeIterativeUpdates() throws Exception {
//        // Arrange
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = createProblemRequiringUpdates();
//
//        // Act
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        // Assert
//        assertNotNull(result, "OptimumImpl should not be null");
//
//        // Assuming expectedPoint is the expected RealVector after updates
//        RealVector expectedPoint = createExpectedPointAfterUpdates();
//        assertArrayEquals(expectedPoint.toArray(), result.getPoint().toArray(), "currentPoint should be updated correctly in each iteration");
//    }
//
//    @Test
//    @DisplayName("Optimize with heuristic adjustments correctly scale parameters based on jacNorm")
//    void TC19_optimizeParameterScaling() throws Exception {
//        // Arrange
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = createProblemRequiringScaling();
//
//        // Act
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        // Assert
//        assertNotNull(result, "OptimumImpl should not be null");
//    }
//
//    @Test
//    @DisplayName("Optimize correctly handles iterations where ratio of actual to predicted reduction is below threshold")
//    void TC20_optimizeReductionRatioBelowThreshold() throws Exception {
//        // Arrange
//        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
//        LeastSquaresProblem problem = createProblemWithLowReductionRatio();
//
//        // Act
//        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
//
//        // Assert
//        assertNotNull(result, "OptimumImpl should not be null");
//    }

    // Helper methods to create LeastSquaresProblem instances for each test scenario
//
//    private LeastSquaresProblem createProblemWithDeltaBelowTolerance() {
//        return new LeastSquaresProblem() {
//            @Override
//            public int getObservationSize() {
//                return 1;
//            }
//
//            @Override
//            public int getParameterSize() {
//                return 1;
//            }
//
//            @Override
//            public RealVector getStart() {
//                return new ArrayRealVector(new double[]{0.0});
//            }
//
//            @Override
//            public LeastSquaresFunction getFunction() {
//                return point -> new ArrayRealVector(new double[]{0.0});
//            }
//
//            @Override
//            public ConvergenceChecker<LeastSquaresOptimizer.Optimum> getConvergenceChecker() {
//                return (iteration, previous, current) -> true;
//            }
//
//            @Override
//            public Incrementor getIterationCounter() {
//                Incrementor iterationCounter = new Incrementor();
//                iterationCounter.setMaximalCount(Integer.MAX_VALUE); // To prevent infinite loop issues
//                return iterationCounter;
//            }
//
//            @Override
//            public Incrementor getEvaluationCounter() {
//                return new Incrementor();
//            }
//        };
//    }
//
//    private LeastSquaresProblem createProblemExceedingIterationLimit() {
//        return new LeastSquaresProblem() {
//            @Override
//            public int getObservationSize() { return 1; }
//            @Override
//            public int getParameterSize() { return 1; }
//
//            @Override
//            public RealVector getStart() {
//                return new ArrayRealVector(new double[]{10.0});
//            }
//
//            @Override
//            public LeastSquaresFunction getFunction() {
//                return point -> new ArrayRealVector(new double[]{point.getEntry(0)});
//            }
//
//            @Override
//            public ConvergenceChecker<LeastSquaresOptimizer.Optimum> getConvergenceChecker() {
//                return (iteration, previous, current) -> false;
//            }
//
//            @Override
//            public Incrementor getIterationCounter() {
//                Incrementor iterationCounter = new Incrementor();
//                iterationCounter.setMaximalCount(1); // Set a limit to ensure the convergence exception
//                return iterationCounter;
//            }
//
//            @Override
//            public Incrementor getEvaluationCounter() {
//                return new Incrementor();
//            }
//        };
//    }
//
//    private LeastSquaresProblem createProblemRequiringUpdates() {
//        return new LeastSquaresProblem() {
//            @Override
//            public int getObservationSize() { return 2; }
//            @Override
//            public int getParameterSize() { return 2; }
//
//            @Override
//            public RealVector getStart() {
//                return new ArrayRealVector(new double[]{1.0, 1.0});
//            }
//
//            @Override
//            public LeastSquaresFunction getFunction() {
//                return point -> {
//                    double x = point.getEntry(0);
//                    double y = point.getEntry(1);
//                    return new ArrayRealVector(new double[]{x - 2, y - 3});
//                };
//            }
//
//            @Override
//            public ConvergenceChecker<LeastSquaresOptimizer.Optimum> getConvergenceChecker() {
//                return (iteration, previous, current) -> iteration.getCount() >= 2;
//            }
//
//            @Override
//            public Incrementor getIterationCounter() {
//                return new Incrementor();
//            }
//
//            @Override
//            public Incrementor getEvaluationCounter() {
//                return new Incrementor();
//            }
//        };
//    }
//
//    private LeastSquaresProblem createProblemRequiringScaling() {
//        return new LeastSquaresProblem() {
//            @Override
//            public int getObservationSize() { return 2; }
//            @Override
//            public int getParameterSize() { return 2; }
//
//            @Override
//            public RealVector getStart() {
//                return new ArrayRealVector(new double[]{100.0, 200.0});
//            }
//
//            @Override
//            public LeastSquaresFunction getFunction() {
//                return point -> {
//                    double x = point.getEntry(0);
//                    double y = point.getEntry(1);
//                    return new ArrayRealVector(new double[]{x / 100, y / 200});
//                };
//            }
//
//            @Override
//            public ConvergenceChecker<LeastSquaresOptimizer.Optimum> getConvergenceChecker() {
//                return (iteration, previous, current) -> true;
//            }
//
//            @Override
//            public Incrementor getIterationCounter() {
//                return new Incrementor();
//            }
//
//            @Override
//            public Incrementor getEvaluationCounter() {
//                return new Incrementor();
//            }
//        };
//    }
//
//    private LeastSquaresProblem createProblemWithLowReductionRatio() {
//        return new LeastSquaresProblem() {
//            @Override
//            public int getObservationSize() { return 1; }
//            @Override
//            public int getParameterSize() { return 1; }
//
//            @Override
//            public RealVector getStart() {
//                return new ArrayRealVector(new double[]{5.0});
//            }
//
//            @Override
//            public LeastSquaresFunction getFunction() {
//                return point -> new ArrayRealVector(new double[]{point.getEntry(0) * 10});
//            }
//
//            @Override
//            public ConvergenceChecker<LeastSquaresOptimizer.Optimum> getConvergenceChecker() {
//                return (iteration, previous, current) -> false;
//            }
//
//            @Override
//            public Incrementor getIterationCounter() {
//                return new Incrementor();
//            }
//
//            @Override
//            public Incrementor getEvaluationCounter() {
//                return new Incrementor();
//            }
//        };
//    }

    private RealVector createExpectedPointAfterUpdates() {
        return new ArrayRealVector(new double[]{2.0, 3.0});
    }
}
