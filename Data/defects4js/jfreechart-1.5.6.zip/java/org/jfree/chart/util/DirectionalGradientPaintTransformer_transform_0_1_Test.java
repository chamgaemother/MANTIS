package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.util.DirectionalGradientPaintTransformer;

public class DirectionalGradientPaintTransformer_transform_0_1_Test {

    @Test
    @DisplayName("Transform with start point (0,0), end point non-zero/non-zero, isCyclic=false for diagonal gradient")
    public void TC01() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 10, 10, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(0, 0, 10, 10);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(new Point2D.Float(0f, 0f), result.getPoint1(), "Point1 should be (bx, by)");
        assertEquals(new Point2D.Float(10f, 10f), result.getPoint2(), "Point2 should be (bx + (bw + bh)/2, by + (bw + bh)/2)");
        assertFalse(result.isCyclic(), "GradientPaint should not be cyclic");
    }

    @Test
    @DisplayName("Transform with start point (0,0), end point non-zero/non-zero, isCyclic=true for diagonal gradient")
    public void TC02() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 10, 10, Color.BLUE, true);
        Shape target = new Rectangle2D.Float(0, 0, 10, 10);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(new Point2D.Float(0f, 0f), result.getPoint1(), "Point1 should be (bx, by)");
        assertEquals(new Point2D.Float(5f, 5f), result.getPoint2(), "Point2 should be (bx + (bw + bh)/4, by + (bw + bh)/4)");
        assertTrue(result.isCyclic(), "GradientPaint should be cyclic");
    }

    @Test
    @DisplayName("Transform with start point (0,0), end point (bw,0), isCyclic=false for horizontal gradient")
    public void TC03() {
        float bx = 0f;
        float by = 0f;
        float bw = 10f;
        float bh = 10f;
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, bw, 0, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 should be (bx, by)");
        assertEquals(new Point2D.Float(bx + bw, by), result.getPoint2(), "Point2 should be (bx + bw, by)");
        assertFalse(result.isCyclic(), "GradientPaint should not be cyclic");
    }

    @Test
    @DisplayName("Transform with start point (0,0), end point (0,bh), isCyclic=false for vertical gradient")
    public void TC04() {
        float bx = 0f;
        float by = 0f;
        float bw = 10f;
        float bh = 10f;
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 0, bh, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 should be (bx, by)");
        assertEquals(new Point2D.Float(bx, by + bh), result.getPoint2(), "Point2 should be (bx, by + bh)");
        assertFalse(result.isCyclic(), "GradientPaint should not be cyclic");
    }

    @Test
    @DisplayName("Transform with start point (0,0), end point (bw,0), isCyclic=true for horizontal gradient with offset")
    public void TC05() {
        float bx = 0f;
        float by = 0f;
        float bw = 10f;
        float bh = 10f;
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, bw, 0, Color.BLUE, true);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);
        GradientPaint result = transformer.transform(paint, target);
        
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 should be (bx, by)");
        assertEquals(new Point2D.Float(bx + bw / 2, by), result.getPoint2(), "Point2 should be (bx + bw/2, by)");
        assertTrue(result.isCyclic(), "GradientPaint should be cyclic");
    }
}