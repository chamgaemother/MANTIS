package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

public class LineUtils_clipLine_0_2_Test {

    @Test
    @DisplayName("Clip horizontal line intersecting left and right sides of the rectangle")
    public void TC06_clipHorizontalIntersectingSides() {
        // Given
        Rectangle2D rect = new Rectangle2D.Double(1.0, 1.0, 9.0, 9.0);
        Line2D line = new Line2D.Double(0.0, 5.0, 11.0, 5.0);
        
        // When
        boolean result = LineUtils.clipLine(line, rect);
        
        // Then
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(1.0, line.getX1(), 0.0001, "Line x1 should be clipped to left boundary");
        assertEquals(5.0, line.getY1(), 0.0001, "Line y1 should remain same");
        assertEquals(10.0, line.getX2(), 0.0001, "Line x2 should be clipped to right boundary");
        assertEquals(5.0, line.getY2(), 0.0001, "Line y2 should remain same");
    }

    @Test
    @DisplayName("Clip vertical line intersecting top and bottom sides of the rectangle")
    public void TC07_clipVerticalIntersectingSides() {
        // Given
        Rectangle2D rect = new Rectangle2D.Double(1.0, 1.0, 9.0, 9.0);
        Line2D line = new Line2D.Double(5.0, 0.0, 5.0, 11.0);
        
        // When
        boolean result = LineUtils.clipLine(line, rect);
        
        // Then
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(5.0, line.getX1(), 0.0001, "Line x1 should remain same");
        assertEquals(1.0, line.getY1(), 0.0001, "Line y1 should be clipped to top boundary");
        assertEquals(5.0, line.getX2(), 0.0001, "Line x2 should remain same");
        assertEquals(10.0, line.getY2(), 0.0001, "Line y2 should be clipped to bottom boundary");
    }

    @Test
    @DisplayName("Clip line with one endpoint exactly on the left boundary of the rectangle")
    public void TC08_clipLineEndpointOnLeftBoundary() {
        // Given
        Rectangle2D rect = new Rectangle2D.Double(1.0, 1.0, 9.0, 9.0);
        Line2D line = new Line2D.Double(1.0, 5.0, 11.0, 5.0);
        
        // When
        boolean result = LineUtils.clipLine(line, rect);
        
        // Then
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(1.0, line.getX1(), 0.0001, "Line x1 should remain on left boundary");
        assertEquals(5.0, line.getY1(), 0.0001, "Line y1 should remain same");
        assertEquals(10.0, line.getX2(), 0.0001, "Line x2 should be clipped to right boundary");
        assertEquals(5.0, line.getY2(), 0.0001, "Line y2 should remain same");
    }

    @Test
    @DisplayName("Clip line with both endpoints on opposite boundaries of the rectangle")
    public void TC09_clipLineBothEndpointsOnOppositeBoundaries() {
        // Given
        Rectangle2D rect = new Rectangle2D.Double(1.0, 1.0, 9.0, 9.0);
        Line2D line = new Line2D.Double(1.0, 5.0, 10.0, 5.0);
        
        // When
        boolean result = LineUtils.clipLine(line, rect);
        
        // Then
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(1.0, line.getX1(), 0.0001, "Line x1 should remain on left boundary");
        assertEquals(5.0, line.getY1(), 0.0001, "Line y1 should remain same");
        assertEquals(10.0, line.getX2(), 0.0001, "Line x2 should remain on right boundary");
        assertEquals(5.0, line.getY2(), 0.0001, "Line y2 should remain same");
    }

    @Test
    @DisplayName("Clip line with one endpoint outside and parallel to the rectangle's top edge")
    public void TC10_clipLineParallelToTopEdgeWithOneEndpointOutside() {
        // Given
        Rectangle2D rect = new Rectangle2D.Double(1.0, 1.0, 9.0, 9.0);
        Line2D line = new Line2D.Double(5.0, 1.0, 15.0, 1.0); // parallel to top edge, one endpoint outside
        
        // When
        boolean result = LineUtils.clipLine(line, rect);
        
        // Then
        assertTrue(result, "Expected clipLine to return true");
        assertEquals(5.0, line.getX1(), 0.0001, "Line x1 should remain same");
        assertEquals(1.0, line.getY1(), 0.0001, "Line y1 should remain on top boundary");
        assertEquals(10.0, line.getX2(), 0.0001, "Line x2 should be clipped to right boundary");
        assertEquals(1.0, line.getY2(), 0.0001, "Line y2 should remain on top boundary");
    }
}