import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MetadataBandGroupTest {

    @Test
    public void testAddParameterAnnotationWithEmptyInputs() {
        CpBands cpBands = mock(CpBands.class);
        MetadataBandGroup group = new MetadataBandGroup("RVA", MetadataBandGroup.CONTEXT_CLASS, cpBands, mock(SegmentHeader.class), 1);

        group.addParameterAnnotation(0, new int[]{}, new IntList(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());

        assertFalse(group.hasContent());
    }

    @Test
    public void testAddParameterAnnotationWithValues() {
        CpBands cpBands = mock(CpBands.class);
        CPSignature cpSignature = mock(CPSignature.class);
        CPUTF8 cpUtf8 = mock(CPUTF8.class);
        CPConstant<?> cpConstant = mock(CPConstant.class);

        when(cpBands.getCPSignature(anyString())).thenReturn(cpSignature);
        when(cpBands.getCPUtf8(anyString())).thenReturn(cpUtf8);
        when(cpBands.getConstant(any())).thenReturn(cpConstant);

        MetadataBandGroup group = new MetadataBandGroup("RVA", MetadataBandGroup.CONTEXT_FIELD, cpBands, mock(SegmentHeader.class), 1);

        IntList pairN = new IntList();
        pairN.add(1);

        List<String> typeRS = List.of("type1");
        List<String> nameRU = List.of("name1");
        List<String> tags = List.of("B", "D", "F", "J", "c", "e", "s");
        List<Object> values = List.of(1, 2.0, 3.0f, 4L, "class", "enum", "string");
        List<Integer> caseArrayN = List.of(2);
        List<String> nestTypeRS = List.of("nestedType");
        List<String> nestNameRU = List.of("nestedName");
        List<Integer> nestPairN = List.of(1);

        group.addParameterAnnotation(1, new int[]{1}, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        assertTrue(group.hasContent());
    }

    @Test
    public void testAddParameterAnnotationWithNullValues() {
        CpBands cpBands = mock(CpBands.class);

        MetadataBandGroup group = new MetadataBandGroup("RVA", MetadataBandGroup.CONTEXT_METHOD, cpBands, mock(SegmentHeader.class), 1);

        assertThrows(NullPointerException.class, () -> {
            group.addParameterAnnotation(1, null, null, null, null, null, null, null, null, null);
        });
    }

    @ParameterizedTest
    @CsvSource({
            // numParams, typeRS.size()
            "1, 1",
            "2, 2"
    })
    public void testAddParameterAnnotationWithCsvInput(int numParams, int expectedSize) {
        CpBands cpBands = mock(CpBands.class);
        CPSignature cpSignature = mock(CPSignature.class);
        CPUTF8 cpUtf8 = mock(CPUTF8.class);
        CPConstant<?> cpConstant = mock(CPConstant.class);

        when(cpBands.getCPSignature(anyString())).thenReturn(cpSignature);
        when(cpBands.getCPUtf8(anyString())).thenReturn(cpUtf8);
        when(cpBands.getConstant(any())).thenReturn(cpConstant);

        MetadataBandGroup group = new MetadataBandGroup("RVA", MetadataBandGroup.CONTEXT_CLASS, cpBands, mock(SegmentHeader.class), 1);

        IntList pairN = new IntList();
        pairN.add(1);

        List<String> typeRS = List.of("type1", "type2").subList(0, expectedSize);
        List<String> nameRU = List.of("name1", "name2").subList(0, expectedSize);
        List<String> tags = List.of("B");
        List<Object> values = List.of(1);
        List<Integer> caseArrayN = List.of(2);
        List<String> nestTypeRS = List.of("nestedType");
        List<String> nestNameRU = List.of("nestedName");
        List<Integer> nestPairN = List.of(1);

        group.addParameterAnnotation(numParams, new int[]{1, 2}, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        assertTrue(group.hasContent());
    }
}