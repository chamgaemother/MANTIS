package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.text.TextUtils;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.chart.ui.TextAnchor;
import org.jfree.data.Range;
import org.jfree.data.general.DefaultValueDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Stroke;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class MeterPlot_draw_1_1_Test {

    @Test
    @DisplayName("Draw method with tickLabelsVisible set to false and data within range")
    public void TC19_draw_with_tickLabelsVisible_false_and_data_within_range() throws Exception {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        plot.setTickLabelsVisible(false);
        plot.setDataset(new DefaultValueDataset(75));
        plot.setRange(new Range(0, 100));

        // Mocking Graphics2D and related objects
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = null;
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that tick labels are not drawn
        verify(g2, never()).drawString(ArgumentMatchers.anyString(), ArgumentMatchers.anyFloat(), ArgumentMatchers.anyFloat());
        // Verify that needle is drawn (assuming fill is called at least once for the needle)
        verify(g2, atLeastOnce()).fill(ArgumentMatchers.any(Polygon.class));
    }

    @Test
    @DisplayName("Draw method with tickLabelsVisible set to false and multiple MeterIntervals")
    public void TC20_draw_with_tickLabelsVisible_false_and_multiple_MeterIntervals() throws Exception {
        // GIVEN
        MeterPlot plot = new MeterPlot();
        plot.setTickLabelsVisible(false);
        plot.setDataset(new DefaultValueDataset(75));
        plot.setRange(new Range(0, 100));
        plot.addInterval(new MeterInterval("Low", new Range(0, 50), Color.GREEN, new BasicStroke(1.0f), null));
        plot.addInterval(new MeterInterval("Medium", new Range(50, 80), Color.YELLOW, new BasicStroke(1.0f), null));
        plot.addInterval(new MeterInterval("High", new Range(80, 100), Color.RED, new BasicStroke(1.0f), null));

        // Mocking Graphics2D and related objects
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = null;
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // WHEN
        plot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that tick labels are not drawn
        verify(g2, never()).drawString(ArgumentMatchers.anyString(), ArgumentMatchers.anyFloat(), ArgumentMatchers.anyFloat());
        // Verify that each MeterInterval is drawn by checking setPaint is called three times
        verify(g2, times(3)).setPaint(ArgumentMatchers.any());
        // Verify that needle is drawn (assuming fill is called at least once for the needle)
        verify(g2, atLeastOnce()).fill(ArgumentMatchers.any(Polygon.class));
    }

}