import org.apache.commons.lang3.time.DurationFormatUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

class DurationFormatUtilsTest {

    @Test
    void testFormatPeriod_NormalCase() {
        long startMillis = 0L;
        long endMillis = 1000L;
        String format = "s's'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1s", result);
    }

    @Test
    void testFormatPeriod_StartMillisGreaterThanEndMillis() {
        long startMillis = 2000L;
        long endMillis = 1000L;
        String format = "s's'";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault()));
        assertEquals("startMillis must not be greater than endMillis", exception.getMessage());
    }

    @Test
    void testFormatPeriod_NullFormat() {
        long startMillis = 0L;
        long endMillis = 1000L;
        String format = null;

        NullPointerException exception = assertThrows(NullPointerException.class, () ->
                DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault()));
        assertEquals("The format must not be null", exception.getMessage());
    }

    @Test
    void testFormatPeriod_InvalidFormat_UnmatchedQuote() {
        long startMillis = 0L;
        long endMillis = 1000L;
        String format = "s's";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault()));
        assertTrue(exception.getMessage().contains("Unmatched quote in format"));
    }

    @Test
    void testFormatPeriod_InvalidFormat_NestedOptional() {
        long startMillis = 0L;
        long endMillis = 1000L;
        String format = "s'[s]'";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault()));
        assertTrue(exception.getMessage().contains("Nested optional block"));
    }

    @Test
    void testFormatPeriod_NullTimezone() {
        long startMillis = 0L;
        long endMillis = 1000L;
        String format = "s's'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, null);
        assertEquals("1s", result);
    }

    @Test
    void testFormatPeriod_ZeroDuration() {
        long startMillis = 1000L;
        long endMillis = 1000L;
        String format = "s's'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("0s", result);
    }

    @Test
    void testFormatPeriod_FormatWithOptionalBlocks_NonZeroFields() {
        long startMillis = 0L;
        long endMillis = 3661000L; // 1 hour, 1 minute, 1 second
        String format = "[H'H'm'm's's']";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1H1m1s", result);
    }

    @Test
    void testFormatPeriod_FormatWithOptionalBlocks_ZeroFields() {
        long startMillis = 0L;
        long endMillis = 0L;
        String format = "[H'H'm'm's's']";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("0s", result);
    }

    @Test
    void testFormatPeriod_FormatWithLiterals() {
        long startMillis = 0L;
        long endMillis = 3600000L; // 1 hour
        String format = "Hour:'H'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("Hour:1", result);
    }

    @Test
    void testFormatPeriod_FormatWithMultipleFields() {
        long startMillis = 0L;
        long endMillis = 90061000L; // 1 day, 1 hour, 1 minute, 1 second
        String format = "d'd' H'H' m'm' s's'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1d 1H 1m 1s", result);
    }

    @Test
    void testFormatPeriod_LessThanOneSecond() {
        long startMillis = 0L;
        long endMillis = 500L;
        String format = "s's' S'S'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("0s 500S", result);
    }

    @Test
    void testFormatPeriod_MaxValues() {
        long startMillis = 0L;
        long endMillis = Long.MAX_VALUE;
        String format = "y'y' M'M' d'd' H'H' m'm' s's' S'S'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertNotNull(result);
        // Not asserting exact value due to size, just ensuring no exception and a result is produced
    }

    @Test
    void testFormatPeriod_MultipleOptionalBlocks() {
        long startMillis = 0L;
        long endMillis = 3601000L; // 1 hour, 1 second
        String format = "[H'H'][m'm'][s's']";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1H0m1s", result);
    }

    @Test
    void testFormatPeriod_PadWithZerosFalse() {
        long startMillis = 0L;
        long endMillis = 61000L; // 1 minute, 1 second
        String format = "m'm' s's'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, false, TimeZone.getDefault());
        assertEquals("1m 1s", result);
    }

    @Test
    void testFormatPeriod_PadWithZerosTrue() {
        long startMillis = 0L;
        long endMillis = 61000L; // 1 minute, 1 second
        String format = "mm'm' ss's'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("01m 01s", result);
    }

    @Test
    void testFormatPeriod_TimezoneEffect() {
        long startMillis = 0L;
        long endMillis = 3600000L; // 1 hour
        TimeZone tz = TimeZone.getTimeZone("GMT+2");
        String format = "H'H'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, tz);
        assertEquals("1H", result);
    }

    @Test
    void testFormatPeriod_FormatWithMilliseconds() {
        long startMillis = 0L;
        long endMillis = 1234L; // 1 second, 234 milliseconds
        String format = "s's' S'S'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1s 234S", result);
    }

    @Test
    void testFormatPeriod_FormatWithYearsAndMonths() {
        long startMillis = 0L;
        long endMillis = 31536000000L + 2592000000L; // 1 year and 1 month in millis
        String format = "y'y' M'M'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1y 1M", result);
    }

    @Test
    void testFormatPeriod_FormatOnlyYears() {
        long startMillis = 0L;
        long endMillis = 63072000000L; // 2 years in millis
        String format = "y'y'";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("2y", result);
    }

    @Test
    void testFormatPeriod_FormatWithOptionalZeroFields() {
        long startMillis = 0L;
        long endMillis = 1000L; // 1 second
        String format = "[m'm' ][s's']";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1s", result);
    }

    @Test
    void testFormatPeriod_FormatAllOptionalWithNonZero() {
        long startMillis = 0L;
        long endMillis = 90061000L; // 1 day, 1 hour, 1 minute, 1 second
        String format = "[d'd' ][H'H' ][m'm' ][s's']";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1d 1H 1m 1s", result);
    }

    @Test
    void testFormatPeriod_FormatAllOptionalWithSomeZero() {
        long startMillis = 0L;
        long endMillis = 3661000L; // 1 hour, 1 minute, 1 second
        String format = "[d'd' ][H'H' ][m'm' ][s's']";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("1H 1m 1s", result);
    }

    @Test
    void testFormatPeriod_FormatAllOptionalWithAllZero() {
        long startMillis = 0L;
        long endMillis = 0L;
        String format = "[d'd' ][H'H' ][m'm' ][s's']";

        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault());
        assertEquals("0s", result);
    }

}