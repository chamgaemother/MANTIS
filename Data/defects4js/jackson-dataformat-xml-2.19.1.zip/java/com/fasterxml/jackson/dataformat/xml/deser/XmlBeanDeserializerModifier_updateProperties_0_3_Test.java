package com.fasterxml.jackson.dataformat.xml.deser;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

public class XmlBeanDeserializerModifier_updateProperties_0_3_Test {

    @Test
    @DisplayName("Single property with wrapperName having null local name, property is unwrapped and handled later")
    public void TC11_SinglePropertyWithWrapperNameHavingNullLocalName_UnchangedProperty() {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        PropertyName wrapper = new PropertyName((String) null);
        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(prop.getWrapperName()).thenReturn(wrapper);
        when(prop.getName()).thenReturn("propertyName");
        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        // WHEN
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        assertEquals(1, result.size(), "Result list should contain exactly one property");
        assertEquals("propertyName", result.get(0).getName(), "Property name should remain unchanged");
    }

    @Test
    @DisplayName("Single property with wrapperName matching property name, no renaming")
    public void TC12_SinglePropertyWithWrapperNameMatchingPropertyName_NoRenaming() {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        PropertyName wrapper = new PropertyName("propertyName");
        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(prop.getWrapperName()).thenReturn(wrapper);
        when(prop.getName()).thenReturn("propertyName");
        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        // WHEN
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        assertEquals(1, result.size(), "Result list should contain exactly one property");
        assertEquals("propertyName", result.get(0).getName(), "Property name should remain unchanged");
    }

    @Test
    @DisplayName("Multiple properties with mixed conditions and renaming")
    public void TC13_MultiplePropertiesWithMixedConditions_RenamingAndUnchanged() {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc1 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop1 = mock(BeanPropertyDefinition.class);
        when(prop1.getPrimaryMember()).thenReturn(acc1);
        when(prop1.getWrapperName()).thenReturn(null);
        when(prop1.getName()).thenReturn("name1");

        AnnotatedMember acc2 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop2 = mock(BeanPropertyDefinition.class);
        when(prop2.getPrimaryMember()).thenReturn(acc2);
        when(prop2.getWrapperName()).thenReturn(null);
        when(prop2.getName()).thenReturn("name2");

        PropertyName wrapper3 = new PropertyName("newName3");
        AnnotatedMember acc3 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop3 = mock(BeanPropertyDefinition.class);
        when(prop3.getPrimaryMember()).thenReturn(acc3);
        when(prop3.getWrapperName()).thenReturn(wrapper3);
        when(prop3.getName()).thenReturn("name3");

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop1, prop2, prop3));

        // WHEN
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        assertEquals(3, result.size(), "Result list should contain three properties");
        assertEquals("name1", result.get(0).getName(), "First property name should remain unchanged");
        assertEquals("name2", result.get(1).getName(), "Second property name should remain unchanged");
        assertEquals("newName3", result.get(2).getName(), "Third property should be renamed to 'newName3'");
    }

    @Test
    @DisplayName("Property with acc not null and wrapperName has non-empty different name, renaming occurs")
    public void TC14_PropertyWithValidNonEmptyWrapperName_RenamingOccurs() {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        PropertyName wrapper = new PropertyName("wrapperDifferentName");
        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(prop.getWrapperName()).thenReturn(wrapper);
        when(prop.getName()).thenReturn("originalName");
        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        // WHEN
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        assertEquals(1, result.size(), "Result list should contain exactly one property");
        assertEquals("wrapperDifferentName", result.get(0).getName(), "Property name should be renamed to 'wrapperDifferentName'");
    }

    @Test
    @DisplayName("Property with wrapperName not requiring renaming")
    public void TC15_PropertyWithWrapperNameNotRequiringRenaming_UnchangedProperty() {
        // GIVEN
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        PropertyName wrapper = new PropertyName("propertyName");
        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(prop.getWrapperName()).thenReturn(wrapper);
        when(prop.getName()).thenReturn("propertyName");
        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        // WHEN
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // THEN
        assertEquals(1, result.size(), "Result list should contain exactly one property");
        assertEquals("propertyName", result.get(0).getName(), "Property name should remain unchanged");
    }
}