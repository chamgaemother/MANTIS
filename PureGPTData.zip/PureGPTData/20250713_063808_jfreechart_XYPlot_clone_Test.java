import static org.junit.jupiter.api.Assertions.*;

import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYPointerAnnotation;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.data.xy.XYSeries;
import org.junit.jupiter.api.Test;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Stroke;
import java.awt.Paint;

class XYPlotTest {

    @Test
    void testCloneBasic() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithDomainAxis() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        ValueAxis domainAxis = new NumberAxis("X");
        plot.setDomainAxis(domainAxis);

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithRangeAxis() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        ValueAxis rangeAxis = new NumberAxis("Y");
        plot.setRangeAxis(rangeAxis);

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithDataset() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        XYSeries series = new XYSeries("Series 1");
        series.add(1.0, 2.0);
        XYDataset dataset = new XYSeriesCollection(series);
        plot.setDataset(dataset);

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithRenderer() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        XYItemRenderer renderer = new XYLineAndShapeRenderer();
        plot.setRenderer(renderer);

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithLegendItems() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        LegendItemCollection legends = new LegendItemCollection();
        plot.setFixedLegendItems(legends);

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithAnnotations() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        XYAnnotation annotation = new XYPointerAnnotation("Test", 1.0, 2.0, 3.0);
        plot.addAnnotation(annotation);

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithDifferentQuadrantOrigin() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        plot.setQuadrantOrigin(new java.awt.geom.Point2D.Double(5.0, 5.0));

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
    }

    @Test
    void testCloneWithDifferentQuadrantPaint() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        Paint[] paints = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW};
        for (int i = 0; i < 4; i++) {
            plot.setQuadrantPaint(i, paints[i]);
        }

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        for (int i = 0; i < 4; i++) {
            assertEquals(plot.getQuadrantPaint(i), clonedPlot.getQuadrantPaint(i));
        }
    }

    @Test
    void testCloneWithDifferentStrokes() throws CloneNotSupportedException {
        XYPlot plot = new XYPlot();
        Stroke stroke = new BasicStroke(1.5f);
        plot.setDomainGridlineStroke(stroke);

        XYPlot clonedPlot = (XYPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot.getDomainGridlineStroke(), clonedPlot.getDomainGridlineStroke());
    }
}