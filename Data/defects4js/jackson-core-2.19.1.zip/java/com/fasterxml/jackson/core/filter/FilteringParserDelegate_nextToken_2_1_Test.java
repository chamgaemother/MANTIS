package com.fasterxml.jackson.core.filter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.filter.TokenFilter;
import com.fasterxml.jackson.core.filter.TokenFilterContext;
import java.lang.reflect.Field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class FilteringParserDelegate_nextToken_2_1_Test {

//     @Test
//     @DisplayName("Throws IllegalArgumentException when an asynchronous parser is used without permission")
//     public void TC06_async_parser_throws_exception() {
//         JsonParser asyncParser = mock(JsonParser.class);
//         when(asyncParser.canParseAsync()).thenReturn(true);
//         TokenFilter includeAllFilter = TokenFilter.INCLUDE_ALL;
// 
//         IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
//             new FilteringParserDelegate(asyncParser, includeAllFilter, TokenFilter.Inclusion.INCLUDE_ALL, false, false);
//         });
// 
//         Assertions.assertTrue(exception.getMessage().contains("which requires explicit permission to be used"),
//                 "Expected IllegalArgumentException with appropriate message");
//     }

    @Test
    @DisplayName("Returns null when a scalar token is not included by _itemFilter and multiple matches are not allowed")
    public void TC07_scalar_token_excluded_no_multi_matches() throws Exception {
        JsonParser delegateMock = mock(JsonParser.class);
        when(delegateMock.nextToken()).thenReturn(JsonToken.VALUE_STRING).thenReturn(null);
        TokenFilter excludeFilter = mock(TokenFilter.class);
        when(excludeFilter.includeValue(delegateMock)).thenReturn(false);

        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, excludeFilter, TokenFilter.Inclusion.ONLY_INCLUDE_ALL, false);

        // Set private fields via reflection
        Field currTokenField = FilteringParserDelegate.class.getDeclaredField("_currToken");
        currTokenField.setAccessible(true);
        currTokenField.set(parser, JsonToken.VALUE_STRING);

        Field exposedContextField = FilteringParserDelegate.class.getDeclaredField("_exposedContext");
        exposedContextField.setAccessible(true);
        exposedContextField.set(parser, null);

        JsonToken result = parser.nextToken();

        Assertions.assertNull(result, "Expected nextToken() to return null when scalar token is excluded and multiple matches are not allowed");
    }

    @Test
    @DisplayName("Processes END_OBJECT token and updates _headContext and _itemFilter accordingly")
    public void TC08_end_object_updates_context() throws Exception {
        JsonParser delegateMock = mock(JsonParser.class);
        when(delegateMock.nextToken()).thenReturn(JsonToken.END_OBJECT).thenReturn(null);
        TokenFilter includeAllFilter = TokenFilter.INCLUDE_ALL;

        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, includeAllFilter, TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH, true);

        TokenFilterContext parentContext = mock(TokenFilterContext.class);
        TokenFilterContext currentContext = mock(TokenFilterContext.class);
        when(currentContext.getParent()).thenReturn(parentContext);
        when(currentContext.getFilter()).thenReturn(includeAllFilter);

        // Set private field _headContext via reflection
        Field headContextField = FilteringParserDelegate.class.getDeclaredField("_headContext");
        headContextField.setAccessible(true);
        headContextField.set(parser, currentContext);

        JsonToken result = parser.nextToken();

        Assertions.assertEquals(JsonToken.END_OBJECT, result, "Expected END_OBJECT token");

        Field headContextFieldGet = FilteringParserDelegate.class.getDeclaredField("_headContext");
        headContextFieldGet.setAccessible(true);
        TokenFilterContext updatedHeadContext = (TokenFilterContext) headContextFieldGet.get(parser);

        Assertions.assertSame(parentContext, updatedHeadContext, "_headContext should be updated to parent context");
    }

    @Test
    @DisplayName("Skips children when _itemFilter returns null for a FIELD_NAME")
    public void TC09_field_name_exclusion_skips_children() throws Exception {
        JsonParser delegateMock = mock(JsonParser.class);
        when(delegateMock.currentName()).thenReturn("excludedField");
        when(delegateMock.nextToken()).thenReturn(JsonToken.FIELD_NAME, JsonToken.VALUE_STRING).thenReturn(null);
        TokenFilter excludeFilter = mock(TokenFilter.class);
        when(excludeFilter.includeProperty("excludedField")).thenReturn(null);

        FilteringParserDelegate parser = new FilteringParserDelegate(delegateMock, excludeFilter, TokenFilter.Inclusion.ONLY_INCLUDE_ALL, false);

        JsonToken result = parser.nextToken();

        verify(delegateMock).skipChildren();
        Assertions.assertNull(result, "Expected nextToken() to return null after skipping excluded FIELD_NAME children");
    }
}