package org.joda.time.format;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FormatUtils_writePaddedInteger_1_1_Test {

    @Test
    @DisplayName("writePaddedInteger with positive value >=1000 and <10000 and size equals digit count (no padding needed)")
    void TC12_writePaddedInteger_positive_four_digits_no_padding() throws IOException {
        // Given
        Writer writer = new StringWriter();
        int value = 1234;
        int size = 4;

        // When
        FormatUtils.writePaddedInteger(writer, value, size);

        // Then
        assertEquals("1234", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value >=1000 and <10000 and size greater than digit count (with padding)")
    void TC13_writePaddedInteger_positive_four_digits_with_padding() throws IOException {
        // Given
        Writer writer = new StringWriter();
        int value = 1234;
        int size = 6;

        // When
        FormatUtils.writePaddedInteger(writer, value, size);

        // Then
        assertEquals("001234", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger with positive value >=1000 and <10000 and size less than digit count (no padding, size ignored)")
    void TC14_writePaddedInteger_positive_four_digits_size_less_than_digits() throws IOException {
        // Given
        Writer writer = new StringWriter();
        int value = 1234;
        int size = 3;

        // When
        FormatUtils.writePaddedInteger(writer, value, size);

        // Then
        assertEquals("1234", writer.toString());
    }

    @Test
    @DisplayName("writePaddedInteger throws IOException when Writer encounters an IO error")
    void TC15_writePaddedInteger_writer_throws_IOException() {
        // Given
        Writer writer = mock(Writer.class);
        int value = 1234;
        int size = 6;

        try {
            doThrow(new IOException("IO Error")).when(writer).write(anyInt());
        } catch (IOException e) {
            // This block will not be executed because we're mocking the behavior
        }

        // When & Then
        IOException exception = assertThrows(IOException.class, () -> {
            FormatUtils.writePaddedInteger(writer, value, size);
        });
        assertEquals("IO Error", exception.getMessage());
    }
}