package org.apache.commons.compress.harmony.pack200;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClassBands_addAnnotation_0_2_Test {

    @Test
    @DisplayName("addAnnotation with context=CONTEXT_FIELD, visible=true, and flag does not have bit21 set")
    void TC06() throws Exception {
        // Initialize parameters
        int context = MetadataBandGroup.CONTEXT_FIELD;
        String desc = "desc";
        boolean visible = true;
        List<String> nameRU = new ArrayList<>();
        List<String> tags = new ArrayList<>();
        List<Object> values = new ArrayList<>();
        List<Integer> caseArrayN = new ArrayList<>();
        List<String> nestTypeRS = new ArrayList<>();
        List<String> nestNameRU = new ArrayList<>();
        List<Integer> nestPairN = new ArrayList<>();

        // Create mocks for dependencies
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with mocked dependencies
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock MetadataBandGroup for field_RVA_bands
        MetadataBandGroup field_RVA_bands = mock(MetadataBandGroup.class);
        Field fieldRvaBandsField = ClassBands.class.getDeclaredField("field_RVA_bands");
        fieldRvaBandsField.setAccessible(true);
        fieldRvaBandsField.set(classBands, field_RVA_bands);

        // Access tempFieldFlags via reflection and initialize it
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Long> tempFieldFlags = (List<Long>) tempFieldFlagsField.get(classBands);
        tempFieldFlags.add(0L);

        // Invoke the method under test
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Verify that newEntryInAnnoN was called
        verify(field_RVA_bands, times(1)).newEntryInAnnoN();

        // Assert that the last element in tempFieldFlags has bit21 set
        Long lastFlag = tempFieldFlags.get(tempFieldFlags.size() - 1);
        assertTrue((lastFlag & (1L << 21)) != 0, "Bit21 should be set in the last flag");
    }

    @Test
    @DisplayName("addAnnotation with context=CONTEXT_FIELD, visible=false, and flag has bit22 set")
    void TC07() throws Exception {
        // Initialize parameters
        int context = MetadataBandGroup.CONTEXT_FIELD;
        String desc = "desc";
        boolean visible = false;
        List<String> nameRU = new ArrayList<>();
        List<String> tags = new ArrayList<>();
        List<Object> values = new ArrayList<>();
        List<Integer> caseArrayN = new ArrayList<>();
        List<String> nestTypeRS = new ArrayList<>();
        List<String> nestNameRU = new ArrayList<>();
        List<Integer> nestPairN = new ArrayList<>();

        // Create mocks for dependencies
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with mocked dependencies
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock MetadataBandGroup for field_RIA_bands
        MetadataBandGroup field_RIA_bands = mock(MetadataBandGroup.class);
        Field fieldRiaBandsField = ClassBands.class.getDeclaredField("field_RIA_bands");
        fieldRiaBandsField.setAccessible(true);
        fieldRiaBandsField.set(classBands, field_RIA_bands);

        // Access tempFieldFlags via reflection and initialize it
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Long> tempFieldFlags = (List<Long>) tempFieldFlagsField.get(classBands);
        tempFieldFlags.add((long) (1 << 22));

        // Invoke the method under test
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Verify that incrementAnnoN was called
        verify(field_RIA_bands, times(1)).incrementAnnoN();

        // Assert that the last element in tempFieldFlags has bit22 set
        Long lastFlag = tempFieldFlags.get(tempFieldFlags.size() - 1);
        assertTrue((lastFlag & (1L << 22)) != 0, "Bit22 should be set in the last flag");
    }

    @Test
    @DisplayName("addAnnotation with context=CONTEXT_FIELD, visible=false, and flag does not have bit22 set")
    void TC08() throws Exception {
        // Initialize parameters
        int context = MetadataBandGroup.CONTEXT_FIELD;
        String desc = "desc";
        boolean visible = false;
        List<String> nameRU = new ArrayList<>();
        List<String> tags = new ArrayList<>();
        List<Object> values = new ArrayList<>();
        List<Integer> caseArrayN = new ArrayList<>();
        List<String> nestTypeRS = new ArrayList<>();
        List<String> nestNameRU = new ArrayList<>();
        List<Integer> nestPairN = new ArrayList<>();

        // Create mocks for dependencies
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with mocked dependencies
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock MetadataBandGroup for field_RIA_bands
        MetadataBandGroup field_RIA_bands = mock(MetadataBandGroup.class);
        Field fieldRiaBandsField = ClassBands.class.getDeclaredField("field_RIA_bands");
        fieldRiaBandsField.setAccessible(true);
        fieldRiaBandsField.set(classBands, field_RIA_bands);

        // Access tempFieldFlags via reflection and initialize it
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Long> tempFieldFlags = (List<Long>) tempFieldFlagsField.get(classBands);
        tempFieldFlags.add(0L);

        // Invoke the method under test
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Verify that newEntryInAnnoN was called
        verify(field_RIA_bands, times(1)).newEntryInAnnoN();

        // Assert that the last element in tempFieldFlags has bit22 set
        Long lastFlag = tempFieldFlags.get(tempFieldFlags.size() - 1);
        assertTrue((lastFlag & (1L << 22)) != 0, "Bit22 should be set in the last flag");
    }

    @Test
    @DisplayName("addAnnotation with context=CONTEXT_METHOD, visible=true, and flag has bit21 set")
    void TC09() throws Exception {
        // Initialize parameters
        int context = MetadataBandGroup.CONTEXT_METHOD;
        String desc = "desc";
        boolean visible = true;
        List<String> nameRU = new ArrayList<>();
        List<String> tags = new ArrayList<>();
        List<Object> values = new ArrayList<>();
        List<Integer> caseArrayN = new ArrayList<>();
        List<String> nestTypeRS = new ArrayList<>();
        List<String> nestNameRU = new ArrayList<>();
        List<Integer> nestPairN = new ArrayList<>();

        // Create mocks for dependencies
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with mocked dependencies
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock MetadataBandGroup for method_RVA_bands
        MetadataBandGroup method_RVA_bands = mock(MetadataBandGroup.class);
        Field methodRvaBandsField = ClassBands.class.getDeclaredField("method_RVA_bands");
        methodRvaBandsField.setAccessible(true);
        methodRvaBandsField.set(classBands, method_RVA_bands);

        // Access tempMethodFlags via reflection and initialize it
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Long> tempMethodFlags = (List<Long>) tempMethodFlagsField.get(classBands);
        tempMethodFlags.add((long) (1 << 21));

        // Invoke the method under test
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Verify that incrementAnnoN was called
        verify(method_RVA_bands, times(1)).incrementAnnoN();

        // Assert that the last element in tempMethodFlags has bit21 set
        Long lastFlag = tempMethodFlags.get(tempMethodFlags.size() - 1);
        assertTrue((lastFlag & (1L << 21)) != 0, "Bit21 should be set in the last flag");
    }

    @Test
    @DisplayName("addAnnotation with context=CONTEXT_METHOD, visible=true, and flag does not have bit21 set")
    void TC10() throws Exception {
        // Initialize parameters
        int context = MetadataBandGroup.CONTEXT_METHOD;
        String desc = "desc";
        boolean visible = true;
        List<String> nameRU = new ArrayList<>();
        List<String> tags = new ArrayList<>();
        List<Object> values = new ArrayList<>();
        List<Integer> caseArrayN = new ArrayList<>();
        List<String> nestTypeRS = new ArrayList<>();
        List<String> nestNameRU = new ArrayList<>();
        List<Integer> nestPairN = new ArrayList<>();

        // Create mocks for dependencies
        Segment segment = mock(Segment.class);
        CpBands cpBands = mock(CpBands.class);
        AttributeDefinitionBands attrBands = mock(AttributeDefinitionBands.class);
        when(segment.getCpBands()).thenReturn(cpBands);
        when(segment.getAttrBands()).thenReturn(attrBands);

        // Instantiate ClassBands with mocked dependencies
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Mock MetadataBandGroup for method_RVA_bands
        MetadataBandGroup method_RVA_bands = mock(MetadataBandGroup.class);
        Field methodRvaBandsField = ClassBands.class.getDeclaredField("method_RVA_bands");
        methodRvaBandsField.setAccessible(true);
        methodRvaBandsField.set(classBands, method_RVA_bands);

        // Access tempMethodFlags via reflection and initialize it
        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Long> tempMethodFlags = (List<Long>) tempMethodFlagsField.get(classBands);
        tempMethodFlags.add(0L);

        // Invoke the method under test
        classBands.addAnnotation(context, desc, visible, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        // Verify that newEntryInAnnoN was called
        verify(method_RVA_bands, times(1)).newEntryInAnnoN();

        // Assert that the last element in tempMethodFlags has bit21 set
        Long lastFlag = tempMethodFlags.get(tempMethodFlags.size() - 1);
        assertTrue((lastFlag & (1L << 21)) != 0, "Bit21 should be set in the last flag");
    }
}