package org.jfree.chart.renderer.xy;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

class XYBarRendererTest {

    private XYBarRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private int series = 0;
    private int item = 0;
    private CrosshairState crosshairState;
    private int pass = 0;

    @BeforeEach
    void setUp() {
        renderer = new XYBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        when(renderer.getItemVisible(series, item)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_UseYInterval_True_ValidValues() {
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(intervalDataset).getStartYValue(series, item);
        verify(intervalDataset).getEndYValue(series, item);
        verify(rangeAxis).valueToJava2D(10.0, dataArea, RectangleEdge.LEFT);
        verify(rangeAxis).valueToJava2D(20.0, dataArea, RectangleEdge.LEFT);
        verify(intervalDataset).getStartXValue(series, item);
        verify(intervalDataset).getEndXValue(series, item);
        verify(domainAxis).valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM);
        verify(domainAxis).valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM);
        verify(plot).getDomainAxisEdge();
        verify(plot).getRangeAxisEdge();
        verify(plot).getOrientation();
        verify(rangeAxis).getRange();
        verify(domainAxis).getRange();
    }

    @Test
    void testDrawItem_UseYInterval_False_BaseUsed() {
        renderer.setUseYInterval(false);
        renderer.setBase(5.0);
        when(dataset.getYValue(series, item)).thenReturn(15.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset).thenReturn(dataset);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(dataset).getYValue(series, item);
        verify(rangeAxis).valueToJava2D(5.0, dataArea, RectangleEdge.LEFT);
        verify(rangeAxis).valueToJava2D(15.0, dataArea, RectangleEdge.LEFT);
        verify(dataset).getXValue(series, item);
        verify(domainAxis).valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM);
        verify(domainAxis).valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM);
    }

    @Test
    void testDrawItem_Value0NaN() {
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(Double.NaN);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(intervalDataset).getStartYValue(series, item);
        verify(intervalDataset).getEndYValue(series, item);
    }

    @Test
    void testDrawItem_Value1NaN() {
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(Double.NaN);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(intervalDataset).getStartYValue(series, item);
        verify(intervalDataset).getEndYValue(series, item);
    }

    @Test
    void testDrawItem_RangeAxisDoesNotIntersect_Value0LessThanValue1() {
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(25.0, 30.0));

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(rangeAxis.getRange()).intersects(10.0, 20.0);
    }

    @Test
    void testDrawItem_RangeAxisDoesNotIntersect_Value0GreaterThanValue1() {
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(20.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(10.0);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(25.0, 30.0));

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(rangeAxis.getRange()).intersects(10.0, 20.0);
    }

    @Test
    void testDrawItem_StartXNaN() {
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(Double.NaN);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(intervalDataset).getStartXValue(series, item);
        verify(intervalDataset).getEndXValue(series, item);
    }

    @Test
    void testDrawItem_EndXNaN() {
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(Double.NaN);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(intervalDataset).getStartXValue(series, item);
        verify(intervalDataset).getEndXValue(series, item);
    }

    @Test
    void testDrawItem_DomainAxisDoesNotIntersect() {
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(20.0, 30.0));

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(domainAxis.getRange()).intersects(5.0, 15.0);
    }

    @Test
    void testDrawItem_AlignmentFactorWithinRange() {
        renderer.setBarAlignmentFactor(0.5);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(0.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(10.0);
        when(dataset.getXValue(series, item)).thenReturn(5.0);
        when(domainAxis.valueToJava2D(0.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(30.0, 50.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 60.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(-10.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(intervalDataset).getStartXValue(series, item);
        verify(intervalDataset).getEndXValue(series, item);
        verify(dataset).getXValue(series, item);
    }

    @Test
    void testDrawItem_AlignmentFactorOutOfRange() {
        renderer.setBarAlignmentFactor(1.5);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(0.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(0.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(30.0, 50.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 60.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(-10.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(dataset, times(0)).getXValue(series, item);
    }

    @Test
    void testDrawItem_HorizontalOrientation() {
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.TOP)).thenReturn(80.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.TOP)).thenReturn(60.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.TOP);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(plot).getOrientation();
    }

    @Test
    void testDrawItem_ShadowsVisible() {
        renderer.setShadowsVisible(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        XYBarPainter painter = mock(XYBarPainter.class);
        renderer.setBarPainter(painter);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(painter).paintBarShadow(any(Graphics2D.class), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), eq(RectangleEdge.LEFT), anyBoolean());
        verify(painter).paintBar(any(Graphics2D.class), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), eq(RectangleEdge.LEFT));
    }

    @Test
    void testDrawItem_ShadowsNotVisible() {
        renderer.setShadowsVisible(false);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        XYBarPainter painter = mock(XYBarPainter.class);
        renderer.setBarPainter(painter);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(painter, never()).paintBarShadow(any(Graphics2D.class), any(), anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class), anyBoolean());
        verify(painter).paintBar(any(Graphics2D.class), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), eq(RectangleEdge.LEFT));
    }

    @Test
    void testDrawItem_ItemLabelVisible() {
        renderer.setUseYInterval(true);
        renderer.setShowLabelInsideVisibleBar(false);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);
        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);
        XYItemLabelGenerator generator = mock(XYItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(generator);
        when(generator.generateLabel(dataset, series, item)).thenReturn("Label");
        when(renderer.getPositiveItemLabelPosition(series, item)).thenReturn(new ItemLabelPosition());
        when(renderer.getNegativeItemLabelPosition(series, item)).thenReturn(new ItemLabelPosition());

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(generator).generateLabel(dataset, series, item);
    }

    @Test
    void testDrawItem_NullEntities() {
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);
        when(state.getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(g2, atLeastOnce()).getClipBounds();
    }

    @Test
    void testDrawItem_WithEntities() {
        org.jfree.chart.entity.EntityCollection entities = mock(org.jfree.chart.entity.EntityCollection.class);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);
        when(state.getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(entities).add(any());
    }

    @Test
    void testDrawItem_NullGraphics() {
        renderer.setUseYInterval(true);
        when(dataset.getYValue(series, item)).thenReturn(15.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        renderer.drawItem(null, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Expecting NPE or handled internally, no interactions since g2 is null
    }

    @Test
    void testDrawItem_NegativeValue() {
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(-20.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(-10.0);
        when(rangeAxis.valueToJava2D(-20.0, dataArea, RectangleEdge.LEFT)).thenReturn(70.0);
        when(rangeAxis.valueToJava2D(-10.0, dataArea, RectangleEdge.LEFT)).thenReturn(90.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(-30.0, 0.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);
        when(state.getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(rangeAxis).valueToJava2D(-20.0, dataArea, RectangleEdge.LEFT);
        verify(rangeAxis).valueToJava2D(-10.0, dataArea, RectangleEdge.LEFT);
    }

    @Test
    void testDrawItem_InvertedRangeAxis() {
        when(rangeAxis.isInverted()).thenReturn(true);
        renderer.setUseYInterval(true);
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(rangeAxis).isInverted();
    }

    @Test
    void testDrawItem_NullPlot() {
        when(renderer.getPlot()).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, info, null, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_InvalidDatasetCast() {
        XYDataset invalidDataset = mock(XYDataset.class);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        renderer.setUseYInterval(true);
        when(renderer.findRangeBounds(any())).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, invalidDataset, series, item, crosshairState, pass);
        // Expecting ClassCastException or handled, no specific verification
    }

    @Test
    void testDrawItem_CrosshairUpdate() {
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(dataset).thenReturn(intervalDataset);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
        when(intervalDataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(15.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(intervalDataset.getStartXValue(series, item)).thenReturn(5.0);
        when(intervalDataset.getEndXValue(series, item)).thenReturn(15.0);
        when(domainAxis.valueToJava2D(5.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(60.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 30.0));
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(state.getElementHinting()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(crosshairState).updateCrosshairValues(eq(10.0), eq(15.0), eq(plot.getOrientation()));
    }
}