package org.apache.commons.collections4.iterators;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class PermutationIterator_next_0_2_Test {

    @Test
    @DisplayName("Handles single-element keys array correctly")
    void TC06_handlesSingleElementKeysArrayCorrectly() throws Exception {
        // Arrange
        List<Integer> initialCollection = Collections.singletonList(1);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Reflection to set private fields
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{1});

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, new boolean[]{true});

        List<Integer> singleElementList = new ArrayList<>();
        singleElementList.add(1);

        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, singleElementList);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMapField.set(iterator, objectMap);

        // Act
        List<Integer> result = iterator.next();

        // Assert
        assertEquals(singleElementList, result, "Returns the single-element list without swapping");
    }

    @Test
    @DisplayName("Handles multiple iterations with multiple swaps")
    void TC07_handlesMultipleIterationsWithMultipleSwaps() throws Exception {
        // Arrange
        List<Integer> initialCollection = Arrays.asList(1, 2, 3);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Reflection to set private fields
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{1, 2, 3});

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, new boolean[]{true, true, true});

        List<Integer> firstPermutation = new ArrayList<>(Arrays.asList(1, 2, 3));

        List<Integer> secondPermutation = new ArrayList<>(Arrays.asList(1, 3, 2));

        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, firstPermutation);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        objectMapField.set(iterator, objectMap);

        // Act
        List<Integer> firstResult = iterator.next();
        List<Integer> secondResult = iterator.next();

        // Assert
        assertAll("Multiple iterations with multiple swaps",
                () -> assertEquals(firstPermutation, firstResult, "First permutation should be unchanged"),
                () -> assertEquals(secondPermutation, secondResult, "Second permutation should have elements swapped correctly")
        );
    }

    @Test
    @DisplayName("Handles direction reversal for integers larger than k after swapping")
    void TC08_handlesDirectionReversalForIntegersLargerThanKAfterSwapping() throws Exception {
        // Arrange
        List<Integer> initialCollection = Arrays.asList(3, 2, 1);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Reflection to set private fields
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{3, 2, 1});

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] directions = {true, false, true};
        directionField.set(iterator, directions);

        List<Integer> currentPermutation = new ArrayList<>(Arrays.asList(3, 2, 1));

        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, currentPermutation);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        objectMapField.set(iterator, objectMap);

        // Act
        iterator.next();

        // Assert
        boolean[] updatedDirections = (boolean[]) directionField.get(iterator);
        assertAll("Direction reversal for integers larger than k after swapping",
                () -> assertFalse(updatedDirections[0], "Direction of first element should be reversed"),
                () -> assertFalse(updatedDirections[1], "Direction of second element should be reversed"),
                () -> assertTrue(updatedDirections[2], "Direction of third element should remain unchanged")
        );
    }

    @Test
    @DisplayName("Handles keys array with all directions set to right")
    void TC09_handlesKeysArrayWithAllDirectionsSetToRight() throws Exception {
        // Arrange
        List<Integer> initialCollection = Arrays.asList(1, 2, 3);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Reflection to set private fields
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{1, 2, 3});

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] directions = {true, true, true};
        directionField.set(iterator, directions);

        List<Integer> currentPermutation = new ArrayList<>(Arrays.asList(1, 2, 3));

        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, currentPermutation);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        objectMapField.set(iterator, objectMap);

        // Act
        List<Integer> result = iterator.next();

        // Assert
        List<Integer> expectedPermutation = Arrays.asList(1, 3, 2);
        assertEquals(expectedPermutation, result, "Swaps correctly based on right directions and updates accordingly");
    }

    @Test
    @DisplayName("Handles keys array with all directions set to left")
    void TC10_handlesKeysArrayWithAllDirectionsSetToLeft() throws Exception {
        // Arrange
        List<Integer> initialCollection = Arrays.asList(3, 2, 1);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialCollection);

        // Reflection to set private fields
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, new int[]{3, 2, 1});

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] directions = {false, false, false};
        directionField.set(iterator, directions);

        List<Integer> currentPermutation = new ArrayList<>(Arrays.asList(3, 2, 1));

        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, currentPermutation);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);
        objectMapField.set(iterator, objectMap);

        // Act
        List<Integer> result = iterator.next();

        // Assert
        List<Integer> expectedPermutation = Arrays.asList(2, 3, 1);
        assertEquals(expectedPermutation, result, "Swaps correctly based on left directions and updates accordingly");
    }
}