package org.apache.commons.math3.geometry.euclidean.twod.hull;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;

import java.util.Arrays;
import java.util.Collection;

public class AklToussaintHeuristic_reducePoints_2_1_Test {

    @Test
    @DisplayName("reducePoints with points forming a quadrilateral and some points inside, ensuring excluded points are not in the result")
    public void TC22_reducePoints_excludesPointsInsideQuadrilateral() {
        // Arrange
        Collection<Vector2D> points = Arrays.asList(
                new Vector2D(0, 0),
                new Vector2D(4, 0),
                new Vector2D(4, 4),
                new Vector2D(0, 4),
                new Vector2D(2, 2)
        );

        // Act
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // Assert
        Assertions.assertTrue(result.containsAll(Arrays.asList(
                new Vector2D(0, 0),
                new Vector2D(4, 0),
                new Vector2D(4, 4),
                new Vector2D(0, 4)
        )), "Result should contain all quadrilateral points");
        Assertions.assertFalse(result.contains(new Vector2D(2, 2)), "Result should exclude points inside the quadrilateral");
    }

    @Test
    @DisplayName("reducePoints with quadrilateral build resulting in size less than 3, returning original collection")
    public void TC23_reducePoints_invalidQuadrilateral_returnsOriginalCollection() {
        // Arrange
        Collection<Vector2D> points = Arrays.asList(
                new Vector2D(1, 1),
                new Vector2D(1, 1),
                new Vector2D(1, 1),
                new Vector2D(1, 1)
        );

        // Act
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // Assert
        Assertions.assertEquals(points, result, "The result should be equal to the original collection as quadrilateral size is less than 3");
    }

    @Test
    @DisplayName("reducePoints with collection containing multiple duplicate points ensures only unique points are processed")
    public void TC24_reducePoints_handlesDuplicatePoints() {
        // Arrange
        Collection<Vector2D> points = Arrays.asList(
                new Vector2D(0, 0),
                new Vector2D(0, 0),
                new Vector2D(4, 0),
                new Vector2D(4, 4),
                new Vector2D(0, 4),
                new Vector2D(4, 4)
        );

        // Act
        Collection<Vector2D> result = AklToussaintHeuristic.reducePoints(points);

        // Assert
        Assertions.assertEquals(4, result.size(), "Result should contain only unique quadrilateral points");
        Assertions.assertTrue(result.containsAll(Arrays.asList(
                new Vector2D(0, 0),
                new Vector2D(4, 0),
                new Vector2D(4, 4),
                new Vector2D(0, 4)
        )), "Result should contain all unique quadrilateral points");
    }
}