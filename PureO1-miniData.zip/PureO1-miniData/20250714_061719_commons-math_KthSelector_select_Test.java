package org.apache.commons.math3.util;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.exception.NullArgumentException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

import java.util.stream.Stream;

class KthSelectorTest {

    @Test
    void testSelectWithNullWorkArray() {
        KthSelector selector = new KthSelector();
        int[] pivotsHeap = {0};
        assertThrows(NullPointerException.class, () -> selector.select(null, pivotsHeap, 0));
    }

    @Test
    void testSelectWithNullPivotsHeap() {
        KthSelector selector = new KthSelector();
        double[] work = {1.0, 2.0, 3.0, 4.0, 5.0};
        double result = selector.select(work, null, 2);
        assertEquals(3.0, result);
    }

    @ParameterizedTest
    @ValueSource(ints = {-1, 5})
    void testSelectWithInvalidK(int k) {
        KthSelector selector = new KthSelector();
        double[] work = {1.0, 2.0, 3.0, 4.0, 5.0};
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> selector.select(work, null, k));
    }

    @Test
    void testSelectWithEmptyWorkArray() {
        KthSelector selector = new KthSelector();
        double[] work = {};
        int[] pivotsHeap = {};
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> selector.select(work, pivotsHeap, 0));
    }

    @Test
    void testSelectWithSingleElement() {
        KthSelector selector = new KthSelector();
        double[] work = {42.0};
        double result = selector.select(work, null, 0);
        assertEquals(42.0, result);
    }

    @Test
    void testSelectWithMinimumSelectSize() {
        KthSelector selector = new KthSelector();
        double[] work = new double[15];
        for (int i = 0; i < 15; i++) {
            work[i] = i;
        }
        double result = selector.select(work, null, 7);
        assertEquals(7.0, result);
    }

    @Test
    void testSelectWithGreaterThanMinimumSelectSize() {
        KthSelector selector = new KthSelector();
        double[] work = {5.0, 3.0, 1.0, 2.0, 4.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0};
        double result = selector.select(work, null, 10);
        assertEquals(11.0, result);
    }

    @Test
    void testSelectWithPivotsHeapContainingNegative() {
        KthSelector selector = new KthSelector();
        double[] work = {4.0, 2.0, 5.0, 1.0, 3.0};
        int[] pivotsHeap = {2, -1, -1};
        double result = selector.select(work, pivotsHeap, 3);
        assertEquals(4.0, result);
    }

    @Test
    void testSelectWithPivotsHeapValid() {
        KthSelector selector = new KthSelector();
        double[] work = {9.0, 1.0, 5.0, 3.0, 7.0, 2.0, 8.0, 6.0, 4.0};
        int[] pivotsHeap = {4, 2, 6};
        double result = selector.select(work, pivotsHeap, 5);
        assertEquals(6.0, result);
    }

    @Test
    void testSelectWithKAsPivot() {
        KthSelector selector = new KthSelector();
        double[] work = {3.0, 1.0, 2.0};
        double result = selector.select(work, null, 1);
        assertEquals(2.0, result);
    }

    @Test
    void testSelectWithAllElementsSame() {
        KthSelector selector = new KthSelector();
        double[] work = {2.0, 2.0, 2.0, 2.0};
        double result = selector.select(work, null, 2);
        assertEquals(2.0, result);
    }

    @Test
    void testSelectWithSortedArray() {
        KthSelector selector = new KthSelector();
        double[] work = {1.0, 2.0, 3.0, 4.0, 5.0};
        double result = selector.select(work, null, 3);
        assertEquals(4.0, result);
    }

    @Test
    void testSelectWithReverseSortedArray() {
        KthSelector selector = new KthSelector();
        double[] work = {5.0, 4.0, 3.0, 2.0, 1.0};
        double result = selector.select(work, null, 2);
        assertEquals(3.0, result);
    }

    @Test
    void testSelectWithDuplicateElements() {
        KthSelector selector = new KthSelector();
        double[] work = {1.0, 3.0, 3.0, 2.0, 2.0, 4.0};
        double result = selector.select(work, null, 3);
        assertEquals(3.0, result);
    }

    @ParameterizedTest
    @MethodSource("provideInvalidKValues")
    void testSelectWithKOutOfBounds(int k, double[] work) {
        KthSelector selector = new KthSelector();
        int[] pivotsHeap = {0};
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> selector.select(work, pivotsHeap, k));
    }

    static Stream<Arguments> provideInvalidKValues() {
        return Stream.of(
                Arguments.of(-1, new double[]{1.0, 2.0, 3.0}),
                Arguments.of(3, new double[]{1.0, 2.0, 3.0}),
                Arguments.of(100, new double[]{1.0, 2.0, 3.0})
        );
    }

    @Test
    void testSelectWithLargeArray() {
        KthSelector selector = new KthSelector();
        int size = 1000;
        double[] work = new double[size];
        for (int i = 0; i < size; i++) {
            work[i] = size - i;
        }
        double result = selector.select(work, null, 499);
        assertEquals(501.0, result);
    }
}