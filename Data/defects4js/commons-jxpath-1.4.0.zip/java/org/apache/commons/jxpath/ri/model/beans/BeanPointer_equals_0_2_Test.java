package org.apache.commons.jxpath.ri.model.beans;
import org.apache.commons.jxpath.ri.model.NodePointer;

import org.apache.commons.jxpath.JXPathBeanInfo;
import org.apache.commons.jxpath.ri.QName;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class BeanPointer_equals_0_2_Test {

    @Test
    @DisplayName("object is BeanPointer with same parent, qName null, index is specific and equal, beans are different Strings")
    void TC06() {
        // GIVEN
        NodePointer parent = null; // corrected type to NodePointer based on the constructor used
        JXPathBeanInfo beanInfo = null;
        QName qName = null;
        BeanPointer bp1 = new BeanPointer(parent, qName, "test1", beanInfo);
        BeanPointer bp2 = new BeanPointer(parent, qName, "test2", beanInfo);
        
        // WHEN
        boolean result = bp1.equals(bp2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("object is BeanPointer with same parent, qName not null and equal, index is WHOLE_COLLECTION, beans are Booleans and equal")
    void TC07() {
        // GIVEN
        NodePointer parent = null;
        JXPathBeanInfo beanInfo = null;
        QName qName = new QName("uri", "local");
        BeanPointer bp1 = new BeanPointer(parent, qName, true, beanInfo);
        BeanPointer bp2 = new BeanPointer(parent, qName, true, beanInfo);
        
        // WHEN
        boolean result = bp1.equals(bp2);
        
        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("object is BeanPointer with same parent, qName not null but not equal, should return false")
    void TC08() {
        // GIVEN
        NodePointer parent = null;
        JXPathBeanInfo beanInfo = null;
        QName qName1 = new QName("uri1", "local1");
        QName qName2 = new QName("uri2", "local2");
        BeanPointer bp1 = new BeanPointer(parent, qName1, true, beanInfo);
        BeanPointer bp2 = new BeanPointer(parent, qName2, true, beanInfo);
        
        // WHEN
        boolean result = bp1.equals(bp2);
        
        // THEN
        assertFalse(result);
    }

//     @Test
//     @DisplayName("object is BeanPointer with different parents where one parent is null, should return false")
//     void TC09() {
        // GIVEN
//         NodePointer parent1 = null;  // corrected both parents type to NodePointer
//         NodePointer parent2 = new NodePointer(null) { @Override public Object getBaseValue() { return null; } };
//         JXPathBeanInfo beanInfo = null;
//         BeanPointer bp1 = new BeanPointer(parent1, null, true, beanInfo);
//         BeanPointer bp2 = new BeanPointer(parent2, null, true, beanInfo);
//         
        // WHEN
//         boolean result = bp1.equals(bp2);
//         
        // THEN
//         assertFalse(result);
//     }

//     @Test
//     @DisplayName("object is BeanPointer with different parents that are not equal, should return false")
//     void TC10() {
        // GIVEN
//         NodePointer parent1 = new NodePointer(null) { @Override public Object getBaseValue() { return null; } };
//         NodePointer parent2 = new NodePointer(null) { @Override public Object getBaseValue() { return null; } };
//         JXPathBeanInfo beanInfo = null;
//         BeanPointer bp1 = new BeanPointer(parent1, null, true, beanInfo);
//         BeanPointer bp2 = new BeanPointer(parent2, null, true, beanInfo);
//         
        // WHEN
//         boolean result = bp1.equals(bp2);
//         
        // THEN
//         assertFalse(result);
//     }
}