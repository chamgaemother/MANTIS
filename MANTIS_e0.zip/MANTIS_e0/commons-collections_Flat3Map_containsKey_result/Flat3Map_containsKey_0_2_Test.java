package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import org.apache.commons.collections4.map.Flat3Map;

public class Flat3Map_containsKey_0_2_Test {

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is null, and all keys are non-null")
    public void test_TC06_containsKey_returnsFalse_whenDelegateMapNull_KeyNull_AllKeysNonNull() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key1, key2, key3 to non-null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // WHEN
        boolean result = map.containsKey(null);

        // THEN
        assertEquals(false, result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is not null, size > 0, and key matches key3")
    public void test_TC07_containsKey_returnsTrue_whenDelegateMapNull_KeyMatchesKey3() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // Set hash3 to 'key3'.hashCode()
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, "key3".hashCode());

        // WHEN
        boolean result = map.containsKey("key3");

        // THEN
        assertEquals(true, result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is not null, size > 0, and key matches key2")
    public void test_TC08_containsKey_returnsTrue_whenDelegateMapNull_KeyMatchesKey2() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Set key1, key2
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        // Set hash2 to 'key2'.hashCode()
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, "key2".hashCode());

        // WHEN
        boolean result = map.containsKey("key2");

        // THEN
        assertEquals(true, result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is not null, size > 0, and key matches key1")
    public void test_TC09_containsKey_returnsTrue_whenDelegateMapNull_KeyMatchesKey1() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Set key1
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        // Set hash1 to 'key1'.hashCode()
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, "key1".hashCode());

        // WHEN
        boolean result = map.containsKey("key1");

        // THEN
        assertEquals(true, result);
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, size > 0, and no matching keys")
    public void test_TC10_containsKey_returnsFalse_whenDelegateMapNull_NoMatchingKeys() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Set delegateMap to null via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, "key1".hashCode());

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, "key2".hashCode());

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, "key3".hashCode());

        // WHEN
        boolean result = map.containsKey("key4");

        // THEN
        assertEquals(false, result);
    }
}