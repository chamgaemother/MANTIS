import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.CyclicXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;

class CyclicXYItemRendererTest {

    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    private CyclicXYItemRenderer renderer;

    @BeforeEach
    void setUp() {
        g2 = Mockito.mock(Graphics2D.class);
        state = Mockito.mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        info = Mockito.mock(PlotRenderingInfo.class);
        plot = Mockito.mock(XYPlot.class);
        domainAxis = Mockito.mock(ValueAxis.class);
        rangeAxis = Mockito.mock(ValueAxis.class);
        dataset = Mockito.mock(XYDataset.class);
        crosshairState = Mockito.mock(CrosshairState.class);

        renderer = new CyclicXYItemRenderer();
    }

    @Test
    void testDrawItemWithNullGraphics() {
        renderer.drawItem(null, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
    }

    @Test
    void testDrawItemWithNonCyclicAxes() {
        Mockito.when(dataset.getXValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(10.0);
        Mockito.when(dataset.getYValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItemWithCyclicDomainAxis() {
        domainAxis = new CyclicNumberAxis("X", 0, 100);
        Mockito.when(dataset.getXValue(Mockito.anyInt(), Mockito.eq(0))).thenReturn(90.0);
        Mockito.when(dataset.getYValue(Mockito.anyInt(), Mockito.eq(0))).thenReturn(10.0);
        Mockito.when(dataset.getXValue(Mockito.anyInt(), Mockito.eq(1))).thenReturn(10.0);
        Mockito.when(dataset.getYValue(Mockito.anyInt(), Mockito.eq(1))).thenReturn(20.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItemWithCyclicRangeAxis() {
        rangeAxis = new CyclicNumberAxis("Y", 0, 100);
        Mockito.when(dataset.getXValue(Mockito.anyInt(), Mockito.eq(0))).thenReturn(10.0);
        Mockito.when(dataset.getYValue(Mockito.anyInt(), Mockito.eq(0))).thenReturn(90.0);
        Mockito.when(dataset.getXValue(Mockito.anyInt(), Mockito.eq(1))).thenReturn(20.0);
        Mockito.when(dataset.getYValue(Mockito.anyInt(), Mockito.eq(1))).thenReturn(10.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItemWithBoundaryConditions() {
        domainAxis = new CyclicNumberAxis("X", 0, 100);
        rangeAxis = new CyclicNumberAxis("Y", 0, 100);

        Mockito.when(dataset.getXValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(0.0).thenReturn(100.0);
        Mockito.when(dataset.getYValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(0.0).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    void testDrawItemWithNaNValues() {
        Mockito.when(dataset.getXValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Double.NaN);
        Mockito.when(dataset.getYValue(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Double.NaN);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }
}