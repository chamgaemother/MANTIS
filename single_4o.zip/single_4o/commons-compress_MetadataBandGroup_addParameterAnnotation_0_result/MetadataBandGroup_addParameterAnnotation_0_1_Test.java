package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MetadataBandGroup_addParameterAnnotation_0_1_Test {

    @Test
    @DisplayName("Test addParameterAnnotation with all empty lists/arrays")
    public void testAddParameterAnnotation_EmptyInputs() throws Exception {
        CpBands mockCpBands = Mockito.mock(CpBands.class);
        SegmentHeader mockSegmentHeader = Mockito.mock(SegmentHeader.class);
        MetadataBandGroup instance = new MetadataBandGroup("", 0, mockCpBands, mockSegmentHeader, 0);

        int numParams = 0;
        int[] annoN = {};
        IntList pairN = new IntList();
        List<String> typeRS = Collections.emptyList();
        List<String> nameRU = Collections.emptyList();
        List<String> tags = Collections.emptyList();
        List<Object> values = Collections.emptyList();
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        instance.addParameterAnnotation(numParams, annoN, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        Field anno_NField = instance.getClass().getDeclaredField("anno_N");
        anno_NField.setAccessible(true);
        IntList anno_N = (IntList) anno_NField.get(instance);

        Field TField = instance.getClass().getDeclaredField("T");
        TField.setAccessible(true);
        List<String> T = (List<String>) TField.get(instance);

        assertTrue(anno_N.isEmpty());
        assertTrue(T.isEmpty());
    }

    @Test
    @DisplayName("Verify loop through annoN with one element")
    public void testAddParameterAnnotation_SingleAnnoN() throws Exception {
        CpBands mockCpBands = Mockito.mock(CpBands.class);
        SegmentHeader mockSegmentHeader = Mockito.mock(SegmentHeader.class);
        MetadataBandGroup instance = new MetadataBandGroup("", 0, mockCpBands, mockSegmentHeader, 0);

        int numParams = 1;
        int[] annoN = {5};
        IntList pairN = new IntList();
        List<String> typeRS = Collections.emptyList();
        List<String> nameRU = Collections.emptyList();
        List<String> tags = Collections.emptyList();
        List<Object> values = Collections.emptyList();
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        instance.addParameterAnnotation(numParams, annoN, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        Field anno_NField = instance.getClass().getDeclaredField("anno_N");
        anno_NField.setAccessible(true);
        IntList anno_N = (IntList) anno_NField.get(instance);

        assertEquals(1, anno_N.size());
        assertEquals(5, anno_N.get(0));
    }

    @Test
    @DisplayName("Check all possible tags in a single execution")
    public void testAddParameterAnnotation_AllTags() throws Exception {
        CpBands mockCpBands = Mockito.mock(CpBands.class);
        SegmentHeader mockSegmentHeader = Mockito.mock(SegmentHeader.class);
        MetadataBandGroup instance = new MetadataBandGroup("", 0, mockCpBands, mockSegmentHeader, 0);

        int numParams = 0;
        int[] annoN = {};
        IntList pairN = new IntList();
        List<String> typeRS = Collections.emptyList();
        List<String> nameRU = Collections.emptyList();
        // Adjusting values size to match tags size
        List<String> tags = List.of("B", "C", "I", "S", "Z", "D", "F", "J", "c", "e", "s");
        List<Object> values = List.of((byte) 0, 'C', 1, (short) 2, true, 2.0, 3.0f, 4L, "cValue", "eValue1", "eValue2", "sValue");

        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        instance.addParameterAnnotation(numParams, annoN, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        Field TField = instance.getClass().getDeclaredField("T");
        TField.setAccessible(true);
        List<String> T = (List<String>) TField.get(instance);

        assertEquals(tags.size(), T.size());
        assertEquals(tags, T);
    }

    @Test
    @DisplayName("Test with one iteration of caseArrayN loop")
    public void testAddParameterAnnotation_SingleCaseArrayN() throws Exception {
        CpBands mockCpBands = Mockito.mock(CpBands.class);
        SegmentHeader mockSegmentHeader = Mockito.mock(SegmentHeader.class);
        MetadataBandGroup instance = new MetadataBandGroup("", 0, mockCpBands, mockSegmentHeader, 0);

        int numParams = 0;
        int[] annoN = {};
        IntList pairN = new IntList();
        List<String> typeRS = Collections.emptyList();
        List<String> nameRU = Collections.emptyList();
        List<String> tags = Collections.emptyList();
        List<Object> values = Collections.emptyList();
        List<Integer> caseArrayN = List.of(5);
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        instance.addParameterAnnotation(numParams, annoN, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        Field casearray_NField = instance.getClass().getDeclaredField("casearray_N");
        casearray_NField.setAccessible(true);
        IntList casearray_N = (IntList) casearray_NField.get(instance);

        Field numBackwardsCallsField = instance.getClass().getDeclaredField("numBackwardsCalls");
        numBackwardsCallsField.setAccessible(true);
        int numBackwardsCalls = numBackwardsCallsField.getInt(instance);

        assertEquals(1, casearray_N.size());
        assertEquals(5, casearray_N.get(0));
        assertEquals(5, numBackwardsCalls);
    }

    @Test
    @DisplayName("Test empty tags list skips processing")
    public void testAddParameterAnnotation_EmptyTags() throws Exception {
        CpBands mockCpBands = Mockito.mock(CpBands.class);
        SegmentHeader mockSegmentHeader = Mockito.mock(SegmentHeader.class);
        MetadataBandGroup instance = new MetadataBandGroup("", 0, mockCpBands, mockSegmentHeader, 0);

        int numParams = 0;
        int[] annoN = {};
        IntList pairN = new IntList();
        List<String> typeRS = Collections.emptyList();
        List<String> nameRU = Collections.emptyList();
        List<String> tags = Collections.emptyList();
        List<Object> values = Collections.emptyList();
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        instance.addParameterAnnotation(numParams, annoN, pairN, typeRS, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        Field TField = instance.getClass().getDeclaredField("T");
        TField.setAccessible(true);
        List<String> T = (List<String>) TField.get(instance);

        assertEquals(0, T.size());
    }
}