package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class BHSDCodec_encode_2_2_Test {

    @Test
    @DisplayName("encode successfully encodes value with isDelta=false and isSigned=true without adjustments")
    void testEncode_TC25() throws Pack200Exception {
        // Given
        int b = 2;
        int h = 100;
        int s = 1;
        int d = 0;
        BHSDCodec codec = new BHSDCodec(b, h, s, d);
        int value = 100;
        int last = 0;
        
        // When
        byte[] result = codec.encode(value, last);
        
        // Then
        byte[] expected = {(byte) 100};
        assertArrayEquals(expected, result, "The encoded byte array does not match the expected result.");
    }
}