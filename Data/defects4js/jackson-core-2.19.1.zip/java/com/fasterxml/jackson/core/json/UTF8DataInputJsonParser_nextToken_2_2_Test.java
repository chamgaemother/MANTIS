package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.ObjectCodec;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.io.ByteArrayInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.nio.charset.StandardCharsets;

/**
 * Test class for UTF8DataInputJsonParser#nextToken method.
 * 
 * This class contains tests to ensure that the nextToken() method
 * behaves correctly under various scenarios to maximize branch coverage.
 */
public class UTF8DataInputJsonParser_nextToken_2_2_Test {

    /**
     * Test Case TC22:
     * 
     * Scenario Description:
     * nextToken() throws exception when parsing numbers with leading zeros and ALLOW_LEADING_ZEROS is disabled.
     *
     * Preconditions:
     * - ALLOW_LEADING_ZEROS feature is disabled.
     *
     * Test Steps:
     * 1. Create a UTF8DataInputJsonParser instance with ALLOW_LEADING_ZEROS disabled.
     * 2. Provide input "0123" to the parser.
     * 3. Call nextToken() and expect a JsonParseException.
     */
    @Test
    @DisplayName("nextToken() throws exception when parsing numbers with leading zeros and ALLOW_LEADING_ZEROS is disabled")
    void TC22_nextToken_throwsExceptionForLeadingZeros() throws Exception {
        // Prepare input data with leading zeros
        byte[] inputBytes = "0123".getBytes(StandardCharsets.UTF_8);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(inputBytes);
        DataInput dataInput = new DataInputStream(byteArrayInputStream);

        // Initialize IOContext (using default or mock values as appropriate)
        IOContext ioContext = new IOContext(null, null, false);

        // Initialize ObjectCodec (can be null if not used)
        ObjectCodec codec = null;

        // Initialize ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Define parser features: disable ALLOW_LEADING_ZEROS.
        int features = 0;

        // Retrieve the first byte from input
        int firstByte = inputBytes[0];

        // Instantiate the UTF8DataInputJsonParser
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, features, dataInput, codec, sym, firstByte);

        // Execute nextToken() and verify that JsonParseException is thrown
        Assertions.assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        }, "Expected nextToken() to throw JsonParseException due to leading zeros, but it did not.");
    }
}
