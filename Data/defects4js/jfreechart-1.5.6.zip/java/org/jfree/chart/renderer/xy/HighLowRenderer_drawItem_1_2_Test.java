// package org.jfree.chart.renderer.xy;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// import org.jfree.data.Range;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.Stroke;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.HighLowRenderer;
// import org.jfree.chart.util.Range;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.data.xy.OHLCDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// import java.lang.reflect.Field;
// 
// public class HighLowRenderer_drawItem_1_2_Test {
// 
//     @Test
//     @DisplayName("DrawItem processes OHLCDataset with valid yHigh and yLow in HORIZONTAL orientation")
//     void TC06_DrawItem_ProcessOHLCDataset_ValidYHighYLow_Horizontal() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(dataset.getHighValue(series, item)).thenReturn(25.0);
//         when(dataset.getLowValue(series, item)).thenReturn(15.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(domainAxis.valueToJava2D(15.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
//         when(rangeAxis.valueToJava2D(25.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
// 
//         // Reflection to set private fields if necessary
//         // Not needed here as setters are available
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2).draw(any()); // Verify that draw was called
//     }
// 
//     @Test
//     @DisplayName("DrawItem handles NaN yHigh in OHLCDataset")
//     void TC07_DrawItem_HandleNaN_YHigh() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(dataset.getHighValue(series, item)).thenReturn(Double.NaN);
//         when(dataset.getLowValue(series, item)).thenReturn(15.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset instanceof OHLCDataset).thenReturn(true);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2, never()).draw(any()); // High value is NaN, so draw should not be called
//     }
// 
//     @Test
//     @DisplayName("DrawItem handles NaN yLow in OHLCDataset")
//     void TC08_DrawItem_HandleNaN_YLow() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(dataset.getHighValue(series, item)).thenReturn(25.0);
//         when(dataset.getLowValue(series, item)).thenReturn(Double.NaN);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset instanceof OHLCDataset).thenReturn(true);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2, never()).draw(any()); // Low value is NaN, so draw should not be called
//     }
// 
//     @Test
//     @DisplayName("DrawItem draws open ticks when drawOpenTicks is enabled and yOpen is valid")
//     void TC09_DrawItem_DrawOpenTicksEnabled_ValidYOpen() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(18.0);
//         when(dataset.getHighValue(series, item)).thenReturn(25.0);
//         when(dataset.getLowValue(series, item)).thenReturn(15.0);
//         when(dataset.getOpenValue(series, item)).thenReturn(18.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
//         when(dataset instanceof OHLCDataset).thenReturn(true);
//         when(rangeAxis.valueToJava2D(18.0, dataArea, RectangleEdge.LEFT)).thenReturn(180.0);
// 
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawOpenTicks(true);
//         renderer.setOpenTickPaint(Color.RED);
// 
//         // Reflection to set private fields
//         Field openTickPaintField = HighLowRenderer.class.getDeclaredField("openTickPaint");
//         openTickPaintField.setAccessible(true);
//         openTickPaintField.set(renderer, Color.RED);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2).setPaint(Color.RED);
//         verify(g2).draw(any()); // Verify that open tick is drawn
//     }
// 
//     @Test
//     @DisplayName("DrawItem does not draw open ticks when drawOpenTicks is disabled")
//     void TC10_DrawItem_OpenTicksDisabled() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         when(dataset.getXValue(series, item)).thenReturn(18.0);
//         when(dataset.getOpenValue(series, item)).thenReturn(18.0);
//         when(dataset instanceof OHLCDataset).thenReturn(true);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
// 
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawOpenTicks(false);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2, never()).setPaint(Color.RED); // Open ticks are disabled
//         verify(g2, never()).draw(any()); // No open tick should be drawn
//     }
// }