package org.apache.commons.collections4.map;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_get_0_2_Test {

    @Test
    @DisplayName("Get returns value3 when size is 3 and key equals key3.")
    void testGetWhenSize3AndKeyEqualsKey3() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = map.getClass();
        Field sizeField = clazz.getDeclaredField("size");
        Field key3Field = clazz.getDeclaredField("key3");
        Field value3Field = clazz.getDeclaredField("value3");

        sizeField.setAccessible(true);
        key3Field.setAccessible(true);
        value3Field.setAccessible(true);

        sizeField.set(map, 3);
        Object testKey = new Object();
        key3Field.set(map, testKey);
        Object testValue = new Object();
        value3Field.set(map, testValue);

        assertEquals(testValue, map.get(testKey), "Returns value3.");
    }

    @Test
    @DisplayName("Get returns value2 when size is 2 and key equals key2.")
    void testGetWhenSize2AndKeyEqualsKey2() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = map.getClass();
        Field sizeField = clazz.getDeclaredField("size");
        Field key2Field = clazz.getDeclaredField("key2");
        Field value2Field = clazz.getDeclaredField("value2");

        sizeField.setAccessible(true);
        key2Field.setAccessible(true);
        value2Field.setAccessible(true);

        sizeField.set(map, 2);
        Object testKey = new Object();
        key2Field.set(map, testKey);
        Object testValue = new Object();
        value2Field.set(map, testValue);

        assertEquals(testValue, map.get(testKey), "Returns value2.");
    }

    @Test
    @DisplayName("Get returns value1 when size is 1 and key equals key1.")
    void testGetWhenSize1AndKeyEqualsKey1() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = map.getClass();
        Field sizeField = clazz.getDeclaredField("size");
        Field key1Field = clazz.getDeclaredField("key1");
        Field value1Field = clazz.getDeclaredField("value1");

        sizeField.setAccessible(true);
        key1Field.setAccessible(true);
        value1Field.setAccessible(true);

        sizeField.set(map, 1);
        Object testKey = new Object();
        key1Field.set(map, testKey);
        Object testValue = new Object();
        value1Field.set(map, testValue);

        assertEquals(testValue, map.get(testKey), "Returns value1.");
    }

    @Test
    @DisplayName("Get returns null when size is greater than 0 but key doesn't match any stored keys.")
    void testGetWhenSizeGreaterThan0AndNoMatchingKey() throws Exception {
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = map.getClass();
        Field sizeField = clazz.getDeclaredField("size");

        sizeField.setAccessible(true);

        sizeField.set(map, 3);
        Object nonMatchingKey = new Object();

        assertNull(map.get(nonMatchingKey), "Returns null.");
    }

    @Test
    @DisplayName("Get returns null for a null key when delegateMap is null and size is zero.")
    void testGetReturnsNullWhenDelegateNullAndSizeZero() {
        Flat3Map<Object, Object> map = new Flat3Map<>();
        assertNull(map.get(null), "Returns null.");
    }
}