package org.apache.commons.math3.analysis.interpolation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.analysis.interpolation.TricubicSplineInterpolator;
import org.apache.commons.math3.analysis.interpolation.TricubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;

public class TricubicSplineInterpolator_interpolate_0_3_Test {

    @Test
    @DisplayName("Interpolate with non-ordered xval array throws exception from MathArrays.checkOrder")
    void TC11() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = {2.0, 1.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[] zval = {1.0, 2.0, 3.0};
        double[][][] fval = {
            { {1,2,3}, {4,5,6}, {7,8,9} },
            { {10,11,12}, {13,14,15}, {16,17,18} },
            { {19,20,21}, {22,23,24}, {25,26,27} }
        };
        Assertions.assertThrows(NonMonotonicSequenceException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with non-ordered yval array throws exception from MathArrays.checkOrder")
    void TC12() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {2.0, 1.0, 3.0};
        double[] zval = {1.0, 2.0, 3.0};
        double[][][] fval = {
            { {1,2,3}, {4,5,6}, {7,8,9} },
            { {10,11,12}, {13,14,15}, {16,17,18} },
            { {19,20,21}, {22,23,24}, {25,26,27} }
        };
        Assertions.assertThrows(NonMonotonicSequenceException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with non-ordered zval array throws exception from MathArrays.checkOrder")
    void TC13() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[] zval = {2.0, 1.0, 3.0};
        double[][][] fval = {
            { {1,2,3}, {4,5,6}, {7,8,9} },
            { {10,11,12}, {13,14,15}, {16,17,18} },
            { {19,20,21}, {22,23,24}, {25,26,27} }
        };
        Assertions.assertThrows(NonMonotonicSequenceException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with fval containing negative values processes correctly")
    void TC14() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[] zval = {1.0, 2.0, 3.0};
        double[][][] fval = {
            { {-1,-2,-3}, {-4,-5,-6}, {-7,-8,-9} },
            { {-10,-11,-12}, {-13,-14,-15}, {-16,-17,-18} },
            { {-19,-20,-21}, {-22,-23,-24}, {-25,-26,-27} }
        };
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);
        Assertions.assertNotNull(result);
    }

    @Test
    @DisplayName("Interpolate with fval containing zero values processes correctly")
    void TC15() {
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {1.0, 2.0, 3.0};
        double[] zval = {1.0, 2.0, 3.0};
        double[][][] fval = {
            { {0,0,0}, {0,0,0}, {0,0,0} },
            { {0,0,0}, {0,0,0}, {0,0,0} },
            { {0,0,0}, {0,0,0}, {0,0,0} }
        };
        TricubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, zval, fval);
        Assertions.assertNotNull(result);
    }
}