package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_get_0_2_Test {

    @Test
    @DisplayName("Delegate map is null, key is null, and size=2 with key2=null")
    void TC06() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = new Object();
        value2Field.set(map, value2);

        // WHEN
        Object result = map.get(null);

        // THEN
        assertEquals(value2, result);
    }

    @Test
    @DisplayName("Delegate map is null, key is null, and size=2 with key2 not null")
    void TC07() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object key2 = new Object();
        key2Field.set(map, key2);

        // WHEN
        Object result = map.get(null);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is null, and size=3 with key3=null")
    void TC08() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object value3 = new Object();
        value3Field.set(map, value3);

        // WHEN
        Object result = map.get(null);

        // THEN
        assertEquals(value3, result);
    }

    @Test
    @DisplayName("Delegate map is null, key is null, and size=3 with key3 not null")
    void TC09() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object key3 = new Object();
        key3Field.set(map, key3);

        // WHEN
        Object result = map.get(null);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is not null, size=0")
    void TC10() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        // Use reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        // Assuming existingKey is defined for the test
        Object existingKey = new Object();

        // WHEN
        Object result = map.get(existingKey);

        // THEN
        assertNull(result);
    }
}