import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Stroke;
import java.util.Collections;

import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.ShadowGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CategoryPlotTest {
    
    private CategoryPlot plot;
    
    @BeforeEach
    public void setUp() {
        plot = new CategoryPlot();
    }
    
    @Test
    public void testCloneDefaultPlot() throws CloneNotSupportedException {
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot, clonedPlot);
        assertEquals(plot, clonedPlot);
        assertEquals(plot.hashCode(), clonedPlot.hashCode());
    }
    
    @Test
    public void testCloneWithDomainAxis() throws CloneNotSupportedException {
        CategoryAxis domainAxis = new CategoryAxis("Domain Axis");
        plot.setDomainAxis(0, domainAxis);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getDomainAxis(), clonedPlot.getDomainAxis());
    }
    
    @Test
    public void testCloneWithRangeAxis() throws CloneNotSupportedException {
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setRangeAxis(0, rangeAxis);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getRangeAxis(), clonedPlot.getRangeAxis());
    }
    
    @Test
    public void testCloneWithRenderer() throws CloneNotSupportedException {
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        plot.setRenderer(0, renderer);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getRenderer(), clonedPlot.getRenderer());
    }
    
    @Test
    public void testCloneWithShadowGenerator() throws CloneNotSupportedException {
        ShadowGenerator shadowGenerator = mock(ShadowGenerator.class);
        plot.setShadowGenerator(shadowGenerator);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getShadowGenerator(), clonedPlot.getShadowGenerator());
    }
    
    @Test
    public void testCloneWithDomainGridline() throws CloneNotSupportedException {
        Stroke domainGridlineStroke = new BasicStroke(1.5f);
        Paint domainGridlinePaint = Color.RED;
        plot.setDomainGridlineStroke(domainGridlineStroke);
        plot.setDomainGridlinePaint(domainGridlinePaint);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getDomainGridlineStroke(), clonedPlot.getDomainGridlineStroke());
        assertNotSame(plot.getDomainGridlinePaint(), clonedPlot.getDomainGridlinePaint());
    }
    
    @Test
    public void testCloneWithRangeGridline() throws CloneNotSupportedException {
        Stroke rangeGridlineStroke = new BasicStroke(2.5f);
        Paint rangeGridlinePaint = Color.GREEN;
        plot.setRangeGridlineStroke(rangeGridlineStroke);
        plot.setRangeGridlinePaint(rangeGridlinePaint);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getRangeGridlineStroke(), clonedPlot.getRangeGridlineStroke());
        assertNotSame(plot.getRangeGridlinePaint(), clonedPlot.getRangeGridlinePaint());
    }
    
    @Test
    public void testCloneWithAnnotations() throws CloneNotSupportedException {
        // Assuming a CategoryAnnotation is a proper class we can use
        plot.addAnnotation(mock(org.jfree.chart.annotations.CategoryAnnotation.class));
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getAnnotations(), clonedPlot.getAnnotations());
    }
    
    @Test
    public void testCloneWithLegendItems() throws CloneNotSupportedException {
        LegendItemCollection legendItems = new LegendItemCollection();
        plot.setFixedLegendItems(legendItems);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getFixedLegendItems(), clonedPlot.getFixedLegendItems());
    }
    
    @Test
    public void testCloneWithDifferentRenderingOrder() throws CloneNotSupportedException {
        plot.setDatasetRenderingOrder(org.jfree.chart.util.DatasetRenderingOrder.FORWARD);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotEquals(plot.getDatasetRenderingOrder(), clonedPlot.getDatasetRenderingOrder());
    }

    @Test
    public void testCloneWithDomainAxisLocations() throws CloneNotSupportedException {
        plot.setDomainAxisLocation(0, AxisLocation.TOP_OR_RIGHT);
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getDomainAxisLocation(), clonedPlot.getDomainAxisLocation());
    }

    @Test
    public void testCloneWithFixedAxisSpace() throws CloneNotSupportedException {
        plot.setFixedDomainAxisSpace(new org.jfree.chart.axis.AxisSpace());
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getFixedDomainAxisSpace(), clonedPlot.getFixedDomainAxisSpace());
    }
    
    @Test
    public void testCloneDifferentAnnotations() throws CloneNotSupportedException {
        plot.addAnnotation(mock(org.jfree.chart.annotations.CategoryAnnotation.class));
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        plot.clearAnnotations();
        assertNotEquals(plot.getAnnotations(), clonedPlot.getAnnotations());
    }

    @Test
    public void testCloneWithAxisOffset() throws CloneNotSupportedException {
        plot.setAxisOffset(new RectangleInsets(1.0, 1.0, 1.0, 1.0));
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        assertNotSame(plot.getAxisOffset(), clonedPlot.getAxisOffset());
    }
    
    @Test
    public void testCloneWithValueLabelFont() throws CloneNotSupportedException {
        CategoryPlot clonedPlot = (CategoryPlot) plot.clone();
        Font originalFont = plot.DEFAULT_VALUE_LABEL_FONT;
        Font clonedFont = clonedPlot.DEFAULT_VALUE_LABEL_FONT;
        assertEquals(originalFont, clonedFont);
    }
}