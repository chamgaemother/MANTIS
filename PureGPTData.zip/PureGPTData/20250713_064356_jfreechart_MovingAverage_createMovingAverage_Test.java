import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.MovingAverage;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeriesDataItem;
import org.jfree.chart.util.Args;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.NoSuchElementException;

public class MovingAverageTest {

    @Test
    public void testCreateMovingAverage_ValidInputs() {
        TimeSeries source = new TimeSeries("Test Series");
        source.add(new Day(1, 1, 2020), 1.0);
        source.add(new Day(2, 1, 2020), 2.0);
        source.add(new Day(3, 1, 2020), 3.0);
        source.add(new Day(4, 1, 2020), 4.0);
        source.add(new Day(5, 1, 2020), 5.0);

        TimeSeries result = MovingAverage.createMovingAverage(source, " MA", 3, 0);

        Assertions.assertEquals(5, result.getItemCount());
        Assertions.assertEquals(2.0, result.getValue(0).doubleValue());
        Assertions.assertEquals(3.0, result.getValue(1).doubleValue());
        Assertions.assertEquals(4.0, result.getValue(2).doubleValue());
        Assertions.assertEquals(3.0, result.getValue(3).doubleValue());
        Assertions.assertNull(result.getValue(4));
    }

    @Test
    public void testCreateMovingAverage_NullSource() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            MovingAverage.createMovingAverage(null, " MA", 3, 0);
        });
    }

    @Test
    public void testCreateMovingAverage_PeriodCountLessThanOne() {
        TimeSeries source = new TimeSeries("Test Series");
        source.add(new Day(1, 1, 2020), 1.0);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            MovingAverage.createMovingAverage(source, " MA", 0, 0);
        });
    }

    @Test
    public void testCreateMovingAverage_EmptySource() {
        TimeSeries source = new TimeSeries("Test Series");
        TimeSeries result = MovingAverage.createMovingAverage(source, " MA", 3, 0);

        Assertions.assertEquals(0, result.getItemCount());
    }

    @Test
    public void testCreateMovingAverage_SkipPeriods() {
        TimeSeries source = new TimeSeries("Test Series");
        source.add(new Day(1, 1, 2020), 1.0);
        source.add(new Day(2, 1, 2020), 2.0);
        source.add(new Day(3, 1, 2020), 3.0);
        source.add(new Day(4, 1, 2020), 4.0);

        TimeSeries result = MovingAverage.createMovingAverage(source, " MA", 2, 2);

        Assertions.assertEquals(2, result.getItemCount());
        Assertions.assertEquals(3.5, result.getValue(0).doubleValue());
        Assertions.assertEquals(3.0, result.getValue(1).doubleValue());
    }

    @Test
    public void testCreateMovingAverage_SingleDataPoint() {
        TimeSeries source = new TimeSeries("Test Series");
        source.add(new Day(1, 1, 2020), 1.0);

        TimeSeries result = MovingAverage.createMovingAverage(source, " MA", 1, 0);

        Assertions.assertEquals(1, result.getItemCount());
        Assertions.assertEquals(1.0, result.getValue(0).doubleValue());
    }

    @Test
    public void testCreateMovingAverage_SkipGreaterThanDataPoints() {
        TimeSeries source = new TimeSeries("Test Series");
        source.add(new Day(1, 1, 2020), 1.0);
        source.add(new Day(2, 1, 2020), 2.0);

        TimeSeries result = MovingAverage.createMovingAverage(source, " MA", 1, 3);

        Assertions.assertEquals(0, result.getItemCount());
    }

    @Test
    public void testCreateMovingAverage_ValuesWithNulls() {
        TimeSeries source = new TimeSeries("Test Series");
        source.add(new Day(1, 1, 2020), 1.0);
        source.add(new Day(2, 1, 2020), null);
        source.add(new Day(3, 1, 2020), 3.0);
        source.add(new Day(4, 1, 2020), 4.0);

        TimeSeries result = MovingAverage.createMovingAverage(source, " MA", 2, 0);

        Assertions.assertEquals(4, result.getItemCount());
        Assertions.assertEquals(1.0, result.getValue(0).doubleValue());
        Assertions.assertNull(result.getValue(1));
        Assertions.assertEquals(3.0, result.getValue(2).doubleValue());
        Assertions.assertEquals(3.5, result.getValue(3).doubleValue());
    }
}