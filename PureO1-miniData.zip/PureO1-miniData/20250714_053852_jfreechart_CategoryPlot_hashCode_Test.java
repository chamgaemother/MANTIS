import static org.junit.jupiter.api.Assertions.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.ui.RectangleInsets;
import org.junit.jupiter.api.Test;

public class CategoryPlotTest {

    @Test
    public void testHashCode_AllFieldsNonNullBooleansTrue() {
        CategoryPlot plot = new CategoryPlot();
        plot.setOrientation(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        plot.setAxisOffset(new RectangleInsets(5, 5, 5, 5));
        
        mapDomainAxes(plot, 1);
        mapRangeAxes(plot, 1);
        mapDatasets(plot, 1);
        mapRenderers(plot, 1);
        
        plot.setRenderingOrder(org.jfree.chart.plot.DatasetRenderingOrder.REVERSE);
        plot.setColumnRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        plot.setRowRenderingOrder(org.jfree.chart.util.SortOrder.ASCENDING);
        
        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePosition(org.jfree.chart.axis.CategoryAnchor.MIDDLE);
        plot.setDomainGridlineStroke(new BasicStroke(1.0f));
        plot.setDomainGridlinePaint(Color.BLUE);
        
        plot.setRangeZeroBaselineVisible(true);
        plot.setRangeZeroBaselineStroke(new BasicStroke(1.0f));
        plot.setRangeZeroBaselinePaint(Color.RED);
        
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlineStroke(new BasicStroke(1.0f));
        plot.setRangeGridlinePaint(Color.GREEN);
        
        plot.setRangeMinorGridlinesVisible(true);
        plot.setRangeMinorGridlineStroke(new BasicStroke(0.5f));
        plot.setRangeMinorGridlinePaint(Color.YELLOW);
        
        plot.setAnchorValue(10.0);
        plot.setCrosshairDatasetIndex(2);
        
        plot.setDomainCrosshairVisible(true);
        plot.setDomainCrosshairRowKey("Row1");
        plot.setDomainCrosshairColumnKey("Column1");
        plot.setDomainCrosshairStroke(new BasicStroke(2.0f));
        plot.setDomainCrosshairPaint(Color.MAGENTA);
        
        plot.setRangeCrosshairVisible(true);
        plot.setRangeCrosshairValue(20.0);
        plot.setRangeCrosshairStroke(new BasicStroke(2.0f));
        plot.setRangeCrosshairPaint(Color.ORANGE);
        plot.setRangeCrosshairLockedOnData(true);
        
        plot.setForegroundDomainMarkers(new HashMap<>());
        plot.setBackgroundDomainMarkers(new HashMap<>());
        plot.setForegroundRangeMarkers(new HashMap<>());
        plot.setBackgroundRangeMarkers(new HashMap<>());
        
        plot.setAnnotations(new java.util.ArrayList<>());
        plot.setWeight(3);
        
        plot.setFixedDomainAxisSpace(new org.jfree.chart.axis.AxisSpace());
        plot.setFixedRangeAxisSpace(new org.jfree.chart.axis.AxisSpace());
        
        plot.setFixedLegendItems(new org.jfree.chart.LegendItemCollection());
        
        plot.setRangePannable(true);
        plot.setShadowGenerator(null);
        
        int expectedHash = computeExpectedHash(plot);
        assertEquals(expectedHash, plot.hashCode());
    }
    
    @Test
    public void testHashCode_SomeFieldsNullBooleansFalse() {
        CategoryPlot plot = new CategoryPlot();
        plot.setOrientation(null);
        plot.setAxisOffset(null);
        
        mapDomainAxes(plot, 0);
        mapRangeAxes(plot, 0);
        mapDatasets(plot, 0);
        mapRenderers(plot, 0);
        
        plot.setRenderingOrder(null);
        plot.setColumnRenderingOrder(null);
        plot.setRowRenderingOrder(null);
        
        plot.setDomainGridlinesVisible(false);
        plot.setDomainGridlinePosition(null);
        plot.setDomainGridlineStroke(null);
        plot.setDomainGridlinePaint(null);
        
        plot.setRangeZeroBaselineVisible(false);
        plot.setRangeZeroBaselineStroke(null);
        plot.setRangeZeroBaselinePaint(null);
        
        plot.setRangeGridlinesVisible(false);
        plot.setRangeGridlineStroke(null);
        plot.setRangeGridlinePaint(null);
        
        plot.setRangeMinorGridlinesVisible(false);
        plot.setRangeMinorGridlineStroke(null);
        plot.setRangeMinorGridlinePaint(null);
        
        plot.setAnchorValue(0.0);
        plot.setCrosshairDatasetIndex(-1);
        
        plot.setDomainCrosshairVisible(false);
        plot.setDomainCrosshairRowKey(null);
        plot.setDomainCrosshairColumnKey(null);
        plot.setDomainCrosshairStroke(null);
        plot.setDomainCrosshairPaint(null);
        
        plot.setRangeCrosshairVisible(false);
        plot.setRangeCrosshairValue(Double.NaN);
        plot.setRangeCrosshairStroke(null);
        plot.setRangeCrosshairPaint(null);
        plot.setRangeCrosshairLockedOnData(false);
        
        plot.setForegroundDomainMarkers(null);
        plot.setBackgroundDomainMarkers(null);
        plot.setForegroundRangeMarkers(null);
        plot.setBackgroundRangeMarkers(null);
        
        plot.setAnnotations(null);
        plot.setWeight(0);
        
        plot.setFixedDomainAxisSpace(null);
        plot.setFixedRangeAxisSpace(null);
        
        plot.setFixedLegendItems(null);
        
        plot.setRangePannable(false);
        plot.setShadowGenerator(null);
        
        int expectedHash = computeExpectedHash(plot);
        assertEquals(expectedHash, plot.hashCode());
    }
    
    @Test
    public void testHashCode_DifferentInstancesSameState() {
        CategoryPlot plot1 = new CategoryPlot();
        plot1.setOrientation(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        plot1.setAxisOffset(new RectangleInsets(10, 10, 10, 10));
        
        CategoryPlot plot2 = new CategoryPlot();
        plot2.setOrientation(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        plot2.setAxisOffset(new RectangleInsets(10, 10, 10, 10));
        
        assertEquals(plot1.hashCode(), plot2.hashCode());
    }
    
    @Test
    public void testHashCode_DifferentInstancesDifferentState() {
        CategoryPlot plot1 = new CategoryPlot();
        plot1.setOrientation(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        
        CategoryPlot plot2 = new CategoryPlot();
        plot2.setOrientation(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        
        assertNotEquals(plot1.hashCode(), plot2.hashCode());
    }
    
    @Test
    public void testHashCode_AllFieldsNullAndFalse() {
        CategoryPlot plot = new CategoryPlot();
        // Manually set fields to null or false where possible
        plot.setOrientation(null);
        plot.setAxisOffset(null);
        
        plot.setDomainCrosshairVisible(false);
        plot.setRangeCrosshairVisible(false);
        plot.setDrawSharedDomainAxis(false);
        plot.setRangePannable(false);
        
        // Nullify all axes, datasets, renderers, markers, etc.
        plot.setDomainAxis(0, null);
        plot.setRangeAxis(0, null);
        plot.setRenderer(0, null);
        plot.setDataset(0, null);
        
        plot.setFixedDomainAxisSpace(null);
        plot.setFixedRangeAxisSpace(null);
        plot.setFixedLegendItems(null);
        
        plot.setAnnotations(null);
        plot.setForegroundDomainMarkers(null);
        plot.setBackgroundDomainMarkers(null);
        plot.setForegroundRangeMarkers(null);
        plot.setBackgroundRangeMarkers(null);
        
        plot.setCrosshairDatasetIndex(-1);
        plot.setAnchorValue(Double.NaN);
        plot.setRangeCrosshairValue(Double.NaN);
        plot.setRangeCrosshairLockedOnData(false);
        
        int expectedHash = computeExpectedHash(plot);
        assertEquals(expectedHash, plot.hashCode());
    }
    
    private void mapDomainAxes(CategoryPlot plot, int count) {
        for (int i = 0; i < count; i++) {
            plot.setDomainAxis(i, new CategoryAxis("Domain " + i));
        }
    }
    
    private void mapRangeAxes(CategoryPlot plot, int count) {
        for (int i = 0; i < count; i++) {
            plot.setRangeAxis(i, new ValueAxis("Range " + i) {
                @Override
                public void configure() {
                }

                @Override
                public java.awt.geom.Rectangle2D reserveSpace(java.awt.Graphics2D g2, CategoryPlot plot, java.awt.geom.Rectangle2D plotArea, RectangleEdge edge, AxisSpace space) {
                    return space;
                }

                @Override
                public double java2DToValue(double java2D, java.awt.geom.Rectangle2D area, RectangleEdge edge) {
                    return 0;
                }

                @Override
                public void resizeRange(double percent) {
                }

                @Override
                public void resizeRange2(double factor, double anchorValue) {
                }

                @Override
                public void zoomRange(double lowerPercent, double upperPercent) {
                }
            });
        }
    }
    
    private void mapDatasets(CategoryPlot plot, int count) {
        for (int i = 0; i < count; i++) {
            plot.setDataset(i, new org.jfree.data.category.DefaultCategoryDataset());
        }
    }
    
    private void mapRenderers(CategoryPlot plot, int count) {
        for (int i = 0; i < count; i++) {
            plot.setRenderer(i, new CategoryItemRenderer() {
                @Override
                public CategoryItemRendererState initialise(java.awt.Graphics2D g2, java.awt.geom.Rectangle2D dataArea, CategoryPlot plot, int rendererIndex, org.jfree.chart.plot.PlotRenderingInfo info) {
                    return new CategoryItemRendererState();
                }

                @Override
                public void drawItem(java.awt.Graphics2D g2, CategoryItemRendererState state, java.awt.geom.Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis, ValueAxis rangeAxis, org.jfree.data.category.CategoryDataset dataset, int row, int column, int pass) {
                }

                @Override
                public void drawBackground(java.awt.Graphics2D g2, CategoryPlot plot, java.awt.geom.Rectangle2D dataArea) {
                }

                @Override
                public void drawRangeGridline(java.awt.Graphics2D g2, CategoryPlot plot, java.awt.geom.Rectangle2D dataArea, double value, Paint paint, Stroke stroke) {
                }

                @Override
                public void drawRangeLine(java.awt.Graphics2D g2, CategoryPlot plot, ValueAxis axis, java.awt.geom.Rectangle2D dataArea, double value, Paint paint, Stroke stroke) {
                }

                @Override
                public void drawDomainMarker(java.awt.Graphics2D g2, CategoryPlot plot, CategoryAxis axis, CategoryMarker marker, java.awt.geom.Rectangle2D dataArea) {
                }

                @Override
                public void drawRangeMarker(java.awt.Graphics2D g2, CategoryPlot plot, ValueAxis axis, Marker marker, java.awt.geom.Rectangle2D dataArea) {
                }

                @Override
                public void drawOutline(java.awt.Graphics2D g2, CategoryPlot plot, java.awt.geom.Rectangle2D dataArea) {
                }

                @Override
                public org.jfree.chart.LegendItemCollection getLegendItems() {
                    return new org.jfree.chart.LegendItemCollection();
                }
            });
        }
    }
    
    private int computeExpectedHash(CategoryPlot plot) {
        int hash = plot.getClass().getSuperclass().hashCode();
        hash = 71 * hash + java.util.Objects.hashCode(plot.orientation);
        hash = 71 * hash + java.util.Objects.hashCode(plot.axisOffset);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainAxes);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainAxisLocations);
        hash = 71 * hash + (plot.drawSharedDomainAxis ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeAxes);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeAxisLocations);
        hash = 71 * hash + java.util.Objects.hashCode(plot.datasets);
        hash = 71 * hash + java.util.Objects.hashCode(plot.datasetToDomainAxesMap);
        hash = 71 * hash + java.util.Objects.hashCode(plot.datasetToRangeAxesMap);
        hash = 71 * hash + java.util.Objects.hashCode(plot.renderers);
        hash = 71 * hash + java.util.Objects.hashCode(plot.renderingOrder);
        hash = 71 * hash + java.util.Objects.hashCode(plot.columnRenderingOrder);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rowRenderingOrder);
        hash = 71 * hash + (plot.domainGridlinesVisible ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainGridlinePosition);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainGridlineStroke);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainGridlinePaint);
        hash = 71 * hash + (plot.rangeZeroBaselineVisible ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeZeroBaselineStroke);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeZeroBaselinePaint);
        hash = 71 * hash + (plot.rangeGridlinesVisible ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeGridlineStroke);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeGridlinePaint);
        hash = 71 * hash + (plot.rangeMinorGridlinesVisible ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeMinorGridlineStroke);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeMinorGridlinePaint);
        hash = 71 * hash + Double.hashCode(plot.anchorValue);
        hash = 71 * hash + plot.crosshairDatasetIndex;
        hash = 71 * hash + (plot.domainCrosshairVisible ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainCrosshairRowKey);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainCrosshairColumnKey);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainCrosshairStroke);
        hash = 71 * hash + java.util.Objects.hashCode(plot.domainCrosshairPaint);
        hash = 71 * hash + (plot.rangeCrosshairVisible ? 1 : 0);
        hash = 71 * hash + Double.hashCode(plot.rangeCrosshairValue);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeCrosshairStroke);
        hash = 71 * hash + java.util.Objects.hashCode(plot.rangeCrosshairPaint);
        hash = 71 * hash + (plot.rangeCrosshairLockedOnData ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.foregroundDomainMarkers);
        hash = 71 * hash + java.util.Objects.hashCode(plot.backgroundDomainMarkers);
        hash = 71 * hash + java.util.Objects.hashCode(plot.foregroundRangeMarkers);
        hash = 71 * hash + java.util.Objects.hashCode(plot.backgroundRangeMarkers);
        hash = 71 * hash + java.util.Objects.hashCode(plot.annotations);
        hash = 71 * hash + plot.weight;
        hash = 71 * hash + java.util.Objects.hashCode(plot.fixedDomainAxisSpace);
        hash = 71 * hash + java.util.Objects.hashCode(plot.fixedRangeAxisSpace);
        hash = 71 * hash + java.util.Objects.hashCode(plot.fixedLegendItems);
        hash = 71 * hash + (plot.rangePannable ? 1 : 0);
        hash = 71 * hash + java.util.Objects.hashCode(plot.shadowGenerator);
        return hash;
    }
}