import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.json.UTF8StreamJsonParser;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UTF8StreamJsonParserTest {

    private ByteArrayBuilder byteArrayBuilder;
    private ByteQuadsCanonicalizer canonicalizer;
    private SerializableString testName;
    private JsonFactory jsonFactory;

    @BeforeEach
    public void setUp() {
        byteArrayBuilder = new ByteArrayBuilder(1024);
        canonicalizer = ByteQuadsCanonicalizer.createRoot();
        testName = mock(SerializableString.class);
        jsonFactory = new JsonFactory();
    }

    @Test
    public void testNextFieldNameGivenExactMatch() throws IOException {
        String json = "{\"name\":\"value\"}";
        try (JsonParser parser = createParser(json)) {
            parser.nextToken(); // Start Object
            when(testName.asQuotedUTF8()).thenReturn("\"name\"".getBytes(StandardCharsets.UTF_8));
            when(testName.getValue()).thenReturn("name");
            assertTrue(parser.nextFieldName(testName));
        }
    }

    @Test
    public void testNextFieldNameGivenMismatchDueToSkippedComma() throws IOException {
        String json = "{ ,\"name\":\"value\"}";
        try (JsonParser parser = createParser(json)) {
            parser.nextToken(); // Start Object
            when(testName.asQuotedUTF8()).thenReturn("\"name\"".getBytes(StandardCharsets.UTF_8));
            when(testName.getValue()).thenReturn("name");
            assertFalse(parser.nextFieldName(testName));
        }
    }

    @Test
    public void testNextFieldNameWithTrailingComma() throws IOException {
        String json = "{\"name\",}";
        try (JsonParser parser = createParser(json)) {
            parser.nextToken(); // Start Object
            when(testName.asQuotedUTF8()).thenReturn("\"name\"".getBytes(StandardCharsets.UTF_8));
            when(testName.getValue()).thenReturn("name");
            assertFalse(parser.nextFieldName(testName));
        }
    }

    @Test
    public void testNextFieldNameNoMatch() throws IOException {
        String json = "{\"foo\": \"bar\"}";
        try (JsonParser parser = createParser(json)) {
            parser.nextToken(); // Start Object
            when(testName.asQuotedUTF8()).thenReturn("\"name\"".getBytes(StandardCharsets.UTF_8));
            when(testName.getValue()).thenReturn("name");
            assertFalse(parser.nextFieldName(testName)); // 'foo' doesn't match 'name'
        }
    }

    @Test
    public void testNextFieldNameEndObject() throws IOException {
        String json = "{\"name\": \"value\"}";
        try (JsonParser parser = createParser(json)) {
            parser.nextToken(); // Start Object
            parser.nextToken(); // Field Name
            parser.nextToken(); // String Value
            parser.nextToken(); // End Object
            when(testName.asQuotedUTF8()).thenReturn("\"name\"".getBytes(StandardCharsets.UTF_8));
            when(testName.getValue()).thenReturn("name");
            assertFalse(parser.nextFieldName(testName)); // At end of object
        }
    }

    private JsonParser createParser(String json) throws IOException {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        return new UTF8StreamJsonParser(null, 0, inputStream, null, canonicalizer, inputStream.readAllBytes(), 0, 0, 0, false);
    }
}