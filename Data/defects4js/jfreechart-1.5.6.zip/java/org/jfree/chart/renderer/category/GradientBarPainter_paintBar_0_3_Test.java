package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class GradientBarPainter_paintBar_0_3_Test {

    @Test
    @DisplayName("itemPaint is neither Color nor GradientPaint, alpha == 0")
    void TC11_paintBar_NoPaintingPerformed() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        Paint otherPaint = mock(Paint.class);
        
        // Mocking renderer to return a non-Color and non-GradientPaint with alpha = 0
        when(renderer.getItemPaint(Mockito.anyInt(), Mockito.anyInt())).thenReturn(otherPaint);
        
        // Creating a custom Color with alpha = 0 by extending Color
        Color transparentColor = new Color(0, 0, 255, 0); // Blue with alpha 0
        when(otherPaint instanceof Color).thenReturn(false);
        when(otherPaint instanceof GradientPaint).thenReturn(false);
        
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleEdge base = RectangleEdge.LEFT;
        GradientBarPainter painter = new GradientBarPainter();
        
        // Using reflection to set private fields g1, g2, g3 if necessary
        // Assuming g1, g2, g3 are doubles
        setPrivateField(painter, "g1", 0.3);
        setPrivateField(painter, "g2", 0.5);
        setPrivateField(painter, "g3", 0.7);
        
        int row = 0;
        int column = 0;
        
        // WHEN
        painter.paintBar(g2, renderer, row, column, bar, base);
        
        // THEN
        // Verify that no painting methods are called
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("itemPaint is GradientPaint, alpha != 0, base is LEFT, isDrawBarOutline is true, outline paint is null")
    void TC12_paintBar_GradientPaint_NoOutline() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        BarRenderer renderer = mock(BarRenderer.class);
        
        // Creating a GradientPaint with alpha != 0
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 10f, 10f, Color.BLUE);
        when(renderer.getItemPaint(Mockito.anyInt(), Mockito.anyInt())).thenReturn(gradientPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        when(renderer.getItemOutlinePaint(Mockito.anyInt(), Mockito.anyInt())).thenReturn(null);
        
        Rectangle2D bar = new Rectangle2D.Double(0, 0, 20, 20);
        RectangleEdge base = RectangleEdge.LEFT;
        GradientBarPainter painter = new GradientBarPainter();
        
        // Using reflection to set private fields g1, g2, g3 if necessary
        setPrivateField(painter, "g1", 0.25);
        setPrivateField(painter, "g2", 0.5);
        setPrivateField(painter, "g3", 0.75);
        
        int row = 1;
        int column = 1;
        
        // WHEN
        painter.paintBar(g2, renderer, row, column, bar, base);
        
        // THEN
        // Verify that setPaint and fill are called for each region
        verify(g2, atLeastOnce()).setPaint(any(GradientPaint.class));
        verify(g2, atLeastOnce()).fill(any(Rectangle2D.class));
        // Verify that draw is not called since outline paint is null
        verify(g2, never()).draw(any());
    }
    
    /**
     * Utility method to set private fields via reflection.
     */
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = null;
        Class<?> clazz = target.getClass();
        while (clazz != null) {
            try {
                field = clazz.getDeclaredField(fieldName);
                break;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        if (field == null) {
            throw new NoSuchFieldException("Field '" + fieldName + "' not found in " + target.getClass());
        }
        field.setAccessible(true);
        field.set(target, value);
    }
}