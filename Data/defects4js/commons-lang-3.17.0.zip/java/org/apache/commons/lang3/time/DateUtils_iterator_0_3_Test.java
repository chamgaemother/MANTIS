package org.apache.commons.lang3.time;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

public class DateUtils_iterator_0_3_Test {

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_CENTER and multiple loop iterations")
    void TC11() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        // Set calendar to a specific date that requires multiple adjustments
        calendar.set(2023, Calendar.MARCH, 10); // Example date
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // THEN
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Example assertion: iterate through expected number of dates
        int count = 0;
        while (iterator.hasNext()) {
            Calendar cal = iterator.next();
            Date date = cal.getTime();
            Assertions.assertNotNull(date, "Date should not be null");
            count++;
        }
        Assertions.assertTrue(count > 1, "Iterator should have multiple iterations");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_MONTH_MONDAY and startCutoff adjustment needed")
    void TC12() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        // Set calendar to a specific date that requires startCutoff adjustment
        calendar.set(2023, Calendar.APRIL, 5); // Example date
        int rangeStyle = DateUtils.RANGE_MONTH_MONDAY;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // THEN
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Example assertion: iterate and verify dates start on Monday
        if (iterator.hasNext()) {
            Calendar firstCal = iterator.next();
            Assertions.assertEquals(Calendar.MONDAY, firstCal.get(Calendar.DAY_OF_WEEK), "Start date should be Monday");
        }
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_MONTH_SUNDAY and endCutoff adjustment needed")
    void TC13() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        // Set calendar to a specific date that requires endCutoff adjustment
        calendar.set(2023, Calendar.MAY, 20); // Example date
        int rangeStyle = DateUtils.RANGE_MONTH_SUNDAY;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // THEN
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Example assertion: iterate and verify dates end on Sunday
        Calendar lastCal = null;
        while (iterator.hasNext()) {
            lastCal = iterator.next();
        }
        Assertions.assertNotNull(lastCal, "Last date should not be null");
        Assertions.assertEquals(Calendar.SUNDAY, lastCal.get(Calendar.DAY_OF_WEEK), "End date should be Sunday");
    }

    @Test
    @DisplayName("iterator with null calendar throws NullPointerException")
    void TC14() {
        // GIVEN
        Calendar calendar = null;
        int rangeStyle = DateUtils.RANGE_WEEK_SUNDAY;

        // WHEN & THEN
        NullPointerException exception = Assertions.assertThrows(NullPointerException.class, () -> {
            DateUtils.iterator(calendar, rangeStyle);
        }, "Expected iterator to throw NullPointerException when calendar is null");

        Assertions.assertEquals("calendar", exception.getMessage(), "Exception message should be 'calendar'");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_SUNDAY and multiple loop iterations")
    void TC15() {
        // GIVEN
        Calendar calendar = Calendar.getInstance();
        // Set calendar to a specific date that requires multiple end adjustments
        calendar.set(2023, Calendar.JUNE, 15); // Example date
        int rangeStyle = DateUtils.RANGE_WEEK_SUNDAY;

        // WHEN
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // THEN
        Assertions.assertNotNull(iterator, "Iterator should not be null");

        // Example assertion: iterate through expected number of dates
        int count = 0;
        while (iterator.hasNext()) {
            Calendar cal = iterator.next();
            Date date = cal.getTime();
            Assertions.assertNotNull(date, "Date should not be null");
            count++;
        }
        Assertions.assertTrue(count > 1, "Iterator should have multiple iterations");
    }
}