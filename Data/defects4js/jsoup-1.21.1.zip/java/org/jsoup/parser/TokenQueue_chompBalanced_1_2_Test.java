package org.jsoup.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TokenQueue_chompBalanced_1_2_Test {

    @Test
    @DisplayName("ChompBalanced with multiple escape sequences and nested quotes handles input correctly")
    void TC29_ChompBalanced_MultipleEscapes_NestedQuotes() throws Exception {
        // Given
        TokenQueue queue = new TokenQueue("\"nested\\\"content\"");
        
        // When
        String result = queue.chompBalanced('"', '"');
        
        // Then
        assertEquals("nested\\\"content", result);
    }

    @Test
    @DisplayName("ChompBalanced with nested different open and close characters handles correctly")
    void TC30_ChompBalanced_NestedDifferentPairs() throws Exception {
        // Given
        TokenQueue queue = new TokenQueue("{{}}}");
        
        // When
        String result = queue.chompBalanced('{', '}');
        
        // Then
        assertEquals("{{}}", result);
    }

    @Test
    @DisplayName("ChompBalanced with open character but missing close character throws exception")
    void TC31_ChompBalanced_OpenMissingClose_ThrowsException() {
        // Given
        TokenQueue queue = new TokenQueue("{{a");
        
        // When & Then
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            queue.chompBalanced('{', '}');
        });
        assertTrue(exception.getMessage().contains("Did not find balanced marker"));
    }

    @Test
    @DisplayName("ChompBalanced with unmatched closing character before any open character throws exception")
    void TC32_ChompBalanced_UnmatchedClosing_ThrowsException() {
        // Given
        TokenQueue queue = new TokenQueue("}a{");
        
        // When & Then
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            queue.chompBalanced('{', '}');
        });
        assertTrue(exception.getMessage().contains("Did not find balanced marker"));
    }

    @Test
    @DisplayName("ChompBalanced with consecutive open and close characters handles correctly")
    void TC33_ChompBalanced_ConsecutivePairs() throws Exception {
        // Given
        TokenQueue queue = new TokenQueue("()()");
        
        // When
        String result = queue.chompBalanced('(', ')');
        
        // Then
        assertEquals("()", result);
    }
}