package org.jfree.data.general;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.Range;

/**
 * JUnit 5 test class for DatasetUtils.iterateRangeBounds method targeting XYDataset.
 */
public class DatasetUtils_iterateRangeBounds_1_1_Test {

    /**
     * TC13: iterateRangeBounds with includeInterval=true
     *  and XYDataset having multiple series and all Y values valid,
     *  verifying correct minimum and maximum.
     */
    @Test
    @DisplayName("iterateRangeBounds with includeInterval=true and XYDataset having multiple series and all Y values valid, verifying correct min and max")
    public void TC13() {
        // Arrange
        DefaultXYDataset dataset = new DefaultXYDataset();
        double[][] data1 = {{1.0, 2.0, 3.0}, {10.0, 20.0, 15.0}};
        double[][] data2 = {{1.0, 2.0, 3.0}, {5.0, 25.0, 12.0}};
        dataset.addSeries("S1", data1);
        dataset.addSeries("S2", data2);
        boolean includeInterval = true;

        // Act
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);

        // Assert
        assertNotNull(result, "The resulting Range should not be null.");
        assertEquals(5.0, result.getLowerBound(), 0.0001, "The lower bound should be 5.0.");
        assertEquals(25.0, result.getUpperBound(), 0.0001, "The upper bound should be 25.0.");
    }

    /**
     * TC14: iterateRangeBounds with includeInterval=true
     * and XYDataset having some Y values as NaN,
     * verifying correct minimum and maximum excluding NaNs.
     */
    @Test
    @DisplayName("iterateRangeBounds with includeInterval=true and XYDataset having some Y values as NaN, verifying correct min and max excluding NaNs")
    public void TC14() {
        // Arrange
        DefaultXYDataset dataset = new DefaultXYDataset();
        double[][] data1 = {{1.0, 2.0, 3.0}, {10.0, Double.NaN, 15.0}};
        double[][] data2 = {{1.0, 2.0, 3.0}, {5.0, 7.0, Double.NaN}};
        dataset.addSeries("S1", data1);
        dataset.addSeries("S2", data2);
        boolean includeInterval = true;

        // Act
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);

        // Assert
        assertNotNull(result, "The resulting Range should not be null.");
        assertEquals(5.0, result.getLowerBound(), 0.0001, "The lower bound should be 5.0.");
        assertEquals(15.0, result.getUpperBound(), 0.0001, "The upper bound should be 15.0.");
    }

    /**
     * TC15: iterateRangeBounds with includeInterval=true
     * and XYDataset having negative Y values, verifying correct min and max.
     */
    @Test
    @DisplayName("iterateRangeBounds with includeInterval=true and XYDataset having negative Y values, verifying correct min and max")
    public void TC15() {
        // Arrange
        DefaultXYDataset dataset = new DefaultXYDataset();
        double[][] data = {{1.0, 2.0}, {-10.0, -25.0}};
        dataset.addSeries("S1", data);
        boolean includeInterval = true;

        // Act
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);

        // Assert
        assertNotNull(result, "The resulting Range should not be null.");
        assertEquals(-25.0, result.getLowerBound(), 0.0001, "The lower bound should be -25.0.");
        assertEquals(-10.0, result.getUpperBound(), 0.0001, "The upper bound should be -10.0.");
    }

    /**
     * TC16: iterateRangeBounds with includeInterval=true
     * and XYDataset having all Y values as NaN, expecting null return.
     */
    @Test
    @DisplayName("iterateRangeBounds with includeInterval=true and XYDataset having all Y values as NaN, expecting null return")
    public void TC16() {
        // Arrange
        DefaultXYDataset dataset = new DefaultXYDataset();
        double[][] data1 = {{1.0, 2.0}, {Double.NaN, Double.NaN}};
        double[][] data2 = {{1.0, 2.0}, {Double.NaN, Double.NaN}};
        dataset.addSeries("S1", data1);
        dataset.addSeries("S2", data2);
        boolean includeInterval = true;

        // Act
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);

        // Assert
        assertNull(result, "The resulting Range should be null when all Y values are NaN.");
    }
}