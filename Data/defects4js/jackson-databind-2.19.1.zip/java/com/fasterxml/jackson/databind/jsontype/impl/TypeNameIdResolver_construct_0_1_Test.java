package com.fasterxml.jackson.databind.jsontype.impl;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import java.util.Collection;
import java.util.Collections;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;
import java.lang.reflect.Field;

public class TypeNameIdResolver_construct_0_1_Test {

    // Dummy class for testing purposes
    private static class ExampleClass {}

    @Test
    @DisplayName("Throws IllegalArgumentException when forSer equals forDeser")
    void TC01_constructThrowsExceptionWhenForSerEqualsForDeser() {
        // Given
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        JavaType baseType = Mockito.mock(JavaType.class);
        Collection<NamedType> subtypes = null;
        boolean forSer = true;
        boolean forDeser = true;

        // When & Then
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
        });
    }

    @Test
    @DisplayName("Construct with forSer=true, forDeser=false and null subtypes")
    void TC02_constructForSerTrueForDeserFalseNullSubtypes() throws Exception {
        // Given
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        JavaType baseType = Mockito.mock(JavaType.class);
        Collection<NamedType> subtypes = null;
        boolean forSer = true;
        boolean forDeser = false;

        // When
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // Then
        // Access typeToId via reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("typeToId");
        typeToIdField.setAccessible(true);
        @SuppressWarnings("unchecked")
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        // Access idToType via reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("idToType");
        idToTypeField.setAccessible(true);
        @SuppressWarnings("unchecked")
        HashMap<String, JavaType> idToType = (HashMap<String, JavaType>) idToTypeField.get(resolver);

        Assertions.assertNotNull(typeToId, "typeToId should be initialized");
        Assertions.assertNull(idToType, "idToType should be null");
    }

    @Test
    @DisplayName("Construct with forSer=true, forDeser=false and empty subtypes")
    void TC03_constructForSerTrueForDeserFalseEmptySubtypes() throws Exception {
        // Given
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        JavaType baseType = Mockito.mock(JavaType.class);
        Collection<NamedType> subtypes = new ArrayList<>();
        boolean forSer = true;
        boolean forDeser = false;

        // When
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // Then
        // Access typeToId via reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("typeToId");
        typeToIdField.setAccessible(true);
        @SuppressWarnings("unchecked")
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        // Access idToType via reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("idToType");
        idToTypeField.setAccessible(true);
        @SuppressWarnings("unchecked")
        HashMap<String, JavaType> idToType = (HashMap<String, JavaType>) idToTypeField.get(resolver);

        Assertions.assertNotNull(typeToId, "typeToId should be initialized");
        Assertions.assertTrue(typeToId.isEmpty(), "typeToId should be empty");
        Assertions.assertNull(idToType, "idToType should be null");
    }

    @Test
    @DisplayName("Construct with forSer=true, forDeser=false and one subtype with a defined name")
    void TC04_constructForSerTrueForDeserFalseOneSubtypeWithName() throws Exception {
        // Given
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        JavaType baseType = Mockito.mock(JavaType.class);
        NamedType subtype = new NamedType(ExampleClass.class, "ExampleName");
        Collection<NamedType> subtypes = Arrays.asList(subtype);
        boolean forSer = true;
        boolean forDeser = false;

        // When
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // Then
        // Access typeToId via reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("typeToId");
        typeToIdField.setAccessible(true);
        @SuppressWarnings("unchecked")
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        // Access idToType via reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("idToType");
        idToTypeField.setAccessible(true);
        @SuppressWarnings("unchecked")
        HashMap<String, JavaType> idToType = (HashMap<String, JavaType>) idToTypeField.get(resolver);

        Assertions.assertNotNull(typeToId, "typeToId should be initialized");
        Assertions.assertEquals(1, typeToId.size(), "typeToId should contain one entry");
        Assertions.assertEquals("ExampleName", typeToId.get(ExampleClass.class.getName()), "typeToId should contain the correct mapping");
        Assertions.assertNull(idToType, "idToType should be null");
    }

    @Test
    @DisplayName("Construct with forSer=true, forDeser=false and one subtype without a defined name")
    void TC05_constructForSerTrueForDeserFalseOneSubtypeWithoutName() throws Exception {
        // Given
        MapperConfig<?> config = Mockito.mock(MapperConfig.class);
        JavaType baseType = Mockito.mock(JavaType.class);
        NamedType subtype = new NamedType(ExampleClass.class);
        Collection<NamedType> subtypes = Arrays.asList(subtype);
        boolean forSer = true;
        boolean forDeser = false;

        // When
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // Then
        // Access typeToId via reflection
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("typeToId");
        typeToIdField.setAccessible(true);
        @SuppressWarnings("unchecked")
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        // Access idToType via reflection
        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("idToType");
        idToTypeField.setAccessible(true);
        @SuppressWarnings("unchecked")
        HashMap<String, JavaType> idToType = (HashMap<String, JavaType>) idToTypeField.get(resolver);

        Assertions.assertNotNull(typeToId, "typeToId should be initialized");
        Assertions.assertEquals(1, typeToId.size(), "typeToId should contain one entry");
        Assertions.assertEquals("ExampleClass", typeToId.get(ExampleClass.class.getName()), "typeToId should contain the default mapping");
        Assertions.assertNull(idToType, "idToType should be null");
    }
}