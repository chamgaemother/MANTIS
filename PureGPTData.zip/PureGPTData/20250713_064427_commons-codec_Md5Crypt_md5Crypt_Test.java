import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

public class Md5CryptTest {

    @ParameterizedTest
    @CsvSource({
        "'password', '$1$saltsalt$', '$1$'",
        "'password', '$apr1$saltsalt$', '$apr1$'",
        "'password', null, '$1$'",  // Testing generation of random salt
        "'password', '$1$saltsalt$', '$apr1$'",  // Valid salt, wrong prefix
        "'password', '$$$', '$1$'",  // Invalid salt
        "'', '$1$saltsalt$', '$1$'",  // Empty password
        "'password', '$1$sa', '$1$'"  // Short salt
    })
    void testMd5CryptDifferentInputs(String key, String salt, String prefix) {
        byte[] keyBytes = key.getBytes(org.apache.commons.codec.Charsets.UTF_8);
        if (salt == null) {
            assertDoesNotThrow(() -> {
                String result = Md5Crypt.md5Crypt(keyBytes, null, prefix);
                assertNotNull(result);
                assertTrue(result.startsWith(prefix));
            });
        } else {
            if ("$$$".equals(salt)) {
                assertThrows(IllegalArgumentException.class, () -> Md5Crypt.md5Crypt(keyBytes, salt, prefix));
            } else {
                assertDoesNotThrow(() -> {
                    String result = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
                    assertNotNull(result);
                    assertTrue(result.startsWith(prefix));
                });
            }
        }
    }

    @Test
    void testMd5CryptNullKeyBytes() {
        assertThrows(NullPointerException.class, () -> Md5Crypt.md5Crypt(null, "$1$salt$", "$1$"));
    }

    @Test
    void testMd5CryptMismatchedPrefix() {
        byte[] keyBytes = "password".getBytes(org.apache.commons.codec.Charsets.UTF_8);
        String result = Md5Crypt.md5Crypt(keyBytes, "$1$saltsalt$", "$apr1$");
        assertNotNull(result);
        assertTrue(result.startsWith("$1$")); // Falls back to prefix from salt
    }

    @Test
    void testMd5CryptValidSingleCharacterSalt() {
        byte[] keyBytes = "password".getBytes(org.apache.commons.codec.Charsets.UTF_8);
        String result = Md5Crypt.md5Crypt(keyBytes, "$1$s$", "$1$");
        assertNotNull(result);
        assertTrue(result.startsWith("$1$"));
    }
}