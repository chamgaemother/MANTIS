import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.JXPathBeanInfo;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.BeanPointer;
import org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BeanPointerTest {

    @Test
    void testEquals_sameObject() {
        QName qName = new QName("test");
        Object bean = new Object();
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer = new BeanPointer(qName, bean, beanInfo, null);

        assertTrue(pointer.equals(pointer));
    }

    @Test
    void testEquals_differentClass() {
        QName qName = new QName("test");
        Object bean = new Object();
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer = new BeanPointer(qName, bean, beanInfo, null);

        assertFalse(pointer.equals(new Object()));
    }

    @Test
    void testEquals_differentParent() {
        QName qName = new QName("test");
        Object bean = new Object();
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        NodePointer parent1 = mock(NodePointer.class);
        NodePointer parent2 = mock(NodePointer.class);

        BeanPointer pointer1 = new BeanPointer(parent1, qName, bean, beanInfo);
        BeanPointer pointer2 = new BeanPointer(parent2, qName, bean, beanInfo);

        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEquals_differentQName() {
        QName qName1 = new QName("test1");
        QName qName2 = new QName("test2");
        Object bean = new Object();
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer1 = new BeanPointer(qName1, bean, beanInfo, null);
        BeanPointer pointer2 = new BeanPointer(qName2, bean, beanInfo, null);

        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEquals_differentIndex() {
        QName qName = new QName("test");
        Object bean = new Object();
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer1 = new BeanPointer(qName, bean, beanInfo, null);
        BeanPointer pointer2 = new BeanPointer(qName, bean, beanInfo, null);
        
        pointer1.setIndex(1);
        pointer2.setIndex(2);

        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEquals_sameBeanValue_number() {
        QName qName = new QName("test");
        Number bean1 = 42;
        Number bean2 = 42;
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer1 = new BeanPointer(qName, bean1, beanInfo, null);
        BeanPointer pointer2 = new BeanPointer(qName, bean2, beanInfo, null);

        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEquals_differentBeanValue_number() {
        QName qName = new QName("test");
        Number bean1 = 42;
        Number bean2 = 43;
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer1 = new BeanPointer(qName, bean1, beanInfo, null);
        BeanPointer pointer2 = new BeanPointer(qName, bean2, beanInfo, null);

        assertFalse(pointer1.equals(pointer2));
    }
    
    @Test
    void testEquals_sameBeanValue_boolean() {
        QName qName = new QName("test");
        Boolean bean1 = true;
        Boolean bean2 = true;
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer1 = new BeanPointer(qName, bean1, beanInfo, null);
        BeanPointer pointer2 = new BeanPointer(qName, bean2, beanInfo, null);

        assertTrue(pointer1.equals(pointer2));
    }

    @Test
    void testEquals_differentBeanValue_string() {
        QName qName = new QName("test");
        String bean1 = "value1";
        String bean2 = "value2";
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer1 = new BeanPointer(qName, bean1, beanInfo, null);
        BeanPointer pointer2 = new BeanPointer(qName, bean2, beanInfo, null);

        assertFalse(pointer1.equals(pointer2));
    }

    @Test
    void testEquals_singularBeans() {
        QName qName = new QName("test");
        Object bean1 = new Object();
        Object bean2 = bean1;
        JXPathBeanInfo beanInfo = mock(JXPathBeanInfo.class);

        BeanPointer pointer1 = new BeanPointer(qName, bean1, beanInfo, null);
        BeanPointer pointer2 = new BeanPointer(qName, bean2, beanInfo, null);

        assertTrue(pointer1.equals(pointer2));
    }
}