import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;

public class Flat3Map_containsKey_2_1_Test {

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=1, and key equals key1")
    void TC20_containsKey_delegateMapNull_size1_keyEqualsKey1() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null using reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1 using reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Create the key and set key1 to this key using reflection
        Object key = new Object();
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key);

        // Set hash1 to key.hashCode() using reflection
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, key.hashCode());

        // Act
        boolean result = map.containsKey(key);

        // Assert
        Assertions.assertTrue(result, "Expected containsKey to return true when key equals key1");
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=1, and key does not equal key1")
    void TC21_containsKey_delegateMapNull_size1_keyNotEqualsKey1() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null using reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1 using reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Create two distinct keys
        Object key = new Object();
        Object differentKey = new Object();

        // Set key1 to differentKey using reflection
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, differentKey);

        // Set hash1 to differentKey.hashCode() using reflection
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, differentKey.hashCode());

        // Act
        boolean result = map.containsKey(key);

        // Assert
        Assertions.assertFalse(result, "Expected containsKey to return false when key does not equal key1");
    }
}