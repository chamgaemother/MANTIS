package org.jfree.chart.plot;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.plot.CategoryPlot;

public class CategoryPlot_hashCode_0_2_Test {

    @Test
    @DisplayName("hashCode with rangeMinorGridlinesVisible=true and others=false")
    public void TC06_hashCode_RangeMinorGridlinesVisibleTrue_OthersFalse() {
        // GIVEN
        CategoryPlot plot1 = new CategoryPlot();
        CategoryPlot plot2 = new CategoryPlot();

        plot1.setDrawSharedDomainAxis(false);
        plot1.setDomainGridlinesVisible(false);
        plot1.setRangeZeroBaselineVisible(false);
        plot1.setRangeGridlinesVisible(false);
        plot1.setRangeMinorGridlinesVisible(true);
        plot1.setDomainCrosshairVisible(false);
        plot1.setRangeCrosshairVisible(false);
        plot1.setRangeCrosshairLockedOnData(false);
        plot1.setRangePannable(false);

        plot2.setDrawSharedDomainAxis(false);
        plot2.setDomainGridlinesVisible(false);
        plot2.setRangeZeroBaselineVisible(false);
        plot2.setRangeGridlinesVisible(false);
        plot2.setRangeMinorGridlinesVisible(true);
        plot2.setDomainCrosshairVisible(false);
        plot2.setRangeCrosshairVisible(false);
        plot2.setRangeCrosshairLockedOnData(false);
        plot2.setRangePannable(false);

        // WHEN
        int hash1 = plot1.hashCode();
        int hash2 = plot2.hashCode();

        // THEN
        assertEquals(hash1, hash2, "Hash codes should be equal for identical configurations");
    }

    @Test
    @DisplayName("hashCode with domainCrosshairVisible=true and others=false")
    public void TC07_hashCode_DomainCrosshairVisibleTrue_OthersFalse() {
        // GIVEN
        CategoryPlot plot1 = new CategoryPlot();
        CategoryPlot plot2 = new CategoryPlot();

        plot1.setDrawSharedDomainAxis(false);
        plot1.setDomainGridlinesVisible(false);
        plot1.setRangeZeroBaselineVisible(false);
        plot1.setRangeGridlinesVisible(false);
        plot1.setRangeMinorGridlinesVisible(false);
        plot1.setDomainCrosshairVisible(true);
        plot1.setRangeCrosshairVisible(false);
        plot1.setRangeCrosshairLockedOnData(false);
        plot1.setRangePannable(false);

        plot2.setDrawSharedDomainAxis(false);
        plot2.setDomainGridlinesVisible(false);
        plot2.setRangeZeroBaselineVisible(false);
        plot2.setRangeGridlinesVisible(false);
        plot2.setRangeMinorGridlinesVisible(false);
        plot2.setDomainCrosshairVisible(true);
        plot2.setRangeCrosshairVisible(false);
        plot2.setRangeCrosshairLockedOnData(false);
        plot2.setRangePannable(false);

        // WHEN
        int hash1 = plot1.hashCode();
        int hash2 = plot2.hashCode();

        // THEN
        assertEquals(hash1, hash2, "Hash codes should be equal for identical configurations");
    }

    @Test
    @DisplayName("hashCode with rangeCrosshairVisible=true and others=false")
    public void TC08_hashCode_RangeCrosshairVisibleTrue_OthersFalse() {
        // GIVEN
        CategoryPlot plot1 = new CategoryPlot();
        CategoryPlot plot2 = new CategoryPlot();

        plot1.setDrawSharedDomainAxis(false);
        plot1.setDomainGridlinesVisible(false);
        plot1.setRangeZeroBaselineVisible(false);
        plot1.setRangeGridlinesVisible(false);
        plot1.setRangeMinorGridlinesVisible(false);
        plot1.setDomainCrosshairVisible(false);
        plot1.setRangeCrosshairVisible(true);
        plot1.setRangeCrosshairLockedOnData(false);
        plot1.setRangePannable(false);

        plot2.setDrawSharedDomainAxis(false);
        plot2.setDomainGridlinesVisible(false);
        plot2.setRangeZeroBaselineVisible(false);
        plot2.setRangeGridlinesVisible(false);
        plot2.setRangeMinorGridlinesVisible(false);
        plot2.setDomainCrosshairVisible(false);
        plot2.setRangeCrosshairVisible(true);
        plot2.setRangeCrosshairLockedOnData(false);
        plot2.setRangePannable(false);

        // WHEN
        int hash1 = plot1.hashCode();
        int hash2 = plot2.hashCode();

        // THEN
        assertEquals(hash1, hash2, "Hash codes should be equal for identical configurations");
    }

    @Test
    @DisplayName("hashCode with rangeCrosshairLockedOnData=true and others=false")
    public void TC09_hashCode_RangeCrosshairLockedOnDataTrue_OthersFalse() {
        // GIVEN
        CategoryPlot plot1 = new CategoryPlot();
        CategoryPlot plot2 = new CategoryPlot();

        plot1.setDrawSharedDomainAxis(false);
        plot1.setDomainGridlinesVisible(false);
        plot1.setRangeZeroBaselineVisible(false);
        plot1.setRangeGridlinesVisible(false);
        plot1.setRangeMinorGridlinesVisible(false);
        plot1.setDomainCrosshairVisible(false);
        plot1.setRangeCrosshairVisible(false);
        plot1.setRangeCrosshairLockedOnData(true);
        plot1.setRangePannable(false);

        plot2.setDrawSharedDomainAxis(false);
        plot2.setDomainGridlinesVisible(false);
        plot2.setRangeZeroBaselineVisible(false);
        plot2.setRangeGridlinesVisible(false);
        plot2.setRangeMinorGridlinesVisible(false);
        plot2.setDomainCrosshairVisible(false);
        plot2.setRangeCrosshairVisible(false);
        plot2.setRangeCrosshairLockedOnData(true);
        plot2.setRangePannable(false);

        // WHEN
        int hash1 = plot1.hashCode();
        int hash2 = plot2.hashCode();

        // THEN
        assertEquals(hash1, hash2, "Hash codes should be equal for identical configurations");
    }

    @Test
    @DisplayName("hashCode with rangePannable=true and others=false")
    public void TC10_hashCode_RangePannableTrue_OthersFalse() {
        // GIVEN
        CategoryPlot plot1 = new CategoryPlot();
        CategoryPlot plot2 = new CategoryPlot();

        plot1.setDrawSharedDomainAxis(false);
        plot1.setDomainGridlinesVisible(false);
        plot1.setRangeZeroBaselineVisible(false);
        plot1.setRangeGridlinesVisible(false);
        plot1.setRangeMinorGridlinesVisible(false);
        plot1.setDomainCrosshairVisible(false);
        plot1.setRangeCrosshairVisible(false);
        plot1.setRangeCrosshairLockedOnData(false);
        plot1.setRangePannable(true);

        plot2.setDrawSharedDomainAxis(false);
        plot2.setDomainGridlinesVisible(false);
        plot2.setRangeZeroBaselineVisible(false);
        plot2.setRangeGridlinesVisible(false);
        plot2.setRangeMinorGridlinesVisible(false);
        plot2.setDomainCrosshairVisible(false);
        plot2.setRangeCrosshairVisible(false);
        plot2.setRangeCrosshairLockedOnData(false);
        plot2.setRangePannable(true);

        // WHEN
        int hash1 = plot1.hashCode();
        int hash2 = plot2.hashCode();

        // THEN
        assertEquals(hash1, hash2, "Hash codes should be equal for identical configurations");
    }
}