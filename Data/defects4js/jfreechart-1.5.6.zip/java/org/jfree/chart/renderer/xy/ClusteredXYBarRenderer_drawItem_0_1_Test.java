package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.RectangleEdge;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ClusteredXYBarRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("TC01: drawItem returns immediately when item is not visible")
    public void TC01_drawItem_ItemNotVisible() {
        // Arrange
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
        Graphics2D graphics = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        // Arrange to simulate getItemVisible return value
        doReturn(false).when(renderer).getItemVisible(series, item);

        // Act
        renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Since item is not visible, no other methods should be invoked on renderer
        verify(graphics, never()).draw(any());
    }

    @Test
    @DisplayName("TC02: drawItem processes item with useYInterval true and valid y0, y1")
    public void TC02_drawItem_UseYIntervalTrue_ValidY0Y1() {
        // Arrange
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
        Graphics2D graphics = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 1;
        int item = 1;
        int pass = 1;

        // Mock dependencies using Mockito spies and doReturn syntax
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();
        doReturn(true).when(renderer).isSeriesVisible(anyInt());

        // Mock dataset values
        when(dataset.getStartYValue(series, item)).thenReturn(5.0);
        when(dataset.getEndYValue(series, item)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, plot.getRangeAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(dataset.getStartXValue(series, item)).thenReturn(1.0);
        when(dataset.getEndXValue(series, item)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge())).thenReturn(20.0);

        // Mock plot orientation
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        // Act
        renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Since the spies are correctly configured, drawing operation should access the bar painter
        verify(renderer, atLeastOnce()).getBarPainter();
    }

//     @Test
//     @DisplayName("TC03: drawItem processes item with useYInterval false and valid y")
//     public void TC03_drawItem_UseYIntervalFalse_ValidY() {
        // Arrange
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
//         Graphics2D graphics = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int series = 2;
//         int item = 2;
//         int pass = 1;
// 
        // Mock dependencies using Mockito spies and doReturn syntax
//         doReturn(true).when(renderer).getItemVisible(series, item);
//         doReturn(false).when(renderer).getUseYInterval();
//         doReturn(0.0).when(renderer).getBase();
//         doReturn(true).when(renderer).isSeriesVisible(anyInt());
// 
        // Mock dataset mocking
//         when(dataset.getYValue(series, item)).thenReturn(15.0);
//         when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(15.0, dataArea, plot.getRangeAxisEdge())).thenReturn(150.0);
//         when(dataset.getStartXValue(series, item)).thenReturn(3.0);
//         when(dataset.getEndXValue(series, item)).thenReturn(4.0);
//         when(domainAxis.valueToJava2D(3.0, dataArea, plot.getDomainAxisEdge())).thenReturn(30.0);
//         when(domainAxis.valueToJava2D(4.0, dataArea, plot.getDomainAxisEdge())).thenReturn(40.0);
// 
        // Mock plot orientation
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
        // Act
//         renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(renderer, atLeastOnce()).getBarPainter();
//     }

    @Test
    @DisplayName("TC04: drawItem returns when y0 is NaN")
    public void TC04_drawItem_Y0IsNaN() {
        // Arrange
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
        Graphics2D graphics = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 3;
        int item = 3;
        int pass = 0;

        // Mock dependencies to assure visibility and intervals
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();

        // Mock y-values with NaN scenario
        when(dataset.getStartYValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(series, item)).thenReturn(20.0);

        // Act
        renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer, never()).getBarPainter();
    }

    @Test
    @DisplayName("TC05: drawItem returns when y1 is NaN")
    public void TC05_drawItem_Y1IsNaN() {
        // Arrange
        ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
        Graphics2D graphics = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 4;
        int item = 4;
        int pass = 0;

        // Mock dependencies to assure visibility and intervals
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();

        // Mock y-values with NaN scenario
        when(dataset.getEndYValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getStartYValue(series, item)).thenReturn(25.0);

        // Act
        renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer, never()).getBarPainter();
    }
}