package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.Arrays;

public class KthSelector_select_0_2_Test {

    @Test
    @DisplayName("select method with r1 as non-null, $i11 <= 15, z0 is false, i0 != i12")
    void TC06_select_with_exact_pivot_match() throws Exception {
        // GIVEN
        double[] work = {3.0, 1.0, 2.0, 4.0, 5.0};
        int[] r1 = {2, 3, 1};
        int k = 2;
        KthSelector selector = new KthSelector();
        
        // Set pivotsHeap via reflection
        Field pivotsHeapField = KthSelector.class.getDeclaredField("pivotsHeap");
        pivotsHeapField.setAccessible(true);
        int[] pivotsHeap = {1, -1, -1};
        pivotsHeapField.set(selector, pivotsHeap);
        
        // WHEN
        double result = selector.select(work, r1, k);
        
        // THEN
        assertEquals(work[k], result, "The returned value should be work[k]");
    }

    @Test
    @DisplayName("select method with r1 as non-null, $i11 <= 15, z0 is false, i0 == i12, z0 is true")
    void TC07_select_with_i0_equal_to_i12_and_multiple_iterations() throws Exception {
        // GIVEN
        double[] work = {7.0, 2.0, 5.0, 3.0, 1.0, 4.0, 6.0};
        int[] r1 = {3, 1, 2};
        int k = 4;
        KthSelector selector = new KthSelector();
        
        // Set pivotsHeap via reflection
        Field pivotsHeapField = KthSelector.class.getDeclaredField("pivotsHeap");
        pivotsHeapField.setAccessible(true);
        int[] pivotsHeap = {2, 4, -1};
        pivotsHeapField.set(selector, pivotsHeap);
        
        // WHEN
        double result = selector.select(work, r1, k);
        
        // THEN
        double expectedValueAfterIterations = 5.0;
        assertEquals(expectedValueAfterIterations, result, "The returned value should match the expected value after iterations");
    }

    @Test
    @DisplayName("select method with r1 as non-null, $i11 <= 15, z0 is false, i0 >= i12")
    void TC08_select_with_i0_greater_than_or_equal_to_i12() throws Exception {
        // GIVEN
        double[] work = {10.0, 9.0, 8.0, 7.0, 6.0};
        int[] r1 = {1, 4, 2};
        int k = 1;
        KthSelector selector = new KthSelector();
        
        // Set pivotsHeap via reflection
        Field pivotsHeapField = KthSelector.class.getDeclaredField("pivotsHeap");
        pivotsHeapField.setAccessible(true);
        int[] pivotsHeap = {3, 2, -1};
        pivotsHeapField.set(selector, pivotsHeap);
        
        // WHEN
        double result = selector.select(work, r1, k);
        
        // THEN
        double expectedValueAfterUpdateEnd = 8.0;
        assertEquals(expectedValueAfterUpdateEnd, result, "The returned value should match the expected value after updating end index");
    }

    @Test
    @DisplayName("select method with r1 as non-null, zero iterations of the while loop")
    void TC09_select_with_zero_loop_iterations() throws Exception {
        // GIVEN
        double[] work = {2.0, 1.0};
        int[] r1 = {0};
        int k = 0;
        KthSelector selector = new KthSelector();
        
        // Set pivotsHeap via reflection
        Field pivotsHeapField = KthSelector.class.getDeclaredField("pivotsHeap");
        pivotsHeapField.setAccessible(true);
        int[] pivotsHeap = {0};
        pivotsHeapField.set(selector, pivotsHeap);
        
        // WHEN
        double result = selector.select(work, r1, k);
        
        // THEN
        assertEquals(work[k], result, "The returned value should be work[k] without entering the loop");
    }

    @Test
    @DisplayName("select method with r1 as non-null, one iteration of the while loop")
    void TC10_select_with_one_loop_iteration() throws Exception {
        // GIVEN
        double[] work = {5.0, 3.0, 4.0, 1.0, 2.0};
        int[] r1 = {2, 0, 1};
        int k = 3;
        KthSelector selector = new KthSelector();
        
        // Set pivotsHeap via reflection
        Field pivotsHeapField = KthSelector.class.getDeclaredField("pivotsHeap");
        pivotsHeapField.setAccessible(true);
        int[] pivotsHeap = {1, -1, -1};
        pivotsHeapField.set(selector, pivotsHeap);
        
        // WHEN
        double result = selector.select(work, r1, k);
        
        // THEN
        double expectedValueAfterOneIteration = 3.0;
        assertEquals(expectedValueAfterOneIteration, result, "The returned value should match the expected value after one loop iteration");
    }
}