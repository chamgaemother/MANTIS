package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_2_2_Test {

    @Test
    @DisplayName("Input with 'G' followed by 'H', should assign code '4'")
    void testTC49() {
        // GIVEN
        String input = "Ghost";
        // WHEN
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);
        // THEN
        assertTrue(result.contains("4"), "Result should contain '4' for 'G' followed by 'H'");
    }

    @Test
    @DisplayName("Input with 'C' after 'Q', should assign code '8'")
    void testTC50() {
        // GIVEN
        String input = "Quack";
        // WHEN
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);
        // THEN
        assertTrue(result.contains("8"), "Result should contain '8' for 'C' after 'Q'");
    }

    @Test
    @DisplayName("Input with 'X' before 'C', should assign code '4C'")
    void testTC51() {
        // GIVEN
        String input = "Exclamation";
        // WHEN
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);
        // THEN
        assertTrue(result.contains("4C"), "Result should contain '4C' for 'X' before 'C'");
    }

    @Test
    @DisplayName("Input with 'D' before 'Q', should assign code '2'")
    void testTC52() {
        // GIVEN
        String input = "DoQ";
        // WHEN
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);
        // THEN
        assertTrue(result.contains("2"), "Result should contain '2' for 'D' before 'Q'");
    }

    @Test
    @DisplayName("Input with 'T' before 'D', should assign code '2'")
    void testTC53() {
        // GIVEN
        String input = "Tad";
        // WHEN
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);
        // THEN
        assertTrue(result.contains("2"), "Result should contain '2' for 'T' before 'D'");
    }
}