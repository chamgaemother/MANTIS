package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class TarArchiveOutputStream_putArchiveEntry_0_4_Test {

//     @Test
//     @DisplayName("putArchiveEntry with bigNumberMode STAR and write operation fails")
//     void testTC16() {
        // Given
//         OutputStream failingOutputStream = new OutputStream() {
//             @Override
//             public void write(int b) throws IOException {
//                 throw new IOException("Simulated write failure");
//             }
//         };
//         try (TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(failingOutputStream)) {
//             tarOutputStream.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR);
//             TarArchiveEntry entry = new TarArchiveEntry("test_entry.txt");
//             entry.setGlobalPaxHeader(true);
//             
            // When & Then
//             IOException exception = assertThrows(IOException.class, () -> tarOutputStream.putArchiveEntry(entry));
//             assertEquals("Simulated write failure", exception.getMessage());
//         } catch (IOException e) {
//             fail("Unexpected IOException during test setup: " + e.getMessage());
//         }
//     }

    @Test
    @DisplayName("putArchiveEntry with ASCII encodable entry and addPaxHeadersForNonAsciiNames enabled")
    void testTC17() {
        // Given
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try (TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream)) {
            tarOutputStream.setAddPaxHeadersForNonAsciiNames(true);
            TarArchiveEntry entry = new TarArchiveEntry("simple_filename.txt");
            
            // When
            tarOutputStream.putArchiveEntry(entry);
            tarOutputStream.closeArchiveEntry();
            
            // Then
            byte[] tarData = byteArrayOutputStream.toByteArray();
            String tarContent = new String(tarData);
            assertFalse(tarContent.contains("PAX"), "PAX headers should not be added for ASCII names.");
        } catch (IOException e) {
            fail("Unexpected IOException during test execution: " + e.getMessage());
        }
    }

//     @Test
//     @DisplayName("putArchiveEntry with no PAX headers and non-global entry")
//     void testTC18() {
        // Given
//         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//         try (TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream)) {
//             TarArchiveEntry entry = new TarArchiveEntry("regular_file.txt");
//             entry.setGlobalPaxHeader(false);
// 
            // When
//             tarOutputStream.putArchiveEntry(entry);
//             tarOutputStream.closeArchiveEntry();
//             
            // Then
//             byte[] tarData = byteArrayOutputStream.toByteArray();
//             String tarContent = new String(tarData);
//             assertFalse(tarContent.contains("PAX"), "PAX headers should not be present for non-global entries without non-ASCII names.");
//         } catch (IOException e) {
//             fail("Unexpected IOException during test execution: " + e.getMessage());
//         }
//     }

    @Test
    @DisplayName("putArchiveEntry throws IllegalArgumentException for null entry")
    void testTC19() {
        // Given
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try (TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream)) {
            // Set up to expect exception
            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
                // This is expected to throw an IllegalArgumentException as the entry is null
                tarOutputStream.putArchiveEntry(null);
            });
            assertEquals("archive entry cannot be null", exception.getMessage(), "Expected exception message for null entry");
        } catch (IOException e) {
            fail("Unexpected IOException during test execution: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("putArchiveEntry with already closed entry and attempting to close again")
    void testTC20() {
        // Given
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try (TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream)) {
            TarArchiveEntry firstEntry = new TarArchiveEntry("first_entry.txt");
            tarOutputStream.putArchiveEntry(firstEntry);
            tarOutputStream.closeArchiveEntry();
            
            // When & Then
            IOException exception = assertThrows(IOException.class, () -> tarOutputStream.closeArchiveEntry());
            assertEquals("No current entry to close", exception.getMessage());
        } catch (IOException e) {
            fail("Unexpected IOException during test setup: " + e.getMessage());
        }
    }
}