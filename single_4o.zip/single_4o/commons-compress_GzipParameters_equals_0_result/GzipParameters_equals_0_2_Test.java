package org.apache.commons.compress.compressors.gzip;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

public class GzipParameters_equals_0_2_Test {

    @Test
    @DisplayName("Different compression levels yield false.")
    void testCompressionLevelDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setCompressionLevel(1);
        GzipParameters params2 = new GzipParameters();
        params2.setCompressionLevel(9);

        boolean result = params1.equals(params2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Different deflate strategies yield false.")
    void testDeflateStrategyDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setDeflateStrategy(0);
        GzipParameters params2 = new GzipParameters();
        params2.setDeflateStrategy(1);

        boolean result = params1.equals(params2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Different extraField values yield false.")
    void testExtraFieldDifference() {
        GzipParameters params1 = new GzipParameters();
        ExtraField extraField1 = new ExtraField();  // Ensure the ExtraField class is correctly initialized
        extraField1.setFieldData(new byte[]{1, 2, 3});  // Hypothetical method
        params1.setExtraField(extraField1);

        GzipParameters params2 = new GzipParameters();
        ExtraField extraField2 = new ExtraField();
        extraField2.setFieldData(new byte[]{4, 5, 6});
        params2.setExtraField(extraField2);

        boolean result = params1.equals(params2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Different fileName values yield false.")
    void testFileNameDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setFileName("file1.gz");
        GzipParameters params2 = new GzipParameters();
        params2.setFileName("file2.gz");

        boolean result = params1.equals(params2);

        assertFalse(result);
    }

    @Test
    @DisplayName("Different fileNameCharset values yield false.")
    void testFileNameCharsetDifference() {
        GzipParameters params1 = new GzipParameters();
        params1.setFileNameCharset(StandardCharsets.UTF_8);
        GzipParameters params2 = new GzipParameters();
        params2.setFileNameCharset(StandardCharsets.ISO_8859_1);

        boolean result = params1.equals(params2);

        assertFalse(result);
    }

    // Helper method to ensure Byte array is not null
    @Test
    @DisplayName("Ensure byte array is not null in extra fields.")
    void testExtraFieldNonNull() {
        ExtraField extraField = new ExtraField();
        extraField.setFieldData(new byte[]{1, 2, 3});

        byte[] data = extraField.getFieldData(); // Hypothetical method call
        assertNotNull(data);
    }
}