// package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// // 
// // import org.apache.commons.math3.exception.CardanEulerSingularityException;
// // import org.apache.commons.math3.geometry.euclidean.threed.FieldRotation;
// // import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
// // import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
// // import org.apache.commons.math3.RealFieldElement;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import static org.junit.jupiter.api.Assertions.*;
// // 
// public class FieldRotation_getAngles_2_2_Test {
// // 
// //     @Test
// //     @DisplayName("TC11: getAngles with RotationOrder.ZXY and VECTOR_OPERATOR, exception expected due to out of bounds")
// //     public void TC11_getAngles_ZXY_VECTOR_OPERATOR_Exception() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.ZXY;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//         // Setup FieldRotation with parameters likely causing out-of-bound error
// //         FieldRotation<Double> rotation = new FieldRotation<>(0.0, 0.8, 0.0, 0.6, false);
// // 
//         // WHEN & THEN
// //         assertThrows(CardanEulerSingularityException.class, () -> {
// //             rotation.getAngles(order, convention);
// //         }, "Expected CardanEulerSingularityException to be thrown");
// //     }
// // 
// //     @Test
// //     @DisplayName("TC12: getAngles with RotationOrder.ZXZ and VECTOR_OPERATOR, success expected")
// //     public void TC12_getAngles_ZXZ_VECTOR_OPERATOR_Success() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.ZXZ;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//         // Setup FieldRotation with normalized quaternion
// //         double angle = Math.PI / 2;
// //         double q0 = Math.cos(angle / 2);
// //         double q1 = Math.sin(angle / 2);
// //         double q2 = 0.0;
// //         double q3 = 0.0;
// //         FieldRotation<Double> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// // 
//         // WHEN
// //         RealFieldElement<?>[] angles = rotation.getAngles(order, convention);
// // 
//         // THEN
// //         assertNotNull(angles, "Angles array should not be null");
// //         assertEquals(3, angles.length, "Angles array should have length 3");
// //     }
// // 
// //     @Test
// //     @DisplayName("TC13: getAngles with RotationOrder.ZXZ and VECTOR_OPERATOR, exception expected due to out of bounds")
// //     public void TC13_getAngles_ZXZ_VECTOR_OPERATOR_Exception() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.ZXZ;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//         // Setup FieldRotation with parameters that could cause exception
// //         FieldRotation<Double> rotation = new FieldRotation<>(0.2, 0.0, 0.9, 0.9, false);
// // 
//         // WHEN & THEN
// //         assertThrows(CardanEulerSingularityException.class, () -> {
// //             rotation.getAngles(order, convention);
// //         }, "Expected CardanEulerSingularityException to be thrown");
// //     }
// // 
// //     @Test
// //     @DisplayName("TC14: getAngles with RotationOrder.ZYZ and VECTOR_OPERATOR, success expected")
// //     public void TC14_getAngles_ZYZ_VECTOR_OPERATOR_Success() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.ZYZ;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//         // Setup normalized rotation
// //         double angle = Math.PI / 3;
// //         double q0 = Math.cos(angle / 2);
// //         double q1 = 0.0;
// //         double q2 = Math.sin(angle / 2);
// //         double q3 = 0.0;
// //         FieldRotation<Double> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// // 
//         // WHEN
// //         RealFieldElement<?>[] angles = rotation.getAngles(order, convention);
// // 
//         // THEN
// //         assertNotNull(angles, "Angles array should not be null");
// //         assertEquals(3, angles.length, "Angles array should have length 3");
// //     }
// // 
// //     @Test
// //     @DisplayName("TC15: getAngles with RotationOrder.ZYZ and VECTOR_OPERATOR, exception expected due to out of bounds")
// //     public void TC15_getAngles_ZYZ_VECTOR_OPERATOR_Exception() {
//         // GIVEN
// //         RotationOrder order = RotationOrder.ZYZ;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//         // Modified parameters to guarantee exception
// //         FieldRotation<Double> rotation = new FieldRotation<>(-0.2, 0.0, 0.0, -1.2, false);
// // 
//         // WHEN & THEN
// //         assertThrows(CardanEulerSingularityException.class, () -> {
// //             rotation.getAngles(order, convention);
// //         }, "Expected CardanEulerSingularityException to be thrown");
// //     }
// // 
// // }
// }