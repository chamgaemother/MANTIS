package org.jfree.chart.axis;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.text.TextBlock;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class CategoryAxis_refreshTicks_0_3_Test {

    @Test
    @DisplayName("Handles top edge by calculating text block height")
    void test_TC11() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 250.0, 100.0);
        RectangleEdge edge = RectangleEdge.TOP;
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = new CategoryAxis();

        // Reflection to set private field 'maximumCategoryLabelWidthRatio'
        Field maxWidthRatioField = CategoryAxis.class.getDeclaredField("maximumCategoryLabelWidthRatio");
        maxWidthRatioField.setAccessible(true);
        maxWidthRatioField.set(categoryAxis, 0.4f);

        List<Comparable> categories = Arrays.asList("Cat1");
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);
        when(categoryAxis.getPlot()).thenReturn(plot);

        CategoryLabelPosition position = mock(CategoryLabelPosition.class);
        when(position.getWidthType()).thenReturn(CategoryLabelWidthType.CATEGORY);
        when(position.getWidthRatio()).thenReturn(0.4f);
        
        // Assuming categoryLabelPositions is a field in CategoryAxis
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, mock(CategoryLabelPositions.class));
        CategoryLabelPositions labelPositions = (CategoryLabelPositions) labelPositionsField.get(categoryAxis);
        when(labelPositions.getLabelPosition(edge)).thenReturn(position);

        TextBlock label = mock(TextBlock.class);
        when(categoryAxis.createLabel(any(), anyFloat(), any(), any())).thenReturn(label);
        when(label.calculateDimensions(g2)).thenReturn(new Size2D(50, 20));

        // WHEN
        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        // THEN
        assertEquals(1, result.size());
        assertEquals(20.0, state.getMax());
    }

    @Test
    @DisplayName("Handles bottom edge with multiple categories and calculates max width")
    void test_TC12() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 500.0, 250.0);
        RectangleEdge edge = RectangleEdge.BOTTOM;
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = new CategoryAxis();

        // Reflection to set private field 'maximumCategoryLabelWidthRatio'
        Field maxWidthRatioField = CategoryAxis.class.getDeclaredField("maximumCategoryLabelWidthRatio");
        maxWidthRatioField.setAccessible(true);
        maxWidthRatioField.set(categoryAxis, 0.3f);

        List<Comparable> categories = Arrays.asList("Cat1", "Cat2", "Cat3");
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);
        when(categoryAxis.getPlot()).thenReturn(plot);

        CategoryLabelPosition position = mock(CategoryLabelPosition.class);
        when(position.getWidthType()).thenReturn(CategoryLabelWidthType.CATEGORY);
        when(position.getWidthRatio()).thenReturn(0.5f);

        // Assuming categoryLabelPositions is a field in CategoryAxis
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, mock(CategoryLabelPositions.class));
        CategoryLabelPositions labelPositions = (CategoryLabelPositions) labelPositionsField.get(categoryAxis);
        when(labelPositions.getLabelPosition(edge)).thenReturn(position);

        TextBlock label = mock(TextBlock.class);
        when(categoryAxis.createLabel(any(), anyFloat(), any(), any())).thenReturn(label);
        when(label.calculateDimensions(g2)).thenReturn(new Size2D(60, 15));

        // WHEN
        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        // THEN
        assertEquals(3, result.size());
        assertEquals(15.0, state.getMax());
    }

    @Test
    @DisplayName("Handles empty categories list by setting max to zero")
    void test_TC13() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);
        RectangleEdge edge = RectangleEdge.BOTTOM;
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = new CategoryAxis();

        // Assuming categoryLabelPositions is a field in CategoryAxis
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, mock(CategoryLabelPositions.class));

        List<Comparable> categories = Collections.emptyList();
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);
        when(categoryAxis.getPlot()).thenReturn(plot);

        // WHEN
        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        // THEN
        assertTrue(result.isEmpty());
        assertEquals(0.0, state.getMax());
    }

    @Test
    @DisplayName("Handles iterator.hasNext() returning false immediately")
    void test_TC14() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 120.0, 80.0);
        RectangleEdge edge = RectangleEdge.TOP;
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = new CategoryAxis();

        // Assuming categoryLabelPositions is a field in CategoryAxis
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, mock(CategoryLabelPositions.class));

        List<Comparable> categories = new ArrayList<>();
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);
        when(categoryAxis.getPlot()).thenReturn(plot);

        // WHEN
        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        // THEN
        assertTrue(result.isEmpty());
        assertEquals(0.0, state.getMax());
    }

    @Test
    @DisplayName("Handles exception when getPlot returns null")
    void test_TC15() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);
        RectangleEdge edge = RectangleEdge.BOTTOM;
        CategoryAxis categoryAxis = new CategoryAxis();

        // Reflection to set private field 'categoryLabelPositions'
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, mock(CategoryLabelPositions.class));

        when(categoryAxis.getPlot()).thenReturn(null);

        // WHEN
        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        // THEN
        assertTrue(result.isEmpty());
        assertEquals(0.0, state.getMax());
    }
}