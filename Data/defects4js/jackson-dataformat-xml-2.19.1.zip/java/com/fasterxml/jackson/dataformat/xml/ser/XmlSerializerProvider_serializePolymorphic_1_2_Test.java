package com.fasterxml.jackson.dataformat.xml.ser;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.SerializationConfig;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.Arrays;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.util.StaxUtil;


@ExtendWith(MockitoExtension.class)
public class XmlSerializerProvider_serializePolymorphic_1_2_Test {

    @Test
    @DisplayName("serializePolymorphic with multiple indexed types resulting in root array")
    void TC06_serializePolymorphic_with_multiple_indexed_types_resulting_in_root_array() throws Exception {
        // Arrange
        JsonGenerator gen = mock(ToXmlGenerator.class);
        Object value = Arrays.asList(new Item1(), new Item2());
        JavaType rootType = null;
        JsonSerializer<Object> ser = null;
        TypeSerializer typeSer = null;

        XmlRootNameLookup rootNameLookup = mock(XmlRootNameLookup.class);
        when(rootNameLookup.findRootName(any(Class.class), any())).thenReturn(new QName("root"));
        SerializationConfig config = mock(SerializationConfig.class);
        when(config.constructType(any(Class.class))).thenReturn(mock(JavaType.class));
        
        XmlSerializerProvider provider = new XmlSerializerProvider(rootNameLookup);

        // Act
        provider.serializePolymorphic(gen, value, rootType, ser, typeSer);

        // Assert
        // Verify TypeUtil.isIndexedType is called and returns true
        // This is implicitly verified by the behavior
        // Verify _startRootArray is called with correct QName
        verify(gen).writeStartObject();
        verify(gen).writeFieldName("item");
        // Verify writeEndObject is called
        verify(gen).writeEndObject();
    }

    @Test
    @DisplayName("serializePolymorphic with non-ObjectNode and ToXmlGenerator enabled")
    void TC07_serializePolymorphic_with_non_ObjectNode_and_ToXmlGenerator_enabled() throws Exception {
        // Arrange
        ToXmlGenerator gen = mock(ToXmlGenerator.class);
        Object value = new RegularObject();
        JavaType rootType = mock(JavaType.class);
        JsonSerializer<Object> ser = null;
        TypeSerializer typeSer = mock(TypeSerializer.class);

        XmlRootNameLookup rootNameLookup = mock(XmlRootNameLookup.class);
        when(rootNameLookup.findRootName(any(JavaType.class), any())).thenReturn(new QName("regular"));
        SerializationConfig config = mock(SerializationConfig.class);
        when(config.constructType(RegularObject.class)).thenReturn(mock(JavaType.class));
        
        XmlSerializerProvider provider = new XmlSerializerProvider(rootNameLookup);

        // Act
        provider.serializePolymorphic(gen, value, rootType, ser, typeSer);

        // Assert
        verify(gen).setNextNameIfMissing(new QName("regular"));
        verify(gen).initGenerator();
        verify(gen, times(0)).writeEndObject(); // Assuming asArray is false
    }

    @Test
    @DisplayName("serializePolymorphic with ser as null and rootType as container type")
    void TC08_serializePolymorphic_with_ser_null_and_rootType_container_type() throws Exception {
        // Arrange
        ToXmlGenerator gen = mock(ToXmlGenerator.class);
        Object value = new ContainerObject();
        JavaType rootType = mock(JavaType.class);
        JsonSerializer<Object> ser = null;
        TypeSerializer typeSer = null;

        XmlRootNameLookup rootNameLookup = mock(XmlRootNameLookup.class);
        when(rootNameLookup.findRootName(any(JavaType.class), any())).thenReturn(new QName("container"));
        SerializationConfig config = mock(SerializationConfig.class);
        when(config.constructType(ContainerObject.class)).thenReturn(mock(JavaType.class));
        
        JsonSerializer<Object> mockSerializer = mock(JsonSerializer.class);
        XmlSerializerProvider provider = spy(new XmlSerializerProvider(rootNameLookup));

        doReturn(mockSerializer).when(provider).findValueSerializer(eq(rootType), isNull());

        // Act
        provider.serializePolymorphic(gen, value, rootType, ser, typeSer);

        // Assert
        verify(provider).findValueSerializer(rootType, null);
        verify(mockSerializer).serializeWithType(eq(value), eq(gen), eq(provider), isNull());
    }

    @Test
    @DisplayName("serializePolymorphic with ser provided and rootType as non-container type")
    void TC09_serializePolymorphic_with_ser_provided_and_rootType_non_container() throws Exception {
        // Arrange
        ToXmlGenerator gen = mock(ToXmlGenerator.class);
        Object value = new CustomSerializedObject();
        JavaType rootType = mock(JavaType.class);
        JsonSerializer<Object> ser = mock(JsonSerializer.class);
        TypeSerializer typeSer = null;

        XmlRootNameLookup rootNameLookup = mock(XmlRootNameLookup.class);
        when(rootNameLookup.findRootName(any(JavaType.class), any())).thenReturn(new QName("custom"));
        SerializationConfig config = mock(SerializationConfig.class);
        when(config.constructType(CustomSerializedObject.class)).thenReturn(mock(JavaType.class));
        
        XmlSerializerProvider provider = new XmlSerializerProvider(rootNameLookup);


        // Act
        provider.serializePolymorphic(gen, value, rootType, ser, typeSer);

        // Assert
        verify(ser).serializeWithType(eq(value), eq(gen), eq(provider), any());
        verify(gen, times(0)).writeEndObject(); // Assuming asArray is false
    }

    @Test
    @DisplayName("serializePolymorphic throws JsonMappingException on serialization failure")
    void TC10_serializePolymorphic_throws_JsonMappingException_on_serialization_failure() throws Exception {
        // Arrange
        ToXmlGenerator gen = mock(ToXmlGenerator.class);
        Object value = new FaultyObject();
        JavaType rootType = mock(JavaType.class);
        JsonSerializer<Object> ser = mock(JsonSerializer.class);
        TypeSerializer typeSer = null;

        doThrow(new IOException("Serialization failed")).when(ser).serializeWithType(any(), any(), any(), any());

        XmlRootNameLookup rootNameLookup = mock(XmlRootNameLookup.class);
        when(rootNameLookup.findRootName(any(JavaType.class), any())).thenReturn(new QName("faulty"));
        SerializationConfig config = mock(SerializationConfig.class);
        when(config.constructType(FaultyObject.class)).thenReturn(mock(JavaType.class));
        
        XmlSerializerProvider provider = new XmlSerializerProvider(rootNameLookup);


        // Act & Assert
        JsonMappingException exception = assertThrows(JsonMappingException.class, () -> {
            provider.serializePolymorphic(gen, value, rootType, ser, typeSer);
        });
        assertEquals("Serialization failed", exception.getCause().getMessage());
    }

    // Mock classes for testing purposes
    static class Item1 {}
    static class Item2 {}
    static class RegularObject {}
    static class ContainerObject {}
    static class CustomSerializedObject {}
    static class FaultyObject {}
}