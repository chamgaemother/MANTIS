// package org.jfree.chart.plot;
// import org.jfree.chart.ui.Layer;
// import org.jfree.chart.LegendItem;
// import org.jfree.chart.LegendItemCollection;
// import org.jfree.chart.axis.AxisSpace;
// import org.jfree.chart.renderer.category.DefaultCategoryItemRenderer;
// import org.jfree.chart.renderer.category.CategoryItemRenderer;
// import org.jfree.chart.axis.NumberAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.axis.CategoryAxis;
// 
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import static org.junit.jupiter.api.Assertions.*;
// import java.lang.reflect.Method;
// import java.util.HashMap;
// import java.util.Map;
// import org.jfree.chart.util.ObjectUtils;
// // Assume necessary imports for CategoryAxis, ValueAxis, CategoryItemRenderer,
// // CategoryMarker, CategoryLabelAnnotation, ShadowGenerator, LegendItemCollection
// 
// public class CategoryPlot_clone_2_1_Test {
// 
//     @Test
//     @DisplayName("TC23: Clone CategoryPlot with all domain and range axes, renderers, markers, annotations, and ShadowGenerator set")
//     public void testCloneWithAllFeatures() throws Exception {
//         // Initialize original CategoryPlot
//         CategoryPlot original = new CategoryPlot();
// 
//         // Setup multiple domain axes
//         CategoryAxis domainAxis1 = new CategoryAxis("Domain Axis 1");
//         CategoryAxis domainAxis2 = new CategoryAxis("Domain Axis 2");
//         original.setDomainAxis(0, domainAxis1);
//         original.setDomainAxis(1, domainAxis2);
// 
//         // Setup multiple range axes
//         ValueAxis rangeAxis1 = new NumberAxis("Range Axis 1");
//         ValueAxis rangeAxis2 = new NumberAxis("Range Axis 2");
//         original.setRangeAxis(0, rangeAxis1);
//         original.setRangeAxis(1, rangeAxis2);
// 
//         // Setup multiple renderers
//         CategoryItemRenderer renderer1 = new DefaultCategoryItemRenderer();
//         CategoryItemRenderer renderer2 = new DefaultCategoryItemRenderer();
//         original.setRenderer(0, renderer1);
//         original.setRenderer(1, renderer2);
// 
//         // Add foreground and background markers
//         CategoryMarker fgMarker = new CategoryMarker("Category1");
//         CategoryMarker bgMarker = new CategoryMarker("Category2");
//         original.addDomainMarker(0, fgMarker, Layer.FOREGROUND);
//         original.addRangeMarker(0, bgMarker, Layer.BACKGROUND);
// 
//         // Add annotations
//         CategoryLabelAnnotation annotation1 = new CategoryLabelAnnotation("Annotation1", CategoryAnchor.MIDDLE, 0.5);
//         original.addAnnotation(annotation1);
// 
//         // Set fixed axis spaces
//         original.setFixedDomainAxisSpace(new AxisSpace());
//         original.setFixedRangeAxisSpace(new AxisSpace());
// 
//         // Set fixed legend items
//         LegendItemCollection legendItems = new LegendItemCollection();
//         legendItems.add(new LegendItem("Series 1"));
//         original.setFixedLegendItems(legendItems);
// 
//         // Set ShadowGenerator
//         ShadowGenerator shadowGen = new ShadowGenerator();
//         original.setShadowGenerator(shadowGen);
// 
//         // Perform cloning
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // Use reflection to verify that cloned domain axes are not the same as originals
//         Method getDomainAxesMethod = CategoryPlot.class.getDeclaredMethod("getDomainAxes");
//         getDomainAxesMethod.setAccessible(true);
//         Map<Integer, CategoryAxis> originalDomainAxes = (Map<Integer, CategoryAxis>) getDomainAxesMethod.invoke(original);
//         Map<Integer, CategoryAxis> clonedDomainAxes = (Map<Integer, CategoryAxis>) getDomainAxesMethod.invoke(clone);
//         assertNotSame(originalDomainAxes, clonedDomainAxes, "Domain axes map should be cloned.");
//         for (Integer key : originalDomainAxes.keySet()) {
//             assertNotSame(originalDomainAxes.get(key), clonedDomainAxes.get(key), "Each DomainAxis should be a cloned instance.");
//         }
// 
//         // Verify cloned range axes
//         Method getRangeAxesMethod = CategoryPlot.class.getDeclaredMethod("getRangeAxes");
//         getRangeAxesMethod.setAccessible(true);
//         Map<Integer, ValueAxis> originalRangeAxes = (Map<Integer, ValueAxis>) getRangeAxesMethod.invoke(original);
//         Map<Integer, ValueAxis> clonedRangeAxes = (Map<Integer, ValueAxis>) getRangeAxesMethod.invoke(clone);
//         assertNotSame(originalRangeAxes, clonedRangeAxes, "Range axes map should be cloned.");
//         for (Integer key : originalRangeAxes.keySet()) {
//             assertNotSame(originalRangeAxes.get(key), clonedRangeAxes.get(key), "Each RangeAxis should be a cloned instance.");
//         }
// 
//         // Verify cloned renderers
//         Method getRenderersMethod = CategoryPlot.class.getDeclaredMethod("getRenderers");
//         getRenderersMethod.setAccessible(true);
//         Map<Integer, CategoryItemRenderer> originalRenderers = (Map<Integer, CategoryItemRenderer>) getRenderersMethod.invoke(original);
//         Map<Integer, CategoryItemRenderer> clonedRenderers = (Map<Integer, CategoryItemRenderer>) getRenderersMethod.invoke(clone);
//         assertNotSame(originalRenderers, clonedRenderers, "Renderers map should be cloned.");
//         for (Integer key : originalRenderers.keySet()) {
//             assertNotSame(originalRenderers.get(key), clonedRenderers.get(key), "Each Renderer should be a cloned instance.");
//         }
// 
//         // Verify cloned markers
//         Method getForegroundDomainMarkersMethod = CategoryPlot.class.getDeclaredMethod("getForegroundDomainMarkers", int.class, Layer.class);
//         getForegroundDomainMarkersMethod.setAccessible(true);
//         Method getBackgroundDomainMarkersMethod = CategoryPlot.class.getDeclaredMethod("getBackgroundDomainMarkers", int.class, Layer.class);
//         getBackgroundDomainMarkersMethod.setAccessible(true);
//         Method getForegroundRangeMarkersMethod = CategoryPlot.class.getDeclaredMethod("getForegroundRangeMarkers", int.class, Layer.class);
//         getForegroundRangeMarkersMethod.setAccessible(true);
//         Method getBackgroundRangeMarkersMethod = CategoryPlot.class.getDeclaredMethod("getBackgroundRangeMarkers", int.class, Layer.class);
//         getBackgroundRangeMarkersMethod.setAccessible(true);
// 
//         // Foreground Domain Markers
//         assertNotSame(original.getForegroundDomainMarkers(0, Layer.FOREGROUND), clone.getForegroundDomainMarkers(0, Layer.FOREGROUND), "Foreground domain markers should be cloned.");
//         // Background Domain Markers
//         assertNotSame(original.getBackgroundDomainMarkers(0, Layer.BACKGROUND), clone.getBackgroundDomainMarkers(0, Layer.BACKGROUND), "Background domain markers should be cloned.");
//         // Foreground Range Markers
//         assertNotSame(original.getForegroundRangeMarkers(0, Layer.FOREGROUND), clone.getForegroundRangeMarkers(0, Layer.FOREGROUND), "Foreground range markers should be cloned.");
//         // Background Range Markers
//         assertNotSame(original.getBackgroundRangeMarkers(0, Layer.BACKGROUND), clone.getBackgroundRangeMarkers(0, Layer.BACKGROUND), "Background range markers should be cloned.");
// 
//         // Verify cloned annotations
//         Method getAnnotationsMethod = CategoryPlot.class.getDeclaredMethod("getAnnotations");
//         getAnnotationsMethod.setAccessible(true);
//         List originalAnnotations = (List) getAnnotationsMethod.invoke(original);
//         List clonedAnnotations = (List) getAnnotationsMethod.invoke(clone);
//         assertNotSame(originalAnnotations, clonedAnnotations, "Annotations list should be cloned.");
//         assertEquals(originalAnnotations.size(), clonedAnnotations.size(), "Annotations count should match.");
// 
//         // Verify fixed axis spaces
//         Method getFixedDomainAxisSpaceMethod = CategoryPlot.class.getDeclaredMethod("getFixedDomainAxisSpace");
//         getFixedDomainAxisSpaceMethod.setAccessible(true);
//         AxisSpace originalFixedDomainSpace = (AxisSpace) getFixedDomainAxisSpaceMethod.invoke(original);
//         AxisSpace clonedFixedDomainSpace = (AxisSpace) getFixedDomainAxisSpaceMethod.invoke(clone);
//         assertNotSame(originalFixedDomainSpace, clonedFixedDomainSpace, "Fixed Domain AxisSpace should be cloned.");
//         
//         Method getFixedRangeAxisSpaceMethod = CategoryPlot.class.getDeclaredMethod("getFixedRangeAxisSpace");
//         getFixedRangeAxisSpaceMethod.setAccessible(true);
//         AxisSpace originalFixedRangeSpace = (AxisSpace) getFixedRangeAxisSpaceMethod.invoke(original);
//         AxisSpace clonedFixedRangeSpace = (AxisSpace) getFixedRangeAxisSpaceMethod.invoke(clone);
//         assertNotSame(originalFixedRangeSpace, clonedFixedRangeSpace, "Fixed Range AxisSpace should be cloned.");
// 
//         // Verify fixed legend items
//         Method getFixedLegendItemsMethod = CategoryPlot.class.getDeclaredMethod("getFixedLegendItems");
//         getFixedLegendItemsMethod.setAccessible(true);
//         LegendItemCollection originalLegendItems = (LegendItemCollection) getFixedLegendItemsMethod.invoke(original);
//         LegendItemCollection clonedLegendItems = (LegendItemCollection) getFixedLegendItemsMethod.invoke(clone);
//         assertNotSame(originalLegendItems, clonedLegendItems, "Fixed LegendItems should be cloned.");
//         assertEquals(originalLegendItems, clonedLegendItems, "Fixed LegendItems should be equal.");
// 
//         // Verify ShadowGenerator
//         Method getShadowGeneratorMethod = CategoryPlot.class.getDeclaredMethod("getShadowGenerator");
//         getShadowGeneratorMethod.setAccessible(true);
//         ShadowGenerator originalShadow = (ShadowGenerator) getShadowGeneratorMethod.invoke(original);
//         ShadowGenerator clonedShadow = (ShadowGenerator) getShadowGeneratorMethod.invoke(clone);
//         if (originalShadow != null) {
//             assertNotSame(originalShadow, clonedShadow, "ShadowGenerator should be cloned.");
//             assertEquals(originalShadow, clonedShadow, "ShadowGenerator should be equal.");
//         } else {
//             assertNull(clonedShadow, "Cloned ShadowGenerator should be null if original was null.");
//         }
//     }
// 
//     @Test
//     @DisplayName("TC24: Clone CategoryPlot with empty marker maps and empty annotations")
//     public void testCloneWithEmptyMarkersAndAnnotations() throws Exception {
//         // Initialize original CategoryPlot
//         CategoryPlot original = new CategoryPlot();
// 
//         // Setup multiple domain axes
//         CategoryAxis domainAxis1 = new CategoryAxis("Domain Axis 1");
//         CategoryAxis domainAxis2 = new CategoryAxis("Domain Axis 2");
//         original.setDomainAxis(0, domainAxis1);
//         original.setDomainAxis(1, domainAxis2);
// 
//         // Setup multiple range axes
//         ValueAxis rangeAxis1 = new NumberAxis("Range Axis 1");
//         ValueAxis rangeAxis2 = new NumberAxis("Range Axis 2");
//         original.setRangeAxis(0, rangeAxis1);
//         original.setRangeAxis(1, rangeAxis2);
// 
//         // Setup multiple renderers
//         CategoryItemRenderer renderer1 = new DefaultCategoryItemRenderer();
//         CategoryItemRenderer renderer2 = new DefaultCategoryItemRenderer();
//         original.setRenderer(0, renderer1);
//         original.setRenderer(1, renderer2);
// 
//         // Ensure no markers are added
//         original.clearDomainMarkers();
//         original.clearRangeMarkers();
// 
//         // Ensure no annotations are added
//         original.clearAnnotations();
// 
//         // Set fixed axis spaces
//         original.setFixedDomainAxisSpace(new AxisSpace());
//         original.setFixedRangeAxisSpace(new AxisSpace());
// 
//         // Set fixed legend items
//         LegendItemCollection legendItems = new LegendItemCollection();
//         legendItems.add(new LegendItem("Series 1"));
//         original.setFixedLegendItems(legendItems);
// 
//         // Ensure ShadowGenerator is not set
//         original.setShadowGenerator(null);
// 
//         // Perform cloning
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // Use reflection to verify that cloned domain axes are not the same as originals
//         Method getDomainAxesMethod = CategoryPlot.class.getDeclaredMethod("getDomainAxes");
//         getDomainAxesMethod.setAccessible(true);
//         Map<Integer, CategoryAxis> originalDomainAxes = (Map<Integer, CategoryAxis>) getDomainAxesMethod.invoke(original);
//         Map<Integer, CategoryAxis> clonedDomainAxes = (Map<Integer, CategoryAxis>) getDomainAxesMethod.invoke(clone);
//         assertNotSame(originalDomainAxes, clonedDomainAxes, "Domain axes map should be cloned.");
//         for (Integer key : originalDomainAxes.keySet()) {
//             assertNotSame(originalDomainAxes.get(key), clonedDomainAxes.get(key), "Each DomainAxis should be a cloned instance.");
//         }
// 
//         // Verify cloned range axes
//         Method getRangeAxesMethod = CategoryPlot.class.getDeclaredMethod("getRangeAxes");
//         getRangeAxesMethod.setAccessible(true);
//         Map<Integer, ValueAxis> originalRangeAxes = (Map<Integer, ValueAxis>) getRangeAxesMethod.invoke(original);
//         Map<Integer, ValueAxis> clonedRangeAxes = (Map<Integer, ValueAxis>) getRangeAxesMethod.invoke(clone);
//         assertNotSame(originalRangeAxes, clonedRangeAxes, "Range axes map should be cloned.");
//         for (Integer key : originalRangeAxes.keySet()) {
//             assertNotSame(originalRangeAxes.get(key), clonedRangeAxes.get(key), "Each RangeAxis should be a cloned instance.");
//         }
// 
//         // Verify cloned renderers
//         Method getRenderersMethod = CategoryPlot.class.getDeclaredMethod("getRenderers");
//         getRenderersMethod.setAccessible(true);
//         Map<Integer, CategoryItemRenderer> originalRenderers = (Map<Integer, CategoryItemRenderer>) getRenderersMethod.invoke(original);
//         Map<Integer, CategoryItemRenderer> clonedRenderers = (Map<Integer, CategoryItemRenderer>) getRenderersMethod.invoke(clone);
//         assertNotSame(originalRenderers, clonedRenderers, "Renderers map should be cloned.");
//         for (Integer key : originalRenderers.keySet()) {
//             assertNotSame(originalRenderers.get(key), clonedRenderers.get(key), "Each Renderer should be a cloned instance.");
//         }
// 
//         // Verify cloned markers maps are empty
//         Method getForegroundDomainMarkersMethod = CategoryPlot.class.getDeclaredMethod("getForegroundDomainMarkers", int.class, Layer.class);
//         getForegroundDomainMarkersMethod.setAccessible(true);
//         Method getBackgroundDomainMarkersMethod = CategoryPlot.class.getDeclaredMethod("getBackgroundDomainMarkers", int.class, Layer.class);
//         getBackgroundDomainMarkersMethod.setAccessible(true);
//         Method getForegroundRangeMarkersMethod = CategoryPlot.class.getDeclaredMethod("getForegroundRangeMarkers", int.class, Layer.class);
//         getForegroundRangeMarkersMethod.setAccessible(true);
//         Method getBackgroundRangeMarkersMethod = CategoryPlot.class.getDeclaredMethod("getBackgroundRangeMarkers", int.class, Layer.class);
//         getBackgroundRangeMarkersMethod.setAccessible(true);
// 
//         // Foreground Domain Markers
//         assertTrue(clone.getForegroundDomainMarkers(0, Layer.FOREGROUND).isEmpty(), "Cloned foregroundDomainMarkers should be empty.");
//         // Background Domain Markers
//         assertTrue(clone.getBackgroundDomainMarkers(0, Layer.BACKGROUND).isEmpty(), "Cloned backgroundDomainMarkers should be empty.");
//         // Foreground Range Markers
//         assertTrue(clone.getForegroundRangeMarkers(0, Layer.FOREGROUND).isEmpty(), "Cloned foregroundRangeMarkers should be empty.");
//         // Background Range Markers
//         assertTrue(clone.getBackgroundRangeMarkers(0, Layer.BACKGROUND).isEmpty(), "Cloned backgroundRangeMarkers should be empty.");
// 
//         // Verify cloned annotations are empty
//         Method getAnnotationsMethod = CategoryPlot.class.getDeclaredMethod("getAnnotations");
//         getAnnotationsMethod.setAccessible(true);
//         List originalAnnotations = (List) getAnnotationsMethod.invoke(original);
//         List clonedAnnotations = (List) getAnnotationsMethod.invoke(clone);
//         assertNotSame(originalAnnotations, clonedAnnotations, "Annotations list should be cloned.");
//         assertTrue(clonedAnnotations.isEmpty(), "Cloned annotations should be empty.");
// 
//         // Verify fixed axis spaces
//         Method getFixedDomainAxisSpaceMethod = CategoryPlot.class.getDeclaredMethod("getFixedDomainAxisSpace");
//         getFixedDomainAxisSpaceMethod.setAccessible(true);
//         AxisSpace originalFixedDomainSpace = (AxisSpace) getFixedDomainAxisSpaceMethod.invoke(original);
//         AxisSpace clonedFixedDomainSpace = (AxisSpace) getFixedDomainAxisSpaceMethod.invoke(clone);
//         assertNotSame(originalFixedDomainSpace, clonedFixedDomainSpace, "Fixed Domain AxisSpace should be cloned.");
//         
//         Method getFixedRangeAxisSpaceMethod = CategoryPlot.class.getDeclaredMethod("getFixedRangeAxisSpace");
//         getFixedRangeAxisSpaceMethod.setAccessible(true);
//         AxisSpace originalFixedRangeSpace = (AxisSpace) getFixedRangeAxisSpaceMethod.invoke(original);
//         AxisSpace clonedFixedRangeSpace = (AxisSpace) getFixedRangeAxisSpaceMethod.invoke(clone);
//         assertNotSame(originalFixedRangeSpace, clonedFixedRangeSpace, "Fixed Range AxisSpace should be cloned.");
// 
//         // Verify fixed legend items
//         Method getFixedLegendItemsMethod = CategoryPlot.class.getDeclaredMethod("getFixedLegendItems");
//         getFixedLegendItemsMethod.setAccessible(true);
//         LegendItemCollection originalLegendItems = (LegendItemCollection) getFixedLegendItemsMethod.invoke(original);
//         LegendItemCollection clonedLegendItems = (LegendItemCollection) getFixedLegendItemsMethod.invoke(clone);
//         assertNotSame(originalLegendItems, clonedLegendItems, "Fixed LegendItems should be cloned.");
//         assertEquals(originalLegendItems, clonedLegendItems, "Fixed LegendItems should be equal.");
// 
//         // Verify ShadowGenerator is not set
//         Method getShadowGeneratorMethod = CategoryPlot.class.getDeclaredMethod("getShadowGenerator");
//         getShadowGeneratorMethod.setAccessible(true);
//         ShadowGenerator clonedShadow = (ShadowGenerator) getShadowGeneratorMethod.invoke(clone);
//         assertNull(clonedShadow, "Cloned ShadowGenerator should be null if original was null.");
//     }
// }