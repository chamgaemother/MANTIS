package org.apache.commons.compress.archivers.cpio;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CpioArchiveInputStream_getNextCPIOEntry_1_1_Test {

    @Test
    @DisplayName("Throws IOException when CRC does not match for MAGIC_NEW_CRC entry")
    void TC19_getNextCPIOEntry_CRC_Mismatch_ThrowsIOException() throws Exception {
        // Arrange
        byte[] magicNewCrcInvalid = createMagicNewCrcEntryWithInvalidCRC();
        InputStream inputStream = new ByteArrayInputStream(magicNewCrcInvalid);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Act & Assert
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        });
        assertTrue(exception.getMessage().contains("CRC Error"));
    }

    @Test
    @DisplayName("Throws IOException when data pad count mismatch occurs")
    void TC20_getNextCPIOEntry_HeaderPadCountMismatch_ThrowsIOException() throws Exception {
        // Arrange
        byte[] magicNewBadPad = createMagicNewEntryWithBadPadCount();
        InputStream inputStream = new ByteArrayInputStream(magicNewBadPad);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Act & Assert
        IOException exception = assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        });
        assertTrue(exception.getMessage().contains("Header pad count mismatch"));
    }

    @Test
    @DisplayName("Returns null when getNextCPIOEntry is called after trailer has been processed")
    void TC21_getNextCPIOEntry_AfterTrailer_ReturnsNull() throws Exception {
        // Arrange
        byte[] trailerOnly = createTrailerOnlyStream();
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(
            new ByteArrayInputStream(trailerOnly));
        // Process trailer entry
        CpioArchiveEntry initialEntry = cpioInputStream.getNextCPIOEntry();
        assertNotNull(initialEntry);
        assertEquals("TRAILER!!!", initialEntry.getName());

        // Act
        CpioArchiveEntry entry = cpioInputStream.getNextCPIOEntry();

        // Assert
        assertNull(entry);
    }

    @Test
    @DisplayName("Throws EOFException when input stream ends unexpectedly during readFully")
    void TC22_getNextCPIOEntry_IncompleteEntry_ThrowsEOFException() throws Exception {
        // Arrange
        byte[] incompleteEntry = createIncompleteMagicNewEntry();
        InputStream inputStream = new ByteArrayInputStream(incompleteEntry);
        CpioArchiveInputStream cpioInputStream = new CpioArchiveInputStream(inputStream);

        // Act & Assert
        assertThrows(IOException.class, () -> {
            cpioInputStream.getNextCPIOEntry();
        });
    }

    // Helper methods to create specific byte arrays for scenarios
    private byte[] createMagicNewCrcEntryWithInvalidCRC() throws Exception {
        // Construct a MAGIC_NEW_CRC entry with incorrect CRC
        String magic = "070702";
        String inode = "00000001";
        String mode = "00000000";
        String uid = "00000001";
        String gid = "00000001";
        String nlink = "00000001";
        String mtime = "00000001";
        String size = "00000004"; // 4 bytes of data
        String deviceMaj = "00000000";
        String deviceMin = "00000000";
        String remoteDeviceMaj = "00000000";
        String remoteDeviceMin = "00000000";
        String namesize = "000007";
        String chksum = "00000002"; // Incorrect CRC
        String name = "test";
        StringBuilder header = new StringBuilder();
        header.append(magic).append(inode).append(mode).append(uid).append(gid)
              .append(nlink).append(mtime).append(size).append(deviceMaj)
              .append(deviceMin).append(remoteDeviceMaj).append(remoteDeviceMin)
              .append(namesize).append(chksum).append(name).append("\0");
        // Padding to align to block size if necessary
        byte[] headerBytes = header.toString().getBytes(StandardCharsets.US_ASCII);
        byte[] data = "data".getBytes(StandardCharsets.US_ASCII);
        byte[] combined = new byte[headerBytes.length + data.length];
        System.arraycopy(headerBytes, 0, combined, 0, headerBytes.length);
        System.arraycopy(data, 0, combined, headerBytes.length, data.length);
        return combined;
    }

    private byte[] createMagicNewEntryWithBadPadCount() throws Exception {
        // Construct a MAGIC_NEW entry with incorrect header pad count
        String magic = "070701";
        String inode = "00000001";
        String mode = "00000000";
        String uid = "00000001";
        String gid = "00000001";
        String nlink = "00000001";
        String mtime = "00000001";
        String size = "00000004"; // 4 bytes of data
        String deviceMaj = "00000000";
        String deviceMin = "00000000";
        String remoteDeviceMaj = "00000000";
        String remoteDeviceMin = "00000000";
        String namesize = "000007";
        String chksum = "00000001";
        String name = "test";
        StringBuilder header = new StringBuilder();
        header.append(magic).append(inode).append(mode).append(uid).append(gid)
              .append(nlink).append(mtime).append(size).append(deviceMaj)
              .append(deviceMin).append(remoteDeviceMaj).append(remoteDeviceMin)
              .append(namesize).append(chksum).append(name).append("\0");
        // Intentionally incorrect padding
        byte[] headerBytes = header.toString().getBytes(StandardCharsets.US_ASCII);
        byte[] data = "data".getBytes(StandardCharsets.US_ASCII);
        byte[] combined = new byte[headerBytes.length + data.length - 1]; // Missing one byte
        System.arraycopy(headerBytes, 0, combined, 0, headerBytes.length);
        System.arraycopy(data, 0, combined, headerBytes.length, data.length - 1);
        return combined;
    }

    private byte[] createTrailerOnlyStream() throws Exception {
        // Construct a stream containing only the TRAILER!!! entry
        String magic = "070701";
        String inode = "00000000";
        String mode = "00000000";
        String uid = "00000000";
        String gid = "00000000";
        String nlink = "00000000";
        String mtime = "00000000";
        String size = "00000000";
        String deviceMaj = "00000000";
        String deviceMin = "00000000";
        String remoteDeviceMaj = "00000000";
        String remoteDeviceMin = "00000000";
        String namesize = "0000000A"; // Length of "TRAILER!!!\0"
        String chksum = "00000000";
        String name = "TRAILER!!!";
        StringBuilder header = new StringBuilder();
        header.append(magic).append(inode).append(mode).append(uid).append(gid)
              .append(nlink).append(mtime).append(size).append(deviceMaj)
              .append(deviceMin).append(remoteDeviceMaj).append(remoteDeviceMin)
              .append(namesize).append(chksum).append(name).append("\0");
        byte[] headerBytes = header.toString().getBytes(StandardCharsets.US_ASCII);
        return headerBytes;
    }

    private byte[] createIncompleteMagicNewEntry() throws Exception {
        // Construct an incomplete MAGIC_NEW entry where the stream ends unexpectedly
        String magic = "070701";
        String inode = "00000001";
        String mode = "00000000";
        String uid = "00000001";
        String gid = "00000001";
        String nlink = "00000001";
        String mtime = "00000001";
        String size = "00000004"; // 4 bytes of data
        String deviceMaj = "00000000";
        String deviceMin = "00000000";
        String remoteDeviceMaj = "00000000";
        String remoteDeviceMin = "00000000";
        String namesize = "000007";
        String chksum = "00000001";
        String name = "test";
        StringBuilder header = new StringBuilder();
        header.append(magic).append(inode).append(mode).append(uid).append(gid)
              .append(nlink).append(mtime).append(size).append(deviceMaj)
              .append(deviceMin).append(remoteDeviceMaj).append(remoteDeviceMin)
              .append(namesize).append(chksum).append(name).append("\0");
        byte[] headerBytes = header.toString().getBytes(StandardCharsets.US_ASCII);
        byte[] data = "dat".getBytes(StandardCharsets.US_ASCII); // Incomplete data (should be 4 bytes)
        byte[] combined = new byte[headerBytes.length + data.length];
        System.arraycopy(headerBytes, 0, combined, 0, headerBytes.length);
        System.arraycopy(data, 0, combined, headerBytes.length, data.length);
        return combined;
    }
}