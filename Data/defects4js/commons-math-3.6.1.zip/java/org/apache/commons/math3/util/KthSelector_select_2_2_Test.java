
package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

public class KthSelector_select_2_2_Test {

    @Test
    @DisplayName("Select with r1 as non-null, array size > MIN_SELECT_SIZE, z0 true, and i0 != i12")
    public void TC24() {
        // GIVEN
        double[] work = {10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0, 100.0, 110.0, 120.0, 130.0, 140.0, 150.0, 160.0, 170.0};
        int[] r1 = {2, 4, 6, 8};
        int k = 3;

        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, r1, k);

        // THEN
        double expected = work[k];
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("Select with r1 as non-null, array size > MIN_SELECT_SIZE, z0 true, and i0 >= i12")
    public void TC25() {
        // GIVEN
        double[] work = {25.0, 15.0, 35.0, 20.0, 30.0, 10.0, 40.0, 45.0, 50.0, 55.0, 60.0, 65.0, 70.0, 75.0, 80.0, 85.0, 90.0};
        int[] r1 = {3, 6, 9, 12};
        int k = 14;

        // WHEN
        KthSelector selector = new KthSelector();
        double result = selector.select(work, r1, k);

        // THEN
        double expected = Arrays.stream(work).sorted().toArray()[k];
        assertEquals(expected, result);
    }
}