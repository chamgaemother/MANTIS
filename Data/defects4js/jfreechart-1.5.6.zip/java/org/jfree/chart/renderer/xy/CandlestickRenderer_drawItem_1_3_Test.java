// package org.jfree.chart.renderer.xy;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.XYItemRendererState;
// import org.jfree.data.xy.OHLCDataset;
// import org.jfree.chart.ui.RectangleEdge;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.geom.Rectangle2D;
// 
// import static org.mockito.ArgumentMatchers.*;
// import static org.mockito.Mockito.*;
// 
// public class CandlestickRenderer_drawItem_1_3_Test {
// 
//     @Test
//     @DisplayName("drawItem uses outline paint when useOutlinePaint is true")
//     void TC11_drawItem_usesOutlinePaint_when_useOutlinePaint_true() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setUseOutlinePaint(true);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
//         when(dataset.getXValue(0, 0)).thenReturn(1.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(2.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(0.5);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(2.0);
//         when(dataset.getVolumeValue(0, 0)).thenReturn(1000.0);
// 
//         // Set Item Outline Paint
//         int series = 0;
//         int item = 0;
//         Paint outlinePaint = Color.BLACK;
//         renderer.setItemOutlinePaint(series, item, outlinePaint);
// 
//         // Mock PlotRenderingInfo and EntityCollection
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         Object owner = mock(Object.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(owner);
//         when(owner.getEntityCollection()).thenReturn(entities);
// 
//         // Mock other dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new XYItemRendererState(mock(PlotRenderingInfo.class));
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(400.0);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(300.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2).setPaint(outlinePaint);
//     }
// 
//     @Test
//     @DisplayName("drawItem uses item paint when useOutlinePaint is false")
//     void TC12_drawItem_usesItemPaint_when_useOutlinePaint_false() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         renderer.setUseOutlinePaint(false);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
//         when(dataset.getXValue(0, 0)).thenReturn(1.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(2.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(0.5);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(1.5);
//         when(dataset.getVolumeValue(0, 0)).thenReturn(1000.0);
// 
//         // Set Item Paint
//         int series = 0;
//         int item = 0;
//         Paint itemPaint = Color.BLUE;
//         renderer.setItemPaint(series, item, itemPaint);
// 
//         // Mock PlotRenderingInfo and EntityCollection
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         Object owner = mock(Object.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(owner);
//         when(owner.getEntityCollection()).thenReturn(entities);
// 
//         // Mock other dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new XYItemRendererState(mock(PlotRenderingInfo.class));
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(400.0);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(300.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
//         // Assert
//         verify(g2).setPaint(itemPaint);
//     }
// 
//     @Test
//     @DisplayName("drawItem handles yClose > yOpen for upPaint")
//     void TC13_drawItem_handles_yClose_greater_than_yOpen_for_upPaint() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         Paint upPaint = Color.GREEN;
//         renderer.setUpPaint(upPaint);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
//         when(dataset.getXValue(0, 0)).thenReturn(1.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(2.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(0.5);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(2.0); // yClose > yOpen
//         when(dataset.getVolumeValue(0, 0)).thenReturn(1000.0);
// 
//         // Mock PlotRenderingInfo and EntityCollection
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         Object owner = mock(Object.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(owner);
//         when(owner.getEntityCollection()).thenReturn(entities);
// 
//         // Mock other dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new XYItemRendererState(mock(PlotRenderingInfo.class));
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(400.0);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(300.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
// 
//         // Assert
//         verify(g2).setPaint(upPaint);
//         verify(g2).fill(any(Rectangle2D.class));
//     }
// 
//     @Test
//     @DisplayName("drawItem handles yClose < yOpen for downPaint")
//     void TC14_drawItem_handles_yClose_less_than_yOpen_for_downPaint() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
//         Paint downPaint = Color.RED;
//         renderer.setDownPaint(downPaint);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
//         when(dataset.getXValue(0, 0)).thenReturn(1.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(2.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(0.5);
//         when(dataset.getOpenValue(0, 0)).thenReturn(2.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(1.0); // yClose < yOpen
//         when(dataset.getVolumeValue(0, 0)).thenReturn(1000.0);
// 
//         // Mock PlotRenderingInfo and EntityCollection
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         Object owner = mock(Object.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(owner);
//         when(owner.getEntityCollection()).thenReturn(entities);
// 
//         // Mock other dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new XYItemRendererState(mock(PlotRenderingInfo.class));
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(400.0);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(300.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
// 
//         // Assert
//         verify(g2).setPaint(downPaint);
//         verify(g2).fill(any(Rectangle2D.class));
//     }
// 
//     @Test
//     @DisplayName("drawItem adds entity when EntityCollection is available")
//     void TC15_drawItem_addsEntity_when_EntityCollection_available() throws Exception {
//         // Arrange
//         CandlestickRenderer renderer = new CandlestickRenderer();
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getItemCount(0)).thenReturn(1);
//         when(dataset.getXValue(0, 0)).thenReturn(1.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(2.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(0.5);
//         when(dataset.getOpenValue(0, 0)).thenReturn(1.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(2.0);
//         when(dataset.getVolumeValue(0, 0)).thenReturn(1000.0);
// 
//         // Mock PlotRenderingInfo and EntityCollection
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         Object owner = mock(Object.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(owner);
//         when(owner.getEntityCollection()).thenReturn(entities);
// 
//         // Mock other dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = new XYItemRendererState(mock(PlotRenderingInfo.class));
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(400.0);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(300.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int pass = 0;
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
// 
//         // Assert
//         verify(entities).addEntity(any(), any(Rectangle2D.class), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble());
//     }
// }