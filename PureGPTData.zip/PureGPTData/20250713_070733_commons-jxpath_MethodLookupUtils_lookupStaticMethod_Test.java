import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.util.MethodLookupUtils;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

class MethodLookupUtilsTest {
    
    static class TestClass {
        public static void staticMethod() {}
        public static void staticMethod(String arg) {}
        public void instanceMethod() {}
    }
    
    static class OverloadedStaticMethods {
        public static void overloadedStaticMethod(String arg) {}
        public static void overloadedStaticMethod(Integer arg) {}
    }

    @Test
    void testLookupStaticMethodExactMatch() throws Exception {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "staticMethod", new Object[0]);
        assertNotNull(method);
        assertEquals("staticMethod", method.getName());
        assertEquals(0, method.getParameterCount());
    }

    @Test
    void testLookupStaticMethodExactMatchWithArgument() throws Exception {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "staticMethod", new Object[]{"test"});
        assertNotNull(method);
        assertEquals("staticMethod", method.getName());
        assertEquals(1, method.getParameterCount());
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    void testLookupStaticMethodWithNullParameter() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "staticMethod", new Object[]{null});
        assertNotNull(method);
        assertEquals("staticMethod", method.getName());
        assertEquals(1, method.getParameterCount());
    }

    @Test
    void testLookupStaticMethodAmbiguousMatch() {
        Exception exception = assertThrows(JXPathException.class, () -> {
            MethodLookupUtils.lookupStaticMethod(OverloadedStaticMethods.class, "overloadedStaticMethod", new Object[]{null});
        });
        assertTrue(exception.getMessage().contains("Ambiguous method call"));
    }

    @Test
    void testLookupStaticMethodNoMatch() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "nonExistentMethod", new Object[0]);
        assertNull(method);
    }

    @Test
    void testLookupStaticMethodIncorrectName() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "instanceMethod", new Object[0]);
        assertNull(method);
    }

    @Test
    void testLookupStaticMethodNullParameters() {
        Method method = MethodLookupUtils.lookupStaticMethod(TestClass.class, "staticMethod", null);
        assertNotNull(method);
        assertEquals("staticMethod", method.getName());
        assertEquals(0, method.getParameterCount());
    }
}