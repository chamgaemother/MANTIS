package org.apache.commons.lang3.text;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.text.Format;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ExtendedMessageFormat_applyPattern_0_3_Test {

    @Test
    @DisplayName("applyPattern encountering unreadable format element, expecting IllegalArgumentException")
    void TC11_applyPattern_with_unreadable_format_element() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", registry);

        // Directly set the registry field for testing purposes
        Field registryField = ExtendedMessageFormat.class.getDeclaredField("registry");
        registryField.setAccessible(true);
        registryField.set(emf, registry);

        String pattern = "Value: {0,}"; // Unreadable format element

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> emf.applyPattern(pattern));

        assertTrue(exception.getMessage().contains("Unreadable format element at position"));
    }

    @Test
    @DisplayName("applyPattern handling quoted strings correctly without affecting parsing")
    void TC12_applyPattern_with_quoted_strings() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", registry);

        // Directly set the registry field for testing purposes
        Field registryField = ExtendedMessageFormat.class.getDeclaredField("registry");
        registryField.setAccessible(true);
        registryField.set(emf, registry);

        String pattern = "He said, '{0,date}' to her."; // Pattern with quoted strings

        // WHEN
        emf.applyPattern(pattern);

        // THEN
        Field toPatternField = ExtendedMessageFormat.class.getDeclaredField("toPattern");
        toPatternField.setAccessible(true);
        String toPattern = (String) toPatternField.get(emf);

        assertEquals("He said, '{0,date}' to her.", toPattern);

        Field formatsField = MessageFormat.class.getDeclaredField("formats");
        formatsField.setAccessible(true);
        final Format[] formats = (Format[]) formatsField.get(emf);

        // Fix: Ensure formats array check is valid and safely handled
        assertNotNull(formats);
        if (formats.length > 0) {
            assertNotNull(formats[0]);
        }
    }

    @Test
    @DisplayName("applyPattern with unterminated quoted string, expecting IllegalArgumentException")
    void TC13_applyPattern_with_unterminated_quoted_string() throws Exception {
        // GIVEN
        Map<String, FormatFactory> registry = new HashMap<>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", registry);

        // Directly set the registry field for testing purposes
        Field registryField = ExtendedMessageFormat.class.getDeclaredField("registry");
        registryField.setAccessible(true);
        registryField.set(emf, registry);

        String pattern = "Start 'quoted string without end"; // Unterminated quoted string

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> emf.applyPattern(pattern));

        assertTrue(exception.getMessage().contains("Unterminated quoted string at position"));
    }
}