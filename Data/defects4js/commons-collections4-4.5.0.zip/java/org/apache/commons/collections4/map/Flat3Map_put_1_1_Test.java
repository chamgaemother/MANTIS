package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class Flat3Map_put_1_1_Test {

    @Test
    @DisplayName("put with existing key in delegateMap updates its value and returns the old value")
    public void TC19_putExistingKeyInDelegateMapUpdatesValueAndReturnsOldValue() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        HashedMap<Object, Object> delegate = new HashedMap<>();
        delegate.put("existingKey", "oldValue");

        // Use reflection to set the private delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);

        // Act
        Object result = map.put("existingKey", "newValue");

        // Assert
        assertEquals("newValue", delegate.get("existingKey"));
        assertEquals("oldValue", result);
    }

    @Test
    @DisplayName("put with key having same hashCode as existing key but not equal adds new key in delegateMap")
    public void TC20_putKeyWithSameHashCodeButNotEqualAddsNewKeyInDelegateMap() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        HashedMap<Object, Object> delegate = new HashedMap<>();
        Object existingKey = "Aa"; // "Aa".hashCode() == "BB".hashCode()
        Object newKey = "BB";
        delegate.put(existingKey, "value1");

        // Use reflection to set the private delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);

        // Act
        Object result = map.put(newKey, "value2");

        // Assert
        assertEquals("value2", delegate.get(newKey));
        assertNull(result, "put should return null when adding a new key");
        assertEquals(2, delegate.size(), "delegateMap should contain both keys");
    }

    @Test
    @DisplayName("put with null value for an existing key updates the value to null and returns the old value")
    public void TC21_putExistingKeyWithNullValueUpdatesValueToNullAndReturnsOldValue() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        HashedMap<Object, Object> delegate = new HashedMap<>();
        delegate.put("existingKey", "oldValue");

        // Use reflection to set the private delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);

        // Act
        Object result = map.put("existingKey", null);

        // Assert
        assertNull(delegate.get("existingKey"));
        assertEquals("oldValue", result);
    }

    @Test
    @DisplayName("put a new key with hashCode collision in delegateMap without affecting existing keys")
    public void TC22_putNewKeyWithHashCodeCollisionInDelegateMapWithoutAffectingExistingKeys() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();
        HashedMap<Object, Object> delegate = new HashedMap<>();
        Object key1 = "Aa"; // "Aa".hashCode() == "BB".hashCode()
        Object key2 = "BB";
        delegate.put(key1, "value1");

        // Use reflection to set the private delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);

        // Act
        Object result = map.put(key2, "value2");

        // Assert
        assertEquals("value2", delegate.get(key2));
        assertEquals("value1", delegate.get(key1), "Existing key should remain unaffected");
        assertNull(result, "put should return null when adding a new key");
    }
}