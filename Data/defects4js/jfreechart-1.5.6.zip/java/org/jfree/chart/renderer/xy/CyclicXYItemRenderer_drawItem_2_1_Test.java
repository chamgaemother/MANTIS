package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;

public class CyclicXYItemRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("TC17: drawItem with plotLines=true, domainAxis is CyclicNumberAxis, and cycleBound is greater than both x-values, no split occurs")
    public void test_TC17_drawItem_NoSplit_DomainCyclicCycleBoundGreaterThanXValues() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        renderer.setPlotLines(true);

        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis.getCycleBound()).thenReturn(150.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        ValueAxis rangeAxis = mock(ValueAxis.class);

        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(50.0);
        when(dataset.getXValue(0, 1)).thenReturn(120.0);
        when(dataset.getYValue(0, 1)).thenReturn(60.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Spy on the renderer to verify super.drawItem calls
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);

        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // THEN
        // Verify that super.drawItem was invoked once without splitting
        verify(spyRenderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    @DisplayName("TC18: drawItem with plotLines=true, domainAxis is CyclicNumberAxis, and cycleBound is less than both x-values, no split occurs")
    public void test_TC18_drawItem_NoSplit_DomainCyclicCycleBoundLessThanXValues() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        renderer.setPlotLines(true);

        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis.getCycleBound()).thenReturn(80.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        ValueAxis rangeAxis = mock(ValueAxis.class);

        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(50.0);
        when(dataset.getXValue(0, 1)).thenReturn(120.0);
        when(dataset.getYValue(0, 1)).thenReturn(60.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Spy on the renderer to verify super.drawItem calls
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);

        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // THEN
        // Verify that super.drawItem was invoked once without splitting
        verify(spyRenderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    @DisplayName("TC19: drawItem with plotLines=true, rangeAxis is CyclicNumberAxis, and cycleBound is greater than both y-values, no split occurs")
    public void test_TC19_drawItem_NoSplit_RangeCyclicCycleBoundGreaterThanYValues() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        renderer.setPlotLines(true);

        ValueAxis domainAxis = mock(ValueAxis.class);

        CyclicNumberAxis rangeAxis = mock(CyclicNumberAxis.class);
        when(rangeAxis.getCycleBound()).thenReturn(250.0);
        when(rangeAxis.isBoundMappedToLastCycle()).thenReturn(false);

        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(200.0);
        when(dataset.getXValue(0, 1)).thenReturn(120.0);
        when(dataset.getYValue(0, 1)).thenReturn(220.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Spy on the renderer to verify super.drawItem calls
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);

        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // THEN
        // Verify that super.drawItem was invoked once without splitting
        verify(spyRenderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    @DisplayName("TC20: drawItem with plotLines=true, rangeAxis is CyclicNumberAxis, and cycleBound is less than both y-values, no split occurs")
    public void test_TC20_drawItem_NoSplit_RangeCyclicCycleBoundLessThanYValues() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        renderer.setPlotLines(true);

        ValueAxis domainAxis = mock(ValueAxis.class);

        CyclicNumberAxis rangeAxis = mock(CyclicNumberAxis.class);
        when(rangeAxis.getCycleBound()).thenReturn(150.0);
        when(rangeAxis.isBoundMappedToLastCycle()).thenReturn(false);

        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(100.0);
        when(dataset.getXValue(0, 1)).thenReturn(120.0);
        when(dataset.getYValue(0, 1)).thenReturn(120.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Spy on the renderer to verify super.drawItem calls
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);

        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // THEN
        // Verify that super.drawItem was invoked once without splitting
        verify(spyRenderer, times(1)).drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
    }

    @Test
    @DisplayName("TC21: drawItem with plotLines=true, domainAxis is CyclicNumberAxis with cycle splitting, rangeAxis is not CyclicNumberAxis")
    public void test_TC21_drawItem_Split_DomainCyclic_RangeNonCyclic() throws Exception {
        // GIVEN
        CyclicXYItemRenderer renderer = new CyclicXYItemRenderer();
        renderer.setPlotLines(true);

        CyclicNumberAxis domainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis.getCycleBound()).thenReturn(100.0);
        when(domainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        ValueAxis rangeAxis = mock(ValueAxis.class);

        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getXValue(0, 0)).thenReturn(90.0);
        when(dataset.getYValue(0, 0)).thenReturn(50.0);
        when(dataset.getXValue(0, 1)).thenReturn(110.0);
        when(dataset.getYValue(0, 1)).thenReturn(60.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Spy on the renderer to verify super.drawItem calls
        CyclicXYItemRenderer spyRenderer = Mockito.spy(renderer);

        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        // THEN
        // Verify that super.drawItem was invoked twice due to cycle splitting
        verify(spyRenderer, times(2)).drawItem(
            eq(g2),
            eq(state),
            eq(dataArea),
            eq(info),
            eq(plot),
            eq(domainAxis),
            eq(rangeAxis),
            any(XYDataset.class),
            eq(0),
            eq(1),
            eq(crosshairState),
            eq(0)
        );
    }
}