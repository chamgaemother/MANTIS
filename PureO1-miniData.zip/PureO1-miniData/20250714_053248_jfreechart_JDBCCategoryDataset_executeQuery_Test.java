package org.jfree.data.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import org.jfree.data.category.DefaultCategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class JDBCCategoryDatasetTest {

    @Mock
    private Connection mockConnection;

    @Mock
    private Statement mockStatement;

    @Mock
    private ResultSet mockResultSet;

    @Mock
    private ResultSetMetaData mockMetaData;

    @InjectMocks
    private JDBCCategoryDataset dataset;

    @BeforeEach
    void setUp() throws SQLException {
        dataset = new JDBCCategoryDataset(mockConnection);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
    }

    @Test
    void executeQuery_NullConnection_ThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> {
            dataset.executeQuery(null, "SELECT * FROM table");
        });
    }

    @Test
    void executeQuery_InsufficientColumns_ThrowsSQLException() throws SQLException {
        when(mockStatement.executeQuery("SELECT column1 FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(1);

        SQLException exception = assertThrows(SQLException.class, () -> {
            dataset.executeQuery(mockConnection, "SELECT column1 FROM table");
        });

        assertTrue(exception.getMessage().contains("insufficient columns"));
    }

    @Test
    void executeQuery_EmptyResultSet_NoDataAdded() throws SQLException {
        when(mockStatement.executeQuery("SELECT column1, column2 FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockResultSet.next()).thenReturn(false);

        dataset.executeQuery(mockConnection, "SELECT column1, column2 FROM table");

        assertEquals(0, dataset.getRowCount());
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_TransposeTrue_NumericValuesAddedCorrectly() throws SQLException {
        dataset.setTranspose(true);
        when(mockStatement.executeQuery("SELECT category, value1, value2 FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(3);
        when(mockResultSet.next()).thenReturn(true, true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1", "Category2");
        when(mockMetaData.getColumnName(2)).thenReturn("Series1");
        when(mockMetaData.getColumnName(3)).thenReturn("Series2");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.DOUBLE);
        when(mockResultSet.getObject(2)).thenReturn(100, 200);
        when(mockResultSet.getObject(3)).thenReturn(123.45, 678.90);

        dataset.executeQuery(mockConnection, "SELECT category, value1, value2 FROM table");

        assertEquals(2, dataset.getRowCount());
        assertEquals(2, dataset.getColumnCount());
        assertEquals(100, dataset.getValue("Series1", "Category1"));
        assertEquals(200, dataset.getValue("Series1", "Category2"));
        assertEquals(123.45, dataset.getValue("Series2", "Category1"));
        assertEquals(678.90, dataset.getValue("Series2", "Category2"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_TransposeFalse_NumericValuesAddedCorrectly() throws SQLException {
        dataset.setTranspose(false);
        when(mockStatement.executeQuery("SELECT category, value1, value2 FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(3);
        when(mockResultSet.next()).thenReturn(true, true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1", "Category2");
        when(mockMetaData.getColumnName(2)).thenReturn("Series1");
        when(mockMetaData.getColumnName(3)).thenReturn("Series2");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.DOUBLE);
        when(mockResultSet.getObject(2)).thenReturn(100, 200);
        when(mockResultSet.getObject(3)).thenReturn(123.45, 678.90);

        dataset.executeQuery(mockConnection, "SELECT category, value1, value2 FROM table");

        assertEquals(2, dataset.getRowCount());
        assertEquals(2, dataset.getColumnCount());
        assertEquals(100, dataset.getValue("Category1", "Series1"));
        assertEquals(200, dataset.getValue("Category2", "Series1"));
        assertEquals(123.45, dataset.getValue("Category1", "Series2"));
        assertEquals(678.90, dataset.getValue("Category2", "Series2"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_NumericColumnTypes_AllHandled() throws SQLException {
        when(mockStatement.executeQuery("SELECT category, intCol, doubleCol, decimalCol FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(4);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockMetaData.getColumnName(2)).thenReturn("IntSeries");
        when(mockMetaData.getColumnName(3)).thenReturn("DoubleSeries");
        when(mockMetaData.getColumnName(4)).thenReturn("DecimalSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.DOUBLE);
        when(mockMetaData.getColumnType(4)).thenReturn(Types.DECIMAL);
        when(mockResultSet.getObject(2)).thenReturn(10);
        when(mockResultSet.getObject(3)).thenReturn(20.5);
        when(mockResultSet.getObject(4)).thenReturn(30.75);

        dataset.executeQuery(mockConnection, "SELECT category, intCol, doubleCol, decimalCol FROM table");

        assertEquals(1, dataset.getRowCount());
        assertEquals(3, dataset.getColumnCount());
        assertEquals(10, dataset.getValue("IntSeries", "Category1"));
        assertEquals(20.5, dataset.getValue("DoubleSeries", "Category1"));
        assertEquals(30.75, dataset.getValue("DecimalSeries", "Category1"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_DateColumnTypes_AllHandled() throws SQLException {
        when(mockStatement.executeQuery("SELECT category, dateCol, timeCol, timestampCol FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(4);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockMetaData.getColumnName(2)).thenReturn("DateSeries");
        when(mockMetaData.getColumnName(3)).thenReturn("TimeSeries");
        when(mockMetaData.getColumnName(4)).thenReturn("TimestampSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.DATE);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.TIME);
        when(mockMetaData.getColumnType(4)).thenReturn(Types.TIMESTAMP);
        Date date = new Date(1625077800000L);
        when(mockResultSet.getObject(2)).thenReturn(date);
        when(mockResultSet.getObject(3)).thenReturn(date);
        when(mockResultSet.getObject(4)).thenReturn(date);

        dataset.executeQuery(mockConnection, "SELECT category, dateCol, timeCol, timestampCol FROM table");

        assertEquals(1, dataset.getRowCount());
        assertEquals(3, dataset.getColumnCount());
        assertEquals(date.getTime(), dataset.getValue("DateSeries", "Category1"));
        assertEquals(date.getTime(), dataset.getValue("TimeSeries", "Category1"));
        assertEquals(date.getTime(), dataset.getValue("TimestampSeries", "Category1"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_StringColumnTypes_ValidNumbers() throws SQLException {
        when(mockStatement.executeQuery("SELECT category, strCol1, strCol2 FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(3);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockMetaData.getColumnName(2)).thenReturn("StrSeries1");
        when(mockMetaData.getColumnName(3)).thenReturn("StrSeries2");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.VARCHAR);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.CHAR);
        when(mockResultSet.getObject(2)).thenReturn("123.45");
        when(mockResultSet.getObject(3)).thenReturn("678");

        dataset.executeQuery(mockConnection, "SELECT category, strCol1, strCol2 FROM table");

        assertEquals(1, dataset.getRowCount());
        assertEquals(2, dataset.getColumnCount());
        assertEquals(123.45, dataset.getValue("StrSeries1", "Category1"));
        assertEquals(678.0, dataset.getValue("StrSeries2", "Category1"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_StringColumnTypes_InvalidNumbers_SuppressValue() throws SQLException {
        when(mockStatement.executeQuery("SELECT category, strCol FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockMetaData.getColumnName(2)).thenReturn("StrSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.VARCHAR);
        when(mockResultSet.getObject(2)).thenReturn("NotANumber");

        dataset.executeQuery(mockConnection, "SELECT category, strCol FROM table");

        assertEquals(1, dataset.getRowCount());
        assertEquals(1, dataset.getColumnCount());
        assertNull(dataset.getValue("StrSeries", "Category1"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_DefaultColumnType_Ignored() throws SQLException {
        when(mockStatement.executeQuery("SELECT category, blobCol FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockMetaData.getColumnName(2)).thenReturn("BlobSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.BLOB);
        when(mockResultSet.getObject(2)).thenReturn(null);

        dataset.executeQuery(mockConnection, "SELECT category, blobCol FROM table");

        assertEquals(1, dataset.getRowCount());
        assertEquals(1, dataset.getColumnCount());
        assertNull(dataset.getValue("BlobSeries", "Category1"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_MultipleRows_DataAddedCorrectly() throws SQLException {
        when(mockStatement.executeQuery("SELECT category, value FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockResultSet.next()).thenReturn(true, true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1", "Category2");
        when(mockMetaData.getColumnName(2)).thenReturn("Series1");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockResultSet.getObject(2)).thenReturn(100, 200);

        dataset.executeQuery(mockConnection, "SELECT category, value FROM table");

        assertEquals(2, dataset.getRowCount());
        assertEquals(1, dataset.getColumnCount());
        assertEquals(100, dataset.getValue("Series1", "Category1"));
        assertEquals(200, dataset.getValue("Series1", "Category2"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_PreviousDataClearedBeforeAddingNewData() throws SQLException {
        // Add initial data
        dataset.addValue(50, "InitialSeries", "InitialCategory");

        when(mockStatement.executeQuery("SELECT category, value FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockMetaData.getColumnName(2)).thenReturn("Series1");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockResultSet.getObject(2)).thenReturn(100);

        dataset.executeQuery(mockConnection, "SELECT category, value FROM table");

        assertEquals(1, dataset.getRowCount());
        assertNull(dataset.getValue("InitialSeries", "InitialCategory"));
        assertEquals(100, dataset.getValue("Series1", "Category1"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_ColumnCountBoundary_TwoColumns() throws SQLException {
        when(mockStatement.executeQuery("SELECT category, value FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockMetaData.getColumnName(2)).thenReturn("Series1");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockResultSet.getObject(2)).thenReturn(100);

        dataset.executeQuery(mockConnection, "SELECT category, value FROM table");

        assertEquals(1, dataset.getRowCount());
        assertEquals(1, dataset.getColumnCount());
        assertEquals(100, dataset.getValue("Series1", "Category1"));
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_SQLExceptionThrown_RaisesException() throws SQLException {
        when(mockStatement.executeQuery("SELECT * FROM table")).thenThrow(new SQLException("Query failed"));

        SQLException exception = assertThrows(SQLException.class, () -> {
            dataset.executeQuery(mockConnection, "SELECT * FROM table");
        });

        assertEquals("Query failed", exception.getMessage());
        verify(mockStatement).close();
    }

    @Test
    void executeQuery_NullResultSet_MetaDataThrowsSQLException() throws SQLException {
        when(mockStatement.executeQuery("SELECT * FROM table")).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenThrow(new SQLException("MetaData error"));

        SQLException exception = assertThrows(SQLException.class, () -> {
            dataset.executeQuery(mockConnection, "SELECT * FROM table");
        });

        assertEquals("MetaData error", exception.getMessage());
        verify(mockResultSet).close();
        verify(mockStatement).close();
    }
}