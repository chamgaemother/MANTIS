import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYStepAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class XYStepAreaRendererTest {

    private XYStepAreaRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;
    private EntityCollection entities;

    @BeforeEach
    public void setUp() {
        renderer = new XYStepAreaRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
        entities = mock(EntityCollection.class);

        when(state.getEntityCollection()).thenReturn(entities);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getOutlineStroke()).thenReturn(mock(Stroke.class));
        when(plot.getOutlinePaint()).thenReturn(mock(Paint.class));
    }

    @Test
    public void testDrawItem_Vertical_FirstItem_NonNaY1_PlotAreaFalse_ShapesVisibleFalse() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(state.getItemCount()).thenReturn(2);
        renderer.setPlotArea(false);
        renderer.setShapesVisible(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
        verify(entities, never()).add(any(Shape.class), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_Vertical_NonFirstItem_NonNaY1_PlotAreaTrue_ShapesVisibleTrue() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);
        when(state.getItemCount()).thenReturn(2);
        renderer.setPlotArea(true);
        renderer.setShapesVisible(true);
        renderer.setOutline(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
        verify(entities).add(any(Shape.class), eq(dataset), eq(0), eq(1), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_Vertical_NaY1() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(renderer.getRangeBase(), dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(state.getItemCount()).thenReturn(1);
        renderer.setPlotArea(true);
        renderer.setOutline(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_Horizontal_ValidInputs() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(15.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(25.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, plot.getRangeAxisEdge())).thenReturn(110.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge())).thenReturn(160.0);
        when(rangeAxis.valueToJava2D(25.0, dataArea, plot.getRangeAxisEdge())).thenReturn(210.0);
        when(state.getItemCount()).thenReturn(2);
        renderer.setPlotArea(true);
        renderer.setShapesVisible(true);
        renderer.setOutline(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
        verify(entities).add(any(Shape.class), eq(dataset), eq(0), eq(1), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_ItemZero_NonNaY1_PlotAreaTrue() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(5.0);
        when(domainAxis.valueToJava2D(0.0, dataArea, plot.getDomainAxisEdge())).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, plot.getRangeAxisEdge())).thenReturn(60.0);
        when(state.getItemCount()).thenReturn(1);
        renderer.setPlotArea(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_ShapesVisible_Filled() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(state.getItemCount()).thenReturn(1);
        renderer.setShapesVisible(true);
        renderer.setShapesFilled(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_ShapesVisible_NotFilled() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(state.getItemCount()).thenReturn(1);
        renderer.setShapesVisible(true);
        renderer.setShapesFilled(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(g2).draw(any(Shape.class));
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    public void testDrawItem_PlotAreaTrue_LastItem_NonNaY1() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(renderer.getRangeBase(), dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(state.getItemCount()).thenReturn(2);
        renderer.setPlotArea(true);
        renderer.setOutline(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_PlotAreaTrue_LastItem_NaY1() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(renderer.getRangeBase(), dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(state.getItemCount()).thenReturn(2);
        renderer.setPlotArea(true);
        renderer.setOutline(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_NullEntities() {
        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(state.getItemCount()).thenReturn(1);
        renderer.setShapesVisible(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(entities, never()).add(any(Shape.class), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_OrientationNull() {
        when(plot.getOrientation()).thenReturn(null);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(state.getItemCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Expect no exception, behavior undefined, just ensure no crash
    }

    @Test
    public void testDrawItem_NullGraphics() {
        when(dataset.getItemCount(0)).thenReturn(1);
        renderer.setPlotArea(true);

        renderer.drawItem(null, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Expect no exception, renderer should handle null Graphics2D gracefully
    }

    @Test
    public void testDrawItem_NullPlot() {
        when(dataset.getItemCount(0)).thenReturn(1);
        renderer.setPlotArea(true);

        renderer.drawItem(g2, state, dataArea, info, null, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Expect no exception, renderer should handle null plot gracefully
    }

    @Test
    public void testDrawItem_NullDataset() {
        renderer.setPlotArea(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, crosshairState, 0);

        // Expect no exception, renderer should handle null dataset gracefully
    }

    @Test
    public void testDrawItem_InvalidStepPoint() {
        renderer.setStepPoint(-0.1);
        // Expect IllegalArgumentException
    }

    @Test
    public void testDrawItem_StepPointBoundary0() {
        renderer.setStepPoint(0.0);
        // Further implementation can be done to test behavior
    }

    @Test
    public void testDrawItem_StepPointBoundary1() {
        renderer.setStepPoint(1.0);
        // Further implementation can be done to test behavior
    }

    @Test
    public void testDrawItem_UpdateCrosshair() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.5);
        when(dataset.getYValue(0, 0)).thenReturn(12.5);
        when(domainAxis.valueToJava2D(1.5, dataArea, plot.getDomainAxisEdge())).thenReturn(75.0);
        when(rangeAxis.valueToJava2D(12.5, dataArea, plot.getRangeAxisEdge())).thenReturn(125.0);
        when(state.getItemCount()).thenReturn(1);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        verify(crosshairState).addCrosshair(any(), eq(1.5), eq(12.5), eq(0));
    }

    @Test
    public void testDrawItem_Y0NaN() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(renderer.getRangeBase(), dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);
        when(state.getItemCount()).thenReturn(2);
        renderer.setPlotArea(true);
        renderer.setOutline(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    public void testDrawItem_RepeatedFillAndDraw() {
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(10.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(20.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(30.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(100.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, plot.getDomainAxisEdge())).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(200.0);
        when(domainAxis.valueToJava2D(3.0, dataArea, plot.getDomainAxisEdge())).thenReturn(250.0);
        when(rangeAxis.valueToJava2D(30.0, dataArea, plot.getRangeAxisEdge())).thenReturn(300.0);
        when(state.getItemCount()).thenReturn(3);
        renderer.setPlotArea(true);
        renderer.setOutline(true);
        renderer.setShapesVisible(true);
        renderer.setShapesFilled(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 2, crosshairState, 0);

        verify(g2, atLeastOnce()).fill(any(Shape.class));
        verify(g2, atLeastOnce()).draw(any(Shape.class));
        verify(entities, atLeastOnce()).add(any(Shape.class), eq(dataset), eq(0), eq(2), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItem_RestrictValueToDataArea_Low() {
        // Assuming restrictValueToDataArea is tested implicitly by mocking valueToJava2D
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(-10.0);
        when(dataset.getYValue(0, 0)).thenReturn(-20.0);
        when(domainAxis.valueToJava2D(-10.0, dataArea, plot.getDomainAxisEdge())).thenReturn(-50.0);
        when(rangeAxis.valueToJava2D(-20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(-100.0);
        when(rangeAxis.valueToJava2D(renderer.getRangeBase(), dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(state.getItemCount()).thenReturn(1);
        renderer.setPlotArea(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Expect restrictValueToDataArea to clamp values, verify fill is called
        verify(g2).fill(any(Shape.class));
    }

    @Test
    public void testDrawItem_RestrictValueToDataArea_High() {
        // Assuming restrictValueToDataArea is tested implicitly by mocking valueToJava2D
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1000.0);
        when(dataset.getYValue(0, 0)).thenReturn(2000.0);
        when(domainAxis.valueToJava2D(1000.0, dataArea, plot.getDomainAxisEdge())).thenReturn(1000.0);
        when(rangeAxis.valueToJava2D(2000.0, dataArea, plot.getRangeAxisEdge())).thenReturn(2000.0);
        when(state.getItemCount()).thenReturn(1);
        renderer.setPlotArea(true);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Expect restrictValueToDataArea to clamp values, verify fill is called
        verify(g2).fill(any(Shape.class));
    }
}