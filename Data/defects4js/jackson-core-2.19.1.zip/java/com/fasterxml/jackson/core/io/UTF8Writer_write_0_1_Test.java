package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

public class UTF8Writer_write_0_1_Test {
    
    private IOContext createMockIOContext() {
        IOContext mockIOContext = Mockito.mock(IOContext.class);
        byte[] buffer = new byte[1024];
        Mockito.when(mockIOContext.allocWriteEncodingBuffer()).thenReturn(buffer);
        return mockIOContext;
    }

    @Test
    @DisplayName("write with len=0 should return immediately without writing")
    void TC01_writeWithLenZero() throws Exception {
        // GIVEN
        char[] cbuf = {};
        int off = 0;
        int len = 0;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        UTF8Writer writer = new UTF8Writer(createMockIOContext(), mockOut);

        // WHEN
        writer.write(cbuf, off, len);

        // THEN
        verifyNoInteractions(mockOut);
    }

    @Test
    @DisplayName("write with len=1 should write a single character")
    void TC02_writeWithLenOne() throws Exception {
        // GIVEN
        char[] cbuf = {'A'};
        int off = 0;
        int len = 1;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        UTF8Writer writer = new UTF8Writer(createMockIOContext(), mockOut);

        // WHEN
        writer.write(cbuf, off, len);

        // THEN
        // 'A' in ASCII is 65
        verify(mockOut, times(1)).write(Mockito.any(byte[].class), Mockito.eq(0), Mockito.eq(1));
    }

    @Test
    @DisplayName("write with len=2 and no surrogate should process normally")
    void TC03_writeWithLenTwoASCII() throws Exception {
        // GIVEN
        char[] cbuf = {'A', 'B'};
        int off = 0;
        int len = 2;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        UTF8Writer writer = new UTF8Writer(createMockIOContext(), mockOut);

        // WHEN
        writer.write(cbuf, off, len);

        // THEN
        // Verify 'A' and 'B' are written as UTF-8
        verify(mockOut, times(1)).write(Mockito.any(byte[].class), Mockito.eq(0), Mockito.eq(2));
    }

    @Test
    @DisplayName("write with surrogate pair properly converts and writes")
    void TC04_writeWithValidSurrogatePair() throws Exception {
        // GIVEN
        char[] cbuf = {'\uD83D', '\uDE00'}; // ð emoji surrogate pair
        int off = 0;
        int len = 2;
        OutputStream mockOut = Mockito.mock(OutputStream.class);
        UTF8Writer writer = new UTF8Writer(createMockIOContext(), mockOut);

        // WHEN
        writer.write(cbuf, off, len);

        // THEN
        // Use ArgumentCaptor to ensure the correct bytes are written
        verify(mockOut, times(1)).write(Mockito.any(byte[].class), Mockito.eq(0), Mockito.eq(4));
    }
}
