package org.apache.commons.jxpath.functions;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.apache.commons.jxpath.ExpressionContext;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;

public class MethodFunction_invoke_0_3_Test {

    // Nested class with target methods for testing
    public static class TestTarget {
        public static boolean methodCalled = false;
        public static Object[] lastInvocationParams = null;

        public static Object multipleParamMethod(ExpressionContext context, Integer param1, String param2, Double param3, Boolean param4) {
            methodCalled = true;
            lastInvocationParams = new Object[]{param1, param2, param3, param4};
            return "success";
        }

        public static Object singleParamMethod(ExpressionContext context, String param1) {
            methodCalled = true;
            lastInvocationParams = new Object[]{param1};
            return "success";
        }
    }

    @Test
    @DisplayName("Loop within parameters processing executes multiple iterations")
    void testTC11() throws Exception {
        // Reset flags
        TestTarget.methodCalled = false;
        TestTarget.lastInvocationParams = null;

        // Obtain Method object for multipleParamMethod
        Method method = TestTarget.class.getMethod("multipleParamMethod", ExpressionContext.class, Integer.class, String.class, Double.class, Boolean.class);

        // Instantiate MethodFunction with the target method
        MethodFunction function = new MethodFunction(method);

        // Create a mock ExpressionContext
        ExpressionContext context = mock(ExpressionContext.class);

        // Define parameters to be converted
        Object[] parameters = { "1", "test", "3.14", "true" };

        // Invoke the method under test
        Object result = function.invoke(context, parameters);

        // Assertions
        assertNotNull(result, "Result should not be null");
        assertTrue(TestTarget.methodCalled, "Target method should have been called");
        assertArrayEquals(new Object[]{1, "test", 3.14, true}, TestTarget.lastInvocationParams, "Parameters should be converted correctly");
    }

    @Test
    @DisplayName("Loop within parameters processing executes single iteration")
    void testTC12() throws Exception {
        // Reset flags
        TestTarget.methodCalled = false;
        TestTarget.lastInvocationParams = null;

        // Obtain Method object for singleParamMethod
        Method method = TestTarget.class.getMethod("singleParamMethod", ExpressionContext.class, String.class);

        // Instantiate MethodFunction with the target method
        MethodFunction function = new MethodFunction(method);

        // Create a mock ExpressionContext
        ExpressionContext context = mock(ExpressionContext.class);

        // Define parameters to be converted
        Object[] parameters = { "test" };

        // Invoke the method under test
        Object result = function.invoke(context, parameters);

        // Assertions
        assertNotNull(result, "Result should not be null");
        assertTrue(TestTarget.methodCalled, "Target method should have been called");
        assertArrayEquals(new Object[]{"test"}, TestTarget.lastInvocationParams, "Parameters should be converted correctly");
    }
}