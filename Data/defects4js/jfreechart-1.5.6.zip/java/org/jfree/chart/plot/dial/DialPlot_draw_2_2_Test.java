package org.jfree.chart.plot.dial;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class DialPlot_draw_2_2_Test {

    @Test
    @DisplayName("Draw method with non-null and visible background, no layers, no pointers, no cap, dialFrame not visible")
    void TC11() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        DialLayer background = mock(DialLayer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);
        Shape originalClip = mock(Shape.class);

        when(g2.getClip()).thenReturn(originalClip);
        when(background.isVisible()).thenReturn(true);
        when(background.isClippedToWindow()).thenReturn(false);
        plot.setBackground(background);
        plot.setCap(null);

        DialFrame dialFrame = plot.getDialFrame();
        Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, false);

        // Accessing private method viewToFrame via reflection
        Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        Rectangle2D frame = (Rectangle2D) viewToFrameMethod.invoke(plot, area);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(background).draw(g2, plot, frame, area);
        verify(g2).setClip(originalClip);
    }

    @Test
    @DisplayName("Draw method with non-null and visible background clipped to window, no layers, no pointers, no cap, dialFrame not visible")
    void TC12() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        DialLayer background = mock(DialLayer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);
        Shape originalClip = mock(Shape.class);

        when(g2.getClip()).thenReturn(originalClip);
        when(background.isVisible()).thenReturn(true);
        when(background.isClippedToWindow()).thenReturn(true);
        plot.setBackground(background);
        plot.setCap(null);

        DialFrame dialFrame = plot.getDialFrame();
        Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, false);

        // Accessing private method viewToFrame via reflection
        Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        Rectangle2D frame = (Rectangle2D) viewToFrameMethod.invoke(plot, area);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(g2).clip(any(Shape.class));
        verify(background).draw(g2, plot, frame, area);
        verify(g2).setClip(originalClip);
    }

    @Test
    @DisplayName("Draw method with non-null and visible background, visible layers and pointers, no cap, dialFrame visible")
    void TC13() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        DialLayer background = mock(DialLayer.class);
        DialLayer layer1 = mock(DialLayer.class);
        DialLayer layer2 = mock(DialLayer.class);
        DialPointer pointer1 = mock(DialPointer.class);
        DialPointer pointer2 = mock(DialPointer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);
        Shape originalClip = mock(Shape.class);

        when(g2.getClip()).thenReturn(originalClip);
        when(background.isVisible()).thenReturn(true);
        when(background.isClippedToWindow()).thenReturn(false);
        plot.setBackground(background);

        when(layer1.isVisible()).thenReturn(true);
        when(layer1.isClippedToWindow()).thenReturn(false);
        when(layer2.isVisible()).thenReturn(true);
        when(layer2.isClippedToWindow()).thenReturn(false);
        plot.addLayer(layer1);
        plot.addLayer(layer2);

        when(pointer1.isVisible()).thenReturn(true);
        when(pointer1.isClippedToWindow()).thenReturn(false);
        when(pointer2.isVisible()).thenReturn(true);
        when(pointer2.isClippedToWindow()).thenReturn(false);
        plot.addPointer(pointer1);
        plot.addPointer(pointer2);

        plot.setCap(null);

        DialFrame dialFrame = plot.getDialFrame();
        Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, true);

        // Accessing private method viewToFrame via reflection
        Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        Rectangle2D frame = (Rectangle2D) viewToFrameMethod.invoke(plot, area);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(background).draw(g2, plot, frame, area);
        verify(layer1).draw(g2, plot, frame, area);
        verify(layer2).draw(g2, plot, frame, area);
        verify(pointer1).draw(g2, plot, frame, area);
        verify(pointer2).draw(g2, plot, frame, area);
        verify(dialFrame).draw(g2, plot, frame, area);
        verify(g2).setClip(originalClip);
    }

    @Test
    @DisplayName("Draw method with non-null and visible background clipped to window, visible layers and pointers clipped to window, no cap, dialFrame visible")
    void TC14() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        DialLayer background = mock(DialLayer.class);
        DialLayer layer1 = mock(DialLayer.class);
        DialLayer layer2 = mock(DialLayer.class);
        DialPointer pointer1 = mock(DialPointer.class);
        DialPointer pointer2 = mock(DialPointer.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);
        Shape originalClip = mock(Shape.class);

        when(g2.getClip()).thenReturn(originalClip);
        when(background.isVisible()).thenReturn(true);
        when(background.isClippedToWindow()).thenReturn(true);
        plot.setBackground(background);

        when(layer1.isVisible()).thenReturn(true);
        when(layer1.isClippedToWindow()).thenReturn(true);
        when(layer2.isVisible()).thenReturn(true);
        when(layer2.isClippedToWindow()).thenReturn(true);
        plot.addLayer(layer1);
        plot.addLayer(layer2);

        when(pointer1.isVisible()).thenReturn(true);
        when(pointer1.isClippedToWindow()).thenReturn(true);
        when(pointer2.isVisible()).thenReturn(true);
        when(pointer2.isClippedToWindow()).thenReturn(true);
        plot.addPointer(pointer1);
        plot.addPointer(pointer2);

        plot.setCap(null);

        DialFrame dialFrame = plot.getDialFrame();
        Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, true);

        // Accessing private method viewToFrame via reflection
        Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        Rectangle2D frame = (Rectangle2D) viewToFrameMethod.invoke(plot, area);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(g2).clip(any(Shape.class));
        verify(background).draw(g2, plot, frame, area);
        verify(layer1).draw(g2, plot, frame, area);
        verify(layer2).draw(g2, plot, frame, area);
        verify(pointer1).draw(g2, plot, frame, area);
        verify(pointer2).draw(g2, plot, frame, area);
        verify(dialFrame).draw(g2, plot, frame, area);
        verify(g2).setClip(originalClip);
    }

}