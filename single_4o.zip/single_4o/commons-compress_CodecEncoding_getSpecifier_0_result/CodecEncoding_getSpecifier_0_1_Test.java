package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CodecEncoding_getSpecifier_0_1_Test {

    private static Map<BHSDCodec, Integer> originalCanonicalCodecsToSpecifiers;
    private static Field canonicalCodecsToSpecifiersField;

    @BeforeAll
    static void setUp() throws Exception {
        // Prepare reflection to modify the private map
        canonicalCodecsToSpecifiersField = CodecEncoding.class.getDeclaredField("canonicalCodecsToSpecifiers");
        canonicalCodecsToSpecifiersField.setAccessible(true);
        // Store original map to restore later if needed
        originalCanonicalCodecsToSpecifiers = (Map<BHSDCodec, Integer>) canonicalCodecsToSpecifiersField.get(null);
    }

    @Test
    @DisplayName("GIVEN known codec in canonicalCodecsToSpecifiers THEN return its specifier directly")
    void testTC01() throws Exception {
        // GIVEN
        Map<BHSDCodec, Integer> canonicalCodecsToSpecifiers = new HashMap<>();
        BHSDCodec mockCodec = new BHSDCodec(1, 256);
        canonicalCodecsToSpecifiers.put(mockCodec, 42);

        // Use reflection to set the private map
        canonicalCodecsToSpecifiersField.set(null, canonicalCodecsToSpecifiers);

        // WHEN
        int[] result = CodecEncoding.getSpecifier(mockCodec, new BHSDCodec(1, 256));

        // THEN
        assertArrayEquals(new int[]{42}, result);
    }

    @Test
    @DisplayName("GIVEN BHSDCodec THEN return calculated specifiers")
    void testTC02() {
        // GIVEN
        BHSDCodec bhsdCodec = new BHSDCodec(3, 5, 7, false);

        // WHEN
        int[] result = CodecEncoding.getSpecifier(bhsdCodec, new BHSDCodec(1, 256));

        // THEN
        int expectedSpecifier1 = 116;
        int expectedSpecifier2 = 0 + 2 * 5 + 8 * (3 - 1);
        int expectedSpecifier3 = 7 - 1;
        assertArrayEquals(new int[]{expectedSpecifier1, expectedSpecifier2, expectedSpecifier3}, result);
    }

    @Test
    @DisplayName("GIVEN BHSDCodec with isDelta true THEN return correct specifiers")
    void testTC03() {
        // GIVEN
        BHSDCodec bhsdCodec = new BHSDCodec(3, 5, 7, true);

        // WHEN
        int[] result = CodecEncoding.getSpecifier(bhsdCodec, new BHSDCodec(1, 256));

        // THEN
        int expectedSpecifier1 = 116;
        int expectedSpecifier2 = 1 + 2 * 5 + 8 * (3 - 1);
        int expectedSpecifier3 = 7 - 1;
        assertArrayEquals(new int[]{expectedSpecifier1, expectedSpecifier2, expectedSpecifier3}, result);
    }

    @Test
    @DisplayName("GIVEN RunCodec with k <= 256 THEN return correct specifier")
    void testTC04() {
        // GIVEN
        RunCodec runCodec = new RunCodec(255, new BHSDCodec(1, 256), new BHSDCodec(1, 256));

        // WHEN
        int[] result = CodecEncoding.getSpecifier(runCodec, new BHSDCodec(1, 256));

        // THEN
        int expectedFirstElement = 117;
        assertEquals(expectedFirstElement, result[0]);
    }

    @Test
    @DisplayName("GIVEN RunCodec with k > 256 but <= 4096 THEN use specific division")
    void testTC05() {
        // GIVEN
        RunCodec runCodec = new RunCodec(3000, new BHSDCodec(1, 256), new BHSDCodec(1, 256));

        // WHEN
        int[] result = CodecEncoding.getSpecifier(runCodec, new BHSDCodec(1, 256));

        // THEN
        int expectedFirstElement = 118;
        assertEquals(expectedFirstElement, result[0]);
    }
}