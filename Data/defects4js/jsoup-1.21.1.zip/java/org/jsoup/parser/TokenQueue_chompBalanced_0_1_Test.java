package org.jsoup.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TokenQueue_chompBalanced_0_1_Test {

    @Test
    @DisplayName("ChompBalanced with empty TokenQueue returns empty string")
    void TC01_chompBalanced_with_empty_TokenQueue_returns_empty_string() {
        // GIVEN
        TokenQueue queue = new TokenQueue("");

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("", result);
    }

    @Test
    @DisplayName("ChompBalanced with single balanced open and close characters")
    void TC02_chompBalanced_with_single_balanced_pair() {
        // GIVEN
        TokenQueue queue = new TokenQueue("()" /* Removed additional parameters */);

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("", result);
    }

    @Test
    @DisplayName("ChompBalanced with multiple nested balanced pairs")
    void TC03_chompBalanced_with_nested_balanced_pairs() {
        // GIVEN
        TokenQueue queue = new TokenQueue("((()))" /* Removed additional parameters */);

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("(())", result);
    }

    @Test
    @DisplayName("ChompBalanced with unbalanced open and close characters throws exception")
    void TC04_chompBalanced_with_unbalanced_open_characters_throws_exception() {
        // GIVEN
        TokenQueue queue = new TokenQueue("((()" /* Removed additional parameters */);

        // WHEN & THEN
        Exception exception = assertThrows(IllegalStateException.class, () -> { // Fixed exception type
            queue.chompBalanced('(', ')');
        });
        assertTrue(exception.getMessage().contains("Did not find balanced marker"));
    }

    @Test
    @DisplayName("ChompBalanced with escaped single quotes inside string")
    void TC05_chompBalanced_with_escaped_single_quotes() {
        // GIVEN
        TokenQueue queue = new TokenQueue("'\"'"); // Fixed string literal

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("'", result);
    }

}