package org.apache.commons.math3.geometry.euclidean.threed;

import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
import org.apache.commons.math3.geometry.euclidean.threed.Rotation;
import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Rotation_getAngles_2_2_Test {

    @Test
    @DisplayName("TC16: getAngles with FRAME_TRANSFORM convention and YXZ order where v2.getZ() exceeds upper boundary, throwing exception")
    void TC16() {
        Rotation rotation = new Rotation(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM, Math.PI / 2 + 1e-10, 0.0, 0.0);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    @DisplayName("TC17: getAngles with FRAME_TRANSFORM convention and ZXY order where v2.getY() is within bounds")
    void TC17() {
        Rotation rotation = new Rotation(RotationOrder.ZXY, RotationConvention.FRAME_TRANSFORM, 0.1, 0.2, 0.3);
        double[] angles = rotation.getAngles(RotationOrder.ZXY, RotationConvention.FRAME_TRANSFORM);
        // Replace the expected values with actual expected angles based on your calculations
        double expectedAlpha = 0.1; // Example value
        double expectedBeta = 0.2;  // Example value
        double expectedGamma = 0.3; // Example value
        assertAll("Angles",
            () -> assertEquals(expectedAlpha, angles[0], 1e-6, "Alpha angle mismatch"),
            () -> assertEquals(expectedBeta, angles[1], 1e-6, "Beta angle mismatch"),
            () -> assertEquals(expectedGamma, angles[2], 1e-6, "Gamma angle mismatch")
        );
    }

    @Test
    @DisplayName("TC18: getAngles with FRAME_TRANSFORM convention and ZXY order where v2.getY() exceeds upper boundary, throwing exception")
    void TC18() {
        Rotation rotation = new Rotation(RotationOrder.ZXY, RotationConvention.FRAME_TRANSFORM, Math.PI / 2 + 1e-10, 0.0, 0.0);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZXY, RotationConvention.FRAME_TRANSFORM);
        });
    }

    @Test
    @DisplayName("TC19: getAngles with FRAME_TRANSFORM convention and XYX order where angles lead to minimal rotation")
    void TC19() {
        double epsilon = 1e-10;
        Rotation rotation = new Rotation(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM, epsilon, epsilon, epsilon);
        double[] angles = rotation.getAngles(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM);
        assertAll("Minimal Rotation Angles",
            () -> assertEquals(0.0, angles[0], 1e-6, "Alpha angle should be approximately zero"),
            () -> assertEquals(0.0, angles[1], 1e-6, "Beta angle should be approximately zero"),
            () -> assertEquals(0.0, angles[2], 1e-6, "Gamma angle should be approximately zero")
        );
    }

    @Test
    @DisplayName("TC20: getAngles with FRAME_TRANSFORM convention and XYX order where angles exceed boundaries, throwing exception")
    void TC20() {
        Rotation rotation = new Rotation(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM, Math.PI / 2 + 1e-10, 0.0, 0.0);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM);
        });
    }
}