package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Array;
import java.lang.reflect.Field;

public class ConcurrentReferenceHashMap_size_0_2_Test {

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() with no segments results in 0 size")
    void testSizeWithNoSegments() throws Exception {
        // Setup
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        Class<?> segmentArrayClass = Array.newInstance(map.segments.getClass().getComponentType(), 0).getClass();

        // Using reflection to set the segments array to empty
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        segmentsField.set(map, Array.newInstance(map.segments.getClass().getComponentType(), 0));

        // Act
        int result = map.size();

        // Assert
        assertEquals(0, result, "Expected size to be 0 when no segments are present");
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() handles segments with mixed segment lengths and returns correct size")
    void testSizeWithMixedSegments() throws Exception {
        // Setup
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        Class<?> segmentClass = map.segments.getClass().getComponentType();
        Object segment1 = segmentClass.getConstructor(int.class, float.class, int.class).newInstance(1, 1.0f, 1);
        Object segment2 = segmentClass.getConstructor(int.class, float.class, int.class).newInstance(1, 1.0f, 1);

        // Using reflection to set counts
        Field countField = segmentClass.getDeclaredField("count");
        countField.setAccessible(true);
        countField.set(segment1, 2);
        countField.setAccessible(true);
        countField.set(segment2, 3);

        // Setting modCounts to match to simulate stable state
        Field modCountField = segmentClass.getDeclaredField("modCount");
        modCountField.setAccessible(true);
        modCountField.set(segment1, 1);
        modCountField.set(segment2, 1);

        // Put segments into the map
        Object segmentsArray = Array.newInstance(segmentClass, 2);
        Array.set(segmentsArray, 0, segment1);
        Array.set(segmentsArray, 1, segment2);

        // Using reflection to set segments array in map
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        segmentsField.set(map, segmentsArray);

        // Act
        int result = map.size();

        // Assert
        assertEquals(5, result, "Expected size to match sum of counts across segments");
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() with quick stability returns immediate correct sum")
    void testSizeQuickStability() throws Exception {
        // Setup
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        Class<?> segmentClass = map.segments.getClass().getComponentType();
        Object segment1 = segmentClass.getConstructor(int.class, float.class, int.class).newInstance(1, 1.0f, 1);

        // Using reflection to set counts
        Field countField = segmentClass.getDeclaredField("count");
        countField.setAccessible(true);
        countField.set(segment1, 7);

        // Setting modCounts to let modCount stabilization
        Field modCountField = segmentClass.getDeclaredField("modCount");
        modCountField.setAccessible(true);
        modCountField.set(segment1, 7);

        // Put segment into the map
        Object segmentsArray = Array.newInstance(segmentClass, 1);
        Array.set(segmentsArray, 0, segment1);

        // Using reflection to set segments array in map
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        segmentsField.set(map, segmentsArray);

        // Act
        int result = map.size();

        // Assert
        assertEquals(7, result, "Expected size to be precisely calculated");
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() with locking after intermittent segment changes")
    void testSizeWithLockingAfterIntermittentChanges() throws Exception {
        // Setup
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        Class<?> segmentClass = map.segments.getClass().getComponentType();
        Object segment1 = segmentClass.getConstructor(int.class, float.class, int.class).newInstance(1, 1.0f, 1);

        // Using reflection to set counts
        Field countField = segmentClass.getDeclaredField("count");
        countField.setAccessible(true);
        countField.set(segment1, 3);

        // Setting modCounts to require lock eventually
        Field modCountField = segmentClass.getDeclaredField("modCount");
        modCountField.setAccessible(true);
        modCountField.set(segment1, 5); // initial modCount not matching to cause retry

        // Put segment into the map
        Object segmentsArray = Array.newInstance(segmentClass, 1);
        Array.set(segmentsArray, 0, segment1);

        // Using reflection to set segments array in map
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        segmentsField.set(map, segmentsArray);

        // Act
        int result = map.size();

        // Assert
        assertEquals(3, result, "Expected computed size after locking due to intermittent changes");
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() with exactly RETRIES_BEFORE_LOCK required and calculated size without locking")
    void testSizeRetrialLimitWithoutLocking() throws Exception {
        // Setup
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        Class<?> segmentClass = map.segments.getClass().getComponentType();
        Object segment1 = segmentClass.getConstructor(int.class, float.class, int.class).newInstance(1, 1.0f, 1);

        // Using reflection to set counts
        Field countField = segmentClass.getDeclaredField("count");
        countField.setAccessible(true);
        countField.set(segment1, 10);

        // Setting modCounts to push retrials to valid conclusion
        Field modCountField = segmentClass.getDeclaredField("modCount");
        modCountField.setAccessible(true);
        modCountField.set(segment1, 10);

        // Put segment into the map
        Object segmentsArray = Array.newInstance(segmentClass, 1);
        Array.set(segmentsArray, 0, segment1);

        // Using reflection to set segments array in map
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        segmentsField.set(map, segmentsArray);

        // Act
        int result = map.size();

        // Assert
        assertEquals(10, result, "Should compute size properly even after maximum retries within limit");
    }
}