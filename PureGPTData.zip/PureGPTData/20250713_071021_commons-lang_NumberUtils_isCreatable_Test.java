import org.apache.commons.lang3.math.NumberUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class NumberUtilsTest {

    @Test
    void testIsCreatableWithNull() {
        assertFalse(NumberUtils.isCreatable(null));
    }
    
    @Test
    void testIsCreatableWithEmptyString() {
        assertFalse(NumberUtils.isCreatable(""));
    }
    
    @ParameterizedTest
    @ValueSource(strings = {"0", "123", "+123", "-123", "0123", "0.123", ".123", "123.456", "1E3", "-1E3", "+1E-3", "0xFF", "#FF", "0755"})
    void testIsCreatableWithValidNumbers(String input) {
        assertTrue(NumberUtils.isCreatable(input));
    }

    @ParameterizedTest
    @ValueSource(strings = {"-0x123", "+0X123", "-#123", "0x", "0X", "#", "0E", "12.", "12.34.56", "1E3.4", "1E", "1E-", "0xGHI", "089"})
    void testIsCreatableWithInvalidNumbers(String input) {
        assertFalse(NumberUtils.isCreatable(input));
    }

    @ParameterizedTest
    @CsvSource({
        "0, true",
        "12, true",
        "12.34, true",
        "1E5, true",
        "1e-5, true",
        "0x5A, true",
        "#5A, true",
        "07234, true",
        "+123, true",
        "-123, true",
        "+.5, true",
        "-.5, true",
        "1.2.3, false",
        "12E, false",
        "12E+5.3, false",
        "+-5, false",
        "-+5, false",
        "0x, false",
        "0X, false",
        "#, false",
        "08, false",
        "0E0.5, false",
        "-0x123H, false"
    })
    void testIsCreatableWithVariousInputs(String input, boolean expected) {
        if (expected) {
            assertTrue(NumberUtils.isCreatable(input));
        } else {
            assertFalse(NumberUtils.isCreatable(input));
        }
    }
}