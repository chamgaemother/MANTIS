package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Objects;

public class Flat3Map_remove_2_1_Test {

    /**
     * DummyKey class to simulate keys with the same hash code but different equality.
     */
    static class DummyKey {
        private final String name;
        private final int hash;

        public DummyKey(String name, int hash) {
            this.name = name;
            this.hash = hash;
        }

        @Override
        public int hashCode() {
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (!(obj instanceof DummyKey)) return false;
            DummyKey other = (DummyKey) obj;
            return Objects.equals(this.name, other.name);
        }

        @Override
        public String toString() {
            return name;
        }
    }

    @Test
    @DisplayName("Remove a key from Flat3Map with delegateMap null, size=3, key2 matches, ensuring key3 shifts correctly.")
    public void test_TC16_remove_Key2_ShiftsCorrectly() throws Exception {
        // Initialize Flat3Map
        Flat3Map<String, String> map = new Flat3Map<>();

        // Use reflection to set private fields
        Class<?> mapClass = map.getClass();

        // Set size to 3
        Field sizeField = mapClass.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set hash1, key1, value1
        Field hash1Field = mapClass.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        String key1 = "key1";
        hash1Field.setInt(map, key1.hashCode());

        Field key1Field = mapClass.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key1);

        Field value1Field = mapClass.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        // Set hash2, key2, value2
        Field hash2Field = mapClass.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        String key2 = "key2";
        hash2Field.setInt(map, key2.hashCode());

        Field key2Field = mapClass.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key2);

        Field value2Field = mapClass.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        // Set hash3, key3, value3
        Field hash3Field = mapClass.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        String key3 = "key3";
        hash3Field.setInt(map, key3.hashCode());

        Field key3Field = mapClass.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, key3);

        Field value3Field = mapClass.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke remove on key2
        Object result = map.remove(key2);

        // Assertions
        assertEquals("value2", result, "remove(key2) should return value2");

        // After removal, key2 should have key3's values, key3 should be null, size should decrement to 2
        String newKey2 = (String) key2Field.get(map);
        String newValue2 = (String) value2Field.get(map);
        String newKey3 = (String) key3Field.get(map);
        String newValue3 = (String) value3Field.get(map);
        int newSize = sizeField.getInt(map);

        assertNull(newKey3, "key3 should be null after shifting.");
        assertEquals(key3, newKey2, "key3 should shift to key2.");
        assertEquals("value3", newValue2, "value3 should shift to value2.");
        assertEquals(2, newSize, "size should decrement to 2.");
    }

    @Test
    @DisplayName("Remove a key with matching hash but different equals in flat mode, ensuring no removal occurs.")
    public void test_TC17_remove_HashCollision_NoRemoval() throws Exception {
        // Initialize Flat3Map
        Flat3Map<Object, String> map = new Flat3Map<>();

        // Use reflection to set private fields
        Class<?> mapClass = map.getClass();

        // Set size to 3
        Field sizeField = mapClass.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Create dummy keys
        DummyKey key1 = new DummyKey("key1", 42);
        DummyKey nonEqualKey = new DummyKey("keY1", 42); // Same hash, different equals

        // Set hash1, key1, value1
        Field hash1Field = mapClass.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, key1.hashCode());

        Field key1Field = mapClass.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key1);

        Field value1Field = mapClass.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        // Set hash2, key2, value2
        Field hash2Field = mapClass.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        String key2 = "key2";
        hash2Field.setInt(map, key2.hashCode());

        Field key2Field = mapClass.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key2);

        Field value2Field = mapClass.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        // Set hash3, key3, value3
        Field hash3Field = mapClass.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        String key3 = "key3";
        hash3Field.setInt(map, key3.hashCode());

        Field key3Field = mapClass.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, key3);

        Field value3Field = mapClass.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        // Invoke remove on nonEqualKey
        Object result = map.remove(nonEqualKey);

        // Assertions
        assertNull(result, "remove(nonEqualKey) should return null");

        // Ensure no keys are removed
        Object currentKey1 = key1Field.get(map);
        Object currentKey2 = key2Field.get(map);
        Object currentKey3 = key3Field.get(map);
        String currentValue1 = (String) value1Field.get(map);
        String currentValue2 = (String) value2Field.get(map);
        String currentValue3 = (String) value3Field.get(map);
        int currentSize = sizeField.getInt(map);

        assertEquals(key1, currentKey1, "key1 should remain unchanged.");
        assertEquals(key2, currentKey2, "key2 should remain unchanged.");
        assertEquals(key3, currentKey3, "key3 should remain unchanged.");
        assertEquals("value1", currentValue1, "value1 should remain unchanged.");
        assertEquals("value2", currentValue2, "value2 should remain unchanged.");
        assertEquals("value3", currentValue3, "value3 should remain unchanged.");
        assertEquals(3, currentSize, "size should remain 3.");
    }
}