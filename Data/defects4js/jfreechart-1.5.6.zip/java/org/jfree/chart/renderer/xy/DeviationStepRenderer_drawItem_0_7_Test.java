package org.jfree.chart.renderer.xy;

import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.*;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.mockito.ArgumentCaptor;

public class DeviationStepRenderer_drawItem_0_7_Test {

    @Test
    @DisplayName("TC31: drawItem handles invalid dataArea dimensions")
    void TC31_drawItem_with_invalid_dataArea_dimensions() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        // Mocking dependencies
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        // Corrected: using .thenReturn instead of instanceof check
        when(dataset.getXValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getStartYValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(series, item)).thenReturn(Double.NaN);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(Double.NaN);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(Double.NaN);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(series)).thenReturn(1);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Since dataArea has invalid dimensions, shading should not be drawn.
        verify(g2, never()).fill(any());
    }

    @Test
    @DisplayName("TC32: drawItem handles null plot parameter")
    void TC32_drawItem_with_null_plot_parameter() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = null; // Null plot
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 1;

        // Mocking dependencies
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        // Act & Assert
        assertDoesNotThrow(() ->
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass));
    }

    @Test
    @DisplayName("TC33: drawItem handles zero alpha transparency")
    void TC33_drawItem_with_zero_alpha_transparency() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        // Set alpha transparency to zero
        doReturn(0.0f).when(renderer).getAlpha();

        // Mocking dependencies
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(100.0);
        when(dataset.getStartYValue(series, item)).thenReturn(100.0);
        when(dataset.getEndYValue(series, item)).thenReturn(100.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(series)).thenReturn(1);
        when(renderer.getItemFillPaint(series, item)).thenReturn(Color.RED);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Composite> compositeCaptor = ArgumentCaptor.forClass(Composite.class);
        verify(g2).setComposite(compositeCaptor.capture());
        assertTrue(compositeCaptor.getValue() instanceof AlphaComposite);
        AlphaComposite ac = (AlphaComposite) compositeCaptor.getValue();
        assertEquals(0.0f, ac.getAlpha(), 0.001f);

        // Ensure fill was called but with full transparency, it should not be visible.
        verify(g2).fill(any());
    }

    @Test
    @DisplayName("TC34: drawItem handles full alpha transparency")
    void TC34_drawItem_with_full_alpha_transparency() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int series = 0;
        int item = 0;
        int pass = 0;

        // Set alpha transparency to full
        doReturn(1.0f).when(renderer).getAlpha();

        // Mocking dependencies
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getXValue(series, item)).thenReturn(100.0);
        when(dataset.getStartYValue(series, item)).thenReturn(100.0);
        when(dataset.getEndYValue(series, item)).thenReturn(100.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getItemCount(series)).thenReturn(1);
        when(renderer.getItemFillPaint(series, item)).thenReturn(Color.RED);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Composite> compositeCaptor = ArgumentCaptor.forClass(Composite.class);
        verify(g2).setComposite(compositeCaptor.capture());
        assertTrue(compositeCaptor.getValue() instanceof AlphaComposite);
        AlphaComposite ac = (AlphaComposite) compositeCaptor.getValue();
        assertEquals(1.0f, ac.getAlpha(), 0.001f);

        // Ensure fill was called and shading is fully opaque
        verify(g2).fill(any());
    }

    @Test
    @DisplayName("TC35: drawItem handles non-integer series and item indices")
    void TC35_drawItem_with_non_integer_indices() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Using non-integer indices by casting to int
        int series = 0; // Corrected to integer
        int item = 1;   // Corrected to integer
        int pass = 1;

        // Mocking dependencies
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        // Act & Assert
        assertDoesNotThrow(() ->
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass));
    }

}
