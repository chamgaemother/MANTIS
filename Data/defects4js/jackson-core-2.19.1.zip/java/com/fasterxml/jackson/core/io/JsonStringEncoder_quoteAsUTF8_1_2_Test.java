package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.io.JsonStringEncoder;
import java.util.Arrays;

/**
 * JUnit 5 test class for JsonStringEncoder.quoteAsUTF8 covering enhanced scenarios.
 */
public class JsonStringEncoder_quoteAsUTF8_1_2_Test {

    @Test
    @DisplayName("quoteAsUTF8 with a string containing control characters requiring numeric escape sequences")
    public void TC26_quoteAsUTF8_controlCharactersNumericEscapes() {
        // GIVEN
        String text = "Test\bTest\fTest";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        byte[] expected = new byte[] {84, 101, 115, 116, 92, 98, 84, 101, 115, 116, 92, 102, 84, 101, 115, 116};
        assertArrayEquals(expected, result, "Byte array should correctly encode control characters using numeric escape sequences.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with a string causing multiple buffer resizes and containing escape characters")
    public void TC27_quoteAsUTF8_multipleBufferResizesWithEscapes() {
        // GIVEN
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 5000; i++) {
            sb.append("a\n");
        }
        String text = sb.toString();

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        byte[] expected = new byte[5000 * 3];
        for(int i = 0; i < 5000; i++) {
            expected[3*i] = (byte) 'a';
            expected[3*i + 1] = (byte) '\\';
            expected[3*i + 2] = (byte) 'n';
        }
        assertEquals(15000, result.length, "Byte array should have the expected length after multiple buffer resizes.");
    }

    @Test
    @DisplayName("quoteAsUTF8 with a string containing all escapable characters")
    public void TC28_quoteAsUTF8_allEscapableCharacters() {
        // GIVEN
        String text = "\n\r\t\b\f";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        byte[] expected = new byte[] {92, 110, 92, 114, 92, 116, 92, 98, 92, 102};
        assertArrayEquals(expected, result, "Byte array should correctly encode all escapable characters.");
    }
}