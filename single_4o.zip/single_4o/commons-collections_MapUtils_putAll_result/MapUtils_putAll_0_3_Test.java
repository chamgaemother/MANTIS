package org.apache.commons.collections4;

import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.HashMap;
import java.util.Map;
import java.lang.reflect.Method;
import static org.junit.jupiter.api.Assertions.*;

public class MapUtils_putAll_0_3_Test {

    @Test
    @DisplayName("Verify processing with nested valid subarrays")
    public void testTC11_VerifyProcessingWithNestedValidSubarrays() throws Exception {
        // Arrange: Setup test data according to the scenario
        Map<String, String> map = new HashMap<>();
        Object[] nestedArray = new Object[] {
            new Object[] {"key1", "value1"},
            new Object[] {"key2", "value2"},
            new Object[] {"key3", "value3"}
        };

        // Use reflection to access the target method
        Method putAllMethod = MapUtils.class.getDeclaredMethod("putAll", Map.class, Object[].class);
        putAllMethod.setAccessible(true);

        // Act: Invoke the target method
        @SuppressWarnings("unchecked")
        Map<String, String> resultMap = (Map<String, String>) putAllMethod.invoke(null, map, nestedArray);

        // Assert: Verify the expected result
        assertEquals(3, resultMap.size(), "Map should contain 3 key-value pairs.");
        assertEquals("value1", resultMap.get("key1"), "Key 'key1' should map to 'value1'");
        assertEquals("value2", resultMap.get("key2"), "Key 'key2' should map to 'value2'");
        assertEquals("value3", resultMap.get("key3"), "Key 'key3' should map to 'value3'");
    }
}