package org.apache.commons.jxpath.ri.model.jdom;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.jxpath.JXPathContext;
import org.jdom.Attribute;
import org.jdom.CDATA;
import org.jdom.Comment;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Locale;

class JDOMNodePointerTest {

    private Element parentElement;
    private Element childElement;
    private Text textNode;
    private JDOMNodePointer textPointer;
    private JDOMNodePointer elementPointer;
    private Document document;

    @BeforeEach
    void setUp() {
        parentElement = new Element("parent");
        childElement = new Element("child");
        parentElement.addContent(childElement);
        textNode = new Text("Original Text");
        childElement.addContent(textNode);
        document = new Document(parentElement);
        textPointer = new JDOMNodePointer(textNode, Locale.ENGLISH);
        elementPointer = new JDOMNodePointer(childElement, Locale.ENGLISH);
    }

    // Tests for node instanceof Text
    @Test
    void testSetValue_TextNode_NonEmptyString() {
        textPointer.setValue("Updated Text");
        assertEquals("Updated Text", textNode.getText());
        assertTrue(childElement.getContent().contains(textNode));
    }

    @Test
    void testSetValue_TextNode_EmptyString() {
        textPointer.setValue("");
        assertFalse(childElement.getContent().contains(textNode));
    }

    @Test
    void testSetValue_TextNode_Null() {
        textPointer.setValue(null);
        assertFalse(childElement.getContent().contains(textNode));
    }

    @Test
    void testSetValue_TextNode_NonStringObject() {
        textPointer.setValue(12345);
        assertEquals("12345", textNode.getText());
        assertTrue(childElement.getContent().contains(textNode));
    }

    // Tests for node instanceof Element
    @Test
    void testSetValue_Element_WithElement() {
        Element newElement = new Element("newChild");
        newElement.addContent(new Text("New Child Text"));
        elementPointer.setValue(newElement);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Text);
        assertEquals("New Child Text", ((Text) addedNode).getText());
    }

    @Test
    void testSetValue_Element_WithDocument() {
        Document newDoc = new Document();
        Element newChild = new Element("docChild");
        newChild.addContent(new Text("Doc Child Text"));
        newDoc.addContent(newChild);
        elementPointer.setValue(newDoc);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Element);
        Element addedElement = (Element) addedNode;
        assertEquals("docChild", addedElement.getName());
        assertEquals("Doc Child Text", ((Text) addedElement.getContent(0)).getText());
    }

    @Test
    void testSetValue_Element_WithText() {
        Text newText = new Text("New Element Text");
        elementPointer.setValue(newText);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Text);
        assertEquals("New Element Text", ((Text) addedNode).getText());
    }

    @Test
    void testSetValue_Element_WithCDATA() {
        CDATA newCdata = new CDATA("New CDATA Content");
        elementPointer.setValue(newCdata);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof CDATA);
        assertEquals("New CDATA Content", ((CDATA) addedNode).getText());
    }

    @Test
    void testSetValue_Element_WithProcessingInstruction() {
        ProcessingInstruction pi = new ProcessingInstruction("target", "data");
        elementPointer.setValue(pi);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof ProcessingInstruction);
        ProcessingInstruction addedPi = (ProcessingInstruction) addedNode;
        assertEquals("target", addedPi.getTarget());
        assertEquals("data", addedPi.getData());
    }

    @Test
    void testSetValue_Element_WithComment() {
        Comment comment = new Comment("This is a comment");
        elementPointer.setValue(comment);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Comment);
        Comment addedComment = (Comment) addedNode;
        assertEquals("This is a comment", addedComment.getText());
    }

    @Test
    void testSetValue_Element_WithNonEmptyString() {
        elementPointer.setValue("Element String Content");
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Text);
        assertEquals("Element String Content", ((Text) addedNode).getText());
    }

    @Test
    void testSetValue_Element_WithEmptyString() {
        elementPointer.setValue("");
        assertEquals(0, childElement.getContentSize());
    }

    @Test
    void testSetValue_Element_WithNull() {
        elementPointer.setValue(null);
        assertEquals(0, childElement.getContentSize());
    }

    // Additional edge case tests
    @Test
    void testSetValue_Element_WithUnknownType() {
        Object unknown = new Object();
        elementPointer.setValue(unknown);
        assertEquals(0, childElement.getContentSize());
    }

    @Test
    void testSetValue_Element_ClearContentBeforeAdding() {
        childElement.addContent(new Text("Existing Content"));
        Element newElement = new Element("newChild");
        newElement.addContent(new Text("New Child Text"));
        elementPointer.setValue(newElement);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Text);
        assertEquals("New Child Text", ((Text) addedNode).getText());
    }

    @Test
    void testSetValue_TextNode_SetEmptyStringWithWhitespace() {
        textPointer.setValue("   ");
        assertFalse(childElement.getContent().contains(textNode));
    }

    @Test
    void testSetValue_TextNode_SetWhitespaceString() {
        textPointer.setValue("  Updated ");
        assertEquals("  Updated ", textNode.getText());
    }

    @Test
    void testSetValue_Element_WithElementHavingNamespaces() {
        Element newElement = new Element("newChild", "http://example.com/ns");
        newElement.addContent(new Text("Namespaced Child Text"));
        elementPointer.setValue(newElement);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Text);
        assertEquals("Namespaced Child Text", ((Text) addedNode).getText());
    }

    @Test
    void testSetValue_Element_WithMultipleChildren() {
        Element newElement = new Element("newChild1");
        newElement.addContent(new Text("Child1"));
        newElement.addContent(new Text("Child2"));
        elementPointer.setValue(newElement);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Text);
        assertEquals("Child1", ((Text) addedNode).getText());
    }

    @Test
    void testSetValue_Element_WithNestedElements() {
        Element newElement = new Element("newChild");
        Element nested = new Element("nestedChild");
        nested.addContent(new Text("Nested Text"));
        newElement.addContent(nested);
        elementPointer.setValue(newElement);
        assertEquals(1, childElement.getContentSize());
        Object addedNode = childElement.getContent(0);
        assertTrue(addedNode instanceof Text);
        assertEquals("newChild", ((Element) addedNode).getName()); // Might need adjustment based on cloning
    }
}