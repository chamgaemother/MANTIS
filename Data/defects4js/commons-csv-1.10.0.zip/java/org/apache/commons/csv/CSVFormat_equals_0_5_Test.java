package org.apache.commons.csv;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CSVFormat_equals_0_5_Test {

    @Test
    @DisplayName("equals returns false when trailingDelimiter differs")
    public void TC21() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withTrailingDelimiter(true);
        CSVFormat format2 = CSVFormat.DEFAULT.withTrailingDelimiter(false);

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result, "Expected formats to be not equal due to differing trailingDelimiter");
    }

    @Test
    @DisplayName("equals returns false when trim differs")
    public void TC22() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT.withTrim(true);
        CSVFormat format2 = CSVFormat.DEFAULT.withTrim(false);

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertFalse(result, "Expected formats to be not equal due to differing trim settings");
    }

    @Test
    @DisplayName("equals returns true when all fields are equal")
    public void TC23() {
        // GIVEN
        CSVFormat format1 = CSVFormat.DEFAULT
            .builder()
            .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
            .setAllowMissingColumnNames(true)
            .setAutoFlush(true)
            .setCommentMarker('#')
            .setDelimiter(',')
            .setEscape('\\')
            .setHeader("A", "B")
            .setHeaderComments("Comment")
            .setIgnoreEmptyLines(true)
            .setIgnoreHeaderCase(true)
            .setIgnoreSurroundingSpaces(true)
            .setNullString("NULL")
            .setQuote('"')
            .setQuoteMode(QuoteMode.MINIMAL)
            .setSkipHeaderRecord(true)
            .setTrailingDelimiter(true)
            .setTrim(true)
            .build();

        CSVFormat format2 = CSVFormat.DEFAULT
            .builder()
            .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
            .setAllowMissingColumnNames(true)
            .setAutoFlush(true)
            .setCommentMarker('#')
            .setDelimiter(',')
            .setEscape('\\')
            .setHeader("A", "B")
            .setHeaderComments("Comment")
            .setIgnoreEmptyLines(true)
            .setIgnoreHeaderCase(true)
            .setIgnoreSurroundingSpaces(true)
            .setNullString("NULL")
            .setQuote('"')
            .setQuoteMode(QuoteMode.MINIMAL)
            .setSkipHeaderRecord(true)
            .setTrailingDelimiter(true)
            .setTrim(true)
            .build();

        // WHEN
        boolean result = format1.equals(format2);

        // THEN
        assertTrue(result, "Expected formats to be equal when all fields match");
    }

}
