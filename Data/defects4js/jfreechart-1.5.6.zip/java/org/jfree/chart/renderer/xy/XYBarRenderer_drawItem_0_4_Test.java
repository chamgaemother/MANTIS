package org.jfree.chart.renderer.xy;
import org.jfree.chart.renderer.category.BarPainter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.mockito.Mockito;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYBarRenderer_drawItem_0_4_Test {

    @Test
    @DisplayName("drawItem throws exception when orientation is invalid")
    void TC16_drawItem_invalidOrientation_throwsIllegalStateException() {
        // Arrange
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
        Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        XYDataset dataset = Mockito.mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = Mockito.mock(CrosshairState.class);
        int pass = 1;

        // Set orientation to null to ensure an illegal state
        when(plot.getOrientation()).thenReturn(null);

        // Act & Assert
        assertThrows(IllegalStateException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("drawItem handles positive Y1 without inversion")
    void TC17_drawItem_positiveY1_withoutInversion_setsBarBaseCorrectly() {
        // Arrange
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
        Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
        int series = 1;
        int item = 1;
        CrosshairState crosshairState = Mockito.mock(CrosshairState.class);
        int pass = 1;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(true);
        when(dataset.getStartYValue(series, item)).thenReturn(10.0);
        when(dataset.getEndYValue(series, item)).thenReturn(20.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(100.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(50.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getMargin()).thenReturn(0.1);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that paintBar is called
        verify(renderer.getBarPainter(), times(1)).paintBar(any(Graphics2D.class), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), any(RectangleEdge.class));
    }

    @Test
    @DisplayName("drawItem handles negative Y1 with inversion")
    void TC18_drawItem_negativeY1_withInversion_setsBarBaseCorrectly() {
        // Arrange
        XYBarRenderer renderer = new XYBarRenderer();
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
        Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
        int series = 2;
        int item = 2;
        CrosshairState crosshairState = Mockito.mock(CrosshairState.class);
        int pass = 1;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(renderer.getBase()).thenReturn(5.0);
        when(dataset.getYValue(series, item)).thenReturn(-15.0);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(80.0);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(40.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getMargin()).thenReturn(0.2);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that paintBar is called
        verify(renderer.getBarPainter(), times(1)).paintBar(any(Graphics2D.class), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), any(RectangleEdge.class));
    }

//     @Test
//     @DisplayName("drawItem paints shadow when pass is 0 and shadows are visible")
//     void TC19_drawItem_paintsShadowWhenPass0AndShadowsVisible() {
        // Arrange
//         XYBarRenderer renderer = new XYBarRenderer();
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
//         Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
//         int series = 3;
//         int item = 3;
//         CrosshairState crosshairState = Mockito.mock(CrosshairState.class);
//         int pass = 0;
// 
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
//         when(renderer.getUseYInterval()).thenReturn(true);
//         when(dataset.getStartYValue(series, item)).thenReturn(5.0);
//         when(dataset.getEndYValue(series, item)).thenReturn(15.0);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(60.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(30.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(renderer.getMargin()).thenReturn(0.15);
// 
//         BarPainter barPainter = Mockito.mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(barPainter);
//         when(renderer.getShadowsVisible()).thenReturn(true);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(barPainter, times(1)).paintBarShadow(any(Graphics2D.class), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), any(RectangleEdge.class), anyBoolean());
//     }

//     @Test
//     @DisplayName("drawItem does not paint shadow when pass is 0 and shadows are not visible")
//     void TC20_drawItem_doesNotPaintShadowWhenPass0AndShadowsNotVisible() {
        // Arrange
//         XYBarRenderer renderer = new XYBarRenderer();
//         Graphics2D g2 = Mockito.mock(Graphics2D.class);
//         XYItemRendererState state = Mockito.mock(XYItemRendererState.class);
//         Rectangle2D dataArea = Mockito.mock(Rectangle2D.class);
//         PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
//         XYPlot plot = Mockito.mock(XYPlot.class);
//         ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
//         ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
//         IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
//         int series = 4;
//         int item = 4;
//         CrosshairState crosshairState = Mockito.mock(CrosshairState.class);
//         int pass = 0;
// 
//         when(renderer.getItemVisible(series, item)).thenReturn(true);
//         when(renderer.getUseYInterval()).thenReturn(false);
//         when(renderer.getBase()).thenReturn(0.0);
//         when(dataset.getYValue(series, item)).thenReturn(25.0);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(120.0);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(60.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         when(renderer.getMargin()).thenReturn(0.05);
// 
//         BarPainter barPainter = Mockito.mock(BarPainter.class);
//         when(renderer.getBarPainter()).thenReturn(barPainter);
//         when(renderer.getShadowsVisible()).thenReturn(false);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(barPainter, never()).paintBarShadow(any(Graphics2D.class), any(XYBarRenderer.class), anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class), anyBoolean());
//     }
}