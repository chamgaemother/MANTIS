package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Random;

public class RandomStringUtils_random_0_5_Test {

    @Test
    @DisplayName("random(count, start=65, end=91, letters=true, numbers=true, chars=null, random) throws exception when end <= 'A'")
    void TC21() {
        // GIVEN
        int count = 5;
        int start = 65;
        int end = 65;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
        assertEquals("Parameter end (65) must be greater than start (65)", exception.getMessage());
    }

    @Test
    @DisplayName("random(count, start=0, end=1114112, letters=false, numbers=false, chars=null, random) sets end to Character.MAX_CODE_POINT")
    void TC22() throws Exception {
        // GIVEN
        int count = 10;
        int start = 0;
        int end = 1114112;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        // Using reflection to verify 'end' is set to Character.MAX_CODE_POINT
        Field endField = RandomStringUtils.class.getDeclaredField("end");
        endField.setAccessible(true);
        // Since 'end' is a local variable, we cannot access it directly. Instead, we ensure that
        // the generated string length matches the count and no exceptions are thrown.
        assertNotNull(result);
        assertEquals(count, result.length());
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=ALPHANUMERICAL_CHARS, random) returns alphanumerical string")
    void TC23() throws Exception {
        // GIVEN
        int count = 8;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        Random random = new Random();
        char[] chars;
        // Reflection to access ALPHANUMERICAL_CHARS
        Field charsField = RandomStringUtils.class.getDeclaredField("ALPHANUMERICAL_CHARS");
        charsField.setAccessible(true);
        chars = (char[]) charsField.get(null);

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertNotNull(result);
        assertEquals(count, result.length());
        for (char c : result.toCharArray()) {
            assertTrue(new String(chars).indexOf(c) >= 0, "Character " + c + " is not in ALPHANUMERICAL_CHARS");
        }
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=ALPHANUMERICAL_CHARS, random) recursive call without optimization")
    void TC24() throws Exception {
        // GIVEN
        int count = 10;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        Random random = new Random();
        char[] chars;
        // Reflection to access ALPHANUMERICAL_CHARS
        Field charsField = RandomStringUtils.class.getDeclaredField("ALPHANUMERICAL_CHARS");
        charsField.setAccessible(true);
        chars = (char[]) charsField.get(null);

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertNotNull(result);
        assertEquals(count, result.length());
        for (char c : result.toCharArray()) {
            assertTrue(new String(chars).indexOf(c) >= 0, "Character " + c + " is not in ALPHANUMERICAL_CHARS");
        }
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=ALPHANUMERICAL_CHARS, random) handles empty char array in recursive call")
    void TC25() throws Exception {
        // GIVEN
        int count = 10;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        Random random = new Random();
        char[] chars;
        // Reflection to access and modify ALPHANUMERICAL_CHARS to be empty
        Field charsField = RandomStringUtils.class.getDeclaredField("ALPHANUMERICAL_CHARS");
        charsField.setAccessible(true);
        chars = (char[]) charsField.get(null);
        char[] emptyChars = new char[0];
        charsField.set(null, emptyChars);

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
        assertEquals("The chars array must not be empty", exception.getMessage());

        // Reset ALPHANUMERICAL_CHARS to its original state to avoid side effects
        charsField.set(null, chars);
    }
}