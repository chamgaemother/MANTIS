package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Dfp_multiply_0_7_Test {

    @Test
    @DisplayName("TC31: Multiplying Dfp numbers where one operand is negative and the other is positive")
    public void TC31_multiply_negative_with_positive() throws Exception {
        // Initialize DfpField with 10 radix digits
        DfpField field = new DfpField(10);

        // Create Dfp instances
        Dfp a = new Dfp(field, -2.0);
        Dfp b = new Dfp(field, 3.0);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Expected product
        Dfp expectedProduct = new Dfp(field, -6.0);

        // Access the private 'sign' field using reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte resultSign = signField.getByte(result);

        // Assertions
        assertEquals(-1, resultSign, "Result sign should be negative");
        assertEquals(expectedProduct, result, "Result should equal expected product");
    }

    @Test
    @DisplayName("TC32: Multiplying Dfp numbers where both operands are negative, resulting in positive product")
    public void TC32_multiply_two_negative_Dfp_numbers() throws Exception {
        // Initialize DfpField with 10 radix digits
        DfpField field = new DfpField(10);

        // Create Dfp instances
        Dfp a = new Dfp(field, -2.0);
        Dfp b = new Dfp(field, -3.0);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Expected product
        Dfp expectedProduct = new Dfp(field, 6.0);

        // Access the private 'sign' field using reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte resultSign = signField.getByte(result);

        // Assertions
        assertEquals(1, resultSign, "Result sign should be positive");
        assertEquals(expectedProduct, result, "Result should equal expected positive product");
    }

    @Test
    @DisplayName("TC33: Multiplying Dfp numbers where one operand has maximum mantissa digits causing precision loss")
    public void TC33_multiply_with_precision_loss() throws Exception {
        // Initialize DfpField with maximum radix digits (e.g., 10)
        DfpField field = new DfpField(10);

        // Define values
        double maxMantissaValue = 9999999999.0; // Assuming 10 digits
        double smallValue = 0.0001;
        Dfp expectedRoundedProduct = new Dfp(field, maxMantissaValue * smallValue);

        // Create Dfp instances
        Dfp a = new Dfp(field, maxMantissaValue);
        Dfp b = new Dfp(field, smallValue);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        assertEquals(expectedRoundedProduct, result, "Result should equal expected rounded product");

        // Access the private 'field' to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        // Access 'IEEEFlagsBits' using reflection
        Field flagsField = DfpField.class.getDeclaredField("IEEEFlagsBits");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(resultField);

        assertEquals(0, flags, "No IEEE flags should be set");
    }

    @Test
    @DisplayName("TC34: Multiplying Dfp numbers resulting in gradual underflow and setting FLAG_UNDERFLOW")
    public void TC34_multiply_causing_gradual_underflow_with_flag() throws Exception {
        // Initialize DfpField with 10 radix digits
        DfpField field = new DfpField(10);

        // Define very small values to cause underflow
        double verySmallValue1 = 1e-50;
        double verySmallValue2 = 1e-50;

        // Create Dfp instances
        Dfp a = new Dfp(field, verySmallValue1);
        Dfp b = new Dfp(field, verySmallValue2);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Access private 'mant' field to determine underflow
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(result);

        // Access private 'exp' field to check exponent
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        int exponent = expField.getInt(result);

        // Assertions for gradual underflow
        assertTrue(exponent < Dfp.MIN_EXP + mant.length, "Result should be in gradual underflow");

        // Access the private 'field' to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        // Access 'IEEEFlagsBits' using reflection
        Field flagsField = DfpField.class.getDeclaredField("IEEEFlagsBits");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(resultField);

        // Assuming FLAG_UNDERFLOW is represented by a specific bit, e.g., 0x01
        int FLAG_UNDERFLOW = 0x01;
        assertTrue((flags & FLAG_UNDERFLOW) != 0, "FLAG_UNDERFLOW should be set");
    }

    @Test
    @DisplayName("TC35: Multiplying Dfp numbers where the product mantissa exactly fits without rounding")
    public void TC35_multiply_with_exact_mantissa_fit() throws Exception {
        // Initialize DfpField with 10 radix digits
        DfpField field = new DfpField(10);

        // Define exact fit values
        double exactMantissaValue1 = 1000.0;
        double exactMantissaValue2 = 2000.0;
        Dfp expectedExactProduct = new Dfp(field, exactMantissaValue1 * exactMantissaValue2);

        // Create Dfp instances
        Dfp a = new Dfp(field, exactMantissaValue1);
        Dfp b = new Dfp(field, exactMantissaValue2);

        // Perform multiplication
        Dfp result = a.multiply(b);

        // Assertions
        assertEquals(expectedExactProduct, result, "Result should equal expected exact product");

        // Access the private 'field' to check IEEE flags
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        // Access 'IEEEFlagsBits' using reflection
        Field flagsField = DfpField.class.getDeclaredField("IEEEFlagsBits");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(resultField);

        assertEquals(0, flags, "No IEEE flags should be set");
    }
}