package org.apache.commons.math3.special;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Beta_regularizedBeta_0_2_Test {

    @Test
    @DisplayName("Input a is zero, should return Double.NaN")
    public void TC06_InputAZero_ReturnsNaN() {
        // Given
        double x = 0.5;
        double a = 0.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // When
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // Then
        assertTrue(Double.isNaN(result), "Expected result to be Double.NaN");
    }

    @Test
    @DisplayName("Input b is zero, should return Double.NaN")
    public void TC07_InputBZero_ReturnsNaN() {
        // Given
        double x = 0.5;
        double a = 2.0;
        double b = -1.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // When
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // Then
        assertTrue(Double.isNaN(result), "Expected result to be Double.NaN");
    }

    @Test
    @DisplayName("x and 1-x satisfy the recursive condition, should perform recursive call")
    public void TC08_RecursiveCondition_Satisfied() {
        // Given
        double x = 0.6;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // When
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);
        double expected = 1 - Beta.regularizedBeta(1 - x, b, a, epsilon, maxIterations);

        // Then
        assertEquals(expected, result, "The result should be equal to 1 - regularizedBeta(1 - x, b, a, epsilon, maxIterations)");
    }

    @Test
    @DisplayName("x does not satisfy recursive condition, proceed with computation via ContinuedFraction")
    public void TC09_RegularComputation_WithoutRecursion() {
        // Given
        double x = 0.3;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // When
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // Then
        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0");
    }

    @Test
    @DisplayName("Computation with high precision epsilon, requiring multiple iterations")
    public void TC10_HighPrecisionEpsilon_MultipleIterations() {
        // Given
        double x = 0.4;
        double a = 2.5;
        double b = 3.5;
        double epsilon = 1e-12;
        int maxIterations = 1000;
        double expectedValue = 0.706634; // This should be replaced with a precomputed expected value

        // When
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // Then
        assertTrue(Math.abs(expectedValue - result) < 1e-12, "Result should meet high precision requirements");
    }
}