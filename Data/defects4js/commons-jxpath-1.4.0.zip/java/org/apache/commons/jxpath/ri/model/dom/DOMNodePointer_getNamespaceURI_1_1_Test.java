package org.apache.commons.jxpath.ri.model.dom;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import java.util.Locale;
import java.io.StringReader;
import org.xml.sax.InputSource;

public class DOMNodePointer_getNamespaceURI_1_1_Test {

    @Test
    @DisplayName("getNamespaceURI with a non-Element, non-Document node throws ClassCastException")
    public void testTC13_getNamespaceURI_with_invalid_node_type() throws Exception {
        // Arrange
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.newDocument();
        Text textNode = doc.createTextNode("Sample Text");
        DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.ENGLISH);

        // Act & Assert
        assertThrows(ClassCastException.class, () -> {
            pointer.getNamespaceURI("test");
        });
    }

    @Test
    @DisplayName("getNamespaceURI retrieves namespace URI from a grandparent element after multiple traversals")
    public void testTC14_getNamespaceURI_with_namespace_defined_in_grandparent() throws Exception {
        // Arrange
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        String xml = "<grandparent xmlns:gp='http://grandparent.namespace.com'><parent><child></child></parent></grandparent>";
        Document doc = builder.parse(new InputSource(new StringReader(xml)));
        Element child = (Element) doc.getElementsByTagName("child").item(0);
        DOMNodePointer pointer = new DOMNodePointer(child, Locale.ENGLISH);

        // Act
        String namespaceURI = pointer.getNamespaceURI("gp");

        // Assert
        assertEquals("http://grandparent.namespace.com", namespaceURI);
    }
}