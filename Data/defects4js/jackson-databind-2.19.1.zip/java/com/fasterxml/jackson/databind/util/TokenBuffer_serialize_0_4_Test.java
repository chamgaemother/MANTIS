package com.fasterxml.jackson.databind.util;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.util.TokenBuffer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import static org.mockito.Mockito.*;

public class TokenBuffer_serialize_0_4_Test {

    @Test
    @DisplayName("serialize with FIELD_NAME token as String")
    public void TC16() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeFieldName("age");
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeFieldName("age");
    }

    @Test
    @DisplayName("serialize with START_ARRAY and END_ARRAY tokens")
    public void TC17() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeStartArray();
        buffer.writeEndArray();
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        InOrder inOrder = inOrder(gen);
        inOrder.verify(gen).writeStartArray();
        inOrder.verify(gen).writeEndArray();
    }

    @Test
    @DisplayName("serialize multiple FIELD_NAME and VALUE_STRING tokens")
    public void TC18() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeStartObject();
        buffer.writeFieldName("firstName");
        buffer.writeString("Alice");
        buffer.writeFieldName("lastName");
        buffer.writeString("Smith");
        buffer.writeEndObject();
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        InOrder inOrder = inOrder(gen);
        inOrder.verify(gen).writeStartObject();
        inOrder.verify(gen).writeFieldName("firstName");
        inOrder.verify(gen).writeString("Alice");
        inOrder.verify(gen).writeFieldName("lastName");
        inOrder.verify(gen).writeString("Smith");
        inOrder.verify(gen).writeEndObject();
    }

    @Test
    @DisplayName("serialize nested START_OBJECT and END_OBJECT tokens")
    public void TC19() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeStartObject();
        buffer.writeStartObject();
        buffer.writeEndObject();
        buffer.writeEndObject();
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        InOrder inOrder = inOrder(gen);
        inOrder.verify(gen).writeStartObject();
        inOrder.verify(gen).writeStartObject();
        inOrder.verify(gen).writeEndObject();
        inOrder.verify(gen).writeEndObject();
    }

    @Test
    @DisplayName("serialize multiple VALUE_NUMBER_INT tokens of different numeric types")
    public void TC20() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNumber(42);
        buffer.writeNumber(123456789012345L);
        buffer.writeNumber((short)7);
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        InOrder inOrder = inOrder(gen);
        inOrder.verify(gen).writeNumber(42);
        inOrder.verify(gen).writeNumber(123456789012345L);
        inOrder.verify(gen).writeNumber((short)7);
    }
}