import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Comparator;

import org.apache.commons.collections4.functors.ComparatorPredicate;
import org.apache.commons.collections4.functors.ComparatorPredicate.Criterion;
import org.junit.jupiter.api.Test;

class ComparatorPredicateTest {

    private final Integer ONE = Integer.valueOf(1);
    private final Integer TWO = Integer.valueOf(2);

    private final Comparator<Integer> comparator = Integer::compareTo;

    @Test
    void testEqualCriterion() {
        var predicate = ComparatorPredicate.comparatorPredicate(ONE, comparator, Criterion.EQUAL);
        assertTrue(predicate.test(ONE));
        assertFalse(predicate.test(TWO));
    }

    @Test
    void testGreaterCriterion() {
        var predicate = ComparatorPredicate.comparatorPredicate(ONE, comparator, Criterion.GREATER);
        assertFalse(predicate.test(ONE));
        assertFalse(predicate.test(TWO));
        assertTrue(predicate.test(0));
    }

    @Test
    void testLessCriterion() {
        var predicate = ComparatorPredicate.comparatorPredicate(ONE, comparator, Criterion.LESS);
        assertFalse(predicate.test(ONE));
        assertTrue(predicate.test(TWO));
        assertFalse(predicate.test(0));
    }

    @Test
    void testGreaterOrEqualCriterion() {
        var predicate = ComparatorPredicate.comparatorPredicate(ONE, comparator, Criterion.GREATER_OR_EQUAL);
        assertTrue(predicate.test(ONE));
        assertFalse(predicate.test(TWO));
        assertTrue(predicate.test(0));
    }

    @Test
    void testLessOrEqualCriterion() {
        var predicate = ComparatorPredicate.comparatorPredicate(ONE, comparator, Criterion.LESS_OR_EQUAL);
        assertTrue(predicate.test(ONE));
        assertTrue(predicate.test(TWO));
        assertFalse(predicate.test(0));
    }

    @Test
    void testNullComparatorThrowsException() {
        assertThrows(NullPointerException.class, () ->
            ComparatorPredicate.comparatorPredicate(ONE, null, Criterion.EQUAL)
        );
    }

    @Test
    void testNullCriterionThrowsException() {
        assertThrows(NullPointerException.class, () ->
            ComparatorPredicate.comparatorPredicate(ONE, comparator, null)
        );
    }
    
    @Test
    void testInvalidCriterionThrowsException() {
        // Creating a custom instance with a null criterion to simulate default block,
        // using reflection to set an invalid enum value
        var predicate = new ComparatorPredicate<>(ONE, comparator, null);
        assertThrows(IllegalStateException.class, () -> predicate.test(ONE));
    }
}