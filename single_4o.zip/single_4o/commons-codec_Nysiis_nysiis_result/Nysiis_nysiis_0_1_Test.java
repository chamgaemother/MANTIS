package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_1_Test {

    @Test
    @DisplayName("Null input string results in a null return value")
    void test_TC01_NullInput() {
        // Given
        Nysiis nysiis = new Nysiis();
        String input = null;

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertNull(result);
    }

    @Test
    @DisplayName("Empty input string results in an empty return value")
    void test_TC02_EmptyInput() {
        // Given
        Nysiis nysiis = new Nysiis();
        String input = "";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("", result);
    }

    @Test
    @DisplayName("Input 'MAC' is transcoded to 'MCC' following MAC replacement")
    void test_TC03_MACTranscoding() {
        // Given
        Nysiis nysiis = new Nysiis();
        String input = "MAC";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("MCC", result);
    }

    @Test
    @DisplayName("Input 'KNIE' is transcoded to 'NYE' using KN replacement and EE to Y")
    void test_TC04_KNIETranscoding() {
        // Given
        Nysiis nysiis = new Nysiis();
        String input = "KNIE";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("NYE", result);
    }

    @Test
    @DisplayName("Transcoding 'SCH' at start of a word results in 'SSS'")
    void test_TC05_SCHTranscoding() {
        // Given
        Nysiis nysiis = new Nysiis();
        String input = "SCH";

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("SSS", result);
    }
}