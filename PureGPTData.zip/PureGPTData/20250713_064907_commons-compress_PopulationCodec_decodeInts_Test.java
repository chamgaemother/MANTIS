import org.apache.commons.compress.harmony.pack200.Codec;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.apache.commons.compress.harmony.pack200.PopulationCodec;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PopulationCodecTest {

    private Codec favouredCodec;
    private Codec tokenCodec;
    private Codec unfavouredCodec;
    private PopulationCodec codec;

    @BeforeEach
    void setUp() {
        favouredCodec = mock(Codec.class);
        tokenCodec = mock(Codec.class);
        unfavouredCodec = mock(Codec.class);
    }

    @Test
    void testDecodeIntsWithNullInputStream() {
        codec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        assertThrows(Pack200Exception.class, () -> codec.decodeInts(10, null));
    }

    @Test
    void testDecodeIntsWithZeroElements() throws IOException, Pack200Exception {
        codec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        InputStream in = new ByteArrayInputStream(new byte[0]);
        int[] result = codec.decodeInts(0, in);
        assertArrayEquals(new int[0], result);
    }

    @Test
    void testDecodeIntsWithFavouredCodecThrowing() throws IOException, Pack200Exception {
        codec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        IOException exception = new IOException("Test exception");
        when(favouredCodec.decode(any(InputStream.class), anyInt())).thenThrow(exception);

        ByteArrayInputStream in = new ByteArrayInputStream(new byte[0]);
        assertThrows(IOException.class, () -> codec.decodeInts(10, in));
    }

    @Test
    void testDecodeIntsWithDerivedTokenCodec() throws IOException, Pack200Exception {
        when(favouredCodec.decode(any(InputStream.class), anyInt())).thenReturn(128, 128, 0);
        codec = new PopulationCodec(favouredCodec, (Codec) null, unfavouredCodec);
        populateUnfavouredCodec(128);

        ByteArrayInputStream in = new ByteArrayInputStream(new byte[]{0, 0, 0, 0});
        int[] result = codec.decodeInts(4, in);

        assertNotNull(result);
    }

    @Test
    void testDecodeIntsWithTokenIndexZero() throws IOException, Pack200Exception {
        when(favouredCodec.decode(any(InputStream.class), anyInt())).thenReturn(1, 1, 0);
        codec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);
        when(tokenCodec.decodeInts(anyInt(), any(InputStream.class))).thenReturn(new int[]{0, 0, 0, 0});
        when(unfavouredCodec.decode(any(InputStream.class), anyInt())).thenReturn(10);

        ByteArrayInputStream in = new ByteArrayInputStream(new byte[]{0, 0, 0, 0});
        int[] result = codec.decodeInts(4, in);

        assertEquals(4, result.length);
        for (int value : result) {
            assertEquals(10, value);
        }
    }

    @Test
    void testDecodeIntsWithSmallestValueHandlingNegative() throws IOException, Pack200Exception {
        when(favouredCodec.decode(any(InputStream.class), anyInt())).thenReturn(-5, 5, 0);
        codec = new PopulationCodec(favouredCodec, tokenCodec, unfavouredCodec);

        ByteArrayInputStream in = new ByteArrayInputStream(new byte[]{1, 1, 1, 1});
        
        assertThrows(Pack200Exception.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                codec.decodeInts(4, in);
            }
        });
    }

    private void populateUnfavouredCodec(int returnValue) throws IOException, Pack200Exception {
        when(unfavouredCodec.decode(any(InputStream.class), anyInt())).thenReturn(returnValue);
    }
}