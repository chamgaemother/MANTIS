package org.jfree.chart.block;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.ui.Size2D;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class RectangleConstraint_calculateConstrainedSize_0_2_Test {

    @Test
    @DisplayName("WidthConstraintType is RANGE and HeightConstraintType is FIXED")
    void TC06_RANGE_FIXED() throws Exception {
        // Modified creation of RectangleConstraint instance with initial constructor
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.RANGE,
                0.0, null, LengthConstraintType.FIXED);

        // Set widthRange
        Field widthRangeField = RectangleConstraint.class.getDeclaredField("widthRange");
        widthRangeField.setAccessible(true);
        Range widthRange = new Range(50.0, 150.0);
        widthRangeField.set(constraint, widthRange);

        // Set fixed height
        Field heightField = RectangleConstraint.class.getDeclaredField("height");
        heightField.setAccessible(true);
        double fixedHeight = 100.0;
        heightField.set(constraint, fixedHeight);

        // Create base Size2D
        Size2D base = new Size2D(100.0, 80.0);

        // Execute method under test
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assertions
        assertEquals(widthRange.constrain(base.width), result.width, "Width should be constrained by widthRange");
        assertEquals(fixedHeight, result.height, "Height should be equal to fixed height");
    }

    @Test
    @DisplayName("WidthConstraintType is FIXED and HeightConstraintType is NONE")
    void TC07_FIXED_NONE() throws Exception {
        // Modified creation of RectangleConstraint instance with initial constructor
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.FIXED,
                0.0, null, LengthConstraintType.NONE);

        // Set fixed width
        Field widthField = RectangleConstraint.class.getDeclaredField("width");
        widthField.setAccessible(true);
        double fixedWidth = 120.0;
        widthField.set(constraint, fixedWidth);

        // Create base Size2D
        Size2D base = new Size2D(100.0, 80.0);

        // Execute method under test
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assertions
        assertEquals(fixedWidth, result.width, "Width should be equal to fixed width");
        assertEquals(base.height, result.height, "Height should be equal to base height");
    }

    @Test
    @DisplayName("WidthConstraintType is FIXED and HeightConstraintType is RANGE")
    void TC08_FIXED_RANGE() throws Exception {
        // Modified creation of RectangleConstraint instance with initial constructor
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.FIXED,
                0.0, null, LengthConstraintType.RANGE);

        // Set fixed width
        Field widthField = RectangleConstraint.class.getDeclaredField("width");
        widthField.setAccessible(true);
        double fixedWidth = 120.0;
        widthField.set(constraint, fixedWidth);

        // Set heightRange
        Field heightRangeField = RectangleConstraint.class.getDeclaredField("heightRange");
        heightRangeField.setAccessible(true);
        Range heightRange = new Range(60.0, 100.0);
        heightRangeField.set(constraint, heightRange);

        // Create base Size2D
        Size2D base = new Size2D(100.0, 80.0);

        // Execute method under test
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assertions
        assertEquals(fixedWidth, result.width, "Width should be equal to fixed width");
        assertEquals(heightRange.constrain(base.height), result.height, "Height should be constrained by heightRange");
    }

    @Test
    @DisplayName("WidthConstraintType is FIXED and HeightConstraintType is FIXED")
    void TC09_FIXED_FIXED() throws Exception {
        // Modified creation of RectangleConstraint instance with initial constructor
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.FIXED,
                0.0, null, LengthConstraintType.FIXED);

        // Set fixed width
        Field widthField = RectangleConstraint.class.getDeclaredField("width");
        widthField.setAccessible(true);
        double fixedWidth = 120.0;
        widthField.set(constraint, fixedWidth);

        // Set fixed height
        Field heightField = RectangleConstraint.class.getDeclaredField("height");
        heightField.setAccessible(true);
        double fixedHeight = 100.0;
        heightField.set(constraint, fixedHeight);

        // Create base Size2D
        Size2D base = new Size2D(100.0, 80.0);

        // Execute method under test
        Size2D result = constraint.calculateConstrainedSize(base);

        // Assertions
        assertEquals(fixedWidth, result.width, "Width should be equal to fixed width");
        assertEquals(fixedHeight, result.height, "Height should be equal to fixed height");
    }

    @Test
    @DisplayName("WidthConstraintType is NONE with heightRange.constrain throwing exception")
    void TC10_NONE_RANGE_Exception() throws Exception {
        // Modified creation of RectangleConstraint instance with initial constructor
        RectangleConstraint constraint = new RectangleConstraint(0.0, null, LengthConstraintType.NONE,
                0.0, null, LengthConstraintType.RANGE);

        // Set heightRange to null to simulate exception
        Field heightRangeField = RectangleConstraint.class.getDeclaredField("heightRange");
        heightRangeField.setAccessible(true);
        heightRangeField.set(constraint, null);

        // Create base Size2D
        Size2D base = new Size2D(100.0, 80.0);

        // Execute method under test and expect exception
        assertThrows(NullPointerException.class, () -> {
            constraint.calculateConstrainedSize(base);
        }, "Expected NullPointerException when heightRange is null");
    }

}