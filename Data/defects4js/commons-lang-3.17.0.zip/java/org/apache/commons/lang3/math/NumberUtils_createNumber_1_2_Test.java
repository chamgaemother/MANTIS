package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigInteger;

public class NumberUtils_createNumber_1_2_Test {

    @Test
    @DisplayName("Input string with lowercase type suffix 'f', should return Float")
    public void TC42_createNumber_lowercaseSuffixF_ReturnsFloat() {
        // Given
        String input = "123.45f";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertTrue(result instanceof Float, "Result should be instance of Float");
        assertEquals(123.45f, result.floatValue(), "Float value should match");
    }

    @Test
    @DisplayName("Input string with only '+' sign, should throw NumberFormatException")
    public void TC43_createNumber_onlyPlusSign_ThrowsNumberFormatException() {
        // Given
        String input = "+";

        // When & Then
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input), "Should throw NumberFormatException");
    }

    @Test
    @DisplayName("Input string with only '-' sign, should throw NumberFormatException")
    public void TC44_createNumber_onlyMinusSign_ThrowsNumberFormatException() {
        // Given
        String input = "-";

        // When & Then
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input), "Should throw NumberFormatException");
    }

    @Test
    @DisplayName("Input string with leading '-' sign and hexadecimal prefix '0x', should return BigInteger")
    public void TC45_createNumber_negativeHexadecimalInput_ReturnsBigInteger() {
        // Given
        String input = "-0x1A";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertTrue(result instanceof BigInteger, "Result should be instance of BigInteger");
        assertEquals(new BigInteger("-1A", 16), result, "BigInteger value should match");
    }

    @Test
    @DisplayName("Input string with prefix '0x' but no digits, should throw NumberFormatException")
    public void TC46_createNumber_hexPrefixWithoutDigits_ThrowsNumberFormatException() {
        // Given
        String input = "0x";

        // When & Then
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input), "Should throw NumberFormatException");
    }
}