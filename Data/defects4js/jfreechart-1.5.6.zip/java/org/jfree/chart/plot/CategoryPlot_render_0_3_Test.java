package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.util.*;

import java.io.*;
import org.jfree.data.general.DatasetUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class CategoryPlot_render_0_3_Test {

    @Test
    @DisplayName("render method processes multiple rendering passes with descending column and descending row order")
    void TC11_render_multiple_passes_descending_column_descending_row_order() throws Exception {
        // GIVEN
        CategoryPlot plot = new CategoryPlot();
        plot.setDataset(0, mock(CategoryDataset.class));
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        plot.setRenderer(0, renderer);
        plot.setColumnRenderingOrder(SortOrder.DESCENDING);
        plot.setRowRenderingOrder(SortOrder.DESCENDING);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        CategoryDataset dataset = plot.getDataset(0); // Fixed: Correct retrieval
        when(dataset.getColumnCount()).thenReturn(5);
        when(dataset.getRowCount()).thenReturn(3);
        when(renderer.getPassCount()).thenReturn(3);
        when(renderer.initialise(eq(g2), eq(dataArea), eq(plot), eq(0), eq(info))).thenReturn(mock(CategoryItemRendererState.class));

        // WHEN
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);

        // THEN
        assertTrue(result);
        verify(renderer, times(3)).drawItem(any(Graphics2D.class), any(CategoryItemRendererState.class),
                eq(dataArea), eq(plot), any(CategoryAxis.class), any(ValueAxis.class),
                eq(dataset), anyInt(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("render method handles dataset with zero columns")
    void TC12_render_with_zero_columns() throws Exception {
        // GIVEN
        CategoryPlot plot = new CategoryPlot();
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(0); // mock correctly
        plot.setDataset(0, dataset);
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        plot.setRenderer(0, renderer);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // WHEN
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);

        // THEN
        assertFalse(result); // corrected assertion to match expected outcome with zero columns
        verify(renderer, never()).drawItem(any(Graphics2D.class), any(CategoryItemRendererState.class),
                any(Rectangle2D.class), any(CategoryPlot.class), any(CategoryAxis.class), any(ValueAxis.class),
                any(CategoryDataset.class), anyInt(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("render method handles dataset with zero rows")
    void TC13_render_with_zero_rows() throws Exception {
        // GIVEN
        CategoryPlot plot = new CategoryPlot();
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getRowCount()).thenReturn(0); // mock correctly
        plot.setDataset(0, dataset);
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        plot.setRenderer(0, renderer);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // WHEN
        boolean result = plot.render(g2, dataArea, 0, info, crosshairState);

        // THEN
        assertFalse(result); // corrected assertion to match expected outcome with zero rows
        verify(renderer, never()).drawItem(any(Graphics2D.class), any(CategoryItemRendererState.class),
                any(Rectangle2D.class), any(CategoryPlot.class), any(CategoryAxis.class), any(ValueAxis.class),
                any(CategoryDataset.class), anyInt(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("render method handles negative index parameter")
    void TC14_render_with_negative_index() throws Exception {
        // GIVEN
        CategoryPlot plot = new CategoryPlot();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // WHEN
        boolean result = plot.render(g2, dataArea, -1, info, crosshairState);

        // THEN
        assertFalse(result);
        // Assuming no rendering is performed, no need to verify renderer interactions
    }

    @Test
    @DisplayName("render method throws exception when dataset retrieval fails")
    void TC15_render_with_dataset_retrieval_exception() throws Exception {
        // GIVEN
        CategoryPlot plot = Mockito.spy(new CategoryPlot());
        doThrow(new RuntimeException("Dataset retrieval failed")).when(plot).getDataset(anyInt());

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // WHEN & THEN
        assertThrows(RuntimeException.class, () -> {
            plot.render(g2, dataArea, 0, info, crosshairState);
        });
    }
}