package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TokenQueueTest {

    @Test
    void testEscapeCssIdentifier_nullInput_throwsNullPointerException() {
        assertThrows(NullPointerException.class, () -> {
            TokenQueue.escapeCssIdentifier(null);
        });
    }

    @Test
    void testEscapeCssIdentifier_emptyString_returnsEmpty() {
        assertEquals("", TokenQueue.escapeCssIdentifier(""));
    }

    @Test
    void testEscapeCssIdentifier_onlyLetters_returnsSame() {
        assertEquals("abcXYZ", TokenQueue.escapeCssIdentifier("abcXYZ"));
    }

    @Test
    void testEscapeCssIdentifier_onlyDigits_escaped() {
        assertEquals("\\31 ", TokenQueue.escapeCssIdentifier("1"));
        assertEquals("\\31 \\32 \\33 ", TokenQueue.escapeCssIdentifier("123"));
    }

    @Test
    void testEscapeCssIdentifier_startWithHyphenOnly_returnsHyphen() {
        assertEquals("-", TokenQueue.escapeCssIdentifier("-"));
    }

    @Test
    void testEscapeCssIdentifier_startWithHyphenFollowedByDigit_escapedDigit() {
        assertEquals("-\\31 ", TokenQueue.escapeCssIdentifier("-1"));
        assertEquals("-\\31 \\32 ", TokenQueue.escapeCssIdentifier("-12"));
    }

    @Test
    void testEscapeCssIdentifier_startWithHyphenFollowedByLetter_returnsSame() {
        assertEquals("-a", TokenQueue.escapeCssIdentifier("-a"));
        assertEquals("-abc", TokenQueue.escapeCssIdentifier("-abc"));
    }

    @Test
    void testEscapeCssIdentifier_containsSpace_escaped() {
        assertEquals("a\\ b", TokenQueue.escapeCssIdentifier("a b"));
        assertEquals("a\\ \\b", TokenQueue.escapeCssIdentifier("a  b"));
    }

    @Test
    void testEscapeCssIdentifier_containsSpecialCharacters_escaped() {
        assertEquals("a\\!\\@\\#", TokenQueue.escapeCssIdentifier("a!@#"));
        assertEquals("\\$a\\%b", TokenQueue.escapeCssIdentifier("$a%b"));
    }

    @Test
    void testEscapeCssIdentifier_containsUnicodeCharacters_preserved() {
        assertEquals("café", TokenQueue.escapeCssIdentifier("café"));
        assertEquals("naïve", TokenQueue.escapeCssIdentifier("naïve"));
    }

    @Test
    void testEscapeCssIdentifier_containsNullCharacter_replaced() {
        assertEquals("a\uFFFDb", TokenQueue.escapeCssIdentifier("a\u0000b"));
    }

    @Test
    void testEscapeCssIdentifier_controlCharacters_escaped() {
        assertEquals("a\\1f b", TokenQueue.escapeCssIdentifier("a\u001F b"));
        assertEquals("a\\7f ", TokenQueue.escapeCssIdentifier("a\u007F "));
    }

    @Test
    void testEscapeCssIdentifier_mixedContent_correctlyEscaped() {
        assertEquals("-\\31 a\\!b\\#", TokenQueue.escapeCssIdentifier("-1a!b#"));
    }

    @Test
    void testEscapeCssIdentifier_allSpecialCharacters_escaped() {
        String special = "!@#$%^&*()+=[]{}|;:',.<>/?`~";
        StringBuilder escaped = new StringBuilder();
        for(char c : special.toCharArray()) {
            escaped.append('\\').append(c);
        }
        assertEquals(escaped.toString(), TokenQueue.escapeCssIdentifier(special));
    }

    @Test
    void testEscapeCssIdentifier_onlyHyphensAndUnderscores_preserved() {
        assertEquals("--__", TokenQueue.escapeCssIdentifier("--__"));
    }

    @Test
    void testEscapeCssIdentifier_startWithNonHyphenNonDigit_specialCharactersEscaped() {
        assertEquals("\\!abc", TokenQueue.escapeCssIdentifier("!abc"));
        assertEquals("\\@abc", TokenQueue.escapeCssIdentifier("@abc"));
    }

    @Test
    void testEscapeCssIdentifier_maximumHexEscape() {
        assertEquals("\\123456 ", TokenQueue.escapeCssIdentifier("\u123456"));
    }

    @Test
    void testEscapeCssIdentifier_escapeWithSpaceAfterHex() {
        assertEquals("\\31 a", TokenQueue.escapeCssIdentifier("1 a"));
    }

    @Test
    void testEscapeCssIdentifier_escapeWithNewlineAfterHex() {
        String input = "1\na";
        String expected = "\\31 \na";
        assertEquals(expected, TokenQueue.escapeCssIdentifier(input));
    }

    @Test
    void testEscapeCssIdentifier_escapeWithCarriageReturnAfterHex() {
        String input = "1\ra";
        String expected = "\\31 \ra";
        assertEquals(expected, TokenQueue.escapeCssIdentifier(input));
    }

    @Test
    void testEscapeCssIdentifier_escapeWithFormFeedAfterHex() {
        String input = "1\fa";
        String expected = "\\31 \fa";
        assertEquals(expected, TokenQueue.escapeCssIdentifier(input));
    }

    @Test
    void testEscapeCssIdentifier_escapeSurrogatePairs_replaced() {
        String input = "a\uD800b"; // Invalid surrogate pair
        String expected = "a\uFFFDb";
        assertEquals(expected, TokenQueue.escapeCssIdentifier(input));
    }
}