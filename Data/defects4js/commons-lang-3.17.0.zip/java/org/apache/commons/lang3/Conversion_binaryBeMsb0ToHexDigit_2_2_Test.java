package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Conversion_binaryBeMsb0ToHexDigit_2_2_Test {

    @Test
    @DisplayName("Throws IndexOutOfBoundsException when srcPos exceeds src array length")
    void TC24() {
        boolean[] src = {true, false};
        int srcPos = 3;

        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(src, srcPos);
        });

        assertEquals("3 is not within array length 2", exception.getMessage());
    }
}