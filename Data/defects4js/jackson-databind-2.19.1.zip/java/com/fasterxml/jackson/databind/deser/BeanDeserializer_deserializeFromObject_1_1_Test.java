package com.fasterxml.jackson.databind.deser;

import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.lang.reflect.Field;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonTokenId;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler;
import com.fasterxml.jackson.databind.deser.impl.UnwrappedPropertyHandler;

public class BeanDeserializer_deserializeFromObject_1_1_Test {

    @Test
    @DisplayName("TC27: deserializeFromObject when _objectIdReader is present but maySerializeAsObject is false")
    public void TC27_deserializeFromObject_ObjectIdReaderPresent_MaySerializeAsObjectFalse() throws Exception {
        // Arrange
        BeanDeserializer deserializer = createBeanDeserializer();
        
        // Set _objectIdReader with maySerializeAsObject = false
        ObjectIdReader objectIdReader = mock(ObjectIdReader.class);
        when(objectIdReader.maySerializeAsObject()).thenReturn(false);
        setPrivateField(deserializer, "_objectIdReader", objectIdReader);

        // Mock JsonParser to simulate JSON Object without Object ID
        JsonParser parser = mock(JsonParser.class);
        DeserializationContext ctxt = mock(DeserializationContext.class);
        
        // Simulate tokens: START_OBJECT, END_OBJECT
        when(parser.isExpectedStartObjectToken()).thenReturn(true);
        when(parser.nextToken()).thenReturn(JsonToken.END_OBJECT);
        
        // Setup: Use real method call for deserializeFromObject
        when(deserializer.deserializeFromObject(parser, ctxt)).thenCallRealMethod();
        
        // Act
        Object result = deserializer.deserializeFromObject(parser, ctxt);
        
        // Assert
        assertNotNull(result, "Bean should be deserialized using default deserialization process");
        verify(objectIdReader, times(1)).maySerializeAsObject();
        verify(parser, times(1)).isExpectedStartObjectToken();
        verify(parser, times(1)).nextToken();
    }

    @Test
    @DisplayName("TC28: deserializeFromObject when _objectIdReader is present, maySerializeAsObject is true, but reference property name is invalid")
    public void TC28_deserializeFromObject_ObjectIdReaderPresent_MaySerializeAsObjectTrue_InvalidReferenceProperty() throws Exception {
        // Arrange
        BeanDeserializer deserializer = createBeanDeserializer();
        
        // Set _objectIdReader with maySerializeAsObject = true
        ObjectIdReader objectIdReader = mock(ObjectIdReader.class);
        when(objectIdReader.maySerializeAsObject()).thenReturn(true);
        when(objectIdReader.isValidReferencePropertyName(anyString(), any(JsonParser.class))).thenReturn(false);
        setPrivateField(deserializer, "_objectIdReader", objectIdReader);

        // Mock JsonParser to simulate invalid reference property name
        JsonParser parser = mock(JsonParser.class);
        DeserializationContext ctxt = mock(DeserializationContext.class);
        
        when(parser.hasTokenId(JsonTokenId.ID_FIELD_NAME)).thenReturn(true);
        when(parser.currentName()).thenReturn("invalidRefProperty");
        when(parser.nextToken()).thenReturn(JsonToken.START_OBJECT);
        
        // Setup: Use real method call for deserializeFromObject
        when(deserializer.deserializeFromObject(parser, ctxt)).thenCallRealMethod();

        // Act
        Object result = deserializer.deserializeFromObject(parser, ctxt);
        
        // Assert
        assertNotNull(result, "Bean should be deserialized without Object ID handling");
        verify(objectIdReader, times(1)).maySerializeAsObject();
        verify(objectIdReader, times(1)).isValidReferencePropertyName("invalidRefProperty", parser);
    }

    @Test
    @DisplayName("TC29: deserializeFromObject with _nonStandardCreation true and both _unwrappedPropertyHandler and _externalTypeIdHandler as null")
    public void TC29_deserializeFromObject_NonStandardCreation_UnwrappedAndExternalTypeIdHandlerNull() throws Exception {
        // Arrange
        BeanDeserializer deserializer = createBeanDeserializer();
        
        // Set _nonStandardCreation = true
        setPrivateField(deserializer, "_nonStandardCreation", true);
        
        // Set _unwrappedPropertyHandler and _externalTypeIdHandler to null
        setPrivateField(deserializer, "_unwrappedPropertyHandler", null);
        setPrivateField(deserializer, "_externalTypeIdHandler", null);
        
        // Mock JsonParser to simulate default JSON Object
        JsonParser parser = mock(JsonParser.class);
        DeserializationContext ctxt = mock(DeserializationContext.class);
        
        // Simulate tokens that lead to non-default instantiation
        when(parser.isExpectedStartObjectToken()).thenReturn(true);
        when(parser.nextToken()).thenReturn(JsonToken.END_OBJECT);
        
        // Setup: Use real method call for deserializeFromObjectUsingNonDefault
        when(deserializer.deserializeFromObjectUsingNonDefault(parser, ctxt)).thenCallRealMethod();

        // Act
        Object result = deserializer.deserializeFromObject(parser, ctxt);
        
        // Assert
        assertNotNull(result, "Bean should be deserialized using non-default instantiation method");
    }

    @Test
    @DisplayName("TC30: deserializeFromObject with _nonStandardCreation true and _unwrappedPropertyHandler not null")
    public void TC30_deserializeFromObject_NonStandardCreation_WithUnwrappedPropertyHandler() throws Exception {
        // Arrange
        BeanDeserializer deserializer = createBeanDeserializer();
        
        // Set _nonStandardCreation = true
        setPrivateField(deserializer, "_nonStandardCreation", true);
        
        // Set _unwrappedPropertyHandler
        UnwrappedPropertyHandler unwrappedHandler = mock(UnwrappedPropertyHandler.class);
        setPrivateField(deserializer, "_unwrappedPropertyHandler", unwrappedHandler);
        
        // Mock JsonParser to simulate JSON Object with unwrapped properties
        JsonParser parser = mock(JsonParser.class);
        DeserializationContext ctxt = mock(DeserializationContext.class);
        
        // Simulate unwrapped property processing
        when(parser.hasTokenId(JsonTokenId.ID_FIELD_NAME)).thenReturn(true);
        when(parser.currentName()).thenReturn("unwrappedProperty");
        when(parser.nextFieldName()).thenReturn(null);
        
        // Setup: Use real method call for deserializeWithUnwrapped
        when(deserializer.deserializeWithUnwrapped(parser, ctxt)).thenCallRealMethod();

        // Act
        Object result = deserializer.deserializeFromObject(parser, ctxt);
        
        // Assert
        assertNotNull(result, "Bean should be deserialized with unwrapped properties");
    }

    @Test
    @DisplayName("TC31: deserializeFromObject with _nonStandardCreation true and _externalTypeIdHandler not null")
    public void TC31_deserializeFromObject_NonStandardCreation_WithExternalTypeIdHandler() throws Exception {
        // Arrange
        BeanDeserializer deserializer = createBeanDeserializer();
        
        // Set _nonStandardCreation = true
        setPrivateField(deserializer, "_nonStandardCreation", true);
        
        // Set _externalTypeIdHandler
        ExternalTypeHandler externalTypeHandler = mock(ExternalTypeHandler.class);
        setPrivateField(deserializer, "_externalTypeIdHandler", externalTypeHandler);
        
        // Mock JsonParser to simulate JSON Object with external type IDs
        JsonParser parser = mock(JsonParser.class);
        DeserializationContext ctxt = mock(DeserializationContext.class);
        
        // Setup: Use real method call for deserializeWithExternalTypeId
        when(deserializer.deserializeWithExternalTypeId(parser, ctxt)).thenCallRealMethod();

        // Act
        Object result = deserializer.deserializeFromObject(parser, ctxt);
        
        // Assert
        assertNotNull(result, "Bean should be deserialized with external type ID handling");
    }
    
    // Helper method to create BeanDeserializer instance using reflection
    private BeanDeserializer createBeanDeserializer() throws Exception {
        // Adjusted to allow realistic instance creation of BeanDeserializer
        return mock(BeanDeserializer.class, withSettings().defaultAnswer(CALLS_REAL_METHODS));
    }
    
    // Helper method to set private fields via reflection
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = BeanDeserializer.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}