import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.LinearGradientPaint;
import java.awt.MultipleGradientPaint.CycleMethod;
import java.awt.Paint;
import java.awt.RadialGradientPaint;

import org.jfree.chart.util.PaintUtils;
import org.junit.jupiter.api.Test;

public class PaintUtilsTest {

    @Test
    public void testEqualWhenBothPaintsAreNull() {
        assertTrue(PaintUtils.equal(null, null));
    }

    @Test
    public void testEqualWhenFirstPaintIsNull() {
        Paint p2 = new Color(255, 0, 0);
        assertFalse(PaintUtils.equal(null, p2));
    }

    @Test
    public void testEqualWhenSecondPaintIsNull() {
        Paint p1 = new Color(255, 0, 0);
        assertFalse(PaintUtils.equal(p1, null));
    }

    @Test
    public void testEqualWhenPaintsAreSameInstance() {
        Paint p = new Color(255, 0, 0);
        assertTrue(PaintUtils.equal(p, p));
    }

    @Test
    public void testEqualWhenPaintsAreDifferentColors() {
        Paint p1 = new Color(255, 0, 0);
        Paint p2 = new Color(0, 255, 0);
        assertFalse(PaintUtils.equal(p1, p2));
    }

    @Test
    public void testEqualWhenGradientPaintsAreEqual() {
        GradientPaint gp1 = new GradientPaint(0, 0, Color.RED, 1, 1, Color.BLUE, true);
        GradientPaint gp2 = new GradientPaint(0, 0, Color.RED, 1, 1, Color.BLUE, true);
        assertTrue(PaintUtils.equal(gp1, gp2));
    }

    @Test
    public void testEqualWhenGradientPaintsAreNotEqual() {
        GradientPaint gp1 = new GradientPaint(0, 0, Color.RED, 1, 1, Color.BLUE, true);
        GradientPaint gp2 = new GradientPaint(0, 0, Color.RED, 1, 1, Color.GREEN, true);
        assertFalse(PaintUtils.equal(gp1, gp2));
    }

    @Test
    public void testEqualWhenLinearGradientPaintsAreEqual() {
        LinearGradientPaint lgp1 = new LinearGradientPaint(
                0, 0, 1, 1, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.BLUE}, 
                CycleMethod.NO_CYCLE);
        LinearGradientPaint lgp2 = new LinearGradientPaint(
                0, 0, 1, 1, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.BLUE}, 
                CycleMethod.NO_CYCLE);
        assertTrue(PaintUtils.equal(lgp1, lgp2));
    }

    @Test
    public void testEqualWhenLinearGradientPaintsAreNotEqual() {
        LinearGradientPaint lgp1 = new LinearGradientPaint(
                0, 0, 1, 1, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.BLUE}, 
                CycleMethod.NO_CYCLE);
        LinearGradientPaint lgp2 = new LinearGradientPaint(
                0, 0, 1, 1, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.GREEN}, 
                CycleMethod.NO_CYCLE);
        assertFalse(PaintUtils.equal(lgp1, lgp2));
    }

    @Test
    public void testEqualWhenRadialGradientPaintsAreEqual() {
        RadialGradientPaint rgp1 = new RadialGradientPaint(
                0, 0, 1, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.BLUE}, 
                CycleMethod.NO_CYCLE);
        RadialGradientPaint rgp2 = new RadialGradientPaint(
                0, 0, 1, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.BLUE}, 
                CycleMethod.NO_CYCLE);
        assertTrue(PaintUtils.equal(rgp1, rgp2));
    }

    @Test
    public void testEqualWhenRadialGradientPaintsAreNotEqual() {
        RadialGradientPaint rgp1 = new RadialGradientPaint(
                0, 0, 1, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.BLUE}, 
                CycleMethod.NO_CYCLE);
        RadialGradientPaint rgp2 = new RadialGradientPaint(
                1, 1, 2, 
                new float[] {0.0f, 1.0f}, 
                new Color[] {Color.RED, Color.GREEN}, 
                CycleMethod.NO_CYCLE);
        assertFalse(PaintUtils.equal(rgp1, rgp2));
    }

    @Test
    public void testEqualUsingNonGradientPaints() {
        Paint p1 = new Color(255, 127, 0);
        Paint p2 = new Color(255, 127, 0);
        assertTrue(PaintUtils.equal(p1, p2));
    }
}