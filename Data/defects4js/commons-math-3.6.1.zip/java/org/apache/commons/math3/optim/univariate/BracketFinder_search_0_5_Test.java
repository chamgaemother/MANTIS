//package org.apache.commons.math3.optim.univariate;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Assertions;
//import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
//import org.apache.commons.math3.analysis.UnivariateFunction;
//
//import static org.mockito.Mockito.*;
//
//import java.lang.reflect.Field;
//
//public class BracketFinder_search_0_5_Test {
//
//    @Test
//    @DisplayName("search method with (w - wLim)*(xC - w) > 0, evaluating fW and potentially updating xB")
//    public void test_TC21() throws Exception {
//        // Given
//        GoalType goal = GoalType.MAXIMIZE;
//        double xA = 1.0;
//        double growLimit = 2.0;
//
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        // Mock behavior to satisfy (w - wLim)*(xC - w) > 0
//        // Define specific return values based on input x
//        when(func.value(1.0)).thenReturn(5.0); // f(xA)
//        when(func.value(2.0)).thenReturn(3.0); // f(xB)
//        when(func.value(3.0)).thenReturn(4.0); // f(xC)
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // When
//        bracketFinder.search(func, goal, xA, growLimit);
//
//        // Then
//        // Access internal fields via reflection
//        Field xBField = BracketFinder.class.getDeclaredField("xB");
//        xBField.setAccessible(true);
//        double xB = xBField.getDouble(bracketFinder);
//
//        Field xCField = BracketFinder.class.getDeclaredField("xC");
//        xCField.setAccessible(true);
//        double xC = xCField.getDouble(bracketFinder);
//
//        // Assert that xB and xC are updated correctly
//        Assertions.assertEquals(2.0, xB, 1e-6);
//        Assertions.assertEquals(3.0, xC, 1e-6);
//    }
//
//    @Test
//    @DisplayName("search method concluding with all conditions leading to final return without swapping lo and hi")
//    public void test_TC22() throws Exception {
//        // Given
//        GoalType goal = GoalType.MINIMIZE;
//        double xA = 1.0;
//        double growLimit = 2.0;
//
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        // Mock behavior to ensure lo <= hi after evaluations
//        when(func.value(1.0)).thenReturn(2.0); // f(xA)
//        when(func.value(2.0)).thenReturn(1.0); // f(xB)
//        when(func.value(3.0)).thenReturn(1.5); // f(xC)
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // When
//        bracketFinder.search(func, goal, xA, growLimit);
//
//        // Then
//        // Access internal fields via reflection
//        Field loField = BracketFinder.class.getDeclaredField("lo");
//        loField.setAccessible(true);
//        double loVal = loField.getDouble(bracketFinder);
//
//        Field hiField = BracketFinder.class.getDeclaredField("hi");
//        hiField.setAccessible(true);
//        double hiVal = hiField.getDouble(bracketFinder);
//
//        // Assert no swap occurs
//        Assertions.assertTrue(loVal <= hiVal, "lo should be less than or equal to hi");
//        Assertions.assertEquals(1.0, loVal, 1e-6);
//        Assertions.assertEquals(2.0, hiVal, 1e-6);
//    }
//
//    @Test
//    @DisplayName("search method with final condition lo > hi triggering swap before return")
//    public void test_TC23() throws Exception {
//        // Given
//        GoalType goal = GoalType.MAXIMIZE;
//        double xA = 3.0;
//        double growLimit = 2.0;
//
//        UnivariateFunction func = mock(UnivariateFunction.class);
//
//        // Mock behavior to result in lo > hi after final evaluations
//        when(func.value(3.0)).thenReturn(4.0); // f(xA)
//        when(func.value(1.0)).thenReturn(5.0); // f(xB)
//        when(func.value(2.0)).thenReturn(3.0); // f(xC)
//
//        BracketFinder bracketFinder = new BracketFinder();
//
//        // When
//        bracketFinder.search(func, goal, xA, growLimit);
//
//        // Then
//        // Access internal fields via reflection
//        Field loField = BracketFinder.class.getDeclaredField("lo");
//        loField.setAccessible(true);
//        double loVal = loField.getDouble(bracketFinder);
//
//        Field hiField = BracketFinder.class.getDeclaredField("hi");
//        hiField.setAccessible(true);
//        double hiVal = hiField.getDouble(bracketFinder);
//
//        // Assert lo and hi are swapped
//        Assertions.assertTrue(loVal <= hiVal, "lo should be less than or equal to hi after swap");
//        Assertions.assertEquals(1.0, loVal, 1e-6);
//        Assertions.assertEquals(3.0, hiVal, 1e-6);
//    }
//
//}