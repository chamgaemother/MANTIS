package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.collections4.map.Flat3Map;

import java.lang.reflect.Field;

public class Flat3Map_get_0_3_Test {

    @Test
    @DisplayName("delegateMap is null, key is not null, size is 1, hash does not match or keys not equal")
    public void test_TC11() throws Exception {
        // Arrange
        Flat3Map map = new Flat3Map();
        
        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);
        
        // Set hash1 to a different value than targetKey.hashCode()
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, 12345); // Assuming targetKey.hashCode() != 12345
        
        // Set key1 to a different key
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "differentKey");
        
        // Initialize targetKey
        Object targetKey = "targetKey";
        
        // Act
        Object result = map.get(targetKey);
        
        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("delegateMap is null, key is not null, size is 2, hash matches and keys are equal")
    public void test_TC12() throws Exception {
        // Arrange
        Flat3Map map = new Flat3Map();
        
        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);
        
        // Initialize targetKey
        Object targetKey = "targetKey";
        int targetHash = targetKey.hashCode();
        
        // Set hash2 to match targetKey.hashCode()
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, targetHash);
        
        // Set key2 to targetKey
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, targetKey);
        
        // Assume value2 is expected to be returned
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object expectedValue = "value2";
        value2Field.set(map, expectedValue);
        
        // Act
        Object result = map.get(targetKey);
        
        // Assert
        assertEquals(expectedValue, result);
    }

    @Test
    @DisplayName("delegateMap is null, key is not null, size is 2, hash does not match or keys not equal")
    public void test_TC13() throws Exception {
        // Arrange
        Flat3Map map = new Flat3Map();
        
        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);
        
        // Initialize targetKey
        Object targetKey = "targetKey";
        int targetHash = targetKey.hashCode();
        
        // Set hash2 to a different value than targetKey.hashCode()
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, targetHash + 1);
        
        // Set key2 to a different key
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "differentKey");
        
        // Act
        Object result = map.get(targetKey);
        
        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("delegateMap is null, key is not null, size is 3, hash matches and keys are equal")
    public void test_TC14() throws Exception {
        // Arrange
        Flat3Map map = new Flat3Map();
        
        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);
        
        // Initialize targetKey
        Object targetKey = "targetKey";
        int targetHash = targetKey.hashCode();
        
        // Set hash3 to match targetKey.hashCode()
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, targetHash);
        
        // Set key3 to targetKey
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, targetKey);
        
        // Assume value3 is expected to be returned
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object expectedValue = "value3";
        value3Field.set(map, expectedValue);
        
        // Act
        Object result = map.get(targetKey);
        
        // Assert
        assertEquals(expectedValue, result);
    }

    @Test
    @DisplayName("delegateMap is null, key is not null, size is 3, hash does not match or keys not equal")
    public void test_TC15() throws Exception {
        // Arrange
        Flat3Map map = new Flat3Map();
        
        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);
        
        // Initialize targetKey
        Object targetKey = "targetKey";
        int targetHash = targetKey.hashCode();
        
        // Set hash3 to a different value than targetKey.hashCode()
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, targetHash + 1);
        
        // Set key3 to a different key
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "differentKey");
        
        // Act
        Object result = map.get(targetKey);
        
        // Assert
        assertNull(result);
    }
}