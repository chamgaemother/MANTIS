package org.apache.commons.jxpath.ri.model.jdom;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Locale;

import org.apache.commons.jxpath.JXPathContext;
import org.jdom.CDATA;
import org.jdom.Comment;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.junit.jupiter.api.Test;

public class JDOMNodePointerTest {

    @Test
    public void testAsPath_WithId() {
        Element root = new Element("root");
        JDOMNodePointer pointer = new JDOMNodePointer(root, Locale.ENGLISH, "123");
        assertEquals("id('123')", pointer.asPath());
    }

    @Test
    public void testAsPath_NoId_NoParent_Element_NoNamespace() {
        Element root = new Element("root");
        JDOMNodePointer pointer = new JDOMNodePointer(root, Locale.ENGLISH);
        assertEquals("/root[1]", pointer.asPath());
    }

    @Test
    public void testAsPath_NoId_WithParent_Element_WithNamespaceAndPrefix() {
        Element parent = new Element("parent", "http://example.com/ns");
        parent.addNamespaceDeclaration("ex", "http://example.com/ns");
        Element child = new Element("child", "http://example.com/ns");
        parent.addContent(child);
        JDOMNodePointer parentPointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        JDOMNodePointer childPointer = new JDOMNodePointer(parentPointer, child);
        assertEquals("/ex:parent[1]/ex:child[1]", childPointer.asPath());
    }

    @Test
    public void testAsPath_NoId_WithParent_Element_WithNamespace_NoPrefix() {
        Element parent = new Element("parent", Namespace.NO_NAMESPACE);
        Element child = new Element("child", "http://example.com/ns");
        parent.addContent(child);
        JDOMNodePointer parentPointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        JDOMNodePointer childPointer = new JDOMNodePointer(parentPointer, child);
        assertEquals("/node()[1]", childPointer.asPath());
    }

    @Test
    public void testAsPath_NoId_WithParent_NonJDOMNodePointer() {
        Element parent = new Element("parent");
        JDOMNodePointer nonJDOMParent = new JDOMNodePointer(parent, Locale.ENGLISH) {
            @Override
            public String asPath() {
                return "/customParent";
            }
        };
        Element child = new Element("child");
        JDOMNodePointer childPointer = new JDOMNodePointer(nonJDOMParent, child);
        assertEquals("/customParent/child[1]", childPointer.asPath());
    }

    @Test
    public void testAsPath_TextNode() {
        Element parent = new Element("parent");
        Text text = new Text("Some text");
        parent.addContent(text);
        JDOMNodePointer parentPointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        JDOMNodePointer textPointer = new JDOMNodePointer(parentPointer, text);
        assertEquals("/parent[1]/text()[1]", textPointer.asPath());
    }

    @Test
    public void testAsPath_CDATANode() {
        Element parent = new Element("parent");
        CDATA cdata = new CDATA("Some CDATA");
        parent.addContent(cdata);
        JDOMNodePointer parentPointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        JDOMNodePointer cdataPointer = new JDOMNodePointer(parentPointer, cdata);
        assertEquals("/parent[1]/text()[1]", cdataPointer.asPath());
    }

    @Test
    public void testAsPath_ProcessingInstruction() {
        Element parent = new Element("parent");
        ProcessingInstruction pi = new ProcessingInstruction("target", "data");
        parent.addContent(pi);
        JDOMNodePointer parentPointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        JDOMNodePointer piPointer = new JDOMNodePointer(parentPointer, pi);
        assertEquals("/parent[1]/processing-instruction('target')[1]", piPointer.asPath());
    }

    @Test
    public void testAsPath_Element_WithParentPath() {
        Element grandParent = new Element("grandparent");
        Element parent = new Element("parent");
        Element child = new Element("child");
        grandParent.addContent(parent);
        parent.addContent(child);
        JDOMNodePointer grandParentPointer = new JDOMNodePointer(grandParent, Locale.ENGLISH);
        JDOMNodePointer parentPointer = new JDOMNodePointer(grandParentPointer, parent);
        JDOMNodePointer childPointer = new JDOMNodePointer(parentPointer, child);
        assertEquals("/grandparent[1]/parent[1]/child[1]", childPointer.asPath());
    }

    @Test
    public void testAsPath_Element_WithoutParent() {
        Element root = new Element("root");
        JDOMNodePointer pointer = new JDOMNodePointer(root, Locale.ENGLISH);
        assertEquals("/root[1]", pointer.asPath());
    }

    @Test
    public void testAsPath_MultipleSiblings() {
        Element parent = new Element("parent");
        Element child1 = new Element("child");
        Element child2 = new Element("child");
        parent.addContent(child1);
        parent.addContent(child2);
        JDOMNodePointer parentPointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        JDOMNodePointer child1Pointer = new JDOMNodePointer(parentPointer, child1);
        JDOMNodePointer child2Pointer = new JDOMNodePointer(parentPointer, child2);
        assertEquals("/parent[1]/child[1]", child1Pointer.asPath());
        assertEquals("/parent[1]/child[2]", child2Pointer.asPath());
    }

    @Test
    public void testAsPath_SiblingProcessingInstructions() {
        Element parent = new Element("parent");
        ProcessingInstruction pi1 = new ProcessingInstruction("target", "data1");
        ProcessingInstruction pi2 = new ProcessingInstruction("target", "data2");
        parent.addContent(pi1);
        parent.addContent(pi2);
        JDOMNodePointer parentPointer = new JDOMNodePointer(parent, Locale.ENGLISH);
        JDOMNodePointer pi1Pointer = new JDOMNodePointer(parentPointer, pi1);
        JDOMNodePointer pi2Pointer = new JDOMNodePointer(parentPointer, pi2);
        assertEquals("/parent[1]/processing-instruction('target')[1]", pi1Pointer.asPath());
        assertEquals("/parent[1]/processing-instruction('target')[2]", pi2Pointer.asPath());
    }

    @Test
    public void testAsPath_SingleRootElement() {
        Document doc = new Document();
        Element root = new Element("root");
        doc.setRootElement(root);
        JDOMNodePointer pointer = new JDOMNodePointer(doc.getRootElement(), Locale.ENGLISH);
        assertEquals("/root[1]", pointer.asPath());
    }

    @Test
    public void testAsPath_NullIdAndParent() {
        Element root = new Element("root");
        JDOMNodePointer pointer = new JDOMNodePointer(root, Locale.ENGLISH);
        assertEquals("/root[1]", pointer.asPath());
    }
}