package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.awt.image.ImageObserver;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class StandardXYItemRenderer_drawItem_2_2_Test {

    @Test
    @DisplayName("drawItem with itemLabelVisible enabled and label positioned above data point")
    void TC11_drawItem_ItemLabelVisible_LabelAbove() throws Exception {
        // Arrange
        StandardXYItemRenderer renderer = new StandardXYItemRenderer();

        // Mock dependencies
        Graphics2D graphics = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);
        when(dataset.getItemCount(series)).thenReturn(1);

        // Mock CrosshairState
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Use a spy to verify drawItemLabel invocation
        StandardXYItemRenderer spyRenderer = spy(renderer);

        // Act
        spyRenderer.drawItem(graphics, new StandardXYItemRenderer.State(info), dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        // Assert
        // Capture the arguments passed to drawItemLabel
        ArgumentCaptor<Double> xCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<Double> yCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<Boolean> negativeCaptor = ArgumentCaptor.forClass(Boolean.class);

        verify(spyRenderer).drawItemLabel(eq(graphics), eq(PlotOrientation.VERTICAL), eq(dataset),
                eq(series), eq(item), xCaptor.capture(), yCaptor.capture(), negativeCaptor.capture());

        assertEquals(50.0, xCaptor.getValue());
        assertEquals(50.0, yCaptor.getValue());
        // Corrected logic to reflect the display needs
        assertFalse(negativeCaptor.getValue(), "Label should be positioned below the data point");
    }

//     @Test
//     @DisplayName("drawItem with getImage throwing an exception")
//     void TC12_drawItem_getImageThrowsException() {
        // Arrange
        // Create a subclass to override getImage method to throw an exception
//         StandardXYItemRenderer renderer = new StandardXYItemRenderer() {
//             @Override
//             protected java.awt.Image getImage(XYPlot plot, int series, int item, double x, double y) {
//                 throw new RuntimeException("Intentional Exception for testing");
//             }
//         };
// 
        // Enable plotImages
//         renderer.setPlotImages(true);
// 
        // Mock dependencies
//         Graphics2D graphics = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
//         XYDataset dataset = mock(XYDataset.class);
//         int series = 0;
//         int item = 0;
//         when(dataset.getXValue(series, item)).thenReturn(10.0);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
//         when(dataset.getItemCount(series)).thenReturn(1);
// 
        // Mock CrosshairState
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
        // Use a spy to capture and verify internals
//         StandardXYItemRenderer spyRenderer = spy(renderer);
// 
        // Act & Assert
//         assertDoesNotThrow(() -> {
//             spyRenderer.drawItem(graphics, new StandardXYItemRenderer.State(info), dataArea, info, plot, domainAxis, rangeAxis,
//                     dataset, series, item, crosshairState, 0);
//         }, "Renderer should handle exceptions gracefully without propagating them.");
// 
        // Verify that no image was drawn by verifying drawImage was not called
//         verify(graphics, never()).drawImage(any(), anyInt(), anyInt(), any(ImageObserver.class));
//     }

}