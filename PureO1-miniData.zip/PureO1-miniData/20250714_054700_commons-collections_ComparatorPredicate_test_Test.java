import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

import org.apache.commons.collections4.functors.ComparatorPredicate;
import org.apache.commons.collections4.functors.ComparatorPredicate.Criterion;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ComparatorPredicateTest {

    private final Integer reference = 10;

    private final Comparator<Integer> naturalComparator = Integer::compareTo;

    private final Comparator<Integer> reverseComparator = (a, b) -> b.compareTo(a);

    @Test
    public void testEqualCriterionTrue() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.EQUAL);
        assertTrue(predicate.test(10));
    }

    @Test
    public void testEqualCriterionFalse() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.EQUAL);
        assertFalse(predicate.test(5));
    }

    @Test
    public void testGreaterCriterionTrue() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.GREATER);
        assertTrue(predicate.test(5));
    }

    @Test
    public void testGreaterCriterionFalse() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.GREATER);
        assertFalse(predicate.test(15));
    }

    @Test
    public void testLessCriterionTrue() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.LESS);
        assertTrue(predicate.test(15));
    }

    @Test
    public void testLessCriterionFalse() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.LESS);
        assertFalse(predicate.test(5));
    }

    @Test
    public void testGreaterOrEqualCriterionTrueEqual() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.GREATER_OR_EQUAL);
        assertTrue(predicate.test(10));
    }

    @Test
    public void testGreaterOrEqualCriterionTrueGreater() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.GREATER_OR_EQUAL);
        assertTrue(predicate.test(5));
    }

    @Test
    public void testGreaterOrEqualCriterionFalse() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.GREATER_OR_EQUAL);
        assertFalse(predicate.test(15));
    }

    @Test
    public void testLessOrEqualCriterionTrueEqual() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.LESS_OR_EQUAL);
        assertTrue(predicate.test(10));
    }

    @Test
    public void testLessOrEqualCriterionTrueLess() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.LESS_OR_EQUAL);
        assertTrue(predicate.test(15));
    }

    @Test
    public void testLessOrEqualCriterionFalse() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.LESS_OR_EQUAL);
        assertFalse(predicate.test(5));
    }

    @Test
    public void testReverseComparatorGreater() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, reverseComparator, Criterion.GREATER);
        assertTrue(predicate.test(15));
    }

    @Test
    public void testReverseComparatorLess() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, reverseComparator, Criterion.LESS);
        assertTrue(predicate.test(5));
    }

    @Test
    public void testTestWithNullTarget() {
        Comparator<Integer> nullCompatibleComparator = (a, b) -> {
            if (b == null) {
                return a == null ? 0 : 1;
            }
            return a.compareTo(b);
        };
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(null, nullCompatibleComparator, Criterion.EQUAL);
        assertTrue(predicate.test(null));

        predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator, Criterion.LESS);
        assertFalse(predicate.test(null));
    }

    @Test
    public void testInvalidCriterionThrowsException() {
        ComparatorPredicate<Integer> predicate = new ComparatorPredicate<>(reference, naturalComparator, null);
        Exception exception = assertThrows(NullPointerException.class, () -> predicate.test(10));
        assertEquals("criterion is null", exception.getMessage());
    }

    @Test
    public void testComparatorIsNullThrowsException() {
        Exception exception = assertThrows(NullPointerException.class, () -> 
            ComparatorPredicate.comparatorPredicate(reference, null, Criterion.EQUAL));
        assertEquals("comparator is null", exception.getMessage());
    }

    @Test
    public void testDefaultCriterionEqual() {
        ComparatorPredicate<Integer> predicate = ComparatorPredicate.comparatorPredicate(reference, naturalComparator);
        assertTrue(predicate.test(10));
        assertFalse(predicate.test(20));
    }

    @Test
    public void testSwitchDefaultThrowsException() {
        ComparatorPredicate<Integer> predicate = new ComparatorPredicate<>(reference, naturalComparator, null);
        assertThrows(NullPointerException.class, () -> predicate.test(10));
    }
}