package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.compress.harmony.pack200.ClassBands.TempParamAnnotation;
import org.apache.commons.compress.harmony.pack200.AttributeDefinitionBands.AttributeDefinition;
import org.apache.commons.compress.harmony.pack200.CpBands.CPClass;
import org.apache.commons.compress.harmony.pack200.CpBands.CPNameAndType;
import org.apache.commons.compress.harmony.pack200.Segment.SegmentHeader;
import org.apache.commons.compress.harmony.pack200.Segment.SegmentMethodVisitor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.objectweb.asm.Label;

class ClassBandsTest {

    private ClassBands classBands;
    private Segment segment;
    private CpBands cpBands;
    private AttributeDefinitionBands attrBands;
    private SegmentHeader segmentHeader;

    @BeforeEach
    void setUp() throws IOException {
        segment = Mockito.mock(Segment.class);
        cpBands = Mockito.mock(CpBands.class);
        attrBands = Mockito.mock(AttributeDefinitionBands.class);
        segmentHeader = Mockito.mock(SegmentHeader.class);
        Mockito.when(segment.getCpBands()).thenReturn(cpBands);
        Mockito.when(segment.getAttrBands()).thenReturn(attrBands);
        Mockito.when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        Mockito.when(segmentHeader.getDefaultMajorVersion()).thenReturn(52);
        classBands = new ClassBands(segment, 1, 0, false);
    }

    @Test
    void testRemoveCurrentClass_NoFlagsSet_IndexZero() {
        classBands.endOfClass();
        classBands.removeCurrentClass();
        assertNull(classBands.class_this[0]);
        assertNull(classBands.class_super[0]);
        assertEquals(0, classBands.class_interface_count[0]);
        assertNull(classBands.class_interface[0]);
        assertEquals(0, classBands.major_versions[0]);
        assertEquals(0, classBands.class_flags[0]);
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_Flag17Set() {
        classBands.class_flags[0] |= (1 << 17);
        classBands.classSourceFile.add(Mockito.mock(CPUTF8.class));
        classBands.tempFieldFlags.add(19L); // Bit 17 and 19 set
        classBands.tempFieldFlags.add(0L); // No bits set
        classBands.tempMethodFlags.add(0L);
        classBands.tempFieldDesc.add(Mockito.mock(CPNameAndType.class));

        classBands.endOfClass();
        classBands.removeCurrentClass();

        assertNull(classBands.class_this[0]);
        assertEquals(0, classBands.class_interface_count[0]);
        assertNull(classBands.class_interface[0]);
        assertEquals(0, classBands.major_versions[0]);
        assertEquals(0, classBands.class_flags[0]);
        assertTrue(classBands.classSourceFile.isEmpty());
        assertTrue(classBands.tempFieldFlags.isEmpty());
        assertTrue(classBands.tempFieldDesc.isEmpty());
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_Flag18Set() {
        classBands.class_flags[0] |= (1 << 18);
        classBands.classEnclosingMethodClass.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.classEnclosingMethodDesc.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.tempMethodFlags.add(18L); // Bit 18 set

        classBands.endOfClass();
        classBands.removeCurrentClass();

        assertTrue(classBands.classEnclosingMethodClass.isEmpty());
        assertTrue(classBands.classEnclosingMethodDesc.isEmpty());
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_Flag19Set() {
        classBands.class_flags[0] |= (1 << 19);
        classBands.classSignature.add(Mockito.mock(CPSignature.class));
        classBands.tempMethodFlags.add(19L); // Bit 19 set

        classBands.endOfClass();
        classBands.removeCurrentClass();

        assertTrue(classBands.classSignature.isEmpty());
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_Flag21Set() {
        classBands.class_flags[0] |= (1 << 21);
        classBands.class_RVA_bands = Mockito.spy(classBands.class_RVA_bands);
        Mockito.doNothing().when(classBands.class_RVA_bands).removeLatest();

        classBands.endOfClass();
        classBands.removeCurrentClass();

        Mockito.verify(classBands.class_RVA_bands, Mockito.times(1)).removeLatest();
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_Flag22Set() {
        classBands.class_flags[0] |= (1 << 22);
        classBands.class_RIA_bands = Mockito.spy(classBands.class_RIA_bands);
        Mockito.doNothing().when(classBands.class_RIA_bands).removeLatest();

        classBands.endOfClass();
        classBands.removeCurrentClass();

        Mockito.verify(classBands.class_RIA_bands, Mockito.times(1)).removeLatest();
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_TempFieldFlags_SetAndNotSet() {
        classBands.class_flags[0] |= (1 << 17);
        classBands.classSourceFile.add(Mockito.mock(CPUTF8.class));
        classBands.tempFieldFlags.add(1L << 19); // Bit 19 set
        classBands.tempFieldFlags.add(0L); // No bits set

        classBands.fieldSignature.add(Mockito.mock(CPSignature.class));
        classBands.fieldConstantValueKQ.add(Mockito.mock(CPConstant.class));
        classBands.field_RVA_bands = Mockito.spy(classBands.field_RVA_bands);
        classBands.field_RIA_bands = Mockito.spy(classBands.field_RIA_bands);
        Mockito.doNothing().when(classBands.field_RVA_bands).removeLatest();
        Mockito.doNothing().when(classBands.field_RIA_bands).removeLatest();

        classBands.tempFieldFlags.add(1L << 21); // Bit 21 set
        classBands.tempFieldFlags.add(1L << 22); // Bit 22 set

        classBands.tempFieldDesc.add(Mockito.mock(CPNameAndType.class));

        classBands.endOfClass();
        classBands.removeCurrentClass();

        assertTrue(classBands.fieldSignature.isEmpty());
        assertTrue(classBands.fieldConstantValueKQ.isEmpty());
        Mockito.verify(classBands.field_RVA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.field_RIA_bands, Mockito.times(1)).removeLatest();
        assertTrue(classBands.tempFieldFlags.isEmpty());
        assertTrue(classBands.tempFieldDesc.isEmpty());
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_TempMethodFlags_SetVariousBits() {
        classBands.class_flags[0] |= (1 << 17);
        classBands.classSourceFile.add(Mockito.mock(CPUTF8.class));
        classBands.tempMethodFlags.add(19L); // Bit 19 set
        classBands.tempMethodFlags.add(18L); // Bit 18 set
        classBands.tempMethodFlags.add(17L); // Bit 17 set
        classBands.tempMethodFlags.add(21L); // Bit 21 set
        classBands.tempMethodFlags.add(22L); // Bit 22 set
        classBands.methodSignature.add(Mockito.mock(CPSignature.class));
        classBands.methodExceptionNumber.add(1);
        classBands.methodExceptionClasses.add(Mockito.mock(CPClass.class));
        classBands.methodSignature.add(Mockito.mock(CPSignature.class));
        classBands.method_RVA_bands = Mockito.spy(classBands.method_RVA_bands);
        classBands.method_RIA_bands = Mockito.spy(classBands.method_RIA_bands);
        classBands.method_RVPA_bands = Mockito.spy(classBands.method_RVPA_bands);
        classBands.method_RIPA_bands = Mockito.spy(classBands.method_RIPA_bands);
        classBands.method_AD_bands = Mockito.spy(classBands.method_AD_bands);
        Mockito.doNothing().when(classBands.method_RVA_bands).removeLatest();
        Mockito.doNothing().when(classBands.method_RIA_bands).removeLatest();
        Mockito.doNothing().when(classBands.method_RVPA_bands).removeLatest();
        Mockito.doNothing().when(classBands.method_RIPA_bands).removeLatest();
        Mockito.doNothing().when(classBands.method_AD_bands).removeLatest();

        classBands.codeMaxLocals.add(2);
        classBands.codeMaxStack.add(3);
        classBands.codeHandlerCount.add(1);
        classBands.codeHandlerStartP.add(new Label());
        classBands.codeHandlerEndPO.add(new Label());
        classBands.codeHandlerCatchPO.add(new Label());
        classBands.codeHandlerClass.add(Mockito.mock(CPClass.class));
        classBands.codeFlags.add(19L); // Bit 17 and 1 set
        classBands.codeLocalVariableTableN.add(1);
        classBands.codeLocalVariableTableBciP.add(10);
        classBands.codeLocalVariableTableSpanO.add(20);
        classBands.codeLocalVariableTableNameRU.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.codeLocalVariableTableTypeRS.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.codeLocalVariableTableSlot.add(1);
        classBands.codeLineNumberTableN.add(1);
        classBands.codeLineNumberTableBciP.add(5);
        classBands.codeLineNumberTableLine.add(100);

        classBands.endOfClass();
        classBands.removeCurrentClass();

        assertTrue(classBands.methodSignature.isEmpty());
        assertTrue(classBands.methodExceptionNumber.isEmpty());
        assertTrue(classBands.methodExceptionClasses.isEmpty());
        Mockito.verify(classBands.method_RVA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.method_RIA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.method_RVPA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.method_RIPA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.method_AD_bands, Mockito.times(1)).removeLatest();
        assertTrue(classBands.codeMaxLocals.isEmpty());
        assertTrue(classBands.codeMaxStack.isEmpty());
        assertTrue(classBands.codeHandlerCount.isEmpty());
        assertTrue(classBands.codeHandlerStartP.isEmpty());
        assertTrue(classBands.codeHandlerEndPO.isEmpty());
        assertTrue(classBands.codeHandlerCatchPO.isEmpty());
        assertTrue(classBands.codeHandlerClass.isEmpty());
        assertTrue(classBands.codeFlags.isEmpty());
        assertTrue(classBands.codeLocalVariableTableN.isEmpty());
        assertTrue(classBands.codeLocalVariableTableBciP.isEmpty());
        assertTrue(classBands.codeLocalVariableTableSpanO.isEmpty());
        assertTrue(classBands.codeLocalVariableTableNameRU.isEmpty());
        assertTrue(classBands.codeLocalVariableTableTypeRS.isEmpty());
        assertTrue(classBands.codeLocalVariableTableSlot.isEmpty());
        assertTrue(classBands.codeLineNumberTableN.isEmpty());
        assertTrue(classBands.codeLineNumberTableBciP.isEmpty());
        assertTrue(classBands.codeLineNumberTableLine.isEmpty());
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_IndexDecrements() {
        classBands.endOfClass(); // index =1
        classBands.endOfClass(); // index=2
        classBands.removeCurrentClass();
        assertEquals(1, classBands.index);
        classBands.removeCurrentClass();
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_IndexDoesNotGoNegative() {
        classBands.endOfClass(); // index=1
        classBands.removeCurrentClass();
        assertEquals(0, classBands.index);
        classBands.removeCurrentClass();
        assertEquals(0, classBands.index);
    }

    @Test
    void testRemoveCurrentClass_MultipleFlagsSet() {
        classBands.class_flags[0] |= (1 << 17) | (1 << 18) | (1 << 19) | (1 << 21) | (1 << 22);
        classBands.classSourceFile.add(Mockito.mock(CPUTF8.class));
        classBands.classEnclosingMethodClass.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.classEnclosingMethodDesc.add(Mockito.mock(ConstantPoolEntry.class));
        classBands.classSignature.add(Mockito.mock(CPSignature.class));
        classBands.class_RVA_bands = Mockito.spy(classBands.class_RVA_bands);
        classBands.class_RIA_bands = Mockito.spy(classBands.class_RIA_bands);
        Mockito.doNothing().when(classBands.class_RVA_bands).removeLatest();
        Mockito.doNothing().when(classBands.class_RIA_bands).removeLatest();

        classBands.tempFieldFlags.add(1L << 17);
        classBands.tempFieldFlags.add(1L << 19);
        classBands.tempFieldFlags.add(1L << 21);
        classBands.tempFieldFlags.add(1L << 22);
        classBands.fieldSignature.add(Mockito.mock(CPSignature.class));
        classBands.fieldConstantValueKQ.add(Mockito.mock(CPConstant.class));
        classBands.field_RVA_bands = Mockito.spy(classBands.field_RVA_bands);
        classBands.field_RIA_bands = Mockito.spy(classBands.field_RIA_bands);
        Mockito.doNothing().when(classBands.field_RVA_bands).removeLatest();
        Mockito.doNothing().when(classBands.field_RIA_bands).removeLatest();

        classBands.tempMethodFlags.add(19L);
        classBands.tempMethodFlags.add(18L);
        classBands.tempMethodFlags.add(17L);
        classBands.tempMethodFlags.add(21L);
        classBands.tempMethodFlags.add(22L);
        classBands.methodSignature.add(Mockito.mock(CPSignature.class));
        classBands.methodExceptionNumber.add(1);
        classBands.methodExceptionClasses.add(Mockito.mock(CPClass.class));
        classBands.method_RVA_bands = Mockito.spy(classBands.method_RVA_bands);
        classBands.method_RIA_bands = Mockito.spy(classBands.method_RIA_bands);
        classBands.method_RVPA_bands = Mockito.spy(classBands.method_RVPA_bands);
        classBands.method_RIPA_bands = Mockito.spy(classBands.method_RIPA_bands);
        Mockito.doNothing().when(classBands.method_RVA_bands).removeLatest();
        Mockito.doNothing().when(classBands.method_RIA_bands).removeLatest();
        Mockito.doNothing().when(classBands.method_RVPA_bands).removeLatest();
        Mockito.doNothing().when(classBands.method_RIPA_bands).removeLatest();

        classBands.endOfClass();
        classBands.removeCurrentClass();

        assertNull(classBands.class_this[0]);
        assertNull(classBands.class_super[0]);
        assertEquals(0, classBands.class_interface_count[0]);
        assertNull(classBands.class_interface[0]);
        assertEquals(0, classBands.major_versions[0]);
        assertEquals(0, classBands.class_flags[0]);
        assertTrue(classBands.classSourceFile.isEmpty());
        assertTrue(classBands.classEnclosingMethodClass.isEmpty());
        assertTrue(classBands.classEnclosingMethodDesc.isEmpty());
        assertTrue(classBands.classSignature.isEmpty());
        Mockito.verify(classBands.class_RVA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.class_RIA_bands, Mockito.times(1)).removeLatest();
        assertTrue(classBands.tempFieldFlags.isEmpty());
        assertTrue(classBands.fieldSignature.isEmpty());
        assertTrue(classBands.fieldConstantValueKQ.isEmpty());
        Mockito.verify(classBands.field_RVA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.field_RIA_bands, Mockito.times(1)).removeLatest();
        assertTrue(classBands.tempMethodFlags.isEmpty());
        assertTrue(classBands.methodSignature.isEmpty());
        assertTrue(classBands.methodExceptionNumber.isEmpty());
        assertTrue(classBands.methodExceptionClasses.isEmpty());
        Mockito.verify(classBands.method_RVA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.method_RIA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.method_RVPA_bands, Mockito.times(1)).removeLatest();
        Mockito.verify(classBands.method_RIPA_bands, Mockito.times(1)).removeLatest();
        assertEquals(0, classBands.index);
    }
}