package org.apache.commons.math3.optim.nonlinear.scalar.noderiv;

import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optim.PointValuePair;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;

public class NelderMeadSimplex_iterate_0_4_Test {

    @Test
    @DisplayName("iterate with maximum iterations leading to shrink")
    void TC16_iterateMaximumIterationsLeadingToShrink() {
        // Initialize MultivariateFunction
        MultivariateFunction function = point -> 0.0;

        // Initialize Comparator
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Initialize NelderMeadSimplex with dimension 2
        NelderMeadSimplex simplex = new NelderMeadSimplex(2);

        // Perform iteration
        simplex.iterate(function, comparator);

        // Assume shrink operation is verified by checking points
        PointValuePair best = simplex.getPoint(0);
        for (int i = 1; i <= simplex.getDimension(); i++) {
            PointValuePair point = simplex.getPoint(i);
            double[] expected = new double[simplex.getDimension()];
            double[] bestPoint = best.getPointRef();
            double[] currentPoint = point.getPointRef();
            for (int j = 0; j < simplex.getDimension(); j++) {
                expected[j] = bestPoint[j] + 0.5 * (currentPoint[j] - bestPoint[j]); // assuming sigma = 0.5 for shrink
                assertEquals(expected[j], currentPoint[j], 1e-6, "Point should be shrunk towards the best point");
            }
        }
    }

    @Test
    @DisplayName("iterate with comparator always returning equal values")
    void TC17_iterateComparatorAlwaysReturnsEqual() {
        // Initialize MultivariateFunction
        MultivariateFunction function = point -> 1.0;

        // Initialize Comparator that always returns zero
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(pair -> 0.0);

        // Initialize NelderMeadSimplex with dimension 2
        NelderMeadSimplex simplex = new NelderMeadSimplex(2);

        // Perform iteration
        simplex.iterate(function, comparator);

        // Access internal points to verify shrink has been performed
        PointValuePair best = simplex.getPoint(0);
        for (int i = 1; i <= simplex.getDimension(); i++) {
            PointValuePair point = simplex.getPoint(i);
            double[] expected = new double[simplex.getDimension()];
            double[] bestPoint = best.getPointRef();
            double[] currentPoint = point.getPointRef();
            for (int j = 0; j < simplex.getDimension(); j++) {
                expected[j] = bestPoint[j] + 0.5 * (currentPoint[j] - bestPoint[j]); // assuming sigma = 0.5 for shrink
                assertEquals(expected[j], currentPoint[j], 1e-6, "Point should be shrunk due to no improvement in comparator");
            }
        }
    }

    @Test
    @DisplayName("iterate with rho set to extreme value influencing reflection")
    void TC18_iterateWithExtremeRhoInfluencingReflection() {
        // Initialize MultivariateFunction
        MultivariateFunction function = point -> 2.0;

        // Initialize Comparator
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Initialize NelderMeadSimplex with dimension 2
        NelderMeadSimplex simplex = new NelderMeadSimplex(2, 10.0, 1000.0, 2.0, 0.5, 0.5);

        // Perform iteration
        simplex.iterate(function, comparator);

        // Assert the behavior of extreme rho is verified through existing logic;
        assertNotNull(simplex);
    }

    @Test
    @DisplayName("iterate with khi set to zero, affecting expansion")
    void TC19_iterateWithKhiSetToZeroAffectingExpansion() throws Exception {
        // Initialize MultivariateFunction
        MultivariateFunction function = point -> -1.0;

        // Initialize Comparator
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Initialize NelderMeadSimplex with dimension 2
        NelderMeadSimplex simplex = new NelderMeadSimplex(2, 10.0, 1.0, 0.0, 0.5, 0.5);

        // Perform iteration
        simplex.iterate(function, comparator);

        // Assert function with khi set to zero
        assertNotNull(simplex);
    }

    @Test
    @DisplayName("iterate with gamma set to one impacting contraction")
    void TC20_iterateWithGammaSetToOneImpactingContraction() throws Exception {
        // Initialize MultivariateFunction
        MultivariateFunction function = point -> 3.0;

        // Initialize Comparator
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Initialize NelderMeadSimplex with dimension 2
        NelderMeadSimplex simplex = new NelderMeadSimplex(2, 10.0, 1.0, 2.0, 1.0, 0.5);

        // Perform iteration
        simplex.iterate(function, comparator);

        // Assert function with gamma set to one
        assertNotNull(simplex);
    }
}
