package org.jsoup.nodes;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.jsoup.helper.HttpConnection;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.FormElement;
import org.jsoup.parser.Tag;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FormElement_formData_0_4_Test {

//     @Test
//     @DisplayName("formData handles elements with multiple selected options in select")
//     public void testFormDataHandlesMultipleSelectedOptions() {
        // GIVEN
//         FormElement form = new FormElement(Tag.valueOf("form"), "", null);
//         Element select = new Element(Tag.valueOf("select"), "");
//         select.attr("name", "fruits");
// 
//         Element option1 = new Element(Tag.valueOf("option"), "")
//                 .attr("value", "apple")
//                 .attr("selected", "selected");
//         Element option2 = new Element(Tag.valueOf("option"), "")
//                 .attr("value", "banana")
//                 .attr("selected", "selected");
//         Element option3 = new Element(Tag.valueOf("option"), "")
//                 .attr("value", "cherry");
// 
//         select.appendChild(option1);
//         select.appendChild(option2);
//         select.appendChild(option3);
// 
//         form.appendChild(select);
// 
        // Ensure that select elements are linked to the form correctly
//         form.addElement(select);
// 
        // WHEN
//         List<HttpConnection.KeyVal> data = form.formData();
// 
        // THEN
//         assertEquals(2, data.size(), "Expected two selected options");
//         assertTrue(data.stream().anyMatch(kv -> "fruits".equals(kv.key()) && "apple".equals(kv.value())), "Missing key-value pair for apple");
//         assertTrue(data.stream().anyMatch(kv -> "fruits".equals(kv.key()) && "banana".equals(kv.value())), "Missing key-value pair for banana");
//     }

}