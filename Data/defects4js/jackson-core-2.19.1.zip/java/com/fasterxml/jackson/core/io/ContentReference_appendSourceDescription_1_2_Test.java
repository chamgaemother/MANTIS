package com.fasterxml.jackson.core.io;

import com.fasterxml.jackson.core.ErrorReportConfiguration;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ContentReference_appendSourceDescription_1_2_Test {

    @Test
    @DisplayName("When hasTextualContent is false and srcRef is a non-byte[] object, ensures no binary length is appended")
    public void TC21_appendSourceDescription_NoBinaryLength() {
        // Arrange
        ContentReference instance = ContentReference.construct(false, new AnotherCustomObject(), ErrorReportConfiguration.defaults());
        
        // Act
        StringBuilder sb = new StringBuilder();
        instance.appendSourceDescription(sb);
        
        // Assert
        assertEquals("(AnotherCustomObject)", sb.toString());
    }
    
    // Dummy class to represent a non-byte[] custom object
    private static class AnotherCustomObject {
        // You can add fields or methods here if needed for the test
    }
}