import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectReadContext;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.json.UTF8StreamJsonParser;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.BufferRecycler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class UTF8StreamJsonParserTest {
    private UTF8StreamJsonParser parser;

    @BeforeEach
    void setUp() {
        JsonFactory factory = new JsonFactory();
        InputStream input = new ByteArrayInputStream("{\"field\":\"value\"}".getBytes());
        IOContext ioContext = new IOContext(factory._getBufferRecycler(), input, false);
        ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
        parser = new UTF8StreamJsonParser(ioContext, 0, input, null, canonicalizer, new byte[1024], 0, 0, false);
    }

    @Test
    void testNextFieldNameWithValidJson() throws Exception {
        parser.nextToken(); // Skip START_OBJECT
        String field = parser.nextFieldName();
        assertEquals("field", field);
    }

    @Test
    void testNextFieldNameWithEndArray() throws Exception {
        parser._parsingContext.createChildArrayContext(-1, -1);
        parser._inputBuffer = new byte[] {']'};
        parser._inputEnd = 1;
        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_ARRAY, parser.currentToken());
    }

    @Test
    void testNextFieldNameWithEndObject() throws Exception {
        parser.nextToken(); // Skip START_OBJECT
        parser._inputBuffer = new byte[] {'}'};
        parser._inputEnd = 1;
        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.END_OBJECT, parser.currentToken());
    }

    @Test
    void testNextFieldNameWithUnexpectedChar() throws Exception {
        parser.nextToken(); // Skip START_OBJECT
        parser._inputBuffer = new byte[] {','};
        parser._inputEnd = 1;
        assertNull(parser.nextFieldName());
        assertEquals(JsonToken.VALUE_NULL, parser.currentToken());
    }

    @Test
    void testNextFieldNameWithInvalidJson() throws Exception {
        parser._parsingContext.createChildObjectContext(-1, -1);
        parser._inputBuffer = new byte[] {'!', 'f', 'i', 'e', 'l', 'd'};
        parser._inputEnd = 6;
        assertNull(parser.nextFieldName());
    }

    @Test
    void testNextFieldNameWithEOF() throws Exception {
        parser._parsingContext.createChildObjectContext(-1, -1);
        parser._inputBuffer = new byte[] {};
        parser._inputEnd = 0;
        parser._inputPtr = 0;
        assertNull(parser.nextFieldName());
    }
}