package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Stroke;
import java.util.TreeMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PiePlotTest {

    private PiePlot<String> plot;

    @BeforeEach
    void setUp() {
        plot = new PiePlot<>();
    }

    @Test
    void testHashCode_circularTrue() {
        plot.setCircular(true, false);
        int hash1 = plot.hashCode();
        plot.setCircular(false, false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_autoPopulateSectionPaintTrue() {
        plot.setAutoPopulateSectionPaint(true);
        int hash1 = plot.hashCode();
        plot.setAutoPopulateSectionPaint(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_sectionOutlinesVisibleTrue() {
        plot.setSectionOutlinesVisible(true);
        int hash1 = plot.hashCode();
        plot.setSectionOutlinesVisible(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_autoPopulateSectionOutlinePaintTrue() {
        plot.setAutoPopulateSectionOutlinePaint(true);
        int hash1 = plot.hashCode();
        plot.setAutoPopulateSectionOutlinePaint(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_autoPopulateSectionOutlineStrokeTrue() {
        plot.setAutoPopulateSectionOutlineStroke(true);
        int hash1 = plot.hashCode();
        plot.setAutoPopulateSectionOutlineStroke(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_simpleLabelsTrue() {
        plot.setSimpleLabels(true);
        int hash1 = plot.hashCode();
        plot.setSimpleLabels(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_labelLinksVisibleTrue() {
        plot.setLabelLinksVisible(true);
        int hash1 = plot.hashCode();
        plot.setLabelLinksVisible(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_ignoreNullValuesTrue() {
        plot.setIgnoreNullValues(true);
        int hash1 = plot.hashCode();
        plot.setIgnoreNullValues(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_ignoreZeroValuesTrue() {
        plot.setIgnoreZeroValues(true);
        int hash1 = plot.hashCode();
        plot.setIgnoreZeroValues(false);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_nullFields() {
        plot.setDirection(null);
        plot.setSectionPaintMap(null);
        plot.setDefaultSectionPaint(null);
        plot.setSectionOutlinePaintMap(null);
        plot.setDefaultSectionOutlinePaint(null);
        plot.setSectionOutlineStrokeMap(null);
        plot.setDefaultSectionOutlineStroke(null);
        plot.setShadowPaint(null);
        plot.setLabelGenerator(null);
        plot.setLabelFont(null);
        plot.setLabelPaint(null);
        plot.setLabelBackgroundPaint(null);
        plot.setLabelOutlinePaint(null);
        plot.setLabelOutlineStroke(null);
        plot.setLabelShadowPaint(null);
        plot.setLabelPadding(null);
        plot.setSimpleLabelOffset(null);
        plot.setLabelLinkStyle(null);
        plot.setLabelLinkPaint(null);
        plot.setLabelLinkStroke(null);
        plot.setToolTipGenerator(null);
        plot.setURLGenerator(null);
        plot.setLegendLabelGenerator(null);
        plot.setLegendLabelToolTipGenerator(null);
        plot.setLegendLabelURLGenerator(null);
        plot.setLegendItemShape(null);
        plot.setShadowGenerator(null);
        int hash = plot.hashCode();
        assertNotNull(hash);
    }

    @Test
    void testHashCode_nonNullFields() {
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setSectionPaintMap(new PaintMap<>());
        plot.setDefaultSectionPaint(Color.BLUE);
        plot.setSectionOutlinePaintMap(new PaintMap<>());
        plot.setDefaultSectionOutlinePaint(Color.RED);
        plot.setSectionOutlineStrokeMap(new StrokeMap<>());
        plot.setDefaultSectionOutlineStroke(new BasicStroke(1.0f));
        plot.setShadowPaint(Color.GRAY);
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator());
        plot.setLabelFont(new Font("Arial", Font.PLAIN, 12));
        plot.setLabelPaint(Color.BLACK);
        plot.setLabelBackgroundPaint(Color.WHITE);
        plot.setLabelOutlinePaint(Color.BLACK);
        plot.setLabelOutlineStroke(new BasicStroke(0.5f));
        plot.setLabelShadowPaint(Color.LIGHT_GRAY);
        plot.setLabelPadding(new RectangleInsets(2, 2, 2, 2));
        plot.setSimpleLabelOffset(new RectangleInsets(1, 1, 1, 1));
        plot.setLabelLinkStyle(PieLabelLinkStyle.STANDARD);
        plot.setLabelLinkPaint(Color.BLUE);
        plot.setLabelLinkStroke(new BasicStroke(0.5f));
        plot.setToolTipGenerator(new PieToolTipGenerator() {
            @Override
            public String generateToolTip(PieDataset dataset, Comparable key) {
                return "Tooltip";
            }
        });
        plot.setURLGenerator(new PieURLGenerator() {
            @Override
            public String generateURL(PieDataset dataset, Comparable key, int pieIndex) {
                return "http://example.com";
            }
        });
        plot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
        plot.setLegendLabelToolTipGenerator(new StandardPieSectionLabelGenerator());
        plot.setLegendLabelURLGenerator(new PieURLGenerator() {
            @Override
            public String generateURL(PieDataset dataset, Comparable key, int pieIndex) {
                return "http://example.com/legend";
            }
        });
        plot.setLegendItemShape(new Rectangle2D.Double());
        plot.setShadowGenerator(new ShadowGenerator());
        int hash = plot.hashCode();
        assertNotNull(hash);
    }

    @Test
    void testHashCode_sameObjectSameHash() {
        int hash1 = plot.hashCode();
        int hash2 = plot.hashCode();
        assertEquals(hash1, hash2);
    }

    @Test
    void testHashCode_differentObjectsDifferentHash() {
        PiePlot<String> plot2 = new PiePlot<>();
        plot2.setCircular(!plot.isCircular());
        int hash1 = plot.hashCode();
        int hash2 = plot2.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_explodePercentages() {
        plot.setExplodePercent("A", 0.1);
        int hash1 = plot.hashCode();
        plot.setExplodePercent("A", 0.2);
        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }

    @Test
    void testHashCode_multipleFields() {
        plot.setCircular(true, false);
        plot.setAutoPopulateSectionPaint(true);
        plot.setSectionOutlinesVisible(true);
        plot.setAutoPopulateSectionOutlinePaint(true);
        plot.setAutoPopulateSectionOutlineStroke(true);
        plot.setSimpleLabels(true);
        plot.setLabelLinksVisible(true);
        plot.setIgnoreNullValues(true);
        plot.setIgnoreZeroValues(true);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setDefaultSectionPaint(Color.GREEN);
        plot.setDefaultSectionOutlinePaint(Color.BLUE);
        plot.setDefaultSectionOutlineStroke(new BasicStroke(1.0f));
        plot.setShadowPaint(Color.BLACK);
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator());
        plot.setLabelFont(new Font("Serif", Font.BOLD, 14));
        plot.setLabelPaint(Color.MAGENTA);
        plot.setLabelBackgroundPaint(Color.YELLOW);
        plot.setLabelOutlinePaint(Color.DARK_GRAY);
        plot.setLabelOutlineStroke(new BasicStroke(2.0f));
        plot.setLabelShadowPaint(Color.LIGHT_GRAY);
        plot.setLabelPadding(new RectangleInsets(5, 5, 5, 5));
        plot.setSimpleLabelOffset(new RectangleInsets(3, 3, 3, 3));
        plot.setLabelLinkStyle(PieLabelLinkStyle.QUAD_CURVE);
        plot.setLabelLinkPaint(Color.ORANGE);
        plot.setLabelLinkStroke(new BasicStroke(1.5f));
        plot.setToolTipGenerator(new PieToolTipGenerator() {
            @Override
            public String generateToolTip(PieDataset dataset, Comparable key) {
                return "Tooltip";
            }
        });
        plot.setURLGenerator(new PieURLGenerator() {
            @Override
            public String generateURL(PieDataset dataset, Comparable key, int pieIndex) {
                return "http://example.com";
            }
        });
        plot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
        plot.setLegendLabelToolTipGenerator(new StandardPieSectionLabelGenerator());
        plot.setLegendLabelURLGenerator(new PieURLGenerator() {
            @Override
            public String generateURL(PieDataset dataset, Comparable key, int pieIndex) {
                return "http://example.com/legend";
            }
        });
        plot.setLegendItemShape(new Ellipse2D.Double());
        plot.setShadowGenerator(new ShadowGenerator());

        int hash1 = plot.hashCode();
        plot.setCircular(false, false);
        plot.setAutoPopulateSectionPaint(false);
        plot.setSectionOutlinesVisible(false);
        plot.setAutoPopulateSectionOutlinePaint(false);
        plot.setAutoPopulateSectionOutlineStroke(false);
        plot.setSimpleLabels(false);
        plot.setLabelLinksVisible(false);
        plot.setIgnoreNullValues(false);
        plot.setIgnoreZeroValues(false);
        plot.setDirection(Rotation.ANTICLOCKWISE);
        plot.setDefaultSectionPaint(Color.RED);
        plot.setDefaultSectionOutlinePaint(Color.PINK);
        plot.setDefaultSectionOutlineStroke(new BasicStroke(0.5f));
        plot.setShadowPaint(Color.WHITE);
        plot.setLabelGenerator(null);
        plot.setLabelFont(null);
        plot.setLabelPaint(null);
        plot.setLabelBackgroundPaint(null);
        plot.setLabelOutlinePaint(null);
        plot.setLabelOutlineStroke(null);
        plot.setLabelShadowPaint(null);
        plot.setLabelPadding(null);
        plot.setSimpleLabelOffset(null);
        plot.setLabelLinkStyle(PieLabelLinkStyle.CUBIC_CURVE);
        plot.setLabelLinkPaint(null);
        plot.setLabelLinkStroke(null);
        plot.setToolTipGenerator(null);
        plot.setURLGenerator(null);
        plot.setLegendLabelGenerator(null);
        plot.setLegendLabelToolTipGenerator(null);
        plot.setLegendLabelURLGenerator(null);
        plot.setLegendItemShape(null);
        plot.setShadowGenerator(null);

        int hash2 = plot.hashCode();
        assertNotEquals(hash1, hash2);
    }
}