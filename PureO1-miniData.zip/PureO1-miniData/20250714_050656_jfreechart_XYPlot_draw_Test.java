package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class XYPlotTest {

    private XYPlot plot;
    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotState parentState;
    private PlotRenderingInfo info;

    @BeforeEach
    void setUp() {
        plot = new XYPlot();
        g2 = mock(Graphics2D.class);
        area = mock(Rectangle2D.class);
        anchor = mock(Point2D.class);
        parentState = mock(PlotState.class);
        info = mock(PlotRenderingInfo.class);
    }

    @Test
    void testDrawWithAreaTooSmallWidth() {
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW - 1);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2, area, anchor, parentState, info);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawWithAreaTooSmallHeight() {
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW - 1);
        plot.draw(g2, area, anchor, parentState, info);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawWithAreaTooSmallBoth() {
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW - 1);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW - 1);
        plot.draw(g2, area, anchor, parentState, info);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawWithNullInfo() {
        plot.setBackgroundPaint(Color.WHITE);
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2, area, anchor, parentState, null);
        verify(info, never()).setPlotArea(any());
    }

    @Test
    void testDrawWithNonNullInfo() {
        plot.setBackgroundPaint(Color.WHITE);
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2, area, anchor, parentState, info);
        verify(info).setPlotArea(area);
    }

    @Test
    void testDrawWithNullAnchor() {
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2, area, null, parentState, info);
        // Further verifications can be done based on mocked renderer etc.
    }

    @Test
    void testDrawWithNonNullAnchorInsideDataArea() {
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        when(area.contains(anyDouble(), anyDouble())).thenReturn(true);
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        when(domainAxis.java2DToValue(anyDouble(), any(), any())).thenReturn(10.0);
        when(rangeAxis.java2DToValue(anyDouble(), any(), any())).thenReturn(20.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(domainAxis).java2DToValue(anyDouble(), any(), any());
        verify(rangeAxis).java2DToValue(anyDouble(), any(), any());
    }

    @Test
    void testDrawWithNonNullAnchorOutsideDataArea() {
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        when(area.contains(anyDouble(), anyDouble())).thenReturn(false);
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2, area, anchor, parentState, info);
        verify(anchor, never()).getX();
        verify(anchor, never()).getY();
    }

    @Test
    void testDrawWithNoDataset() {
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2, area, anchor, parentState, info);
        // Since no dataset, renderer should not be called
        verify(g2, times(1)).clip(any());
    }

    @Test
    void testDrawWithDatasetButNoRenderer() {
        XYDataset dataset = mock(XYDataset.class);
        plot.setDataset(dataset);
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        when(area.getWidth()).thenReturn(XYPlot.MINIMUM_WIDTH_TO_DRAW + 10);
        when(area.getHeight()).thenReturn(XYPlot.MINIMUM_HEIGHT_TO_DRAW + 10);
        plot.draw(g2, area, anchor, parentState, info);
        // Renderer is null, so no items should be drawn
        verify(g2, times(1)).clip(any());
    }

    @Test
    void testDrawWithDatasetAndRenderer() {
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).initialise(g2, area, plot, dataset, info);
    }

    @Test
    void testDrawWithDomainGridlinesVisible() {
        plot.setDomainGridlinesVisible(true);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        when(domainAxis.getRange()).thenReturn(new Range(0, 100));
        when(domainAxis.valueToJava2D(anyDouble(), any(), any()))
            .thenReturn(50.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, atLeastOnce()).drawDomainLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithDomainGridlinesInvisible() {
        plot.setDomainGridlinesVisible(false);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis domainAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, never()).drawDomainLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithRangeGridlinesVisible() {
        plot.setRangeGridlinesVisible(true);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setRangeAxis(rangeAxis);
        when(rangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any()))
            .thenReturn(50.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, atLeastOnce()).drawRangeLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithRangeGridlinesInvisible() {
        plot.setRangeGridlinesVisible(false);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setRangeAxis(rangeAxis);
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, never()).drawRangeLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithDomainMinorGridlinesVisible() {
        plot.setDomainMinorGridlinesVisible(true);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis domainAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        when(domainAxis.getRange()).thenReturn(new Range(0, 100));
        when(domainAxis.valueToJava2D(anyDouble(), any(), any()))
            .thenReturn(50.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, atLeastOnce()).drawDomainLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithDomainMinorGridlinesInvisible() {
        plot.setDomainMinorGridlinesVisible(false);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis domainAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, never()).drawDomainLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithRangeMinorGridlinesVisible() {
        plot.setRangeMinorGridlinesVisible(true);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setRangeAxis(rangeAxis);
        when(rangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any()))
            .thenReturn(50.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, atLeastOnce()).drawRangeLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithRangeMinorGridlinesInvisible() {
        plot.setRangeMinorGridlinesVisible(false);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setRangeAxis(rangeAxis);
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, never()).drawRangeLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithCrosshairsVisible() {
        plot.setDomainCrosshairVisible(true);
        plot.setRangeCrosshairVisible(true);
        plot.setDomainCrosshairValue(50.0);
        plot.setRangeCrosshairValue(50.0);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        when(domainAxis.getRange()).thenReturn(new Range(0, 100));
        when(domainAxis.valueToJava2D(50.0, area, RectangleEdge.BOTTOM))
            .thenReturn(100.0);
        when(rangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(rangeAxis.valueToJava2D(50.0, area, RectangleEdge.LEFT))
            .thenReturn(100.0);
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawDomainLine(any(), any(), any(), any(), eq(50.0), any(), any());
        verify(renderer).drawRangeLine(any(), any(), any(), any(), eq(50.0), any(), any());
    }

    @Test
    void testDrawWithCrosshairsInvisible() {
        plot.setDomainCrosshairVisible(false);
        plot.setRangeCrosshairVisible(false);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer, never()).drawDomainLine(any(), any(), any(), any(), anyDouble(), any(), any());
        verify(renderer, never()).drawRangeLine(any(), any(), any(), any(), anyDouble(), any(), any());
    }

    @Test
    void testDrawWithLockedDomainCrosshair() {
        plot.setDomainCrosshairVisible(true);
        plot.setDomainCrosshairLockedOnData(true);
        plot.setDomainCrosshairValue(50.0);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        ValueAxis domainAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        when(domainAxis.getRange()).thenReturn(new Range(0, 100));
        when(domainAxis.valueToJava2D(50.0, area, RectangleEdge.BOTTOM))
            .thenReturn(100.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawDomainLine(any(), any(), any(), any(), eq(50.0), any(), any());
    }

    @Test
    void testDrawWithUnlockedDomainCrosshair() {
        plot.setDomainCrosshairVisible(true);
        plot.setDomainCrosshairLockedOnData(false);
        plot.setDomainCrosshairValue(50.0);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        ValueAxis domainAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        when(domainAxis.getRange()).thenReturn(new Range(0, 100));
        when(domainAxis.java2DToValue(anyDouble(), any(), any()))
            .thenReturn(60.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawDomainLine(any(), any(), any(), any(), eq(60.0), any(), any());
    }

    @Test
    void testDrawWithLockedRangeCrosshair() {
        plot.setRangeCrosshairVisible(true);
        plot.setRangeCrosshairLockedOnData(true);
        plot.setRangeCrosshairValue(50.0);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setRangeAxis(rangeAxis);
        when(rangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(rangeAxis.valueToJava2D(50.0, area, RectangleEdge.LEFT))
            .thenReturn(100.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawRangeLine(any(), any(), any(), any(), eq(50.0), any(), any());
    }

    @Test
    void testDrawWithUnlockedRangeCrosshair() {
        plot.setRangeCrosshairVisible(true);
        plot.setRangeCrosshairLockedOnData(false);
        plot.setRangeCrosshairValue(50.0);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setRangeAxis(rangeAxis);
        when(rangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(rangeAxis.java2DToValue(anyDouble(), any(), any()))
            .thenReturn(60.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawRangeLine(any(), any(), any(), any(), eq(60.0), any(), any());
    }

    @Test
    void testDrawWithAnnotations() {
        plot.setBackgroundPaint(Color.WHITE);
        XYAnnotation annotation = mock(XYAnnotation.class);
        plot.addAnnotation(annotation);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        plot.draw(g2, area, anchor, parentState, info);
        verify(annotation).draw(any(), eq(plot), eq(area), eq(domainAxis), eq(rangeAxis), eq(0), eq(info));
    }

    @Test
    void testDrawWithShadowGenerator() {
        ShadowGenerator shadow = mock(ShadowGenerator.class);
        BufferedImage shadowImage = mock(BufferedImage.class);
        when(shadow.createDropShadow(any())).thenReturn(shadowImage);
        plot.setShadowGenerator(shadow);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(shadow).createDropShadow(any());
        verify(g2).drawImage(shadowImage, anyInt(), anyInt(), any());
        verify(g2).drawImage(any(), anyInt(), anyInt(), any());
    }

    @Test
    void testDrawWithZeroBaselineVisible() {
        plot.setDomainZeroBaselineVisible(true);
        plot.setRangeZeroBaselineVisible(true);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        when(domainAxis.getRange()).thenReturn(new Range(-100, 100));
        when(domainAxis.valueToJava2D(0.0, area, RectangleEdge.BOTTOM))
            .thenReturn(100.0);
        when(rangeAxis.getRange()).thenReturn(new Range(-100, 100));
        when(rangeAxis.valueToJava2D(0.0, area, RectangleEdge.LEFT))
            .thenReturn(100.0);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawDomainLine(any(), any(), any(), any(), eq(0.0), any(), any());
        verify(renderer).drawRangeLine(any(), any(), any(), any(), eq(0.0), any(), any());
    }

    @Test
    void testDrawWithNoData() {
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDataset(null);
        plot.setRenderer(null);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        plot.draw(g2, area, anchor, parentState, info);
        // Assuming drawNoDataMessage is implemented, we would verify it was called
        // Since it's a protected method, we might need to spy the plot
        XYPlot spyPlot = spy(plot);
        spyPlot.draw(g2, area, anchor, parentState, info);
        verify(spyPlot).drawNoDataMessage(g2, area);
    }

    @Test
    void testDrawWithForegroundMarkers() {
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        Marker marker = mock(Marker.class);
        plot.addDomainMarker(marker, Layer.FOREGROUND);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis domainAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawDomainMarker(any(), eq(plot), eq(domainAxis), eq(marker), eq(area));
    }

    @Test
    void testDrawWithBackgroundMarkers() {
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        Marker marker = mock(Marker.class);
        plot.addDomainMarker(marker, Layer.BACKGROUND);
        when(area.getWidth()).thenReturn(200.0);
        when(area.getHeight()).thenReturn(200.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis domainAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).drawDomainMarker(any(), eq(plot), eq(domainAxis), eq(marker), eq(area));
    }

    @Test
    void testDrawWithFixedDomainAxisSpace() {
        AxisSpace fixedSpace = new AxisSpace();
        plot.setFixedDomainAxisSpace(fixedSpace);
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        when(area.getWidth()).thenReturn(300.0);
        when(area.getHeight()).thenReturn(300.0);
        when(info.getDataArea()).thenReturn(area);
        plot.draw(g2, area, anchor, parentState, info);
        verify(domainAxis, never()).configure();
    }

    @Test
    void testDrawWithFixedRangeAxisSpace() {
        AxisSpace fixedSpace = new AxisSpace();
        plot.setFixedRangeAxisSpace(fixedSpace);
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        when(area.getWidth()).thenReturn(300.0);
        when(area.getHeight()).thenReturn(300.0);
        when(info.getDataArea()).thenReturn(area);
        plot.draw(g2, area, anchor, parentState, info);
        verify(rangeAxis, never()).configure();
    }

    @Test
    void testDrawWithRendererChange() {
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(dataset);
        plot.setRenderer(renderer);
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
        when(area.getWidth()).thenReturn(300.0);
        when(area.getHeight()).thenReturn(300.0);
        when(info.getDataArea()).thenReturn(area);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        when(renderer.initialise(g2, area, plot, dataset, info))
            .thenReturn(mock(RendererUtils.class));
        plot.draw(g2, area, anchor, parentState, info);
        verify(renderer).initialize(g2, plot, dataset, info);
    }

    @Test
    void testDrawWithSeriesRenderingOrderReverse() {
        plot.setSeriesRenderingOrder(SeriesRenderingOrder.REVERSE);
        plot.setBackgroundPaint(Color.WHITE);
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        plot.setDataset(0, dataset);
        plot.setRenderer(0, renderer);
        when(dataset.getSeriesCount()).thenReturn(2);
        when(renderer.getPassCount()).thenReturn(1);
        when(renderer.isSeriesVisible(0)).thenReturn(true);
        when(renderer.isSeriesVisibleInLegend(0)).thenReturn(true);
        when(renderer.getLegendItem(0, 0)).thenReturn(mock(LegendItem.class));
        when(renderer.isSeriesVisible(1)).thenReturn(true);
        when(renderer.isSeriesVisibleInLegend(1)).thenReturn(true);
        when(renderer.getLegendItem(0, 1)).thenReturn(mock(LegendItem.class));
        when(area.getWidth()).thenReturn(300.0);
        when(area.getHeight()).thenReturn(300.0);
        when(info.getDataArea()).thenReturn(area);
        plot.draw(g2, area, anchor, parentState, info);
        // Further verifications can be added based on renderer behavior
    }

}