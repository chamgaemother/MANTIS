package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Flat3Map_containsKey_0_2_Test {

    @Test
    @DisplayName("When delegateMap is null, key is null, size=2, key2 is null")
    public void TC06_containsKey_delegateMap_null_key_null_size2_key2_null() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);

        // Set key2 to null
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        // Key is null
        Object key = null;

        // When
        boolean result = map.containsKey(key);

        // Then
        assertEquals(false, result);
    }

    @Test
    @DisplayName("When delegateMap is null, key is null, size=1, key1 is null")
    public void TC07_containsKey_delegateMap_null_key_null_size1_key1_null() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 1);

        // Set key1 to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // Key is null
        Object key = null;

        // When
        boolean result = map.containsKey(key);

        // Then
        assertEquals(false, result);
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size>0, hash3 matches and key equals key3")
    public void TC08_containsKey_delegateMap_null_key_not_null_size_gt0_hash3_match_key_equals_key3() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set key1 to someKey1
        Object someKey1 = new Object();
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, someKey1);

        // Set key2 to someKey2
        Object someKey2 = new Object();
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, someKey2);

        // Set key3 to targetKey
        Object targetKey = new Object();
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, targetKey);

        // Set hash1 to targetKey.hashCode()
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, targetKey.hashCode());

        // Set hash2 to someOtherHash
        int someOtherHash = 12345;
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, someOtherHash);

        // Set hash3 to targetKey.hashCode()
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, targetKey.hashCode());

        // Key is targetKey
        Object key = targetKey;

        // When
        boolean result = map.containsKey(key);

        // Then
        assertEquals(true, result);
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size>0, hash3 does not match but hash2 matches and key equals key2")
    public void TC09_containsKey_delegateMap_null_key_not_null_size_gt0_hash3_mismatch_hash2_match_key_equals_key2() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set key1 to someKey1
        Object someKey1 = new Object();
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, someKey1);

        // Set key2 to targetKey
        Object targetKey = new Object();
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, targetKey);

        // Set key3 to someKey3
        Object someKey3 = new Object();
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, someKey3);

        // Set hash1 to someHash1
        int someHash1 = 11111;
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, someHash1);

        // Set hash2 to targetKey.hashCode()
        int targetHash = targetKey.hashCode();
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, targetHash);

        // Set hash3 to someHash3
        int someHash3 = 22222;
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, someHash3);

        // Key is targetKey
        Object key = targetKey;

        // When
        boolean result = map.containsKey(key);

        // Then
        assertEquals(true, result);
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size>0, hash3 and hash2 do not match, but hash1 matches and key equals key1")
    public void TC10_containsKey_delegateMap_null_key_not_null_size_gt0_hash3_hash2_mismatch_hash1_match_key_equals_key1() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set key1 to targetKey
        Object targetKey = new Object();
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, targetKey);

        // Set key2 to someKey2
        Object someKey2 = new Object();
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, someKey2);

        // Set key3 to someKey3
        Object someKey3 = new Object();
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, someKey3);

        // Set hash1 to targetKey.hashCode()
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, targetKey.hashCode());

        // Set hash2 to someHash2
        int someHash2 = 33333;
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, someHash2);

        // Set hash3 to someHash3
        int someHash3 = 44444;
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, someHash3);

        // Key is targetKey
        Object key = targetKey;

        // When
        boolean result = map.containsKey(key);

        // Then
        assertEquals(true, result);
    }
}