package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.parser.ParseException;

public class XPathParser_AxisName_2_4_Test {

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_FOLLOWING but token.kind=AXIS_PRECEDING")
    void TC32() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_FOLLOWING;
        parser.jj_nt = jj_nt;
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_PRECEDING;
        parser.token = token;

        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_DESCENDANT but token.kind=AXIS_CHILD")
    void TC33() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_DESCENDANT;
        parser.jj_nt = jj_nt;
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_CHILD;
        parser.token = token;

        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_DESCENDANT and token.kind=AXIS_SELF")
    void TC34() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_DESCENDANT;
        parser.jj_nt = jj_nt;
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_SELF;
        parser.token = token;

        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_ANCESTOR_OR_SELF but token.kind=AXIS_CHILD")
    void TC35() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_ANCESTOR_OR_SELF;
        parser.jj_nt = jj_nt;
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_CHILD;
        parser.token = token;

        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_ANCESTOR_OR_SELF but token.kind=AXIS_PRECEDING")
    void TC36() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));
        Token jj_nt = new Token();
        jj_nt.kind = XPathParserConstants.AXIS_ANCESTOR_OR_SELF;
        parser.jj_nt = jj_nt;
        Token token = new Token();
        token.kind = XPathParserConstants.AXIS_PRECEDING;
        parser.token = token;

        assertThrows(ParseException.class, () -> parser.AxisName());
    }
}