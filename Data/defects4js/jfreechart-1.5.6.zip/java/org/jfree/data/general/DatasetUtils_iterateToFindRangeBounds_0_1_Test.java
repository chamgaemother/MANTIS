package org.jfree.data.general;

import java.util.Arrays;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import static org.mockito.Mockito.*;

public class DatasetUtils_iterateToFindRangeBounds_0_1_Test {

    @Test
    @DisplayName("Throws exception when dataset is null")
    void TC01_iterateToFindRangeBounds_nullDataset() {
        // GIVEN
        CategoryDataset dataset = null;
        List<String> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = true;

        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);
        });
    }

    @Test
    @DisplayName("Throws exception when visibleSeriesKeys is null")
    void TC02_iterateToFindRangeBounds_nullVisibleSeriesKeys() {
        // GIVEN
        CategoryDataset dataset = mock(CategoryDataset.class);
        List<String> visibleSeriesKeys = null;
        boolean includeInterval = true;

        // WHEN & THEN
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);
        });
    }

    @Test
    @DisplayName("Returns null when includeInterval is false and dataset has no data")
    void TC03_iterateToFindRangeBounds_noDataNoInterval() {
        // GIVEN
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(0);
        List<String> visibleSeriesKeys = Arrays.asList();
        boolean includeInterval = false;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertNull(result);
    }

    @Test
    @DisplayName("Returns correct Range with includeInterval=false and dataset has data")
    void TC04_iterateToFindRangeBounds_standardDatasetWithData() {
        // GIVEN
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getRowIndex("Series1")).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        when(dataset.getValue(0, 1)).thenReturn(-3.0);
        List<String> visibleSeriesKeys = Arrays.asList("Series1");
        boolean includeInterval = false;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertEquals(new Range(-3.0, 5.0), result);
    }

    @Test
    @DisplayName("Handles BoxAndWhiskerCategoryDataset with multiple series and items")
    void TC05_iterateToFindRangeBounds_BoxAndWhiskerDataset_multipleSeries() {
        // GIVEN
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getRowIndex("Series1")).thenReturn(0);
        when(dataset.getRowIndex("Series2")).thenReturn(1);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(2.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(10.0);
        when(dataset.getMinRegularValue(1, 1)).thenReturn(5.0);
        when(dataset.getMaxRegularValue(1, 1)).thenReturn(15.0);
        List<String> visibleSeriesKeys = Arrays.asList("Series1", "Series2");
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindRangeBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        Assertions.assertEquals(new Range(2.0, 15.0), result);
    }
}
