import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class Flat3MapTest {

    @Test
    void containsKey_DelegateMapNotNull_KeyPresent() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        map.put("four", 4); // Triggers delegateMap
        assertTrue(map.containsKey("two"));
    }

    @Test
    void containsKey_DelegateMapNotNull_KeyAbsent() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        map.put("four", 4); // Triggers delegateMap
        assertFalse(map.containsKey("five"));
    }

    @Test
    void containsKey_DelegateMapNotNull_NullKey() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        map.put(null, 0); // Triggers delegateMap
        assertTrue(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeZero() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        assertFalse(map.containsKey("one"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeOne_KeyPresent_NonNull() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        assertTrue(map.containsKey("one"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeOne_KeyAbsent() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        assertFalse(map.containsKey("two"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeOne_NullKeyPresent() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put(null, 1);
        assertTrue(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeOne_NullKeyAbsent() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        assertFalse(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeTwo_FirstKeyPresent_NonNull() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        assertTrue(map.containsKey("one"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeTwo_SecondKeyPresent_NonNull() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        assertTrue(map.containsKey("two"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeTwo_KeyAbsent() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        assertFalse(map.containsKey("three"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeTwo_FirstKeyNull_Present() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put(null, 0);
        map.put("two", 2);
        assertTrue(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeTwo_SecondKeyNull_Present() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put(null, 0);
        assertTrue(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeTwo_NoNullKeys() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        assertFalse(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeThree_AllKeysPresent_NonNull() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        assertTrue(map.containsKey("one"));
        assertTrue(map.containsKey("two"));
        assertTrue(map.containsKey("three"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeThree_SomeKeysPresent_NonNull() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        assertFalse(map.containsKey("four"));
    }

    @Test
    void containsKey_DelegateMapNull_SizeThree_WithNullKey_Present() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put(null, 0);
        map.put("three", 3);
        assertTrue(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeThree_WithNullKey_Absent() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        assertFalse(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_SizeThree_KeyWithSameHashAndEqual() {
        Flat3Map<KeyWithHash, Integer> map = new Flat3Map<>();
        KeyWithHash key1 = new KeyWithHash("key", 123);
        KeyWithHash key2 = new KeyWithHash("key", 123);
        map.put(key1, 1);
        map.put("two", 2);
        map.put("three", 3);
        assertTrue(map.containsKey(key2));
    }

    @Test
    void containsKey_DelegateMapNull_SizeThree_KeyWithSameHash_NotEqual() {
        Flat3Map<KeyWithHash, Integer> map = new Flat3Map<>();
        KeyWithHash key1 = new KeyWithHash("key", 123);
        KeyWithHash key2 = new KeyWithHash("key", 456);
        map.put(key1, 1);
        map.put("two", 2);
        map.put("three", 3);
        assertFalse(map.containsKey(key2));
    }

    @Test
    void containsKey_DelegateMapNull_SizeThree_KeyWithDifferentHash() {
        Flat3Map<KeyWithHash, Integer> map = new Flat3Map<>();
        KeyWithHash key1 = new KeyWithHash("key1", 123);
        KeyWithHash key2 = new KeyWithHash("key2", 456);
        map.put(key1, 1);
        map.put(key2, 2);
        map.put("three", 3);
        KeyWithHash key3 = new KeyWithHash("key3", 789);
        assertFalse(map.containsKey(key3));
    }

    @Test
    void containsKey_DelegateMapNull_KeyIsNull_SizeThree_WithNullKey() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put(null, 0);
        map.put("two", 2);
        map.put("three", 3);
        assertTrue(map.containsKey(null));
    }

    @Test
    void containsKey_DelegateMapNull_KeyIsNull_SizeThree_NoNullKey() {
        Flat3Map<String, Integer> map = new Flat3Map<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        assertFalse(map.containsKey(null));
    }

    // Helper class for testing hash and equals
    private static class KeyWithHash {
        private final String name;
        private final int hash;

        public KeyWithHash(String name, int hash) {
            this.name = name;
            this.hash = hash;
        }

        @Override
        public int hashCode() {
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof KeyWithHash)) {
                return false;
            }
            KeyWithHash other = (KeyWithHash) obj;
            return this.name.equals(other.name) && this.hash == other.hash;
        }
    }
}