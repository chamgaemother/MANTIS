package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.plot.CrosshairState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_0_2_Test {

    @Test
    @DisplayName("TC06: drawVerticalItem with exactBoxWidth <= 0 leading to width < 3")
    void TC06_drawVerticalItem_exactBoxWidth_leq_0_width_less_than_3() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(series, item)).thenReturn(10);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(5);
        when(boxDataset.getMedianValue(series, item)).thenReturn(12.5);
        when(boxDataset.getMeanValue(series, item)).thenReturn(13.0);
        when(boxDataset.getQ1Value(series, item)).thenReturn(10.0);
        when(boxDataset.getQ3Value(series, item)).thenReturn(15.0);
        when(boxDataset.getOutliers(series, item)).thenReturn(null);

        // Mock domainAxis and rangeAxis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        // Mock getBoxWidth to return <=0
        Mockito.doReturn(-1.0).when(renderer).getBoxWidth();

        // Mock getItemCount to cause width < 3
        when(boxDataset.getItemCount(series)).thenReturn(100);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<java.awt.Stroke> strokeCaptor = ArgumentCaptor.forClass(java.awt.Stroke.class);
        verify(g2).setStroke(strokeCaptor.capture());
        // Further assertions can be added based on how 'width' affects drawing
        // For example, verify that width was set to 3 by checking drawing coordinates
    }

    @Test
    @DisplayName("TC07: drawVerticalItem with exactBoxWidth <= 0 leading to width > maxBoxWidth")
    void TC07_drawVerticalItem_exactBoxWidth_leq_0_width_greater_than_maxBoxWidth() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(series, item)).thenReturn(10);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(5);
        when(boxDataset.getMedianValue(series, item)).thenReturn(12.5);
        when(boxDataset.getMeanValue(series, item)).thenReturn(13.0);
        when(boxDataset.getQ1Value(series, item)).thenReturn(10.0);
        when(boxDataset.getQ3Value(series, item)).thenReturn(15.0);
        when(boxDataset.getOutliers(series, item)).thenReturn(null);

        // Mock domainAxis and rangeAxis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        // Mock getBoxWidth to return <=0
        Mockito.doReturn(-1.0).when(renderer).getBoxWidth();

        // Mock getItemCount to cause width > maxBoxWidth
        when(boxDataset.getItemCount(series)).thenReturn(1);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<java.awt.Stroke> strokeCaptor = ArgumentCaptor.forClass(java.awt.Stroke.class);
        verify(g2).setStroke(strokeCaptor.capture());
        // Further assertions can be added based on how 'width' affects drawing
    }

    @Test
    @DisplayName("TC08: drawVerticalItem with exactBoxWidth <= 0 leading to width between 3 and maxBoxWidth")
    void TC08_drawVerticalItem_exactBoxWidth_leq_0_width_between_3_and_maxBoxWidth() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(series, item)).thenReturn(10);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(5);
        when(boxDataset.getMedianValue(series, item)).thenReturn(12.5);
        when(boxDataset.getMeanValue(series, item)).thenReturn(13.0);
        when(boxDataset.getQ1Value(series, item)).thenReturn(10.0);
        when(boxDataset.getQ3Value(series, item)).thenReturn(15.0);
        when(boxDataset.getOutliers(series, item)).thenReturn(null);

        // Mock domainAxis and rangeAxis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        // Mock getBoxWidth to return <=0
        Mockito.doReturn(-1.0).when(renderer).getBoxWidth();

        // Mock getItemCount to cause width between 3 and maxBoxWidth
        when(boxDataset.getItemCount(series)).thenReturn(10);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<java.awt.Stroke> strokeCaptor = ArgumentCaptor.forClass(java.awt.Stroke.class);
        verify(g2).setStroke(strokeCaptor.capture());
        // Further assertions can be added based on how 'width' affects drawing
    }

    @Test
    @DisplayName("TC09: drawVerticalItem with fillBox enabled (fillBox == true)")
    void TC09_drawVerticalItem_fillBox_enabled() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(true);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(series, item)).thenReturn(10);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(5);
        when(boxDataset.getMedianValue(series, item)).thenReturn(12.5);
        when(boxDataset.getMeanValue(series, item)).thenReturn(13.0);
        when(boxDataset.getQ1Value(series, item)).thenReturn(10.0);
        when(boxDataset.getQ3Value(series, item)).thenReturn(15.0);
        when(boxDataset.getOutliers(series, item)).thenReturn(null);

        // Mock domainAxis and rangeAxis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, times(2)).setPaint(any()); // Once for box fill and once for outline
        verify(g2).fill(any());
        verify(g2).draw(any());
    }

    @Test
    @DisplayName("TC10: drawVerticalItem with fillBox disabled (fillBox == false)")
    void TC10_drawVerticalItem_fillBox_disabled() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.setFillBox(false);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset instanceof BoxAndWhiskerXYDataset).thenReturn(true);
        BoxAndWhiskerXYDataset boxDataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset).thenReturn(boxDataset);
        when(boxDataset.getX(series, item)).thenReturn(10);
        when(boxDataset.getMaxRegularValue(series, item)).thenReturn(20);
        when(boxDataset.getMinRegularValue(series, item)).thenReturn(5);
        when(boxDataset.getMedianValue(series, item)).thenReturn(12.5);
        when(boxDataset.getMeanValue(series, item)).thenReturn(13.0);
        when(boxDataset.getQ1Value(series, item)).thenReturn(10.0);
        when(boxDataset.getQ3Value(series, item)).thenReturn(15.0);
        when(boxDataset.getOutliers(series, item)).thenReturn(null);

        // Mock domainAxis and rangeAxis behavior
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, never()).fill(any());
        verify(g2, atLeastOnce()).draw(any());
    }
}