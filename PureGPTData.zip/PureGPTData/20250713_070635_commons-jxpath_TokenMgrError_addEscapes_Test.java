import org.apache.commons.jxpath.ri.parser.TokenMgrError;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TokenMgrErrorTest {

    @Test
    @DisplayName("Test null input")
    void testNullInput() {
        assertEquals("", TokenMgrError.addEscapes(null));
    }

    @Test
    @DisplayName("Test empty string")
    void testEmptyString() {
        assertEquals("", TokenMgrError.addEscapes(""));
    }

    @ParameterizedTest(name = "{index} => input={0}, expected={1}")
    @CsvSource({
        // Single characters
        "'\\b', '\\\\b'",
        "'\\t', '\\\\t'",
        "'\\n', '\\\\n'",
        "'\\f', '\\\\f'",
        "'\\r', '\\\\r'",
        "'\"', '\\\\\"'",
        "'\\'', '\\\\\''",
        "'\\\\', '\\\\\\\\'",
        // Unprintable characters
        "'\\u0000', ''",  // Null char
        "'\\u0019', '\\\\u0019'", 
        "'\\u007f', '\\\\u007f'",
        // Printable characters
        "'A', 'A'",
        "'z', 'z'",
        // Integer range tests
        "'\\u0000ABC', 'ABC'",
        "'\\u0019AB\\u007fC', '\\\\u0019AB\\\\u007fC'",
        "'Normal Text', 'Normal Text'"
    })
    @DisplayName("Test single character escapes and normal ranges")
    void testAddEscapes(String input, String expected) {
        assertEquals(expected, TokenMgrError.addEscapes(input));
    }
}