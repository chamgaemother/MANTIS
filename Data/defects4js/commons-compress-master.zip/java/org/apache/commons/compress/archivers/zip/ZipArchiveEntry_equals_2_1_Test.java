package org.apache.commons.compress.archivers.zip;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.nio.file.attribute.FileTime;
import static org.junit.jupiter.api.Assertions.*;

public class ZipArchiveEntry_equals_2_1_Test {

    @Test
    @DisplayName("equals() returns false when one ZipArchiveEntry has a null name and the other has a non-null name")
    public void TC31_equalsWithOneNullName() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry((String) null);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result, "equals() should return false when one name is null and the other is not");
    }

    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntry names are null")
    public void TC32_equalsWithBothNullNames() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry((String) null);
        ZipArchiveEntry entry2 = new ZipArchiveEntry((String) null);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertTrue(result, "equals() should return true when both names are null");
    }

    @Test
    @DisplayName("equals() returns false when one ZipArchiveEntry has a null comment and the other has a non-null comment")
    public void TC33_equalsWithOneNullComment() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setComment(null);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setComment("Non-null comment");

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result, "equals() should return false when one comment is null and the other is not");
    }

    @Test
    @DisplayName("equals() returns true when both ZipArchiveEntry comments are null")
    public void TC34_equalsWithBothNullComments() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setComment(null);
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setComment(null);

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertTrue(result, "equals() should return true when both comments are null");
    }

    @Test
    @DisplayName("equals() returns false when one ZipArchiveEntry has a null lastModifiedTime and the other has a non-null lastModifiedTime")
    public void TC35_equalsWithOneNullLastModifiedTime() {
        // GIVEN
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        entry1.setLastModifiedTime(null); // This requires setLastModifiedTime to handle null values
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");
        entry2.setLastModifiedTime(FileTime.fromMillis(System.currentTimeMillis()));

        // WHEN
        boolean result = entry1.equals(entry2);

        // THEN
        assertFalse(result, "equals() should return false when one lastModifiedTime is null and the other is not");
    }
}