package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.chart.axis.CyclicNumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * JUnit 5 test class for CyclicXYItemRenderer.drawItem method covering all provided scenarios.
 */
@ExtendWith(MockitoExtension.class)
public class CyclicXYItemRenderer_drawItem_0_1_Test {

    @InjectMocks
    private CyclicXYItemRenderer renderer = spy(new CyclicXYItemRenderer());

    @Mock
    private Graphics2D g2;

    @Mock
    private XYItemRendererState state;

    @Mock
    private Rectangle2D dataArea;

    @Mock
    private PlotRenderingInfo info;

    @Mock
    private XYPlot plot;

    @Mock
    private ValueAxis domainAxis;

    @Mock
    private ValueAxis rangeAxis;

    @Mock
    private XYDataset dataset;

    @Mock
    private CrosshairState crosshairState;

    /**
     * TC01: getPlotLines() returns false, delegates to super.drawItem and returns.
     */
    @Test
    @DisplayName("getPlotLines() returns false, delegates to super.drawItem and returns")
    void TC01_drawItem_without_plot_lines() throws Exception {
        // Given
        doReturn(false).when(renderer).getPlotLines(); // fixed
        int series = 0;
        int item = 0;
        int pass = 0;

        // When
        callDrawItem(series, item, pass);

        // Then
        verifyCallToSuperDrawItem(series, item, pass);
    }

    /**
     * TC02: getPlotLines() returns true, domainAxis and rangeAxis are not CyclicNumberAxis, item > 0.
     */
    @Test
    @DisplayName("getPlotLines() returns true, domainAxis not CyclicNumberAxis, rangeAxis not CyclicNumberAxis, item > 0")
    void TC02_drawItem_with_plot_lines_non_cyclic_axes() throws Exception {
        // Given
        doReturn(true).when(renderer).getPlotLines(); // fixed
        int series = 0;
        int item = 1;
        int pass = 0;

        // Mock domainAxis and rangeAxis to not be instances of CyclicNumberAxis
        // Fixed mock condition
        when(domainAxis instanceof CyclicNumberAxis).thenReturn(false);
        when(rangeAxis instanceof CyclicNumberAxis).thenReturn(false);

        // When
        callDrawItem(series, item, pass);

        // Then
        verifyCallToSuperDrawItem(series, item, pass);
    }

    /**
     * TC03: getPlotLines() returns true, domainAxis is CyclicNumberAxis, cycle splitting occurs.
     */
    @Test
    @DisplayName("getPlotLines() returns true, domainAxis is CyclicNumberAxis, cycle splitting occurs")
    void TC03_drawItem_with_cyclic_domain_axis_requiring_split() throws Exception {
        // Given
        doReturn(true).when(renderer).getPlotLines(); // fixed
        int series = 0;
        int item = 1;
        int pass = 0;

        CyclicNumberAxis mockDomainAxis = mock(CyclicNumberAxis.class);
        when(domainAxis).thenReturn(mockDomainAxis); // fixed

        when(mockDomainAxis.getCycleBound()).thenReturn(100.0);
        when(mockDomainAxis.isBoundMappedToLastCycle()).thenReturn(false);

        // Mock dataset values
        when(dataset.getXValue(series, item - 1)).thenReturn(90.0);
        when(dataset.getYValue(series, item - 1)).thenReturn(50.0);
        when(dataset.getXValue(series, item)).thenReturn(110.0);
        when(dataset.getYValue(series, item)).thenReturn(60.0);

        // When
        callDrawItem(series, item, pass);

        // Then
        // Verify that the cycle was split and super.drawItem was called with the new dataset
        verify(renderer, times(2)).drawItem(
            any(Graphics2D.class),
            any(XYItemRendererState.class),
            any(Rectangle2D.class),
            any(PlotRenderingInfo.class),
            any(XYPlot.class),
            any(ValueAxis.class),
            any(ValueAxis.class),
            any(XYDataset.class),
            anyInt(),
            anyInt(),
            any(CrosshairState.class),
            anyInt()
        );
    }

    /**
     * TC04: getPlotLines() returns true, y-value of previous data point is NaN.
     */
    @Test
    @DisplayName("getPlotLines() returns true, y-value of previous data point is NaN")
    void TC04_drawItem_with_previous_y_value_nan() throws Exception {
        // Given
        doReturn(true).when(renderer).getPlotLines(); // fixed
        int series = 0;
        int item = 1;
        int pass = 0;

        when(dataset.getYValue(series, item - 1)).thenReturn(Double.NaN);

        // When
        callDrawItem(series, item, pass);

        // Then
        verifyCallToSuperDrawItem(series, item, pass);
    }

    /**
     * TC05: getPlotLines() returns true, current y-value is NaN, method returns without drawing.
     */
    @Test
    @DisplayName("getPlotLines() returns true, current y-value is NaN, method returns without drawing")
    void TC05_drawItem_with_current_y_value_nan() throws Exception {
        // Given
        doReturn(true).when(renderer).getPlotLines(); // fixed
        int series = 0;
        int item = 1;
        int pass = 0;

        when(dataset.getYValue(series, item - 1)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(Double.NaN);

        // When
        callDrawItem(series, item, pass);

        // Then
        verify(renderer, never()).drawItem(
            any(Graphics2D.class),
            any(XYItemRendererState.class),
            any(Rectangle2D.class),
            any(PlotRenderingInfo.class),
            any(XYPlot.class),
            any(ValueAxis.class),
            any(ValueAxis.class),
            any(XYDataset.class),
            anyInt(),
            anyInt(),
            any(CrosshairState.class),
            anyInt()
        );
    }

    private void callDrawItem(int series, int item, int pass) throws Exception {
        // Reflection method is not needed, so replaced with direct call
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
    }

    private void verifyCallToSuperDrawItem(int series, int item, int pass) throws Exception {
        ArgumentCaptor<Graphics2D> g2Captor = ArgumentCaptor.forClass(Graphics2D.class);
        ArgumentCaptor<XYItemRendererState> stateCaptor = ArgumentCaptor.forClass(XYItemRendererState.class);
        ArgumentCaptor<Rectangle2D> dataAreaCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        ArgumentCaptor<PlotRenderingInfo> infoCaptor = ArgumentCaptor.forClass(PlotRenderingInfo.class);
        ArgumentCaptor<XYPlot> plotCaptor = ArgumentCaptor.forClass(XYPlot.class);
        ArgumentCaptor<ValueAxis> domainAxisCaptor = ArgumentCaptor.forClass(ValueAxis.class);
        ArgumentCaptor<ValueAxis> rangeAxisCaptor = ArgumentCaptor.forClass(ValueAxis.class);
        ArgumentCaptor<XYDataset> datasetCaptor = ArgumentCaptor.forClass(XYDataset.class);
        ArgumentCaptor<Integer> seriesCaptor = ArgumentCaptor.forClass(Integer.class);
        ArgumentCaptor<Integer> itemCaptor = ArgumentCaptor.forClass(Integer.class);
        ArgumentCaptor<CrosshairState> crosshairStateCaptor = ArgumentCaptor.forClass(CrosshairState.class);
        ArgumentCaptor<Integer> passCaptor = ArgumentCaptor.forClass(Integer.class);

        verify(renderer, times(1)).drawItem(
            g2Captor.capture(),
            stateCaptor.capture(),
            dataAreaCaptor.capture(),
            infoCaptor.capture(),
            plotCaptor.capture(),
            domainAxisCaptor.capture(),
            rangeAxisCaptor.capture(),
            datasetCaptor.capture(),
            seriesCaptor.capture(),
            itemCaptor.capture(),
            crosshairStateCaptor.capture(),
            passCaptor.capture()
        );

        assertEquals(g2, g2Captor.getValue());
        assertEquals(state, stateCaptor.getValue());
        assertEquals(dataArea, dataAreaCaptor.getValue());
        assertEquals(info, infoCaptor.getValue());
        assertEquals(plot, plotCaptor.getValue());
        assertEquals(domainAxis, domainAxisCaptor.getValue());
        assertEquals(rangeAxis, rangeAxisCaptor.getValue());
        assertEquals(dataset, datasetCaptor.getValue());
        assertEquals(series, seriesCaptor.getValue());
        assertEquals(item, itemCaptor.getValue());
        assertEquals(crosshairState, crosshairStateCaptor.getValue());
        assertEquals(pass, passCaptor.getValue());
    }
}