package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;

public class ISO8601Utils_parse_0_9_Test {

    @Test
    @DisplayName("Parse throws ParseException when milliseconds have more than three digits")
    void TC41_ParseThrowsParseExceptionWhenMillisecondsHaveMoreThanThreeDigits() {
        // GIVEN
        String date = "2023-10-05T14:30:00.1234Z";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("Failed to parse date"));
    }

    @Test
    @DisplayName("Parse successfully parses date with negative timezone offset without colon")
    void TC42_ParseSuccessfullyParsesDateWithNegativeTimezoneOffsetWithoutColon() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00-0500";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT-5"));
        expectedCalendar.setLenient(false);
        expectedCalendar.set(Calendar.YEAR, 2023);
        expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER);
        expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
        expectedCalendar.set(Calendar.HOUR_OF_DAY, 14);
        expectedCalendar.set(Calendar.MINUTE, 30);
        expectedCalendar.set(Calendar.SECOND, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();
        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse throws ParseException when 'Z' is followed by unexpected characters")
    void TC43_ParseThrowsParseExceptionWhenZIsFollowedByUnexpectedCharacters() {
        // GIVEN
        String date = "2023-10-05T14:30:00Z+02:00";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("Failed to parse date"));
    }

    @Test
    @DisplayName("Parse handles date with no time and 'T' followed by timezone")
    void TC44_ParseHandlesDateWithNoTimeAndTFollowedByTimezone() throws ParseException {
        // GIVEN
        String date = "2023-10-05T+02:00";
        ParsePosition pos = new ParsePosition(0);

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("GMT+2"));
        expectedCalendar.setLenient(false);
        expectedCalendar.set(Calendar.YEAR, 2023);
        expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER);
        expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
        expectedCalendar.set(Calendar.HOUR_OF_DAY, 0);
        expectedCalendar.set(Calendar.MINUTE, 0);
        expectedCalendar.set(Calendar.SECOND, 0);
        expectedCalendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = expectedCalendar.getTime();
        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("Parse throws ParseException when timezone offset has invalid hour value")
    void TC45_ParseThrowsParseExceptionWhenTimezoneOffsetHasInvalidHourValue() {
        // GIVEN
        String date = "2023-10-05T14:30:00+25:00";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("Failed to parse date"));
    }
}