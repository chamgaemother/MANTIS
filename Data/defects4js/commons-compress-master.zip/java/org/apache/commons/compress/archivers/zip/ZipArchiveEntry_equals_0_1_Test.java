package org.apache.commons.compress.archivers.zip;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.nio.file.attribute.FileTime;

public class ZipArchiveEntry_equals_0_1_Test {

    @Test
    @DisplayName("equals() returns true when comparing the object to itself (this == obj)")
    public void TC01_equalsSameObject() {
        ZipArchiveEntry entry = new ZipArchiveEntry("test.zip");

        boolean result = entry.equals(entry);

        assertTrue(result, "equals() should return true when comparing the object to itself");
    }

    @Test
    @DisplayName("equals() returns false when obj is null")
    public void TC02_equalsWithNullObject() {
        ZipArchiveEntry entry = new ZipArchiveEntry("test.zip");
        Object obj = null;

        boolean result = entry.equals(obj);

        assertFalse(result, "equals() should return false when obj is null");
    }

    @Test
    @DisplayName("equals() returns false when obj is of a different class")
    public void TC03_equalsWithDifferentClassObject() {
        ZipArchiveEntry entry = new ZipArchiveEntry("test.zip");
        Object obj = "test.zip";

        boolean result = entry.equals(obj);

        assertFalse(result, "equals() should return false when obj is of a different class");
    }

    @Test
    @DisplayName("equals() returns true when all fields are equal")
    public void TC04_equalsWithAllFieldsEqual() throws Exception {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test.zip");

        // Set identical fields for entry1 and entry2 using reflection
        setPrivateField(entry1, "name", "test.zip");
        setPrivateField(entry2, "name", "test.zip");

        setPrivateField(entry1, "versionMadeBy", 2);
        setPrivateField(entry2, "versionMadeBy", 2);

        setPrivateField(entry1, "platform", 3);
        setPrivateField(entry2, "platform", 3);

        // Using reflection to set example fields (modify as needed with real fields/values)
        // Ensure the part below reflects actual private fields you need to set
        
        boolean result = entry1.equals(entry2);

        assertTrue(result, "equals() should return true when all fields are equal");
    }

    @Test
    @DisplayName("equals() returns false when names are different")
    public void TC05_equalsWithDifferentNames() {
        ZipArchiveEntry entry1 = new ZipArchiveEntry("test1.zip");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("test2.zip");

        boolean result = entry1.equals(entry2);

        assertFalse(result, "equals() should return false when names are different");
    }

    private void setPrivateField(ZipArchiveEntry entry, String fieldName, Object value) throws Exception {
        Field field = ZipArchiveEntry.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(entry, value);
    }
}