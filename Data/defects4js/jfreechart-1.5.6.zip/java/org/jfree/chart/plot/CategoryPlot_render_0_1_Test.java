package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryCrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtils;
import org.jfree.chart.util.SortOrder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CategoryPlot_render_0_1_Test {

    @Test
    @DisplayName("render method returns false when dataset is empty")
    void TC01_render_with_empty_dataset() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        int index = 0;
        CategoryDataset emptyDataset = mock(CategoryDataset.class);
        when(emptyDataset.getRowCount()).thenReturn(0);
        when(emptyDataset.getColumnCount()).thenReturn(0);
        plot.setDataset(index, emptyDataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertFalse(result, "Expected render to return false when dataset is empty");
    }

    @Test
    @DisplayName("render method returns false when renderer is null")
    void TC02_render_with_null_renderer() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        int index = 0;
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getRowCount()).thenReturn(5);
        when(dataset.getColumnCount()).thenReturn(5);
        plot.setDataset(index, dataset);
        plot.setRenderer(index, null);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertFalse(result, "Expected render to return false when renderer is null");
    }

    @Test
    @DisplayName("render method returns true with no rendering passes when pass count is zero")
    void TC03_render_with_zero_rendering_passes() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        int index = 0;
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getRowCount()).thenReturn(5);
        when(dataset.getColumnCount()).thenReturn(5);
        plot.setDataset(index, dataset);

        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        // Fix: Properly define mock behavior for getPassCount
        when(renderer.getPassCount()).thenReturn(0);
        plot.setRenderer(index, renderer);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertTrue(result, "Expected render to return true when pass count is zero");
        verify(renderer, never()).drawItem(any(), any(), any(), any(), any(), any(), any(), anyInt(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("render method processes one rendering pass with ascending column and ascending row order")
    void TC04_render_one_pass_ascending_order() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        int index = 0;
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getRowCount()).thenReturn(2);
        when(dataset.getColumnCount()).thenReturn(2);
        plot.setDataset(index, dataset);

        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        // Fix: Properly define mock behavior for getPassCount
        when(renderer.getPassCount()).thenReturn(1);
        plot.setRenderer(index, renderer);

        plot.setColumnRenderingOrder(SortOrder.ASCENDING);
        plot.setRowRenderingOrder(SortOrder.ASCENDING);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertTrue(result, "Expected render to return true with one rendering pass");
        verify(renderer, times(4)).drawItem(eq(g2), any(), eq(dataArea), eq(plot), any(CategoryAxis.class), any(ValueAxis.class), eq(dataset), anyInt(), anyInt(), eq(0));
    }

    @Test
    @DisplayName("render method processes multiple rendering passes with ascending column and ascending row order")
    void TC05_render_multiple_passes_ascending_order() throws Exception {
        // Arrange
        CategoryPlot plot = new CategoryPlot();
        int index = 0;
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getRowCount()).thenReturn(2);
        when(dataset.getColumnCount()).thenReturn(2);
        plot.setDataset(index, dataset);

        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        // Fix: Properly define mock behavior for getPassCount
        when(renderer.getPassCount()).thenReturn(3);
        plot.setRenderer(index, renderer);

        plot.setColumnRenderingOrder(SortOrder.ASCENDING);
        plot.setRowRenderingOrder(SortOrder.ASCENDING);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        CategoryCrosshairState crosshairState = mock(CategoryCrosshairState.class);

        // Act
        boolean result = plot.render(g2, dataArea, index, info, crosshairState);

        // Assert
        assertTrue(result, "Expected render to return true with multiple rendering passes");
        verify(renderer, times(12)).drawItem(eq(g2), any(), eq(dataArea), eq(plot), any(CategoryAxis.class), any(ValueAxis.class), eq(dataset), anyInt(), anyInt(), anyInt());
    }

}