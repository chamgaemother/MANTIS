package org.apache.commons.math3.optim.univariate;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BracketFinderTest {

    @Test
    void testSearchWithNullFunction() {
        BracketFinder finder = new BracketFinder();
        assertThrows(NullPointerException.class, () -> {
            finder.search(null, GoalType.MINIMIZE, 0.0, 1.0);
        });
    }

    @Test
    void testSearchWithNullGoal() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> x;
        assertThrows(NullPointerException.class, () -> {
            finder.search(func, null, 0.0, 1.0);
        });
    }

    @Test
    void testSearchMinimizeFunction() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> (x - 2) * (x - 2);
        finder.search(func, GoalType.MINIMIZE, 0.0, 1.0);
        assertTrue(finder.getLo() <= 2.0 && finder.getHi() >= 2.0);
    }

    @Test
    void testSearchMaximizeFunction() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> -((x - 3) * (x - 3));
        finder.search(func, GoalType.MAXIMIZE, 2.0, 4.0);
        assertTrue(finder.getLo() <= 3.0 && finder.getHi() >= 3.0);
    }

    @Test
    void testSearchExchangeInitialPoints() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> x;
        finder.search(func, GoalType.MINIMIZE, 2.0, 1.0);
        assertEquals(1.0, finder.getLo(), 1e-10);
        assertEquals(2.0, finder.getHi(), 1e-10);
    }

    @Test
    void testSearchWithSameInitialPoints() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> x * x;
        finder.search(func, GoalType.MINIMIZE, 1.0, 1.0);
        assertEquals(1.0, finder.getLo(), 1e-10);
        assertEquals(1.0, finder.getHi(), 1e-10);
    }

    @Test
    void testSearchExceedMaxEvaluations() {
        BracketFinder finder = new BracketFinder(2.0, 3);
        UnivariateFunction func = x -> x;
        assertThrows(TooManyEvaluationsException.class, () -> {
            finder.search(func, GoalType.MINIMIZE, 0.0, 1.0);
        });
    }

    @Test
    void testSearchDenominatorNearZero() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = new UnivariateFunction() {
            @Override
            public double value(double x) {
                return 1e-22 * x;
            }
        };
        finder.search(func, GoalType.MINIMIZE, 0.0, 1.0);
        assertNotNull(finder.getLo());
        assertNotNull(finder.getHi());
    }

    @Test
    void testSearchLoGreaterThanHi() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> (x - 5) * (x - 5);
        finder.search(func, GoalType.MINIMIZE, 6.0, 4.0);
        assertTrue(finder.getLo() <= 5.0 && finder.getHi() >= 5.0);
        assertTrue(finder.getLo() <= finder.getHi());
    }

    @Test
    void testSearchWithFlatFunctionMinimize() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> 0.0;
        finder.search(func, GoalType.MINIMIZE, -1.0, 1.0);
        assertEquals(-1.0, finder.getLo(), 1e-10);
        assertEquals(1.0, finder.getHi(), 1e-10);
    }

    @Test
    void testSearchWithFlatFunctionMaximize() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> 0.0;
        finder.search(func, GoalType.MAXIMIZE, -2.0, 2.0);
        assertEquals(-2.0, finder.getLo(), 1e-10);
        assertEquals(2.0, finder.getHi(), 1e-10);
    }

    @Test
    void testSearchWithSingleEvaluation() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = x -> x;
        finder.search(func, GoalType.MINIMIZE, 0.0, 1.0);
        assertEquals(0.0, finder.getLo(), 1e-10);
        assertEquals(1.0, finder.getHi(), 1e-10);
    }

    @Test
    void testSearchWithMultipleSwaps() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction func = new UnivariateFunction() {
            @Override
            public double value(double x) {
                if (x < 1.0) return 2.0;
                if (x < 2.0) return 1.0;
                return 3.0;
            }
        };
        finder.search(func, GoalType.MINIMIZE, 0.5, 3.0);
        assertTrue(finder.getLo() <= 1.0 && finder.getHi() >= 1.0);
    }

    @Test
    void testSearchWithGrowLimitBoundary() {
        BracketFinder finder = new BracketFinder(1.0, 10);
        UnivariateFunction func = x -> x;
        finder.search(func, GoalType.MINIMIZE, 0.0, 1.0);
        assertTrue(finder.getLo() <= 0.0 && finder.getHi() >= 1.0);
    }
}