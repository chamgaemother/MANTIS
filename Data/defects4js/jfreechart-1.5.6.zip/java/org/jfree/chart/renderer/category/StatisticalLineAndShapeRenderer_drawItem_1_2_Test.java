package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class StatisticalLineAndShapeRenderer_drawItem_1_2_Test {

    private Graphics2D g2 = mock(Graphics2D.class);
    private CategoryItemRendererState state = mock(CategoryItemRendererState.class);
    private Rectangle2D dataArea = mock(Rectangle2D.class);
    private CategoryPlot plot = mock(CategoryPlot.class);
    private CategoryAxis domainAxis = mock(CategoryAxis.class);
    private ValueAxis rangeAxis = mock(ValueAxis.class);
    private StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
    private EntityCollection entities = mock(EntityCollection.class);
    private StatisticalLineAndShapeRenderer renderer = new StatisticalLineAndShapeRenderer();

    @Test
    @DisplayName("ErrorIndicatorPaint is set, standard deviation lines use custom paint")
    void TC12() throws Exception {
        Paint customErrorPaint = mock(Paint.class);
        renderer.setErrorIndicatorPaint(customErrorPaint);

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(state.getEntityCollection()).thenReturn(entities);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);

        verify(g2).setPaint(customErrorPaint);
        verify(g2, times(3)).draw(any());
    }

    @Test
    @DisplayName("ErrorIndicatorStroke is set, standard deviation lines use custom stroke")
    void TC13() throws Exception {
        Stroke customErrorStroke = mock(Stroke.class);
        renderer.setErrorIndicatorStroke(customErrorStroke);

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(15.0);
        when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(3.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.RIGHT);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(state.getEntityCollection()).thenReturn(entities);
        when(domainAxis.getCategorySeriesMiddle(anyInt(), anyInt(), anyInt(), anyInt(), anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(75.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(150.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 1);

        verify(g2).setStroke(customErrorStroke);
        verify(g2, times(3)).draw(any());
    }

    @Test
    @DisplayName("Standard deviation is null, lines not drawn")
    void TC14() throws Exception {
        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(20.0);
        when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(null);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(state.getEntityCollection()).thenReturn(entities);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(120.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 2, 1);

        verify(g2, never()).setPaint(any());
        verify(g2, never()).draw(any());
    }

    @Test
    @DisplayName("Shape fill is used with useFillPaint=false")
    void TC15() throws Exception {
        renderer.setUseFillPaint(false);
        when(renderer.getItemShapeFilled(anyInt(), anyInt())).thenReturn(true);
        when(renderer.getItemFillPaint(anyInt(), anyInt())).thenReturn(mock(Paint.class));
        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(mock(Paint.class));
        when(renderer.getDrawOutlines()).thenReturn(true);
        when(renderer.getUseOutlinePaint()).thenReturn(false);
        when(renderer.getItemOutlinePaint(anyInt(), anyInt())).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(anyInt(), anyInt())).thenReturn(mock(Stroke.class));

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(25.0);
        when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(state.getEntityCollection()).thenReturn(entities);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(110.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 3, 3, 1);

        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(java.awt.Shape.class));
        verify(g2).draw(any(java.awt.Shape.class));
    }

    @Test
    @DisplayName("Item label is visible for positive mean value in vertical orientation")
    void TC16() throws Exception {
        when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(30.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(65.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(130.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 4, 4, 1);

        verify(renderer).drawItemLabel(any(Graphics2D.class), any(PlotOrientation.class),
                any(StatisticalCategoryDataset.class), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }
}