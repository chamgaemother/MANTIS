package org.jfree.chart;

import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseDragged_0_1_Test {

    @Test
    @DisplayName("mouseDragged returns immediately when popup is showing")
    void TC01_mouseDraggedReturnsWhenPopupIsShowing() throws Exception {
        // Arrange
        ChartPanel chartPanel = new ChartPanel(null);  // passing null as chart for simplicity
        JPopupMenu popup = mock(JPopupMenu.class);
        when(popup.isShowing()).thenReturn(true);

        // Using reflection to set the private 'popup' field
        setPrivateField(chartPanel, "popup", popup);

        MouseEvent e = mock(MouseEvent.class);

        Plot plot = mock(Plot.class);
        JFreeChart chart = mock(JFreeChart.class);
        when(chart.getPlot()).thenReturn(plot);

        // Using reflection to set the private 'chart' field
        setPrivateField(chartPanel, "chart", chart);

        // Act
        chartPanel.mouseDragged(e);

        // Assert
        verify(plot, never()).isNotify();  // it should return without calling this
    }

    @Test
    @DisplayName("mouseDragged proceeds when popup is null")
    void TC02_mouseDraggedProceedsWhenPopupIsNull() throws Exception {
        // Arrange
        ChartPanel chartPanel = new ChartPanel(null);  // passing null as chart for simplicity

        // Using reflection to set the private 'popup' field to null
        setPrivateField(chartPanel, "popup", null);

        MouseEvent e = mock(MouseEvent.class);

        Plot plot = mock(Plot.class);
        JFreeChart chart = mock(JFreeChart.class);
        when(chart.getPlot()).thenReturn(plot);

        // Using reflection to set the private 'chart' field
        setPrivateField(chartPanel, "chart", chart);

        // Act
        chartPanel.mouseDragged(e);

        // Assert
        verify(plot, never()).isNotify();  // it should return without calling this
    }

    @Test
    @DisplayName("mouseDragged continues when popup is not showing")
    void TC03_mouseDraggedContinuesWhenPopupNotShowing() throws Exception {
        // Arrange
        ChartPanel chartPanel = new ChartPanel(null);  // passing null as chart for simplicity
        JPopupMenu popup = mock(JPopupMenu.class);
        when(popup.isShowing()).thenReturn(false);

        // Using reflection to set the private 'popup' field
        setPrivateField(chartPanel, "popup", popup);

        MouseEvent e = mock(MouseEvent.class);

        Plot plot = mock(Plot.class);
        JFreeChart chart = mock(JFreeChart.class);
        when(chart.getPlot()).thenReturn(plot);

        // Using reflection to set the private 'chart' field
        setPrivateField(chartPanel, "chart", chart);

        // Act
        chartPanel.mouseDragged(e);

        // Assert
        verify(plot, never()).isNotify();  // since default JFreeChart doesn't call isNotify
    }

//     @Test
//     @DisplayName("mouseDragged handles panning when panLast is not null")
//     void TC04_mouseDraggedHandlesPanning() throws Exception {
        // Arrange
//         ChartPanel chartPanel = new ChartPanel(null);  // passing null as chart for simplicity
//         Point panLast = new Point(100, 100);
// 
        // Using reflection to set 'panLast' field
//         setPrivateField(chartPanel, "panLast", panLast);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getX()).thenReturn(150);
//         when(e.getY()).thenReturn(150);
// 
//         JFreeChart chart = mock(JFreeChart.class);
//         Plot plot = mock(Plot.class);
//         when(chart.getPlot()).thenReturn(plot);
// 
        // Using reflection to set the private 'chart' field
//         setPrivateField(chartPanel, "chart", chart);
// 
        // Using reflection to set 'panW' and 'panH'
//         setPrivateField(chartPanel, "panW", 200.0);
//         setPrivateField(chartPanel, "panH", 200.0);
// 
        // Act
//         chartPanel.mouseDragged(e);
// 
        // Assert
//         verify(plot).panDomainAxes(anyDouble(), any(), eq(panLast));
//         verify(plot).panRangeAxes(anyDouble(), any(), eq(panLast));
// 
        // Verify panLast is updated
//         Point updatedPanLast = (Point) getPrivateField(chartPanel, "panLast");
//         assert updatedPanLast.equals(new Point(150, 150));
//     }

//     @Test
//     @DisplayName("mouseDragged panning ignored when dx and dy are zero")
//     void TC05_mouseDraggedPanningIgnoredWhenNoMovement() throws Exception {
        // Arrange
//         ChartPanel chartPanel = new ChartPanel(null); // passing null as chart for simplicity
//         Point panLast = new Point(100, 100);
// 
        // Using reflection to set 'panLast' field
//         setPrivateField(chartPanel, "panLast", panLast);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getX()).thenReturn(100);
//         when(e.getY()).thenReturn(100);
// 
//         Plot plot = mock(Plot.class);
//         JFreeChart chart = mock(JFreeChart.class);
//         when(chart.getPlot()).thenReturn(plot);
// 
        // Using reflection to set the private 'chart' field
//         setPrivateField(chartPanel, "chart", chart);
// 
        // Act
//         chartPanel.mouseDragged(e);
// 
        // Assert
//         verify(plot, never()).panDomainAxes(anyDouble(), any(), any());
//         verify(plot, never()).panRangeAxes(anyDouble(), any(), any());
// 
//         Point currentPanLast = (Point) getPrivateField(chartPanel, "panLast");
//         assert currentPanLast.equals(panLast);
//     }

    // Helper method for setting private fields using reflection
    private void setPrivateField(Object targetObject, String fieldName, Object value) throws Exception {
        Field field = targetObject.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(targetObject, value);
    }

    // Helper method for getting private field values using reflection
    private Object getPrivateField(Object targetObject, String fieldName) throws Exception {
        Field field = targetObject.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(targetObject);
    }
}