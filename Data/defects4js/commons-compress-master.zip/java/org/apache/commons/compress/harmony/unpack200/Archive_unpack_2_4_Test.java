package org.apache.commons.compress.harmony.unpack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.jar.JarOutputStream;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class Archive_unpack_2_4_Test {

    @Test
    @DisplayName("InputStream contains corrupt data leading to IOException during unpacking")
    void TC44_InputStreamCorruptData_ThrowsIOException() throws IOException {
        // Arrange
        byte[] magicBytes = {(byte)0xCA, (byte)0xFE, (byte)0xD0, (byte)0x0D};
        byte[] corruptData = {0x01, 0x02}; // Incomplete segment data
        ByteArrayOutputStream combinedStream = new ByteArrayOutputStream();
        combinedStream.write(magicBytes);
        combinedStream.write(corruptData);
        ByteArrayInputStream inputStream = new ByteArrayInputStream(combinedStream.toByteArray());
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        JarOutputStream outputStream = new JarOutputStream(byteArrayOutputStream);
        Archive archive = new Archive(inputStream, outputStream);

        // Act & Assert
        assertThrows(IOException.class, () -> archive.unpack());
    }

}