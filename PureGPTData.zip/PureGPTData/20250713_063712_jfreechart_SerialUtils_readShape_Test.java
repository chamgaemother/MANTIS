import org.jfree.chart.util.SerialUtils;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;
import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

class SerialUtilsTest {

    @Test
    void testReadShapeWithNullStream() {
        assertThrows(IllegalArgumentException.class, () -> {
            SerialUtils.readShape(null);
        }, "Expected readShape() to throw exception for null input stream.");
    }

    @Test
    void testReadShapeWithSerializationException() {
        assertThrows(IOException.class, () -> {
            ObjectInputStream stream = new ObjectInputStream(new InputStream() {
                @Override
                public int read() throws IOException {
                    throw new IOException("Mock IOException");
                }
            });
            SerialUtils.readShape(stream);
        });
    }

    @Test
    void testReadShapeWithNullShape() throws Exception {
        ByteArrayInputStream bis = new ByteArrayInputStream(new byte[]{1});
        ObjectInputStream stream = new ObjectInputStream(bis);
        Shape result = SerialUtils.readShape(stream);
        assertNull(result, "Expected result to be null.");
    }

    @Test
    void testReadShapeWithLine2D() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        
        oos.writeBoolean(false);
        oos.writeObject(Line2D.class);
        oos.writeDouble(1.0);
        oos.writeDouble(2.0);
        oos.writeDouble(3.0);
        oos.writeDouble(4.0);
        
        oos.flush();
        ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        
        Shape result = SerialUtils.readShape(stream);
        assertTrue(result instanceof Line2D.Double);
    }

    @Test
    void testReadShapeWithRectangle2D() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);

        oos.writeBoolean(false);
        oos.writeObject(Rectangle2D.class);
        oos.writeDouble(1.0);
        oos.writeDouble(2.0);
        oos.writeDouble(3.0);
        oos.writeDouble(4.0);
        
        oos.flush();
        ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        
        Shape result = SerialUtils.readShape(stream);
        assertTrue(result instanceof Rectangle2D.Double);
    }

    @Test
    void testReadShapeWithEllipse2D() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);

        oos.writeBoolean(false);
        oos.writeObject(Ellipse2D.class);
        oos.writeDouble(1.0);
        oos.writeDouble(2.0);
        oos.writeDouble(3.0);
        oos.writeDouble(4.0);
        
        oos.flush();
        ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        
        Shape result = SerialUtils.readShape(stream);
        assertTrue(result instanceof Ellipse2D.Double);
    }

    @Test
    void testReadShapeWithArc2D() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);

        oos.writeBoolean(false);
        oos.writeObject(Arc2D.class);
        oos.writeDouble(1.0);
        oos.writeDouble(2.0);
        oos.writeDouble(3.0);
        oos.writeDouble(4.0);
        oos.writeDouble(5.0);
        oos.writeDouble(6.0);
        oos.writeInt(Arc2D.OPEN);
        
        oos.flush();
        ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        
        Shape result = SerialUtils.readShape(stream);
        assertTrue(result instanceof Arc2D.Double);
    }

    @Test
    void testReadShapeWithGeneralPath() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);

        oos.writeBoolean(false);
        oos.writeObject(GeneralPath.class);
        float[] args = {0.0f, 0.0f, 1.0f, 1.0f, 2.0f, 2.0f};
        oos.writeBoolean(false);
        oos.writeInt(PathIterator.SEG_MOVETO);
        for (float arg : args) {
            oos.writeFloat(arg);
        }
        oos.writeInt(PathIterator.WIND_NON_ZERO);
        oos.writeBoolean(true);
        
        oos.flush();
        ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        
        Shape result = SerialUtils.readShape(stream);
        assertTrue(result instanceof GeneralPath);
    }

    @Test
    void testReadShapeWithUnknownClass() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);

        oos.writeBoolean(false);
        oos.writeObject(String.class); // Pretend to be a Shape class
        oos.writeObject(new Line2D.Double(1.0, 2.0, 3.0, 4.0));
        
        oos.flush();
        ObjectInputStream stream = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));

        Shape result = SerialUtils.readShape(stream);
        assertNotNull(result);
        assertTrue(result instanceof Line2D.Double);
    }
}