package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.entity.EntityCollection;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.Arrays;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_1_1_Test {

//     @Test
//     @DisplayName("drawVerticalItem with yAverage above dataArea bounds, ensuring average ellipse is not drawn")
//     void TC21_drawVerticalItem_yAverageAboveDataAreaBounds() throws Exception {
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.JFreeChart.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
//                .thenReturn(150.0); // yAverage maps to 150, which is above dataArea upper bound
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
//         when(dataset.getX(series, item)).thenReturn(50.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(50.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(120.0); // Above dataArea upper bound
//         when(dataset.getQ1Value(series, item)).thenReturn(30.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(70.0);
//         when(dataset.getOutliers(series, item)).thenReturn(Collections.emptyList());
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
//         verify(g2, never()).fill(any(Ellipse2D.Double.class));
//         verify(g2, never()).draw(any(Ellipse2D.Double.class));
//     }

//     @Test
//     @DisplayName("drawVerticalItem with yAverage below dataArea bounds, ensuring average ellipse is not drawn")
//     void TC22_drawVerticalItem_yAverageBelowDataAreaBounds() throws Exception {
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.JFreeChart.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
//                .thenReturn(-20.0); // yAverage maps to -20, which is below dataArea lower bound
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
//         when(dataset.getX(series, item)).thenReturn(50.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(50.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(-30.0); // Below dataArea lower bound
//         when(dataset.getQ1Value(series, item)).thenReturn(30.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(70.0);
//         when(dataset.getOutliers(series, item)).thenReturn(Collections.emptyList());
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
//         verify(g2, never()).fill(any(Ellipse2D.Double.class));
//         verify(g2, never()).draw(any(Ellipse2D.Double.class));
//     }

//     @Test
//     @DisplayName("drawVerticalItem with yOutliers exactly at maxOutlier and minOutlier boundaries")
//     void TC23_drawVerticalItem_yOutliersAtBoundaries() throws Exception {
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.JFreeChart.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
//                .thenReturn(50.0); // Regular mapping
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
//         when(dataset.getX(series, item)).thenReturn(50.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(50.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(50.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(30.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(70.0);
//         when(dataset.getOutliers(series, item)).thenReturn(Arrays.asList(80.0, 20.0)); // Outliers exactly at boundary
//         when(dataset.getMaxOutlier(series, item)).thenReturn(80.0);
//         when(dataset.getMinOutlier(series, item)).thenReturn(20.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
//         verify(g2).draw(any(Line2D.Double.class)); // Verify that far out markers are drawn for outliers at boundaries
//     }

//     @Test
//     @DisplayName("drawVerticalItem with lookupBoxPaint returning null, ensuring fallback to getItemPaint")
//     void TC24_drawVerticalItem_lookupBoxPaintFallback() throws Exception {
//         XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
//         doReturn(null).when(renderer).lookupBoxPaint(anyInt(), anyInt()); // Mock lookupBoxPaint to return null
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.JFreeChart.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
//                .thenReturn(50.0);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
//         when(dataset.getX(series, item)).thenReturn(50.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(50.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(60.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(30.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(70.0);
//         when(dataset.getOutliers(series, item)).thenReturn(Collections.emptyList());
//         Paint mockPaint = mock(Paint.class);
//         doReturn(mockPaint).when(renderer).getItemPaint(series, item); // Mock getItemPaint
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
//         verify(renderer).getItemPaint(series, item); // Verify getItemPaint was called as fallback
//         verify(g2).setPaint(mockPaint); // Verify box is filled with fallback paint
//         verify(g2).fill(any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("drawVerticalItem with yOutliers containing both regular and far out outliers")
//     void TC25_drawVerticalItem_mixedOutliers() throws Exception {
//         XYBoxAndWhiskerRenderer renderer = spy(new XYBoxAndWhiskerRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         doNothing().when(renderer).drawHighFarOut(anyDouble(), eq(g2), anyDouble(), anyDouble()); // To avoid method source not found error
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(org.jfree.chart.JFreeChart.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT)))
//                .thenReturn(50.0);
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         int series = 0;
//         int item = 0;
//         when(dataset.getX(series, item)).thenReturn(50.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         when(dataset.getMedianValue(series, item)).thenReturn(50.0);
//         when(dataset.getMeanValue(series, item)).thenReturn(60.0);
//         when(dataset.getQ1Value(series, item)).thenReturn(30.0);
//         when(dataset.getQ3Value(series, item)).thenReturn(70.0);
//         when(dataset.getOutliers(series, item)).thenReturn(Arrays.asList(75.0, 85.0)); // Regular and far out outliers
//         when(dataset.getMaxOutlier(series, item)).thenReturn(80.0);
//         when(dataset.getMinOutlier(series, item)).thenReturn(20.0);
//         when(dataset.getMaxRegularValue(series, item)).thenReturn(80.0);
//         when(dataset.getMinRegularValue(series, item)).thenReturn(20.0);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
//         verify(g2).draw(any(Ellipse2D.Double.class)); // Verify regular outlier is drawn
//         verify(renderer).drawHighFarOut(anyDouble(), eq(g2), anyDouble(), anyDouble()); // Verify far out outlier is drawn
//     }

}