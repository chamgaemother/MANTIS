package org.apache.commons.math3.ode.sampling;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.apache.commons.math3.ode.sampling.StepNormalizer;
import org.apache.commons.math3.ode.sampling.StepNormalizerBounds;
import org.apache.commons.math3.ode.sampling.StepNormalizerMode;
import org.apache.commons.math3.ode.sampling.FixedStepHandler;
import org.apache.commons.math3.ode.sampling.StepHandler;
import org.mockito.Mockito;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class StepNormalizer_handleStep_0_3_Test {

    @Test
    @DisplayName("Handle step with h set to zero, expecting no progression in nextTime")
    void TC11_handleStep_hZero_noProgression() throws MaxCountExceededException {
        // Initialize mocks
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizerBounds bounds = StepNormalizerBounds.FIRST; // Use actual enum
        StepInterpolator interpolator = mock(StepInterpolator.class);

        // Set up interpolator mock behavior
        when(interpolator.getPreviousTime()).thenReturn(1.0);
        when(interpolator.getCurrentTime()).thenReturn(1.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{0.0});

        // Initialize StepNormalizer with h=0
        StepNormalizer normalizer = new StepNormalizer(0.0, handler, StepNormalizerMode.INCREMENT, bounds);

        // Invoke handleStep
        normalizer.handleStep(interpolator, false);

        // Verify that handler.handleStep was not called
        verify(handler, times(0)).handleStep(any(), any(), any(), anyBoolean());
    }

    @Test
    @DisplayName("Handle step when interpolator provides identical current and previous times")
    void TC12_handleStep_identicalCurrentPreviousTimes() throws MaxCountExceededException {
        // Initialize mocks
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizerBounds bounds = StepNormalizerBounds.FIRST; // Use actual enum
        StepInterpolator interpolator = mock(StepInterpolator.class);

        // Set up interpolator mock behavior: currentTime == previousTime
        when(interpolator.getPreviousTime()).thenReturn(2.0);
        when(interpolator.getCurrentTime()).thenReturn(2.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{1.0});

        // Initialize StepNormalizer with h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.INCREMENT, bounds);

        // Invoke handleStep
        normalizer.handleStep(interpolator, false);

        // Verify that handler.handleStep was not called due to same time
        verify(handler, times(0)).handleStep(any(), any(), any(), anyBoolean());
    }

    @Test
    @DisplayName("Handle step when storeStep throws an exception, expecting the method to propagate the exception")
    void TC13_handleStep_storeStepThrowsException() {
        // Initialize mocks
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizerBounds bounds = StepNormalizerBounds.FIRST;
        StepInterpolator interpolator = mock(StepInterpolator.class);

        // Set up interpolator mock behavior
        when(interpolator.getPreviousTime()).thenReturn(3.0);
        when(interpolator.getCurrentTime()).thenReturn(4.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{2.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{2.0});

        // Initialize StepNormalizer with h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.INCREMENT, bounds);

        // Create a spy of StepNormalizer
        StepNormalizer spyNormalizer = Mockito.spy(normalizer);

        try {
            doThrow(new RuntimeException("storeStep exception")).when(spyNormalizer).handleStep(interpolator, false);

            // Expect the exception to be thrown when handleStep is invoked
            assertThrows(RuntimeException.class, () -> spyNormalizer.handleStep(interpolator, false));
        } catch (MaxCountExceededException mcee) {
            // handle exception
        }
    }

    @Test
    @DisplayName("Handle step when doNormalizedStep is called with isLast=true")
    void TC14_handleStep_doNormalizedStepCalledWithIsLastTrue() throws MaxCountExceededException {
        // Initialize mocks
        FixedStepHandler handler = mock(FixedStepHandler.class);
        StepNormalizerBounds bounds = StepNormalizerBounds.FIRST;
        StepInterpolator interpolator = mock(StepInterpolator.class);

        // Set up interpolator mock behavior
        when(interpolator.getPreviousTime()).thenReturn(4.0);
        when(interpolator.getCurrentTime()).thenReturn(5.0);
        when(interpolator.getInterpolatedState()).thenReturn(new double[]{3.0});
        when(interpolator.getInterpolatedDerivatives()).thenReturn(new double[]{3.0});

        // Initialize StepNormalizer with h=0.1
        StepNormalizer normalizer = new StepNormalizer(0.1, handler, StepNormalizerMode.INCREMENT, bounds);

        // Create a spy of StepNormalizer
        StepNormalizer spyNormalizer = Mockito.spy(normalizer);

        // Call handleStep with isLast=true
        spyNormalizer.handleStep(interpolator, true);

        // Verify that the last doNormalizedStep was called
        verify(handler, atLeastOnce()).handleStep(anyDouble(), any(double[].class), any(double[].class), eq(true));
    }
}
