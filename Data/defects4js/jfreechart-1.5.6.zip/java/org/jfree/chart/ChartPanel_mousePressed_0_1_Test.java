package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.Pannable;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ChartPanel_mousePressed_0_1_Test {

    @Test
    @DisplayName("mousePressed returns immediately when chart is null")
    void TC01_mousePressed_returnsImmediatelyWhenChartIsNull() throws Exception {
        // GIVEN
        ChartPanel chartPanel = new ChartPanel(null);
        MouseEvent e = mock(MouseEvent.class);

        // WHEN
        chartPanel.mousePressed(e);

        // THEN
        // Verify no interactions with MouseEvent
        verify(e, never()).getModifiers();
        // Additionally, ensure no exceptions are thrown and method exits
    }

//     @Test
//     @DisplayName("mousePressed performs panning when modifiers match panMask and plot is Pannable with domain pannable")
//     void TC02_mousePressed_performsPanningWithDomainPannable() throws Exception {
        // GIVEN
//         JFreeChart chart = mock(JFreeChart.class);
//         Pannable plot = mock(Pannable.class);
//         when(chart.getPlot()).thenReturn(plot);
//         when(plot.isDomainPannable()).thenReturn(true);
//         when(plot.isRangePannable()).thenReturn(false);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getModifiers()).thenReturn(InputEvent.CTRL_DOWN_MASK); // Changed to CTRL_DOWN_MASK
//         when(e.getX()).thenReturn(100);
//         when(e.getY()).thenReturn(100);
//         Point mockPoint = new Point(150, 150);
//         when(e.getPoint()).thenReturn(mockPoint);
// 
//         Rectangle2D screenDataArea = new Rectangle2D.Double(50, 50, 200, 200);
// 
        // WHEN
//         chartPanel.panW = screenDataArea.getWidth();
//         chartPanel.panH = screenDataArea.getHeight();
//         chartPanel.panLast = mockPoint;
// 
//         chartPanel.mousePressed(e);
// 
        // THEN
        // Verify cursor is set to MOVE_CURSOR via reflection
//         assertEquals(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR), chartPanel.getCursor());
// 
        // Verify panW, panH, and panLast via reflection
//         assertEquals(screenDataArea.getWidth(), chartPanel.panW);
//         assertEquals(screenDataArea.getHeight(), chartPanel.panH);
//     }

//     @Test
//     @DisplayName("mousePressed performs panning when modifiers match panMask and plot is Pannable with range pannable")
//     void TC03_mousePressed_performsPanningWithRangePannable() throws Exception {
        // GIVEN
//         JFreeChart chart = mock(JFreeChart.class);
//         Pannable plot = mock(Pannable.class);
//         when(chart.getPlot()).thenReturn(plot);
//         when(plot.isDomainPannable()).thenReturn(false);
//         when(plot.isRangePannable()).thenReturn(true);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getModifiers()).thenReturn(InputEvent.CTRL_DOWN_MASK); // Changed to CTRL_DOWN_MASK
//         when(e.getX()).thenReturn(100);
//         when(e.getY()).thenReturn(100);
//         Point mockPoint = new Point(150, 150);
//         when(e.getPoint()).thenReturn(mockPoint);
// 
//         Rectangle2D screenDataArea = new Rectangle2D.Double(50, 50, 200, 200);
// 
        // WHEN
//         chartPanel.panW = screenDataArea.getWidth();
//         chartPanel.panH = screenDataArea.getHeight();
//         chartPanel.panLast = mockPoint;
// 
//         chartPanel.mousePressed(e);
// 
        // THEN
        // Verify cursor is set to MOVE_CURSOR via reflection
//         assertEquals(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR), chartPanel.getCursor());
// 
        // Verify panW, panH, and panLast via reflection
//         assertEquals(screenDataArea.getWidth(), chartPanel.panW);
//         assertEquals(screenDataArea.getHeight(), chartPanel.panH);
//     }

//     @Test
//     @DisplayName("mousePressed does not perform panning when modifiers match panMask but plot is not Pannable")
//     void TC04_mousePressed_doesNotPerformPanningWhenPlotNotPannable() throws Exception {
        // GIVEN
//         JFreeChart chart = mock(JFreeChart.class);
//         Plot plot = mock(Plot.class);
//         when(chart.getPlot()).thenReturn(plot);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getModifiers()).thenReturn(InputEvent.CTRL_DOWN_MASK); // Changed to CTRL_DOWN_MASK
// 
        // WHEN
//         chartPanel.mousePressed(e);
// 
        // THEN
        // Verify cursor is not set via reflection
//         assertNotEquals(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR), chartPanel.getCursor());
// 
        // Verify panW, panH, and panLast are not set via reflection
//         assertEquals(0.0, chartPanel.panW);
//         assertEquals(0.0, chartPanel.panH);
//         assertNull(chartPanel.panLast);
//     }

//     @Test
//     @DisplayName("mousePressed panning is not initiated when neither domain nor range is pannable")
//     void TC05_mousePressed_panningNotInitiatedWhenNeitherDomainNorRangePannable() throws Exception {
        // GIVEN
//         JFreeChart chart = mock(JFreeChart.class);
//         Pannable plot = mock(Pannable.class);
//         when(chart.getPlot()).thenReturn(plot);
//         when(plot.isDomainPannable()).thenReturn(false);
//         when(plot.isRangePannable()).thenReturn(false);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getModifiers()).thenReturn(InputEvent.CTRL_DOWN_MASK); // Changed to CTRL_DOWN_MASK
// 
        // WHEN
//         chartPanel.mousePressed(e);
// 
        // THEN
        // Verify cursor is not set via reflection
//         assertNotEquals(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR), chartPanel.getCursor());
// 
        // Verify panW, panH, and panLast are not set via reflection
//         assertEquals(0.0, chartPanel.panW);
//         assertEquals(0.0, chartPanel.panH);
//         assertNull(chartPanel.panLast);
//     }

    private int getModifiers(ChartPanel chartPanel) {
        int panMask = 0;
        try {
            Field field = ChartPanel.class.getDeclaredField("panMask");
            field.setAccessible(true);
            panMask = (int) field.get(chartPanel);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return panMask;
    }
}