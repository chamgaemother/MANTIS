package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.*;

import java.io.StringReader;

import org.apache.commons.jxpath.ri.Compiler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class XPathParserTest {

    private Compiler compiler;

    @BeforeEach
    public void setUp() {
        compiler = new Compiler();
    }

    @Test
    public void testAxisNameSelf() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("self::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_SELF, axis);
    }

    @Test
    public void testAxisNameChild() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("child::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_CHILD, axis);
    }

    @Test
    public void testAxisNameParent() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("parent::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_PARENT, axis);
    }

    @Test
    public void testAxisNameAncestor() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("ancestor::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_ANCESTOR, axis);
    }

    @Test
    public void testAxisNameAttribute() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("attribute::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_ATTRIBUTE, axis);
    }

    @Test
    public void testAxisNameNamespace() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("namespace::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_NAMESPACE, axis);
    }

    @Test
    public void testAxisNamePreceding() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("preceding::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_PRECEDING, axis);
    }

    @Test
    public void testAxisNameFollowing() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("following::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_FOLLOWING, axis);
    }

    @Test
    public void testAxisNameDescendant() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("descendant::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_DESCENDANT, axis);
    }

    @Test
    public void testAxisNameAncestorOrSelf() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("ancestor-or-self::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_ANCESTOR_OR_SELF, axis);
    }

    @Test
    public void testAxisNameFollowingSibling() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("following-sibling::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_FOLLOWING_SIBLING, axis);
    }

    @Test
    public void testAxisNamePrecedingSibling() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("preceding-sibling::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_PRECEDING_SIBLING, axis);
    }

    @Test
    public void testAxisNameDescendantOrSelf() throws ParseException {
        XPathParser parser = new XPathParser(new StringReader("descendant-or-self::node()"));
        parser.setCompiler(compiler);
        int axis = parser.AxisName();
        assertEquals(Compiler.AXIS_DESCENDANT_OR_SELF, axis);
    }

    @Test
    public void testAxisNameInvalid() {
        XPathParser parser = new XPathParser(new StringReader("invalid::node()"));
        parser.setCompiler(compiler);
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    public void testAxisNameEmptyInput() {
        XPathParser parser = new XPathParser(new StringReader(""));
        parser.setCompiler(compiler);
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }
}