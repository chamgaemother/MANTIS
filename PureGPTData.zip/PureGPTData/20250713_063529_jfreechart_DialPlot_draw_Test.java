import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.plot.dial.DialLayer;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;
import org.jfree.chart.plot.dial.DialFrame;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.general.ValueDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DialPlotTest {

    private DialPlot plot;
    private DialLayer mockBackground;
    private DialLayer mockCap;
    private DialFrame mockDialFrame;
    private List<DialLayer> mockLayers;
    private List<DialPointer> mockPointers;

    @BeforeEach
    void setUp() {
        plot = new DialPlot();
        mockBackground = mock(DialLayer.class);
        mockCap = mock(DialLayer.class);
        mockDialFrame = mock(DialFrame.class);
        mockLayers = new ArrayList<>();
        mockPointers = new ArrayList<>();
    }

    @Test
    void testDrawNullGraphics2D() {
        assertThrows(NullPointerException.class, () -> {
            plot.draw(null, new Rectangle2D.Double(0, 0, 100, 100), null, null, null);
        });
    }

    @Test
    void testDrawNullArea() {
        assertThrows(NullPointerException.class, () -> {
            plot.draw(mock(Graphics2D.class), null, null, null, null);
        });
    }

    @Test
    void testDrawWithBackgroundVisibleAndClipped() {
        when(mockBackground.isVisible()).thenReturn(true);
        when(mockBackground.isClippedToWindow()).thenReturn(true);
        plot.setBackground(mockBackground);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockBackground, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithBackgroundVisibleAndNotClipped() {
        when(mockBackground.isVisible()).thenReturn(true);
        when(mockBackground.isClippedToWindow()).thenReturn(false);
        plot.setBackground(mockBackground);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockBackground, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithBackgroundNotVisible() {
        when(mockBackground.isVisible()).thenReturn(false);
        plot.setBackground(mockBackground);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockBackground, never()).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithCapVisibleAndClipped() {
        when(mockCap.isVisible()).thenReturn(true);
        when(mockCap.isClippedToWindow()).thenReturn(true);
        plot.setCap(mockCap);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockCap, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithCapVisibleAndNotClipped() {
        when(mockCap.isVisible()).thenReturn(true);
        when(mockCap.isClippedToWindow()).thenReturn(false);
        plot.setCap(mockCap);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockCap, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithCapNotVisible() {
        when(mockCap.isVisible()).thenReturn(false);
        plot.setCap(mockCap);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockCap, never()).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithLayers() {
        DialLayer layer1 = mock(DialLayer.class);
        DialLayer layer2 = mock(DialLayer.class);

        plot.addLayer(layer1);
        plot.addLayer(layer2);

        when(layer1.isVisible()).thenReturn(true);
        when(layer2.isVisible()).thenReturn(true);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(layer1, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
        verify(layer2, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithPointers() {
        DialPointer pointer1 = mock(DialPointer.class);
        DialPointer pointer2 = mock(DialPointer.class);

        plot.addPointer(pointer1);
        plot.addPointer(pointer2);

        when(pointer1.isVisible()).thenReturn(true);
        when(pointer2.isVisible()).thenReturn(true);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(pointer1, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
        verify(pointer2, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithDialFrameVisible() {
        when(mockDialFrame.isVisible()).thenReturn(true);
        plot.setDialFrame(mockDialFrame);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockDialFrame, times(1)).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }

    @Test
    void testDrawWithDialFrameNotVisible() {
        when(mockDialFrame.isVisible()).thenReturn(false);
        plot.setDialFrame(mockDialFrame);

        plot.draw(mock(Graphics2D.class), new Rectangle2D.Double(0, 0, 100, 100), null, null, null);

        verify(mockDialFrame, never()).draw(any(Graphics2D.class), eq(plot), any(Rectangle2D.class), any(Rectangle2D.class));
    }
}