package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.RectangleEdge;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.entity.EntityCollection;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class BarRenderer_drawItem_1_3_Test {

    @Test
    @DisplayName("drawItem adds multiple item entities for different columns")
    void TC26_drawItemAddsMultipleItemEntitiesForDifferentColumns() throws Exception {
        // GIVEN
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        int row = 10;
        int column1 = 10;
        int column2 = 11;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column1)).thenReturn(20.0);
        when(dataset.getValue(row, column2)).thenReturn(30.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.calculateBarL0L1(20.0)).thenReturn(new double[] {0.0, 20.0});
        when(renderer.calculateBarL0L1(30.0)).thenReturn(new double[] {0.0, 30.0});
        when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, plot.getRangeAxisEdge())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(30.0, dataArea, plot.getRangeAxisEdge())).thenReturn(30.0);
        when(state.getBarWidth()).thenReturn(10.0);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entities);

        // Use reflection to stub addItemEntity method
        BarRenderer spyRenderer = spy(renderer);

        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column1, 0);
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column2, 1);

        // THEN
        verify(spyRenderer, times(2)).addItemEntity(eq(entities), eq(dataset), eq(row), anyInt(), any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles exception when dataset retrieval fails")
    void TC27_drawItemHandlesExceptionWhenDatasetRetrievalFails() {
        // GIVEN
        BarRenderer renderer = new BarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 12;
        int column = 12;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenThrow(new RuntimeException("Dataset retrieval failed"));
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);

        // WHEN & THEN
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
        });
        assertEquals("Dataset retrieval failed", exception.getMessage());
    }

    @Test
    @DisplayName("drawItem processes bar with exactly minimumBarLength")
    void TC28_drawItemProcessesBarWithExactlyMinimumBarLength() throws Exception {
        // GIVEN
        BarRenderer renderer = new BarRenderer();
        // Set minimumBarLength to 5.0 via reflection
        Field minBarLengthField = BarRenderer.class.getDeclaredField("minimumBarLength");
        minBarLengthField.setAccessible(true);
        minBarLengthField.set(renderer, 5.0);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 13;
        int column = 13;

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenReturn(3.0); // barLengthAdj = 5.0 - 3.0 = 2.0
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.calculateBarL0L1(3.0)).thenReturn(new double[] {0.0, 3.0});
        when(renderer.calculateBarW0(plot, PlotOrientation.VERTICAL, dataArea, domainAxis, state, row, column)).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge())).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, plot.getRangeAxisEdge())).thenReturn(3.0);
        when(state.getBarWidth()).thenReturn(10.0);

        // Mock BarPainter and its paintBar method
        BarPainter barPainter = mock(BarPainter.class);
        Field barPainterField = BarRenderer.class.getDeclaredField("barPainter");
        barPainterField.setAccessible(true);
        barPainterField.set(renderer, barPainter);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        // THEN
        ArgumentCaptor<Rectangle2D> barCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        ArgumentCaptor<RectangleEdge> edgeCaptor = ArgumentCaptor.forClass(RectangleEdge.class);
        verify(barPainter, times(1)).paintBar(eq(g2), eq(renderer), eq(row), eq(column), barCaptor.capture(), edgeCaptor.capture());
        Rectangle2D capturedBar = barCaptor.getValue();
        assertEquals(5.0, capturedBar.getHeight(), 0.001, "Bar length should be exactly minimumBarLength");
    }
}