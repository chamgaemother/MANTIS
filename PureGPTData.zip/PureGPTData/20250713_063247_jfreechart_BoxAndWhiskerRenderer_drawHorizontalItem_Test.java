import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BoxAndWhiskerRendererTest {

    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private BoxAndWhiskerCategoryDataset dataset;
    private BoxAndWhiskerRenderer renderer;

    @BeforeEach
    void setUp() {
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);

        renderer = new BoxAndWhiskerRenderer();
        dataset = new DefaultBoxAndWhiskerCategoryDataset();
    }

    @Test
    void testDrawHorizontalItemWithValidInputs() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getRenderer()).thenReturn(renderer);
        when(plot.getDomainAxis()).thenReturn(domainAxis);

        assertDoesNotThrow(() -> {
            ((DefaultBoxAndWhiskerCategoryDataset) dataset).add(
                    Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0), "Series 1", "Category 1"
            );

            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                    dataset, 0, 0);
        });
    }

    @Test
    void testDrawHorizontalItemWithNullDataset() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getRenderer()).thenReturn(renderer);
        when(plot.getDomainAxis()).thenReturn(domainAxis);

        assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                    mock(CategoryDataset.class), 0, 0);
        });
    }

    @Test
    void testDrawHorizontalItemWithNullRangeAxisValues() {
        ((DefaultBoxAndWhiskerCategoryDataset) dataset).add(
                null, "Series 1", "Category 1"
        );
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getRenderer()).thenReturn(renderer);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        
        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                    dataset, 0, 0);
        });
    }

    @Test
    void testDrawHorizontalItemWithVerticalOrientation() {
        ((DefaultBoxAndWhiskerCategoryDataset) dataset).add(
                Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0), "Series 1", "Category 1"
        );
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRenderer()).thenReturn(renderer);
        when(plot.getDomainAxis()).thenReturn(domainAxis);

        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                    dataset, 0, 0);
        });
    }

    @Test
    void testDrawHorizontalItemWithInvisibleItem() {
        renderer.setSeriesVisible(0, false);

        ((DefaultBoxAndWhiskerCategoryDataset) dataset).add(
                Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0), "Series 1", "Category 1"
        );

        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getRenderer()).thenReturn(renderer);
        when(plot.getDomainAxis()).thenReturn(domainAxis);

        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis,
                    dataset, 0, 0);
        });
    }
}