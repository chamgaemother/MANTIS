import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.euclidean.twod.Line;
import org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet;
import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.apache.commons.math3.geometry.partitioning.BSPTree;
import org.apache.commons.math3.geometry.partitioning.SubHyperplane;
import org.apache.commons.math3.geometry.partitioning.BoundaryAttribute;
import org.apache.commons.math3.geometry.partitioning.Side;
import org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane;
import org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;

public class PolygonsSetTest {

    @Test
    void testGetVerticesWholePlane() {
        PolygonsSet polygonsSet = new PolygonsSet(1.0e-10);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(0, vertices.length, "Vertices array should be empty for whole plane");
    }

    @Test
    void testGetVerticesEmptyBoundary() {
        Collection<SubHyperplane<Euclidean2D>> boundary = Collections.emptyList();
        PolygonsSet polygonsSet = new PolygonsSet(boundary, 1.0e-10);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(0, vertices.length, "Vertices array should be empty for empty boundary");
    }

    @Test
    void testGetVerticesBoundedBox() {
        double xMin = 0.0;
        double xMax = 10.0;
        double yMin = 0.0;
        double yMax = 5.0;
        PolygonsSet polygonsSet = new PolygonsSet(xMin, xMax, yMin, yMax, 1.0e-10);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(1, vertices.length, "There should be one loop for the bounded box");
        Vector2D[] loop = vertices[0];
        assertEquals(4, loop.length, "Bounded box should have four vertices");
        assertTrue(Arrays.asList(loop).containsAll(Arrays.asList(
                new Vector2D(xMin, yMin),
                new Vector2D(xMax, yMin),
                new Vector2D(xMax, yMax),
                new Vector2D(xMin, yMax)
        )), "Bounded box vertices mismatch");
    }

    @Test
    void testGetVerticesSingleClosedPolygon() {
        Vector2D v1 = new Vector2D(0, 0);
        Vector2D v2 = new Vector2D(5, 0);
        Vector2D v3 = new Vector2D(5, 5);
        Vector2D v4 = new Vector2D(0, 5);
        PolygonsSet polygonsSet = new PolygonsSet(1.0e-10, v1, v2, v3, v4);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(1, vertices.length, "There should be one loop for the closed polygon");
        Vector2D[] loop = vertices[0];
        assertEquals(4, loop.length, "Closed polygon should have four vertices");
        assertArrayEquals(new Vector2D[] {v1, v2, v3, v4}, loop, "Closed polygon vertices mismatch");
    }

    @Test
    void testGetVerticesSingleInfiniteLine() {
        Line line = new Line(new Vector2D(0, 0), new Vector2D(1, 1), 1.0e-10);
        Vector2D v1 = line.toSpace(new Vector1D(Double.NEGATIVE_INFINITY));
        Vector2D v2 = line.toSpace(new Vector1D(Double.POSITIVE_INFINITY));
        PolygonsSet polygonsSet = new PolygonsSet(1.0e-10, null, v1, v2);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(1, vertices.length, "There should be one loop for the infinite line");
        Vector2D[] loop = vertices[0];
        assertEquals(3, loop.length, "Infinite line loop should have three elements");
        assertNull(loop[0], "First element should be null for open loop");
        assertEquals(v1, loop[1], "First dummy point mismatch");
        assertEquals(v2, loop[2], "Second dummy point mismatch");
    }

    @Test
    void testGetVerticesMultiplePolygons() {
        // First polygon
        Vector2D p1 = new Vector2D(0, 0);
        Vector2D p2 = new Vector2D(4, 0);
        Vector2D p3 = new Vector2D(4, 4);
        Vector2D p4 = new Vector2D(0, 4);
        PolygonsSet polygon1 = new PolygonsSet(1.0e-10, p1, p2, p3, p4);

        // Second polygon
        Vector2D q1 = new Vector2D(5, 5);
        Vector2D q2 = new Vector2D(7, 5);
        Vector2D q3 = new Vector2D(7, 7);
        Vector2D q4 = new Vector2D(5, 7);
        PolygonsSet polygon2 = new PolygonsSet(1.0e-10, q1, q2, q3, q4);

        // Combine boundaries
        Collection<SubHyperplane<Euclidean2D>> boundary = new ArrayList<>();
        boundary.addAll(polygon1.getTree(false).getAttribute().getSplitters());
        boundary.addAll(polygon2.getTree(false).getAttribute().getSplitters());

        PolygonsSet combined = new PolygonsSet(boundary, 1.0e-10);
        Vector2D[][] vertices = combined.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(2, vertices.length, "There should be two loops for multiple polygons");

        Vector2D[] loop1 = vertices[0];
        Vector2D[] loop2 = vertices[1];
        // Check first polygon
        assertEquals(4, loop1.length, "First polygon should have four vertices");
        assertTrue(Arrays.asList(loop1).containsAll(Arrays.asList(p1, p2, p3, p4)),
                "First polygon vertices mismatch");
        // Check second polygon
        assertEquals(4, loop2.length, "Second polygon should have four vertices");
        assertTrue(Arrays.asList(loop2).containsAll(Arrays.asList(q1, q2, q3, q4)),
                "Second polygon vertices mismatch");
    }

    @Test
    void testGetVerticesOpenLoop() {
        // Create a polygon set with an open loop
        // This requires manually constructing a BSPTree with an open loop
        // For simplicity, assume that such a BSPTree can be constructed accordingly

        // Construct a horizontal line from (0,0) to (10,0) with open ends
        Line line = new Line(new Vector2D(0, 0), new Vector2D(1, 0), 1.0e-10);
        SubHyperplane<Euclidean2D> sub = new AbstractSubHyperplane<Euclidean2D, Euclidean1D>(line) {
            @Override
            public double getSize() {
                return 10.0;
            }

            @Override
            public SubHyperplane<Euclidean2D> split(Hyperplane<Euclidean2D> hyperplane, double tolerance) {
                return null;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public SubHyperplane<Euclidean2D> copySelf() {
                return this;
            }
        };
        Collection<SubHyperplane<Euclidean2D>> boundary = Collections.singleton(sub);
        PolygonsSet polygonsSet = new PolygonsSet(boundary, 1.0e-10);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        // Since it's an open loop, it should start with null
        assertTrue(vertices.length >= 1, "There should be at least one loop");
        Vector2D[] loop = vertices[0];
        assertTrue(loop.length >= 3, "Open loop should have at least three elements");
        assertNull(loop[0], "First element should be null for open loop");
    }

    @Test
    void testGetVerticesDegeneratedLoop() {
        // Create a degenerated loop with two points and null start
        Vector2D dummy1 = new Vector2D(-1000, -1000);
        Vector2D dummy2 = new Vector2D(1000, 1000);
        PolygonsSet polygonsSet = new PolygonsSet(1.0e-10, null, dummy1, dummy2);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(1, vertices.length, "There should be one loop for degenerated loop");
        Vector2D[] loop = vertices[0];
        assertEquals(3, loop.length, "Degenerated loop should have three elements");
        assertNull(loop[0], "First element should be null for degenerated loop");
        assertEquals(dummy1, loop[1], "First dummy point mismatch");
        assertEquals(dummy2, loop[2], "Second dummy point mismatch");
    }

    @Test
    void testGetVerticesMultipleLoopsIncludingInfinite() {
        // Create a bounded square
        Vector2D s1 = new Vector2D(0, 0);
        Vector2D s2 = new Vector2D(0, 10);
        Vector2D s3 = new Vector2D(10, 10);
        Vector2D s4 = new Vector2D(10, 0);
        PolygonsSet square = new PolygonsSet(1.0e-10, s1, s2, s3, s4);

        // Create an infinite horizontal line
        Line line = new Line(new Vector2D(5, 5), new Vector2D(1, 0), 1.0e-10);
        Vector2D l1 = line.toSpace(new Vector1D(Double.NEGATIVE_INFINITY));
        Vector2D l2 = line.toSpace(new Vector1D(Double.POSITIVE_INFINITY));
        PolygonsSet infiniteLine = new PolygonsSet(1.0e-10, null, l1, l2);

        // Combine boundaries
        Collection<SubHyperplane<Euclidean2D>> boundary = new ArrayList<>();
        boundary.addAll(square.getTree(false).getAttribute().getSplitters());
        boundary.addAll(infiniteLine.getTree(false).getAttribute().getSplitters());

        PolygonsSet combined = new PolygonsSet(boundary, 1.0e-10);
        Vector2D[][] vertices = combined.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(2, vertices.length, "There should be two loops");

        // One loop is the square
        Vector2D[] loop1 = vertices[0];
        assertEquals(4, loop1.length, "Square should have four vertices");
        assertTrue(Arrays.asList(loop1).containsAll(Arrays.asList(s1, s2, s3, s4)),
                "Square vertices mismatch");

        // Second loop is the infinite line
        Vector2D[] loop2 = vertices[1];
        assertEquals(3, loop2.length, "Infinite line loop should have three elements");
        assertNull(loop2[0], "First element should be null for infinite line loop");
        assertEquals(l1, loop2[1], "Infinite line first dummy point mismatch");
        assertEquals(l2, loop2[2], "Infinite line second dummy point mismatch");
    }

    @Test
    void testGetVerticesNoLoops() {
        // Create a polygons set without any loops (empty boundary)
        Collection<SubHyperplane<Euclidean2D>> boundary = Collections.emptyList();
        PolygonsSet polygonsSet = new PolygonsSet(boundary, 1.0e-10);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(0, vertices.length, "Vertices array should be empty for no loops");
    }

    @Test
    void testGetVerticesLoopWithSpuriousVertices() {
        // Create a square with an extra spurious vertex on one side
        Vector2D v1 = new Vector2D(0, 0);
        Vector2D v2 = new Vector2D(5, 0);
        Vector2D v3 = new Vector2D(5, 0); // Spurious vertex
        Vector2D v4 = new Vector2D(5, 5);
        Vector2D v5 = new Vector2D(0, 5);
        PolygonsSet polygonsSet = new PolygonsSet(1.0e-10, v1, v2, v3, v4, v5);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(1, vertices.length, "There should be one loop for the polygon");
        Vector2D[] loop = vertices[0];
        assertEquals(4, loop.length, "Polygon should have four unique vertices after filtering spurious");
        assertTrue(Arrays.asList(loop).containsAll(Arrays.asList(v1, v2, v4, v5)),
                "Polygon vertices mismatch after filtering spurious vertices");
    }

    @Test
    void testGetVerticesNullInitialLoop() {
        // Create a polygons set with an initial null and valid vertices
        Vector2D dummy = null;
        Vector2D v1 = new Vector2D(1, 1);
        Vector2D v2 = new Vector2D(2, 2);
        PolygonsSet polygonsSet = new PolygonsSet(1.0e-10, dummy, v1, v2);
        Vector2D[][] vertices = polygonsSet.getVertices();
        assertNotNull(vertices, "Vertices should not be null");
        assertEquals(1, vertices.length, "There should be one loop");
        Vector2D[] loop = vertices[0];
        assertEquals(3, loop.length, "Loop should have three elements");
        assertNull(loop[0], "First element should be null for open loop");
        assertEquals(v1, loop[1], "First real vertex mismatch");
        assertEquals(v2, loop[2], "Second real vertex mismatch");
    }
}