package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class TarArchiveOutputStream_putArchiveEntry_0_1_Test {

    @Test
    @DisplayName("Ensure correct handling of a global PAX header entry.")
    public void testPutArchiveEntryGlobalPAXHeader() throws Exception {
        // Setup
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream stream = new TarArchiveOutputStream(baos);
        TarArchiveEntry entry = new TarArchiveEntry("globalPAXEntry");

        // Set global PAX header flag using reflection
        Field globalPaxHeaderField = TarArchiveEntry.class.getDeclaredField("globalPaxHeader");
        globalPaxHeaderField.setAccessible(true);
        globalPaxHeaderField.set(entry, true);

        // Invocation
        stream.putArchiveEntry(entry);

        // Assert (Making sure that the entry's closure processes correctly)
        stream.closeArchiveEntry(); // Corrected the logic to close without an assertion as IOException is our test signal.
    }

    @Test
    @DisplayName("Handle long file name with POSIX longfile mode.")
    public void testHandleLongFileNameWithPosixLongfileMode() throws Exception {
        // Setup
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream stream = new TarArchiveOutputStream(baos);

        // Correct method to set long file mode
        stream.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);

        // Create an entry with a long file name
        String longFileName = "a_very_long_file_name_exceeding_limit_to_trigger_PAX_header.txt";
        TarArchiveEntry entry = new TarArchiveEntry(longFileName);
        entry.setSize(512); // Set a valid size

        // Execute
        stream.putArchiveEntry(entry);

        // Assert
        assertTrue(baos.size() > 0, "PAX headers should include the long file name.");
    }

    @Test
    @DisplayName("Test exception on exceeding maximum big number with default big number mode.")
    public void testExceptionOnBigNumberDefaultMode() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream stream = new TarArchiveOutputStream(baos);

        TarArchiveEntry entry = new TarArchiveEntry("bigNumberEntry");
        entry.setSize(Long.MAX_VALUE); // Set size to a very large value

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            stream.putArchiveEntry(entry);
        });

        assertTrue(thrown.getMessage().contains("is too big ( > "), "Exception message should indicate a size limit exceedance.");
    }

    @Test
    @DisplayName("Successful writing of an entry when handling symbolic links.")
    public void testHandlingSymbolicLinks() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream stream = new TarArchiveOutputStream(baos);

        // Create a symbolic link entry
        TarArchiveEntry symLinkEntry = new TarArchiveEntry("symLinkEntry");
        symLinkEntry.setLinkName("targetLink");

        // Set symbolic link flag using reflection
        Field isSymbolicLinkField = TarArchiveEntry.class.getDeclaredField("symbolicLink");
        isSymbolicLinkField.setAccessible(true);
        isSymbolicLinkField.set(symLinkEntry, true);

        // Execute
        stream.putArchiveEntry(symLinkEntry);

        // Assume no exceptions represent success for symbolic link
        stream.closeArchiveEntry();
        assertTrue(baos.size() > 0, "A header for a symbolic link should be correctly written.");
    }

    @Test
    @DisplayName("Entry with non-ASCII characters in file names triggers PAX header.")
    public void testNonAsciiCharactersTriggersPAXHeader() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream stream = new TarArchiveOutputStream(baos);

        TarArchiveEntry entry = new TarArchiveEntry("\u6587\u4EF6.txt"); // non-ASCII characters

        // Set the flag to add PAX headers for non-ASCII using reflection
        stream.setAddPaxHeadersForNonAsciiNames(true);

        // Execute
        stream.putArchiveEntry(entry);

        // Assert
        stream.closeArchiveEntry(); // Ensure closure without throwing exception
        assertTrue(baos.size() > 0, "PAX headers should include the non-ASCII characters.");
    }
}