package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class ClusteredXYBarRendererTest {

    private ClusteredXYBarRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private int series;
    private int item;
    private CrosshairState crosshairState;
    private int pass;

    @BeforeEach
    void setUp() {
        renderer = new ClusteredXYBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        series = 0;
        item = 0;
        crosshairState = mock(CrosshairState.class);
        pass = 0;

        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
    }

    @Test
    void drawItem_ItemNotVisible_ShouldReturn() {
        renderer = spy(renderer);
        doReturn(false).when(renderer).getItemVisible(series, item);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer).getItemVisible(series, item);
        verifyNoMoreInteractions(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, crosshairState);
    }

    @Test
    void drawItem_UseYIntervalTrue_YValuesNotNaN() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(1.0);
        when(dataset.getEndYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));
        when(renderer.isShadowsVisible()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        verify(renderer).getUseYInterval();
        verify(dataset).getStartYValue(series, item);
        verify(dataset).getEndYValue(series, item);
        verify(dataset).getStartXValue(series, item);
        verify(dataset).getEndXValue(series, item);
    }

    @Test
    void drawItem_UseYIntervalFalse_YValuesNotNaN() {
        renderer = spy(renderer);
        doReturn(false).when(renderer).getUseYInterval();
        when(renderer.getBase()).thenReturn(0.0);
        when(dataset.getYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.isShadowsVisible()).thenReturn(false);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        verify(renderer).getUseYInterval();
        verify(renderer).getBase();
        verify(dataset).getYValue(series, item);
        verify(dataset).getStartXValue(series, item);
        verify(dataset).getEndXValue(series, item);
    }

    @Test
    void drawItem_YValuesNaN_ShouldReturn() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(series, item)).thenReturn(5.0);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer).getUseYInterval();
        verify(dataset).getStartYValue(series, item);
        verify(dataset).getEndYValue(series, item);
        verifyNoMoreInteractions(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, crosshairState);
    }

    @Test
    void drawItem_CenterBarAtStartValueTrue() {
        renderer = new ClusteredXYBarRenderer(0.0, true);
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(1.0);
        when(dataset.getEndYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));
        when(renderer.isShadowsVisible()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        verify(renderer).getItemVisible(series, item);
        verify(renderer).getUseYInterval();
        verify(dataset).getStartYValue(series, item);
        verify(dataset).getEndYValue(series, item);
        verify(dataset).getStartXValue(series, item);
        verify(dataset).getEndXValue(series, item);
        verify(domainAxis).valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM);
        verify(domainAxis).valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM);
    }

    @Test
    void drawItem_MarginGreaterThanZero() {
        renderer = spy(renderer);
        doReturn(false).when(renderer).getItemVisible(series, item);
        when(renderer.getMargin()).thenReturn(0.1);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
    }

    @Test
    void drawItem_OrientationHorizontal() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(1.0);
        when(dataset.getEndYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));
        when(renderer.isShadowsVisible()).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        verify(plot).getOrientation();
    }

    @Test
    void drawItem_PositiveY_InvertedAxis() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(1.0);
        when(dataset.getEndYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.isShadowsVisible()).thenReturn(false);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        ArgumentCaptor<Rectangle2D> captor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(g2, atLeast(0)).draw(captor.capture());
    }

    @Test
    void drawItem_Pass0_ShadowsVisible() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        when(renderer.isShadowsVisible()).thenReturn(true);
        when(renderer.getPassCount()).thenReturn(2);
        when(pass).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer).isShadowsVisible();
        // Further interactions would require more detailed setup
    }

    @Test
    void drawItem_Pass1_ItemLabelVisible() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(true).when(renderer).getUseYInterval();
        when(dataset.getStartYValue(series, item)).thenReturn(1.0);
        when(dataset.getEndYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        XYItemLabelGenerator generator = mock(XYItemLabelGenerator.class);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(generator);
        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        verify(renderer).isItemLabelVisible(series, item);
        verify(renderer).getItemLabelGenerator(series, item);
        verify(renderer).drawItemLabel(g2, dataset, series, item, plot, generator, any(Rectangle2D.class), anyBoolean());
    }

    @Test
    void drawItem_InfoNull_ShouldSkipEntity() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(false).when(renderer).getUseYInterval();
        when(renderer.getBase()).thenReturn(0.0);
        when(dataset.getYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.isShadowsVisible()).thenReturn(false);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, null, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        verify(info, never()).getOwner();
    }

    @Test
    void drawItem_EntityCollectionNull_ShouldNotAddEntity() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        doReturn(false).when(renderer).getUseYInterval();
        when(renderer.getBase()).thenReturn(0.0);
        when(dataset.getYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.isShadowsVisible()).thenReturn(false);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(info.getOwner().getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        verify(info.getOwner()).getEntityCollection();
    }

    @Test
    void drawItem_InvisibleSeries_ShouldNotDraw() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(renderer.isSeriesVisible(series)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        verify(renderer).isSeriesVisible(series);
        verifyNoMoreInteractions(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, crosshairState);
    }
    
    @Test
    void drawItem_NoVisibleSeries_ShouldNotDraw() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(dataset.getSeriesCount()).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Depending on implementation, verify appropriate interactions
    }
    
    @Test
    void drawItem_SeriesBarWidthZero_ShouldHandleGracefully() {
        renderer = spy(renderer);
        doReturn(true).when(renderer).getItemVisible(series, item);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(renderer.getBase()).thenReturn(0.0);
        when(dataset.getYValue(series, item)).thenReturn(5.0);
        when(dataset.getStartXValue(series, item)).thenReturn(10.0);
        when(dataset.getEndXValue(series, item)).thenReturn(10.0); // intervalW = 0
        when(rangeAxis.valueToJava2D(0.0, dataArea, RectangleEdge.LEFT)).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(series)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.isShadowsVisible()).thenReturn(false);
        when(renderer.getItemLabelGenerator(series, item)).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));

        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);

        // Verify that no exception is thrown and appropriate methods are called
    }

    @Test
    void drawItem_MultipleVisibleSeries_ShouldCalculateBarWidthCorrectly() {
        renderer = new ClusteredXYBarRenderer(0.0, false);
        renderer = spy(renderer);
        when(renderer.getMargin()).thenReturn(0.0);
        when(renderer.isSeriesVisible(anyInt())).thenReturn(true);
        when(dataset.getSeriesCount()).thenReturn(3);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(renderer.getUseYInterval()).thenReturn(false);
        when(renderer.getBase()).thenReturn(0.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.LEFT))).thenReturn(100.0);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPassCount()).thenReturn(2);
        when(renderer.isShadowsVisible()).thenReturn(false);
        when(renderer.getItemLabelGenerator(anyInt(), anyInt())).thenReturn(mock(XYItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(false);
        when(info.getOwner()).thenReturn(mock(PlotRenderingInfo.class));

        for (int s = 0; s < 3; s++) {
            renderer.drawItem(g2, state, dataArea, info, plot,
                    domainAxis, rangeAxis, dataset, s, item, crosshairState, 1);
        }

        // Verify that bar width is calculated as intervalW / numSeries = 100 / 3
    }
}