package org.jfree.chart.title;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.block.LengthConstraintType;
import org.jfree.chart.block.RectangleConstraint;
import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.jfree.data.Range;
import org.jfree.chart.text.TextUtils;

class ShortTextTitleTest {

    private ShortTextTitle title;
    private Graphics2D g2Mock;
    private RectangleConstraint constraintMock;
    private FontMetrics fontMetricsMock;

    @BeforeEach
    void setUp() {
        title = new ShortTextTitle("Test Title");
        g2Mock = mock(Graphics2D.class);
        constraintMock = mock(RectangleConstraint.class);
        fontMetricsMock = mock(FontMetrics.class);
        when(g2Mock.getFontMetrics(any(Font.class))).thenReturn(fontMetricsMock);
    }

    @Test
    void testArrange_WNone_HNone_ValidSize() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(100, size.getWidth());
        assertEquals(20, size.getHeight());
    }

    @Test
    void testArrange_WNone_HNone_InvalidSize() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, -10, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }

    @Test
    void testArrange_WRange_HNone_SizeWithinRange() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 150));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(100, size.getWidth());
        assertEquals(20, size.getHeight());
    }

    @Test
    void testArrange_WRange_HNone_SizeExceedsRange() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 90));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }

    @Test
    void testArrange_WRange_HRange_SizeWithinRanges() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 150));
        when(constraintMock.getHeightRange()).thenReturn(new Range(10, 30));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(100, size.getWidth());
        assertEquals(20, size.getHeight());
    }

    @Test
    void testArrange_WRange_HRange_SizeExceedsWidth() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 90));
        when(constraintMock.getHeightRange()).thenReturn(new Range(10, 30));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }

    @Test
    void testArrange_WRange_HRange_SizeExceedsHeight() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 150));
        when(constraintMock.getHeightRange()).thenReturn(new Range(10, 15));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }

    @Test
    void testArrange_WFixed_HNone_SizeFitsFixedWidth() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.FIXED);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidth()).thenReturn(100.0);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 90, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(100.0, size.getWidth());
        assertEquals(20.0, size.getHeight());
    }

    @Test
    void testArrange_WFixed_HNone_SizeExceedsFixedWidth() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.FIXED);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidth()).thenReturn(80.0);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 90, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }

    @Test
    void testArrange_WNone_HRange_NotImplemented() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.RANGE);
        
        assertThrows(RuntimeException.class, () -> {
            title.arrange(g2Mock, constraintMock);
        });
    }

    @Test
    void testArrange_WNone_HFixed_NotImplemented() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.FIXED);
        
        assertThrows(RuntimeException.class, () -> {
            title.arrange(g2Mock, constraintMock);
        });
    }

    @Test
    void testArrange_WRange_HFixed_NotImplemented() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.FIXED);
        
        assertThrows(RuntimeException.class, () -> {
            title.arrange(g2Mock, constraintMock);
        });
    }

    @Test
    void testArrange_WFixed_HRange_NotImplemented() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.FIXED);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.RANGE);
        
        assertThrows(RuntimeException.class, () -> {
            title.arrange(g2Mock, constraintMock);
        });
    }

    @Test
    void testArrange_WFixed_HFixed_NotImplemented() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.FIXED);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.FIXED);
        
        assertThrows(RuntimeException.class, () -> {
            title.arrange(g2Mock, constraintMock);
        });
    }

    @Test
    void testArrange_NullGraphics2D() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        
        assertThrows(NullPointerException.class, () -> {
            title.arrange(null, constraintMock);
        });
    }

    @Test
    void testArrange_NullConstraint() {
        g2Mock.setFont(title.getFont());
        when(g2Mock.getFontMetrics(any(Font.class))).thenReturn(fontMetricsMock);
        
        assertThrows(NullPointerException.class, () -> {
            title.arrange(g2Mock, null);
        });
    }

    @Test
    void testArrange_ArrangeRR_SizeWithin() {
        // Directly testing arrangeRR by setting up arrange implementation via arrange method
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 150));
        when(constraintMock.getHeightRange()).thenReturn(new Range(10, 30));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(100.0, size.getWidth());
        assertEquals(20.0, size.getHeight());
    }

    @Test
    void testArrange_ArrangeRR_SizeExceeds() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 90));
        when(constraintMock.getHeightRange()).thenReturn(new Range(10, 30));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }

    @Test
    void testArrange_ArrangeFN_SizeFits() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.FIXED);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidth()).thenReturn(100.0);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 100, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(100.0, size.getWidth());
        assertEquals(20.0, size.getHeight());
    }

    @Test
    void testArrange_ArrangeFN_SizeDoesNotFit() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.FIXED);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidth()).thenReturn(80.0);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 90, 20);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }

    @Test
    void testArrange_ArrangeNN_SizePositive() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 200, 40);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(200.0, size.getWidth());
        assertEquals(40.0, size.getHeight());
    }

    @Test
    void testArrange_ArrangeNN_SizeZero() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getHeightConstraintType()).toReturn(LengthConstraintType.NONE);
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 0, 0);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }
    
    @Test
    void testArrange_ArrangeRN_SizeWithin() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 150));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 120, 25);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        assertEquals(120.0, size.getWidth());
        assertEquals(25.0, size.getHeight());
    }
    
    @Test
    void testArrange_ArrangeRN_SizeConstrained() {
        when(constraintMock.getWidthConstraintType()).thenReturn(LengthConstraintType.RANGE);
        when(constraintMock.getHeightConstraintType()).thenReturn(LengthConstraintType.NONE);
        when(constraintMock.getWidthRange()).thenReturn(new Range(50, 100));
        
        Rectangle2D bounds = new Rectangle2D.Double(0, 0, 120, 25);
        when(TextUtils.getTextBounds(anyString(), eq(g2Mock), eq(fontMetricsMock))).thenReturn(bounds);
        
        Size2D size = title.arrange(g2Mock, constraintMock);
        
        // Since arrangeFN will be called with w = 100
        assertEquals(0.0, size.getWidth());
        assertEquals(0.0, size.getHeight());
    }
}