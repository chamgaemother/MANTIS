package org.apache.commons.jxpath.ri.parser;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.util.Vector;

public class XPathParser_generateParseException_0_1_Test {

    @Test
    @DisplayName("Initial call with jj_kind < 0 and no jj_la1 entries matching jj_gen")
    void TC01() throws Exception {
        // Instantiate XPathParser with a suitable constructor
        XPathParser parser = new XPathParser(new StringReader(""));

        // Set jj_kind to -1
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, -1);

        // Set jj_la1 to not match jj_gen
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jj_la1 = new int[39];
        for (int i = 0; i < jj_la1.length; i++) {
            jj_la1[i] = -1; // Assuming jj_gen is non-negative
        }
        jjLa1Field.set(parser, jj_la1);

        // Ensure jj_expentries is empty
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<int[]> jj_expentries = (Vector<int[]>) jjExpentriesField.get(parser);
        jj_expentries.clear();

        // Set token to a dummy Token instance
        Token dummyToken = new Token();
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        tokenField.set(parser, dummyToken);

        // Adjust tokenImage to match expected format
        Field tokenImageField = XPathParser.class.getDeclaredField("tokenImage");
        tokenImageField.setAccessible(true);
        String[] tokenImage = {"dummy"};
        tokenImageField.set(parser, tokenImage);

        // Call generateParseException
        ParseException parseException = parser.generateParseException();

        // Verify that exptokseq is empty
        Assertions.assertNotNull(parseException, "ParseException should not be null");

        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(parseException);
        Assertions.assertEquals(0, exptokseq.length, "exptokseq should be empty");
    }

    @Test
    @DisplayName("jj_kind >= 0 sets corresponding la1tokens and resets jj_kind")
    void TC02() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser(new StringReader(""));

        // Set jj_kind to 5
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, 5);

        // Set jj_gen to a specific value
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjGenField.setInt(parser, 100);

        // Set jj_la1[0] to match jj_gen
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jj_la1 = new int[39];
        jj_la1[0] = 100; // Match jj_gen
        // Initialize other entries to not match
        for (int i = 1; i < jj_la1.length; i++) {
            jj_la1[i] = -1;
        }
        jjLa1Field.set(parser, jj_la1);

        // Set jj_la1_0, jj_la1_1, jj_la1_2 with specific bits for i=0
        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        int[] jj_la1_0 = new int[39];
        jj_la1_0[0] = 0b00000000000000000000000000010000; // Bit 4 set
        jjLa1_0Field.set(parser, jj_la1_0);

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        int[] jj_la1_1 = new int[39];
        jj_la1_1[0] = 0b00000000000000000000000000100000; // Bit 5 set
        jjLa1_1Field.set(parser, jj_la1_1);

        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        int[] jj_la1_2 = new int[39];
        jj_la1_2[0] = 0b00000000000000000000000001000000; // Bit 6 set
        jjLa1_2Field.set(parser, jj_la1_2);

        // Initialize jj_expentries
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<int[]> jj_expentries = (Vector<int[]>) jjExpentriesField.get(parser);
        jj_expentries.clear();

        // Set token and tokenImage
        Token dummyToken = new Token();
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        tokenField.set(parser, dummyToken);

        Field tokenImageField = XPathParser.class.getDeclaredField("tokenImage");
        tokenImageField.setAccessible(true);
        String[] tokenImage = {"dummy"};
        tokenImageField.set(parser, tokenImage);

        // Call generateParseException
        ParseException parseException = parser.generateParseException();

        // Verify that la1tokens[5] is true and exptokseq contains the correct tokens
        Assertions.assertNotNull(parseException, "ParseException should not be null");

        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(parseException);

        // Expecting tokens from jj_kind and jj_la1 entries
        Assertions.assertEquals(4, exptokseq.length, "exptokseq should contain tokens from jj_kind and jj_la1 entries");

        // Further assertions can be added based on the exact expected tokens
    }

    @Test
    @DisplayName("jj_la1[i] equals jj_gen triggers setting la1tokens for multiple j")
    void TC03() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser(new StringReader(""));

        // Set jj_gen to 200
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjGenField.setInt(parser, 200);

        // Set jj_la1[10] = jj_gen
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jj_la1 = new int[39];
        jj_la1[10] = 200; // Match jj_gen
        // Initialize other entries to not match
        for (int i = 0; i < jj_la1.length; i++) {
            if (i != 10) {
                jj_la1[i] = -1;
            }
        }
        jjLa1Field.set(parser, jj_la1);

        // Set jj_la1_0 and jj_la1_1 with multiple bits set for i=10
        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        int[] jj_la1_0 = new int[39];
        jj_la1_0[10] = 0b00000000000000000000000000010010; // Bits 1 and 4 set
        jjLa1_0Field.set(parser, jj_la1_0);

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        int[] jj_la1_1 = new int[39];
        jj_la1_1[10] = 0b00000000000000000000000000100100; // Bits 2 and 5 set
        jjLa1_1Field.set(parser, jj_la1_1);

        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        int[] jj_la1_2 = new int[39];
        jj_la1_2[10] = 0b00000000000000000000000001001000; // Bits 3 and 6 set
        jjLa1_2Field.set(parser, jj_la1_2);

        // Initialize jj_expentries
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<int[]> jj_expentries = (Vector<int[]>) jjExpentriesField.get(parser);
        jj_expentries.clear();

        // Set token and tokenImage
        Token dummyToken = new Token();
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        tokenField.set(parser, dummyToken);

        Field tokenImageField = XPathParser.class.getDeclaredField("tokenImage");
        tokenImageField.setAccessible(true);
        String[] tokenImage = {"dummy"};
        tokenImageField.set(parser, tokenImage);

        // Call generateParseException
        ParseException parseException = parser.generateParseException();

        // Verify that multiple tokens are set from jj_la1 entries
        Assertions.assertNotNull(parseException, "ParseException should not be null");

        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(parseException);

        // Expected tokens from jj_kind and jj_la1 entries
        Assertions.assertEquals(7, exptokseq.length, "exptokseq should contain multiple tokens from jj_la1 entries");

        // Further assertions can be added based on the exact expected tokens
    }

    @Test
    @DisplayName("No jj_la1 entries match jj_gen, jj_kind >= 0")
    void TC04() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser(new StringReader(""));

        // Set jj_kind to 10
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, 10);

        // Set jj_gen to a value that jj_la1 does not match
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjGenField.setInt(parser, 300);

        // Set jj_la1 to not match jj_gen
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jj_la1 = new int[39];
        for (int i = 0; i < jj_la1.length; i++) {
            jj_la1[i] = -1;
        }
        jjLa1Field.set(parser, jj_la1);

        // Initialize jj_la1_0, jj_la1_1, jj_la1_2 with no bits set for any i
        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        int[] jj_la1_0 = new int[39];
        jjLa1_0Field.set(parser, jj_la1_0);

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        int[] jj_la1_1 = new int[39];
        jjLa1_1Field.set(parser, jj_la1_1);

        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        int[] jj_la1_2 = new int[39];
        jjLa1_2Field.set(parser, jj_la1_2);

        // Initialize jj_expentries
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<int[]> jj_expentries = (Vector<int[]>) jjExpentriesField.get(parser);
        jj_expentries.clear();

        // Set token and tokenImage
        Token dummyToken = new Token();
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        tokenField.set(parser, dummyToken);

        Field tokenImageField = XPathParser.class.getDeclaredField("tokenImage");
        tokenImageField.setAccessible(true);
        String[] tokenImage = {"dummy"};
        tokenImageField.set(parser, tokenImage);

        // Call generateParseException
        ParseException parseException = parser.generateParseException();

        // Verify that only the token from jj_kind is included
        Assertions.assertNotNull(parseException, "ParseException should not be null");

        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(parseException);

        Assertions.assertEquals(1, exptokseq.length, "exptokseq should contain only the token from jj_kind");
        Assertions.assertEquals(10, exptokseq[0][0], "The token should be from jj_kind and equal to 10");
    }

    @Test
    @DisplayName("jj_la1[i] != jj_gen skips setting la1tokens")
    void TC05() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser(new StringReader(""));

        // Set jj_gen to a value
        Field jjGenField = XPathParser.class.getDeclaredField("jj_gen");
        jjGenField.setAccessible(true);
        jjGenField.setInt(parser, 400);

        // Set jj_la1[15] != jj_gen
        Field jjLa1Field = XPathParser.class.getDeclaredField("jj_la1");
        jjLa1Field.setAccessible(true);
        int[] jj_la1 = new int[39];
        jj_la1[15] = 500; // Not equal to jj_gen
        // Initialize other entries as needed
        jjLa1Field.set(parser, jj_la1);

        // Initialize jj_la1_0, jj_la1_1, jj_la1_2 with no matching bits for i=15
        Field jjLa1_0Field = XPathParser.class.getDeclaredField("jj_la1_0");
        jjLa1_0Field.setAccessible(true);
        int[] jj_la1_0 = new int[39];
        jj_la1_0[15] = 0;
        jjLa1_0Field.set(parser, jj_la1_0);

        Field jjLa1_1Field = XPathParser.class.getDeclaredField("jj_la1_1");
        jjLa1_1Field.setAccessible(true);
        int[] jj_la1_1 = new int[39];
        jj_la1_1[15] = 0;
        jjLa1_1Field.set(parser, jj_la1_1);

        Field jjLa1_2Field = XPathParser.class.getDeclaredField("jj_la1_2");
        jjLa1_2Field.setAccessible(true);
        int[] jj_la1_2 = new int[39];
        jj_la1_2[15] = 0;
        jjLa1_2Field.set(parser, jj_la1_2);

        // Initialize jj_expentries
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        Vector<int[]> jj_expentries = (Vector<int[]>) jjExpentriesField.get(parser);
        jj_expentries.clear();

        // Set jj_kind to a value >= 0 to include its token
        Field jjKindField = XPathParser.class.getDeclaredField("jj_kind");
        jjKindField.setAccessible(true);
        jjKindField.setInt(parser, 20);

        // Set token and tokenImage
        Token dummyToken = new Token();
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        tokenField.set(parser, dummyToken);

        Field tokenImageField = XPathParser.class.getDeclaredField("tokenImage");
        tokenImageField.setAccessible(true);
        String[] tokenImage = {"dummy"};
        tokenImageField.set(parser, tokenImage);

        // Call generateParseException
        ParseException parseException = parser.generateParseException();

        // Verify that no tokens are set from jj_la1 and only jj_kind token is present
        Assertions.assertNotNull(parseException, "ParseException should not be null");

        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(parseException);

        Assertions.assertEquals(1, exptokseq.length, "exptokseq should contain only the token from jj_kind");
        Assertions.assertEquals(20, exptokseq[0][0], "The token should be from jj_kind and equal to 20");
    }

}