package org.apache.commons.csv;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CSVFormat_toString_0_4_Test {

    @Test
    @DisplayName("toString() with no fields set")
    public void TC16_toString_with_no_fields_set() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT;

        // WHEN
        String result = format.toString();

        // THEN
        assertTrue(result.contains("Delimiter=<,>"), "Result should contain the default delimiter");
        assertFalse(result.contains("Escape=<"), "Result should not contain Escape when not set");
        assertFalse(result.contains("QuoteChar=<"), "Result should not contain QuoteChar when not set");
        assertFalse(result.contains("QuoteMode=<"), "Result should not contain QuoteMode when not set");
        assertFalse(result.contains("CommentStart=<"), "Result should not contain CommentStart when not set");
        assertFalse(result.contains("NullString=<"), "Result should not contain NullString when not set");
        assertFalse(result.contains("RecordSeparator=<"), "Result should not contain RecordSeparator when not set");
        assertFalse(result.contains("EmptyLines:ignored"), "Result should not indicate that empty lines are ignored by default");
        assertTrue(result.contains("SurroundingSpaces:ignored"), "Result should indicate that surrounding spaces are ignored by default");
        assertFalse(result.contains("IgnoreHeaderCase:ignored"), "Result should not indicate that header case is ignored by default");
        assertTrue(result.contains("SkipHeaderRecord:false"), "Result should indicate that header record is not skipped by default");
        assertFalse(result.contains("HeaderComments:"), "Result should not contain HeaderComments when not set");
        assertFalse(result.contains("Header:"), "Result should not contain Header when not set");
    }

    @Test
    @DisplayName("toString() with some fields explicitly set to null")
    public void TC17_toString_with_some_fields_explicitly_set_to_null() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .withDelimiter(',')
                .withEscape(null)
                .withQuote(null)
                .withQuoteMode(null)
                .withCommentMarker(null)
                .withNullString(null)
                .withRecordSeparator(null)
                .withIgnoreEmptyLines(false)
                .withIgnoreSurroundingSpaces(true)
                .withIgnoreHeaderCase(false)
                .withSkipHeaderRecord(false)
                .withHeaderComments((String[]) null)
                .withHeader((String[]) null);

        // WHEN
        String result = format.toString();

        // THEN
        assertTrue(result.contains("Delimiter=<,>"), "Result should contain the delimiter");
        assertFalse(result.contains("Escape=<"), "Result should not contain Escape when set to null");
        assertFalse(result.contains("QuoteChar=<"), "Result should not contain QuoteChar when set to null");
        assertFalse(result.contains("QuoteMode=<"), "Result should not contain QuoteMode when set to null");
        assertFalse(result.contains("CommentStart=<"), "Result should not contain CommentStart when set to null");
        assertFalse(result.contains("NullString=<"), "Result should not contain NullString when set to null");
        assertFalse(result.contains("RecordSeparator=<"), "Result should not contain RecordSeparator when set to null");
        assertTrue(result.contains("EmptyLines:ignored"), "Result should indicate that empty lines are ignored");
        assertTrue(result.contains("SurroundingSpaces:ignored"), "Result should indicate that surrounding spaces are ignored");
        assertFalse(result.contains("IgnoreHeaderCase:ignored"), "Result should not indicate that header case is ignored");
        assertTrue(result.contains("SkipHeaderRecord:false"), "Result should indicate that header record is not skipped");
        assertFalse(result.contains("HeaderComments:"), "Result should not contain HeaderComments when set to null");
        assertFalse(result.contains("Header:"), "Result should not contain Header when set to null");
    }
}
