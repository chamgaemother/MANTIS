package org.joda.time.tz;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ZoneInfoCompiler_parseDataFile_2_2_Test {

    @Test
    @DisplayName("parseDataFile processes LINK_LOOKUP with 'backward' flag true and non-special alias, expecting addition to iBackLinks")
    public void TC33_parseDataFile_linkLookup_backwardTrue_nonSpecialAlias() throws Exception {
        // Arrange
        String input = "Link RealABC ABC";
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean backward = true;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Add 'link' to LINK_LOOKUP via reflection
        Field linkLookupField = ZoneInfoCompiler.class.getDeclaredField("LINK_LOOKUP");
        linkLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> LINK_LOOKUP = (Set<String>) linkLookupField.get(null);
        LINK_LOOKUP.add("link");

        // Act
        compiler.parseDataFile(in, backward);

        // Assert
        Field iBackLinksField = ZoneInfoCompiler.class.getDeclaredField("iBackLinks");
        iBackLinksField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> iBackLinks = (List<String>) iBackLinksField.get(compiler);
        assertTrue(iBackLinks.contains("RealABC"), "iBackLinks should contain 'RealABC'");
        assertTrue(iBackLinks.contains("ABC"), "iBackLinks should contain 'ABC'");
    }

//     @Test
//     @DisplayName("parseDataFile processes RULE_LOOKUP line with valid tokens and multiple rules, expecting all rules are added")
//     public void TC34_parseDataFile_ruleLookup_multipleRules() throws Exception {
        // Arrange
//         String input = "rule summer 1980 2000 - Mar 21 2:00 1:00 S\nrule summer 2001 2020 - Sep 21 2:00 0:00 S";
//         BufferedReader in = new BufferedReader(new StringReader(input));
//         boolean backward = false;
//         ZoneInfoCompiler compiler = new ZoneInfoCompiler();
// 
        // Add 'summer' to RULE_LOOKUP via reflection
//         Field ruleLookupField = ZoneInfoCompiler.class.getDeclaredField("RULE_LOOKUP");
//         ruleLookupField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Set<String> RULE_LOOKUP = (Set<String>) ruleLookupField.get(null);
//         RULE_LOOKUP.add("summer");
// 
        // Act
//         compiler.parseDataFile(in, backward);
// 
        // Assert
//         Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
//         iRuleSetsField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Map<String, ZoneInfoCompiler.RuleSet> iRuleSets = (Map<String, ZoneInfoCompiler.RuleSet>) iRuleSetsField.get(compiler);
//         assertTrue(iRuleSets.containsKey("summer"), "iRuleSets should contain 'summer'");
//         ZoneInfoCompiler.RuleSet summerRuleSet = iRuleSets.get("summer");
//         assertNotNull(summerRuleSet, "summer RuleSet should not be null");
        // Access the private 'iRules' field within RuleSet
//         Field rulesField = ZoneInfoCompiler.RuleSet.class.getDeclaredField("iRules");
//         rulesField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         List<ZoneInfoCompiler.Rule> rules = (List<ZoneInfoCompiler.Rule>) rulesField.get(summerRuleSet);
//         assertEquals(2, rules.size(), "summer RuleSet should contain 2 rules");
//     }

    @Test
    @DisplayName("parseDataFile processes ZONE_LOOKUP line with missing tokens after 'Link', expecting IllegalArgumentException")
    public void TC35_parseDataFile_linkLookup_missingAlias() throws Exception {
        // Arrange
        String input = "Link RealABC"; // Missing alias
        BufferedReader in = new BufferedReader(new StringReader(input));
        boolean backward = false;
        ZoneInfoCompiler compiler = new ZoneInfoCompiler();

        // Add 'link' to LINK_LOOKUP via reflection
        Field linkLookupField = ZoneInfoCompiler.class.getDeclaredField("LINK_LOOKUP");
        linkLookupField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Set<String> LINK_LOOKUP = (Set<String>) linkLookupField.get(null);
        LINK_LOOKUP.add("link");

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            compiler.parseDataFile(in, backward);
        }, "Expected parseDataFile to throw IllegalArgumentException due to missing alias");
    }

//     @Test
//     @DisplayName("parseDataFile processes multiple lines with mixed valid and invalid tokens, expecting partial processing and exceptions")
//     public void TC36_parseDataFile_mixedValidAndInvalidLines() throws Exception {
        // Arrange
//         String input = "rule summer 1980 2000 - Mar 21 2:00 1:00 S\nEurope/London GMT0 Extra\nrule summer abc def - Sep 21 2:00 0:00 S";
//         BufferedReader in = new BufferedReader(new StringReader(input));
//         boolean backward = false;
//         ZoneInfoCompiler compiler = new ZoneInfoCompiler();
// 
        // Add 'summer' to RULE_LOOKUP and 'europe/london' to ZONE_LOOKUP via reflection
//         Field ruleLookupField = ZoneInfoCompiler.class.getDeclaredField("RULE_LOOKUP");
//         ruleLookupField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Set<String> RULE_LOOKUP = (Set<String>) ruleLookupField.get(null);
//         RULE_LOOKUP.add("summer");
// 
//         Field zoneLookupField = ZoneInfoCompiler.class.getDeclaredField("ZONE_LOOKUP");
//         zoneLookupField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Set<String> ZONE_LOOKUP = (Set<String>) zoneLookupField.get(null);
//         ZONE_LOOKUP.add("europe/london");
// 
        // Act
//         Exception exception = null;
//         try {
//             compiler.parseDataFile(in, backward);
//         } catch (Exception e) {
//             exception = e;
//         }
// 
        // Assert
        // Verify that 'summer' rule was partially added before exception
//         Field iRuleSetsField = ZoneInfoCompiler.class.getDeclaredField("iRuleSets");
//         iRuleSetsField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         Map<String, ZoneInfoCompiler.RuleSet> iRuleSets = (Map<String, ZoneInfoCompiler.RuleSet>) iRuleSetsField.get(compiler);
//         assertTrue(iRuleSets.containsKey("summer"), "iRuleSets should contain 'summer'");
//         ZoneInfoCompiler.RuleSet summerRuleSet = iRuleSets.get("summer");
//         assertNotNull(summerRuleSet, "summer RuleSet should not be null");
//         Field rulesField = ZoneInfoCompiler.RuleSet.class.getDeclaredField("iRules");
//         rulesField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         List<ZoneInfoCompiler.Rule> rules = (List<ZoneInfoCompiler.Rule>) rulesField.get(summerRuleSet);
//         assertEquals(1, rules.size(), "summer RuleSet should contain 1 valid rule before exception");
// 
        // Verify that 'Europe/London' zone was added correctly
//         Field iZonesField = ZoneInfoCompiler.class.getDeclaredField("iZones");
//         iZonesField.setAccessible(true);
//         @SuppressWarnings("unchecked")
//         List<ZoneInfoCompiler.Zone> iZones = (List<ZoneInfoCompiler.Zone>) iZonesField.get(compiler);
//         assertTrue(iZones.stream().anyMatch(zone -> zone.iName.equals("Europe/London")), "iZones should contain 'Europe/London'");
//         
        // Verify that an exception was thrown for the invalid RULE_LOOKUP line
//         assertNotNull(exception, "Expected an exception due to invalid RULE_LOOKUP line");
//         assertTrue(exception instanceof IllegalArgumentException, "Expected IllegalArgumentException");
//     }

}