package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;

/**
 * Generated JUnit 5 tests for the multiply method in org.apache.commons.math3.dfp.Dfp class.
 */
public class Dfp_multiply_0_5_Test {

    @Test
    @DisplayName("Multiplying Dfp numbers with one iteration in the multiplication loop")
    public void TC21() {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 2);
        Dfp b = new Dfp(field, 3);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        Dfp expected = new Dfp(field, 6);
        assertEquals(expected, result, "Multiplication result should be equal to expected single step product.");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers with multiple iterations in the multiplication loop")
    public void TC22() {
        // GIVEN
        DfpField field = new DfpField(15);
        Dfp a = new Dfp(field, 12345);
        Dfp b = new Dfp(field, 67890);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        Dfp expected = new Dfp(field, 838102050);
        assertEquals(expected, result, "Multiplication result should be equal to expected multi-step product.");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers where both operands are zero")
    public void TC23() {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 0);
        Dfp b = new Dfp(field, 0);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertTrue(result.isZero(), "Multiplying two zero Dfp numbers should result in zero.");
    }

    @Test
    @DisplayName("Multiplying a Dfp number by one, expecting the same number")
    public void TC24() {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 12345);
        Dfp one = new Dfp(field, 1);

        // WHEN
        Dfp result = a.multiply(one);

        // THEN
        assertEquals(a, result, "Multiplying by one should return the original Dfp number unchanged.");
    }

    @Test
    @DisplayName("Multiplying a Dfp number by negative one, expecting negation")
    public void TC25() {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 12345);
        Dfp negOne = new Dfp(field, -1);

        // WHEN
        Dfp result = a.multiply(negOne);

        // THEN
        Dfp expected = a.negate();
        assertEquals(expected, result, "Multiplying by negative one should negate the original Dfp number.");
    }
}