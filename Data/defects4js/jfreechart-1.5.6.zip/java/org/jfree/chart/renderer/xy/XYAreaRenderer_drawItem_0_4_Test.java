package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYAreaRenderer_drawItem_0_4_Test {

//     @Test
//     @DisplayName("Does not draw outline when isOutline() returns false")
//     void TC16_outlineDrawingDisabled() {
        // Arrange
//         XYAreaRenderer renderer = new XYAreaRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYAreaRenderer.XYAreaRendererState state = renderer.new XYAreaRendererState(new PlotRenderingInfo(null));
//         Rectangle2D dataArea = new Rectangle2D.Double();
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
        // Verify that no outline was drawn
//         verify(g2, never()).draw(any(java.awt.Shape.class));
//     }

//     @Test
//     @DisplayName("Handles entity collection when info is not null and shape is not null")
//     void TC17_entityCollectionWithValidShape() {
        // Arrange
//         XYAreaRenderer renderer = new XYAreaRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYAreaRenderer.XYAreaRendererState state = renderer.new XYAreaRendererState(new PlotRenderingInfo(null));
//         Rectangle2D dataArea = new Rectangle2D.Double();
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         EntityCollection entities = new EntityCollection();
        // Fix: Correct mock call on info for getEntityCollection
//         when(info.getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int series = 1;
//         int item = 1;
//         int pass = 1;
// 
        // Mock dataset values
//         when(dataset.getXValue(series, item)).thenReturn(10.0);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
        // Verify that the entity collection is not empty when a valid shape is involved
//         assertFalse(entities.isEmpty(), "Entity should be added to the collection");
//     }

//     @Test
//     @DisplayName("Does not add entity when shape is null")
//     void TC18_entityCollectionWithNullShape() {
        // Arrange
//         XYAreaRenderer renderer = new XYAreaRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYAreaRenderer.XYAreaRendererState state = renderer.new XYAreaRendererState(new PlotRenderingInfo(null));
//         Rectangle2D dataArea = new Rectangle2D.Double();
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         EntityCollection entities = new EntityCollection();
//         when(info.getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int series = 1;
//         int item = 1;
//         int pass = 1;
// 
        // Mock dataset values
//         when(dataset.getXValue(series, item)).thenReturn(10.0);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
        // Verify that the entity collection remains empty when no valid shape is involved
//         assertTrue(entities.isEmpty(), "No entity should be added when shape is null");
//     }

//     @Test
//     @DisplayName("Handles empty data area hotspot intersection")
//     void TC19_emptyDataAreaHotspot() {
        // Arrange
//         XYAreaRenderer renderer = new XYAreaRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYAreaRenderer.XYAreaRendererState state = renderer.new XYAreaRendererState(new PlotRenderingInfo(null));
//         Rectangle2D dataArea = new Rectangle2D.Double();
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         EntityCollection entities = new EntityCollection();
//         when(info.getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int series = 2;
//         int item = 2;
//         int pass = 1;
// 
        // Mock dataset values
//         when(dataset.getXValue(series, item)).thenReturn(15.0);
//         when(dataset.getYValue(series, item)).thenReturn(25.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
        // Verify that the entity collection remains empty when the intersection of the hotspot is empty
//         assertTrue(entities.isEmpty(), "No entity should be added when hotspot intersection is empty");
//     }

//     @Test
//     @DisplayName("Handles tooltip generation when tooltip generator is present")
//     void TC20_tooltipGenerationWithGenerator() {
        // Arrange
//         XYAreaRenderer renderer = new XYAreaRenderer();
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYAreaRenderer.XYAreaRendererState state = renderer.new XYAreaRendererState(new PlotRenderingInfo(null));
//         Rectangle2D dataArea = new Rectangle2D.Double();
//         PlotRenderingInfo info = new PlotRenderingInfo(null);
//         EntityCollection entities = new EntityCollection();
//         when(info.getEntityCollection()).thenReturn(entities);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         int series = 3;
//         int item = 3;
//         int pass = 1;
// 
        // Mock dataset values
//         when(dataset.getXValue(series, item)).thenReturn(20.0);
//         when(dataset.getYValue(series, item)).thenReturn(30.0);
// 
        // Mock tooltip generator
//         XYToolTipGenerator tooltipGenerator = mock(XYToolTipGenerator.class);
//         when(tooltipGenerator.generateToolTip(dataset, series, item)).thenReturn("Tooltip Text");
//         renderer.setDefaultToolTipGenerator(tooltipGenerator);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
        // Verify that the entity collection is not empty and the tooltip text is as expected
//         assertFalse(entities.isEmpty(), "Entity should be added to the collection");
//         XYItemEntity entity = (XYItemEntity) entities.getEntity(0);
//         assertEquals("Tooltip Text", entity.getToolTipText(), "Tooltip should match the generated text");
//     }
}