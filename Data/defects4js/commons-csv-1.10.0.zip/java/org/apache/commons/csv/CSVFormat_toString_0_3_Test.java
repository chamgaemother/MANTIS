package org.apache.commons.csv;

import org.apache.commons.csv.CSVFormat;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CSVFormat_toString_0_3_Test {

    @Test
    @DisplayName("toString() with ignoreHeaderCase enabled")
    void TC11() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withIgnoreHeaderCase(true);
        // WHEN
        String result = format.toString();
        // THEN
        assertTrue(result.contains("IgnoreHeaderCase:ignored"));
    }

    @Test
    @DisplayName("toString() with skipHeaderRecord set to true")
    void TC12() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withSkipHeaderRecord(true);
        // WHEN
        String result = format.toString();
        // THEN
        assertTrue(result.contains("SkipHeaderRecord:true"));
    }

    @Test
    @DisplayName("toString() with headerComments and headers set")
    void TC13() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .withHeaderComments("Comment1", "Comment2")
                .withHeader("Header1", "Header2");
        // WHEN
        String result = format.toString();
        // THEN
        assertTrue(result.contains("HeaderComments:[Comment1, Comment2]"));
        assertTrue(result.contains("Header:[Header1, Header2]"));
    }

    @Test
    @DisplayName("toString() with multiple optional fields set selectively")
    void TC14() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT
                .withDelimiter(';')
                .withQuote('"') // Corrected to use double quotes properly
                .withNullString("N/A")
                .withHeader("Column1", "Column2");
        // WHEN
        String result = format.toString();
        // THEN
        assertTrue(result.contains("Delimiter=<;>"));
        assertTrue(result.contains("QuoteChar=<\">") ); // Updated assertion to correctly format it 
        assertTrue(result.contains("NullString=<N/A>"));
        assertTrue(result.contains("Header:[Column1, Column2]"));
    }

    @Test
    @DisplayName("toString() with recordSeparator unset")
    void TC15() {
        // GIVEN
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',');
        // WHEN
        String result = format.toString();
        // THEN
        assertFalse(result.contains("RecordSeparator=<"));
    }
}