package com.fasterxml.jackson.databind.introspect;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.PropertyName;
import java.lang.reflect.Field;

public class POJOPropertyBuilder_removeNonVisible_2_1_Test {

    @Test
    @DisplayName("removeNonVisible with access type READ_WRITE ensures no trimming is performed")
    public void TC17_removeNonVisible_READ_WRITE_no_trimming() throws Exception {
        // Arrange
        MapperConfig<?> mockConfig = Mockito.mock(MapperConfig.class);
        AnnotationIntrospector mockIntrospector = Mockito.mock(AnnotationIntrospector.class);
        PropertyName internalName = new PropertyName("testProperty");
        
        POJOPropertyBuilder builder = new POJOPropertyBuilder(mockConfig, mockIntrospector, true, internalName);
        
        // Use reflection to access private fields
        Class<?> clazz = POJOPropertyBuilder.class;
        Field gettersField = clazz.getDeclaredField("_getters");
        gettersField.setAccessible(true);
        Object initialGetters = gettersField.get(builder);
        
        Field settersField = clazz.getDeclaredField("_setters");
        settersField.setAccessible(true);
        Object initialSetters = settersField.get(builder);
        
        Field fieldsField = clazz.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        Object initialFields = fieldsField.get(builder);
        
        Field ctorParamsField = clazz.getDeclaredField("_ctorParameters");
        ctorParamsField.setAccessible(true);
        Object initialCtorParams = ctorParamsField.get(builder);
        
        // Act
        Access result = builder.removeNonVisible(true, null);
        
        // Assert
        assertEquals(Access.READ_WRITE, result, "The access type should be READ_WRITE");
        assertSame(initialGetters, gettersField.get(builder), "_getters should remain unchanged");
        assertSame(initialSetters, settersField.get(builder), "_setters should remain unchanged");
        assertSame(initialFields, fieldsField.get(builder), "_fields should remain unchanged");
        assertSame(initialCtorParams, ctorParamsField.get(builder), "_ctorParameters should remain unchanged");
    }

    @Test
    @DisplayName("removeNonVisible with access type READ_WRITE and _forSerialization is false ensures no trimming is performed")
    public void TC18_removeNonVisible_READ_WRITE_no_trimming_false() throws Exception {
        // Arrange
        MapperConfig<?> mockConfig = Mockito.mock(MapperConfig.class);
        AnnotationIntrospector mockIntrospector = Mockito.mock(AnnotationIntrospector.class);
        PropertyName internalName = new PropertyName("testProperty");
        
        POJOPropertyBuilder builder = new POJOPropertyBuilder(mockConfig, mockIntrospector, false, internalName);
        
        // Use reflection to access private fields
        Class<?> clazz = POJOPropertyBuilder.class;
        Field gettersField = clazz.getDeclaredField("_getters");
        gettersField.setAccessible(true);
        Object initialGetters = gettersField.get(builder);
        
        Field settersField = clazz.getDeclaredField("_setters");
        settersField.setAccessible(true);
        Object initialSetters = settersField.get(builder);
        
        Field fieldsField = clazz.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        Object initialFields = fieldsField.get(builder);
        
        Field ctorParamsField = clazz.getDeclaredField("_ctorParameters");
        ctorParamsField.setAccessible(true);
        Object initialCtorParams = ctorParamsField.get(builder);
        
        // Act
        Access result = builder.removeNonVisible(false, null);
        
        // Assert
        assertEquals(Access.READ_WRITE, result, "The access type should be READ_WRITE");
        assertSame(initialGetters, gettersField.get(builder), "_getters should remain unchanged");
        assertSame(initialSetters, settersField.get(builder), "_setters should remain unchanged");
        assertSame(initialFields, fieldsField.get(builder), "_fields should remain unchanged");
        assertSame(initialCtorParams, ctorParamsField.get(builder), "_ctorParameters should remain unchanged");
    }
}