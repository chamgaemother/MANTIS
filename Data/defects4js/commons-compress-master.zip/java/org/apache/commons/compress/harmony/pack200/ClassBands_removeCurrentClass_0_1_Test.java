package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class ClassBands_removeCurrentClass_0_1_Test {

    @Test
    @DisplayName("Only class_flags[index] bit17 is set; tempFieldFlags and tempMethodFlags are empty")
    public void TC01() throws Exception {
        // Initialize ClassBands instance
        ClassBands classBands = new ClassBands();

        // Access and set 'index' field
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        int index = 0;
        indexField.setInt(classBands, index);

        // Access and set 'class_flags' array
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L};
        classFlags[index] = 1L << 17; // Set bit17
        classFlagsField.set(classBands, classFlags);

        // Access and initialize 'classSourceFile' list
        Field classSourceFileField = ClassBands.class.getDeclaredField("classSourceFile");
        classSourceFileField.setAccessible(true);
        List<String> classSourceFile = new ArrayList<>();
        classSourceFile.add("SourceFile1.java");
        classSourceFile.add("SourceFile2.java");
        classSourceFileField.set(classBands, classSourceFile);

        // Ensure 'tempFieldFlags' and 'tempMethodFlags' are empty
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlagsField.set(classBands, tempFieldFlags);

        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Invoke 'removeCurrentClass' method
        classBands.removeCurrentClass();

        // Assert 'classSourceFile' has its last element removed
        Assertions.assertEquals(1, classSourceFile.size(), "classSourceFile should have one element after removal");
        Assertions.assertEquals("SourceFile1.java", classSourceFile.get(0), "Remaining source file should be 'SourceFile1.java'");
        
        // Ensure other lists remain unchanged
        // Example: 'classEnclosingMethodClass' should remain the same
        Field classEnclosingMethodClassField = ClassBands.class.getDeclaredField("classEnclosingMethodClass");
        classEnclosingMethodClassField.setAccessible(true);
        List<String> classEnclosingMethodClass = (List<String>) classEnclosingMethodClassField.get(classBands);
        Assertions.assertTrue(classEnclosingMethodClass.isEmpty(), "classEnclosingMethodClass should remain unchanged");
    }

    @Test
    @DisplayName("Only class_flags[index] bit18 is set; tempFieldFlags and tempMethodFlags are empty")
    public void TC02() throws Exception {
        // Initialize ClassBands instance
        ClassBands classBands = new ClassBands();

        // Access and set 'index' field
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        int index = 0;
        indexField.setInt(classBands, index);

        // Access and set 'class_flags' array
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L};
        classFlags[index] = 1L << 18; // Set bit18
        classFlagsField.set(classBands, classFlags);

        // Access and initialize 'classEnclosingMethodClass' and 'classEnclosingMethodDesc' lists
        Field classEnclosingMethodClassField = ClassBands.class.getDeclaredField("classEnclosingMethodClass");
        classEnclosingMethodClassField.setAccessible(true);
        List<String> classEnclosingMethodClass = new ArrayList<>();
        classEnclosingMethodClass.add("EnclosingMethodClass1");
        classEnclosingMethodClass.add("EnclosingMethodClass2");
        classEnclosingMethodClassField.set(classBands, classEnclosingMethodClass);

        Field classEnclosingMethodDescField = ClassBands.class.getDeclaredField("classEnclosingMethodDesc");
        classEnclosingMethodDescField.setAccessible(true);
        List<String> classEnclosingMethodDesc = new ArrayList<>();
        classEnclosingMethodDesc.add("MethodDesc1");
        classEnclosingMethodDesc.add("MethodDesc2");
        classEnclosingMethodDescField.set(classBands, classEnclosingMethodDesc);

        // Ensure 'tempFieldFlags' and 'tempMethodFlags' are empty
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlagsField.set(classBands, tempFieldFlags);

        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Invoke 'removeCurrentClass' method
        classBands.removeCurrentClass();

        // Assert 'classEnclosingMethodClass' and 'classEnclosingMethodDesc' have their last elements removed
        Assertions.assertEquals(1, classEnclosingMethodClass.size(), "classEnclosingMethodClass should have one element after removal");
        Assertions.assertEquals("EnclosingMethodClass1", classEnclosingMethodClass.get(0), "Remaining enclosing method class should be 'EnclosingMethodClass1'");
        
        Assertions.assertEquals(1, classEnclosingMethodDesc.size(), "classEnclosingMethodDesc should have one element after removal");
        Assertions.assertEquals("MethodDesc1", classEnclosingMethodDesc.get(0), "Remaining method description should be 'MethodDesc1'");
        
        // Ensure other lists remain unchanged
        Field classSourceFileField = ClassBands.class.getDeclaredField("classSourceFile");
        classSourceFileField.setAccessible(true);
        List<String> classSourceFile = (List<String>) classSourceFileField.get(classBands);
        Assertions.assertTrue(classSourceFile.isEmpty(), "classSourceFile should remain unchanged");
    }

    @Test
    @DisplayName("Both class_flags[index] bit17 and bit18 are set; tempFieldFlags and tempMethodFlags are empty")
    public void TC03() throws Exception {
        // Initialize ClassBands instance
        ClassBands classBands = new ClassBands();

        // Access and set 'index' field
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        int index = 0;
        indexField.setInt(classBands, index);

        // Access and set 'class_flags' array
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L};
        classFlags[index] = (1L << 17) | (1L << 18); // Set bits17 and bit18
        classFlagsField.set(classBands, classFlags);

        // Access and initialize 'classSourceFile' list
        Field classSourceFileField = ClassBands.class.getDeclaredField("classSourceFile");
        classSourceFileField.setAccessible(true);
        List<String> classSourceFile = new ArrayList<>();
        classSourceFile.add("SourceFile1.java");
        classSourceFile.add("SourceFile2.java");
        classSourceFileField.set(classBands, classSourceFile);

        // Access and initialize 'classEnclosingMethodClass' and 'classEnclosingMethodDesc' lists
        Field classEnclosingMethodClassField = ClassBands.class.getDeclaredField("classEnclosingMethodClass");
        classEnclosingMethodClassField.setAccessible(true);
        List<String> classEnclosingMethodClass = new ArrayList<>();
        classEnclosingMethodClass.add("EnclosingMethodClass1");
        classEnclosingMethodClass.add("EnclosingMethodClass2");
        classEnclosingMethodClassField.set(classBands, classEnclosingMethodClass);

        Field classEnclosingMethodDescField = ClassBands.class.getDeclaredField("classEnclosingMethodDesc");
        classEnclosingMethodDescField.setAccessible(true);
        List<String> classEnclosingMethodDesc = new ArrayList<>();
        classEnclosingMethodDesc.add("MethodDesc1");
        classEnclosingMethodDesc.add("MethodDesc2");
        classEnclosingMethodDescField.set(classBands, classEnclosingMethodDesc);

        // Ensure 'tempFieldFlags' and 'tempMethodFlags' are empty
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlagsField.set(classBands, tempFieldFlags);

        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Invoke 'removeCurrentClass' method
        classBands.removeCurrentClass();

        // Assert 'classSourceFile', 'classEnclosingMethodClass', and 'classEnclosingMethodDesc' have their last elements removed
        Assertions.assertEquals(1, classSourceFile.size(), "classSourceFile should have one element after removal");
        Assertions.assertEquals("SourceFile1.java", classSourceFile.get(0), "Remaining source file should be 'SourceFile1.java'");
        
        Assertions.assertEquals(1, classEnclosingMethodClass.size(), "classEnclosingMethodClass should have one element after removal");
        Assertions.assertEquals("EnclosingMethodClass1", classEnclosingMethodClass.get(0), "Remaining enclosing method class should be 'EnclosingMethodClass1'");
        
        Assertions.assertEquals(1, classEnclosingMethodDesc.size(), "classEnclosingMethodDesc should have one element after removal");
        Assertions.assertEquals("MethodDesc1", classEnclosingMethodDesc.get(0), "Remaining method description should be 'MethodDesc1'");
        
        // Ensure other lists remain unchanged
        Field classSignatureField = ClassBands.class.getDeclaredField("classSignature");
        classSignatureField.setAccessible(true);
        List<String> classSignature = (List<String>) classSignatureField.get(classBands);
        Assertions.assertTrue(classSignature.isEmpty(), "classSignature should remain unchanged");
    }

    @Test
    @DisplayName("class_flags[index] bit19 is set; tempFieldFlags and tempMethodFlags are empty")
    public void TC04() throws Exception {
        // Initialize ClassBands instance
        ClassBands classBands = new ClassBands();

        // Access and set 'index' field
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        int index = 0;
        indexField.setInt(classBands, index);

        // Access and set 'class_flags' array
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L};
        classFlags[index] = 1L << 19; // Set bit19
        classFlagsField.set(classBands, classFlags);

        // Access and initialize 'classSignature' list
        Field classSignatureField = ClassBands.class.getDeclaredField("classSignature");
        classSignatureField.setAccessible(true);
        List<String> classSignature = new ArrayList<>();
        classSignature.add("Signature1");
        classSignature.add("Signature2");
        classSignatureField.set(classBands, classSignature);

        // Ensure 'tempFieldFlags' and 'tempMethodFlags' are empty
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlagsField.set(classBands, tempFieldFlags);

        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Invoke 'removeCurrentClass' method
        classBands.removeCurrentClass();

        // Assert 'classSignature' has its last element removed
        Assertions.assertEquals(1, classSignature.size(), "classSignature should have one element after removal");
        Assertions.assertEquals("Signature1", classSignature.get(0), "Remaining class signature should be 'Signature1'");
        
        // Ensure other lists remain unchanged
        Field classSourceFileField = ClassBands.class.getDeclaredField("classSourceFile");
        classSourceFileField.setAccessible(true);
        List<String> classSourceFile = (List<String>) classSourceFileField.get(classBands);
        Assertions.assertTrue(classSourceFile.isEmpty(), "classSourceFile should remain unchanged");
    }

    @Test
    @DisplayName("Loop over tempFieldFlags with zero entries")
    public void TC05() throws Exception {
        // Initialize ClassBands instance
        ClassBands classBands = new ClassBands();

        // Access and set 'index' field
        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        int index = 0;
        indexField.setInt(classBands, index);

        // Access and set 'class_flags' array with no relevant bits set
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] classFlags = new long[]{0L};
        classFlags[index] = 0L; // No relevant bits set
        classFlagsField.set(classBands, classFlags);

        // Ensure 'tempFieldFlags' and 'tempMethodFlags' are empty
        Field tempFieldFlagsField = ClassBands.class.getDeclaredField("tempFieldFlags");
        tempFieldFlagsField.setAccessible(true);
        List<Long> tempFieldFlags = new ArrayList<>();
        tempFieldFlagsField.set(classBands, tempFieldFlags);

        Field tempMethodFlagsField = ClassBands.class.getDeclaredField("tempMethodFlags");
        tempMethodFlagsField.setAccessible(true);
        List<Long> tempMethodFlags = new ArrayList<>();
        tempMethodFlagsField.set(classBands, tempMethodFlags);

        // Access and initialize lists that should remain unchanged
        Field classSourceFileField = ClassBands.class.getDeclaredField("classSourceFile");
        classSourceFileField.setAccessible(true);
        List<String> classSourceFile = new ArrayList<>();
        classSourceFile.add("SourceFile1.java");
        classSourceFileField.set(classBands, classSourceFile);

        // Invoke 'removeCurrentClass' method
        classBands.removeCurrentClass();

        // Assert 'classSourceFile' remains unchanged
        Assertions.assertEquals(1, classSourceFile.size(), "classSourceFile should remain unchanged");
        Assertions.assertEquals("SourceFile1.java", classSourceFile.get(0), "classSourceFile should still contain 'SourceFile1.java'");
        
        // Assert 'tempFieldFlags' and 'tempMethodFlags' remain empty
        Assertions.assertTrue(tempFieldFlags.isEmpty(), "tempFieldFlags should remain empty");
        Assertions.assertTrue(tempMethodFlags.isEmpty(), "tempMethodFlags should remain empty");
        
        // Additional assertions can be added based on method flags processing if necessary
    }
}