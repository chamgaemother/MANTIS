import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import com.fasterxml.jackson.databind.introspect.AnnotationIntrospector;
import com.fasterxml.jackson.dataformat.xml.deser.XmlBeanDeserializerModifier;
import com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class XmlBeanDeserializerModifierTest {

    @Test
    public void testUpdateProperties_emptyList() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");
        when(config.getAnnotationIntrospector()).thenReturn(mock(AnnotationIntrospector.class));

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
    }

    @Test
    public void testUpdateProperties_nullPrimaryMember() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(null);

        List<BeanPropertyDefinition> propDefs = Arrays.asList(prop);

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
    }

    @Test
    public void testUpdateProperties_textProperty_shouldRename() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.TRUE);
        when(prop.withSimpleName("textValue")).thenReturn(prop);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
        verify(prop).withSimpleName("textValue");
    }

    @Test
    public void testUpdateProperties_textProperty_noRenameNeeded() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.TRUE);
        when(prop.withSimpleName("textValue")).thenReturn(prop);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
        verify(prop).withSimpleName("textValue");
    }

    @Test
    public void testUpdateProperties_wrapperNameDifferent_shouldRename() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(null);

        PropertyName wrapperName = new PropertyName("wrapper");
        when(prop.getWrapperName()).thenReturn(wrapperName);
        when(wrapperName.getSimpleName()).thenReturn("wrapper");
        when(prop.getName()).thenReturn("originalName");
        BeanPropertyDefinition renamedProp = mock(BeanPropertyDefinition.class);
        when(prop.withSimpleName("wrapper")).thenReturn(renamedProp);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertEquals(1, result.size());
        assertSame(renamedProp, result.get(0));
    }

    @Test
    public void testUpdateProperties_wrapperNameSame_noRename() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(null);

        PropertyName wrapperName = new PropertyName("sameName");
        when(prop.getWrapperName()).thenReturn(wrapperName);
        when(wrapperName.getSimpleName()).thenReturn("sameName");
        when(prop.getName()).thenReturn("sameName");

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
    }

    @Test
    public void testUpdateProperties_wrapperNameEmpty_noRename() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(null);

        PropertyName wrapperName = new PropertyName("");
        when(prop.getWrapperName()).thenReturn(wrapperName);
        when(wrapperName.getSimpleName()).thenReturn("");
        when(prop.getName()).thenReturn("originalName");

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
    }

    @Test
    public void testUpdateProperties_wrapperNameNoName_noRename() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(null);

        when(prop.getWrapperName()).thenReturn(PropertyName.NO_NAME);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
    }

    @Test
    public void testUpdateProperties_mixedProperties() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        // Property 1: text property, needs rename
        AnnotatedMember acc1 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop1 = mock(BeanPropertyDefinition.class);
        when(prop1.getPrimaryMember()).thenReturn(acc1);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc1)).thenReturn(Boolean.TRUE);
        when(prop1.withSimpleName("textValue")).thenReturn(prop1);

        // Property 2: wrapper name different, needs rename
        AnnotatedMember acc2 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop2 = mock(BeanPropertyDefinition.class);
        when(prop2.getPrimaryMember()).thenReturn(acc2);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc2)).thenReturn(null);
        PropertyName wrapperName2 = new PropertyName("wrapper2");
        when(prop2.getWrapperName()).thenReturn(wrapperName2);
        when(wrapperName2.getSimpleName()).thenReturn("wrapper2");
        when(prop2.getName()).thenReturn("original2");
        BeanPropertyDefinition renamedProp2 = mock(BeanPropertyDefinition.class);
        when(prop2.withSimpleName("wrapper2")).thenReturn(renamedProp2);

        // Property 3: wrapper name same, no rename
        AnnotatedMember acc3 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop3 = mock(BeanPropertyDefinition.class);
        when(prop3.getPrimaryMember()).thenReturn(acc3);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc3)).thenReturn(null);
        PropertyName wrapperName3 = new PropertyName("sameName");
        when(prop3.getWrapperName()).thenReturn(wrapperName3);
        when(wrapperName3.getSimpleName()).thenReturn("sameName");
        when(prop3.getName()).thenReturn("sameName");

        // Property 4: no text, no wrapper
        AnnotatedMember acc4 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop4 = mock(BeanPropertyDefinition.class);
        when(prop4.getPrimaryMember()).thenReturn(acc4);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc4)).thenReturn(null);
        when(prop4.getWrapperName()).thenReturn(null);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop1, prop2, prop3, prop4));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertEquals(4, result.size());
        assertSame(prop1, result.get(0));
        assertSame(renamedProp2, result.get(1));
        assertSame(prop3, result.get(2));
        assertSame(prop4, result.get(3));
    }

    @Test
    public void testUpdateProperties_multipleTextProperties() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        // Property 1: text property, needs rename
        AnnotatedMember acc1 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop1 = mock(BeanPropertyDefinition.class);
        when(prop1.getPrimaryMember()).thenReturn(acc1);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc1)).thenReturn(Boolean.TRUE);
        when(prop1.withSimpleName("textValue1")).thenReturn(prop1);

        // Property 2: text property, needs rename
        AnnotatedMember acc2 = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop2 = mock(BeanPropertyDefinition.class);
        when(prop2.getPrimaryMember()).thenReturn(acc2);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc2)).thenReturn(Boolean.TRUE);
        when(prop2.withSimpleName("textValue1")).thenReturn(prop2);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop1, prop2));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue1");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
        verify(prop1).withSimpleName("textValue1");
        verify(prop2).withSimpleName("textValue1");
    }

    @Test
    public void testUpdateProperties_nullConfig() {
        // Arrange
        DeserializationConfig config = null;
        BeanDescription beanDesc = mock(BeanDescription.class);
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            modifier.updateProperties(config, beanDesc, propDefs);
        });
    }

    @Test
    public void testUpdateProperties_nullBeanDescription() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.getAnnotationIntrospector()).thenReturn(mock(AnnotationIntrospector.class));
        BeanDescription beanDesc = null;
        List<BeanPropertyDefinition> propDefs = new ArrayList<>();

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            modifier.updateProperties(config, beanDesc, propDefs);
        });
    }

    @Test
    public void testUpdateProperties_nullPropDefs() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.getAnnotationIntrospector()).thenReturn(mock(AnnotationIntrospector.class));
        BeanDescription beanDesc = mock(BeanDescription.class);
        List<BeanPropertyDefinition> propDefs = null;

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            modifier.updateProperties(config, beanDesc, propDefs);
        });
    }

    @Test
    public void testUpdateProperties_nullWrapperName() {
        // Arrange
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(null);
        when(prop.getWrapperName()).thenReturn(null);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("textValue");

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
    }

    @Test
    public void testUpdateProperties_emptyCfgNameForTextValue() {
        // Arrange
        XmlBeanDeserializerModifier modifier = new XmlBeanDeserializerModifier("");
        DeserializationConfig config = mock(DeserializationConfig.class);
        AnnotationIntrospector intr = mock(AnnotationIntrospector.class);
        when(config.getAnnotationIntrospector()).thenReturn(intr);
        BeanDescription beanDesc = mock(BeanDescription.class);

        AnnotatedMember acc = mock(AnnotatedMember.class);
        BeanPropertyDefinition prop = mock(BeanPropertyDefinition.class);
        when(prop.getPrimaryMember()).thenReturn(acc);
        when(AnnotationUtil.findIsTextAnnotation(config, intr, acc)).thenReturn(Boolean.TRUE);
        when(prop.withSimpleName("")).thenReturn(prop);

        List<BeanPropertyDefinition> propDefs = new ArrayList<>(Arrays.asList(prop));

        // Act
        List<BeanPropertyDefinition> result = modifier.updateProperties(config, beanDesc, propDefs);

        // Assert
        assertSame(propDefs, result);
        verify(prop).withSimpleName("");
    }
}