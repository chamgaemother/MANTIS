package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import static org.junit.jupiter.api.Assertions.*;

public class DfpDec_nextAfter_2_1_Test {

    @Test
    @DisplayName("nextAfter called with differing radix digits and this does not less than x")
    public void TC21_nextAfter_differingRadixDigits_thisNotLessThanX() throws Exception {
        // GIVEN
        DfpField fieldN = new DfpField(10);
        DfpDec thisDfp = createDfpDec(fieldN, 150.0);

        DfpField fieldM = new DfpField(12);
        DfpDec x = createDfpDec(fieldM, 100.0);

        // WHEN
        Dfp result = thisDfp.nextAfter(x);

        // THEN
        assertEquals(Dfp.QNAN, result.classify(), "When radix digits differ, result should be QNAN");
    }

    @Test
    @DisplayName("nextAfter called with differing radix digits and this less than x")
    public void TC22_nextAfter_differingRadixDigits_thisLessThanX_nonInfinite() throws Exception {
        // GIVEN
        DfpField fieldN = new DfpField(10);
        DfpDec thisDfp = createDfpDec(fieldN, 50.0);

        DfpField fieldM = new DfpField(12);
        DfpDec x = createDfpDec(fieldM, 100.0);

        // WHEN
        Dfp result = thisDfp.nextAfter(x);

        // THEN
        assertEquals(Dfp.QNAN, result.classify(), "When radix digits differ, result should be QNAN");
    }

    @Test
    @DisplayName("nextAfter called with differing radix digits resulting in INFINITE classification")
    public void TC23_nextAfter_differingRadixDigits_leadingToInfinite() throws Exception {
        // GIVEN
        DfpField fieldN = new DfpField(10);
        DfpDec thisDfp = createDfpDec(fieldN, Double.MAX_VALUE);

        DfpField fieldM = new DfpField(12);
        DfpDec x = createDfpDec(fieldM, Double.POSITIVE_INFINITY);

        // WHEN
        Dfp result = thisDfp.nextAfter(x);

        // THEN
        assertEquals(Dfp.QNAN, result.classify(), "When radix digits differ, result should be QNAN");
    }

    @Test
    @DisplayName("nextAfter called with differing radix digits resulting in zero while original is non-zero")
    public void TC24_nextAfter_differingRadixDigits_leadingToZero() throws Exception {
        // GIVEN
        DfpField fieldN = new DfpField(10);
        DfpDec thisDfp = createDfpDec(fieldN, 1.0e-300);

        DfpField fieldM = new DfpField(12);
        DfpDec x = createDfpDec(fieldM, 0.0);

        // WHEN
        Dfp result = thisDfp.nextAfter(x);

        // THEN
        assertEquals(Dfp.QNAN, result.classify(), "When radix digits differ, result should be QNAN");
    }

    @Test
    @DisplayName("nextAfter called with this equals x resulting in immediate return of new instance")
    public void TC25_nextAfter_differingRadixDigits_thisEqualsX() throws Exception {
        // GIVEN
        DfpField fieldN = new DfpField(10);
        DfpDec thisDfp = createDfpDec(fieldN, 100.0);

        DfpField fieldM = new DfpField(12);
        DfpDec x = createDfpDec(fieldM, 100.0);

        // WHEN
        Dfp result = thisDfp.nextAfter(x);

        // THEN
        assertNotSame(thisDfp, result, "Result should be a new instance");
        assertEquals(Dfp.QNAN, result.classify(), "When radix digits differ, result should be QNAN");
    }

    /**
     * Utility method to create a DfpDec instance using reflection.
     * @param field The DfpField instance.
     * @param value The double value to initialize the DfpDec.
     * @return A new instance of DfpDec.
     * @throws NoSuchMethodException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws InstantiationException
     */
    private DfpDec createDfpDec(DfpField field, double value) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<DfpDec> constructor = DfpDec.class.getDeclaredConstructor(DfpField.class, double.class);
        constructor.setAccessible(true);
        return constructor.newInstance(field, value);
    }
}
