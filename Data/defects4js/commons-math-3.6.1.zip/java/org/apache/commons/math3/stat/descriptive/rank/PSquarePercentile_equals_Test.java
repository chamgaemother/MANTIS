import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.stat.descriptive.rank.PSquarePercentile;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class PSquarePercentile_equals_Test {

    @Test
    public void equals_sameObject() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        Assertions.assertTrue(p1.equals(p1));
    }

    @Test
    public void equals_nullObject() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        Assertions.assertFalse(p1.equals(null));
    }

    @Test
    public void equals_differentObjectType() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        String str = "DifferentType";
        Assertions.assertFalse(p1.equals(str));
    }

    @Test
    public void equals_differentQuantile() {
        PSquarePercentile p1 = new PSquarePercentile(25);
        PSquarePercentile p2 = new PSquarePercentile(75);
        Assertions.assertFalse(p1.equals(p2));
    }

    @Test
    public void equals_markersNull() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        Assertions.assertTrue(p1.equals(p2));
    }

    @Test
    public void equals_markersNotEqual() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        p1.increment(1.0);
        p1.increment(2.0);
        p1.increment(3.0);
        p1.increment(4.0);
        p1.increment(5.0);

        p2.increment(1.0);
        p2.increment(2.0);
        p2.increment(3.0);
        p2.increment(4.0);
        p2.increment(6.0);

        Assertions.assertFalse(p1.equals(p2));
    }

    @Test
    public void equals_markersEqual() {
        PSquarePercentile p1 = new PSquarePercentile(50);
        PSquarePercentile p2 = new PSquarePercentile(50);
        p1.increment(1.0);
        p1.increment(2.0);
        p1.increment(3.0);
        p1.increment(4.0);
        p1.increment(5.0);

        p2.increment(1.0);
        p2.increment(2.0);
        p2.increment(3.0);
        p2.increment(4.0);
        p2.increment(5.0);

        Assertions.assertTrue(p1.equals(p2));
    }
    
    @Test
    public void equals_sameNumObservations() {
        PSquarePercentile p1 = new PSquarePercentile(25);
        PSquarePercentile p2 = new PSquarePercentile(25);
        for (int i = 0; i < 10; i++) {
            p1.increment(i);
        }
        for (int i = 0; i < 10; i++) {
            p2.increment(i);
        }
        Assertions.assertTrue(p1.equals(p2));
    }

    @Test
    public void equals_differentNumObservations() {
        PSquarePercentile p1 = new PSquarePercentile(25);
        PSquarePercentile p2 = new PSquarePercentile(25);
        for (int i = 0; i < 10; i++) {
            p1.increment(i);
        }
        for (int i = 0; i < 9; i++) {
            p2.increment(i);
        }
        Assertions.assertFalse(p1.equals(p2));
    }
}