import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.json.UTF8DataInputJsonParser;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.core.util.JsonGeneratorDelegate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

public class UTF8DataInputJsonParserTest {

    private IOContext ioContext;
    private ByteQuadsCanonicalizer canonicalizer;
    private ObjectCodec codec;

    @BeforeEach
    public void setup() {
        ioContext = new IOContext(new BufferRecycler(), null, false);
        canonicalizer = ByteQuadsCanonicalizer.createRoot();
        codec = new ObjectMapper();
    }

    private UTF8DataInputJsonParser createParser(String jsonData) throws IOException {
        DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream(jsonData.getBytes()));
        return new UTF8DataInputJsonParser(ioContext, 0, dataInputStream, codec, canonicalizer, 0);
    }

    @Test
    public void testNextTokenEOF() throws IOException {
        UTF8DataInputJsonParser parser = createParser("");
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStartArray() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[1, 2, 3]");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
    }

    @Test
    public void testNextTokenEndArray() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[1, 2, 3]");
        parser.nextToken(); // START_ARRAY
        parser.nextToken(); // 1
        parser.nextToken(); // ,
        parser.nextToken(); // 2
        parser.nextToken(); // ,
        parser.nextToken(); // 3
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
    }

    @Test
    public void testNextTokenStartObject() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
    }

    @Test
    public void testNextTokenEndObject() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{}");
        parser.nextToken(); // START_OBJECT
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
    }

    @Test
    public void testNextTokenNullValue() throws IOException {
        UTF8DataInputJsonParser parser = createParser("null");
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
    }

    @Test
    public void testNextTokenTrueValue() throws IOException {
        UTF8DataInputJsonParser parser = createParser("true");
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
    }

    @Test
    public void testNextTokenFalseValue() throws IOException {
        UTF8DataInputJsonParser parser = createParser("false");
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
    }

    @Test
    public void testNextTokenString() throws IOException {
        UTF8DataInputJsonParser parser = createParser("\"string\"");
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("string", parser.getText());
    }

    @Test
    public void testNextTokenNumber() throws IOException {
        UTF8DataInputJsonParser parser = createParser("123");
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());
    }

    @Test
    public void testNextTokenNegativeNumber() throws IOException {
        UTF8DataInputJsonParser parser = createParser("-789");
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(-789, parser.getIntValue());
    }

    @Test
    public void testNextTokenUnexpectedCharacter() {
        assertThrows(JsonParseException.class, () -> {
            UTF8DataInputJsonParser parser = createParser("!");
            parser.nextToken();
        });
    }

    @Test
    public void testNextTokenCommaInRoot() {
        assertThrows(JsonParseException.class, () -> {
            UTF8DataInputJsonParser parser = createParser(",");
            parser.nextToken();
        });
    }

    @Test
    public void testNextTokenTrailingComma() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[1,]");
        parser.enable(JsonParser.Feature.ALLOW_TRAILING_COMMA);
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
    }

    @Test
    public void testNextTokenMissingValue() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[,]");
        parser.enable(JsonParser.Feature.ALLOW_MISSING_VALUES);
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
    }
}