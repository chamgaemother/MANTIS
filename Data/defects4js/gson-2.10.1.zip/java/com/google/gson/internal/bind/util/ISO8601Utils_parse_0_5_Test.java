package com.google.gson.internal.bind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParsePosition;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601Utils_parse_0_5_Test {

//     @Test
//     @DisplayName("parse date with minimal time component")
//     void TC21_parseDateWithMinimalTimeComponent() {
        // GIVEN
//         String date = "2023-10-05T00:00:00Z";
//         ParsePosition pos = new ParsePosition(0);
//         Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
//         expectedCalendar.set(Calendar.YEAR, 2023);
//         expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER - 1); // Months are 0-based
//         expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
//         expectedCalendar.set(Calendar.HOUR_OF_DAY, 0);
//         expectedCalendar.set(Calendar.MINUTE, 0);
//         expectedCalendar.set(Calendar.SECOND, 0);
//         expectedCalendar.set(Calendar.MILLISECOND, 0);
//         Date expectedDate = expectedCalendar.getTime();
//         
        // WHEN
//         Date result = ISO8601Utils.parse(date, pos);
//         
        // THEN
//         assertEquals(expectedDate, result, "The parsed date should match the expected date.");
//         assertEquals(date.length(), pos.getIndex(), "The ParsePosition index should be at the end of the string.");
//     }

//     @Test
//     @DisplayName("parse date with seconds omitted")
//     void TC22_parseDateWithSecondsOmitted() {
        // GIVEN
//         String date = "2023-10-05T14:30Z";
//         ParsePosition pos = new ParsePosition(0);
//         Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
//         expectedCalendar.set(Calendar.YEAR, 2023);
//         expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER - 1);
//         expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
//         expectedCalendar.set(Calendar.HOUR_OF_DAY, 14);
//         expectedCalendar.set(Calendar.MINUTE, 30);
//         expectedCalendar.set(Calendar.SECOND, 0);
//         expectedCalendar.set(Calendar.MILLISECOND, 0);
//         Date expectedDate = expectedCalendar.getTime();
//         
        // WHEN
//         Date result = ISO8601Utils.parse(date, pos);
//         
        // THEN
//         assertEquals(expectedDate, result, "The parsed date should match the expected calendar time.");
//         assertEquals(date.length(), pos.getIndex(), "The ParsePosition index should be at the end of the string.");
//     }

    @Test
    @DisplayName("parse date with invalid timezone offset length")
    void TC23_parseDateWithInvalidTimezoneOffsetLength() {
        // GIVEN
        String date = "2023-10-05T14:30:00+2500";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN & THEN
        assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "An IndexOutOfBoundsException should be thrown for invalid timezone offset length.");
    }

    @Test
    @DisplayName("parse date with incomplete timezone information")
    void TC24_parseDateWithIndexOutOfBoundsInTimezoneProcessing() {
        // GIVEN
        String date = "2023-10-05T14:30:00+";
        ParsePosition pos = new ParsePosition(0);
        
        // WHEN & THEN
        assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        }, "An IndexOutOfBoundsException should be thrown for missing timezone indicator after offset.");
    }

//     @Test
//     @DisplayName("parse date with incomplete milliseconds component")
//     void TC25_parseDateWithIncompleteMillisecondsComponent() {
        // GIVEN
//         String date = "2023-10-05T14:30:00.1Z";
//         ParsePosition pos = new ParsePosition(0);
//         Calendar expectedCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
//         expectedCalendar.set(Calendar.YEAR, 2023);
//         expectedCalendar.set(Calendar.MONTH, Calendar.OCTOBER - 1);
//         expectedCalendar.set(Calendar.DAY_OF_MONTH, 5);
//         expectedCalendar.set(Calendar.HOUR_OF_DAY, 14);
//         expectedCalendar.set(Calendar.MINUTE, 30);
//         expectedCalendar.set(Calendar.SECOND, 0);
//         expectedCalendar.set(Calendar.MILLISECOND, 100); // .1 translates to 100 milliseconds
//         Date expectedDate = expectedCalendar.getTime();
//         
        // WHEN
//         Date result = ISO8601Utils.parse(date, pos);
//         
        // THEN
//         assertEquals(expectedDate, result, "The parsed date should match the expected date including milliseconds.");
//         assertEquals(date.length(), pos.getIndex(), "The ParsePosition index should be at the end of the string.");
//     }
}