package org.apache.commons.collections4.functors;

import org.apache.commons.collections4.functors.ComparatorPredicate;
import org.apache.commons.collections4.functors.ComparatorPredicate.Criterion;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;

public class ComparatorPredicate_test_0_2_Test {

    @Test
    @DisplayName("Criterion LESS, comparator returns 0, expect false as objects are not less")
    void testCriterionLessComparatorReturns0() throws Exception {
        Comparator<Object> comparator = (o1, o2) -> 0; // stub comparator
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(comparator, target, Criterion.LESS);

        boolean result = predicate.test(new Object());
        assertEquals(false, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL, comparator returns 0, expect true as objects are equal")
    void testCriterionGreaterOrEqualComparatorReturns0() throws Exception {
        Comparator<Object> comparator = (o1, o2) -> 0; // stub comparator
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(comparator, target, Criterion.GREATER_OR_EQUAL);

        boolean result = predicate.test(new Object());
        assertEquals(true, result);
    }

    @Test
    @DisplayName("Criterion GREATER_OR_EQUAL, comparator returns positive, expect true as first object is greater")
    void testCriterionGreaterOrEqualComparatorReturnsPositive() throws Exception {
        Comparator<Object> comparator = (o1, o2) -> 1; // stub comparator, positive value
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(comparator, target, Criterion.GREATER_OR_EQUAL);

        boolean result = predicate.test(new Object());
        assertEquals(true, result);
    }

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL, comparator returns 0, expect true as objects are equal")
    void testCriterionLessOrEqualComparatorReturns0() throws Exception {
        Comparator<Object> comparator = (o1, o2) -> 0; // stub comparator
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(comparator, target, Criterion.LESS_OR_EQUAL);

        boolean result = predicate.test(new Object());
        assertEquals(true, result);
    }

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL, comparator returns negative, expect true as first object is less")
    void testCriterionLessOrEqualComparatorReturnsNegative() throws Exception {
        Comparator<Object> comparator = (o1, o2) -> -1; // stub comparator, negative value
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(comparator, target, Criterion.LESS_OR_EQUAL);

        boolean result = predicate.test(new Object());
        assertEquals(true, result);
    }
}