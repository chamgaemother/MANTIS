import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.XYPlot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.event.ActionEvent;

import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.*;

// Note: Additional dependencies like mockito will be required for this test class

class ChartPanelTest {

    private ChartPanel chartPanel;
    private JFreeChart chart;
    private XYPlot plot;

    @BeforeEach
    void setUp() {
        plot = mock(XYPlot.class, Mockito.CALLS_REAL_METHODS);
        chart = mock(JFreeChart.class);
        when(chart.getPlot()).thenReturn(plot);
        chartPanel = new ChartPanel(chart);
    }

    @Test
    void testPropertiesCommand() {
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.PROPERTIES_COMMAND);
        chartPanel.actionPerformed(e);
        // This is just to hit the branch, the actual editor cannot be mocked without a live GUI
    }

    @Test
    void testCopyCommand() {
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.COPY_COMMAND);
        chartPanel.actionPerformed(e);
        // This is just to hit the branch, the actual copy operation would require clipboard access
    }

    @Test
    void testSaveAsPngCommand() {
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "SAVE_AS_PNG");
        chartPanel.actionPerformed(e);
        // IOExceptions would be tested elsewhere, here we just need the method to run
    }

    @Test
    void testZoomInBothCommand() {
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_IN_BOTH_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomDomainAxes(anyDouble(), any(), any(), anyBoolean());
        verify(plot, atLeastOnce()).zoomRangeAxes(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void testZoomInDomainCommand() {
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_IN_DOMAIN_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomDomainAxes(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void testZoomInRangeCommand() {
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_IN_RANGE_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomRangeAxes(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void testZoomOutBothCommand() {
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_OUT_BOTH_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomDomainAxes(anyDouble(), any(), any(), anyBoolean());
        verify(plot, atLeastOnce()).zoomRangeAxes(anyDouble(), any(), anyBoolean());
    }

    @Test
    void testZoomOutDomainCommand() {
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_OUT_DOMAIN_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomDomainAxes(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void testZoomOutRangeCommand() {
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_OUT_RANGE_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomRangeAxes(anyDouble(), any(), any(), anyBoolean());
    }

    @Test
    void testZoomResetBothCommand() {
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_RESET_BOTH_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomRangeAxes(0.0, null, null);
        verify(plot, atLeastOnce()).zoomDomainAxes(0.0, null, null);
    }

    @Test
    void testZoomResetDomainCommand() {
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_RESET_DOMAIN_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomDomainAxes(0.0, null, null);
    }

    @Test
    void testZoomResetRangeCommand() {
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, ChartPanel.ZOOM_RESET_RANGE_COMMAND);
        chartPanel.actionPerformed(e);
        verify(plot, atLeastOnce()).zoomRangeAxes(0.0, null, null);
    }

    @Test
    void testInvalidCommand() {
        ActionEvent e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "INVALID_COMMAND");
        chartPanel.actionPerformed(e);
        // This is just to confirm that no exceptions are thrown for unknown commands
    }
}