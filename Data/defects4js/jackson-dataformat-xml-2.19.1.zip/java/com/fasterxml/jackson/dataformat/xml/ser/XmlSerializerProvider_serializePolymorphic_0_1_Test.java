package com.fasterxml.jackson.dataformat.xml.ser;
import java.io.*;

import java.io.IOException;
import java.lang.reflect.*;
import java.util.*;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import javax.xml.namespace.QName;
import static org.mockito.Mockito.*;

public class XmlSerializerProvider_serializePolymorphic_0_1_Test {

    @Test
    @DisplayName("serializePolymorphic with value as null triggers _serializeXmlNull and returns")
    public void testSerializePolymorphic_withNullValue() throws Exception {
        JsonGenerator gen = mock(JsonGenerator.class);
        Object value = null;
        JavaType rootType = null;
        JsonSerializer<Object> serializer = null;
        TypeSerializer typeSer = null;

        XmlSerializerProvider provider = mock(XmlSerializerProvider.class, Mockito.CALLS_REAL_METHODS);

        doCallRealMethod().when(provider).serializePolymorphic(gen, value, rootType, serializer, typeSer);
        doNothing().when(provider)._serializeXmlNull(gen);

        provider.serializePolymorphic(gen, value, rootType, serializer, typeSer);

        verify(provider, times(1))._serializeXmlNull(gen);
    }

    @Test
    @DisplayName("serializePolymorphic with non-null value and rootType is null")
    public void testSerializePolymorphic_withNonNullValueAndNullRootType() throws Exception {
        JsonGenerator gen = mock(ToXmlGenerator.class);
        Object value = new SomeClass();
        JavaType rootType = null;
        JsonSerializer<Object> serializer = null;
        TypeSerializer typeSer = mock(TypeSerializer.class);

        XmlSerializerProvider provider = mock(XmlSerializerProvider.class, Mockito.CALLS_REAL_METHODS);

        JsonSerializer<Object> mockSerializer = mock(JsonSerializer.class);
        when(provider.findValueSerializer(any(Class.class), any())).thenReturn(mockSerializer);

        provider.serializePolymorphic(gen, value, rootType, serializer, typeSer);

        verify(mockSerializer, times(1)).serializeWithType(eq(value), eq(gen), eq(provider), eq(typeSer));
        verify(gen, never()).writeEndObject();
    }


    @Test
    @DisplayName("serializePolymorphic with _asXmlGenerator returning null indicating convertValue is called")
    public void testSerializePolymorphic_withAsXmlGeneratorNull() throws Exception {
        JsonGenerator gen = mock(JsonGenerator.class);
        Object value = new SomeClass();
        JavaType rootType = mock(JavaType.class);
        JsonSerializer<Object> serializer = null;
        TypeSerializer typeSer = mock(TypeSerializer.class);

        XmlSerializerProvider provider = mock(XmlSerializerProvider.class, Mockito.CALLS_REAL_METHODS);

        when(provider._asXmlGenerator(gen)).thenReturn(null);

        JsonSerializer<Object> mockSerializer = mock(JsonSerializer.class);
        when(provider.findValueSerializer(any(Class.class), any())).thenReturn(mockSerializer);

        provider.serializePolymorphic(gen, value, rootType, serializer, typeSer);

        verify(mockSerializer, times(1)).serializeWithType(eq(value), eq(gen), eq(provider), eq(typeSer));
        verify(gen, never()).writeEndObject();
    }

    @Test
    @DisplayName("serializePolymorphic with configured rootName and indexed type")
    public void testSerializePolymorphic_withConfiguredRootNameAndIndexedType() throws Exception {
        ToXmlGenerator gen = mock(ToXmlGenerator.class);
        Object value = new IndexedClass();
        JavaType rootType = mock(JavaType.class);
        JsonSerializer<Object> serializer = mock(JsonSerializer.class);
        TypeSerializer typeSer = mock(TypeSerializer.class);

        XmlSerializerProvider provider = mock(XmlSerializerProvider.class, Mockito.CALLS_REAL_METHODS);

        QName rootName = new QName("namespace", "root");
        when(provider._rootNameFromConfig()).thenReturn(rootName);
        when(provider._asXmlGenerator(gen)).thenReturn(gen);

        JsonSerializer<Object> mockSerializer = mock(JsonSerializer.class);
        when(provider.findValueSerializer(any(Class.class), any())).thenReturn(mockSerializer);

        provider.serializePolymorphic(gen, value, rootType, serializer, typeSer);

        verify(provider, times(1))._initWithRootName(gen, rootName);
        verify(provider, times(1))._startRootArray(gen, rootName);
        verify(mockSerializer, times(1)).serializeWithType(eq(value), eq(gen), eq(provider), eq(typeSer));
        verify(gen, times(1)).writeEndObject();
    }

    private static class SomeClass {}
    private static class IndexedClass {}
}