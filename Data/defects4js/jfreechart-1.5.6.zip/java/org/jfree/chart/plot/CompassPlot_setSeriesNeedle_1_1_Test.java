package org.jfree.chart.plot;


import org.jfree.chart.needle.MeterNeedle;
import org.jfree.chart.plot.CompassPlot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class CompassPlot_setSeriesNeedle_1_1_Test {

    @Test
    @DisplayName("setSeriesNeedle with valid type=0 and index=-1 does not modify seriesNeedle array")
    public void TC12() throws Exception {
        // GIVEN
        CompassPlot compassPlot = new CompassPlot();

        // Access seriesNeedle via reflection
        Field field = CompassPlot.class.getDeclaredField("seriesNeedle");
        field.setAccessible(true);
        MeterNeedle[] before = (MeterNeedle[]) field.get(compassPlot);
        // Clone the before array
        MeterNeedle[] beforeClone = before.clone();

        // WHEN
        compassPlot.setSeriesNeedle(-1, 0);

        // THEN
        MeterNeedle[] after = (MeterNeedle[]) field.get(compassPlot);
        assertArrayEquals(beforeClone, after, "seriesNeedle array should remain unchanged");
    }

    @Test
    @DisplayName("setSeriesNeedle with valid type=5 and index=1 exceeds seriesNeedle array bounds")
    public void TC13() throws Exception {
        // GIVEN
        CompassPlot compassPlot = new CompassPlot();

        // Access seriesNeedle via reflection
        Field field = CompassPlot.class.getDeclaredField("seriesNeedle");
        field.setAccessible(true);
        MeterNeedle[] before = (MeterNeedle[]) field.get(compassPlot);
        // Clone the before array
        MeterNeedle[] beforeClone = before.clone();

        // WHEN
        compassPlot.setSeriesNeedle(1, 5);

        // THEN
        MeterNeedle[] after = (MeterNeedle[]) field.get(compassPlot);
        assertArrayEquals(beforeClone, after, "seriesNeedle array should remain unchanged");
    }
}