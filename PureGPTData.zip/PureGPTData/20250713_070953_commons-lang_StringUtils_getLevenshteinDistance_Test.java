import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class StringUtilsTest {
    
    @Test
    void testGetLevenshteinDistanceNullInputs() {
        assertThrows(IllegalArgumentException.class, () ->
                StringUtils.getLevenshteinDistance(null, "test", 1));
        assertThrows(IllegalArgumentException.class, () ->
                StringUtils.getLevenshteinDistance("test", null, 1));
    }
    
    @Test
    void testGetLevenshteinDistanceNegativeThreshold() {
        assertThrows(IllegalArgumentException.class, () ->
                StringUtils.getLevenshteinDistance("test", "test", -1));
    }

    @Test
    void testGetLevenshteinDistanceEmptyStrings() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", "", 0));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a", 1));
        assertEquals(-1, StringUtils.getLevenshteinDistance("", "a", 0));
    }

    @Test
    void testGetLevenshteinDistanceStringsWithinThreshold() {
        assertEquals(3, StringUtils.getLevenshteinDistance("kitten", "sitting", 5));
        assertEquals(4, StringUtils.getLevenshteinDistance("flaw", "lawn", 5));
    }

    @Test
    void testGetLevenshteinDistanceStringsBeyondThreshold() {
        assertEquals(-1, StringUtils.getLevenshteinDistance("kitten", "sitting", 2));
        assertEquals(-1, StringUtils.getLevenshteinDistance("flaw", "lawn", 2));
    }

    @Test
    void testGetLevenshteinDistanceIdenticalStrings() {
        assertEquals(0, StringUtils.getLevenshteinDistance("identity", "identity", 0));
        assertEquals(0, StringUtils.getLevenshteinDistance("identity", "identity", 2));
    }

    @Test
    void testGetLevenshteinDistanceSingleCharacterEdits() {
        assertEquals(1, StringUtils.getLevenshteinDistance("flaw", "flawn", 1));
        assertEquals(1, StringUtils.getLevenshteinDistance("flawn", "flaw", 1));
    }
}