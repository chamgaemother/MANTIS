package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.Conversion;

public class Conversion_binaryToHexDigit_0_5_Test {

    @Test
    @DisplayName("Returns '2' when src.length > srcPos +1 and src[srcPos+1]=true, src[srcPos]=false")
    public void test_TC21() {
        boolean[] src = {false, true, false, false}; // Ensuring src.length > srcPos +1
        int srcPos = 0;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('2', result);
    }

    @Test
    @DisplayName("Returns '1' when src.length <= srcPos +1 and src[srcPos]=true at different srcPos")
    public void test_TC22() {
        boolean[] src = {true, false};
        int srcPos = 1;
        char result = Conversion.binaryToHexDigit(src, srcPos);
        assertEquals('1', result);
    }
}