package org.apache.commons.jxpath.ri.parser;

// Generated JUnit 5 test class for XPathParser's AxisName method covering enhanced scenarios.
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.lang.reflect.Field;
import org.apache.commons.jxpath.ri.parser.XPathParser;
import org.apache.commons.jxpath.ri.parser.Token;
import org.apache.commons.jxpath.ri.parser.ParseException;
import org.apache.commons.jxpath.ri.Compiler;

public class XPathParser_AxisName_2_5_Test {

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_FOLLOWING_SIBLING but token.kind=AXIS_SELF")
    void test_TC37() throws Exception {
        // Initialize parser with empty InputStream
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Use reflection to set jj_nt.kind to AXIS_FOLLOWING_SIBLING
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_FOLLOWING_SIBLING);

        // Use reflection to set token.kind to AXIS_SELF
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        kindField.setInt(token, Compiler.AXIS_SELF);

        // Assert that AxisName() throws ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_FOLLOWING_SIBLING but token.kind=AXIS_PRECEDING")
    void test_TC38() throws Exception {
        // Initialize parser with empty InputStream
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Use reflection to set jj_nt.kind to AXIS_FOLLOWING_SIBLING
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_FOLLOWING_SIBLING);

        // Use reflection to set token.kind to AXIS_PRECEDING
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        kindField.setInt(token, Compiler.AXIS_PRECEDING);

        // Assert that AxisName() throws ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_PRECEDING_SIBLING but token.kind=AXIS_CHILD")
    void test_TC39() throws Exception {
        // Initialize parser with empty InputStream
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Use reflection to set jj_nt.kind to AXIS_PRECEDING_SIBLING
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_PRECEDING_SIBLING);

        // Use reflection to set token.kind to AXIS_CHILD
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        kindField.setInt(token, Compiler.AXIS_CHILD);

        // Assert that AxisName() throws ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_PRECEDING_SIBLING but token.kind=AXIS_SELF")
    void test_TC40() throws Exception {
        // Initialize parser with empty InputStream
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Use reflection to set jj_nt.kind to AXIS_PRECEDING_SIBLING
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_PRECEDING_SIBLING);

        // Use reflection to set token.kind to AXIS_SELF
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        kindField.setInt(token, Compiler.AXIS_SELF);

        // Assert that AxisName() throws ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_DESCENDANT_OR_SELF but token.kind=AXIS_CHILD")
    void test_TC41() throws Exception {
        // Initialize parser with empty InputStream
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Use reflection to set jj_nt.kind to AXIS_DESCENDANT_OR_SELF
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_DESCENDANT_OR_SELF);

        // Use reflection to set token.kind to AXIS_CHILD
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        kindField.setInt(token, Compiler.AXIS_CHILD);

        // Assert that AxisName() throws ParseException
        assertThrows(ParseException.class, () -> {
            parser.AxisName();
        });
    }
}