package com.fasterxml.jackson.dataformat.xml.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class StaxUtilTest {

    @Test
    @DisplayName("sanitizeXmlTypeName should return null when input is null")
    void testSanitizeXmlTypeName_nullInput() {
        assertNull(StaxUtil.sanitizeXmlTypeName(null));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should return empty string when input is empty")
    void testSanitizeXmlTypeName_emptyString() {
        assertEquals("", StaxUtil.sanitizeXmlTypeName(""));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle name without array suffix and no changes needed")
    void testSanitizeXmlTypeName_noArrayNoChange() {
        String input = "ValidName123";
        String expected = "ValidName123";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle name without array suffix with character replacements")
    void testSanitizeXmlTypeName_noArrayWithChanges() {
        String input = "Invalid$Name.";
        String expected = "Invalid.Name.";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle name with single array suffix and pluralize")
    void testSanitizeXmlTypeName_singleArraySuffix() {
        String input = "Item[]";
        String expected = "Items";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle name with multiple array suffixes and pluralize correctly")
    void testSanitizeXmlTypeName_multipleArraySuffixes() {
        String input = "Element[][][]";
        String expected = "Elements";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should pluralize names ending with 's' by adding 'es'")
    void testSanitizeXmlTypeName_pluralization_with_s_suffix() {
        String input = "Class";
        String expected = "Classes";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should pluralize names not ending with 's' by adding 's'")
    void testSanitizeXmlTypeName_pluralization_without_s_suffix() {
        String input = "Book";
        String expected = "Books";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle names with all allowed characters without changes")
    void testSanitizeXmlTypeName_allAllowedCharacters() {
        String input = "Valid_Name-123.";
        String expected = "Valid_Name-123.";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should replace non-allowed ASCII characters with '_' or '.'")
    void testSanitizeXmlTypeName_withNonAllowedAsciiCharacters() {
        String input = "Inval!d$Name#Test";
        String expected = "Inval_d.Name_Test";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should leave non-ASCII characters unchanged")
    void testSanitizeXmlTypeName_withNonAsciiCharacters() {
        String input = "Nameéñ";
        String expected = "Nameéñ";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle names with only non-allowed ASCII characters")
    void testSanitizeXmlTypeName_onlyNonAllowedAsciiCharacters() {
        String input = "$$$";
        String expected = "...";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle names ending with multiple non-allowed characters")
    void testSanitizeXmlTypeName_endingWithMultipleNonAllowedCharacters() {
        String input = "Name$$$";
        String expected = "Name...";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle names with mixed allowed and non-allowed characters")
    void testSanitizeXmlTypeName_mixedCharacters() {
        String input = "Valid$Name-123[]";
        String expected = "Valid.Name-123s";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }

    @Test
    @DisplayName("sanitizeXmlTypeName should handle names with trailing array and non-allowed characters")
    void testSanitizeXmlTypeName_trailingArrayAndCharacters() {
        String input = "Test$$[]";
        String expected = "Test..s";
        assertEquals(expected, StaxUtil.sanitizeXmlTypeName(input));
    }
}