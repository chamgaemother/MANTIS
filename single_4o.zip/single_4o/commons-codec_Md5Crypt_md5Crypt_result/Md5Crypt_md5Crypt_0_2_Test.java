package org.apache.commons.codec.digest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Md5Crypt_md5Crypt_0_2_Test {

    @Test
    @DisplayName("md5Crypt handles keyBytes with length equal to 16")
    public void testMd5CryptHandlesKeyBytesLength16() {
        // GIVEN a byte array for keyBytes with length 16 and a valid salt
        byte[] keyBytes = new byte[16];
        String salt = "$1$12345678";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, Md5Crypt.MD5_PREFIX);

        // THEN a valid md5 hash string is returned
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    @DisplayName("md5Crypt handles single loop iteration of i24")
    public void testMd5CryptSingleLoopIteration() {
        // GIVEN a byte array for keyBytes with length 1 and a valid salt
        byte[] keyBytes = new byte[1];
        String salt = "$1$12345678";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, Md5Crypt.MD5_PREFIX);

        // THEN a valid md5 hash string is returned after one iteration
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    @DisplayName("md5Crypt processes 1000 loop iterations")
    public void testMd5CryptFullLoopExecution() {
        // GIVEN a valid byte array for keyBytes and salt
        byte[] keyBytes = new byte[20];
        String salt = "$1$12345678";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, Md5Crypt.MD5_PREFIX);

        // THEN a valid md5 hash string is computed after 1000 iterations
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    @DisplayName("md5Crypt handles minimum possible salt after validation")
    public void testMd5CryptMinimumSaltValidation() {
        // GIVEN a valid byte array for keyBytes and the smallest valid salt
        byte[] keyBytes = new byte[10];
        String salt = "$1$1";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, Md5Crypt.MD5_PREFIX);

        // THEN a valid md5 hash computed with minimal valid salt
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
    }

    @Test
    @DisplayName("md5Crypt resets arrays after computation ensuring cleanup")
    public void testMd5CryptCleanup() {
        // GIVEN a valid array for keyBytes and salt
        byte[] keyBytes = new byte[12];
        String salt = "$1$abcdefgh";

        // WHEN md5Crypt is called
        String result = Md5Crypt.md5Crypt(keyBytes, salt, Md5Crypt.MD5_PREFIX);

        // THEN all temporary arrays are cleared after the computation
        assertNotNull(result);
        assertTrue(result.startsWith(Md5Crypt.MD5_PREFIX));
        // Since we can't directly test private array resets, rely on the function behavior being correct
    }
}