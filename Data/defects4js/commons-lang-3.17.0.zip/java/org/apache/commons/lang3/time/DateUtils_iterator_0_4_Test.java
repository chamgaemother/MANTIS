package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;
import java.util.Calendar;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

public class DateUtils_iterator_0_4_Test {

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_CENTER and no iterations needed")
    public void test_TC16() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.MARCH, 15); // Wednesday, already centered
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;
        
        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // Then
        Class<?> iteratorClass = iterator.getClass();

        Field spotField = iteratorClass.getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);
        
        Field endFinalField = iteratorClass.getDeclaredField("endFinal");
        endFinalField.setAccessible(true);
        Calendar endFinal = (Calendar) endFinalField.get(iterator);
        
        // Assert that start is Monday and end is Sunday
        assertEquals(Calendar.MONDAY, spot.get(Calendar.DAY_OF_WEEK), "Start day should be Monday");
        assertEquals(Calendar.SUNDAY, endFinal.get(Calendar.DAY_OF_WEEK), "End day should be Sunday");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_RELATIVE and single loop iteration")
    public void test_TC17() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.MARCH, 14); // Tuesday, requires one cutoff adjustment
        int rangeStyle = DateUtils.RANGE_WEEK_RELATIVE;
        
        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // Then
        Class<?> iteratorClass = iterator.getClass();

        Field spotField = iteratorClass.getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);
        
        Field endFinalField = iteratorClass.getDeclaredField("endFinal");
        endFinalField.setAccessible(true);
        Calendar endFinal = (Calendar) endFinalField.get(iterator);
        
        // Assert that start is adjusted by one day
        assertEquals(Calendar.MONDAY, spot.get(Calendar.DAY_OF_WEEK), "Start day should be adjusted to Monday");
        
        // Assert that end is adjusted by one day
        assertEquals(Calendar.SUNDAY, endFinal.get(Calendar.DAY_OF_WEEK), "End day should be adjusted to Sunday");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_CENTER and startCutoff below Calendar.SUNDAY")
    public void test_TC18() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.MARCH, 13); // Monday, but startCutoff will be set below SUNDAY
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;
        
        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // Then
        Class<?> iteratorClass = iterator.getClass();

        Field spotField = iteratorClass.getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);

        // Assert that start is adjusted correctly
        assertTrue(spot.get(Calendar.DAY_OF_WEEK) >= Calendar.SUNDAY && spot.get(Calendar.DAY_OF_WEEK) <= Calendar.SATURDAY, "Start day should be in valid range");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_CENTER and endCutoff above Calendar.SATURDAY")
    public void test_TC19() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.MARCH, 19); // Sunday, but endCutoff will be set above SATURDAY
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;
        
        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // Then
        Class<?> iteratorClass = iterator.getClass();

        Field endFinalField = iteratorClass.getDeclaredField("endFinal");
        endFinalField.setAccessible(true);
        Calendar endFinal = (Calendar) endFinalField.get(iterator);
        
        // Assert that endCutoff is adjusted correctly
        assertTrue(endFinal.get(Calendar.DAY_OF_WEEK) >= Calendar.SUNDAY && endFinal.get(Calendar.DAY_OF_WEEK) <= Calendar.SATURDAY, "End day should be in valid range");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_MONTH_SUNDAY requiring multiple loop iterations")
    public void test_TC20() throws Exception {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.MARCH, 1); // Far from cutoff Sunday
        int rangeStyle = DateUtils.RANGE_MONTH_SUNDAY;
        
        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);
        
        // Then
        Class<?> iteratorClass = iterator.getClass();

        Field spotField = iteratorClass.getDeclaredField("spot");
        spotField.setAccessible(true);
        Calendar spot = (Calendar) spotField.get(iterator);

        Field endFinalField = iteratorClass.getDeclaredField("endFinal");
        endFinalField.setAccessible(true);
        Calendar endFinal = (Calendar) endFinalField.get(iterator);

        // Assert that multiple iterations have adjusted the start and end
        assertTrue(spot.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY, "Start day should be adjusted to Sunday");
        assertTrue(endFinal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY, "End day should be adjusted to Saturday");
    }
}
