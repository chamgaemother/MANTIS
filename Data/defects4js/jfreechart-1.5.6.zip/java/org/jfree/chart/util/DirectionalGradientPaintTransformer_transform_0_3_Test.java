package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.GradientPaint;
import java.awt.Shape;
import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;

public class DirectionalGradientPaintTransformer_transform_0_3_Test {

    @Test
    @DisplayName("Transform with start point (0,0), end point mixed zero and non-zero, isCyclic=false for horizontal gradient")
    public void test_TC11() {
        // Given
        float bx = 10.0f;
        float by = 20.0f;
        float bw = 30.0f;
        float bh = 40.0f;

        GradientPaint paint = new GradientPaint(0, 0, Color.RED, bw, 0, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);

        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();

        // When
        GradientPaint result = transformer.transform(paint, target);

        // Then
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 does not match expected value");
        assertEquals(new Point2D.Float(bx + bw, by), result.getPoint2(), "Point2 does not match expected value");
        assertFalse(result.isCyclic(), "Cyclic flag does not match expected value");
    }

    @Test
    @DisplayName("Transform with start point (0,0), end point mixed zero and non-zero, isCyclic=true for horizontal gradient with offset")
    public void test_TC12() {
        // Given
        float bx = 10.0f;
        float by = 20.0f;
        float bw = 30.0f;
        float bh = 40.0f;

        GradientPaint paint = new GradientPaint(0, 0, Color.RED, bw, 0, Color.BLUE, true);
        Shape target = new Rectangle2D.Float(bx, by, bw, bh);

        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();

        // When
        GradientPaint result = transformer.transform(paint, target);

        // Then
        assertEquals(new Point2D.Float(bx, by), result.getPoint1(), "Point1 does not match expected value");
        assertEquals(new Point2D.Float(bx + bw / 2.0f, by), result.getPoint2(), "Point2 does not match expected value");
        assertTrue(result.isCyclic(), "Cyclic flag does not match expected value");
    }
}