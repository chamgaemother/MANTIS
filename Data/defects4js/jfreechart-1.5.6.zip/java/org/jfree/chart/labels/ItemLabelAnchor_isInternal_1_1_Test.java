package org.jfree.chart.labels;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.jfree.chart.labels.ItemLabelAnchor;

public class ItemLabelAnchor_isInternal_1_1_Test {

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE2")
    void TC15() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE2;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE3")
    void TC16() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE3;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE4")
    void TC17() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE4;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE5")
    void TC18() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE5;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("isInternal() returns false when the anchor is OUTSIDE6")
    void TC19() {
        // Arrange
        ItemLabelAnchor anchor = ItemLabelAnchor.OUTSIDE6;
        // Act
        boolean result = anchor.isInternal();
        // Assert
        assertFalse(result);
    }

}