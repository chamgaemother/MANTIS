package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.apache.commons.math3.util.ArithmeticUtils;

public class ArithmeticUtils_gcd_2_2_Test {

    @Test
    @DisplayName("gcd(-1, -1) returns 1 when both operands are -1")
    void TC28() {
        // Given
        int p = -1;
        int q = -1;

        // When
        int result = ArithmeticUtils.gcd(p, q);

        // Then
        assertEquals(1, result, "The GCD of -1 and -1 should be 1");
    }

}