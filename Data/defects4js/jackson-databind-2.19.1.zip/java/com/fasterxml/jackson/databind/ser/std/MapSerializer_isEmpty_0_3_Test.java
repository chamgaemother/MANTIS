package com.fasterxml.jackson.databind.ser.std;
import com.fasterxml.jackson.databind.JavaType;

import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.type.TypeFactory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.lang.reflect.Field;
import java.util.*;

public class MapSerializer_isEmpty_0_3_Test {

    @Test
    @DisplayName("isEmpty handles null elements properly when suppressNulls is true")
    public void TC11() throws Exception {
        // GIVEN
        SerializerProvider provider = null; // No real implementation needed for this test context
        Map<String, Object> map = new HashMap<>();
        map.put("key1", null);

        MapSerializer mapSerializer = createMapSerializer();

        // Reflectively set _suppressableValue to null
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, null);

        // Reflectively set _suppressNulls to true
        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, true);

        // WHEN
        boolean result = mapSerializer.isEmpty(provider, map);

        // THEN
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("isEmpty returns false when suppressNulls is false and map contains null elements")
    public void TC12() throws Exception {
        // GIVEN
        SerializerProvider provider = null; // No real implementation needed for this test context
        Map<String, Object> map = new HashMap<>();
        map.put("key1", null);

        MapSerializer mapSerializer = createMapSerializer();

        // Reflectively set _suppressableValue to null
        Field suppressableValueField = MapSerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(mapSerializer, null);

        // Reflectively set _suppressNulls to false
        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, false);

        // WHEN
        boolean result = mapSerializer.isEmpty(provider, map);

        // THEN
        Assertions.assertFalse(result);
    }

    private MapSerializer createMapSerializer() throws Exception {
        Set<String> ignoredEntries = Collections.emptySet();
        Set<String> includedEntries = Collections.emptySet();
        JavaType keyType = TypeFactory.defaultInstance().constructType(Object.class);
        JavaType valueType = TypeFactory.defaultInstance().constructType(Object.class);
        boolean valueTypeIsStatic = false;
        TypeSerializer vts = null; // No real implementation needed for this test context
        JsonSerializer<?> keySerializer = null; // No real implementation needed for this test context
        JsonSerializer<?> valueSerializer = null; // No real implementation needed for this test context

        return new MapSerializer(ignoredEntries, includedEntries, keyType, valueType, valueTypeIsStatic, vts, keySerializer, valueSerializer);
    }
}
