package org.apache.commons.math3.linear;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.exception.MathParseException;

public class RealMatrixFormat_parse_1_1_Test {

    @Test
    @DisplayName("parse(null) throws NullPointerException when source is null")
    void TC16() {
        RealMatrixFormat format = new RealMatrixFormat();
        String source = null;
        assertThrows(NullPointerException.class, () -> {
            format.parse(source);
        });
    }
    
    @Test
    @DisplayName("parse with incomplete matrix format throws MathParseException")
    void TC17() {
        RealMatrixFormat format = new RealMatrixFormat();
        String source = "[[1.0,2.0],[3.0,4.0"; // Missing closing brace
        assertThrows(MathParseException.class, () -> {
            format.parse(source);
        });
    }

}