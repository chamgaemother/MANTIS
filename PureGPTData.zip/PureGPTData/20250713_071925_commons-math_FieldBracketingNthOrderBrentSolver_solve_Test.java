import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.solvers.FieldBracketingNthOrderBrentSolver;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.util.Decimal64;
import org.apache.commons.math3.util.Decimal64Field;
import org.junit.jupiter.api.Test;

class FieldBracketingNthOrderBrentSolverTest {

    // Helper class to mock a simple quadratic function
    private static class QuadraticFunction implements RealFieldUnivariateFunction<Decimal64> {
        @Override
        public Decimal64 value(Decimal64 x) {
            // Function: f(x) = x^2 - 2x + 1, roots at x=1
            return x.multiply(x).subtract(x.add(x)).add(Decimal64.ONE);
        }
    }

    @Test
    void testSolveWithPerfectRootInStartValue() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
            new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                3);

        Decimal64 result = solver.solve(
            100, new QuadraticFunction(),
            new Decimal64(0), new Decimal64(2),
            new Decimal64(1), AllowedSolution.ANY_SIDE);

        assertEquals(1.0, result.getReal(), 1e-10);
    }

    @Test
    void testSolveWithPerfectRootAtBounds() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
            new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                3);

        Decimal64 result = solver.solve(
            100, new QuadraticFunction(),
            new Decimal64(1), new Decimal64(2),
            AllowedSolution.ANY_SIDE);

        assertEquals(1.0, result.getReal(), 1e-10);
    }

    @Test
    void testSolveWithNoBracketing() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
            new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                3);

        assertThrows(NoBracketingException.class, () -> 
            solver.solve(100, new QuadraticFunction(),
                new Decimal64(-5), new Decimal64(-4),
                AllowedSolution.ANY_SIDE));
    }

    @Test
    void testSolveNullFunction() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
            new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                3);

        assertThrows(NullArgumentException.class, () -> 
            solver.solve(100, null,
                new Decimal64(-5), new Decimal64(5),
                AllowedSolution.ANY_SIDE));
    }

    @Test
    void testMaximalOrderException() {
        assertThrows(NumberIsTooSmallException.class, () ->
            new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                1));
    }

    @Test
    void testCustomAllowedSolution() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver =
            new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                3);

        Decimal64 result = solver.solve(
            100, new QuadraticFunction(),
            new Decimal64(0), new Decimal64(2),
            new Decimal64(1), AllowedSolution.BELOW_SIDE);

        assertEquals(1.0, result.getReal(), 1e-10);
    }
}