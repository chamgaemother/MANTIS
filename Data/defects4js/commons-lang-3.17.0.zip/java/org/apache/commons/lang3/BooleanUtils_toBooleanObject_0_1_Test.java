package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.lang3.BooleanUtils;

public class BooleanUtils_toBooleanObject_0_1_Test {

    @Test
    @DisplayName("Input string is 'true', returns Boolean.TRUE")
    public void TC01() {
        // GIVEN
        String input = "true";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is 'TRUE', returns Boolean.TRUE")
    public void TC02() {
        // GIVEN
        String input = "TRUE";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is 'TrUe', returns Boolean.TRUE")
    public void TC03() {
        // GIVEN
        String input = "TrUe";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is null, returns null")
    public void TC04() {
        // GIVEN
        String input = null;
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("Input string is single character 'y', returns Boolean.TRUE")
    public void TC05() {
        // GIVEN
        String input = "y";
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        // THEN
        assertEquals(Boolean.TRUE, result);
    }
}