import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.special.Gamma;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class GammaTest {

    @Test
    void testRegularizedGammaPWithNaNInputs() {
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(Double.NaN, 1.0, 1e-10, 1000)));
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(1.0, Double.NaN, 1e-10, 1000)));
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(Double.NaN, Double.NaN, 1e-10, 1000)));
    }

    @ParameterizedTest
    @ValueSource(doubles = {Double.NEGATIVE_INFINITY, -1.0, -0.0001, 0.0})
    void testRegularizedGammaPWithInvalidA(double a) {
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(a, 1.0, 1e-10, 1000)));
    }

    @ParameterizedTest
    @ValueSource(doubles = {-Double.MAX_VALUE, -1.0, -0.0001})
    void testRegularizedGammaPWithInvalidX(double x) {
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(1.0, x, 1e-10, 1000)));
    }

    @Test
    void testRegularizedGammaPWithXZero() {
        assertEquals(0.0, Gamma.regularizedGammaP(1.0, 0.0, 1e-10, 1000));
        assertEquals(0.0, Gamma.regularizedGammaP(5.0, 0.0, 1e-10, 1000));
    }

    @Test
    void testRegularizedGammaPWithXGreaterThanAPlusOne() {
        double a = 2.0;
        double x = 4.0;
        double result = Gamma.regularizedGammaP(a, x, 1e-10, 1000);
        assertTrue(result > 0.5 && result < 1.0);
    }

    @Test
    void testRegularizedGammaPWithXEqualToAPlusOne() {
        double a = 3.0;
        double x = 4.0;
        double result = Gamma.regularizedGammaP(a, x, 1e-10, 1000);
        assertTrue(result > 0.5 && result < 1.0);
    }

    @Test
    void testRegularizedGammaPWithXLessThanAPlusOne() {
        double a = 5.0;
        double x = 5.0;
        double result = Gamma.regularizedGammaP(a, x, 1e-10, 1000);
        assertTrue(result < 0.5 && result > 0.0);
    }

    @Test
    void testRegularizedGammaPConvergence() {
        double a = 2.5;
        double x = 2.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        assertFalse(Double.isNaN(result));
        assertTrue(result > 0.0 && result < 1.0);
    }

    @Test
    void testRegularizedGammaPMaxIterationsExceeded() {
        double a = 2.0;
        double x = 1.0;
        double epsilon = 1e-300;
        int maxIterations = 10;
        assertThrows(MaxCountExceededException.class, () -> {
            Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        });
    }

    @ParameterizedTest
    @ValueSource(doubles = {0.0001, 1e-10, 1e-15})
    void testRegularizedGammaPBoundaryValues(double epsilon) {
        double a = 1.0;
        double x = 1.0;
        double result = Gamma.regularizedGammaP(a, x, epsilon, 1000);
        assertEquals(0.6321205588285577, result, 1e-10);
    }
}