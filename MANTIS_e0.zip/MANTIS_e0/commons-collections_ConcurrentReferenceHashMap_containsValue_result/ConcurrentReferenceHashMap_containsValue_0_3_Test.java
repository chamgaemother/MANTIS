package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ConcurrentReferenceHashMap_containsValue_0_3_Test {

    @Test
    @DisplayName("Value does not exist and modCount stabilizes after retries, clean sweep")
    void TC11_containsValue_not_present_with_modCount_stabilization_after_retries() {
        // Initialize ConcurrentReferenceHashMap instance
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>(16, 0.75f, 16, ConcurrentReferenceHashMap.ReferenceType.WEAK, ConcurrentReferenceHashMap.ReferenceType.STRONG, null);
        Object value = "absentValue";

        // Ensure map does not contain the value
        assertFalse(map.containsValue(value));
    }

    @Test
    @DisplayName("Value exists during locked iteration despite earlier clean sweep failures")
    void TC12_containsValue_present_during_locked_iteration_after_retries() {
        // Initialize ConcurrentReferenceHashMap instance
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>(16, 0.75f, 16, ConcurrentReferenceHashMap.ReferenceType.WEAK, ConcurrentReferenceHashMap.ReferenceType.STRONG, null);
        Object value = "dynamicValue";

        // Initially, the map does not contain the value
        assertFalse(map.containsValue(value));

        // Insert the value
        map.put("key1", "value1");
        map.put("key2", (String) value);

        // Invoke containsValue to trigger the method logic
        boolean result = map.containsValue(value);

        // Assert that the result is true as expected
        assertTrue(result);
    }
}
