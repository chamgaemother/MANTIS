package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.DataInputStream;

import static org.junit.jupiter.api.Assertions.*;

public class UTF8DataInputJsonParser_nextToken_2_1_Test {

//     @Test
//     @DisplayName("TC17: nextToken() parses 'NaN' correctly when ALLOW_NON_NUMERIC_NUMBERS is enabled")
//     public void TC17_nextToken_ParseNaN_WithAllowNonNumericNumbersEnabled() throws IOException {
        // GIVEN
//         String jsonInput = "NaN";
//         byte[] inputBytes = jsonInput.getBytes("UTF-8");
//         DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(inputBytes));
//         IOContext ioContext = new IOContext(null, null, false);
//         int features = JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS.mappedFeature();
//         ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
//         UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, features, dataInput, null, sym, 0);
// 
        // WHEN
//         JsonToken token = parser.nextToken();
//         double value = parser.getValueAsDouble();
// 
        // THEN
//         assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token);
//         assertTrue(Double.isNaN(value));
//     }

//     @Test
//     @DisplayName("TC18: nextToken() parses 'Infinity' correctly when ALLOW_NON_NUMERIC_NUMBERS is enabled")
//     public void TC18_nextToken_ParseInfinity_WithAllowNonNumericNumbersEnabled() throws IOException {
        // GIVEN
//         String jsonInput = "Infinity";
//         byte[] inputBytes = jsonInput.getBytes("UTF-8");
//         DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(inputBytes));
//         IOContext ioContext = new IOContext(null, null, false);
//         int features = JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS.mappedFeature();
//         ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
//         UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, features, dataInput, null, sym, 0);
// 
        // WHEN
//         JsonToken token = parser.nextToken();
//         double value = parser.getValueAsDouble();
// 
        // THEN
//         assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token);
//         assertEquals(Double.POSITIVE_INFINITY, value);
//     }

    @Test
    @DisplayName("TC19: nextToken() throws exception when parsing 'NaN' with ALLOW_NON_NUMERIC_NUMBERS disabled")
    public void TC19_nextToken_ParseNaN_WithAllowNonNumericNumbersDisabled() throws IOException {
        // GIVEN
        String jsonInput = "NaN";
        byte[] inputBytes = jsonInput.getBytes("UTF-8");
        DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(inputBytes));
        IOContext ioContext = new IOContext(null, null, false);
        int features = 0; // ALLOW_NON_NUMERIC_NUMBERS is disabled
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, features, dataInput, null, sym, 0);

        // WHEN & THEN
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("Non-standard token 'NaN'") || exception.getMessage().contains("Invalid token"));
    }

    @Test
    @DisplayName("TC20: nextToken() throws exception when parsing 'Infinity' with ALLOW_NON_NUMERIC_NUMBERS disabled")
    public void TC20_nextToken_ParseInfinity_WithAllowNonNumericNumbersDisabled() throws IOException {
        // GIVEN
        String jsonInput = "Infinity";
        byte[] inputBytes = jsonInput.getBytes("UTF-8");
        DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(inputBytes));
        IOContext ioContext = new IOContext(null, null, false);
        int features = 0; // ALLOW_NON_NUMERIC_NUMBERS is disabled
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, features, dataInput, null, sym, 0);

        // WHEN & THEN
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("Non-standard token 'Infinity'") || exception.getMessage().contains("Invalid token"));
    }

//     @Test
//     @DisplayName("TC21: nextToken() parses numbers with leading zeros correctly when ALLOW_LEADING_ZEROS is enabled")
//     public void TC21_nextToken_ParseNumberWithLeadingZeros_WithAllowLeadingZerosEnabled() throws IOException {
        // GIVEN
//         String jsonInput = "0123";
//         byte[] inputBytes = jsonInput.getBytes("UTF-8");
//         DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(inputBytes));
//         IOContext ioContext = new IOContext(null, null, false);
//         int features = JsonReadFeature.ALLOW_LEADING_ZEROS.mappedFeature();
//         ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
//         UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ioContext, features, dataInput, null, sym, 0);
// 
        // WHEN
//         JsonToken token = parser.nextToken();
//         int value = parser.getValueAsInt();
// 
        // THEN
//         assertEquals(JsonToken.VALUE_NUMBER_INT, token);
//         assertEquals(123, value);
//     }
}