package org.jfree.chart;

import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertNull;

public class ChartPanel_mouseReleased_0_8_Test {

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, minimal zoom area calculation, ensuring no negative dimensions")
    void TC36() throws Exception {
        // Initialize ChartPanel instance
        ChartPanel panel = new ChartPanel(null);

        // Use reflection to set private fields
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        Rectangle2D minimalZoomRectangle = new Rectangle2D.Double(100, 100, 1, 1); // minimal non-negative dimensions
        zoomRectangleField.set(panel, minimalZoomRectangle);

        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        Point2D zoomPoint = new Point2D.Double(100, 100);
        zoomPointField.set(panel, zoomPoint);

        // Create a minimal MouseEvent
        MouseEvent event = new MouseEvent(panel, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(), 0, 101, 101, 1, false);

        // Invoke the method under test
        panel.mouseReleased(event);

        // Assertions to verify zoomArea dimensions and zoom execution
        // Since zoomArea is not exposed, we can verify post-conditions such as zoomRectangle being null
        assertNull(zoomRectangleField.get(panel), "zoomRectangle should be null after zoom operation");
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation HORIZONTAL, zoomTrigger1 true on left side")
    void TC37() throws Exception {
        // Initialize ChartPanel instance
        ChartPanel panel = new ChartPanel(null);

        // Use reflection to set private fields
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        Rectangle2D zoomRectangle = new Rectangle2D.Double(50, 50, 100, 100);
        zoomRectangleField.set(panel, zoomRectangle);

        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        Field zoomTriggerDistanceField = ChartPanel.class.getDeclaredField("zoomTriggerDistance");
        zoomTriggerDistanceField.setAccessible(true);
        zoomTriggerDistanceField.setInt(panel, 10);

        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        Point2D zoomPoint = new Point2D.Double(100, 100);
        zoomPointField.set(panel, zoomPoint);

        // Create a MouseEvent with x < zoomPoint.getX() to trigger left side zoom
        MouseEvent event = new MouseEvent(panel, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(), 0, 85, 100, 1, false);

        // Invoke the method under test
        panel.mouseReleased(event);

        // Assertions to verify that restoreAutoBounds was called
        // Checking post-conditions such as zoomRectangle and zoomPoint being null
        assertNull(zoomRectangleField.get(panel), "zoomRectangle should be null after restoring auto bounds");
        assertNull(zoomPointField.get(panel), "zoomPoint should be null after restoring auto bounds");
    }

}