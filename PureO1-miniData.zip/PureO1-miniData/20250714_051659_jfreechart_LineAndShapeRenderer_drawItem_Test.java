import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

class LineAndShapeRendererTest {

    private LineAndShapeRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;
    private EntityCollection entities;

    @BeforeEach
    void setUp() {
        renderer = new LineAndShapeRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);
        entities = mock(EntityCollection.class);

        when(state.getVisibleSeriesIndex(anyInt())).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(state.getEntityCollection()).thenReturn(entities);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getDataset(anyInt())).thenReturn(dataset);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any()))
                .thenReturn(50.0);
        when(domainAxis.getCategorySeriesMiddle(anyInt(), anyInt(), anyInt(), anyInt(), anyDouble(), any(), any()))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(), any()))
                .thenReturn(100.0);
    }

    @Test
    @DisplayName("Test drawItem when item is not visible")
    void testDrawItem_ItemNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Test drawItem when lines and shapes are not visible")
    void testDrawItem_LinesAndShapesNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(false);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Test drawItem when dataset value is null")
    void testDrawItem_ValueIsNull() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Test drawItem when visibleRow is negative")
    void testDrawItem_VisibleRowNegative() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(-1);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Test drawItem pass 0 with line visible, column > 0, previousValue not null, vertical orientation")
    void testDrawItem_Pass0_LineVisible_ColumnGreaterThanZero_PreviousValueNotNull_Vertical() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, -1)).thenReturn(5.0);
        when(domainAxis.getCategoryMiddle(0, 1, 0, plot.getDomainAxisEdge())).thenReturn(50.0);
        when(domainAxis.getCategoryMiddle(-1, 1, 0, plot.getDomainAxisEdge())).thenReturn(45.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).setStroke(renderer.getItemStroke(0, 0));
        verify(g2).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("Test drawItem pass 0 with line not visible")
    void testDrawItem_Pass0_LineNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(false);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Test drawItem pass 0 with column equals 0")
    void testDrawItem_Pass0_ColumnEqualsZero() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Test drawItem pass 0 with previousValue null")
    void testDrawItem_Pass0_PreviousValueNull() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 1)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 1)).thenReturn(true);
        when(dataset.getValue(0, 1)).thenReturn(10.0);
        when(dataset.getValue(0, 0)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("Test drawItem pass 0 with horizontal orientation")
    void testDrawItem_Pass0_HorizontalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 1)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 1)).thenReturn(true);
        when(dataset.getValue(0, 1)).thenReturn(10.0);
        when(dataset.getValue(0, 0)).thenReturn(5.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        verify(g2).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("Test drawItem pass 1 with shape visible and filled, useFillPaint true, drawOutlines true, useOutlinePaint true")
    void testDrawItem_Pass1_ShapeVisibleFilled_UseFillPaint_DrawOutlines_UseOutlinePaint() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(false);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeFilled(0, 0)).thenReturn(true);
        renderer.setUseFillPaint(true);
        renderer.setDrawOutlines(true);
        renderer.setUseOutlinePaint(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(Shape.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Test drawItem pass 1 with shape not visible")
    void testDrawItem_Pass1_ShapeNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(false);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(false);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Test drawItem pass 1 with drawOutlines false")
    void testDrawItem_Pass1_DrawOutlinesFalse() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(false);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeFilled(0, 0)).thenReturn(true);
        renderer.setUseFillPaint(false);
        renderer.setDrawOutlines(false);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Test drawItem pass 1 with horizontal orientation and item label visible")
    void testDrawItem_Pass1_HorizontalOrientation_ItemLabelVisible() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(false);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeFilled(0, 0)).thenReturn(false);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        verify(renderer).drawItemLabel(eq(g2), eq(PlotOrientation.HORIZONTAL), eq(dataset), eq(0), eq(0), eq(100.0), eq(50.0), eq(false));
    }

    @Test
    @DisplayName("Test drawItem pass 1 with vertical orientation and item label not visible")
    void testDrawItem_Pass1_VerticalOrientation_ItemLabelNotVisible() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(false);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeFilled(0, 0)).thenReturn(false);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(false);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        verify(renderer, never()).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("Test drawItem with null Graphics2D")
    void testDrawItem_NullGraphics2D() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        // Expect NullPointerException
        org.junit.jupiter.api.Assertions.assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(null, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    @DisplayName("Test drawItem with null dataArea")
    void testDrawItem_NullDataArea() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        // Expect NullPointerException
        org.junit.jupiter.api.Assertions.assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, null, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    @DisplayName("Test drawItem with useSeriesOffset true and itemMargin set")
    void testDrawItem_UseSeriesOffset_ItemMarginSet() {
        renderer.setUseSeriesOffset(true);
        renderer.setItemMargin(0.2);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, -1)).thenReturn(5.0);
        when(domainAxis.getCategorySeriesMiddle(0, 1, 0, 1, 0.2, dataArea, plot.getDomainAxisEdge()))
                .thenReturn(60.0);
        when(domainAxis.getCategorySeriesMiddle(-1, 1, 0, 1, 0.2, dataArea, plot.getDomainAxisEdge()))
                .thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).setPaint(renderer.getItemPaint(0, 0));
        verify(g2).setStroke(renderer.getItemStroke(0, 0));
        verify(g2).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("Test drawItem with itemMargin out of bounds")
    void testDrawItem_ItemMarginOutOfBounds() {
        // Expect IllegalArgumentException
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> {
            renderer.setItemMargin(-0.1);
        });
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> {
            renderer.setItemMargin(1.0);
        });
    }

    @Test
    @DisplayName("Test drawItem with multiple passes")
    void testDrawItem_MultiplePasses() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, -1)).thenReturn(5.0);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2).draw(any(Line2D.class));
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        verify(g2, times(2)).setPaint(any(Paint.class));
        verify(g2, times(1)).fill(any(Shape.class));
    }

    @Test
    @DisplayName("Test drawItem with null dataset")
    void testDrawItem_NullDatasetValue() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(renderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verifyNoInteractions(g2);
    }
}