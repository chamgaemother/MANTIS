package org.apache.commons.lang3;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.BooleanUtils;

public class BooleanUtils_toBooleanObject_0_7_Test {

    @Test
    @DisplayName("Input string is two characters 'OF', returns Boolean.FALSE")
    void TC31() {
        String input = "OF";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string is three characters 'YeS', returns Boolean.TRUE")
    void TC32() {
        String input = "YeS";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is four characters 'TRUE', returns Boolean.TRUE")
    void TC33() {
        String input = "TRUE";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input string is five characters 'False', returns Boolean.FALSE")
    void TC34() {
        String input = "False";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input string is three characters 'noo', returns Boolean.FALSE")
    void TC35() {
        String input = "noo";
        Boolean result = BooleanUtils.toBooleanObject(input);
        assertEquals(Boolean.FALSE, result);
    }

}