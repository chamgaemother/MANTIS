package org.jsoup.internal;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CoderResult;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class SimpleStreamReader_read_0_4_Test {

    @Test
    @DisplayName("read with charBuf position remains 0 after decode, expecting -1")
    void TC16_readCharBufPositionZero_returnsMinusOne() throws Exception {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;

        // Mock dependencies
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.available()).thenReturn(0);

        CharsetDecoder mockDecoder = mock(Charset.class).newDecoder();
        CoderResult mockCoderResult = CoderResult.UNDERFLOW;
        when(mockDecoder.decode(any(ByteBuffer.class), any(CharBuffer.class), Mockito.anyBoolean()))
            .thenReturn(mockCoderResult);

        // Instantiate SimpleStreamReader
        SimpleStreamReader reader = new SimpleStreamReader(mockInputStream, Charset.defaultCharset());

        // Use reflection to set private fields
        Field decoderField = SimpleStreamReader.class.getDeclaredField("decoder");
        decoderField.setAccessible(true);
        decoderField.set(reader, mockDecoder);

        Field byteBufField = SimpleStreamReader.class.getDeclaredField("byteBuf");
        byteBufField.setAccessible(true);
        byteBufField.set(reader, ByteBuffer.allocate(0));

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertEquals(-1, result);
    }
}