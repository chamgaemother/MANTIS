package org.apache.commons.math3.special;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Test class for Beta#regularizedBeta method.
 */
public class Beta_regularizedBeta_0_4_Test {

    @Test
    @DisplayName("Minimal valid input parameters")
    void test_TC16_MinimalValidInputParameters() {
        // Given
        double x = 0.1;
        double a = 0.1;
        double b = 0.1;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // When
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // Then
        assertTrue(result >= 0.0 && result <= 1.0, "The result should be between 0.0 and 1.0");
    }
}