import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.general.DatasetUtils;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DatasetUtilsTest {

    @Test
    public void testIterateToFindDomainBounds_NullDataset() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(null, Arrays.asList("Series1"), true);
        });
    }

    @Test
    public void testIterateToFindDomainBounds_NullVisibleSeriesKeys() {
        XYDataset dataset = mock(XYDataset.class);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(dataset, null, true);
        });
    }

    @Test
    public void testIterateToFindDomainBounds_ValidInputWithEmptySeriesKeys() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, Collections.emptyList(), true);
        assertNull(result);
    }

    @Test
    public void testIterateToFindDomainBounds_IntervalXYDatasetWithValidRange() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getStartXValue(0, 1)).thenReturn(1.5);
        when(dataset.getEndXValue(0, 1)).thenReturn(2.5);

        List<String> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);

        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, true);
        assertEquals(new Range(0.5, 2.5), result);
    }

    @Test
    public void testIterateToFindDomainBounds_XYDatasetWithInvalidRange() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);

        List<String> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);

        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNull(result);
    }

    @Test
    public void testIterateToFindDomainBounds_XYDatasetWithNaNValues() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);

        List<String> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);

        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertEquals(new Range(3.0, 3.0), result);
    }

    @Test
    public void testIterateToFindDomainBounds_MultipleSeriesStandardXYDataset() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(4.0);
        when(dataset.getItemCount(1)).thenReturn(2);
        when(dataset.getXValue(1, 0)).thenReturn(2.0);
        when(dataset.getXValue(1, 1)).thenReturn(3.0);

        List<String> visibleSeriesKeys = Arrays.asList("Series1", "Series2");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.indexOf("Series2")).thenReturn(1);

        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertEquals(new Range(1.0, 4.0), result);
    }
}