package org.jfree.chart.plot;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.ui.Layer;
import org.jfree.chart.util.ShadowGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CategoryPlot_draw_0_3_Test {

    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotState state;
    private PlotRenderingInfo info;
    private CategoryPlot categoryPlot;

    @BeforeEach
    public void setup() {
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 500, 500);
        anchor = new Point2D.Double(250, 250);
        state = new PlotState();
        info = new PlotRenderingInfo(null);
        categoryPlot = new CategoryPlot();
    }

    @Test
    @DisplayName("Draw method handles shadow suppression when rendering hint is set")
    public void TC11() throws Exception {
        // GIVEN
        ShadowGenerator shadowGenerator = mock(ShadowGenerator.class);
        Field shadowGenField = CategoryPlot.class.getDeclaredField("shadowGenerator");
        shadowGenField.setAccessible(true);
        shadowGenField.set(categoryPlot, shadowGenerator);

        when(g2.getRenderingHint(JFreeChart.KEY_SUPPRESS_SHADOW_GENERATION)).thenReturn(Boolean.TRUE);

        // WHEN
        categoryPlot.draw(g2, area, anchor, state, info);

        // THEN
        verify(shadowGenerator, never()).createDropShadow(any(BufferedImage.class));
    }

//     @Test
//     @DisplayName("Draw method handles no data scenario by displaying no data message")
//     public void TC12() throws Exception {
        // GIVEN
//         CategoryPlot spyPlot = Mockito.spy(categoryPlot);
//         doReturn(new java.util.ArrayList<>()).when(spyPlot).getDatasetIndices(any());
// 
        // WHEN
//         spyPlot.draw(g2, area, anchor, state, info);
// 
        // THEN
//         verify(spyPlot).drawNoDataMessage(g2, area);
//     }

    @Test
    @DisplayName("Draw method renders domain and range gridlines when enabled")
    public void TC13() throws Exception {
        // GIVEN
        categoryPlot.setDomainGridlinesVisible(true);
        categoryPlot.setRangeGridlinesVisible(true);

        CategoryPlot spyPlot = Mockito.spy(categoryPlot);
        doNothing().when(spyPlot).drawDomainGridlines(g2, any(Rectangle2D.class));
        doNothing().when(spyPlot).drawRangeGridlines(g2, any(Rectangle2D.class), any());

        // WHEN
        spyPlot.draw(g2, area, anchor, state, info);

        // THEN
        verify(spyPlot).drawDomainGridlines(g2, area);
        verify(spyPlot).drawRangeGridlines(g2, area, any());
    }

    @Test
    @DisplayName("Draw method does not render gridlines when they are disabled")
    public void TC14() throws Exception {
        // GIVEN
        categoryPlot.setDomainGridlinesVisible(false);
        categoryPlot.setRangeGridlinesVisible(false);

        CategoryPlot spyPlot = Mockito.spy(categoryPlot);
        doNothing().when(spyPlot).drawDomainGridlines(g2, any(Rectangle2D.class));
        doNothing().when(spyPlot).drawRangeGridlines(g2, any(Rectangle2D.class), any());

        // WHEN
        spyPlot.draw(g2, area, anchor, state, info);

        // THEN
        verify(spyPlot, never()).drawDomainGridlines(g2, area);
        verify(spyPlot, never()).drawRangeGridlines(g2, area, any());
    }

//     @Test
//     @DisplayName("Draw method handles multiple renderer layers correctly")
//     public void TC15() throws Exception {
        // GIVEN
//         CategoryItemRenderer backgroundRenderer = mock(CategoryItemRenderer.class);
//         CategoryItemRenderer foregroundRenderer = mock(CategoryItemRenderer.class);
// 
//         Field renderersField = CategoryPlot.class.getDeclaredField("renderers");
//         renderersField.setAccessible(true);
//         Map<Integer, CategoryItemRenderer> renderers = new HashMap<>();
//         renderers.put(0, backgroundRenderer);
//         renderers.put(1, foregroundRenderer);
//         renderersField.set(categoryPlot, renderers);
// 
        // WHEN
//         categoryPlot.draw(g2, area, anchor, state, info);
// 
        // THEN
//         verify(backgroundRenderer).drawDomainMarkers(g2, area, anyInt(), eq(Layer.BACKGROUND));
//         verify(backgroundRenderer).drawRangeMarkers(g2, area, anyInt(), eq(Layer.BACKGROUND));
//         verify(foregroundRenderer).drawDomainMarkers(g2, area, anyInt(), eq(Layer.FOREGROUND));
//         verify(foregroundRenderer).drawRangeMarkers(g2, area, anyInt(), eq(Layer.FOREGROUND));
//     }

}