package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_createNumber_0_5_Test {

    @Test
    @DisplayName("Input string with exponent but missing mantissa, should throw NumberFormatException")
    void test_TC21_InputStringWithExponentButMissingMantissa_ShouldThrowNumberFormatException() {
        // Given
        String input = "e10";

        // When and Then
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input));
    }

    @Test
    @DisplayName("Input string with multiple leading zeros, should return Integer")
    void test_TC22_InputStringWithMultipleLeadingZeros_ShouldReturnInteger() {
        // Given
        String input = "000012345";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertInstanceOf(Integer.class, result);
        assertEquals(12345, result.intValue());
    }

    @Test
    @DisplayName("Input string with type suffix 'D' and exponent, should return Double")
    void test_TC23_InputStringWithTypeSuffixDAndExponent_ShouldReturnDouble() {
        // Given
        String input = "1.23e10D";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertInstanceOf(Double.class, result);
        assertEquals(1.23e10D, result.doubleValue());
    }

    @Test
    @DisplayName("Input string with decimal point and invalid exponent position, should throw NumberFormatException")
    void test_TC24_InputStringWithDecimalPointAndInvalidExponentPosition_ShouldThrowNumberFormatException() {
        // Given
        String input = "123.45e";

        // When and Then
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(input));
    }

    @Test
    @DisplayName("Input string with positive exponent and valid Double, should return Double")
    void test_TC25_InputStringWithPositiveExponentAndValidDouble_ShouldReturnDouble() {
        // Given
        String input = "1.23e+10";

        // When
        Number result = NumberUtils.createNumber(input);

        // Then
        assertInstanceOf(Double.class, result);
        assertEquals(1.23e+10D, result.doubleValue());
    }
}