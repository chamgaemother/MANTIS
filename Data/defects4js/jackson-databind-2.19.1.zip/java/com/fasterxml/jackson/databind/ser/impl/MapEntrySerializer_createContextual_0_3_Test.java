package com.fasterxml.jackson.databind.ser.impl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MapEntrySerializer_createContextual_0_3_Test {

//     @Test
//     @DisplayName("When valueType is static and java.lang.Object, does not find content value serializer")
//     public void TC11() throws Exception {
//         SerializerProvider provider = mock(SerializerProvider.class);
//         when(provider.getAnnotationIntrospector()).thenReturn(new ObjectMapper().getSerializationConfig().getAnnotationIntrospector());
//         when(provider.constructType(Object.class)).thenReturn(JavaType.construct(Object.class, null, false)); // fixed return with modeled JavaType
// 
//         BeanProperty property = mock(BeanProperty.class);
//         when(property.findPropertyInclusion(any(), any())).thenReturn(null);
// 
//         MapEntrySerializer serializer = new MapEntrySerializer(null, null, null, false, null, null);
// 
//         JsonSerializer<?> result = serializer.createContextual(provider, property);
// 
//         Field valueSerializerField = MapEntrySerializer.class.getDeclaredField("_valueSerializer");
//         valueSerializerField.setAccessible(true);
//         JsonSerializer<?> originalSer = (JsonSerializer<?>) valueSerializerField.get(serializer);
// 
//         assertEquals(originalSer, result);
//     }

    @Test
    @DisplayName("When keySer is null after annotations, uses _keySerializer")
    public void TC12() throws Exception {
        SerializerProvider provider = mock(SerializerProvider.class);
        when(provider.getAnnotationIntrospector()).thenReturn(null);

        BeanProperty property = mock(BeanProperty.class);

        JsonSerializer<Object> defaultKeySer = mock(JsonSerializer.class);
        MapEntrySerializer serializer = new MapEntrySerializer(null, null, null, false, null, null);

        Field keySerializerField = MapEntrySerializer.class.getDeclaredField("_keySerializer");
        keySerializerField.setAccessible(true);
        keySerializerField.set(serializer, defaultKeySer);

        JsonSerializer<?> result = serializer.createContextual(provider, property);

        JsonSerializer<?> originalKeySer = (JsonSerializer<?>) keySerializerField.get(serializer);
        assertEquals(originalKeySer, result);
    }

//     @Test
//     @DisplayName("When handleSecondaryContextualization is invoked on keySer")
//     public void TC13() throws Exception {
//         SerializerProvider provider = mock(SerializerProvider.class);
//         JsonSerializer<Object> customKeySerializer = mock(JsonSerializer.class);
//         when(provider.handleSecondaryContextualization(any(), any())).thenReturn(customKeySerializer);
// 
//         BeanProperty property = mock(BeanProperty.class);
// 
//         JsonSerializer<?> initialKeySer = mock(JsonSerializer.class);
//         MapEntrySerializer serializer = new MapEntrySerializer(null, null, null, false, null, null);
// 
//         Field keySerializerField = MapEntrySerializer.class.getDeclaredField("_keySerializer");
//         keySerializerField.setAccessible(true);
//         keySerializerField.set(serializer, initialKeySer);
// 
//         JsonSerializer<?> result = serializer.createContextual(provider, property);
// 
//         assertNotNull(result);
//         assertEquals(customKeySerializer, result);
//     }

    @Test
    @DisplayName("When suppressableValue is set to default value and is non-null array")
    public void TC14() throws Exception {
        SerializerProvider provider = mock(SerializerProvider.class);
        when(provider.getAnnotationIntrospector()).thenReturn(new ObjectMapper().getSerializationConfig().getAnnotationIntrospector());
        when(provider.includeFilterSuppressNulls(any())).thenReturn(true);

        BeanProperty property = mock(BeanProperty.class);
        when(property.findPropertyInclusion(any(), any())).thenReturn(
            JsonInclude.Value.construct(JsonInclude.Include.NON_DEFAULT, JsonInclude.Include.ALWAYS));

        MapEntrySerializer serializer = new MapEntrySerializer(null, null, null, false, null, null);

        String[] defaultArray = {"default"};
        Field suppressableValueField = MapEntrySerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        suppressableValueField.set(serializer, defaultArray);

        JsonSerializer<?> result = serializer.createContextual(provider, property);

        Object valueToSuppress = suppressableValueField.get(serializer);

        assertNotNull(valueToSuppress);
        assertTrue(valueToSuppress instanceof String[]);
    }

    @Test
    @DisplayName("When content inclusion is NON_ABSENT and value type is reference, sets MarkerForEmpty")
    public void TC15() throws Exception {
        SerializerProvider provider = mock(SerializerProvider.class);
        when(provider.getAnnotationIntrospector()).thenReturn(new ObjectMapper().getSerializationConfig().getAnnotationIntrospector());

        BeanProperty property = mock(BeanProperty.class);
        when(property.findPropertyInclusion(any(), any())).thenReturn(
            JsonInclude.Value.construct(JsonInclude.Include.NON_ABSENT, JsonInclude.Include.NON_ABSENT));

        MapEntrySerializer serializer = new MapEntrySerializer(null, null, null, true, null, null);

        JsonSerializer<?> result = serializer.createContextual(provider, property);

        Field suppressableValueField = MapEntrySerializer.class.getDeclaredField("_suppressableValue");
        suppressableValueField.setAccessible(true);
        Object valueToSuppress = suppressableValueField.get(serializer);

        Field suppressNullsField = MapEntrySerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        boolean suppressNulls = suppressNullsField.getBoolean(serializer);

        Field markerField = MapEntrySerializer.class.getDeclaredField("MARKER_FOR_EMPTY");
        markerField.setAccessible(true);
        Object marker = markerField.get(null);

        assertEquals(marker, valueToSuppress);
        assertTrue(suppressNulls);
    }
}