import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FastMathTest {

    @Test
    public void testAtan2NaN() {
        assertTrue(Double.isNaN(FastMath.atan2(Double.NaN, 1.0)));
        assertTrue(Double.isNaN(FastMath.atan2(1.0, Double.NaN)));
        assertTrue(Double.isNaN(FastMath.atan2(Double.NaN, Double.NaN)));
    }

    @Test
    public void testAtan2ZeroX() {
        assertEquals(0.0, FastMath.atan2(0.0, Double.POSITIVE_INFINITY), 1e-15);
        assertEquals(Math.PI, FastMath.atan2(0.0, Double.NEGATIVE_INFINITY), 1e-15);
        assertEquals(-0.0, FastMath.atan2(-0.0, Double.POSITIVE_INFINITY), 1e-15);
        assertEquals(-Math.PI, FastMath.atan2(-0.0, Double.NEGATIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2ZeroY() {
        assertEquals(0.0, FastMath.atan2(0.0, 1.0), 1e-15);
        assertEquals(Math.PI, FastMath.atan2(-0.0, -1.0), 1e-15);
        assertEquals(Math.PI, FastMath.atan2(0.0, -1.0), 1e-15);
        assertEquals(-0.0, FastMath.atan2(-0.0, 1.0), 1e-15);
    }

    @Test
    public void testAtan2InfinityY() {
        assertEquals(Math.PI / 2, FastMath.atan2(Double.POSITIVE_INFINITY, 1.0), 1e-15);
        assertEquals(-Math.PI / 2, FastMath.atan2(Double.NEGATIVE_INFINITY, 1.0), 1e-15);
    }

    @Test
    public void testAtan2InfinityX() {
        assertEquals(0.0, FastMath.atan2(1.0, Double.POSITIVE_INFINITY), 1e-15);
        assertEquals(FastMath.PI, FastMath.atan2(1.0, Double.NEGATIVE_INFINITY), 1e-15);
        assertEquals(-0.0, FastMath.atan2(-1.0, Double.POSITIVE_INFINITY), 1e-15);
        assertEquals(-FastMath.PI, FastMath.atan2(-1.0, Double.NEGATIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2BothInfinities() {
        assertEquals(Math.PI / 4, FastMath.atan2(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY), 1e-15);
        assertEquals(3 * Math.PI / 4, FastMath.atan2(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY), 1e-15);
        assertEquals(-Math.PI / 4, FastMath.atan2(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY), 1e-15);
        assertEquals(-3 * Math.PI / 4, FastMath.atan2(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY), 1e-15);
    }

    @Test
    public void testAtan2FiniteValues() {
        assertEquals(Math.atan2(1.0, 1.0), FastMath.atan2(1.0, 1.0), 1e-15);
        assertEquals(Math.atan2(-1.0, 1.0), FastMath.atan2(-1.0, 1.0), 1e-15);
        assertEquals(Math.atan2(1.0, -1.0), FastMath.atan2(1.0, -1.0), 1e-15);
        assertEquals(Math.atan2(-1.0, -1.0), FastMath.atan2(-1.0, -1.0), 1e-15);
    }
}