package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.HashMap;

public class Flat3Map_get_0_1_Test {

    @Test
    @DisplayName("Delegate map is not null and returns a valid value for a given key")
    void TC01() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Setup delegateMap with existing key
        HashMap<Object, Object> delegateMap = new HashMap<>();
        Object existingKey = "existingKey";
        Object expectedValue = "expectedValue";
        delegateMap.put(existingKey, expectedValue);

        // Use reflection to set the private delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegateMap);

        // Invoke the get method
        Object result = map.get(existingKey);

        // Assert the result
        assertEquals(expectedValue, result);
    }

    @Test
    @DisplayName("Delegate map is not null and returns null for a non-existing key")
    void TC02() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Setup delegateMap without the key
        HashMap<Object, Object> delegateMap = new HashMap<>();
        Object existingKey = "existingKey";
        delegateMap.put(existingKey, "someValue");

        // Use reflection to set the private delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegateMap);

        // Invoke the get method with a non-existing key
        Object nonExistingKey = "nonExistingKey";
        Object result = map.get(nonExistingKey);

        // Assert the result is null
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null and key is null with size=0")
    void TC03() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set the private delegateMap field to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Use reflection to set the size field to 0
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        // Invoke the get method with null key
        Object result = map.get(null);

        // Assert the result is null
        assertNull(result);
    }

    @Test
    @DisplayName("Delegate map is null, key is null, and size=1 with key1=null")
    void TC04() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set the private delegateMap field to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Use reflection to set the size field to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Use reflection to set key1 to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // Use reflection to set value1
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = "value1";
        value1Field.set(map, value1);

        // Invoke the get method with null key
        Object result = map.get(null);

        // Assert the result equals value1
        assertEquals(value1, result);
    }

    @Test
    @DisplayName("Delegate map is null, key is null, and size=1 with key1 not null")
    void TC05() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set the private delegateMap field to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Use reflection to set the size field to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Use reflection to set key1 to a non-null value
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object key1 = "key1";
        key1Field.set(map, key1);

        // Invoke the get method with null key
        Object result = map.get(null);

        // Assert the result is null
        assertNull(result);
    }
}