package org.apache.commons.math3.ode.events;

import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.apache.commons.math3.analysis.solvers.UnivariateSolver;
import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import java.lang.reflect.Field;

public class EventState_evaluateStep_0_4_Test {

//    @Test
//    @DisplayName("evaluateStep checks previousEventTime as NaN and sets pendingEventTime")
//    public void TC16_evaluateStep_sets_pendingEventTime_when_previousEventTime_is_NaN() throws Exception {
//        EventHandler handler = Mockito.mock(EventHandler.class);
//        Mockito.when(handler.g(Mockito.anyDouble(), Mockito.any(double[].class))).thenReturn(-1.0);
//
//        UnivariateSolver solver = Mockito.mock(UnivariateSolver.class);
//        Mockito.when(solver.solve(Mockito.anyInt(), Mockito.any(UnivariateFunction.class), Mockito.anyDouble(), Mockito.anyDouble(), Mockito.any(AllowedSolution.class))).thenReturn(1.5);
//        Mockito.when(solver.getEvaluations()).thenReturn(10);
//
//        EventState eventState = new EventState(handler, 10.0, 1e-6, 100, solver);
//
//        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
//        Mockito.when(interpolator.isForward()).thenReturn(true);
//        Mockito.when(interpolator.getCurrentTime()).thenReturn(2.0);
//
//        setPrivateField(eventState, "t0", 1.0);
//        setPrivateField(eventState, "g0", -1.0);
//        setPrivateField(eventState, "forward", true);
//        setPrivateField(eventState, "previousEventTime", Double.NaN);
//
//        boolean result = eventState.evaluateStep(interpolator);
//
//        double pendingEventTime = (double) getPrivateField(eventState, "pendingEventTime");
//
//        assertEquals(1.5, pendingEventTime, 1e-9, "pendingEventTime should be set to root");
//        assertTrue(result, "evaluateStep should return true");
//    }
//
//    @Test
//    @DisplayName("evaluateStep sets pendingEventTime when previousEventTime is NaN")
//    public void TC17_evaluateStep_sets_pendingEventTime_with_previousEventTime_as_NaN() throws Exception {
//        EventHandler handler = Mockito.mock(EventHandler.class);
//        Mockito.when(handler.g(Mockito.anyDouble(), Mockito.any(double[].class))).thenReturn(1.0);
//
//        UnivariateSolver solver = Mockito.mock(UnivariateSolver.class);
//        Mockito.when(solver.solve(Mockito.anyInt(), Mockito.any(UnivariateFunction.class), Mockito.anyDouble(), Mockito.anyDouble(), Mockito.any(AllowedSolution.class))).thenReturn(2.5);
//        Mockito.when(solver.getEvaluations()).thenReturn(8);
//
//        EventState eventState = new EventState(handler, 5.0, 1e-6, 50, solver);
//
//        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
//        Mockito.when(interpolator.isForward()).thenReturn(true);
//        Mockito.when(interpolator.getCurrentTime()).thenReturn(3.0);
//
//        setPrivateField(eventState, "t0", 1.5);
//        setPrivateField(eventState, "g0", 1.0);
//        setPrivateField(eventState, "forward", true);
//        setPrivateField(eventState, "previousEventTime", Double.NaN);
//
//        boolean result = eventState.evaluateStep(interpolator);
//
//        double pendingEventTime = (double) getPrivateField(eventState, "pendingEventTime");
//
//        assertEquals(2.5, pendingEventTime, 1e-9, "pendingEventTime should be set to root");
//        assertTrue(result, "evaluateStep should return true");
//    }
//
//    @Test
//    @DisplayName("evaluateStep sets pendingEventTime when root - previousEventTime > convergence")
//    public void TC18_evaluateStep_sets_pendingEventTime_when_root_minus_previousEventTime_greater_than_convergence() throws Exception {
//        EventHandler handler = Mockito.mock(EventHandler.class);
//        Mockito.when(handler.g(Mockito.anyDouble(), Mockito.any(double[].class))).thenReturn(-2.0);
//
//        UnivariateSolver solver = Mockito.mock(UnivariateSolver.class);
//        Mockito.when(solver.solve(Mockito.anyInt(), Mockito.any(UnivariateFunction.class), Mockito.anyDouble(), Mockito.anyDouble(), Mockito.any(AllowedSolution.class))).thenReturn(3.5);
//        Mockito.when(solver.getEvaluations()).thenReturn(15);
//
//        EventState eventState = new EventState(handler, 2.0, 1e-6, 200, solver);
//
//        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
//        Mockito.when(interpolator.isForward()).thenReturn(false);
//        Mockito.when(interpolator.getCurrentTime()).thenReturn(4.0);
//
//        setPrivateField(eventState, "t0", 2.0);
//        setPrivateField(eventState, "g0", -2.0);
//        setPrivateField(eventState, "forward", false);
//        setPrivateField(eventState, "previousEventTime", 1.0);
//
//        boolean result = eventState.evaluateStep(interpolator);
//
//        double pendingEventTime = (double) getPrivateField(eventState, "pendingEventTime");
//
//        assertEquals(3.5, pendingEventTime, 1e-9, "pendingEventTime should be updated to new root");
//        assertTrue(result, "evaluateStep should return true");
//    }
//
//    @Test
//    @DisplayName("evaluateStep does not set pendingEventTime when root - previousEventTime <= convergence")
//    public void TC19_evaluateStep_does_not_set_pendingEventTime_when_root_minus_previousEventTime_less_or_equal_to_convergence() throws Exception {
//        EventHandler handler = Mockito.mock(EventHandler.class);
//        Mockito.when(handler.g(Mockito.anyDouble(), Mockito.any(double[].class))).thenReturn(0.5);
//
//        UnivariateSolver solver = Mockito.mock(UnivariateSolver.class);
//        Mockito.when(solver.solve(Mockito.anyInt(), Mockito.any(UnivariateFunction.class), Mockito.anyDouble(), Mockito.anyDouble(), Mockito.any(AllowedSolution.class))).thenReturn(4.999999);
//        Mockito.when(solver.getEvaluations()).thenReturn(20);
//
//        EventState eventState = new EventState(handler, 1.0, 1e-6, 150, solver);
//
//        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
//        Mockito.when(interpolator.isForward()).thenReturn(true);
//        Mockito.when(interpolator.getCurrentTime()).thenReturn(5.0);
//
//        setPrivateField(eventState, "t0", 4.0);
//        setPrivateField(eventState, "g0", 0.5);
//        setPrivateField(eventState, "forward", true);
//        setPrivateField(eventState, "previousEventTime", 4.999999);
//
//        boolean result = eventState.evaluateStep(interpolator);
//
//        double pendingEventTime = (double) getPrivateField(eventState, "pendingEventTime");
//        boolean pendingEvent = (boolean) getPrivateField(eventState, "pendingEvent");
//
//        assertTrue(Double.isNaN(pendingEventTime), "pendingEventTime should not be set");
//        assertFalse(pendingEvent, "evaluateStep should return false");
//        assertFalse(result, "evaluateStep should return false");
//    }

    @Test
    @DisplayName("evaluateStep handles solver not being BracketedUnivariateSolver and sets pendingEventTime")
    public void TC20_evaluateStep_handles_nonBracketedUnivariateSolver_and_sets_pendingEventTime() throws Exception {
        EventHandler handler = Mockito.mock(EventHandler.class);
        Mockito.when(handler.g(Mockito.anyDouble(), Mockito.any(double[].class))).thenReturn(-3.0);

        UnivariateSolver solver = Mockito.mock(UnivariateSolver.class);
        Mockito.when(solver.solve(Mockito.anyInt(), Mockito.any(UnivariateFunction.class), Mockito.anyDouble(), Mockito.anyDouble())).thenReturn(5.5);
        Mockito.when(solver.getEvaluations()).thenReturn(25);

        EventState eventState = new EventState(handler, 1.0, 1e-6, 100, solver);

        StepInterpolator interpolator = Mockito.mock(StepInterpolator.class);
        Mockito.when(interpolator.isForward()).thenReturn(false);
        Mockito.when(interpolator.getCurrentTime()).thenReturn(6.0);

        setPrivateField(eventState, "t0", 5.0);
        setPrivateField(eventState, "g0", -3.0);
        setPrivateField(eventState, "forward", false);
        setPrivateField(eventState, "previousEventTime", 4.0);

        boolean result = eventState.evaluateStep(interpolator);

        double pendingEventTime = (double) getPrivateField(eventState, "pendingEventTime");

        assertEquals(5.5, pendingEventTime, 1e-9, "pendingEventTime should be set to root");
        assertTrue(result, "evaluateStep should return true");
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = EventState.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private Object getPrivateField(Object target, String fieldName) throws Exception {
        Field field = EventState.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(target);
    }
}