package org.apache.commons.jxpath.ri.model.dom;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class DOMNodePointer_getNamespaceURI_0_1_Test {

//     @Test
//     @DisplayName("getNamespaceURI(null) returns the default namespace URI")
//     void TC01_getNamespaceURI_null_returnsDefaultNamespaceURI() throws Exception {
        // GIVEN
//         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//         factory.setNamespaceAware(true); // Make sure namespace awareness is enabled
//         DocumentBuilder builder = factory.newDocumentBuilder();
//         Document document = builder.newDocument();
//         Element root = document.createElement("root");
//         root.setAttribute("xmlns", "http://default.namespace.uri/");
//         document.appendChild(root);
//         DOMNodePointer pointer = new DOMNodePointer(document.getDocumentElement(), null);
// 
        // Access getDefaultNamespaceURI via reflection
//         Method getDefaultNamespaceURIMethod = DOMNodePointer.class.getDeclaredMethod("getDefaultNamespaceURI");
//         getDefaultNamespaceURIMethod.setAccessible(true); // Make private method accessible
//         String expected = (String) getDefaultNamespaceURIMethod.invoke(pointer);
// 
        // WHEN
//         String result = pointer.getNamespaceURI(null);
// 
        // THEN
//         assertEquals(expected, result, "The default namespace URI should be returned when prefix is null");
//     }

    @Test
    @DisplayName("getNamespaceURI empty string returns the default namespace URI")
    void TC02_getNamespaceURI_emptyString_returnsDefaultNamespaceURI() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true); // Ensure namespace awareness
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        root.setAttribute("xmlns", "http://default.namespace.uri/");
        document.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(document.getDocumentElement(), null);

        // Access getDefaultNamespaceURI via reflection
        Method getDefaultNamespaceURIMethod = DOMNodePointer.class.getDeclaredMethod("getDefaultNamespaceURI");
        getDefaultNamespaceURIMethod.setAccessible(true); // For invoking the private method
        String expected = (String) getDefaultNamespaceURIMethod.invoke(pointer);

        // WHEN
        String result = pointer.getNamespaceURI("");

        // THEN
        assertEquals(expected, result, "The default namespace URI should be returned when prefix is empty string");
    }

    @Test
    @DisplayName("getNamespaceURI(\"xml\") returns the XML namespace URI")
    void TC03_getNamespaceURI_xml_returnsXMLNamespaceURI() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true); // Ensure namespace awareness
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        document.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(document.getDocumentElement(), null);

        // WHEN
        String result = pointer.getNamespaceURI("xml");

        // THEN
        assertEquals(DOMNodePointer.XML_NAMESPACE_URI, result, "The XML namespace URI should be returned for prefix 'xml'");
    }

    @Test
    @DisplayName("getNamespaceURI(\"xmlns\") returns the XMLNS namespace URI")
    void TC04_getNamespaceURI_xmlns_returnsXMLNSNamespaceURI() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true); // Ensure namespace awareness
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        document.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(document.getDocumentElement(), null);

        // WHEN
        String result = pointer.getNamespaceURI("xmlns");

        // THEN
        assertEquals(DOMNodePointer.XMLNS_NAMESPACE_URI, result, "The XMLNS namespace URI should be returned for prefix 'xmlns'");
    }

    @Test
    @DisplayName("getNamespaceURI with new prefix initializes namespaces map")
    void TC05_getNamespaceURI_newPrefix_initializesNamespacesMap() throws Exception {
        // GIVEN
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true); // Ensure namespace awareness
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("root");
        root.setAttribute("xmlns:newPrefix", "http://new.prefix.uri/");
        document.appendChild(root);
        DOMNodePointer pointer = new DOMNodePointer(document.getDocumentElement(), null);

        // Access 'namespaces' field via reflection
        Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
        namespacesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
        assertTrue(namespaces == null || namespaces.isEmpty(), "Namespaces map should be null or empty before the method call");

        // WHEN
        String result = pointer.getNamespaceURI("newPrefix");

        // THEN
        // Access 'namespaces' field again to verify it was initialized
        namespaces = (Map<String, String>) namespacesField.get(pointer);
        assertTrue(namespaces.containsKey("newPrefix"), "Namespaces map should contain the new prefix after the method call");
        assertEquals("http://new.prefix.uri/", namespaces.get("newPrefix"), "The namespace URI should match the defined value for 'newPrefix'");
        assertEquals("http://new.prefix.uri/", result, "The resolved namespace URI should be returned for 'newPrefix'");
    }
}