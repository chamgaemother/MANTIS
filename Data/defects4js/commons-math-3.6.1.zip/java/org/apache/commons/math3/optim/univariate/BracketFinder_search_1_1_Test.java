package org.apache.commons.math3.optim.univariate;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.*;

public class BracketFinder_search_1_1_Test {

    @Test
    @DisplayName("TC24: search method where FastMath.abs(val) < EPS_MIN, setting denom to 2 * EPS_MIN to prevent division by zero")
    void TC24_search_DenomBelowEPSMin() {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.0;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(1.0)).thenReturn(1.0);
        when(func.value(2.0)).thenReturn(1.0);
        when(func.value(anyDouble())).thenReturn(1.0);

        // WHEN
        BracketFinder finder = new BracketFinder(growLimit, 100);
        finder.search(func, goal, xA, xB);

        // THEN
        // Since denom is not accessible, we verify that the search completed without exception
        // and the bracket is correctly identified.
        assertEquals(1.0, finder.getLo(), 1e-6, "lo should be equal to xA");
        assertEquals(2.0, finder.getMid(), 1e-6, "mid should be equal to xB");
        assertTrue(finder.getHi() > finder.getMid(), "hi should be greater than mid");
        assertEquals(1.0, finder.getFLo(), 1e-6, "fLo should be fA");
        assertEquals(1.0, finder.getFMid(), 1e-6, "fMid should be fB");
        assertEquals(1.0, finder.getFHi(), 1e-6, "fHi should be fC");
    }

    @Test
    @DisplayName("TC25: search method with GoalType MINIMIZE and (w - xC)*(xB - w) > 0, updating xA and xB")
    void TC25_search_Minimize_UpdateXA_XB() {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.618034;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(1.0)).thenReturn(1.0);
        when(func.value(2.0)).thenReturn(2.0);
        when(func.value(1.618034 * (2.0 - 1.0) + 2.0)).thenReturn(0.5);

        // WHEN
        BracketFinder finder = new BracketFinder(growLimit, 1000);
        finder.search(func, goal, xA, xB);

        // THEN
        assertEquals(2.0, finder.getLo(), 1e-6, "lo should be updated to xB");
        assertEquals(1.0, finder.getMid(), 1e-6, "mid should be updated to xA");
        assertTrue(finder.getHi() > finder.getMid(), "hi should be greater than mid");
        assertEquals(2.0, finder.getFLo(), 1e-6, "fLo should be fB after swap");
        assertEquals(1.0, finder.getFMid(), 1e-6, "fMid should be fA after swap");
    }

    @Test
    @DisplayName("TC26: search method with GoalType MAXIMIZE and (w - wLim)*(wLim - xC) >= 0, setting w to wLim")
    void TC26_search_Maximize_SetWtoWLim() {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 1.0;
        double xB = 2.0;
        double growLimit = 1.0;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(1.0)).thenReturn(3.0);
        when(func.value(2.0)).thenReturn(2.0);
        when(func.value(2.0 + 1.618034 * (2.0 - 1.0))).thenReturn(4.0);

        // WHEN
        BracketFinder finder = new BracketFinder(growLimit, 1000);
        finder.search(func, goal, xA, xB);

        // THEN
        assertEquals(3.618034, finder.getHi(), 1e-6, "hi should be set to wLim");
        // Additional assertions can be added based on expected behavior
        assertEquals(1.0, finder.getLo(), 1e-6, "lo should remain as xA");
        assertEquals(2.0, finder.getMid(), 1e-6, "mid should remain as xB");
    }

    @Test
    @DisplayName("TC27: search method where lo > hi after search, triggering swap before return")
    void TC27_search_SwapLoHi_WhenLoGreaterThanHi() {
        // GIVEN
        GoalType goal = GoalType.MAXIMIZE;
        double xA = 3.0;
        double xB = 1.0;
        double growLimit = 2.0;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(3.0)).thenReturn(5.0);
        when(func.value(1.0)).thenReturn(4.0);
        when(func.value(1.618034 * (1.0 - 3.0) + 1.0)).thenReturn(6.0);

        // WHEN
        BracketFinder finder = new BracketFinder(growLimit, 1000);
        finder.search(func, goal, xA, xB);

        // THEN
        assertTrue(finder.getLo() <= finder.getHi(), "lo should be less than or equal to hi after swap");
        assertEquals(1.0, finder.getLo(), 1e-6, "lo should be swapped to initial hi");
        assertEquals(3.0, finder.getHi(), 1e-6, "hi should be swapped to initial lo");
    }

    @Test
    @DisplayName("TC28: search method with xA equal to xB, ensuring no swap and correct bracket")
    void TC28_search_NoSwap_WhenXAEqualsXB() {
        // GIVEN
        GoalType goal = GoalType.MINIMIZE;
        double xA = 2.0;
        double xB = 2.0;
        double growLimit = 1.618034;
        UnivariateFunction func = mock(UnivariateFunction.class);
        when(func.value(2.0)).thenReturn(1.0);
        when(func.value(anyDouble())).thenReturn(1.0);

        // WHEN
        BracketFinder finder = new BracketFinder(growLimit, 1000);
        finder.search(func, goal, xA, xB);

        // THEN
        assertEquals(2.0, finder.getLo(), 1e-6, "lo should remain as xA");
        assertEquals(2.0, finder.getMid(), 1e-6, "mid should remain as xB");
        assertTrue(finder.getHi() > finder.getMid(), "hi should be greater than mid");
        assertEquals(1.0, finder.getFLo(), 1e-6, "fLo should remain as fA");
        assertEquals(1.0, finder.getFMid(), 1e-6, "fMid should remain as fB");
        assertEquals(1.0, finder.getFHi(), 1e-6, "fHi should remain as fC");
    }
}