import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Locale;

import org.apache.commons.jxpath.JXPathException;
import org.jdom.Comment;
import org.jdom.CDATA;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class JDOMNodePointerTest {

    private JDOMNodePointer nodePointer;
    private Namespace xmlNamespace;

    @BeforeEach
    void setUp() {
        xmlNamespace = Namespace.getNamespace("xml", Namespace.XML_NAMESPACE.getURI());
    }
    
    @Test
    void testGetValue_ElementWithText() {
        Element element = new Element("test");
        element.addContent(new Text("Hello "));
        element.addContent(new Text("World"));

        nodePointer = new JDOMNodePointer(element, Locale.getDefault());
        assertEquals("Hello World", nodePointer.getValue());
    }

    @Test
    void testGetValue_ElementWithNestedElement() {
        Element root = new Element("root");
        Element child = new Element("child");
        child.addContent(new Text("Nested Text"));
        root.addContent(child);
        
        nodePointer = new JDOMNodePointer(root, Locale.getDefault());
        assertEquals("Nested Text", nodePointer.getValue());
    }

    @Test
    void testGetValue_Comment() {
        Comment comment = new Comment(" Some Comment ");
        nodePointer = new JDOMNodePointer(comment, Locale.getDefault());
        assertEquals("Some Comment", nodePointer.getValue());
    }

    @Test
    void testGetValue_Text() {
        Text text = new Text("   Some Text   ");
        nodePointer = new JDOMNodePointer(text, Locale.getDefault());
        assertEquals("Some Text", nodePointer.getValue());
    }

    @Test
    void testGetValue_CDATA() {
        CDATA cdata = new CDATA("Some CDATA");
        nodePointer = new JDOMNodePointer(cdata, Locale.getDefault());
        assertEquals("Some CDATA", nodePointer.getValue());
    }

    @Test
    void testGetValue_ProcessingInstruction_NotPreserve() {
        ProcessingInstruction pi = new ProcessingInstruction("target", "   Data   ");
        Element parent = new Element("parent");
        pi.setParent(parent);
        nodePointer = new JDOMNodePointer(pi, Locale.getDefault());
        assertEquals("Data", nodePointer.getValue());
    }

    @Test
    void testGetValue_ProcessingInstruction_PreserveSpace() {
        ProcessingInstruction pi = new ProcessingInstruction("target", "   Data   ");
        Element parent = new Element("parent");
        parent.setAttribute("space", "preserve", xmlNamespace);
        pi.setParent(parent);
        nodePointer = new JDOMNodePointer(pi, Locale.getDefault());
        assertEquals("   Data   ", nodePointer.getValue());
    }

    @Test
    void testGetValue_ProcessingInstruction_EmptyData() {
        ProcessingInstruction pi = new ProcessingInstruction("target", "");
        nodePointer = new JDOMNodePointer(pi, Locale.getDefault());
        assertEquals("", nodePointer.getValue());
    }
}