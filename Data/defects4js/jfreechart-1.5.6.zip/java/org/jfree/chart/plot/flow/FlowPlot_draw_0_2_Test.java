package org.jfree.chart.plot.flow;
import java.lang.reflect.*;
import org.jfree.chart.entity.FlowEntity;

import java.io.*;
import java.util.*;
import org.jfree.data.flow.FlowDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.entity.EntityCollection;
import org.mockito.Mockito;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FlowPlot_draw_0_2_Test {

    @Test
    @DisplayName("Verifies draw method with one stage accurately processes nodes and flows")
    public void TC06_draw_oneStage_processesNodesAndFlows() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);

        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(1);

        List<Comparable> sources = new ArrayList<>();
        sources.add("Source1");
        sources.add("Source2");
        when(dataset.getSources(0)).thenReturn(sources);

        List<Comparable> destinations = new ArrayList<>();
        destinations.add("Destination1");
        destinations.add("Destination2");
        when(dataset.getDestinations(0)).thenReturn(destinations);

        when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(10);
        when(dataset.getFlow(0, "Source1", "Destination2")).thenReturn(20);
        when(dataset.getFlow(0, "Source2", "Destination1")).thenReturn(30);
        when(dataset.getFlow(0, "Source2", "Destination2")).thenReturn(40);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        verify(g2, atLeastOnce()).setPaint(any(Color.class));
        verify(g2, atLeastOnce()).fill(any(Path2D.class));
        verify(entities, atLeastOnce()).add(any());
    }

    @Test
    @DisplayName("Verifies draw method with multiple stages correctly iterates and processes all stages")
    public void TC07_draw_multipleStages_processesAllStages() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 1200, 800);
        Point2D point = new Point2D.Double(600, 400);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);

        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(3);

        List<Comparable> sources0 = new ArrayList<>();
        sources0.add("S0_Source1");
        sources0.add("S0_Source2");
        when(dataset.getSources(0)).thenReturn(sources0);

        List<Comparable> destinations0 = new ArrayList<>();
        destinations0.add("S0_Destination1");
        destinations0.add("S0_Destination2");
        when(dataset.getDestinations(0)).thenReturn(destinations0);

        List<Comparable> sources1 = new ArrayList<>();
        sources1.add("S1_Source1");
        when(dataset.getSources(1)).thenReturn(sources1);

        List<Comparable> destinations1 = new ArrayList<>();
        destinations1.add("S1_Destination1");
        when(dataset.getDestinations(1)).thenReturn(destinations1);

        List<Comparable> sources2 = new ArrayList<>();
        sources2.add("S2_Source1");
        sources2.add("S2_Source2");
        sources2.add("S2_Source3");
        when(dataset.getSources(2)).thenReturn(sources2);

        List<Comparable> destinations2 = new ArrayList<>();
        destinations2.add("S2_Destination1");
        when(dataset.getDestinations(2)).thenReturn(destinations2);

        when(dataset.getFlow(0, "S0_Source1", "S0_Destination1")).thenReturn(15);
        when(dataset.getFlow(0, "S0_Source1", "S0_Destination2")).thenReturn(25);
        when(dataset.getFlow(0, "S0_Source2", "S0_Destination1")).thenReturn(35);
        when(dataset.getFlow(0, "S0_Source2", "S0_Destination2")).thenReturn(45);

        when(dataset.getFlow(1, "S1_Source1", "S1_Destination1")).thenReturn(50);

        when(dataset.getFlow(2, "S2_Source1", "S2_Destination1")).thenReturn(60);
        when(dataset.getFlow(2, "S2_Source2", "S2_Destination1")).thenReturn(70);
        when(dataset.getFlow(2, "S2_Source3", "S2_Destination1")).thenReturn(80);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        verify(g2, atLeast(3)).setPaint(any(Color.class));
        verify(g2, atLeast(3)).fill(any(Path2D.class));
        verify(entities, atLeast(3 * 2)).add(any()); // 3 stages * 2 entities per stage
    }

    @Test
    @DisplayName("Verifies draw method correctly handles maximum flow space calculation")
    public void TC08_draw_calculatesMaxFlowSpaceCorrectly() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 1600, 1200);
        Point2D point = new Point2D.Double(800, 600);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);

        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(2);

        List<Comparable> sources0 = new ArrayList<>();
        sources0.add("Source1");
        sources0.add("Source2");
        sources0.add("Source3");
        when(dataset.getSources(0)).thenReturn(sources0);

        List<Comparable> destinations0 = new ArrayList<>();
        destinations0.add("Destination1");
        when(dataset.getDestinations(0)).thenReturn(destinations0);

        List<Comparable> sources1 = new ArrayList<>();
        sources1.add("Source4");
        when(dataset.getSources(1)).thenReturn(sources1);

        List<Comparable> destinations1 = new ArrayList<>();
        destinations1.add("Destination2");
        when(dataset.getDestinations(1)).thenReturn(destinations1);

        when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(100);
        when(dataset.getFlow(0, "Source2", "Destination1")).thenReturn(200);
        when(dataset.getFlow(0, "Source3", "Destination1")).thenReturn(300);

        when(dataset.getFlow(1, "Source4", "Destination2")).thenReturn(400);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        verify(g2, atLeastOnce()).setPaint(any(Color.class));
        verify(g2, atLeastOnce()).fill(any(Path2D.class));
    }
//
//    @Test
//    @DisplayName("Verifies draw method handles large datasets performance")
//    public void TC09_draw_largeDataset_performance() throws Exception {
//        // GIVEN
//        Graphics2D g2 = mock(Graphics2D.class);
//        Rectangle2D area = new Rectangle2D.Double(0, 0, 2000, 1500);
//        Point2D point = new Point2D.Double(1000, 750);
//        PlotState state = mock(PlotState.class);
//        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//        EntityCollection entities = mock(EntityCollection.class);
//
//        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
//        when(info.getOwner().getEntityCollection()).thenReturn(entities);
//
//        FlowDataset dataset = mock(FlowDataset.class);
//        int largeStageCount = 100;
//        when(dataset.getStageCount()).thenReturn(largeStageCount);
//
//        for (int stage = 0; stage < largeStageCount; stage++) {
//            List<Comparable> sources = new ArrayList<>();
//            for (int s = 0; s < 50; s++) {
//                sources.add("Stage" + stage + "_Source" + s);
//            }
//            when(dataset.getSources(stage)).thenReturn(sources);
//
//            List<Comparable> destinations = new ArrayList<>();
//            for (int d = 0; d < 50; d++) {
//                destinations.add("Stage" + stage + "_Destination" + d);
//            }
//            when(dataset.getDestinations(stage)).thenReturn(destinations);
//
//            for (Comparable source : sources) {
//                for (Comparable dest : destinations) {
//                    when(dataset.getFlow(stage, source, dest)).thenReturn(1);
//                }
//            }
//        }
//
//        FlowPlot flowPlot = new FlowPlot(dataset);
//
//        // WHEN
//        long startTime = System.currentTimeMillis();
//        flowPlot.draw(g2, area, point, state, info);
//        long endTime = System.currentTimeMillis();
//        long duration = endTime - startTime;
//
//        // THEN
//        assertTrue(duration < 2000, "Draw method should execute within 2 seconds");
//    }

    @Test
    @DisplayName("Verifies draw method correctly handles nodes with zero inflow and outflow")
    public void TC10_draw_nodesWithZeroFlow_renderedCorrectly() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);

        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(1);

        List<Comparable> sources = new ArrayList<>();
        sources.add("Source1");
        when(dataset.getSources(0)).thenReturn(sources);

        List<Comparable> destinations = new ArrayList<>();
        destinations.add("Destination1");
        when(dataset.getDestinations(0)).thenReturn(destinations);

        when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(0);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        verify(g2, atLeastOnce()).setPaint(any(Color.class));
        verify(g2, never()).fill(any(Path2D.class));
        verify(entities, never()).add(any(FlowEntity.class));
    }
}