package org.jfree.chart.renderer.category;

import static org.mockito.Mockito.*;
import org.jfree.chart.renderer.AreaRendererEndType;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.anyDouble;

import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.AreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AreaRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("drawItem processes with TAPER endType when column is the first column")
    public void TC32_drawItem_TAPER_firstColumn() throws Exception {
        // GIVEN
        AreaRenderer renderer = spy(new AreaRenderer());
        renderer.setEndType(AreaRendererEndType.TAPER);

        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getColumnCount()).thenReturn(5);

        CategoryPlot plot = mock(CategoryPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entities);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // THEN
        verify(g2).fill(any(GeneralPath.class));
        verify(renderer).drawItemLabel(any(), any(), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble(), eq(false));
    }

    @Test
    @DisplayName("drawItem processes with TAPER endType when column is a middle column")
    public void TC33_drawItem_TAPER_middleColumn() throws Exception {
        // GIVEN
        AreaRenderer renderer = spy(new AreaRenderer());
        renderer.setEndType(AreaRendererEndType.TAPER);

        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, 1)).thenReturn(20.0);
        when(dataset.getColumnCount()).thenReturn(5);
        when(dataset.getValue(0, 0)).thenReturn(30.0);
        when(dataset.getValue(0, 2)).thenReturn(35.0);

        CategoryPlot plot = mock(CategoryPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entities);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 1);

        // THEN
        verify(g2).fill(any(GeneralPath.class));
        verify(renderer).drawItemLabel(any(), any(), eq(dataset), eq(0), eq(1), anyDouble(), anyDouble(), eq(false));
    }

    @Test
    @DisplayName("drawItem processes with TAPER endType when column is the last column")
    public void TC34_drawItem_TAPER_lastColumn() throws Exception {
        // GIVEN
        AreaRenderer renderer = spy(new AreaRenderer());
        renderer.setEndType(AreaRendererEndType.TAPER);

        int lastColumn = 4;
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getValue(0, lastColumn)).thenReturn(30.0);
        when(dataset.getColumnCount()).thenReturn(5);
        when(dataset.getValue(0, 3)).thenReturn(40.0);

        CategoryPlot plot = mock(CategoryPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getCrosshairState()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entities);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, lastColumn, 0);

        // THEN
        verify(g2).fill(any(GeneralPath.class));
        verify(renderer).drawItemLabel(any(), any(), eq(dataset), eq(0), eq(lastColumn), anyDouble(), anyDouble(), eq(false));
    }
}