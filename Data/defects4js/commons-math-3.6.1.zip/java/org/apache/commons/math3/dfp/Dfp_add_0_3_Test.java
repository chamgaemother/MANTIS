package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Dfp_add_0_3_Test {

    @Test
    @DisplayName("Adding Dfp numbers with opposite signs without cancellation resulting in correct sum")
    public void TC11() throws Exception {
        // Initialize DfpField via reflection
        Class<?> dfpFieldClass = Class.forName("org.apache.commons.math3.dfp.DfpField");
        Constructor<?> dfpFieldConstructor = dfpFieldClass.getConstructor(int.class);
        Object field = dfpFieldConstructor.newInstance(10); // Example precision

        // Create Dfp instances a and b
        Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
        Constructor<?> dfpConstructor = dfpClass.getConstructor(dfpFieldClass, double.class);

        Object a = dfpConstructor.newInstance(field, 10.5);
        Object b = dfpConstructor.newInstance(field, -5.2);

        // Invoke add method
        Method addMethod = dfpClass.getMethod("add", dfpClass);
        Object result = addMethod.invoke(a, b);

        // Access equals method
        Method equalsMethod = dfpClass.getMethod("equals", Object.class);
        boolean isEqual = (boolean) equalsMethod.invoke(result, dfpConstructor.newInstance(field, 5.3));

        // Access getSign method (correct signature ensured)
        Method getSignMethod = dfpClass.getDeclaredMethod("getSign");
        getSignMethod.setAccessible(true); // Ensure it's accessible
        byte sign = (byte) getSignMethod.invoke(result);

        // Assertions
        assertTrue(isEqual, "The sum should be equal to 5.3");
        assertEquals(1, sign, "The sign should be positive");
    }

    @Test
    @DisplayName("Adding Dfp numbers resulting in underflow triggers underflow handling via dotrap")
    public void TC12() throws Exception {
        // Initialize DfpField via reflection
        Class<?> dfpFieldClass = Class.forName("org.apache.commons.math3.dfp.DfpField");
        Constructor<?> dfpFieldConstructor = dfpFieldClass.getConstructor(int.class);
        Object field = dfpFieldConstructor.newInstance(10); // Example precision

        // Create very small Dfp instances a and b
        Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
        Constructor<?> dfpConstructor = dfpClass.getConstructor(dfpFieldClass, double.class);

        Object a = dfpConstructor.newInstance(field, 1e-300);
        Object b = dfpConstructor.newInstance(field, 1e-300);

        // Invoke add method
        Method addMethod = dfpClass.getMethod("add", dfpClass);
        Object result = addMethod.invoke(a, b);

        // Access nans field via reflection
        Field nansField = dfpClass.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte nans = nansField.getByte(result);

        // Access isZero method
        Method isZeroMethod = dfpClass.getMethod("isZero");
        boolean isZero = (boolean) isZeroMethod.invoke(result);

        // Assertions
        assertEquals(3, nans, "FLAG_UNDERFLOW should be set");
        assertTrue(isZero, "Result should be zero or gradually underflowed");
    }

    @Test
    @DisplayName("Adding Dfp numbers where one is NaN and the other is NaN returns NaN appropriately")
    public void TC13() throws Exception {
        // Initialize DfpField via reflection
        Class<?> dfpFieldClass = Class.forName("org.apache.commons.math3.dfp.DfpField");
        Constructor<?> dfpFieldConstructor = dfpFieldClass.getConstructor(int.class);
        Object field = dfpFieldConstructor.newInstance(10); // Example precision

        // Create NaN Dfp instances a and b
        Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
        Constructor<?> dfpConstructor = dfpClass.getConstructor(dfpFieldClass, String.class);

        Object a = dfpConstructor.newInstance(field, "NaN");
        Object b = dfpConstructor.newInstance(field, "NaN");

        // Invoke add method
        Method addMethod = dfpClass.getMethod("add", dfpClass);
        Object result = addMethod.invoke(a, b);

        // Access isNaN method
        Method isNaNMethod = dfpClass.getMethod("isNaN");
        boolean isNaN = (boolean) isNaNMethod.invoke(result);

        // Assertions
        assertTrue(isNaN, "Result should be NaN");
    }

    @Test
    @DisplayName("Adding Dfp number to zero preserves the original number")
    public void TC14() throws Exception {
        // Initialize DfpField via reflection
        Class<?> dfpFieldClass = Class.forName("org.apache.commons.math3.dfp.DfpField");
        Constructor<?> dfpFieldConstructor = dfpFieldClass.getConstructor(int.class);
        Object field = dfpFieldConstructor.newInstance(10); // Example precision

        // Create Dfp instances a and zero
        Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
        Constructor<?> dfpConstructor = dfpClass.getConstructor(dfpFieldClass, double.class);

        Object a = dfpConstructor.newInstance(field, 15.7);
        Object zero = dfpConstructor.newInstance(field, 0);

        // Invoke add method
        Method addMethod = dfpClass.getMethod("add", dfpClass);
        Object result = addMethod.invoke(a, zero);

        // Access equals method
        Method equalsMethod = dfpClass.getMethod("equals", Object.class);
        boolean isEqual = (boolean) equalsMethod.invoke(result, a);

        // Assertions
        assertTrue(isEqual, "Adding zero should preserve the original number");
    }

    @Test
    @DisplayName("Adding Dfp numbers with maximum mantissa causing rounding")
    public void TC15() throws Exception {
        // Initialize DfpField via reflection
        Class<?> dfpFieldClass = Class.forName("org.apache.commons.math3.dfp.DfpField");
        Constructor<?> dfpFieldConstructor = dfpFieldClass.getConstructor(int.class);
        Object field = dfpFieldConstructor.newInstance(10); // Example precision

        // Create Dfp instances a and b that will cause mantissa rounding
        Class<?> dfpClass = Class.forName("org.apache.commons.math3.dfp.Dfp");
        Constructor<?> dfpConstructor = dfpClass.getConstructor(dfpFieldClass, double.class);

        Object a = dfpConstructor.newInstance(field, 1.9999e10);
        Object b = dfpConstructor.newInstance(field, 2.0001e10);

        // Invoke add method
        Method addMethod = dfpClass.getMethod("add", dfpClass);
        Object result = addMethod.invoke(a, b);

        // Access equals method and expected rounded value
        Constructor<?> expectedConstructor = dfpClass.getConstructor(dfpFieldClass, double.class);
        Object expected = expectedConstructor.newInstance(field, 4.0000e10); // Expected rounded value

        Method equalsMethod = dfpClass.getMethod("equals", Object.class);
        boolean isEqual = (boolean) equalsMethod.invoke(result, expected);

        // Assertions
        assertTrue(isEqual, "Result should be correctly rounded to 4.0000e10");
    }
}