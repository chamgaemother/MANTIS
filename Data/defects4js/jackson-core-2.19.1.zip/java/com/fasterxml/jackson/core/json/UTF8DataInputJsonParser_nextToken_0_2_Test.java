// package com.fasterxml.jackson.core.json;
// import com.fasterxml.jackson.core.json.JsonReadFeature;
// 
// import com.fasterxml.jackson.core.JsonFactory;
// import com.fasterxml.jackson.core.JsonParseException;
// import com.fasterxml.jackson.core.JsonParser;
// import com.fasterxml.jackson.core.JsonToken;
// import com.fasterxml.jackson.core.JsonReadFeature;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import java.io.IOException;
// import java.io.StringReader;
// import java.lang.reflect.Field;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// public class UTF8DataInputJsonParser_nextToken_0_2_Test {
// 
//     @Test
//     @DisplayName("nextToken() reports unexpected character when comma is expected but not found")
//     public void TC06_nextToken_throwsExceptionWhenCommaMissing() throws IOException {
//         // Arrange
//         String jsonInput = "{\"field1\":\"value1\" \"field2\":\"value2\"}"; // Missing comma between fields
//         JsonFactory factory = new JsonFactory();
//         JsonParser parser = factory.createParser(new StringReader(jsonInput));
// 
//         // Act & Assert
//         JsonParseException exception = assertThrows(JsonParseException.class, () -> {
//             parser.nextToken();
//             parser.nextToken(); // This should throw due to missing comma
//         });
//         assertTrue(exception.getMessage().contains("was expecting comma to separate"), "Exception message should indicate missing comma");
//     }
// 
// //     @Test
// //     @DisplayName("nextToken() handles trailing comma when FEAT_MASK_TRAILING_COMMA is enabled")
// //     public void TC07_nextToken_handlesTrailingCommaWithFeatureEnabled() throws IOException {
//         // Arrange
// //         String jsonInput = "{\"field1\":\"value1\",}"; // Trailing comma
// //         JsonFactory factory = JsonFactory.builder()
// //                 .enable(JsonReadFeature.ALLOW_TRAILING_COMMA.mappedFeature())
// //                 .build();
// //         JsonParser parser = factory.createParser(new StringReader(jsonInput));
// // 
//         // Act
// //         parser.nextToken(); // Start Object
// //         parser.nextToken(); // FIELD_NAME
// //         parser.nextToken(); // VALUE_STRING
// //         JsonToken result = parser.nextToken(); // Should handle trailing comma and return END_OBJECT
// // 
//         // Assert
// //         assertEquals(JsonToken.END_OBJECT, result, "Parser should return END_OBJECT token after trailing comma");
// //     }
// 
//     @Test
//     @DisplayName("nextToken() rejects trailing comma when FEAT_MASK_TRAILING_COMMA is disabled")
//     public void TC08_nextToken_rejectsTrailingCommaWithFeatureDisabled() throws IOException {
//         // Arrange
//         String jsonInput = "{\"field1\":\"value1\",}"; // Trailing comma
//         JsonFactory factory = new JsonFactory(); // Trailing comma feature is disabled by default
//         JsonParser parser = factory.createParser(new StringReader(jsonInput));
// 
//         // Act & Assert
//         JsonParseException exception = assertThrows(JsonParseException.class, () -> {
//             parser.nextToken(); // Start Object
//             parser.nextToken(); // FIELD_NAME
//             parser.nextToken(); // VALUE_STRING
//             parser.nextToken(); // Should throw due to unexpected comma
//         });
//         assertTrue(exception.getMessage().contains("Unexpected character ('}"), "Exception message should indicate unexpected comma");
//     }
// 
//     @Test
//     @DisplayName("nextToken() parses FIELD_NAME and updates current name")
//     public void TC09_nextToken_parsesFieldNameAndUpdatesCurrentName() throws Exception {
//         // Arrange
//         String jsonInput = "{\"field1\":\"value1\"}";
//         JsonFactory factory = new JsonFactory();
//         JsonParser parser = factory.createParser(new StringReader(jsonInput));
// 
//         // Act
//         parser.nextToken(); // Start Object
//         JsonToken result = parser.nextToken(); // FIELD_NAME
// 
//         // Using reflection helper to access the internal _parsingContext
//         String currentName = orElseThrow(parser.getParsingContext(), "_currentName");
// 
//         // Assert
//         assertEquals(JsonToken.FIELD_NAME, result, "Parser should return FIELD_NAME token");
//         assertEquals("field1", currentName, "Current name should be 'field1'");
//     }
// 
//     @Test
//     @DisplayName("nextToken() returns START_ARRAY when '[' is encountered outside an object")
//     public void TC10_nextToken_returnsStartArrayOnOpeningBracketOutsideObject() throws IOException {
//         // Arrange
//         String jsonInput = "[1, 2, 3]";
//         JsonFactory factory = new JsonFactory();
//         JsonParser parser = factory.createParser(new StringReader(jsonInput));
// 
//         // Act
//         JsonToken result = parser.nextToken(); // START_ARRAY
// 
//         // Assert
//         assertEquals(JsonToken.START_ARRAY, result, "Parser should return START_ARRAY token when '[' is encountered outside an object");
//     }
// 
//     /**
//      * Reflection helper to access private fields.
//      * @param instance Object from which to read the field
//      * @param fieldName The name of the private field
//      * @return Value of the field
//      */
//     private static <T> T orElseThrow(Object instance, String fieldName) throws ReflectiveOperationException {
//         Field field = instance.getClass().getDeclaredField(fieldName);
//         field.setAccessible(true);
//         return (T) field.get(instance);
//     }
// }