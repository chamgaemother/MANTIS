package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.*;

import java.text.Format;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.Validate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ExtendedMessageFormatTest {

    private Map<String, FormatFactory> registry;

    @BeforeEach
    void setUp() {
        registry = new HashMap<>();
        registry.put("upper", new FormatFactory() {
            @Override
            public Format getFormat(String name, String args, Locale locale) {
                return new UpperCaseFormat();
            }
        });
        registry.put("lower", new FormatFactory() {
            @Override
            public Format getFormat(String name, String args, Locale locale) {
                return new LowerCaseFormat();
            }
        });
    }

    @Test
    void applyPattern_NullRegistry_ValidPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}", Locale.ENGLISH, null);
        assertEquals("Hello {0}", emf.toPattern());
    }

    @Test
    void applyPattern_NullRegistry_InvalidPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.ENGLISH, null);
        assertThrows(IllegalArgumentException.class, () -> emf.applyPattern("Hello {"));
    }

    @Test
    void applyPattern_WithRegistry_NoCustomFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}", Locale.ENGLISH, registry);
        assertEquals("Hello {0}", emf.toPattern());
        assertEquals("Hello {0}", emf.toPattern());
    }

    @Test
    void applyPattern_WithRegistry_CustomFormatExists() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0,upper}", Locale.ENGLISH, registry);
        assertEquals("Hello {0,upper}", emf.toPattern());
        Object[] args = { "world" };
        assertEquals("Hello WORLD", emf.format(args));
    }

    @Test
    void applyPattern_WithRegistry_CustomFormatDoesNotExist() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0,unknown}", Locale.ENGLISH, registry);
        assertEquals("Hello {0,unknown}", emf.toPattern());
        Object[] args = { "world" };
        assertEquals("Hello {0,unknown}", emf.format(args));
    }

    @Test
    void applyPattern_WithRegistry_UnterminatedQuote() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.ENGLISH, registry);
        assertThrows(IllegalArgumentException.class, () -> emf.applyPattern("Hello 'World"));
    }

    @Test
    void applyPattern_WithRegistry_UnterminatedFormatElement() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.ENGLISH, registry);
        assertThrows(IllegalArgumentException.class, () -> emf.applyPattern("Hello {0,upper"));
    }

    @Test
    void applyPattern_WithRegistry_EscapedQuotes() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("He said ''Hello'' to {0}", Locale.ENGLISH, registry);
        assertEquals("He said ''Hello'' to {0}", emf.toPattern());
        Object[] args = { "world" };
        assertEquals("He said 'Hello' to world", emf.format(args));
    }

    @Test
    void applyPattern_WithRegistry_NestedFormatElements() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,choice,0#zero|1#{1,upper}}", Locale.ENGLISH, registry);
        assertEquals("Value: {0,choice,0#zero|1#{1,upper}}", emf.toPattern());
        Object[] args = { 1, "test" };
        assertEquals("Value: TEST", emf.format(args));
    }

    @Test
    void applyPattern_WithRegistry_MultipleCustomFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Start {0,upper} middle {1,lower} end", Locale.ENGLISH, registry);
        assertEquals("Start {0,upper} middle {1,lower} end", emf.toPattern());
        Object[] args = { "UPPER", "LOWER" };
        assertEquals("Start UPPER middle lower end", emf.format(args));
    }

    @Test
    void applyPattern_NullPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.ENGLISH, registry);
        assertThrows(NullPointerException.class, () -> emf.applyPattern(null));
    }

    @Test
    void applyPattern_EmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.ENGLISH, registry);
        emf.applyPattern("");
        assertEquals("", emf.toPattern());
    }

    @Test
    void applyPattern_OnlyQuotes() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.ENGLISH, registry);
        emf.applyPattern("'{'0'}'");
        assertEquals("'{'0'}'", emf.toPattern());
        Object[] args = { "test" };
        assertEquals("{0}", emf.format(args));
    }

    @Test
    void applyPattern_InvalidArgumentIndex() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.ENGLISH, registry);
        assertThrows(IllegalArgumentException.class, () -> emf.applyPattern("Hello {a,upper}"));
    }

    @Test
    void applyPattern_FormatWithArgsContainingComma() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("List: {0}", Locale.ENGLISH, registry);
        Object[] args = { "a, b, c" };
        assertEquals("List: a, b, c", emf.format(args));
    }

    // Mock FormatFactory implementations for testing
    interface FormatFactory {
        Format getFormat(String name, String args, Locale locale);
    }

    static class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, java.text.FieldPosition pos) {
            if (obj == null) {
                obj = "";
            }
            toAppendTo.append(obj.toString().toUpperCase());
            return toAppendTo;
        }

        @Override
        public Object parseObject(String source, java.text.ParsePosition pos) {
            return source.toUpperCase();
        }
    }

    static class LowerCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, java.text.FieldPosition pos) {
            if (obj == null) {
                obj = "";
            }
            toAppendTo.append(obj.toString().toLowerCase());
            return toAppendTo;
        }

        @Override
        public Object parseObject(String source, java.text.ParsePosition pos) {
            return source.toLowerCase();
        }
    }
}