package org.jfree.data.general;

import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class DatasetUtilsTest {

    @Test
    void iterateRangeBounds_NullDataset_ThrowsException() {
        assertThrows(NullPointerException.class, () -> {
            DatasetUtils.iterateRangeBounds(null, true);
        });
    }

    @Test
    void iterateRangeBounds_EmptyDataset_ReturnsNull() {
        CategoryDataset dataset = new DefaultCategoryDataset();
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNull(range);
    }

    @Test
    void iterateRangeBounds_AllValuesNull_IncludeIntervalFalse_ReturnsNull() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(null, "Row1", "Col1");
        dataset.addValue(null, "Row1", "Col2");
        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNull(range);
    }

    @Test
    void iterateRangeBounds_AllValuesNaN_IncludeIntervalFalse_ReturnsNull() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Double.NaN, "Row1", "Col1");
        dataset.addValue(Double.NaN, "Row1", "Col2");
        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNull(range);
    }

    @Test
    void iterateRangeBounds_SomeValidValues_IncludeIntervalFalse_ReturnsCorrectRange() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10.0, "Row1", "Col1");
        dataset.addValue(null, "Row1", "Col2");
        dataset.addValue(20.0, "Row1", "Col3");
        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNotNull(range);
        assertEquals(10.0, range.getLowerBound());
        assertEquals(20.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_NotIntervalCategoryDataset_ReturnsStandardRange() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Row1", "Col1");
        dataset.addValue(15.0, "Row1", "Col2");
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(5.0, range.getLowerBound());
        assertEquals(15.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_IntervalCategoryDataset_AllValuesNull_ReturnsNull() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 1; }
            @Override
            public int getColumnCount() { return 1; }
            @Override
            public Comparable getRowKey(int row) { return "Row1"; }
            @Override
            public Comparable getColumnKey(int column) { return "Col1"; }
            @Override
            public Number getValue(int row, int column) { return null; }
            @Override
            public Number getStartValue(int row, int column) { return null; }
            @Override
            public Number getEndValue(int row, int column) { return null; }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNull(range);
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_IntervalCategoryDataset_SomeValuesValid_ReturnsCorrectRange() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 2; }
            @Override
            public int getColumnCount() { return 2; }
            @Override
            public Comparable getRowKey(int row) { return "Row" + (row + 1); }
            @Override
            public Comparable getColumnKey(int column) { return "Col" + (column + 1); }
            @Override
            public Number getValue(int row, int column) {
                if (row == 0 && column == 0) return 10.0;
                if (row == 0 && column == 1) return Double.NaN;
                if (row == 1 && column == 0) return null;
                if (row == 1 && column == 1) return 20.0;
                return null;
            }
            @Override
            public Number getStartValue(int row, int column) {
                if (row == 0 && column == 0) return 8.0;
                if (row == 0 && column == 1) return 12.0;
                if (row == 1 && column == 0) return null;
                if (row == 1 && column == 1) return 18.0;
                return null;
            }
            @Override
            public Number getEndValue(int row, int column) {
                if (row == 0 && column == 0) return 12.0;
                if (row == 0 && column == 1) return 16.0;
                if (row == 1 && column == 0) return null;
                if (row == 1 && column == 1) return 22.0;
                return null;
            }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(8.0, range.getLowerBound());
        assertEquals(22.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_IntervalCategoryDataset_AllValuesNaN_ReturnsNull() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 1; }
            @Override
            public int getColumnCount() { return 1; }
            @Override
            public Comparable getRowKey(int row) { return "Row1"; }
            @Override
            public Comparable getColumnKey(int column) { return "Col1"; }
            @Override
            public Number getValue(int row, int column) { return Double.NaN; }
            @Override
            public Number getStartValue(int row, int column) { return Double.NaN; }
            @Override
            public Number getEndValue(int row, int column) { return Double.NaN; }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNull(range);
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_IntervalCategoryDataset_SomeIntervalsNull_ReturnsCorrectRange() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 1; }
            @Override
            public int getColumnCount() { return 2; }
            @Override
            public Comparable getRowKey(int row) { return "Row1"; }
            @Override
            public Comparable getColumnKey(int column) { return "Col" + (column + 1); }
            @Override
            public Number getValue(int row, int column) {
                if (column == 0) return 10.0;
                if (column == 1) return 20.0;
                return null;
            }
            @Override
            public Number getStartValue(int row, int column) {
                if (column == 0) return 9.0;
                if (column == 1) return null;
                return null;
            }
            @Override
            public Number getEndValue(int row, int column) {
                if (column == 0) return 11.0;
                if (column == 1) return 21.0;
                return null;
            }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(9.0, range.getLowerBound());
        assertEquals(21.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalFalse_AllValuesValid_ReturnsCorrectRange() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, "Row1", "Col1");
        dataset.addValue(15.0, "Row1", "Col2");
        dataset.addValue(10.0, "Row2", "Col1");
        dataset.addValue(20.0, "Row2", "Col2");
        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNotNull(range);
        assertEquals(5.0, range.getLowerBound());
        assertEquals(20.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalFalse_SomeValuesNaN_ReturnsCorrectRange() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Double.NaN, "Row1", "Col1");
        dataset.addValue(15.0, "Row1", "Col2");
        dataset.addValue(null, "Row2", "Col1");
        dataset.addValue(20.0, "Row2", "Col2");
        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNotNull(range);
        assertEquals(15.0, range.getLowerBound());
        assertEquals(20.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_DatasetNotIntervalCategoryDataset_ReturnsCorrectRange() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(7.0, "Row1", "Col1");
        dataset.addValue(14.0, "Row1", "Col2");
        dataset.addValue(21.0, "Row2", "Col1");
        dataset.addValue(28.0, "Row2", "Col2");
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(7.0, range.getLowerBound());
        assertEquals(28.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_IntervalCategoryDataset_MixedValues_ReturnsCorrectRange() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 2; }
            @Override
            public int getColumnCount() { return 2; }
            @Override
            public Comparable getRowKey(int row) { return "Row" + (row + 1); }
            @Override
            public Comparable getColumnKey(int column) { return "Col" + (column + 1); }
            @Override
            public Number getValue(int row, int column) {
                if (row == 0 && column == 0) return 10.0;
                if (row == 0 && column == 1) return null;
                if (row == 1 && column == 0) return 20.0;
                if (row == 1 && column == 1) return Double.NaN;
                return null;
            }
            @Override
            public Number getStartValue(int row, int column) {
                if (row == 0 && column == 0) return 8.0;
                if (row == 0 && column == 1) return null;
                if (row == 1 && column == 0) return 18.0;
                if (row == 1 && column == 1) return Double.NaN;
                return null;
            }
            @Override
            public Number getEndValue(int row, int column) {
                if (row == 0 && column == 0) return 12.0;
                if (row == 0 && column == 1) return null;
                if (row == 1 && column == 0) return 22.0;
                if (row == 1 && column == 1) return Double.NaN;
                return null;
            }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(8.0, range.getLowerBound());
        assertEquals(22.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalFalse_AllValuesNaN_ReturnsNull() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(Double.NaN, "Row1", "Col1");
        dataset.addValue(Double.NaN, "Row1", "Col2");
        Range range = DatasetUtils.iterateRangeBounds(dataset, false);
        assertNull(range);
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_DatasetWithMixedNullAndNaN_ReturnsCorrectRange() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 1; }
            @Override
            public int getColumnCount() { return 3; }
            @Override
            public Comparable getRowKey(int row) { return "Row1"; }
            @Override
            public Comparable getColumnKey(int column) { return "Col" + (column + 1); }
            @Override
            public Number getValue(int row, int column) {
                if (column == 0) return 5.0;
                if (column == 1) return Double.NaN;
                if (column == 2) return null;
                return null;
            }
            @Override
            public Number getStartValue(int row, int column) {
                if (column == 0) return 4.0;
                if (column == 1) return Double.NaN;
                if (column == 2) return null;
                return null;
            }
            @Override
            public Number getEndValue(int row, int column) {
                if (column == 0) return 6.0;
                if (column == 1) return Double.NaN;
                if (column == 2) return null;
                return null;
            }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(4.0, range.getLowerBound());
        assertEquals(6.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_DatasetWithNoValidValues_ReturnsNull() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 1; }
            @Override
            public int getColumnCount() { return 2; }
            @Override
            public Comparable getRowKey(int row) { return "Row1"; }
            @Override
            public Comparable getColumnKey(int column) { return "Col" + (column + 1); }
            @Override
            public Number getValue(int row, int column) { return null; }
            @Override
            public Number getStartValue(int row, int column) { return null; }
            @Override
            public Number getEndValue(int row, int column) { return null; }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNull(range);
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_DatasetWithOnlyStartValues_ReturnsCorrectRange() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 1; }
            @Override
            public int getColumnCount() { return 2; }
            @Override
            public Comparable getRowKey(int row) { return "Row1"; }
            @Override
            public Comparable getColumnKey(int column) { return "Col" + (column + 1); }
            @Override
            public Number getValue(int row, int column) { return null; }
            @Override
            public Number getStartValue(int row, int column) {
                if (column == 0) return 2.0;
                if (column == 1) return 4.0;
                return null;
            }
            @Override
            public Number getEndValue(int row, int column) { return null; }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(2.0, range.getLowerBound());
        assertEquals(4.0, range.getUpperBound());
    }

    @Test
    void iterateRangeBounds_IncludeIntervalTrue_DatasetWithOnlyEndValues_ReturnsCorrectRange() {
        IntervalCategoryDataset dataset = new IntervalCategoryDataset() {
            @Override
            public int getRowCount() { return 1; }
            @Override
            public int getColumnCount() { return 2; }
            @Override
            public Comparable getRowKey(int row) { return "Row1"; }
            @Override
            public Comparable getColumnKey(int column) { return "Col" + (column + 1); }
            @Override
            public Number getValue(int row, int column) { return null; }
            @Override
            public Number getStartValue(int row, int column) { return null; }
            @Override
            public Number getEndValue(int row, int column) {
                if (column == 0) return 3.0;
                if (column == 1) return 5.0;
                return null;
            }
        };
        Range range = DatasetUtils.iterateRangeBounds(dataset, true);
        assertNotNull(range);
        assertEquals(3.0, range.getLowerBound());
        assertEquals(5.0, range.getUpperBound());
    }
}