package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class FastMath_atan2_0_1_Test {

    @Test
    @DisplayName("atan2(x=NaN, y=1.0) returns Double.NaN when x is NaN")
    void TC01() {
        double x = Double.NaN;
        double y = 1.0;
        double result = FastMath.atan2(x, y);
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("atan2(x=1.0, y=NaN) returns Double.NaN when y is NaN")
    void TC02() {
        double x = 1.0;
        double y = Double.NaN;
        double result = FastMath.atan2(x, y);
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("atan2(x=5.0, y=0.0) returns +0.0 when y is zero and x is positive infinite")
    void TC03() {
        double x = 5.0;
        double y = 0.0;
        double result = FastMath.atan2(x, y);
        assertEquals(0.0, result);
    }

    @Test
    @DisplayName("atan2(x=-5.0, y=0.0) returns Math.PI with y=0 and x is negative")
    void TC04() {
        double x = -5.0;
        double y = 0.0;
        double result = FastMath.atan2(x, y);
        assertEquals(Math.PI, result);
    }

    @Test
    @DisplayName("atan2(x=5.0, y=-0.0) returns -0.0 when y is negative zero and x is positive")
    void TC05() {
        double x = 5.0;
        double y = -0.0;
        double result = FastMath.atan2(x, y);
        assertEquals(Double.doubleToLongBits(-0.0), Double.doubleToLongBits(result));
    }
}