
package org.apache.commons.collections4.functors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Comparator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class ComparatorPredicate_test_0_3_Test {

    @Test
    @DisplayName("Invalid criterion throws NullPointerException")
    public void TC11_InvalidCriterionThrowsException() throws Exception {
        // GIVEN
        Comparator<Object> mockComparator = Mockito.mock(Comparator.class);
        when(mockComparator.compare(any(Object.class), any(Object.class))).thenReturn(0);

        // Instantiate ComparatorPredicate using the constructor
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(new Object(), mockComparator, ComparatorPredicate.Criterion.EQUAL);

        // Use reflection to set an invalid criterion (null)
        Field criterionField = ComparatorPredicate.class.getDeclaredField("criterion");
        criterionField.setAccessible(true);
        criterionField.set(predicate, null);

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> predicate.test(new Object()));
    }

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL with comparison result zero")
    public void TC12_LessOrEqualComparisonZero() throws Exception {
        // GIVEN
        Comparator<Object> mockComparator = Mockito.mock(Comparator.class);
        when(mockComparator.compare(any(Object.class), any(Object.class))).thenReturn(0);

        // Instantiate ComparatorPredicate with Criterion.LESS_OR_EQUAL
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(new Object(), mockComparator, ComparatorPredicate.Criterion.LESS_OR_EQUAL);

        // WHEN
        boolean result = predicate.test(new Object());

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL with comparison result positive")
    public void TC13_LessOrEqualComparisonPositive() throws Exception {
        // GIVEN
        Comparator<Object> mockComparator = Mockito.mock(Comparator.class);
        when(mockComparator.compare(any(Object.class), any(Object.class))).thenReturn(1);

        // Instantiate ComparatorPredicate with Criterion.LESS_OR_EQUAL
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(new Object(), mockComparator, ComparatorPredicate.Criterion.LESS_OR_EQUAL);

        // WHEN
        boolean result = predicate.test(new Object());

        // THEN
        assertFalse(result);
    }
}