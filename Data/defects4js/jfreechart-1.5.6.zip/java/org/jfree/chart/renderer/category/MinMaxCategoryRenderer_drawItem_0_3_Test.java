package org.jfree.chart.renderer.category;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MinMaxCategoryRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem sets correct paint and stroke for the item")
    void TC11_drawItemSetsCorrectPaintAndStroke() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = spy(new MinMaxCategoryRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        Paint itemPaint = mock(Paint.class);
        Stroke itemStroke = mock(Stroke.class);

        when(dataset.getValue(row, column)).thenReturn(15);
        doReturn(itemPaint).when(renderer).getItemPaint(row, column);
        doReturn(itemStroke).when(renderer).getItemStroke(row, column);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(15.0), eq(dataArea), any())).thenReturn(50.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2).setPaint(itemPaint);
        verify(g2).setStroke(itemStroke);
    }

    @Test
    @DisplayName("drawItem throws exception when dataset.getValue throws RuntimeException")
    void TC12_drawItemPropagatesRuntimeException() {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenThrow(new RuntimeException("Data access error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        });
        assertEquals("Data access error", thrown.getMessage());
    }

    @Test
    @DisplayName("drawItem handles minimal dataArea dimensions without errors")
    void TC13_drawItemWithMinimalDataArea() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 1, 1);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(15);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any())).thenReturn(0.5);
        when(rangeAxis.valueToJava2D(eq(15.0), eq(dataArea), any())).thenReturn(0.5);

        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        });
    }

    @Test
    @DisplayName("drawItem processes multiple iterations with varying dataset values")
    void TC14_drawItemHandlesMultipleIterations() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = spy(new MinMaxCategoryRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int pass = 0;

        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getValue(anyInt(), anyInt())).thenReturn(5, 15, 10, 20);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.setDrawLines(true);

        // Act
        for (int column = 0; column < 4; column++) {
            int row = 0; // testing for single row
            Paint itemPaint = mock(Paint.class);
            Stroke itemStroke = mock(Stroke.class);
            doReturn(itemPaint).when(renderer).getItemPaint(row, column);
            doReturn(itemStroke).when(renderer).getItemStroke(row, column);
            when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any())).thenReturn(10.0 * (column + 1));
            when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0 * (column + 1));
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        }

        // Assert
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).setStroke(any(Stroke.class));
    }

//     @Test
//     @DisplayName("drawItem does not add item entity when entity collection is null")
//     void TC15_drawItemNoEntityCollection() throws Exception {
        // Arrange
//         MinMaxCategoryRenderer renderer = spy(new MinMaxCategoryRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
// 
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(dataset.getValue(row, column)).thenReturn(15);
//         when(state.getEntityCollection()).thenReturn(null);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(eq(15.0), eq(dataArea), any())).thenReturn(50.0);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
        // Assert
        // Verify that addItemEntity is not called when EntityCollection is null
//         verify(renderer, never()).addItemEntity(any(EntityCollection.class), any(), anyInt(), anyInt(), any(Shape.class));
//     }

}