package org.apache.commons.math3.special;

import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.util.MathArrays;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;

public class BesselJ_rjBesl_1_1_Test {

    @Test
    @DisplayName("rjBesl throws MathIllegalArgumentException when alpha=1.0, violating (alpha < 1)")
    public void testTC16_alphaEqualsUpperBoundary() throws Exception {
        // Initialize parameters
        double x = 10.0;
        double alpha = 1.0;
        int nb = 3;

        // Use reflection to access the rjBesl method
        Method rjBeslMethod = BesselJ.class.getDeclaredMethod("rjBesl", double.class, double.class, int.class);
        rjBeslMethod.setAccessible(true);

        // Assert that MathIllegalArgumentException is thrown
        assertThrows(MathIllegalArgumentException.class, () -> {
            rjBeslMethod.invoke(null, x, alpha, nb);
        });
    }

    @Test
    @DisplayName("rjBesl throws MathIllegalArgumentException when alpha=-0.5, violating (alpha >= 0)")
    public void testTC17_alphaBelowLowerBoundary() throws Exception {
        // Initialize parameters
        double x = 10.0;
        double alpha = -0.5;
        int nb = 3;

        // Use reflection to access the rjBesl method
        Method rjBeslMethod = BesselJ.class.getDeclaredMethod("rjBesl", double.class, double.class, int.class);
        rjBeslMethod.setAccessible(true);

        // Assert that MathIllegalArgumentException is thrown
        assertThrows(MathIllegalArgumentException.class, () -> {
            rjBeslMethod.invoke(null, x, alpha, nb);
        });
    }

    @Test
    @DisplayName("rjBesl throws ConvergenceException when computation fails to converge")
    public void testTC18_computationFailsToConverge() throws Exception {
        // Initialize parameters
        double x = 1e308;
        double alpha = 0.5;
        int nb = 100;

        // Use reflection to access the rjBesl method
        Method rjBeslMethod = BesselJ.class.getDeclaredMethod("rjBesl", double.class, double.class, int.class);
        rjBeslMethod.setAccessible(true);

        // Assert that ConvergenceException is thrown
        assertThrows(ConvergenceException.class, () -> {
            rjBeslMethod.invoke(null, x, alpha, nb);
        });
    }

    @Test
    @DisplayName("rjBesl processes nb=2 with x=0, ensuring correct initialization and handling of zero argument")
    public void testTC19_nbEquals2WithXZero() throws Exception {
        // Initialize parameters
        double x = 0.0;
        double alpha = 0.2;
        int nb = 2;

        // Use reflection to access the rjBesl method
        Method rjBeslMethod = BesselJ.class.getDeclaredMethod("rjBesl", double.class, double.class, int.class);
        rjBeslMethod.setAccessible(true);

        // Invoke the method
        BesselJ.BesselJResult result = (BesselJ.BesselJResult) rjBeslMethod.invoke(null, x, alpha, nb);

        // Assertions
        assertNotNull(result, "Result should not be null");
        double[] vals = result.getVals();
        assertEquals(2, vals.length, "Result should contain 2 values");
        assertEquals(2, result.getnVals(), "nVals should be 2");
        assertEquals(0.0, vals[0], 1e-10, "First value should be 0.0");
        assertEquals(0.0, vals[1], 1e-10, "Second value should be 0.0");
    }

    @Test
    @DisplayName("rjBesl handles nb=3 with alpha near zero, ensuring accurate computation with minimal iterations")
    public void testTC20_nbEquals3WithAlphaNearZero() throws Exception {
        // Initialize parameters
        double x = 5.0;
        double alpha = 1e-10;
        int nb = 3;

        // Use reflection to access the rjBesl method
        Method rjBeslMethod = BesselJ.class.getDeclaredMethod("rjBesl", double.class, double.class, int.class);
        rjBeslMethod.setAccessible(true);

        // Invoke the method
        BesselJ.BesselJResult result = (BesselJ.BesselJResult) rjBeslMethod.invoke(null, x, alpha, nb);

        // Assertions
        assertNotNull(result, "Result should not be null");
        double[] vals = result.getVals();
        assertEquals(3, vals.length, "Result should contain 3 values");
        assertEquals(3, result.getnVals(), "nVals should be 3");

        // Additional assertions based on expected BesselJ values can be added here
        // For example:
        // assertEquals(expectedValue0, vals[0], 1e-10);
        // assertEquals(expectedValue1, vals[1], 1e-10);
        // assertEquals(expectedValue2, vals[2], 1e-10);
    }
}