package org.jsoup.internal;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class SimpleStreamReader_read_0_1_Test {

    @Test
    @DisplayName("read is called with charBuffer position at 0 and byteBuf is null, expecting validation to fail")
    public void TC01_readWithNullByteBuf_shouldThrowNullPointerException() {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        InputStream in = new ByteArrayInputStream(new byte[0]);

        // WHEN & THEN
        Exception exception = assertThrows(NullPointerException.class, () -> {
            SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);
            Field byteBufField = SimpleStreamReader.class.getDeclaredField("byteBuf");
            byteBufField.setAccessible(true);
            byteBufField.set(reader, null);  // Manually set byteBuf to null to trigger exception
            reader.read(buffer, off, len);
        });

        assertNotNull(exception.getMessage());
    }

    @Test
    @DisplayName("read is called with charBuffer position not at 0, ensuring slice is called")
    public void TC02_readWithCharBufferPositionGreaterThanZero_shouldReturnCharactersRead() throws Exception {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        byte[] byteArray = "HelloWorld".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(byteArray);

        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // Using reflection to set the position of charBuffer to simulate > 0
        Field byteBufField = SimpleStreamReader.class.getDeclaredField("byteBuf");
        byteBufField.setAccessible(true);
        ByteBuffer internalByteBuf = (ByteBuffer) byteBufField.get(reader);
        internalByteBuf.position(5); // Set position > 0 in byteBuf to simulate slice requirement in CharBuffer

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertTrue(result > 0 && result <= len, "Number of characters read should be greater than 0 and less than or equal to len");
    }

    @Test
    @DisplayName("read with readFully true and charBuffer has no remaining, expecting loop to break")
    public void TC03_readWithReadFullyTrueAndNoRemaining_shouldReturnNumberOfCharactersRead() throws Exception {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        byte[] byteArray = "HelloWorld".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(new byte[0]);  // Simulated fully read

        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // Using reflection to manipulate the internal state
        Field byteBufField = SimpleStreamReader.class.getDeclaredField("byteBuf");
        byteBufField.setAccessible(true);
        ByteBuffer internalByteBuf = (ByteBuffer) byteBufField.get(reader);
        internalByteBuf.position(internalByteBuf.limit()); // Simulate readFully

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertEquals(len, result, "Number of characters read should be equal to len");
    }

    @Test
    @DisplayName("read triggers an underflow without readFully and available bytes, expecting loop to break")
    public void TC04_readUnderflowNoReadFullyNoAvailableBytes_shouldReturnPartialCharactersRead() throws Exception {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        byte[] byteArray = "Hello".getBytes(StandardCharsets.UTF_8); // Partial data
        InputStream in = new ByteArrayInputStream(new byte[0]); // No available bytes

        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        Field byteBufField = SimpleStreamReader.class.getDeclaredField("byteBuf");
        byteBufField.setAccessible(true);
        ByteBuffer internalByteBuf = (ByteBuffer) byteBufField.get(reader);
        internalByteBuf.put(byteArray);
        internalByteBuf.flip();

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertTrue(result > 0 && result < len, "Number of characters read should be greater than 0 and less than len");
    }

    @Test
    @DisplayName("read triggers an overflow, expecting CharsetDecoder to throw exception")
    public void TC05_readWithDecoderOverflow_shouldThrowIOException() throws Exception {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;

        byte[] overflowBytes = new byte[1024];
        InputStream in = new ByteArrayInputStream(overflowBytes);

        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN & THEN
        IOException exception = assertThrows(IOException.class, () -> {
            reader.read(buffer, off, len);
        });
        assertNotNull(exception);
    }
}