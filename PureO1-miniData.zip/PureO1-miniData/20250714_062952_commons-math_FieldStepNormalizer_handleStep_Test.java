package org.apache.commons.math3.ode.sampling;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FieldStepNormalizerTest {

    private static class MockRealFieldElement implements RealFieldElement<MockRealFieldElement> {
        private final double value;

        MockRealFieldElement(double value) {
            this.value = value;
        }

        @Override
        public double getReal() {
            return value;
        }

        @Override
        public MockRealFieldElement add(MockRealFieldElement a) {
            return new MockRealFieldElement(this.value + a.value);
        }

        @Override
        public MockRealFieldElement subtract(MockRealFieldElement a) {
            return new MockRealFieldElement(this.value - a.value);
        }

        @Override
        public MockRealFieldElement multiply(MockRealFieldElement a) {
            return new MockRealFieldElement(this.value * a.value);
        }

        @Override
        public MockRealFieldElement divide(MockRealFieldElement a) {
            return new MockRealFieldElement(this.value / a.value);
        }

        @Override
        public MockRealFieldElement negate() {
            return new MockRealFieldElement(-this.value);
        }

        @Override
        public MockRealFieldElement abs() {
            return new MockRealFieldElement(Math.abs(this.value));
        }

        @Override
        public MockRealFieldElement reciprocal() {
            return new MockRealFieldElement(1.0 / this.value);
        }

        @Override
        public MockRealFieldElement sqrt() {
            return new MockRealFieldElement(Math.sqrt(this.value));
        }

        @Override
        public MockRealFieldElement pow(double x) {
            return new MockRealFieldElement(Math.pow(this.value, x));
        }

        @Override
        public MockRealFieldElement rint() {
            return new MockRealFieldElement(Math.rint(this.value));
        }

        @Override
        public double getImaginary() {
            return 0.0;
        }
    }

    private FieldFixedStepHandler<MockRealFieldElement> handler;
    private FieldStepNormalizer<MockRealFieldElement> normalizer;
    private FieldStepInterpolator<MockRealFieldElement> interpolator;
    private FieldODEStateAndDerivative<MockRealFieldElement> initialState;
    private FieldODEStateAndDerivative<MockRealFieldElement> previousState;
    private FieldODEStateAndDerivative<MockRealFieldElement> currentState;
    private FieldODEStateAndDerivative<MockRealFieldElement> interpolatedState;

    @BeforeEach
    void setUp() {
        handler = mock(FieldFixedStepHandler.class);
        interpolator = mock(FieldStepInterpolator.class);
        initialState = mock(FieldODEStateAndDerivative.class);
        previousState = mock(FieldODEStateAndDerivative.class);
        currentState = mock(FieldODEStateAndDerivative.class);
        interpolatedState = mock(FieldODEStateAndDerivative.class);

        when(interpolator.getPreviousState()).thenReturn(previousState);
        when(interpolator.getCurrentState()).thenReturn(currentState);
    }

    @Test
    void testHandleStep_FirstCall_Forward_INCREMENT_FIRST() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        MockRealFieldElement initialTime = new MockRealFieldElement(0.3);
        MockRealFieldElement finalTime = new MockRealFieldElement(3.1);
        when(initialState.getTime()).thenReturn(initialTime);
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(0.8));
        when(interpolator.isForward()).thenReturn(true);

        normalizer.init(initialState, finalTime);
        normalizer.handleStep(interpolator, false);

        ArgumentCaptor<FieldODEStateAndDerivative<MockRealFieldElement>> captor = ArgumentCaptor.forClass(FieldODEStateAndDerivative.class);
        verify(handler, times(1)).handleStep(captor.capture(), eq(false));
        assertEquals(previousState, captor.getValue());
    }

    @Test
    void testHandleStep_FirstCall_Backward_INCREMENT_FIRST() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        MockRealFieldElement initialTime = new MockRealFieldElement(3.1);
        MockRealFieldElement finalTime = new MockRealFieldElement(0.3);
        when(initialState.getTime()).thenReturn(initialTime);
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(2.6));
        when(interpolator.isForward()).thenReturn(false);

        normalizer.init(initialState, finalTime);
        normalizer.handleStep(interpolator, false);

        ArgumentCaptor<FieldODEStateAndDerivative<MockRealFieldElement>> captor = ArgumentCaptor.forClass(FieldODEStateAndDerivative.class);
        verify(handler, times(1)).handleStep(captor.capture(), eq(false));
        assertEquals(previousState, captor.getValue());
    }

    @Test
    void testHandleStep_MultipleNormalizedSteps_INCREMENT_NEITHER() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);

        when(previousState.getTime()).thenReturn(new MockRealFieldElement(0.3));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(2.8));
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(0.8))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(1.3))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(1.8))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(2.3))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(2.8))).thenReturn(interpolatedState);

        normalizer.init(initialState, new MockRealFieldElement(3.1));
        normalizer.handleStep(interpolator, false);

        verify(handler, times(5)).handleStep(eq(interpolatedState), eq(false));
    }

    @Test
    void testHandleStep_MultipleNormalizedSteps_MULTIPLES_FIRST() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.FIRST);

        when(previousState.getTime()).thenReturn(new MockRealFieldElement(0.3));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(2.8));
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(0.5))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(1.0))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(1.5))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(2.0))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(2.5))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(3.0))).thenReturn(interpolatedState);

        normalizer.init(initialState, new MockRealFieldElement(3.1));
        normalizer.handleStep(interpolator, false);

        verify(handler, times(6)).handleStep(eq(interpolatedState), eq(false));
    }

    @Test
    void testHandleStep_HandleLastStep_AddLast() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.LAST);

        when(previousState.getTime()).thenReturn(new MockRealFieldElement(2.8));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(3.1));
        when(interpolator.isForward()).thenReturn(true);

        normalizer.init(initialState, new MockRealFieldElement(3.1));
        normalizer.handleStep(interpolator, true);

        ArgumentCaptor<FieldODEStateAndDerivative<MockRealFieldElement>> captor = ArgumentCaptor.forClass(FieldODEStateAndDerivative.class);
        verify(handler, times(2)).handleStep(captor.capture(), anyBoolean());
        assertEquals(previousState, captor.getAllValues().get(0));
        assertEquals(currentState, captor.getAllValues().get(1));
    }

    @Test
    void testHandleStep_HandleLastStep_DoNotAddLast() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);

        when(previousState.getTime()).thenReturn(new MockRealFieldElement(2.8));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(3.1));
        when(interpolator.isForward()).thenReturn(true);

        normalizer.init(initialState, new MockRealFieldElement(3.1));
        normalizer.handleStep(interpolator, true);

        verify(handler, times(1)).handleStep(eq(previousState), eq(false));
    }

    @Test
    void testHandleStep_NotFirstStep_FORWARD_INCREMENT_FIRST() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.FIRST);

        // First handleStep call
        when(previousState.getTime()).thenReturn(new MockRealFieldElement(0.3));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(0.8));
        when(interpolator.isForward()).thenReturn(true);
        normalizer.init(initialState, new MockRealFieldElement(3.1));
        normalizer.handleStep(interpolator, false);

        // Second handleStep call
        when(previousState.getTime()).thenReturn(new MockRealFieldElement(0.8));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(1.3));
        normalizer.handleStep(interpolator, false);

        verify(handler, times(2)).handleStep(any(), eq(false));
    }

    @Test
    void testHandleStep_NullInterpolator() {
        normalizer = new FieldStepNormalizer<>(0.5, handler);

        normalizer.init(initialState, new MockRealFieldElement(3.0));
        assertThrows(NullPointerException.class, () -> normalizer.handleStep(null, false));
    }

    @Test
    void testHandleStep_DoNormalizedStep_BoundsFirstExcluded() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.NEITHER);

        when(previousState.getTime()).thenReturn(new MockRealFieldElement(0.3));
        when(lastStateTime()).thenReturn(new MockRealFieldElement(0.3));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(0.8));
        when(interpolator.isForward()).thenReturn(true);

        normalizer.init(initialState, new MockRealFieldElement(3.1));
        normalizer.handleStep(interpolator, false);

        verify(handler, never()).handleStep(any(), anyBoolean());
    }

    @Test
    void testHandleStep_ModeMultiples_NextTimeEqualLastTime() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.MULTIPLES, StepNormalizerBounds.NEITHER);

        when(previousState.getTime()).thenReturn(new MockRealFieldElement(1.0));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(1.0));
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(1.5))).thenReturn(interpolatedState);

        normalizer.init(initialState, new MockRealFieldElement(2.0));
        normalizer.handleStep(interpolator, false);

        verify(handler, times(1)).handleStep(eq(interpolatedState), eq(false));
    }

    @Test
    void testHandleStep_NotForward() throws MaxCountExceededException {
        normalizer = new FieldStepNormalizer<>(0.5, handler, StepNormalizerMode.INCREMENT, StepNormalizerBounds.BOTH);

        when(previousState.getTime()).thenReturn(new MockRealFieldElement(3.1));
        when(currentState.getTime()).thenReturn(new MockRealFieldElement(2.6));
        when(interpolator.isForward()).thenReturn(false);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(2.6))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(2.1))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(1.6))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(1.1))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(0.6))).thenReturn(interpolatedState);
        when(interpolator.getInterpolatedState(new MockRealFieldElement(0.3))).thenReturn(interpolatedState);

        normalizer.init(initialState, new MockRealFieldElement(0.3));
        normalizer.handleStep(interpolator, true);

        verify(handler, times(8)).handleStep(eq(interpolatedState), anyBoolean());
    }
}