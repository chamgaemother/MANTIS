import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpDec;
import org.apache.commons.math3.dfp.DfpField;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DfpDecTest {

    private final DfpField field = new DfpField(35); // Adjust precision as necessary

    @Test
    void testNextAfterWithValidInputLessThan() {
        DfpDec dfp1 = new DfpDec(field, 2.0);
        DfpDec dfp2 = new DfpDec(field, 3.0);
        Dfp result = dfp1.nextAfter(dfp2);
        assertTrue(result.lessThan(dfp2));
        assertTrue(result.greaterThan(dfp1));
    }

    @Test
    void testNextAfterWithValidInputGreaterThan() {
        DfpDec dfp1 = new DfpDec(field, 3.0);
        DfpDec dfp2 = new DfpDec(field, 2.0);
        Dfp result = dfp1.nextAfter(dfp2);
        assertTrue(result.greaterThan(dfp2));
        assertTrue(result.lessThan(dfp1));
    }

    @Test
    void testNextAfterWithEqualInput() {
        DfpDec dfp1 = new DfpDec(field, 3.0);
        Dfp result = dfp1.nextAfter(dfp1);
        assertEquals(dfp1, result);
    }

    @Test
    void testNextAfterWithNegativeInput() {
        DfpDec dfp1 = new DfpDec(field, -2.0);
        DfpDec dfp2 = new DfpDec(field, -3.0);
        Dfp result = dfp1.nextAfter(dfp2);
        assertTrue(result.lessThan(dfp1));
    }

    @Test
    void testNextAfterWithZero() {
        DfpDec zero = new DfpDec(field, 0.0);
        DfpDec dfp = new DfpDec(field, 1.0);
        Dfp result = zero.nextAfter(dfp);
        assertTrue(result.greaterThan(zero));
    }

    @Test
    void testNextAfterTowardsZero() {
        DfpDec dfp = new DfpDec(field, 1.0);
        DfpDec zero = new DfpDec(field, 0.0);
        Dfp result = dfp.nextAfter(zero);
        assertTrue(result.lessThan(dfp));
    }

    @Test
    void testNextAfterWithDifferentPrecision() {
        DfpField differentField = new DfpField(36); // Different precision
        DfpDec dfp1 = new DfpDec(field, 2.0);
        DfpDec dfp2 = new DfpDec(differentField, 3.0);
        Dfp result = dfp1.nextAfter(dfp2);
        assertTrue(Double.isNaN(result.toDouble()));
    }

    @Test
    void testNextAfterWithInfinite() {
        DfpDec dfp = new DfpDec(field, Double.POSITIVE_INFINITY);
        Dfp result = dfp.nextAfter(new DfpDec(field, 0.0));
        assertTrue(Double.isInfinite(result.toDouble()));
    }

    @Test
    void testNextAfterWithNegativeInfinite() {
        DfpDec dfp = new DfpDec(field, Double.NEGATIVE_INFINITY);
        Dfp result = dfp.nextAfter(new DfpDec(field, 0.0));
        assertTrue(Double.isInfinite(result.toDouble()));
    }

    @Test
    void testNextAfterEdgeMinExp() {
        DfpDec minExp = new DfpDec(field, Dfp.MIN_EXP);
        Dfp zero = new DfpDec(field, 0.0);
        Dfp result = minExp.nextAfter(zero);
        assertTrue(result.lessThan(minExp));
    }

    @Test
    void testNextAfterEdgeMaxExp() {
        DfpDec maxExp = new DfpDec(field, Dfp.MAX_EXP);
        Dfp zero = new DfpDec(field, 0.0);
        Dfp result = maxExp.nextAfter(zero);
        assertTrue(Double.isInfinite(result.toDouble()));
    }
}