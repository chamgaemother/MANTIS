package org.apache.commons.math3.geometry.euclidean.threed;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for Rotation#getAngles method.
 */
public class Rotation_getAngles_1_2_Test {

    /**
     * TC09: getAngles with FRAME_TRANSFORM convention and ZYX order where rotation angles are Ï.
     */
    @Test
    @DisplayName("TC09: getAngles with FRAME_TRANSFORM convention and ZYX order where rotation angles are Ï")
    public void testTC09_getAngles_FRAME_TRANSFORM_ZYX_piRotation() {
        // Arrange
        Rotation rotation = new Rotation(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM, Math.PI, Math.PI, Math.PI);

        // Act
        double[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        assertEquals(Math.PI, angles[0], 1e-10, "First angle should be Ï");
        assertEquals(0.0, angles[1], 1e-10, "Second angle should be 0.0 due to singularity at Ï");
        assertEquals(Math.PI, angles[2], 1e-10, "Third angle should be Ï");
    }

    /**
     * TC10: getAngles with FRAME_TRANSFORM convention and XYZ order with negative angles.
     */
    @Test
    @DisplayName("TC10: getAngles with FRAME_TRANSFORM convention and XYZ order with negative angles")
    public void testTC10_getAngles_FRAME_TRANSFORM_XYZ_negativeAngles() {
        // Arrange
        double angle1 = -0.3;
        double angle2 = -0.4;
        double angle3 = -0.5;
        Rotation rotation = new Rotation(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM, angle1, angle2, angle3);

        // Act
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        assertEquals(angle1, angles[0], 1e-10, "First angle should be -0.3");
        assertEquals(angle2, angles[1], 1e-10, "Second angle should be -0.4");
        assertEquals(angle3, angles[2], 1e-10, "Third angle should be -0.5");
    }

    /**
     * TC11: getAngles with FRAME_TRANSFORM convention and ZXY order causing singularity when v2.getY() exceeds boundary.
     */
    @Test
    @DisplayName("TC11: getAngles with FRAME_TRANSFORM convention and ZXY order causing singularity when v2.getY() exceeds boundary")
    public void testTC11_getAngles_FRAME_TRANSFORM_ZXY_Singularity() {
        // Arrange
        // Angles are set to values that cause v2.getY() to exceed the boundary [-1, 1]
        // For example, setting angle2 slightly greater than Ï/2 or less than -Ï/2
        double angle1 = 0.0;
        double angle2 = Math.PI / 2 + 1e-10; // Slightly greater than Ï/2
        double angle3 = 0.0;
        Rotation rotation = new Rotation(RotationOrder.ZXY, RotationConvention.FRAME_TRANSFORM, angle1, angle2, angle3);

        // Act & Assert
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZXY, RotationConvention.FRAME_TRANSFORM);
        }, "Expected getAngles to throw CardanEulerSingularityException when v2.getY() exceeds boundary");
    }

    /**
     * TC12: getAngles with FRAME_TRANSFORM convention and XYX order where angles lead to minimal rotation.
     */
    @Test
    @DisplayName("TC12: getAngles with FRAME_TRANSFORM convention and XYX order where angles lead to minimal rotation")
    public void testTC12_getAngles_FRAME_TRANSFORM_XYX_minimalRotation() {
        // Arrange
        double epsilon = 1e-10;
        Rotation rotation = new Rotation(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM, epsilon, epsilon, epsilon);

        // Act
        double[] angles = rotation.getAngles(RotationOrder.XYX, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        assertEquals(epsilon, angles[0], 1e-10, "First angle should be approximately 0");
        assertEquals(epsilon, angles[1], 1e-10, "Second angle should be approximately 0");
        assertEquals(epsilon, angles[2], 1e-10, "Third angle should be approximately 0");
    }

    /**
     * TC13: getAngles with FRAME_TRANSFORM convention and YZY order where rotation is identity.
     */
    @Test
    @DisplayName("TC13: getAngles with FRAME_TRANSFORM convention and YZY order where rotation is identity")
    public void testTC13_getAngles_FRAME_TRANSFORM_YZY_identityRotation() {
        // Arrange
        Rotation rotation = Rotation.IDENTITY;

        // Act
        double[] angles = rotation.getAngles(RotationOrder.YZY, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have length 3");
        assertEquals(0.0, angles[0], 1e-10, "First angle should be 0.0");
        assertEquals(0.0, angles[1], 1e-10, "Second angle should be 0.0");
        assertEquals(0.0, angles[2], 1e-10, "Third angle should be 0.0");
    }
}