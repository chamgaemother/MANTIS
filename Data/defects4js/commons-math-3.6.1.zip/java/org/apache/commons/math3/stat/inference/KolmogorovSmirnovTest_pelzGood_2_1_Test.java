package org.apache.commons.math3.stat.inference;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.stat.inference.KolmogorovSmirnovTest;

public class KolmogorovSmirnovTest_pelzGood_2_1_Test {

    @Test
    @DisplayName("pelzGood with d=1e-20 and n=2 to test boundary condition with very small d")
    void TC24_pelzGood_with_d1e20_and_n2() {
        // Given
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = 1e-20;
        int n = 2;
        
        // When
        double result = ksTest.pelzGood(d, n);
        
        // Then
        assertTrue(Double.isFinite(result), "Result should be a finite double value.");
    }

    @Test
    @DisplayName("pelzGood with d=2.0 and n=5 to test typical execution path with moderate inputs")
    void TC25_pelzGood_with_d2_and_n5() {
        // Given
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = 2.0;
        int n = 5;
        
        // When
        double result = ksTest.pelzGood(d, n);
        
        // Then
        assertTrue(Double.isFinite(result), "Result should be a finite double value.");
    }

    @Test
    @DisplayName("pelzGood with d=Infinity and n=10 to test handling of infinite distance")
    void TC26_pelzGood_with_dInfinity_and_n10() {
        // Given
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = Double.POSITIVE_INFINITY;
        int n = 10;
        
        // When
        double result = ksTest.pelzGood(d, n);
        
        // Then
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be Double.POSITIVE_INFINITY.");
    }

    @Test
    @DisplayName("pelzGood with d=NaN and n=10 to verify behavior with undefined distance")
    void TC27_pelzGood_with_dNaN_and_n10() {
        // Given
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = Double.NaN;
        int n = 10;
        
        // When
        double result = ksTest.pelzGood(d, n);
        
        // Then
        assertTrue(Double.isNaN(result), "Result should be Double.NaN.");
    }

}