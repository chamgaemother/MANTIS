import org.apache.commons.math3.distribution.MultivariateNormalDistribution;
import org.apache.commons.math3.distribution.MixtureMultivariateNormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.util.Pair;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MultivariateNormalMixtureExpectationMaximizationTest {

    @Test
    public void testFitWithValidInput() {
        double[][] data = {{1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0}};
        MultivariateNormalMixtureExpectationMaximization emm = 
            new MultivariateNormalMixtureExpectationMaximization(data);

        double[][] means = {{1.0, 2.0}, {3.0, 4.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}, {{1.0, 0.0}, {0.0, 1.0}}};
        double[] weights = {0.5, 0.5};

        MultivariateNormalDistribution[] components = new MultivariateNormalDistribution[2];
        for (int i = 0; i < 2; i++) {
            components[i] = new MultivariateNormalDistribution(means[i], covariances[i]);
        }

        MixtureMultivariateNormalDistribution initialMixture = 
            new MixtureMultivariateNormalDistribution(Arrays.asList(
                new Pair<>(weights[0], components[0]),
                new Pair<>(weights[1], components[1])));

        assertDoesNotThrow(() -> emm.fit(initialMixture, 10, 1E-5));
    }

    @Test
    public void testFitWithSingularMatrix() {
        double[][] data = {{1.0, 1.0}, {1.0, 1.0}, {1.0, 1.0}};
        MultivariateNormalMixtureExpectationMaximization emm = 
            new MultivariateNormalMixtureExpectationMaximization(data);

        double[][] means = {{1.0, 1.0}, {1.0, 1.0}};
        double[][][] covariances = {{{0.0, 0.0}, {0.0, 0.0}}, {{0.0, 0.0}, {0.0, 0.0}}};
        double[] weights = {0.5, 0.5};

        MultivariateNormalDistribution[] components = new MultivariateNormalDistribution[2];
        for (int i = 0; i < 2; i++) {
            components[i] = new MultivariateNormalDistribution(means[i], covariances[i]);
        }

        MixtureMultivariateNormalDistribution initialMixture = 
            new MixtureMultivariateNormalDistribution(Arrays.asList(
                new Pair<>(weights[0], components[0]),
                new Pair<>(weights[1], components[1])));

        assertThrows(SingularMatrixException.class, () -> emm.fit(initialMixture, 10, 1E-5));
    }

    @Test
    public void testFitWithConvergenceFailure() {
        double[][] data = {{1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0}};
        MultivariateNormalMixtureExpectationMaximization emm = 
            new MultivariateNormalMixtureExpectationMaximization(data);

        double[][] means = {{1.0, 2.0}, {3.0, 4.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}, {{1.0, 0.0}, {0.0, 1.0}}};
        double[] weights = {0.5, 0.5};

        MultivariateNormalDistribution[] components = new MultivariateNormalDistribution[2];
        for (int i = 0; i < 2; i++) {
            components[i] = new MultivariateNormalDistribution(means[i], covariances[i]);
        }

        MixtureMultivariateNormalDistribution initialMixture = 
            new MixtureMultivariateNormalDistribution(Arrays.asList(
                new Pair<>(weights[0], components[0]),
                new Pair<>(weights[1], components[1])));

        assertThrows(ConvergenceException.class, () -> emm.fit(initialMixture, 1, 1E-5));
    }

    @Test
    public void testFitWithInvalidMaxIterations() {
        double[][] data = {{1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0}};
        MultivariateNormalMixtureExpectationMaximization emm = 
            new MultivariateNormalMixtureExpectationMaximization(data);

        double[][] means = {{1.0, 2.0}, {3.0, 4.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}, {{1.0, 0.0}, {0.0, 1.0}}};
        double[] weights = {0.5, 0.5};

        MultivariateNormalDistribution[] components = new MultivariateNormalDistribution[2];
        for (int i = 0; i < 2; i++) {
            components[i] = new MultivariateNormalDistribution(means[i], covariances[i]);
        }

        MixtureMultivariateNormalDistribution initialMixture = 
            new MixtureMultivariateNormalDistribution(Arrays.asList(
                new Pair<>(weights[0], components[0]),
                new Pair<>(weights[1], components[1])));

        assertThrows(NotStrictlyPositiveException.class, () -> emm.fit(initialMixture, 0, 1E-5));
    }

    @Test
    public void testFitWithInvalidThreshold() {
        double[][] data = {{1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0}};
        MultivariateNormalMixtureExpectationMaximization emm = 
            new MultivariateNormalMixtureExpectationMaximization(data);

        double[][] means = {{1.0, 2.0}, {3.0, 4.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}, {{1.0, 0.0}, {0.0, 1.0}}};
        double[] weights = {0.5, 0.5};

        MultivariateNormalDistribution[] components = new MultivariateNormalDistribution[2];
        for (int i = 0; i < 2; i++) {
            components[i] = new MultivariateNormalDistribution(means[i], covariances[i]);
        }

        MixtureMultivariateNormalDistribution initialMixture = 
            new MixtureMultivariateNormalDistribution(Arrays.asList(
                new Pair<>(weights[0], components[0]),
                new Pair<>(weights[1], components[1])));

        assertThrows(NotStrictlyPositiveException.class, () -> emm.fit(initialMixture, 10, Double.MIN_VALUE / 2));
    }

    @Test
    public void testFitWithDimensionMismatch() {
        double[][] data = {{1.0, 2.0}, {3.0, 4.0}, {5.0, 6.0}};
        MultivariateNormalMixtureExpectationMaximization emm = 
            new MultivariateNormalMixtureExpectationMaximization(data);

        double[][] means = {{1.0, 2.0, 3.0}, {3.0, 4.0, 5.0}};
        double[][][] covariances = {
            {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}}, 
            {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}}
        };
        double[] weights = {0.5, 0.5};

        MultivariateNormalDistribution[] components = new MultivariateNormalDistribution[2];
        for (int i = 0; i < 2; i++) {
            components[i] = new MultivariateNormalDistribution(means[i], covariances[i]);
        }

        MixtureMultivariateNormalDistribution initialMixture = 
            new MixtureMultivariateNormalDistribution(Arrays.asList(
                new Pair<>(weights[0], components[0]),
                new Pair<>(weights[1], components[1])));

        assertThrows(DimensionMismatchException.class, () -> emm.fit(initialMixture, 10, 1E-5));
    }
}