package org.apache.commons.math3.dfp;

import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Dfp_multiply_0_2_Test {

    @Test
    @DisplayName("TC06: Multiplying a finite Dfp with an infinite Dfp returns an infinite result with correct sign")
    void TC06_multiplyFiniteWithInfinite() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10); // Assuming radix digits = 10
        Dfp a = new Dfp(field, 1.0); // finiteValue = 1.0
        Dfp b = new Dfp(field, Byte.MAX_VALUE, Dfp.INFINITE); // Construct infinite Dfp correctly

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertEquals(a.sign * b.sign, result.sign, "Result sign should be the product of input signs");
    }

    @Test
    @DisplayName("TC07: Multiplying two infinite Dfp numbers returns an infinite result with correct sign")
    void TC07_multiplyTwoInfinite() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, Byte.MIN_VALUE, Dfp.INFINITE); // Negative Infinity
        Dfp b = new Dfp(field, Byte.MAX_VALUE, Dfp.INFINITE); // Positive Infinity

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertTrue(result.isInfinite(), "Result should be infinite");
        assertEquals(a.sign * b.sign, result.sign, "Result sign should be the product of input signs");
    }

    @Test
    @DisplayName("TC08: Multiplying an infinite Dfp with zero triggers FLAG_INVALID and returns QNAN")
    void TC08_multiplyInfiniteWithZero() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, Byte.MAX_VALUE, Dfp.INFINITE); // Positive Infinity
        Dfp b = new Dfp(field, 0.0); // Zero

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertTrue(result.isNaN(), "Result should be NaN");

        // Using reflection to access private field 'field'
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        // Accessing 'FIELD' flags via reflection
        Field flagsField = DfpField.class.getDeclaredField("ieeeFlags");
        flagsField.setAccessible(true);
        long flags = flagsField.getLong(resultField);
        long FLAG_INVALID = DfpField.FLAG_INVALID; // Use constant from DfpField
        assertTrue((flags & FLAG_INVALID) != 0, "FLAG_INVALID should be set");
    }

    @Test
    @DisplayName("TC09: Multiplying two finite Dfp numbers resulting in zero")
    void TC09_multiplyResultingInZero() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 0.0001); // smallValue1
        Dfp b = new Dfp(field, 0.0001); // smallValue2

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertTrue(result.isZero(), "Result should be zero");
        assertEquals(0, result.exp, "Exponent should be zero when result is zero");
    }

    @Test
    @DisplayName("TC10: Multiplying two finite Dfp numbers causing overflow")
    void TC10_multiplyCausingOverflow() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 1e308); // largeValue1
        Dfp b = new Dfp(field, 1e308); // largeValue2

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertTrue(result.isInfinite(), "Result should be infinite");

        // Using reflection to access private field 'field'
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField resultField = (DfpField) fieldField.get(result);

        // Accessing 'FIELD' flags via reflection
        Field flagsField = DfpField.class.getDeclaredField("ieeeFlags");
        flagsField.setAccessible(true);
        long flags = flagsField.getLong(resultField);
        long FLAG_OVERFLOW = DfpField.FLAG_OVERFLOW; // Use constant from DfpField
        assertTrue((flags & FLAG_OVERFLOW) != 0, "FLAG_OVERFLOW should be set");
    }
}