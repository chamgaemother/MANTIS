
package org.jfree.chart.plot;

import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.LegendItem;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Iterator;

public class PiePlot_getLegendItems_2_1_Test {

    @Test
    @DisplayName("Processes multiple keys with dataExtractOrder set to BY_ROW and limit â¤ 0, expecting all LegendItems without an aggregated item")
    public void TC13() throws Exception {
        // Initialize MultiplePiePlot instance
        MultiplePiePlot plot = new MultiplePiePlot();

        // Set dataExtractOrder to BY_ROW using reflection
        Field dataExtractOrderField = MultiplePiePlot.class.getDeclaredField("dataExtractOrder");
        dataExtractOrderField.setAccessible(true);
        dataExtractOrderField.set(plot, TableOrder.BY_ROW);

        // Set limit to 0.0 using reflection
        Field limitField = MultiplePiePlot.class.getDeclaredField("limit");
        limitField.setAccessible(true);
        limitField.setDouble(plot, 0.0);

        // Create and set dataset with multiple column keys
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(2.0, "Row2", "Col2");
        dataset.addValue(3.0, "Row3", "Col3");
        plot.setDataset(dataset);

        // Invoke getLegendItems()
        LegendItemCollection legendItems = plot.getLegendItems();

        // Assert that legendItems size equals number of column keys
        assertNotNull(legendItems, "LegendItemCollection should not be null");
        assertEquals(dataset.getColumnCount(), legendItems.getItemCount(), "LegendItemCollection should contain all LegendItems without an aggregated item");
    }

    @Test
    @DisplayName("Processes multiple keys with dataExtractOrder set to BY_ROW and limit > 0, expecting all LegendItems with an aggregated item")
    public void TC14() throws Exception {
        // Initialize MultiplePiePlot instance
        MultiplePiePlot plot = new MultiplePiePlot();

        // Set dataExtractOrder to BY_ROW using reflection
        Field dataExtractOrderField = MultiplePiePlot.class.getDeclaredField("dataExtractOrder");
        dataExtractOrderField.setAccessible(true);
        dataExtractOrderField.set(plot, TableOrder.BY_ROW);

        // Set limit to 1.0 using reflection
        Field limitField = MultiplePiePlot.class.getDeclaredField("limit");
        limitField.setAccessible(true);
        limitField.setDouble(plot, 1.0);

        // Create and set dataset with multiple column keys
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(2.0, "Row2", "Col2");
        dataset.addValue(3.0, "Row3", "Col3");
        plot.setDataset(dataset);

        // Set aggregatedItemsKey using reflection
        Field aggregatedItemsKeyField = MultiplePiePlot.class.getDeclaredField("aggregatedItemsKey");
        aggregatedItemsKeyField.setAccessible(true);
        aggregatedItemsKeyField.set(plot, "Aggregated");

        // Set aggregatedItemsPaint using reflection
        Field aggregatedItemsPaintField = MultiplePiePlot.class.getDeclaredField("aggregatedItemsPaint");
        aggregatedItemsPaintField.setAccessible(true);
        aggregatedItemsPaintField.set(plot, java.awt.Color.BLACK);

        // Invoke getLegendItems()
        LegendItemCollection legendItems = plot.getLegendItems();

        // Assert that legendItems size equals number of column keys plus one aggregated item
        assertNotNull(legendItems, "LegendItemCollection should not be null");
        assertEquals(dataset.getColumnCount() + 1, legendItems.getItemCount(), "LegendItemCollection should contain all LegendItems plus an aggregated LegendItem");
    }

    @Test
    @DisplayName("Processes multiple keys with dataExtractOrder set to BY_COLUMN and limit â¤ 0, expecting all LegendItems without an aggregated item")
    public void TC15() throws Exception {
        // Initialize MultiplePiePlot instance
        MultiplePiePlot plot = new MultiplePiePlot();

        // Set dataExtractOrder to BY_COLUMN using reflection
        Field dataExtractOrderField = MultiplePiePlot.class.getDeclaredField("dataExtractOrder");
        dataExtractOrderField.setAccessible(true);
        dataExtractOrderField.set(plot, TableOrder.BY_COLUMN);

        // Set limit to 0.0 using reflection
        Field limitField = MultiplePiePlot.class.getDeclaredField("limit");
        limitField.setAccessible(true);
        limitField.setDouble(plot, 0.0);

        // Create and set dataset with multiple row keys
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(2.0, "Row1", "Col2");
        dataset.addValue(3.0, "Row1", "Col3");
        plot.setDataset(dataset);

        // Invoke getLegendItems()
        LegendItemCollection legendItems = plot.getLegendItems();

        // Assert that legendItems size equals number of row keys
        assertNotNull(legendItems, "LegendItemCollection should not be null");
        assertEquals(dataset.getRowCount(), legendItems.getItemCount(), "LegendItemCollection should contain all LegendItems without an aggregated item");
    }

    @Test
    @DisplayName("Processes multiple keys with dataExtractOrder set to BY_COLUMN and limit > 0, expecting all LegendItems with an aggregated item")
    public void TC16() throws Exception {
        // Initialize MultiplePiePlot instance
        MultiplePiePlot plot = new MultiplePiePlot();

        // Set dataExtractOrder to BY_COLUMN using reflection
        Field dataExtractOrderField = MultiplePiePlot.class.getDeclaredField("dataExtractOrder");
        dataExtractOrderField.setAccessible(true);
        dataExtractOrderField.set(plot, TableOrder.BY_COLUMN);

        // Set limit to 1.0 using reflection
        Field limitField = MultiplePiePlot.class.getDeclaredField("limit");
        limitField.setAccessible(true);
        limitField.setDouble(plot, 1.0);

        // Create and set dataset with multiple row keys
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Row1", "Col1");
        dataset.addValue(2.0, "Row1", "Col2");
        dataset.addValue(3.0, "Row1", "Col3");
        plot.setDataset(dataset);

        // Set aggregatedItemsKey using reflection
        Field aggregatedItemsKeyField = MultiplePiePlot.class.getDeclaredField("aggregatedItemsKey");
        aggregatedItemsKeyField.setAccessible(true);
        aggregatedItemsKeyField.set(plot, "Aggregated");

        // Set aggregatedItemsPaint using reflection
        Field aggregatedItemsPaintField = MultiplePiePlot.class.getDeclaredField("aggregatedItemsPaint");
        aggregatedItemsPaintField.setAccessible(true);
        aggregatedItemsPaintField.set(plot, java.awt.Color.BLACK);

        // Invoke getLegendItems()
        LegendItemCollection legendItems = plot.getLegendItems();

        // Assert that legendItems size equals number of row keys plus one aggregated item
        assertNotNull(legendItems, "LegendItemCollection should not be null");
        assertEquals(dataset.getRowCount() + 1, legendItems.getItemCount(), "LegendItemCollection should contain all LegendItems plus an aggregated LegendItem");
    }

}