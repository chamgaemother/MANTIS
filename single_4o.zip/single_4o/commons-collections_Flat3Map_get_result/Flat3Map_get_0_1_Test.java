package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class Flat3Map_get_0_1_Test {

    @Test
    @DisplayName("Get returns value3 when delegateMap is not null.")
    void testGetWhenDelegateMapIsNotNull() throws Exception {
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to access private field delegateMap
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        Map<Object, Object> delegateMap = new HashMap<>();
        Object key = "key";
        Object value = "value3";
        delegateMap.put(key, value);
        delegateMapField.set(flat3Map, delegateMap);

        Object result = flat3Map.get(key);

        assertEquals(value, result);
    }

    @Test
    @DisplayName("Get returns null when the map is empty and key is null.")
    void testGetWhenMapIsEmptyAndKeyIsNull() {
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        Object result = flat3Map.get(null);

        assertNull(result);
    }

    @Test
    @DisplayName("Get returns value3 when size is 3 and key3 is null.")
    void testGetWhenSizeIsThreeAndKey3IsNull() throws Exception {
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to set private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 3);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(flat3Map, null);

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object value3 = "value3";
        value3Field.set(flat3Map, value3);

        Object result = flat3Map.get(null);

        assertEquals(value3, result);
    }

    @Test
    @DisplayName("Get returns value2 when size is 2 and key2 is null.")
    void testGetWhenSizeIsTwoAndKey2IsNull() throws Exception {
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to set private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(flat3Map, null);

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = "value2";
        value2Field.set(flat3Map, value2);

        Object result = flat3Map.get(null);

        assertEquals(value2, result);
    }

    @Test
    @DisplayName("Get returns value1 when size is 1 and key1 is null.")
    void testGetWhenSizeIsOneAndKey1IsNull() throws Exception {
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to set private fields
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(flat3Map, null);

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = "value1";
        value1Field.set(flat3Map, value1);

        Object result = flat3Map.get(null);

        assertEquals(value1, result);
    }
}