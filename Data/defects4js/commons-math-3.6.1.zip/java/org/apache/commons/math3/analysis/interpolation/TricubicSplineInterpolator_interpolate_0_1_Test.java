package org.apache.commons.math3.analysis.interpolation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TricubicSplineInterpolator_interpolate_0_1_Test {

    @Test
    @DisplayName("Interpolate with empty xval array throws NoDataException")
    void TC01_interpolate_empty_xval_throws_NoDataException() {
        // Given
        double[] xval = {};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {{{1.0}}};
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // When & Then
        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with empty yval array throws NoDataException")
    void TC02_interpolate_empty_yval_throws_NoDataException() {
        // Given
        double[] xval = {1.0};
        double[] yval = {};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {{{1.0}}};
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // When & Then
        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with empty zval array throws NoDataException")
    void TC03_interpolate_empty_zval_throws_NoDataException() {
        // Given
        double[] xval = {1.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {};
        double[][][] fval = {{{1.0}}};
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // When & Then
        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with empty fval array throws NoDataException")
    void TC04_interpolate_empty_fval_throws_NoDataException() {
        // Given
        double[] xval = {1.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {};
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // When & Then
        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }

    @Test
    @DisplayName("Interpolate with xval length not equal to fval length throws DimensionMismatchException")
    void TC05_interpolate_xval_length_mismatch_throws_DimensionMismatchException() {
        // Given
        double[] xval = {1.0, 2.0};
        double[] yval = {1.0, 2.0};
        double[] zval = {1.0, 2.0};
        double[][][] fval = {{{1.0}}, {{2.0}}, {{3.0}}};
        TricubicSplineInterpolator interpolator = new TricubicSplineInterpolator();

        // When & Then
        assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, zval, fval);
        });
    }
}