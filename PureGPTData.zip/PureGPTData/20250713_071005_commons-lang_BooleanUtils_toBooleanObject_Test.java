import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class BooleanUtilsTest {

    @ParameterizedTest
    @NullSource
    @CsvSource({
        "'true', true",
        "'TRUE', true",
        "'on', true",
        "'yes', true",
        "'y', true",
        "'t', true",
        "'1', true",
        "'false', false",
        "'FALSE', false",
        "'off', false",
        "'no', false",
        "'n', false",
        "'f', false",
        "'0', false"
    })
    void testToBooleanObjectValidStrings(String input, Boolean expected) {
        assertEquals(expected, BooleanUtils.toBooleanObject(input));
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "true ",  // Trailing space
        "yes ",   // Trailing space
        "truE",   // Mixed case invalid
        "tRue",   // Mixed case but valid
        "0something", // Prefix of valid but extra characters
        "101",    // Numeric but not valid
        "random"  // Completely invalid
    })
    void testToBooleanObjectInvalidStrings(String input) {
        assertNull(BooleanUtils.toBooleanObject(input));
    }

    @Test
    void testToBooleanObjectBoundary() {
        assertTrue(BooleanUtils.toBooleanObject("true"));
        assertFalse(BooleanUtils.toBooleanObject("false"));
        assertNull(BooleanUtils.toBooleanObject(null));
    }
}