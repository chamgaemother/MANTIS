package org.jsoup.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TokenQueue_chompBalanced_0_2_Test {

    @Test
    @DisplayName("ChompBalanced with double quotes and open char inside")
    void TC06_ChompBalanced_with_double_quotes_and_open_char_inside() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\"\"value\"\", data"); // Corrected constructor usage

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("\"value\"", result);
    }

    @Test
    @DisplayName("ChompBalanced with regex \\Q...\\E pattern inside")
    void TC07_ChompBalanced_with_regex_QE_pattern_inside() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\\Q[a-z]\\E"); // Corrected constructor usage

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("[a-z]", result);
    }

    @Test
    @DisplayName("ChompBalanced with single quote toggling in string")
    void TC08_ChompBalanced_with_single_quote_toggling_in_string() {
        // GIVEN
        TokenQueue queue = new TokenQueue("'a'"); // Corrected constructor usage

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("a", result);
    }

    @Test
    @DisplayName("ChompBalanced with unmatched closing character restores reader position and throws exception")
    void TC09_ChompBalanced_with_unmatched_closing_character() {
        // GIVEN
        TokenQueue queue = new TokenQueue(")abc("); // Corrected constructor usage

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            queue.chompBalanced('(', ')');
        });
        assertTrue(exception.getMessage().contains(")abc"));
    }

    @Test
    @DisplayName("ChompBalanced iterates with multiple characters before balancing")
    void TC10_ChompBalanced_with_multiple_nested_balanced_pairs() {
        // GIVEN
        TokenQueue queue = new TokenQueue("((a)(b)(c))"); // Corrected constructor usage

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("(a)(b)(c)", result);
    }
}