package org.apache.commons.jxpath.ri.model.jdom;

import org.jdom.Comment;
import org.jdom.CDATA;
import org.jdom.Element;
import org.jdom.ProcessingInstruction;
import org.jdom.Text;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class JDOMNodePointer_setValue_0_2_Test {

    @Test
    @DisplayName("node is Element and value is Text, adds new Text content")
    public void TC06_setValue_withElementNode_andTextValue() throws Exception {
        // Arrange
        Element node = new Element("parent");
        Text newText = new Text("Sample Text");
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);

        // Act
        pointer.setValue(newText);

        // Assert
        assertTrue(node.getContent().stream().anyMatch(content ->
                content instanceof Text &&
                ((Text) content).getText().equals("Sample Text")),
                "The node should contain the new Text content.");
    }

    @Test
    @DisplayName("node is Element and value is CDATA, adds new CDATA content")
    public void TC07_setValue_withElementNode_andCDATAValue() throws Exception {
        // Arrange
        Element node = new Element("parent");
        CDATA cdata = new CDATA("Sample CDATA");
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);

        // Act
        pointer.setValue(cdata);

        // Assert
        assertTrue(node.getContent().stream().anyMatch(content ->
                content instanceof CDATA &&
                ((CDATA) content).getText().equals("Sample CDATA")),
                "The node should contain the new CDATA content.");
    }

    @Test
    @DisplayName("node is Element and value is ProcessingInstruction, adds cloned PI")
    public void TC08_setValue_withElementNode_andProcessingInstructionValue() throws Exception {
        // Arrange
        Element node = new Element("parent");
        ProcessingInstruction pi = new ProcessingInstruction("target", "data");
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);

        // Act
        pointer.setValue(pi);

        // Assert
        assertTrue(node.getContent().stream().anyMatch(content ->
                content instanceof ProcessingInstruction &&
                ((ProcessingInstruction) content).getTarget().equals("target") &&
                ((ProcessingInstruction) content).getData().equals("data")),
                "The node should contain the cloned ProcessingInstruction.");
    }

    @Test
    @DisplayName("node is Element and value is Comment, adds cloned Comment")
    public void TC09_setValue_withElementNode_andCommentValue() throws Exception {
        // Arrange
        Element node = new Element("parent");
        Comment comment = new Comment("Sample Comment");
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);

        // Act
        pointer.setValue(comment);

        // Assert
        assertTrue(node.getContent().stream().anyMatch(content ->
                content instanceof Comment &&
                ((Comment) content).getText().equals("Sample Comment")),
                "The node should contain the cloned Comment.");
    }

    @Test
    @DisplayName("node is Element and value is convertible to non-null and non-empty String, adds Text content")
    public void TC10_setValue_withElementNode_andConvertibleStringValue() throws Exception {
        // Arrange
        Element node = new Element("parent");
        Object newValue = 12345; // Assume convertible to "12345"
        JDOMNodePointer pointer = new JDOMNodePointer(node, null);

        // Act
        pointer.setValue(newValue);

        // Assert
        assertTrue(node.getContent().stream().anyMatch(content ->
                content instanceof Text &&
                ((Text) content).getText().equals("12345")),
                "The node should contain the new Text content with the converted string.");
    }
}
