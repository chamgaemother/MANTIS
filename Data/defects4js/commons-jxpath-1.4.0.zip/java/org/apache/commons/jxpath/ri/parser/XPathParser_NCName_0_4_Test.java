package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class XPathParser_NCName_0_4_Test {

    @Test
    @DisplayName("NCName() processes kind FUNCTION_NAME and returns token image")
    public void TC16() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);  // Fixed constructor call to include a null token manager

        // Reflection to set jj_nt.kind to FUNCTION_NAME
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_NAME);

        // Call NCName()
        String result = parser.NCName();

        // Reflection to get token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Field imageField = token.getClass().getDeclaredField("image");
        imageField.setAccessible(true);
        String tokenImage = (String) imageField.get(token);

        // Assert equality
        assertEquals(tokenImage, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_STRING and returns token image")
    public void TC17() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);  // Fixed constructor call to include a null token manager

        // Reflection to set jj_nt.kind to FUNCTION_STRING
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_STRING);

        // Call NCName()
        String result = parser.NCName();

        // Reflection to get token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Field imageField = token.getClass().getDeclaredField("image");
        imageField.setAccessible(true);
        String tokenImage = (String) imageField.get(token);

        // Assert equality
        assertEquals(tokenImage, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_CONCAT and returns token image")
    public void TC18() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);  // Fixed constructor call to include a null token manager

        // Reflection to set jj_nt.kind to FUNCTION_CONCAT
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_CONCAT);

        // Call NCName()
        String result = parser.NCName();

        // Reflection to get token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Field imageField = token.getClass().getDeclaredField("image");
        imageField.setAccessible(true);
        String tokenImage = (String) imageField.get(token);

        // Assert equality
        assertEquals(tokenImage, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_STARTS_WITH and returns token image")
    public void TC19() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);  // Fixed constructor call to include a null token manager

        // Reflection to set jj_nt.kind to FUNCTION_STARTS_WITH
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_STARTS_WITH);

        // Call NCName()
        String result = parser.NCName();

        // Reflection to get token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Field imageField = token.getClass().getDeclaredField("image");
        imageField.setAccessible(true);
        String tokenImage = (String) imageField.get(token);

        // Assert equality
        assertEquals(tokenImage, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_ENDS_WITH and returns token image")
    public void TC20() throws Exception {
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);  // Fixed constructor call to include a null token manager

        // Reflection to set jj_nt.kind to FUNCTION_ENDS_WITH
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_ENDS_WITH);

        // Call NCName()
        String result = parser.NCName();

        // Reflection to get token.image
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Object token = tokenField.get(parser);

        Field imageField = token.getClass().getDeclaredField("image");
        imageField.setAccessible(true);
        String tokenImage = (String) imageField.get(token);

        // Assert equality
        assertEquals(tokenImage, result);
    }
}