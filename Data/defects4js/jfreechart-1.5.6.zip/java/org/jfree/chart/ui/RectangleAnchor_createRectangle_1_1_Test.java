package org.jfree.chart.ui;

import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.awt.geom.Rectangle2D;

public class RectangleAnchor_createRectangle_1_1_Test {

    @Test
    @DisplayName("createRectangle with zero width sets rectangle with zero width")
    public void TC13_createRectangle_zeroWidth() {
        // GIVEN
        Size2D dimensions = new Size2D(0.0, 100.0);
        double anchorX = 100.0;
        double anchorY = 200.0;
        RectangleAnchor anchor = RectangleAnchor.TOP;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(0.0, result.getWidth(), 0.0001);
        assertEquals(100.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with zero height sets rectangle with zero height")
    public void TC14_createRectangle_zeroHeight() {
        // GIVEN
        Size2D dimensions = new Size2D(100.0, 0.0);
        double anchorX = 150.0;
        double anchorY = 250.0;
        RectangleAnchor anchor = RectangleAnchor.BOTTOM;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(100.0, result.getWidth(), 0.0001);
        assertEquals(0.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with negative width sets rectangle with negative width")
    public void TC15_createRectangle_negativeWidth() {
        // GIVEN
        Size2D dimensions = new Size2D(-50.0, 100.0);
        double anchorX = 200.0;
        double anchorY = 300.0;
        RectangleAnchor anchor = RectangleAnchor.LEFT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(-50.0, result.getWidth(), 0.0001);
        assertEquals(100.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with negative height sets rectangle with negative height")
    public void TC16_createRectangle_negativeHeight() {
        // GIVEN
        Size2D dimensions = new Size2D(100.0, -100.0);
        double anchorX = 250.0;
        double anchorY = 350.0;
        RectangleAnchor anchor = RectangleAnchor.RIGHT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(100.0, result.getWidth(), 0.0001);
        assertEquals(-100.0, result.getHeight(), 0.0001);
    }

    @Test
    @DisplayName("createRectangle with zero width and height sets rectangle with zero dimensions")
    public void TC17_createRectangle_zeroWidthHeight() {
        // GIVEN
        Size2D dimensions = new Size2D(0.0, 0.0);
        double anchorX = 300.0;
        double anchorY = 400.0;
        RectangleAnchor anchor = RectangleAnchor.TOP_LEFT;

        // WHEN
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // THEN
        assertEquals(0.0, result.getWidth(), 0.0001);
        assertEquals(0.0, result.getHeight(), 0.0001);
    }

}