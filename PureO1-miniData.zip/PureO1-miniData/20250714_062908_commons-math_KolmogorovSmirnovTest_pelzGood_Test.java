package org.apache.commons.math3.stat.inference;

import org.apache.commons.math3.exception.TooManyIterationsException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class KolmogorovSmirnovTestTest {

    @Test
    void testPelzGood_NormalCase() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = 1.0;
        int n = 10;
        double result = ksTest.pelzGood(d, n);
        assertTrue(Double.isFinite(result), "Result should be a finite number for normal inputs.");
    }

    @Test
    void testPelzGood_ZeroD() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = 0.0;
        int n = 10;
        assertThrows(ArithmeticException.class, () -> ksTest.pelzGood(d, n),
                     "Should throw ArithmeticException when d is zero due to division by zero.");
    }

    @Test
    void testPelzGood_LargeIterations() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = 1e-10;
        int n = 100000;
        assertThrows(TooManyIterationsException.class, () -> ksTest.pelzGood(d, n),
                     "Should throw TooManyIterationsException when the loop does not converge.");
    }

    @Test
    void testPelzGood_NegativeD() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = -1.0;
        int n = 10;
        double result = ksTest.pelzGood(d, n);
        assertTrue(Double.isFinite(result), "Result should be a finite number even when d is negative.");
    }

    @Test
    void testPelzGood_BoundaryD_One() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = 1.0;
        int n = 1;
        double result = ksTest.pelzGood(d, n);
        assertTrue(Double.isFinite(result), "Result should be a finite number for d=1 and n=1.");
    }
    
    @Test
    void testPelzGood_BoundaryD_MaxDouble() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = Double.MAX_VALUE;
        int n = 10;
        double result = ksTest.pelzGood(d, n);
        assertTrue(Double.isFinite(result), "Result should be a finite number for d=Double.MAX_VALUE.");
    }
    
    @Test
    void testPelzGood_BoundaryD_MinPositive() {
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double d = Double.MIN_VALUE;
        int n = 10;
        // Depending on implementation, may throw or not. If not, it should throw TooManyIterationsException
        assertThrows(TooManyIterationsException.class, () -> ksTest.pelzGood(d, n),
                     "Should throw TooManyIterationsException for extremely small d causing non-convergence.");
    }
}