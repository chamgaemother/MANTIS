package org.apache.commons.math3.special;

import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BesselJ_rjBesl_0_1_Test {

    @Test
    @DisplayName("Valid input with nb=1, x within small range, alpha=0")
    void TC01_valid_single_iteration_small_x_alpha_zero() {
        double x = 1.0;
        double alpha = 0.0;
        int nb = 1;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(1, result.getVals().length, "The length of b should be 1.");
        assertEquals(1, result.getnVals(), "ncalc should be set to 1.");
    }

    @Test
    @DisplayName("Valid input with nb=5, x within range, alpha=0.5")
    void TC02_valid_multiple_iterations() {
        double x = 10.0;
        double alpha = 0.5;
        int nb = 5;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(5, result.getVals().length, "The length of b should be 5.");
        assertEquals(5, result.getnVals(), "ncalc should be set to 5.");
    }

    @Test
    @DisplayName("Edge case with x exactly at RTNSIG")
    void TC03_boundary_x_RTN_SIG() throws Exception {
        Field rtnSigField = BesselJ.class.getDeclaredField("RTNSIG");
        rtnSigField.setAccessible(true);
        double RTNSIG = rtnSigField.getDouble(null);
        
        double x = RTNSIG;
        double alpha = 0.3;
        int nb = 3;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(3, result.getVals().length, "The length of b should be 3.");
        assertEquals(3, result.getnVals(), "ncalc should be set to 3.");
    }

    @Test
    @DisplayName("Alpha at lower boundary (alpha=0)")
    void TC04_boundary_alpha_zero() {
        double x = 5.0;
        double alpha = 0.0;
        int nb = 2;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(2, result.getVals().length, "The length of b should be 2.");
        assertEquals(2, result.getnVals(), "ncalc should be set to 2.");
    }

    @Test
    @DisplayName("Alpha near upper boundary (alpha=0.999999)")
    void TC05_boundary_alpha_max() {
        double x = 15.0;
        double alpha = 0.999999;
        int nb = 4;
        BesselJ.BesselJResult result = BesselJ.rjBesl(x, alpha, nb);
        assertEquals(4, result.getVals().length, "The length of b should be 4.");
        assertEquals(4, result.getnVals(), "ncalc should be set to 4.");
    }
}
