package com.fasterxml.jackson.databind.deser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.KeyDeserializer;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UntypedObjectDeserializer_createContextual_0_1_Test {

//     @Test
//     @DisplayName("createContextual with property null and defaultMergeable false")
//     void TC01() throws Exception {
        // Arrange
//         DeserializationContext ctxt = mock(DeserializationContext.class);
//         MapperConfig<?> config = mock(MapperConfig.class);
//         when(ctxt.getConfig()).thenReturn(config);
//         when(config.getDefaultMergeable(Object.class)).thenReturn(Boolean.FALSE);
//         BeanProperty property = null;
// 
//         UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer((JavaType) null, (JavaType) null);
// 
        // Act
//         JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);
// 
        // Assert
//         assertTrue(result.getClass().getSimpleName().equals("UntypedObjectDeserializerNR"));
//     }

//     @Test
//     @DisplayName("createContextual with property not null and defaultMergeable true")
//     void TC02() throws Exception {
        // Arrange
//         DeserializationContext ctxt = mock(DeserializationContext.class);
//         MapperConfig<?> config = mock(MapperConfig.class);
//         when(ctxt.getConfig()).thenReturn(config);
//         when(config.getDefaultMergeable(Object.class)).thenReturn(Boolean.TRUE);
//         BeanProperty property = mock(BeanProperty.class);
// 
//         UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer((JavaType) null, (JavaType) null);
// 
        // Act
//         JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);
// 
        // Assert
//         assertTrue(result instanceof UntypedObjectDeserializer);
//     }

    @Test
    @DisplayName("createContextual with standard customKeyDeserializer")
    void TC03() throws Exception {
        // Arrange
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);
        KeyDeserializer standardKeyDeserializer = mock(KeyDeserializer.class);
        when(ctxt.constructType(Object.class)).thenReturn((JavaType) mock(JavaType.class));
        when(ctxt.findKeyDeserializer(ctxt.constructType(Object.class), property)).thenReturn(null); // Fixed

        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer((JavaType) null, (JavaType) null);

        // Act
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        // Assert
        assertTrue(result instanceof UntypedObjectDeserializer);
    }

    @Test
    @DisplayName("createContextual with non-standard customKeyDeserializer")
    void TC04() throws Exception {
        // Arrange
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);
        KeyDeserializer customKeyDeserializer = mock(KeyDeserializer.class);
        when(ctxt.constructType(Object.class)).thenReturn((JavaType) mock(JavaType.class));
        when(ctxt.findKeyDeserializer(ctxt.constructType(Object.class), property)).thenReturn(customKeyDeserializer);

        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer((JavaType) null, (JavaType) null);

        // Act
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        // Assert
        assertNotSame(deserializer, result);
    }

    @Test
    @DisplayName("createContextual with all deserializers null")
    void TC05() throws Exception {
        // Arrange
        DeserializationContext ctxt = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);
        when(ctxt.constructType(Object.class)).thenReturn((JavaType) mock(JavaType.class));
        when(ctxt.findKeyDeserializer(ctxt.constructType(Object.class), property)).thenReturn(null);

        UntypedObjectDeserializer deserializer = new UntypedObjectDeserializer((JavaType) null, (JavaType) null);

        // Using reflection to set all deserializers to null
        setDeserializerFieldsToNull(deserializer);

        // Act
        JsonDeserializer<?> result = deserializer.createContextual(ctxt, property);

        // Assert
        assertTrue(result.getClass().getSimpleName().equals("UntypedObjectDeserializerNR"));
    }

    private void setDeserializerFieldsToNull(UntypedObjectDeserializer deserializer) throws Exception {
        Field[] fields = UntypedObjectDeserializer.class.getDeclaredFields();
        for (Field field : fields) {
            if (field.getName().startsWith("_")) {
                field.setAccessible(true);
                field.set(deserializer, null);
            }
        }
    }

}