package org.apache.commons.math3.stat.descriptive;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.apache.commons.math3.stat.descriptive.moment.Mean;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;

public class MultivariateSummaryStatistics_equals_1_1_Test {

    @Test
    @DisplayName("equals(null) returns false when the object is null")
    public void TC13_equalsWithNullObject() {
        // GIVEN
        MultivariateSummaryStatistics stats = new MultivariateSummaryStatistics(2, true);

        // WHEN
        boolean result = stats.equals(null);

        // THEN
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when internal summaries contain NaN values")
    public void TC14_equalsWithNaNInInternalSummaries() throws Exception {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);

        // Use reflection to set one internal summary to NaN
        Field meanImplField = MultivariateSummaryStatistics.class.getDeclaredField("meanImpl");
        meanImplField.setAccessible(true);

        // Create a new array to mimic the StorelessUnivariateStatistic
        Mean[] nanMeanImpl = new Mean[2];
        for (int i = 0; i < nanMeanImpl.length; i++) {
            // Create a subclass instance of StorelessUnivariateStatistic with NaN result
            nanMeanImpl[i] = new Mean() {
                @Override
                public double getResult() {
                    return Double.NaN;
                }
            };
        }

        // Ensure stats1's meanImpl field uses NaN values
        meanImplField.set(stats1, nanMeanImpl);

        // WHEN
        boolean result = stats1.equals(stats2);

        // THEN
        Assertions.assertFalse(result);
    }
}