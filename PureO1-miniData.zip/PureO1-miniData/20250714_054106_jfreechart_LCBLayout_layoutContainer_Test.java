package org.jfree.chart.ui;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class LCBLayoutTest {

    // Mock Component with predefined preferred size and tracking bounds
    class MockComponent extends Component {
        private Dimension preferredSize;
        private int x, y, width, height;

        public MockComponent(Dimension preferredSize) {
            this.preferredSize = preferredSize;
        }

        @Override
        public Dimension getPreferredSize() {
            return preferredSize;
        }

        @Override
        public Dimension getMinimumSize() {
            return preferredSize;
        }

        @Override
        public void setBounds(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        public int getXBound() { return x; }
        public int getYBound() { return y; }
        public int getWidthBound() { return width; }
        public int getHeightBound() { return height; }
    }

    // Mock Container with configurable insets and components
    class MockContainer extends Container {
        private Insets insets;
        private List<Component> components = new ArrayList<>();
        private int width = 300;
        private int height = 300;

        public MockContainer(Insets insets) {
            this.insets = insets;
        }

        @Override
        public Insets getInsets() {
            return insets;
        }

        @Override
        public int getComponentCount() {
            return components.size();
        }

        @Override
        public Component getComponent(int index) {
            return components.get(index);
        }

        public void addMockComponent(Component comp) {
            components.add(comp);
        }

        @Override
        public int getWidth() {
            return width;
        }

        @Override
        public int getHeight() {
            return height;
        }

        public void setSize(int width, int height) {
            this.width = width;
            this.height = height;
        }
    }

    @Test
    void testLayoutContainer_nullParent() {
        LCBLayout layout = new LCBLayout(1);
        assertThrows(NullPointerException.class, () -> layout.layoutContainer(null));
    }

    @Test
    void testLayoutContainer_zeroComponents() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        LCBLayout layout = new LCBLayout(1);
        assertDoesNotThrow(() -> layout.layoutContainer(parent));
        // No components to layout, nothing to assert
    }

    @Test
    void testLayoutContainer_oneComponent() {
        MockContainer parent = new MockContainer(new Insets(5, 5, 5, 5));
        MockComponent comp1 = new MockComponent(new Dimension(50, 20));
        parent.addMockComponent(comp1);
        LCBLayout layout = new LCBLayout(1);
        layout.layoutContainer(parent);
        assertEquals(5, comp1.getXBound());
        assertEquals(5, comp1.getYBound());
        assertEquals(50, comp1.getWidthBound());
        assertEquals(20, comp1.getHeightBound());
    }

    @Test
    void testLayoutContainer_threeComponents_exactColumns() {
        MockContainer parent = new MockContainer(new Insets(10, 10, 10, 10));
        MockComponent comp1 = new MockComponent(new Dimension(40, 30));
        MockComponent comp2 = new MockComponent(new Dimension(60, 25));
        MockComponent comp3 = new MockComponent(new Dimension(50, 35));
        parent.addMockComponent(comp1);
        parent.addMockComponent(comp2);
        parent.addMockComponent(comp3);
        LCBLayout layout = new LCBLayout(1);
        layout.layoutContainer(parent);
        // Column widths
        assertEquals(40, layout.colWidth[0]);
        assertEquals(60, layout.colWidth[1]);
        assertEquals(50, layout.colWidth[2]);
        // Row heights
        assertEquals(35, layout.rowHeight[0]);
        // Component bounds
        assertEquals(10, comp1.getXBound());
        assertEquals(10 + (35 - 30) / 2, comp1.getYBound());
        assertEquals(40 + 10, comp2.getXBound());
        assertEquals(10 + (35 - 25) / 2, comp2.getYBound());
        assertEquals(40 + 10 + 60 + 6, comp3.getXBound());
        assertEquals(10 + (35 - 35) / 2, comp3.getYBound());
    }

    @Test
    void testLayoutContainer_fourComponents_nonExactColumns() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        MockComponent comp1 = new MockComponent(new Dimension(30, 20));
        MockComponent comp2 = new MockComponent(new Dimension(40, 25));
        MockComponent comp3 = new MockComponent(new Dimension(35, 15));
        MockComponent comp4 = new MockComponent(new Dimension(50, 30));
        parent.addMockComponent(comp1);
        parent.addMockComponent(comp2);
        parent.addMockComponent(comp3);
        parent.addMockComponent(comp4);
        LCBLayout layout = new LCBLayout(2);
        layout.layoutContainer(parent);
        // First row
        assertEquals(30, layout.colWidth[0]);
        assertEquals(40, layout.colWidth[1]);
        assertEquals(35, layout.colWidth[2]);
        // Second row
        assertEquals(50, layout.colWidth[0] < 50 ? 50 : layout.colWidth[0]);
        assertEquals(40, layout.colWidth[1]);
        assertEquals(35, layout.colWidth[2]);
        assertEquals(30, layout.rowHeight[0]);
        assertEquals(30, layout.rowHeight[1]);
        // Component bounds
        // Row 0
        assertEquals(0, comp1.getXBound());
        assertEquals((30 - 20) / 2, comp1.getYBound());
        assertEquals(30, comp2.getXBound());
        assertEquals((30 - 25) / 2, comp2.getYBound());
        assertEquals(30 + 40 + 6, comp3.getXBound());
        assertEquals((30 - 15) / 2, comp3.getYBound());
        // Row 1
        assertEquals(0, comp4.getXBound());
        assertEquals(30 + 2, comp4.getYBound());
    }

    @Test
    void testLayoutContainer_adjustColumnWidth_positive() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        parent.setSize(200, 100);
        MockComponent comp1 = new MockComponent(new Dimension(30, 20));
        MockComponent comp2 = new MockComponent(new Dimension(40, 25));
        MockComponent comp3 = new MockComponent(new Dimension(35, 15));
        parent.addMockComponent(comp1);
        parent.addMockComponent(comp2);
        parent.addMockComponent(comp3);
        LCBLayout layout = new LCBLayout(1);
        layout.layoutContainer(parent);
        // Total width before adjustment: 30 + 40 + 35 = 105
        // Available: 200 - 0 - 0 -10 -6 = 184
        // Adjustment: 40 + (184 - 105) = 40 + 79 = 119
        assertEquals(30, layout.colWidth[0]);
        assertEquals(119, layout.colWidth[1]);
        assertEquals(35, layout.colWidth[2]);
    }

    @Test
    void testLayoutContainer_adjustColumnWidth_negative() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        parent.setSize(80, 100);
        MockComponent comp1 = new MockComponent(new Dimension(30, 20));
        MockComponent comp2 = new MockComponent(new Dimension(40, 25));
        MockComponent comp3 = new MockComponent(new Dimension(35, 15));
        parent.addMockComponent(comp1);
        parent.addMockComponent(comp2);
        parent.addMockComponent(comp3);
        LCBLayout layout = new LCBLayout(1);
        layout.layoutContainer(parent);
        // Total width before adjustment: 30 + 40 + 35 = 105
        // Available: 80 - 0 -0 -10 -6 =64
        // Adjustment: 40 + (64 -105) =40 -41 =-1
        assertEquals(30, layout.colWidth[0]);
        assertEquals(39, layout.colWidth[1]);
        assertEquals(35, layout.colWidth[2]);
    }

    @Test
    void testLayoutContainer_multipleRows() {
        MockContainer parent = new MockContainer(new Insets(5, 5, 5, 5));
        parent.setSize(400, 200);
        // Row 1
        MockComponent comp1 = new MockComponent(new Dimension(50, 20));
        MockComponent comp2 = new MockComponent(new Dimension(60, 25));
        MockComponent comp3 = new MockComponent(new Dimension(55, 30));
        // Row 2
        MockComponent comp4 = new MockComponent(new Dimension(45, 22));
        MockComponent comp5 = new MockComponent(new Dimension(65, 28));
        MockComponent comp6 = new MockComponent(new Dimension(50, 24));
        parent.addMockComponent(comp1);
        parent.addMockComponent(comp2);
        parent.addMockComponent(comp3);
        parent.addMockComponent(comp4);
        parent.addMockComponent(comp5);
        parent.addMockComponent(comp6);
        LCBLayout layout = new LCBLayout(2);
        layout.layoutContainer(parent);
        // Column widths before adjustment: [50, 65, 55]
        // Available: 400 -10 -6 =384
        // TotalWidth: 50 +60 +55=165
        // Adjustment: 65 + (384 - 165) =65 +219=284
        assertEquals(50, layout.colWidth[0]);
        assertEquals(284, layout.colWidth[1]);
        assertEquals(55, layout.colWidth[2]);
        // Component bounds
        // Row 1
        assertEquals(5, comp1.getXBound());
        assertEquals(5 + (30 - 20)/2, comp1.getYBound());
        assertEquals(5 + 50 +10, comp2.getXBound());
        assertEquals(5 + (30 -25)/2, comp2.getYBound());
        assertEquals(5 + 50 +10 +284 +6, comp3.getXBound());
        assertEquals(5 + (30 -30)/2, comp3.getYBound());
        // Row 2
        assertEquals(5, comp4.getXBound());
        assertEquals(5 + 30 +2, comp4.getYBound());
        assertEquals(5 + 50 +10, comp5.getXBound());
        assertEquals(5 + 30 +2 + (28 -28)/2, comp5.getYBound());
        assertEquals(5 + 50 +10 +284 +6, comp6.getXBound());
        assertEquals(5 + 30 +2 + (24 -24)/2, comp6.getYBound());
    }

    @Test
    void testLayoutContainer_maxrowsBoundary() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        LCBLayout layout = new LCBLayout(0); // maxrows=0
        MockComponent comp1 = new MockComponent(new Dimension(30, 20));
        parent.addMockComponent(comp1);
        // This should not cause array index out of bounds, but rowHeight has size 0
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> layout.layoutContainer(parent));
    }

    @Test
    void testLayoutContainer_negativeMaxrows() {
        assertThrows(NegativeArraySizeException.class, () -> new LCBLayout(-1));
    }

    @Test
    void testLayoutContainer_largeNumberOfComponents() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        int maxrows = 10;
        LCBLayout layout = new LCBLayout(maxrows);
        for (int i = 0; i < 25; i++) {
            parent.addMockComponent(new MockComponent(new Dimension(10 + i, 10 + i)));
        }
        layout.layoutContainer(parent);
        // Verify column widths and row heights
        for (int c = 0; c < 3; c++) {
            int expectedWidth = 0;
            for (int r = 0; r < 25 / 3; r++) {
                int index = r * 3 + c;
                if (index < 25) {
                    expectedWidth = Math.max(expectedWidth, 10 + index);
                }
            }
            assertEquals(expectedWidth, layout.colWidth[c]);
        }
        for (int r = 0; r < 25 / 3; r++) {
            int expectedHeight = 0;
            for (int c = 0; c <3; c++) {
                int index = r *3 +c;
                if(index <25){
                    expectedHeight = Math.max(expectedHeight, 10 + index);
                }
            }
            assertEquals(expectedHeight, layout.rowHeight[r]);
        }
    }

    @Test
    void testLayoutContainer_vGapZero() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        parent.setSize(150, 100);
        LCBLayout layout = new LCBLayout(2);
        // Manually set gaps to zero using reflection or extend LCBLayout
        // For simplicity, assume default gaps
        MockComponent comp1 = new MockComponent(new Dimension(50, 20));
        MockComponent comp2 = new MockComponent(new Dimension(50, 20));
        MockComponent comp3 = new MockComponent(new Dimension(50, 20));
        MockComponent comp4 = new MockComponent(new Dimension(50, 20));
        parent.addMockComponent(comp1);
        parent.addMockComponent(comp2);
        parent.addMockComponent(comp3);
        parent.addMockComponent(comp4);
        layout.layoutContainer(parent);
        // Verify no vertical gap
        assertEquals(0, parent.getHeight() - (20 * 2));
    }

    @Test
    void testLayoutContainer_componentsWithZeroSize() {
        MockContainer parent = new MockContainer(new Insets(0, 0, 0, 0));
        MockComponent comp1 = new MockComponent(new Dimension(0, 0));
        MockComponent comp2 = new MockComponent(new Dimension(0, 0));
        MockComponent comp3 = new MockComponent(new Dimension(0, 0));
        parent.addMockComponent(comp1);
        parent.addMockComponent(comp2);
        parent.addMockComponent(comp3);
        LCBLayout layout = new LCBLayout(1);
        layout.layoutContainer(parent);
        assertEquals(0, comp1.getWidthBound());
        assertEquals(0, comp1.getHeightBound());
        assertEquals(0, comp2.getWidthBound());
        assertEquals(0, comp2.getHeightBound());
        assertEquals(0, comp3.getWidthBound());
        assertEquals(0, comp3.getHeightBound());
    }
}