package org.jfree.data.general;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;

public class DatasetUtilsTest {

    @Test
    void testIterateToFindDomainBounds_NullDataset() {
        List<Comparable> visibleSeriesKeys = Collections.emptyList();
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(null, visibleSeriesKeys, true);
        });
        assertEquals("null \'dataset\' argument.", exception.getMessage());
    }

    @Test
    void testIterateToFindDomainBounds_NullVisibleSeriesKeys() {
        XYDataset dataset = mock(XYDataset.class);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateToFindDomainBounds(dataset, null, true);
        });
        assertEquals("null \'visibleSeriesKeys\' argument.", exception.getMessage());
    }

    @Test
    void testIterateToFindDomainBounds_EmptyVisibleSeriesKeys_IntervalXYDataset() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        List<Comparable> visibleSeriesKeys = Collections.emptyList();
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, true);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_EmptyVisibleSeriesKeys_PlainXYDataset() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Collections.emptyList();
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_IncludeInterval_IsIntervalXYDataset_NoData() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, true);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_IncludeInterval_IsIntervalXYDataset_WithData() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);
        when(dataset.getStartXValue(0, 1)).thenReturn(2.5);
        when(dataset.getEndXValue(0, 1)).thenReturn(3.5);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, true);
        assertNotNull(result);
        assertEquals(0.5, result.getLowerBound());
        assertEquals(3.5, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_IncludeInterval_IsNotIntervalXYDataset_NoData() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, true);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_IncludeInterval_IsNotIntervalXYDataset_WithData() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 2)).thenReturn(4.0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNotNull(result);
        assertEquals(1.0, result.getLowerBound());
        assertEquals(4.0, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_AllXNaN_IntervalXYDataset() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getStartXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getStartXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, true);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_AllXNaN_PlainXYDataset() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_MultipleSeries_IntervalXYDataset() {
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1", "Series2");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.indexOf("Series2")).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(2.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.5);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.5);
        when(dataset.getItemCount(1)).thenReturn(1);
        when(dataset.getXValue(1, 0)).thenReturn(4.0);
        when(dataset.getStartXValue(1, 0)).thenReturn(3.5);
        when(dataset.getEndXValue(1, 0)).thenReturn(4.5);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, true);
        assertNotNull(result);
        assertEquals(1.5, result.getLowerBound());
        assertEquals(4.5, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_MultipleSeries_PlainXYDataset() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1", "Series2");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.indexOf("Series2")).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);
        when(dataset.getItemCount(1)).thenReturn(2);
        when(dataset.getXValue(1, 0)).thenReturn(2.0);
        when(dataset.getXValue(1, 1)).thenReturn(4.0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNotNull(result);
        assertEquals(1.0, result.getLowerBound());
        assertEquals(4.0, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_SeriesKeyNotFound() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(-1);
        when(dataset.getItemCount(-1)).thenReturn(0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_SeriesWithSomeNaN() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 2)).thenReturn(5.0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNotNull(result);
        assertEquals(1.0, result.getLowerBound());
        assertEquals(5.0, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_NoVisibleSeries() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1", "Series2");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.indexOf("Series2")).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getItemCount(1)).thenReturn(2);
        when(dataset.getXValue(1, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(1, 1)).thenReturn(Double.NaN);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNull(result);
    }

    @Test
    void testIterateToFindDomainBounds_SingleSeriesSingleItem() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(2.0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNotNull(result);
        assertEquals(2.0, result.getLowerBound());
        assertEquals(2.0, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_SingleSeriesMultipleItems() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(4);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(2.0);
        when(dataset.getXValue(0, 3)).thenReturn(4.0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNotNull(result);
        assertEquals(1.0, result.getLowerBound());
        assertEquals(4.0, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_MultipleVisibleSeriesWithData() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1", "Series2");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.indexOf("Series2")).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(5.0);
        when(dataset.getItemCount(1)).thenReturn(3);
        when(dataset.getXValue(1, 0)).thenReturn(2.0);
        when(dataset.getXValue(1, 1)).thenReturn(4.0);
        when(dataset.getXValue(1, 2)).thenReturn(6.0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNotNull(result);
        assertEquals(1.0, result.getLowerBound());
        assertEquals(6.0, result.getUpperBound());
    }

    @Test
    void testIterateToFindDomainBounds_MultipleVisibleSeriesWithSomeEmpty() {
        XYDataset dataset = mock(XYDataset.class);
        List<Comparable> visibleSeriesKeys = Arrays.asList("Series1", "Series2", "Series3");
        when(dataset.indexOf("Series1")).thenReturn(0);
        when(dataset.indexOf("Series2")).thenReturn(1);
        when(dataset.indexOf("Series3")).thenReturn(2);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);
        when(dataset.getItemCount(1)).thenReturn(0);
        when(dataset.getItemCount(2)).thenReturn(1);
        when(dataset.getXValue(2, 0)).thenReturn(4.0);
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, false);
        assertNotNull(result);
        assertEquals(1.0, result.getLowerBound());
        assertEquals(4.0, result.getUpperBound());
    }

}