package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_3_Test {

    @Test
    @DisplayName("metaphone word with 'SCH' converts to 'SK'")
    void TC11() {
        // Given
        String txt = "school";
        Metaphone metaphone = new Metaphone();

        // When
        String result = metaphone.metaphone(txt);

        // Then
        assertEquals("SKL", result);
    }

    @Test
    @DisplayName("metaphone word with 'TH' converts to '0'")
    void TC12() {
        // Given
        String txt = "that";
        Metaphone metaphone = new Metaphone();

        // When
        String result = metaphone.metaphone(txt);

        // Then
        assertEquals("0T", result);
    }

    @Test
    @DisplayName("metaphone word with double consonants (e.g., 'letter') removes duplicate consonants")
    void TC13() {
        // Given
        String txt = "letter";
        Metaphone metaphone = new Metaphone();

        // When
        String result = metaphone.metaphone(txt);

        // Then
        assertEquals("LTR", result);
    }

    @Test
    @DisplayName("metaphone word with 'CIA' and vowel following converts correctly")
    void TC14() {
        // Given
        String txt = "facial";
        Metaphone metaphone = new Metaphone();

        // When
        String result = metaphone.metaphone(txt);

        // Then
        assertEquals("FSL", result);
    }

    @Test
    @DisplayName("metaphone word with 'G' before vowel converts to 'J'")
    void TC15() {
        // Given
        String txt = "get";
        Metaphone metaphone = new Metaphone();

        // When
        String result = metaphone.metaphone(txt);

        // Then
        assertEquals("JT", result);
    }
}