package com.fasterxml.jackson.databind.module;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.Module.SetupContext;

public class SimpleModule_setupModule_0_1_Test {

    @Test
    @DisplayName("All configurational fields are null; no serializers or deserializers are added")
    void TC01_setupModule_withAllFieldsNull() {
        // GIVEN
        SimpleModule module = new SimpleModule();
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verifyNoInteractions(context);
    }

    @Test
    @DisplayName("Only _serializers is not null; serializers are added to SetupContext")
    void TC02_setupModule_withOnlySerializers() {
        // GIVEN
        SimpleSerializers serializers = new SimpleSerializers();
        SimpleModule module = new SimpleModule();
        module.setSerializers(serializers);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addSerializers(serializers);
    }

    @Test
    @DisplayName("Only _deserializers is not null; deserializers are added to SetupContext")
    void TC03_setupModule_withOnlyDeserializers() {
        // GIVEN
        SimpleDeserializers deserializers = new SimpleDeserializers();
        SimpleModule module = new SimpleModule();
        module.setDeserializers(deserializers);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addDeserializers(deserializers);
    }

    @Test
    @DisplayName("Both _serializers and _deserializers are populated")
    void TC04_setupModule_withSerializersAndDeserializers() {
        // GIVEN
        SimpleSerializers serializers = new SimpleSerializers();
        SimpleDeserializers deserializers = new SimpleDeserializers();
        SimpleModule module = new SimpleModule();
        module.setSerializers(serializers);
        module.setDeserializers(deserializers);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addSerializers(serializers);
        verify(context).addDeserializers(deserializers);
    }

    @Test
    @DisplayName("Only _keySerializers is not null; key serializers are added to SetupContext")
    void TC05_setupModule_withOnlyKeySerializers() {
        // GIVEN
        SimpleSerializers keySerializers = new SimpleSerializers();
        SimpleModule module = new SimpleModule();
        module.setKeySerializers(keySerializers);
        SetupContext context = mock(SetupContext.class);

        // WHEN
        module.setupModule(context);

        // THEN
        verify(context).addKeySerializers(keySerializers);
    }
}