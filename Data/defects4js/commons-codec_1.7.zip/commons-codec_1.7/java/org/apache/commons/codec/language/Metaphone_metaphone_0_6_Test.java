package org.apache.commons.codec.language;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_6_Test {

    @Test
    @DisplayName("metaphone word with 'G' before non-vowel converts to 'K'")
    void TC26_metaphone_G_before_non_vowel() {
        // GIVEN
        String txt = "gift";
        
        // WHEN
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("KFT", result);
    }

    @Test
    @DisplayName("metaphone word with 'C' followed by front vowels converts to 'S'")
    void TC27_metaphone_C_before_front_vowel() {
        // GIVEN
        String txt = "city";
        
        // WHEN
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("ST", result);
    }

    @Test
    @DisplayName("metaphone word with 'C' followed by non-front vowels converts to 'K'")
    void TC28_metaphone_C_before_non_front_vowel() {
        // GIVEN
        String txt = "cat";
        
        // WHEN
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("KT", result);
    }

    @Test
    @DisplayName("metaphone word with 'D' followed by 'GE' converts to 'J'")
    void TC29_metaphone_DGE_sequence() {
        // GIVEN
        String txt = "edge";
        
        // WHEN
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("J", result);
    }

    @Test
    @DisplayName("metaphone word with 'WH' converts to 'W'")
    void TC30_metaphone_WH_sequence() {
        // GIVEN
        String txt = "whale";
        
        // WHEN
        Metaphone metaphone = new Metaphone();
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("WL", result);
    }
}