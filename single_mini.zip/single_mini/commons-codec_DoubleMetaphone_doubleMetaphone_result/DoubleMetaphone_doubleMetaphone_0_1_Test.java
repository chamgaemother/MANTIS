package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_1_Test {

    @Test
    @DisplayName("doubleMetaphone(null, false) returns null")
    void TC01() throws Exception {
        // Initialize DoubleMetaphone instance
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // Test input
        String value = null;
        
        // Invoke the method under test
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // Assert the result is null
        assertNull(result);
    }

    @Test
    @DisplayName("doubleMetaphone empty string returns null")
    void TC02() throws Exception {
        // Initialize DoubleMetaphone instance
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // Test input
        String value = "";
        
        // Invoke the method under test
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // Assert the result is null
        assertNull(result);
    }

    @Test
    @DisplayName("doubleMetaphone with silent start prefix 'GN' correctly encodes 'GNOME'")
    void TC03() throws Exception {
        // Initialize DoubleMetaphone instance
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // Test input
        String value = "GNOME";
        
        // Invoke the method under test
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // Assert the encoded string excludes silent 'GN'
        assertTrue("NMM".equals(result) || "NAM".equals(result), "Encoded result should be 'NMM' or 'NAM' but was " + result);
    }

    @Test
    @DisplayName("doubleMetaphone with slavo-germanic origin encodes 'KAZAK'")
    void TC04() throws Exception {
        // Initialize DoubleMetaphone instance
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // Test input
        String value = "KAZAK";
        
        // Invoke the method under test
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // Assert the correct double metaphone encoding for slavo-germanic
        assertTrue("KSKK".equals(result) || "KSK".equals(result), "Encoded result should be 'KSKK' or 'KSK' but was " + result);
    }

    @Test
    @DisplayName("doubleMetaphone handles vowels correctly in 'AEIOUY'")
    void TC05() throws Exception {
        // Initialize DoubleMetaphone instance
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // Test input
        String value = "AEIOUY";
        
        // Invoke the method under test
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // Assert the encoded string includes initial vowel
        assertNotNull(result, "Result should not be null");
        assertTrue(result.startsWith("A"), "Encoded result should start with 'A' but was " + result);
    }
}