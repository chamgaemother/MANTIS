package org.jsoup.select;

import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeFilter.FilterResult;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

public class NodeTraversorTest {

    @Test
    void filter_nullFilter_throwsNullPointerException() {
        Node root = new Element("root");
        assertThrows(NullPointerException.class, () -> NodeTraversor.filter(null, root));
    }

    @Test
    void filter_nullRoot_returnsContinue() {
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, null);
        assertEquals(FilterResult.CONTINUE, result);
    }

    @Test
    void filter_headReturnsStop() {
        Node root = new Element("root");
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.STOP;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.STOP, result);
    }

    @Test
    void filter_headReturnsContinue_noChildren() {
        Element root = new Element("root");
        List<String> visited = new ArrayList<>();
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                visited.add("head:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                visited.add("tail:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(List.of("head:root", "tail:root"), visited);
    }

    @Test
    void filter_headReturnsContinue_withChildren() {
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        root.appendChild(child1);
        root.appendChild(child2);
        List<String> visited = new ArrayList<>();
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                visited.add("head:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                visited.add("tail:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(List.of(
            "head:root",
            "head:child1",
            "tail:child1",
            "head:child2",
            "tail:child2",
            "tail:root"
        ), visited);
    }

    @Test
    void filter_headReturnsSkipChildren_noChildren() {
        Element root = new Element("root");
        List<String> visited = new ArrayList<>();
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                visited.add("head:" + node.nodeName());
                return FilterResult.SKIP_CHILDREN;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                visited.add("tail:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(List.of("head:root", "tail:root"), visited);
    }

    @Test
    void filter_headReturnsSkipChildren_withChildren() {
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);
        List<String> visited = new ArrayList<>();
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                visited.add("head:" + node.nodeName());
                return FilterResult.SKIP_CHILDREN;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                visited.add("tail:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(List.of("head:root", "tail:root"), visited);
    }

    @Test
    void filter_tailReturnsStop() {
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.nodeName().equals("child")) {
                    return FilterResult.STOP;
                }
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.STOP, result);
    }

    @Test
    void filter_tailReturnsRemove() {
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        root.appendChild(child1);
        root.appendChild(child2);
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.nodeName().equals("child1")) {
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(1, root.childNodeSize());
        assertEquals("child2", root.child(0).nodeName());
    }

    @Test
    void filter_skipRemoveRoot() {
        Element root = new Element("root");
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.REMOVE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertNull(root.parent());
    }

    @Test
    void filter_multipleLevels() {
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element grandChild = new Element("grandChild");
        child1.appendChild(grandChild);
        root.appendChild(child1);
        root.appendChild(child2);
        List<String> visited = new ArrayList<>();
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                visited.add("head:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                visited.add("tail:" + node.nodeName());
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(List.of(
            "head:root",
            "head:child1",
            "head:grandChild",
            "tail:grandChild",
            "tail:child1",
            "head:child2",
            "tail:child2",
            "tail:root"
        ), visited);
    }

    @Test
    void filter_removeIntermediateNode() {
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element grandChild = new Element("grandChild");
        child1.appendChild(grandChild);
        root.appendChild(child1);
        root.appendChild(child2);
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.nodeName().equals("child1")) {
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(1, root.childNodeSize());
        assertEquals("child2", root.child(0).nodeName());
    }

    @Test
    void filter_nestedRemove() {
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element grandChild1 = new Element("grandChild1");
        Element grandChild2 = new Element("grandChild2");
        child1.appendChild(grandChild1);
        child1.appendChild(grandChild2);
        root.appendChild(child1);
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.nodeName().startsWith("grandChild")) {
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        Element updatedChild1 = (Element) root.child(0);
        assertEquals(0, updatedChild1.childNodeSize());
    }

    @Test
    void filter_headSkipAndTailRemove() {
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                if (node.nodeName().equals("root")) {
                    return FilterResult.SKIP_CHILDREN;
                }
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.nodeName().equals("child")) {
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        // child was skipped, so not traversed, hence not removed
        assertEquals(1, root.childNodeSize());
    }

    @Test
    void filter_headContinue_tailRemove() {
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);
        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.REMOVE;
            }
        };
        FilterResult result = NodeTraversor.filter(filter, root);
        assertEquals(FilterResult.CONTINUE, result);
        assertEquals(0, root.childNodeSize());
    }

}