package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class StringUtils_indexOfDifference_1_1_Test {

    @Test
    @DisplayName("TC16: Arrays contain strings with supplementary Unicode characters, differing at a supplementary character")
    public void testTC16() {
        CharSequence[] css = {"AðBC", "AðAC"}; // Strings with supplementary characters
        int result = StringUtils.indexOfDifference(css);
        assertEquals(3, result, "The index where surrogate pair differs should be 3");
    }

    @Test
    @DisplayName("TC17: Arrays contain strings with mixed basic and supplementary characters, differing at multiple positions")
    public void testTC17() {
        CharSequence[] css = {"AðBCð", "AðACð"};
        int result = StringUtils.indexOfDifference(css);
        assertEquals(3, result, "The first differing index between the surrogate pairs should be 3");
    }

}