package org.apache.commons.math3.special;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for Beta#regularizedBeta method.
 */
public class Beta_regularizedBeta_0_3_Test {

    @Test
    @DisplayName("Computation hits maxIterations without convergence")
    void TC11_ComputationHitsMaxIterationsWithoutConvergence() {
        // GIVEN
        double x = 0.5;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-15;
        int maxIterations = 1;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0 due to maxIterations limit.");
    }

    @Test
    @DisplayName("Computation within ContinuedFraction with even iteration steps")
    void TC12_ComputationWithinContinuedFractionWithEvenIterations() {
        // GIVEN
        double x = 0.5;
        double a = 4.0;
        double b = 5.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0 for even iteration steps.");
    }

    @Test
    @DisplayName("Computation within ContinuedFraction with odd iteration steps")
    void TC13_ComputationWithinContinuedFractionWithOddIterations() {
        // GIVEN
        double x = 0.5;
        double a = 3.0;
        double b = 4.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0 for odd iteration steps.");
    }

    @Test
    @DisplayName("All parameters are valid and x is at lower boundary (x = 0)")
    void TC14_AllParametersValid_xAtLowerBoundary() {
        // GIVEN
        double x = 0.0;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertEquals(0.0, result, "When x is 0, the regularized beta should be 0.0.");
    }

    @Test
    @DisplayName("All parameters are valid and x is at upper boundary (x = 1)")
    void TC15_AllParametersValid_xAtUpperBoundary() {
        // GIVEN
        double x = 1.0;
        double a = 2.0;
        double b = 3.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertEquals(1.0, result, "When x is 1, the regularized beta should be 1.0.");
    }
}