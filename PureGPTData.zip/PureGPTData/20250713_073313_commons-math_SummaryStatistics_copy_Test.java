import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.apache.commons.math3.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.moment.Variance;
import org.apache.commons.math3.stat.descriptive.rank.Max;
import org.apache.commons.math3.stat.descriptive.rank.Min;
import org.apache.commons.math3.stat.descriptive.summary.Sum;
import org.apache.commons.math3.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math3.stat.descriptive.summary.SumOfSquares;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class SummaryStatisticsTest {

    @Test
    public void testCopyWithNullSource() {
        SummaryStatistics dest = new SummaryStatistics();
        assertThrows(NullArgumentException.class, () -> SummaryStatistics.copy(null, dest));
    }

    @Test
    public void testCopyWithNullDest() {
        SummaryStatistics source = new SummaryStatistics();
        assertThrows(NullArgumentException.class, () -> SummaryStatistics.copy(source, null));
    }

    @Test
    public void testCopyWithBothNull() {
        assertThrows(NullArgumentException.class, () -> SummaryStatistics.copy(null, null));
    }

    @Test
    public void testCopyAllDefaultImplementations() {
        SummaryStatistics source = new SummaryStatistics();
        source.addValue(1.0);
        source.addValue(2.0);
        source.addValue(3.0);

        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);

        assertEquals(source.getN(), dest.getN());
        assertEquals(source.getSum(), dest.getSum());
        assertEquals(source.getMean(), dest.getMean());
        assertEquals(source.getVariance(), dest.getVariance());
        assertEquals(source.getMin(), dest.getMin());
        assertEquals(source.getMax(), dest.getMax());
    }

    @Test
    public void testCopyWithCustomVarianceImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setVarianceImpl(new Variance());
        source.addValue(1.0);
        source.addValue(2.0);
        source.addValue(3.0);

        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);

        assertEquals(source.getVariance(), dest.getVariance());
    }

    @Test
    public void testCopyWithCustomMeanImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setMeanImpl(new Mean());
        source.addValue(1.0);
        source.addValue(2.0);
        source.addValue(3.0);

        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);

        assertEquals(source.getMean(), dest.getMean());
    }

    @Test
    public void testCopyWithCustomGeoMeanImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setGeoMeanImpl(new GeometricMean(new SumOfLogs()));
        source.addValue(1.0);
        source.addValue(2.0);
        source.addValue(3.0);

        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);

        assertEquals(source.getGeometricMean(), dest.getGeometricMean());
    }

    @Test
    public void testCopyWithCustomMaxImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setMaxImpl(new Max());
        source.addValue(1.0);
        source.addValue(2.0);
        source.addValue(3.0);

        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);

        assertEquals(source.getMax(), dest.getMax());
    }

    @Test
    public void testCopyWithCustomMinImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setMinImpl(new Min());
        source.addValue(1.0);
        source.addValue(2.0);
        source.addValue(3.0);

        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);

        assertEquals(source.getMin(), dest.getMin());
    }

    @Test
    public void testCopyEdgeCaseNoValuesAdded() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);

        assertEquals(source.getN(), dest.getN());
        assertEquals(source.getSum(), dest.getSum());
        assertEquals(source.getMean(), dest.getMean());
        assertEquals(source.getVariance(), dest.getVariance());
        assertEquals(source.getMin(), dest.getMin());
        assertEquals(source.getMax(), dest.getMax());
    }
}