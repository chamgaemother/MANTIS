package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.charset.StandardCharsets;

public class JsonStringEncoder_encodeAsUTF8_0_4_Test {

    @Test
    @DisplayName("encodeAsUTF8 ending with outputPtr == outputEnd before final character")
    public void TC16_encodeAsUTF8_outputPtrReachesOutputEndBoundary() {
        // Given
        String text = "\u00C0" + "A".repeat(14);
        JsonStringEncoder encoder = new JsonStringEncoder();

        // When
        byte[] result = encoder.encodeAsUTF8(text);

        // Then
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result, "The encoded byte array should match the expected UTF-8 bytes.");
    }

    @Test
    @DisplayName("encodeAsUTF8 with maximum allowed characters without exceeding MAX_BYTE_BUFFER_SIZE")
    public void TC17_encodeAsUTF8_maximumAllowedInputSize() {
        // Given
        // Assuming MAX_BYTE_BUFFER_SIZE is defined as 1,000,000 bytes for testing
        String text = "A".repeat(666667);
        JsonStringEncoder encoder = new JsonStringEncoder();

        // When
        byte[] result = encoder.encodeAsUTF8(text);

        // Then
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result, "The encoded byte array should match the expected UTF-8 bytes for maximum input size.");
    }

    @Test
    @DisplayName("encodeAsUTF8 with multiple exception paths: buffer overflow and illegal surrogate")
    public void TC18_encodeAsUTF8_multipleExceptionPaths() {
        // Given
        JsonStringEncoder encoder = new JsonStringEncoder();
        String overflowText = "A".repeat(2000000);
        String illegalSurrogate = "\uD800";

        // When & Then
        // Case 1: Buffer overflow
        IllegalArgumentException overflowException = assertThrows(IllegalArgumentException.class, () -> {
            encoder.encodeAsUTF8(overflowText);
        }, "Expected encodeAsUTF8 to throw IllegalArgumentException due to buffer overflow.");
        assertTrue(overflowException.getMessage().contains("illegal"), "Exception message should indicate illegal condition.");
        
        // Case 2: Illegal surrogate
        IllegalArgumentException surrogateException = assertThrows(IllegalArgumentException.class, () -> {
            encoder.encodeAsUTF8(illegalSurrogate);
        }, "Expected encodeAsUTF8 to throw IllegalArgumentException due to illegal surrogate.");
        assertTrue(surrogateException.getMessage().contains("surrogate"), "Exception message should indicate surrogate issue.");
    }

    @Test
    @DisplayName("encodeAsUTF8 with multiple outputPtr resets")
    public void TC19_encodeAsUTF8_multipleOutputPtrResets() {
        // Given
        String text = "AÃ©AÃ©AÃ©AÃ©AÃ©AÃ©AÃ©AÃ©AÃ©AÃ©";
        JsonStringEncoder encoder = new JsonStringEncoder();

        // When
        byte[] result = encoder.encodeAsUTF8(text);

        // Then
        byte[] expected = text.getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result, "The encoded byte array should correctly handle multiple outputPtr resets.");
    }
}