package org.apache.commons.jxpath.util;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import org.junit.jupiter.api.Test;

class ValueUtilsTest {

    @Test
    void testGetValue_NullCollection() {
        Object result = ValueUtils.getValue(null, 0);
        assertNull(result, "Expected null when collection is null");
    }

    @Test
    void testGetValue_UnwrappedNull() {
        Object container = new ContainerImpl(null);
        Object result = ValueUtils.getValue(container, 0);
        assertNull(result, "Expected null when unwrapped collection is null");
    }

    @Test
    void testGetValue_Array_IndexNegative() {
        Object array = new int[] {1, 2, 3};
        Object result = ValueUtils.getValue(array, -1);
        assertNull(result, "Expected null for negative index on array");
    }

    @Test
    void testGetValue_Array_IndexOutOfBounds() {
        Object array = new String[] {"a", "b", "c"};
        Object result = ValueUtils.getValue(array, 3);
        assertNull(result, "Expected null for index >= array length");
    }

    @Test
    void testGetValue_Array_ValidIndex() {
        Object array = new String[] {"a", "b", "c"};
        Object result = ValueUtils.getValue(array, 1);
        assertEquals("b", result, "Expected element at index 1 in array");
    }

    @Test
    void testGetValue_List_IndexNegative() {
        List<String> list = Arrays.asList("x", "y", "z");
        Object result = ValueUtils.getValue(list, -2);
        assertNull(result, "Expected null for negative index on list");
    }

    @Test
    void testGetValue_List_IndexOutOfBounds() {
        List<String> list = Arrays.asList("x", "y", "z");
        Object result = ValueUtils.getValue(list, 3);
        assertNull(result, "Expected null for index >= list size");
    }

    @Test
    void testGetValue_List_ValidIndex() {
        List<String> list = Arrays.asList("x", "y", "z");
        Object result = ValueUtils.getValue(list, 2);
        assertEquals("z", result, "Expected element at index 2 in list");
    }

    @Test
    void testGetValue_Collection_IndexNegative() {
        Collection<String> set = new HashSet<>(Arrays.asList("alpha", "beta", "gamma"));
        Object result = ValueUtils.getValue(set, -1);
        assertNull(result, "Expected null for negative index on collection");
    }

    @Test
    void testGetValue_Collection_IndexOutOfBounds() {
        Collection<String> set = new HashSet<>(Arrays.asList("alpha", "beta", "gamma"));
        Object result = ValueUtils.getValue(set, 5);
        assertNull(result, "Expected null for index >= collection size");
    }

    @Test
    void testGetValue_Collection_ValidIndex() {
        Collection<String> set = new ArrayList<>(Arrays.asList("alpha", "beta", "gamma"));
        Object result = ValueUtils.getValue(set, 1);
        assertEquals("beta", result, "Expected element at index 1 in collection");
    }

    @Test
    void testGetValue_Collection_LastElement() {
        Collection<String> set = new ArrayList<>(Arrays.asList("alpha", "beta", "gamma"));
        Object result = ValueUtils.getValue(set, 2);
        assertEquals("gamma", result, "Expected last element in collection");
    }

    @Test
    void testGetValue_SingleObject() {
        String obj = "singleton";
        Object result = ValueUtils.getValue(obj, 0);
        assertEquals(obj, result, "Expected the object itself when not a collection");
    }

    @Test
    void testGetValue_SingleObject_WithNonZeroIndex() {
        String obj = "singleton";
        Object result = ValueUtils.getValue(obj, 5);
        assertEquals(obj, result, "Expected the object itself when not a collection, regardless of index");
    }

    @Test
    void testGetValue_EmptyArray() {
        Object array = new int[] {};
        Object result = ValueUtils.getValue(array, 0);
        assertNull(result, "Expected null when accessing any index on empty array");
    }

    @Test
    void testGetValue_EmptyList() {
        List<String> list = Collections.emptyList();
        Object result = ValueUtils.getValue(list, 0);
        assertNull(result, "Expected null when accessing any index on empty list");
    }

    @Test
    void testGetValue_EmptyCollection() {
        Collection<String> collection = Collections.emptySet();
        Object result = ValueUtils.getValue(collection, 0);
        assertNull(result, "Expected null when accessing any index on empty collection");
    }

    @Test
    void testGetValue_Array_WithNullElements() {
        Object array = new String[] {"a", null, "c"};
        Object result = ValueUtils.getValue(array, 1);
        assertNull(result, "Expected null for element at index with null value in array");
    }

    @Test
    void testGetValue_List_WithNullElements() {
        List<String> list = Arrays.asList("a", null, "c");
        Object result = ValueUtils.getValue(list, 1);
        assertNull(result, "Expected null for element at index with null value in list");
    }

    @Test
    void testGetValue_Collection_WithNullElements() {
        Collection<String> collection = new ArrayList<>(Arrays.asList("a", null, "c"));
        Object result = ValueUtils.getValue(collection, 1);
        assertNull(result, "Expected null for element at index with null value in collection");
    }

    // Helper class to simulate Container
    private static class ContainerImpl implements Container {
        private final Object value;

        public ContainerImpl(Object value) {
            this.value = value;
        }

        @Override
        public Object getValue() {
            return value;
        }
    }
}