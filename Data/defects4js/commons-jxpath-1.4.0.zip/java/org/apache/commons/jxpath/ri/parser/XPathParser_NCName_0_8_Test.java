package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class XPathParser_NCName_0_8_Test {

    @Test
    @DisplayName("NCName() processes kind FUNCTION_FLOOR and returns token image")
    public void TC36() throws Exception {
        // Initialize class with a dummy InputStream to avoid potential null issues
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Set jj_nt.kind to FUNCTION_FLOOR using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_FLOOR);

        // Set token.image using reflection
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedFloorImage");

        // Invoke NCName and assert the result
        String result = parser.NCName();
        assertEquals("expectedFloorImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_CEILING and returns token image")
    public void TC37() throws Exception {
        // Initialize class with a dummy InputStream to avoid potential null issues
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Set jj_nt.kind to FUNCTION_CEILING using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_CEILING);

        // Set token.image using reflection
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedCeilingImage");

        // Invoke NCName and assert the result
        String result = parser.NCName();
        assertEquals("expectedCeilingImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_ROUND and returns token image")
    public void TC38() throws Exception {
        // Initialize class with a dummy InputStream to avoid potential null issues
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Set jj_nt.kind to FUNCTION_ROUND using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_ROUND);

        // Set token.image using reflection
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedRoundImage");

        // Invoke NCName and assert the result
        String result = parser.NCName();
        assertEquals("expectedRoundImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_KEY and returns token image")
    public void TC39() throws Exception {
        // Initialize class with a dummy InputStream to avoid potential null issues
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Set jj_nt.kind to FUNCTION_KEY using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_KEY);

        // Set token.image using reflection
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);

        Field imageField = Token.class.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "expectedKeyImage");

        // Invoke NCName and assert the result
        String result = parser.NCName();
        assertEquals("expectedKeyImage", result);
    }

    @Test
    @DisplayName("NCName() processes undefined kind and throws ParseException")
    public void TC40() throws Exception {
        // Initialize class with a dummy InputStream to avoid potential null issues
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Set jj_nt.kind to an undefined value using reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, -1); // Assuming -1 is undefined

        // Invoke NCName and assert that ParseException is thrown
        assertThrows(ParseException.class, () -> {
            parser.NCName();
        });
    }
}