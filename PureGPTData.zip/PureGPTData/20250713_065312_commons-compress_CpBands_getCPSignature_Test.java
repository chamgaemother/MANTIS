import org.apache.commons.compress.harmony.pack200.CPSignature;
import org.apache.commons.compress.harmony.pack200.CpBands;
import org.apache.commons.compress.harmony.pack200.Segment;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CpBandsTest {

    private final Segment mockSegment = mock(Segment.class);
    private final CpBands cpBands = new CpBands(mockSegment, 5);

    @Test
    public void testGetCPSignature_NullInput() {
        assertNull(cpBands.getCPSignature(null), "Expected null for null input");
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "I", "Lcom/example/MyClass;", "[I", "Ljava/util/List<Ljava/lang/String;>;"})
    public void testGetCPSignature_SimpleSignatures(String signature) {
        CPSignature cps = cpBands.getCPSignature(signature);
        assertNotNull(cps, "CPSignature should not be null for input: " + signature);
        assertEquals(signature, cps.getUnderlyingString(), "Underlying string should match the input");
    }

    @Test
    public void testGetCPSignature_ComplexSignature() {
        String complexSignature = "Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;>;";
        CPSignature cps = cpBands.getCPSignature(complexSignature);
        assertNotNull(cps, "CPSignature should not be null for complex signature");
        assertEquals(complexSignature, cps.getUnderlyingString(), "Underlying string should match the input");
    }

    @Test
    public void testGetCPSignature_RepeatedCall() {
        String signature = "Ljava/lang/String;";
        CPSignature cps1 = cpBands.getCPSignature(signature);
        CPSignature cps2 = cpBands.getCPSignature(signature);
        assertSame(cps1, cps2, "Expected the same CPSignature instance for the same signature input");
    }

    @Test
    public void testGetCPSignature_RemoveCpUtf8Check() {
        String signatureWithClasses = "Lcom/example/Foo;Lcom/example/Bar$Baz;";
        CPSignature cps = cpBands.getCPSignature(signatureWithClasses);
        assertNotNull(cps, "CPSignature should not be null for complex signature with nested classes");
    }
}