package com.fasterxml.jackson.databind.deser;
import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
import java.lang.reflect.*;
import java.io.*;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.deser.impl.*;
import com.fasterxml.jackson.databind.introspect.*;
import com.fasterxml.jackson.databind.util.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class BeanDeserializerFactory_buildThrowableDeserializer_0_1_Test {

    @Test
    @DisplayName("buildThrowableDeserializer with no properties results in normal deserializer construction")
    public void TC01_buildThrowableDeserializer_with_no_properties() throws Exception {
        // GIVEN
        DeserializationContext ctxt = mock(DeserializationContext.class);
        JavaType javaType = mock(JavaType.class);
        BeanDescription beanDesc = mock(BeanDescription.class);

        when(ctxt.getConfig()).thenReturn(mock(DeserializationConfig.class));
        when(beanDesc.findProperties()).thenReturn(java.util.Collections.emptyList());

        BeanDeserializerFactory factory = new BeanDeserializerFactory(new DeserializerFactoryConfig());

        // WHEN
        JsonDeserializer<?> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        // THEN
        assertNotNull(deserializer, "Deserializer should not be null");
        assertFalse(deserializer instanceof BeanDeserializer, "Deserializer should not be an instance of BeanDeserializer");
    }

    @Test
    @DisplayName("buildThrowableDeserializer removes 'setCause' property when present")
    public void TC02_buildThrowableDeserializer_removes_setCause_property() throws Exception {
        // GIVEN
        DeserializationContext ctxt = mock(DeserializationContext.class);
        JavaType javaType = mock(JavaType.class);
        BeanDescription beanDesc = mock(BeanDescription.class);

        when(ctxt.getConfig()).thenReturn(mock(DeserializationConfig.class));
        BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, ctxt);
        /* Changed: Instead of tracking the iterator directly, verify the builder methods as below. */
        SettableBeanProperty setCauseProperty = mock(SettableBeanProperty.class);
        AnnotatedMethod annotatedMethod = mock(AnnotatedMethod.class);

        when(setCauseProperty.getMember()).thenReturn(annotatedMethod);
        when(annotatedMethod.getName()).thenReturn("setCause");
        Iterator<SettableBeanProperty> iterator = spy(Arrays.asList(setCauseProperty).iterator());
        when(builder.getProperties()).thenReturn(iterator); // Add method to mock builderâs properties list

        BeanDeserializerFactory factory = spy(new BeanDeserializerFactory(new DeserializerFactoryConfig()));
        doReturn(builder).when(factory).constructBeanDeserializerBuilder(ctxt, beanDesc);

        // WHEN
        factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        // THEN
        verify(iterator).remove(); // Confirm the remove method on iterator was called
    }

    @Test
    @DisplayName("buildThrowableDeserializer handles null 'initCause' method gracefully")
    public void TC03_buildThrowableDeserializer_with_null_initCause_method() throws Exception {
        // GIVEN
        DeserializationContext ctxt = mock(DeserializationContext.class);
        JavaType javaType = mock(JavaType.class);
        BeanDescription beanDesc = mock(BeanDescription.class);

        when(ctxt.getConfig()).thenReturn(mock(DeserializationConfig.class));
        when(beanDesc.findMethod(eq("initCause"), any(Class[].class))).thenReturn(null);
        BeanDeserializerBuilder builder = spy(new BeanDeserializerBuilder(beanDesc, ctxt));

        BeanDeserializerFactory factory = spy(new BeanDeserializerFactory(new DeserializerFactoryConfig()));
        doReturn(builder).when(factory).constructBeanDeserializerBuilder(eq(ctxt), eq(beanDesc));

        // WHEN
        JsonDeserializer<?> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        // THEN
        assertNotNull(deserializer, "Deserializer should be built without 'cause' property modifications");
    }

    @Test
    @DisplayName("buildThrowableDeserializer processes 'cause' as CreatorProperty successfully")
    public void TC04_buildThrowableDeserializer_with_cause_as_CreatorProperty() throws Exception {
        // GIVEN
        DeserializationContext ctxt = mock(DeserializationContext.class);
        DeserializationConfig config = mock(DeserializationConfig.class);
        JavaType javaType = mock(JavaType.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        BeanDeserializerBuilder builder = spy(new BeanDeserializerBuilder(beanDesc, ctxt));

        CreatorProperty causeCreatorProp = mock(CreatorProperty.class);

        when(ctxt.getConfig()).thenReturn(config);
        when(beanDesc.findMethod(eq("initCause"), any(Class[].class))).thenReturn(mock(AnnotatedMethod.class));
        when(builder.findProperty(PropertyName.construct("cause"))).thenReturn(causeCreatorProp);
        BeanDeserializerFactory factory = spy(new BeanDeserializerFactory(new DeserializerFactoryConfig()));
        doReturn(builder).when(factory).constructBeanDeserializerBuilder(eq(ctxt), eq(beanDesc));

        // WHEN
        factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        // THEN
        verify(causeCreatorProp).setFallbackSetter(null);
    }

    @Test
    @DisplayName("buildThrowableDeserializer applies PropertyNamingStrategy when renaming 'cause'")
    public void TC05_buildThrowableDeserializer_with_PropertyNamingStrategy() throws Exception {
        // GIVEN
        DeserializationContext ctxt = mock(DeserializationContext.class);
        DeserializationConfig config = mock(DeserializationConfig.class);
        PropertyNamingStrategy namingStrategy = mock(PropertyNamingStrategy.class);
        JavaType javaType = mock(JavaType.class);
        BeanDescription beanDesc = mock(BeanDescription.class);
        AnnotatedMethod initCauseMethod = mock(AnnotatedMethod.class);
        BeanDeserializerBuilder builder = spy(new BeanDeserializerBuilder(beanDesc, ctxt));

        when(ctxt.getConfig()).thenReturn(config);
        when(config.getPropertyNamingStrategy()).thenReturn(namingStrategy);
        when(beanDesc.findMethod(eq("initCause"), any(Class[].class))).thenReturn(initCauseMethod);
        when(namingStrategy.nameForSetterMethod(eq(config), eq(initCauseMethod), eq("cause"))).thenReturn("renamedCause");
        BeanDeserializerFactory factory = spy(new BeanDeserializerFactory(new DeserializerFactoryConfig()));
        doReturn(builder).when(factory).constructBeanDeserializerBuilder(eq(ctxt), eq(beanDesc));

        // WHEN
        JsonDeserializer<?> deserializer = factory.buildThrowableDeserializer(ctxt, javaType, beanDesc);

        // THEN
        assertNotNull(deserializer, "Deserializer should be built with renamed 'cause' property");
    }

    /**
     * A simple iterator implementation used to simulate iterating and removing items for the test.
     */
    private static class FakeIterator<E> implements Iterator<E> {
        private E current;
        private boolean removeCalled;

        FakeIterator(E element) {
            current = element;
            removeCalled = false;
        }

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public E next() {
            E temp = current;
            current = null;
            return temp;
        }

        @Override
        public void remove() {
            removeCalled = true;
        }
    }
}