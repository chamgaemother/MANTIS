import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.awt.geom.Ellipse2D;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

class DeviationRendererTest {

    private DeviationRenderer renderer;
    private Graphics2D g2Mock;
    private XYItemRendererState stateMock;
    private Rectangle2D dataAreaMock;
    private PlotRenderingInfo infoMock;
    private XYPlot plotMock;
    private ValueAxis domainAxisMock;
    private ValueAxis rangeAxisMock;
    private IntervalXYDataset datasetMock;
    private CrosshairState crosshairStateMock;

    @BeforeEach
    void setUp() {
        renderer = new DeviationRenderer();
        g2Mock = mock(Graphics2D.class);
        stateMock = mock(XYItemRendererState.class);
        dataAreaMock = mock(RectangularShape.class);
        infoMock = mock(PlotRenderingInfo.class);
        plotMock = mock(XYPlot.class);
        domainAxisMock = mock(ValueAxis.class);
        rangeAxisMock = mock(ValueAxis.class);
        datasetMock = mock(IntervalXYDataset.class);
        crosshairStateMock = mock(CrosshairState.class);
        when(plotMock.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plotMock.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        renderer.drawItem(g2Mock, stateMock, dataAreaMock, infoMock, plotMock,
                domainAxisMock, rangeAxisMock, datasetMock, 0, 0, null, 0);
        
        verify(g2Mock, never()).fill((GeneralPath) any());
    }

    @Test
    void testDrawItem_FirstPass() {
        renderer.setSeriesVisible(0, true);
        when(datasetMock.getItemCount(0)).thenReturn(2);
        when(plotMock.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxisMock.valueToJava2D(anyDouble(), eq(dataAreaMock), any()))
                .thenReturn(1.0);
        when(rangeAxisMock.valueToJava2D(anyDouble(), eq(dataAreaMock), any()))
                .thenReturn(1.0);
        when(datasetMock.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(datasetMock.getStartYValue(anyInt(), anyInt())).thenReturn(0.5);
        when(datasetMock.getEndYValue(anyInt(), anyInt())).thenReturn(1.5);
        
        renderer.drawItem(g2Mock, new DeviationRenderer.State(infoMock),
                dataAreaMock, infoMock, plotMock, domainAxisMock, rangeAxisMock,
                datasetMock, 0, 1, crosshairStateMock, 0);

        verify(g2Mock).setComposite(ArgumentMatchers.any());
        verify(g2Mock).fill(ArgumentMatchers.any(GeneralPath.class));
        verify(g2Mock).setComposite(ArgumentMatchers.any());
    }

    @Test
    void testDrawItem_SecondPass_LineVisible() {
        renderer.setSeriesVisible(0, true);
        renderer.setBaseLinesVisible(true);
        when(datasetMock.getItemCount(0)).thenReturn(2);
        when(domainAxisMock.valueToJava2D(anyDouble(), eq(dataAreaMock), any()))
                .thenReturn(1.0);
        when(rangeAxisMock.valueToJava2D(anyDouble(), eq(dataAreaMock), any()))
                .thenReturn(1.0);

        renderer.drawItem(g2Mock, new DeviationRenderer.State(infoMock),
                dataAreaMock, infoMock, plotMock, domainAxisMock, rangeAxisMock,
                datasetMock, 0, 0, crosshairStateMock, 1);

        verify(g2Mock, never()).draw(any());
    }

    @Test
    void testDrawItem_ThirdPass_ItemVisible() {
        renderer.setSeriesVisible(0, true);
        renderer.setBaseShapesVisible(true);
        when(datasetMock.getItemCount(0)).thenReturn(2);
        when(domainAxisMock.valueToJava2D(anyDouble(), eq(dataAreaMock), any()))
                .thenReturn(1.0);
        when(rangeAxisMock.valueToJava2D(anyDouble(), eq(dataAreaMock), any()))
                .thenReturn(1.0);

        stateMock.seriesPath = new GeneralPath();
        renderer.drawItem(g2Mock, stateMock,
                new Rectangle2D.Double(0, 0, 1, 1), infoMock, plotMock,
                domainAxisMock, rangeAxisMock, datasetMock, 0, 0, crosshairStateMock, 2);

        verify(g2Mock).fill(any(Ellipse2D.class));
    }
}