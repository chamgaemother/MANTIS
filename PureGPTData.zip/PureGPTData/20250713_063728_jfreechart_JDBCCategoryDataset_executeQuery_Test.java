import org.jfree.data.jdbc.JDBCCategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class JDBCCategoryDatasetTest {

    private Connection mockConnection;
    private Statement mockStatement;
    private ResultSet mockResultSet;
    private ResultSetMetaData mockMetaData;

    @BeforeEach
    public void setUp() throws SQLException {
        mockConnection = mock(Connection.class);
        mockStatement = mock(Statement.class);
        mockResultSet = mock(ResultSet.class);
        mockMetaData = mock(ResultSetMetaData.class);

        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
        when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
    }

    @Test
    public void testExecuteQueryWithNullResultSet() throws SQLException {
        when(mockConnection.createStatement()).thenReturn(null);
        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        assertThrows(SQLException.class, () -> dataset.executeQuery(mockConnection, "SELECT * FROM table"));
    }

    @Test
    public void testExecuteQueryWithInsufficientColumns() throws SQLException {
        when(mockMetaData.getColumnCount()).thenReturn(1);
        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        assertThrows(SQLException.class, () -> dataset.executeQuery(mockConnection, "SELECT * FROM table"));
    }

    @Test
    public void testExecuteQueryWithValidNumericData() throws SQLException {
        when(mockMetaData.getColumnCount()).thenReturn(3);
        when(mockMetaData.getColumnName(2)).thenReturn("Series1");
        when(mockMetaData.getColumnName(3)).thenReturn("Series2");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.DOUBLE);

        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockResultSet.getObject(2)).thenReturn(100);
        when(mockResultSet.getObject(3)).thenReturn(200.0);

        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM table");

        assertNotNull(dataset.getValue("Series1", "Category1"));
        assertNotNull(dataset.getValue("Series2", "Category1"));
    }

    @Test
    public void testExecuteQueryWithDateData() throws SQLException {
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockMetaData.getColumnName(2)).thenReturn("DateSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.DATE);

        Date date = new Date(System.currentTimeMillis());
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockResultSet.getObject(2)).thenReturn(date);

        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM table");

        assertNotNull(dataset.getValue("DateSeries", "Category1"));
    }

    @Test
    public void testExecuteQueryWithInvalidDataType() throws SQLException {
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockMetaData.getColumnName(2)).thenReturn("InvalidSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.BLOB); // Unsupported type

        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockResultSet.getObject(2)).thenReturn(null);

        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM table");

        assertNull(dataset.getValue("InvalidSeries", "Category1"));
    }

    @Test
    public void testExecuteQueryWithTransposedFlagFalse() throws SQLException {
        when(mockMetaData.getColumnCount()).thenReturn(3);
        when(mockMetaData.getColumnName(2)).thenReturn("Series1");
        when(mockMetaData.getColumnName(3)).thenReturn("Series2");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.INTEGER);
        when(mockMetaData.getColumnType(3)).thenReturn(Types.DOUBLE);

        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockResultSet.getObject(2)).thenReturn(100);
        when(mockResultSet.getObject(3)).thenReturn(200.0);

        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        dataset.setTranspose(false);
        dataset.executeQuery(mockConnection, "SELECT * FROM table");

        assertNotNull(dataset.getValue("Category1", "Series1"));
        assertNotNull(dataset.getValue("Category1", "Series2"));
    }

    @Test
    public void testExecuteQueryWithStringConvertibleToNumber() throws SQLException {
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockMetaData.getColumnName(2)).thenReturn("StringSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.VARCHAR);

        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockResultSet.getObject(2)).thenReturn("123.45");

        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM table");

        assertEquals(123.45, dataset.getValue("StringSeries", "Category1"));
    }

    @Test
    public void testExecuteQueryWithStringNotConvertibleToNumber() throws SQLException {
        when(mockMetaData.getColumnCount()).thenReturn(2);
        when(mockMetaData.getColumnName(2)).thenReturn("InvalidStringSeries");
        when(mockMetaData.getColumnType(2)).thenReturn(Types.VARCHAR);

        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getString(1)).thenReturn("Category1");
        when(mockResultSet.getObject(2)).thenReturn("not-a-number");

        JDBCCategoryDataset dataset = new JDBCCategoryDataset(mockConnection);
        dataset.executeQuery(mockConnection, "SELECT * FROM table");

        assertNull(dataset.getValue("InvalidStringSeries", "Category1"));
    }
}