package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonToken;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class ReaderBasedJsonParser_nextToken_0_1_Test {

    private ReaderBasedJsonParser createParser(String json) throws IOException {
        JsonFactory factory = new JsonFactory();
        Reader reader = new StringReader(json);
        return (ReaderBasedJsonParser) factory.createParser(reader);
    }

    @Test
    @DisplayName("nextToken() returns _nextAfterName() when current token is FIELD_NAME")
    public void TC01() throws Exception {
        // GIVEN
        ReaderBasedJsonParser parser = createParser("{\"key\": \"value\"}");
        
        // Set _currToken to FIELD_NAME using reflection
        Field currTokenField = ReaderBasedJsonParser.class.getDeclaredField("_currToken");
        currTokenField.setAccessible(true);
        currTokenField.set(parser, JsonToken.FIELD_NAME);
        
        // Set _nextToken to VALUE_STRING which _nextAfterName should return
        Field nextTokenField = ReaderBasedJsonParser.class.getDeclaredField("_nextToken");
        nextTokenField.setAccessible(true);
        nextTokenField.set(parser, JsonToken.VALUE_STRING);

        // WHEN
        JsonToken result = parser.nextToken();
        
        // THEN
        assertEquals(JsonToken.VALUE_STRING, result);
    }

    @Test
    @DisplayName("nextToken() handles incomplete token by skipping string")
    public void TC02() throws Exception {
        // GIVEN
        ReaderBasedJsonParser parser = createParser("{\"key\": \"value"); // Incomplete JSON
        
        // Set _currToken to a non-FIELD_NAME and _tokenIncomplete to true using reflection
        Field currTokenField = ReaderBasedJsonParser.class.getDeclaredField("_currToken");
        currTokenField.setAccessible(true);
        currTokenField.set(parser, JsonToken.START_OBJECT);
        
        Field tokenIncompleteField = ReaderBasedJsonParser.class.getDeclaredField("_tokenIncomplete");
        tokenIncompleteField.setAccessible(true);
        tokenIncompleteField.set(parser, true);
        
        // WHEN
        JsonToken result = parser.nextToken();
        
        // THEN
        Field closedField = ReaderBasedJsonParser.class.getDeclaredField("_closed");
        closedField.setAccessible(true);
        boolean isClosed = closedField.getBoolean(parser);
        
        assertTrue(isClosed, "Parser should be closed");
        assertNull(result, "Result should be null token");
    }

    @Test
    @DisplayName("nextToken() returns JsonToken.NOT_AVAILABLE when end of input is reached")
    public void TC03() throws Exception {
        // GIVEN
        ReaderBasedJsonParser parser = createParser(""); // Empty JSON
        
        // WHEN
        JsonToken result = parser.nextToken();
        
        // THEN
        assertNull(result, "Result should be null token"); // Not_AVAILABLE is not a valid accessible token
    }

    @Test
    @DisplayName("nextToken() closes parser and returns null token when _skipWSOrEnd() returns negative")
    public void TC04() throws Exception {
        // GIVEN
        ReaderBasedJsonParser parser = createParser("   "); // JSON with only whitespace
        
        // WHEN
        JsonToken result = parser.nextToken();
        
        // THEN
        Field closedField = ReaderBasedJsonParser.class.getDeclaredField("_closed");
        closedField.setAccessible(true);
        boolean isClosed = closedField.getBoolean(parser);
        
        assertTrue(isClosed, "Parser should be closed after skipping whitespace");
        assertNull(result, "Result should be null token");
    }

    @Test
    @DisplayName("nextToken() correctly closes scope when closing brace '}' is encountered")
    public void TC05() throws Exception {
        // GIVEN
        ReaderBasedJsonParser parser = createParser("{\"key\": \"value\"}");
        
        // Advance to the closing brace
        parser.nextToken(); // START_OBJECT
        parser.nextToken(); // FIELD_NAME
        parser.nextToken(); // VALUE_STRING
        
        // WHEN
        JsonToken result = parser.nextToken();
        
        // THEN
        assertEquals(JsonToken.END_OBJECT, result, "Result should be END_OBJECT");

        // Verify that the parsing context is updated correctly using reflection
        Field parsingContextField = ReaderBasedJsonParser.class.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        Object parsingContext = parsingContextField.get(parser);
        
        Method inObjectMethod = parsingContext.getClass().getDeclaredMethod("inObject");
        inObjectMethod.setAccessible(true);
        boolean inObject = (boolean) inObjectMethod.invoke(parsingContext);
        
        assertFalse(inObject, "Parser should no longer be inside an object scope");
    }
}