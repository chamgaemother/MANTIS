package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Flat3Map_put_0_2_Test {

    @Test
    @DisplayName("put with new key when size is 3 triggers delegateMap conversion")
    public void TC06_put_new_key_size3_delegateMap_conversion() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting private fields via reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, "key1".hashCode());

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, "key2".hashCode());

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.set(map, "key3".hashCode());

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        Object key = "key4";
        Object value = "value4";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Verify convertToMap was called by checking delegateMap is not null
        assertNotNull(delegateMapField.get(map), "delegateMap should be initialized after conversion");

        // Verify delegateMap.put was called by checking the key-value pair exists in delegateMap
        AbstractHashedMap delegateMap = (AbstractHashedMap) delegateMapField.get(map);
        Object delegateResult = delegateMap.put(key, value);
        assertNull(result, "Result of put should be null as per expected outcome");
    }

    @Test
    @DisplayName("put with key having same hashCode as key2 and equals key2 updates value2")
    public void TC07_put_key_sameHash_equals_key2_updates_value2() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting private fields via reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, "key2".hashCode());

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "oldValue2");

        Object key = "key2";
        Object value = "newValue2";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Verify value2 is updated
        assertEquals("newValue2", value2Field.get(map), "value2 should be updated to newValue2");

        // Verify old value is returned
        assertEquals("oldValue2", result, "put should return the old value2");
    }

    @Test
    @DisplayName("put with key having same hashCode but not equal to any existing keys adds new key")
    public void TC08_put_key_sameHash_notEqual_adds_new_key() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting private fields via reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, "key1".hashCode());

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.set(map, "key2".hashCode());

        Object key = "keyDifferent";
        Object value = "valueDifferent";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Verify key3 is set correctly
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        assertEquals("keyDifferent", key3Field.get(map), "key3 should be set to keyDifferent");

        // Verify value3 is set correctly
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        assertEquals("valueDifferent", value3Field.get(map), "value3 should be set to valueDifferent");

        // Verify result is null
        assertNull(result, "Result of put should be null as per expected outcome");
    }

    @Test
    @DisplayName("put with key having different hashCode and not equal adds new key")
    public void TC09_put_key_diffHash_notEqual_adds_new_key() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting private fields via reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, "key1".hashCode());

        Object key = "uniqueKey";
        Object value = "uniqueValue";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Verify key2 is set correctly
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        assertEquals("uniqueKey", key2Field.get(map), "key2 should be set to uniqueKey");

        // Verify value2 is set correctly
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        assertEquals("uniqueValue", value2Field.get(map), "value2 should be set to uniqueValue");

        // Verify result is null
        assertNull(result, "Result of put should be null as per expected outcome");
    }

    @Test
    @DisplayName("put with key having same hashCode and equals to key1 updates value1")
    public void TC10_put_key_sameHash_equals_key1_updates_value1() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Setting private fields via reflection
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 1);

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.set(map, "key1".hashCode());

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "oldValue1");

        Object key = "key1";
        Object value = "newValue1";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Verify value1 is updated
        assertEquals("newValue1", value1Field.get(map), "value1 should be updated to newValue1");

        // Verify old value is returned
        assertEquals("oldValue1", result, "put should return the old value1");
    }
}