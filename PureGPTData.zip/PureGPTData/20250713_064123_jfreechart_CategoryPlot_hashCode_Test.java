import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.util.SortOrder;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.util.CloneUtils;
import org.jfree.data.Range;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Stroke;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

class CategoryPlotTest {

    private CategoryPlot plot;
    
    @BeforeEach
    void setUp() {
        plot = new CategoryPlot();
    }

    @Test
    void testDefaultHashCode() {
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentOrientation() {
        plot.setOrientation(PlotOrientation.HORIZONTAL);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentRangePannable() {
        plot.setRangePannable(true);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentDomainGridlinesVisible() {
        plot.setDomainGridlinesVisible(true);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentDomainGridlinePosition() {
        plot.setDomainGridlinePosition(CategoryAnchor.END);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentRangeGridlinesVisible() {
        plot.setRangeGridlinesVisible(false);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentRangeMinorGridlinesVisible() {
        plot.setRangeMinorGridlinesVisible(true);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentAnchorValue() {
        plot.setAnchorValue(50.0);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentRangeCrosshairVisible() {
        plot.setRangeCrosshairVisible(true);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentDomainCrosshairVisible() {
        plot.setDomainCrosshairVisible(true);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentRangeCrosshairValue() {
        plot.setRangeCrosshairValue(100.0);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentRangeCrosshairLockedOnData() {
        plot.setRangeCrosshairLockedOnData(false);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentRangeZeroBaselineVisible() {
        plot.setRangeZeroBaselineVisible(true);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testDifferentWeights() {
        plot.setWeight(5);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithFixedDomainAxisSpace() {
        plot.setFixedDomainAxisSpace(new AxisSpace(), false);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithFixedRangeAxisSpace() {
        plot.setFixedRangeAxisSpace(new AxisSpace(), false);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithFixedLegendItems() {
        plot.setFixedLegendItems(new LegendItemCollection());
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithDomainAxes() {
        plot.setDomainAxes(new CategoryAxis[]{new CategoryAxis("Category")});
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithRangeAxes() {
        plot.setRangeAxes(new ValueAxis[]{new NumberAxis()});
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithDatasets() {
        CategoryDataset dataset = new DefaultCategoryDataset();
        plot.setDataset(0, dataset);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithDomainAxisLocations() {
        plot.setDomainAxisLocation(0, AxisLocation.BOTTOM_OR_RIGHT);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithRangeAxisLocations() {
        plot.setRangeAxisLocation(0, AxisLocation.BOTTOM_OR_RIGHT);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithDatasetToDomainAxesMap() {
        TreeMap<Integer, List<Integer>> map = new TreeMap<>();
        map.put(0, Arrays.asList(0));
        plot.setDatasetToDomainAxesMap(map);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithDatasetToRangeAxesMap() {
        TreeMap<Integer, List<Integer>> map = new TreeMap<>();
        map.put(0, Arrays.asList(0));
        plot.setDatasetToRangeAxesMap(map);
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithRenderers() {
        plot.setRenderers(new CategoryItemRenderer[]{new BarRenderer()});
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithAnnotations() {
        plot.addAnnotation(Mockito.mock(CategoryAnnotation.class));
        assertEquals(plot.hashCode(), plot.hashCode());
    }

    @Test
    void testWithShadowGenerator() {
        plot.setShadowGenerator(null);
        assertEquals(plot.hashCode(), plot.hashCode());
    }
}