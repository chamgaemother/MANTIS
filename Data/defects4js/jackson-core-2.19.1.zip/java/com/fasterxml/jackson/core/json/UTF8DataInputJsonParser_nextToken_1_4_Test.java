package com.fasterxml.jackson.core.json;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.json.UTF8DataInputJsonParser;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.JsonParseException;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.nio.charset.StandardCharsets;

public class UTF8DataInputJsonParser_nextToken_1_4_Test {

    // Feature Masks (Assumed values based on parser implementation)
    private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = 1 << 0;
    private static final int FEAT_MASK_NON_NUM_NUMBERS = 1 << 1;
    private static final int FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS = 1 << 2;
    private static final int FEAT_MASK_TRAILING_COMMA = 1 << 3;
    private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = 1 << 4;
    private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = 1 << 5;
    private static final int FEAT_MASK_ALLOW_MISSING = 1 << 6;

    @Test
    @DisplayName("nextToken() handles nested objects within arrays correctly")
    public void TC32_parse_nested_objects_within_arrays() throws Exception {
        // GIVEN
        String json = "[{\"key1\":1},{\"key2\":2}]";
        ByteArrayInputStream bais = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        DataInputStream dis = new DataInputStream(bais);
        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int features = 0; // Default settings
        ObjectCodec codec = null;
        int firstByte = dis.readUnsignedByte();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, features, dis, codec, sym, firstByte);

        // WHEN
        JsonToken firstStart = parser.nextToken(); // START_ARRAY
        JsonToken firstInnerStart = parser.nextToken(); // START_OBJECT
        JsonToken firstKey = parser.nextToken(); // FIELD_NAME 'key1'
        JsonToken firstValue = parser.nextToken(); // VALUE_NUMBER_INT 1
        JsonToken firstInnerEnd = parser.nextToken(); // END_OBJECT
        JsonToken secondInnerStart = parser.nextToken(); // START_OBJECT
        JsonToken secondKey = parser.nextToken(); // FIELD_NAME 'key2'
        JsonToken secondValue = parser.nextToken(); // VALUE_NUMBER_INT 2
        JsonToken secondInnerEnd = parser.nextToken(); // END_OBJECT
        JsonToken end = parser.nextToken(); // END_ARRAY

        // THEN
        assertEquals(JsonToken.START_ARRAY, firstStart);
        assertEquals(JsonToken.START_OBJECT, firstInnerStart);
        assertEquals(JsonToken.FIELD_NAME, firstKey);
        assertEquals("key1", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, firstValue);
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.END_OBJECT, firstInnerEnd);
        assertEquals(JsonToken.START_OBJECT, secondInnerStart);
        assertEquals(JsonToken.FIELD_NAME, secondKey);
        assertEquals("key2", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, secondValue);
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.END_OBJECT, secondInnerEnd);
        assertEquals(JsonToken.END_ARRAY, end);
    }

    @Test
    @DisplayName("nextToken() handles invalid starting character by throwing exception")
    public void TC33_parse_invalid_starting_character_throws_exception() throws Exception {
        // GIVEN
        String json = "@";
        ByteArrayInputStream bais = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        DataInputStream dis = new DataInputStream(bais);
        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int features = 0; // Default settings
        ObjectCodec codec = null;
        int firstByte = dis.readUnsignedByte();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, features, dis, codec, sym, firstByte);

        // WHEN & THEN
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        });
        assertTrue(exception.getMessage().contains("expected a value"));
    }

    @Test
    @DisplayName("nextToken() handles single quotes for field names when ALLOW_SINGLE_QUOTES is enabled")
    public void TC34_parse_field_name_with_single_quotes() throws Exception {
        // GIVEN
        String json = "{'name':'John'}";
        ByteArrayInputStream bais = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        DataInputStream dis = new DataInputStream(bais);
        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int features = FEAT_MASK_ALLOW_SINGLE_QUOTES; // Enable ALLOW_SINGLE_QUOTES
        ObjectCodec codec = null;
        int firstByte = dis.readUnsignedByte();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, features, dis, codec, sym, firstByte);

        // WHEN
        JsonToken fieldNameToken = parser.nextToken(); // START_OBJECT
        fieldNameToken = parser.nextToken(); // FIELD_NAME 'name'
        String fieldName = parser.getCurrentName();
        JsonToken valueToken = parser.nextToken(); // VALUE_STRING 'John'

        // THEN
        assertEquals(JsonToken.FIELD_NAME, fieldNameToken);
        assertEquals("name", fieldName);
        assertEquals(JsonToken.VALUE_STRING, valueToken);
        assertEquals("John", parser.getText());
    }

    @Test
    @DisplayName("nextToken() throws exception when single quotes are used but ALLOW_SINGLE_QUOTES is disabled")
    public void TC35_parse_field_name_with_single_quotes_throws_exception() throws Exception {
        // GIVEN
        String json = "{'name':'John'}";
        ByteArrayInputStream bais = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        DataInputStream dis = new DataInputStream(bais);
        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int features = 0; // ALLOW_SINGLE_QUOTES is disabled
        ObjectCodec codec = null;
        int firstByte = dis.readUnsignedByte();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, features, dis, codec, sym, firstByte);

        // WHEN & THEN
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken(); // START_OBJECT
            parser.nextToken(); // Attempts to parse FIELD_NAME with single quotes
        });
        assertTrue(exception.getMessage().contains("was expecting double-quote"));
    }

    @Test
    @DisplayName("nextToken() handles strings with multiple escaped characters correctly")
    public void TC36_parse_string_with_multiple_escaped_characters() throws Exception {
        // GIVEN
        String json = "\"Line1\nLine2\tTabbed\"";
        ByteArrayInputStream bais = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        DataInputStream dis = new DataInputStream(bais);
        IOContext ctxt = new IOContext(null, null, false);
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
        int features = 0; // Default settings
        ObjectCodec codec = null;
        int firstByte = dis.readUnsignedByte();
        UTF8DataInputJsonParser parser = new UTF8DataInputJsonParser(ctxt, features, dis, codec, sym, firstByte);

        // WHEN
        JsonToken result = parser.nextToken(); // VALUE_STRING
        String text = parser.getText();

        // THEN
        assertEquals(JsonToken.VALUE_STRING, result);
        assertEquals("Line1\nLine2\tTabbed", text);
    }
}
