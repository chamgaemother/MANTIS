import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections4.KeyValue;
import org.apache.commons.collections4.map.DefaultMapEntry;
import org.apache.commons.collections4.keyvalue.DefaultKeyValue;
import org.junit.jupiter.api.Test;

public class MapUtilsTest {

    @Test
    void testPutAll_NullMap() {
        assertThrows(NullPointerException.class, () -> {
            MapUtils.putAll(null, new Object[] { "key", "value" });
        });
    }

    @Test
    void testPutAll_NullArray() {
        Map<String, String> map = new HashMap<>();
        map.put("existing", "data");
        MapUtils.putAll(map, null);
        assertEquals(1, map.size());
        assertEquals("data", map.get("existing"));
    }

    @Test
    void testPutAll_EmptyArray() {
        Map<String, String> map = new HashMap<>();
        map.put("existing", "data");
        MapUtils.putAll(map, new Object[] {});
        assertEquals(1, map.size());
        assertEquals("data", map.get("existing"));
    }

    @Test
    void testPutAll_MapEntryArray() {
        Map<String, String> map = new HashMap<>();
        Map.Entry<String, String> entry1 = new DefaultMapEntry<>("key1", "value1");
        Map.Entry<String, String> entry2 = new DefaultMapEntry<>("key2", "value2");
        Object[] array = new Object[] { entry1, entry2 };
        MapUtils.putAll(map, array);
        assertEquals(2, map.size());
        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testPutAll_MapEntryArray_WithNullEntry() {
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[] { new DefaultMapEntry<>("key1", "value1"), null };
        assertThrows(NullPointerException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_KeyValueArray() {
        Map<String, Integer> map = new HashMap<>();
        KeyValue<String, Integer> kv1 = new DefaultKeyValue<>("key1", 1);
        KeyValue<String, Integer> kv2 = new DefaultKeyValue<>("key2", 2);
        Object[] array = new Object[] { kv1, kv2 };
        MapUtils.putAll(map, array);
        assertEquals(2, map.size());
        assertEquals(Integer.valueOf(1), map.get("key1"));
        assertEquals(Integer.valueOf(2), map.get("key2"));
    }

    @Test
    void testPutAll_KeyValueArray_WithNullKeyValue() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[] { new DefaultKeyValue<>("key1", 1), null };
        assertThrows(NullPointerException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_SubArrayPairs() {
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[] {
                new Object[] { "key1", "value1" },
                new Object[] { "key2", "value2" }
        };
        MapUtils.putAll(map, array);
        assertEquals(2, map.size());
        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));
    }

    @Test
    void testPutAll_SubArray_WithInsufficientElements() {
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[] {
                new Object[] { "key1", "value1" },
                new Object[] { "key2" }
        };
        assertThrows(IllegalArgumentException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_SubArray_WithNullSubArray() {
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[] {
                new Object[] { "key1", "value1" },
                null
        };
        assertThrows(IllegalArgumentException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_SubArray_WithIncorrectTypes() {
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[] {
                new Object[] { "key1", "value1" },
                new Object[] { 2, "value2" }
        };
        assertThrows(ClassCastException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_AlternatingKeysAndValues_Even() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[] { "key1", 1, "key2", 2 };
        MapUtils.putAll(map, array);
        assertEquals(2, map.size());
        assertEquals(Integer.valueOf(1), map.get("key1"));
        assertEquals(Integer.valueOf(2), map.get("key2"));
    }

    @Test
    void testPutAll_AlternatingKeysAndValues_Odd() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[] { "key1", 1, "key2" };
        MapUtils.putAll(map, array);
        assertEquals(1, map.size());
        assertEquals(Integer.valueOf(1), map.get("key1"));
        assertFalse(map.containsKey("key2"));
    }

    @Test
    void testPutAll_AlternatingKeysAndValues_WithIncorrectTypes() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[] { "key1", 1, "key2", "two" };
        assertThrows(ClassCastException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_MapEntryArray_WithMixedTypes() {
        Map<String, String> map = new HashMap<>();
        Object[] array = new Object[] { new DefaultMapEntry<>("key1", "value1"), "invalid" };
        assertThrows(ClassCastException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_KeyValueArray_WithMixedTypes() {
        Map<String, Integer> map = new HashMap<>();
        Object[] array = new Object[] { new DefaultKeyValue<>("key1", 1), "invalid" };
        assertThrows(ClassCastException.class, () -> {
            MapUtils.putAll(map, array);
        });
    }

    @Test
    void testPutAll_SubArrayPairs_WithMixedTypes() {
        Map<String, Object> map = new HashMap<>();
        Object[] array = new Object[] {
                new Object[] { "key1", "value1" },
                new Object[] { "key2", 2 }
        };
        MapUtils.putAll(map, array);
        assertEquals(2, map.size());
        assertEquals("value1", map.get("key1"));
        assertEquals(2, map.get("key2"));
    }
}