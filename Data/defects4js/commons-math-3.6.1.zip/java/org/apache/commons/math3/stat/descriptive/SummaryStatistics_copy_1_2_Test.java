package org.apache.commons.math3.stat.descriptive;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.apache.commons.math3.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math3.stat.descriptive.summary.SumOfLogs;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class SummaryStatistics_copy_1_2_Test {

    @Test
    @DisplayName("copy copies sumLog when source.sumLog does not equal sumLogImpl")
    void TC19_copyCopiesSumLog_whenSumLogDoesNotEqualSumLogImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to access private fields
        Field sumLogField = SummaryStatistics.class.getDeclaredField("sumLog");
        Field sumLogImplField = SummaryStatistics.class.getDeclaredField("sumLogImpl");
        sumLogField.setAccessible(true);
        sumLogImplField.setAccessible(true);

        // Ensure source.sumLog does not equal source.sumLogImpl
        sumLogField.set(source, new SumOfLogs());
        sumLogImplField.set(source, new SumOfLogs());

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destSumLogField = SummaryStatistics.class.getDeclaredField("sumLog");
        destSumLogField.setAccessible(true);
        Object destSumLog = destSumLogField.get(dest);
        assertNotSame(source.getSumOfLogs(), destSumLog, "dest.sumLog should be a copy of source.sumLog");
    }

    @Test
    @DisplayName("copy assigns sumsq from sumsqImpl when source.sumsq equals sumsqImpl")
    void TC20_copyAssignsSumsqFromSumsqImpl_whenSumsqEqualsSumsqImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to access private fields
        Field sumsqField = SummaryStatistics.class.getDeclaredField("sumsq");
        Field sumsqImplField = SummaryStatistics.class.getDeclaredField("sumsqImpl");
        sumsqField.setAccessible(true);
        sumsqImplField.setAccessible(true);

        // Ensure source.sumsq equals source.sumsqImpl
        sumsqField.set(source, sumsqImplField.get(source));

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destSumsqField = SummaryStatistics.class.getDeclaredField("sumsq");
        destSumsqField.setAccessible(true);
        Object destSumsq = destSumsqField.get(dest);
        Object destSumsqImpl = sumsqImplField.get(dest);
        assertSame(destSumsqImpl, destSumsq, "dest.sumsq should be assigned from dest.sumsqImpl");
    }

    @Test
    @DisplayName("copy copies sumsq when source.sumsq does not equal sumsqImpl")
    void TC21_copyCopiesSumsq_whenSumsqDoesNotEqualSumsqImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to access private fields
        Field sumsqField = SummaryStatistics.class.getDeclaredField("sumsq");
        Field sumsqImplField = SummaryStatistics.class.getDeclaredField("sumsqImpl");
        sumsqField.setAccessible(true);
        sumsqImplField.setAccessible(true);

        // Ensure source.sumsq does not equal source.sumsqImpl
        sumsqField.set(source, new SumOfSquares());
        sumsqImplField.set(source, new SumOfSquares());

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destSumsqField = SummaryStatistics.class.getDeclaredField("sumsq");
        destSumsqField.setAccessible(true);
        Object destSumsq = destSumsqField.get(dest);
        assertNotSame(source.getSumsq(), destSumsq, "dest.sumsq should be a copy of source.sumsq");
    }
}