package org.apache.commons.compress.archivers.cpio;

import org.apache.commons.compress.utils.ArchiveUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class CpioArchiveInputStream_getNextCPIOEntry_0_1_Test {

    @Test
    @DisplayName("Stream is closed, throws IOException upon invoking ensureOpen")
    void testStreamClosedThrowsIOException() {
        CpioArchiveInputStream stream = new CpioArchiveInputStream(new ByteArrayInputStream(new byte[0]));
        try {
            stream.close();
            assertThrows(IOException.class, stream::getNextCPIOEntry);
        } catch (IOException e) {
            fail("Unexpected IOException in setup.");
        }
    }

    @Test
    @DisplayName("Entry already open, closeEntry is called to handle it")
    void testCloseExistingEntry() throws Exception {
        CpioArchiveInputStream stream = new CpioArchiveInputStream(new ByteArrayInputStream(new byte[0]));
        CpioArchiveEntry entry = new CpioArchiveEntry("dummy", 0, 0, 0, 0, 0); // Initialize CpioArchiveEntry with dummy values

        // Set private field 'entry' via reflection
        java.lang.reflect.Field entryField = CpioArchiveInputStream.class.getDeclaredField("entry");
        entryField.setAccessible(true);
        entryField.set(stream, entry);

        // This will internally invoke closeEntry
        stream.getNextCPIOEntry();

        // Check that entry was closed
        assertNull(stream.entry); // Access entry field to ensure its reset
    }

    @Test
    @DisplayName("Read Old Binary, magic number matches non-swapped format")
    void testReadOldBinaryNonSwapped() throws Exception {
        byte[] buffer = { (byte)0x71, (byte)0xc7, 0, 0, 0, 0 }; // Simulate reading known magic bytes for non-swapped format
        ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(bais);

        CpioArchiveEntry entry = stream.getNextCPIOEntry();
        assertNotNull(entry);
    }

    @Test
    @DisplayName("Read Old Binary, magic number matches swapped format")
    void testReadOldBinarySwapped() throws Exception {
        byte[] buffer = { (byte)0xc7, (byte)0x71, 0, 0, 0, 0 }; // Simulate reading swapped format
        ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(bais);

        CpioArchiveEntry entry = stream.getNextCPIOEntry();
        assertNotNull(entry);
    }

    @Test
    @DisplayName("Read New Format Entry, magic string matches MAGIC_NEW")
    void testReadNewEntry() throws Exception {
        byte[] buffer = ArchiveUtils.fromAsciiString("0000000000070701"); // Simulate reading MAGIC_NEW with correct length
        ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(bais);

        CpioArchiveEntry entry = stream.getNextCPIOEntry();
        assertNotNull(entry);
    }

}