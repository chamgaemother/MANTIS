import org.apache.commons.math3.util.KthSelector;
import org.apache.commons.math3.util.MedianOf3PivotingStrategy;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class KthSelectorTest {

    @Test
    void testSelectKthElementWithNoPivots() {
        KthSelector selector = new KthSelector(new MedianOf3PivotingStrategy());
        double[] work = {3.0, 1.0, 2.0};
        int[] pivotsHeap = null;
        int k = 1;
        assertEquals(2.0, selector.select(work, pivotsHeap, k));
    }

    @Test
    void testSelectKthElementWithPivots() {
        KthSelector selector = new KthSelector(new MedianOf3PivotingStrategy());
        double[] work = {3.0, 1.0, 2.0};
        int[] pivotsHeap = new int[5];
        int k = 1;
        assertEquals(2.0, selector.select(work, pivotsHeap, k));
    }

    @Test
    void testSelectFirstElement() {
        KthSelector selector = new KthSelector(new MedianOf3PivotingStrategy());
        double[] work = {10.0, 7.0, 3.0, 2.0, 5.0};
        int[] pivotsHeap = new int[10];
        int k = 0;
        assertEquals(2.0, selector.select(work, pivotsHeap, k));
    }

    @Test
    void testSelectLastElement() {
        KthSelector selector = new KthSelector(new MedianOf3PivotingStrategy());
        double[] work = {5.0, 7.0, 3.0, 9.0, 1.0, 4.0};
        int[] pivotsHeap = new int[5];
        int k = 5;
        assertEquals(9.0, selector.select(work, pivotsHeap, k));
    }

    @Test
    void testSelectMiddleElement() {
        KthSelector selector = new KthSelector(new MedianOf3PivotingStrategy());
        double[] work = {10.0, 5.0, 2.0, 6.0, 3.0, 4.0};
        int[] pivotsHeap = new int[7];
        int k = 3;
        assertEquals(5.0, selector.select(work, pivotsHeap, k));
    }

    @Test
    void testSelectWithEmptyArray() {
        KthSelector selector = new KthSelector(new MedianOf3PivotingStrategy());
        double[] work = {};
        int[] pivotsHeap = new int[5];
        int k = 0;
        assertThrows(IndexOutOfBoundsException.class, () -> selector.select(work, pivotsHeap, k));
    }

    @Test
    void testSelectWithSingleElementArray() {
        KthSelector selector = new KthSelector(new MedianOf3PivotingStrategy());
        double[] work = {1.0};
        int[] pivotsHeap = new int[3];
        int k = 0;
        assertEquals(1.0, selector.select(work, pivotsHeap, k));
    }
}