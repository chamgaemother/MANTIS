package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import org.apache.commons.collections4.map.Flat3Map;

public class Flat3Map_remove_0_3_Test {

    @Test
    @DisplayName("Remove key with matching hash but not equal to existing keys")
    public void TC11() throws Exception {
        Flat3Map<String, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key1, key2, key3
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "FB"); // hashCode 2236

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, "key2");

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, "key3");

        // Set value1, value2, value3
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, "value2");

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, "value3");

        String targetKey = "Ea"; // hashCode 2236, not equal to "FB"

        Object result = map.remove(targetKey);

        assertNull(result);
        
        // Verify size remains 3
        int size = sizeField.getInt(map);
        assertEquals(3, size);
    }

    @Test
    @DisplayName("Remove key when size is greater than 0 but delegateMap is null")
    public void TC12() throws Exception {
        Flat3Map<String, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Set key1 and value1
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, "key1");

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        value1Field.set(map, "value1");

        String nonExistentKey = "nonExistentKey";

        Object result = map.remove(nonExistentKey);

        assertNull(result);
        
        // Verify size remains 1
        int size = sizeField.getInt(map);
        assertEquals(1, size);
    }
}