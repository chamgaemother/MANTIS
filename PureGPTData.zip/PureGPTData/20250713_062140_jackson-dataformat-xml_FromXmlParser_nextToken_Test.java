import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.util.JacksonFeatureSet;
import com.fasterxml.jackson.dataformat.xml.XmlNameProcessor;
import com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser;
import com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext;
import com.fasterxml.jackson.dataformat.xml.deser.XmlTokenStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.xml.stream.XMLStreamReader;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FromXmlParserTest {

    private FromXmlParser parser;
    private IOContext mockIoContext;
    private XMLStreamReader mockXmlStreamReader;
    private XmlNameProcessor mockTagProcessor;
    private XmlTokenStream mockXmlTokens;

    @BeforeEach
    void setUp() throws IOException {
        mockIoContext = mock(IOContext.class);
        mockXmlStreamReader = mock(XMLStreamReader.class);
        mockTagProcessor = mock(XmlNameProcessor.class);
        mockXmlTokens = mock(XmlTokenStream.class);
        
        when(mockXmlTokens.initialize()).thenReturn(XmlTokenStream.XML_START_ELEMENT);
        parser = new FromXmlParser(
                mockIoContext,
                0,
                0,
                null,
                mockXmlStreamReader,
                mockTagProcessor
                ) {
            @Override
            protected int _nextToken() throws IOException { return mockXmlTokens.next(); }
            @Override
            protected void _skipEndElement() throws IOException { mockXmlTokens.skipEndElement(); }
        };
    }

    @Test
    void testStartElementToken() throws IOException {
        when(mockXmlTokens.next()).thenReturn(XmlTokenStream.XML_START_ELEMENT);
        JsonToken result = parser.nextToken();
        assertEquals(JsonToken.START_OBJECT, result);
        
        verify(mockXmlTokens, atLeastOnce()).next();
    }

    @Test
    void testEndElementTokenInArrayAsLeaf() throws IOException {
        when(mockXmlTokens.next()).thenReturn(XmlTokenStream.XML_END_ELEMENT);
        parser._parsingContext = mock(XmlReadContext.class);
        when(parser._parsingContext.inArray()).thenReturn(true);
        
        JsonToken result = parser.nextToken();
        assertEquals(JsonToken.VALUE_NULL, result);
    }

    @Test
    void testEndElementTokenNotLeaf() throws IOException {
        when(mockXmlTokens.next()).thenReturn(XmlTokenStream.XML_END_ELEMENT);
        parser._parsingContext = mock(XmlReadContext.class);
        when(parser._parsingContext.inArray()).thenReturn(false);
        when(parser._parsingContext.inRoot()).thenReturn(false);

        JsonToken result = parser.nextToken();
        assertEquals(JsonToken.END_OBJECT, result);
    }
    
    @Test
    void testAttributeNameTokenAsLeaf() throws IOException {
        when(mockXmlTokens.next()).thenReturn(XmlTokenStream.XML_ATTRIBUTE_NAME);
        parser._mayBeLeaf = true;

        JsonToken result = parser.nextToken();
        assertEquals(JsonToken.START_OBJECT, result);
    }

    @Test
    void testAttributeValueToken() throws IOException {
        when(mockXmlTokens.next()).thenReturn(XmlTokenStream.XML_ATTRIBUTE_VALUE);
        JsonToken result = parser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, result);
    }

    @Test
    void testTextTokenNotLeaf() throws IOException {
        when(mockXmlTokens.next()).thenReturn(XmlTokenStream.XML_TEXT);
        when(mockXmlTokens.getText()).thenReturn("");
        parser._parsingContext = spy(new XmlReadContext(null, null, null, null, 0, 0));
        parser._parsingContext.setAsArray();

        JsonToken result = parser.nextToken();
        assertNull(result);
    }

    @Test
    void testEndOfStreamToken() throws IOException {
        when(mockXmlTokens.next()).thenReturn(XmlTokenStream.XML_END);
        JsonToken result = parser.nextToken();
        assertNull(result);
    }
    
    @Test
    void testUnexpectedTokenCallsInternalError() throws IOException {
        when(mockXmlTokens.next()).thenReturn(-999); // some unexpected token
        assertThrows(IllegalStateException.class, () -> parser.nextToken());
    }
}