package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.event.ActionEvent;
import java.awt.geom.Point2D;
import java.lang.reflect.Field;

public class ChartPanel_actionPerformed_0_4_Test {

    // Subclass to track method invocations
    private class TestChartPanel extends ChartPanel {
        boolean zoomOutDomainCalled = false;
        boolean zoomOutRangeCalled = false;
        boolean restoreAutoBoundsCalled = false;

        public TestChartPanel() {
            super(null); // Assuming a constructor that accepts a Chart object
        }

        @Override
        public void zoomOutDomain(double x, double y) {
            zoomOutDomainCalled = true;
            super.zoomOutDomain(x, y);
        }

        @Override
        public void zoomOutRange(double x, double y) {
            zoomOutRangeCalled = true;
            super.zoomOutRange(x, y);
        }

        @Override
        public void restoreAutoBounds() {
            restoreAutoBoundsCalled = true;
            super.restoreAutoBounds();
        }
    }

    @Test
    @DisplayName("actionPerformed with command 'ZOOM_OUT_DOMAIN' and zoomPoint is non-null")
    void TC16() throws Exception {
        TestChartPanel chartPanel = new TestChartPanel();

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(chartPanel, new Point2D.Double(150.0, 250.0));

        // Create ActionEvent with command 'ZOOM_OUT_DOMAIN'
        ActionEvent event = new ActionEvent(chartPanel, ActionEvent.ACTION_PERFORMED, "ZOOM_OUT_DOMAIN");

        // Call actionPerformed
        chartPanel.actionPerformed(event);

        // Assert that zoomOutDomain was called
        assertTrue(chartPanel.zoomOutDomainCalled, "zoomOutDomain should be invoked");
    }

    @Test
    @DisplayName("actionPerformed with command 'ZOOM_OUT_RANGE' and zoomPoint is null")
    void TC17() throws Exception {
        TestChartPanel chartPanel = new TestChartPanel();

        // Ensure zoomPoint is null via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(chartPanel, null);

        // Create ActionEvent with command 'ZOOM_OUT_RANGE'
        ActionEvent event = new ActionEvent(chartPanel, ActionEvent.ACTION_PERFORMED, "ZOOM_OUT_RANGE");

        // Call actionPerformed
        chartPanel.actionPerformed(event);

        // Assert that zoomOutRange was called
        assertTrue(chartPanel.zoomOutRangeCalled, "zoomOutRange should be invoked");
    }

    @Test
    @DisplayName("actionPerformed with command 'ZOOM_RESET_BOTH' and zoomPoint is non-null")
    void TC18() throws Exception {
        TestChartPanel chartPanel = new TestChartPanel();

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(chartPanel, new Point2D.Double(200.0, 300.0));

        // Create ActionEvent with command 'ZOOM_RESET_BOTH'
        ActionEvent event = new ActionEvent(chartPanel, ActionEvent.ACTION_PERFORMED, "ZOOM_RESET_BOTH");

        // Call actionPerformed
        chartPanel.actionPerformed(event);

        // Assert that restoreAutoBounds was called
        assertTrue(chartPanel.restoreAutoBoundsCalled, "restoreAutoBounds should be invoked");
    }
}