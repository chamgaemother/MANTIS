import com.fasterxml.jackson.core.format.InputAccessor;
import com.fasterxml.jackson.core.format.MatchStrength;
import com.fasterxml.jackson.dataformat.xml.XmlFactory;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class XmlFactoryTest {

    @Test
    public void testEmptyInput() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(false);

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void testUtf8BomStart() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, true, true, true, false);
        when(accessor.nextByte()).thenReturn((byte) 0xEF, (byte) 0xBB, (byte) 0xBF, (byte) '<');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void testSingleLessThan() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, false);
        when(accessor.nextByte()).thenReturn((byte) '<');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void testSpaceFollowedByLessThan() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, true, false);
        when(accessor.nextByte()).thenReturn((byte) ' ', (byte) '<');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void testXmlDeclaration() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, true, true, true, false);
        when(accessor.nextByte()).thenReturn((byte) '<', (byte) '?', (byte) 'x', (byte) 'm', (byte) 'l');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.FULL_MATCH, strength);
    }

    @Test
    public void testXmlRootStart() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, false);
        when(accessor.nextByte()).thenReturn((byte) '<', (byte) 'r');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void testExclNotCommentOrDoctype() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, false);
        when(accessor.nextByte()).thenReturn((byte) '<', (byte) '!');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void testExclComment() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, true, false);
        when(accessor.nextByte()).thenReturn((byte) '<', (byte) '!', (byte) '-');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.INCONCLUSIVE, strength);
    }

    @Test
    public void testExclDocType() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, true, true, true, false);
        when(accessor.nextByte()).thenReturn((byte) '<', (byte) '!', (byte) 'D', (byte) 'O', (byte) 'C', (byte) 'T');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.SOLID_MATCH, strength);
    }

    @Test
    public void testInvalidCharacterAfterExclamation() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, true, false);
        when(accessor.nextByte()).thenReturn((byte) '<', (byte) '!', (byte) 'A');

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }

    @Test
    public void testInvalidByteArrayUtf8Bom() throws IOException {
        InputAccessor accessor = Mockito.mock(InputAccessor.class);
        when(accessor.hasMoreBytes()).thenReturn(true, true, true, false);
        when(accessor.nextByte()).thenReturn((byte) 0xEF, (byte) 0xBB, (byte) 0x00);

        MatchStrength strength = XmlFactory.hasXMLFormat(accessor);
        assertEquals(MatchStrength.NO_MATCH, strength);
    }
}