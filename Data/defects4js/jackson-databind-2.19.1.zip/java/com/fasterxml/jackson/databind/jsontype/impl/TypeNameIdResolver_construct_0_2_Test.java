package com.fasterxml.jackson.databind.jsontype.impl;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TypeNameIdResolver_construct_0_2_Test {

    // Example classes for testing
    static class ExampleClass {}
    static class ParentClass {}
    static class ChildClass extends ParentClass {}

    @Test
    @DisplayName("Construct with forSer=false, forDeser=true and null subtypes")
    void test_TC06() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        JavaType baseType = mock(JavaType.class);
        Collection<NamedType> subtypes = null;
        boolean forSer = false;
        boolean forDeser = true;

        // WHEN
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // THEN
        // Using reflection to access private fields
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        Map<String, JavaType> idToType = (Map<String, JavaType>) idToTypeField.get(resolver);

        // Assert typeToId is initialized with initial capacity 4 and empty
        assertNotNull(typeToId, "typeToId should be initialized");
        assertTrue(typeToId.isEmpty(), "typeToId should be empty");

        // Assert idToType is initialized and empty
        assertNotNull(idToType, "idToType should be initialized");
        assertTrue(idToType.isEmpty(), "idToType should be empty");
    }

    @Test
    @DisplayName("Construct with forSer=false, forDeser=true and empty subtypes collection")
    void test_TC07() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        JavaType baseType = mock(JavaType.class);
        Collection<NamedType> subtypes = new ArrayList<>();
        boolean forSer = false;
        boolean forDeser = true;

        // WHEN
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // THEN
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        Map<String, JavaType> idToType = (Map<String, JavaType>) idToTypeField.get(resolver);

        // Assert typeToId is initialized with capacity 4 and empty
        assertNotNull(typeToId, "typeToId should be initialized");
        assertTrue(typeToId.isEmpty(), "typeToId should be empty");

        // Assert idToType is initialized and empty
        assertNotNull(idToType, "idToType should be initialized");
        assertTrue(idToType.isEmpty(), "idToType should be empty");
    }

    @Test
    @DisplayName("Construct with forSer=false, forDeser=true, one subtype with a defined name and caseInsensitive=false")
    void test_TC08() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        when(config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES)).thenReturn(false);
        JavaType baseType = mock(JavaType.class);
        NamedType subtype = new NamedType(ExampleClass.class, "ExampleName");
        Collection<NamedType> subtypes = Arrays.asList(subtype);
        boolean forSer = false;
        boolean forDeser = true;

        // Mock behavior for config.constructType
        JavaType exampleJavaType = mock(JavaType.class);
        when(config.constructType(ExampleClass.class)).thenReturn(exampleJavaType);

        // WHEN
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // THEN
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        Map<String, JavaType> idToType = (Map<String, JavaType>) idToTypeField.get(resolver);

        // Assert typeToId has the class name mapped to the defined id
        assertNotNull(typeToId, "typeToId should be initialized");
        assertTrue(typeToId.containsKey(ExampleClass.class.getName()), "typeToId should contain the class name as key");
        assertEquals("ExampleName", typeToId.get(ExampleClass.class.getName()), "typeToId should map to 'ExampleName'");

        // Assert idToType is initialized and contains the mapping
        assertNotNull(idToType, "idToType should be initialized");
        assertTrue(idToType.containsKey("ExampleName"), "idToType should contain 'ExampleName' as key");
        assertEquals(exampleJavaType, idToType.get("ExampleName"), "idToType should map 'ExampleName' to the corresponding JavaType");
    }

    @Test
    @DisplayName("Construct with forSer=false, forDeser=true, one subtype with a defined name and caseInsensitive=true")
    void test_TC09() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        when(config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES)).thenReturn(true);
        JavaType baseType = mock(JavaType.class);
        NamedType subtype = new NamedType(ExampleClass.class, "ExampleName");
        Collection<NamedType> subtypes = Arrays.asList(subtype);
        boolean forSer = false;
        boolean forDeser = true;

        // Mock behavior for config.constructType
        JavaType exampleJavaType = mock(JavaType.class);
        when(config.constructType(ExampleClass.class)).thenReturn(exampleJavaType);

        // WHEN
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // THEN
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        Map<String, JavaType> idToType = (Map<String, JavaType>) idToTypeField.get(resolver);

        // Assert typeToId is initialized with the class name mapped to the defined id
        assertNotNull(typeToId, "typeToId should be initialized");
        assertTrue(typeToId.containsKey(ExampleClass.class.getName()), "typeToId should contain the class name as key");
        assertEquals("ExampleName", typeToId.get(ExampleClass.class.getName()), "typeToId should map to 'ExampleName'");

        // Assert idToType contains the lowercase id and JavaType
        assertNotNull(idToType, "idToType should be initialized");
        assertTrue(idToType.containsKey("examplename"), "idToType should contain 'examplename' as key");
        assertEquals(exampleJavaType, idToType.get("examplename"), "idToType should map 'examplename' to the corresponding JavaType");
    }

    @Test
    @DisplayName("Construct with multiple subtypes having conflicting names and caseInsensitive=true")
    void test_TC10() throws Exception {
        // GIVEN
        MapperConfig<?> config = mock(MapperConfig.class);
        when(config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES)).thenReturn(true);
        JavaType baseType = mock(JavaType.class);
        NamedType subtype1 = new NamedType(ParentClass.class, "TypeName");
        NamedType subtype2 = new NamedType(ChildClass.class, "typename");
        Collection<NamedType> subtypes = Arrays.asList(subtype1, subtype2);
        boolean forSer = false;
        boolean forDeser = true;

        // Mock behavior for config.constructType
        JavaType childJavaType = mock(JavaType.class);
        when(config.constructType(ChildClass.class)).thenReturn(childJavaType);

        // WHEN
        TypeNameIdResolver resolver = TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);

        // THEN
        Field typeToIdField = TypeNameIdResolver.class.getDeclaredField("_typeToId");
        typeToIdField.setAccessible(true);
        ConcurrentHashMap<String, String> typeToId = (ConcurrentHashMap<String, String>) typeToIdField.get(resolver);

        Field idToTypeField = TypeNameIdResolver.class.getDeclaredField("_idToType");
        idToTypeField.setAccessible(true);
        Map<String, JavaType> idToType = (Map<String, JavaType>) idToTypeField.get(resolver);

        // Assert typeToId is initialized and contains both class names mapped to their ids
        assertNotNull(typeToId, "typeToId should be initialized");
        assertTrue(typeToId.containsKey(ParentClass.class.getName()), "typeToId should contain ParentClass name as key");
        assertTrue(typeToId.containsKey(ChildClass.class.getName()), "typeToId should contain ChildClass name as key");

        // Assert idToType contains 'typename' mapped to the ChildClass's JavaType
        assertNotNull(idToType, "idToType should be initialized");
        assertTrue(idToType.containsKey("typename"), "idToType should contain 'typename' as key");
        assertEquals(childJavaType, idToType.get("typename"), "idToType should map 'typename' to ChildClass's JavaType");
    }
}