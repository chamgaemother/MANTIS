package org.jfree.chart.renderer.category;
import org.jfree.chart.ui.RectangleEdge;

import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.renderer.Outlier;
import org.jfree.chart.renderer.OutlierList;
import org.jfree.chart.renderer.OutlierListCollection;

// The test class to ensure drawHorizontalItem method functionality.
public class BoxAndWhiskerRenderer_drawHorizontalItem_0_4_Test {

    private BoxAndWhiskerRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private BoxAndWhiskerCategoryDataset dataset;

    @BeforeEach
    void setUp() {
        renderer = new BoxAndWhiskerRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(BoxAndWhiskerCategoryDataset.class);
    }

    @Test
    @DisplayName("Handles medianVisible=true with null median value")
    void TC16_medianVisible_true_nullMedian() throws Exception {
        // Arrange
        renderer.setMedianVisible(true);

        when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(null);

        // Act
        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 4, 2);
        });

        // Assert
        verify(g2, never()).draw(argThat(shape -> shape instanceof Line2D &&
            ((Line2D) shape).getY1() == ((Line2D) shape).getY2()));
    }

    @Test
    @DisplayName("Handles medianVisible=false ensuring median is not drawn")
    void TC17_medianVisible_false_noMedianDrawn() throws Exception {
        // Arrange
        renderer.setMedianVisible(false);

        when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(5.0);

        // Act
        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 4, 3);
        });

        // Assert
        verify(g2, never()).draw(argThat(shape -> shape instanceof Line2D &&
            ((Line2D) shape).getY1() == ((Line2D) shape).getY2()));
    }

    @Test
    @DisplayName("Handles null artifactPaint without affecting other drawings")
    void TC18_null_artifactPaint() throws Exception {
        // Arrange
        renderer.setArtifactPaint(mock(Paint.class));
        renderer.setMeanVisible(true);

        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(5.0);

        // Act
        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 5, 1);
        });

        // Assert
        verify(g2, never()).fill(argThat(shape -> shape instanceof java.awt.geom.Ellipse2D));
        verify(g2, never()).draw(argThat(shape -> shape instanceof java.awt.geom.Ellipse2D));

        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).setStroke(any(Stroke.class));
        verify(g2, atLeastOnce()).draw(any(java.awt.Shape.class));
    }

    @Test
    @DisplayName("Handles entityCollection being null gracefully")
    void TC19_null_entityCollection() throws Exception {
        // Arrange
        renderer.setMeanVisible(true);
        renderer.setMedianVisible(true);

        when(state.getEntityCollection()).thenReturn(null);
        when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
        when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(5.0);

        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 6, 1);
        });

        verify(state, never()).getEntityCollection();
    }

//     @Test
//     @DisplayName("Handles addItemEntity with valid entityCollection and box not null")
//     void TC20_addItemEntity_valid_entityCollection() throws Exception {
        // Arrange
//         renderer.setMeanVisible(true);
//         renderer.setMedianVisible(true);
// 
//         EntityCollection entities = mock(EntityCollection.class);
//         when(state.getEntityCollection()).thenReturn(entities);
// 
//         when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(dataset.getMedianValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(dataset.getQ1Value(anyInt(), anyInt())).thenReturn(2.0);
//         when(dataset.getQ3Value(anyInt(), anyInt())).thenReturn(8.0);
//         when(dataset.getMaxRegularValue(anyInt(), anyInt())).thenReturn(12.0);
//         when(dataset.getMinRegularValue(anyInt(), anyInt())).thenReturn(1.0);
// 
        // Act
//         assertDoesNotThrow(() -> {
//             renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 7, 1);
//         });
// 
//         verify(state, atLeastOnce()).addItemEntity(eq(entities), eq(dataset), eq(7), eq(1), any(java.awt.Shape.class));
//     }
}