package com.fasterxml.jackson.core.io;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.OutputStream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class UTF8Writer_write_1_2_Test {

    @Test
    @DisplayName("write with len=5 containing mixed ASCII and multi-byte characters")
    public void TC10_write_mixed_ascii_multibyte() throws IOException {
        // GIVEN
        char[] cbuf = { 'A', '\u00A2', '\u00E9', '\uD83D', '\uDE00' }; // 'A', Â¢, Ã©, surrogate pair
        int off = 0;
        int len = 5;
        
        OutputStream mockOut = mock(OutputStream.class);
        IOContext mockContext = mock(IOContext.class);
        when(mockContext.allocWriteEncodingBuffer()).thenReturn(new byte[13]);
        
        UTF8Writer writer = new UTF8Writer(mockContext, mockOut);
        
        // WHEN
        writer.write(cbuf, off, len);
        
        // THEN
        verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(9));
    }
}