package org.jfree.chart;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.lang.reflect.Field;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.plot.Pannable;
import org.jfree.chart.plot.Plot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class ChartPanel_mousePressed_2_1_Test {

//     @Test
//     @DisplayName("TC21: mousePressed does not initiate panning when panMask is matched, plot is Pannable, but getScreenDataArea returns null")
//     void testMousePressed_PanMaskMatched_PannablePlot_ScreenDataAreaNull() throws Exception {
        // Arrange
//         ChartPanel chartPanel = new ChartPanel(null);
// 
        // Mock JFreeChart and Plot
//         JFreeChart mockChart = mock(JFreeChart.class);
//         Plot mockPlot = mock(Pannable.class);
//         when(mockChart.getPlot()).thenReturn(mockPlot);
//         when(((Pannable) mockPlot).isDomainPannable()).thenReturn(true);
//         when(((Pannable) mockPlot).isRangePannable()).thenReturn(false);
// 
        // Set the chart using reflection
//         Field chartField = ChartPanel.class.getDeclaredField("chart");
//         chartField.setAccessible(true);
//         chartField.set(chartPanel, mockChart);
// 
        // Set panMask using reflection (e.g., CTRL_MASK)
//         Field panMaskField = ChartPanel.class.getDeclaredField("panMask");
//         panMaskField.setAccessible(true);
//         panMaskField.setInt(chartPanel, java.awt.event.InputEvent.CTRL_MASK);
// 
        // Mock getScreenDataArea to return null
//         ChartPanel spyChartPanel = Mockito.spy(chartPanel);
//         doReturn(null).when(spyChartPanel).getScreenDataArea(anyInt(), anyInt());
// 
        // Create a MouseEvent with panMask matched
//         MouseEvent mockEvent = mock(MouseEvent.class);
//         when(mockEvent.getModifiers()).thenReturn(java.awt.event.InputEvent.CTRL_MASK);
//         when(mockEvent.getX()).thenReturn(100);
//         when(mockEvent.getY()).thenReturn(100);
//         when(mockEvent.getPoint()).thenReturn(new Point(100, 100));
//         when(mockEvent.isPopupTrigger()).thenReturn(false);
// 
        // Act
//         spyChartPanel.mousePressed(mockEvent);
// 
        // Assert
        // Verify that panW and panH are not set (remain 0.0)
//         Field panWField = ChartPanel.class.getDeclaredField("panW");
//         panWField.setAccessible(true);
//         double panW = panWField.getDouble(spyChartPanel);
//         assertEquals(0.0, panW, "panW should not be set.");
// 
//         Field panHField = ChartPanel.class.getDeclaredField("panH");
//         panHField.setAccessible(true);
//         double panH = panHField.getDouble(spyChartPanel);
//         assertEquals(0.0, panH, "panH should not be set.");
// 
        // Verify that panLast is not set (remains null)
//         Field panLastField = ChartPanel.class.getDeclaredField("panLast");
//         panLastField.setAccessible(true);
//         Object panLast = panLastField.get(spyChartPanel);
//         assertNull(panLast, "panLast should not be set.");
// 
        // Verify that cursor remains default
//         Field cursorField = java.awt.Component.class.getDeclaredField("cursor");
//         cursorField.setAccessible(true);
//         Cursor currentCursor = (Cursor) cursorField.get(spyChartPanel);
//         assertEquals(Cursor.getDefaultCursor(), currentCursor, "Cursor should remain default.");
//     }

//     @Test
//     @DisplayName("TC22: mousePressed does not initiate panning when panMask is matched, plot is Pannable, but screenDataArea does not contain the mouse point")
//     void testMousePressed_PanMaskMatched_PannablePlot_ScreenDataAreaDoesNotContainPoint() throws Exception {
        // Arrange
//         ChartPanel chartPanel = new ChartPanel(null);
// 
        // Mock JFreeChart and Plot
//         JFreeChart mockChart = mock(JFreeChart.class);
//         Plot mockPlot = mock(Pannable.class);
//         when(mockChart.getPlot()).thenReturn(mockPlot);
//         when(((Pannable) mockPlot).isDomainPannable()).thenReturn(true);
//         when(((Pannable) mockPlot).isRangePannable()).thenReturn(true);
// 
        // Set the chart using reflection
//         Field chartField = ChartPanel.class.getDeclaredField("chart");
//         chartField.setAccessible(true);
//         chartField.set(chartPanel, mockChart);
// 
        // Set panMask using reflection (e.g., CTRL_MASK)
//         Field panMaskField = ChartPanel.class.getDeclaredField("panMask");
//         panMaskField.setAccessible(true);
//         panMaskField.setInt(chartPanel, java.awt.event.InputEvent.CTRL_MASK);
// 
        // Mock getScreenDataArea to return a Rectangle that does not contain the point
//         Rectangle2D mockDataArea = new Rectangle2D.Double(0, 0, 50, 50);
//         ChartPanel spyChartPanel = Mockito.spy(chartPanel);
//         doReturn(mockDataArea).when(spyChartPanel).getScreenDataArea(anyInt(), anyInt());
// 
        // Create a MouseEvent with panMask matched
//         MouseEvent mockEvent = mock(MouseEvent.class);
//         when(mockEvent.getModifiers()).thenReturn(java.awt.event.InputEvent.CTRL_MASK);
//         when(mockEvent.getX()).thenReturn(100);
//         when(mockEvent.getY()).thenReturn(100);
//         when(mockEvent.getPoint()).thenReturn(new Point(100, 100));
//         when(mockEvent.isPopupTrigger()).thenReturn(false);
// 
        // Act
//         spyChartPanel.mousePressed(mockEvent);
// 
        // Assert
        // Verify that panW and panH are not set (remain 0.0)
//         Field panWField = ChartPanel.class.getDeclaredField("panW");
//         panWField.setAccessible(true);
//         double panW = panWField.getDouble(spyChartPanel);
//         assertEquals(0.0, panW, "panW should not be set.");
// 
//         Field panHField = ChartPanel.class.getDeclaredField("panH");
//         panHField.setAccessible(true);
//         double panH = panHField.getDouble(spyChartPanel);
//         assertEquals(0.0, panH, "panH should not be set.");
// 
        // Verify that panLast is not set (remains null)
//         Field panLastField = ChartPanel.class.getDeclaredField("panLast");
//         panLastField.setAccessible(true);
//         Object panLast = panLastField.get(spyChartPanel);
//         assertNull(panLast, "panLast should not be set.");
// 
        // Verify that cursor remains default
//         Field cursorField = java.awt.Component.class.getDeclaredField("cursor");
//         cursorField.setAccessible(true);
//         Cursor currentCursor = (Cursor) cursorField.get(spyChartPanel);
//         assertEquals(Cursor.getDefaultCursor(), currentCursor, "Cursor should remain default.");
//     }
}