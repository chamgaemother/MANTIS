package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.util.FastMath;

public class FastMath_pow_0_2_Test {

    @Test
    @DisplayName("pow(-1.0, y) returns 1.0 when y is a large even integer")
    void pow_negative_one_large_even_integer() {
        // GIVEN
        double x = -1.0;
        double y = 1e20;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertEquals(1.0, result);
    }

    @Test
    @DisplayName("pow(-1.0, y) returns NaN when y is infinite")
    void pow_negative_one_y_infinite() {
        // GIVEN
        double x = -1.0;
        double y = Double.POSITIVE_INFINITY;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertTrue(Double.isNaN(result));
    }

    @Test
    @DisplayName("pow(x, y) returns POSITIVE_INFINITY when y is +infinity and |x| > 1")
    void pow_y_positive_infinite_x_greater_than_one() {
        // GIVEN
        double x = 2.0;
        double y = Double.POSITIVE_INFINITY;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result);
    }

    @Test
    @DisplayName("pow(x, y) returns +0.0 when y is +infinity and |x| < 1")
    void pow_y_positive_infinite_x_less_than_one() {
        // GIVEN
        double x = 0.5;
        double y = Double.POSITIVE_INFINITY;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertEquals(+0.0, result);
    }

    @Test
    @DisplayName("pow(x, y) returns +0.0 when y is -infinity and |x| > 1")
    void pow_y_negative_infinite_x_greater_than_one() {
        // GIVEN
        double x = 3.0;
        double y = Double.NEGATIVE_INFINITY;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertEquals(+0.0, result);
    }
}