package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ConversionTest {

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should throw NullPointerException when src is null")
    void testBinaryBeMsb0ToHexDigit_NullSrc() {
        assertThrows(NullPointerException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(null, 0);
        });
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should throw IllegalArgumentException when src is empty")
    void testBinaryBeMsb0ToHexDigit_EmptySrc() {
        boolean[] src = {};
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(src, 0);
        });
        assertEquals("Cannot convert an empty array.", exception.getMessage());
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should throw IndexOutOfBoundsException when srcPos is out of bounds")
    void testBinaryBeMsb0ToHexDigit_SrcPosOutOfBounds() {
        boolean[] src = {true, false, true};
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(src, 5);
        });
        assertEquals("5 is not within array length 3", exception.getMessage());
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return correct hex digit for pos >= 3 and src[pos-3] is true")
    void testBinaryBeMsb0ToHexDigit_PosGreaterOrEqual3_SrcPosMinus3True() {
        boolean[] src = {true, true, true, true};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('f', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return 'e' when src[pos] is false")
    void testBinaryBeMsb0ToHexDigit_ReturnE() {
        boolean[] src = {true, true, true, false};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('e', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return 'd' when src[pos-1] is false and src[pos] is true")
    void testBinaryBeMsb0ToHexDigit_ReturnD() {
        boolean[] src = {true, true, false, true};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('d', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return 'c' when src[pos-1] is false and src[pos] is false")
    void testBinaryBeMsb0ToHexDigit_ReturnC() {
        boolean[] src = {false, true, false, true};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('c', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return 'b' when src[pos-2] is false and src[pos-1] is true")
    void testBinaryBeMsb0ToHexDigit_ReturnB() {
        boolean[] src = {true, true, false, false};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('b', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return 'a' when src[pos-2] is false and src[pos-1] is false and src[pos] is true")
    void testBinaryBeMsb0ToHexDigit_ReturnA() {
        boolean[] src = {true, false, false, false};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('a', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return '9' when src[pos-2] is false and src[pos-1] is false and src[pos] is false")
    void testBinaryBeMsb0ToHexDigit_Return9() {
        boolean[] src = {false, false, false, false};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('8', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should handle srcPos correctly")
    void testBinaryBeMsb0ToHexDigit_SrcPos() {
        boolean[] src = {false, true, false, true, true, true, true};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 2);
        assertEquals('c', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return '7' when pos >=3 and specific bits are set")
    void testBinaryBeMsb0ToHexDigit_Return7() {
        boolean[] src = {false, false, false, true};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('9', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return correct hex digit for pos < 3")
    void testBinaryBeMsb0ToHexDigit_PosLessThan3() {
        boolean[] src = {true, false};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('1', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should return '0' when all relevant bits are false")
    void testBinaryBeMsb0ToHexDigit_AllFalse() {
        boolean[] src = {false, false, false, false};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 0);
        assertEquals('0', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should handle maximum srcPos")
    void testBinaryBeMsb0ToHexDigit_MaxSrcPos() {
        boolean[] src = {true, false, true, true, true};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 4);
        assertEquals('1', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should handle overlapping positions correctly")
    void testBinaryBeMsb0ToHexDigit_OverlappingPositions() {
        boolean[] src = {true, true, true, true, true, true, true, true};
        char result = Conversion.binaryBeMsb0ToHexDigit(src, 4);
        assertEquals('f', result);
    }

    @Test
    @DisplayName("binaryBeMsb0ToHexDigit should throw IndexOutOfBoundsException when srcPos negative")
    void testBinaryBeMsb0ToHexDigit_NegativeSrcPos() {
        boolean[] src = {true, true, true};
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            Conversion.binaryBeMsb0ToHexDigit(src, -1);
        });
        assertEquals("-1 is not within array length 3", exception.getMessage());
    }
}