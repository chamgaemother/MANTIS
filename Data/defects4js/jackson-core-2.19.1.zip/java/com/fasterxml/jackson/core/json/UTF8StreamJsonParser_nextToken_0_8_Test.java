package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

public class UTF8StreamJsonParser_nextToken_0_8_Test {

    @Test
    @DisplayName("nextToken processes empty string input correctly")
    public void TC36() throws Exception {
        // Initialize parser with empty input
        String input = "";
        ByteArrayInputStream bais = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
        JsonFactory jsonFactory = new JsonFactory();
        JsonParser parser = jsonFactory.createParser(bais);

        try {
            // Call nextToken
            JsonToken result = parser.nextToken();

            // Verify result is VALUE_NULL
            Assertions.assertEquals(JsonToken.VALUE_NULL, result, "Parser should return VALUE_NULL after closing on empty input");
        } finally {
            parser.close();
        }
    }

    @Test
    @DisplayName("nextToken handles escaped characters within a string")
    public void TC37() throws Exception {
        // Initialize parser with input containing escaped characters within a string
        String input = "{\"key\": \"value\\n\"}";
        ByteArrayInputStream bais = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
        JsonFactory jsonFactory = new JsonFactory();
        JsonParser parser = jsonFactory.createParser(bais);

        try {
            // Call nextToken to move to FIELD_NAME
            JsonToken token = parser.nextToken();
            Assertions.assertEquals(JsonToken.FIELD_NAME, token, "First token should be FIELD_NAME");

            String fieldName = parser.getCurrentName();
            Assertions.assertEquals("key", fieldName, "Field name should be 'key'");
            
            // Call nextToken to move to VALUE_STRING
            token = parser.nextToken();
            Assertions.assertEquals(JsonToken.VALUE_STRING, token, "Second token should be VALUE_STRING");

            // Get the value
            String value = parser.getValueAsString();
            Assertions.assertEquals("value\n", value, "Parsed string should handle escaped characters correctly");
        } finally {
            parser.close();
        }
    }

    @Test
    @DisplayName("nextToken throws exception on invalid control character within a string")
    public void TC38() throws Exception {
        // Initialize parser with input containing invalid control character within a string
        String input = "{\"key\": \"value\u0001\"}";
        ByteArrayInputStream bais = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
        JsonFactory jsonFactory = new JsonFactory();
        JsonParser parser = jsonFactory.createParser(bais);

        try {
            // Call nextToken to move to FIELD_NAME
            JsonToken token = parser.nextToken();
            Assertions.assertEquals(JsonToken.FIELD_NAME, token, "First token should be FIELD_NAME");

            // Call nextToken to attempt to parse VALUE_STRING, expect exception
            Exception exception = Assertions.assertThrows(JsonParseException.class, () -> {
                parser.nextToken();
            });

            String expectedMessage = "Unquoted control character (code 1) in string";
            String actualMessage = exception.getMessage();

            Assertions.assertTrue(actualMessage.contains(expectedMessage), "Exception message should indicate unquoted control character");
        } finally {
            parser.close();
        }
    }
}