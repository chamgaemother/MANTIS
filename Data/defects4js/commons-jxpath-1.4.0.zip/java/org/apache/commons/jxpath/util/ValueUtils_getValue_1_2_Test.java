package org.apache.commons.jxpath.util;
// 
// import org.apache.commons.jxpath.Container;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// /**
//  * JUnit 5 test class for ValueUtils.getValue method.
//  * Generated to enhance branch coverage based on provided scenarios.
//  */
public class ValueUtils_getValue_1_2_Test {
// 
//     /**
//      * Simple implementation of Container for testing purposes.
//      */
//     static class SimpleContainer implements Container {
//         private final Object value;
// 
//         public SimpleContainer(Object value) {
//             this.value = value;
//         }
// 
//         @Override
//         public Object getValue() {
//             return value;
//         }
//     }
// 
//     @Test
//     @DisplayName("getValue processes multiple Container layers and returns the innermost primitive non-Container object")
//     void TC17() {
        // GIVEN
//         Container innerContainer = new SimpleContainer(Integer.valueOf(75));
//         Container outerContainer = new SimpleContainer(innerContainer);
// 
        // WHEN
//         Object result = ValueUtils.getValue(outerContainer);
// 
        // THEN
//         assertEquals(Integer.valueOf(75), result, "The innermost primitive object should be returned.");
//     }
// 
//     @Test
//     @DisplayName("getValue processes a Container that returns null and returns null")
//     void TC18() {
        // GIVEN
//         Container container = new SimpleContainer(null);
// 
        // WHEN
//         Object result = ValueUtils.getValue(container);
// 
        // THEN
//         assertNull(result, "The returned value should be null when the container holds null.");
//     }
// 
//     @Test
//     @DisplayName("getValue processes a Container that returns another Container which returns null")
//     void TC19() {
        // GIVEN
//         Container innerContainer = new SimpleContainer(null);
//         Container outerContainer = new SimpleContainer(innerContainer);
// 
        // WHEN
//         Object result = ValueUtils.getValue(outerContainer);
// 
        // THEN
//         assertNull(result, "The returned value should be null when nested containers hold null.");
//     }
// }
}