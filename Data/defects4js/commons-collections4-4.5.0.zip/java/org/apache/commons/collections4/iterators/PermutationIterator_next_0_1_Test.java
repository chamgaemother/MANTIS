package org.apache.commons.collections4.iterators;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.*;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;

public class PermutationIterator_next_0_1_Test {

    private PermutationIterator<String> createIteratorForKeysAndDirection(int[] keys, boolean[] direction, Map<Integer, String> objectMap) throws Exception {
        // Bypassing private constructor parameters to set test conditions directly
        PermutationIterator<String> iterator = new PermutationIterator<>(new ArrayList<>(objectMap.values()));
        
        // Using reflection to set private fields
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, keys);

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, direction);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        objectMapField.set(iterator, objectMap);

        return iterator;
    }

    @Test
    @DisplayName("next() throws NoSuchElementException when hasNext() returns false")
    void TC01_nextThrowsNoSuchElementExceptionWhenHasNextIsFalse() throws Exception {
        // GIVEN
        int[] keys = {};
        boolean[] direction = {};
        Map<Integer, String> objectMap = new HashMap<>();
        PermutationIterator<String> iterator = createIteratorForKeysAndDirection(keys, direction, objectMap);

        // Ensure nextPermutation is null via reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, null);

        // WHEN & THEN
        assertThrows(NoSuchElementException.class, () -> iterator.next());
    }

    @Test
    @DisplayName("next() returns the first permutation when initialized with a single element")
    void TC02_nextReturnsFirstPermutationWithSingleElement() throws Exception {
        // GIVEN
        int[] keys = {1};
        boolean[] direction = {true};
        String element1 = "element1";
        Map<Integer, String> objectMap = new HashMap<>();
        objectMap.put(1, element1);
        PermutationIterator<String> iterator = createIteratorForKeysAndDirection(keys, direction, objectMap);

        // WHEN
        List<String> result = iterator.next();

        // THEN
        assertEquals(Collections.singletonList(element1), result);
    }

    @Test
    @DisplayName("next() returns next permutation when multiple permutations exist")
    void TC03_nextReturnsNextPermutationForTwoElements() throws Exception {
        // GIVEN
        int[] keys = {1, 2};
        boolean[] direction = {true, true};
        String element1 = "element1";
        String element2 = "element2";
        Map<Integer, String> objectMap = new HashMap<>();
        objectMap.put(1, element1);
        objectMap.put(2, element2);
        PermutationIterator<String> iterator = createIteratorForKeysAndDirection(keys, direction, objectMap);
        iterator.next(); // Initialize first permutation

        // WHEN
        List<String> result = iterator.next();

        // THEN
        assertEquals(Arrays.asList(element2, element1), result);
    }

    @Test
    @DisplayName("next() handles largest mobile integer at beginning")
    void TC04_nextHandlesLargestMobileIntegerAtBeginning() throws Exception {
        // GIVEN
        int[] keys = {3, 2, 1};
        boolean[] direction = {true, false, false};
        String element1 = "element1";
        String element2 = "element2";
        String element3 = "element3";
        Map<Integer, String> objectMap = new HashMap<>();
        objectMap.put(1, element1);
        objectMap.put(2, element2);
        objectMap.put(3, element3);
        PermutationIterator<String> iterator = createIteratorForKeysAndDirection(keys, direction, objectMap);

        // WHEN
        List<String> result = iterator.next();

        // THEN
        assertEquals(Arrays.asList(element2, element3, element1), result);
    }

    @Test
    @DisplayName("next() reverses directions of integers larger than swapped key")
    void TC05_nextReversesDirectionsAfterSwap() throws Exception {
        // GIVEN
        int[] keys = {1, 3, 2};
        boolean[] direction = {true, true, false};
        String element1 = "element1";
        String element2 = "element2";
        String element3 = "element3";
        Map<Integer, String> objectMap = new HashMap<>();
        objectMap.put(1, element1);
        objectMap.put(2, element2);
        objectMap.put(3, element3);
        PermutationIterator<String> iterator = createIteratorForKeysAndDirection(keys, direction, objectMap);
        iterator.next(); // First permutation [1,3,2]

        // WHEN
        List<String> result = iterator.next();

        // THEN
        assertAll(
            () -> assertEquals(Arrays.asList(element1, element2, element3), result),
            () -> {
                // Verify direction of key '3' is reversed to false via reflection
                Field directionField = PermutationIterator.class.getDeclaredField("direction");
                directionField.setAccessible(true);
                boolean[] updatedDirection = (boolean[]) directionField.get(iterator);
                assertFalse(updatedDirection[1], "Direction of key '3' should be reversed to false");
            }
        );
    }
}