import org.jsoup.internal.SimpleStreamReader;
import org.jsoup.helper.Validate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class SimpleStreamReaderTest {
    
    @Test
    void testReadEmptyStream() throws IOException {
        InputStream emptyStream = new ByteArrayInputStream(new byte[0]);
        SimpleStreamReader reader = new SimpleStreamReader(emptyStream, StandardCharsets.UTF_8);
        char[] charArray = new char[10];
        int bytesRead = reader.read(charArray, 0, 10);
        assertEquals(-1, bytesRead);
    }

    @Test
    void testReadSingleByteStream() throws IOException {
        InputStream singleByteStream = new ByteArrayInputStream("A".getBytes(StandardCharsets.UTF_8));
        SimpleStreamReader reader = new SimpleStreamReader(singleByteStream, StandardCharsets.UTF_8);
        char[] charArray = new char[10];
        int bytesRead = reader.read(charArray, 0, 10);
        assertEquals(1, bytesRead);
        assertEquals('A', charArray[0]);
    }

    @Test
    void testReadWithExactBufferSize() throws IOException {
        byte[] data = "Hello".getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(data);
        SimpleStreamReader reader = new SimpleStreamReader(stream, StandardCharsets.UTF_8);
        char[] charArray = new char[data.length];
        int bytesRead = reader.read(charArray, 0, data.length);
        assertEquals(data.length, bytesRead);
        assertEquals("Hello", new String(charArray, 0, bytesRead));
    }

    @Test
    void testReadPartialBuffer() throws IOException {
        byte[] data = "Hello".getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(data);
        SimpleStreamReader reader = new SimpleStreamReader(stream, StandardCharsets.UTF_8);
        char[] charArray = new char[10];
        int bytesRead = reader.read(charArray, 0, 2);
        assertEquals(2, bytesRead);
        assertEquals("He", new String(charArray, 0, bytesRead));
    }

    @Test
    void testInvalidCharsetInput() {
        InputStream streamMock = Mockito.mock(InputStream.class);
        SimpleStreamReader reader = new SimpleStreamReader(streamMock, StandardCharsets.UTF_8);
        
        assertThrows(NullPointerException.class, () -> {
            reader.read(null, 0, 10);
        });
    }

    @Test
    void testReadAfterClose() throws IOException {
        byte[] data = "Hello".getBytes(StandardCharsets.UTF_8);
        InputStream stream = new ByteArrayInputStream(data);
        SimpleStreamReader reader = new SimpleStreamReader(stream, StandardCharsets.UTF_8);
        reader.close();
        char[] charArray = new char[10];
        
        IOException exception = assertThrows(IOException.class, () -> reader.read(charArray, 0, 10));
        assertEquals("Stream closed", exception.getMessage());
    }

    @Test
    void testReadZeroLength() throws IOException {
        InputStream singleByteStream = new ByteArrayInputStream("A".getBytes(StandardCharsets.UTF_8));
        SimpleStreamReader reader = new SimpleStreamReader(singleByteStream, StandardCharsets.UTF_8);
        char[] charArray = new char[10];
        int bytesRead = reader.read(charArray, 0, 0);
        assertEquals(0, bytesRead);
    }
}