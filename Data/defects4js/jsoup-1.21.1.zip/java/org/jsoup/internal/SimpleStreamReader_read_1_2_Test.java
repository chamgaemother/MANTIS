package org.jsoup.internal;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import static org.mockito.Mockito.*;

public class SimpleStreamReader_read_1_2_Test {

    @Test
    @DisplayName("read with negative length, expecting IndexOutOfBoundsException")
    void TC22_readWithNegativeLength_throwsIndexOutOfBoundsException() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = -5;
        InputStream in = new ByteArrayInputStream(new byte[]{'a', 'b', 'c', 'd', 'e'});
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN & THEN
        Assertions.assertThrows(IndexOutOfBoundsException.class, () -> {
            reader.read(buffer, off, len);
        });
    }

    @Test
    @DisplayName("read successfully reads exact number of characters matching buffer size")
    void TC23_readWithExactBufferSize_returnsExactNumberOfCharacters() throws IOException {
        // GIVEN
        char[] buffer = new char[5];
        int off = 0;
        int len = 5;
        byte[] inputBytes = "Hello".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(inputBytes);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        Assertions.assertEquals(5, result);
        Assertions.assertEquals("Hello", new String(buffer));
    }

    @Test
    @DisplayName("read reads fewer characters than buffer size due to end of stream")
    void TC24_readWithPartialReadBeforeEndOfStream_returnsFewerCharacters() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        byte[] inputBytes = "Hi".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(inputBytes);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        Assertions.assertEquals(2, result);
        Assertions.assertEquals('H', buffer[0]);
        Assertions.assertEquals('i', buffer[1]);
    }

    @Test
    @DisplayName("read repeatedly reads until end of stream with multiple iterations")
    void TC25_readMultipleIterations_handlesEndOfStreamCorrectly() throws IOException {
        // GIVEN
        char[] buffer = new char[3];
        int off = 0;
        int len = 3;
        byte[] inputBytes = "HelloWorld".getBytes(StandardCharsets.UTF_8);
        InputStream in = new ByteArrayInputStream(inputBytes);
        SimpleStreamReader reader = new SimpleStreamReader(in, StandardCharsets.UTF_8);

        // WHEN
        int firstRead = reader.read(buffer, off, len);
        int secondRead = reader.read(buffer, off, len);
        int thirdRead = reader.read(buffer, off, len);
        int fourthRead = reader.read(buffer, off, len);

        // THEN
        Assertions.assertEquals(3, firstRead);
        Assertions.assertEquals("Hel", new String(buffer, 0, firstRead));
        Assertions.assertEquals(3, secondRead);
        Assertions.assertEquals("loW", new String(buffer, 0, secondRead));
        Assertions.assertEquals(3, thirdRead);
        Assertions.assertEquals("orl", new String(buffer, 0, thirdRead));
        Assertions.assertEquals(1, fourthRead);
        Assertions.assertEquals('d', buffer[0]);
    }

    @Test
    @DisplayName("read with bufferUp returning zero bytes, expecting IOException")
    void TC26_readBufferUpReturnsZeroBytes_throwsIOException() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;
        InputStream mockInputStream = mock(InputStream.class);
        when(mockInputStream.available()).thenReturn(10);
        when(mockInputStream.read(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
        SimpleStreamReader reader = new SimpleStreamReader(mockInputStream, StandardCharsets.UTF_8);

        // WHEN & THEN
        Assertions.assertThrows(IOException.class, () -> {
            reader.read(buffer, off, len);
        });
    }
}