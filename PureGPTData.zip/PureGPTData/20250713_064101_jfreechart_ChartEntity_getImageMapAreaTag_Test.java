import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.imagemap.ToolTipTagFragmentGenerator;
import org.jfree.chart.imagemap.URLTagFragmentGenerator;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class ChartEntityTest {

    @Test
    public void testGetImageMapAreaTag_NoURLNoToolTip() {
        Shape area = new Rectangle2D.Double(1.0, 1.0, 1.0, 1.0);
        ChartEntity entity = new ChartEntity(area);
        
        ToolTipTagFragmentGenerator tooltipGen = mock(ToolTipTagFragmentGenerator.class);
        URLTagFragmentGenerator urlGen = mock(URLTagFragmentGenerator.class);
        
        String result = entity.getImageMapAreaTag(tooltipGen, urlGen);
        assertEquals("", result);
    }

    @Test
    public void testGetImageMapAreaTag_WithToolTipNoURL() {
        Shape area = new Rectangle2D.Double(1.0, 1.0, 1.0, 1.0);
        ChartEntity entity = new ChartEntity(area, "tooltip");
        
        ToolTipTagFragmentGenerator tooltipGen = mock(ToolTipTagFragmentGenerator.class);
        when(tooltipGen.generateToolTipFragment("tooltip")).thenReturn(" title=\"tooltip\"");
        URLTagFragmentGenerator urlGen = mock(URLTagFragmentGenerator.class);
        
        String result = entity.getImageMapAreaTag(tooltipGen, urlGen);
        assertEquals("<area shape=\"rect\" coords=\"1,1,2,2\" title=\"tooltip\" nohref=\"nohref\"/>", result);
    }

    @Test
    public void testGetImageMapAreaTag_WithURLNoToolTip() {
        Shape area = new Rectangle2D.Double(1.0, 1.0, 1.0, 1.0);
        ChartEntity entity = new ChartEntity(area, null, "http://example.com");
        
        ToolTipTagFragmentGenerator tooltipGen = mock(ToolTipTagFragmentGenerator.class);
        URLTagFragmentGenerator urlGen = mock(URLTagFragmentGenerator.class);
        when(urlGen.generateURLFragment("http://example.com")).thenReturn(" href=\"http://example.com\"");
        
        String result = entity.getImageMapAreaTag(tooltipGen, urlGen);
        assertEquals("<area shape=\"rect\" coords=\"1,1,2,2\" href=\"http://example.com\" alt=\"\"/>", result);
    }

    @Test
    public void testGetImageMapAreaTag_WithToolTipAndURL() {
        Shape area = new Rectangle2D.Double(1.0, 1.0, 1.0, 1.0);
        ChartEntity entity = new ChartEntity(area, "tooltip", "http://example.com");
        
        ToolTipTagFragmentGenerator tooltipGen = mock(ToolTipTagFragmentGenerator.class);
        when(tooltipGen.generateToolTipFragment("tooltip")).thenReturn(" title=\"tooltip\"");
        URLTagFragmentGenerator urlGen = mock(URLTagFragmentGenerator.class);
        when(urlGen.generateURLFragment("http://example.com")).thenReturn(" href=\"http://example.com\"");
        
        String result = entity.getImageMapAreaTag(tooltipGen, urlGen);
        assertEquals("<area shape=\"rect\" coords=\"1,1,2,2\" title=\"tooltip\" href=\"http://example.com\"/>", result);
    }
}