package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class EqualsBuilderTest {

    private EqualsBuilder equalsBuilder;

    @BeforeEach
    public void setUp() {
        equalsBuilder = new EqualsBuilder();
    }

    @Test
    public void testReflectionAppend_IsEqualsFalse() {
        equalsBuilder.append(false, true);
        equalsBuilder.reflectionAppend(new Object(), new Object());
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_SameObject() {
        Object obj = new Object();
        equalsBuilder.reflectionAppend(obj, obj);
        assertTrue(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_LhsNull_RhsNotNull() {
        equalsBuilder.reflectionAppend(null, new Object());
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_RhsNull_LhsNotNull() {
        equalsBuilder.reflectionAppend(new Object(), null);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_ClassesNotRelated() {
        Object lhs = new Object();
        Object rhs = new String("Test");
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_LhsInstanceOfRhsClass_BothInstances() {
        Child child = new Child();
        Parent parent = child;
        equalsBuilder.reflectionAppend(parent, child);
        assertTrue(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_LhsInstanceOfRhsClass_NotBothInstances() {
        Parent parent = new Parent();
        Child child = new Child();
        equalsBuilder.setReflectUpToClass(Parent.class);
        equalsBuilder.reflectionAppend(parent, child);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_RhsInstanceOfLhsClass_BothInstances() {
        Child child = new Child();
        Parent parent = child;
        equalsBuilder.reflectionAppend(child, parent);
        assertTrue(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_RhsInstanceOfLhsClass_NotBothInstances() {
        Parent parent = new Parent();
        Child child = new Child();
        equalsBuilder.setReflectUpToClass(Parent.class);
        equalsBuilder.reflectionAppend(child, parent);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_TestClassIsArray() {
        int[] lhs = {1, 2, 3};
        int[] rhs = {1, 2, 3};
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertTrue(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_TestClassIsArray_DifferentArrays() {
        int[] lhs = {1, 2, 3};
        int[] rhs = {1, 2, 4};
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_BypassReflectionClassesContains() {
        Object lhs = new String("Test");
        Object rhs = new String("Test");
        equalsBuilder.setBypassReflectionClasses(Arrays.asList(String.class));
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertTrue(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_BypassReflectionClassesContains_NotEqual() {
        Object lhs = new String("Test");
        Object rhs = new String("Different");
        equalsBuilder.setBypassReflectionClasses(Arrays.asList(String.class));
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_NotBypassReflectionClasses() {
        Person lhs = new Person("John", 30);
        Person rhs = new Person("John", 30);
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertTrue(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_NotBypassReflectionClasses_NotEqual() {
        Person lhs = new Person("John", 30);
        Person rhs = new Person("Jane", 25);
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_ReflectionAppendThrowsIllegalArgumentException() {
        MalformedObject lhs = new MalformedObject();
        MalformedObject rhs = new MalformedObject();
        equalsBuilder.setReflectUpToClass(MalformedObject.class);
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertFalse(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_WithExcludedFields() {
        PersonWithExcludedField lhs = new PersonWithExcludedField("John", 30, "secret");
        PersonWithExcludedField rhs = new PersonWithExcludedField("John", 30, "differentSecret");
        equalsBuilder.setExcludeFields("secret");
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertTrue(equalsBuilder.isEquals());
    }

    @Test
    public void testReflectionAppend_WithExcludedFields_NotEqualNonExcluded() {
        PersonWithExcludedField lhs = new PersonWithExcludedField("John", 30, "secret");
        PersonWithExcludedField rhs = new PersonWithExcludedField("Jane", 30, "secret");
        equalsBuilder.setExcludeFields("secret");
        equalsBuilder.reflectionAppend(lhs, rhs);
        assertFalse(equalsBuilder.isEquals());
    }

    // Helper Classes

    static class Parent {
    }

    static class Child extends Parent {
    }

    static class Person {
        private String name;
        private int age;

        Person(String name, int age) {
            this.name = name;
            this.age = age;
        }
    }

    static class PersonWithExcludedField extends Person {
        private String secret;

        PersonWithExcludedField(String name, int age, String secret) {
            super(name, age);
            this.secret = secret;
        }
    }

    static class MalformedObject {
        private void someMethod() {
            throw new IllegalArgumentException();
        }

        @Override
        public boolean equals(Object obj) {
            someMethod();
            return super.equals(obj);
        }
    }
}