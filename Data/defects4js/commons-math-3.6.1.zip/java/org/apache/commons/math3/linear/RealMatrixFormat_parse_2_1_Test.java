package org.apache.commons.math3.linear;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealMatrixFormat;

public class RealMatrixFormat_parse_2_1_Test {

    @Test
    @DisplayName("parse with custom row separator ';' and column separator ':' successfully returns the correct RealMatrix")
    void TC18_parse_with_custom_separators() {
        // Arrange
        String source = "[[1.0:2.0];[3.0:4.0]]";
        RealMatrixFormat format = new RealMatrixFormat("[", "]", "[", "]", ";", ":");

        // Act
        RealMatrix result = format.parse(source);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.getRowDimension());
        assertEquals(2, result.getColumnDimension());
        assertEquals(1.0, result.getEntry(0, 0));
        assertEquals(2.0, result.getEntry(0, 1));
        assertEquals(3.0, result.getEntry(1, 0));
        assertEquals(4.0, result.getEntry(1, 1));
    }

    @Test
    @DisplayName("parse with custom row prefix '<' and row suffix '>' successfully returns the correct RealMatrix")
    void TC19_parse_with_custom_row_prefix_suffix() {
        // Arrange
        String source = "{<1.0,2.0>,<3.0,4.0>}";
        RealMatrixFormat format = new RealMatrixFormat("{", "}", "<", ">", ",", ",");

        // Act
        RealMatrix result = format.parse(source);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.getRowDimension());
        assertEquals(2, result.getColumnDimension());
        assertEquals(1.0, result.getEntry(0, 0));
        assertEquals(2.0, result.getEntry(0, 1));
        assertEquals(3.0, result.getEntry(1, 0));
        assertEquals(4.0, result.getEntry(1, 1));
    }
}