package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class WordUtils_wrap_0_1_Test {

    @Test
    @DisplayName("wrap(null, 10, \"\\n\", true, \",\") returns null when input string is null")
    public void TC01_wrap_null_input() {
        String str = null;
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ",";
        
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        
        assertNull(result, "The result should be null when input string is null.");
    }

    @Test
    @DisplayName("wrap(\"Sample text\", 10, null, true, \",\") uses system line separator when newLineStr is null")
    public void TC02_wrap_uses_default_newline() {
        String str = "Sample text";
        int wrapLength = 10;
        String newLineStr = null;
        boolean wrapLongWords = true;
        String wrapOn = ",";
        
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        
        assertNotNull(result, "The result should not be null.");
        assertTrue(result.contains(System.lineSeparator()), "The result should contain the system line separator.");
    }

    @Test
    @DisplayName("wrap(\"Sample text\", 0, \"\\n\", false, \",\") sets wrapLength to 1 when wrapLength < 1")
    public void TC03_wrap_wrapLength_less_than_1() {
        String str = "Sample text";
        int wrapLength = 0;
        String newLineStr = "\n";
        boolean wrapLongWords = false;
        String wrapOn = ",";
        
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        
        // Since wrapLength is set to 1 internally, verify that the wrapped text has line breaks after each character
        String expected = "S\na\nm\np\nl\ne\n \nt\ne\nx\nt";
        assertEquals(expected, result, "The wrapLength should be set to 1, resulting in a newline after every character.");
    }

    @Test
    @DisplayName("wrap(\"Sample text\", 10, \"\\n\", true, \"\") sets wrapOn to space when wrapOn is blank")
    public void TC04_wrapOn_is_blank_sets_to_space() {
        String str = "Sample text for wrapping";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "";
        
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        
        assertTrue(result.contains(" "), "The result should contain space as wrap delimiter.");
    }
    
    @Test
    @DisplayName("wrap with wrapOn as comma correctly wraps at commas")
    public void TC05_wrapOn_as_comma() {
        String str = "apple,banana,orange,grape";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ",";
        
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);
        
        // Expected to have newLineStr at comma positions
        String expected = "apple\nbanana\norange\ngrape";
        assertEquals(expected, result, "The text should be wrapped at commas with new line separator.");
    }
}