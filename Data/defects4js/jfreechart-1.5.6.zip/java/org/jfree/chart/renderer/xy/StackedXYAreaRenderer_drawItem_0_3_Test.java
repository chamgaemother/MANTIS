package org.jfree.chart.renderer.xy;

import java.util.Stack;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StackedXYAreaRenderer.StackedXYAreaRendererState;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.entity.XYItemEntity;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class StackedXYAreaRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem with CrosshairState updates correctly")
    public void TC11_drawItem_updates_CrosshairState() throws Exception {
        // Arrange
        StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = new CrosshairState();
        int series = 0;
        int item = 0;
        int pass = 0;

        // Using PlotOrientation.VERTEDICAL without repeating it ensures consistent testing
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        assertEquals(1.0, crosshairState.getCrosshairX(), 0.0001);
        assertEquals(2.0, crosshairState.getCrosshairY(), 0.0001);
    }

    @Test
    @DisplayName("drawItem with getShapePaint returns null uses seriesPaint")
    public void TC12_drawItem_getShapePaint_null_defaults_to_seriesPaint() throws Exception {
        // Arrange
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = new CrosshairState();
        int series = 0;
        int item = 0;
        int pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);

        doReturn(null).when(renderer).getShapePaint();
        Paint seriesPaint = mock(Paint.class);
        doReturn(seriesPaint).when(renderer).getItemPaint(series, item);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2).setPaint(seriesPaint);
    }

    @Test
    @DisplayName("drawItem with getShapeStroke returns null uses seriesStroke")
    public void TC13_drawItem_getShapeStroke_null_defaults_to_seriesStroke() throws Exception {
        // Arrange
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = new CrosshairState();
        int series = 0;
        int item = 0;
        int pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);

        doReturn(null).when(renderer).getShapeStroke();
        Stroke seriesStroke = mock(Stroke.class);
        doReturn(seriesStroke).when(renderer).getItemStroke(series, item);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2).setStroke(seriesStroke);
    }

    @Test
    @DisplayName("drawItem with empty lastSeriesPoints does not fill area")
    public void TC14_drawItem_empty_lastSeriesPoints_does_not_fill_area() throws Exception {
        // Arrange
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = new CrosshairState();
        int series = 0;
        int item = 0;
        int pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(Double.NaN);

        Stack<Point> emptyStack = new Stack<>();
        doReturn(emptyStack).when(state).getLastSeriesPoints();

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, never()).fill(any(Shape.class));
    }

//     @Test
//     @DisplayName("drawItem with null URLGenerator does not generate URL")
//     public void TC15_drawItem_null_URLGenerator_does_not_generate_URL() throws Exception {
        // Arrange
//         StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
//         Graphics2D g2 = mock(Graphics2D.class);
//         StackedXYAreaRendererState state = mock(StackedXYAreaRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = new CrosshairState();
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(dataset.getXValue(series, item)).thenReturn(1.0);
//         when(dataset.getYValue(series, item)).thenReturn(2.0);
// 
//         doReturn(null).when(renderer).getURLGenerator();
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
//         verify(info, never()).addEntity(any(XYItemEntity.class));
//     }
}