package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.json.UTF8StreamJsonParser;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

public class UTF8StreamJsonParser_nextToken_1_4_Test {

    @Test
    @DisplayName("nextToken throws exception on string with incomplete escape sequence '\\'")
    public void TC21() throws Exception {
        String json = "\"value\\\"";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextConstructor = IOContext.class.getDeclaredConstructor(Object.class, byte[].class, boolean.class, boolean.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        IOContext ctxt = ioContextConstructor.newInstance(this, new byte[0], false, false, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser via reflection
        Constructor<UTF8StreamJsonParser> parserConstructor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserConstructor.setAccessible(true);
        UTF8StreamJsonParser parser = parserConstructor.newInstance(ctxt, 0, input, null, sym, new byte[1024], 0, 0, 0, false);

        // Assert exception is thrown when calling nextToken()
        assertThrows(JsonParseException.class, () -> parser.nextToken());
    }

    @Test
    @DisplayName("nextToken correctly parses an empty array '[]'")
    public void TC22() throws Exception {
        String json = "[]";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextConstructor = IOContext.class.getDeclaredConstructor(Object.class, byte[].class, boolean.class, boolean.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        IOContext ctxt = ioContextConstructor.newInstance(this, new byte[0], false, false, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser via reflection
        Constructor<UTF8StreamJsonParser> parserConstructor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserConstructor.setAccessible(true);
        UTF8StreamJsonParser parser = parserConstructor.newInstance(ctxt, 0, input, null, sym, new byte[1024], 0, 0, 0, false);

        // Call nextToken and assert the tokens
        JsonToken token1 = parser.nextToken();
        JsonToken token2 = parser.nextToken();

        assertEquals(JsonToken.START_ARRAY, token1);
        assertEquals(JsonToken.END_ARRAY, token2);
    }

    @Test
    @DisplayName("nextToken correctly parses an array with one element")
    public void TC23() throws Exception {
        String json = "[1]";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextConstructor = IOContext.class.getDeclaredConstructor(Object.class, byte[].class, boolean.class, boolean.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        IOContext ctxt = ioContextConstructor.newInstance(this, new byte[0], false, false, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser via reflection
        Constructor<UTF8StreamJsonParser> parserConstructor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserConstructor.setAccessible(true);
        UTF8StreamJsonParser parser = parserConstructor.newInstance(ctxt, 0, input, null, sym, new byte[1024], 0, 0, 0, false);

        // Call nextToken and assert the tokens
        JsonToken token1 = parser.nextToken();
        JsonToken token2 = parser.nextToken();
        JsonToken token3 = parser.nextToken();

        assertEquals(JsonToken.START_ARRAY, token1);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token2);
        assertEquals(JsonToken.END_ARRAY, token3);
    }

    @Test
    @DisplayName("nextToken correctly parses an array with multiple elements")
    public void TC24() throws Exception {
        String json = "[1, 2, 3]";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextConstructor = IOContext.class.getDeclaredConstructor(Object.class, byte[].class, boolean.class, boolean.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        IOContext ctxt = ioContextConstructor.newInstance(this, new byte[0], false, false, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser via reflection
        Constructor<UTF8StreamJsonParser> parserConstructor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserConstructor.setAccessible(true);
        UTF8StreamJsonParser parser = parserConstructor.newInstance(ctxt, 0, input, null, sym, new byte[1024], 0, 0, 0, false);

        // Call nextToken and assert the tokens
        JsonToken token1 = parser.nextToken();
        JsonToken token2 = parser.nextToken();
        JsonToken token3 = parser.nextToken();
        JsonToken token4 = parser.nextToken();
        JsonToken token5 = parser.nextToken();

        assertEquals(JsonToken.START_ARRAY, token1);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token2);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token3);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token4);
        assertEquals(JsonToken.END_ARRAY, token5);
    }

    @Test
    @DisplayName("nextToken correctly parses an array with multiple elements and verifies each element")
    public void TC25() throws Exception {
        String json = "[1, 2, 3]";
        InputStream input = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        // Instantiate IOContext via reflection
        Constructor<IOContext> ioContextConstructor = IOContext.class.getDeclaredConstructor(Object.class, byte[].class, boolean.class, boolean.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        IOContext ctxt = ioContextConstructor.newInstance(this, new byte[0], false, false, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Instantiate UTF8StreamJsonParser via reflection
        Constructor<UTF8StreamJsonParser> parserConstructor = UTF8StreamJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class, byte[].class, int.class, int.class, int.class, boolean.class);
        parserConstructor.setAccessible(true);
        UTF8StreamJsonParser parser = parserConstructor.newInstance(ctxt, 0, input, null, sym, new byte[1024], 0, 0, 0, false);

        // Call nextToken and assert the tokens and their values
        JsonToken token1 = parser.nextToken();
        JsonToken token2 = parser.nextToken();
        int value1 = parser.getIntValue();
        JsonToken token3 = parser.nextToken();
        int value2 = parser.getIntValue();
        JsonToken token4 = parser.nextToken();
        int value3 = parser.getIntValue();
        JsonToken token5 = parser.nextToken();

        assertEquals(JsonToken.START_ARRAY, token1);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token2);
        assertEquals(1, value1);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token3);
        assertEquals(2, value2);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token4);
        assertEquals(3, value3);
        assertEquals(JsonToken.END_ARRAY, token5);
    }
}