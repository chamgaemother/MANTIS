package org.jfree.chart.title;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;

public class PaintScaleLegend_draw_0_1_Test {

    @Test
    @DisplayName("draw method with backgroundPaint set to null, skipping background fill")
    public void TC01_drawWithoutBackgroundPaint() throws Exception {
        // GIVEN
        PaintScale mockScale = mock(PaintScale.class);
        ValueAxis mockAxis = mock(ValueAxis.class);
        PaintScaleLegend legend = new PaintScaleLegend(mockScale, mockAxis);
        legend.setBackgroundPaint(null);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        verify(g2, never()).fill(Mockito.any(Rectangle2D.class));
    }

    @Test
    @DisplayName("draw method with backgroundPaint non-null, filling the background")
    public void TC02_drawWithBackgroundPaint() throws Exception {
        // GIVEN
        PaintScale mockScale = mock(PaintScale.class);
        ValueAxis mockAxis = mock(ValueAxis.class);
        PaintScaleLegend legend = new PaintScaleLegend(mockScale, mockAxis);
        Paint background = Color.BLUE;
        legend.setBackgroundPaint(background);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        verify(g2, times(1)).setPaint(background);
        verify(g2, times(1)).fill(Mockito.any(Rectangle2D.class));
    }

    @Test
    @DisplayName("draw method where getPosition is Top, processing top edge")
    public void TC03_drawWithPositionTop() throws Exception {
        // GIVEN
        PaintScale mockScale = mock(PaintScale.class);
        ValueAxis mockAxis = mock(ValueAxis.class);
        PaintScaleLegend legend = new PaintScaleLegend(mockScale, mockAxis);
        legend.setPosition(RectangleEdge.TOP);
        legend.setBackgroundPaint(null);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        // Additional verification for top edge processing can be added here
    }

    @Test
    @DisplayName("draw method where getPosition is Bottom, processing bottom edge")
    public void TC04_drawWithPositionBottom() throws Exception {
        // GIVEN
        PaintScale mockScale = mock(PaintScale.class);
        ValueAxis mockAxis = mock(ValueAxis.class);
        PaintScaleLegend legend = new PaintScaleLegend(mockScale, mockAxis);
        legend.setPosition(RectangleEdge.BOTTOM);
        legend.setBackgroundPaint(null);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        // Additional verification for bottom edge processing can be added here
    }

    @Test
    @DisplayName("draw method where getPosition is Left, processing left edge")
    public void TC05_drawWithPositionLeft() throws Exception {
        // GIVEN
        PaintScale mockScale = mock(PaintScale.class);
        ValueAxis mockAxis = mock(ValueAxis.class);
        PaintScaleLegend legend = new PaintScaleLegend(mockScale, mockAxis);
        legend.setPosition(RectangleEdge.LEFT);
        legend.setBackgroundPaint(null);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        // Additional verification for left edge processing can be added here
    }
}