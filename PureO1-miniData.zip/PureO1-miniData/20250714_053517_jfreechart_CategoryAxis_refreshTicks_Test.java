import static org.junit.jupiter.api.Assertions.*;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class CategoryAxisTest {

    private CategoryAxis axis;
    private Graphics2D g2;
    private AxisState state;
    private Rectangle2D dataArea;
    private RectangleEdge edge;
    private CategoryPlot plot;

    @BeforeEach
    void setUp() {
        axis = new CategoryAxis("Category");
        g2 = Mockito.mock(Graphics2D.class);
        state = new AxisState(0.0);
        dataArea = new Rectangle2D.Double(0, 0, 500, 300);
        plot = Mockito.mock(CategoryPlot.class);
        axis.setPlot(plot);
    }

    @Test
    void refreshTicks_DataAreaHeightZero_ReturnsEmptyList() {
        Rectangle2D zeroHeightArea = new Rectangle2D.Double(0, 0, 500, 0);
        List ticks = axis.refreshTicks(g2, state, zeroHeightArea, RectangleEdge.BOTTOM);
        assertTrue(ticks.isEmpty());
        assertEquals(0.0, state.getMax());
    }

    @Test
    void refreshTicks_DataAreaWidthNegative_ReturnsEmptyList() {
        Rectangle2D negativeWidthArea = new Rectangle2D.Double(0, 0, -100, 300);
        List ticks = axis.refreshTicks(g2, state, negativeWidthArea, RectangleEdge.BOTTOM);
        assertTrue(ticks.isEmpty());
        assertEquals(0.0, state.getMax());
    }

    @Test
    void refreshTicks_IsTickLabelsVisibleFalse_ReturnsEmptyList() {
        axis.setTickLabelsVisible(false);
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(Arrays.asList("A", "B", "C"));
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertTrue(ticks.isEmpty());
        assertEquals(0.0, state.getMax());
    }

    @Test
    void refreshTicks_IsTickLabelsVisibleTrue_CategoriesNull_ReturnsEmptyList() {
        axis.setTickLabelsVisible(true);
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(null);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertTrue(ticks.isEmpty());
        assertEquals(0.0, state.getMax());
    }

    @Test
    void refreshTicks_IsTickLabelsVisibleTrue_CategoriesEmpty_ReturnsEmptyList() {
        axis.setTickLabelsVisible(true);
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(Collections.emptyList());
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertTrue(ticks.isEmpty());
        assertEquals(0.0, state.getMax());
    }

    @Test
    void refreshTicks_IsTickLabelsVisibleTrue_SingleCategory_ReturnsOneTick() {
        axis.setTickLabelsVisible(true);
        List categories = Collections.singletonList("A");
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(categories);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertEquals(1, ticks.size());
        assertEquals(state.getMax(), calculateExpectedHeight(ticks, RectangleEdge.BOTTOM));
    }

    @Test
    void refreshTicks_IsTickLabelsVisibleTrue_MultipleCategories_ReturnsTicks() {
        axis.setTickLabelsVisible(true);
        List categories = Arrays.asList("A", "B", "C");
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(categories);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertEquals(3, ticks.size());
        assertEquals(state.getMax(), calculateExpectedHeight(ticks, RectangleEdge.BOTTOM));
    }

    @Test
    void refreshTicks_TopEdge_ReturnsTicksWithMaxHeight() {
        axis.setTickLabelsVisible(true);
        List categories = Arrays.asList("A", "B");
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(categories);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.TOP);
        assertEquals(2, ticks.size());
        assertEquals(state.getMax(), calculateExpectedHeight(ticks, RectangleEdge.TOP));
    }

    @Test
    void refreshTicks_LeftEdge_ReturnsTicksWithMaxWidth() {
        axis.setTickLabelsVisible(true);
        List categories = Arrays.asList("A", "B", "C");
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(categories);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.LEFT);
        assertEquals(3, ticks.size());
        assertEquals(state.getMax(), calculateExpectedWidth(ticks, RectangleEdge.LEFT));
    }

    @Test
    void refreshTicks_MaxCategoryLabelWidthRatioZero_UsesPositionWidthRatio() {
        axis.setMaximumCategoryLabelWidthRatio(0.0f);
        axis.setTickLabelsVisible(true);
        List categories = Arrays.asList("A", "B");
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(categories);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertEquals(2, ticks.size());
    }

    @Test
    void refreshTicks_MaxCategoryLabelWidthRatioPositive_UsesSetRatio() {
        axis.setMaximumCategoryLabelWidthRatio(0.5f);
        axis.setTickLabelsVisible(true);
        List categories = Arrays.asList("A", "B", "C");
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(categories);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.BOTTOM);
        assertEquals(3, ticks.size());
    }

    @Test
    void refreshTicks_RightEdge_ReturnsTicksWithMaxWidth() {
        axis.setTickLabelsVisible(true);
        List categories = Arrays.asList("A", "B", "C", "D");
        Mockito.when(plot.getCategoriesForAxis(axis)).thenReturn(categories);
        List ticks = axis.refreshTicks(g2, state, dataArea, RectangleEdge.RIGHT);
        assertEquals(4, ticks.size());
        assertEquals(state.getMax(), calculateExpectedWidth(ticks, RectangleEdge.RIGHT));
    }

    private double calculateExpectedHeight(List ticks, RectangleEdge edge) {
        // Mock calculation for expected max height
        // In actual tests, this should calculate based on mock labels
        return 10.0;
    }

    private double calculateExpectedWidth(List ticks, RectangleEdge edge) {
        // Mock calculation for expected max width
        // In actual tests, this should calculate based on mock labels
        return 15.0;
    }
}