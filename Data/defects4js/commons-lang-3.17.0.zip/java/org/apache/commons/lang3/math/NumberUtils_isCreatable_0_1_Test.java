package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_isCreatable_0_1_Test {

    @Test
    @DisplayName("isCreatable(null) returns false when input string is null")
    void TC01_isCreatable_null_input() {
        // GIVEN
        String input = null;

        // WHEN
        boolean result = NumberUtils.isCreatable(input);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"\") returns false when input string is empty")
    void TC02_isCreatable_empty_string() {
        // GIVEN
        String input = "";

        // WHEN
        boolean result = NumberUtils.isCreatable(input);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"123\") returns true for a valid integer")
    void TC03_isCreatable_valid_integer() {
        // GIVEN
        String input = "123";

        // WHEN
        boolean result = NumberUtils.isCreatable(input);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"+0x1A\") returns true for a valid hexadecimal number")
    void TC04_isCreatable_valid_hexadecimal() {
        // GIVEN
        String input = "+0x1A";

        // WHEN
        boolean result = NumberUtils.isCreatable(input);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"-075\") returns true for a valid octal number")
    void TC05_isCreatable_valid_octal() {
        // GIVEN
        String input = "-075";

        // WHEN
        boolean result = NumberUtils.isCreatable(input);

        // THEN
        assertTrue(result);
    }
}