package com.google.gson.stream;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Field;

public class JsonReader_skipValue_0_1_Test {

    @Test
    @DisplayName("skipValue() with peeked initially as PEEKED_NONE and first token as PEEKED_BEGIN_ARRAY")
    void TC01_skipValue_begins_array() throws Exception {
        // GIVEN
        String json = "[ ]";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.beginArray(); // Initializes with BEGIN_ARRAY

        // WHEN
        reader.skipValue();

        // THEN
        // Use reflection to verify that END_ARRAY was processed and stack decremented
        Field stackField = JsonReader.class.getDeclaredField("stack");
        stackField.setAccessible(true);
        int[] stack = (int[]) stackField.get(reader);

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        int stackSize = stackSizeField.getInt(reader);

        assertEquals(JsonScope.EMPTY_ARRAY, stack[stackSize], "EMPTY_ARRAY should be processed at the top of the stack");
    }

    @Test
    @DisplayName("skipValue() with peeked initially as PEEKED_NONE and first token as PEEKED_BEGIN_OBJECT")
    void TC02_skipValue_begins_object() throws Exception {
        // GIVEN
        String json = "{ }";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.beginObject(); // Initializes with BEGIN_OBJECT

        // WHEN
        reader.skipValue();

        // THEN
        // Use reflection to verify that END_OBJECT was processed and stack decremented
        Field stackField = JsonReader.class.getDeclaredField("stack");
        stackField.setAccessible(true);
        int[] stack = (int[]) stackField.get(reader);

        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        int stackSize = stackSizeField.getInt(reader);

        assertEquals(JsonScope.EMPTY_OBJECT, stack[stackSize], "EMPTY_OBJECT should be processed at the top of the stack");
    }

    @Test
    @DisplayName("skipValue() with peeked initially as PEEKED_NONE and first token as PEEKED_END_ARRAY")
    void TC03_skipValue_ends_array() throws Exception {
        // GIVEN
        String json = " ]";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.beginArray();  // Sets initial state for testing

        // WHEN
        reader.skipValue();

        // THEN
        // Verify stackSize is decremented
        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        int stackSize = stackSizeField.getInt(reader);
        assertEquals(0, stackSize, "stackSize should be decremented to 0");
    }

    @Test
    @DisplayName("skipValue() with peeked initially as PEEKED_NONE and first token as PEEKED_END_OBJECT")
    void TC04_skipValue_ends_object() throws Exception {
        // GIVEN
        String json = " }";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.beginObject();  // Sets initial state for testing

        // WHEN
        reader.skipValue();

        // THEN
        // Verify stackSize is decremented
        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        int stackSize = stackSizeField.getInt(reader);
        assertEquals(0, stackSize, "stackSize should be decremented to 0");
    }

    @Test
    @DisplayName("skipValue() with peeked initially as PEEKED_NONE and first token as PEEKED_UNQUOTED")
    void TC05_skipValue_with_unquoted_value() throws Exception {
        // GIVEN
        String json = "unquotedValue";
        JsonReader reader = new JsonReader(new StringReader(json));

        // WHEN
        reader.skipValue();

        // THEN
        // Verify position moved to the end of the string
        Field posField = JsonReader.class.getDeclaredField("pos");
        posField.setAccessible(true);
        int pos = posField.getInt(reader);

        assertEquals(json.length(), pos, "Position should be moved past the unquoted value");
    }
}
