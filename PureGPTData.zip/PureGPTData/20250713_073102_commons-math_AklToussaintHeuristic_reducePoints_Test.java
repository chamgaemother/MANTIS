import org.apache.commons.math3.geometry.euclidean.twod.Vector2D;
import org.apache.commons.math3.geometry.euclidean.twod.hull.AklToussaintHeuristic;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class AklToussaintHeuristicTest {

    // Helper method to provide different test cases
    static Stream<Collection<Vector2D>> pointCollections() {
        return Stream.of(
            Collections.emptyList(), // Case 1: empty input
            Arrays.asList(new Vector2D(1, 1)), // Case 2: single point
            Arrays.asList(new Vector2D(1, 1), new Vector2D(2, 2)), // Case 3: two points
            Arrays.asList(new Vector2D(1, 1), new Vector2D(2, 2), new Vector2D(3, 3)), // Case 4: three collinear points
            Arrays.asList(
                new Vector2D(0, 0), new Vector2D(0, 5), new Vector2D(5, 5), new Vector2D(5, 0),
                new Vector2D(2, 2) // Inside quadrilateral
            ),
            Arrays.asList(
                new Vector2D(0, 0), new Vector2D(0, 5), new Vector2D(5, 5), new Vector2D(5, 0),
                new Vector2D(6, 6) // Outside quadrilateral
            )
        );
    }

    @ParameterizedTest
    @MethodSource("pointCollections")
    void testReducePoints(Collection<Vector2D> points) {
        Collection<Vector2D> reducedPoints = AklToussaintHeuristic.reducePoints(points);
        assertNotNull(reducedPoints);

        if (points.size() < 4) {
            assertEquals(points.size(), reducedPoints.size());
        } else {
            for (Vector2D point : reducedPoints) {
                assertFalse(
                    insideQuadrilateral(point, points),
                    "Point should not be inside quadrilateral"
                );
            }
        }
    }

    @Test
    void testAllPointsOutsideQuadrilateral() {
        List<Vector2D> points = Arrays.asList(
                new Vector2D(0, 0), new Vector2D(10, 0), new Vector2D(10, 10), new Vector2D(0, 10),
                new Vector2D(-1, -1), new Vector2D(11, 11) // Outside points
        );

        Collection<Vector2D> reducedPoints = AklToussaintHeuristic.reducePoints(points);
        assertEquals(points.size(), reducedPoints.size());
    }

    @Test
    void testReducePointsWithInsidePointsRemoved() {
        List<Vector2D> points = Arrays.asList(
            new Vector2D(0, 0), new Vector2D(0, 10), new Vector2D(10, 10), new Vector2D(10, 0),
            new Vector2D(5, 5), new Vector2D(3, 3) // Inside points
        );

        Collection<Vector2D> reducedPoints = AklToussaintHeuristic.reducePoints(points);
        assertFalse(reducedPoints.contains(new Vector2D(5, 5)));
        assertFalse(reducedPoints.contains(new Vector2D(3, 3)));
    }

    private boolean insideQuadrilateral(Vector2D point, Collection<Vector2D> points) {
        // Recreate the logic from the private method for testing purposes
        if (points.size() < 4) return false;
        Vector2D[] quad = new Vector2D[4];
        points.toArray(quad);
        for (int i = 0; i < 4; i++) {
            if (point.equals(quad[i])) {
                return true;
            }
            Vector2D p1 = quad[i];
            Vector2D p2 = quad[(i+1) % 4];
            double cross = point.crossProduct(p1, p2);
            if (cross <= 0) {
                return false;
            }
        }
        return true;
    }
}