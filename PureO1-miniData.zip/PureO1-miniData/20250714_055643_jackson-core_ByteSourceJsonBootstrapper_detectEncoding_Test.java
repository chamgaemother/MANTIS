package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.io.IOContext;

class ByteSourceJsonBootstrapperTest {

    private IOContext createIOContext() {
        return Mockito.mock(IOContext.class, Mockito.RETURNS_DEEP_STUBS);
    }

    @Test
    void detectEncoding_UTF8_BOM() throws IOException {
        byte[] utf8BOM = new byte[] {(byte)0xEF, (byte)0xBB, (byte)0xBF, '{'};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf8BOM, 0, utf8BOM.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    @Test
    void detectEncoding_UTF16_BE_BOM() throws IOException {
        byte[] utf16BEBOM = new byte[] {(byte)0xFE, (byte)0xFF, 0x00, '{'};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf16BEBOM, 0, utf16BEBOM.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF16_BE, encoding);
    }

    @Test
    void detectEncoding_UTF16_LE_BOM() throws IOException {
        byte[] utf16LEBOM = new byte[] {(byte)0xFF, (byte)0xFE, '{', 0x00};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf16LEBOM, 0, utf16LEBOM.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF16_LE, encoding);
    }

    @Test
    void detectEncoding_UTF32_BE_BOM() throws IOException {
        byte[] utf32BEBOM = new byte[] {0x00, 0x00, (byte)0xFE, (byte)0xFF, 0x00, 0x00, 0x00, '{'};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf32BEBOM, 0, utf32BEBOM.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF32_BE, encoding);
    }

    @Test
    void detectEncoding_UTF32_LE_BOM() throws IOException {
        byte[] utf32LEBOM = new byte[] {(byte)0xFF, (byte)0xFE, 0x00, 0x00, '{', 0x00, 0x00, 0x00};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf32LEBOM, 0, utf32LEBOM.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF32_LE, encoding);
    }

    @Test
    void detectEncoding_UTF8_NoBOM() throws IOException {
        byte[] utf8 = "{ \"key\": \"value\" }".getBytes(StandardCharsets.UTF_8);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf8, 0, utf8.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    @Test
    void detectEncoding_UTF16_BE_NoBOM() throws IOException {
        byte[] utf16BE = new byte[] {0x00, '{', 0x00, ' '};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf16BE, 0, utf16BE.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF16_BE, encoding);
    }

    @Test
    void detectEncoding_UTF16_LE_NoBOM() throws IOException {
        byte[] utf16LE = new byte[] {'{', 0x00, ' ', 0x00};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf16LE, 0, utf16LE.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF16_LE, encoding);
    }

    @Test
    void detectEncoding_UTF32_BE_NoBOM() throws IOException {
        byte[] utf32BE = new byte[] {0x00, 0x00, 0x00, '{'};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf32BE, 0, utf32BE.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF32_BE, encoding);
    }

    @Test
    void detectEncoding_UTF32_LE_NoBOM() throws IOException {
        byte[] utf32LE = new byte[] {'{', 0x00, 0x00, 0x00};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, utf32LE, 0, utf32LE.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF32_LE, encoding);
    }

    @Test
    void detectEncoding_InsufficientBytes() throws IOException {
        byte[] insufficient = new byte[] {(byte)0xEF};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, insufficient, 0, insufficient.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    @Test
    void detectEncoding_InvalidUTF8BOM() throws IOException {
        byte[] invalidUTF8BOM = new byte[] {(byte)0xEF, (byte)0xBA, (byte)0xBF, '{'};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, invalidUTF8BOM, 0, invalidUTF8BOM.length);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    @Test
    void detectEncoding_InvalidUTF32() {
        byte[] invalidUTF32 = new byte[] {0x12, 0x34, 0x56, 0x78, '{', 0x00, 0x00, 0x00};
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, invalidUTF32, 0, invalidUTF32.length);
        assertThrows(IOException.class, boot::detectEncoding);
    }

    @Test
    void detectEncoding_Stream_UTF8() throws IOException {
        byte[] utf8 = "{ \"key\": \"value\" }".getBytes(StandardCharsets.UTF_8);
        ByteArrayInputStream in = new ByteArrayInputStream(utf8);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, in);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    @Test
    void detectEncoding_Stream_UTF16_BE() throws IOException {
        byte[] utf16BE = new byte[] {0x00, '{', 0x00, ' '};
        ByteArrayInputStream in = new ByteArrayInputStream(utf16BE);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, in);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF16_BE, encoding);
    }

    @Test
    void detectEncoding_Stream_UTF16_LE() throws IOException {
        byte[] utf16LE = new byte[] {'{', 0x00, ' ', 0x00};
        ByteArrayInputStream in = new ByteArrayInputStream(utf16LE);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, in);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF16_LE, encoding);
    }

    @Test
    void detectEncoding_Stream_UTF32_BE() throws IOException {
        byte[] utf32BE = new byte[] {0x00, 0x00, 0x00, '{'};
        ByteArrayInputStream in = new ByteArrayInputStream(utf32BE);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, in);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF32_BE, encoding);
    }

    @Test
    void detectEncoding_Stream_UTF32_LE() throws IOException {
        byte[] utf32LE = new byte[] {'{', 0x00, 0x00, 0x00};
        ByteArrayInputStream in = new ByteArrayInputStream(utf32LE);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, in);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF32_LE, encoding);
    }

    @Test
    void detectEncoding_Stream_InsufficientBytes() throws IOException {
        byte[] insufficient = new byte[] {(byte)0xEF};
        ByteArrayInputStream in = new ByteArrayInputStream(insufficient);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, in);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF8, encoding);
    }

    @Test
    void detectEncoding_Stream_InvalidUTF16() throws IOException {
        byte[] invalidUTF16 = new byte[] {0x01, 0x02, 0x03, 0x04};
        ByteArrayInputStream in = new ByteArrayInputStream(invalidUTF16);
        IOContext ctxt = createIOContext();
        ByteSourceJsonBootstrapper boot = new ByteSourceJsonBootstrapper(ctxt, in);
        JsonEncoding encoding = boot.detectEncoding();
        assertEquals(JsonEncoding.UTF8, encoding);
    }
}