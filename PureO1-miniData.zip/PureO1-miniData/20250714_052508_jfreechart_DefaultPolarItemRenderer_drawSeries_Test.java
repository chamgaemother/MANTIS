package org.jfree.chart.renderer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.*;
import java.awt.geom.*;
import java.util.Collections;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.PolarPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class DefaultPolarItemRendererTest {

    private DefaultPolarItemRenderer renderer;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private PolarPlot plot;
    private XYDataset dataset;

    @BeforeEach
    void setUp() {
        renderer = new DefaultPolarItemRenderer();
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(PolarPlot.class);
        dataset = mock(XYDataset.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(mock(ValueAxis.class));
        renderer.setPlot(plot);
    }

    @Test
    void testDrawSeries_numPointsZero() {
        when(dataset.getItemCount(0)).thenReturn(0);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawSeries_connectFirstAndLastPoint_true() {
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(90.0);
        when(dataset.getYValue(0, 1)).thenReturn(1.0);
        when(dataset.getXValue(0, 2)).thenReturn(180.0);
        when(dataset.getYValue(0, 2)).thenReturn(1.0);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(50, 50))
            .thenReturn(new Point(60, 60))
            .thenReturn(new Point(70, 70));

        renderer.setConnectFirstAndLastPoint(true);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawSeries_connectFirstAndLastPoint_false() {
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(90.0);
        when(dataset.getYValue(0, 1)).thenReturn(1.0);
        when(dataset.getXValue(0, 2)).thenReturn(180.0);
        when(dataset.getYValue(0, 2)).thenReturn(1.0);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(50, 50))
            .thenReturn(new Point(60, 60))
            .thenReturn(new Point(70, 70));

        renderer.setConnectFirstAndLastPoint(false);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawSeries_isSeriesFilled_true_drawOutlineWhenFilled_true() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(90.0);
        when(dataset.getYValue(0, 1)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(50, 50))
            .thenReturn(new Point(60, 60));

        renderer.setSeriesFilled(0, true);
        renderer.setDrawOutlineWhenFilled(true);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawSeries_isSeriesFilled_true_drawOutlineWhenFilled_false() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(90.0);
        when(dataset.getYValue(0, 1)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(50, 50))
            .thenReturn(new Point(60, 60));

        renderer.setSeriesFilled(0, true);
        renderer.setDrawOutlineWhenFilled(false);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(g2).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawSeries_isSeriesFilled_false() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(90.0);
        when(dataset.getYValue(0, 1)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(50, 50))
            .thenReturn(new Point(60, 60));

        renderer.setSeriesFilled(0, false);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(g2).draw(any(Shape.class));
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    void testDrawSeries_useFillPaint_true() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(90.0);
        when(dataset.getYValue(0, 1)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(50, 50))
            .thenReturn(new Point(60, 60));

        renderer.setUseFillPaint(true);
        renderer.setSeriesFilled(0, true);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawSeries_useFillPaint_false() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(0.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(90.0);
        when(dataset.getYValue(0, 1)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(50, 50))
            .thenReturn(new Point(60, 60));

        renderer.setUseFillPaint(false);
        renderer.setSeriesFilled(0, true);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawSeries_shapesVisible_true_entityWithinDataArea() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(45.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(45.0, 1.0, axis, dataArea))
            .thenReturn(new Point(50, 50));
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        renderer.setShapesVisible(true);
        renderer.setSeriesFilled(false);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(entities).add(any(XYItemEntity.class));
    }

    @Test
    void testDrawSeries_shapesVisible_true_entityOutsideDataArea() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(45.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(45.0, 1.0, axis, dataArea))
            .thenReturn(new Point(150, 150));
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        renderer.setShapesVisible(true);
        renderer.setSeriesFilled(false);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(entities, never()).add(any(XYItemEntity.class));
    }

    @Test
    void testDrawSeries_shapesVisible_false() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(45.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(45.0, 1.0, axis, dataArea))
            .thenReturn(new Point(50, 50));
        renderer.setShapesVisible(false);
        renderer.setSeriesFilled(false);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(info.getOwner(), never()).getEntityCollection();
    }

    @Test
    void testDrawSeries_nullInfo() {
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(45.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(45.0, 1.0, axis, dataArea))
            .thenReturn(new Point(50, 50));
        renderer.setShapesVisible(true);
        renderer.setSeriesFilled(false);
        renderer.drawSeries(g2, dataArea, null, plot, dataset, 0);

        // Should not throw exception and not add entities
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawSeries_nullDataset() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawSeries(g2, dataArea, info, plot, null, 0);
        });
    }

    @Test
    void testDrawSeries_boundaryValues() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(Double.MIN_VALUE);
        when(dataset.getYValue(0, 0)).thenReturn(Double.MAX_VALUE);
        when(dataset.getXValue(0, 1)).thenReturn(-Double.MIN_VALUE);
        when(dataset.getYValue(0, 1)).thenReturn(-Double.MAX_VALUE);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenReturn(new Point(Integer.MAX_VALUE, Integer.MAX_VALUE))
            .thenReturn(new Point(Integer.MIN_VALUE, Integer.MIN_VALUE));

        renderer.setConnectFirstAndLastPoint(true);
        renderer.setSeriesFilled(false);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);

        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawSeries_negativeSeriesIndex() {
        when(dataset.getItemCount(-1)).thenReturn(0);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, -1);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawSeries_largeSeriesIndex() {
        when(dataset.getItemCount(100)).thenReturn(0);
        renderer.drawSeries(g2, dataArea, info, plot, dataset, 100);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawSeries_nullPlot() {
        assertThrows(NullPointerException.class, () -> {
            renderer.drawSeries(g2, dataArea, info, null, dataset, 0);
        });
    }

    @Test
    void testDrawSeries_datasetWithNullValues() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(null);
        when(dataset.getYValue(0, 0)).thenReturn(null);
        when(dataset.getXValue(0, 1)).thenReturn(null);
        when(dataset.getYValue(0, 1)).thenReturn(null);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), any(ValueAxis.class), eq(dataArea)))
            .thenThrow(new IllegalArgumentException("Null values"));

        assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawSeries(g2, dataArea, info, plot, dataset, 0);
        });
    }
}