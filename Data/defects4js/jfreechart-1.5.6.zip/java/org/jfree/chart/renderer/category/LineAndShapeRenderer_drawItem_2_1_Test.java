package org.jfree.chart.renderer.category;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.mockito.Mockito.*;
import org.mockito.ArgumentCaptor;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.Shape;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.PlotOrientation;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.awt.geom.Line2D;

public class LineAndShapeRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("drawItem calculates x1 without series offset when useSeriesOffset is false")
    void TC06_drawItem_calculates_x1_without_series_offset() throws Exception {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        // Use reflection to set 'useSeriesOffset' to false
        Field useSeriesOffsetField = LineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
        useSeriesOffsetField.setAccessible(true);
        useSeriesOffsetField.set(renderer, false);
        // Spy the renderer to mock methods
        LineAndShapeRenderer spyRenderer = spy(renderer);
        // Create mocks for dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        // Set up mock behaviors
        when(spyRenderer.getItemVisible(0, 0)).thenReturn(true);
        when(spyRenderer.getItemLineVisible(0, 0)).thenReturn(true);
        when(spyRenderer.getItemShapeVisible(0, 0)).thenReturn(true);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any())).thenReturn(100.0);
        // Act
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Assert
        verify(domainAxis).getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any());
    }

    @Test
    @DisplayName("drawItem draws line when pass is 0 and line is visible")
    void TC07_drawItem_draws_line_on_pass0_when_line_visible() throws Exception {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        // Use reflection to set 'useSeriesOffset' to false
        Field useSeriesOffsetField = LineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
        useSeriesOffsetField.setAccessible(true);
        useSeriesOffsetField.set(renderer, false);
        // Spy the renderer to mock methods
        LineAndShapeRenderer spyRenderer = spy(renderer);
        // Create mocks for dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        // Set up mock behaviors
        when(spyRenderer.getItemVisible(0, 1)).thenReturn(true);
        when(spyRenderer.getItemLineVisible(0, 1)).thenReturn(true);
        when(spyRenderer.getItemShapeVisible(0, 1)).thenReturn(true);
        when(dataset.getValue(0, 1)).thenReturn(20.0);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.getCategoryMiddle(eq(1), anyInt(), eq(dataArea), any())).thenReturn(60.0);
        when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(eq(20.0), eq(dataArea), any())).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any())).thenReturn(100.0);
        // Act
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        // Assert
        ArgumentCaptor<Line2D> lineCaptor = ArgumentCaptor.forClass(Line2D.class);
        verify(g2).draw(lineCaptor.capture());
        Line2D drawnLine = lineCaptor.getValue();
        assertEquals(50.0, drawnLine.getX1(), 0.001);
        assertEquals(100.0, drawnLine.getY1(), 0.001);
        assertEquals(60.0, drawnLine.getX2(), 0.001);
        assertEquals(200.0, drawnLine.getY2(), 0.001);
    }

    @Test
    @DisplayName("drawItem does not draw line when pass is 0 and line is not visible")
    void TC08_drawItem_does_not_draw_line_on_pass0_when_line_not_visible() throws Exception {
        // Arrange
        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        // Use reflection to set 'useSeriesOffset' to false
        Field useSeriesOffsetField = LineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
        useSeriesOffsetField.setAccessible(true);
        useSeriesOffsetField.set(renderer, false);
        // Spy the renderer to mock methods
        LineAndShapeRenderer spyRenderer = spy(renderer);
        // Create mocks for dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        // Set up mock behaviors
        when(spyRenderer.getItemVisible(0, 1)).thenReturn(true);
        when(spyRenderer.getItemLineVisible(0, 1)).thenReturn(false);
        when(spyRenderer.getItemShapeVisible(0, 1)).thenReturn(true);
        when(dataset.getValue(0, 1)).thenReturn(20.0);
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        // Act
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        // Assert
        verify(g2, never()).draw(any(Line2D.class));
    }

//     @Test
//     @DisplayName("drawItem draws shape when pass is 1 and shape is visible")
//     void TC09_drawItem_draws_shape_on_pass1_when_shape_visible() throws Exception {
        // Arrange
//         LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        // Use reflection to set 'useSeriesOffset' to either true or false as needed
//         Field useSeriesOffsetField = LineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
//         useSeriesOffsetField.setAccessible(true);
//         useSeriesOffsetField.set(renderer, false);
        // Use reflection to set 'drawOutlines' to true
//         Field drawOutlinesField = LineAndShapeRenderer.class.getDeclaredField("drawOutlines");
//         drawOutlinesField.setAccessible(true);
//         drawOutlinesField.set(renderer, true);
        // Spy the renderer to mock methods
//         LineAndShapeRenderer spyRenderer = spy(renderer);
        // Create mocks for dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         Shape mockShape = mock(Shape.class);
        // Set up mock behaviors
//         when(spyRenderer.getItemVisible(0, 0)).thenReturn(true);
//         when(spyRenderer.getItemLineVisible(0, 0)).thenReturn(true);
//         when(spyRenderer.getItemShapeVisible(0, 0)).thenReturn(true);
//         when(spyRenderer.getItemShapeFilled(0, 0)).thenReturn(true);
//         when(dataset.getValue(0, 0)).thenReturn(10.0);
//         when(state.getVisibleSeriesIndex(0)).thenReturn(0);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(spyRenderer.getItemShape(0, 0)).thenReturn(mockShape);
//         when(state.getEntityCollection()).thenReturn(entityCollection);
//         when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any())).thenReturn(100.0);
        // Act
//         spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        // Assert
//         verify(g2).fill(mockShape);
//         verify(g2).draw(mockShape);
//         verify(entityCollection).add(eq(null), eq(dataset), eq(0), eq(0), eq(mockShape));
//     }

//     @Test
//     @DisplayName("drawItem handles shape not being filled when getItemShapeFilled returns false")
//     void TC10_drawItem_outlines_shape_without_filling_when_shape_not_filled() throws Exception {
        // Arrange
//         LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        // Use reflection to set 'useSeriesOffset' to either true or false as needed
//         Field useSeriesOffsetField = LineAndShapeRenderer.class.getDeclaredField("useSeriesOffset");
//         useSeriesOffsetField.setAccessible(true);
//         useSeriesOffsetField.set(renderer, false);
        // Use reflection to set 'drawOutlines' to true
//         Field drawOutlinesField = LineAndShapeRenderer.class.getDeclaredField("drawOutlines");
//         drawOutlinesField.setAccessible(true);
//         drawOutlinesField.set(renderer, true);
        // Use reflection to set 'useFillPaint' to false
//         Field useFillPaintField = LineAndShapeRenderer.class.getDeclaredField("useFillPaint");
//         useFillPaintField.setAccessible(true);
//         useFillPaintField.set(renderer, false);
        // Spy the renderer to mock methods
//         LineAndShapeRenderer spyRenderer = spy(renderer);
        // Create mocks for dependencies
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         Shape mockShape = mock(Shape.class);
        // Set up mock behaviors
//         when(spyRenderer.getItemVisible(0, 0)).thenReturn(true);
//         when(spyRenderer.getItemLineVisible(0, 0)).thenReturn(true);
//         when(spyRenderer.getItemShapeVisible(0, 0)).thenReturn(true);
//         when(spyRenderer.getItemShapeFilled(0, 0)).thenReturn(false);
//         when(dataset.getValue(0, 0)).thenReturn(10.0);
//         when(state.getVisibleSeriesIndex(0)).thenReturn(0);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(spyRenderer.getItemShape(0, 0)).thenReturn(mockShape);
//         when(state.getEntityCollection()).thenReturn(entityCollection);
//         when(domainAxis.getCategoryMiddle(eq(0), anyInt(), eq(dataArea), any())).thenReturn(50.0);
//         when(rangeAxis.valueToJava2D(eq(10.0), eq(dataArea), any())).thenReturn(100.0);
        // Act
//         spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);
        // Assert
//         verify(g2, never()).fill(any(Shape.class));
//         verify(g2).draw(mockShape);
//         verify(entityCollection).add(eq(null), eq(dataset), eq(0), eq(0), eq(mockShape));
//     }

}