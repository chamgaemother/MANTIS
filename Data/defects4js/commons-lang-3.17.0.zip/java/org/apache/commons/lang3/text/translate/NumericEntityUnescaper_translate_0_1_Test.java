package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.text.translate.NumericEntityUnescaper;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.EnumSet;
import org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION;

public class NumericEntityUnescaper_translate_0_1_Test {

    @Test
    @DisplayName("Input char at index is not '&', no translation performed")
    void test_TC01_non_entity_start() throws Exception {
        // GIVEN
        CharSequence input = "A sample text";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals(0, result);
    }
    
    @Test
    @DisplayName("Input starts with '&' but not followed by '#', no translation performed")
    void test_TC02_ampersand_without_hash() throws Exception {
        // GIVEN
        CharSequence input = "&amp;Test";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals(0, result);
    }
    
    @Test
    @DisplayName("Input starts with '&#' but index is at seqEnd -2, no translation performed")
    void test_TC03_index_at_boundary() throws Exception {
        // GIVEN
        CharSequence input = "&#A";
        int index = 1;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals(0, result);
    }
    
    @Test
    @DisplayName("Input starts with '&#x' followed by valid hexadecimal digits and ends with ';'")
    void test_TC04_valid_hex_with_semicolon() throws Exception {
        // GIVEN
        CharSequence input = "&#x41;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        
        // Reflection to ensure OPTION.semiColonRequired is not set
        Field optionsField = NumericEntityUnescaper.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(unescaper, EnumSet.noneOf(OPTION.class));
        
        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals("A", out.toString());
        assertEquals(5, result);
    }
    
    @Test
    @DisplayName("Input starts with '&#X' followed by valid hexadecimal digits and ends with ';'")
    void test_TC05_valid_hex_uppercase_X_with_semicolon() throws Exception {
        // GIVEN
        CharSequence input = "&#X41;";
        int index = 0;
        Writer out = new StringWriter();
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        
        // Reflection to ensure OPTION.semiColonRequired is not set
        Field optionsField = NumericEntityUnescaper.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(unescaper, EnumSet.noneOf(OPTION.class));
        
        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals("A", out.toString());
        assertEquals(5, result);
    }
}