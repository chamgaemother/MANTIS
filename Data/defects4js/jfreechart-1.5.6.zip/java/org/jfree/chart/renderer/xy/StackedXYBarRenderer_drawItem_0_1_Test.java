package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class StackedXYBarRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem returns early when getItemVisible(series, item) is false")
    public void TC01_drawItem_ItemNotVisible() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;
        
        StackedXYBarRenderer spyRenderer = Mockito.spy(renderer);
        Mockito.doReturn(false).when(spyRenderer).getItemVisible(series, item);
        
        // Act
        spyRenderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
        
        // Assert
        Mockito.verify(spyRenderer, times(1)).getItemVisible(series, item);
        Mockito.verifyNoInteractions(g2);
    }

    @Test
    @DisplayName("drawItem throws IllegalArgumentException when dataset is neither IntervalXYDataset nor TableXYDataset")
    public void TC02_drawItem_InvalidDatasetType() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class); // Not IntervalXYDataset or TableXYDataset
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
        });
        assertTrue(exception.getMessage().contains("has wrong type:"));
    }

    @Test
    @DisplayName("drawItem throws IllegalArgumentException when dataset is not IntervalXYDataset")
    public void TC03_drawItem_DatasetNotIntervalXYDataset() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        // Mock TableXYDataset only
        TableXYDataset dataset = mock(TableXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
        });
        assertTrue(exception.getMessage().contains("it is no IntervalXYDataset"));
    }

    @Test
    @DisplayName("drawItem throws IllegalArgumentException when dataset is not TableXYDataset")
    public void TC04_drawItem_DatasetNotTableXYDataset() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        // Mock IntervalXYDataset only
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
        });
        assertTrue(exception.getMessage().contains("it is no TableXYDataset"));
    }

    @Test
    @DisplayName("drawItem returns early when Y value is NaN")
    public void TC05_drawItem_YValueIsNaN() throws Exception {
        StackedXYBarRenderer renderer = new StackedXYBarRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        // Mock IntervalXYDataset
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;
        
        renderer.drawItem(g2, state, dataArea, info, plot, rangeAxis, domainAxis, dataset, series, item, crosshairState, pass);
        verify(dataset, times(1)).getYValue(series, item);
        verifyNoInteractions(g2);
    }
}