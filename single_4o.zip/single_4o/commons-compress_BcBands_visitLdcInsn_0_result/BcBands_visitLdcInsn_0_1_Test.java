package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BcBands_visitLdcInsn_0_1_Test {

    @Test
    @DisplayName("Verify handling an integer constant with wide index")
    public void testTC01() throws Exception {
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(new CpBands(segment), segment, 0);

        // Reflectively set segment's lastConstantHadWideIndex to true
        segment.setLastConstantHadWideIndex(true);

        CPInt intConstant = new CPInt(42); // Example value
        bcBands.visitLdcInsn(intConstant);

        // Verify assertion: bcCodes should contain 237 and bcIntref should contain the CPInt constant
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(237), "bcCodes should contain 237");

        Field bcIntrefField = BcBands.class.getDeclaredField("bcIntref");
        bcIntrefField.setAccessible(true);
        List<CPInt> bcIntref = (List<CPInt>) bcIntrefField.get(bcBands);
        assertTrue(bcIntref.contains(intConstant), "bcIntref should contain the CPInt constant");
    }

    @Test
    @DisplayName("Verify handling a float constant with non-wide index")
    public void testTC02() throws Exception {
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(new CpBands(segment), segment, 0);

        segment.setLastConstantHadWideIndex(false);

        CPFloat floatConstant = new CPFloat(3.14f); // Example value
        bcBands.visitLdcInsn(floatConstant);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(235), "bcCodes should contain 235");

        Field bcFloatRefField = BcBands.class.getDeclaredField("bcFloatRef");
        bcFloatRefField.setAccessible(true);
        List<CPFloat> bcFloatRef = (List<CPFloat>) bcFloatRefField.get(bcBands);
        assertTrue(bcFloatRef.contains(floatConstant), "bcFloatRef should contain the CPFloat constant");
    }

    @Test
    @DisplayName("Verify handling a long constant with wide index")
    public void testTC03() throws Exception {
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(new CpBands(segment), segment, 0);

        segment.setLastConstantHadWideIndex(true);

        CPLong longConstant = new CPLong(42L); // Example value
        bcBands.visitLdcInsn(longConstant);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(20), "bcCodes should contain 20");

        Field bcLongRefField = BcBands.class.getDeclaredField("bcLongRef");
        bcLongRefField.setAccessible(true);
        List<CPLong> bcLongRef = (List<CPLong>) bcLongRefField.get(bcBands);
        assertTrue(bcLongRef.contains(longConstant), "bcLongRef should contain the CPLong constant");
    }

    @Test
    @DisplayName("Verify handling a double constant with wide index")
    public void testTC04() throws Exception {
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(new CpBands(segment), segment, 0);

        segment.setLastConstantHadWideIndex(true);

        CPDouble doubleConstant = new CPDouble(3.14); // Example value
        bcBands.visitLdcInsn(doubleConstant);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(239), "bcCodes should contain 239");

        Field bcDoubleRefField = BcBands.class.getDeclaredField("bcDoubleRef");
        bcDoubleRefField.setAccessible(true);
        List<CPDouble> bcDoubleRef = (List<CPDouble>) bcDoubleRefField.get(bcBands);
        assertTrue(bcDoubleRef.contains(doubleConstant), "bcDoubleRef should contain the CPDouble constant");
    }

    @Test
    @DisplayName("Verify handling a string constant with wide index")
    public void testTC05() throws Exception {
        Segment segment = new Segment();
        BcBands bcBands = new BcBands(new CpBands(segment), segment, 0);

        segment.setLastConstantHadWideIndex(true);

        CPString stringConstant = new CPString("test"); // Example value
        bcBands.visitLdcInsn(stringConstant);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        assertTrue(bcCodes.contains(19), "bcCodes should contain 19");

        Field bcStringRefField = BcBands.class.getDeclaredField("bcStringRef");
        bcStringRefField.setAccessible(true);
        List<CPString> bcStringRef = (List<CPString>) bcStringRefField.get(bcBands);
        assertTrue(bcStringRef.contains(stringConstant), "bcStringRef should contain the CPString constant");
    }
}