import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.FieldUnivariateFunction;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.solvers.FieldBracketingNthOrderBrentSolver;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.util.Decimal64;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

public class FieldBracketingNthOrderBrentSolverTest {

    @Test
    void testSolve_NullFunction_ThrowsNullArgumentException() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        assertThrows(NullArgumentException.class, () -> 
            solver.solve(100, null, new Decimal64(-1), new Decimal64(1), new Decimal64(0), AllowedSolution.ANY_SIDE)
        );
    }

    @Test
    void testSolve_StartValueIsRoot_ReturnsStartValue() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> x.getReal() == 0.0 ? new Decimal64(0.0) : new Decimal64(1.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0), AllowedSolution.ANY_SIDE);
        assertEquals(0.0, result.getReal(), 0.0);
    }

    @Test
    void testSolve_MinIsRoot_ReturnsMin() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> x.getReal() == -1.0 ? new Decimal64(0.0) : new Decimal64(1.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0), AllowedSolution.ANY_SIDE);
        assertEquals(-1.0, result.getReal(), 0.0);
    }

    @Test
    void testSolve_MaxIsRoot_ReturnsMax() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> x.getReal() == 1.0 ? new Decimal64(0.0) : new Decimal64(1.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0), AllowedSolution.ANY_SIDE);
        assertEquals(1.0, result.getReal(), 0.0);
    }

    @Test
    void testSolve_NoBracketing_ThrowsNoBracketingException() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(1.0);
        assertThrows(NoBracketingException.class, () -> 
            solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0), AllowedSolution.ANY_SIDE)
        );
    }

    @Test
    void testSolve_BracketsRoot_Y0Y1LessThanZero() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal());
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0.5), AllowedSolution.ANY_SIDE);
        assertEquals(0.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_BracketsRoot_Y1Y2LessThanZero() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal() - 1.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(0), new Decimal64(2), new Decimal64(1.5), AllowedSolution.ANY_SIDE);
        assertEquals(1.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_ConvergenceByXtol_ReturnsCorrectSolution() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal()-2.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(1.999999), new Decimal64(2.000001), new Decimal64(2.0), AllowedSolution.ANY_SIDE);
        assertEquals(2.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_ConvergenceByFunctionValueAccuracy_ReturnsCorrectSolution() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(Math.pow(x.getReal(), 2) - 4.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(1.9), new Decimal64(2.1), new Decimal64(2.0), AllowedSolution.ANY_SIDE);
        assertEquals(2.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_AllowedSolution_LeftSide_ReturnsXA() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal());
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0.5), AllowedSolution.LEFT_SIDE);
        assertEquals(-1.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_AllowedSolution_RightSide_ReturnsXB() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal());
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0.5), AllowedSolution.RIGHT_SIDE);
        assertEquals(1.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_AllowedSolution_BelowSide_ReturnsCorrectSide() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal());
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0.5), AllowedSolution.BELOW_SIDE);
        assertEquals(-1.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_AllowedSolution_AboveSide_ReturnsCorrectSide() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        // f(x) = x, root at 0, yA <0, so ABOVE_SIDE should return xB=1
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal());
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0.5), AllowedSolution.ABOVE_SIDE);
        assertEquals(1.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_MaximalAging_ComputesTargetYCorrectly() {
        // This test is complex to setup; it would require simulating aging
        // For simplicity, ensure that the solver does not throw and finds the root
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                new Decimal64(1e-10),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal() * x.getReal() - 1.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(0.5), new Decimal64(2.0), new Decimal64(1.5), AllowedSolution.ANY_SIDE);
        assertEquals(1.0, result.getReal(), 1e-10);
    }

    @Test
    void testSolve_GuessXFails_UsesBisection() {
        // Define a function where inverse polynomial interpolation cannot guess correctly
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                2
        );
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(Math.sin(x.getReal()));
        Decimal64 result = solver.solve(100, f, new Decimal64(3), new Decimal64(4), new Decimal64(3.5), AllowedSolution.ANY_SIDE);
        assertEquals(Math.PI, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_ExactRootFound_ReturnsExactRoot() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        FieldUnivariateFunction<Decimal64> f = x -> {
            if (x.getReal() == 2.0) {
                return new Decimal64(0.0);
            } else {
                return new Decimal64(x.getReal() - 2.0);
            }
        };
        Decimal64 result = solver.solve(100, f, new Decimal64(1.0), new Decimal64(3.0), new Decimal64(2.0), AllowedSolution.ANY_SIDE);
        assertEquals(2.0, result.getReal(), 0.0);
    }

    @Test
    void testSolve_InvalidMaximalOrder_ThrowsNumberIsTooSmallException() {
        Executable constructor = () -> new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                1
        );
        assertThrows(NumberIsTooSmallException.class, constructor);
    }

    @Test
    void testSolve_FunctionNeverZero_ReturnsAllowedSolution() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                new Decimal64(1e-6),
                5
        );
        // f(x) = x + 1, root at -1 which is min
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(x.getReal() + 1.0);
        Decimal64 result = solver.solve(100, f, new Decimal64(-1), new Decimal64(1), new Decimal64(0), AllowedSolution.ANY_SIDE);
        assertEquals(-1.0, result.getReal(), 1e-6);
    }

    @Test
    void testSolve_MultipleRoots_BracketsCorrectly() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-8),
                new Decimal64(1e-8),
                new Decimal64(1e-8),
                5
        );
        // f(x) = (x-1)(x-2)(x-3), roots at 1,2,3
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64((x.getReal()-1)*(x.getReal()-2)*(x.getReal()-3));
        // Bracket around 2
        Decimal64 result = solver.solve(100, f, new Decimal64(1.5), new Decimal64(2.5), new Decimal64(2.0), AllowedSolution.ANY_SIDE);
        assertEquals(2.0, result.getReal(), 1e-8);
    }

    @Test
    void testSolve_FuncitonValueAccuracyNotMet_MaxIterationsReached() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-20),
                new Decimal64(1e-20),
                new Decimal64(1e-20),
                5
        );
        // f(x) = x^3, root at 0
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(Math.pow(x.getReal(), 3));
        Decimal64 result = solver.solve(10, f, new Decimal64(-1e-10), new Decimal64(1e-10), new Decimal64(0), AllowedSolution.ANY_SIDE);
        assertTrue(Math.abs(result.getReal()) <= 1e-10);
    }

    @Test
    void testSolve_MaxEvaluationsExceeded() {
        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
                new Decimal64(1e-15),
                new Decimal64(1e-15),
                new Decimal64(1e-15),
                5
        );
        // f(x) = sin(x), root at multiples of pi
        FieldUnivariateFunction<Decimal64> f = x -> new Decimal64(Math.sin(x.getReal()));
        assertThrows(NoBracketingException.class, () -> 
            solver.solve(0, f, new Decimal64(3.0), new Decimal64(4.0), new Decimal64(3.5), AllowedSolution.ANY_SIDE)
        );
    }
}