package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_remove_0_3_Test {

    @Test
    @DisplayName("Attempt to remove null key when size is three but no keys are null")
    void TC11_removeNullKeyWhenSizeThreeNoNullKeys() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set private fields via reflection
        setPrivateField(map, "size", 3);
        setPrivateField(map, "key1", "Key1");
        setPrivateField(map, "key2", "Key2");
        setPrivateField(map, "key3", "Key3");
        setPrivateField(map, "value1", "Value1");
        setPrivateField(map, "value2", "Value2");
        setPrivateField(map, "value3", "Value3");
        setPrivateField(map, "hash1", "Key1".hashCode());
        setPrivateField(map, "hash2", "Key2".hashCode());
        setPrivateField(map, "hash3", "Key3".hashCode());

        // Perform the remove operation
        Object result = map.remove(null);

        // Assertions
        assertNull(result, "Result should be null when removing a non-existent null key.");
        assertEquals(3, getPrivateField(map, "size"), "Size should remain unchanged.");
        assertEquals("Key1", getPrivateField(map, "key1"), "Key1 should remain unchanged.");
        assertEquals("Key2", getPrivateField(map, "key2"), "Key2 should remain unchanged.");
        assertEquals("Key3", getPrivateField(map, "key3"), "Key3 should remain unchanged.");
    }

    @Test
    @DisplayName("Remove existing non-null key when size is one")
    void TC12_removeExistingKeyWhenSizeOne() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set private fields via reflection
        setPrivateField(map, "size", 1);
        setPrivateField(map, "key1", "MatchingKey");
        setPrivateField(map, "value1", "ExpectedValue1");
        setPrivateField(map, "hash1", "MatchingKey".hashCode());

        // Perform the remove operation
        Object result = map.remove("MatchingKey");

        // Assertions
        assertEquals("ExpectedValue1", result, "Removed value should match the expected value.");
        assertNull(getPrivateField(map, "key1"), "Key1 should be null after removal.");
        assertEquals(0, getPrivateField(map, "size"), "Size should be zero after removal.");
    }

    // Helper method to set private fields via reflection
    private void setPrivateField(Flat3Map<Object, Object> map, String fieldName, Object value) throws Exception {
        Field field = Flat3Map.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(map, value);
    }

    // Helper method to get private fields via reflection
    private Object getPrivateField(Flat3Map<Object, Object> map, String fieldName) throws Exception {
        Field field = Flat3Map.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(map);
    }
}