package com.fasterxml.jackson.databind.util;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TokenBuffer_serialize_0_5_Test {

    @Test
    @DisplayName("serialize with multiple VALUE_NUMBER_FLOAT tokens of different numeric types")
    void TC21_serialize_multiple_VALUE_NUMBER_FLOAT_tokens_different_types() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNumber(3.14);
        buffer.writeNumber(new BigDecimal("2.71828"));
        buffer.writeNumber(1.618f);
        // Add invalid token using a valid public method
        buffer.writeNumber(new BigDecimal("invalid"));  // Safe casting to BigDecimal
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        assertThrows(RuntimeException.class, () -> buffer.serialize(gen));

        // THEN
        verify(gen).writeNumber(3.14);
        verify(gen).writeNumber(new BigDecimal("2.71828"));
        verify(gen).writeNumber(1.618f);
    }

    @Test
    @DisplayName("serialize with VALUE_NUMBER_FLOAT token as Float")
    void TC22_serialize_VALUE_NUMBER_FLOAT_as_Float() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNumber(9.81f);
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeNumber(9.81f);
    }

    @Test
    @DisplayName("serialize with VALUE_EMBEDDED_OBJECT token as null")
    void TC23_serialize_VALUE_EMBEDDED_OBJECT_as_null() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeObject(null);
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeEmbeddedObject(null);
    }

    @Test
    @DisplayName("serialize with multiple iterations looping exactly 16 tokens")
    void TC24_serialize_exactly_16_tokens_loop() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        for(int i = 0; i < 16; i++) {
            buffer.writeNumber(i);
        }
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        for(int i = 0; i < 16; i++) {
            verify(gen).writeNumber(i);
        }
    }

    @Test
    @DisplayName("serialize with loop exceeding 16 tokens leading to multiple segments")
    void TC25_serialize_exceeding_16_tokens_multiple_segments() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        for(int i = 0; i < 17; i++) {
            buffer.writeNumber(i);
        }
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        for(int i = 0; i < 17; i++) {
            verify(gen).writeNumber(i);
        }
    }
}