package org.jfree.chart;

import java.awt.event.ActionEvent;
import java.awt.geom.Point2D;
import java.lang.reflect.Field;

import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.Zoomable;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ChartPanel_actionPerformed_1_1_Test {
    
    @Mock
    private JFreeChart mockChart;

    @Mock
    private Plot mockPlot;

    @Mock
    private Zoomable mockZoomablePlot;

    @InjectMocks
    private ChartPanel chartPanel;

//     @Test
//     @DisplayName("Test: actionPerformed with command 'ZOOM_RESET_DOMAIN' and zoomPoint is null")
//     void testActionPerformed_ZOOM_RESET_DOMAIN_ZoomPointNull() throws Exception {
        // Arrange
//         ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "ZOOM_RESET_DOMAIN");
//         when(mockChart.getPlot()).thenReturn(mockZoomablePlot);
//         when(mockZoomablePlot.isNotify()).thenReturn(true);
// 
        // Act
//         chartPanel.setChart(mockChart);
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, null);
//         chartPanel.actionPerformed(event);
// 
        // Assert
//         verify(mockZoomablePlot, times(1)).zoomDomainAxes(eq(0.0), any(), any(Point2D.class));
//     }

//     @Test
//     @DisplayName("Test: actionPerformed with command 'ZOOM_RESET_RANGE' and zoomPoint is null")
//     void testActionPerformed_ZOOM_RESET_RANGE_ZoomPointNull() throws Exception {
        // Arrange
//         ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "ZOOM_RESET_RANGE");
//         when(mockChart.getPlot()).thenReturn(mockZoomablePlot);
//         when(mockZoomablePlot.isNotify()).thenReturn(true);
// 
        // Act
//         chartPanel.setChart(mockChart);
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, null);
//         chartPanel.actionPerformed(event);
// 
        // Assert
//         verify(mockZoomablePlot, times(1)).zoomRangeAxes(eq(0.0), any(), any(Point2D.class));
//     }

    @Test
    @DisplayName("Test: actionPerformed with unrecognized command 'INVALID_COMMAND' and zoomPoint is null")
    void testActionPerformed_InvalidCommand_ZoomPointNull() throws Exception {
        // Arrange
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "INVALID_COMMAND");
        when(mockChart.getPlot()).thenReturn(mockPlot);

        // Act
        chartPanel.setChart(mockChart);
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(chartPanel, null);
        chartPanel.actionPerformed(event);

        // Assert
        verify(mockZoomablePlot, never()).zoomDomainAxes(anyDouble(), any(), any());
        verify(mockZoomablePlot, never()).zoomRangeAxes(anyDouble(), any(), any());
    }

//     @Test
//     @DisplayName("Test: actionPerformed with command 'ZOOM_RESET_DOMAIN' and zoomPoint is non-null")
//     void testActionPerformed_ZOOM_RESET_DOMAIN_ZoomPointNonNull() throws Exception {
        // Arrange
//         ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "ZOOM_RESET_DOMAIN");
//         when(mockChart.getPlot()).thenReturn(mockZoomablePlot);
//         when(mockZoomablePlot.isNotify()).thenReturn(true);
// 
        // Act
//         chartPanel.setChart(mockChart);
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         Point2D testPoint = new Point2D.Double(150.0, 250.0);
//         zoomPointField.set(chartPanel, testPoint);
//         chartPanel.actionPerformed(event);
// 
        // Assert
//         verify(mockZoomablePlot, times(1)).zoomDomainAxes(eq(0.0), any(), eq(testPoint));
//     }

//     @Test
//     @DisplayName("Test: actionPerformed with command 'ZOOM_RESET_RANGE' and zoomPoint is non-null")
//     void testActionPerformed_ZOOM_RESET_RANGE_ZoomPointNonNull() throws Exception {
        // Arrange
//         ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "ZOOM_RESET_RANGE");
//         when(mockChart.getPlot()).thenReturn(mockZoomablePlot);
//         when(mockZoomablePlot.isNotify()).thenReturn(true);
// 
        // Act
//         chartPanel.setChart(mockChart);
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         Point2D testPoint = new Point2D.Double(200.0, 300.0);
//         zoomPointField.set(chartPanel, testPoint);
//         chartPanel.actionPerformed(event);
// 
        // Assert
//         verify(mockZoomablePlot, times(1)).zoomRangeAxes(eq(0.0), any(), eq(testPoint));
//     }
}