package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.codec.EncoderException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Nysiis_nysiis_0_2_Test {

    @Test
    @DisplayName("Input containing non-applicable characters returns same encoded string")
    public void testTC06_UnchangedInput() {
        // GIVEN
        Nysiis nysiis = new Nysiis();
        String input = "XYZ";
        // WHEN
        String result = nysiis.nysiis(input);
        // THEN
        assertEquals("XYZ", result, "The encoded result should be the same as the input");
    }

    @Test
    @DisplayName("Last 'S' in the encoded string is removed")
    public void testTC07_RemovalOfLastS() {
        // GIVEN
        Nysiis nysiis = new Nysiis();
        String input = "ROBERTS";
        // WHEN
        String result = nysiis.nysiis(input);
        // THEN
        assertEquals("ROBERT", result, "The encoded result should not end with 'S'");
    }

    @Test
    @DisplayName("Last 'AY' in the encoded string is replaced with 'Y'")
    public void testTC08_ReplacementOfLastAY() {
        // GIVEN
        Nysiis nysiis = new Nysiis();
        String input = "MAY";
        // WHEN
        String result = nysiis.nysiis(input);
        // THEN
        assertEquals("MY", result, "The encoded result should end with 'Y'");
    }

    @Test
    @DisplayName("Last character 'A' is removed if strict mode is enabled")
    public void testTC09_StrictRemovalOfLastA() {
        // GIVEN
        Nysiis nysiis = new Nysiis(true);
        String input = "ALMA";
        // WHEN
        String result = nysiis.nysiis(input);
        // THEN
        assertEquals("ALM", result, "The encoded result should not end with 'A'");
    }

    @Test
    @DisplayName("Returns string not exceeding max length in strict mode")
    public void testTC10_StrictLengthCheck() {
        // GIVEN
        Nysiis nysiis = new Nysiis(true);
        String input = "ALAMOANA";
        // WHEN
        String result = nysiis.nysiis(input);
        // THEN
        assertTrue(result.length() <= 6, "The encoded result should not exceed length of 6 in strict mode");
    }
}