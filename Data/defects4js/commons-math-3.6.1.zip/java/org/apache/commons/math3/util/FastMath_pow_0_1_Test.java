package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FastMath_pow_0_1_Test {

    @Test
    @DisplayName("pow(x, 0) returns 1.0 when y is +0")
    void TC01_pow_y_zero() {
        // GIVEN
        double x = 2.0;
        double y = 0.0;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertEquals(1.0, result, "pow(x, 0) should return 1.0");
    }

    @Test
    @DisplayName("pow(x, -0.0) returns 1.0 when y is -0")
    void TC02_pow_y_negative_zero() {
        // GIVEN
        double x = 3.0;
        double y = -0.0;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertEquals(1.0, result, "pow(x, -0.0) should return 1.0");
    }

    @Test
    @DisplayName("pow(x, y) returns NaN when y is NaN")
    void TC03_pow_y_nan() {
        // GIVEN
        double x = 2.0;
        double y = Double.NaN;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertTrue(Double.isNaN(result), "pow(x, NaN) should return NaN");
    }

    @Test
    @DisplayName("pow(NaN, y) returns NaN when x is NaN and y is not 0")
    void TC04_pow_x_nan() {
        // GIVEN
        double x = Double.NaN;
        double y = 2.0;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertTrue(Double.isNaN(result), "pow(NaN, y) should return NaN when y is not 0");
    }

    @Test
    @DisplayName("pow(1.0, y) returns 1.0 for finite y")
    void TC05_pow_one_to_any_finite_y() {
        // GIVEN
        double x = 1.0;
        double y = 1000.0;
        
        // WHEN
        double result = FastMath.pow(x, y);
        
        // THEN
        assertEquals(1.0, result, "pow(1.0, y) should return 1.0 for any finite y");
    }
}