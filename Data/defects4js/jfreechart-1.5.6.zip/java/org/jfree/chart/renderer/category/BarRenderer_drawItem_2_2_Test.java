package org.jfree.chart.renderer.category;

import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.Color;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BarRenderer_drawItem_2_2_Test {

    @Mock
    private Graphics2D g2;

    @Mock
    private CategoryItemRendererState state;

    @Mock
    private Rectangle2D dataArea;

    @Mock
    private CategoryPlot plot;

    @Mock
    private CategoryAxis domainAxis;

    @Mock
    private ValueAxis rangeAxis;

    @Mock
    private CategoryDataset dataset;

    @InjectMocks
    private BarRenderer renderer;

    @Test
    @DisplayName("drawItem draws bar correctly with rectangle outline enabled")
    void TC09_drawItem_withOutline() throws Exception {
        int row = 5;
        int column = 5;
        double barValue = 30.0;
        double[] barL0L1 = {0.0, 30.0};

        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(dataset.getValue(row, column)).thenReturn(barValue);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.calculateBarL0L1(barValue)).thenReturn(barL0L1);
        when(state.getBarWidth()).thenReturn(10.0);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(dataset.getRowCount()).thenReturn(10);
        when(dataset.getColumnCount()).thenReturn(10);

        renderer.setDrawBarOutline(true);

        doNothing().when(g2).draw(any(Rectangle2D.class));

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);

        verify(g2, atLeastOnce()).setPaint(any(Color.class));  // Specify Color
        ArgumentCaptor<Rectangle2D> rectangleCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(g2, atLeastOnce()).draw(rectangleCaptor.capture());
        Rectangle2D drawnBar = rectangleCaptor.getValue();
        assertNotNull(drawnBar);
    }

//     @Test
//     @DisplayName("drawItem draws item label correctly when label fits inside the bar")
//     void TC10_drawItem_label_fits_inside() throws Exception {
//         int row = 0;
//         int column = 0;
//         double barValue = 20.0;
//         double[] barL0L1 = {0.0, 20.0};
//         String label = "Label";
// 
//         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
//         when(dataset.getValue(row, column)).thenReturn(barValue);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(renderer.calculateBarL0L1(barValue)).thenReturn(barL0L1);
//         when(state.getBarWidth()).thenReturn(10.0);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(dataset.getRowCount()).thenReturn(1);
//         when(dataset.getColumnCount()).thenReturn(1);
//         CategoryItemLabelGenerator labelGenerator = mock(CategoryItemLabelGenerator.class);
//         when(renderer.getItemLabelGenerator(row, column)).thenReturn(labelGenerator);
//         when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
//         when(labelGenerator.generateLabel(dataset, row, column)).thenReturn(label);
//         when(renderer.calculateLabelAnchorPoint(any(), any(), eq(PlotOrientation.VERTICAL))).thenReturn(new Point2D.Double(5.0, 5.0));
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// 
        // Assert
//         verify(renderer).drawItemLabel(eq(g2), eq(dataset), eq(row), eq(column), eq(plot), eq(labelGenerator), any(Rectangle2D.class), eq(false));
//     }

//     @Test
//     @DisplayName("drawItem uses fallback position when item label does not fit inside the bar")
//     void TC11_drawItem_label_fallback_position() throws Exception {
//         int row = 0;
//         int column = 0;
//         double barValue = 20.0;
//         double[] barL0L1 = {0.0, 20.0};
//         String longLabel = "VeryLongLabelThatDoesNotFit";
// 
//         when(state.getVisibleSeriesIndex(row)).thenReturn(row);
//         when(dataset.getValue(row, column)).thenReturn(barValue);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(renderer.getLowerClip()).thenReturn(0.0);
//         when(renderer.getUpperClip()).thenReturn(100.0);
//         when(renderer.calculateBarL0L1(barValue)).thenReturn(barL0L1);
//         when(state.getBarWidth()).thenReturn(10.0);
//         when(state.getVisibleSeriesCount()).thenReturn(1);
//         when(dataset.getRowCount()).thenReturn(1);
//         when(dataset.getColumnCount()).thenReturn(1);
//         CategoryItemLabelGenerator labelGenerator = mock(CategoryItemLabelGenerator.class);
//         ItemLabelPosition fallbackPosition = mock(ItemLabelPosition.class);
// 
//         when(renderer.getItemLabelGenerator(row, column)).thenReturn(labelGenerator);
//         when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
//         when(labelGenerator.generateLabel(dataset, row, column)).thenReturn(longLabel);
//         when(renderer.calculateLabelAnchorPoint(any(), any(), eq(PlotOrientation.VERTICAL))).thenReturn(new Point2D.Double(100.0, 100.0));
//         when(renderer.getPositiveItemLabelPositionFallback()).thenReturn(fallbackPosition);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
// 
        // Assert
//         verify(renderer).drawItemLabel(eq(g2), eq(dataset), eq(row), eq(column), eq(plot), eq(labelGenerator), any(Rectangle2D.class), eq(true));
//         verify(renderer).calculateLabelAnchorPoint(any(), any(), eq(PlotOrientation.VERTICAL));
//         verify(renderer).getPositiveItemLabelPositionFallback();
//     }
}