package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_2_Test {

    @Test
    @DisplayName("Input with 'P' before 'H', should assign code '3'")
    void TC06() {
        // Given
        String input = "Phantom";

        // When
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("3"), "The result should contain '3' for 'PH' sequence");
    }

    @Test
    @DisplayName("Input with 'D' before 'C', should assign code '2'")
    void TC07() {
        // Given
        String input = "Dictate";

        // When
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("2"), "The result should contain '2' for 'D' before 'C'");
    }

    @Test
    @DisplayName("Input with 'D' before 'S', should assign code '2'")
    void TC08() {
        // Given
        String input = "Dust";

        // When
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("2"), "The result should contain '2' for 'D' before 'S'");
    }

    @Test
    @DisplayName("Input with 'X' not after 'C', should assign code '4' and add 'S'")
    void TC09() {
        // Given
        String input = "Axel";

        // When
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("4S"), "The result should contain '4S' for 'X' not after 'C'");
    }

    @Test
    @DisplayName("Input with 'X' after 'C', should assign code '48' without adding 'S'")
    void TC10() {
        // Given
        String input = "Complex";

        // When
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String result = colognePhonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("48"), "The result should contain '48' for 'X' after 'C'");
    }
}