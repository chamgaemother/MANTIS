package org.apache.commons.math3.stat.ranking;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NaturalRanking_rank_2_1_Test {

    @Test
    @DisplayName("rank with FIXED strategy and no NaNs does not modify any elements")
    public void TC19_rankWithFixedStrategyNoNaNs() throws Exception {
        // Given
        double[] data = {1.0, 2.0, 3.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.FIXED, TiesStrategy.AVERAGE);

        // When
        double[] result = ranking.rank(data);

        // Then
        assertEquals(1.0, result[0], "First element should have rank 1.0");
        assertEquals(2.0, result[1], "Second element should have rank 2.0");
        assertEquals(3.0, result[2], "Third element should have rank 3.0");
    }

    @Test
    @DisplayName("rank with FIXED strategy and all elements as NaN preserves all NaN positions")
    public void TC20_rankWithFixedStrategyAllNaNs() throws Exception {
        // Given
        double[] data = {Double.NaN, Double.NaN, Double.NaN};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.FIXED, TiesStrategy.AVERAGE);

        // When
        double[] result = ranking.rank(data);

        // Then
        assertTrue(Double.isNaN(result[0]), "First element should be NaN");
        assertTrue(Double.isNaN(result[1]), "Second element should be NaN");
        assertTrue(Double.isNaN(result[2]), "Third element should be NaN");
    }
}