package org.apache.commons.math3.stat.descriptive;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.apache.commons.math3.stat.descriptive.summary.Sum;
import org.apache.commons.math3.analysis.function.Min;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class SummaryStatistics_copy_1_1_Test {

    @Test
    @DisplayName("copy assigns min from minImpl when source.min equals minImpl")
    void TC14_copyAssignsMinFromMinImpl_whenMinEqualsMinImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to set source.min = source.minImpl
        Field minField = SummaryStatistics.class.getDeclaredField("min");
        Field minImplField = SummaryStatistics.class.getDeclaredField("minImpl");
        minField.setAccessible(true);
        minImplField.setAccessible(true);
        minField.set(source, minImplField.get(source));

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destMinField = SummaryStatistics.class.getDeclaredField("min");
        Field destMinImplField = SummaryStatistics.class.getDeclaredField("minImpl");
        destMinField.setAccessible(true);
        destMinImplField.setAccessible(true);
        Object destMin = destMinField.get(dest);
        Object destMinImpl = destMinImplField.get(dest);
        assertSame(destMinImpl, destMin, "dest.min should be assigned from dest.minImpl");
    }

    @Test
    @DisplayName("copy copies min when source.min does not equal minImpl")
    void TC15_copyCopiesMin_whenMinDoesNotEqualMinImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to set source.min != source.minImpl
        Field minField = SummaryStatistics.class.getDeclaredField("min");
        Field minImplField = SummaryStatistics.class.getDeclaredField("minImpl");
        minField.setAccessible(true);
        minImplField.setAccessible(true);
        minField.set(source, new Min());
        minImplField.set(source, new Min());

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destMinField = SummaryStatistics.class.getDeclaredField("min");
        Object destMin = destMinField.get(dest);
        assertNotSame(source.getMin(), destMin, "dest.min should be a copy of source.min");
    }

    @Test
    @DisplayName("copy assigns sum from sumImpl when source.sum equals sumImpl")
    void TC16_copyAssignsSumFromSumImpl_whenSumEqualsSumImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to set source.sum = source.sumImpl
        Field sumField = SummaryStatistics.class.getDeclaredField("sum");
        Field sumImplField = SummaryStatistics.class.getDeclaredField("sumImpl");
        sumField.setAccessible(true);
        sumImplField.setAccessible(true);
        sumField.set(source, sumImplField.get(source));

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destSumField = SummaryStatistics.class.getDeclaredField("sum");
        Field destSumImplField = SummaryStatistics.class.getDeclaredField("sumImpl");
        destSumField.setAccessible(true);
        destSumImplField.setAccessible(true);
        Object destSum = destSumField.get(dest);
        Object destSumImpl = destSumImplField.get(dest);
        assertSame(destSumImpl, destSum, "dest.sum should be assigned from dest.sumImpl");
    }

    @Test
    @DisplayName("copy copies sum when source.sum does not equal sumImpl")
    void TC17_copyCopiesSum_whenSumDoesNotEqualSumImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to set source.sum != source.sumImpl
        Field sumField = SummaryStatistics.class.getDeclaredField("sum");
        Field sumImplField = SummaryStatistics.class.getDeclaredField("sumImpl");
        sumField.setAccessible(true);
        sumImplField.setAccessible(true);
        sumField.set(source, new Sum());
        sumImplField.set(source, new Sum());

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destSumField = SummaryStatistics.class.getDeclaredField("sum");
        Object destSum = destSumField.get(dest);
        assertNotSame(source.getSum(), destSum, "dest.sum should be a copy of source.sum");
    }

    @Test
    @DisplayName("copy assigns sumLog from sumLogImpl when source.sumLog equals sumLogImpl")
    void TC18_copyAssignsSumLogFromSumLogImpl_whenSumLogEqualsSumLogImpl() throws Exception {
        // GIVEN
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();

        // Use reflection to set source.sumLog = source.sumLogImpl
        Field sumLogField = SummaryStatistics.class.getDeclaredField("sumLog");
        Field sumLogImplField = SummaryStatistics.class.getDeclaredField("sumLogImpl");
        sumLogField.setAccessible(true);
        sumLogImplField.setAccessible(true);
        sumLogField.set(source, sumLogImplField.get(source));

        // WHEN
        SummaryStatistics.copy(source, dest);

        // THEN
        Field destSumLogField = SummaryStatistics.class.getDeclaredField("sumLog");
        Field destSumLogImplField = SummaryStatistics.class.getDeclaredField("sumLogImpl");
        destSumLogField.setAccessible(true);
        destSumLogImplField.setAccessible(true);
        Object destSumLog = destSumLogField.get(dest);
        Object destSumLogImpl = destSumLogImplField.get(dest);
        assertSame(destSumLogImpl, destSumLog, "dest.sumLog should be assigned from dest.sumLogImpl");
    }
}