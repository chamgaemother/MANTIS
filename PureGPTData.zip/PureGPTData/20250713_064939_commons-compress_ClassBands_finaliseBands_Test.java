import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.apache.commons.compress.harmony.pack200.*;

import java.util.*;

public class ClassBandsTest {

    private ClassBands classBands;
    private Segment segment;
    private SegmentHeader segmentHeader;

    @BeforeEach
    public void setup() throws Exception {
        segment = mock(Segment.class);
        segmentHeader = mock(SegmentHeader.class);
        when(segment.getSegmentHeader()).thenReturn(segmentHeader);
        when(segmentHeader.getDefaultMajorVersion()).thenReturn(50);
        when(segmentHeader.have_class_flags_hi()).thenReturn(false);
        when(segmentHeader.have_method_flags_hi()).thenReturn(false);
        when(segmentHeader.have_field_flags_hi()).thenReturn(false);
        when(segmentHeader.have_all_code_flags()).thenReturn(false);
        classBands = new ClassBands(segment, 10, 5, false);
        
        CpBands cpBands = mock(CpBands.class);
        when(segment.getCpBands()).thenReturn(cpBands);
    }

    @Test
    public void testFinaliseBandsWithNoClasses() {
        classBands.finaliseBands();
        assertEquals(0, classBands.numClassesProcessed());
    }

    @Test
    public void testFinaliseBandsWithMajorVersionDifferences() {
        classBands.addClass(51, 0, "Test", null, "java/lang/Object", new String[]{});
        classBands.endOfClass();
        
        classBands.finaliseBands();
        
        assertEquals(1, classBands.numClassesProcessed());
        assertEquals(1, classBands.classFileVersionMajor.size());
        assertEquals(51, classBands.classFileVersionMajor.get(0));
    }

    @Test
    public void testFinaliseBandsWithNoHandlerAndMaxStackUnder12() {
        classBands.addMethod(0, "method", "()V", null, null);
        classBands.addMaxStack(10, 20);
        classBands.addCode();
        classBands.endOfMethod();
        classBands.endOfClass();
        
        classBands.finaliseBands();
        assertTrue(classBands.codeFlags.contains(0L));
    }

    @Test
    public void testFinaliseBandsWithHandler() {
        classBands.addMethod(0, "method", "()V", null, null);
        classBands.addMaxStack(10, 20);
        classBands.addCode();
        classBands.addHandler(new Label(), new Label(), new Label(), null);
        classBands.endOfMethod();
        classBands.endOfClass();
        
        classBands.finaliseBands();
        assertFalse(classBands.codeFlags.contains(0L));
    }

    @Test
    public void testFinaliseBandsWithIcTuple() {
        IcBands icBands = mock(IcBands.class);
        when(segment.getIcBands()).thenReturn(icBands);

        IcBands.IcTuple icTuple = mock(IcBands.IcTuple.class);
        when(icTuple.isAnonymous()).thenReturn(false);
        when(icBands.getIcTuple(any())).thenReturn(icTuple);

        classBands.addClass(50, 0, "Outer", null, "java/lang/Object", new String[]{});
        classBands.currentClassReferencesInnerClass(mock(CPClass.class));
        classBands.endOfClass();
        
        classBands.finaliseBands();
        
        assertTrue(classBands.class_InnerClasses_N.length > 0);
    }

    @Test
    public void testFinaliseBandsWithCodeFlagsAbsent() {
        when(segmentHeader.have_all_code_flags()).thenReturn(false);

        classBands.addMethod(0, "method", "()V", null, null);
        classBands.addMaxStack(10, 20);
        classBands.addCode();
        Label start = new Label();
        Label end = new Label();
        classBands.addHandler(start, end, new Label(), null);
        classBands.endOfMethod();
        classBands.endOfClass();
        
        classBands.finaliseBands();

        assertFalse(classBands.codeFlags.contains(0L));
    }
}