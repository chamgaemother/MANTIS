import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.util.GradientPaintTransformer;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.jfree.data.Range;

class XYBarRendererTest {

    private XYBarRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private IntervalXYDataset dataset;

    @BeforeEach
    public void setUp() {
        renderer = new XYBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0.0, 0.0, 400.0, 300.0);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = new NumberAxis("X");
        rangeAxis = new NumberAxis("Y");
        dataset = mock(IntervalXYDataset.class);

        when(plot.getDomainAxisForDataset(anyInt())).thenReturn(domainAxis);
        when(plot.getRangeAxisForDataset(anyInt())).thenReturn(rangeAxis);
    }

    @Test
    public void testDrawItem_ItemNotVisible() {
        // Test item not visible
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 1);
        verifyZeroInteractions(g2); // No drawing occurs
    }

    @Test
    public void testDrawItem_NaNValues() {
        // Both value0 and value1 are NaN
        when(dataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndYValue(0, 0)).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 1);
        verifyZeroInteractions(g2); // No drawing occurs
    }

    @Test
    public void testDrawItem_InvalidRange() {
        // Values outside of range
        when(dataset.getStartYValue(0, 0)).thenReturn(-10.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(-5.0);
        when(rangeAxis.getRange()).thenReturn(new Range(0.0, 10.0));
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 1);
        verifyZeroInteractions(g2); // No drawing occurs
    }

    @Test
    public void testDrawItem_DrawsNormalBar() {
        // Normal bar within range
        when(dataset.getStartYValue(0, 0)).thenReturn(2.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(5.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> (double) invocation.getArgument(0));
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> (double) invocation.getArgument(0) * 100);

        doNothing().when(g2).draw(any());
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 1);

        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawItem_DrawsNegativeBar() {
        // Negative bar check
        when(dataset.getStartYValue(0, 0)).thenReturn(-5.0);
        when(dataset.getEndYValue(0, 0)).thenReturn(-2.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(2.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> 300 - (double) invocation.getArgument(0));
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenAnswer(invocation -> (double) invocation.getArgument(0) * 100);

        doNothing().when(g2).draw(any());
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 1);

        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawItem_NullDataset() {
        // Dataset is null
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, 0, 0, null, 1);
        verifyZeroInteractions(g2); // No drawing occurs
    }
}