package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Md5Crypt_md5Crypt_1_1_Test {

    @Test
    @DisplayName("md5Crypt with null keyBytes throws NullPointerException")
    void testTC16() {
        byte[] keyBytes = null;
        String salt = "$1$salt1234";
        String prefix = "$1$";

        assertThrows(NullPointerException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        });
    }

    @Test
    @DisplayName("md5Crypt with salt starting with prefix but empty salt group throws IllegalArgumentException")
    void testTC17() {
        byte[] keyBytes = "password".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String salt = "$1$$";
        String prefix = "$1$";

        assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        });
    }

    @Test
    @DisplayName("md5Crypt with salt containing minimum allowed characters processes correctly")
    void testTC18() {
        byte[] keyBytes = "password".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String salt = "$1$a";
        String prefix = "$1$";

        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(hash);
        assertTrue(hash.startsWith("$1$a$"));
        // Further assertions based on expected hash format can be added here
    }

    @Test
    @DisplayName("md5Crypt with custom prefix and valid salt generates hash with specified prefix")
    void testTC19() {
        byte[] keyBytes = "customprefix".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String salt = "$custom$salt123";
        String prefix = "$custom$";

        String hash = Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        assertNotNull(hash);
        assertTrue(hash.startsWith("$custom$salt123$"));
        // Further assertions based on expected hash format can be added here
    }

    @Test
    @DisplayName("md5Crypt with salt exceeding maximum length throws IllegalArgumentException")
    void testTC20() {
        byte[] keyBytes = "password".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String salt = "$1$toolongsalt12345$";
        String prefix = "$1$";

        assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        });
    }
}