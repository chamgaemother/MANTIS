package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_4_Test {

    @Test
    @DisplayName("metaphone word ending with 'MB' makes 'B' silent")
    void TC16_metaphone_MB_ending() {
        // Given
        Metaphone metaphone = new Metaphone();
        String txt = "lamb";
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("LM", result);
    }

    @Test
    @DisplayName("metaphone word with 'SH' converts to 'X'")
    void TC17_metaphone_SH_sequence() {
        // Given
        Metaphone metaphone = new Metaphone();
        String txt = "she";
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("X", result);
    }

    @Test
    @DisplayName("metaphone word with multiple vowels at start")
    void TC18_metaphone_multiple_leading_vowels() {
        // Given
        Metaphone metaphone = new Metaphone();
        String txt = "aeiou";
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("AEIOU", result);
    }

    @Test
    @DisplayName("metaphone word exceeding maxCodeLen truncates to maxCodeLen")
    void TC19_metaphone_exceeds_maxCodeLen() {
        // Given
        Metaphone metaphone = new Metaphone();
        String txt = "metaphonetest";
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals(4, result.length());
        assertEquals("METP", result);
    }

    @Test
    @DisplayName("metaphone word with 'TIA' converts to 'X'")
    void TC20_metaphone_TIA_sequence() {
        // Given
        Metaphone metaphone = new Metaphone();
        String txt = "action";
        
        // When
        String result = metaphone.metaphone(txt);
        
        // Then
        assertEquals("AKXN", result);
    }
}