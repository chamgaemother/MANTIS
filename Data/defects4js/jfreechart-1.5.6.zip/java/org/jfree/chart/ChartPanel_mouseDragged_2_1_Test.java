package org.jfree.chart;
// import org.jfree.chart.ChartRenderingInfo;
// 
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.Zoomable;
// import org.jfree.chart.plot.Pannable;
// import org.jfree.chart.JFreeChart;
// import org.jfree.chart.event.ChartRenderingInfo;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import java.awt.event.MouseEvent;
// import java.awt.geom.Point2D;
// import java.lang.reflect.Field;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
public class ChartPanel_mouseDragged_2_1_Test {
// 
    // MockPlot is a custom Plot implementation to verify interactions
//     private static class MockPlot implements Zoomable, Pannable {
//         boolean domainPannable = false;
//         boolean rangePannable = false;
//         PlotOrientation orientation = PlotOrientation.VERTICAL;
//         boolean zoomDomainAxesCalled = false;
//         boolean zoomRangeAxesCalled = false;
//         boolean panDomainAxesCalled = false;
//         boolean panRangeAxesCalled = false;
// 
//         @Override
//         public boolean isDomainZoomable() {
//             return domainPannable;
//         }
// 
//         @Override
//         public boolean isRangeZoomable() {
//             return rangePannable;
//         }
// 
//         @Override
//         public PlotOrientation getOrientation() {
//             return orientation;
//         }
// 
//         @Override
//         public void zoomDomainAxes(double factor, ChartRenderingInfo info, Point2D source, boolean useAnchor) {
//             zoomDomainAxesCalled = true;
//         }
// 
//         @Override
//         public void zoomRangeAxes(double factor, ChartRenderingInfo info, Point2D source, boolean useAnchor) {
//             zoomRangeAxesCalled = true;
//         }
// 
//         @Override
//         public void panDomainAxes(double percent, ChartRenderingInfo info, Point2D source) {
//             panDomainAxesCalled = true;
//         }
// 
//         @Override
//         public void panRangeAxes(double percent, ChartRenderingInfo info, Point2D source) {
//             panRangeAxesCalled = true;
//         }
//     }
// 
    // Helper method to set private fields via reflection
//     private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
//         Field field = target.getClass().getDeclaredField(fieldName);
//         field.setAccessible(true);
//         field.set(target, value);
//     }
// 
    // Helper method to get private fields via reflection
//     private Object getPrivateField(Object target, String fieldName) throws Exception {
//         Field field = target.getClass().getDeclaredField(fieldName);
//         field.setAccessible(true);
//         return field.get(target);
//     }
// 
//     @Test
//     @DisplayName("mouseDragged does not perform panning when panLast is set but mouse movement delta is zero (dx=0, dy=0)")
//     void TC04_mouseDragged_NoPanningOnZeroDelta() throws Exception {
        // Arrange
//         MockPlot mockPlot = new MockPlot();
//         mockPlot.domainPannable = true;
//         mockPlot.rangePannable = true;
// 
        // Initialize ChartPanel with mockPlot
//         ChartPanel chartPanel = new ChartPanel(null);
//         setPrivateField(chartPanel, "chart", new JFreeChart(mockPlot));
//         setPrivateField(chartPanel, "panLast", new Point2D.Double(100, 100));
//         setPrivateField(chartPanel, "panW", 50.0);
//         setPrivateField(chartPanel, "panH", 50.0);
// 
        // Create MouseEvent with zero movement
//         MouseEvent mouseEvent = new MouseEvent(chartPanel, MouseEvent.MOUSE_DRAGGED, System.currentTimeMillis(), 0, 100, 100, 0, false);
// 
        // Act
//         chartPanel.mouseDragged(mouseEvent);
// 
        // Assert
//         assertFalse(mockPlot.panDomainAxesCalled, "panDomainAxes should not be called");
//         assertFalse(mockPlot.panRangeAxesCalled, "panRangeAxes should not be called");
        // panLast should remain unchanged
//         Point2D panLast = (Point2D) getPrivateField(chartPanel, "panLast");
//         assertEquals(100, panLast.getX(), "panLast X should remain unchanged");
//         assertEquals(100, panLast.getY(), "panLast Y should remain unchanged");
//     }
// 
//     @Test
//     @DisplayName("mouseDragged performs zoom on the range axis only when only rangeZoomable is enabled")
//     void TC05_mouseDragged_ZoomRangeOnly() throws Exception {
        // Arrange
//         MockPlot mockPlot = new MockPlot();
//         mockPlot.domainPannable = false;
//         mockPlot.rangePannable = true;
//         mockPlot.orientation = PlotOrientation.VERTICAL;
// 
//         ChartPanel chartPanel = new ChartPanel(null);
//         setPrivateField(chartPanel, "chart", new JFreeChart(mockPlot));
//         setPrivateField(chartPanel, "zoomPoint", new Point2D.Double(200, 200));
//         setPrivateField(chartPanel, "zoomTriggerDistance", 10);
// 
        // Create MouseEvent that exceeds zoomTriggerDistance only vertically
//         MouseEvent mouseEvent = new MouseEvent(chartPanel, MouseEvent.MOUSE_DRAGGED, System.currentTimeMillis(), 0, 200, 250, 0, false);
// 
        // Act
//         chartPanel.mouseDragged(mouseEvent);
// 
        // Assert
//         assertFalse(mockPlot.zoomDomainAxesCalled, "zoomDomainAxes should not be called");
//         assertTrue(mockPlot.zoomRangeAxesCalled, "zoomRangeAxes should be called");
//     }
// 
//     @Test
//     @DisplayName("mouseDragged performs zoom on the domain axis only when only domainZoomable is enabled")
//     void TC06_mouseDragged_ZoomDomainOnly() throws Exception {
        // Arrange
//         MockPlot mockPlot = new MockPlot();
//         mockPlot.domainPannable = true;
//         mockPlot.rangePannable = false;
//         mockPlot.orientation = PlotOrientation.VERTICAL;
// 
//         ChartPanel chartPanel = new ChartPanel(null);
//         setPrivateField(chartPanel, "chart", new JFreeChart(mockPlot));
//         setPrivateField(chartPanel, "zoomPoint", new Point2D.Double(300, 300));
//         setPrivateField(chartPanel, "zoomTriggerDistance", 10);
// 
        // Create MouseEvent that exceeds zoomTriggerDistance only horizontally
//         MouseEvent mouseEvent = new MouseEvent(chartPanel, MouseEvent.MOUSE_DRAGGED, System.currentTimeMillis(), 0, 350, 300, 0, false);
// 
        // Act
//         chartPanel.mouseDragged(mouseEvent);
// 
        // Assert
//         assertTrue(mockPlot.zoomDomainAxesCalled, "zoomDomainAxes should be called");
//         assertFalse(mockPlot.zoomRangeAxesCalled, "zoomRangeAxes should not be called");
//     }
// 
//     @Test
//     @DisplayName("mouseDragged initiates zoom when mouse movement equals zoomTriggerDistance")
//     void TC07_mouseDragged_ZoomOnExactTriggerDistance() throws Exception {
        // Arrange
//         MockPlot mockPlot = new MockPlot();
//         mockPlot.domainPannable = true;
//         mockPlot.rangePannable = true;
//         mockPlot.orientation = PlotOrientation.VERTICAL;
// 
//         ChartPanel chartPanel = new ChartPanel(null);
//         setPrivateField(chartPanel, "chart", new JFreeChart(mockPlot));
//         setPrivateField(chartPanel, "zoomPoint", new Point2D.Double(400, 400));
//         setPrivateField(chartPanel, "zoomTriggerDistance", 10);
// 
        // Create MouseEvent that exactly equals zoomTriggerDistance
//         MouseEvent mouseEvent = new MouseEvent(chartPanel, MouseEvent.MOUSE_DRAGGED, System.currentTimeMillis(), 0, 410, 410, 0, false);
// 
        // Act
//         chartPanel.mouseDragged(mouseEvent);
// 
        // Assert
//         assertTrue(mockPlot.zoomDomainAxesCalled, "zoomDomainAxes should be called");
//         assertTrue(mockPlot.zoomRangeAxesCalled, "zoomRangeAxes should be called");
//     }
// }
}