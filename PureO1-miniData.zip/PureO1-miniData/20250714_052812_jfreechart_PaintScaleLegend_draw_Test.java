import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.PaintScale;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class PaintScaleLegendTest {

    private PaintScale scale;
    private ValueAxis axis;
    private PaintScaleLegend legend;
    private Graphics2D g2;
    private Rectangle2D area;

    @BeforeEach
    public void setUp() {
        scale = mock(PaintScale.class);
        when(scale.getLowerBound()).thenReturn(0.0);
        when(scale.getUpperBound()).thenReturn(100.0);
        axis = mock(ValueAxis.class);
        when(axis.getLowerBound()).thenReturn(0.0);
        when(axis.getUpperBound()).thenReturn(100.0);
        legend = new PaintScaleLegend(scale, axis);
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 200, 100);
    }

    @Test
    public void testDrawWithBackgroundPaint() {
        legend.setBackgroundPaint(Color.BLUE);
        legend.draw(g2, area, null);
        try {
            ArgumentCaptor<Paint> paintCaptor = ArgumentCaptor.forClass(Paint.class);
            ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
            verify(g2).setPaint(paintCaptor.capture());
            verify(g2).fill(rectCaptor.capture());
            assertEquals(Color.BLUE, paintCaptor.getValue());
            assertEquals(area, rectCaptor.getValue());
        } catch (Exception e) {
            fail("Exception should not be thrown");
        }
    }

    @Test
    public void testDrawWithoutBackgroundPaint() {
        legend.setBackgroundPaint(null);
        legend.draw(g2, area, null);
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any());
    }

    @Test
    public void testDrawTopAxisEdgeWithOutline() {
        legend.setPosition(RectangleEdge.BOTTOM);
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        legend.setStripOutlineVisible(true);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.RED);
        legend.draw(g2, area, null);
        // Verify outline is drawn
        verify(g2).setPaint(legend.getStripOutlinePaint());
        verify(g2).setStroke(legend.getStripOutlineStroke());
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawTopAxisEdgeWithoutOutline() {
        legend.setPosition(RectangleEdge.BOTTOM);
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        legend.setStripOutlineVisible(false);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.RED);
        legend.draw(g2, area, null);
        // Verify outline is not drawn
        verify(g2, never()).setPaint(legend.getStripOutlinePaint());
        verify(g2, never()).setStroke(legend.getStripOutlineStroke());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawBottomAxisEdgeWithOutline() {
        legend.setPosition(RectangleEdge.TOP);
        legend.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        legend.setStripOutlineVisible(true);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.GREEN);
        legend.draw(g2, area, null);
        // Verify outline is drawn
        verify(g2).setPaint(legend.getStripOutlinePaint());
        verify(g2).setStroke(legend.getStripOutlineStroke());
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawBottomAxisEdgeWithoutOutline() {
        legend.setPosition(RectangleEdge.TOP);
        legend.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        legend.setStripOutlineVisible(false);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.GREEN);
        legend.draw(g2, area, null);
        // Verify outline is not drawn
        verify(g2, never()).setPaint(legend.getStripOutlinePaint());
        verify(g2, never()).setStroke(legend.getStripOutlineStroke());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawLeftAxisEdgeWithOutline() {
        legend.setPosition(RectangleEdge.RIGHT);
        legend.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        legend.setStripOutlineVisible(true);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.YELLOW);
        legend.draw(g2, area, null);
        // Verify outline is drawn
        verify(g2).setPaint(legend.getStripOutlinePaint());
        verify(g2).setStroke(legend.getStripOutlineStroke());
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawLeftAxisEdgeWithoutOutline() {
        legend.setPosition(RectangleEdge.RIGHT);
        legend.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        legend.setStripOutlineVisible(false);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.YELLOW);
        legend.draw(g2, area, null);
        // Verify outline is not drawn
        verify(g2, never()).setPaint(legend.getStripOutlinePaint());
        verify(g2, never()).setStroke(legend.getStripOutlineStroke());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawRightAxisEdgeWithOutline() {
        legend.setPosition(RectangleEdge.LEFT);
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        legend.setStripOutlineVisible(true);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.ORANGE);
        legend.draw(g2, area, null);
        // Verify outline is drawn
        verify(g2).setPaint(legend.getStripOutlinePaint());
        verify(g2).setStroke(legend.getStripOutlineStroke());
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawRightAxisEdgeWithoutOutline() {
        legend.setPosition(RectangleEdge.LEFT);
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        legend.setStripOutlineVisible(false);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.ORANGE);
        legend.draw(g2, area, null);
        // Verify outline is not drawn
        verify(g2, never()).setPaint(legend.getStripOutlinePaint());
        verify(g2, never()).setStroke(legend.getStripOutlineStroke());
        verify(g2, never()).draw(any(Rectangle2D.class));
    }

    @Test
    public void testDrawWithTopPosition() {
        legend.setPosition(RectangleEdge.BOTTOM);
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.CYAN);
        legend.draw(g2, area, null);
        // Verify axis drawing
        verify(axis).draw(eq(g2), anyDouble(), eq(area), eq(area), eq(RectangleEdge.TOP), isNull());
    }

    @Test
    public void testDrawWithBottomPosition() {
        legend.setPosition(RectangleEdge.TOP);
        legend.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.MAGENTA);
        legend.draw(g2, area, null);
        // Verify axis drawing
        verify(axis).draw(eq(g2), anyDouble(), eq(area), eq(area), eq(RectangleEdge.BOTTOM), isNull());
    }

    @Test
    public void testDrawWithLeftPosition() {
        legend.setPosition(RectangleEdge.RIGHT);
        legend.setAxisLocation(AxisLocation.TOP_OR_RIGHT);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.PINK);
        legend.draw(g2, area, null);
        // Verify axis drawing
        verify(axis).draw(eq(g2), anyDouble(), eq(area), eq(area), eq(RectangleEdge.LEFT), isNull());
    }

    @Test
    public void testDrawWithRightPosition() {
        legend.setPosition(RectangleEdge.LEFT);
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.GRAY);
        legend.draw(g2, area, null);
        // Verify axis drawing
        verify(axis).draw(eq(g2), anyDouble(), eq(area), eq(area), eq(RectangleEdge.RIGHT), isNull());
    }

    @Test
    public void testDrawWithSubdivisionsOne() {
        legend.setSubdivisionCount(1);
        when(scale.getPaint(0.0)).thenReturn(Color.BLACK);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        legend.draw(g2, area, null);
        // Verify one fill call
        verify(g2, times(1)).fill(any(Rectangle2D.class));
    }

    @Test
    public void testDrawWithSubdivisionsMultiple() {
        legend.setSubdivisionCount(10);
        when(scale.getPaint(anyDouble())).thenReturn(Color.BLUE);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        legend.draw(g2, area, null);
        // Verify multiple fill calls
        verify(g2, times(10)).fill(any(Rectangle2D.class));
    }

    @Test
    public void testDrawWithNullGraphics2D() {
        assertThrows(NullPointerException.class, () -> {
            legend.draw(null, area, null);
        });
    }

    @Test
    public void testDrawWithNullArea() {
        assertThrows(NullPointerException.class, () -> {
            legend.draw(g2, null, null);
        });
    }

    @Test
    public void testDrawWithDifferentAxisLocations() {
        // Test TOP_OR_LEFT location
        legend.setPosition(RectangleEdge.BOTTOM);
        legend.setAxisLocation(AxisLocation.TOP_OR_LEFT);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        when(scale.getPaint(anyDouble())).thenReturn(Color.RED);
        legend.draw(g2, area, null);
        verify(axis).draw(eq(g2), anyDouble(), eq(area), eq(area), eq(RectangleEdge.TOP), isNull());

        // Test BOTTOM_OR_LEFT location
        legend.setAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
        legend.draw(g2, area, null);
        verify(axis).draw(eq(g2), anyDouble(), eq(area), eq(area), eq(RectangleEdge.TOP), isNull());
    }

    @Test
    public void testDrawWithCustomStripWidth() {
        legend.setStripWidth(25.0);
        when(scale.getPaint(anyDouble())).thenReturn(Color.RED);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        legend.draw(g2, area, null);
        // There is no direct way to verify stripWidth usage without deeper inspection
        // So this test ensures no exceptions are thrown
        assertDoesNotThrow(() -> legend.draw(g2, area, null));
    }

    @Test
    public void testDrawWithCustomAxisOffset() {
        legend.setAxisOffset(10.0);
        when(scale.getPaint(anyDouble())).thenReturn(Color.RED);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        legend.draw(g2, area, null);
        // There is no direct way to verify axisOffset usage without deeper inspection
        // So this test ensures no exceptions are thrown
        assertDoesNotThrow(() -> legend.draw(g2, area, null));
    }

    @Test
    public void testDrawWithCustomStripOutlinePaintAndStroke() {
        legend.setStripOutlinePaint(Color.BLACK);
        legend.setStripOutlineStroke(new BasicStroke(2.0f));
        legend.setStripOutlineVisible(true);
        when(scale.getPaint(anyDouble())).thenReturn(Color.RED);
        when(axis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 100.0));
        legend.draw(g2, area, null);
        // Verify custom outline paint and stroke are used
        verify(g2).setPaint(Color.BLACK);
        verify(g2).setStroke(new BasicStroke(2.0f));
    }
}