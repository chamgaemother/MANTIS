package org.apache.commons.math3.util;

import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_scalb_0_1_Test {

    @Test
    @DisplayName("scalb with n within normal range and d is a positive normal number")
    public void TC01_scalb_normal_range_positive() {
        // GIVEN
        double d = 1.5;
        int n = 10;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(1.5 * Math.pow(2, 10), result, "Result should be d multiplied by 2^n using fast path");
    }

    @Test
    @DisplayName("scalb with n just below lower bound (-1024) and d is a positive normal number")
    public void TC02_scalb_n_just_below_lower_bound() {
        // GIVEN
        double d = 1.0;
        int n = -1024;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(0.0, result, "Result should be 0.0");
    }

    @Test
    @DisplayName("scalb with n significantly below lower bound (-2500) and d is a negative normal number")
    public void TC03_scalb_n_significantly_below_lower_bound() {
        // GIVEN
        double d = -2.0;
        int n = -2500;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(-0.0, result, "Result should be -0.0");
    }

    @Test
    @DisplayName("scalb with n just above upper bound (2098) and d is a positive normal number")
    public void TC04_scalb_n_just_above_upper_bound() {
        // GIVEN
        double d = 3.0;
        int n = 2098;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be Double.POSITIVE_INFINITY");
    }

    @Test
    @DisplayName("scalb with n significantly above upper bound (2500) and d is a negative normal number")
    public void TC05_scalb_n_significantly_above_upper_bound() {
        // GIVEN
        double d = -4.0;
        int n = 2500;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(Double.NEGATIVE_INFINITY, result, "Result should be Double.NEGATIVE_INFINITY");
    }
}