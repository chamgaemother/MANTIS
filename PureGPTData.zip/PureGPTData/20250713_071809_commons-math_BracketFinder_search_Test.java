import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.apache.commons.math3.optim.univariate.BracketFinder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

class BracketFinderTest {

    @Test
    void testMinimization() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction parabola = x -> (x - 3) * (x - 3);
        finder.search(parabola, GoalType.MINIMIZE, 2, 5);
        assertTrue(finder.getLo() < finder.getHi());
    }

    @Test
    void testMaximization() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction parabola = x -> -(x - 3) * (x - 3);
        finder.search(parabola, GoalType.MAXIMIZE, 2, 5);
        assertTrue(finder.getLo() < finder.getHi());
    }

    @Test
    void testReversedInitialPoints() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction parabola = x -> (x - 3) * (x - 3);
        finder.search(parabola, GoalType.MINIMIZE, 5, 2);
        assertTrue(finder.getLo() < finder.getHi());
    }

    @Test
    void testTooManyEvaluationsException() {
        BracketFinder finder = new BracketFinder(100, 1);
        UnivariateFunction function = x -> x * x;
        Executable executable = () -> finder.search(function, GoalType.MINIMIZE, 0, 1);
        assertThrows(TooManyEvaluationsException.class, executable);
    }

    @Test
    void testEvaluatorIncrement() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction linearFunction = x -> x;
        finder.search(linearFunction, GoalType.MINIMIZE, -1, 1);
        assertTrue(finder.getEvaluations() > 0);
    }

    @Test
    void testIfElseBranches() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction function = x -> 4 * (x - 5) * (x - 5) - 5;
        finder.search(function, GoalType.MINIMIZE, 6, 10);
        assertTrue(finder.getLo() <= finder.getMid() && finder.getMid() <= finder.getHi());
    }

    @Test
    void testZeroSlopeAtStart() {
        BracketFinder finder = new BracketFinder();
        UnivariateFunction constantFunction = x -> 1;
        finder.search(constantFunction, GoalType.MINIMIZE, 0, 1);
        assertEquals(1, finder.getFLo());
        assertEquals(1, finder.getFMid());
        assertEquals(1, finder.getFHi());
    }
}