import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.solvers.BrentSolver;
import org.apache.commons.math3.analysis.solvers.UnivariateSolver;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.apache.commons.math3.ode.events.EventHandler;
import org.apache.commons.math3.ode.sampling.StepInterpolator;
import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class EventStateTest {

    private EventState eventState;
    private EventHandler mockHandler;
    private UnivariateSolver mockSolver;
    private StepInterpolator mockInterpolator;
    private ExpandableStatefulODE mockExpandable;

    @BeforeEach
    public void setUp() {
        mockHandler = mock(EventHandler.class);
        mockSolver = new BrentSolver();
        eventState = new EventState(mockHandler, 1.0, 1e-10, 100, mockSolver);
        mockInterpolator = mock(StepInterpolator.class);
        mockExpandable = mock(ExpandableStatefulODE.class);
        eventState.setExpandable(mockExpandable);
    }
    
    @Test
    public void testEvaluateStep_NoEvent() throws Exception {
        when(mockInterpolator.isForward()).thenReturn(true);
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.5);
        setHandlerGValues(1.0, 0.0, 1.0); // positive, flat line, no zero crossing
        eventState.reinitializeBegin(mockInterpolator);
        
        boolean result = eventState.evaluateStep(mockInterpolator);
        
        assertFalse(result);
    }
    
    @Test
    public void testEvaluateStep_EventDetected() throws Exception {
        when(mockInterpolator.isForward()).thenReturn(true);
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.5);
        setHandlerGValues(-1.0, 0.0, 1.0); // crosses zero
        
        eventState.reinitializeBegin(mockInterpolator);
        
        boolean result = eventState.evaluateStep(mockInterpolator);
        
        assertTrue(result);
        assertEquals(0.0, eventState.getEventTime(), 1e-10);
    }
    
    @Test
    public void testEvaluateStep_ImmediateEventAtStepStart() throws Exception {
        when(mockInterpolator.isForward()).thenReturn(true);
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.5);
        setHandlerGValues(0.0, 0.0, 1.0); // exactly zero at start, then positive
        
        eventState.reinitializeBegin(mockInterpolator);
        
        boolean result = eventState.evaluateStep(mockInterpolator);
        
        assertFalse(result);
    }
    
    @Test
    public void testEvaluateStep_NoPreviousEventTime() throws Exception {
        when(mockInterpolator.isForward()).thenReturn(true);
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.5);
        setHandlerGValues(-1.0, -1.0, 1.0); // wrong brackets to ensure no false positive

        eventState.reinitializeBegin(mockInterpolator);

        assertDoesNotThrow(() -> eventState.evaluateStep(mockInterpolator));
    }
    
    @Test
    public void testEvaluateStep_SolverThrows() throws Exception {
        when(mockInterpolator.isForward()).thenReturn(true);
        when(mockInterpolator.getPreviousTime()).thenReturn(0.0);
        when(mockInterpolator.getCurrentTime()).thenReturn(0.5);
        setHandlerGValues(-1.0, 0.0, 1.0); // crosses zero

        UnivariateSolver solver = mock(UnivariateSolver.class);
        when(solver.solve(anyInt(), any(), anyDouble(), anyDouble(), any(AllowedSolution.class)))
            .thenThrow(new NoBracketingException(0, 1, -1, 1));

        eventState = new EventState(mockHandler, 1.0, 1e-10, 100, solver);
        eventState.setExpandable(mockExpandable);
        eventState.reinitializeBegin(mockInterpolator);

        assertThrows(NoBracketingException.class, () -> eventState.evaluateStep(mockInterpolator));
    }
    
    private void setHandlerGValues(double... values) throws MaxCountExceededException {
        for (int i = 0; i < values.length; i++) {
            when(mockHandler.g(anyDouble(), any())).thenAnswer(invocation -> {
                double t = invocation.getArgument(0);
                if (t == 0.0) {
                    return values[0];
                } else if (t == 0.25) {
                    return values[1];
                } else {
                    return values[2];
                }
            });
        }
    }
}