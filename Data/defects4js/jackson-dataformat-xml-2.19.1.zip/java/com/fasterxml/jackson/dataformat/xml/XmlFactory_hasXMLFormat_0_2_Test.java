package com.fasterxml.jackson.dataformat.xml;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.format.InputAccessor;
import com.fasterxml.jackson.core.format.MatchStrength;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class XmlFactory_hasXMLFormat_0_2_Test {

    @Test
    @DisplayName("InputAccessor without BOM, starts with '<?todo', should return SOLID_MATCH")
    public void TC06() throws Exception {
        // Arrange
        byte[] data = new byte[] {'<', '?', 't', 'o', 'd', 'o'};
        InputAccessor acc = new InputAccessor.Std(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.SOLID_MATCH, result);
    }

    @Test
    @DisplayName("InputAccessor without BOM, starts with '<!--', should return SOLID_MATCH")
    public void TC07() throws Exception {
        // Arrange
        byte[] data = new byte[] {'<', '!', '-', '-', 'c', 'm', 't'};
        InputAccessor acc = new InputAccessor.Std(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.SOLID_MATCH, result);
    }

    @Test
    @DisplayName("InputAccessor without BOM, starts with '<!DOCTYPE', should return SOLID_MATCH")
    public void TC08() throws Exception {
        // Arrange
        byte[] data = new byte[] {'<', '!', 'D', 'O', 'C', 'T', 'Y', 'P', 'E'};
        InputAccessor acc = new InputAccessor.Std(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.SOLID_MATCH, result);
    }

    @Test
    @DisplayName("InputAccessor without BOM, starts with '<rootElement', should return FULL_MATCH")
    public void TC09() throws Exception {
        // Arrange
        byte[] data = new byte[] {'<', 'r', 'o', 'o', 't', 'E', 'l', 'e', 'm', 'e', 'n', 't'};
        InputAccessor acc = new InputAccessor.Std(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.FULL_MATCH, result);
    }

    @Test
    @DisplayName("InputAccessor starts with '<1invalid', invalid character after '<', should return NO_MATCH")
    public void TC10() throws Exception {
        // Arrange
        byte[] data = new byte[] {'<', '1', 'i', 'n', 'v', 'a', 'l', 'i', 'd'};
        InputAccessor acc = new InputAccessor.Std(data);
        XmlFactory xmlFactory = new XmlFactory();

        // Act
        MatchStrength result = xmlFactory.hasXMLFormat(acc);

        // Assert
        assertEquals(MatchStrength.NO_MATCH, result);
    }
}