import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class XYShapeRendererTest {

    private XYShapeRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private XYZDataset xyzDataset;
    private int series = 0;
    private int item = 0;
    private CrosshairState crosshairState;
    private EntityCollection entities;

    @BeforeEach
    void setUp() {
        renderer = new XYShapeRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        xyzDataset = mock(XYZDataset.class);
        crosshairState = mock(CrosshairState.class);
        entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.plot.PlotOrientation.TOP);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.plot.PlotOrientation.LEFT);
    }

    @Test
    void testDrawItem_NullDataset() {
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, series, item, crosshairState, 1);
    }

    @Test
    void testDrawItem_XNaN() {
        when(dataset.getXValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
    }

    @Test
    void testDrawItem_YNaN() {
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
    }

    @Test
    void testDrawItem_Pass0_GuideLinesVisible_Horizontal() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        renderer.setGuideLinesVisible(true);
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(50.0, dataArea, PlotOrientation.HORIZONTAL)).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, PlotOrientation.HORIZONTAL)).thenReturn(40.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
        verify(g2, times(2)).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_Pass0_GuideLinesVisible_Vertical() {
        renderer.setGuideLinesVisible(true);
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(60.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
        verify(g2, times(2)).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_Pass0_GuideLinesNotVisible() {
        renderer.setGuideLinesVisible(false);
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 0);
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_Pass1_ShapeIntersects_DrawOutlines_False_NotXYZ() {
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(series, item)).thenReturn(shape);
        when(shape.getBounds()).thenReturn(new Rectangle2D.Double(45, 45, 10, 10));
        when(shape.intersects(dataArea)).thenReturn(true);
        renderer.setDrawOutlines(false);
        renderer.setUseFillPaint(false);
        when(dataset instanceof XYZDataset).thenReturn(false);
        when(shape.intersects(dataArea)).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(shape);
        verify(g2, never()).draw(shape);
        verify(entities).add(any());
    }

    @Test
    void testDrawItem_Pass1_ShapeIntersects_DrawOutlines_True_UseOutlinePaint_NotXYZ() {
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(series, item)).thenReturn(shape);
        when(shape.getBounds()).thenReturn(new Rectangle2D.Double(45, 45, 10, 10));
        when(shape.intersects(dataArea)).thenReturn(true);
        renderer.setDrawOutlines(true);
        renderer.setUseOutlinePaint(true);
        when(dataset instanceof XYZDataset).thenReturn(false);
        Paint outlinePaint = Color.RED;
        when(renderer.getItemOutlinePaint(series, item)).thenReturn(outlinePaint);
        Stroke outlineStroke = new BasicStroke();
        when(renderer.getItemOutlineStroke(series, item)).thenReturn(outlineStroke);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(shape);
        verify(g2).setPaint(outlinePaint);
        verify(g2).setStroke(outlineStroke);
        verify(g2).draw(shape);
        verify(entities).add(any());
    }

    @Test
    void testDrawItem_Pass1_ShapeIntersects_DrawOutlines_True_UseRegularPaint_NotXYZ() {
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(series, item)).thenReturn(shape);
        when(shape.getBounds()).thenReturn(new Rectangle2D.Double(45, 45, 10, 10));
        when(shape.intersects(dataArea)).thenReturn(true);
        renderer.setDrawOutlines(true);
        renderer.setUseOutlinePaint(false);
        when(dataset instanceof XYZDataset).thenReturn(false);
        Paint regularPaint = Color.BLUE;
        when(renderer.getItemPaint(series, item)).thenReturn(regularPaint);
        Stroke outlineStroke = new BasicStroke();
        when(renderer.getItemOutlineStroke(series, item)).thenReturn(outlineStroke);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
        verify(g2).setPaint(any(Paint.class));
        verify(g2).fill(shape);
        verify(g2).setPaint(regularPaint);
        verify(g2).setStroke(outlineStroke);
        verify(g2).draw(shape);
        verify(entities).add(any());
    }

    @Test
    void testDrawItem_Pass1_ShapeDoesNotIntersect() {
        when(dataset.getXValue(series, item)).thenReturn(150.0);
        when(dataset.getYValue(series, item)).thenReturn(150.0);
        when(domainAxis.valueToJava2D(150.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(150.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(150.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(series, item)).thenReturn(shape);
        when(shape.intersects(dataArea)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
        verify(g2, never()).fill(shape);
        verify(g2, never()).draw(shape);
        verify(entities, never()).add(any());
    }

    @Test
    void testDrawItem_Pass1_XYZDataset_UseFillPaint() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        XYShapeRenderer xyzRenderer = new XYShapeRenderer();
        xyzRenderer.setUseFillPaint(true);
        xyzRenderer.setPaintScale(mock(PaintScale.class));
        when(xyzDataset.getXValue(series, item)).thenReturn(50.0);
        when(xyzDataset.getYValue(series, item)).thenReturn(50.0);
        when(xyzDataset instanceof XYZDataset).thenReturn(true);
        when(xyzDataset.getZValue(series, item)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        Shape shape = mock(Shape.class);
        when(xyzRenderer.getItemShape(series, item)).thenReturn(shape);
        when(shape.getBounds()).thenReturn(new Rectangle2D.Double(45, 45, 10, 10));
        when(shape.intersects(dataArea)).thenReturn(true);
        xyzRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, xyzDataset, series, item, crosshairState, 1);
        verify(xyzRenderer.getPaint(xyzDataset, series, item)).isInstance(xyzDataset);
    }

    @Test
    void testDrawItem_Pass1_XYZDataset_DoNotUseFillPaint() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        XYShapeRenderer xyzRenderer = new XYShapeRenderer();
        xyzRenderer.setUseFillPaint(false);
        PaintScale paintScale = mock(PaintScale.class);
        when(paintScale.getPaint(10.0)).thenReturn(Color.GREEN);
        xyzRenderer.setPaintScale(paintScale);
        when(xyzDataset.getXValue(series, item)).thenReturn(50.0);
        when(xyzDataset.getYValue(series, item)).thenReturn(50.0);
        when(xyzDataset instanceof XYZDataset).thenReturn(true);
        when(xyzDataset.getZValue(series, item)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        Shape shape = mock(Shape.class);
        when(xyzRenderer.getItemShape(series, item)).thenReturn(shape);
        when(shape.getBounds()).thenReturn(new Rectangle2D.Double(45, 45, 10, 10));
        when(shape.intersects(dataArea)).thenReturn(true);
        xyzRenderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, xyzDataset, series, item, crosshairState, 1);
        verify(paintScale).getPaint(10.0);
        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(shape);
    }

    @Test
    void testDrawItem_EntitiesNull() {
        when(info.getOwner().getEntityCollection()).thenReturn(null);
        when(dataset.getXValue(series, item)).thenReturn(50.0);
        when(dataset.getYValue(series, item)).thenReturn(50.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(series, item)).thenReturn(shape);
        when(shape.getBounds()).thenReturn(new Rectangle2D.Double(45, 45, 10, 10));
        when(shape.intersects(dataArea)).thenReturn(true);
        renderer.setDrawOutlines(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
        verify(entities, never()).add(any());
    }
}