import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

public class Flat3MapTest {

    private Flat3Map<String, String> map;

    @BeforeEach
    void setUp() {
        map = new Flat3Map<>();
    }

    // Test with an empty map, expecting false for any input
    @Test
    void testContainsKeyOnEmptyMap() {
        assertFalse(map.containsKey("key1"));
        assertFalse(map.containsKey(null));
    }

    // Test containsKey with null key when map contains only null keys
    @Test
    void testContainsKeyWithNullKeyInFlatMode() {
        map.put(null, "value1");
        map.put(null, "value2");
        map.put(null, "value3");
        assertTrue(map.containsKey(null));
    }
    
    // Test containsKey with a non-null key that is present in flat mode
    @Test
    void testContainsKeyWithNonNullKeyInFlatMode() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        
        assertTrue(map.containsKey("key1"));
        assertTrue(map.containsKey("key2"));
        assertTrue(map.containsKey("key3"));
    }

    // Test containsKey with a non-null key that is absent in flat mode
    @Test
    void testContainsKeyWithAbsentNonNullKeyInFlatMode() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");

        assertFalse(map.containsKey("key4"));
    }

    // Test containsKey with null key when map contains null and non-null keys in flat mode
    @Test
    void testContainsKeyWithMixedKeysInFlatMode() {
        map.put(null, "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");

        assertTrue(map.containsKey(null));
        assertFalse(map.containsKey("key4"));
    }
    
    // Test containsKey in delegate mode when key is present
    @Test
    void testContainsKeyInDelegateModeKeyPresent() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4"); // should trigger delegate map

        assertTrue(map.containsKey("key4"));
    }

    // Test containsKey in delegate mode when key is absent
    @Test
    void testContainsKeyInDelegateModeKeyAbsent() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4"); // should trigger delegate map

        assertFalse(map.containsKey("key5"));
    }

    // Test containsKey with a null key in delegate mode
    @Test
    void testContainsKeyWithNullKeyInDelegateMode() {
        map.put(null, "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4"); // should trigger delegate map 

        assertTrue(map.containsKey(null));
    }
}