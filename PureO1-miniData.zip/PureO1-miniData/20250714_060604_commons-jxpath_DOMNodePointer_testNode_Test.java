package org.apache.commons.jxpath.ri.model.dom;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class DOMNodePointerTest {

    private static Document document;
    private static Element elementWithNamespace;
    private static Element elementWithoutNamespace;
    private static Text textNode;
    private static Comment commentNode;
    private static ProcessingInstruction piNode;

    @BeforeAll
    public static void setUp() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        document = builder.newDocument();

        elementWithoutNamespace = document.createElement("testElement");
        document.appendChild(elementWithoutNamespace);

        elementWithNamespace = document.createElementNS("http://example.com/ns", "ns:testElement");
        elementWithoutNamespace.appendChild(elementWithNamespace);

        textNode = document.createTextNode("Sample Text");
        elementWithoutNamespace.appendChild(textNode);

        commentNode = document.createComment("Sample Comment");
        elementWithoutNamespace.appendChild(commentNode);

        piNode = document.createProcessingInstruction("target", "data");
        elementWithoutNamespace.appendChild(piNode);
    }

    @Test
    public void testTestNode_NullTest_ReturnsTrue() {
        assertTrue(DOMNodePointer.testNode(elementWithoutNamespace, null));
    }

    @Test
    public void testTestNode_NodeNameTest_NodeNotElement_ReturnsFalse() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("testElement"), null);
        assertFalse(DOMNodePointer.testNode(textNode, test));
    }

    @Test
    public void testTestNode_NodeNameTest_WildcardNoPrefix_ReturnsTrue() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("*"), null);
        assertTrue(DOMNodePointer.testNode(elementWithoutNamespace, test));
    }

    @Test
    public void testTestNode_NodeNameTest_WildcardWithPrefix_ReturnsTrue() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("*", "ns"), null);
        assertTrue(DOMNodePointer.testNode(elementWithNamespace, test));
    }

    @Test
    public void testTestNode_NodeNameTest_NamesEqual_NSEqual_ReturnsTrue() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("testElement", "http://example.com/ns"), null);
        assertTrue(DOMNodePointer.testNode(elementWithNamespace, test));
    }

    @Test
    public void testTestNode_NodeNameTest_NamesEqual_NodeNSNull_PrefixEqual_ReturnsTrue() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("testElement", "ns"), null);
        assertTrue(DOMNodePointer.testNode(elementWithoutNamespace, test));
    }

    @Test
    public void testTestNode_NodeNameTest_NamesEqual_DifferentNS_ReturnsFalse() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("testElement", "http://different.com/ns"), null);
        assertFalse(DOMNodePointer.testNode(elementWithNamespace, test));
    }

    @Test
    public void testTestNode_NodeNameTest_NamesNotEqual_ReturnsFalse() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("differentElement"), null);
        assertFalse(DOMNodePointer.testNode(elementWithoutNamespace, test));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypeNode_ReturnsTrue() {
        NodeTest test = new NodeTypeTest(NodeTypeTest.NODE_TYPE_NODE);
        assertTrue(DOMNodePointer.testNode(elementWithoutNamespace, test));
        assertTrue(DOMNodePointer.testNode(textNode, test));
        assertTrue(DOMNodePointer.testNode(commentNode, test));
        assertTrue(DOMNodePointer.testNode(piNode, test));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypeText_NodeText_ReturnsTrue() {
        NodeTest test = new NodeTypeTest(NodeTypeTest.NODE_TYPE_TEXT);
        assertTrue(DOMNodePointer.testNode(textNode, test));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypeText_NodeCDATA_ReturnsTrue() throws Exception {
        Text cdata = document.createCDATASection("CDATA Content");
        assertTrue(DOMNodePointer.testNode(cdata, testNodeTypeText()));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypeText_NodeComment_ReturnsFalse() {
        NodeTest test = new NodeTypeTest(NodeTypeTest.NODE_TYPE_TEXT);
        assertFalse(DOMNodePointer.testNode(commentNode, test));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypeComment_NodeComment_ReturnsTrue() {
        NodeTest test = new NodeTypeTest(NodeTypeTest.NODE_TYPE_COMMENT);
        assertTrue(DOMNodePointer.testNode(commentNode, test));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypeComment_NodeElement_ReturnsFalse() {
        NodeTest test = new NodeTypeTest(NodeTypeTest.NODE_TYPE_COMMENT);
        assertFalse(DOMNodePointer.testNode(elementWithoutNamespace, test));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypePI_NodePI_ReturnsTrue() {
        NodeTest test = new NodeTypeTest(NodeTypeTest.NODE_TYPE_PI);
        assertTrue(DOMNodePointer.testNode(piNode, test));
    }

    @Test
    public void testTestNode_NodeTypeTest_NodeTypePI_NodeElement_ReturnsFalse() {
        NodeTest test = new NodeTypeTest(NodeTypeTest.NODE_TYPE_PI);
        assertFalse(DOMNodePointer.testNode(elementWithoutNamespace, test));
    }

    @Test
    public void testTestNode_ProcessingInstructionTest_PITargetEquals_ReturnsTrue() {
        ProcessingInstructionTest test = new ProcessingInstructionTest("target");
        assertTrue(DOMNodePointer.testNode(piNode, test));
    }

    @Test
    public void testTestNode_ProcessingInstructionTest_PITargetNotEquals_ReturnsFalse() {
        ProcessingInstructionTest test = new ProcessingInstructionTest("differentTarget");
        assertFalse(DOMNodePointer.testNode(piNode, test));
    }

    @Test
    public void testTestNode_ProcessingInstructionTest_NodeNotPI_ReturnsFalse() {
        ProcessingInstructionTest test = new ProcessingInstructionTest("target");
        assertFalse(DOMNodePointer.testNode(elementWithoutNamespace, test));
    }

    @Test
    public void testTestNode_OtherTest_ReturnsFalse() {
        NodeTest test = new NodeTest() {
            @Override
            public short getNodeType() {
                return 999;
            }
        };
        assertFalse(DOMNodePointer.testNode(elementWithoutNamespace, test));
    }

    @Test
    public void testTestNode_NullNode_ThrowsException() {
        NodeTest test = new NodeNameTest(new org.apache.commons.jxpath.ri.QName("testElement"), null);
        assertThrows(NullPointerException.class, () -> DOMNodePointer.testNode(null, test));
    }

    private NodeTest testNodeTypeText() {
        return new NodeTypeTest(NodeTypeTest.NODE_TYPE_TEXT);
    }
}