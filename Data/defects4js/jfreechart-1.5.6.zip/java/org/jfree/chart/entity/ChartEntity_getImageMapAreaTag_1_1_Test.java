package org.jfree.chart.entity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Shape;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.imagemap.ToolTipTagFragmentGenerator;
import org.jfree.chart.imagemap.URLTagFragmentGenerator;

/**
 * Test class for ChartEntity#getImageMapAreaTag
 */
public class ChartEntity_getImageMapAreaTag_1_1_Test {

    @Test
    @DisplayName("When toolTipTagFragmentGenerator is null and toolTipText is non-null and not empty, a NullPointerException is thrown")
    void TC13() {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = "Tooltip text";
        Shape area = new Rectangle2D.Double(0, 0, 10, 10);
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);
        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = null;
        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);
        });
    }

    @Test
    @DisplayName("When urlTagFragmentGenerator is null and urlText is non-null and not empty, a NullPointerException is thrown")
    void TC14() {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = null;
        Shape area = new Rectangle2D.Double(0, 0, 10, 10);
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);
        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip=" + toolTipText;
            }
        };
        URLTagFragmentGenerator urlTagFragmentGenerator = null;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);
        });
    }

    @Test
    @DisplayName("When area is Rectangle2D with zero width, getShapeCoords adjusts x2 to x1 + 1")
    void TC15() {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = "Tooltip text";
        Shape area = new Rectangle2D.Double(5, 5, 0, 10);  // width = 0
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);
        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip=" + toolTipText;
            }
        };
        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        assertTrue(result.contains("coords=\"5,5,6,15\""));
    }

    @Test
    @DisplayName("When area is Rectangle2D with zero height, getShapeCoords adjusts y2 to y1 + 1")
    void TC16() {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = "Tooltip text";
        Shape area = new Rectangle2D.Double(5, 5, 10, 0);  // height = 0
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);
        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip=" + toolTipText;
            }
        };
        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        assertTrue(result.contains("coords=\"5,5,15,6\""));
    }

}