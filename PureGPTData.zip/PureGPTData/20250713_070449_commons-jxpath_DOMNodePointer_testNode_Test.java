import org.apache.commons.jxpath.ri.compiler.Compiler;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

import javax.xml.parsers.DocumentBuilderFactory;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DOMNodePointerTest {

    @Test
    public void testNodeWithNodeNameTestAndWildcardPrefix() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element element = document.createElement("test");
        NodeNameTest nodeNameTest = new NodeNameTest(new QName(null, ""), null, true);
        assertTrue(DOMNodePointer.testNode(element, nodeNameTest));
    }

    @Test
    public void testNodeWithNodeNameTestAndMatchingName() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element element = document.createElement("test");
        NodeNameTest nodeNameTest = new NodeNameTest(new QName(null, "test"), null, false);
        assertTrue(DOMNodePointer.testNode(element, nodeNameTest));
    }

    @Test
    public void testNodeWithNodeNameTestAndDifferentName() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element element = document.createElement("test");
        NodeNameTest nodeNameTest = new NodeNameTest(new QName(null, "other"), null, false);
        assertFalse(DOMNodePointer.testNode(element, nodeNameTest));
    }

    @Test
    public void testNodeWithNodeTypeTestNodeTypeNode() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element element = document.createElement("test");
        NodeTypeTest nodeTypeTest = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
        assertTrue(DOMNodePointer.testNode(element, nodeTypeTest));
    }

    @Test
    public void testNodeWithNodeTypeTestNodeTypeText() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Text textNode = document.createTextNode("text");
        NodeTypeTest nodeTypeTest = new NodeTypeTest(Compiler.NODE_TYPE_TEXT);
        assertTrue(DOMNodePointer.testNode(textNode, nodeTypeTest));
    }

    @Test
    public void testNodeWithNodeTypeTestNodeTypeComment() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        org.w3c.dom.Comment commentNode = document.createComment("comment");
        NodeTypeTest nodeTypeTest = new NodeTypeTest(Compiler.NODE_TYPE_COMMENT);
        assertTrue(DOMNodePointer.testNode(commentNode, nodeTypeTest));
    }

    @Test
    public void testNodeWithNodeTypeTestNodeTypePI() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        ProcessingInstruction pi = document.createProcessingInstruction("target", "data");
        NodeTypeTest nodeTypeTest = new NodeTypeTest(Compiler.NODE_TYPE_PI);
        assertTrue(DOMNodePointer.testNode(pi, nodeTypeTest));
    }

    @Test
    public void testNodeWithProcessingInstructionTestMatchingTarget() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        ProcessingInstruction pi = document.createProcessingInstruction("target", "data");
        ProcessingInstructionTest piTest = new ProcessingInstructionTest("target");
        assertTrue(DOMNodePointer.testNode(pi, piTest));
    }

    @Test
    public void testNodeWithProcessingInstructionTestDifferentTarget() throws Exception {
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        ProcessingInstruction pi = document.createProcessingInstruction("target", "data");
        ProcessingInstructionTest piTest = new ProcessingInstructionTest("otherTarget");
        assertFalse(DOMNodePointer.testNode(pi, piTest));
    }

    @Test
    public void testNodeWithNullTest() {
        Element element = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument().createElement("test");
        assertTrue(DOMNodePointer.testNode(element, null));
    }

    @Test
    public void testNodeWithNullNode() {
        NodeNameTest nodeNameTest = new NodeNameTest(new QName(null, "test"), null, false);
        assertFalse(DOMNodePointer.testNode(null, nodeNameTest));
    }
}