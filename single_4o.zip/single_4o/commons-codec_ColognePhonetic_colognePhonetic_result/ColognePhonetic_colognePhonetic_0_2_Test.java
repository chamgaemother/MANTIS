// complete JUnit 5 test class here
package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_0_2_Test {

    @Test
    @DisplayName("colognePhonetic('XYZ') processes 'X' following non 'C','K','Q'")
    public void testXYZPattern() {
        // GIVEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String text = "XYZ";

        // WHEN
        String result = colognePhonetic.colognePhonetic(text);

        // THEN
        assertEquals("485", result);
    }

    @Test
    @DisplayName("colognePhonetic handles strings with umlauts correctly")
    public void testUmlautHandling() {
        // GIVEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String text = "RÃ¤uber";

        // WHEN
        String result = colognePhonetic.colognePhonetic(text);

        // THEN
        assertEquals("7011", result);
    }

    @Test
    @DisplayName("colognePhonetic evaluates 'C' handling with special context after S or Z")
    public void testSCHandling() {
        // GIVEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String text = "SC";

        // WHEN
        String result = colognePhonetic.colognePhonetic(text);

        // THEN
        assertEquals("88", result);
    }

    @Test
    @DisplayName("colognePhonetic evaluates complex input string with varied conditions")
    public void testComplexString() {
        // GIVEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String text = "GabelStaplerFahrerde";

        // WHEN
        String result = colognePhonetic.colognePhonetic(text);

        // THEN
        assertEquals("484538658824", result);
    }

    @Test
    @DisplayName("colognePhonetic handles strings with multiple consecutive '0's")
    public void testZeroReduction() {
        // GIVEN
        ColognePhonetic colognePhonetic = new ColognePhonetic();
        String text = "Aaoouy";

        // WHEN
        String result = colognePhonetic.colognePhonetic(text);

        // THEN
        assertEquals("", result);
    }
}