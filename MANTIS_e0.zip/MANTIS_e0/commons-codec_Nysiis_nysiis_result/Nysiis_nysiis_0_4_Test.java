package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_4_Test {

    @Test
    @DisplayName("nysiis replaces trailing AY with Y")
    void TC16_nysiis_replaces_trailing_AY_with_Y() {
        Nysiis encoder = new Nysiis();
        String input = "STAY";
        String result = encoder.nysiis(input);
        assertTrue(result.endsWith("Y"));
    }

    @Test
    @DisplayName("nysiis removes trailing A from key")
    void TC17_nysiis_removes_trailing_A_from_key() {
        Nysiis encoder = new Nysiis();
        String input = "MARA";
        String result = encoder.nysiis(input);
        assertFalse(result.endsWith("A"));
    }

    @Test
    @DisplayName("nysiis collapses repeated characters in key")
    void TC18_nysiis_collapses_repeated_characters_in_key() {
        Nysiis encoder = new Nysiis();
        String input = "BOBBY";
        String result = encoder.nysiis(input);
        assertFalse(result.matches(".*(.)\\1+.*"));
    }

    @Test
    @DisplayName("nysiis encodes with strict mode limiting to 6 characters")
    void TC19_nysiis_with_strict_mode_limiting_to_6_characters() {
        Nysiis encoder = new Nysiis(true);
        String input = "LONGNAME";
        String result = encoder.nysiis(input);
        assertEquals(6, result.length());
    }

    @Test
    @DisplayName("nysiis encodes without strict mode allowing arbitrary length")
    void TC20_nysiis_without_strict_mode_allowing_full_length() {
        Nysiis encoder = new Nysiis(false);
        String input = "LONGNAME";
        String result = encoder.nysiis(input);
        assertTrue(result.length() > 6);
    }
}