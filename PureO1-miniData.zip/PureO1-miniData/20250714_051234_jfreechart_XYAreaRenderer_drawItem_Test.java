import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.awt.GradientPaint;

import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.renderer.xy.XYAreaRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class XYAreaRendererTest {

    private XYAreaRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYAreaRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_Y1NaN() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(dataset).getYValue(0, 0);
    }

    @Test
    void testDrawItem_Y0NaN() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(5.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(dataset).getYValue(0, 0);
    }

    @Test
    void testDrawItem_Y2NaN() {
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(3.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(dataset).getYValue(0, 1);
    }

    @Test
    void testDrawItem_ItemIsZero_Vertical() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotArea()).thenReturn(true);
        when(renderer.getItemCount(0)).thenReturn(1);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_ItemIsZero_Horizontal() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getPlotArea()).thenReturn(true);
        when(renderer.getItemCount(0)).thenReturn(1);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotShapesTrue() {
        renderer.setPlotShapes(true);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        Shape mockShape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(mockShape);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotLinesTrue_Vertical() {
        renderer.setPlotLines(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        Stroke mockStroke = mock(BasicStroke.class);
        when(renderer.getItemStroke(0, 1)).thenReturn(mockStroke);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_PlotAreaTrue_LastItem() {
        renderer.setPlotArea(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.setUseFillPaint(false);
        renderer.setShowOutline(true);
        Paint mockPaint = mock(Paint.class);
        when(renderer.lookupSeriesOutlinePaint(0)).thenReturn(mockPaint);
        Stroke mockStroke = new BasicStroke();
        when(renderer.lookupSeriesOutlineStroke(0)).thenReturn(mockStroke);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PaintIsGradientPaint() {
        renderer.setUseFillPaint(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.setShowOutline(false);
        GradientPaint gp = mock(GradientPaint.class);
        when(renderer.lookupSeriesFillPaint(0)).thenReturn(gp);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(g2).setPaint(any(GradientPaint.class));
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_PaintIsNotGradientPaint() {
        renderer.setUseFillPaint(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.setShowOutline(false);
        Paint mockPaint = mock(Paint.class);
        when(renderer.lookupSeriesFillPaint(0)).thenReturn(mockPaint);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(g2).setPaint(mockPaint);
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_ShowOutlineFalse() {
        renderer.setShowOutline(false);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_ShowOutlineTrue_NonBasicStroke() {
        renderer.setShowOutline(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        Stroke mockStroke = mock(Stroke.class);
        when(renderer.lookupSeriesOutlineStroke(0)).thenReturn(mockStroke);
        Paint mockPaint = mock(Paint.class);
        when(renderer.lookupSeriesOutlinePaint(0)).thenReturn(mockPaint);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_ShowOutlineTrue_BasicStrokeWithDash() {
        renderer.setShowOutline(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(40.0);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        BasicStroke bs = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1.0f, new float[] {2.0f}, 0.0f);
        when(renderer.lookupSeriesOutlineStroke(0)).thenReturn(bs);
        Paint mockPaint = mock(Paint.class);
        when(renderer.lookupSeriesOutlinePaint(0)).thenReturn(mockPaint);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotShapesFalse_PlotLinesFalse_PlotAreaFalse() {
        renderer.setPlotShapes(false);
        renderer.setPlotLines(false);
        renderer.setPlotArea(false);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).draw(any(Shape.class));
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_EntitiesNull() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getEntityCollection()).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        // No exception should be thrown
    }

    @Test
    void testDrawItem_EntitiesNotNull() {
        renderer.setPlotArea(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(renderer.getPlotArea()).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(state.getEntityCollection()).thenReturn(mock(org.jfree.chart.entity.EntityCollection.class));
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 0);
        verify(state.getEntityCollection()).add(any());
    }

    @Test
    void testDrawItem_NullGraphics2D() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        renderer.drawItem(null, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        // Expect NullPointerException or handle gracefully
    }

    @Test
    void testDrawItem_LastItem_NotDrawingArea() {
        renderer.setPlotArea(true);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getPlotArea()).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);
        verify(g2).fill(any(Shape.class));
    }
}