package org.apache.commons.csv;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class CSVFormat_equals_0_2_Test {

    @Test
    @DisplayName("equals returns false when autoFlush differs")
    void TC06() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setAutoFlush(true).build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setAutoFlush(false).build();
        boolean result = format1.equals(format2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when commentMarker differs")
    void TC07() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setCommentMarker('!').build();
        boolean result = format1.equals(format2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when delimiter differs")
    void TC08() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setDelimiter(',').build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setDelimiter(';').build();
        boolean result = format1.equals(format2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when escapeCharacter differs")
    void TC09() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setEscape('\\').build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setEscape('/').build();
        boolean result = format1.equals(format2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when headers differ")
    void TC10() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader("A", "B").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader("A", "C").build();
        boolean result = format1.equals(format2);
        assertFalse(result);
    }
}