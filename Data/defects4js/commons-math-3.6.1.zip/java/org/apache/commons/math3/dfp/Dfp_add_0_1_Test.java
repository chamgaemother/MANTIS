package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;

import java.lang.reflect.Field;

public class Dfp_add_0_1_Test {

    @Test
    @DisplayName("Adding two finite Dfp numbers with equal radix digits and same sign results in correct sum")
    public void TC01() throws Exception {
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 1.5);
        Dfp b = new Dfp(field, 2.5);
        Dfp expectedSum = new Dfp(field, 4.0);
        Dfp result = a.add(b);
        Assertions.assertEquals(expectedSum, result, "The sum of two finite Dfp numbers with the same sign should be correct.");
    }

    @Test
    @DisplayName("Adding two Dfp numbers with different radix digits triggers invalid flag and returns QNAN")
    public void TC02() throws Exception {
        DfpField field1 = new DfpField(10);
        DfpField field2 = new DfpField(15);
        Dfp a = new Dfp(field1, 1.0);
        Dfp b = new Dfp(field2, 2.0); // field2 has different radix digits
        Dfp result = a.add(b);
        
        // Access the private 'flags' field in DfpField using reflection
        Field flagsField = DfpField.class.getDeclaredField("flags");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(field1);
        
        // Assert that FLAG_INVALID is set
        Assertions.assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set when adding Dfp with different radix digits.");
        
        // Assert that result is QNAN
        Assertions.assertTrue(result.isNaN(), "Result should be QNAN when adding Dfp with different radix digits.");
    }

    @Test
    @DisplayName("Adding a finite Dfp and a NaN Dfp returns the finite Dfp if it is not NaN")
    public void TC03() throws Exception {
        DfpField field = new DfpField(10);
        Dfp finite = new Dfp(field, 1.0);
        Dfp nan = new Dfp(field, Double.NaN); // Assuming constructor sets nans to QNAN

        Dfp result = finite.add(nan);
        
        // Assert that the result equals the finite Dfp instance
        Assertions.assertEquals(finite, result, "Adding a finite Dfp and a NaN Dfp should return the finite Dfp.");
    }

    @Test
    @DisplayName("Adding two infinite Dfp numbers with the same sign returns infinity with that sign")
    public void TC04() throws Exception {
        DfpField field = new DfpField(10);
        // Assuming Dfp has predefined constants for infinite values
        Dfp a = getInfiniteDfp(field, 1);
        Dfp b = getInfiniteDfp(field, 1); // same sign

        Dfp result = a.add(b);
        
        Assertions.assertTrue(result.isInfinite(), "Result should be infinite when adding two infinite Dfp numbers with the same sign.");
        
        // Access the 'sign' field via reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        byte sign = signField.getByte(result);
        Assertions.assertEquals(1, sign, "Result should have positive sign.");
    }

    @Test
    @DisplayName("Adding two infinite Dfp numbers with opposite signs triggers invalid flag and returns QNAN")
    public void TC05() throws Exception {
        DfpField field = new DfpField(10);
        Dfp a = getInfiniteDfp(field, 1); // positive infinity
        Dfp b = getInfiniteDfp(field, -1); // negative infinity

        Dfp result = a.add(b);
        
        // Access the private 'flags' field in DfpField using reflection
        Field flagsField = DfpField.class.getDeclaredField("flags");
        flagsField.setAccessible(true);
        int flags = flagsField.getInt(field);
        
        // Assert that FLAG_INVALID is set
        Assertions.assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set when adding two infinite Dfp numbers with opposite signs.");
        
        // Assert that result is QNAN
        Assertions.assertTrue(result.isNaN(), "Result should be QNAN when adding two infinite Dfp numbers with opposite signs.");
    }
    
    // Helper method to create infinite Dfp instances using reflection
    private Dfp getInfiniteDfp(DfpField field, int sign) throws Exception {
        Dfp infinite = new Dfp(field, Double.POSITIVE_INFINITY);
        
        // Access and set the 'sign' field via reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(infinite, (byte) sign);
        
        return infinite;
    }
}