package org.apache.commons.codec.language;

import org.apache.commons.codec.language.DoubleMetaphone;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_9_Test {

    @Test
    @DisplayName("doubleMetaphone handles 'C' followed by 'K' in 'KICK'")
    public void TC41_doubleMetaphone_CK_handling_KICK() {
        // GIVEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "KICK";

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("K"), "Encoded result should contain 'K'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'G' followed by 'N' in 'GNOME'")
    public void TC42_doubleMetaphone_GN_handling_GNOME() {
        // GIVEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "GNOME";

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("N"), "Encoded result should contain 'N'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'KN' prefix in 'KNIFE'")
    public void TC43_doubleMetaphone_KN_prefix_KNIFE() {
        // GIVEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "KNIFE";

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // THEN
        assertTrue(result.contains("N"), "Encoded result should contain 'N'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'GN' followed by 'A' in 'GNAUT'")
    public void TC44_doubleMetaphone_GN_followed_A_GNAUT() {
        // GIVEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "GNAUT";

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, true);

        // THEN
        assertTrue(result.contains("N"), "Encoded result should contain 'N'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'WITZ' suffix in 'OWSKI'")
    public void TC45_doubleMetaphone_WITZ_suffix_OWSKI() {
        // GIVEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String value = "OWSKI";

        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, true);

        // THEN
        assertTrue(result.endsWith("FX"), "Encoded result should end with 'FX'");
    }
}