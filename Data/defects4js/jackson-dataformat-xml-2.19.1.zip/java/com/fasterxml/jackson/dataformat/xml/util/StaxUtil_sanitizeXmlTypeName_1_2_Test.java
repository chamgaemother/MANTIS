package com.fasterxml.jackson.dataformat.xml.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class StaxUtil_sanitizeXmlTypeName_1_2_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName with all valid characters")
    void TC06_sanitizeXmlTypeName_with_all_valid_characters() {
        // GIVEN
        String name = "ValidName";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);
        
        // THEN
        assertEquals("ValidNames", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with '$' character to be replaced by '.'")
    void TC07_sanitizeXmlTypeName_with_dollar_character() {
        // GIVEN
        String name = "Price$Value";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);
        
        // THEN
        assertEquals("Price.Values", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with '@' character to be replaced by '_'")
    void TC08_sanitizeXmlTypeName_with_at_character() {
        // GIVEN
        String name = "User@Name";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);
        
        // THEN
        assertEquals("User_Namees", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with non-ASCII character, ensuring it's skipped")
    void TC09_sanitizeXmlTypeName_with_non_ascii_characters() {
        // GIVEN
        String name = "CafÃ©";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);
        
        // THEN
        assertEquals("Cafes", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with multiple characters needing replacement")
    void TC10_sanitizeXmlTypeName_with_multiple_special_characters() {
        // GIVEN
        String name = "Price$Value@2023";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);
        
        // THEN
        assertEquals("Price.Value_2023s", result);
    }
}