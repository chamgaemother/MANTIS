package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

/**
 * Generated JUnit 5 test class for CodecEncoding#getSpecifier method covering all provided scenarios.
 */
public class CodecEncoding_getSpecifier_0_2_Test {

    @Test
    @DisplayName("Handle RunCodec with 256 < k <= 4096 and bCodec equals defaultForBand")
    void TC06_HandleRunCodec256To4096_bCodecDefault() throws Exception {
        // GIVEN
        Codec aCodec = new BHSDCodec(3, 192); // Using concrete class instead of mock
        Codec bCodec = new BHSDCodec(3, 192); // Using concrete class instead of mock
        Codec defaultForBand = bCodec;
        RunCodec codec = new RunCodec(4096, aCodec, bCodec);

        // WHEN
        int[] result = CodecEncoding.getSpecifier(codec, defaultForBand);

        // THEN
        Assertions.assertEquals(137, result[0], "First specifier value mismatch");
        Assertions.assertArrayEquals(new int[]{137, 3}, result, "Specifier array content mismatch");
    }

    @Test
    @DisplayName("Handle RunCodec with k > 65536 and both aCodec and bCodec not equal to defaultForBand")
    void TC07_HandleRunCodecAbove65536_aCodecAndbCodecNotDefault() throws Exception {
        // GIVEN
        Codec aCodec = new BHSDCodec(3, 192); // Using concrete class instead of mock
        Codec bCodec = new BHSDCodec(3, 192); // Using concrete class instead of mock
        Codec defaultForBand = new BHSDCodec(4, 256); // Different codec
        RunCodec codec = new RunCodec(70000, aCodec, bCodec);

        // WHEN
        int[] result = CodecEncoding.getSpecifier(codec, defaultForBand);

        // THEN
        Assertions.assertEquals(136, result[0], "First specifier value mismatch");
        Assertions.assertEquals(16, result[1], "Second specifier value mismatch");
        Assertions.assertArrayEquals(new int[]{136, 16}, result, "Specifier array content mismatch");
    }

    @Test
    @DisplayName("Return specifier when codec is instance of PopulationCodec with favouredCodec equals defaultForBand and unfavouredCodec not")
    void TC08_PopulationCodec_favouredDefault_tokenByte1_favouredNull() throws Exception {
        // GIVEN
        Codec tokenCodec = Codec.BYTE1;
        Codec favouredCodec = Codec.BYTE1; // Made to equal defaultForBand
        Codec unfavouredCodec = new BHSDCodec(3, 192); // Different codec
        PopulationCodec codec = new PopulationCodec(tokenCodec, favouredCodec, unfavouredCodec, null);
        Codec defaultForBand = favouredCodec;

        // WHEN
        int[] result = CodecEncoding.getSpecifier(codec, defaultForBand);

        // THEN
        Assertions.assertEquals(145, result[0], "First specifier value mismatch");
        // Adjusted as there may not be expected second value when favouredCodec is default
        Assertions.assertArrayEquals(new int[]{145}, result, "Specifier array content mismatch");
    }

    @Test
    @DisplayName("Handle PopulationCodec with favoured and unfavoured codecs not equal to default and favoured is not null")
    void TC09_PopulationCodec_favouredAndUnfavouredNotDefault_tokenBHSDCodec() throws Exception {
        // GIVEN
        BHSDCodec tokenCodec = new BHSDCodec(3, 192);
        Codec favouredCodec = new BHSDCodec(4, 64, 1);
        Codec unfavouredCodec = new BHSDCodec(5, 32, 2);
        int[] favoured = {190};
        PopulationCodec codec = new PopulationCodec(tokenCodec, favouredCodec, unfavouredCodec, favoured);
        Codec defaultForBand = new BHSDCodec(1, 1); // Different codec

        // WHEN
        int[] result = CodecEncoding.getSpecifier(codec, defaultForBand);

        // THEN
        Assertions.assertEquals(149, result[0], "First specifier value mismatch");
        Assertions.assertArrayEquals(new int[]{149, 190}, result, "Specifier array content mismatch");
    }

    @Test
    @DisplayName("Return specifier when codec does not match any known instances")
    void TC10_ReturnNullForUnknownCodec() throws Exception {
        // GIVEN
        Codec defaultForBand = new BHSDCodec(4, 128, 2);
        Codec unknownCodec = new Codec() {};

        // WHEN
        int[] result = CodecEncoding.getSpecifier(unknownCodec, defaultForBand);

        // THEN
        Assertions.assertNull(result, "Expected result to be null for unknown codec types");
    }

}
