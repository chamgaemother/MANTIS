import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.ri.parser.XPathParser;
import org.apache.commons.jxpath.ri.parser.XPathParserTokenManager;
import org.apache.commons.jxpath.ri.parser.Token;
import org.junit.jupiter.api.Test;

public class XPathParserTest {

    @Test
    public void testAxisNameSelf() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_SELF);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_SELF, parser.AxisName());
    }

    @Test
    public void testAxisNameChild() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_CHILD);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_CHILD, parser.AxisName());
    }

    @Test
    public void testAxisNameParent() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_PARENT);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_PARENT, parser.AxisName());
    }

    @Test
    public void testAxisNameAncestor() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_ANCESTOR);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_ANCESTOR, parser.AxisName());
    }

    @Test
    public void testAxisNameAttribute() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_ATTRIBUTE);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_ATTRIBUTE, parser.AxisName());
    }

    @Test
    public void testAxisNameNamespace() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_NAMESPACE);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_NAMESPACE, parser.AxisName());
    }

    @Test
    public void testAxisNamePreceding() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_PRECEDING);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_PRECEDING, parser.AxisName());
    }

    @Test
    public void testAxisNameFollowing() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_FOLLOWING);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_FOLLOWING, parser.AxisName());
    }

    @Test
    public void testAxisNameDescendant() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_DESCENDANT);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_DESCENDANT, parser.AxisName());
    }

    @Test
    public void testAxisNameAncestorOrSelf() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_ANCESTOR_OR_SELF);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_ANCESTOR_OR_SELF, parser.AxisName());
    }

    @Test
    public void testAxisNameFollowingSibling() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_FOLLOWING_SIBLING);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_FOLLOWING_SIBLING, parser.AxisName());
    }

    @Test
    public void testAxisNamePrecedingSibling() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_PRECEDING_SIBLING);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_PRECEDING_SIBLING, parser.AxisName());
    }

    @Test
    public void testAxisNameDescendantOrSelf() {
        XPathParserTokenManager tokenManager = createTokenManager(XPathParserConstants.AXIS_DESCENDANT_OR_SELF);
        XPathParser parser = new XPathParser(tokenManager);
        assertEquals(Compiler.AXIS_DESCENDANT_OR_SELF, parser.AxisName());
    }

    private XPathParserTokenManager createTokenManager(int kind) {
        Token token = new Token();
        token.kind = kind;
        XPathParserTokenManager tokenManager = new XPathParserTokenManager(null);
        tokenManager.nextToken = token;
        return tokenManager;
    }
}