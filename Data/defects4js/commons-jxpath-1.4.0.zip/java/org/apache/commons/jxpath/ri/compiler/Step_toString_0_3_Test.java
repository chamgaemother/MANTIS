package org.apache.commons.jxpath.ri.compiler;

import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import org.apache.commons.jxpath.ri.Compiler;

public class Step_toString_0_3_Test {

    private void setPrivateField(Object instance, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
        Field field = Step.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(instance, value);
    }

    @Test
    @DisplayName("toString with axis PARENT and nodeTest as NodeTypeTest with non-NODE_TYPE_NODE, predicates present")
    public void TC11() {
        // Use reflection to access private fields
        try {
            Step step = new Step(0, null, null);
            setPrivateField(step, "axis", Compiler.AXIS_PARENT);

            NodeTypeTest nodeTypeTestNonNode = Mockito.mock(NodeTypeTest.class);
            Mockito.when(nodeTypeTestNonNode.getNodeType()).thenReturn(2); // != Compiler.NODE_TYPE_NODE (1)
            Mockito.when(nodeTypeTestNonNode.toString()).thenReturn("nodeTest");
            setPrivateField(step, "nodeTest", nodeTypeTestNonNode);

            Expression predicate1 = Mockito.mock(Expression.class);
            Expression predicate2 = Mockito.mock(Expression.class);
            Mockito.when(predicate1.toString()).thenReturn("predicate1");
            Mockito.when(predicate2.toString()).thenReturn("predicate2");

            setPrivateField(step, "predicates", new Expression[]{predicate1, predicate2});

            String result = step.toString();

            assertEquals("parent::nodeTest[predicate1][predicate2]", result);
        } catch (Exception e) {
            fail("Reflection exception: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("toString with axis DESCENDANT_OR_SELF and nodeTest as NodeTypeTest with NODE_TYPE_NODE, predicates null")
    public void TC12() {
        try {
            Step step = new Step(0, null, null);
            setPrivateField(step, "axis", Compiler.AXIS_DESCENDANT_OR_SELF);

            NodeTypeTest nodeTypeTestNode = Mockito.mock(NodeTypeTest.class);
            Mockito.when(nodeTypeTestNode.getNodeType()).thenReturn(1); // == Compiler.NODE_TYPE_NODE (1)
            Mockito.when(nodeTypeTestNode.toString()).thenReturn("nodeTest");
            setPrivateField(step, "nodeTest", nodeTypeTestNode);

            setPrivateField(step, "predicates", null);

            String result = step.toString();

            assertEquals("", result);
        } catch (Exception e) {
            fail("Reflection exception: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("toString with axis DESCENDANT_OR_SELF and nodeTest as NodeTypeTest with NODE_TYPE_NODE, predicates present")
    public void TC13() {
        try {
            Step step = new Step(0, null, null);
            setPrivateField(step, "axis", Compiler.AXIS_DESCENDANT_OR_SELF);

            NodeTypeTest nodeTypeTestNode = Mockito.mock(NodeTypeTest.class);
            Mockito.when(nodeTypeTestNode.getNodeType()).thenReturn(1); // == Compiler.NODE_TYPE_NODE (1)
            Mockito.when(nodeTypeTestNode.toString()).thenReturn("nodeTest");
            setPrivateField(step, "nodeTest", nodeTypeTestNode);

            Expression predicate1 = Mockito.mock(Expression.class);
            Expression predicate2 = Mockito.mock(Expression.class);
            Mockito.when(predicate1.toString()).thenReturn("predicate1");
            Mockito.when(predicate2.toString()).thenReturn("predicate2");

            setPrivateField(step, "predicates", new Expression[]{predicate1, predicate2});

            String result = step.toString();

            assertEquals("descendant-or-self::nodeTest[predicate1][predicate2]", result);
        } catch (Exception e) {
            fail("Reflection exception: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("toString with unknown axis value, nodeTest not a NodeTypeTest, predicates null")
    public void TC14() {
        try {
            Step step = new Step(0, null, null);
            setPrivateField(step, "axis", 99);

            NodeTest nonNodeTypeTest = Mockito.mock(NodeTest.class);
            Mockito.when(nonNodeTypeTest.toString()).thenReturn("nodeTest");
            setPrivateField(step, "nodeTest", nonNodeTypeTest);

            setPrivateField(step, "predicates", null);

            String result = step.toString();

            assertEquals("UNKNOWN::nodeTest", result);
        } catch (Exception e) {
            fail("Reflection exception: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("toString with axis CHILD and nodeTest as NodeTypeTest with non-NODE_TYPE_NODE, predicates empty")
    public void TC15() {
        try {
            Step step = new Step(0, null, null);
            setPrivateField(step, "axis", Compiler.AXIS_CHILD);

            NodeTypeTest nodeTypeTestNonNode = Mockito.mock(NodeTypeTest.class);
            Mockito.when(nodeTypeTestNonNode.getNodeType()).thenReturn(2); // != Compiler.NODE_TYPE_NODE (1)
            Mockito.when(nodeTypeTestNonNode.toString()).thenReturn("nodeTest");
            setPrivateField(step, "nodeTest", nodeTypeTestNonNode);

            setPrivateField(step, "predicates", new Expression[0]);

            String result = step.toString();

            assertEquals("nodeTest", result);
        } catch (Exception e) {
            fail("Reflection exception: " + e.getMessage());
        }
    }
}
