package com.fasterxml.jackson.databind.ser.std;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.JsonSerializer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MapSerializer_serializeFilteredFields_0_2_Test {

    @Test
    @DisplayName("serializeFilteredFields with null value and _suppressNulls is false")
    public void TC06_serializeFilteredFields_nullValue_noSuppression() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", null);
        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = null;
        JsonSerializer<Object> defaultNullValueSerializer = mock(JsonSerializer.class);

        MapSerializer mapSerializer = createMapSerializerInstance();

        // Reflectively set _suppressNulls to false
        Field suppressNullsField = MapSerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        suppressNullsField.set(mapSerializer, false);

        // Reflectively set _valueSerializer to a mock
        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, null);

        // Mock provider.getDefaultNullValueSerializer()
        when(provider.getDefaultNullValueSerializer()).thenReturn(defaultNullValueSerializer);

        // WHEN
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // THEN
        verify(provider).getDefaultNullValueSerializer();
        verify(filter).serializeAsField(eq(value), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("serializeFilteredFields with non-null value and _valueSerializer is null")
    public void TC07_serializeFilteredFields_dynamicSerializer() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");
        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = null;

        MapSerializer mapSerializer = createMapSerializerInstance();

        // Reflectively set _valueSerializer to null
        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, null);

        // Mock _findSerializer using reflection
        JsonSerializer<Object> dynamicSerializer = mock(JsonSerializer.class);
        when(provider.findValueSerializer(any(Class.class), eq(mapSerializer._property))).thenReturn(dynamicSerializer);

        // WHEN
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // THEN
        verify(provider).findValueSerializer(any(Class.class), eq(mapSerializer._property));
        verify(filter).serializeAsField(eq(value), eq(gen), eq(provider), any());
    }

    @Test
    @DisplayName("serializeFilteredFields with valueSer.isEmpty returns true and checkEmpty is true")
    public void TC08_serializeFilteredFields_emptyValueSuppressed() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", new EmptyObject());
        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = MapSerializer.MARKER_FOR_EMPTY;

        MapSerializer mapSerializer = createMapSerializerInstance();

        // Reflectively set _valueSerializer
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, valueSerializer);

        // Mock valueSerializer.isEmpty()
        when(valueSerializer.isEmpty(provider, any())).thenReturn(true);

        // WHEN
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // THEN
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
    }

    @Test
    @DisplayName("serializeFilteredFields with suppressableValue equals valueElem and checkEmpty is false")
    public void TC09_serializeFilteredFields_suppressableValue() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "suppress");
        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = "suppress";

        MapSerializer mapSerializer = createMapSerializerInstance();

        // Reflectively set _valueSerializer
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, valueSerializer);

        // Mock valueSerializer.isEmpty() to return false
        when(valueSerializer.isEmpty(provider, "suppress")).thenReturn(false);

        // WHEN
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // THEN
        verify(filter, never()).serializeAsField(any(), any(), any(), any());
    }

    @Test
    @DisplayName("serializeFilteredFields with map having multiple entries, all valid and serialized")
    public void TC10_serializeFilteredFields_multipleValidEntries() throws Exception {
        // GIVEN
        Map<Object, Object> value = new HashMap<>();
        value.put("key1", "value1");
        value.put("key2", "value2");
        JsonGenerator gen = mock(JsonGenerator.class);
        SerializerProvider provider = mock(SerializerProvider.class);
        PropertyFilter filter = mock(PropertyFilter.class);
        Object suppressableValue = null;

        MapSerializer mapSerializer = createMapSerializerInstance();

        // Reflectively set _valueSerializer
        JsonSerializer<Object> valueSerializer = mock(JsonSerializer.class);
        Field valueSerializerField = MapSerializer.class.getDeclaredField("_valueSerializer");
        valueSerializerField.setAccessible(true);
        valueSerializerField.set(mapSerializer, valueSerializer);

        // WHEN
        mapSerializer.serializeFilteredFields(value, gen, provider, filter, suppressableValue);

        // THEN
        verify(filter, times(2)).serializeAsField(eq(value), eq(gen), eq(provider), any());
    }

    private MapSerializer createMapSerializerInstance() {
        // Use the reflection mechanism to bypass constructors requiring parameters
        try {
            return (MapSerializer) MapSerializer.class.getDeclaredConstructors()[0].newInstance(new Object[]{null, null, null, null, false, null, null, null});
        } catch (Exception e) {
            throw new RuntimeException("Failed to create MapSerializer instance", e);
        }
    }

    // Helper class for empty object scenario
    private static class EmptyObject {
        // This class can be extended as needed
    }
}