package org.jfree.chart.plot.dial;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.mockito.Mockito;

public class DialPlot_draw_2_1_Test {

    @Test
    @DisplayName("Draw method with non-null but invisible background, no layers, no pointers, no cap, dialFrame not visible")
    public void TC06() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        DialLayer background = mock(DialLayer.class);
        plot.setBackground(background);
        when(background.isVisible()).thenReturn(false);
        plot.setCap(null);
        DialFrame dialFrame = plot.getDialFrame();

        // Using reflection to set dialFrame visibility to false
        java.lang.reflect.Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, false);

        // Mocking Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);
        Shape originalClip = mock(Shape.class);
        when(g2.getClip()).thenReturn(originalClip);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(background, never()).draw(any(Graphics2D.class), any(DialPlot.class), any(Rectangle2D.class), any(Rectangle2D.class));
        verify(g2).setClip(originalClip);
    }

    @Test
    @DisplayName("Draw method with non-null and invisible background, with visible layers not clipped to window, no pointers, no cap, dialFrame not visible")
    public void TC07() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        DialLayer background = mock(DialLayer.class);
        plot.setBackground(background);
        when(background.isVisible()).thenReturn(false);

        DialLayer layer1 = mock(DialLayer.class);
        DialLayer layer2 = mock(DialLayer.class);
        plot.addLayer(layer1);
        plot.addLayer(layer2);
        when(layer1.isVisible()).thenReturn(true);
        when(layer1.isClippedToWindow()).thenReturn(false);
        when(layer2.isVisible()).thenReturn(true);
        when(layer2.isClippedToWindow()).thenReturn(false);

        plot.setCap(null);
        DialFrame dialFrame = plot.getDialFrame();

        // Using reflection to set dialFrame visibility to false
        java.lang.reflect.Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, false);

        // Mocking Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Mocking viewToFrame method
        Rectangle2D frame = mock(Rectangle2D.class);
        java.lang.reflect.Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        when(viewToFrameMethod.invoke(plot, area)).thenReturn(frame);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(layer1).draw(g2, plot, frame, area);
        verify(layer2).draw(g2, plot, frame, area);
        verify(g2).setClip(Mockito.any(Shape.class));
    }

    @Test
    @DisplayName("Draw method with non-null and invisible background, with visible layers clipped to window, no pointers, no cap, dialFrame not visible")
    public void TC08() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        DialLayer background = mock(DialLayer.class);
        plot.setBackground(background);
        when(background.isVisible()).thenReturn(false);

        DialLayer layer1 = mock(DialLayer.class);
        DialLayer layer2 = mock(DialLayer.class);
        plot.addLayer(layer1);
        plot.addLayer(layer2);
        when(layer1.isVisible()).thenReturn(true);
        when(layer1.isClippedToWindow()).thenReturn(true);
        when(layer2.isVisible()).thenReturn(true);
        when(layer2.isClippedToWindow()).thenReturn(true);

        plot.setCap(null);
        DialFrame dialFrame = plot.getDialFrame();

        // Using reflection to set dialFrame visibility to false
        java.lang.reflect.Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, false);

        // Mocking Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Mocking viewToFrame method
        Rectangle2D frame = mock(Rectangle2D.class);
        java.lang.reflect.Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        when(viewToFrameMethod.invoke(plot, area)).thenReturn(frame);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(g2).clip(any(Shape.class));
        verify(layer1).draw(g2, plot, frame, area);
        verify(layer2).draw(g2, plot, frame, area);
        verify(g2).setClip(Mockito.any(Shape.class));
    }

    @Test
    @DisplayName("Draw method with null background, visible pointers, no layers, no cap, dialFrame not visible")
    public void TC09() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        plot.setBackground(null);

        DialPointer pointer1 = mock(DialPointer.class);
        DialPointer pointer2 = mock(DialPointer.class);
        plot.addPointer(pointer1);
        plot.addPointer(pointer2);
        when(pointer1.isVisible()).thenReturn(true);
        when(pointer1.isClippedToWindow()).thenReturn(false);
        when(pointer2.isVisible()).thenReturn(true);
        when(pointer2.isClippedToWindow()).thenReturn(false);

        plot.setCap(null);
        DialFrame dialFrame = plot.getDialFrame();

        // Using reflection to set dialFrame visibility to false
        java.lang.reflect.Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, false);

        // Mocking Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Mocking viewToFrame method
        Rectangle2D frame = mock(Rectangle2D.class);
        java.lang.reflect.Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        when(viewToFrameMethod.invoke(plot, area)).thenReturn(frame);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(pointer1).draw(g2, plot, frame, area);
        verify(pointer2).draw(g2, plot, frame, area);
        verify(g2).setClip(Mockito.any(Shape.class));
    }

    @Test
    @DisplayName("Draw method with null background, visible pointers clipped to window, no layers, no cap, dialFrame not visible")
    public void TC10() throws Exception {
        // GIVEN
        DialPlot plot = new DialPlot();
        plot.setBackground(null);

        DialPointer pointer1 = mock(DialPointer.class);
        DialPointer pointer2 = mock(DialPointer.class);
        plot.addPointer(pointer1);
        plot.addPointer(pointer2);
        when(pointer1.isVisible()).thenReturn(true);
        when(pointer1.isClippedToWindow()).thenReturn(true);
        when(pointer2.isVisible()).thenReturn(true);
        when(pointer2.isClippedToWindow()).thenReturn(true);

        plot.setCap(null);
        DialFrame dialFrame = plot.getDialFrame();

        // Using reflection to set dialFrame visibility to false
        java.lang.reflect.Method setVisibleMethod = DialFrame.class.getDeclaredMethod("setVisible", boolean.class);
        setVisibleMethod.setAccessible(true);
        setVisibleMethod.invoke(dialFrame, false);

        // Mocking Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = mock(Rectangle2D.class);
        Point2D centerPoint = mock(Point2D.class);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Mocking viewToFrame method
        Rectangle2D frame = mock(Rectangle2D.class);
        java.lang.reflect.Method viewToFrameMethod = DialPlot.class.getDeclaredMethod("viewToFrame", Rectangle2D.class);
        viewToFrameMethod.setAccessible(true);
        when(viewToFrameMethod.invoke(plot, area)).thenReturn(frame);

        // WHEN
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // THEN
        verify(g2).clip(any(Shape.class));
        verify(pointer1).draw(g2, plot, frame, area);
        verify(pointer2).draw(g2, plot, frame, area);
        verify(g2).setClip(Mockito.any(Shape.class));
    }
}