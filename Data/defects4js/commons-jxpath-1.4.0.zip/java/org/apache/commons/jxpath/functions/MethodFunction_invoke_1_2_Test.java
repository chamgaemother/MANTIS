package org.apache.commons.jxpath.functions;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MethodFunction_invoke_1_2_Test {

//     @Test
//     @DisplayName("invoke method and handle InvocationTargetException with non-Runtime exception")
//     public void invoke_method_and_handle_InvocationTargetException_with_non_Runtime_exception() throws Exception {
        // Arrange
//         ExpressionContext context = mock(ExpressionContext.class);
//         Object[] parameters = new Object[]{"param1"};
// 
//         Method method = mock(Method.class);
//         when(method.getModifiers()).thenReturn(Modifier.PUBLIC);
//         when(method.invoke(null, parameters)).thenThrow(new InvocationTargetException(new IOException("IO Error")));
// 
        // Use reflection to create MethodFunction instance
//         Class<MethodFunction> clazz = MethodFunction.class;
//         Method constructor = clazz.getDeclaredConstructor(Method.class);
//         constructor.setAccessible(true);
//         MethodFunction function = (MethodFunction) constructor.invoke(null, method);
// 
        // Act & Assert
//         JXPathInvalidAccessException exception = assertThrows(JXPathInvalidAccessException.class, () -> {
//             function.invoke(context, parameters);
//         });
//         assertTrue(exception.getCause() instanceof IOException);
//         assertEquals("IO Error", exception.getCause().getMessage());
//     }
}