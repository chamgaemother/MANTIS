package org.apache.commons.compress.harmony.pack200;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.InputStream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class CodecEncoding_getCodec_0_2_Test {

    @Test
    @DisplayName("Throws EOFException when value is 116 and first InputStream.read() returns -1")
    void TC06() {
        // GIVEN
        int value = 116;
        byte[] data = { (byte) -1 };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN & THEN
        EOFException exception = assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("End of buffer read whilst trying to decode codec", exception.getMessage());
    }

    @Test
    @DisplayName("Throws EOFException when value is 116 and second InputStream.read() returns -1")
    void TC07() {
        // GIVEN
        int value = 116;
        byte[] data = { 0x0F, (byte) -1 };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN & THEN
        EOFException exception = assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("End of buffer read whilst trying to decode codec", exception.getMessage());
    }

    @Test
    @DisplayName("Throws Pack200Exception when value is between 117-140 and both adef and bdef are true")
    void TC08() {
        // GIVEN
        int value = 130;
        byte[] data = {};
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN & THEN
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("ADef and BDef should never both be true", exception.getMessage());
    }

    @Test
    @DisplayName("Returns RunCodec when value is between 117-140, adef=true, bdef=false, and kbflag=true")
    void TC09() {
        // GIVEN
        int value = 120;
        byte[] data = { 0x04, 0x05, 0x06 };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        assertNotNull(result, "Resulting Codec should not be null");
        assertTrue(result instanceof RunCodec, "Result should be an instance of RunCodec");
        // Additional assertions for RunCodec parameters can be added here if getters are available
    }

    @Test
    @DisplayName("Returns RunCodec when value is between 117-140, adef=true, bdef=false, and kbflag=false")
    void TC10() {
        // GIVEN
        int value = 118;
        byte[] data = { 0x07, 0x08 };
        InputStream in = new ByteArrayInputStream(data);
        Codec defaultCodec = new DefaultCodec();

        // WHEN
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);

        // THEN
        assertNotNull(result, "Resulting Codec should not be null");
        assertTrue(result instanceof RunCodec, "Result should be an instance of RunCodec");
        // Verify k is calculated using kb=3 if applicable
        // Additional assertions can be added here based on RunCodec's properties
    }
    
}