package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Arc2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Arrays;

import org.jfree.chart.labels.PieToolTipGenerator;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.chart.util.PaintAlpha;
import org.jfree.data.general.PieDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class PiePlot3DTest {

    private PiePlot3D plot;
    private Graphics2D g2;
    private Rectangle2D plotArea;
    private Point2D anchor;
    private PlotState parentState;
    private PlotRenderingInfo info;
    private PieDataset dataset;
    private PlotShadowGenerator shadowGenerator;

    @BeforeEach
    public void setUp() {
        plot = new PiePlot3D();
        g2 = mock(Graphics2D.class);
        plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        anchor = new Point2D.Double(200, 150);
        parentState = mock(PlotState.class);
        info = mock(PlotRenderingInfo.class);
        dataset = mock(PieDataset.class);
        shadowGenerator = mock(PlotShadowGenerator.class);
    }

    @Test
    public void testDrawWithNullGraphics() {
        assertThrows(NullPointerException.class, () -> {
            plot.draw(null, plotArea, anchor, parentState, info);
        });
    }

    @Test
    public void testDrawWithNullPlotArea() {
        assertThrows(NullPointerException.class, () -> {
            plot.draw(g2, null, anchor, parentState, info);
        });
    }

    @Test
    public void testDrawWithNullDataset() {
        plot.setDataset(null);
        plot.draw(g2, plotArea, anchor, parentState, info);
        verify(g2).setClip(any());
        verify(g2).drawString(eq("No data available"), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawWithEmptyDataset() {
        when(dataset.getKeys()).thenReturn(Arrays.asList());
        when(plot.getDataset()).thenReturn(dataset);
        plot.draw(g2, plotArea, anchor, parentState, info);
        verify(g2).setClip(any());
        verify(g2).drawString(eq("No data available"), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawWithTooManyElements() {
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B", "C", "D", "E"));
        when(dataset.getValue("A")).thenReturn(10);
        when(dataset.getValue("B")).thenReturn(20);
        when(dataset.getValue("C")).thenReturn(30);
        when(dataset.getValue("D")).thenReturn(40);
        when(dataset.getValue("E")).thenReturn(50);
        when(plot.getDataset()).thenReturn(dataset);
        Rectangle2D largePlotArea = new Rectangle2D.Double(0, 0, 3, 300);
        plot.draw(g2, largePlotArea, anchor, parentState, info);
        verify(g2).drawString(eq("Too many elements"), anyInt(), anyInt());
    }

    @Test
    public void testDrawWithShadowGenerator() {
        plot.setShadowGenerator(shadowGenerator);
        when(shadowGenerator.createDropShadow(any(BufferedImage.class))).thenReturn(new BufferedImage(400, 300, BufferedImage.TYPE_INT_ARGB));
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(30);
        when(dataset.getValue("B")).thenReturn(70);
        plot.draw(g2, plotArea, anchor, parentState, info);
        verify(shadowGenerator).createDropShadow(any(BufferedImage.class));
        verify(g2, times(2)).drawImage(any(BufferedImage.class), anyInt(), anyInt(), any());
    }

    @Test
    public void testDrawWithCircularTrue() {
        plot.setCircular(true, false);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(50);
        when(dataset.getValue("B")).thenReturn(50);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Additional verifications can be added based on internal adjustments
    }

    @Test
    public void testDrawWithDepthFactorNegative() {
        plot.setDepthFactor(-0.1);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A"));
        when(dataset.getValue("A")).thenReturn(100);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Should not draw anything due to negative depth
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    public void testDrawWithZeroAndNegativeValues() {
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B", "C"));
        when(dataset.getValue("A")).thenReturn(100);
        when(dataset.getValue("B")).thenReturn(0);
        when(dataset.getValue("C")).thenReturn(-50);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Only "A" should be processed
        verify(g2, atLeastOnce()).fill(any(Arc2D.class));
    }

    @Test
    public void testDrawWithMinimumArcAngle() {
        plot.setMinimumArcAngleToDraw(10.0);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(1);
        when(dataset.getValue("B")).thenReturn(99);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // "A" might be below minimum angle and not drawn
        // Verification can be added based on internal arc list
    }

    @Test
    public void testDrawWithDarkerSidesTrue() {
        plot.setDarkerSides(true);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(60);
        when(dataset.getValue("B")).thenReturn(40);
        Paint originalPaint = Color.RED;
        Paint darkerPaint = PaintAlpha.darker(originalPaint);
        when(plot.lookupSectionPaint("A")).thenReturn(originalPaint);
        when(plot.lookupSectionOutlinePaint("A")).thenReturn(Color.BLACK);
        when(plot.lookupSectionOutlineStroke("A")).thenReturn(new BasicStroke(1.0f));
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Verify that darker paint is used for sides
    }

    @Test
    public void testDrawWithLabelGenerator() {
        plot.setLabelGenerator(mock(PieToolTipGenerator.class));
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A"));
        when(dataset.getValue("A")).thenReturn(100);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Verify tooltip generation
    }

    @Test
    public void testDrawWithSimpleLabels() {
        plot.setSimpleLabels(true);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(70);
        when(dataset.getValue("B")).thenReturn(30);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Verify simple label drawing
    }

    @Test
    public void testDrawWithNonSimpleLabels() {
        plot.setSimpleLabels(false);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B", "C"));
        when(dataset.getValue("A")).thenReturn(40);
        when(dataset.getValue("B")).thenReturn(30);
        when(dataset.getValue("C")).thenReturn(30);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Verify regular label drawing
    }

    @Test
    public void testDrawWithDirectionClockwise() {
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(25);
        when(dataset.getValue("B")).thenReturn(75);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Verify segments are drawn clockwise
    }

    @Test
    public void testDrawWithDirectionAnticlockwise() {
        plot.setDirection(Rotation.ANTICLOCKWISE);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(25);
        when(dataset.getValue("B")).thenReturn(75);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Verify segments are drawn anticlockwise
    }

    @Test
    public void testDrawWithExplodedSections() {
        plot.setExplodePercent("A", 0.1);
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B"));
        when(dataset.getValue("A")).thenReturn(50);
        when(dataset.getValue("B")).thenReturn(50);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Verify exploded section drawing
    }

    @Test
    public void testDrawWithNullInfo() {
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A"));
        when(dataset.getValue("A")).thenReturn(100);
        plot.draw(g2, plotArea, anchor, parentState, null);
        // Should handle null PlotRenderingInfo gracefully
    }

    @Test
    public void testDrawWithFullCycle() {
        plot.setDataset(dataset);
        when(dataset.getKeys()).thenReturn(Arrays.asList("A", "B", "C"));
        when(dataset.getValue("A")).thenReturn(30);
        when(dataset.getValue("B")).thenReturn(50);
        when(dataset.getValue("C")).thenReturn(20);
        plot.draw(g2, plotArea, anchor, parentState, info);
        // Comprehensive test covering multiple segments
    }

}