package org.apache.commons.math3.special;

import org.apache.commons.math3.exception.MaxCountExceededException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Gamma_regularizedGammaP_1_1_Test {

    @Test
    @DisplayName("regularizedGammaP with x equal to a + 1 tests exact boundary condition")
    void test_TC15_regularizedGammaP_boundary_value_x_equals_a_plus_1() {
        // GIVEN
        double a = 3.0;
        double x = a + 1.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);
        double expected = 1.0 - Gamma.regularizedGammaQ(a, x, epsilon, maxIterations);

        // THEN
        assertEquals(expected, result, epsilon, "Result should be 1.0 minus regularizedGammaQ(a, x, epsilon, maxIterations)");
    }

    @Test
    @DisplayName("regularizedGammaP with x as Double.POSITIVE_INFINITY returns 1.0")
    void test_TC16_regularizedGammaP_with_infinite_x_returns_1_0() {
        // GIVEN
        double a = 2.0;
        double x = Double.POSITIVE_INFINITY;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        // THEN
        assertEquals(1.0, result, "Result should be 1.0 when x is positive infinity");
    }
}