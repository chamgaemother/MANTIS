package org.jfree.chart;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import static org.mockito.Mockito.*;

import java.awt.event.ActionEvent;
import java.awt.geom.Point2D;
import java.io.IOException;
import java.lang.reflect.Field;
import javax.swing.JOptionPane;

public class ChartPanel_actionPerformed_0_2_Test {

//    @Test
//    @DisplayName("actionPerformed with command 'SAVE_AS_PNG' throws IOException and zoomPoint is null")
//    public void TC06_actionPerformed_SAVE_AS_PNG_IOException_zoomPoint_null() throws Exception {
//        // Arrange
//        ChartPanel chartPanel = spy(new ChartPanel((JFreeChart) null));
//
//        // Set zoomPoint to null using reflection
//        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//        zoomPointField.setAccessible(true);
//        zoomPointField.set(chartPanel, null);
//
//        // Mock ActionEvent with command 'SAVE_AS_PNG'
//        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "SAVE_AS_PNG");
//
//        // Mock doSaveAs() to throw IOException
//        doThrow(new IOException()).when(chartPanel).doSaveAs();
//
//        // Mock JOptionPane.showMessageDialog using MockedStatic
//        try (MockedStatic<JOptionPane> mockedJOptionPane = mockStatic(JOptionPane.class)) {
//            // Act
//            chartPanel.actionPerformed(event);
//
//            // Assert
//            mockedJOptionPane.verify(() -> JOptionPane.showMessageDialog(
//                chartPanel,
//                "I/O error occurred.",
//                chartPanel.localizationResources.getString("Save_as_PNG"),
//                JOptionPane.WARNING_MESSAGE
//            ));
//        }
//    }
//
//    @Test
//    @DisplayName("actionPerformed with command 'SAVE_AS_PNG' successfully saves the chart and zoomPoint is non-null")
//    public void TC07_actionPerformed_SAVE_AS_PNG_success_zoomPoint_non_null() throws Exception {
//        // Arrange
//        ChartPanel chartPanel = spy(new ChartPanel((JFreeChart) null));
//
//        // Set zoomPoint to a valid Point2D using reflection
//        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//        zoomPointField.setAccessible(true);
//        Point2D zoomPoint = new Point2D.Double(100.0, 200.0);
//        zoomPointField.set(chartPanel, zoomPoint);
//
//        // Mock ActionEvent with command 'SAVE_AS_PNG'
//        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "SAVE_AS_PNG");
//
//        // Act
//        chartPanel.actionPerformed(event);
//
//        // Assert
//        verify(chartPanel, times(1)).doSaveAs();
//    }

//     @Test
//     @DisplayName("actionPerformed with command 'SAVE_AS_SVG' successfully saves the chart and zoomPoint is null")
//     public void TC08_actionPerformed_SAVE_AS_SVG_success_zoomPoint_null() throws Exception {
        // Arrange
//         ChartPanel chartPanel = spy(new ChartPanel((JFreeChart) null));
// 
        // Set zoomPoint to null using reflection
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, null);
// 
        // Mock ActionEvent with command 'SAVE_AS_SVG'
//         ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "SAVE_AS_SVG");
// 
        // Act
//         chartPanel.actionPerformed(event);
// 
        // Assert
//         verify(chartPanel, times(1)).saveAsSVG(null);
//     }

//     @Test
//     @DisplayName("actionPerformed with command 'SAVE_AS_SVG' throws IOException and zoomPoint is null")
//     public void TC09_actionPerformed_SAVE_AS_SVG_IOException_zoomPoint_null() throws Exception {
        // Arrange
//         ChartPanel chartPanel = spy(new ChartPanel((JFreeChart) null));
// 
        // Set zoomPoint to null using reflection
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, null);
// 
        // Mock ActionEvent with command 'SAVE_AS_SVG'
//         ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "SAVE_AS_SVG");
// 
        // Mock saveAsSVG(null) to throw IOException
//         doThrow(new IOException()).when(chartPanel).saveAsSVG(null);
// 
        // Mock JOptionPane.showMessageDialog using MockedStatic
//         try (MockedStatic<JOptionPane> mockedJOptionPane = mockStatic(JOptionPane.class)) {
            // Act
//             chartPanel.actionPerformed(event);
// 
            // Assert
//             mockedJOptionPane.verify(() -> JOptionPane.showMessageDialog(
//                 chartPanel,
//                 "I/O error occurred.",
//                 chartPanel.localizationResources.getString("Save_as_SVG"),
//                 JOptionPane.WARNING_MESSAGE
//             ));
//         }
//     }

//     @Test
//     @DisplayName("actionPerformed with command 'SAVE_AS_PDF' and zoomPoint is null")
//     public void TC10_actionPerformed_SAVE_AS_PDF_zoomPoint_null() throws Exception {
        // Arrange
//         ChartPanel chartPanel = spy(new ChartPanel((JFreeChart) null));
// 
        // Set zoomPoint to null using reflection
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, null);
// 
        // Mock ActionEvent with command 'SAVE_AS_PDF'
//         ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "SAVE_AS_PDF");
// 
        // Act
//         chartPanel.actionPerformed(event);
// 
        // Assert
//         verify(chartPanel, times(1)).saveAsPDF(null);
//     }

}