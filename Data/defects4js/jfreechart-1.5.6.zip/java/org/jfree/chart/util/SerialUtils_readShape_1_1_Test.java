package org.jfree.chart.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.ObjectInputStream;

import org.jfree.chart.util.SerialUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/**
 * Test class for SerialUtils.readShape method.
 */
public class SerialUtils_readShape_1_1_Test {

    @Test
    @DisplayName("readShape throws IOException when stream.readObject() throws IOException while reading class object")
    void TC21() throws Exception {
        // Arrange
        ObjectInputStream stream = Mockito.mock(ObjectInputStream.class);
        Mockito.when(stream.readBoolean()).thenReturn(false);
        Mockito.when(stream.readObject()).thenThrow(new IOException("Test IOException"));

        // Act & Assert
        assertThrows(IOException.class, () -> {
            SerialUtils.readShape(stream);
        });
    }

    @Test
    @DisplayName("readShape throws ClassNotFoundException when stream.readObject() throws ClassNotFoundException while reading class object")
    void TC22() throws Exception {
        // Arrange
        ObjectInputStream stream = Mockito.mock(ObjectInputStream.class);
        Mockito.when(stream.readBoolean()).thenReturn(false);
        Mockito.when(stream.readObject()).thenThrow(new ClassNotFoundException("Test ClassNotFoundException"));

        // Act & Assert
        assertThrows(ClassNotFoundException.class, () -> {
            SerialUtils.readShape(stream);
        });
    }
}