package org.apache.commons.jxpath;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.apache.commons.jxpath.Function;

import java.lang.reflect.*;
// Import necessary classes
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.apache.commons.jxpath.functions.MethodFunction;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class focusing on the function lookup capabilities of PackageFunctions
 */
public class PackageFunctions_getFunction_0_1_Test {

    @Test
    @DisplayName("Namespace does not match; method returns null")
    void TC01() throws Exception {
        // Initialize PackageFunctions instance with mock namespace
        PackageFunctions pf = new PackageFunctions("", "ns1");

        String namespace = "ns2";
        String name = "functionName";
        Object[] parameters = new Object[] { /* ... */ };

        // Invoke the target method
        Function result = pf.getFunction(namespace, name, parameters);

        // Assert the result is null
        assertNull(result, "Expected result to be null due to namespace mismatch");
    }

    @Test
    @DisplayName("Namespace matches and parameters are null; parameters set to EMPTY_ARRAY")
    void TC02() throws Exception {
        // Initialize PackageFunctions instance with mock namespace
        PackageFunctions pf = new PackageFunctions("", "ns1");

        String namespace = "ns1";
        String name = "nonExistentFunction";
        Object[] parameters = null;

        // Invoke the target method
        Function result = pf.getFunction(namespace, name, parameters);

        // Assert the result is null
        assertNull(result, "Expected result to be null due to method lookup failure");
    }

    @Test
    @DisplayName("Parameters are empty after null handling; method proceeds to build fullName and returns null")
    void TC03() throws Exception {
        // Initialize PackageFunctions instance with mock namespace
        PackageFunctions pf = new PackageFunctions("", "ns1");

        String namespace = "ns1";
        String name = "nonExistentFunction";
        Object[] parameters = new Object[0];

        // Invoke the target method
        Function result = pf.getFunction(namespace, name, parameters);

        // Assert the result is null
        assertNull(result, "Expected result to be null due to insufficient parameters");
    }

    @Test
    @DisplayName("Parameters provided but conversion results in null; method sets target to null and proceeds")
    void TC04() throws Exception {
        // Initialize PackageFunctions instance with mock namespace
        PackageFunctions pf = new PackageFunctions("", "ns1");

        String namespace = "ns1";
        String name = "functionName";
        Object[] parameters = new Object[] { null };

        // Invoke the target method
        Function result = pf.getFunction(namespace, name, parameters);

        // Assert the result is null
        assertNull(result, "Expected result to be null due to target conversion being null");
    }

    @Test
    @DisplayName("Method lookup succeeds on target's class; returns MethodFunction")
    void TC05() throws Exception {
        // Initialize PackageFunctions instance with mock namespace
        PackageFunctions pf = new PackageFunctions("java.util.", "ns1");

        String namespace = "ns1";
        String name = "Collections:singleton";
        Object[] parameters = new Object[] { "validTarget" };

        // Invoke the target method
        Function result = pf.getFunction(namespace, name, parameters);

        // Assert the result is an instance of MethodFunction
        assertTrue(result instanceof MethodFunction, "Expected result to be an instance of MethodFunction");
    }

}