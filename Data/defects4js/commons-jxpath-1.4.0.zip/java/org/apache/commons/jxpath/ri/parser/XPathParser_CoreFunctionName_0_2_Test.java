package org.apache.commons.jxpath.ri.parser;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Field;

import org.apache.commons.jxpath.ri.Compiler;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XPathParser_CoreFunctionName_0_2_Test {

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_NAMESPACE_URI returns Compiler.FUNCTION_NAMESPACE_URI")
    void TC06() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and set jj_nt.kind via reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.FUNCTION_NAMESPACE_URI);

        // Invoke CoreFunctionName method
        int result = parser.CoreFunctionName();

        // Assert the expected result
        assertEquals(Compiler.FUNCTION_NAMESPACE_URI, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_NAME returns Compiler.FUNCTION_NAME")
    void TC07() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and set jj_nt.kind via reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.FUNCTION_NAME);

        // Invoke CoreFunctionName method
        int result = parser.CoreFunctionName();

        // Assert the expected result
        assertEquals(Compiler.FUNCTION_NAME, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_STRING returns Compiler.FUNCTION_STRING")
    void TC08() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and set jj_nt.kind via reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.FUNCTION_STRING);

        // Invoke CoreFunctionName method
        int result = parser.CoreFunctionName();

        // Assert the expected result
        assertEquals(Compiler.FUNCTION_STRING, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_CONCAT returns Compiler.FUNCTION_CONCAT")
    void TC09() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and set jj_nt.kind via reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.FUNCTION_CONCAT);

        // Invoke CoreFunctionName method
        int result = parser.CoreFunctionName();

        // Assert the expected result
        assertEquals(Compiler.FUNCTION_CONCAT, result);
    }

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_STARTS_WITH returns Compiler.FUNCTION_STARTS_WITH")
    void TC10() throws Exception {
        // Instantiate XPathParser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Access and set jj_nt.kind via reflection
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(parser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.FUNCTION_STARTS_WITH);

        // Invoke CoreFunctionName method
        int result = parser.CoreFunctionName();

        // Assert the expected result
        assertEquals(Compiler.FUNCTION_STARTS_WITH, result);
    }
}