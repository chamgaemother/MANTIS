package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_7_Test {

    @Test
    @DisplayName("doubleMetaphone handles 'PS' prefix in 'PSYCHO'")
    public void TC31_doubleMetaphone_PSYCHO() throws Exception {
        // Given
        String value = "PSYCHO";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("S"), "Encoded 'PS' should contain 'S'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'Z' at end in 'LEHZ'")
    public void TC32_doubleMetaphone_LEHZ() throws Exception {
        // Given
        String value = "LEHZ";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("S"), "Encoded 'Z' should be 'S'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'CIO' sequence in 'FOCIACCI'")
    public void TC33_doubleMetaphone_FOCIACCI() throws Exception {
        // Given
        String value = "FOCIACCI";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("X"), "Encoded 'CIO' should be 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'N' with tilde in 'NIÃO'")
    public void TC34_doubleMetaphone_NIÃO() throws Exception {
        // Given
        String value = "NIÃO";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        assertTrue(result.contains("N"), "Encoded 'Ã' should be 'N'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'R' at the end with 'IE' in 'MERRIE'")
    public void TC35_doubleMetaphone_MERRIE() throws Exception {
        // Given
        String value = "MERRIE";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();

        // When
        String result = doubleMetaphone.doubleMetaphone(value, false);

        // Then
        // Since the scenario mentions alternate encoding but 'false' is passed,
        // we'll check the primary encoding for 'R'.
        assertTrue(result.contains("R"), "Encoded 'R' should be present");
    }
}