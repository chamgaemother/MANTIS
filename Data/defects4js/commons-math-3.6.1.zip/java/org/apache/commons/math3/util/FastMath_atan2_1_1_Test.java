package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class FastMath_atan2_1_1_Test {

    @Test
    @DisplayName("atan2(y=1.7320508075688772 (sqrt(3)), x=1.0) returns Math.PI/3 for y and x in the first quadrant with y/x = sqrt(3)")
    void testTC31() {
        double y = 1.7320508075688772;
        double x = 1.0;
        double result = FastMath.atan2(y, x);
        assertEquals(Math.PI / 3, result, 1e-10);
    }

    @Test
    @DisplayName("atan2(y=1.0, x=1.7320508075688772 (sqrt(3))) returns Math.PI/6 for y and x in the first quadrant with y/x = 1/sqrt(3)")
    void testTC32() {
        double y = 1.0;
        double x = 1.7320508075688772;
        double result = FastMath.atan2(y, x);
        assertEquals(Math.PI / 6, result, 1e-10);
    }

    @Test
    @DisplayName("atan2(y=1.0, x=-1.0) returns 3*Math.PI/4 for positive y and negative x in the second quadrant")
    void testTC33() {
        double y = 1.0;
        double x = -1.0;
        double result = FastMath.atan2(y, x);
        assertEquals(3 * Math.PI / 4, result, 1e-10);
    }

    @Test
    @DisplayName("atan2(y=-1.0, x=-1.0) returns -3*Math.PI/4 for negative y and negative x in the third quadrant")
    void testTC34() {
        double y = -1.0;
        double x = -1.0;
        double result = FastMath.atan2(y, x);
        assertEquals(-3 * Math.PI / 4, result, 1e-10);
    }

    @Test
    @DisplayName("atan2(y=-1.0, x=1.0) returns -Math.PI/4 for negative y and positive x in the fourth quadrant")
    void testTC35() {
        double y = -1.0;
        double x = 1.0;
        double result = FastMath.atan2(y, x);
        assertEquals(-Math.PI / 4, result, 1e-10);
    }

}