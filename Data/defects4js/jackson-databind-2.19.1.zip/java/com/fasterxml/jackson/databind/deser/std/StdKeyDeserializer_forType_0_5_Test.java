package com.fasterxml.jackson.databind.deser.std;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class StdKeyDeserializer_forType_0_5_Test {

    @Test
    @DisplayName("forType(byte[].class) returns StdKeyDeserializer with TYPE_BYTE_ARRAY")
    void TC21_forTypeWithByteArrayClass() throws Exception {
        // GIVEN
        Class<?> raw = byte[].class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNotNull(result, "Result should not be null");

        // Access 'kind' field via reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);
        assertEquals(17, kind, "Kind should be TYPE_BYTE_ARRAY");

        // Access 'raw' field via reflection
        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> resultRaw = (Class<?>) rawField.get(result);
        assertEquals(byte[].class, resultRaw, "Raw class should be byte[].class");
    }

    @Test
    @DisplayName("forType(List.class) returns null for unsupported type")
    void TC22_forTypeWithListClass() {
        // GIVEN
        Class<?> raw = List.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNull(result, "Result should be null for unsupported type");
    }

    @Test
    @DisplayName("forType(null) returns null")
    void TC23_forTypeWithNull() {
        // GIVEN
        Class<?> raw = null;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        assertNull(result, "Result should be null when input is null");
    }
}