package org.apache.commons.collections4.functors;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ComparatorPredicate_test_0_1_Test {

    private enum Criterion {
        EQUAL, GREATER, LESS, GREATER_OR_EQUAL, LESS_OR_EQUAL
    }

    private static class ComparatorPredicate {
        private final Comparator<Object> comparator;
        private final Object target;
        private final Criterion criterion;

        public ComparatorPredicate(Comparator<Object> comparator, Object target, Criterion criterion) {
            this.comparator = comparator;
            this.target = target;
            this.criterion = criterion;
        }

        public boolean test(Object object) {
            boolean result = false;
            final int comparison = comparator.compare(object, target);
            switch (criterion) {
            case EQUAL:
                result = comparison == 0;
                break;
            case GREATER:
                result = comparison > 0;
                break;
            case LESS:
                result = comparison < 0;
                break;
            case GREATER_OR_EQUAL:
                result = comparison >= 0;
                break;
            case LESS_OR_EQUAL:
                result = comparison <= 0;
                break;
            default:
                throw new IllegalStateException("The current criterion '" + criterion + "' is invalid.");
            }

            return result;
        }
    }

    @Test
    @DisplayName("Criterion EQUAL, comparator returns 0, expect true as objects are equal")
    void testEqualObjects() {
        Comparator<Object> comparator = (o1, o2) -> 0;
        Criterion criterion = Criterion.EQUAL;
        Object object = new Object();

        ComparatorPredicate predicate = new ComparatorPredicate(comparator, object, criterion);
        assertTrue(predicate.test(object));
    }

    @Test
    @DisplayName("Criterion EQUAL, comparator returns non-zero, expect false as objects are not equal")
    void testNonEqualObjects() {
        Comparator<Object> comparator = (o1, o2) -> 1;
        Criterion criterion = Criterion.EQUAL;
        Object object = new Object();

        ComparatorPredicate predicate = new ComparatorPredicate(comparator, object, criterion);
        assertFalse(predicate.test(object));
    }

    @Test
    @DisplayName("Criterion GREATER, comparator returns positive, expect true as first object is greater")
    void testGreaterObjects() {
        Comparator<Object> comparator = (o1, o2) -> 1;
        Criterion criterion = Criterion.GREATER;
        Object object = new Object();

        ComparatorPredicate predicate = new ComparatorPredicate(comparator, object, criterion);
        assertTrue(predicate.test(object));
    }

    @Test
    @DisplayName("Criterion GREATER, comparator returns 0, expect false as objects are not greater")
    void testNotGreaterObjects() {
        Comparator<Object> comparator = (o1, o2) -> 0;
        Criterion criterion = Criterion.GREATER;
        Object object = new Object();

        ComparatorPredicate predicate = new ComparatorPredicate(comparator, object, criterion);
        assertFalse(predicate.test(object));
    }

    @Test
    @DisplayName("Criterion LESS, comparator returns negative, expect true as first object is less")
    void testLessObjects() {
        Comparator<Object> comparator = (o1, o2) -> -1;
        Criterion criterion = Criterion.LESS;
        Object object = new Object();

        ComparatorPredicate predicate = new ComparatorPredicate(comparator, object, criterion);
        assertTrue(predicate.test(object));
    }
}