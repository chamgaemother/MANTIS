package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import org.jfree.chart.StrokeMap;
import org.jfree.chart.PaintMap;
import org.jfree.chart.labels.StandardPieToolTipGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.ui.RectangleInsets;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class PiePlot_hashCode_0_2_Test {

//     @Test
//     @DisplayName("hashCode with simpleLabels=false and ignoreZeroValues=false")
//     public void testTC06() {
//         PiePlot plot = new PiePlot();
//         plot.setCircular(true);
//         plot.setSimpleLabels(false);
//         plot.setIgnoreZeroValues(false);
//         plot.setAutoPopulateSectionPaint(true);
//         plot.setSectionOutlinesVisible(true);
//         plot.setAutoPopulateSectionOutlinePaint(true);
//         plot.setAutoPopulateSectionOutlineStroke(true);
//         plot.setShadowPaint(Color.BLACK);
//         plot.setShadowXOffset(0.0);
//         plot.setShadowYOffset(0.0);
//         plot.setIgnoreNullValues(true);
//         plot.setMaximumLabelWidth(1.0);
//         plot.setLabelGap(0.1);
//         plot.setLabelLinksVisible(true);
//         plot.setIgnoreZeroValues(false);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.sectionPaintMap = new PaintMap();
//         plot.defaultSectionPaint = Color.BLACK;
//         plot.sectionOutlinePaintMap = new PaintMap();
//         plot.defaultSectionOutlinePaint = Color.BLACK;
//         plot.sectionOutlineStrokeMap = new StrokeMap();
//         plot.defaultSectionOutlineStroke = new BasicStroke(1.0f);
//         plot.explodePercentages = new HashMap<>();
//         plot.labelGenerator = new StandardPieSectionLabelGenerator();
//         plot.labelFont = new Font("Arial", Font.PLAIN, 12);
//         plot.labelPaint = Color.BLACK;
//         plot.labelBackgroundPaint = Color.WHITE;
//         plot.labelOutlinePaint = Color.BLACK;
//         plot.labelOutlineStroke = new BasicStroke(1.0f);
//         plot.labelShadowPaint = Color.BLACK;
//         plot.labelPadding = new RectangleInsets(0, 0, 0, 0);
//         plot.simpleLabelOffset = new RectangleInsets(0, 0, 0, 0);
//         plot.labelLinkStyle = PieLabelLinkStyle.STANDARD;
//         plot.labelLinkPaint = Color.BLACK;
//         plot.labelLinkStroke = new BasicStroke(1.0f);
//         plot.setToolTipGenerator(new StandardPieToolTipGenerator());
//         plot.setURLGenerator(null);
//         plot.legendLabelGenerator = new StandardPieSectionLabelGenerator();
//         plot.legendLabelToolTipGenerator = null;
//         plot.legendLabelURLGenerator = null;
//         plot.legendItemShape = new Rectangle2D.Double(0, 0, 1, 1);
//         plot.setMinimumArcAngleToDraw(0.0);
//         plot.shadowGenerator = null;
// 
//         int result = plot.hashCode();
// 
//         assertNotEquals(0, result, "Hash code should be non-zero");
//     }

//     @Test
//     @DisplayName("hashCode with all boolean fields false")
//     public void testTC07() {
//         PiePlot plot = new PiePlot();
//         plot.setCircular(false);
//         plot.setAutoPopulateSectionPaint(false);
//         plot.setSectionOutlinesVisible(false);
//         plot.setAutoPopulateSectionOutlinePaint(false);
//         plot.setAutoPopulateSectionOutlineStroke(false);
//         plot.setSimpleLabels(false);
//         plot.setLabelLinksVisible(false);
//         plot.setIgnoreNullValues(false);
//         plot.setIgnoreZeroValues(false);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.sectionPaintMap = new PaintMap();
//         plot.defaultSectionPaint = Color.BLACK;
//         plot.sectionOutlinePaintMap = new PaintMap();
//         plot.defaultSectionOutlinePaint = Color.BLACK;
//         plot.sectionOutlineStrokeMap = new StrokeMap();
//         plot.defaultSectionOutlineStroke = new BasicStroke(1.0f);
//         plot.setShadowPaint(Color.BLACK);
//         plot.setShadowXOffset(0.0);
//         plot.setShadowYOffset(0.0);
//         plot.explodePercentages = new HashMap<>();
//         plot.setLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLabelFont(new Font("Arial", Font.PLAIN, 12));
//         plot.setLabelPaint(Color.BLACK);
//         plot.labelBackgroundPaint = Color.WHITE;
//         plot.labelOutlinePaint = Color.BLACK;
//         plot.labelOutlineStroke = new BasicStroke(1.0f);
//         plot.labelShadowPaint = Color.BLACK;
//         plot.setLabelPadding(new RectangleInsets(0, 0, 0, 0));
//         plot.setSimpleLabelOffset(new RectangleInsets(0, 0, 0, 0));
//         plot.setMaximumLabelWidth(1.0);
//         plot.setLabelGap(0.1);
//         plot.setLabelLinkStyle(PieLabelLinkStyle.STANDARD);
//         plot.setLabelLinkPaint(Color.BLACK);
//         plot.setLabelLinkStroke(new BasicStroke(1.0f));
//         plot.setToolTipGenerator(new StandardPieToolTipGenerator());
//         plot.setURLGenerator(null);
//         plot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLegendLabelToolTipGenerator(null);
//         plot.setLegendLabelURLGenerator(null);
//         plot.setLegendItemShape(new Rectangle2D.Double(0, 0, 1, 1));
//         plot.setMinimumArcAngleToDraw(0.0);
//         plot.setShadowGenerator(null);
// 
//         int result = plot.hashCode();
// 
//         assertNotEquals(0, result, "Hash code should be non-zero");
//     }

//     @Test
//     @DisplayName("hashCode with mixed boolean fields and some object fields null")
//     public void testTC08() {
//         PiePlot plot = new PiePlot();
//         plot.setCircular(true);
//         plot.setAutoPopulateSectionPaint(true);
//         plot.setSectionOutlinesVisible(false);
//         plot.setAutoPopulateSectionOutlinePaint(false);
//         plot.setAutoPopulateSectionOutlineStroke(true);
//         plot.setSimpleLabels(true);
//         plot.setLabelLinksVisible(false);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(false);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.sectionPaintMap = null;
//         plot.defaultSectionPaint = Color.BLACK;
//         plot.sectionOutlinePaintMap = new PaintMap();
//         plot.defaultSectionOutlinePaint = Color.BLACK;
//         plot.sectionOutlineStrokeMap = new StrokeMap();
//         plot.defaultSectionOutlineStroke = new BasicStroke(1.0f);
//         plot.setShadowPaint(Color.BLACK);
//         plot.setShadowXOffset(0.0);
//         plot.setShadowYOffset(0.0);
//         plot.explodePercentages = new HashMap<>();
//         plot.setLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLabelFont(new Font("Arial", Font.PLAIN, 12));
//         plot.setLabelPaint(Color.BLACK);
//         plot.labelBackgroundPaint = Color.WHITE;
//         plot.labelOutlinePaint = Color.BLACK;
//         plot.labelOutlineStroke = new BasicStroke(1.0f);
//         plot.labelShadowPaint = Color.BLACK;
//         plot.setLabelPadding(new RectangleInsets(0, 0, 0, 0));
//         plot.setSimpleLabelOffset(new RectangleInsets(0, 0, 0, 0));
//         plot.setMaximumLabelWidth(1.0);
//         plot.setLabelGap(0.1);
//         plot.setLabelLinkStyle(PieLabelLinkStyle.STANDARD);
//         plot.setLabelLinkPaint(Color.BLACK);
//         plot.setLabelLinkStroke(new BasicStroke(1.0f));
//         plot.setToolTipGenerator(new StandardPieToolTipGenerator());
//         plot.setURLGenerator(null);
//         plot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLegendLabelToolTipGenerator(null);
//         plot.setLegendLabelURLGenerator(null);
//         plot.setLegendItemShape(new Rectangle2D.Double(0, 0, 1, 1));
//         plot.setMinimumArcAngleToDraw(0.0);
//         plot.setShadowGenerator(null);
// 
//         int result = plot.hashCode();
// 
//         assertNotEquals(0, result, "Hash code should be non-zero");
//     }

//     @Test
//     @DisplayName("hashCode with maximumLabelWidth and labelGap at boundary values")
//     public void testTC09() {
//         PiePlot plot = new PiePlot();
//         plot.setCircular(true);
//         plot.setMaximumLabelWidth(Double.MAX_VALUE);
//         plot.setLabelGap(Double.MIN_VALUE);
//         plot.setSimpleLabels(true);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(true);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.sectionPaintMap = new PaintMap();
//         plot.defaultSectionPaint = Color.BLACK;
//         plot.sectionOutlinePaintMap = new PaintMap();
//         plot.defaultSectionOutlinePaint = Color.BLACK;
//         plot.sectionOutlineStrokeMap = new StrokeMap();
//         plot.defaultSectionOutlineStroke = new BasicStroke(1.0f);
//         plot.setShadowPaint(Color.BLACK);
//         plot.setShadowXOffset(0.0);
//         plot.setShadowYOffset(0.0);
//         plot.explodePercentages = new HashMap<>();
//         plot.setLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLabelFont(new Font("Arial", Font.PLAIN, 12));
//         plot.setLabelPaint(Color.BLACK);
//         plot.labelBackgroundPaint = Color.WHITE;
//         plot.labelOutlinePaint = Color.BLACK;
//         plot.labelOutlineStroke = new BasicStroke(1.0f);
//         plot.labelShadowPaint = Color.BLACK;
//         plot.setLabelPadding(new RectangleInsets(0, 0, 0, 0));
//         plot.setSimpleLabelOffset(new RectangleInsets(0, 0, 0, 0));
//         plot.setLabelLinkStyle(PieLabelLinkStyle.STANDARD);
//         plot.setLabelLinkPaint(Color.BLACK);
//         plot.setLabelLinkStroke(new BasicStroke(1.0f));
//         plot.setToolTipGenerator(new StandardPieToolTipGenerator());
//         plot.setURLGenerator(null);
//         plot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLegendLabelToolTipGenerator(null);
//         plot.setLegendLabelURLGenerator(null);
//         plot.setLegendItemShape(new Rectangle2D.Double(0, 0, 1, 1));
//         plot.setMinimumArcAngleToDraw(Double.MIN_VALUE);
//         plot.setShadowGenerator(null);
// 
//         int result = plot.hashCode();
// 
//         assertNotEquals(0, result, "Hash code should be non-zero");
//     }

//     @Test
//     @DisplayName("hashCode with shadowXOffset and shadowYOffset as zero")
//     public void testTC10() {
//         PiePlot plot = new PiePlot();
//         plot.setCircular(true);
//         plot.setShadowXOffset(0.0);
//         plot.setShadowYOffset(0.0);
//         plot.setSimpleLabels(true);
//         plot.setIgnoreNullValues(true);
//         plot.setIgnoreZeroValues(true);
//         plot.setDirection(Rotation.CLOCKWISE);
//         plot.sectionPaintMap = new PaintMap();
//         plot.defaultSectionPaint = Color.BLACK;
//         plot.sectionOutlinePaintMap = new PaintMap();
//         plot.defaultSectionOutlinePaint = Color.BLACK;
//         plot.sectionOutlineStrokeMap = new StrokeMap();
//         plot.defaultSectionOutlineStroke = new BasicStroke(1.0f);
//         plot.setShadowPaint(Color.BLACK);
//         plot.explodePercentages = new HashMap<>();
//         plot.setLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLabelFont(new Font("Arial", Font.PLAIN, 12));
//         plot.setLabelPaint(Color.BLACK);
//         plot.labelBackgroundPaint = Color.WHITE;
//         plot.labelOutlinePaint = Color.BLACK;
//         plot.labelOutlineStroke = new BasicStroke(1.0f);
//         plot.labelShadowPaint = Color.BLACK;
//         plot.setLabelPadding(new RectangleInsets(0, 0, 0, 0));
//         plot.setSimpleLabelOffset(new RectangleInsets(0, 0, 0, 0));
//         plot.setMaximumLabelWidth(1.0);
//         plot.setLabelGap(0.1);
//         plot.setLabelLinkStyle(PieLabelLinkStyle.STANDARD);
//         plot.setLabelLinkPaint(Color.BLACK);
//         plot.setLabelLinkStroke(new BasicStroke(1.0f));
//         plot.setToolTipGenerator(new StandardPieToolTipGenerator());
//         plot.setURLGenerator(null);
//         plot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
//         plot.setLegendLabelToolTipGenerator(null);
//         plot.setLegendLabelURLGenerator(null);
//         plot.setLegendItemShape(new Rectangle2D.Double(0, 0, 1, 1));
//         plot.setMinimumArcAngleToDraw(0.0);
//         plot.setShadowGenerator(null);
// 
//         int result = plot.hashCode();
// 
//         assertNotEquals(0, result, "Hash code should be non-zero");
//     }
}