package org.apache.commons.collections4.map;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Flat3Map_put_0_1_Test {

    @Test
    @DisplayName("put when delegateMap is null, key is null, and size is 0 adds first null key")
    public void TC01_put_first_null_key() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Object key = null;
        Object value = "Value1";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(1, map.size());
        
        // Verify internal key1 and value1 via reflection
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object key1 = key1Field.get(map);
        assertNull(key1);
        
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = value1Field.get(map);
        assertEquals("Value1", value1);
    }

    @Test
    @DisplayName("put when delegateMap is null, key is null, and size is 1 adds second null key")
    public void TC02_put_second_null_key() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        map.put(null, "Value1");
        Object key = null;
        Object value = "Value2";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(2, map.size());
        
        // Verify internal key2 and value2 via reflection
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object key2 = key2Field.get(map);
        assertNull(key2);
        
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = value2Field.get(map);
        assertEquals("Value2", value2);
    }

    @Test
    @DisplayName("put when delegateMap is null, key is null, and size is 2 adds third null key")
    public void TC03_put_third_null_key() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        map.put(null, "Value1");
        map.put(null, "Value2");
        Object key = null;
        Object value = "Value3";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(3, map.size());
        
        // Verify internal key3 and value3 via reflection
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object key3 = key3Field.get(map);
        assertNull(key3);
        
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object value3 = value3Field.get(map);
        assertEquals("Value3", value3);
    }

    @Test
    @DisplayName("put when delegateMap is null, key is null, and size is 3 triggers convertToMap")
    public void TC04_put_null_key_with_size_3_triggers_convertToMap() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        map.put(null, "Value1");
        map.put(null, "Value2");
        map.put(null, "Value3");
        Object key = null;
        Object value = "Value4";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(4, map.size());
        
        // Verify delegateMap via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        Object delegateMap = delegateMapField.get(map);
        assertNotNull(delegateMap);
        
        // Assuming delegateMap is a Map, verify it contains the new key
        @SuppressWarnings("unchecked")
        java.util.Map<Object, Object> delegate = (java.util.Map<Object, Object>) delegateMap;
        assertTrue(delegate.containsKey(null));
        assertEquals("Value4", delegate.get(null));
    }

    @Test
    @DisplayName("put when delegateMap is null, key is non-null, and size is 0 adds first non-null key")
    public void TC05_put_first_non_null_key() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Object key = "Key1";
        Object value = "Value1";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(1, map.size());
        
        // Verify internal key1 via reflection
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object key1 = key1Field.get(map);
        assertEquals("Key1", key1);
    }
}