package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.*;
import static com.fasterxml.jackson.core.JsonToken.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.BufferRecycler;
import com.fasterxml.jackson.core.util.JsonReadFeature;

public class UTF8StreamJsonParserTest {

    private UTF8StreamJsonParser createParser(String json, int features) throws IOException {
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.builder().build();
        IOContext ctxt = new IOContext(new BufferRecycler(), null, null, false);
        byte[] inputBytes = json.getBytes(StandardCharsets.UTF_8);
        return new UTF8StreamJsonParser(ctxt, features, new ByteArrayInputStream(inputBytes),
                null, sym, inputBytes, 0, inputBytes.length, 0, false);
    }

    @Test
    public void testNextTokenEmptyInput() throws IOException {
        UTF8StreamJsonParser parser = createParser("", 0);
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStartObjectEndObject() throws IOException {
        UTF8StreamJsonParser parser = createParser("{}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStartArrayEndArray() throws IOException {
        UTF8StreamJsonParser parser = createParser("[]", 0);
        assertEquals(START_ARRAY, parser.nextToken());
        assertEquals(END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenFieldNameSimple() throws IOException {
        UTF8StreamJsonParser parser = createParser("{\"a\":1}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenFieldNameWithEscape() throws IOException {
        UTF8StreamJsonParser parser = createParser("{\"a\\\"b\": \"c\\\\d\"}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(FIELD_NAME, parser.nextToken());
        assertEquals("a\"b", parser.currentName());
        assertEquals(VALUE_STRING, parser.nextToken());
        assertEquals("c\\d", parser.getText());
        assertEquals(END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenValueString() throws IOException {
        UTF8StreamJsonParser parser = createParser("\"hello\"", 0);
        assertEquals(VALUE_STRING, parser.nextToken());
        assertEquals("hello", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenValueNumberInt() throws IOException {
        UTF8StreamJsonParser parser = createParser("123", 0);
        assertEquals(VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());
        assertEquals(123L, parser.getLongValue());
        assertEquals("123", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenValueNumberFloat() throws IOException {
        UTF8StreamJsonParser parser = createParser("123.45", 0);
        assertEquals(VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(123.45, parser.getDoubleValue(), 0.0001);
        assertEquals("123.45", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenValueTrue() throws IOException {
        UTF8StreamJsonParser parser = createParser("true", 0);
        assertEquals(VALUE_TRUE, parser.nextToken());
        assertTrue(parser.getBooleanValue());
        assertEquals("true", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenValueFalse() throws IOException {
        UTF8StreamJsonParser parser = createParser("false", 0);
        assertEquals(VALUE_FALSE, parser.nextToken());
        assertFalse(parser.getBooleanValue());
        assertEquals("false", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenValueNull() throws IOException {
        UTF8StreamJsonParser parser = createParser("null", 0);
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertNull(parser.getValueAsString());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenUnexpectedChar() throws IOException {
        UTF8StreamJsonParser parser = createParser("{a:1}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        JsonParseException ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("was expecting double-quote to start field name"));
    }

    @Test
    public void testNextTokenInvalidNumber() throws IOException {
        UTF8StreamJsonParser parser = createParser("-01", 0);
        parser.nextToken();
        JsonParseException ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("Leading zeroes not allowed"));
    }

    @Test
    public void testNextTokenTrailingCommaAllowed() throws IOException {
        int features = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
        UTF8StreamJsonParser parser = createParser("{\"a\":1,}", features);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenTrailingCommaDisallowed() throws IOException {
        UTF8StreamJsonParser parser = createParser("{\"a\":1,}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        JsonParseException ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("was expecting comma to separate Object entries"));
    }

    @Test
    public void testNextTokenSingleQuotesAllowed() throws IOException {
        int features = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
        UTF8StreamJsonParser parser = createParser("{'a': 'b'}", features);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(VALUE_STRING, parser.nextToken());
        assertEquals("b", parser.getText());
        assertEquals(END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenSingleQuotesDisallowed() throws IOException {
        UTF8StreamJsonParser parser = createParser("{'a': 'b'}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        JsonParseException ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("was expecting double-quote to start field name"));
    }

    @Test
    public void testNextTokenSpecialNumbersAllowed() throws IOException {
        int features = JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS.mappedFeature().getMask();
        UTF8StreamJsonParser parser = createParser("NaN", features);
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertTrue(Double.isNaN(parser.getDoubleValue()));

        parser = createParser("Infinity", features);
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(Double.POSITIVE_INFINITY, parser.getDoubleValue());

        parser = createParser("-Infinity", features);
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(Double.NEGATIVE_INFINITY, parser.getDoubleValue());
    }

    @Test
    public void testNextTokenSpecialNumbersDisallowed() throws IOException {
        UTF8StreamJsonParser parser = createParser("NaN", 0);
        JsonParseException ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("Non-standard token 'NaN'"));

        parser = createParser("Infinity", 0);
        ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("Non-standard token 'Infinity'"));

        parser = createParser("-Infinity", 0);
        ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("Non-standard token '-Infinity'"));
    }

    @Test
    public void testNextTokenWithCommentsAllowed() throws IOException {
        int features = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_COMMENTS.getMask();
        UTF8StreamJsonParser parser = createParser("{/*comment*/\"a\":1}", features);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenWithCommentsDisallowed() throws IOException {
        UTF8StreamJsonParser parser = createParser("{/*comment*/\"a\":1}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        JsonParseException ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("was expecting comma to separate Object entries"));
    }

    @Test
    public void testNextTokenInvalidEscapedString() throws IOException {
        UTF8StreamJsonParser parser = createParser("\"abc\\x\"", 0);
        parser.nextToken();
        JsonParseException ex = assertThrows(JsonParseException.class, parser::getText);
        assertTrue(ex.getMessage().contains("Invalid UTF-8 middle byte"));
    }

    @Test
    public void testNextTokenIncompleteString() throws IOException {
        UTF8StreamJsonParser parser = createParser("\"abc", 0);
        parser.nextToken();
        JsonParseException ex = assertThrows(JsonParseException.class, parser::getText);
        assertTrue(ex.getMessage().contains("Invalid EOF within/between String value"));
    }

    @Test
    public void testNextTokenUnquotedFieldName() throws IOException {
        int features = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
        UTF8StreamJsonParser parser = createParser("{a:1}", features);
        assertEquals(START_OBJECT, parser.nextToken());
        assertEquals(FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenUnquotedFieldNameDisallowed() throws IOException {
        UTF8StreamJsonParser parser = createParser("{a:1}", 0);
        assertEquals(START_OBJECT, parser.nextToken());
        JsonParseException ex = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(ex.getMessage().contains("was expecting double-quote to start field name"));
    }
}