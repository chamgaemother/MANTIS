package org.jfree.data.general;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.data.Range;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import static org.mockito.Mockito.*;

public class DatasetUtils_iterateDomainBounds_0_2_Test {

    @Test
    @DisplayName("iterateDomainBounds with includeInterval=true and dataset not instance of IntervalXYDataset behaves as includeInterval=false")
    public void TC06() {
        // GIVEN
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);

        // THEN
        assertEquals(new Range(10.0, 10.0), result);
    }

    @Test
    @DisplayName("iterateDomainBounds with includeInterval=true and seriesCount=1 with all interval values not NaN returns correct Range")
    public void TC07() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(5.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(4.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(6.0);
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);

        // THEN
        assertEquals(new Range(4.0, 6.0), result);
    }

    @Test
    @DisplayName("iterateDomainBounds with includeInterval=true and some interval values as NaN are ignored")
    public void TC08() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getStartXValue(0, 0)).thenReturn(4.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(Double.NaN);
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);

        // THEN
        assertEquals(new Range(4.0, 4.0), result);
    }

    @Test
    @DisplayName("iterateDomainBounds with includeInterval=true and multiple series with multiple items returns correct Range")
    public void TC09() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(2);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getItemCount(1)).thenReturn(2);
        
        // Series 0
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
        when(dataset.getXValue(0, 1)).thenReturn(3.0);
        when(dataset.getStartXValue(0, 1)).thenReturn(2.5);
        when(dataset.getEndXValue(0, 1)).thenReturn(3.5);
        
        // Series 1
        when(dataset.getXValue(1, 0)).thenReturn(2.0);
        when(dataset.getStartXValue(1, 0)).thenReturn(1.5);
        when(dataset.getEndXValue(1, 0)).thenReturn(2.5);
        when(dataset.getXValue(1, 1)).thenReturn(4.0);
        when(dataset.getStartXValue(1, 1)).thenReturn(3.5);
        when(dataset.getEndXValue(1, 1)).thenReturn(4.5);
        
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);

        // THEN
        assertEquals(new Range(0.5, 4.5), result);
    }

    @Test
    @DisplayName("iterateDomainBounds with includeInterval=true and seriesCount=1 with all interval values as NaN returns null")
    public void TC10() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        when(dataset.getSeriesCount()).thenReturn(1);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getStartXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndXValue(0, 0)).thenReturn(Double.NaN);
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateDomainBounds(dataset, includeInterval);

        // THEN
        assertNull(result);
    }
}