package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class Base64Variant_decode_0_4_Test {

    @Test
    @DisplayName("decode encounters undefined character and throws IllegalArgumentException")
    public void TC16() throws Exception {
        // Given
        String str = "TWÂ";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // Instantiate Base64Variant using reflection
        Class<Base64Variant> clazz = Base64Variant.class;
        Constructor<Base64Variant> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance();

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            variant.decode(str, builder);
        });
    }

    @Test
    @DisplayName("decode with mixed valid and invalid base64 units throws IllegalArgumentException after processing valid units")
    public void TC17() throws Exception {
        // Given
        String str = "TWFu@@";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // Instantiate Base64Variant using reflection
        Class<Base64Variant> clazz = Base64Variant.class;
        Constructor<Base64Variant> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance();

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            variant.decode(str, builder);
        });
    }

    @Test
    @DisplayName("decode with excessive padding characters throws IllegalArgumentException")
    public void TC18() throws Exception {
        // Given
        String str = "TWFu====";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // Instantiate Base64Variant using reflection
        Class<Base64Variant> clazz = Base64Variant.class;
        Constructor<Base64Variant> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance();

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            variant.decode(str, builder);
        });
    }

    @Test
    @DisplayName("decode with undefined whitespace character throws IllegalArgumentException")
    public void TC19() throws Exception {
        // Given
        String str = "TW\u001fVu";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // Instantiate Base64Variant using reflection
        Class<Base64Variant> clazz = Base64Variant.class;
        Constructor<Base64Variant> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance();

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            variant.decode(str, builder);
        });
    }

    @Test
    @DisplayName("decode with padding required but missing in multi-iteration input throws IllegalArgumentException")
    public void TC20() throws Exception {
        // Given
        String str = "TWFuIGlzIGRpc3Rpbm";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // Instantiate Base64Variant using reflection
        Class<Base64Variant> clazz = Base64Variant.class;
        Constructor<Base64Variant> constructor = clazz.getDeclaredConstructor();
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance();

        // Set requiresPaddingOnRead to true using reflection
        var field = clazz.getDeclaredField("_paddingReadBehaviour");
        field.setAccessible(true);
        field.set(variant, Base64Variant.PaddingReadBehaviour.PADDING_REQUIRED);

        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            variant.decode(str, builder);
        });
    }
}