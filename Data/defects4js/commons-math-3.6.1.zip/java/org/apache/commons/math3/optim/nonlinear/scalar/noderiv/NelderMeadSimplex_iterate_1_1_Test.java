package org.apache.commons.math3.optim.nonlinear.scalar.noderiv;

import org.apache.commons.math3.optim.PointValuePair;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;

public class NelderMeadSimplex_iterate_1_1_Test {

    @Test
    @DisplayName("iterate with reflection point equal to best point, leading to contraction")
    void TC28_iterate_with_reflection_point_equal_to_best_leading_to_contraction() throws Exception {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {1.0, 1.0},
            {2.0, 2.0}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act
        simplex.iterate(function, comparator);

        // Assert
        // Using reflection to access the private getPoints method if necessary
        Method getPointsMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoints");
        getPointsMethod.setAccessible(true);
        PointValuePair[] points = (PointValuePair[]) getPointsMethod.invoke(simplex);

        // Verify that the worst point has been replaced
        // Assuming the worst point was {2.0, 2.0} and should have been contracted
        boolean contractionPerformed = false;
        for (PointValuePair pair : points) {
            if (pair.getValue() < 2.0) {
                contractionPerformed = true;
                break;
            }
        }
        assertTrue(contractionPerformed, "Contraction should have been performed and worst point replaced.");
    }

    @Test
    @DisplayName("iterate with gamma set to a negative value, causing invalid contraction and throwing IllegalArgumentException")
    void TC29_iterate_with_negative_gamma_throwing_exception() {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {2.0, 2.0},
            {3.0, 3.0}
        };
        // Using reflection to access the private constructor if necessary
        // Assuming there's a constructor that accepts gamma
        // Since constructors are public, we can use them directly
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints, 1.0, 2.0, -0.5, 0.5); // gamma=-0.5
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            simplex.iterate(function, comparator);
        }, "IllegalArgumentException should be thrown due to invalid contraction factor (gamma).");
    }

    @Test
    @DisplayName("iterate with evaluationFunction returning positive infinity, triggering exception handling")
    void TC30_iterate_with_evaluationFunction_infinite_value_throwing_exception() {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {2.0, 2.0},
            {3.0, 3.0}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);
        MultivariateFunction function = point -> Double.POSITIVE_INFINITY;
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            simplex.iterate(function, comparator);
        }, "IllegalArgumentException should be thrown due to invalid evaluation value (infinity).");
    }

    @Test
    @DisplayName("iterate with simplex dimension set to zero, ensuring method handles gracefully without changes")
    void TC31_iterate_with_zero_dimension_simplex_handles_gracefully() throws Exception {
        // Arrange
        double[][] initialPoints = {
            {}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);
        MultivariateFunction function = point -> 0.0;
        Comparator<PointValuePair> comparator = Comparator.comparingDouble(PointValuePair::getValue);

        // Act
        simplex.iterate(function, comparator);

        // Assert
        // Using reflection to access the private getPoints method if necessary
        Method getPointsMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoints");
        getPointsMethod.setAccessible(true);
        PointValuePair[] points = (PointValuePair[]) getPointsMethod.invoke(simplex);

        assertEquals(1, points.length, "Simplex should have exactly one point when dimension is zero.");
        assertArrayEquals(new double[]{}, points[0].getPoint(), "The single point should remain unchanged.");
    }

    @Test
    @DisplayName("iterate with Comparator comparing based on custom criteria leading to shrink")
    void TC32_iterate_with_custom_comparator_leading_to_shrink() throws Exception {
        // Arrange
        double[][] initialPoints = {
            {1.0, 1.0},
            {2.0, 2.0},
            {3.0, 3.0}
        };
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoints);
        MultivariateFunction function = point -> point[0] + point[1];
        Comparator<PointValuePair> comparator = (p1, p2) -> Double.compare(p2.getValue(), p1.getValue()); // Reverse order

        // Act
        simplex.iterate(function, comparator);

        // Assert
        // Using reflection to access the private getPoints method if necessary
        Method getPointsMethod = NelderMeadSimplex.class.getDeclaredMethod("getPoints");
        getPointsMethod.setAccessible(true);
        PointValuePair[] points = (PointValuePair[]) getPointsMethod.invoke(simplex);

        // Verify that shrink operation is triggered based on reverse ordering
        // This might mean that points have been moved closer to the best point
        // For simplicity, check that points are closer to the first point
        double[] bestPoint = points[0].getPoint();
        boolean shrinkPerformed = true;
        for (int i = 1; i < points.length; i++) {
            double[] currentPoint = points[i].getPoint();
            for (int j = 0; j < bestPoint.length; j++) {
                if (Math.abs(currentPoint[j] - bestPoint[j]) > 1.0) { // Assuming shrinkage factor
                    shrinkPerformed = false;
                    break;
                }
            }
            if (!shrinkPerformed) {
                break;
            }
        }
        assertTrue(shrinkPerformed, "Shrink operation should have been triggered based on custom Comparator logic.");
    }
}