import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonStreamContext;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
import com.fasterxml.jackson.core.filter.TokenFilter;
import com.fasterxml.jackson.core.filter.TokenFilterContext;
import com.fasterxml.jackson.core.filter.TokenFilter.Inclusion;

class FilteringParserDelegateTest {

    private JsonParser mockParser;
    private TokenFilter mockFilter;
    private FilteringParserDelegate filteringParser;

    @BeforeEach
    void setUp() {
        mockParser = mock(JsonParser.class);
        mockFilter = mock(TokenFilter.class);
        filteringParser = new FilteringParserDelegate(mockParser, mockFilter, Inclusion.ONLY_INCLUDE_ALL, false);
    }

    @Test
    void testNextToken_NullInitialToken() throws IOException {
        when(mockParser.nextToken()).thenReturn(null);
        JsonToken token = filteringParser.nextToken();
        assertNull(token);
        verify(mockParser).nextToken();
    }

    @Test
    void testNextToken_NotAllowMultipleMatches_ScalarHandled() throws IOException {
        JsonToken scalarToken = JsonToken.VALUE_STRING;
        filteringParser._currToken = scalarToken;
        filteringParser._exposedContext = null;
        filteringParser._headContext = TokenFilterContext.createRootContext(TokenFilter.INCLUDE_ALL);
        filteringParser._inclusion = Inclusion.ONLY_INCLUDE_ALL;
        filteringParser._itemFilter = TokenFilter.INCLUDE_ALL;

        JsonToken result = filteringParser.nextToken();
        assertNull(result);
        assertNull(filteringParser.currentToken());
    }

    @Test
    void testNextToken_BufferedContextReturnsToken() throws IOException {
        TokenFilterContext exposedContext = mock(TokenFilterContext.class);
        when(exposedContext.nextTokenToRead()).thenReturn(JsonToken.START_OBJECT, null);
        filteringParser._exposedContext = exposedContext;

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.START_OBJECT, token);
        verify(exposedContext).nextTokenToRead();
    }

    @Test
    void testNextToken_DelegateReturnsStartArray_IncludeAll() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.START_ARRAY);
        when(mockFilter.filterStartArray()).thenReturn(TokenFilter.INCLUDE_ALL);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.START_ARRAY, token);
        verify(mockParser).nextToken();
        verify(mockFilter).filterStartArray();
    }

    @Test
    void testNextToken_DelegateReturnsStartObject_IncludeAll() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.START_OBJECT);
        when(mockFilter.filterStartObject()).thenReturn(TokenFilter.INCLUDE_ALL);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.START_OBJECT, token);
        verify(mockParser).nextToken();
        verify(mockFilter).filterStartObject();
    }

    @Test
    void testNextToken_DelegateReturnsFieldName_IncludeProperty() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.FIELD_NAME, JsonToken.VALUE_STRING);
        when(mockParser.currentName()).thenReturn("field");
        when(mockFilter.setFieldName("field")).thenReturn(mockFilter);
        when(mockFilter.includeProperty("field")).thenReturn(TokenFilter.INCLUDE_ALL);
        when(mockFilter.filterStartObject()).thenReturn(TokenFilter.INCLUDE_ALL);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.FIELD_NAME, token);
        verify(mockParser, times(1)).nextToken();
        verify(mockFilter).setFieldName("field");
        verify(mockFilter).includeProperty("field");
    }

    @Test
    void testNextToken_DelegateReturnsEndArray_HandleFilter() throws IOException {
        TokenFilterContext context = TokenFilterContext.createRootContext(mockFilter);
        when(mockFilter.getFilter()).thenReturn(mockFilter);
        when(mockParser.nextToken()).thenReturn(JsonToken.END_ARRAY);
        filteringParser._headContext = context;

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.END_ARRAY, token);
        verify(mockFilter).filterFinishArray();
    }

    @Test
    void testNextToken_DelegateReturnsEndObject_HandleFilter() throws IOException {
        TokenFilterContext context = TokenFilterContext.createRootContext(mockFilter);
        when(mockFilter.getFilter()).thenReturn(mockFilter);
        when(mockParser.nextToken()).thenReturn(JsonToken.END_OBJECT);
        filteringParser._headContext = context;

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.END_OBJECT, token);
        verify(mockFilter).filterFinishObject();
    }

    @Test
    void testNextToken_IncludeValue_MatchAllowed() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockFilter.includeValue(mockParser)).thenReturn(true);
        filteringParser._allowMultipleMatches = true;

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, token);
        verify(mockFilter).includeValue(mockParser);
    }

    @Test
    void testNextToken_IncludeValue_MatchNotAllowed() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockFilter.includeValue(mockParser)).thenReturn(true);
        filteringParser._allowMultipleMatches = false;
        filteringParser._matchCount = 1;

        JsonToken token = filteringParser.nextToken();
        assertNull(token);
        verify(mockFilter).includeValue(mockParser);
    }

    @Test
    void testNextToken_NotAvailableToken_ThrowsException() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.NOT_AVAILABLE);

        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            filteringParser.nextToken();
        });
        assertTrue(ex.getMessage().contains("JsonToken.NOT_AVAILABLE"));
    }

    @Test
    void testNextToken_SkipChildrenWhenFilterNull() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.START_OBJECT);
        when(mockFilter.filterStartObject()).thenReturn(null);

        JsonToken token = filteringParser.nextToken();
        assertNull(token);
        verify(mockParser).skipChildren();
    }

    @Test
    void testNextToken_ScalarValue_NotIncluded() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockFilter.includeValue(mockParser)).thenReturn(false);

        JsonToken token = filteringParser.nextToken();
        assertNull(token);
        verify(mockFilter).includeValue(mockParser);
    }

    @Test
    void testNextToken_MultipleTokenTypes() throws IOException {
        InOrder inOrder = inOrder(mockParser, mockFilter);
        when(mockParser.nextToken()).thenReturn(
                JsonToken.START_OBJECT,
                JsonToken.FIELD_NAME,
                JsonToken.VALUE_STRING,
                JsonToken.END_OBJECT
        );
        when(mockFilter.filterStartObject()).thenReturn(TokenFilter.INCLUDE_ALL);
        when(mockFilter.setFieldName("name")).thenReturn(mockFilter);
        when(mockFilter.includeProperty("name")).thenReturn(TokenFilter.INCLUDE_ALL);

        JsonToken token1 = filteringParser.nextToken();
        JsonToken token2 = filteringParser.nextToken();
        JsonToken token3 = filteringParser.nextToken();
        JsonToken token4 = filteringParser.nextToken();

        assertEquals(JsonToken.START_OBJECT, token1);
        assertEquals(JsonToken.FIELD_NAME, token2);
        assertEquals(JsonToken.VALUE_STRING, token3);
        assertEquals(JsonToken.END_OBJECT, token4);

        inOrder.verify(mockParser).nextToken();
        inOrder.verify(mockFilter).filterStartObject();
        inOrder.verify(mockParser).nextToken();
        inOrder.verify(mockFilter).setFieldName("name");
        inOrder.verify(mockFilter).includeProperty("name");
    }

    @Test
    void testNextToken_ExposedContextReturnsMultipleTokens() throws IOException {
        TokenFilterContext exposedContext = mock(TokenFilterContext.class);
        when(exposedContext.nextTokenToRead()).thenReturn(JsonToken.START_ARRAY, JsonToken.VALUE_NUMBER_INT, null);
        filteringParser._exposedContext = exposedContext;

        JsonToken token1 = filteringParser.nextToken();
        JsonToken token2 = filteringParser.nextToken();
        JsonToken token3 = filteringParser.nextToken();

        assertEquals(JsonToken.START_ARRAY, token1);
        assertEquals(JsonToken.VALUE_NUMBER_INT, token2);
        assertNull(token3);
        verify(exposedContext, times(3)).nextTokenToRead();
    }

    @Test
    void testNextToken_IncludeNonNull_InclusionPath() throws IOException {
        filteringParser = new FilteringParserDelegate(mockParser, mockFilter, Inclusion.INCLUDE_NON_NULL, true);
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockFilter.includeValue(mockParser)).thenReturn(true);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, token);
        verify(mockFilter).includeValue(mockParser);
    }

    @Test
    void testNextToken_IncludeAllAndPath_Buffering() throws IOException {
        filteringParser = new FilteringParserDelegate(mockParser, mockFilter, Inclusion.INCLUDE_ALL_AND_PATH, true);
        TokenFilterContext buffRoot = mock(TokenFilterContext.class);
        filteringParser._headContext = buffRoot;
        when(mockParser.nextToken()).thenReturn(JsonToken.START_OBJECT, JsonToken.FIELD_NAME, JsonToken.VALUE_STRING);
        when(mockFilter.filterStartObject()).thenReturn(TokenFilter.INCLUDE_ALL);
        when(buffRoot.createChildObjectContext(TokenFilter.INCLUDE_ALL, true)).thenReturn(buffRoot);
        when(buffRoot.nextTokenToRead()).thenReturn(JsonToken.START_OBJECT, JsonToken.FIELD_NAME, JsonToken.VALUE_STRING, null);

        JsonToken token1 = filteringParser.nextToken();
        JsonToken token2 = filteringParser.nextToken();
        JsonToken token3 = filteringParser.nextToken();
        JsonToken token4 = filteringParser.nextToken();

        assertEquals(JsonToken.START_OBJECT, token1);
        assertEquals(JsonToken.FIELD_NAME, token2);
        assertEquals(JsonToken.VALUE_STRING, token3);
        assertNull(token4);
    }

    @Test
    void testNextToken_OverrideCurrentName_ThrowsException() {
        assertThrows(UnsupportedOperationException.class, () -> {
            filteringParser.overrideCurrentName("newName");
        });
    }

    @Test
    void testNextToken_SkipChildrenOnScalar() throws IOException {
        when(mockParser.currentToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockFilter.includeValue(mockParser)).thenReturn(false);

        JsonToken token = filteringParser.nextToken();
        assertNull(token);
        verify(mockParser).skipChildren();
    }

    @Test
    void testNextToken_GetTextForFieldName() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.FIELD_NAME);
        when(mockParser.currentName()).thenReturn("fieldName");

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.FIELD_NAME, token);
        assertEquals("fieldName", filteringParser.getText());
    }

    @Test
    void testNextToken_GetTextForValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.getText()).thenReturn("value");

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals("value", filteringParser.getText());
    }

    @Test
    void testNextToken_GetValueAsInt() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getIntValue()).thenReturn(123);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token);
        assertEquals(123, filteringParser.getValueAsInt());
    }

    @Test
    void testNextToken_GetNumberType() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getNumberType()).thenReturn(JsonParser.NumberType.INT);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token);
        assertEquals(JsonParser.NumberType.INT, filteringParser.getNumberType());
    }

    @Test
    void testNextToken_GetCurrentLocation() throws IOException {
        JsonLocation location = mock(JsonLocation.class);
        when(mockParser.currentTokenLocation()).thenReturn(location);
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals(location, filteringParser.currentTokenLocation());
    }

    @Test
    void testNextToken_SkipChildrenWhenNotStart() throws IOException {
        when(filteringParser.currentToken()).thenReturn(JsonToken.VALUE_STRING);
        JsonParser parserSpy = spy(mockParser);
        filteringParser = new FilteringParserDelegate(parserSpy, mockFilter, Inclusion.ONLY_INCLUDE_ALL, false);

        filteringParser.skipChildren();
        verify(parserSpy, never()).skipChildren();
    }

    @Test
    void testNextToken_SkipChildrenWhenStart() throws IOException {
        when(filteringParser.currentToken()).thenReturn(JsonToken.START_ARRAY);
        when(mockParser.nextToken()).thenReturn(JsonToken.START_ARRAY, JsonToken.VALUE_NUMBER_INT, JsonToken.END_ARRAY);
        JsonParser parserSpy = spy(mockParser);
        filteringParser = new FilteringParserDelegate(parserSpy, mockFilter, Inclusion.ONLY_INCLUDE_ALL, false);

        filteringParser.nextToken();
        filteringParser.skipChildren();
        verify(parserSpy).skipChildren();
    }

    @Test
    void testNextToken_GetBinaryValue() throws IOException {
        byte[] data = {1, 2, 3};
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_EMBEDDED_OBJECT);
        when(mockParser.getBinaryValue(any())).thenReturn(data);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_EMBEDDED_OBJECT, token);
        assertArrayEquals(data, filteringParser.getBinaryValue(null));
    }

    @Test
    void testNextToken_GetEmbeddedObject() throws IOException {
        Object obj = new Object();
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_EMBEDDED_OBJECT);
        when(mockParser.getEmbeddedObject()).thenReturn(obj);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_EMBEDDED_OBJECT, token);
        assertEquals(obj, filteringParser.getEmbeddedObject());
    }

    @Test
    void testNextToken_GetValueAsStringForFieldName() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.FIELD_NAME);
        when(mockParser.currentName()).thenReturn("fieldName");

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.FIELD_NAME, token);
        assertEquals("fieldName", filteringParser.getValueAsString());
    }

    @Test
    void testNextToken_GetValueAsStringForValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.getValueAsString()).thenReturn("value");

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals("value", filteringParser.getValueAsString());
    }

    @Test
    void testNextToken_GetValueAsBoolean() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_TRUE);
        when(mockParser.getBooleanValue()).thenReturn(true);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_TRUE, token);
        assertTrue(filteringParser.getBooleanValue());
    }

    @Test
    void testNextToken_GetFloatValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_FLOAT);
        when(mockParser.getFloatValue()).thenReturn(1.23f);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token);
        assertEquals(1.23f, filteringParser.getFloatValue());
    }

    @Test
    void testNextToken_GetDoubleValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_FLOAT);
        when(mockParser.getDoubleValue()).thenReturn(1.23);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token);
        assertEquals(1.23, filteringParser.getDoubleValue());
    }

    @Test
    void testNextToken_GetLongValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getLongValue()).thenReturn(123L);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token);
        assertEquals(123L, filteringParser.getLongValue());
    }

    @Test
    void testNextToken_GetBigIntegerValue() throws IOException {
        java.math.BigInteger bigInt = new java.math.BigInteger("123456789");
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getBigIntegerValue()).thenReturn(bigInt);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token);
        assertEquals(bigInt, filteringParser.getBigIntegerValue());
    }

    @Test
    void testNextToken_GetBigDecimalValue() throws IOException {
        java.math.BigDecimal bigDec = new java.math.BigDecimal("123.45");
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_FLOAT);
        when(mockParser.getDecimalValue()).thenReturn(bigDec);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, token);
        assertEquals(bigDec, filteringParser.getDecimalValue());
    }

    @Test
    void testNextToken_GetByteValue() throws IOException {
        byte byteVal = 10;
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getByteValue()).thenReturn(byteVal);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token);
        assertEquals(byteVal, filteringParser.getByteValue());
    }

    @Test
    void testNextToken_GetShortValue() throws IOException {
        short shortVal = 20;
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getShortValue()).thenReturn(shortVal);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token);
        assertEquals(shortVal, filteringParser.getShortValue());
    }

    @Test
    void testNextToken_GetNumberValue() throws IOException {
        Number number = 123;
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getNumberValue()).thenReturn(number);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NUMBER_INT, token);
        assertEquals(number, filteringParser.getNumberValue());
    }

    @Test
    void testNextToken_GetValueAsBooleanWithDefault() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NULL);
        when(mockParser.getValueAsBoolean(false)).thenReturn(false);

        boolean value = filteringParser.getValueAsBoolean(false);
        assertFalse(value);
        verify(mockParser).getValueAsBoolean(false);
    }

    @Test
    void testNextToken_GetValueAsIntWithDefault() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NULL);
        when(mockParser.getValueAsInt(100)).thenReturn(100);

        int value = filteringParser.getValueAsInt(100);
        assertEquals(100, value);
        verify(mockParser).getValueAsInt(100);
    }

    @Test
    void testNextToken_GetValueAsDoubleWithDefault() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NULL);
        when(mockParser.getValueAsDouble(1.23)).thenReturn(1.23);

        double value = filteringParser.getValueAsDouble(1.23);
        assertEquals(1.23, value);
        verify(mockParser).getValueAsDouble(1.23);
    }

    @Test
    void testNextToken_GetValueAsStringWithDefault() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NULL);
        when(mockParser.getValueAsString("default")).thenReturn("default");

        String value = filteringParser.getValueAsString("default");
        assertEquals("default", value);
        verify(mockParser).getValueAsString("default");
    }

    @Test
    void testNextToken_GetCurrentNameWhenNoContext() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(filteringParser.getParsingContext()).thenReturn(null);

        String name = filteringParser.getCurrentName();
        assertNull(name);
    }

    @Test
    void testNextToken_HasCurrentToken() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        JsonToken token = filteringParser.nextToken();
        assertTrue(filteringParser.hasCurrentToken());
        assertEquals(JsonToken.VALUE_STRING, token);
    }

    @Test
    void testNextToken_HasTokenId() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        JsonToken token = filteringParser.nextToken();
        assertTrue(filteringParser.hasTokenId(JsonTokenId.ID_STRING));
        assertFalse(filteringParser.hasTokenId(JsonTokenId.ID_START_OBJECT));
    }

    @Test
    void testNextToken_HasToken() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        JsonToken token = filteringParser.nextToken();
        assertTrue(filteringParser.hasToken(JsonToken.VALUE_STRING));
        assertFalse(filteringParser.hasToken(JsonToken.START_ARRAY));
    }

    @Test
    void testNextToken_CurrentTokenLocation() throws IOException {
        JsonLocation location = mock(JsonLocation.class);
        when(mockParser.currentTokenLocation()).thenReturn(location);
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals(location, filteringParser.currentTokenLocation());
    }

    @Test
    void testNextToken_CurrentLocation() throws IOException {
        JsonLocation location = mock(JsonLocation.class);
        when(mockParser.currentLocation()).thenReturn(location);
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);

        JsonLocation loc = filteringParser.currentLocation();
        assertEquals(location, loc);
    }

    @Test
    void testNextToken_HasTextCharacters() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.hasTextCharacters()).thenReturn(true);

        boolean hasChars = filteringParser.hasTextCharacters();
        assertTrue(hasChars);
        verify(mockParser).hasTextCharacters();
    }

    @Test
    void testNextToken_GetTextCharactersForFieldName() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.FIELD_NAME);
        when(mockParser.currentName()).thenReturn("fieldName");

        char[] chars = filteringParser.getTextCharacters();
        assertArrayEquals("fieldName".toCharArray(), chars);
    }

    @Test
    void testNextToken_GetTextCharactersForValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.getTextCharacters()).thenReturn(new char[] {'v', 'a', 'l', 'u', 'e'});

        char[] chars = filteringParser.getTextCharacters();
        assertArrayEquals(new char[] {'v', 'a', 'l', 'u', 'e'}, chars);
    }

    @Test
    void testNextToken_GetTextLengthForFieldName() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.FIELD_NAME);
        when(mockParser.currentName()).thenReturn("fieldName");

        int length = filteringParser.getTextLength();
        assertEquals("fieldName".length(), length);
    }

    @Test
    void testNextToken_GetTextLengthForValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.getTextLength()).thenReturn(5);

        int length = filteringParser.getTextLength();
        assertEquals(5, length);
    }

    @Test
    void testNextToken_GetTextOffsetForFieldName() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.FIELD_NAME);
        when(mockParser.currentName()).thenReturn("fieldName");

        int offset = filteringParser.getTextOffset();
        assertEquals(0, offset);
    }

    @Test
    void testNextToken_GetTextOffsetForValue() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        when(mockParser.getTextOffset()).thenReturn(2);

        int offset = filteringParser.getTextOffset();
        assertEquals(2, offset);
    }

    @Test
    void testNextToken_ClearCurrentToken() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        filteringParser.nextToken();
        filteringParser.clearCurrentToken();
        assertNull(filteringParser.getCurrentToken());
        assertEquals(JsonToken.VALUE_STRING, filteringParser.getLastClearedToken());
    }

    @Test
    void testNextToken_GetLastClearedToken() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_STRING);
        filteringParser.nextToken();
        filteringParser.clearCurrentToken();
        JsonToken clearedToken = filteringParser.getLastClearedToken();
        assertEquals(JsonToken.VALUE_STRING, clearedToken);
    }

    @Test
    void testNextToken_GetNumberType() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NUMBER_INT);
        when(mockParser.getNumberType()).thenReturn(JsonParser.NumberType.INT);

        JsonParser.NumberType numberType = filteringParser.getNumberType();
        assertEquals(JsonParser.NumberType.INT, numberType);
    }

    @Test
    void testNextToken_GetEmbeddedObject_Null() throws IOException {
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_NULL);
        when(mockParser.getEmbeddedObject()).thenReturn(null);

        JsonToken token = filteringParser.nextToken();
        assertEquals(JsonToken.VALUE_NULL, token);
        assertNull(filteringParser.getEmbeddedObject());
    }

    @Test
    void testNextToken_ReadBinaryValue() throws IOException {
        OutputStream out = mock(OutputStream.class);
        when(mockParser.nextToken()).thenReturn(JsonToken.VALUE_EMBEDDED_OBJECT);
        when(mockParser.readBinaryValue(any(), eq(out))).thenReturn(3);

        int bytesRead = filteringParser.readBinaryValue(null, out);
        assertEquals(3, bytesRead);
        verify(mockParser).readBinaryValue(null, out);
    }
}