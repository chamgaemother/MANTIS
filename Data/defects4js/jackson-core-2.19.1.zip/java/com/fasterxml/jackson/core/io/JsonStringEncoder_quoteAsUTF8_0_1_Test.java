package com.fasterxml.jackson.core.io;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.charset.StandardCharsets;
import com.fasterxml.jackson.core.io.JsonStringEncoder;

public class JsonStringEncoder_quoteAsUTF8_0_1_Test {

    @Test
    @DisplayName("quoteAsUTF8 with an empty string returns an empty byte array")
    public void TC01_emptyString_returnsEmptyByteArray() {
        // GIVEN
        String text = "";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        assertEquals(0, result.length, "Expected empty byte array");
    }

    @Test
    @DisplayName("quoteAsUTF8 with ASCII string without escapable characters")
    public void TC02_asciiNoEscapes() {
        // GIVEN
        String text = "HelloWorld";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        byte[] expected = "HelloWorld".getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result, "Byte array does not match expected ASCII bytes");
    }

    @Test
    @DisplayName("quoteAsUTF8 with ASCII string containing escapable characters")
    public void TC03_asciiWithEscapes() {
        // GIVEN
        String text = "Hello\nWorld";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        byte[] expected = "Hello\nWorld".getBytes(StandardCharsets.UTF_8);
        assertArrayEquals(expected, result, "Byte array does not properly contain escaped characters");
    }

    @Test
    @DisplayName("quoteAsUTF8 with non-ASCII characters requiring 2-byte UTF-8 encoding")
    public void TC04_nonASCII_2ByteUTF8() {
        // GIVEN
        String text = "CafÃ©";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        byte[] expected = {67, 97, 102, (byte)0xC3, (byte)0xA9};
        assertArrayEquals(expected, result, "Byte array does not correctly encode 2-byte UTF-8 characters");
    }

    @Test
    @DisplayName("quoteAsUTF8 with non-ASCII characters requiring 3-byte UTF-8 encoding")
    public void TC05_nonASCII_3ByteUTF8() {
        // GIVEN
        String text = "æ±å­";

        // WHEN
        byte[] result = JsonStringEncoder.getInstance().quoteAsUTF8(text);

        // THEN
        byte[] expected = {(byte)0xE6, (byte)0xBC, (byte)0xA2, (byte)0xE5, (byte)0xAD, (byte)0x97};
        assertArrayEquals(expected, result, "Byte array does not correctly encode 3-byte UTF-8 characters");
    }
}