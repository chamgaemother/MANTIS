// package org.apache.commons.jxpath.ri.parser;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// import java.lang.reflect.Field;
// 
// public class XPathParser_AxisName_2_6_Test {
// 
//     @Test
//     @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_DESCENDANT_OR_SELF but token.kind=AXIS_PRECEDING")
//     void TC42() throws Exception {
//         // Initialize XPathParser with empty input
//         XPathParser parser = new XPathParser(new java.io.StringReader("")); 
// 
//         // Use reflection to set jj_nt.kind = AXIS_DESCENDANT_OR_SELF
//         Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
//         jj_ntField.setAccessible(true);
//         Token jj_nt = new Token();
//         jj_nt.kind = Compiler.AXIS_DESCENDANT_OR_SELF;
//         jj_ntField.set(parser, jj_nt);
// 
//         // Use reflection to set token.kind = AXIS_PRECEDING
//         Field tokenField = XPathParser.class.getDeclaredField("token");
//         tokenField.setAccessible(true);
//         Token token = new Token();
//         token.kind = Compiler.AXIS_PRECEDING;
//         tokenField.set(parser, token);
// 
//         // Expect AxisName() to throw ParseException
//         assertThrows(ParseException.class, () -> parser.AxisName());
//     }
// }