// JUnit 5 Test Class for Flat3Map.put method
package org.apache.commons.collections4.map;

import org.apache.commons.collections4.map.Flat3Map;
import org.apache.commons.collections4.map.AbstractHashedMap;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_put_0_3_Test {
    
    @Test
    @DisplayName("put when delegateMap is null, key is non-null, size is 3, and key does not match triggers convertToMap")
    void TC11() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        map.put("Key1", "Value1");
        map.put("Key2", "Value2");
        map.put("Key3", "Value3");
        Object key = "Key4";
        Object value = "Value4";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(4, map.size());
        
        // Using reflection to access delegateMap
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        AbstractHashedMap delegateMap = (AbstractHashedMap) delegateMapField.get(map);
        assertNotNull(delegateMap);
        assertTrue(delegateMap.containsKey("Key4"));
    }

    @Test
    @DisplayName("put when delegateMap is not null delegates to delegateMap.put")
    void TC12() throws Exception {
        // GIVEN
        AbstractHashedMap delegate = new AbstractHashedMap();
        Flat3Map map = new Flat3Map(delegate);
        Object key = "Key1";
        Object value = "Value1";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        Object delegateResult = delegate.put(key, value);
        assertEquals(delegateResult, result);

        // Using reflection to access delegateMap to verify size
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        AbstractHashedMap mapDelegate = (AbstractHashedMap) delegateMapField.get(map);
        assertEquals(mapDelegate.size(), map.size());
    }

    @Test
    @DisplayName("put with key having same hashCode as key1 but different equals does not update key1")
    void TC13() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        map.put("Key1", "Value1");
        String key = "KeyCollision"; // Assume same hashCode as "Key1"
        Object value = "ValueCollision";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(2, map.size());

        // Using reflection to access key2
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object key2 = key2Field.get(map);
        assertEquals(key, key2);
    }

    @Test
    @DisplayName("put with key having same hashCode and equals to key1 updates value1")
    void TC14() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        map.put("Key1", "Value1");
        Object key = new String("Key1");
        Object value = "Value1Updated";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertEquals("Value1", result);
        assertEquals(1, map.size());

        // Using reflection to access value1
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = value1Field.get(map);
        assertEquals("Value1Updated", value1);
    }

    @Test
    @DisplayName("put with key having different hashCode from all existing keys adds new key")
    void TC15() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        map.put("Key1", "Value1");
        map.put("Key2", "Value2");
        Object key = "KeyUnique"; // Different hashCode
        Object value = "ValueUnique";
        
        // WHEN
        Object result = map.put(key, value);
        
        // THEN
        assertNull(result);
        assertEquals(3, map.size());

        // Using reflection to access key3
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object key3 = key3Field.get(map);
        assertEquals(key, key3);
    }
}