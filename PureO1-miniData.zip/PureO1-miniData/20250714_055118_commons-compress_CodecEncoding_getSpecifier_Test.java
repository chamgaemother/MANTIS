package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.function.Executable;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;

public class CodecEncodingTest {

    @Test
    @DisplayName("Test getSpecifier with codec in canonicalCodecsToSpecifiers")
    public void testGetSpecifier_CanonicalCodec() {
        Codec mockCodec = CodecEncoding.getCanonicalCodec(1);
        Codec defaultCodec = null; // Irrelevant for canonical codec
        int[] specifier = CodecEncoding.getSpecifier(mockCodec, defaultCodec);
        assertArrayEquals(new int[] {1}, specifier);
    }

    @Test
    @DisplayName("Test getSpecifier with BHSDCodec not in canonicalCodecsToSpecifiers")
    public void testGetSpecifier_BHSDCodec() {
        BHSDCodec bhsdCodec = new BHSDCodec(1, 256, 1, 1);
        Codec defaultCodec = null;
        int[] specifier = CodecEncoding.getSpecifier(bhsdCodec, defaultCodec);
        assertArrayEquals(new int[] {116, 5, 256}, specifier);
    }

    @Test
    @DisplayName("Test getSpecifier with RunCodec not in canonicalCodecsToSpecifiers with k <= 256 and aCodec default")
    public void testGetSpecifier_RunCodec_kLessThan256_aDefault() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        Mockito.when(defaultCodec.equals(Mockito.any())).thenReturn(true);

        RunCodec runCodec = new RunCodec(100, defaultCodec, Mockito.mock(Codec.class));
        int[] specifier = CodecEncoding.getSpecifier(runCodec, defaultCodec);
        assertNotNull(specifier);
        assertTrue(specifier.length >= 1);
        assertEquals(117, specifier[0]);
    }

    @Test
    @DisplayName("Test getSpecifier with RunCodec not in canonicalCodecsToSpecifiers with k > 256 and bCodec default")
    public void testGetSpecifier_RunCodec_kGreaterThan256_bDefault() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        Mockito.when(defaultCodec.equals(Mockito.any())).thenReturn(true);

        RunCodec runCodec = new RunCodec(3000, Mockito.mock(Codec.class), defaultCodec);
        int[] specifier = CodecEncoding.getSpecifier(runCodec, defaultCodec);
        assertNotNull(specifier);
        assertTrue(specifier.length >= 1);
        assertEquals(117 + 1 + 8 * 1, specifier[0]);
    }

    @Test
    @DisplayName("Test getSpecifier with PopulationCodec not in canonicalCodecsToSpecifiers with all codecs default")
    public void testGetSpecifier_PopulationCodec_AllDefault() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        Mockito.when(defaultCodec.equals(Mockito.any())).thenReturn(true);

        PopulationCodec populationCodec = new PopulationCodec(defaultCodec, null, defaultCodec);
        int[] specifier = CodecEncoding.getSpecifier(populationCodec, defaultCodec);
        assertNotNull(specifier);
        assertTrue(specifier.length >= 1);
        assertEquals(141, specifier[0]);
    }

    @Test
    @DisplayName("Test getSpecifier with PopulationCodec not in canonicalCodecsToSpecifiers with non-default favoured and unfavoured codecs")
    public void testGetSpecifier_PopulationCodec_NonDefault() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        Codec favouredCodec = Mockito.mock(Codec.class);
        Codec tokenCodec = Mockito.mock(Codec.class);
        Codec unfavouredCodec = Mockito.mock(Codec.class);

        Mockito.when(defaultCodec.equals(favouredCodec)).thenReturn(false);
        Mockito.when(defaultCodec.equals(unfavouredCodec)).thenReturn(false);

        PopulationCodec populationCodec = new PopulationCodec(tokenCodec, favouredCodec, unfavouredCodec);
        int[] specifier = CodecEncoding.getSpecifier(populationCodec, defaultCodec);
        assertNotNull(specifier);
        assertTrue(specifier.length >= 4);
        assertEquals(141, specifier[0]);
    }

    @Test
    @DisplayName("Test getSpecifier with codec not in map and not instance of known codecs")
    public void testGetSpecifier_UnknownCodec() {
        Codec unknownCodec = Mockito.mock(Codec.class);
        Codec defaultCodec = Mockito.mock(Codec.class);
        int[] specifier = CodecEncoding.getSpecifier(unknownCodec, defaultCodec);
        assertNull(specifier);
    }

    @Test
    @DisplayName("Test getSpecifier with null codec")
    public void testGetSpecifier_NullCodec() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        int[] specifier = CodecEncoding.getSpecifier(null, defaultCodec);
        assertNull(specifier);
    }

    @Test
    @DisplayName("Test getSpecifier with BHSDCodec in canonicalCodecsToSpecifiers")
    public void testGetSpecifier_BHSDCodec_Canonical() {
        BHSDCodec bhsdCodec = CodecEncoding.getCanonicalCodec(2);
        Codec defaultCodec = null;
        int[] specifier = CodecEncoding.getSpecifier(bhsdCodec, defaultCodec);
        assertArrayEquals(new int[] {2}, specifier);
    }

    @Test
    @DisplayName("Test getSpecifier with RunCodec k at boundary 256")
    public void testGetSpecifier_RunCodec_kAt256() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        RunCodec runCodec = new RunCodec(256, defaultCodec, Mockito.mock(Codec.class));
        int[] specifier = CodecEncoding.getSpecifier(runCodec, defaultCodec);
        assertNotNull(specifier);
        assertEquals(117, specifier[0]);
    }

    @Test
    @DisplayName("Test getSpecifier with RunCodec k at boundary 257")
    public void testGetSpecifier_RunCodec_kAt257() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        RunCodec runCodec = new RunCodec(257, Mockito.mock(Codec.class), defaultCodec);
        int[] specifier = CodecEncoding.getSpecifier(runCodec, defaultCodec);
        assertNotNull(specifier);
        assertTrue(specifier[0] > 117);
    }

    @Test
    @DisplayName("Test getSpecifier with PopulationCodec and tokenCodec default")
    public void testGetSpecifier_PopulationCodec_TokenDefault() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        Codec favouredCodec = Mockito.mock(Codec.class);
        Codec unfavouredCodec = Mockito.mock(Codec.class);

        Mockito.when(defaultCodec.equals(favouredCodec)).thenReturn(false);
        Mockito.when(defaultCodec.equals(unfavouredCodec)).thenReturn(false);

        PopulationCodec populationCodec = new PopulationCodec(defaultCodec, favouredCodec, unfavouredCodec);
        int[] specifier = CodecEncoding.getSpecifier(populationCodec, defaultCodec);
        // Depending on implementation, verify specifier structure
        assertNotNull(specifier);
    }

    @Test
    @DisplayName("Test getSpecifier with PopulationCodec and favouredCodec default")
    public void testGetSpecifier_PopulationCodec_FavouredDefault() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        Codec tokenCodec = Mockito.mock(Codec.class);
        Codec unfavouredCodec = Mockito.mock(Codec.class);

        Mockito.when(defaultCodec.equals(defaultCodec)).thenReturn(true);
        Mockito.when(defaultCodec.equals(unfavouredCodec)).thenReturn(false);

        PopulationCodec populationCodec = new PopulationCodec(tokenCodec, defaultCodec, unfavouredCodec);
        int[] specifier = CodecEncoding.getSpecifier(populationCodec, defaultCodec);
        assertNotNull(specifier);
        assertTrue(specifier.length >= 2);
    }

    @Test
    @DisplayName("Test getSpecifier with PopulationCodec and unfavouredCodec default")
    public void testGetSpecifier_PopulationCodec_UnfavouredDefault() {
        Codec defaultCodec = Mockito.mock(Codec.class);
        Codec tokenCodec = Mockito.mock(Codec.class);
        Codec favouredCodec = Mockito.mock(Codec.class);

        Mockito.when(defaultCodec.equals(favouredCodec)).thenReturn(false);
        Mockito.when(defaultCodec.equals(defaultCodec)).thenReturn(true);

        PopulationCodec populationCodec = new PopulationCodec(tokenCodec, favouredCodec, defaultCodec);
        int[] specifier = CodecEncoding.getSpecifier(populationCodec, defaultCodec);
        assertNotNull(specifier);
        assertTrue(specifier.length >= 2);
    }
}