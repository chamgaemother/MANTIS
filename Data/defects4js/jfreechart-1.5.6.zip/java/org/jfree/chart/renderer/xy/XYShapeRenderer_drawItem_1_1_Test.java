package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.renderer.LookupPaintScale;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class XYShapeRenderer_drawItem_1_1_Test {

//     @Test
//     @DisplayName("drawItem with XYZDataset utilizes paintScale based on z-value")
//     void TC14_drawItem_with_XYZDataset_utilizes_paintScale_based_on_z_value() throws Exception {
        // GIVEN
//         XYShapeRenderer renderer = new XYShapeRenderer();
//         LookupPaintScale paintScale = mock(LookupPaintScale.class);
//         renderer.setPaintScale(paintScale);
// 
        // Correct XYZDataset mock setup
//         XYZDataset dataset = mock(XYZDataset.class);
//         int series = 0;
//         int item = 0;
//         when(dataset.getZValue(series, item)).thenReturn(5.0);
//         when(dataset.getXValue(series, item)).thenReturn(10.0);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
// 
//         renderer.setUseFillPaint(false);
//         renderer.setDrawOutlines(true);
//         renderer.setUseOutlinePaint(true);
// 
        // Setup other necessary mocks
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getDomainAxisEdge()).thenReturn(XYPlot.DEFAULT_DOMAIN_AXIS_EDGE);
//         when(plot.getRangeAxisEdge()).thenReturn(XYPlot.DEFAULT_RANGE_AXIS_EDGE);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(10.0, dataArea, XYPlot.DEFAULT_DOMAIN_AXIS_EDGE)).thenReturn(50.0);
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, XYPlot.DEFAULT_RANGE_AXIS_EDGE)).thenReturn(60.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         org.jfree.chart.ChartRenderingInfo chartRenderingInfo = mock(org.jfree.chart.ChartRenderingInfo.class);
//         when(info.getOwner()).thenReturn(chartRenderingInfo);
//         when(chartRenderingInfo.getEntityCollection()).thenReturn(entities);
// 
        // WHEN
//         renderer.drawItem(g2, null, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
// 
        // THEN
//         verify(paintScale).getPaint(5.0);
//         verify(g2).fill(any(Shape.class));
//         verify(g2).draw(any(Shape.class));
//         verify(entities, atLeastOnce()).add(any());
//     }

//     @Test
//     @DisplayName("drawItem with useFillPaint enabled uses item fill paint for shapes")
//     void TC15_drawItem_with_useFillPaint_enabled_uses_item_fill_paint_for_shapes() throws Exception {
        // GIVEN
//         XYShapeRenderer renderer = new XYShapeRenderer();
//         renderer.setUseFillPaint(true);
// 
//         XYDataset dataset = mock(XYDataset.class);
//         int series = 1;
//         int item = 1;
//         when(dataset.getXValue(series, item)).thenReturn(10.0);
//         when(dataset.getYValue(series, item)).thenReturn(20.0);
// 
        // Setup other necessary mocks
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getDomainAxisEdge()).thenReturn(XYPlot.DEFAULT_DOMAIN_AXIS_EDGE);
//         when(plot.getRangeAxisEdge()).thenReturn(XYPlot.DEFAULT_RANGE_AXIS_EDGE);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.valueToJava2D(10.0, dataArea, XYPlot.DEFAULT_DOMAIN_AXIS_EDGE)).thenReturn(50.0);
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(20.0, dataArea, XYPlot.DEFAULT_RANGE_AXIS_EDGE)).thenReturn(60.0);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         org.jfree.chart.ChartRenderingInfo chartRenderingInfo = mock(org.jfree.chart.ChartRenderingInfo.class);
//         when(info.getOwner()).thenReturn(chartRenderingInfo);
//         when(chartRenderingInfo.getEntityCollection()).thenReturn(entities);
// 
        // WHEN
//         renderer.drawItem(g2, null, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
// 
        // THEN
//         verify(g2).fill(any(Shape.class));
//         verify(g2).draw(any(Shape.class));
//         verify(entities, atLeastOnce()).add(any());
//     }
}