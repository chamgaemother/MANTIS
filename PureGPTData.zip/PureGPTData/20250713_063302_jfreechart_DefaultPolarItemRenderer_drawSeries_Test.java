import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PolarPlot;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DefaultPolarItemRendererTest {

    private DefaultPolarItemRenderer renderer;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private PolarPlot plot;
    private XYDataset dataset;
    private ValueAxis axis;

    @BeforeEach
    void setUp() {
        renderer = new DefaultPolarItemRenderer();
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = new PlotRenderingInfo(null);
        plot = mock(PolarPlot.class);
        dataset = mock(XYDataset.class);
        axis = mock(ValueAxis.class);
        when(plot.getDataset(anyInt())).thenReturn(dataset);
        when(plot.getAxisForDataset(anyInt())).thenReturn(axis);
    }

    @Test
    void testDrawSeriesWithNoDataPoints() {
        when(dataset.getItemCount(anyInt())).thenReturn(0);
        assertDoesNotThrow(() -> renderer.drawSeries(g2, dataArea, info, plot, dataset, 0));
    }

    @Test
    void testDrawSeriesWithFilledSeries() {
        when(dataset.getItemCount(anyInt())).thenReturn(2);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(0.0, 90.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0, 1.0);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), eq(axis), eq(dataArea)))
                .thenReturn(new Point(50, 50), new Point(60, 60));
        when(renderer.isSeriesFilled(anyInt())).thenReturn(true);
        renderer.setConnectFirstAndLastPoint(true);

        assertDoesNotThrow(() -> renderer.drawSeries(g2, dataArea, info, plot, dataset, 0));
    }

    @Test
    void testDrawSeriesWithoutFilledSeries() {
        when(dataset.getItemCount(anyInt())).thenReturn(2);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(0.0, 90.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0, 1.0);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), eq(axis), eq(dataArea)))
                .thenReturn(new Point(50, 50), new Point(60, 60));
        when(renderer.isSeriesFilled(anyInt())).thenReturn(false);
        renderer.setConnectFirstAndLastPoint(true);

        assertDoesNotThrow(() -> renderer.drawSeries(g2, dataArea, info, plot, dataset, 0));
    }

    @Test
    void testDrawSeriesWithoutConnectingFirstAndLastPoint() {
        when(dataset.getItemCount(anyInt())).thenReturn(2);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(0.0, 90.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0, 1.0);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), eq(axis), eq(dataArea)))
                .thenReturn(new Point(50, 50), new Point(60, 60));
        when(renderer.isSeriesFilled(anyInt())).thenReturn(false);
        renderer.setConnectFirstAndLastPoint(false);

        assertDoesNotThrow(() -> renderer.drawSeries(g2, dataArea, info, plot, dataset, 0));
    }

    @Test
    void testDrawSeriesWithShapesVisible() {
        when(dataset.getItemCount(anyInt())).thenReturn(2);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(0.0, 90.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0, 1.0);
        when(plot.translateToJava2D(anyDouble(), anyDouble(), eq(axis), eq(dataArea)))
                .thenReturn(new Point(50, 50), new Point(60, 60));
        renderer.setShapesVisible(true);

        assertDoesNotThrow(() -> renderer.drawSeries(g2, dataArea, info, plot, dataset, 0));
    }
}