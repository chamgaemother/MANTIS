package org.jfree.chart.renderer.category;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.renderer.category.CategoryItemRendererState;

public class WaterfallBarRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("drawItem with null GradientPaintTransformer and GradientPaint")
    void test_TC06_drawItem_with_null_GradientPaintTransformer_and_GradientPaint() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setGradientPaintTransformer(null); // setting to accept null value
        renderer.setPositiveBarPaint(Color.GREEN);

        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem with draw bar outline enabled and stroke and paint provided")
    void test_TC07_drawItem_with_draw_bar_outline_enabled_and_stroke_and_paint_provided() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setDrawBarOutline(true);

        // Creating a spy to override methods
        WaterfallBarRenderer rendererSpy = spy(renderer);
        Stroke stroke = new java.awt.BasicStroke(1.0f);
        Paint outlinePaint = Color.BLACK;

        // Stubbing methods using spy
        doReturn(stroke).when(rendererSpy).getItemOutlineStroke(1, 1);
        doReturn(outlinePaint).when(rendererSpy).getItemOutlinePaint(1, 1);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(g2).setStroke(stroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem with draw bar outline enabled but stroke is null")
    void test_TC08_drawItem_with_draw_bar_outline_enabled_but_stroke_is_null() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setDrawBarOutline(true);

        // Creating a spy to override methods
        WaterfallBarRenderer rendererSpy = spy(renderer);
        doReturn(null).when(rendererSpy).getItemOutlineStroke(1, 1);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(g2, never()).draw(any(Rectangle2D.class)); // No outline stroke so draw should not happen
    }

    @Test
    @DisplayName("drawItem with draw bar outline enabled but paint is null")
    void test_TC09_drawItem_with_draw_bar_outline_enabled_but_paint_is_null() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setDrawBarOutline(true);

        // Creating a spy to override methods
        WaterfallBarRenderer rendererSpy = spy(renderer);
        doReturn(null).when(rendererSpy).getItemOutlinePaint(1, 1);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(g2, never()).draw(any(Rectangle2D.class)); // No outline paint so draw should not happen
    }

    @Test
    @DisplayName("drawItem with item label generator present and label visible")
    void test_TC10_drawItem_with_item_label_generator_present_and_label_visible() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        WaterfallBarRenderer renderer = new WaterfallBarRenderer();

        // Creating a spy to override methods
        WaterfallBarRenderer rendererSpy = spy(renderer);
        doReturn(generator).when(rendererSpy).getItemLabelGenerator(1, 1);
        doReturn(true).when(rendererSpy).isItemLabelVisible(1, 1);

        // WHEN
        rendererSpy.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // THEN
        verify(generator).generateLabel(dataset, 1, 1);
        verify(rendererSpy).drawItemLabel(eq(g2), eq(dataset), eq(1), eq(1), eq(plot), eq(generator), any(Rectangle2D.class), eq(false));
    }

}
