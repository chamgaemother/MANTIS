package com.fasterxml.jackson.databind.ser.std;

import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;

public class MapSerializer_serializeOptionalFields_2_1_Test {

    @Test
    @DisplayName("serializeOptionalFields serializes entries not matching suppressableValue and skips those that match for multiple entries")
    public void TC18() throws Exception {
        // Arrange
        // Create a MapSerializer instance via reflection
        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, null);

        // Set the _valueTypeSerializer field to a mock TypeSerializer
        TypeSerializer mockTypeSerializer = Mockito.mock(TypeSerializer.class);
        setField(mapSerializer, "_valueTypeSerializer", mockTypeSerializer);

        // Set the _suppressableValue to MARKER_FOR_EMPTY
        setField(mapSerializer, "_suppressableValue", MapSerializer.MARKER_FOR_EMPTY);

        // Set the _suppressNulls to true
        setField(mapSerializer, "_suppressNulls", true);

        // Mock key and value serializers
        JsonSerializer<Object> mockKeySerializer = Mockito.mock(JsonSerializer.class);
        JsonSerializer<Object> mockValueSerializer = Mockito.mock(JsonSerializer.class);

        // Set the _keySerializer and _valueSerializer fields
        setField(mapSerializer, "_keySerializer", mockKeySerializer);
        setField(mapSerializer, "_valueSerializer", mockValueSerializer);

        // Create the map with multiple entries
        Map<String, Object> map = new HashMap<>();
        map.put("key1", "value1");
        map.put("key2", MapSerializer.MARKER_FOR_EMPTY);
        map.put("key3", "value3");

        // Mock SerializerProvider
        SerializerProvider mockProvider = Mockito.mock(SerializerProvider.class);

        // Mock JsonGenerator
        JsonGenerator mockGenerator = Mockito.mock(JsonGenerator.class);

        // Act
        mapSerializer.serializeOptionalFields(map, mockGenerator, mockProvider, MapSerializer.MARKER_FOR_EMPTY);

        // Assert
        verify(mockKeySerializer).serialize(eq("key1"), eq(mockGenerator), eq(mockProvider));
        verify(mockValueSerializer).serialize(eq("value1"), eq(mockGenerator), eq(mockProvider));
        verify(mockKeySerializer).serialize(eq("key3"), eq(mockGenerator), eq(mockProvider));
        verify(mockValueSerializer).serialize(eq("value3"), eq(mockGenerator), eq(mockProvider));

        verify(mockKeySerializer, never()).serialize(eq("key2"), any(), any());
        verify(mockValueSerializer, never()).serialize(eq(MapSerializer.MARKER_FOR_EMPTY), any(), any());
    }

    @Test
    @DisplayName("serializeOptionalFields skips entries based on _inclusionChecker and serializes others when _inclusionChecker.shouldIgnore returns true for some keys")
    public void TC19() throws Exception {
        // Arrange
        // Create a MapSerializer instance via reflection
        MapSerializer mapSerializer = new MapSerializer(null, null, null, null, false, null, null, null);

        // Set the _inclusionChecker field to a mock IgnorePropertiesUtil.Checker
        IgnorePropertiesUtil.Checker mockInclusionChecker = Mockito.mock(IgnorePropertiesUtil.Checker.class);
        setField(mapSerializer, "_inclusionChecker", mockInclusionChecker);

        // Mock the shouldIgnore method
        when(mockInclusionChecker.shouldIgnore("ignoreKey")).thenReturn(true);
        when(mockInclusionChecker.shouldIgnore("key2")).thenReturn(false);

        // Mock key and value serializers
        JsonSerializer<Object> mockKeySerializer = Mockito.mock(JsonSerializer.class);
        JsonSerializer<Object> mockValueSerializer = Mockito.mock(JsonSerializer.class);

        // Set the _keySerializer and _valueSerializer fields
        setField(mapSerializer, "_keySerializer", mockKeySerializer);
        setField(mapSerializer, "_valueSerializer", mockValueSerializer);

        // Create the map with entries
        Map<String, Object> map = new HashMap<>();
        map.put("ignoreKey", "value1");
        map.put("key2", "value2");

        // Mock SerializerProvider
        SerializerProvider mockProvider = Mockito.mock(SerializerProvider.class);

        // Mock JsonGenerator
        JsonGenerator mockGenerator = Mockito.mock(JsonGenerator.class);

        // Act
        mapSerializer.serializeOptionalFields(map, mockGenerator, mockProvider, null);

        // Assert
        verify(mockInclusionChecker).shouldIgnore("ignoreKey");
        verify(mockInclusionChecker).shouldIgnore("key2");

        verify(mockKeySerializer).serialize(eq("key2"), eq(mockGenerator), eq(mockProvider));
        verify(mockValueSerializer).serialize(eq("value2"), eq(mockGenerator), eq(mockProvider));

        verify(mockKeySerializer, never()).serialize(eq("ignoreKey"), any(), any());
        verify(mockValueSerializer, never()).serialize(eq("value1"), any(), any());
    }

    // Helper method to set private or protected fields via reflection
    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = null;
        Class<?> clazz = target.getClass();
        while (clazz != null) {
            try {
                field = clazz.getDeclaredField(fieldName);
                break;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        if (field == null) {
            throw new NoSuchFieldException("Field " + fieldName + " not found in " + target.getClass());
        }
        field.setAccessible(true);
        field.set(target, value);
    }
}
