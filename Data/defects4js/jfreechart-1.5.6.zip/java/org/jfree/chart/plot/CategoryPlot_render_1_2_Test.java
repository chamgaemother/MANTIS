package org.jfree.chart.plot;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.plot.Plot;

import java.lang.reflect.Field;

public class CategoryPlot_render_1_2_Test {

    @Test
    @DisplayName("rendererChanged throws RuntimeException with different non-RendererChangeListener parent types")
    void TC06() throws Exception {
        // Arrange
        Plot differentPlotParent = Mockito.mock(Plot.class);
        CategoryPlot plot = new CategoryPlot();
        RendererChangeEvent event = Mockito.mock(RendererChangeEvent.class);

        // Use reflection to set the private parent field
        Field parentField = Plot.class.getDeclaredField("parent");
        parentField.setAccessible(true);
        parentField.set(plot, differentPlotParent);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class,
            () -> plot.rendererChanged(event),
            "Expected RuntimeException when parent does not implement RendererChangeListener");
        assertEquals("The renderer has changed and I don't know what to do!", exception.getMessage());
    }
}