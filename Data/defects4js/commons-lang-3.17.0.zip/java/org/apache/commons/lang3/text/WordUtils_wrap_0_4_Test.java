package org.apache.commons.lang3.text;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class WordUtils_wrap_0_4_Test {

    @Test
    @DisplayName("wrap handles null wrapOn by setting to default space")
    void testTC16() {
        // GIVEN
        String str = "apple banana cherry";
        int wrapLength = 6;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = null;

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "apple\nbanana\ncherry";
        assertEquals(expected, result, "Wrapping should occur at spaces when wrapOn is null.");
    }

    @Test
    @DisplayName("wrap handles wrapLength larger than string length without wrapping")
    void testTC17() {
        // GIVEN
        String str = "Short";
        int wrapLength = 20;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = " ";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "Short";
        assertEquals(expected, result, "No wrapping should occur as wrapLength exceeds string length.");
    }

    @Test
    @DisplayName("wrap handles multiple delimiters in wrapOn pattern")
    void testTC18() {
        // GIVEN
        String str = "one,two;three.four";
        int wrapLength = 5;
        String newLineStr = "\n";
        boolean wrapLongWords = false;
        String wrapOn = "[,;.]+";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "one,\ntwo;\nthree.\nfour";
        assertEquals(expected, result, "Text should be wrapped at commas, semicolons, and periods.");
    }

    @Test
    @DisplayName("wrap handles string with consecutive wrapOn delimiters correctly")
    void testTC19() {
        // GIVEN
        String str = "one,,two;;;three..four";
        int wrapLength = 5;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "[,;.]+";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "one,,\ntwo;;;\nthree..\nfour";
        assertFalse(result.contains("\n\n"), "There should be no empty lines due to consecutive delimiters.");
        assertEquals(expected, result, "Wrapping should occur correctly at each delimiter.");
    }

    @Test
    @DisplayName("wrap handles string ending with a wrapOn delimiter correctly")
    void testTC20() {
        // GIVEN
        String str = "one,two,three,";
        int wrapLength = 5;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ",";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        String expected = "one,\ntwo,\nthree,";
        assertFalse(result.endsWith("\n"), "There should be no extra empty lines at the end.");
        assertEquals(expected, result, "Wrapping should occur correctly before each comma.");
    }
}