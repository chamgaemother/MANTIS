import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.util.DefaultShadowGenerator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class XYBubbleRendererTest {

    XYBubbleRenderer renderer;
    XYItemRendererState state;
    Rectangle2D dataArea;
    PlotRenderingInfo plotInfo;
    XYPlot plot;
    XYZDataset dataset;
    ValueAxis domainAxis, rangeAxis;
    CrosshairState crosshairState;
    Graphics2D g2;

    @BeforeEach
    public void setUp() {
        renderer = new XYBubbleRenderer();
        state = new XYItemRendererState(plotInfo);
        dataArea = new Rectangle2D.Double(0, 0, 400, 200);
        plotInfo = new PlotRenderingInfo(null);
        plot = mock(XYPlot.class);
        dataset = mock(XYZDataset.class);
        domainAxis = new NumberAxis();
        rangeAxis = new NumberAxis();
        crosshairState = new CrosshairState();
        g2 = new BufferedImage(400, 200, BufferedImage.TYPE_INT_ARGB).createGraphics();
    }

    @Test
    public void testDrawItemNotVisible() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(1.0);
        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        // No drawing occurs, so we do not have to check anything specific.
    }

    @Test
    public void testDrawItemNullZValue() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(0.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        // Z is NaN, so no rendering should take place.
    }

    @ParameterizedTest
    @CsvSource({"VERTICAL", "HORIZONTAL"})
    public void testDrawItemValid(PlotOrientation orientation) {
        when(plot.getOrientation()).thenReturn(orientation);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(3.0);
        
        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // No exception should occur, and graphics draws must have been called at least once.
    }

    @Test
    public void testDrawItemWithEntityCollection() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(3.0);
        when(plotInfo.getOwner()).thenReturn(mock(DefaultShadowGenerator.class));

        EntityCollection entityCollection = mock(EntityCollection.class);
        when(plotInfo.getOwner().getEntityCollection()).thenReturn(entityCollection);

        renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Check the entity add call
        verify(entityCollection, times(1)).add(any(), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble());
    }

    @Test
    public void testDrawItemIndexOutOfBounds() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(Double.NaN);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(Double.NaN);

        assertDoesNotThrow(() -> renderer.drawItem(g2, state, dataArea, plotInfo, plot, domainAxis, rangeAxis, dataset, 2000, 1000, crosshairState, 0));
    }
}