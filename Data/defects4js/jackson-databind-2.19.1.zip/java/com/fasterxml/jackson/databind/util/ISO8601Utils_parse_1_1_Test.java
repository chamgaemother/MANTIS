package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;

public class ISO8601Utils_parse_1_1_Test {

    @Test
    @DisplayName("Parse date string with seconds=60, expecting seconds truncated to 59")
    void TC51_parseSecondsEqualTo60TruncateTo59() throws ParseException {
        String date = "2023-10-05T14:30:60Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(date, pos);
        Assertions.assertEquals(59, result.getSeconds(), "Seconds should be truncated to 59");
        Assertions.assertEquals(date.length(), pos.getIndex(), "Parse position should be at the end of the string");
    }

    @Test
    @DisplayName("Parse date string with seconds=61, expecting seconds truncated to 59")
    void TC52_parseSecondsEqualTo61TruncateTo59() throws ParseException {
        String date = "2023-10-05T14:30:61Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(date, pos);
        Assertions.assertEquals(59, result.getSeconds(), "Seconds should be truncated to 59");
        Assertions.assertEquals(date.length(), pos.getIndex(), "Parse position should be at the end of the string");
    }
}