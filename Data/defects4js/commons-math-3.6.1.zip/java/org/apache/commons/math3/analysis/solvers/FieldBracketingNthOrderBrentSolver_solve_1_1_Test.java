package org.apache.commons.math3.analysis.solvers;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.math3.analysis.solvers.FieldBracketingNthOrderBrentSolver;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.Decimal64;
import org.apache.commons.math3.RealFieldElement;

/**
 * Test class for FieldBracketingNthOrderBrentSolver.solve method.
 */
public class FieldBracketingNthOrderBrentSolver_solve_1_1_Test {

    @Test
    @DisplayName("solve returns min when AllowedSolution is BELOW_SIDE and yA <= 0")
    public void TC21_solve_returns_min_with_BELOW_SIDE_and_yA_leq_0() throws NullArgumentException, NoBracketingException {
        // Arrange
        Decimal64 min = new Decimal64(1.0);
        Decimal64 max = new Decimal64(2.0);
        Decimal64 startValue = new Decimal64(1.5);
        AllowedSolution allowedSolution = AllowedSolution.BELOW_SIDE;

        RealFieldUnivariateFunction<Decimal64> f = value ->
            value.equals(min) ? new Decimal64(-1.0) : new Decimal64(1.0);

        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
            new Decimal64(1e-6),
            new Decimal64(1e-10),
            new Decimal64(1e-10),
            5
        );

        int maxEval = 100;

        // Act
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // Assert
        assertEquals(min, result, "Solver should return min as the root.");
    }

    @Test
    @DisplayName("solve returns max when AllowedSolution is ABOVE_SIDE and yA < 0")
    public void TC22_solve_returns_max_with_ABOVE_SIDE_and_yA_lt_0() throws NullArgumentException, NoBracketingException {
        // Arrange
        Decimal64 min = new Decimal64(1.0);
        Decimal64 max = new Decimal64(2.0);
        Decimal64 startValue = new Decimal64(1.5);
        AllowedSolution allowedSolution = AllowedSolution.ABOVE_SIDE;

        RealFieldUnivariateFunction<Decimal64> f = value ->
            value.equals(max) ? new Decimal64(1.0) : new Decimal64(-1.0);

        FieldBracketingNthOrderBrentSolver<Decimal64> solver = new FieldBracketingNthOrderBrentSolver<>(
            new Decimal64(1e-6),
            new Decimal64(1e-10),
            new Decimal64(1e-10),
            5
        );

        int maxEval = 100;

        // Act
        Decimal64 result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);

        // Assert
        assertEquals(max, result, "Solver should return max as the root.");
    }
}