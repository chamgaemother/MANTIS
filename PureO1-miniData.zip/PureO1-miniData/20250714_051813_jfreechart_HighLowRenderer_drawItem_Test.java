import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.io.IOException;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.HighLowRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.Range;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;

public class HighLowRendererTest {

    private HighLowRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;
    private EntityCollection entities;

    @BeforeEach
    public void setUp() {
        renderer = new HighLowRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);
        entities = mock(EntityCollection.class);
        
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
    }

    @Test
    public void testDrawItem_XNotInRange() {
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verifyNoInteractions(g2);
        verifyNoInteractions(info);
    }

    @Test
    public void testDrawItem_DatasetIsOHLCDataset_VerticalOrientation_DrawAllTicks() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(52.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(52.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(renderer.getDrawOpenTicks()).thenReturn(true);
        when(renderer.getDrawCloseTicks()).thenReturn(true);
        renderer.setOpenTickPaint(null);
        renderer.setCloseTickPaint(null);
        renderer.setTickLength(2.0);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).draw(new Line2D.Double(50.0, 45.0, 50.0, 55.0));
        verify(g2).draw(new Line2D.Double(48.0, 50.0, 50.0, 50.0));
        verify(g2).draw(new Line2D.Double(50.0, 52.0, 52.0, 52.0));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_DatasetIsOHLCDataset_HorizontalOrientation_InvertedAxis_NoTicks() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.HORIZONTAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(Double.NaN);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(Double.NaN);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(rangeAxis.isInverted()).thenReturn(true);
        renderer.setDrawOpenTicks(false);
        renderer.setDrawCloseTicks(false);
        renderer.setTickLength(2.0);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).draw(new Line2D.Double(45.0, 50.0, 55.0, 50.0));
        verify(g2, never()).draw(any(Line2D.class));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_DatasetNotOHLCDataset_ItemZero() {
        when(dataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, null, plot,
                domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verifyNoMoreInteractions(g2);
    }

    @Test
    public void testDrawItem_DatasetNotOHLCDataset_ItemGreaterThanZero_ValidPrevious() {
        when(dataset.getXValue(0, 0)).thenReturn(25.0);
        when(dataset.getYValue(0, 0)).thenReturn(50.0);
        when(dataset.getXValue(0, 1)).thenReturn(26.0);
        when(dataset.getYValue(0, 1)).thenReturn(55.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(26.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemPaint(0, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 1)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, null, plot,
                domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).draw(new Line2D.Double(50.0, 50.0, 60.0, 55.0));
    }

    @Test
    public void testDrawItem_DatasetNotOHLCDataset_PrevOrCurrentNaN() {
        when(dataset.getXValue(0, 0)).thenReturn(25.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(26.0);
        when(dataset.getYValue(0, 1)).thenReturn(55.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(domainAxis.valueToJava2D(26.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(60.0);
        when(rangeAxis.valueToJava2D(Double.NaN, dataArea, RectangleEdge.LEFT)).thenReturn(Double.NaN);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.getItemPaint(0, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 1)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, null, plot,
                domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    public void testDrawItem_OHLCDataset_WithNullPaints() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(52.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(52.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.setDrawOpenTicks(true);
        renderer.setDrawCloseTicks(true);
        renderer.setOpenTickPaint(null);
        renderer.setCloseTickPaint(null);
        renderer.setTickLength(2.0);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        InOrder inOrder = inOrder(g2);
        inOrder.verify(g2).setPaint(any(Paint.class));
        inOrder.verify(g2).setStroke(any(Stroke.class));
        inOrder.verify(g2).setPaint(any(Paint.class));
        inOrder.verify(g2).draw(any(Line2D.class));
        inOrder.verify(g2).setPaint(any(Paint.class));
        inOrder.verify(g2).draw(any(Line2D.class));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_OHLCDataset_WithCustomPaints() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        Paint openPaint = mock(Paint.class);
        Paint closePaint = mock(Paint.class);
        when(renderer.getOpenTickPaint()).thenReturn(openPaint);
        when(renderer.getCloseTickPaint()).thenReturn(closePaint);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(52.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(52.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.setDrawOpenTicks(true);
        renderer.setDrawCloseTicks(true);
        renderer.setOpenTickPaint(openPaint);
        renderer.setCloseTickPaint(closePaint);
        renderer.setTickLength(2.0);
        Paint seriesPaint = mock(Paint.class);
        when(renderer.getItemPaint(0, 0)).thenReturn(seriesPaint);
        Stroke seriesStroke = mock(Stroke.class);
        when(renderer.getItemStroke(0, 0)).thenReturn(seriesStroke);
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        InOrder inOrder = inOrder(g2);
        inOrder.verify(g2).setPaint(seriesPaint);
        inOrder.verify(g2).setStroke(seriesStroke);
        inOrder.verify(g2).draw(new Line2D.Double(50.0, 45.0, 50.0, 55.0));
        inOrder.verify(g2).setPaint(openPaint);
        inOrder.verify(g2).draw(new Line2D.Double(50.0, 52.0, 50.0, 50.0));
        inOrder.verify(g2).setPaint(closePaint);
        inOrder.verify(g2).draw(new Line2D.Double(50.0, 52.0, 52.0, 52.0));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_OHLCDataset_NaNHighLow() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(Double.NaN);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(Double.NaN);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Line2D.class));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_NullEntityCollection() {
        when(dataset.getXValue(0, 0)).thenReturn(25.0);
        when(dataset instanceof OHLCDataset).thenReturn(false);
        when(dataset.getYValue(0, 0)).thenReturn(50.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(info.getOwner().getEntityCollection()).thenReturn(null);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verifyNoInteractions(entities);
    }

    @Test
    public void testDrawItem_DomainAxisInverted() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(52.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(52.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(true);
        renderer.setDrawOpenTicks(true);
        renderer.setDrawCloseTicks(true);
        renderer.setTickLength(2.0);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        verify(g2).draw(new Line2D.Double(50.0, 45.0, 50.0, 55.0));
        verify(g2).draw(new Line2D.Double(50.0, 52.0, 50.0, 50.0));
        verify(g2).draw(new Line2D.Double(50.0, 52.0, 52.0, 52.0));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_NullDataset() {
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, null, 0, 0, crosshairState, 0);
        
        verifyNoInteractions(g2);
        verifyNoInteractions(info);
    }

    @Test
    public void testDrawItem_ExceptionHandling() {
        when(dataset.getXValue(0, 0)).thenThrow(new RuntimeException("Test Exception"));
        
        assertThrows(RuntimeException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot,
                    domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        });
    }

    @Test
    public void testDrawItem_DrawOpenTicksFalse() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(50.0);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(52.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(52.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.setDrawOpenTicks(false);
        renderer.setDrawCloseTicks(true);
        renderer.setTickLength(2.0);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        verify(g2).draw(new Line2D.Double(50.0, 45.0, 50.0, 55.0));
        verify(g2, never()).draw(new Line2D.Double(anyDouble(), anyDouble(), anyDouble(), anyDouble()));
        verify(g2).draw(new Line2D.Double(50.0, 52.0, 52.0, 52.0));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_DrawCloseTicksFalse() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(50.0);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(52.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(52.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.setDrawOpenTicks(true);
        renderer.setDrawCloseTicks(false);
        renderer.setTickLength(2.0);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        verify(g2).draw(new Line2D.Double(50.0, 45.0, 50.0, 55.0));
        verify(g2).draw(new Line2D.Double(50.0, 52.0, 50.0, 50.0));
        verify(g2, never()).draw(new Line2D.Double(anyDouble(), anyDouble(), anyDouble(), anyDouble()));
        verify(entities).add(any());
    }

    @Test
    public void testDrawItem_TickLengthZero() {
        OHLCDataset ohlcDataset = mock(OHLCDataset.class);
        when(ohlcDataset.getXValue(0, 0)).thenReturn(25.0);
        when(domainAxis.getRange()).thenReturn(new Range(20.0, 30.0));
        when(domainAxis.valueToJava2D(25.0, dataArea, PlotOrientation.VERTICAL)).thenReturn(50.0);
        when(rangeAxis.getRange()).thenReturn(new Range(40.0, 60.0));
        when(ohlcDataset.getHighValue(0, 0)).thenReturn(55.0);
        when(ohlcDataset.getLowValue(0, 0)).thenReturn(45.0);
        when(rangeAxis.valueToJava2D(55.0, dataArea, RectangleEdge.LEFT)).thenReturn(55.0);
        when(rangeAxis.valueToJava2D(45.0, dataArea, RectangleEdge.LEFT)).thenReturn(45.0);
        when(ohlcDataset.getOpenValue(0, 0)).thenReturn(50.0);
        when(ohlcDataset.getCloseValue(0, 0)).thenReturn(52.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(52.0, dataArea, RectangleEdge.LEFT)).thenReturn(52.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(rangeAxis.isInverted()).thenReturn(false);
        renderer.setDrawOpenTicks(true);
        renderer.setDrawCloseTicks(true);
        renderer.setTickLength(0.0);
        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        
        renderer.drawItem(g2, state, dataArea, info, plot,
                domainAxis, rangeAxis, ohlcDataset, 0, 0, crosshairState, 0);
        
        verify(g2).draw(new Line2D.Double(50.0, 45.0, 50.0, 55.0));
        verify(g2).draw(new Line2D.Double(50.0, 50.0, 50.0, 50.0));
        verify(g2).draw(new Line2D.Double(50.0, 52.0, 52.0, 52.0));
        verify(entities).add(any());
    }
}