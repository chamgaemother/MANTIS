package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ConcurrentReferenceHashMap_size_0_3_Test {

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() handles identical modCounts in all segments and returns correct sum")
    public void testSizeWithIdenticalModCounts() throws Exception {
        // Create a ConcurrentReferenceHashMap
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();
        
        // Access the 'segments' array via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Simulate uniform modCounts and consistent counts
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.setInt(segment, 5); // use a consistent count value

            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            modCountField.setInt(segment, 1); // ensure all modCounts are the same
        }

        // Invoke the 'size' method
        Method sizeMethod = ConcurrentReferenceHashMap.class.getDeclaredMethod("size");
        sizeMethod.setAccessible(true);
        int result = (int) sizeMethod.invoke(map);

        // Expected result is number of segments times the count per segment
        int expectedSum = segments.length * 5;

        // Assert that the correct sum is returned
        assertEquals(expectedSum, result);
    }

    @Test
    @DisplayName("ConcurrentReferenceHashMap.size() retries try count but succeeds in counting without final locking")
    public void testSizeRetriesBeforeLocking() throws Exception {
        // Create a ConcurrentReferenceHashMap
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>();

        // Access the 'segments' array via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Simulate retry condition with modCount that stabilizes before locking
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.setInt(segment, 7); // use a consistent count value

            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            modCountField.setInt(segment, 1); // initial modCount
        }

        // Final attempts to set modCount to a stable state
        for (int i = 0; i < segments.length / 2; i++) {
            Object segment = segments[i];
            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            modCountField.setInt(segment, 2); // update to a new stable modCount
        }

        // Invoke the 'size' method
        Method sizeMethod = ConcurrentReferenceHashMap.class.getDeclaredMethod("size");
        sizeMethod.setAccessible(true);
        int result = (int) sizeMethod.invoke(map);

        // Expected result is number of segments times the count per segment
        int expectedSum = segments.length * 7;

        // Assert that the correct sum is returned
        assertEquals(expectedSum, result);
    }
}