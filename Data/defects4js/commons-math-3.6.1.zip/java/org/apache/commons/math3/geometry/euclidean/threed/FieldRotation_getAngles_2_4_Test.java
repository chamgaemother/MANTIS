// package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // 
// // import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// // import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
// // import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import java.lang.reflect.Field;
// // 
// // import static org.junit.jupiter.api.Assertions.assertEquals;
// // import static org.junit.jupiter.api.Assertions.assertNotNull;
// // import static org.junit.jupiter.api.Assertions.assertThrows;
// // 
// public class FieldRotation_getAngles_2_4_Test {
// // 
// //     @Test
// //     @DisplayName("getAngles called with ZYX and FRAME_TRANSFORM causing exception on v2.getX() out of bounds")
// //     void testTC21() throws Exception {
// //         FieldRotation<Double> rotation = createFieldRotation(0.0, 1.0, 0.0, 0.0);
// //         RotationOrder order = RotationOrder.ZYX;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// //         assertThrows(CardanEulerSingularityException.class, () -> rotation.getAngles(order, convention));
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with YXY and FRAME_TRANSFORM, v2.getY() within bounds")
// //     void testTC22() throws Exception {
// //         FieldRotation<Double> rotation = createFieldRotation(0.7071, 0.0, 0.7071, 0.0);
// //         RotationOrder order = RotationOrder.YXY;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// //         Double[] angles = rotation.getAngles(order, convention);
// //         assertNotNull(angles, "Angles array should not be null");
// //         assertEquals(3, angles.length, "Angles array should have length 3");
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with YXY and FRAME_TRANSFORM causing exception on v2.getY() out of bounds")
// //     void testTC23() throws Exception {
// //         FieldRotation<Double> rotation = createFieldRotation(0.0, 0.0, 0.0, 1.0);
// //         RotationOrder order = RotationOrder.YXY;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// //         assertThrows(CardanEulerSingularityException.class, () -> rotation.getAngles(order, convention));
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with YZY and FRAME_TRANSFORM, v2.getY() within bounds")
// //     void testTC24() throws Exception {
// //         FieldRotation<Double> rotation = createFieldRotation(0.8660, 0.5, 0.0, 0.0);
// //         RotationOrder order = RotationOrder.YZY;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// //         Double[] angles = rotation.getAngles(order, convention);
// //         assertNotNull(angles, "Angles array should not be null");
// //         assertEquals(3, angles.length, "Angles array should have length 3");
// //     }
// // 
// //     @Test
// //     @DisplayName("getAngles called with YZY and FRAME_TRANSFORM causing exception on v2.getY() out of bounds")
// //     void testTC25() throws Exception {
// //         FieldRotation<Double> rotation = createFieldRotation(0.0, 1.0, 1.0, 0.0);
// //         RotationOrder order = RotationOrder.YZY;
// //         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// //         assertThrows(CardanEulerSingularityException.class, () -> rotation.getAngles(order, convention));
// //     }
// // 
// //     private FieldRotation<Double> createFieldRotation(double q0, double q1, double q2, double q3) throws Exception {
// //         FieldRotation<Double> rotation = new FieldRotation<>(1.0, 0.0, 0.0, 0.0, false);
// //         setPrivateField(rotation, "q0", q0);
// //         setPrivateField(rotation, "q1", q1);
// //         setPrivateField(rotation, "q2", q2);
// //         setPrivateField(rotation, "q3", q3);
// //         return rotation;
// //     }
// // 
// //     private void setPrivateField(FieldRotation<?> rotation, String fieldName, double value) throws NoSuchFieldException, IllegalAccessException {
// //         Field field = FieldRotation.class.getDeclaredField(fieldName);
// //         field.setAccessible(true);
// //         field.set(rotation, value);
// //     }
// // }
// }