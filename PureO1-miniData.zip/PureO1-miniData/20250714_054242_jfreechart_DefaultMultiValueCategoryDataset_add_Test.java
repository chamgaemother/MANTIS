import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jfree.data.statistics.DefaultMultiValueCategoryDataset;
import org.jfree.data.Range;
import org.jfree.data.general.DatasetChangeEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class DefaultMultiValueCategoryDatasetTest {

    private DefaultMultiValueCategoryDataset dataset;

    @BeforeEach
    void setUp() {
        dataset = new DefaultMultiValueCategoryDataset();
    }

    @Test
    void testAdd_NullValues_ThrowsException() {
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        assertThrows(IllegalArgumentException.class, () -> {
            dataset.add(null, rowKey, columnKey);
        });
    }

    @Test
    void testAdd_NullRowKey_ThrowsException() {
        List<Number> values = Arrays.asList(1, 2, 3);
        Comparable columnKey = "Column1";
        assertThrows(IllegalArgumentException.class, () -> {
            dataset.add(values, null, columnKey);
        });
    }

    @Test
    void testAdd_NullColumnKey_ThrowsException() {
        List<Number> values = Arrays.asList(1, 2, 3);
        Comparable rowKey = "Row1";
        assertThrows(IllegalArgumentException.class, () -> {
            dataset.add(values, rowKey, null);
        });
    }

    @Test
    void testAdd_EmptyList() {
        List<Number> values = Collections.emptyList();
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        dataset.add(values, rowKey, columnKey);
        List<?> storedValues = dataset.getValues(rowKey, columnKey);
        assertTrue(storedValues.isEmpty());
        assertNull(dataset.getValue(rowKey, columnKey));
        Range range = dataset.getRangeBounds(false);
        assertEquals(new Range(0.0, 0.0), range);
    }

    @Test
    void testAdd_ListWithAllNulls() {
        List<Number> values = Arrays.asList(null, null, null);
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        dataset.add(values, rowKey, columnKey);
        List<?> storedValues = dataset.getValues(rowKey, columnKey);
        assertTrue(storedValues.isEmpty());
        assertNull(dataset.getValue(rowKey, columnKey));
        Range range = dataset.getRangeBounds(false);
        assertEquals(new Range(0.0, 0.0), range);
    }

    @Test
    void testAdd_ListWithAllNaNs() {
        List<Number> values = Arrays.asList(Double.NaN, Double.NaN);
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        dataset.add(values, rowKey, columnKey);
        List<?> storedValues = dataset.getValues(rowKey, columnKey);
        assertTrue(storedValues.isEmpty());
        assertNull(dataset.getValue(rowKey, columnKey));
        Range range = dataset.getRangeBounds(false);
        assertEquals(new Range(0.0, 0.0), range);
    }

    @Test
    void testAdd_ListWithValidAndInvalidValues() {
        List<Number> values = Arrays.asList(3, null, Double.NaN, 1, 2);
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        dataset.add(values, rowKey, columnKey);
        List<?> storedValues = dataset.getValues(rowKey, columnKey);
        assertEquals(Arrays.asList(1, 2, 3), storedValues);
        assertEquals(2.0, dataset.getValue(rowKey, columnKey).doubleValue(), 0.0001);
        Range range = dataset.getRangeBounds(false);
        assertEquals(new Range(1.0, 3.0), range);
    }

    @Test
    void testAdd_ListIsSorted() {
        List<Number> values = Arrays.asList(5, 2, 4, 1, 3);
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        dataset.add(values, rowKey, columnKey);
        List<?> storedValues = dataset.getValues(rowKey, columnKey);
        assertEquals(Arrays.asList(1, 2, 3, 4, 5), storedValues);
    }

    @Test
    void testAdd_MultipleAdds_UpdateRange() {
        List<Number> values1 = Arrays.asList(1, 2, 3);
        Comparable rowKey1 = "Row1";
        Comparable columnKey1 = "Column1";
        dataset.add(values1, rowKey1, columnKey1);
        Range range1 = dataset.getRangeBounds(false);
        assertEquals(new Range(1.0, 3.0), range1);

        List<Number> values2 = Arrays.asList(4, 5);
        Comparable rowKey2 = "Row2";
        Comparable columnKey2 = "Column2";
        dataset.add(values2, rowKey2, columnKey2);
        Range range2 = dataset.getRangeBounds(false);
        assertEquals(new Range(1.0, 5.0), range2);

        List<Number> values3 = Arrays.asList(-2, 0);
        Comparable rowKey3 = "Row3";
        Comparable columnKey3 = "Column3";
        dataset.add(values3, rowKey3, columnKey3);
        Range range3 = dataset.getRangeBounds(false);
        assertEquals(new Range(-2.0, 5.0), range3);

        List<Number> values4 = Arrays.asList(2, 3);
        Comparable rowKey4 = "Row4";
        Comparable columnKey4 = "Column4";
        dataset.add(values4, rowKey4, columnKey4);
        Range range4 = dataset.getRangeBounds(false);
        assertEquals(new Range(-2.0, 5.0), range4);
    }

    @Test
    void testAdd_NewMinLessThanCurrentMin() {
        List<Number> values1 = Arrays.asList(1, 2, 3);
        dataset.add(values1, "Row1", "Column1");
        Range range1 = dataset.getRangeBounds(false);
        assertEquals(new Range(1.0, 3.0), range1);

        List<Number> values2 = Arrays.asList(-1, 0);
        dataset.add(values2, "Row2", "Column2");
        Range range2 = dataset.getRangeBounds(false);
        assertEquals(new Range(-1.0, 3.0), range2);
    }

    @Test
    void testAdd_NewMaxGreaterThanCurrentMax() {
        List<Number> values1 = Arrays.asList(1, 2, 3);
        dataset.add(values1, "Row1", "Column1");
        Range range1 = dataset.getRangeBounds(false);
        assertEquals(new Range(1.0, 3.0), range1);

        List<Number> values2 = Arrays.asList(4, 5, 6);
        dataset.add(values2, "Row2", "Column2");
        Range range2 = dataset.getRangeBounds(false);
        assertEquals(new Range(1.0, 6.0), range2);
    }

    @Test
    void testAdd_NewValuesWithinCurrentRange() {
        List<Number> values1 = Arrays.asList(2, 3, 4);
        dataset.add(values1, "Row1", "Column1");
        Range range1 = dataset.getRangeBounds(false);
        assertEquals(new Range(2.0, 4.0), range1);

        List<Number> values2 = Arrays.asList(3, 3.5);
        dataset.add(values2, "Row2", "Column2");
        Range range2 = dataset.getRangeBounds(false);
        assertEquals(new Range(2.0, 4.0), range2);
    }

    @Test
    void testAdd_FireDatasetChanged() {
        DefaultMultiValueCategoryDataset spyDataset = Mockito.spy(dataset);
        List<Number> values = Arrays.asList(1, 2, 3);
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        spyDataset.add(values, rowKey, columnKey);
        Mockito.verify(spyDataset).fireDatasetChanged();
    }

    @Test
    void testAdd_DuplicateRowColumnKeys() {
        List<Number> values1 = Arrays.asList(1, 2);
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        dataset.add(values1, rowKey, columnKey);

        List<Number> values2 = Arrays.asList(3, 4);
        dataset.add(values2, rowKey, columnKey);

        List<?> storedValues = dataset.getValues(rowKey, columnKey);
        assertEquals(Arrays.asList(1, 2, 3, 4), storedValues);

        Number average = dataset.getValue(rowKey, columnKey);
        assertEquals(2.5, average.doubleValue(), 0.0001);

        Range range = dataset.getRangeBounds(false);
        assertEquals(new Range(1.0, 4.0), range);
    }
}