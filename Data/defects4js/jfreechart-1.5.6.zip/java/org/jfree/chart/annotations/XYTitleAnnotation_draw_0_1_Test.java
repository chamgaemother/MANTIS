package org.jfree.chart.annotations;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.util.XYCoordinateType;
import org.jfree.chart.title.TextTitle;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYTitleAnnotation_draw_0_1_Test {

    @Test
    @DisplayName("draw with coordinateType RELATIVE, orientation HORIZONTAL, maxWidth and maxHeight > 0, info is null")
    void TC01() throws Exception {
        // GIVEN
        TextTitle title = new TextTitle("Test Title");
        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, title);
        // Setting private fields via reflection
        Field coordinateTypeField = XYTitleAnnotation.class.getDeclaredField("coordinateType");
        coordinateTypeField.setAccessible(true);
        coordinateTypeField.set(annotation, XYCoordinateType.RELATIVE);

        Field maxWidthField = XYTitleAnnotation.class.getDeclaredField("maxWidth");
        maxWidthField.setAccessible(true);
        maxWidthField.set(annotation, 1.0);

        Field maxHeightField = XYTitleAnnotation.class.getDeclaredField("maxHeight");
        maxHeightField.setAccessible(true);
        maxHeightField.set(annotation, 1.0);

        PlotRenderingInfo info = null;
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Mock axis ranges
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);

        // WHEN
        annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 0, info);

        // THEN
        verify(g2).draw(any()); // Replace any() with specific arguments if possible
        // No entities should be added since info is null
    }


    @Test
    @DisplayName("draw with coordinateType RELATIVE, orientation VERTICAL, maxWidth <= 0 and maxHeight <= 0, info has entity collection")
    void TC02() throws Exception {
        // GIVEN
        TextTitle title = new TextTitle("Test Title");
        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, title);
        // Setting private fields via reflection
        Field coordinateTypeField = XYTitleAnnotation.class.getDeclaredField("coordinateType");
        coordinateTypeField.setAccessible(true);
        coordinateTypeField.set(annotation, XYCoordinateType.RELATIVE);

        Field maxWidthField = XYTitleAnnotation.class.getDeclaredField("maxWidth");
        maxWidthField.setAccessible(true);
        maxWidthField.set(annotation, 0.0);

        Field maxHeightField = XYTitleAnnotation.class.getDeclaredField("maxHeight");
        maxHeightField.setAccessible(true);
        maxHeightField.set(annotation, 0.0);

        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        org.jfree.chart.entity.EntityCollection entities = mock(org.jfree.chart.entity.EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Mock axis ranges
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);

        // WHEN
        annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 0, info);

        // THEN
        verify(g2).draw(any()); // Replace any() with specific arguments if possible
        verify(entities).addAll(any()); // Replace any() with specific arguments if possible
    }

    @Test
    @DisplayName("draw with coordinateType DATA, orientation HORIZONTAL, maxWidth set to specific value, info is null")
    void TC03() throws Exception {
        // GIVEN
        TextTitle title = new TextTitle("Test Title");
        XYTitleAnnotation annotation = new XYTitleAnnotation(100.0, 100.0, title);
        // Setting private fields via reflection
        Field coordinateTypeField = XYTitleAnnotation.class.getDeclaredField("coordinateType");
        coordinateTypeField.setAccessible(true);
        coordinateTypeField.set(annotation, XYCoordinateType.DATA);

        Field maxWidthField = XYTitleAnnotation.class.getDeclaredField("maxWidth");
        maxWidthField.setAccessible(true);
        maxWidthField.set(annotation, 500.0);

        PlotRenderingInfo info = null;
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Mock axis ranges
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);

        // WHEN
        annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 0, info);

        // THEN
        verify(g2).draw(any()); // Replace any() with specific arguments if possible
        // No entities should be added since info is null
    }

    @Test
    @DisplayName("draw with coordinateType DATA, orientation VERTICAL, maxHeight set to specific value, info has entity collection")
    void TC04() throws Exception {
        // GIVEN
        TextTitle title = new TextTitle("Test Title");
        XYTitleAnnotation annotation = new XYTitleAnnotation(200.0, 150.0, title);
        // Setting private fields via reflection
        Field coordinateTypeField = XYTitleAnnotation.class.getDeclaredField("coordinateType");
        coordinateTypeField.setAccessible(true);
        coordinateTypeField.set(annotation, XYCoordinateType.DATA);

        Field maxHeightField = XYTitleAnnotation.class.getDeclaredField("maxHeight");
        maxHeightField.setAccessible(true);
        maxHeightField.set(annotation, 300.0);

        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        org.jfree.chart.entity.EntityCollection entities = mock(org.jfree.chart.entity.EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Mock axis ranges
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);

        // WHEN
        annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 1, info);

        // THEN
        verify(g2).draw(any()); // Replace any() with specific arguments if possible
        verify(entities).addAll(any()); // Replace any() with specific arguments if possible
    }

    @Test
    @DisplayName("draw with coordinateType RELATIVE, orientation HORIZONTAL, maxWidth <= 0, maxHeight > 0, info has no existing entity collection")
    void TC05() throws Exception {
        // GIVEN
        TextTitle title = new TextTitle("Test Title");
        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, title);
        // Setting private fields via reflection
        Field coordinateTypeField = XYTitleAnnotation.class.getDeclaredField("coordinateType");
        coordinateTypeField.setAccessible(true);
        coordinateTypeField.set(annotation, XYCoordinateType.RELATIVE);

        Field maxWidthField = XYTitleAnnotation.class.getDeclaredField("maxWidth");
        maxWidthField.setAccessible(true);
        maxWidthField.set(annotation, 0.0);

        Field maxHeightField = XYTitleAnnotation.class.getDeclaredField("maxHeight");
        maxHeightField.setAccessible(true);
        maxHeightField.set(annotation, 1.0);

        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        when(info.getOwner().getEntityCollection()).thenReturn(null);
        Graphics2D g2 = mock(Graphics2D.class);
        XYPlot plot = mock(XYPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Mock axis ranges
        when(domainAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0, 100));
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);

        // WHEN
        annotation.draw(g2, plot, dataArea, domainAxis, rangeAxis, 2, info);

        // THEN
        verify(g2).draw(any()); // Replace any() with specific arguments if possible
    }
}