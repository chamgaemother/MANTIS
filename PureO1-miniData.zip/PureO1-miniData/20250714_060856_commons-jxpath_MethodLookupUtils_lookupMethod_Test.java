package org.apache.commons.jxpath.util;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.JXPathException;
import org.junit.jupiter.api.Test;

class MethodLookupUtilsTest {

    // Helper classes for testing
    static class TestExpressionContext implements ExpressionContext {
        // Implement necessary methods if any
    }

    static class TestClass {
        public void instanceMethod(ExpressionContext ctx, String param) {}
        public void instanceMethod(ExpressionContext ctx, Object param) {}
        public void anotherMethod(ExpressionContext ctx, Integer param) {}
        public static void staticMethod(ExpressionContext ctx, String param) {}
        public void methodWithNullableParam(ExpressionContext ctx, String param, Integer number) {}
    }

    @Test
    void testLookupMethod_NullParameters() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", null);
        assertNull(method, "Expected null when parameters are null");
    }

    @Test
    void testLookupMethod_EmptyParameters() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", new Object[] {});
        assertNull(method, "Expected null when parameters are empty");
    }

    @Test
    void testLookupMethod_FirstParameterNull() {
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", new Object[] { null, "test" });
        assertNull(method, "Expected null when first parameter is null");
    }

    @Test
    void testLookupMethod_MatchTypeNoMatch() {
        Object[] params = { new Object(), "test" };
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", params);
        assertNull(method, "Expected null when matchType returns NO_MATCH");
    }

    @Test
    void testLookupMethod_ExactMatch() throws NoSuchMethodException {
        Object[] params = { new TestExpressionContext(), "test" };
        Method expected = TestClass.class.getMethod("instanceMethod", ExpressionContext.class, String.class);
        Method actual = MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", params);
        assertEquals(expected, actual, "Expected exact match method");
    }

    @Test
    void testLookupMethod_TypeConversionMatch() throws NoSuchMethodException {
        Object[] params = { new TestExpressionContext(), 123 };
        Method expected = TestClass.class.getMethod("anotherMethod", ExpressionContext.class, Integer.class);
        Method actual = MethodLookupUtils.lookupMethod(TestClass.class, "anotherMethod", params);
        assertEquals(expected, actual, "Expected method match with type conversion");
    }

    @Test
    void testLookupMethod_AmbiguousMatch() {
        Object[] params = { new TestExpressionContext(), "ambiguous" };
        // Both instanceMethod(ExpressionContext, String) and instanceMethod(ExpressionContext, Object) match
        Exception exception = assertThrows(JXPathException.class, () -> {
            MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", params);
        });
        assertTrue(exception.getMessage().contains("Ambiguous method call"), "Expected ambiguous method call exception");
    }

    @Test
    void testLookupMethod_NoMethodFound() {
        Object[] params = { new TestExpressionContext(), true };
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "nonExistentMethod", params);
        assertNull(method, "Expected null when no method is found");
    }

    @Test
    void testLookupMethod_StaticMethodExcluded() {
        Object[] params = { new TestExpressionContext(), "test" };
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "staticMethod", params);
        assertNull(method, "Expected null when looking up a static method with lookupMethod");
    }

    @Test
    void testLookupMethod_MethodWithNullableParam_NullArgument() throws NoSuchMethodException {
        Object[] params = { new TestExpressionContext(), null, 10 };
        Method expected = null;
        // Exact match is not possible, but methodWithNullableParam exists
        Method actual = MethodLookupUtils.lookupMethod(TestClass.class, "methodWithNullableParam", params);
        // Depending on TypeUtils.canConvert, assume it finds the method
        // Since null can be assigned to any reference type, it's a match
        try {
            expected = TestClass.class.getMethod("methodWithNullableParam", ExpressionContext.class, String.class, Integer.class);
            assertEquals(expected, actual, "Expected method with nullable parameter");
        } catch (NoSuchMethodException e) {
            fail("Expected methodWithNullableParam to exist");
        }
    }

    @Test
    void testLookupMethod_FirstParamNotExpressionContext() {
        Object[] params = { "NotExpressionContext", "test" };
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", params);
        assertNull(method, "Expected null when first parameter is not ExpressionContext");
    }

    @Test
    void testLookupMethod_ParametersLengthMismatch() {
        Object[] params = { new TestExpressionContext() };
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "instanceMethod", params);
        assertNull(method, "Expected null when parameters length does not match");
    }

    @Test
    void testLookupMethod_TypeConversionNotPossible() {
        Object[] params = { new TestExpressionContext(), new Object() };
        Method method = MethodLookupUtils.lookupMethod(TestClass.class, "anotherMethod", params);
        assertNull(method, "Expected null when type conversion is not possible");
    }

    @Test
    void testLookupMethod_MultipleParameterTypes() throws NoSuchMethodException {
        Object[] params = { new TestExpressionContext(), "test", 5 };
        Method expected = TestClass.class.getMethod("methodWithNullableParam", ExpressionContext.class, String.class, Integer.class);
        Method actual = MethodLookupUtils.lookupMethod(TestClass.class, "methodWithNullableParam", params);
        assertEquals(expected, actual, "Expected method with multiple parameters");
    }
}