package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_isCreatable_2_1_Test {

    @Test
    @DisplayName("isCreatable(\"+\") returns false when input string is only a plus sign")
    void TC41_isCreatable_sign_only_plus() {
        String input = "+";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result, "Expected isCreatable(\"+\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"-\") returns false when input string is only a minus sign")
    void TC42_isCreatable_sign_only_minus() {
        String input = "-";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result, "Expected isCreatable(\"-\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"++123\") returns false for multiple leading plus signs")
    void TC43_isCreatable_multiple_leading_plus() {
        String input = "++123";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result, "Expected isCreatable(\"++123\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"--123\") returns false for multiple leading minus signs")
    void TC44_isCreatable_multiple_leading_minus() {
        String input = "--123";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result, "Expected isCreatable(\"--123\") to return false");
    }

    @Test
    @DisplayName("isCreatable(\"+\") returns false when input string is only a plus sign")
    void TC45_isCreatable_single_plus() {
        String input = "+";
        boolean result = NumberUtils.isCreatable(input);
        assertFalse(result, "Expected isCreatable(\"+\") to return false");
    }
}