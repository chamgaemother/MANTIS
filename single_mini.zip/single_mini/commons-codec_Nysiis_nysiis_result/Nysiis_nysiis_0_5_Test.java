package org.apache.commons.codec.language;

import org.apache.commons.codec.EncoderException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_5_Test {

    @Test
    @DisplayName("nysiis handles loop with zero iterations for single-character input")
    public void TC21_nysiis_handles_loop_with_zero_iterations_for_single_character_input() throws Exception {
        // Given
        String input = "A";
        Nysiis nysiis = new Nysiis();

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("A", result);
    }

    @Test
    @DisplayName("nysiis handles loop with one iteration for typical input")
    public void TC22_nysiis_handles_loop_with_one_iteration_for_typical_input() throws Exception {
        // Given
        String input = "BAT";
        Nysiis nysiis = new Nysiis();

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("BAT", result);
    }

    @Test
    @DisplayName("nysiis handles loop with multiple iterations for complex input")
    public void TC23_nysiis_handles_loop_with_multiple_iterations_for_complex_input() throws Exception {
        // Given
        String input = "SCHOLAR";
        Nysiis nysiis = new Nysiis();

        // When
        String result = nysiis.nysiis(input);

        // Then
        assertEquals("SSSOLAR", result);
    }

    @Test
    @DisplayName("nysiis throws EncoderException when input is not a string")
    public void TC24_nysiis_throws_EncoderException_when_input_is_not_a_string() {
        // Given
        Object input = 12345;
        Nysiis nysiis = new Nysiis();

        // When & Then
        assertThrows(EncoderException.class, () -> {
            nysiis.encode(input);
        });
    }
}