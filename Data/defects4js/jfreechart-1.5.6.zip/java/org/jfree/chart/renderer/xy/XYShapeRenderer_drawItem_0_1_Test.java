package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class XYShapeRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("info is null, pass=0, guideLinesVisible=true, orientation is HORIZONTAL")
    void TC01_drawItem_infoNull_pass0_guideLinesVisibleTrue_orientationHorizontal() throws Exception {
        // Arrange
        XYShapeRenderer renderer = new XYShapeRenderer();
        renderer.setGuideLinesVisible(true);
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        // info is intentionally null for this test case
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(20.0);

        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(20.0);

        // Act
        renderer.drawItem(g2, state, dataArea, null, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Line2D.Double> lineCaptor = ArgumentCaptor.forClass(Line2D.Double.class);
        verify(g2, times(2)).draw(lineCaptor.capture());
    }

    @Test
    @DisplayName("info is provided, x is NaN, method returns early")
    void TC02_drawItem_infoProvided_xNaN_returnsEarly() throws Exception {
        // Arrange
        XYShapeRenderer renderer = new XYShapeRenderer();
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset.getXValue(series, item)).thenReturn(Double.NaN);
        when(dataset.getYValue(series, item)).thenReturn(20.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("info is provided, y is NaN, method returns early")
    void TC03_drawItem_infoProvided_yNaN_returnsEarly() throws Exception {
        // Arrange
        XYShapeRenderer renderer = new XYShapeRenderer();
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getYValue(series, item)).thenReturn(Double.NaN);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("info is provided, pass=0, guideLinesVisible=false, orientation is VERTICAL")
    void TC04_drawItem_infoProvided_pass0_guideLinesVisibleFalse_orientationVertical() throws Exception {
        // Arrange
        XYShapeRenderer renderer = new XYShapeRenderer();
        renderer.setGuideLinesVisible(false);
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(15.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(25.0);

        when(dataset.getXValue(series, item)).thenReturn(15.0);
        when(dataset.getYValue(series, item)).thenReturn(25.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("info is provided, pass=0, guideLinesVisible=true, orientation is VERTICAL")
    void TC05_drawItem_infoProvided_pass0_guideLinesVisibleTrue_orientationVertical() throws Exception {
        // Arrange
        XYShapeRenderer renderer = new XYShapeRenderer();
        renderer.setGuideLinesVisible(true);
        
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(20.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(30.0);

        when(dataset.getXValue(series, item)).thenReturn(20.0);
        when(dataset.getYValue(series, item)).thenReturn(30.0);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        ArgumentCaptor<Line2D.Double> lineCaptor = ArgumentCaptor.forClass(Line2D.Double.class);
        verify(g2, times(2)).draw(lineCaptor.capture());
    }
}