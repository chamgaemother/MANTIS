package org.jfree.chart.renderer.category;

import java.lang.reflect.*;
import java.io.*;
import org.jfree.chart.ui.GradientPaintTransformer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.renderer.category.WaterfallBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.mockito.ArgumentCaptor;

public class WaterfallBarRenderer_drawItem_1_3_Test {

    @Test
    @DisplayName("drawItem with multiple iterations affecting seriesRunningTotal")
    public void testDrawItem_multipleIterations_seriesRunningTotal() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 0)).thenReturn(10.0);
        when(dataset.getValue(0, 1)).thenReturn(-4.0);
        when(dataset.getValue(0, 2)).thenReturn(6.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setFirstBarPaint(Color.BLUE);
        renderer.setLastBarPaint(Color.RED);
        renderer.setPositiveBarPaint(Color.GREEN);
        renderer.setNegativeBarPaint(new Color(139, 0, 0)); // Fixed: Color.RED was incorrect
        when(state.getSeriesRunningTotal()).thenReturn(0.0, 10.0, 6.0);

        // Act
        // First iteration
        renderer.drawItem(g2, state, new Rectangle2D.Double(0, 0, 100, 100), plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        // Second iteration
        renderer.drawItem(g2, state, new Rectangle2D.Double(0, 0, 100, 100), plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
        // Third iteration
        renderer.drawItem(g2, state, new Rectangle2D.Double(0, 0, 100, 100), plot, domainAxis, rangeAxis, dataset, 0, 2, 0);

        // Assert
        // First drawItem call
        verify(g2).setPaint(Color.BLUE);
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(Mockito.eq(10.0));
        
        // Second drawItem call
        verify(g2).setPaint(new Color(139, 0, 0)); // Fixed: Color.DARK_RED is incorrect, corrected to match paint initialization
        verify(g2, times(2)).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(Mockito.eq(6.0));
        
        // Third drawItem call
        verify(g2).setPaint(Color.RED);
        verify(g2, times(3)).fill(any(Rectangle2D.class));
        verify(state, times(2)).setSeriesRunningTotal(Mockito.eq(6.0));
    }

    @Test
    @DisplayName("drawItem with exception thrown by addItemEntity")
    public void testDrawItem_withExceptionInAddItemEntity() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = spy(new WaterfallBarRenderer());
        doThrow(new RuntimeException("Entity error")).when(renderer).addItemEntity(eq(entities), eq(dataset), eq(1), eq(1), any(Rectangle2D.class));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        });
        assertEquals("Entity error", exception.getMessage());
    }

    @Test
    @DisplayName("drawItem with dataset value zero, ensuring positiveBarPaint is used")
    public void testDrawItem_withZeroValue_usesPositiveBarPaint() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(0.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        renderer.setPositiveBarPaint(Color.GREEN);
        when(state.getSeriesRunningTotal()).thenReturn(10.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);

        // Assert
        verify(g2).setPaint(Color.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
        verify(state).setSeriesRunningTotal(10.0);
    }

    @Test
    @DisplayName("drawItem with minimal bar length ensuring barHeight/width meets minimum")
    public void testDrawItem_withBarHeightLessThanMinimum() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = spy(new WaterfallBarRenderer());
        
        // Use reflection to set private field 'minimumBarLength' to 5.0
        Field minBarLengthField = WaterfallBarRenderer.class.getDeclaredField("minimumBarLength");
        minBarLengthField.setAccessible(true);
        minBarLengthField.set(renderer, 5.0);
        
        when(state.getBarWidth()).thenReturn(1.0);
        when(state.getSeriesRunningTotal()).thenReturn(0.0);
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        ArgumentCaptor<Rectangle2D> rectangleCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(g2).fill(rectangleCaptor.capture());
        Rectangle2D capturedRect = rectangleCaptor.getValue();
        assertTrue(capturedRect.getHeight() >= 5.0, "Bar height should be at least the minimumBarLength");
        verify(state).setSeriesRunningTotal(2.0);
    }

    @Test
    @DisplayName("drawItem with getItemLabelGenerator throwing exception")
    public void testDrawItem_withExceptionInItemLabelGenerator() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        WaterfallBarRenderer renderer = spy(new WaterfallBarRenderer());
        CategoryItemLabelGenerator generator = mock(CategoryItemLabelGenerator.class);
        doReturn(generator).when(renderer).getItemLabelGenerator(1, 1);
        when(renderer.isItemLabelVisible(1, 1)).thenReturn(true);
        doThrow(new RuntimeException("Label generator error")).when(generator).generateLabel(any(), eq(1), eq(1));
        
        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        });
        assertEquals("Label generator error", exception.getMessage());
    }
}
