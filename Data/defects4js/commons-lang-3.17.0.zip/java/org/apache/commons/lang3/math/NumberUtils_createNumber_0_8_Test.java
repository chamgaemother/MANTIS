package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_createNumber_0_8_Test {

    @Test
    @DisplayName("Input string with uppercase type suffix 'F', valid Float, should return Float")
    public void TC36_createNumber_suffix_F_uppercase() {
        String input = "123.45F";
        Number result = NumberUtils.createNumber(input);
        assertTrue(result instanceof Float, "Result should be an instance of Float");
        assertEquals(123.45F, result.floatValue(), "Float value should match the input");
    }

}