package org.apache.commons.codec.language.bm;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.codec.language.bm.NameType;
import org.apache.commons.codec.language.bm.RuleType;
import org.apache.commons.codec.language.bm.Languages;

public class PhoneticEngine_encode_0_4_Test {

    @Test
    @DisplayName("encode with null input string")
    public void TC16_encodeWithNullInput() {
        // GIVEN
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.LANG_SPECIFIC, true);
        String input = null;
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("en");
        
        // WHEN & THEN
        Assertions.assertThrows(NullPointerException.class, () -> engine.encode(input, languageSet));
    }

    @Test
    @DisplayName("encode with LanguageSet containing multiple languages")
    public void TC17_encodeWithMultipleLanguages() {
        // GIVEN
        PhoneticEngine engine = new PhoneticEngine(NameType.ASHKENAZI, RuleType.LANG_SPECIFIC, true);
        String input = "Ben Affleck";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("he", "en");
        
        // WHEN
        String result = engine.encode(input, languageSet);
        
        // THEN
        Assertions.assertEquals("bn aflk", result);
    }

    @Test
    @DisplayName("encode with LanguageSet containing no languages")
    public void TC18_encodeWithEmptyLanguageSet() {
        // GIVEN
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.LANG_SPECIFIC, true);
        String input = "Example";
        Languages.LanguageSet languageSet = Languages.LanguageSet.empty();
        
        // WHEN
        String result = engine.encode(input, languageSet);
        
        // THEN
        Assertions.assertEquals("", result);
    }

    @Test
    @DisplayName("encode with input containing only spaces")
    public void TC19_encodeWithOnlySpaces() {
        // GIVEN
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.LANG_SPECIFIC, true);
        String input = "   ";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("en");
        
        // WHEN
        String result = engine.encode(input, languageSet);
        
        // THEN
        Assertions.assertEquals("", result);
    }

    @Test
    @DisplayName("encode with multiple iterations in loop processing input characters")
    public void TC20_encodeWithMultipleLoopIterations() {
        // GIVEN
        PhoneticEngine engine = new PhoneticEngine(NameType.GENERIC, RuleType.LANG_SPECIFIC, true);
        String input = "d'Oliveira van der Sar";
        Languages.LanguageSet languageSet = Languages.LanguageSet.from("en", "nl");
        
        // WHEN
        String result = engine.encode(input, languageSet);
        
        // THEN
        Assertions.assertEquals("d olivr vn dr sr", result);
    }
}