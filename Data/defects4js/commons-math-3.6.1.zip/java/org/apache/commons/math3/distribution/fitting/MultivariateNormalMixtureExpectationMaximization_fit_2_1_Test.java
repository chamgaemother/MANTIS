package org.apache.commons.math3.distribution.fitting;

import org.apache.commons.math3.distribution.MixtureMultivariateNormalDistribution;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.MathArrays;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MultivariateNormalMixtureExpectationMaximization_fit_2_1_Test {
    
//     @Test
//     @DisplayName("fit with initial mixture weights not summing to 1 normalizes weights and converges successfully")
//     public void TC23_fit_normalizes_weights_and_converges() throws Exception {
        // GIVEN
//         double[] weights = {0.3, 0.3}; // Sum is 0.6, not 1
//         double[][] means = {{1.0, 1.0}, {5.0, 5.0}};
//         double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}, {{1.5, 0.0}, {0.0, 1.5}}};
//         MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
//         double[][] data = {{1.1, 0.9}, {5.2, 4.8}, {1.0, 1.0}, {5.0, 5.0}};
//         MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);
//         
        // WHEN
//         optimizer.fit(initialMixture, 10, 1e-6);
//         
        // THEN
//         MixtureMultivariateNormalDistribution fittedModel = optimizer.getFittedModel();
//         assertNotNull(fittedModel, "Fitted model should not be null");
//         
        // Assert that weights are normalized to sum to 1
//         double[] fittedWeights = fittedModel.getWeights();
//         double sumWeights = MathArrays.sum(fittedWeights);
//         assertEquals(1.0, sumWeights, 1e-6, "Weights should be normalized to sum to 1");
//         
        // Additional assertions can be added here to verify fittedModel's parameters
//     }
    
    @Test
    @DisplayName("fit with initial mixture containing negative weights processes correctly or throws exception")
    public void TC24_fit_with_negative_weights() {
        // GIVEN
        double[] weights = {0.5, -0.5}; // Intentional negative weight
        double[][] means = {{2.0, 2.0}, {4.0, 4.0}};
        double[][][] covariances = {{{1.0, 0.1}, {0.1, 1.0}}, {{1.5, 0.2}, {0.2, 1.5}}};
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        double[][] data = {{2.1, 1.9}, {4.2, 3.8}, {2.0, 2.0}, {4.0, 4.0}};
        MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);
        
        // WHEN & THEN
        // Expect NotStrictlyPositiveException to be thrown as per the scenario
        assertThrows(NotStrictlyPositiveException.class, () -> {
            optimizer.fit(initialMixture, 10, 1e-6);
        }, "Fitting with negative weights should throw NotStrictlyPositiveException");
    }
    
    @Test
    @DisplayName("fit with initial mixture having one component with zero weight throws NotStrictlyPositiveException")
    public void TC25_fit_with_zero_weight_throws_exception() {
        // GIVEN
        double[] weights = {1.0, 0.0}; // Second component has zero weight
        double[][] means = {{3.0, 3.0}, {6.0, 6.0}};
        double[][][] covariances = {{{1.0, 0.0}, {0.0, 1.0}}, {{1.5, 0.0}, {0.0, 1.5}}};
        MixtureMultivariateNormalDistribution initialMixture = new MixtureMultivariateNormalDistribution(weights, means, covariances);
        double[][] data = {{3.1, 2.9}, {6.2, 5.8}, {3.0, 3.0}, {6.0, 6.0}};
        MultivariateNormalMixtureExpectationMaximization optimizer = new MultivariateNormalMixtureExpectationMaximization(data);
        
        // WHEN & THEN
        // Expect NotStrictlyPositiveException to be thrown
        assertThrows(NotStrictlyPositiveException.class, () -> {
            optimizer.fit(initialMixture, 10, 1e-6);
        }, "Fitting with a component having zero weight should throw NotStrictlyPositiveException");
    }
}