import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

public class UTF8DataInputJsonParserTest {

    private IOContext ioContext;
    private ByteQuadsCanonicalizer sym;
    private ObjectCodec codec;

    @BeforeEach
    public void setUp() {
        ioContext = IOContext.create(JsonToken.class, null);
        sym = ByteQuadsCanonicalizer.createRoot();
        codec = mock(ObjectCodec.class);
    }

    private UTF8DataInputJsonParser createParser(String json) throws IOException {
        byte[] bytes = json.getBytes("UTF-8");
        DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(bytes));
        int firstByte = dataInput.readUnsignedByte();
        return new UTF8DataInputJsonParser(ioContext, 0, dataInput, codec, sym, firstByte);
    }

    @Test
    public void testNextTokenEmpty() throws IOException {
        UTF8DataInputJsonParser parser = createParser("");
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStartObject() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{ }");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStartArray() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[ ]");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenFieldName() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{\"name\": \"value\"}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.currentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenString() throws IOException {
        UTF8DataInputJsonParser parser = createParser("\"hello\"");
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("hello", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStringWithEscape() throws IOException {
        UTF8DataInputJsonParser parser = createParser("\"he\\nllo\"");
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("he\nllo", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenTrue() throws IOException {
        UTF8DataInputJsonParser parser = createParser("true");
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenFalse() throws IOException {
        UTF8DataInputJsonParser parser = createParser("false");
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenNull() throws IOException {
        UTF8DataInputJsonParser parser = createParser("null");
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenNumberInt() throws IOException {
        UTF8DataInputJsonParser parser = createParser("123");
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenNumberNegativeInt() throws IOException {
        UTF8DataInputJsonParser parser = createParser("-456");
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(-456, parser.getIntValue());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenNumberFloat() throws IOException {
        UTF8DataInputJsonParser parser = createParser("78.90");
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(78.90, parser.getDoubleValue(), 0.0001);
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenNumberExponential() throws IOException {
        UTF8DataInputJsonParser parser = createParser("1e10");
        assertEquals(JsonToken.VALUE_NUMBER_FLOAT, parser.nextToken());
        assertEquals(1e10, parser.getDoubleValue(), 0.0001);
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenInvalidToken() throws IOException {
        UTF8DataInputJsonParser parser = createParser("tru");
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenInvalidNumber() throws IOException {
        UTF8DataInputJsonParser parser = createParser("-");
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenEndObjectWithoutStart() throws IOException {
        UTF8DataInputJsonParser parser = createParser("}");
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenMalformedString() throws IOException {
        UTF8DataInputJsonParser parser = createParser("\"unclosed string");
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenMultipleValues() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{\"a\":1, \"b\":2}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("b", parser.currentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenArrayWithValues() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[true, false, null, 123]");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenNestedObjects() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{\"outer\":{\"inner\":\"value\"}}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("outer", parser.currentName());
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("inner", parser.currentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenInvalidJson() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{invalid}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenEmptyObject() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenEmptyArray() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[]");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenCommaWithoutValue() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{\"a\":1,}");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenTrailingCommaInArray() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[1,2,3,]");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(3, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenMultipleRootValues() throws IOException {
        UTF8DataInputJsonParser parser = createParser("true false null");
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStringAfterNumber() throws IOException {
        UTF8DataInputJsonParser parser = createParser("123 \"abc\"");
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(123, parser.getIntValue());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("abc", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenInvalidCharacterInNumber() throws IOException {
        UTF8DataInputJsonParser parser = createParser("12a3");
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenUnterminatedObject() throws IOException {
        UTF8DataInputJsonParser parser = createParser("{\"a\":1");
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("a", parser.currentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenUnterminatedArray() throws IOException {
        UTF8DataInputJsonParser parser = createParser("[1,2,3");
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(3, parser.getIntValue());
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenInvalidStartCharacter() throws IOException {
        UTF8DataInputJsonParser parser = createParser("@");
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenComplexJson() throws IOException {
        String json = "{ \"name\": \"John\", \"age\": 30, \"isMarried\": false, \"children\": [\"Ann\", \"Billy\"] }";
        UTF8DataInputJsonParser parser = createParser(json);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("name", parser.currentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("John", parser.getText());
        
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("age", parser.currentName());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(30, parser.getIntValue());

        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("isMarried", parser.currentName());
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());

        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("children", parser.currentName());
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("Ann", parser.getText());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("Billy", parser.getText());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());

        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenStringWithUnicode() throws IOException {
        UTF8DataInputJsonParser parser = createParser("\"Hello \\u0041\\u0042\\u0043\"");
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("Hello ABC", parser.getText());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenSingleQuoteString() throws IOException {
        UTF8DataInputJsonParser parser = createParser("'single quoted string'");
        // Assuming single quotes are not allowed by default
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenSingleQuoteStringAllowed() throws IOException {
        // Enable single quotes
        UTF8DataInputJsonParser parser = createParserWithFeatures("'single quoted string'", 1 << 1);
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("single quoted string", parser.getText());
        assertNull(parser.nextToken());
    }

    private UTF8DataInputJsonParser createParserWithFeatures(String json, int features) throws IOException {
        byte[] bytes = json.getBytes("UTF-8");
        DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(bytes));
        int firstByte = dataInput.readUnsignedByte();
        return new UTF8DataInputJsonParser(ioContext, features, dataInput, codec, sym, firstByte);
    }

    @Test
    public void testNextTokenSingleQuoteStringAfterAllowed() throws IOException {
        // Enable single quotes and parse multiple tokens
        String json = "{'key':'value'}";
        UTF8DataInputJsonParser parser = createParserWithFeatures(json, 1 << 1);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("key", parser.currentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenInvalidEscape() throws IOException {
        UTF8DataInputJsonParser parser = createParser("\"Invalid \\x escape\"");
        assertThrows(JsonParseException.class, parser::nextToken);
    }

    @Test
    public void testNextTokenInvalidUnicodeEscape() throws IOException {
        UTF8DataInputJsonParser parser = createParser("\"Invalid \\u12G4 escape\"");
        assertThrows(JsonParseException.class, parser::nextToken);
    }
}