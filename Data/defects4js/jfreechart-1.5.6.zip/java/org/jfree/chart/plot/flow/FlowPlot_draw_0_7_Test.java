package org.jfree.chart.plot.flow;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.NodeEntity;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.data.flow.FlowDataset;
import org.jfree.data.flow.FlowDatasetUtils;
import org.jfree.data.flow.FlowKey;
import org.jfree.data.flow.NodeKey;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FlowPlot_draw_0_7_Test {

    @Test
    @DisplayName("Verifies draw method correctly handles empty destinations list in a stage")
    void TC31_draw_emptyDestinationsList_skipsProcessing() throws Exception {
        // Arrange
        FlowPlot flowPlot = new FlowPlot(null);

        // Use reflection to set private dataset field if necessary
        Field datasetField = FlowPlot.class.getDeclaredField("dataset");
        datasetField.setAccessible(true);
        FlowDataset mockDataset = mock(FlowDataset.class);
        when(mockDataset.getStageCount()).thenReturn(1);
        when(mockDataset.getSources(0)).thenReturn(Arrays.asList("Source1"));
        when(mockDataset.getDestinations(0)).thenReturn(Arrays.asList());
        when(mockDataset.getFlow(0, "Source1", "Destination1")).thenReturn(null);
        datasetField.set(flowPlot, mockDataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
        Point2D point = new Point2D.Double(250, 250);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entityCollection = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entityCollection);

        // Act
        flowPlot.draw(g2, area, point, state, info);

        // Assert
        verify(mockDataset, times(1)).getDestinations(0);
        // Verify that no entities are added since destinations are empty
        verify(entityCollection, never()).add(any());
    }

    @Test
    @DisplayName("Verifies draw method correctly draws background when provided")
    void TC32_draw_drawsBackgroundCorrectly() throws Exception {
        // Arrange
        FlowPlot flowPlot = new FlowPlot(null);

        // Use reflection to set private fields if necessary
        Field backgroundPaintField = FlowPlot.class.getDeclaredField("defaultNodeLabelPaint");
        backgroundPaintField.setAccessible(true);
        Color backgroundColor = Color.BLUE;
        backgroundPaintField.set(flowPlot, backgroundColor);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
        Point2D point = new Point2D.Double(250, 250);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // Act
        flowPlot.draw(g2, area, point, state, info);

        // Assert
        verify(g2, times(1)).setPaint(backgroundColor);
        verify(g2, times(1)).fill(area);
    }

    @Test
    @DisplayName("Verifies draw method correctly calculates stageWidth based on area width and nodeWidth")
    void TC33_draw_calculatesStageWidthCorrectly() throws Exception {
        // Arrange
        FlowPlot flowPlot = new FlowPlot(null);

        // Set nodeWidth and flowMargin
        Field nodeWidthField = FlowPlot.class.getDeclaredField("nodeWidth");
        nodeWidthField.setAccessible(true);
        nodeWidthField.set(flowPlot, 50.0);

        Field flowMarginField = FlowPlot.class.getDeclaredField("flowMargin");
        flowMarginField.setAccessible(true);
        flowMarginField.set(flowPlot, 0.1);

        // Mock dataset
        Field datasetField = FlowPlot.class.getDeclaredField("dataset");
        datasetField.setAccessible(true);
        FlowDataset mockDataset = mock(FlowDataset.class);
        when(mockDataset.getStageCount()).thenReturn(3);
        datasetField.set(flowPlot, mockDataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
        Point2D point = new Point2D.Double(250, 250);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        // Act
        flowPlot.draw(g2, area, point, state, info);

        // Assert
        // Calculate expected stageWidth
        double expectedStageWidth = (area.getWidth() - ((3 + 1) * 50.0)) / 3;

        // Indirect verification, as stageWidth is a local calculation
        verify(mockDataset, times(1)).getStageCount();
    }

//     @Test
//     @DisplayName("Verifies draw method marks the last stage's destination nodes correctly")
//     void TC34_draw_finalStageDestinationNodesRenderedCorrectly() throws Exception {
        // Arrange
//         FlowPlot flowPlot = new FlowPlot(null);
// 
        // Mock dataset
//         Field datasetField = FlowPlot.class.getDeclaredField("dataset");
//         datasetField.setAccessible(true);
//         FlowDataset mockDataset = mock(FlowDataset.class);
//         when(mockDataset.getStageCount()).thenReturn(2);
//         when(mockDataset.getDestinations(1)).thenReturn(Arrays.asList("Destination1", "Destination2"));
//         when(mockDataset.getSources(1)).thenReturn(Arrays.asList("Source1", "Source2"));
//         datasetField.set(flowPlot, mockDataset);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
//         Point2D point = new Point2D.Double(250, 250);
//         PlotState state = mock(PlotState.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(mock(ChartRenderingInfo.class));
//         when(info.getOwner().getEntityCollection()).thenReturn(entityCollection);
// 
        // Act
//         flowPlot.draw(g2, area, point, state, info);
// 
        // Assert
//         ArgumentCaptor<NodeEntity> captor = ArgumentCaptor.forClass(NodeEntity.class);
//         verify(entityCollection, times(2)).add(captor.capture());
//         for (NodeEntity entity : captor.getAllValues()) {
//             assertTrue(entity.getNodeKey().getStage() == 2, "Destination nodes should belong to the last stage");
//             assertNotNull(entity.getLabel(), "Destination node labels should not be null");
//         }
//     }

}