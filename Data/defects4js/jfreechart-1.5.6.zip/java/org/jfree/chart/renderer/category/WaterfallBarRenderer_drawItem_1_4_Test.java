package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.ui.GradientPaintTransformer;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.ui.GradientPaintTransformType;
import org.jfree.chart.ui.StandardGradientPaintTransformer;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class WaterfallBarRenderer_drawItem_1_4_Test {

    @Test
    @DisplayName("TC31: drawItem with gradientPaintTransformer present but seriesPaint is null")
    void TC31_drawItem_withGradientPaintTransformer_present_but_seriesPaint_null() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        GradientPaintTransformer transformer = mock(GradientPaintTransformer.class);
        renderer.setGradientPaintTransformer(transformer);
        renderer.setPositiveBarPaint(null);
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        verify(g2).setPaint(null);
        verify(g2).fill(any(Rectangle2D.class));
        verify(transformer, never()).transform(any(), any(Rectangle2D.class));
    }

    @Test
    @DisplayName("TC32: drawItem with rangeAxis returning null range bounds")
    void TC32_drawItem_withRangeAxisReturningNull() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(null);
        
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        verify(g2, never()).setPaint(any());
        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(state, never()).setSeriesRunningTotal(anyDouble());
    }

    @Test
    @DisplayName("TC33: drawItem with getItemMargin returning extreme values")
    void TC33_drawItem_withExtremeItemMarginValues() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(1, 1)).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.getCategorySeriesMiddle(any(), any(), any(), eq(1000.0), eq(dataArea), eq(RectangleEdge.LEFT)))
            .thenReturn(50.0);
        
        WaterfallBarRenderer renderer = spy(new WaterfallBarRenderer());
        doReturn(1000.0).when(renderer).getItemMargin();
        
        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1, 0);
        
        // Assert
        verify(domainAxis).getCategorySeriesMiddle(any(), any(), any(), eq(1000.0), eq(dataArea), eq(RectangleEdge.LEFT));
        verify(g2).fill(any(Rectangle2D.class));
    }
}