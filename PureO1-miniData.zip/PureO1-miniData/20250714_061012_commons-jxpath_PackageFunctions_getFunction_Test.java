package org.apache.commons.jxpath;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.jxpath.functions.ConstructorFunction;
import org.apache.commons.jxpath.functions.MethodFunction;
import org.apache.commons.jxpath.util.ClassLoaderUtil;
import org.apache.commons.jxpath.util.MethodLookupUtils;
import org.apache.commons.jxpath.util.TypeUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PackageFunctionsTest {

    @Mock
    private TypeUtils typeUtils;

    @Mock
    private MethodLookupUtils methodLookupUtils;

    @Mock
    private ClassLoaderUtil classLoaderUtil;

    @Mock
    private NodeSet nodeSet;

    @Mock
    private Pointer pointer;

    @InjectMocks
    private PackageFunctions packageFunctions = new PackageFunctions("java.util.", "util");

    @Test
    void testGetFunction_NamespaceMismatch() {
        Function func = packageFunctions.getFunction("other", "Date.new", null);
        assertNull(func);
    }

    @Test
    void testGetFunction_NullParameters() {
        packageFunctions = new PackageFunctions("java.util.", "util");
        Function func = packageFunctions.getFunction("util", "Date.new", null);
        // Assuming MethodLookupUtils and ClassLoaderUtil are properly mocked
        // Here we expect ConstructorFunction or MethodFunction based on mocks
        // Since no setup, likely to throw exception or return null
        // For simplicity, assert not null or null as per behavior
        // But without setup, it would throw JXPathException due to ClassNotFound
        assertThrows(JXPathException.class, () -> packageFunctions.getFunction("util", "Date.new", null));
    }

    @Test
    void testGetFunction_NoParameters_MethodNotFound() {
        Object[] params = {};
        Function func = packageFunctions.getFunction("util", "nonExistentMethod", params);
        assertNull(func);
    }

    @Test
    void testGetFunction_MethodFoundOnTarget() throws Exception {
        Object[] params = { "test" };
        String methodName = "substring";
        String target = "example";

        Method method = String.class.getMethod(methodName, int.class, int.class);
        when(MethodLookupUtils.lookupMethod(String.class, methodName, params)).thenReturn(method);

        packageFunctions = new PackageFunctions("java.lang.", "util");
        Function func = packageFunctions.getFunction("util", methodName, new Object[] { target, 1, 2 });
        assertTrue(func instanceof MethodFunction);
        assertEquals(method, ((MethodFunction) func).getMethod());
    }

    @Test
    void testGetFunction_TargetIsNodeSet_MethodFound() throws Exception {
        Object[] params = { nodeSet, "size" };
        Method method = List.class.getMethod("size");
        when(nodeSet.getPointers()).thenReturn(Collections.emptyList());
        when(MethodLookupUtils.lookupMethod(List.class, "size", params)).thenReturn(method);

        Function func = packageFunctions.getFunction("util", "size", params);
        assertTrue(func instanceof MethodFunction);
        assertEquals(method, ((MethodFunction) func).getMethod());
    }

    @Test
    void testGetFunction_TargetIsCollection_PointerFound() throws Exception {
        Object[] params = { List.of(pointer), "size" };
        Method method = List.class.getMethod("size");
        when(pointer.getValue()).thenReturn(List.of());
        when(MethodLookupUtils.lookupMethod(List.class, "size", params)).thenReturn(method);

        Function func = packageFunctions.getFunction("util", "size", params);
        assertTrue(func instanceof MethodFunction);
        assertEquals(method, ((MethodFunction) func).getMethod());
    }

    @Test
    void testGetFunction_TargetIsCollection_NoElements() {
        Object[] params = { Collections.emptyList(), "size" };
        Function func = packageFunctions.getFunction("util", "size", params);
        assertNull(func);
    }

    @Test
    void testGetFunction_MethodNotFoundAfterNodeSet() throws Exception {
        Object[] params = { nodeSet, "nonExistentMethod" };
        when(nodeSet.getPointers()).thenReturn(Collections.emptyList());
        when(MethodLookupUtils.lookupMethod(List.class, "nonExistentMethod", params)).thenReturn(null);

        Function func = packageFunctions.getFunction("util", "nonExistentMethod", params);
        assertNull(func);
    }

    @Test
    void testGetFunction_FullNameNoDot() {
        Function func = packageFunctions.getFunction("util", "newMethod", new Object[] {});
        assertNull(func);
    }

    @Test
    void testGetFunction_ClassNotFound() throws Exception {
        String name = "NonExistentClass.new";
        String namespace = "util";
        Object[] params = {};

        when(ClassLoaderUtil.getClass("java.util.NonExistentClass", true)).thenThrow(ClassNotFoundException.class);

        assertThrows(JXPathException.class, () -> packageFunctions.getFunction(namespace, name, params));
    }

    @Test
    void testGetFunction_ConstructorFound() throws Exception {
        String name = "Date.new";
        String namespace = "util";
        Object[] params = {};

        Constructor<?> constructor = java.util.Date.class.getConstructor();
        when(ClassLoaderUtil.getClass("java.util.Date", true)).thenReturn(java.util.Date.class);
        when(MethodLookupUtils.lookupConstructor(java.util.Date.class, params)).thenReturn(constructor);

        Function func = packageFunctions.getFunction(namespace, name, params);
        assertTrue(func instanceof ConstructorFunction);
        assertEquals(constructor, ((ConstructorFunction) func).getConstructor());
    }

    @Test
    void testGetFunction_StaticMethodFound() throws Exception {
        String name = "Collections.singleton";
        String namespace = "util";
        Object[] params = { "foo" };

        Method method = Collections.class.getMethod("singleton", Object.class);
        when(ClassLoaderUtil.getClass("java.util.Collections", true)).thenReturn(Collections.class);
        when(MethodLookupUtils.lookupStaticMethod(Collections.class, "singleton", params)).thenReturn(method);

        Function func = packageFunctions.getFunction(namespace, name, params);
        assertTrue(func instanceof MethodFunction);
        assertEquals(method, ((MethodFunction) func).getMethod());
    }

    @Test
    void testGetFunction_MethodNotFound() throws Exception {
        String name = "Collections.nonExistentMethod";
        String namespace = "util";
        Object[] params = { "foo" };

        when(ClassLoaderUtil.getClass("java.util.Collections", true)).thenReturn(Collections.class);
        when(MethodLookupUtils.lookupStaticMethod(Collections.class, "nonExistentMethod", params)).thenReturn(null);

        Function func = packageFunctions.getFunction(namespace, name, params);
        assertNull(func);
    }

    @Test
    void testGetFunction_InvalidMethodName() {
        String name = "InvalidMethodName";
        String namespace = "util";
        Object[] params = {};

        Function func = packageFunctions.getFunction(namespace, name, params);
        assertNull(func);
    }

    @Test
    void testGetFunction_MethodNameNew_NoConstructorFound() throws Exception {
        String name = "Date.new";
        String namespace = "util";
        Object[] params = { "invalid" };

        when(ClassLoaderUtil.getClass("java.util.Date", true)).thenReturn(java.util.Date.class);
        when(MethodLookupUtils.lookupConstructor(java.util.Date.class, params)).thenReturn(null);

        Function func = packageFunctions.getFunction(namespace, name, params);
        assertNull(func);
    }

    @Test
    void testGetFunction_StaticMethodWithSubpackage() throws Exception {
        String name = "subpkg.SubClass.staticMethod";
        String namespace = "util";
        Object[] params = { 123 };

        Class<?> subClass = Subpkg.SubClass.class;
        Method method = subClass.getMethod("staticMethod", int.class);
        when(ClassLoaderUtil.getClass("java.util.subpkg.SubClass", true)).thenReturn(subClass);
        when(MethodLookupUtils.lookupStaticMethod(subClass, "staticMethod", params)).thenReturn(method);

        packageFunctions = new PackageFunctions("java.util.", "util");
        Function func = packageFunctions.getFunction(namespace, name, params);
        assertTrue(func instanceof MethodFunction);
        assertEquals(method, ((MethodFunction) func).getMethod());
    }

    // Dummy subpackage class for testing
    public static class Subpkg {
        public static class SubClass {
            public static String staticMethod(int num) {
                return "Number: " + num;
            }
        }
    }
}