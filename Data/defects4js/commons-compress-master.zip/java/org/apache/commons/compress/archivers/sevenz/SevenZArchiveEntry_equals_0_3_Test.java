package org.apache.commons.compress.archivers.sevenz;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.attribute.FileTime;
import java.util.Collections;

public class SevenZArchiveEntry_equals_0_3_Test {

    // Removed invalid constructor parameters from SevenZArchiveEntry
    private SevenZArchiveEntry createSevenZArchiveEntry(String name, boolean hasStream, boolean isDirectory, boolean isAntiItem,
              boolean hasCreationDate, FileTime creationDate, boolean hasAccessDate, FileTime accessDate,
              boolean hasWindowsAttributes, int windowsAttributes,
              boolean hasCrc, long crc, long compressedCrc, long size, long compressedSize, Iterable<?> contentMethods) {
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        entry.setName(name);
        entry.setHasStream(hasStream);
        entry.setDirectory(isDirectory);
        entry.setAntiItem(isAntiItem);
        entry.setHasCreationDate(hasCreationDate);
        if (creationDate != null) {
            entry.setCreationTime(creationDate);
        }
        entry.setHasAccessDate(hasAccessDate);
        if (accessDate != null) {
            entry.setAccessTime(accessDate);
        }
        entry.setHasWindowsAttributes(hasWindowsAttributes);
        entry.setWindowsAttributes(windowsAttributes);
        entry.setHasCrc(hasCrc);
        entry.setCrcValue(crc);
        entry.setCompressedCrcValue(compressedCrc);
        entry.setSize(size);
        entry.setCompressedSize(compressedSize);
        entry.setContentMethods(Collections.emptyList());
        return entry;
    }

    @Test
    @DisplayName("equals called with different hasLastModifiedDate field returns false")
    public void test_TC11() throws Exception {
        String name = "testName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.fromMillis(1000);
        boolean hasLastModifiedDate1 = true;
        FileTime lastModifiedDate1 = FileTime.fromMillis(2000);
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.fromMillis(3000);
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc = 54321L;
        long size = 1024L;
        long compressedSize = 512L;
        Iterable<?> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate, accessDate, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        boolean hasLastModifiedDate2 = false;
        FileTime lastModifiedDate2 = FileTime.fromMillis(2000);
        SevenZArchiveEntry entry2 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate, accessDate, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        // Set specific fields differently
        entry1.setLastModifiedTime(lastModifiedDate1);
        entry2.setLastModifiedTime(lastModifiedDate2);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different lastModifiedDate returns false")
    public void test_TC12() throws Exception {
        String name = "testName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.fromMillis(1000);
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate1 = FileTime.fromMillis(3000);
        FileTime lastModifiedDate2 = FileTime.fromMillis(4000);
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.fromMillis(5000);
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc = 54321L;
        long size = 1024L;
        long compressedSize = 512L;
        Iterable<?> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate, accessDate, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        SevenZArchiveEntry entry2 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate, accessDate, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        // Set specific fields differently
        entry1.setLastModifiedTime(lastModifiedDate1);
        entry2.setLastModifiedTime(lastModifiedDate2);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different hasAccessDate field returns false")
    public void test_TC13() throws Exception {
        String name = "testName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.fromMillis(1000);
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.fromMillis(2000);
        boolean hasAccessDate1 = true;
        FileTime accessDate1 = FileTime.fromMillis(5000);
        boolean hasAccessDate2 = false;
        FileTime accessDate2 = FileTime.fromMillis(6000);
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc = 54321L;
        long size = 1024L;
        long compressedSize = 512L;
        Iterable<?> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate1, accessDate1, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        SevenZArchiveEntry entry2 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate2, accessDate2, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different accessDate returns false")
    public void test_TC14() throws Exception {
        String name = "testName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.fromMillis(1000);
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.fromMillis(2000);
        boolean hasAccessDate1 = true;
        FileTime accessDate1 = FileTime.fromMillis(5000);
        boolean hasAccessDate2 = true;
        FileTime accessDate2 = FileTime.fromMillis(6000);
        boolean hasWindowsAttributes = true;
        int windowsAttributes = 0;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc = 54321L;
        long size = 1024L;
        long compressedSize = 512L;
        Iterable<?> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate1, accessDate1, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        SevenZArchiveEntry entry2 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate2, accessDate2, hasWindowsAttributes, windowsAttributes,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different hasWindowsAttributes field returns false")
    public void test_TC15() throws Exception {
        String name = "testName";
        boolean hasStream = true;
        boolean isDirectory = false;
        boolean isAntiItem = false;
        boolean hasCreationDate = true;
        FileTime creationDate = FileTime.fromMillis(1000);
        boolean hasLastModifiedDate = true;
        FileTime lastModifiedDate = FileTime.fromMillis(2000);
        boolean hasAccessDate = true;
        FileTime accessDate = FileTime.fromMillis(3000);
        boolean hasWindowsAttributes1 = true;
        int windowsAttributes1 = 0;
        boolean hasWindowsAttributes2 = false;
        int windowsAttributes2 = 0;
        boolean hasCrc = true;
        long crc = 12345L;
        long compressedCrc = 54321L;
        long size = 1024L;
        long compressedSize = 512L;
        Iterable<?> contentMethods = Collections.emptyList();

        SevenZArchiveEntry entry1 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate, accessDate, hasWindowsAttributes1, windowsAttributes1,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        SevenZArchiveEntry entry2 = createSevenZArchiveEntry(name, hasStream, isDirectory, isAntiItem,
                hasCreationDate, creationDate, hasAccessDate, accessDate, hasWindowsAttributes2, windowsAttributes2,
                hasCrc, crc, compressedCrc, size, compressedSize, contentMethods);

        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }
}
