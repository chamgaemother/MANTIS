import org.apache.commons.jxpath.JXPathTypeConversionException;
import org.apache.commons.jxpath.util.BasicTypeConverter;
import org.apache.commons.jxpath.util.TypeUtils;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

class BasicTypeConverterTest {

    private final BasicTypeConverter converter = new BasicTypeConverter();

    @Test
    void testConvertNullToObject() {
        assertNull(converter.convert(null, Object.class));
    }

    @Test
    void testConvertNullToPrimitive() {
        assertEquals(false, converter.convert(null, boolean.class));
        assertEquals('\0', converter.convert(null, char.class));
        assertEquals((byte) 0, converter.convert(null, byte.class));
        assertEquals((short) 0, converter.convert(null, short.class));
        assertEquals(0, converter.convert(null, int.class));
        assertEquals(0L, converter.convert(null, long.class));
        assertEquals(0f, converter.convert(null, float.class));
        assertEquals(0.0, converter.convert(null, double.class));
    }

    @Test
    void testConvertSameType() {
        Integer value = 5;
        assertEquals(value, converter.convert(value, Integer.class));
    }

    @Test
    void testConvertArrayToArray() {
        Integer[] intArray = {1, 2, 3};
        Double[] expectedArray = {1.0, 2.0, 3.0};
        assertArrayEquals(expectedArray, (Double[]) converter.convert(intArray, Double[].class));
    }

    @Test
    void testConvertArrayToCollection() {
        Integer[] intArray = {1, 2, 3};
        List<Integer> expectedList = Arrays.asList(1, 2, 3);
        assertEquals(expectedList, converter.convert(intArray, List.class));
    }

    @Test
    void testConvertCollectionToArray() {
        List<Integer> intList = Arrays.asList(1, 2, 3);
        Integer[] expectedArray = {1, 2, 3};
        assertArrayEquals(expectedArray, (Integer[]) converter.convert(intList, Integer[].class));
    }

    @Test
    void testConvertCollectionToCollection() {
        List<Integer> intList = Arrays.asList(1, 2, 3);
        List<Integer> expectedList = Arrays.asList(1, 2, 3);
        assertEquals(expectedList, converter.convert(intList, List.class));
    }

    @Test
    void testConvertStringToPrimitive() {
        assertEquals(true, converter.convert("true", Boolean.class));
        assertEquals('a', converter.convert("a", Character.class));
        assertEquals((byte) 1, converter.convert("1", Byte.class));
        assertEquals((short) 1, converter.convert("1", Short.class));
        assertEquals(1, converter.convert("1", Integer.class));
        assertEquals(1L, converter.convert("1", Long.class));
        assertEquals(1.0f, converter.convert("1.0", Float.class));
        assertEquals(1.0, converter.convert("1.0", Double.class));
    }

    @Test
    void testConvertBooleanToNumber() {
        assertEquals(1, converter.convert(true, Integer.class));
        assertEquals(0, converter.convert(false, Integer.class));
    }

    @Test
    void testConvertNumberToBoolean() {
        assertEquals(true, converter.convert(1, Boolean.class));
        assertEquals(false, converter.convert(0, Boolean.class));
    }

    @Test
    void testConvertInvalidStringToNumber() {
        assertThrows(NumberFormatException.class, () -> {
            converter.convert("invalid", Integer.class);
        });
    }

    @Test
    void testCannotConvert() {
        assertThrows(JXPathTypeConversionException.class, () -> {
            converter.convert(new Object(), TypeUtils.wrapPrimitive(void.class));
        });
    }
}