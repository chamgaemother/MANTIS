package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Array;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrentReferenceHashMap_size_0_2_Test {

    private static Class<?> getSegmentClass() throws ClassNotFoundException {
        return Class.forName("org.apache.commons.collections4.map.ConcurrentReferenceHashMap$Segment");
    }

    private static Object createSegment(Object map) throws Exception {
        Class<?> segmentClass = getSegmentClass();
        Constructor<?> segmentConstructor = segmentClass.getDeclaredConstructor(int.class, float.class, ConcurrentReferenceHashMap.ReferenceType.class,
                ConcurrentReferenceHashMap.ReferenceType.class, boolean.class);
        segmentConstructor.setAccessible(true);
        return segmentConstructor.newInstance(ConcurrentReferenceHashMap.DEFAULT_INITIAL_CAPACITY,
                ConcurrentReferenceHashMap.DEFAULT_LOAD_FACTOR,
                ConcurrentReferenceHashMap.DEFAULT_KEY_TYPE,
                ConcurrentReferenceHashMap.DEFAULT_VALUE_TYPE,
                false);
    }

    private static Field getAccessibleField(String fieldName, Class<?> clazz) throws NoSuchFieldException {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field;
    }

    @Test
    @DisplayName("size() handles zero segments gracefully")
    public void TC06_size_handles_zero_segments_gracefully() throws Exception {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>(1, 1.0f, 1, ConcurrentReferenceHashMap.ReferenceType.WEAK, ConcurrentReferenceHashMap.ReferenceType.STRONG, null);
        Field segmentsField = getAccessibleField("segments", ConcurrentReferenceHashMap.class);
        segmentsField.set(map, new Object[0]);

        int result = map.size();

        Assertions.assertEquals(0, result, "Expected size to be 0 when there are no segments");
    }

    @Test
    @DisplayName("size() correctly counts with a single segment and no modifications")
    public void TC07_size_counts_correctly_single_segment_no_modifications() throws Exception {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>(1, 1.0f, 1, ConcurrentReferenceHashMap.ReferenceType.WEAK, ConcurrentReferenceHashMap.ReferenceType.STRONG, null);
        Object segment = createSegment(map);

        Field countField = getAccessibleField("count", segment.getClass());
        countField.set(segment, 5);
        Field modCountField = getAccessibleField("modCount", segment.getClass());
        modCountField.set(segment, 1);

        Field segmentsField = getAccessibleField("segments", ConcurrentReferenceHashMap.class);
        segmentsField.set(map, Array.newInstance(segment.getClass(), 1));
        Object[] segments = (Object[]) segmentsField.get(map);
        segments[0] = segment;
        segmentsField.set(map, segments);

        int result = map.size();

        Assertions.assertEquals(5, result, "Expected size to match the number of elements in the single segment");
    }

    @Test
    @DisplayName("size() retries multiple times due to multiple segment modifications before succeeding")
    public void TC08_size_retries_multiple_modifications_before_success() throws Exception {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>(1, 1.0f, 1, ConcurrentReferenceHashMap.ReferenceType.WEAK, ConcurrentReferenceHashMap.ReferenceType.STRONG, null);
        Object segment1 = createSegment(map);
        Object segment2 = createSegment(map);
        Object segment3 = createSegment(map);

        Field countField = getAccessibleField("count", segment1.getClass());
        countField.set(segment1, 3);
        countField.set(segment2, 2);
        countField.set(segment3, 4);

        Field modCountField = getAccessibleField("modCount", segment1.getClass());
        modCountField.set(segment1, 2);
        modCountField.set(segment2, 3);
        modCountField.set(segment3, 4);

        Field segmentsField = getAccessibleField("segments", ConcurrentReferenceHashMap.class);
        segmentsField.set(map, new Object[]{segment1, segment2, segment3});

        int result = map.size();

        int expectedTotal = 3 + 2 + 4;

        Assertions.assertEquals(expectedTotal, result, "Expected size to match the total number of elements after retries");
    }

    @Test
    @DisplayName("size() locks all segments after maximum retries and accurately counts elements")
    public void TC09_size_locks_all_segments_after_max_retries() throws Exception {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>(1, 1.0f, 1, ConcurrentReferenceHashMap.ReferenceType.WEAK, ConcurrentReferenceHashMap.ReferenceType.STRONG, null);
        Object segment1 = createSegment(map);
        Object segment2 = createSegment(map);

        Field countField = getAccessibleField("count", segment1.getClass());
        countField.set(segment1, 10);
        countField.set(segment2, 15);

        Field modCountField = getAccessibleField("modCount", segment1.getClass());
        modCountField.set(segment1, Integer.MAX_VALUE);
        modCountField.set(segment2, Integer.MAX_VALUE);

        Field segmentsField = getAccessibleField("segments", ConcurrentReferenceHashMap.class);
        segmentsField.set(map, new Object[]{segment1, segment2});

        int result = map.size();

        int expectedTotal = 10 + 15;

        Assertions.assertEquals(expectedTotal, result, "Expected size to match the total number of elements after locking all segments");
    }

    @Test
    @DisplayName("size() returns accurate count after partial segment modifications and successful retry")
    public void TC10_size_returns_accurate_count_after_partial_modifications() throws Exception {
        ConcurrentReferenceHashMap<String, String> map = new ConcurrentReferenceHashMap<>(1, 1.0f, 1, ConcurrentReferenceHashMap.ReferenceType.WEAK, ConcurrentReferenceHashMap.ReferenceType.STRONG, null);
        Object segment1 = createSegment(map);
        Object segment2 = createSegment(map);
        Object segment3 = createSegment(map);

        Field countField = getAccessibleField("count", segment1.getClass());
        countField.set(segment1, 7);
        countField.set(segment2, 8);
        countField.set(segment3, 9);

        Field modCountField = getAccessibleField("modCount", segment1.getClass());
        modCountField.set(segment1, 1);
        modCountField.set(segment2, 2);
        modCountField.set(segment3, 1);

        Field segmentsField = getAccessibleField("segments", ConcurrentReferenceHashMap.class);
        segmentsField.set(map, new Object[]{segment1, segment2, segment3});

        modCountField.set(segment2, 1);

        int result = map.size();

        int expectedTotal = 7 + 8 + 9;

        Assertions.assertEquals(expectedTotal, result, "Expected size to match the total number of elements after successful retry");
    }
}
