package org.apache.commons.codec.digest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import java.nio.charset.StandardCharsets;

public class Md5Crypt_md5Crypt_2_2_Test {

    @Test
    @DisplayName("md5Crypt with salt containing only prefix and no salt group throws IllegalArgumentException")
    void TC27() {
        byte[] keyBytes = "password".getBytes(StandardCharsets.UTF_8);
        String salt = "$1$$";
        String prefix = "$1$";
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Md5Crypt.md5Crypt(keyBytes, salt, prefix);
        });
    }

}