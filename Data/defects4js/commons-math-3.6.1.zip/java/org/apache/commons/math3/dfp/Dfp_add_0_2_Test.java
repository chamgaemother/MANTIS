package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

/**
 * JUnit 5 test class for org.apache.commons.math3.dfp.Dfp#add(Dfp)
 */
public class Dfp_add_0_2_Test {

    /**
     * Utility method to create a new Dfp instance using reflection.
     */
    private Dfp createDfpInstance(DfpField field, int value) throws Exception {
        return new Dfp(field, (long) value); // Casting int to long
    }

    /**
     * Utility method to get the DfpField instance using reflection.
     */
    private DfpField getDfpField() throws Exception {
        return new DfpField(4); // Adjust radix digits to match necessary precision
    }

    @Test
    @DisplayName("Adding two finite Dfp numbers with different signs resulting in zero")
    public void TC06_addFiniteOppositeSignsResultingInZero() throws Exception {
        // GIVEN
        DfpField field = getDfpField();
        Dfp a = createDfpInstance(field, 100);
        Dfp b = createDfpInstance(field, -100);

        // WHEN
        Dfp result = a.add(b);

        // THEN
        assertTrue(result.isZero(), "Result should be zero");
        assertEquals(1, result.sign, "Sign of zero should be positive");
    }

    @Test
    @DisplayName("Adding Dfp numbers where one mantissa is zero to test exponent alignment")
    public void TC07_addMantissaZeroExponentAlignment() throws Exception {
        // GIVEN
        DfpField field = getDfpField();
        Dfp a = createDfpInstance(field, 100);
        Dfp b = createDfpInstance(field, 0);

        // WHEN
        Dfp result = a.add(b);

        // THEN
        assertEquals(a, result, "Result should be equal to the non-zero operand");
    }

    @Test
    @DisplayName("Adding Dfp numbers resulting in mantissa carry-over and exponent increment")
    public void TC08_addMantissaCarryOverExponentIncrement() throws Exception {
        // GIVEN
        DfpField field = getDfpField();
        Dfp a = createDfpInstance(field, 9999);
        Dfp b = createDfpInstance(field, 1); // Sum causes carry

        // WHEN
        Dfp result = a.add(b);

        // THEN
        assertEquals(a.exp + 1, result.exp, "Exponent should be incremented by one after carry-over");
        assertNotEquals(a.mant[0], result.mant[0], "Mantissa carry-over should change the first digit");
    }

    @Test
    @DisplayName("Adding Dfp numbers with maximum exponent to trigger overflow and dotrap")
    public void TC09_addOverflowTriggersDotrap() throws Exception {
        // GIVEN
        DfpField field = getDfpField();
        Dfp a = field.newDfp(Double.POSITIVE_INFINITY);
        Dfp b = field.newDfp(Double.POSITIVE_INFINITY);

        // WHEN
        Dfp result = a.add(b);

        // THEN
        Field flagsField = DfpField.class.getDeclaredField("flags");
        flagsField.setAccessible(true);
        int flags = (int) flagsField.get(field);
        assertTrue((flags & DfpField.FLAG_OVERFLOW) != 0, "FLAG_OVERFLOW should be set");
        assertTrue(result.isInfinite(), "Result should be infinite due to overflow");
        assertEquals(a.sign, result.sign, "Sign of the result should match the operands");
    }

    @Test
    @DisplayName("Adding Dfp numbers with different exponents to test alignment and normalization")
    public void TC10_addDifferentExponentsAlignmentNormalization() throws Exception {
        // GIVEN
        DfpField field = getDfpField();
        Dfp a = createDfpInstance(field, 1); // Low exponent value
        Dfp b = createDfpInstance(field, 10000); // High exponent value

        // WHEN
        Dfp result = a.add(b);

        // THEN
        assertEquals(b.exp, result.exp, "Exponent should match the higher exponent operand");
        assertEquals(b, result, "Result should be equal to the operand with the higher exponent");
    }
}
