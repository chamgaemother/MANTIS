package com.google.gson.internal.bind.util;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

public class ISO8601UtilsTest {

    @Test
    public void testParseNullDate() {
        ParsePosition pos = new ParsePosition(0);
        assertThrows(NullPointerException.class, () -> {
            ISO8601Utils.parse(null, pos);
        });
    }
    
    @Test
    public void testParseEmptyString() {
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse("", pos);
        });
    }
    
    @Test
    public void testParseValidDateWithoutTime() throws ParseException {
        String dateStr = "2023-10-05";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseValidDateWithoutTimeNoDashes() throws ParseException {
        String dateStr = "20231005";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseValidDateWithTimeZ() throws ParseException {
        String dateStr = "2023-10-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseValidDateWithTimeAndMillisecondsZ() throws ParseException {
        String dateStr = "2023-10-05T14:30:00.123Z";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseValidDateWithTimeAndMillisecondsOffset() throws ParseException {
        String dateStr = "2023-10-05T14:30:00.123+02:00";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseValidDateWithTimeAndNoMilliseconds() throws ParseException {
        String dateStr = "2023-10-05T14:30:00+0200";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseValidDateWithOnlyDateAndTimeNoTimezone() {
        String dateStr = "2023-10-05T14:30:00";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(IllegalArgumentException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseValidLeapSecond() throws ParseException {
        String dateStr = "2016-12-31T23:59:60Z";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseInvalidMonth() {
        String dateStr = "2023-13-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidDay() {
        String dateStr = "2023-10-32T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidHour() {
        String dateStr = "2023-10-05T24:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidMinute() {
        String dateStr = "2023-10-05T14:60:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidSecond() {
        String dateStr = "2023-10-05T14:30:61Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidMilliseconds() {
        String dateStr = "2023-10-05T14:30:00.12Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseMissingTimezone() {
        String dateStr = "2023-10-05T14:30:00";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidTimezoneIndicator() {
        String dateStr = "2023-10-05T14:30:00X";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseTimezoneWithoutMinutes() throws ParseException {
        String dateStr = "2023-10-05T14:30:00+02";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseTimezoneWithSingleDigitHour() {
        String dateStr = "2023-10-05T14:30:00+2:00";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseExtraCharactersAfterValidDate() {
        String dateStr = "2023-10-05T14:30:00Zextra";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals("2023-10-05T14:30:00Z".length(), pos.getIndex());
    }
    
    @Test
    public void testParsePartialDate() {
        String dateStr = "2023-10";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidCharacterInDate() {
        String dateStr = "2023-10-0XT14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseNullParsePosition() {
        assertThrows(NullPointerException.class, () -> {
            ISO8601Utils.parse("2023-10-05", null);
        });
    }
    
    @Test
    public void testParseInvalidYear() {
        String dateStr = "20a3-10-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
    
    @Test
    public void testParseInvalidMonthFormat() {
        String dateStr = "2023-1A-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }

    @Test
    public void testParseTimezoneWithColonMissing() throws ParseException {
        String dateStr = "2023-10-05T14:30:00+0200";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseTimezoneWithColon() throws ParseException {
        String dateStr = "2023-10-05T14:30:00+02:00";
        ParsePosition pos = new ParsePosition(0);
        Date date = ISO8601Utils.parse(dateStr, pos);
        assertNotNull(date);
        assertEquals(dateStr.length(), pos.getIndex());
    }
    
    @Test
    public void testParseUTCWithLowerCaseZ() {
        String dateStr = "2023-10-05T14:30:00z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(dateStr, pos);
        });
    }
}