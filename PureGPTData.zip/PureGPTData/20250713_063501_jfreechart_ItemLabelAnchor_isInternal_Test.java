import org.jfree.chart.labels.ItemLabelAnchor;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ItemLabelAnchorTest {

    @Test
    public void testIsInternalWithCenter() {
        assertTrue(ItemLabelAnchor.CENTER.isInternal());
    }
    
    @Test
    public void testIsInternalWithInsideAnchors() {
        assertTrue(ItemLabelAnchor.INSIDE1.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE2.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE3.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE4.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE5.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE6.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE7.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE8.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE9.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE10.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE11.isInternal());
        assertTrue(ItemLabelAnchor.INSIDE12.isInternal());
    }

    @Test
    public void testIsInternalWithOutsideAnchors() {
        assertFalse(ItemLabelAnchor.OUTSIDE1.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE2.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE3.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE4.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE5.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE6.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE7.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE8.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE9.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE10.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE11.isInternal());
        assertFalse(ItemLabelAnchor.OUTSIDE12.isInternal());
    }
}