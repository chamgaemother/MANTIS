// package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// // import java.lang.reflect.*;
// // import static org.mockito.Mockito.*;
// // import java.io.*;
// // import java.util.*;
// // import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// // 
// // import org.apache.commons.math3.RealFieldElement;
// // import org.apache.commons.math3.exception.CardanEulerSingularityException;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // import static org.junit.jupiter.api.Assertions.*;
// // 
// public class FieldRotation_getAngles_2_1_Test {
// // 
//     // Mock class for RealFieldElement, implementing necessary methods
// //     static class RealFieldElementMock implements RealFieldElement<RealFieldElementMock> {
// //         private final double value;
// // 
// //         public RealFieldElementMock(double value) {
// //             this.value = value;
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock add(RealFieldElementMock other) {
// //             return new RealFieldElementMock(this.value + other.value);
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock subtract(RealFieldElementMock other) {
// //             return new RealFieldElementMock(this.value - other.value);
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock negate() {
// //             return new RealFieldElementMock(-this.value);
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock multiply(RealFieldElementMock other) {
// //             return new RealFieldElementMock(this.value * other.value);
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock multiply(double a) {
// //             return new RealFieldElementMock(this.value * a);
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock divide(RealFieldElementMock other) {
// //             return new RealFieldElementMock(this.value / other.value);
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock reciprocal() {
// //             return new RealFieldElementMock(1.0 / this.value);
// //         }
// // 
// //         @Override
// //         public double getReal() {
// //             return this.value;
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock sqrt() {
// //             return new RealFieldElementMock(Math.sqrt(this.value));
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock asin() {
// //             return new RealFieldElementMock(Math.asin(this.value));
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock acos() {
// //             return new RealFieldElementMock(Math.acos(this.value));
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock sin() {
// //             return new RealFieldElementMock(Math.sin(this.value));
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock cos() {
// //             return new RealFieldElementMock(Math.cos(this.value));
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock add(double a) {
// //             return new RealFieldElementMock(this.value + a);
// //         }
// // 
// //         @Override
// //         public RealFieldElementMock pow(int n) {
// //             return new RealFieldElementMock(Math.pow(this.value, n));
// //         }
// // 
//         // Remaining methods are omitted for brevity, but they would typically
//         // need appropriate mock implementations
// //     }
// // 
// //     
// //     @Test
// //     @DisplayName("TC06: getAngles with YZX and VECTOR_OPERATOR, v2.getY() within bounds")
// //     void TC06_getAngles_YZX_VECTOR_OPERATOR_withinBounds() {
// //         RotationOrder order = RotationOrder.YZX;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
// //         
//         // Correct quaternion values
// //         RealFieldElementMock q0 = new RealFieldElementMock(1.0);
// //         RealFieldElementMock q1 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q2 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q3 = new RealFieldElementMock(0.0);
// //         
// //         FieldRotation<RealFieldElementMock> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
// //         assertDoesNotThrow(() -> {
// //             RealFieldElementMock[] angles = rotation.getAngles(order, convention);
// //             assertNotNull(angles);
// //             assertEquals(3, angles.length);
// //         });
// //     }
// // 
// //     @Test
// //     @DisplayName("TC07: getAngles with YZY and VECTOR_OPERATOR, v2.getY() within bounds")
// //     void TC07_getAngles_YZY_VECTOR_OPERATOR_withinBounds() {
// //         RotationOrder order = RotationOrder.YZY;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
// //         
// //         RealFieldElementMock q0 = new RealFieldElementMock(1.0);
// //         RealFieldElementMock q1 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q2 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q3 = new RealFieldElementMock(0.0);
// //         
// //         FieldRotation<RealFieldElementMock> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
// //         assertDoesNotThrow(() -> {
// //             RealFieldElementMock[] angles = rotation.getAngles(order, convention);
// //             assertNotNull(angles);
// //             assertEquals(3, angles.length);
// //         });
// //     }
// // 
// //     @Test
// //     @DisplayName("TC08: getAngles with ZXY and VECTOR_OPERATOR, v2.getY() within bounds")
// //     void TC08_getAngles_ZXY_VECTOR_OPERATOR_withinBounds() {
// //         RotationOrder order = RotationOrder.ZXY;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
// //         
// //         RealFieldElementMock q0 = new RealFieldElementMock(1.0);
// //         RealFieldElementMock q1 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q2 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q3 = new RealFieldElementMock(0.0);
// //         
// //         FieldRotation<RealFieldElementMock> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// //         
// //         assertDoesNotThrow(() -> {
// //             RealFieldElementMock[] angles = rotation.getAngles(order, convention);
// //             assertNotNull(angles);
// //             assertEquals(3, angles.length);
// //         });
// //     }
// // 
// //     @Test
// //     @DisplayName("TC09: getAngles with YZX and VECTOR_OPERATOR, exception for out of bounds")
// //     void TC09_getAngles_YZX_VECTOR_OPERATOR_outOfBounds_exception() {
// //         RotationOrder order = RotationOrder.YZX;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
// // 
// //         RealFieldElementMock q0 = new RealFieldElementMock(0.5); // adjust value to avoid -1 or 1 bounds
// //         RealFieldElementMock q1 = new RealFieldElementMock(1.0);
// //         RealFieldElementMock q2 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q3 = new RealFieldElementMock(0.0);
// // 
// //         FieldRotation<RealFieldElementMock> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// // 
// //         assertThrows(CardanEulerSingularityException.class, () -> rotation.getAngles(order, convention));
// //     }
// // 
// //     @Test
// //     @DisplayName("TC10: getAngles with YZY and VECTOR_OPERATOR, exception for out of bounds")
// //     void TC10_getAngles_YZY_VECTOR_OPERATOR_outOfBounds_exception() {
// //         RotationOrder order = RotationOrder.YZY;
// //         RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
// // 
// //         RealFieldElementMock q0 = new RealFieldElementMock(0.5); // adjust value to avoid -1 or 1 bounds
// //         RealFieldElementMock q1 = new RealFieldElementMock(1.0);
// //         RealFieldElementMock q2 = new RealFieldElementMock(0.0);
// //         RealFieldElementMock q3 = new RealFieldElementMock(0.0);
// // 
// //         FieldRotation<RealFieldElementMock> rotation = new FieldRotation<>(q0, q1, q2, q3, false);
// // 
// //         assertThrows(CardanEulerSingularityException.class, () -> rotation.getAngles(order, convention));
// //     }
// // 
// // }
// }