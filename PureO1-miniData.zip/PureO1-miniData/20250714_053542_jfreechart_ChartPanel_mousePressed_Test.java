import static org.mockito.Mockito.*;

import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JPopupMenu;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Pannable;
import org.jfree.chart.plot.Plot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class ChartPanelTest {

    private ChartPanel chartPanel;
    private JFreeChart mockChart;
    private Plot mockPlot;
    private MouseEvent mockMouseEvent;
    private JPopupMenu mockPopup;

    @BeforeEach
    void setUp() {
        mockChart = mock(JFreeChart.class);
        mockPlot = mock(Plot.class);
        when(mockChart.getPlot()).thenReturn(mockPlot);
        chartPanel = new ChartPanel(mockChart);
        mockMouseEvent = mock(MouseEvent.class);
        mockPopup = mock(JPopupMenu.class);
        chartPanel.setPopupMenu(mockPopup);
    }

    @Test
    void testMousePressed_chartNull() {
        ChartPanel panelWithNullChart = new ChartPanel(null);
        panelWithNullChart.mousePressed(mockMouseEvent);
        verifyNoInteractions(mockMouseEvent);
    }

    @Test
    void testMousePressed_panMaskSet_pannableTrue_domainPannable_screenDataAreaContains() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot.isNotify()).thenReturn(true);
        when(mockPannable.isDomainPannable()).thenReturn(true);
        when(mockPannable.isRangePannable()).thenReturn(false);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot).thenReturn(mockPannable);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 100, 100);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.getX()).thenReturn(50);
        when(mockMouseEvent.getY()).thenReturn(50);
        Point2D point = new Point2D.Double(50, 50);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(50, 50));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel).setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
        assert(spyPanel.panLast.equals(mockMouseEvent.getPoint()));
        assert(spyPanel.panW == mockArea.getWidth());
        assert(spyPanel.panH == mockArea.getHeight());
    }

    @Test
    void testMousePressed_panMaskSet_pannableTrue_domainPannable_screenDataAreaDoesNotContain() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPannable.isDomainPannable()).thenReturn(true);
        when(mockPannable.isRangePannable()).thenReturn(false);
        when(mockPlot).thenReturn(mockPannable);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 100, 100);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.getX()).thenReturn(150);
        when(mockMouseEvent.getY()).thenReturn(150);
        Point2D point = new Point2D.Double(150, 150);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(150, 150));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel, never()).setCursor(any());
        assert(spyPanel.panLast == null);
    }

    @Test
    void testMousePressed_panMaskSet_pannableFalse() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        when(mockPlot instanceof Pannable).thenReturn(true);
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot).thenReturn(mockPannable);
        when(mockPannable.isDomainPannable()).thenReturn(false);
        when(mockPannable.isRangePannable()).thenReturn(false);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 100, 100);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.getX()).thenReturn(50);
        when(mockMouseEvent.getY()).thenReturn(50);
        when(mockPannable.isDomainPannable()).thenReturn(false);
        when(mockPannable.isRangePannable()).thenReturn(false);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(50, 50));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel, never()).setCursor(any());
        assert(spyPanel.panLast == null);
    }

    @Test
    void testMousePressed_panMaskNotSet_zoomRectangleNull_screenDataAreaNotNull_popupTriggerTrue_popupNotNull() {
        when(mockMouseEvent.getModifiers()).thenReturn(0);
        when(mockMouseEvent.getX()).thenReturn(50);
        when(mockMouseEvent.getY()).thenReturn(50);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 100, 100);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.isPopupTrigger()).thenReturn(true);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(50, 50));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel).displayPopupMenu(50, 50);
        assert(spyPanel.zoomPoint.equals(spyPanel.getPointInRectangle(50, 50, mockArea)));
    }

    @Test
    void testMousePressed_panMaskNotSet_zoomRectangleNull_screenDataAreaNotNull_popupTriggerTrue_popupNull() {
        chartPanel.setPopupMenu(null);
        when(mockMouseEvent.getModifiers()).thenReturn(0);
        when(mockMouseEvent.getX()).thenReturn(50);
        when(mockMouseEvent.getY()).thenReturn(50);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 100, 100);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.isPopupTrigger()).thenReturn(true);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(50, 50));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel, never()).displayPopupMenu(anyInt(), anyInt());
        assert(spyPanel.zoomPoint.equals(spyPanel.getPointInRectangle(50, 50, mockArea)));
    }

    @Test
    void testMousePressed_panMaskNotSet_zoomRectangleNull_screenDataAreaNull() {
        when(mockMouseEvent.getModifiers()).thenReturn(0);
        when(mockMouseEvent.getX()).thenReturn(150);
        when(mockMouseEvent.getY()).thenReturn(150);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(null).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.isPopupTrigger()).thenReturn(false);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(150, 150));

        spyPanel.mousePressed(mockMouseEvent);

        assert(spyPanel.zoomPoint == null);
    }

    @Test
    void testMousePressed_panMaskNotSet_zoomRectangleNotNull() {
        chartPanel.zoomRectangle = new Rectangle2D.Double(10, 10, 20, 20);
        when(mockMouseEvent.getModifiers()).thenReturn(0);

        chartPanel.mousePressed(mockMouseEvent);

        verifyNoInteractions(mockPopup);
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle != null);
    }

    @Test
    void testMousePressed_nullMouseEvent() {
        assertThrows(NullPointerException.class, () -> {
            chartPanel.mousePressed(null);
        });
    }

    @Test
    void testMousePressed_popupTriggerFalse() {
        when(mockMouseEvent.getModifiers()).thenReturn(0);
        when(mockMouseEvent.getX()).thenReturn(50);
        when(mockMouseEvent.getY()).thenReturn(50);
        when(mockMouseEvent.isPopupTrigger()).thenReturn(false);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 100, 100);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(50, 50));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel, never()).displayPopupMenu(anyInt(), anyInt());
        assert(spyPanel.zoomPoint.equals(spyPanel.getPointInRectangle(50, 50, mockArea)));
    }

    @Test
    void testMousePressed_panMaskSet_plotNotPannable() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        when(mockPlot instanceof Pannable).thenReturn(true);
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot).thenReturn(mockPannable);
        when(mockPannable.isDomainPannable()).thenReturn(false);
        when(mockPannable.isRangePannable()).thenReturn(false);
        when(mockMouseEvent.getX()).thenReturn(50);
        when(mockMouseEvent.getY()).thenReturn(50);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(50, 50));

        chartPanel.mousePressed(mockMouseEvent);

        verify(chartPanel, never()).setCursor(any());
        assert(chartPanel.panLast == null);
    }

    @Test
    void testMousePressed_panMaskSet_plotNotPannable_plotInstanceNotPannable() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        when(mockPlot instanceof Pannable).thenReturn(false);
        when(mockMouseEvent.getX()).thenReturn(50);
        when(mockMouseEvent.getY()).thenReturn(50);

        chartPanel.mousePressed(mockMouseEvent);

        verify(chartPanel, never()).setCursor(any());
        assert(chartPanel.panLast == null);
    }

    @Test
    void testMousePressed_panMaskSet_pannableTrue_rangePannable_screenDataAreaContains() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot).thenReturn(mockPannable);
        when(mockPannable.isDomainPannable()).thenReturn(false);
        when(mockPannable.isRangePannable()).thenReturn(true);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 200, 200);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.getX()).thenReturn(100);
        when(mockMouseEvent.getY()).thenReturn(100);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(100, 100));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel).setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
        assert(spyPanel.panLast.equals(mockMouseEvent.getPoint()));
        assert(spyPanel.panW == mockArea.getWidth());
        assert(spyPanel.panH == mockArea.getHeight());
    }

    @Test
    void testMousePressed_panMaskSet_pannableTrue_rangePannable_screenDataAreaDoesNotContain() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot).thenReturn(mockPannable);
        when(mockPannable.isDomainPannable()).thenReturn(false);
        when(mockPannable.isRangePannable()).thenReturn(true);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 100, 100);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.getX()).thenReturn(150);
        when(mockMouseEvent.getY()).thenReturn(150);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(150, 150));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel, never()).setCursor(any());
        assert(spyPanel.panLast == null);
    }

    @Test
    void testMousePressed_panMaskSet_pannableTrue_bothPannable_screenDataAreaContains() {
        when(mockMouseEvent.getModifiers()).thenReturn(chartPanel.panMask);
        Pannable mockPannable = mock(Pannable.class);
        when(mockPlot instanceof Pannable).thenReturn(true);
        when(mockPlot).thenReturn(mockPannable);
        when(mockPannable.isDomainPannable()).thenReturn(true);
        when(mockPannable.isRangePannable()).thenReturn(true);
        Rectangle2D mockArea = new Rectangle2D.Double(0, 0, 300, 300);
        ChartPanel spyPanel = spy(chartPanel);
        doReturn(mockArea).when(spyPanel).getScreenDataArea(anyInt(), anyInt());
        when(mockMouseEvent.getX()).thenReturn(150);
        when(mockMouseEvent.getY()).thenReturn(150);
        when(mockMouseEvent.getPoint()).thenReturn(new java.awt.Point(150, 150));

        spyPanel.mousePressed(mockMouseEvent);

        verify(spyPanel).setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
        assert(spyPanel.panLast.equals(mockMouseEvent.getPoint()));
        assert(spyPanel.panW == mockArea.getWidth());
        assert(spyPanel.panH == mockArea.getHeight());
    }

}