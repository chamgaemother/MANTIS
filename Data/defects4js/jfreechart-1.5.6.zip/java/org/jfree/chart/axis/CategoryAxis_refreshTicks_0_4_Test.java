package org.jfree.chart.axis;

import org.jfree.chart.axis.CategoryLabelWidthType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.text.TextBlock;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.CategoryLabelPosition;
import org.jfree.chart.ui.Size2D;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

public class CategoryAxis_refreshTicks_0_4_Test {

    @Test
    @DisplayName("Handles multiple categories with varying label sizes")
    public void TC16_HandleMultipleCategoriesVaryingLabelSizes() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 600.0, 300.0);
        RectangleEdge edge = RectangleEdge.BOTTOM;

        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = spy(new CategoryAxis());

        List<Comparable> categories = Arrays.asList("Short", "MediumLength", "AQuiteLongCategoryName");
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);

        doReturn(plot).when(categoryAxis).getPlot();

        CategoryLabelPositions categoryLabelPositions = mock(CategoryLabelPositions.class);
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, categoryLabelPositions);

        CategoryLabelPosition position = mock(CategoryLabelPosition.class);
        when(position.getWidthType()).thenReturn(CategoryLabelWidthType.CATEGORY);
        when(categoryLabelPositions.getLabelPosition(edge)).thenReturn(position);

        Field maxWidthRatioField = CategoryAxis.class.getDeclaredField("maximumCategoryLabelWidthRatio");
        maxWidthRatioField.setAccessible(true);
        maxWidthRatioField.setFloat(categoryAxis, 0.3f);

        TextBlock labelShort = mock(TextBlock.class);
        TextBlock labelMedium = mock(TextBlock.class);
        TextBlock labelLong = mock(TextBlock.class);

        when(categoryAxis.createLabel(eq("Short"), anyFloat(), eq(edge), eq(g2))).thenReturn(labelShort);
        when(categoryAxis.createLabel(eq("MediumLength"), anyFloat(), eq(edge), eq(g2))).thenReturn(labelMedium);
        when(categoryAxis.createLabel(eq("AQuiteLongCategoryName"), anyFloat(), eq(edge), eq(g2))).thenReturn(labelLong);

        when(labelShort.calculateDimensions(g2)).thenReturn(new Size2D(30, 10));
        when(labelMedium.calculateDimensions(g2)).thenReturn(new Size2D(50, 15));
        when(labelLong.calculateDimensions(g2)).thenReturn(new Size2D(100, 20));

        // WHEN
        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        // THEN
        Assertions.assertEquals(3, result.size());
        Assertions.assertEquals(20.0, state.getMax());
    }

    @Test
    @DisplayName("Handles single category with maximumCategoryLabelWidthRatio > 0")
    public void TC17_HandleSingleCategoryWithPositiveWidthRatio() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 150.0, 75.0);
        RectangleEdge edge = RectangleEdge.BOTTOM;

        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = spy(new CategoryAxis());

        List<Comparable> categories = Arrays.asList("OnlyCategory");
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);

        doReturn(plot).when(categoryAxis).getPlot();

        CategoryLabelPositions categoryLabelPositions = mock(CategoryLabelPositions.class);
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, categoryLabelPositions);

        CategoryLabelPosition position = mock(CategoryLabelPosition.class);
        when(position.getWidthType()).thenReturn(CategoryLabelWidthType.CATEGORY);
        when(position.getWidthRatio()).thenReturn(0.6f);
        when(categoryLabelPositions.getLabelPosition(edge)).thenReturn(position);

        Field maxWidthRatioField = CategoryAxis.class.getDeclaredField("maximumCategoryLabelWidthRatio");
        maxWidthRatioField.setAccessible(true);
        maxWidthRatioField.setFloat(categoryAxis, 0.5f);

        TextBlock label = mock(TextBlock.class);
        when(categoryAxis.createLabel(eq("OnlyCategory"), anyFloat(), eq(edge), eq(g2))).thenReturn(label);
        when(label.calculateDimensions(g2)).thenReturn(new Size2D(80, 25));

        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        Assertions.assertEquals(1, result.size());
        Assertions.assertEquals(25.0, state.getMax());
    }

    @Test
    @DisplayName("Handles exception when getTickLabelFont throws IllegalArgumentException")
    public void TC18_HandleGetTickLabelFontException() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 200.0, 100.0);
        RectangleEdge edge = RectangleEdge.BOTTOM;

        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = spy(new CategoryAxis());

        List<Comparable> categories = Arrays.asList("Cat1", "Cat2");
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);

        doReturn(plot).when(categoryAxis).getPlot();

        CategoryLabelPositions categoryLabelPositions = mock(CategoryLabelPositions.class);
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, categoryLabelPositions);

        CategoryLabelPosition position = mock(CategoryLabelPosition.class);
        when(position.getWidthType()).thenReturn(CategoryLabelWidthType.CATEGORY);
        when(categoryLabelPositions.getLabelPosition(edge)).thenReturn(position);

        Field maxWidthRatioField = CategoryAxis.class.getDeclaredField("maximumCategoryLabelWidthRatio");
        maxWidthRatioField.setAccessible(true);
        maxWidthRatioField.setFloat(categoryAxis, 0.4f);

        when(categoryAxis.getTickLabelFont("Cat1")).thenReturn(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));
        when(categoryAxis.getTickLabelFont("Cat2")).thenThrow(new IllegalArgumentException("Invalid category"));

        TextBlock label1 = mock(TextBlock.class);
        when(categoryAxis.createLabel(eq("Cat1"), anyFloat(), eq(edge), eq(g2))).thenReturn(label1);
        when(label1.calculateDimensions(g2)).thenReturn(new Size2D(50, 20));

        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        Assertions.assertEquals(1, result.size());
        Assertions.assertEquals(20.0, state.getMax());
    }

    @Test
    @DisplayName("Handles multiple iterations with mixed edge conditions")
    public void TC19_HandleMultipleIterationsMixedEdgeConditions() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        AxisState state = new AxisState();
        Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 450.0, 225.0);
        RectangleEdge edge = RectangleEdge.BOTTOM;

        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis categoryAxis = spy(new CategoryAxis());

        List<Comparable> categories = Arrays.asList("Cat1", "Cat2", "Cat3");
        when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);

        doReturn(plot).when(categoryAxis).getPlot();

        CategoryLabelPositions categoryLabelPositions = mock(CategoryLabelPositions.class);
        Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
        labelPositionsField.setAccessible(true);
        labelPositionsField.set(categoryAxis, categoryLabelPositions);

        CategoryLabelPosition position = mock(CategoryLabelPosition.class);
        when(position.getWidthType()).thenReturn(CategoryLabelWidthType.CATEGORY);
        when(position.getAngle()).thenReturn(45.0);
        when(categoryLabelPositions.getLabelPosition(edge)).thenReturn(position);

        Field maxWidthRatioField = CategoryAxis.class.getDeclaredField("maximumCategoryLabelWidthRatio");
        maxWidthRatioField.setAccessible(true);
        maxWidthRatioField.setFloat(categoryAxis, 0.35f);

        TextBlock label1 = mock(TextBlock.class);
        TextBlock label2 = mock(TextBlock.class);
        TextBlock label3 = mock(TextBlock.class);

        when(categoryAxis.createLabel(eq("Cat1"), anyFloat(), eq(edge), eq(g2))).thenReturn(label1);
        when(categoryAxis.createLabel(eq("Cat2"), anyFloat(), eq(edge), eq(g2))).thenReturn(label2);
        when(categoryAxis.createLabel(eq("Cat3"), anyFloat(), eq(edge), eq(g2))).thenReturn(label3);

        when(label1.calculateDimensions(g2)).thenReturn(new Size2D(40, 15));
        when(label2.calculateDimensions(g2)).thenReturn(new Size2D(60, 25));
        when(label3.calculateDimensions(g2)).thenReturn(new Size2D(80, 30));

        List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);

        Assertions.assertEquals(3, result.size());
        Assertions.assertEquals(30.0, state.getMax());
    }

//     @Test
//     @DisplayName("Handles RectangleEdge being LEFT and verifies width calculation")
//     public void TC20_HandleRectangleEdgeLeftAndVerifyWidthCalculation() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         AxisState state = new AxisState();
//         Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 250.0, 150.0);
//         RectangleEdge edge = RectangleEdge.LEFT;
// 
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis categoryAxis = spy(new CategoryAxis());
// 
//         List<Comparable> categories = Arrays.asList("Cat1", "Cat2");
//         when(plot.getCategoriesForAxis(categoryAxis)).thenReturn(categories);
// 
//         doReturn(plot).when(categoryAxis).getPlot();
// 
//         CategoryLabelPositions categoryLabelPositions = mock(CategoryLabelPositions.class);
//         Field labelPositionsField = CategoryAxis.class.getDeclaredField("categoryLabelPositions");
//         labelPositionsField.setAccessible(true);
//         labelPositionsField.set(categoryAxis, categoryLabelPositions);
// 
//         CategoryLabelPosition position = mock(CategoryLabelPosition.class);
//         when(position.getWidthType()).thenReturn(CategoryLabelWidthType.PROPORTIONAL);
//         when(categoryLabelPositions.getLabelPosition(edge)).thenReturn(position);
// 
//         Field maxWidthRatioField = CategoryAxis.class.getDeclaredField("maximumCategoryLabelWidthRatio");
//         maxWidthRatioField.setAccessible(true);
//         maxWidthRatioField.setFloat(categoryAxis, 0.4f);
// 
//         TextBlock label1 = mock(TextBlock.class);
//         TextBlock label2 = mock(TextBlock.class);
// 
//         when(categoryAxis.createLabel(eq("Cat1"), anyFloat(), eq(edge), eq(g2))).thenReturn(label1);
//         when(categoryAxis.createLabel(eq("Cat2"), anyFloat(), eq(edge), eq(g2))).thenReturn(label2);
// 
//         when(label1.calculateDimensions(g2)).thenReturn(new Size2D(70, 20));
//         when(label2.calculateDimensions(g2)).thenReturn(new Size2D(90, 25));
// 
//         List<?> result = categoryAxis.refreshTicks(g2, state, dataArea, edge);
// 
//         Assertions.assertEquals(2, result.size());
//         Assertions.assertEquals(25.0, state.getMax());
//     }
}