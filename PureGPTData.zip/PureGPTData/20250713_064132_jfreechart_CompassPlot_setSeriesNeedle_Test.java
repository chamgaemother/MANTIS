import org.jfree.chart.needle.*;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;
import org.junit.jupiter.api.Test;

import java.awt.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CompassPlotTest {

    @Test
    public void testSetSeriesNeedle_ArrowNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 0);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_LineNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 1);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_LongNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 2);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_PinNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 3);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_PlumNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 4);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_PointerNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 5);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_ShipNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 6);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_WindNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 7);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_SecondArrowNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 8);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_MiddlePinNeedle() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        compassPlot.setSeriesNeedle(0, 9);
        assertTrue(compassPlot.getDatasets().length > 0);
    }

    @Test
    public void testSetSeriesNeedle_InvalidType() {
        CompassPlot compassPlot = new CompassPlot(new DefaultValueDataset());
        assertThrows(IllegalArgumentException.class, () -> compassPlot.setSeriesNeedle(0, 10));
    }
}