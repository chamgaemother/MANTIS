import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ConversionTest {

    @Test
    void testBinaryToHexDigit_NullInput() {
        assertThrows(NullPointerException.class, () -> {
            Conversion.binaryToHexDigit(null);
        });
    }

    @Test
    void testBinaryToHexDigit_EmptyArray() {
        assertThrows(IllegalArgumentException.class, () -> {
            Conversion.binaryToHexDigit(new boolean[0]);
        });
    }

    @Test
    void testBinaryToHexDigit_SingleBit0() {
        assertEquals('0', Conversion.binaryToHexDigit(new boolean[]{false}));
    }

    @Test
    void testBinaryToHexDigit_SingleBit1() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[]{true}));
    }

    @Test
    void testBinaryToHexDigit_AllBits0() {
        assertEquals('0', Conversion.binaryToHexDigit(new boolean[]{false, false, false, false}));
    }

    @Test
    void testBinaryToHexDigit_1000() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[]{true, false, false, false}));
    }

    @Test
    void testBinaryToHexDigit_0100() {
        assertEquals('2', Conversion.binaryToHexDigit(new boolean[]{false, true, false, false}));
    }

    @Test
    void testBinaryToHexDigit_0010() {
        assertEquals('4', Conversion.binaryToHexDigit(new boolean[]{false, false, true, false}));
    }

    @Test
    void testBinaryToHexDigit_0001() {
        assertEquals('8', Conversion.binaryToHexDigit(new boolean[]{false, false, false, true}));
    }

    @Test
    void testBinaryToHexDigit_allFalseWithSrcPos() {
        assertEquals('0', Conversion.binaryToHexDigit(new boolean[]{false, false, false, false, true}, 1));
    }

    @Test
    void testBinaryToHexDigit_1001() {
        assertEquals('9', Conversion.binaryToHexDigit(new boolean[]{true, false, false, true}));
    }

    @Test
    void testBinaryToHexDigit_1111() {
        assertEquals('f', Conversion.binaryToHexDigit(new boolean[]{true, true, true, true}));
    }

    @Test
    void testBinaryToHexDigit_InvalidSrcPos() {
        boolean[] src = new boolean[]{true, true, true, false};
        int invalidPos = src.length + 1; // invalid index
        assertThrows(IndexOutOfBoundsException.class, () -> {
            Conversion.binaryToHexDigit(src, invalidPos);
        });
    }
}