package com.fasterxml.jackson.core.io;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class NumberInputTest {

    @Test
    void parseInt_NullInput_ThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> NumberInput.parseInt(null));
    }

    @Test
    void parseInt_EmptyString_ThrowsStringIndexOutOfBoundsException() {
        assertThrows(StringIndexOutOfBoundsException.class, () -> NumberInput.parseInt(""));
    }

    @Test
    void parseInt_SinglePositiveDigit() {
        assertEquals(5, NumberInput.parseInt("5"));
    }

    @Test
    void parseInt_SingleNegativeDigit() {
        assertEquals(-3, NumberInput.parseInt("-3"));
    }

    @Test
    void parseInt_PositiveWithPlusSign() {
        assertEquals(123, NumberInput.parseInt("+123"));
    }

    @Test
    void parseInt_PositiveWithLeadingZeroes() {
        assertEquals(42, NumberInput.parseInt("00042"));
    }

    @Test
    void parseInt_NegativeWithLeadingZeroes() {
        assertEquals(-42, NumberInput.parseInt("-00042"));
    }

    @Test
    void parseInt_NegativeSingleCharacter_ThrowsNumberFormatException() {
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt("-"));
    }

    @Test
    void parseInt_NegativeExceedsMaxDigits_UsesIntegerParseInt() {
        String input = "-12345678901";
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt(input));
    }

    @Test
    void parseInt_PositiveExceedsMaxDigits_UsesIntegerParseInt() {
        String input = "1234567890";
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt(input));
    }

    @Test
    void parseInt_InvalidFirstCharacter_UsesIntegerParseInt() {
        String input = "a123";
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt(input));
    }

    @Test
    void parseInt_InvalidCharacterInMiddle_UsesIntegerParseInt() {
        String input = "12a34";
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt(input));
    }

    @Test
    void parseInt_InvalidCharacterAtEnd_UsesIntegerParseInt() {
        String input = "1234a";
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt(input));
    }

    @Test
    void parseInt_IntegerMaxValue() {
        assertEquals(Integer.MAX_VALUE, NumberInput.parseInt("2147483647"));
    }

    @Test
    void parseInt_IntegerMinValue() {
        assertEquals(Integer.MIN_VALUE, NumberInput.parseInt("-2147483648"));
    }

    @Test
    void parseInt_PlusZero() {
        assertEquals(0, NumberInput.parseInt("+0"));
    }

    @Test
    void parseInt_NegativeZero() {
        assertEquals(0, NumberInput.parseInt("-0"));
    }

    @Test
    void parseInt_MultipleDigitsValid() {
        assertEquals(123456789, NumberInput.parseInt("123456789"));
    }

    @Test
    void parseInt_OnlyPlusSign_ThrowsNumberFormatException() {
        assertThrows(NumberFormatException.class, () -> NumberInput.parseInt("+"));
    }

}