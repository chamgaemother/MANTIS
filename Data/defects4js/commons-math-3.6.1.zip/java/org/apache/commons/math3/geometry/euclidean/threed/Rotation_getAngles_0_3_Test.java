package org.apache.commons.math3.geometry.euclidean.threed;


import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class Rotation_getAngles_0_3_Test {

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZYX order where v2.getX() is within bounds")
    public void test_TC1() {
        // GIVEN
        Rotation rotation = new Rotation(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR, 0.3, 0.4, 0.5);
        
        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
        
        // THEN
        assertEquals(3, angles.length, "Angle array should have length 3");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZYX order where v2.getX() exceeds threshold, throwing CardanEulerSingularityException")
    public void test_TC2() {
        // GIVEN
        Rotation rotation = new Rotation(0, 0, 0, 1, false); // Set this to a singular quaternion

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZYX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and XYX order where v2.getX() is within bounds")
    public void test_TC3() {
        // GIVEN
        Rotation rotation = new Rotation(RotationOrder.XYX, RotationConvention.VECTOR_OPERATOR, FastMath.PI / 4, FastMath.PI / 6, FastMath.PI / 3);
        
        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.XYX, RotationConvention.VECTOR_OPERATOR);
        
        // THEN
        assertEquals(3, angles.length, "Angle array should have length 3");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and XYX order where v2.getX() exceeds threshold, throwing CardanEulerSingularityException")
    public void test_TC4() {
        // GIVEN
        Rotation rotation = new Rotation(0, 0, 0, 1, false); // Set this to a singular quaternion

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYX, RotationConvention.VECTOR_OPERATOR);
        });
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and XZX order where v2.getX() is within bounds")
    public void test_TC5() {
        // GIVEN
        Rotation rotation = new Rotation(RotationOrder.XZX, RotationConvention.VECTOR_OPERATOR, FastMath.PI / 3, FastMath.PI / 4, FastMath.PI / 6);
        
        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.XZX, RotationConvention.VECTOR_OPERATOR);
        
        // THEN
        assertEquals(3, angles.length, "Angle array should have length 3");
    }
}
