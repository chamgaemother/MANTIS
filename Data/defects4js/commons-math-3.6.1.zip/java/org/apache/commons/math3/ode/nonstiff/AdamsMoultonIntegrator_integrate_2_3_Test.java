//package org.apache.commons.math3.ode.nonstiff;
//
//import static org.junit.jupiter.api.Assertions.assertThrows;
//
//import org.apache.commons.math3.exception.NoBracketingException;
//import org.apache.commons.math3.ode.ExpandableStatefulODE;
//import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//
///**
// * Test class for AdamsMoultonIntegrator.integrate method.
// */
//public class AdamsMoultonIntegrator_integrate_2_3_Test {
//
//    @Test
//    @DisplayName("Integrate with NoBracketingException when step cannot bracket root")
//    public void testIntegrate_NoBracketingException() {
//        // GIVEN
//        AdamsMoultonIntegrator integrator = new AdamsMoultonIntegrator(5, 0.1, 1.0, 1.0e-5, 1.0e-5);
//        FirstOrderDifferentialEquations equations = new NoBracketingDifferentialEquations();
//        ExpandableStatefulODE expandable = new ExpandableStatefulODE(equations);
//        expandable.setTime(0.0);
//        expandable.setCompleteState(new double[]{0.0});
//        double targetTime = 10.0;
//
//        // WHEN & THEN
//        // Expecting NoBracketingException due to non-changing derivatives
//        assertThrows(NoBracketingException.class, () -> {
//            integrator.integrate(expandable, targetTime);
//        }, "Expected NoBracketingException when step cannot bracket root");
//    }
//
//    /**
//     * A Differential Equations implementation that causes NoBracketingException.
//     */
//    private static class NoBracketingDifferentialEquations implements FirstOrderDifferentialEquations {
//
//        @Override
//        public int getDimension() {
//            return 1;
//        }
//
//        @Override
//        public void computeDerivatives(double t, double[] y, double[] yDot) {
//            // No derivatives are changing, making it impossible to bracket any root.
//            yDot[0] = 0.0;
//        }
//    }
//}