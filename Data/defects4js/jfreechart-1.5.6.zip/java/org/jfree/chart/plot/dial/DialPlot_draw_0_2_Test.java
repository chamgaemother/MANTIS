package org.jfree.chart.plot.dial;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Generated JUnit 5 test class for DialPlot.draw method.
 */
@ExtendWith(MockitoExtension.class)
public class DialPlot_draw_0_2_Test {

    @Test
    @DisplayName("Draw method with no visible layers")
    public void TC06_draw_with_no_visible_layers() throws Exception {
        // Initialize DialPlot instance
        DialPlot plot = new DialPlot();

        // Set layers with none visible
        DialLayer layer1 = mock(DialLayer.class);
        DialLayer layer2 = mock(DialLayer.class);
        List<DialLayer> layers = new ArrayList<>();
        layers.add(layer1);
        layers.add(layer2);
        // Using reflection to set private 'layers' field
        Field layersField = DialPlot.class.getDeclaredField("layers");
        layersField.setAccessible(true);
        layersField.set(plot, layers);

        // Set layers to not visible
        when(layer1.isVisible()).thenReturn(false);
        when(layer2.isVisible()).thenReturn(false);

        // Set no pointers
        List<DialPointer> pointers = new ArrayList<>();
        Field pointersField = DialPlot.class.getDeclaredField("pointers");
        pointersField.setAccessible(true);
        pointersField.set(plot, pointers);

        // Set no cap
        Field capField = DialPlot.class.getDeclaredField("cap");
        capField.setAccessible(true);
        capField.set(plot, null);

        // Set dialFrame not visible
        DialFrame dialFrame = mock(DialFrame.class);
        when(dialFrame.isVisible()).thenReturn(false);
        Field dialFrameField = DialPlot.class.getDeclaredField("dialFrame");
        dialFrameField.setAccessible(true);
        dialFrameField.set(plot, dialFrame);

        // Mock Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D centerPoint = new Point2D.Double(50, 50);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Invoke draw method
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // Verify no layers drawn
        verify(layer1, never()).draw(any(Graphics2D.class), any(DialPlot.class), any(Rectangle2D.class), any(Rectangle2D.class));
        verify(layer2, never()).draw(any(Graphics2D.class), any(DialPlot.class), any(Rectangle2D.class), any(Rectangle2D.class));

        // Verify original clip is restored
        verify(g2, times(1)).setClip(any(Shape.class));
    }

    @Test
    @DisplayName("Draw method with visible pointers not clipped to window")
    public void TC07_draw_with_visible_pointers_not_clipped() throws Exception {
        // Initialize DialPlot instance
        DialPlot plot = new DialPlot();

        // Set visible pointers not clipped to window
        DialPointer visiblePointer1 = mock(DialPointer.class);
        DialPointer visiblePointer2 = mock(DialPointer.class);
        List<DialPointer> pointers = new ArrayList<>();
        pointers.add(visiblePointer1);
        pointers.add(visiblePointer2);
        // Using reflection to set private 'pointers' field
        Field pointersField = DialPlot.class.getDeclaredField("pointers");
        pointersField.setAccessible(true);
        pointersField.set(plot, pointers);

        // Set pointers to visible and not clipped
        when(visiblePointer1.isVisible()).thenReturn(true);
        when(visiblePointer1.isClippedToWindow()).thenReturn(false);
        when(visiblePointer2.isVisible()).thenReturn(true);
        when(visiblePointer2.isClippedToWindow()).thenReturn(false);

        // Set no background
        Field backgroundField = DialPlot.class.getDeclaredField("background");
        backgroundField.setAccessible(true);
        backgroundField.set(plot, null);

        // Set no layers
        List<DialLayer> layers = new ArrayList<>();
        Field layersField = DialPlot.class.getDeclaredField("layers");
        layersField.setAccessible(true);
        layersField.set(plot, layers);

        // Set no cap
        Field capField = DialPlot.class.getDeclaredField("cap");
        capField.setAccessible(true);
        capField.set(plot, null);

        // Set dialFrame not visible
        DialFrame dialFrame = mock(DialFrame.class);
        when(dialFrame.isVisible()).thenReturn(false);
        Field dialFrameField = DialPlot.class.getDeclaredField("dialFrame");
        dialFrameField.setAccessible(true);
        dialFrameField.set(plot, dialFrame);

        // Mock Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D centerPoint = new Point2D.Double(50, 50);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Invoke draw method
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // Verify pointers drawn without clipping
        verify(visiblePointer1, times(1)).draw(g2, plot, any(Rectangle2D.class), eq(area));
        verify(visiblePointer2, times(1)).draw(g2, plot, any(Rectangle2D.class), eq(area));

        // Verify original clip is restored
        verify(g2, times(1)).setClip(any(Shape.class));
    }

    @Test
    @DisplayName("Draw method with visible pointers clipped to window")
    public void TC08_draw_with_visible_pointers_clipped() throws Exception {
        // Initialize DialPlot instance
        DialPlot plot = new DialPlot();

        // Set visible pointers clipped to window
        DialPointer visiblePointer1 = mock(DialPointer.class);
        DialPointer visiblePointer2 = mock(DialPointer.class);
        List<DialPointer> pointers = new ArrayList<>();
        pointers.add(visiblePointer1);
        pointers.add(visiblePointer2);
        // Using reflection to set private 'pointers' field
        Field pointersField = DialPlot.class.getDeclaredField("pointers");
        pointersField.setAccessible(true);
        pointersField.set(plot, pointers);

        // Set pointers to visible and clipped
        when(visiblePointer1.isVisible()).thenReturn(true);
        when(visiblePointer1.isClippedToWindow()).thenReturn(true);
        when(visiblePointer2.isVisible()).thenReturn(true);
        when(visiblePointer2.isClippedToWindow()).thenReturn(true);

        // Set no background
        Field backgroundField = DialPlot.class.getDeclaredField("background");
        backgroundField.setAccessible(true);
        backgroundField.set(plot, null);

        // Set no layers
        List<DialLayer> layers = new ArrayList<>();
        Field layersField = DialPlot.class.getDeclaredField("layers");
        layersField.setAccessible(true);
        layersField.set(plot, layers);

        // Set no cap
        Field capField = DialPlot.class.getDeclaredField("cap");
        capField.setAccessible(true);
        capField.set(plot, null);

        // Set dialFrame not visible
        DialFrame dialFrame = mock(DialFrame.class);
        when(dialFrame.isVisible()).thenReturn(false);
        Field dialFrameField = DialPlot.class.getDeclaredField("dialFrame");
        dialFrameField.setAccessible(true);
        dialFrameField.set(plot, dialFrame);

        // Mock Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D centerPoint = new Point2D.Double(50, 50);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Invoke draw method
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // Verify pointers drawn with clipping
        verify(visiblePointer1, times(1)).draw(g2, plot, any(Rectangle2D.class), eq(area));
        verify(visiblePointer2, times(1)).draw(g2, plot, any(Rectangle2D.class), eq(area));

        // Verify original clip is restored
        verify(g2, times(1)).setClip(any(Shape.class));
    }

    @Test
    @DisplayName("Draw method with no visible pointers")
    public void TC09_draw_with_no_visible_pointers() throws Exception {
        // Initialize DialPlot instance
        DialPlot plot = new DialPlot();

        // Set pointers with none visible
        DialPointer pointer1 = mock(DialPointer.class);
        DialPointer pointer2 = mock(DialPointer.class);
        List<DialPointer> pointers = new ArrayList<>();
        pointers.add(pointer1);
        pointers.add(pointer2);
        // Using reflection to set private 'pointers' field
        Field pointersField = DialPlot.class.getDeclaredField("pointers");
        pointersField.setAccessible(true);
        pointersField.set(plot, pointers);

        // Set pointers to not visible
        when(pointer1.isVisible()).thenReturn(false);
        when(pointer2.isVisible()).thenReturn(false);

        // Set no background
        Field backgroundField = DialPlot.class.getDeclaredField("background");
        backgroundField.setAccessible(true);
        backgroundField.set(plot, null);

        // Set no layers
        List<DialLayer> layers = new ArrayList<>();
        Field layersField = DialPlot.class.getDeclaredField("layers");
        layersField.setAccessible(true);
        layersField.set(plot, layers);

        // Set no cap
        Field capField = DialPlot.class.getDeclaredField("cap");
        capField.setAccessible(true);
        capField.set(plot, null);

        // Set dialFrame not visible
        DialFrame dialFrame = mock(DialFrame.class);
        when(dialFrame.isVisible()).thenReturn(false);
        Field dialFrameField = DialPlot.class.getDeclaredField("dialFrame");
        dialFrameField.setAccessible(true);
        dialFrameField.set(plot, dialFrame);

        // Mock Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D centerPoint = new Point2D.Double(50, 50);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Invoke draw method
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // Verify no pointers drawn
        verify(pointer1, never()).draw(any(Graphics2D.class), any(DialPlot.class), any(Rectangle2D.class), any(Rectangle2D.class));
        verify(pointer2, never()).draw(any(Graphics2D.class), any(DialPlot.class), any(Rectangle2D.class), any(Rectangle2D.class));

        // Verify original clip is restored
        verify(g2, times(1)).setClip(any(Shape.class));
    }

    @Test
    @DisplayName("Draw method with visible cap not clipped to window")
    public void TC10_draw_with_visible_cap_not_clipped() throws Exception {
        // Initialize DialPlot instance
        DialPlot plot = new DialPlot();

        // Set visible cap not clipped to window
        DialCap visibleCap = mock(DialCap.class);
        // Using reflection to set private 'cap' field
        Field capField = DialPlot.class.getDeclaredField("cap");
        capField.setAccessible(true);
        capField.set(plot, visibleCap);

        // Set cap to visible and not clipped
        when(visibleCap.isVisible()).thenReturn(true);
        when(visibleCap.isClippedToWindow()).thenReturn(false);

        // Set no background
        Field backgroundField = DialPlot.class.getDeclaredField("background");
        backgroundField.setAccessible(true);
        backgroundField.set(plot, null);

        // Set no layers
        List<DialLayer> layers = new ArrayList<>();
        Field layersField = DialPlot.class.getDeclaredField("layers");
        layersField.setAccessible(true);
        layersField.set(plot, layers);

        // Set no pointers
        List<DialPointer> pointers = new ArrayList<>();
        Field pointersField = DialPlot.class.getDeclaredField("pointers");
        pointersField.setAccessible(true);
        pointersField.set(plot, pointers);

        // Set dialFrame not visible
        DialFrame dialFrame = mock(DialFrame.class);
        when(dialFrame.isVisible()).thenReturn(false);
        Field dialFrameField = DialPlot.class.getDeclaredField("dialFrame");
        dialFrameField.setAccessible(true);
        dialFrameField.set(plot, dialFrame);

        // Mock Graphics2D and other parameters
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D centerPoint = new Point2D.Double(50, 50);
        PlotState plotState = mock(PlotState.class);
        PlotRenderingInfo plotRenderingInfo = mock(PlotRenderingInfo.class);

        // Invoke draw method
        plot.draw(g2, area, centerPoint, plotState, plotRenderingInfo);

        // Verify cap drawn without clipping
        verify(visibleCap, times(1)).draw(g2, plot, any(Rectangle2D.class), eq(area));

        // Verify original clip is restored
        verify(g2, times(1)).setClip(any(Shape.class));
    }
}