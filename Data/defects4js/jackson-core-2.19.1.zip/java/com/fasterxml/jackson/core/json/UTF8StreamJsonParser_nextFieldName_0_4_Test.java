package com.fasterxml.jackson.core.json;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

public class UTF8StreamJsonParser_nextFieldName_0_4_Test {

    @Test
    @DisplayName("Parses a field name followed by true boolean value")
    void TC16() throws Exception {
        // Initialize parser with {"expectedFieldName": true}
        String json = "{\"expectedFieldName\": true}";
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);
        assertEquals(JsonToken.VALUE_TRUE, parser.getCurrentToken());
        parser.close();
    }

    @Test
    @DisplayName("Parses a field name followed by false boolean value")
    void TC17() throws Exception {
        // Initialize parser with {"expectedFieldName": false}
        String json = "{\"expectedFieldName\": false}";
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);
        assertEquals(JsonToken.VALUE_FALSE, parser.getCurrentToken());
        parser.close();
    }

    @Test
    @DisplayName("Parses a field name followed by null value")
    void TC18() throws Exception {
        // Initialize parser with {"expectedFieldName": null}
        String json = "{\"expectedFieldName\": null}";
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);
        assertEquals(JsonToken.VALUE_NULL, parser.getCurrentToken());
        parser.close();
    }

    @Test
    @DisplayName("Parses a field name followed by start of array")
    void TC19() throws Exception {
        // Initialize parser with {"expectedFieldName": [1, 2, 3]}
        String json = "{\"expectedFieldName\": [1, 2, 3]}";
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);
        assertEquals(JsonToken.START_ARRAY, parser.getCurrentToken());
        parser.close();
    }

    @Test
    @DisplayName("Parses a field name followed by start of object")
    void TC20() throws Exception {
        // Initialize parser with {"expectedFieldName": {"nestedField": "value"}}
        String json = "{\"expectedFieldName\": {\"nestedField\": \"value\"}}";
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(json.getBytes(StandardCharsets.UTF_8));
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("expectedFieldName", fieldName);
        assertEquals(JsonToken.START_OBJECT, parser.getCurrentToken());
        parser.close();
    }
}