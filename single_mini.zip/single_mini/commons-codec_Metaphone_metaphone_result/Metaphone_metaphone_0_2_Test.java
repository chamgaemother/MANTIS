package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.Metaphone;

public class Metaphone_metaphone_0_2_Test {

    @Test
    @DisplayName("metaphone(\"whale\") processes initial 'wh' correctly")
    void test_TC06_metaphone_whale_processes_initial_wh_correctly() {
        // GIVEN
        String input = "whale";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertEquals("WAL", result, "Metaphone code should handle initial 'wh' correctly");
    }

    @Test
    @DisplayName("metaphone(\"xylophone\") processes initial 'x' as 'S'")
    void test_TC07_metaphone_xylophone_processes_initial_x_as_S() {
        // GIVEN
        String input = "xylophone";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertTrue(result.startsWith("S"), "Metaphone code should start with 'S' for initial 'x'");
    }

    @Test
    @DisplayName("metaphone(\"SCHOLAR\") handles 'SCH' as 'SK'")
    void test_TC08_metaphone_SCHOLAR_handles_SCH_as_SK() {
        // GIVEN
        String input = "SCHOLAR";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertTrue(result.contains("SK"), "Metaphone code should contain 'SK' for 'SCH'");
    }

    @Test
    @DisplayName("metaphone(\"THOUGHT\") converts 'TH' to '0'")
    void test_TC09_metaphone_THOUGHT_converts_TH_to_0() {
        // GIVEN
        String input = "THOUGHT";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertTrue(result.contains("0"), "Metaphone code should contain '0' for 'TH'");
    }

    @Test
    @DisplayName("metaphone(\"PHASE\") converts 'PH' to 'F'")
    void test_TC10_metaphone_PHASE_converts_PH_to_F() {
        // GIVEN
        String input = "PHASE";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(input);
        
        // THEN
        assertTrue(result.contains("F"), "Metaphone code should contain 'F' for 'PH'");
    }

}