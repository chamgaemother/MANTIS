package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class BoxAndWhiskerRenderer_drawHorizontalItem_0_2_Test {

    @Test
    @DisplayName("Handles a null MaxRegularValue by early exit without drawing box")
    public void testHandlesNullMaxRegularValueWithoutDrawingBox() throws Exception {
        // GIVEN
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(0, 2)).thenReturn(1.0);
        when(dataset.getQ3Value(0, 2)).thenReturn(3.0);
        when(dataset.getMaxRegularValue(0, 2)).thenReturn(null);
        when(dataset.getMinRegularValue(0, 2)).thenReturn(0.5);
        
        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2);

        // THEN
        // g2.fill and g2.draw should never be called
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
        // Entity addition should not occur
        verify(state, never()).getEntityCollection();
    }

    @Test
    @DisplayName("Handles a null MinRegularValue by early exit without drawing box")
    public void testHandlesNullMinRegularValueWithoutDrawingBox() throws Exception {
        // GIVEN
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(0, 3)).thenReturn(1.5);
        when(dataset.getQ3Value(0, 3)).thenReturn(2.5);
        when(dataset.getMaxRegularValue(0, 3)).thenReturn(4.0);
        when(dataset.getMinRegularValue(0, 3)).thenReturn(null);

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 3);

        // THEN
        // g2.fill and g2.draw should never be called
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
        // Entity addition should not occur
        verify(state, never()).getEntityCollection();
    }

    @Test
    @DisplayName("Handles fillBox=true ensuring the box shape is filled")
    public void testHandlesFillBoxTrue() throws Exception {
        // GIVEN
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field fillBoxField = BoxAndWhiskerRenderer.class.getDeclaredField("fillBox");
        fillBoxField.setAccessible(true);
        fillBoxField.set(renderer, true);
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(1, 1)).thenReturn(2.0);
        when(dataset.getQ3Value(1, 1)).thenReturn(4.0);
        when(dataset.getMaxRegularValue(1, 1)).thenReturn(5.0);
        when(dataset.getMinRegularValue(1, 1)).thenReturn(1.0);

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);

        // THEN
        ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
        verify(g2, times(1)).fill(shapeCaptor.capture());
        Shape filledShape = shapeCaptor.getValue();
        assertTrue(filledShape instanceof Rectangle2D);
        verify(g2, times(1)).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Handles fillBox=false ensuring the box shape is not filled")
    public void testHandlesFillBoxFalse() throws Exception {
        // GIVEN
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field fillBoxField = BoxAndWhiskerRenderer.class.getDeclaredField("fillBox");
        fillBoxField.setAccessible(true);
        fillBoxField.set(renderer, false);
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(1, 2)).thenReturn(2.5);
        when(dataset.getQ3Value(1, 2)).thenReturn(3.5);
        when(dataset.getMaxRegularValue(1, 2)).thenReturn(4.5);
        when(dataset.getMinRegularValue(1, 2)).thenReturn(1.5);

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 2);

        // THEN
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, times(1)).draw(any(Shape.class));
    }

    @Test
    @DisplayName("Tests useOutlinePaintForWhiskers=true uses outline paint for whiskers")
    public void testUseOutlinePaintForWhiskers() throws Exception {
        // GIVEN
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        Field useOutlinePaintForWhiskersField = BoxAndWhiskerRenderer.class.getDeclaredField("useOutlinePaintForWhiskers");
        useOutlinePaintForWhiskersField.setAccessible(true);
        useOutlinePaintForWhiskersField.set(renderer, true);
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerCategoryDataset dataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(dataset.getQ1Value(2, 2)).thenReturn(2.0);
        when(dataset.getQ3Value(2, 2)).thenReturn(4.0);
        when(dataset.getMaxRegularValue(2, 2)).thenReturn(5.0);
        when(dataset.getMinRegularValue(2, 2)).thenReturn(1.0);

        Paint outlinePaint = mock(Paint.class);
        when(renderer.getItemOutlinePaint(2, 2)).thenReturn(outlinePaint);
        Stroke outlineStroke = mock(Stroke.class);
        when(renderer.getItemOutlineStroke(2, 2)).thenReturn(outlineStroke);

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 2);

        // THEN
        verify(g2).setPaint(outlinePaint);
        verify(g2, times(4)).draw(any(Line2D.class));
        verify(g2).setStroke(outlineStroke);
    }
}