package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_containsKey_0_3_Test {

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, size is 1, hash matches, but key does not equal key1")
    void TC11_containsKey_delegateMapNull_KeyNotNull_Size1_HashMatch_KeyNotEqual() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map flat3Map = new Flat3Map();
        
        // Set fields via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 1);

        Object specificKey = new Object();

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(flat3Map, specificKey.hashCode());

        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(flat3Map, new Object()); // Different key

        // Invoke containsKey
        boolean result = flat3Map.containsKey(specificKey);

        // Assert the result
        assertFalse(result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is not null, size is 2, hash matches hash2, and key equals key2")
    void TC12_containsKey_delegateMapNull_KeyNotNull_Size2_HashMatch_KeyEquals() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map flat3Map = new Flat3Map();
        
        // Set fields via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 2);

        Object specificKey = new Object();

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(flat3Map, specificKey.hashCode());

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(flat3Map, specificKey); // Equal key

        // Invoke containsKey
        boolean result = flat3Map.containsKey(specificKey);

        // Assert the result
        assertTrue(result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is not null, size is 3, hash matches hash3, and key equals key3")
    void TC13_containsKey_delegateMapNull_KeyNotNull_Size3_HashMatch_KeyEquals() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map flat3Map = new Flat3Map();
        
        // Set fields via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 3);

        Object specificKey = new Object();

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(flat3Map, specificKey.hashCode());

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(flat3Map, specificKey); // Equal key

        // Invoke containsKey
        boolean result = flat3Map.containsKey(specificKey);

        // Assert the result
        assertTrue(result);
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, size is 3, and hash matches hash3 but key does not equal key3")
    void TC14_containsKey_delegateMapNull_KeyNotNull_Size3_HashMatch_KeyNotEqual() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map flat3Map = new Flat3Map();
        
        // Set fields via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 3);

        Object specificKey = new Object();

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(flat3Map, specificKey.hashCode());

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(flat3Map, new Object()); // Different key

        // Invoke containsKey
        boolean result = flat3Map.containsKey(specificKey);

        // Assert the result
        assertFalse(result);
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, size is 2, hash matches hash2, but key does not equal key2")
    void TC15_containsKey_delegateMapNull_KeyNotNull_Size2_HashMatch_KeyNotEqual() throws Exception {
        // Initialize Flat3Map instance
        Flat3Map flat3Map = new Flat3Map();
        
        // Set fields via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 2);

        Object specificKey = new Object();

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(flat3Map, specificKey.hashCode());

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(flat3Map, new Object()); // Different key

        // Invoke containsKey
        boolean result = flat3Map.containsKey(specificKey);

        // Assert the result
        assertFalse(result);
    }
}