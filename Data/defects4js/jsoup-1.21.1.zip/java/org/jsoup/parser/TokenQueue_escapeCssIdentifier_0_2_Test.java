package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jsoup.parser.TokenQueue;

public class TokenQueue_escapeCssIdentifier_0_2_Test {

    @Test
    @DisplayName("Input contains control character below U+001F, escapes as codepoint")
    public void TC06_escapeCssIdentifier_control_character() {
        // GIVEN
        String input = "abc\u001Fdef";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("abc\\001F def", result);
    }

    @Test
    @DisplayName("Input contains DEL character (U+007F), escapes as codepoint")
    public void TC07_escapeCssIdentifier_DEL_character() {
        // GIVEN
        String input = "abc\u007Fdef";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("abc\\007Fdef", result);
    }

    @Test
    @DisplayName("Input contains non-ASCII identifier character, appends as is")
    public void TC08_escapeCssIdentifier_non_ASCII_identifier() {
        // GIVEN
        String input = "abcÎ©def";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("abcÎ©def", result);
    }

    @Test
    @DisplayName("Input contains special character not handled, escapes the character")
    public void TC09_escapeCssIdentifier_special_character() {
        // GIVEN
        String input = "abc@def";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("abc\\@def", result);
    }

    @Test
    @DisplayName("Input with multiple characters requiring different escapes")
    public void TC10_escapeCssIdentifier_multiple_escapes() {
        // GIVEN
        String input = "-5\0AÎ©@";
        
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        
        // THEN
        assertEquals("-\\35\\uFFFDÎ©\\@ ", result);
    }
}