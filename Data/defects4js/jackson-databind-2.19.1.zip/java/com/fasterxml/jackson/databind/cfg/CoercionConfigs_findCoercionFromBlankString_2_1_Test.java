package com.fasterxml.jackson.databind.cfg;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.cfg.*;
import com.fasterxml.jackson.databind.type.*;

public class CoercionConfigs_findCoercionFromBlankString_2_1_Test {

//     @Test
//     @DisplayName("When _perClassCoercions is not null, targetClass is null, and _perTypeCoercions is not null but has no specific coercion defined")
//     void TC21_handle_null_targetClass_with_no_specific_perTypeCoercion() {
        // GIVEN
//         MutableCoercionConfig[] perTypeCoercions = new MutableCoercionConfig[LogicalType.values().length];
//         Map<Class<?>, MutableCoercionConfig> perClassCoercions = new HashMap<>();
//         
//         CoercionAction defaultAction = CoercionAction.TryConvert;
//         MutableCoercionConfig defaultCoercions = new MutableCoercionConfig();
// 
//         CoercionConfigs coercionConfigs = new CoercionConfigs(defaultAction, defaultCoercions, perTypeCoercions, perClassCoercions);
// 
//         DeserializationConfig config = DeserializationConfig.builder().with(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT).build();
//         
//         LogicalType targetType = LogicalType.OtherScalar;
//         Class<?> targetClass = null;
//         CoercionAction actionIfBlankNotAllowed = CoercionAction.Fail;
// 
        // WHEN
//         CoercionAction result = coercionConfigs.findCoercionFromBlankString(config, targetType, targetClass, actionIfBlankNotAllowed);
// 
        // THEN
//         assertEquals(CoercionAction.Fail, result);
//     }

//     @Test
//     @DisplayName("When _perClassCoercions is not null with acceptBlankAsEmpty set to false and _perTypeCoercions has acceptBlankAsEmpty set to true")
//     void TC22_handle_conflicting_perClass_and_perType_acceptBlankAsEmpty() {
        // GIVEN
//         MutableCoercionConfig classConfig = new MutableCoercionConfig();
//         classConfig.setAcceptBlankAsEmpty(false);
//         classConfig.setAction(CoercionInputShape.EmptyString, CoercionAction.AsNull);
//         Map<Class<?>, MutableCoercionConfig> perClassCoercions = new HashMap<>();
//         perClassCoercions.put(String.class, classConfig);
// 
//         MutableCoercionConfig typeConfig = new MutableCoercionConfig();
//         typeConfig.setAcceptBlankAsEmpty(true);
//         typeConfig.setAction(CoercionInputShape.EmptyString, CoercionAction.AsNull);
//         MutableCoercionConfig[] perTypeCoercions = new MutableCoercionConfig[LogicalType.values().length];
//         perTypeCoercions[LogicalType.String.ordinal()] = typeConfig;
// 
//         CoercionAction defaultAction = CoercionAction.TryConvert;
//         MutableCoercionConfig defaultCoercions = new MutableCoercionConfig();
// 
//         CoercionConfigs coercionConfigs = new CoercionConfigs(defaultAction, defaultCoercions, perTypeCoercions, perClassCoercions);
//         
//         DeserializationConfig config = DeserializationConfig.builder().build();
// 
//         LogicalType targetType = LogicalType.String;
//         Class<?> targetClass = String.class;
//         CoercionAction actionIfBlankNotAllowed = CoercionAction.Fail;
// 
        // WHEN
//         CoercionAction result = coercionConfigs.findCoercionFromBlankString(config, targetType, targetClass, actionIfBlankNotAllowed);
// 
        // THEN
//         assertEquals(CoercionAction.Fail, result);
//     }

//     @Test
//     @DisplayName("When _perTypeCoercions is not null, targetType has no specific coercion, and ACCEPT_EMPTY_STRING_AS_NULL_OBJECT is enabled")
//     void TC23_handle_no_specific_perTypeCoercion_with_feature_enabled() {
        // GIVEN
//         MutableCoercionConfig[] perTypeCoercions = new MutableCoercionConfig[LogicalType.values().length];
//         Map<Class<?>, MutableCoercionConfig> perClassCoercions = null;
// 
//         CoercionAction defaultAction = CoercionAction.TryConvert;
//         MutableCoercionConfig defaultCoercions = new MutableCoercionConfig();
// 
//         CoercionConfigs coercionConfigs = new CoercionConfigs(defaultAction, defaultCoercions, perTypeCoercions, perClassCoercions);
// 
//         DeserializationConfig config = DeserializationConfig.builder()
//                 .with(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)
//                 .build();
// 
//         LogicalType targetType = LogicalType.OtherScalar;
//         Class<?> targetClass = Object.class;
//         CoercionAction actionIfBlankNotAllowed = CoercionAction.Fail;
// 
        // WHEN
//         CoercionAction result = coercionConfigs.findCoercionFromBlankString(config, targetType, targetClass, actionIfBlankNotAllowed);
// 
        // THEN
//         assertEquals(CoercionAction.AsNull, result);
//     }

//     @Test
//     @DisplayName("When _perTypeCoercions is not null, targetType is scalar, and ACCEPT_EMPTY_STRING_AS_NULL_OBJECT is disabled")
//     void TC24_handle_scalar_perTypeCoercion_with_feature_disabled() {
        // GIVEN
//         MutableCoercionConfig[] perTypeCoercions = new MutableCoercionConfig[LogicalType.values().length];
//         Map<Class<?>, MutableCoercionConfig> perClassCoercions = null;
// 
//         CoercionAction defaultAction = CoercionAction.TryConvert;
//         MutableCoercionConfig defaultCoercions = new MutableCoercionConfig();
// 
//         CoercionConfigs coercionConfigs = new CoercionConfigs(defaultAction, defaultCoercions, perTypeCoercions, perClassCoercions);
// 
//         DeserializationConfig config = DeserializationConfig.builder()
//                 .without(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)
//                 .build();
// 
//         LogicalType targetType = LogicalType.Boolean;
//         Class<?> targetClass = Boolean.class;
//         CoercionAction actionIfBlankNotAllowed = CoercionAction.Fail;
// 
        // WHEN
//         CoercionAction result = coercionConfigs.findCoercionFromBlankString(config, targetType, targetClass, actionIfBlankNotAllowed);
// 
        // THEN
//         assertEquals(CoercionAction.Fail, result);
//     }

//     @Test
//     @DisplayName("When both _perClassCoercions and _perTypeCoercions have specific coercion actions defined for EmptyString")
//     void TC25_handle_both_perClass_and_perType_coercion_defined() {
        // GIVEN
//         MutableCoercionConfig classConfig = new MutableCoercionConfig();
//         classConfig.setAcceptBlankAsEmpty(true);
//         classConfig.setAction(CoercionInputShape.EmptyString, CoercionAction.AsEmpty);
//         Map<Class<?>, MutableCoercionConfig> perClassCoercions = new HashMap<>();
//         perClassCoercions.put(String.class, classConfig);
// 
//         MutableCoercionConfig typeConfig = new MutableCoercionConfig();
//         typeConfig.setAcceptBlankAsEmpty(true);
//         typeConfig.setAction(CoercionInputShape.EmptyString, CoercionAction.AsNull);
//         MutableCoercionConfig[] perTypeCoercions = new MutableCoercionConfig[LogicalType.values().length];
//         perTypeCoercions[LogicalType.String.ordinal()] = typeConfig;
// 
//         CoercionAction defaultAction = CoercionAction.TryConvert;
//         MutableCoercionConfig defaultCoercions = new MutableCoercionConfig();
// 
//         CoercionConfigs coercionConfigs = new CoercionConfigs(defaultAction, defaultCoercions, perTypeCoercions, perClassCoercions);
// 
//         DeserializationConfig config = DeserializationConfig.builder().build();
// 
//         LogicalType targetType = LogicalType.String;
//         Class<?> targetClass = String.class;
//         CoercionAction actionIfBlankNotAllowed = CoercionAction.Fail;
// 
        // WHEN
//         CoercionAction result = coercionConfigs.findCoercionFromBlankString(config, targetType, targetClass, actionIfBlankNotAllowed);
// 
        // THEN
//         assertEquals(CoercionAction.AsEmpty, result);
//     }

}