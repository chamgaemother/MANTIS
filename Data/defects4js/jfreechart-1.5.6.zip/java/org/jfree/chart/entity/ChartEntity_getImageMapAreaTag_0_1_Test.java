package org.jfree.chart.entity;

import org.jfree.chart.imagemap.ToolTipTagFragmentGenerator;
import org.jfree.chart.imagemap.URLTagFragmentGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.geom.Rectangle2D;
import java.awt.Shape;

import static org.junit.jupiter.api.Assertions.*;

public class ChartEntity_getImageMapAreaTag_0_1_Test {

    @Test
    @DisplayName("When both urlText and toolTipText are null, no image map area tag is generated")
    public void TC01() throws Exception {
        // GIVEN
        String urlText = null;
        String toolTipText = null;
        Shape area = new Rectangle2D.Double(0, 0, 10, 10);
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip_fragment";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        assertEquals("", result);
    }

    @Test
    @DisplayName("When urlText is non-null and not empty, and toolTipText is null, generate area tag with URL and noalt attribute")
    public void TC02() throws Exception {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = null;
        Shape area = new Rectangle2D.Double(0, 0, 10, 10);
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip_fragment";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        assertTrue(result.contains("shape=\"") && result.contains("coords=\"") && result.contains("href=\"http://example.com\"") && result.contains("alt=\"\""));
    }

    @Test
    @DisplayName("When both urlText and toolTipText are non-null and not empty, generate area tag with URL and ToolTip")
    public void TC03() throws Exception {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = "Tooltip text";
        Shape area = new Rectangle2D.Double(0, 0, 10, 10);
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip_fragment";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        assertTrue(result.contains("shape=\"") && result.contains("coords=\"") && result.contains("tooltip_fragment") && result.contains("href=\"http://example.com\"") && !result.contains("alt=\""));
    }

    @Test
    @DisplayName("When urlText is non-null but empty, and toolTipText is null, generate area tag with nohref and alt attribute")
    public void TC04() throws Exception {
        // GIVEN
        String urlText = "";
        String toolTipText = null;
        Shape area = new Rectangle2D.Double(0, 0, 10, 10);
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip_fragment";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        assertTrue(result.contains("shape=\"") && result.contains("coords=\"") && result.contains("nohref=\"nohref\"") && result.contains("alt=\"\""));
    }

    @Test
    @DisplayName("When urlText is non-null but empty, and toolTipText is non-null and not empty, generate area tag with ToolTip and nohref")
    public void TC05() throws Exception {
        // GIVEN
        String urlText = "";
        String toolTipText = "Tooltip text";
        Shape area = new Rectangle2D.Double(0, 0, 10, 10);
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String toolTipText) {
                return "tooltip_fragment";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String urlText) {
                return "href=\"" + urlText + "\"";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        assertTrue(result.contains("shape=\"") && result.contains("coords=\"") && result.contains("tooltip_fragment") && result.contains("nohref=\"nohref\"") && !result.contains("alt=\""));
    }
}