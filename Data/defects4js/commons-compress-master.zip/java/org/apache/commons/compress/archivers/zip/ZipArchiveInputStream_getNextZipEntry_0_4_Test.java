package org.apache.commons.compress.archivers.zip;
import java.lang.reflect.*;
import java.util.*;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.deflate64.Deflate64CompressorInputStream;
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorInputStream;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ZipArchiveInputStream_getNextZipEntry_0_4_Test {

    @Test
    @DisplayName("Handles Deflate compression method")
    public void TC16_deflate_compression_method_handled() throws Exception {
        // GIVEN
        byte[] deflateLFH = createLFHSigWithDeflateMethod();
        InputStream inputStream = new ByteArrayInputStream(deflateLFH);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, StandardCharsets.UTF_8.name(), true);

        // Setup using reflection
        Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("lfhBuf");
        lfhBufField.setAccessible(true);
        lfhBufField.set(zipInputStream, deflateLFH);

        // WHEN
        ZipArchiveEntry entry = zipInputStream.getNextZipEntry();

        // THEN
        assertNotNull(entry);
        assertEquals(ZipMethod.DEFLATED.getCode(), entry.getMethod());
    }

    @Test
    @DisplayName("Handles BZip2 compression method")
    public void TC17_bzip2_compression_method_handled() throws Exception {
        // GIVEN
        byte[] bzip2LFH = createLFHSigWithBZip2Method();
        InputStream inputStream = new ByteArrayInputStream(bzip2LFH);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, null, false);

        // WHEN
        ZipArchiveEntry entry = zipInputStream.getNextZipEntry();

        // THEN
        assertNotNull(entry);
        assertEquals(ZipMethod.BZIP2.getCode(), entry.getMethod());

        // Verify that inputStream is an instance of BZip2CompressorInputStream
        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
        currentField.setAccessible(true);
        Object current = currentField.get(zipInputStream);

        Field inputStreamField = current.getClass().getDeclaredField("inputStream");
        inputStreamField.setAccessible(true);
        InputStream compressorInputStream = (InputStream) inputStreamField.get(current);

        assertNotNull(compressorInputStream);
        assertTrue(compressorInputStream instanceof BZip2CompressorInputStream);
    }

    @Test
    @DisplayName("Handles Unsupported compression method by skipping the entry")
    public void TC18_unsupported_compression_method_skipped() throws Exception {
        // GIVEN
        byte[] unsupportedLFH = createLFHSigWithUnsupportedMethod();
        InputStream inputStream = new ByteArrayInputStream(unsupportedLFH);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, null, true);

        // WHEN
        ZipArchiveEntry entry = zipInputStream.getNextZipEntry();

        // THEN
        assertNull(entry);
    }

    @Test
    @DisplayName("Processes entry with ZSTD compression method")
    public void TC19_zstd_compression_method_handled() throws Exception {
        // GIVEN
        byte[] zstdLFH = createLFHSigWithZSTDMethod();
        InputStream inputStream = new ByteArrayInputStream(zstdLFH);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, null, false);

        // WHEN
        ZipArchiveEntry entry = zipInputStream.getNextZipEntry();

        // THEN
        assertNotNull(entry);
        assertEquals(ZipMethod.ZSTD.getCode(), entry.getMethod());

        // Verify that input_stream is an instance of ZstdCompressorInputStream
        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
        currentField.setAccessible(true);
        Object current = currentField.get(zipInputStream);

        Field inputStreamField = current.getClass().getDeclaredField("inputStream");
        inputStreamField.setAccessible(true);
        InputStream compressorInputStream = (InputStream) inputStreamField.get(current);

        assertNotNull(compressorInputStream);
        assertTrue(compressorInputStream instanceof ZstdCompressorInputStream);
    }

//     @Test
//     @DisplayName("Throws IOException when IMPLODE data is bad")
//     public void TC20_bad_IMPLODE_data_throws_ioexception() throws Exception {
        // GIVEN
//         byte[] impodingBadLFH = createLFHSigWithImpodingMethodAndBadData();
//         InputStream inputStream = new ByteArrayInputStream(new byte[0]) {
//             @Override
//             public int read() throws IOException {
//                 throw new IllegalArgumentException("Bad IMPLODE data");
//             }
//         };
//         ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream);
// 
        // Setup using reflection
//         Field lfhBufField = ZipArchiveInputStream.class.getDeclaredField("lfhBuf");
//         lfhBufField.setAccessible(true);
//         lfhBufField.set(zipInputStream, impodingBadLFH);
// 
        // WHEN & THEN
//         IOException exception = assertThrows(IOException.class, () -> {
//             zipInputStream.getNextZipEntry();
//         });
//         assertEquals("bad IMPLODE data", exception.getMessage());
//     }

    // Helper methods to create LFH signatures for different compression methods
    private byte[] createLFHSigWithDeflateMethod() {
        byte[] lfh = new byte[30];
        lfh[0] = (byte) (0x50);
        lfh[1] = (byte) (0x4B);
        lfh[2] = (byte) (0x03);
        lfh[3] = (byte) (0x04);
        lfh[8] = 0x08;
        return lfh;
    }

    private byte[] createLFHSigWithBZip2Method() {
        byte[] lfh = new byte[30];
        lfh[0] = (byte) (0x50);
        lfh[1] = (byte) (0x4B);
        lfh[2] = (byte) (0x03);
        lfh[3] = (byte) (0x04);
        lfh[8] = 0x14;
        return lfh;
    }

    private byte[] createLFHSigWithUnsupportedMethod() {
        byte[] lfh = new byte[30];
        lfh[0] = (byte) (0x50);
        lfh[1] = (byte) (0x4B);
        lfh[2] = (byte) (0x03);
        lfh[3] = (byte) (0x04);
        lfh[8] = 0x63;
        return lfh;
    }

    private byte[] createLFHSigWithZSTDMethod() {
        byte[] lfh = new byte[30];
        lfh[0] = (byte) (0x50);
        lfh[1] = (byte) (0x4B);
        lfh[2] = (byte) (0x03);
        lfh[3] = (byte) (0x04);
        lfh[8] = 0x19;
        return lfh;
    }

    private byte[] createLFHSigWithImpodingMethodAndBadData() {
        byte[] lfh = new byte[30];
        lfh[0] = (byte) (0x50);
        lfh[1] = (byte) (0x4B);
        lfh[2] = (byte) (0x03);
        lfh[3] = (byte) (0x04);
        lfh[8] = 0x0B;
        return lfh;
    }
}