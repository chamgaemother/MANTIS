package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class MetadataBandGroupTest {

    private CpBands mockCpBands;
    private SegmentHeader mockSegmentHeader;
    private MetadataBandGroup metadataBandGroup;

    @BeforeEach
    void setUp() {
        mockCpBands = mock(CpBands.class);
        mockSegmentHeader = mock(SegmentHeader.class);
        metadataBandGroup = new MetadataBandGroup("AD", MetadataBandGroup.CONTEXT_CLASS, mockCpBands, mockSegmentHeader, 0);
    }

    @Test
    void testAddAnnotationWithEmptyLists() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Collections.emptyList();
        List<String> tags = Collections.emptyList();
        List<Object> values = Collections.emptyList();
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verifyNoMoreInteractions(mockCpBands);
        assertTrue(metadataBandGroup.hasContent());
    }

    @Test
    void testAddAnnotationWithNullDesc() {
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("I");
        List<Object> values = Arrays.asList(123);
        List<Integer> caseArrayN = Arrays.asList(1);
        List<String> nestTypeRS = Arrays.asList("Ljava/lang/Integer;");
        List<String> nestNameRU = Arrays.asList("nestedName");
        List<Integer> nestPairN = Arrays.asList(2);

        when(mockCpBands.getCPSignature(null)).thenThrow(new NullPointerException());

        assertThrows(NullPointerException.class, () -> {
            metadataBandGroup.addAnnotation(null, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);
        });

        verify(mockCpBands).getCPSignature(null);
    }

    @Test
    void testAddAnnotationWithVariousTags() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1", "name2");
        List<String> tags = Arrays.asList("I", "D", "c", "e", "s", "[", "@");
        List<Object> values = Arrays.asList(100, 3.14, "signature", "utf8String", "anotherUtf8");
        List<Integer> caseArrayN = Arrays.asList(2);
        List<String> nestTypeRS = Arrays.asList("Ljava/util/List;");
        List<String> nestNameRU = Arrays.asList("nestedName1");
        List<Integer> nestPairN = Arrays.asList(1);

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getCPUtf8("name2")).thenReturn(new CPUtf8("name2"));
        when(mockCpBands.getConstant(100)).thenReturn(new CPConstant<>(100));
        when(mockCpBands.getConstant(3.14)).thenReturn(new CPConstant<>(3.14));
        when(mockCpBands.getCPSignature("signature")).thenReturn(new CPSignature("signature"));
        when(mockCpBands.getCPUtf8("utf8String")).thenReturn(new CPUtf8("utf8String"));
        when(mockCpBands.getCPSignature("Ljava/util/List;")).thenReturn(new CPSignature("Ljava/util/List;"));
        when(mockCpBands.getCPUtf8("nestedName1")).thenReturn(new CPUtf8("nestedName1"));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getCPUtf8("name2");
        verify(mockCpBands).getConstant(100);
        verify(mockCpBands).getConstant(3.14);
        verify(mockCpBands).getCPSignature("signature");
        verify(mockCpBands).getCPUtf8("utf8String");
        verify(mockCpBands).getCPSignature("Ljava/util/List;");
        verify(mockCpBands).getCPUtf8("nestedName1");
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(2, metadataBandGroup.pair_N.size());
        assertEquals(2, metadataBandGroup.name_RU.size());
        assertEquals(7, metadataBandGroup.T.size());
        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertEquals(1, metadataBandGroup.caseD_KD.size());
        assertEquals(1, metadataBandGroup.casec_RS.size());
        assertEquals(1, metadataBandGroup.caseet_RS.size());
        assertEquals(1, metadataBandGroup.caseec_RU.size());
        assertEquals(1, metadataBandGroup.cases_RU.size());
        assertEquals(1, metadataBandGroup.casearray_N.size());
        assertEquals(1, metadataBandGroup.nesttype_RS.size());
        assertEquals(1, metadataBandGroup.nestpair_N.size());
        assertEquals(1, metadataBandGroup.nestname_RU.size());
        assertEquals(2, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithUnhandledTags() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("[", "@");
        List<Object> values = Arrays.asList();
        List<Integer> caseArrayN = Arrays.asList(1);
        List<String> nestTypeRS = Arrays.asList("Ljava/util/Map;");
        List<String> nestNameRU = Arrays.asList("nestedMap");
        List<Integer> nestPairN = Arrays.asList(2);

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getCPSignature("Ljava/util/Map;")).thenReturn(new CPSignature("Ljava/util/Map;"));
        when(mockCpBands.getCPUtf8("nestedMap")).thenReturn(new CPUtf8("nestedMap"));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getCPSignature("Ljava/util/Map;");
        verify(mockCpBands).getCPUtf8("nestedMap");
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(2, metadataBandGroup.T.size());
        assertEquals(1, metadataBandGroup.casearray_N.size());
        assertEquals(1, metadataBandGroup.nesttype_RS.size());
        assertEquals(1, metadataBandGroup.nestpair_N.size());
        assertEquals(1, metadataBandGroup.nestname_RU.size());
        assertEquals(1, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithNullLists() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = null;
        List<String> tags = null;
        List<Object> values = null;
        List<Integer> caseArrayN = null;
        List<String> nestTypeRS = null;
        List<String> nestNameRU = null;
        List<Integer> nestPairN = null;

        assertThrows(NullPointerException.class, () -> {
            metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);
        });

        verify(mockCpBands).getCPSignature(desc);
    }

    @Test
    void testAddAnnotationWithInvalidTag() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("X");
        List<Object> values = Arrays.asList("valueX");
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));

        // Even with invalid tag, it should process without throwing, just ignore the tag
        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(1, metadataBandGroup.T.size());
        // No case lists should be populated
        assertTrue(metadataBandGroup.caseI_KI.isEmpty());
        assertTrue(metadataBandGroup.caseD_KD.isEmpty());
        assertTrue(metadataBandGroup.caseF_KF.isEmpty());
        assertTrue(metadataBandGroup.caseJ_KJ.isEmpty());
        assertTrue(metadataBandGroup.casec_RS.isEmpty());
        assertTrue(metadataBandGroup.caseet_RS.isEmpty());
        assertTrue(metadataBandGroup.caseec_RU.isEmpty());
        assertTrue(metadataBandGroup.cases_RU.isEmpty());
        assertTrue(metadataBandGroup.casearray_N.isEmpty());
        assertTrue(metadataBandGroup.nesttype_RS.isEmpty());
        assertTrue(metadataBandGroup.nestpair_N.isEmpty());
        assertTrue(metadataBandGroup.nestname_RU.isEmpty());
        assertEquals(0, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithMixedTags() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1", "name2", "name3");
        List<String> tags = Arrays.asList("B", "D", "c", "e", "s", "[", "@", "Z");
        List<Object> values = Arrays.asList(1, 2.0, "signature1", "utf8Str1", "utf8Str2", 3, "Ljava/lang/Object;", "utf8Str3");
        List<Integer> caseArrayN = Arrays.asList(1, 2);
        List<String> nestTypeRS = Arrays.asList("Ljava/util/Set;", "Ljava/util/Map;");
        List<String> nestNameRU = Arrays.asList("nestedSet", "nestedMap");
        List<Integer> nestPairN = Arrays.asList(1, 2);

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getCPUtf8("name2")).thenReturn(new CPUtf8("name2"));
        when(mockCpBands.getCPUtf8("name3")).thenReturn(new CPUtf8("name3"));
        when(mockCpBands.getConstant(1)).thenReturn(new CPConstant<>(1));
        when(mockCpBands.getConstant(2.0)).thenReturn(new CPConstant<>(2.0));
        when(mockCpBands.getCPSignature("signature1")).thenReturn(new CPSignature("signature1"));
        when(mockCpBands.getCPUtf8("utf8Str1")).thenReturn(new CPUtf8("utf8Str1"));
        when(mockCpBands.getCPUtf8("utf8Str2")).thenReturn(new CPUtf8("utf8Str2"));
        when(mockCpBands.getCPSignature("Ljava/lang/Object;")).thenReturn(new CPSignature("Ljava/lang/Object;"));
        when(mockCpBands.getCPUtf8("utf8Str3")).thenReturn(new CPUtf8("utf8Str3"));
        when(mockCpBands.getCPSignature("Ljava/util/Set;")).thenReturn(new CPSignature("Ljava/util/Set;"));
        when(mockCpBands.getCPSignature("Ljava/util/Map;")).thenReturn(new CPSignature("Ljava/util/Map;"));
        when(mockCpBands.getCPUtf8("nestedSet")).thenReturn(new CPUtf8("nestedSet"));
        when(mockCpBands.getCPUtf8("nestedMap")).thenReturn(new CPUtf8("nestedMap"));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getCPUtf8("name2");
        verify(mockCpBands).getCPUtf8("name3");
        verify(mockCpBands).getConstant(1);
        verify(mockCpBands).getConstant(2.0);
        verify(mockCpBands).getCPSignature("signature1");
        verify(mockCpBands).getCPUtf8("utf8Str1");
        verify(mockCpBands).getCPUtf8("utf8Str2");
        verify(mockCpBands).getCPSignature("Ljava/lang/Object;");
        verify(mockCpBands).getCPUtf8("utf8Str3");
        verify(mockCpBands).getCPSignature("Ljava/util/Set;");
        verify(mockCpBands).getCPSignature("Ljava/util/Map;");
        verify(mockCpBands).getCPUtf8("nestedSet");
        verify(mockCpBands).getCPUtf8("nestedMap");
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(3, metadataBandGroup.pair_N.size());
        assertEquals(3, metadataBandGroup.name_RU.size());
        assertEquals(8, metadataBandGroup.T.size());
        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertEquals(1, metadataBandGroup.caseD_KD.size());
        assertEquals(1, metadataBandGroup.casec_RS.size());
        assertEquals(1, metadataBandGroup.caseet_RS.size());
        assertEquals(1, metadataBandGroup.caseec_RU.size());
        assertEquals(1, metadataBandGroup.cases_RU.size());
        assertEquals(2, metadataBandGroup.casearray_N.size());
        assertEquals(2, metadataBandGroup.nesttype_RS.size());
        assertEquals(2, metadataBandGroup.nestpair_N.size());
        assertEquals(2, metadataBandGroup.nestname_RU.size());
        assertEquals(3, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithSingleTag() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("Z");
        List<Object> values = Arrays.asList(true);
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getConstant(true)).thenReturn(new CPConstant<>(true));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getConstant(true);
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(1, metadataBandGroup.T.size());
        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertTrue(metadataBandGroup.caseD_KD.isEmpty());
        assertTrue(metadataBandGroup.casec_RS.isEmpty());
        assertTrue(metadataBandGroup.caseet_RS.isEmpty());
        assertTrue(metadataBandGroup.caseec_RU.isEmpty());
        assertTrue(metadataBandGroup.cases_RU.isEmpty());
        assertTrue(metadataBandGroup.casearray_N.isEmpty());
        assertTrue(metadataBandGroup.nesttype_RS.isEmpty());
        assertTrue(metadataBandGroup.nestpair_N.isEmpty());
        assertTrue(metadataBandGroup.nestname_RU.isEmpty());
        assertEquals(0, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithRepeatedTags() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("I", "I", "I");
        List<Object> values = Arrays.asList(10, 20, 30);
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getConstant(10)).thenReturn(new CPConstant<>(10));
        when(mockCpBands.getConstant(20)).thenReturn(new CPConstant<>(20));
        when(mockCpBands.getConstant(30)).thenReturn(new CPConstant<>(30));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getConstant(10);
        verify(mockCpBands).getConstant(20);
        verify(mockCpBands).getConstant(30);
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(3, metadataBandGroup.T.size());
        assertEquals(3, metadataBandGroup.caseI_KI.size());
        assertTrue(metadataBandGroup.caseD_KD.isEmpty());
        assertTrue(metadataBandGroup.casec_RS.isEmpty());
        assertTrue(metadataBandGroup.caseet_RS.isEmpty());
        assertTrue(metadataBandGroup.caseec_RU.isEmpty());
        assertTrue(metadataBandGroup.cases_RU.isEmpty());
        assertTrue(metadataBandGroup.casearray_N.isEmpty());
        assertTrue(metadataBandGroup.nesttype_RS.isEmpty());
        assertTrue(metadataBandGroup.nestpair_N.isEmpty());
        assertTrue(metadataBandGroup.nestname_RU.isEmpty());
        assertEquals(0, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithCaseArrayN() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("[", "I", "D");
        List<Object> values = Arrays.asList(2, 100, 200.0);
        List<Integer> caseArrayN = Arrays.asList(2);
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getConstant(100)).thenReturn(new CPConstant<>(100));
        when(mockCpBands.getConstant(200.0)).thenReturn(new CPConstant<>(200.0));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getConstant(100);
        verify(mockCpBands).getConstant(200.0);
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(3, metadataBandGroup.T.size());
        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertEquals(1, metadataBandGroup.caseD_KD.size());
        assertEquals(1, metadataBandGroup.casearray_N.size());
        assertEquals(2, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithMultipleCaseArrayN() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("[", "I", "D", "[", "F", "J");
        List<Object> values = Arrays.asList(2, 100, 200.0, 1, 3.14f, 400L);
        List<Integer> caseArrayN = Arrays.asList(2, 1);
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getConstant(100)).thenReturn(new CPConstant<>(100));
        when(mockCpBands.getConstant(200.0)).thenReturn(new CPConstant<>(200.0));
        when(mockCpBands.getConstant(3.14f)).thenReturn(new CPConstant<>(3.14f));
        when(mockCpBands.getConstant(400L)).thenReturn(new CPConstant<>(400L));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getConstant(100);
        verify(mockCpBands).getConstant(200.0);
        verify(mockCpBands).getConstant(3.14f);
        verify(mockCpBands).getConstant(400L);
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(6, metadataBandGroup.T.size());
        assertEquals(1, metadataBandGroup.caseI_KI.size());
        assertEquals(1, metadataBandGroup.caseD_KD.size());
        assertEquals(1, metadataBandGroup.caseF_KF.size());
        assertEquals(1, metadataBandGroup.caseJ_KJ.size());
        assertEquals(2, metadataBandGroup.casearray_N.size());
        assertEquals(3, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithNestedAnnotations() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("@", "c");
        List<Object> values = Arrays.asList("Ljava/util/List;", "signatureNested");
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Arrays.asList("Ljava/util/List;");
        List<String> nestNameRU = Arrays.asList("nestedSignature");
        List<Integer> nestPairN = Arrays.asList(1);

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getCPSignature("Ljava/util/List;")).thenReturn(new CPSignature("Ljava/util/List;"));
        when(mockCpBands.getCPSignature("signatureNested")).thenReturn(new CPSignature("signatureNested"));
        when(mockCpBands.getCPUtf8("nestedSignature")).thenReturn(new CPUtf8("nestedSignature"));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getCPSignature("Ljava/util/List;");
        verify(mockCpBands).getCPSignature("signatureNested");
        verify(mockCpBands).getCPUtf8("nestedSignature");
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(2, metadataBandGroup.T.size());
        assertEquals(0, metadataBandGroup.caseI_KI.size());
        assertEquals(0, metadataBandGroup.caseD_KD.size());
        assertEquals(1, metadataBandGroup.casec_RS.size());
        assertEquals(1, metadataBandGroup.caseet_RS.size());
        assertEquals(1, metadataBandGroup.caseec_RU.size());
        assertEquals(0, metadataBandGroup.cases_RU.size());
        assertEquals(0, metadataBandGroup.casearray_N.size());
        assertEquals(1, metadataBandGroup.nesttype_RS.size());
        assertEquals(1, metadataBandGroup.nestpair_N.size());
        assertEquals(1, metadataBandGroup.nestname_RU.size());
        assertEquals(1, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithMultipleNestedAnnotations() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1");
        List<String> tags = Arrays.asList("@", "@", "c", "e");
        List<Object> values = Arrays.asList("Ljava/util/List;", "Ljava/util/Map;", "signature1", "signature2", "utf8Str1", "utf8Str2");
        List<Integer> caseArrayN = Arrays.asList(1, 2);
        List<String> nestTypeRS = Arrays.asList("Ljava/util/List;", "Ljava/util/Map;");
        List<String> nestNameRU = Arrays.asList("nestedList", "nestedMap");
        List<Integer> nestPairN = Arrays.asList(1, 2);

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getCPSignature("Ljava/util/List;")).thenReturn(new CPSignature("Ljava/util/List;"));
        when(mockCpBands.getCPSignature("Ljava/util/Map;")).thenReturn(new CPSignature("Ljava/util/Map;"));
        when(mockCpBands.getCPSignature("signature1")).thenReturn(new CPSignature("signature1"));
        when(mockCpBands.getCPSignature("signature2")).thenReturn(new CPSignature("signature2"));
        when(mockCpBands.getCPUtf8("utf8Str1")).thenReturn(new CPUtf8("utf8Str1"));
        when(mockCpBands.getCPUtf8("utf8Str2")).thenReturn(new CPUtf8("utf8Str2"));
        when(mockCpBands.getCPUtf8("nestedList")).thenReturn(new CPUtf8("nestedList"));
        when(mockCpBands.getCPUtf8("nestedMap")).thenReturn(new CPUtf8("nestedMap"));

        metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getCPSignature("Ljava/util/List;");
        verify(mockCpBands).getCPSignature("Ljava/util/Map;");
        verify(mockCpBands).getCPSignature("signature1");
        verify(mockCpBands).getCPSignature("signature2");
        verify(mockCpBands).getCPUtf8("utf8Str1");
        verify(mockCpBands).getCPUtf8("utf8Str2");
        verify(mockCpBands).getCPUtf8("nestedList");
        verify(mockCpBands).getCPUtf8("nestedMap");
        verifyNoMoreInteractions(mockCpBands);

        assertEquals(1, metadataBandGroup.type_RS.size());
        assertEquals(1, metadataBandGroup.pair_N.size());
        assertEquals(1, metadataBandGroup.name_RU.size());
        assertEquals(4, metadataBandGroup.T.size());
        assertEquals(0, metadataBandGroup.caseI_KI.size());
        assertEquals(0, metadataBandGroup.caseD_KD.size());
        assertEquals(1, metadataBandGroup.casec_RS.size());
        assertEquals(1, metadataBandGroup.caseet_RS.size());
        assertEquals(2, metadataBandGroup.caseec_RU.size());
        assertEquals(0, metadataBandGroup.cases_RU.size());
        assertEquals(2, metadataBandGroup.casearray_N.size());
        assertEquals(2, metadataBandGroup.nesttype_RS.size());
        assertEquals(2, metadataBandGroup.nestpair_N.size());
        assertEquals(2, metadataBandGroup.nestname_RU.size());
        assertEquals(3, metadataBandGroup.numBackwardsCalls());
    }

    @Test
    void testAddAnnotationWithEmptyValuesForTags() {
        String desc = "Ljava/lang/String;";
        List<String> nameRU = Arrays.asList("name1", "name2");
        List<String> tags = Arrays.asList("c", "e");
        List<Object> values = Arrays.asList();
        List<Integer> caseArrayN = Collections.emptyList();
        List<String> nestTypeRS = Collections.emptyList();
        List<String> nestNameRU = Collections.emptyList();
        List<Integer> nestPairN = Collections.emptyList();

        when(mockCpBands.getCPSignature(desc)).thenReturn(new CPSignature(desc));
        when(mockCpBands.getCPUtf8("name1")).thenReturn(new CPUtf8("name1"));
        when(mockCpBands.getCPUtf8("name2")).thenReturn(new CPUtf8("name2"));

        assertThrows(java.util.NoSuchElementException.class, () -> {
            metadataBandGroup.addAnnotation(desc, nameRU, tags, values, caseArrayN, nestTypeRS, nestNameRU, nestPairN);
        });

        verify(mockCpBands).getCPSignature(desc);
        verify(mockCpBands).getCPUtf8("name1");
        verify(mockCpBands).getCPUtf8("name2");
    }

}