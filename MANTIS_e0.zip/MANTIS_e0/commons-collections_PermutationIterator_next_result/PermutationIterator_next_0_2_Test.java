package org.apache.commons.collections4.iterators;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

public class PermutationIterator_next_0_2_Test {

    private static <E> PermutationIterator<E> createIteratorWithFields(int[] keys, boolean[] directions, List<E> nextPermutation) throws Exception {
        // Mock a PermutationIterator with injected fields
        PermutationIterator<E> iterator = new PermutationIterator<>(List.of());
        
        // Use reflection to set private fields
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        
        keysField.setAccessible(true);
        directionField.setAccessible(true);
        nextPermutationField.setAccessible(true);
        
        keysField.set(iterator, keys);
        directionField.set(iterator, directions);
        nextPermutationField.set(iterator, new ArrayList<>(nextPermutation));
        
        return iterator;
    }

    @Test
    @DisplayName("next() sets nextPermutation to null when largestKey is -1 and returns current nextPermutation")
    public void TC06_next_setsNextPermutationToNull_whenLargestKeyIsMinusOne() throws Exception {
        // GIVEN
        int[] keys = {3, 2, 1}; // Assuming this configuration leads to largestKey = -1
        boolean[] direction = {false, false, false};
        List<Integer> mockNextPermutation = List.of(3, 2, 1);
        PermutationIterator<Integer> iterator = createIteratorWithFields(keys, direction, mockNextPermutation);
        
        // WHEN
        List<Integer> result = iterator.next();
        
        // THEN
        // Assert the returned result is equal to the original nextPermutation
        assertEquals(mockNextPermutation, result, "The returned permutation should match the current nextPermutation.");
        // Assert that nextPermutation is set to null
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        assertNull(nextPermutationField.get(iterator), "nextPermutation should be set to null after calling next().");
    }

    @Test
    @DisplayName("next() handles direction[i18] == true and swaps keys accordingly")
    public void TC07_next_handlesDirectionTrue_swapsKeysCorrectly() throws Exception {
        // GIVEN
        int[] keys = {1, 3, 2}; // Configuration where direction[i18] == true
        boolean[] direction = {true, true, true};
        List<Integer> expectedNextPermutation = List.of(1, 2, 3);
        PermutationIterator<Integer> iterator = createIteratorWithFields(keys, direction, expectedNextPermutation);
        
        // WHEN
        List<Integer> result = iterator.next();
        
        // THEN
        // Assert that keys have been swapped in the positive direction
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] updatedKeys = (int[]) keysField.get(iterator);
        assertArrayEquals(new int[]{1, 2, 3}, updatedKeys, "Keys should be swapped in the positive direction correctly.");
        // Assert the next permutation is returned correctly
        assertEquals(expectedNextPermutation, result, "The returned permutation should match the expected nextPermutation.");
    }

    @Test
    @DisplayName("next() handles direction[i18] == false and swaps keys accordingly")
    public void TC08_next_handlesDirectionFalse_swapsKeysCorrectly() throws Exception {
        // GIVEN
        int[] keys = {3, 1, 2}; // Configuration where direction[i18] == false
        boolean[] direction = {false, false, false};
        List<Integer> expectedNextPermutation = List.of(2, 1, 3);
        PermutationIterator<Integer> iterator = createIteratorWithFields(keys, direction, expectedNextPermutation);
        
        // WHEN
        List<Integer> result = iterator.next();
        
        // THEN
        // Assert that keys have been swapped in the negative direction
        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        int[] updatedKeys = (int[]) keysField.get(iterator);
        assertArrayEquals(new int[]{2, 1, 3}, updatedKeys, "Keys should be swapped in the negative direction correctly.");
        // Assert the next permutation is returned correctly
        assertEquals(expectedNextPermutation, result, "The returned permutation should match the expected nextPermutation.");
    }

    @Test
    @DisplayName("next() processes when i19 != -1 and updates nextPermutation to null")
    public void TC09_next_withI19NotMinusOne_updatesNextPermutationToNull() throws Exception {
        // GIVEN
        int[] keys = {1, 2, 3}; // Configuration leading to i19 != -1
        boolean[] direction = {true, true, true};
        List<Integer> mockNextPermutation = List.of(1, 2, 3);
        PermutationIterator<Integer> iterator = createIteratorWithFields(keys, direction, mockNextPermutation);
        
        // Set i19 via reflection to a valid index
        Field i19Field = PermutationIterator.class.getDeclaredField("i19");
        i19Field.setAccessible(true);
        i19Field.setInt(iterator, 1);
        
        // WHEN
        List<Integer> result = iterator.next();
        
        // THEN
        // Assert the returned result is equal to the original nextPermutation
        assertEquals(mockNextPermutation, result, "The returned permutation should match the current nextPermutation.");
        // Assert that nextPermutation is set to null
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        assertNull(nextPermutationField.get(iterator), "nextPermutation should be set to null after calling next().");
    }

    @Test
    @DisplayName("next() processes when i19 == -1 and direction is updated accordingly")
    public void TC10_next_withI19MinusOne_updatesDirectionAndNextPermutation() throws Exception {
        // GIVEN
        int[] keys = {1, 3, 2}; // Configuration leading to i19 == -1
        boolean[] direction = {true, true, true};
        List<Integer> mockNextPermutation = List.of(1, 3, 2);
        PermutationIterator<Integer> iterator = createIteratorWithFields(keys, direction, mockNextPermutation);
        
        // Set i19 via reflection to -1
        Field i19Field = PermutationIterator.class.getDeclaredField("i19");
        i19Field.setAccessible(true);
        i19Field.setInt(iterator, -1);
        
        // WHEN
        List<Integer> result = iterator.next();
        
        // THEN
        // Assert that direction has been updated correctly
        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] updatedDirection = (boolean[]) directionField.get(iterator);
        assertArrayEquals(new boolean[]{false, false, false}, updatedDirection, "Direction should be updated correctly.");
        // Assert that nextPermutation is set as expected
        Field expectedNextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        expectedNextPermutationField.setAccessible(true);
        List<Integer> expectedNextPermutation = List.of(2, 1, 3);
        assertEquals(expectedNextPermutation, expectedNextPermutationField.get(iterator), "nextPermutation should be updated as expected.");
        // Assert the returned permutation is correct
        assertEquals(mockNextPermutation, result, "The returned permutation should match the expected nextPermutation.");
    }

}