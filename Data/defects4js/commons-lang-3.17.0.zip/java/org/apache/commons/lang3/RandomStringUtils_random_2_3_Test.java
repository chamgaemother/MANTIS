package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Random;

public class RandomStringUtils_random_2_3_Test {

    @Test
    @DisplayName("random(count=5, start=0, end=0, letters=true, numbers=true, chars={@, #, $, %, A, 1, b, 2, C, 3}, random) generates alphanumerical string from specified chars")
    public void TC16() {
        // GIVEN
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = {'@', '#', '$', '%', 'A', '1', 'b', '2', 'C', '3'};
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(count, result.length(), "Result length should be equal to count.");
        String charsString = new String(chars);
        assertTrue(result.chars().allMatch(c -> Character.isLetterOrDigit(c) && charsString.indexOf(c) >= 0), "All characters should be alphanumerical and from the provided chars array");
    }

    @Test
    @DisplayName("random(count=1, start=0, end=0, letters=false, numbers=false, chars=null, random) generates single character within full Unicode range")
    public void TC17() {
        // GIVEN
        int count = 1;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(1, result.length(), "Result length should be 1.");
        int codePoint = result.codePointAt(0);
        assertTrue(codePoint >= 0 && codePoint <= Character.MAX_CODE_POINT, "Character should be within full Unicode range.");
        int type = Character.getType(codePoint);
        assertFalse(type == Character.UNASSIGNED, "Character should not be unassigned.");
        assertFalse(type == Character.PRIVATE_USE, "Character should not be private use.");
        assertFalse(Character.isSurrogate((char) codePoint), "Character should not be a surrogate.");
    }

    @Test
    @DisplayName("random(count=6, start=48, end=58, letters=false, numbers=true, chars={0,1,2,3,4,5}, random) generates numeric string from provided chars")
    public void TC18() {
        // GIVEN
        int count = 6;
        int start = 48;
        int end = 58;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = {'0', '1', '2', '3', '4', '5'};
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(count, result.length(), "Result length should be equal to count.");
        String charsString = new String(chars);
        assertTrue(result.chars().allMatch(c -> Character.isDigit(c) && charsString.indexOf(c) >= 0), "All characters should be digits from the provided chars array");
    }

    @Test
    @DisplayName("random(count=10, start=32, end=126, letters=true, numbers=true, chars=null, random) generates string with printable ASCII characters")
    public void TC19() {
        // GIVEN
        int count = 10;
        int start = 32;
        int end = 126;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(count, result.length(), "Result length should be equal to count.");
        assertTrue(result.chars().allMatch(c -> (Character.isLetterOrDigit(c) && c >= 32 && c <= 126)), "All characters should be printable ASCII letters or digits within the specified range");
    }

    @Test
    @DisplayName("random(count=10, start=32, end=126, letters=true, numbers=false, chars={A, B, C, 1, 2, 3}, random) generates string with only specified letters")
    public void TC20() {
        // GIVEN
        int count = 10;
        int start = 32;
        int end = 126;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = {'A', 'B', 'C', '1', '2', '3'};
        Random random = new Random();
        
        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        
        // THEN
        assertEquals(count, result.length(), "Result length should be equal to count.");
        String charsString = new String(chars);
        assertTrue(result.chars().allMatch(c -> (Character.isLetter(c) && charsString.indexOf(c) >= 0)), "All characters should be letters from the provided chars array");
    }

}