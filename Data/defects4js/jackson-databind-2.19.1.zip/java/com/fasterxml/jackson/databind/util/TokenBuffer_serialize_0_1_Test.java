package com.fasterxml.jackson.databind.util;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.util.TokenBuffer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import java.lang.reflect.Field;

import static org.mockito.Mockito.*;

public class TokenBuffer_serialize_0_1_Test {

    @Test
    @DisplayName("serialize with _mayHaveNativeIds false and no IDs present, zero iterations")
    public void TC01() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen, never()).writeObjectId(any());
        verify(gen, never()).writeTypeId(any());
        verify(gen, never()).writeStartObject();
        verify(gen, never()).writeEndObject();
    }

    @Test
    @DisplayName("serialize with _mayHaveNativeIds true but segment.hasIds false, single iteration")
    public void TC02() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, true);
        buffer.writeStartObject();
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeStartObject();
        verify(gen, never()).writeObjectId(any());
    }

    @Test
    @DisplayName("serialize with _mayHaveNativeIds true and segment.hasIds true, multiple iterations with mixed token types")
    public void TC03() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, true);
        buffer.writeStartObject();
        buffer.writeFieldName("name");
        buffer.writeString("John Doe");
        buffer.writeEndObject();

        // Using reflection to simulate hasIds
        Field firstSegmentField = TokenBuffer.class.getDeclaredField("_first");
        firstSegmentField.setAccessible(true);
        Object segment = firstSegmentField.get(buffer);

        Field nativeIdsField = segment.getClass().getDeclaredField("_nativeIds");
        nativeIdsField.setAccessible(true);
        if (nativeIdsField.get(segment) == null) {
            nativeIdsField.set(segment, new java.util.TreeMap<>());
        }

        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        InOrder inOrder = inOrder(gen);
        inOrder.verify(gen).writeStartObject();
        inOrder.verify(gen).writeFieldName("name");
        inOrder.verify(gen).writeString("John Doe");
        inOrder.verify(gen).writeEndObject();
    }

    @Test
    @DisplayName("serialize with segment.next() returning null after multiple segments, ensuring termination")
    public void TC04() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, true);
        buffer.writeStartObject();
        buffer.writeEndObject();
        buffer.writeStartArray();
        buffer.writeEndArray();
        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen).writeStartObject();
        verify(gen).writeEndObject();
        verify(gen).writeStartArray();
        verify(gen).writeEndArray();
    }

    @Test
    @DisplayName("serialize encounters null JsonToken type, leading to termination")
    public void TC05() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, false);
        buffer.writeNull(); // Writes a token with JsonToken.VALUE_NULL

        // Using reflection to set the token type to null to simulate corruption
        Field firstSegmentField = TokenBuffer.class.getDeclaredField("_first");
        firstSegmentField.setAccessible(true);
        Object segment = firstSegmentField.get(buffer);

        // Correct field name for the internal structure holding token types
        Field tokenTypesField = segment.getClass().getDeclaredField("_tokenTypes");
        tokenTypesField.setAccessible(true);
        // If there's a buffer for custom tokens, it should be something else than array
        long tokenTypes = tokenTypesField.getLong(segment);
        tokenTypes &= ~0xF; // Zero out the first 4 bits (first token type)
        tokenTypesField.setLong(segment, tokenTypes);

        JsonGenerator gen = mock(JsonGenerator.class);

        // WHEN
        buffer.serialize(gen);

        // THEN
        verify(gen, never()).writeNull();
    }
}