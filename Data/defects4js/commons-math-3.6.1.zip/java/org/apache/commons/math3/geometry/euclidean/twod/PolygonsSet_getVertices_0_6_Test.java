package org.apache.commons.math3.geometry.euclidean.twod;

import org.apache.commons.math3.geometry.partitioning.BSPTree;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class PolygonsSet_getVertices_0_6_Test {

    @Test
    @DisplayName("When a loop has exactly two segments with null start and end, it represents a single infinite line.")
    void TC26_getVertices_SingleInfiniteLine() throws Exception {
        // Initialize PolygonsSet with vertices = null
        PolygonsSet polygonsSet = new PolygonsSet();

        // Use reflection to set the private 'vertices' field to null
        Field verticesField = PolygonsSet.class.getDeclaredField("vertices");
        verticesField.setAccessible(true);
        verticesField.set(polygonsSet, null);

        // Directly set the vertices to represent a single infinite line
        Vector2D[] singleInfiniteLine = new Vector2D[] {
            null,
            new Vector2D(Double.NEGATIVE_INFINITY, 0),
            new Vector2D(Double.POSITIVE_INFINITY, 0)
        };
        Vector2D[][] expectedVertices = new Vector2D[][] { singleInfiniteLine };

        // Use reflection to set the 'vertices' directly to simulate scenario
        verticesField.set(polygonsSet, expectedVertices);

        // Invoke getVertices
        Vector2D[][] result = polygonsSet.getVertices();

        // Assert that the result matches the expected vertices
        assertArrayEquals(expectedVertices, result, "vertices array should represent a single infinite line");
    }
}
