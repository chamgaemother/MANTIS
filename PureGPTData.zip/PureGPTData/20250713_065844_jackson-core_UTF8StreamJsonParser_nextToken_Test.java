import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.BufferRecycler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

public class UTF8StreamJsonParserTest {
    private static final JsonFactory JSON_FACTORY = new JsonFactory();

    private BufferRecycler bufferRecycler;
    private ByteQuadsCanonicalizer symbols;
    private IOContext ioContext;

    @BeforeEach
    public void setup() {
        bufferRecycler = new BufferRecycler();
        ioContext = new IOContext(bufferRecycler, null, false);
        symbols = ByteQuadsCanonicalizer.createRoot().makeChild(0);
    }

    private UTF8StreamJsonParser createParser(byte[] input) throws IOException {
        InputStream inputStream = new ByteArrayInputStream(input);
        return new UTF8StreamJsonParser(ioContext, 0, inputStream, null, symbols, null, 0, 0, 0, false);
    }

    @Test
    public void testNextTokenForValidJson() throws IOException {
        byte[] input = "{\"key\":\"value\"}".getBytes();
        UTF8StreamJsonParser parser = createParser(input);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("key", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenForArray() throws IOException {
        byte[] input = "[1, 2, 3]".getBytes();
        UTF8StreamJsonParser parser = createParser(input);
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(3, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenForNestedStructures() throws IOException {
        byte[] input = "{\"array\":[true, false, null], \"object\":{\"key\":\"value\"}}".getBytes();
        UTF8StreamJsonParser parser = createParser(input);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("array", parser.getCurrentName());
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("object", parser.getCurrentName());
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("key", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenUnexpectedComma() throws IOException {
        byte[] input = "[1,]".getBytes();
        UTF8StreamJsonParser parser = createParser(input);
        parser.enable(JsonFactory.Feature.ALLOW_MISSING_VALUES);
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenUnexpectedEndOfFile() throws IOException {
        byte[] input = "{\"key\": \"value\",}".getBytes();
        UTF8StreamJsonParser parser = createParser(input);
        parser.enable(JsonFactory.Feature.ALLOW_MISSING_VALUES);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertDoesNotThrow(new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.nextToken();
            }
        });
    }

    @Test
    public void testNextTokenWithCommentsEnabled() throws IOException {
        byte[] input = "[1, /* comment */ 2, // comment\n3]".getBytes();
        UTF8StreamJsonParser parser = createParser(input);
        parser.enable(JsonFactory.Feature.ALLOW_COMMENTS);
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(3, parser.getIntValue());
        assertEquals(JsonToken.END_ARRAY, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenWithSingleQuotesEnabled() throws IOException {
        byte[] input = "{'key': 'value'}".getBytes();
        UTF8StreamJsonParser parser = createParser(input);
        parser.enable(JsonFactory.Feature.ALLOW_SINGLE_QUOTES);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
        assertEquals("key", parser.getCurrentName());
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
        assertEquals("value", parser.getText());
        assertEquals(JsonToken.END_OBJECT, parser.nextToken());
        assertNull(parser.nextToken());
    }

    @Test
    public void testNextTokenInvalidToken() throws IOException {
        byte[] input = "[1, 2, unknown]".getBytes();
        UTF8StreamJsonParser parser = createParser(input);

        // Parse until failure
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(1, parser.getIntValue());
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
        assertEquals(2, parser.getIntValue());

        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.nextToken();
            }
        });
    }
}