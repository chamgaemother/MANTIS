package org.jsoup.select;

import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeFilter.FilterResult;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NodeTraversor_filter_2_1_Test {

    @Test
    @DisplayName("filter returns REMOVE during tail processing when node has no siblings")
    void testTC23() {
        // GIVEN
        Element root = new Element("root");
        Element child = new Element("child");
        root.appendChild(child);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.REMOVE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(0, root.childNodeSize(), "Child node should be removed");
        assertEquals(FilterResult.CONTINUE, result, "FilterResult should be CONTINUE");
    }

    @Test
    @DisplayName("filter returns SKIP_CHILDREN and continues traversal")
    void testTC24() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element grandchild1 = new Element("grandchild1");
        child1.appendChild(grandchild1);
        root.appendChild(child1);
        root.appendChild(child2);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.equals(child1)) {
                    return FilterResult.SKIP_CHILDREN;
                }
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        // grandchild1 should remain as SKIP_CHILDREN does not remove nodes
        assertEquals(2, root.childNodeSize(), "Root should still have two children");
        assertNotNull(root.child(0).childNode(0), "child1 should still have its grandchild");
        assertEquals(FilterResult.CONTINUE, result, "FilterResult should be CONTINUE");
    }

    @Test
    @DisplayName("filter returns REMOVE during head processing with multiple iterations")
    void testTC25() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element child3 = new Element("child3");
        root.appendChild(child1);
        root.appendChild(child2);
        root.appendChild(child3);

        NodeFilter filter = new NodeFilter() {
            private int count = 0;

            @Override
            public FilterResult head(Node node, int depth) {
                if (node.equals(child1) || node.equals(child2)) {
                    count++;
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(1, root.childNodeSize(), "Only child3 should remain");
        assertEquals(child3, root.child(0), "Remaining child should be child3");
        assertEquals(FilterResult.CONTINUE, result, "FilterResult should be CONTINUE");
    }

    @Test
    @DisplayName("filter stops traversal after skipping children in tail processing")
    void testTC26() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        Element grandchild1 = new Element("grandchild1");
        Element grandchild2 = new Element("grandchild2");
        child1.appendChild(grandchild1);
        child2.appendChild(grandchild2);
        root.appendChild(child1);
        root.appendChild(child2);

        NodeFilter filter = new NodeFilter() {
            private boolean stopCalled = false;

            @Override
            public FilterResult head(Node node, int depth) {
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                if (node.equals(child1)) {
                    return FilterResult.SKIP_CHILDREN;
                }
                if (node.equals(child2) && !stopCalled) {
                    stopCalled = true;
                    return FilterResult.STOP;
                }
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        // Both children should still exist
        assertEquals(2, root.childNodeSize(), "Root should still have two children");
        assertEquals(FilterResult.STOP, result, "FilterResult should be STOP");
    }

    @Test
    @DisplayName("filter handles CONTINUE and REMOVE in combination")
    void testTC27() {
        // GIVEN
        Element root = new Element("root");
        Element child1 = new Element("child1");
        Element child2 = new Element("child2");
        root.appendChild(child1);
        root.appendChild(child2);

        NodeFilter filter = new NodeFilter() {
            @Override
            public FilterResult head(Node node, int depth) {
                if (node.equals(child1)) {
                    return FilterResult.REMOVE;
                }
                return FilterResult.CONTINUE;
            }

            @Override
            public FilterResult tail(Node node, int depth) {
                return FilterResult.CONTINUE;
            }
        };

        // WHEN
        FilterResult result = NodeTraversor.filter(filter, root);

        // THEN
        assertEquals(1, root.childNodeSize(), "Only child2 should remain");
        assertEquals(child2, root.child(0), "Remaining child should be child2");
        assertEquals(FilterResult.CONTINUE, result, "FilterResult should be CONTINUE");
    }
}