package org.apache.commons.math3.dfp;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Dfp_toDouble_1_2_Test {

    @Test
    @DisplayName("TC19 toDouble handles mantissa rounding up to nearest double representation")
    void testTC19_toDouble_mantissa_rounding_up() throws Exception {
        // Initialize DfpField with a specific precision (e.g., 5 digits)
        Constructor<DfpField> fieldConstructor = DfpField.class.getDeclaredConstructor(int.class);
        fieldConstructor.setAccessible(true);
        DfpField field = fieldConstructor.newInstance(5);

        // Create a new Dfp instance using reflection
        Method newInstanceMethod = DfpField.class.getMethod("newInstance");
        Dfp dfp = (Dfp) newInstanceMethod.invoke(field);

        // Access and set the 'mant' field via reflection
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = {9999, 9999, 9999, 9999, 9999}; // Mantissa requiring rounding up
        mantField.set(dfp, mantissa);

        // Access and set the 'exp' field via reflection
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(dfp, 0); // Exponent

        // Access and set the 'sign' field via reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(dfp, (byte) 1); // Positive sign

        // Invoke the toDouble method
        Method toDoubleMethod = Dfp.class.getMethod("toDouble");
        double result = (double) toDoubleMethod.invoke(dfp);

        // Define the expected rounded up value (calculated manually or known)
        double expected = 2.0; // Example expected value after rounding up

        // Assert that the result is as expected
        assertEquals(expected, result, "toDouble should correctly round up the mantissa.");
    }

    @Test
    @DisplayName("TC20 toDouble correctly converts a Dfp number with zero mantissa and non-zero exponent positive")
    void testTC20_toDouble_zero_mantissa_nonzero_exponent_positive() throws Exception {
        // Initialize DfpField with a specific precision (e.g., 5 digits)
        Constructor<DfpField> fieldConstructor = DfpField.class.getDeclaredConstructor(int.class);
        fieldConstructor.setAccessible(true);
        DfpField field = fieldConstructor.newInstance(5);

        // Create a new Dfp instance using reflection
        Method newInstanceMethod = DfpField.class.getMethod("newInstance");
        Dfp dfp = (Dfp) newInstanceMethod.invoke(field);

        // Access and set the 'mant' field via reflection to all zeros
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = {0, 0, 0, 0, 0};
        mantField.set(dfp, mantissa);

        // Access and set the 'exp' field via reflection to a non-zero value
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(dfp, 10); // Non-zero exponent

        // Access and set the 'sign' field via reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(dfp, (byte) 1); // Positive sign

        // Invoke the toDouble method
        Method toDoubleMethod = Dfp.class.getMethod("toDouble");
        double result = (double) toDoubleMethod.invoke(dfp);

        // Define the expected value
        double expected = 0.0;

        // Assert that the result is as expected
        assertEquals(expected, result, "toDouble should return 0.0 for zero mantissa with positive exponent.");
    }

    @Test
    @DisplayName("TC21 toDouble correctly converts a Dfp number with zero mantissa and non-zero exponent negative")
    void testTC21_toDouble_zero_mantissa_nonzero_exponent_negative() throws Exception {
        // Initialize DfpField with a specific precision (e.g., 5 digits)
        Constructor<DfpField> fieldConstructor = DfpField.class.getDeclaredConstructor(int.class);
        fieldConstructor.setAccessible(true);
        DfpField field = fieldConstructor.newInstance(5);

        // Create a new Dfp instance using reflection
        Method newInstanceMethod = DfpField.class.getMethod("newInstance");
        Dfp dfp = (Dfp) newInstanceMethod.invoke(field);

        // Access and set the 'mant' field via reflection to all zeros
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = {0, 0, 0, 0, 0};
        mantField.set(dfp, mantissa);

        // Access and set the 'exp' field via reflection to a non-zero value
        Field expField = Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.setInt(dfp, -10); // Non-zero exponent

        // Access and set the 'sign' field via reflection
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(dfp, (byte) -1); // Negative sign

        // Invoke the toDouble method
        Method toDoubleMethod = Dfp.class.getMethod("toDouble");
        double result = (double) toDoubleMethod.invoke(dfp);

        // Define the expected value
        double expected = -0.0;

        // Assert that the result is as expected
        assertEquals(expected, result, "toDouble should return -0.0 for zero mantissa with negative exponent.");
    }

}