// package org.jfree.chart.plot;
// import org.jfree.chart.ui.RectangleInsets;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// 
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.data.category.CategoryDataset;
// import org.jfree.data.category.DefaultCategoryDataset;
// import org.jfree.chart.LegendItemCollection;
// import org.jfree.chart.LegendItem;
// import org.jfree.chart.annotations.CategoryAnnotation;
// import org.jfree.chart.annotations.CategoryLabelAnnotation;
// 
// public class CategoryPlot_clone_1_3_Test {
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with all non-null datasets")
//     public void TC11_cloneWithAllNonNullDatasets() throws CloneNotSupportedException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         CategoryDataset dataset1 = new DefaultCategoryDataset();
//         CategoryDataset dataset2 = new DefaultCategoryDataset();
//         original.setDataset(0, dataset1);
//         original.setDataset(1, dataset2);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         assertNotNull(clone.getDataset(0), "Cloned dataset 0 should not be null");
//         assertNotNull(clone.getDataset(1), "Cloned dataset 1 should not be null");
//         assertNotSame(original.getDataset(0), clone.getDataset(0), "Dataset 0 should be cloned");
//         assertNotSame(original.getDataset(1), clone.getDataset(1), "Dataset 1 should be cloned");
//         assertEquals(original.getDataset(0), clone.getDataset(0), "Dataset 0 should be equal");
//         assertEquals(original.getDataset(1), clone.getDataset(1), "Dataset 1 should be equal");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with null fixedLegendItems")
//     public void TC12_cloneWithNullFixedLegendItems() throws CloneNotSupportedException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         original.setFixedLegendItems(null);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         assertNull(clone.getFixedLegendItems(), "Cloned fixedLegendItems should be null");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with non-null fixedLegendItems")
//     public void TC13_cloneWithNonNullFixedLegendItems() throws CloneNotSupportedException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         LegendItemCollection legendItems = new LegendItemCollection();
//         legendItems.add(new LegendItem("Series 1"));
//         original.setFixedLegendItems(legendItems);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         assertNotNull(clone.getFixedLegendItems(), "Cloned fixedLegendItems should not be null");
//         assertNotSame(original.getFixedLegendItems(), clone.getFixedLegendItems(), "fixedLegendItems should be cloned");
//         assertEquals(original.getFixedLegendItems(), clone.getFixedLegendItems(), "fixedLegendItems should be equal");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with empty annotations")
//     public void TC14_cloneWithEmptyAnnotations() throws CloneNotSupportedException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         original.clearAnnotations();
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         assertTrue(clone.getAnnotations().isEmpty(), "Cloned annotations should be empty");
//     }
// 
//     @Test
//     @DisplayName("Clone CategoryPlot with non-empty annotations")
//     public void TC15_cloneWithNonEmptyAnnotations() throws CloneNotSupportedException {
//         // GIVEN
//         CategoryPlot original = new CategoryPlot();
//         CategoryAnnotation annotation = new CategoryLabelAnnotation("Annotation 1", CategoryAnchor.MIDDLE, 0.5);
//         original.addAnnotation(annotation);
// 
//         // WHEN
//         CategoryPlot clone = (CategoryPlot) original.clone();
// 
//         // THEN
//         assertEquals(1, clone.getAnnotations().size(), "Cloned annotations should contain one element");
//         CategoryAnnotation clonedAnnotation = clone.getAnnotations().get(0);
//         assertNotSame(original.getAnnotations().get(0), clonedAnnotation, "Annotation should be cloned");
//         assertEquals(original.getAnnotations().get(0), clonedAnnotation, "Annotation should be equal");
//     }
// }