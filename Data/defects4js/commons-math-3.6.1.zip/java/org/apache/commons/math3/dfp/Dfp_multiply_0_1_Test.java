package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

public class Dfp_multiply_0_1_Test {

    @Test
    @DisplayName("Multiplying two finite Dfp numbers with equal radix digits")
    public void TC01() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 2.5);
        Dfp b = new Dfp(field, 4.0);
        Dfp expectedProduct = new Dfp(field, 10.0);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertEquals(expectedProduct, result, "The product should be equal to 10.0");
    }

    @Test
    @DisplayName("Multiplying Dfp numbers with unequal radix digits results in QNAN and FLAG_INVALID")
    public void TC02() throws Exception {
        // GIVEN
        DfpField field1 = new DfpField(10);
        DfpField field2 = new DfpField(12); // Different radix digits
        Dfp a = new Dfp(field1, 3.0);
        Dfp b = new Dfp(field2, 5.0);

        // Access private 'field' using reflection
        Field fieldA = Dfp.class.getDeclaredField("field");
        fieldA.setAccessible(true);
        DfpField dfpFieldA = (DfpField) fieldA.get(a);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertTrue(result.isNaN(), "Result should be NaN");

        // Access and verify FLAG_INVALID
        Method getIEEEFlagsBits = DfpField.class.getDeclaredMethod("getIEEEFlagsBits");
        getIEEEFlagsBits.setAccessible(true);
        long flags = (long) getIEEEFlagsBits.invoke(dfpFieldA);
        assertTrue((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should be set");
    }

    @Test
    @DisplayName("Multiplying when the first operand is NaN returns the first operand")
    public void TC03() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, Double.NaN);
        Dfp b = new Dfp(field, 5.0);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertEquals(a, result, "Result should be the first NaN operand");
    }

    @Test
    @DisplayName("Multiplying when the second operand is NaN returns the second operand")
    public void TC04() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 5.0);
        Dfp b = new Dfp(field, Double.NaN);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertEquals(b, result, "Result should be the second NaN operand");
    }

    @Test
    @DisplayName("Multiplying when both operands are NaN returns the first NaN operand")
    public void TC05() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, Double.NaN);
        Dfp b = new Dfp(field, Double.NaN);

        // WHEN
        Dfp result = a.multiply(b);

        // THEN
        assertEquals(a, result, "Result should be the first NaN operand when both are NaN");
    }
}