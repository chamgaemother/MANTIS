package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.TableXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYAreaRenderer_drawItem_0_3_Test {

//     @Test
//     @DisplayName("Verifies rendering without plot lines when getPlotLines() returns false")
//     void TC11_VerifiesRenderingWithoutPlotLines() throws Exception {
        // Arrange
//         XYAreaRenderer renderer = new XYAreaRenderer();
//         XYDataset dataset = mock(XYDataset.class);
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CrosshairState crosshairState = new CrosshairState();
// 
//         int series = 0;
//         int item = 0;
//         int pass = 0;
// 
        // Use reflection to set 'plotLines' to false
//         java.lang.reflect.Field plotLinesField = XYAreaRenderer.class.getDeclaredField("plotLines");
//         plotLinesField.setAccessible(true);
//         plotLinesField.set(renderer, false);
// 
        // Set plot mock returns
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getDomainAxisEdge()).thenReturn(ValueAxis.DEFAULT_AXIS_LOCATION);
//         when(plot.getRangeAxisEdge()).thenReturn(ValueAxis.DEFAULT_AXIS_LOCATION);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
// 
        // Assert
        // Verify that no lines are rendered
//         verify(g2, never()).draw(any());
//     }

    @Test
    @DisplayName("Handles last item in series with multiple items and plot area enabled")
    void TC12_HandlesLastItemInSeriesWithPlotArea() throws Exception {
        // Arrange
        XYAreaRenderer renderer = new XYAreaRenderer();

        // Set the private field 'plotArea' to true using reflection
        java.lang.reflect.Field plotAreaField = XYAreaRenderer.class.getDeclaredField("plotArea");
        plotAreaField.setAccessible(true);
        plotAreaField.set(renderer, true);

        XYDataset dataset = mock(TableXYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(3);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);

        CrosshairState crosshairState = new CrosshairState();

        int series = 0;
        int item = 2; // Last item
        int pass = 0;

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2).fill(any());
    }

    @Test
    @DisplayName("Throws exception when dataset is null")
    void TC13_ThrowsExceptionWhenDatasetIsNull() {
        // Arrange
        XYAreaRenderer renderer = new XYAreaRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CrosshairState crosshairState = new CrosshairState();

        int series = 0;
        int item = 0;
        int pass = 0;

        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, null, series, item, crosshairState, pass);
        });
    }

    @Test
    @DisplayName("Handles plot lines rendering when item index is greater than 0")
    void TC14_HandlesPlotLinesRendering() throws Exception {
        // Arrange
        XYAreaRenderer renderer = new XYAreaRenderer();
        java.lang.reflect.Field plotLinesField = XYAreaRenderer.class.getDeclaredField("plotLines");
        plotLinesField.setAccessible(true);
        plotLinesField.set(renderer, true);

        XYDataset dataset = mock(TableXYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(2);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);

        CrosshairState crosshairState = new CrosshairState();

        int series = 0;
        int item = 1; // Greater than 0
        int pass = 0;

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2).draw(any());
    }

    @Test
    @DisplayName("Handles outline drawing when isOutline() returns true")
    void TC15_HandlesOutlineDrawing() throws Exception {
        // Arrange
        XYAreaRenderer renderer = new XYAreaRenderer();
        java.lang.reflect.Field outlineField = XYAreaRenderer.class.getDeclaredField("showOutline");
        outlineField.setAccessible(true);
        outlineField.set(renderer, true);

        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(anyInt())).thenReturn(1);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);

        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(200.0);

        CrosshairState crosshairState = new CrosshairState();

        int series = 0;
        int item = 0;
        int pass = 0;

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2).draw(any());
        verify(g2).setStroke(any());
        verify(g2).setPaint(any());
    }

}