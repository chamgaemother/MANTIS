package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DfpTest {

    private final DfpField field = new DfpField(5); // Example with 5 radix digits

    @Test
    void testToDouble_InfinitePositive() {
        Dfp inf = new Dfp(field, (byte)1, Dfp.FINITE);
        inf.nans = Dfp.INFINITE;
        inf.sign = 1;
        double result = inf.toDouble();
        assertEquals(Double.POSITIVE_INFINITY, result);
    }

    @Test
    void testToDouble_InfiniteNegative() {
        Dfp inf = new Dfp(field, (byte)-1, Dfp.FINITE);
        inf.nans = Dfp.INFINITE;
        inf.sign = -1;
        double result = inf.toDouble();
        assertEquals(Double.NEGATIVE_INFINITY, result);
    }

    @Test
    void testToDouble_NaN() {
        Dfp nan = new Dfp(field, (byte)1, Dfp.QNAN);
        double result = nan.toDouble();
        assertTrue(Double.isNaN(result));
    }

    @Test
    void testToDouble_ZeroPositive() {
        Dfp zero = new Dfp(field);
        zero.mant = new int[field.getRadixDigits()];
        zero.sign = 1;
        zero.exp = 0;
        zero.nans = Dfp.FINITE;
        double result = zero.toDouble();
        assertEquals(+0.0, result, 0.0);
    }

    @Test
    void testToDouble_ZeroNegative() {
        Dfp zero = new Dfp(field);
        zero.mant = new int[field.getRadixDigits()];
        zero.sign = -1;
        zero.exp = 0;
        zero.nans = Dfp.FINITE;
        double result = zero.toDouble();
        assertEquals(-0.0, result, 0.0);
    }

    @Test
    void testToDouble_NormalPositive() {
        Dfp one = new Dfp(field, "1");
        double result = one.toDouble();
        assertEquals(1.0, result, 1e-10);
    }

    @Test
    void testToDouble_NormalNegative() {
        Dfp negOne = new Dfp(field, "-1");
        double result = negOne.toDouble();
        assertEquals(-1.0, result, 1e-10);
    }

    @Test
    void testToDouble_Overflow() {
        Dfp overflow = new Dfp(field, (byte)1, Dfp.FINITE);
        overflow.exp = Dfp.MAX_EXP + 1;
        overflow.mant[field.getRadixDigits() - 1] = 1;
        double result = overflow.toDouble();
        assertEquals(Double.POSITIVE_INFINITY, result);
    }

    @Test
    void testToDouble_Underflow() {
        Dfp underflow = new Dfp(field, (byte)1, Dfp.FINITE);
        underflow.exp = Dfp.MIN_EXP - field.getRadixDigits();
        underflow.mant = new int[field.getRadixDigits()];
        double result = underflow.toDouble();
        assertEquals(0.0, result, 0.0);
    }

    @Test
    void testToDouble_RoundUp() {
        Dfp value = new Dfp(field, "1.9999");
        double result = value.toDouble();
        assertEquals(1.9999, result, 1e-4);
    }

    @Test
    void testToDouble_RoundDown() {
        Dfp value = new Dfp(field, "1.0001");
        double result = value.toDouble();
        assertEquals(1.0001, result, 1e-4);
    }

    @Test
    void testToDouble_HighPrecision() {
        Dfp value = new Dfp(field, "12345.6789");
        double result = value.toDouble();
        assertEquals(12345.6789, result, 1e-4);
    }

    @Test
    void testToDouble_MinimumPositiveNormal() {
        Dfp minNormal = new Dfp(field, "2.2250738585072014E-308");
        double result = minNormal.toDouble();
        assertEquals(2.2250738585072014E-308, result, 1e-324);
    }

    @Test
    void testToDouble_MaximumFinite() {
        Dfp maxFinite = new Dfp(field, "1.7976931348623157E308");
        double result = maxFinite.toDouble();
        assertEquals(1.7976931348623157E308, result, 1e292);
    }

    @Test
    void testToDouble_SubnormalPositive() {
        Dfp subNormal = new Dfp(field, "4.9406564584124654E-324");
        double result = subNormal.toDouble();
        assertEquals(4.9406564584124654E-324, result, 1e-324);
    }

    @Test
    void testToDouble_SubnormalNegative() {
        Dfp subNormal = new Dfp(field, "-4.9406564584124654E-324");
        double result = subNormal.toDouble();
        assertEquals(-4.9406564584124654E-324, result, 1e-324);
    }

    @Test
    void testToDouble_SignZeroPositive() {
        Dfp zero = new Dfp(field);
        zero.sign = 1;
        zero.exp = 0;
        zero.nans = Dfp.FINITE;
        double result = zero.toDouble();
        assertEquals(+0.0, result, 0.0);
    }

    @Test
    void testToDouble_SignZeroNegative() {
        Dfp zero = new Dfp(field);
        zero.sign = -1;
        zero.exp = 0;
        zero.nans = Dfp.FINITE;
        double result = zero.toDouble();
        assertEquals(-0.0, result, 0.0);
    }

}