import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Stack;

class PrecedingOrFollowingContextTest {

    private EvalContext parentContext;
    private NodeTest nodeTest;
    private PrecedingOrFollowingContext context;
    private Stack<NodeIterator> stack;
    private NodePointer currentNodePointer;
    private NodePointer currentRootLocation;
    private NodePointer parentNode;
    private NodeIterator nodeIterator;

    @BeforeEach
    void setUp() {
        parentContext = mock(EvalContext.class);
        nodeTest = mock(NodeTest.class);
        
        currentNodePointer = mock(NodePointer.class);
        currentRootLocation = mock(NodePointer.class);
        parentNode = mock(NodePointer.class);
        nodeIterator = mock(NodeIterator.class);

        when(parentContext.getCurrentNodePointer()).thenReturn(currentRootLocation);
        when(currentRootLocation.getParent()).thenReturn(parentNode);
        when(currentRootLocation.isRoot()).thenReturn(false);

        stack = new Stack<>();
    }

    @Test
    void testNextNodeWithNothingInStackNoParent() {
        when(currentRootLocation.getParent()).thenReturn(null);

        context = new PrecedingOrFollowingContext(parentContext, nodeTest, false);

        assertFalse(context.nextNode());
    }

    @Test
    void testNextNodeWithNothingInStackRootReached() {
        when(currentRootLocation.getParent()).thenReturn(parentNode);
        when(parentNode.getParent()).thenReturn(null); // Reached root

        context = new PrecedingOrFollowingContext(parentContext, nodeTest, false);

        assertFalse(context.nextNode());
    }

    @Test
    void testNextNodeIteratesNodes() {
        when(nodeIterator.setPosition(anyInt())).thenReturn(true, false); // First true, then false
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(nodeTest.apply(currentNodePointer)).thenReturn(true);

        when(parentNode.childIterator(null, false, currentRootLocation)).thenReturn(nodeIterator);

        context = new PrecedingOrFollowingContext(parentContext, nodeTest, false);

        assertTrue(context.nextNode()); // First call to nextNode should return true
    }

    @Test
    void testNextNodeIteratesNodesReverse() {
        when(nodeIterator.setPosition(anyInt())).thenReturn(true, false); // First true, then false
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(nodeTest.apply(currentNodePointer)).thenReturn(true);

        when(parentNode.childIterator(null, true, currentRootLocation)).thenReturn(nodeIterator);

        context = new PrecedingOrFollowingContext(parentContext, nodeTest, true);

        assertTrue(context.nextNode()); // First call to nextNode should return true
    }

    @Test
    void testNextNodeWithStackClearsProperly() {
        stack.push(nodeIterator);
        context = new PrecedingOrFollowingContext(parentContext, nodeTest, false);

        context.nextNode();

        assertTrue(stack.isEmpty());
    }

    @Test
    void testNextNodeIteratesLeafs() {
        when(nodeIterator.setPosition(anyInt())).thenReturn(true, false); // First true, then false
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(nodeTest.apply(currentNodePointer)).thenReturn(true);
        when(currentNodePointer.isLeaf()).thenReturn(true);

        when(parentNode.childIterator(null, false, currentRootLocation)).thenReturn(nodeIterator);

        context = new PrecedingOrFollowingContext(parentContext, nodeTest, false);

        assertTrue(context.nextNode()); // Leaf node should return true since it matches nodeTest
    }

    @Test
    void testNextNodeRepeatsUntilAllNodesChecked() {
        when(nodeIterator.setPosition(anyInt())).thenReturn(false); // Always return false
        when(parentNode.childIterator(null, false, currentRootLocation)).thenReturn(nodeIterator);

        context = new PrecedingOrFollowingContext(parentContext, nodeTest, false);

        assertFalse(context.nextNode()); // Should complete and return false
    }
}