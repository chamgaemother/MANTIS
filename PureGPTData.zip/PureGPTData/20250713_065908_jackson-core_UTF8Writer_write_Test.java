import com.fasterxml.jackson.core.io.UTF8Writer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class UTF8WriterTest {
    private ByteArrayOutputStream outputStream;
    private UTF8Writer utf8Writer;
    private MockIOContext mockIOContext;

    @BeforeEach
    public void setUp() {
        outputStream = new ByteArrayOutputStream();
        mockIOContext = new MockIOContext();
        utf8Writer = new UTF8Writer(mockIOContext, outputStream);
    }

    @Test
    public void testWriteEmptyArray() {
        char[] emptyArray = {};
        assertDoesNotThrow(() -> utf8Writer.write(emptyArray, 0, 0));
    }

    @Test
    public void testWriteSingleAsciiCharacter() {
        char[] chars = {'A'};
        assertDoesNotThrow(() -> utf8Writer.write(chars, 0, 1));
    }
    
    @Test
    public void testWriteSingleMultiByteCharacter() {
        char[] chars = {'ñ'};
        assertDoesNotThrow(() -> utf8Writer.write(chars, 0, 1));
    }

    @Test
    public void testWriteSurrogatePair() {
        char[] chars = {0xD83D, 0xDE00}; // U+1F600 (😀)
        assertDoesNotThrow(() -> utf8Writer.write(chars, 0, 2));
    }

    @Test
    public void testWriteUnmatchedFirstSurrogate() {
        char[] chars = {0xD83D};
        assertThrows(IOException.class, () -> utf8Writer.write(chars, 0, 1));
    }

    @Test
    public void testWriteUnmatchedSecondSurrogate() {
        char[] chars = {0xDE00};
        assertThrows(IOException.class, () -> utf8Writer.write(chars, 0, 1));
    }

    @Test
    public void testWriteSurrogatePairsSplitAcrossTwoCalls() throws IOException {
        char[] firstPart = {0xD83D};
        char[] secondPart = {0xDE00};

        assertDoesNotThrow(() -> utf8Writer.write(firstPart, 0, 1));
        assertDoesNotThrow(() -> utf8Writer.write(secondPart, 0, 1));
    }

    @Test
    public void testEncodeAndFlush() throws IOException {
        char[] chars = "Hello, 世界!".toCharArray();
        utf8Writer.write(chars, 0, chars.length);
        utf8Writer.flush();  // To check flush path
    }

    @Test
    public void testWriteInvalidSurrogatePair() throws IOException {
        char[] chars = {0xD83D, 'A'}; // Second char not a low surrogate
        assertThrows(IOException.class, () -> utf8Writer.write(chars, 0, 2));
    }

    private class MockIOContext extends UTF8Writer.IOContext {
        public MockIOContext() {
            super(null, null, false);
        }

        @Override
        public byte[] allocWriteEncodingBuffer() {
            return new byte[256];
        }

        @Override
        public void releaseWriteEncodingBuffer(byte[] buf) {
            // Dummy method for testing
        }

        @Override
        public void close() {
            // Dummy method for testing
        }
    }
}