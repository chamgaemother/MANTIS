package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_1_8_Test {

    @Test
    @DisplayName("cls is primitive (int) and toClass is itself with autoboxing=false")
    void TC41() {
        Class<?> cls = int.class;
        Class<?> toClass = int.class;
        boolean autoboxing = false;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Long) and toClass is itself with autoboxing=true")
    void TC42() {
        Class<?> cls = Long.class;
        Class<?> toClass = Long.class;
        boolean autoboxing = true;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertTrue(result);
    }

    @Test
    @DisplayName("cls is equal to toClass (String) with autoboxing=false")
    void TC43() {
        Class<?> cls = String.class;
        Class<?> toClass = String.class;
        boolean autoboxing = false;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertTrue(result);
    }

    @Test
    @DisplayName("cls is equal to toClass (Integer) with autoboxing=true")
    void TC44() {
        Class<?> cls = Integer.class;
        Class<?> toClass = Integer.class;
        boolean autoboxing = true;

        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        assertTrue(result);
    }

}