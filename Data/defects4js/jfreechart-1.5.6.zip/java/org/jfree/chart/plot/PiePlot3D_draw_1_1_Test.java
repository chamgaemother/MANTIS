package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.PieSectionEntity;
import org.jfree.chart.labels.PieToolTipGenerator;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatcher;

public class PiePlot3D_draw_1_1_Test {

    @Test
    @DisplayName("When darkerSides is enabled, pie chart sides are rendered with darker colors")
    void TC06_darkerSidesEnabled_rendersDarkerSides() throws Exception {
        // GIVEN
        PiePlot3D piePlot3D = new PiePlot3D();
        piePlot3D.setDarkerSides(true);
        PieDataset dataset = new DefaultPieDataset();
        ((DefaultPieDataset) dataset).setValue("Category A", 30);
        ((DefaultPieDataset) dataset).setValue("Category B", 70);
        piePlot3D.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        Point2D anchor = new Point2D.Double(200, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // WHEN
        piePlot3D.draw(g2, plotArea, anchor, state, info);

        // THEN
        verify(g2, atLeastOnce()).setPaint(argThat(new ArgumentMatcher<Color>() {
            @Override
            public boolean matches(Color color) {
                return color != null && color.darker() != color;
            }
        }));
    }

    @Test
    @DisplayName("When depthFactor is set to zero, pie chart has no depth applied")
    void TC07_depthFactorZero_rendersFlatPieChart() throws Exception {
        // GIVEN
        PiePlot3D piePlot3D = new PiePlot3D();
        piePlot3D.setDepthFactor(0.0);
        PieDataset dataset = new DefaultPieDataset();
        ((DefaultPieDataset) dataset).setValue("Category X", 50);
        ((DefaultPieDataset) dataset).setValue("Category Y", 50);
        piePlot3D.setDataset(dataset);

        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 400, 300);
        Point2D anchor = new Point2D.Double(200, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // WHEN
        piePlot3D.draw(g2, plotArea, anchor, state, info);

        // THEN
        verify(g2, atLeastOnce()).fill(argThat(shape -> !(shape instanceof java.awt.Polygon)));
        verify(g2, never()).fill(argThat(shape -> shape instanceof java.awt.Polygon && ((java.awt.Polygon) shape).npoints > 0));
    }
}
