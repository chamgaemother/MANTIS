package org.jfree.chart.plot;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;

import org.jfree.chart.needle.ArrowNeedle;
import org.jfree.chart.needle.LineNeedle;
import org.jfree.chart.needle.LongNeedle;
import org.jfree.chart.needle.PinNeedle;
import org.jfree.chart.needle.PlumNeedle;
import org.jfree.chart.needle.PointerNeedle;
import org.jfree.chart.needle.ShipNeedle;
import org.jfree.chart.needle.WindNeedle;
import org.jfree.chart.needle.MiddlePinNeedle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CompassPlotTest {

    private CompassPlot plot;

    @BeforeEach
    public void setUp() {
        plot = new CompassPlot();
    }

    @Test
    public void testSetSeriesNeedle_Type0_ValidIndex() {
        plot.setSeriesNeedle(0, 0);
        assertTrue(plot.seriesNeedle[0] instanceof ArrowNeedle);
        assertEquals(Color.RED, plot.seriesNeedle[0].getFillPaint());
        assertEquals(Color.WHITE, plot.seriesNeedle[0].getHighlightPaint());
    }

    @Test
    public void testSetSeriesNeedle_Type0_InvalidIndex() {
        plot.setSeriesNeedle(1, 0);
        assertEquals(ArrowNeedle.class, plot.seriesNeedle[0].getClass());
    }

    @Test
    public void testSetSeriesNeedle_Type1_ValidIndex() {
        plot.setSeriesNeedle(0, 1);
        assertTrue(plot.seriesNeedle[0] instanceof LineNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type1_InvalidIndex() {
        plot.setSeriesNeedle(1, 1);
        assertTrue(plot.seriesNeedle[0] instanceof LineNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type2_ValidIndex() {
        plot.setSeriesNeedle(0, 2);
        assertTrue(plot.seriesNeedle[0] instanceof LongNeedle);
        assertEquals(0.5, ((LongNeedle) plot.seriesNeedle[0]).getRotateY());
    }

    @Test
    public void testSetSeriesNeedle_Type2_InvalidIndex() {
        plot.setSeriesNeedle(1, 2);
        assertTrue(plot.seriesNeedle[0] instanceof LongNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type3_ValidIndex() {
        plot.setSeriesNeedle(0, 3);
        assertTrue(plot.seriesNeedle[0] instanceof PinNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type3_InvalidIndex() {
        plot.setSeriesNeedle(1, 3);
        assertTrue(plot.seriesNeedle[0] instanceof PinNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type4_ValidIndex() {
        plot.setSeriesNeedle(0, 4);
        assertTrue(plot.seriesNeedle[0] instanceof PlumNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type4_InvalidIndex() {
        plot.setSeriesNeedle(1, 4);
        assertTrue(plot.seriesNeedle[0] instanceof PlumNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type5_ValidIndex() {
        plot.setSeriesNeedle(0, 5);
        assertTrue(plot.seriesNeedle[0] instanceof PointerNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type5_InvalidIndex() {
        plot.setSeriesNeedle(1, 5);
        assertTrue(plot.seriesNeedle[0] instanceof PointerNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type6_ValidIndex() {
        plot.setSeriesNeedle(0, 6);
        assertTrue(plot.seriesNeedle[0] instanceof ShipNeedle);
        assertNull(plot.seriesNeedle[0].getFillPaint());
        assertEquals(new java.awt.BasicStroke(3), plot.seriesNeedle[0].getOutlineStroke());
    }

    @Test
    public void testSetSeriesNeedle_Type6_InvalidIndex() {
        plot.setSeriesNeedle(1, 6);
        assertTrue(plot.seriesNeedle[0] instanceof ShipNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type7_ValidIndex() {
        plot.setSeriesNeedle(0, 7);
        assertTrue(plot.seriesNeedle[0] instanceof WindNeedle);
        assertEquals(Color.BLUE, plot.seriesNeedle[0].getFillPaint());
    }

    @Test
    public void testSetSeriesNeedle_Type7_InvalidIndex() {
        plot.setSeriesNeedle(1, 7);
        assertTrue(plot.seriesNeedle[0] instanceof WindNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type8_ValidIndex() {
        plot.setSeriesNeedle(0, 8);
        assertTrue(plot.seriesNeedle[0] instanceof ArrowNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type8_InvalidIndex() {
        plot.setSeriesNeedle(1, 8);
        assertTrue(plot.seriesNeedle[0] instanceof ArrowNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type9_ValidIndex() {
        plot.setSeriesNeedle(0, 9);
        assertTrue(plot.seriesNeedle[0] instanceof MiddlePinNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type9_InvalidIndex() {
        plot.setSeriesNeedle(1, 9);
        assertTrue(plot.seriesNeedle[0] instanceof MiddlePinNeedle);
    }

    @Test
    public void testSetSeriesNeedle_InvalidType() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            plot.setSeriesNeedle(0, -1);
        });
        assertEquals("Unrecognised type.", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            plot.setSeriesNeedle(0, 10);
        });
        assertEquals("Unrecognised type.", exception.getMessage());
    }

    @Test
    public void testSetSeriesNeedle_InvalidIndex_Type0() {
        plot.setSeriesNeedle(-1, 0);
        assertTrue(plot.seriesNeedle[0] instanceof ArrowNeedle);
    }

    @Test
    public void testSetSeriesNeedle_InvalidIndex_Type5() {
        plot.setSeriesNeedle(-1, 5);
        assertTrue(plot.seriesNeedle[0] instanceof PointerNeedle);
    }

    @Test
    public void testSetSeriesNeedle_Type0_NullPaints() {
        plot.setSeriesPaint(0, null);
        plot.setSeriesNeedle(0, 0);
        assertNull(plot.seriesNeedle[0].getFillPaint());
        assertNull(plot.seriesNeedle[0].getOutlinePaint());
    }

    @Test
    public void testSetSeriesNeedle_MultipleCalls() {
        plot.setSeriesNeedle(0, 1);
        assertTrue(plot.seriesNeedle[0] instanceof LineNeedle);
        plot.setSeriesNeedle(0, 5);
        assertTrue(plot.seriesNeedle[0] instanceof PointerNeedle);
    }

    @Test
    public void testSetSeriesNeedle_NullNeedleHandling() {
        plot.setSeriesNeedle(0, 6);
        plot.setSeriesPaint(0, null);
        assertNull(plot.seriesNeedle[0].getFillPaint());
    }
}