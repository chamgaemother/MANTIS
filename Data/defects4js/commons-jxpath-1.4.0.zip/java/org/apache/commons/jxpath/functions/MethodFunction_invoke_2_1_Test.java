package org.apache.commons.jxpath.functions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.functions.MethodFunction;
import org.apache.commons.jxpath.JXPathInvalidAccessException;

/**
 * JUnit 5 test class for MethodFunction.invoke covering scenarios TC18-TC22.
 */
public class MethodFunction_invoke_2_1_Test {

    @Test
    @DisplayName("invoke method when Modifier.isStatic returns false and parameters are null")
    void TC18_invokeNonStaticMethodWithNullParameters() throws Exception {
        // Arrange
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        Object[] parameters = null;
        Method method = ClassWithNonStaticMethod.class.getMethod("nonStaticMethod");
        MethodFunction methodFunction = new MethodFunction(method);

        // Act & Assert
        assertThrows(JXPathInvalidAccessException.class, () -> {
            methodFunction.invoke(context, parameters);
        });
    }

    @Test
    @DisplayName("invoke method when Modifier.isStatic returns false and parameters are insufficient")
    void TC19_invokeNonStaticMethodWithInsufficientParameters() throws Exception {
        // Arrange
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        Object[] parameters = new Object[]{"target"};
        Method method = ClassWithNonStaticMethodWithParams.class.getMethod("nonStaticMethodWithParams", String.class, String.class);
        MethodFunction methodFunction = new MethodFunction(method);

        // Act & Assert
        assertThrows(JXPathInvalidAccessException.class, () -> {
            methodFunction.invoke(context, parameters);
        });
    }

    @Test
    @DisplayName("invoke method with static method having ExpressionContext as first parameter")
    void TC20_invokeStaticMethodWithExpressionContext() throws Exception {
        // Arrange
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        Object[] parameters = new Object[]{"param1"};
        Method method = ClassWithStaticMethod.class.getMethod("staticMethodWithParams", ExpressionContext.class, String.class);
        MethodFunction methodFunction = new MethodFunction(method);

        // Act
        Object result = methodFunction.invoke(context, parameters);

        // Assert
        assertNotNull(result);
        assertEquals("Static Method with Params: param1", result);
    }

    @Test
    @DisplayName("invoke method with static method lacking ExpressionContext as first parameter and multiple parameters")
    void TC21_invokeStaticMethodWithoutExpressionContextMultipleParameters() throws Exception {
        // Arrange
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        Object[] parameters = new Object[]{"param1", "param2", "param3"};
        Method method = ClassWithStaticMethod.class.getMethod("staticMethod", String.class, String.class, String.class);
        MethodFunction methodFunction = new MethodFunction(method);

        // Act
        Object result = methodFunction.invoke(context, parameters);

        // Assert
        assertNotNull(result);
        assertEquals("Static Method with Params: param1param2param3", result);
    }

    @Test
    @DisplayName("invoke method and handle InvocationTargetException with null target")
    void TC22_invokeMethodHandleInvocationTargetException() throws Exception {
        // Arrange
        ExpressionContext context = Mockito.mock(ExpressionContext.class);
        Object[] parameters = new Object[]{"param1"};
        Method mockMethod = Mockito.mock(Method.class);
        Mockito.when(mockMethod.getModifiers()).thenReturn(java.lang.reflect.Modifier.STATIC);
        Mockito.when(mockMethod.invoke(null, parameters)).thenThrow(new InvocationTargetException(null));
        MethodFunction methodFunction = new MethodFunction(mockMethod);

        // Act & Assert
        JXPathInvalidAccessException exception = assertThrows(JXPathInvalidAccessException.class, () -> {
            methodFunction.invoke(context, parameters);
        });
        assertTrue(exception.getMessage().contains("Cannot invoke"));
        assertNull(exception.getCause());
    }

    // Helper classes for testing

    /**
     * Helper class with a non-static method.
     */
    public static class ClassWithNonStaticMethod {
        public Object nonStaticMethod() {
            return "Non-Static Method Invoked";
        }
    }

    /**
     * Helper class with a non-static method that accepts parameters.
     */
    public static class ClassWithNonStaticMethodWithParams {
        public Object nonStaticMethodWithParams(String param1, String param2) {
            return "Non-Static Method with Params: " + param1 + ", " + param2;
        }
    }

    /**
     * Helper class with static methods.
     */
    public static class ClassWithStaticMethod {
        public static Object staticMethodWithParams(ExpressionContext context, String param1) {
            return "Static Method with Params: " + param1;
        }

        public static Object staticMethod(String param1, String param2, String param3) {
            return "Static Method with Params: " + param1 + param2 + param3;
        }
    }
}