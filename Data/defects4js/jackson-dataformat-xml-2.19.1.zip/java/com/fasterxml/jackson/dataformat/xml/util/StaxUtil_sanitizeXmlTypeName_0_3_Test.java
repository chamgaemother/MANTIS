package com.fasterxml.jackson.dataformat.xml.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StaxUtil_sanitizeXmlTypeName_0_3_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName with name consisting only of '[]', returns 's'")
    void TC11() {
        // GIVEN
        String name = "[][]";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("s", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with name requiring no changes after character processing")
    void TC12() {
        // GIVEN
        String name = "Valid_Name-123";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("Valid_Name-123", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with name containing multiple '$' characters")
    void TC13() {
        // GIVEN
        String name = "Price$Value$USD";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("Price.Value.USD", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with name containing both '$' and disallowed characters")
    void TC14() {
        // GIVEN
        String name = "User$Name#1";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("User.Name_1", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with name containing hyphens and periods")
    void TC15() {
        // GIVEN
        String name = "Version-1.0";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("Version-1.0", result);
    }
}