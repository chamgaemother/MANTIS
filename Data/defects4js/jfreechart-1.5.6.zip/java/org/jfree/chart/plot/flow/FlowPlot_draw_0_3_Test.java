package org.jfree.chart.plot.flow;
import java.lang.reflect.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.jfree.data.flow.FlowDataset;
import org.jfree.data.flow.NodeKey;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.ui.RectangleInsets;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class FlowPlot_draw_0_3_Test {

    @Test
    @DisplayName("Verifies draw method applies insets correctly to the plotting area")
    void TC11_draw_appliesInsetsCorrectly() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        FlowPlot flowPlot = new FlowPlot(mock(FlowDataset.class)); // instantiated with a mocked dataset

        // Set insets using reflection
        Method getInsetsMethod = FlowPlot.class.getDeclaredMethod("getInsets");
        getInsetsMethod.setAccessible(true);
        RectangleInsets insets = new RectangleInsets(10, 20, 30, 40);
        Field insetsField = FlowPlot.class.getSuperclass().getDeclaredField("insets");
        insetsField.setAccessible(true);
        insetsField.set(flowPlot, insets);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        ArgumentCaptor<Rectangle2D> areaCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(info).setPlotArea(areaCaptor.capture());
        Rectangle2D adjustedArea = areaCaptor.getValue();
        assertEquals(area.getX() + insets.getLeft(), adjustedArea.getX(), "Left inset applied correctly");
        assertEquals(area.getY() + insets.getTop(), adjustedArea.getY(), "Top inset applied correctly");
        assertEquals(area.getWidth() - insets.getLeft() - insets.getRight(), adjustedArea.getWidth(), "Width inset applied correctly");
        assertEquals(area.getHeight() - insets.getTop() - insets.getBottom(), adjustedArea.getHeight(), "Height inset applied correctly");
    }

    @Test
    @DisplayName("Verifies draw method handles extremely large flow values without overflow")
    void TC12_draw_extremelyLargeFlowValues_noOverflow() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, Double.MAX_VALUE, Double.MAX_VALUE);
        Point2D point = new Point2D.Double(Double.MAX_VALUE / 2, Double.MAX_VALUE / 2);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(2);
        when(dataset.getSources(0)).thenReturn(List.of("Source1", "Source2"));
        when(dataset.getDestinations(0)).thenReturn(List.of("Destination1", "Destination2"));
        when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(Double.MAX_VALUE);
        when(dataset.getFlow(0, "Source1", "Destination2")).thenReturn(Double.MAX_VALUE);
        when(dataset.getFlow(0, "Source2", "Destination1")).thenReturn(Double.MAX_VALUE);
        when(dataset.getFlow(0, "Source2", "Destination2")).thenReturn(Double.MAX_VALUE);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

       // THEN
        // Sadly, we cannot directly access or verify private fields without reflection hacks
        // for field 'flow2d'. Thus, this step is blocked and left here for illustrative purposes.
        // Instead, main verification step should focus on ensuring method execution without exceptions
        // adding assertions in terms of flow2d implicitly observed through method behaviors.
        
        // Verify drawing performed to some extent to implicitly ensure calculations proceed
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    @DisplayName("Verifies draw method correctly colors nodes based on nodeColorMap")
    void TC13_draw_nodesColoredAccordingToMap() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(List.of("Source1", "Source2"));
        when(dataset.getDestinations(0)).thenReturn(List.of("Destination1", "Destination2"));
        when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(100.0);
        when(dataset.getFlow(0, "Source1", "Destination2")).thenReturn(150.0);
        when(dataset.getFlow(0, "Source2", "Destination1")).thenReturn(200.0);
        when(dataset.getFlow(0, "Source2", "Destination2")).thenReturn(250.0);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // Populate nodeColorMap
        Field nodeColorMapField = FlowPlot.class.getDeclaredField("nodeColorMap");
        nodeColorMapField.setAccessible(true);
        Map<NodeKey, Color> nodeColorMap = new HashMap<>();
        nodeColorMap.put(new NodeKey(0, "Source1"), Color.RED);
        nodeColorMap.put(new NodeKey(0, "Source2"), Color.BLUE);
        nodeColorMapField.set(flowPlot, nodeColorMap);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        // Verify that setPaint is called with correct colors
        verify(g2, times(2)).setPaint(any(Color.class));
        ArgumentCaptor<Color> colorCaptor = ArgumentCaptor.forClass(Color.class);
        verify(g2, times(2)).setPaint(colorCaptor.capture());
        assertTrue(colorCaptor.getAllValues().contains(Color.RED), "Source1 should be colored RED");
        assertTrue(colorCaptor.getAllValues().contains(Color.BLUE), "Source2 should be colored BLUE");
    }

    @Test
    @DisplayName("Verifies draw method assigns default color to nodes not present in nodeColorMap")
    void TC14_draw_nodesWithoutColorMapEntry_useDefaultColor() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(List.of("Source1", "Source2"));
        when(dataset.getDestinations(0)).thenReturn(List.of("Destination1", "Destination2"));
        when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(100.0);
        when(dataset.getFlow(0, "Source1", "Destination2")).thenReturn(150.0);
        when(dataset.getFlow(0, "Source2", "Destination1")).thenReturn(200.0);
        when(dataset.getFlow(0, "Source2", "Destination2")).thenReturn(250.0);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // Populate nodeColorMap with some entries
        Field nodeColorMapField = FlowPlot.class.getDeclaredField("nodeColorMap");
        nodeColorMapField.setAccessible(true);
        Map<NodeKey, Color> nodeColorMap = new HashMap<>();
        nodeColorMap.put(new NodeKey(0, "Source1"), Color.RED);
        nodeColorMapField.set(flowPlot, nodeColorMap);

        // Set defaultNodeColor
        Field defaultNodeColorField = FlowPlot.class.getDeclaredField("defaultNodeColor");
        defaultNodeColorField.setAccessible(true);
        defaultNodeColorField.set(flowPlot, Color.GREEN);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        // Verify that setPaint is called with RED for Source1 and GREEN for Source2
        ArgumentCaptor<Color> colorCaptor = ArgumentCaptor.forClass(Color.class);
        verify(g2, times(2)).setPaint(colorCaptor.capture());
        assertEquals(Color.RED, colorCaptor.getAllValues().get(0), "Source1 should be colored RED");
        assertEquals(Color.GREEN, colorCaptor.getAllValues().get(1), "Source2 should use default color GREEN");
    }

    @Test
    @DisplayName("Verifies draw method correctly iterates over sources and destinations within a stage")
    void TC15_draw_iteratesOverAllSourcesAndDestinations() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 800, 600);
        Point2D point = new Point2D.Double(400, 300);
        PlotState state = mock(PlotState.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);

        FlowDataset dataset = mock(FlowDataset.class);
        when(dataset.getStageCount()).thenReturn(1);
        when(dataset.getSources(0)).thenReturn(List.of("Source1", "Source2", "Source3"));
        when(dataset.getDestinations(0)).thenReturn(List.of("Destination1", "Destination2", "Destination3"));
        when(dataset.getFlow(0, "Source1", "Destination1")).thenReturn(100.0);
        when(dataset.getFlow(0, "Source1", "Destination2")).thenReturn(150.0);
        when(dataset.getFlow(0, "Source1", "Destination3")).thenReturn(200.0);
        when(dataset.getFlow(0, "Source2", "Destination1")).thenReturn(250.0);
        when(dataset.getFlow(0, "Source2", "Destination2")).thenReturn(300.0);
        when(dataset.getFlow(0, "Source2", "Destination3")).thenReturn(350.0);
        when(dataset.getFlow(0, "Source3", "Destination1")).thenReturn(400.0);
        when(dataset.getFlow(0, "Source3", "Destination2")).thenReturn(450.0);
        when(dataset.getFlow(0, "Source3", "Destination3")).thenReturn(500.0);

        FlowPlot flowPlot = new FlowPlot(dataset);

        // WHEN
        flowPlot.draw(g2, area, point, state, info);

        // THEN
        // Verify that setPaint and fill are called for each source-destination pair
        verify(g2, atLeast(9)).setPaint(any(Color.class));
        verify(g2, atLeast(9)).fill(any(Rectangle2D.class));
    }
}