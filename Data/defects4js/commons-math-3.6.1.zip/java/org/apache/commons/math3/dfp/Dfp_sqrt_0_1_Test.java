package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Dfp_sqrt_0_1_Test {

    @Test
    @DisplayName("sqrt() with finite input and mantissa last digit zero returns a new instance")
    void test_TC01() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field, 4.0); // Example finite value

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte FINITE = 0;
        nansField.setByte(input, FINITE);

        // Set mantissa last digit to 0
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = (int[]) mantField.get(input);
        mantissa[mantissa.length - 1] = 0;

        // Set sign to positive
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // When
        Dfp result = input.sqrt();

        // Then
        Method newInstanceMethod = Dfp.class.getDeclaredMethod("newInstance", Dfp.class);
        newInstanceMethod.setAccessible(true);
        Dfp expected = (Dfp)newInstanceMethod.invoke(input, input);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("sqrt() with finite input and mantissa last digit non-zero proceeds with computation")
    void test_TC02() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field, 3.0); // Example finite non-zero mantissa value

        // Set 'nans' to FINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte FINITE = 0;
        nansField.setByte(input, FINITE);

        // Set mantissa last digit to non-zero
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = (int[]) mantField.get(input);
        mantissa[mantissa.length - 1] = 1;

        // Set sign to positive
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // When
        Dfp result = input.sqrt();

        // Then
        // Assuming expectedComputationResult is predefined or computed
        Method newInstanceMethod = Dfp.class.getDeclaredMethod("newInstance", Dfp.class);
        newInstanceMethod.setAccessible(true);
        Dfp expected = (Dfp)newInstanceMethod.invoke(input, input);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("sqrt() with non-finite input as positive infinity returns a new instance")
    void test_TC03() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field, Double.POSITIVE_INFINITY);

        // Set 'nans' to INFINITE
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte INFINITE = 1;
        nansField.setByte(input, INFINITE);

        // Set mantissa (irrelevant for infinity, but initialized)
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = (int[]) mantField.get(input);
        mantissa[mantissa.length - 1] = 0;

        // Set sign to positive
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // When
        Dfp result = input.sqrt();

        // Then
        Method newInstanceMethod = Dfp.class.getDeclaredMethod("newInstance", Dfp.class);
        newInstanceMethod.setAccessible(true);
        Dfp expected = (Dfp)newInstanceMethod.invoke(input, input);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("sqrt() with non-finite input as QNaN returns a new instance")
    void test_TC04() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field, Double.NaN); // Example QNaN value

        // Set 'nans' to QNAN
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte QNAN = 3;
        nansField.setByte(input, QNAN);

        // Set mantissa (irrelevant for QNaN, but initialized)
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = (int[]) mantField.get(input);
        mantissa[mantissa.length - 1] = 0;

        // Set sign to positive
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // When
        Dfp result = input.sqrt();

        // Then
        Method newInstanceMethod = Dfp.class.getDeclaredMethod("newInstance", Dfp.class);
        newInstanceMethod.setAccessible(true);
        Dfp expected = (Dfp)newInstanceMethod.invoke(input, input);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("sqrt() with non-finite input as SNaN sets flags and traps, then returns result")
    void test_TC05() throws Exception {
        // Arrange
        DfpField field = new DfpField(10);
        Dfp input = new Dfp(field, Double.NaN); // Example SNaN value

        // Set 'nans' to SNAN
        Field nansField = Dfp.class.getDeclaredField("nans");
        nansField.setAccessible(true);
        byte SNAN = 2;
        nansField.setByte(input, SNAN);

        // Set mantissa (irrelevant for SNaN, but initialized)
        Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mantissa = (int[]) mantField.get(input);
        mantissa[mantissa.length - 1] = 0;

        // Set sign to positive
        Field signField = Dfp.class.getDeclaredField("sign");
        signField.setAccessible(true);
        signField.setByte(input, (byte)1);

        // When
        Dfp result = input.sqrt();

        // Then
        // Verify IEEE invalid flag is set
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        DfpField dfpField = (DfpField) fieldField.get(input);

        Method hasFlagMethod = DfpField.class.getDeclaredMethod("hasFlag", byte.class);
        hasFlagMethod.setAccessible(true);
        boolean hasInvalidFlag = (boolean) hasFlagMethod.invoke(dfpField, (byte)1); // FLAG_INVALID
        assertTrue(hasInvalidFlag, "IEEE invalid flag should be set");

        // Invoke dotrap and verify the result
        Method dotrapMethod = Dfp.class.getDeclaredMethod("dotrap", byte.class, String.class, Object.class, Dfp.class);
        dotrapMethod.setAccessible(true);
        Dfp dotrapResult = (Dfp) dotrapMethod.invoke(input, (byte)1, "sqrt", null, result);

        assertEquals(dotrapResult, result, "Result should equal the trapped result");
    }
}