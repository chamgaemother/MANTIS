package org.apache.commons.jxpath.util;

import org.apache.commons.jxpath.util.ValueUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.List;

public class ValueUtils_getValue_0_1_Test {

    @Test
    @DisplayName("getValue returns null when collection is null")
    public void TC01_getValueReturnsNullWhenCollectionIsNull() {
        // GIVEN
        Object collection = null;
        int index = 0;

        // WHEN
        Object result = ValueUtils.getValue(collection, index);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("getValue returns array element when collection is an array and index is within bounds")
    public void TC02_getValueReturnsArrayElementWhenIndexIsWithinBounds() {
        // GIVEN
        Object collection = new int[]{10, 20, 30};
        int index = 1;

        // WHEN
        Object result = ValueUtils.getValue(collection, index);

        // THEN
        assertEquals(20, result);
    }

    @Test
    @DisplayName("getValue returns null when collection is an array and index is negative")
    public void TC03_getValueReturnsNullWhenArrayIndexIsNegative() {
        // GIVEN
        Object collection = new int[]{10, 20, 30};
        int index = -1;

        // WHEN
        Object result = ValueUtils.getValue(collection, index);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("getValue returns null when collection is an array and index is out of bounds")
    public void TC04_getValueReturnsNullWhenArrayIndexIsOutOfBounds() {
        // GIVEN
        Object collection = new int[]{10, 20, 30};
        int index = 5;

        // WHEN
        Object result = ValueUtils.getValue(collection, index);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("getValue returns list element when collection is a List and index is within bounds")
    public void TC05_getValueReturnsListElementWhenIndexIsWithinBounds() {
        // GIVEN
        List<String> collection = Arrays.asList("a", "b", "c");
        int index = 1;

        // WHEN
        Object result = ValueUtils.getValue(collection, index);

        // THEN
        assertEquals("b", result);
    }
}