package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_1_1_Test {

    @Test
    @DisplayName("doubleMetaphone(\"ACCIENT\", false) handles 'CC' followed by 'I'")
    public void TC41_doubleMetaphone_ACCIENT() {
        // Initialize encoder
        DoubleMetaphone encoder = new DoubleMetaphone();
        
        // Input
        String input = "ACCIENT";
        
        // Execute
        String result = encoder.doubleMetaphone(input, false);
        
        // Assertion
        assertEquals("AXSNT", result, "'CCI' should be encoded as 'KS'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"BACHER\", false) handles 'CH' after 'B'")
    public void TC42_doubleMetaphone_BACHER() {
        // Initialize encoder
        DoubleMetaphone encoder = new DoubleMetaphone();
        
        // Input
        String input = "BACHER";
        
        // Execute
        String result = encoder.doubleMetaphone(input, false);
        
        // Assertion
        assertEquals("BKSR", result, "'CH' after 'B' should be encoded as 'K'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"EDGE\", false) handles 'DG' followed by 'E'")
    public void TC43_doubleMetaphone_EDGE() {
        // Initialize encoder
        DoubleMetaphone encoder = new DoubleMetaphone();
        
        // Input
        String input = "EDGE";
        
        // Execute
        String result = encoder.doubleMetaphone(input, false);
        
        // Assertion
        assertEquals("DJ", result, "'DGE' should be encoded as 'DJ'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"COACH\", false) handles 'CH' in the middle")
    public void TC44_doubleMetaphone_COACH() {
        // Initialize encoder
        DoubleMetaphone encoder = new DoubleMetaphone();
        
        // Input
        String input = "COACH";
        
        // Execute
        String result = encoder.doubleMetaphone(input, false);
        
        // Assertion
        assertEquals("KAX", result, "'CH' should be encoded as 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone(\"BELL\", false) handles double 'L'")
    public void TC45_doubleMetaphone_BELL() {
        // Initialize encoder
        DoubleMetaphone encoder = new DoubleMetaphone();
        
        // Input
        String input = "BELL";
        
        // Execute
        String result = encoder.doubleMetaphone(input, false);
        
        // Assertion
        assertEquals("BL", result, "Double 'L' should be encoded as single 'L'");
    }
}