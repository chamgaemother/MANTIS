import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;

public class MethodUtilsTest {

    private static class TestClass {
        public void publicMethod() {}
        protected void protectedMethod() {}
        @SuppressWarnings("unused")
        private void privateMethod() {}
        void defaultMethod() {}
        public void overloadedMethod(String param) {}
        public void overloadedMethod(Object param) {}
        public void varArgsMethod(String... args) {}
    }
    
    @Test
    public void testGetMatchingAccessibleMethod_NullClass() {
        Method result = MethodUtils.getMatchingAccessibleMethod(null, "publicMethod");
        assertNull(result);
    }
    
    @Test
    public void testGetMatchingAccessibleMethod_NullMethodName() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, null);
        assertNull(result);
    }

    @Test
    public void testGetMatchingAccessibleMethod_NoMethodFound() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "nonExistentMethod");
        assertNull(result);
    }

    @Test
    public void testGetMatchingAccessibleMethod_PublicMethod() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "publicMethod");
        assertNotNull(result);
        assertTrue(result.isAccessible());
    }

    @Test
    public void testGetMatchingAccessibleMethod_ProtectedMethod() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "protectedMethod");
        assertNull(result);
    }

    @Test
    public void testGetMatchingAccessibleMethod_PrivateMethod() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "privateMethod");
        assertNull(result);
    }

    @Test
    public void testGetMatchingAccessibleMethod_DefaultMethod() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "defaultMethod");
        assertNull(result);
    }

    @Test
    public void testGetMatchingAccessibleMethod_OverloadedMethod_String() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "overloadedMethod", String.class);
        assertNotNull(result);
        assertTrue(result.isAccessible());
        assertEquals(String.class, result.getParameterTypes()[0]);
    }
    
    @Test
    public void testGetMatchingAccessibleMethod_OverloadedMethod_Object() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "overloadedMethod", Object.class);
        assertNotNull(result);
        assertTrue(result.isAccessible());
        assertEquals(Object.class, result.getParameterTypes()[0]);
    }
    
    @Test
    public void testGetMatchingAccessibleMethod_VarArgsMethod() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "varArgsMethod", String[].class);
        assertNotNull(result);
        assertTrue(result.isAccessible());
        assertTrue(result.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleMethod_ExactMatchPreferred() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "overloadedMethod", Object.class);
        assertNotNull(result);
        assertEquals(Object.class, result.getParameterTypes()[0]);
    }
    
    @Test
    public void testGetMatchingAccessibleMethod_AdditionalNullEdgeCases() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "overloadedMethod", (Class<?>[]) null);
        assertNull(result);
    }

    @Test
    public void testGetMatchingAccessibleMethod_FullyQualifiedMethod() {
        Method result = MethodUtils.getMatchingAccessibleMethod(TestClass.class, "varArgsMethod", String.class);
        assertNull(result);
    }
}