package org.apache.commons.lang3.text;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class WordUtils_wrap_2_1_Test {

    @Test
    @DisplayName("wrap with wrapOn pattern that matches every character and wrapLongWords=true to ensure maximum wrapping")
    void test_TC30() {
        // GIVEN
        String str = "abcdef";
        int wrapLength = 1;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = ".";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        assertEquals("a\nb\nc\nd\ne\nf", result, "Each character should be wrapped with a newline.");
    }

    @Test
    @DisplayName("wrap with wrapOn pattern that never matches any characters and wrapLongWords=true to ensure entire string is broken into wrapLength segments")
    void test_TC31() {
        // GIVEN
        String str = "abcdefghijk";
        int wrapLength = 3;
        String newLineStr = "\n";
        boolean wrapLongWords = true;
        String wrapOn = "[XYZ]";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        assertEquals("abc\ndef\nghi\njk", result, "The string should be wrapped into segments of 3 characters each.");
    }

    @Test
    @DisplayName("wrap with multiple consecutive delimiters and wrapLongWords=false to ensure no word breaking and no empty lines")
    void test_TC32() {
        // GIVEN
        String str = "word1,,word2;;;word3..word4";
        int wrapLength = 10;
        String newLineStr = "\n";
        boolean wrapLongWords = false;
        String wrapOn = "[,;.]+";

        // WHEN
        String result = WordUtils.wrap(str, wrapLength, newLineStr, wrapLongWords, wrapOn);

        // THEN
        assertEquals("word1,,\nword2;;;\nword3..\nword4", result, "Wrapping should occur correctly at each delimiter without adding empty lines.");
    }
}