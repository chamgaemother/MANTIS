package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.analysis.UnivariateFunction;
import org.apache.commons.math3.analysis.polynomials.PolynomialSplineFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.util.MathArrays;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BicubicSplineInterpolator_interpolate_2_1_Test {

    @Test
    @DisplayName("Interpolate with initializeDerivatives set to false, ensuring derivatives are not initialized")
    void TC21_interpolate_without_derivative_initialization() throws NoDataException, DimensionMismatchException, NonMonotonicSequenceException, NumberIsTooSmallException {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {4.0, 5.0, 6.0};
        double[][] fval = {
            {7.0, 8.0, 9.0},
            {10.0, 11.0, 12.0},
            {13.0, 14.0, 15.0}
        };

        // WHEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator(false);
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The result should not be null");

        // Optionally verify that derivatives are not initialized
        // This requires reflection as initializeDerivatives is a private field
        try {
            java.lang.reflect.Field field = BicubicSplineInterpolator.class.getDeclaredField("initializeDerivatives");
            field.setAccessible(true);
            boolean initialized = field.getBoolean(interpolator);
            assertFalse(initialized, "Derivatives should not be initialized");
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("Interpolate with initializeDerivatives set to false and single-element arrays, ensuring no derivative calculations")
    void TC22_interpolate_with_single_element_arrays() throws NoDataException, DimensionMismatchException, NonMonotonicSequenceException, NumberIsTooSmallException {
        // GIVEN
        double[] xval = {1.0};
        double[] yval = {2.0};
        double[][] fval = {
            {3.0}
        };

        // WHEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator(false);
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The result should not be null");

        // Optionally verify that derivatives are not initialized
        try {
            java.lang.reflect.Field field = BicubicSplineInterpolator.class.getDeclaredField("initializeDerivatives");
            field.setAccessible(true);
            boolean initialized = field.getBoolean(interpolator);
            assertFalse(initialized, "Derivatives should not be initialized");
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("Interpolate with nextIndex at maximum index, ensuring correct clipping")
    void TC23_interpolate_with_nextIndex_at_maximum() throws NoDataException, DimensionMismatchException, NonMonotonicSequenceException, NumberIsTooSmallException {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {4.0, 5.0, 6.0};
        double[][] fval = {
            {7.0, 8.0, 9.0},
            {10.0, 11.0, 12.0},
            {13.0, 14.0, 15.0}
        };

        // WHEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The result should not be null");

        // Optionally, verify internal handling using reflection if necessary
        // Since nextIndex is used internally, we can infer correctness by ensuring no exceptions and valid result
    }

    @Test
    @DisplayName("Interpolate with previousIndex at zero, ensuring correct clipping")
    void TC24_interpolate_with_previousIndex_at_zero() throws NoDataException, DimensionMismatchException, NonMonotonicSequenceException, NumberIsTooSmallException {
        // GIVEN
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {4.0, 5.0, 6.0};
        double[][] fval = {
            {7.0, 8.0, 9.0},
            {10.0, 11.0, 12.0},
            {13.0, 14.0, 15.0}
        };

        // WHEN
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // THEN
        assertNotNull(result, "The result should not be null");

        // Optionally, verify internal handling using reflection if necessary
        // Since previousIndex is used internally, we can infer correctness by ensuring no exceptions and valid result
    }
}