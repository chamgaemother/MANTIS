
package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_1_6_Test {

    @Test
    @DisplayName("cls is wrapper (Double) and toClass is non-primitive (Number) with autoboxing=false")
    void testTC31() {
        // Arrange
        Class<?> cls = Double.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = false;

        // Act
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is non-primitive (List) and toClass is non-assignable (String) with autoboxing=true")
    void testTC32() {
        // Arrange
        Class<?> cls = java.util.List.class;
        Class<?> toClass = String.class;
        boolean autoboxing = true;

        // Act
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is primitive (long) and toClass is assignable primitive (float) with autoboxing=false")
    void testTC33() {
        // Arrange
        Class<?> cls = long.class;
        Class<?> toClass = float.class;
        boolean autoboxing = false;

        // Act
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Assert
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Float) and toClass is primitive (double) with autoboxing=true")
    void testTC34() {
        // Arrange
        Class<?> cls = Float.class;
        Class<?> toClass = double.class;
        boolean autoboxing = true;

        // Act
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Assert
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Long) and toClass is primitive (double) with autoboxing=true")
    void testTC35() {
        // Arrange
        Class<?> cls = Long.class;
        Class<?> toClass = double.class;
        boolean autoboxing = true;

        // Act
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Assert
        assertTrue(result);
    }

}