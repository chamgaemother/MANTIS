package org.jfree.chart.renderer.category;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BarRenderer_drawItem_0_9_Test {

    @Test
    @DisplayName("drawItem handles null CategoryAxis gracefully")
    public void TC41_drawItem_with_null_CategoryAxis() throws Exception {
        // Create instance of BarRenderer
        BarRenderer barRenderer = new BarRenderer();

        // Use reflection to set private fields if necessary
        setPrivateField(barRenderer, "base", 0.0);
        setPrivateField(barRenderer, "minimumBarLength", 1.0);
        setPrivateField(barRenderer, "shadowsVisible", true);
        setPrivateField(barRenderer, "barPainter", mock(BarPainter.class));

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up mock behaviors
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(10);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getBarWidth()).thenReturn(5.0);

        // Define null CategoryAxis
        CategoryAxis domainAxis = null;
        ValueAxis rangeAxis = mock(ValueAxis.class);

        // Expect NullPointerException when CategoryAxis is null
        assertThrows(NullPointerException.class, () -> {
            barRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    @Test
    @DisplayName("drawItem handles null ValueAxis gracefully")
    public void TC42_drawItem_with_null_ValueAxis() throws Exception {
        // Create instance of BarRenderer
        BarRenderer barRenderer = new BarRenderer();

        // Use reflection to set private fields if necessary
        setPrivateField(barRenderer, "base", 0.0);
        setPrivateField(barRenderer, "minimumBarLength", 1.0);
        setPrivateField(barRenderer, "shadowsVisible", true);
        setPrivateField(barRenderer, "barPainter", mock(BarPainter.class));

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        // Set up mock behaviors
        when(state.getVisibleSeriesIndex(0)).thenReturn(0);
        when(dataset.getValue(0, 0)).thenReturn(10);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.indexOf(dataset)).thenReturn(0);
        when(state.getBarWidth()).thenReturn(5.0);

        // Define null ValueAxis
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = null;

        // Expect NullPointerException when ValueAxis is null
        assertThrows(NullPointerException.class, () -> {
            barRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        });
    }

    // Helper method to set private fields via reflection
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}