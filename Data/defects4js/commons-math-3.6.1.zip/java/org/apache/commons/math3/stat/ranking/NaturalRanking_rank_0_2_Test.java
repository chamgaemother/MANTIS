package org.apache.commons.math3.stat.ranking;

import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.exception.NotANumberException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NaturalRanking_rank_0_2_Test {

    @Test
    @DisplayName("rank records NaN positions using FIXED strategy without throwing exception")
    void TC06_rank_records_NaN_positions_with_FIXED_strategy() {
        // GIVEN
        double[] data = new double[]{2.0, Double.NaN, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.FIXED);

        // WHEN
        double[] result = ranking.rank(data);

        // THEN
        assertTrue(Double.isNaN(result[1]), "The second element should be NaN");
        assertEquals(1.0, result[0], "First rank should be 1.0");
        assertEquals(3.0, result[2], "Third rank should be 3.0");
    }

    @Test
    @DisplayName("rank throws NotANumberException when NaNs are present with FAILED strategy")
    void TC07_rank_throws_NotANumberException_with_FAILED_strategy() {
        // GIVEN
        double[] data = new double[]{1.0, Double.NaN, 3.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.FAILED);

        // WHEN & THEN
        assertThrows(NotANumberException.class, () -> ranking.rank(data), "Should throw NotANumberException when NaNs are present with FAILED strategy");
    }

    @Test
    @DisplayName("rank with multiple identical values resolves ties using AVERAGE strategy")
    void TC09_rank_resolves_ties_with_AVERAGE_strategy() {
        // GIVEN
        double[] data = new double[]{2.0, 2.0, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.FIXED, TiesStrategy.AVERAGE);

        // WHEN
        double[] result = ranking.rank(data);

        // THEN
        assertAll("Tied ranks should be averaged correctly",
            () -> assertEquals(1.5, result[0], "First rank should be 1.5"),
            () -> assertEquals(1.5, result[1], "Second rank should be 1.5"),
            () -> assertEquals(3.0, result[2], "Third rank should be 3.0")
        );
    }

    @Test
    @DisplayName("rank resolves ties using MAXIMUM strategy")
    void TC10_rank_resolves_ties_with_MAXIMUM_strategy() {
        // GIVEN
        double[] data = new double[]{2.0, 2.0, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.FIXED, TiesStrategy.MAXIMUM);

        // WHEN
        double[] result = ranking.rank(data);

        // THEN
        assertAll("Tied ranks should be assigned the maximum rank",
            () -> assertEquals(2.0, result[0], "First rank should be 2.0"),
            () -> assertEquals(2.0, result[1], "Second rank should be 2.0"),
            () -> assertEquals(3.0, result[2], "Third rank should be 3.0")
        );
    }

    @Test
    @DisplayName("rank throws MathInternalError with undefined NaNStrategy")
    void TC08_rank_throws_MathInternalError_with_undefined_NaNStrategy() {
        // GIVEN
        double[] data = new double[]{1.0, 2.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.MINIMAL);

        // WHEN & THEN
        assertThrows(MathInternalError.class, () -> ranking.rank(data), "Should throw MathInternalError");
    }

}
