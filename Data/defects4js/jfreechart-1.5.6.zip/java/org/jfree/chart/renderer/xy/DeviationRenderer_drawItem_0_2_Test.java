package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.plot.CrosshairState;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class DeviationRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("Pass is not 0, it is an item pass with non-null EntityCollection")
    void TC06_itemPass_with_entityCollection_present() throws Exception {
        // GIVEN
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 2;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 2;
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isItemPass(pass)).thenReturn(true);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        verify(renderer).drawSecondaryPass(g2, plot, dataset, pass, series, item, domainAxis, dataArea, rangeAxis, crosshairState, entities);
    }

    @Test
    @DisplayName("Pass is not 0, it is an item pass with null EntityCollection")
    void TC07_itemPass_with_entityCollection_null() throws Exception {
        // GIVEN
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 2;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 2;
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(null);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isItemPass(pass)).thenReturn(true);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        verify(renderer).drawSecondaryPass(g2, plot, dataset, pass, series, item, domainAxis, dataArea, rangeAxis, crosshairState, null);
    }

    @Test
    @DisplayName("Pass is 0, orientation neither HORIZONTAL nor VERTICAL")
    void TC08_pass0_orientation_unknown() throws Exception {
        // GIVEN
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 1;
        int item = 3;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isLinePass(pass)).thenReturn(false);
        when(renderer.isItemPass(pass)).thenReturn(false);
        when(plot.getOrientation()).thenReturn(null); // Unknown orientation

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // No coordinates should be added, verify methods related to shading are not called
        Field lowerCoordinatesField = DeviationRenderer.class.getDeclaredField("lowerCoordinates");
        lowerCoordinatesField.setAccessible(true);
        List<?> lowerCoordinates = (List<?>) lowerCoordinatesField.get(renderer);
        assertTrue(lowerCoordinates.isEmpty(), "Lower coordinates should not be added");

        Field upperCoordinatesField = DeviationRenderer.class.getDeclaredField("upperCoordinates");
        upperCoordinatesField.setAccessible(true);
        List<?> upperCoordinates = (List<?>) upperCoordinatesField.get(renderer);
        assertTrue(upperCoordinates.isEmpty(), "Upper coordinates should not be added");
    }

    @Test
    @DisplayName("Pass is 0, orientation is HORIZONTAL, loop with multiple lower and upper coordinates")
    void TC09_horizontal_orientation_multiple_coordinates() throws Exception {
        // GIVEN
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 2;
        int item = mock(XYDataset.class, RETURNS_DEEP_STUBS).getItemCount(series) - 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isLinePass(pass)).thenReturn(false);
        when(renderer.isItemPass(pass)).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getXValue(series, item)).thenReturn(10.0);
        when(dataset.getStartYValue(series, item)).thenReturn(5.0);
        when(dataset.getEndYValue(series, item)).thenReturn(15.0);

        // Mock multiple lower and upper coordinates
        // Since lowerCoordinates and upperCoordinates are internal, use reflection to verify additions

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that lowerCoordinates and upperCoordinates have been populated correctly
        Field lowerCoordinatesField = DeviationRenderer.class.getDeclaredField("lowerCoordinates");
        lowerCoordinatesField.setAccessible(true);
        List<?> lowerCoordinates = (List<?>) lowerCoordinatesField.get(renderer);
        assertFalse(lowerCoordinates.isEmpty(), "Lower coordinates should be populated");

        Field upperCoordinatesField = DeviationRenderer.class.getDeclaredField("upperCoordinates");
        upperCoordinatesField.setAccessible(true);
        List<?> upperCoordinates = (List<?>) upperCoordinatesField.get(renderer);
        assertFalse(upperCoordinates.isEmpty(), "Upper coordinates should be populated");

        // Further assertions can be added to check the exact coordinates if needed
    }

    @Test
    @DisplayName("Pass is 0, orientation is VERTICAL, loop with single lower and upper coordinate")
    void TC10_vertical_orientation_single_coordinate() throws Exception {
        // GIVEN
        DeviationRenderer renderer = new DeviationRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 2;
        int item = mock(XYDataset.class, RETURNS_DEEP_STUBS).getItemCount(series) - 1;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isLinePass(pass)).thenReturn(false);
        when(renderer.isItemPass(pass)).thenReturn(false);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(dataset.getXValue(series, item)).thenReturn(20.0);
        when(dataset.getStartYValue(series, item)).thenReturn(10.0);
        when(dataset.getEndYValue(series, item)).thenReturn(30.0);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // THEN
        // Verify that lowerCoordinates and upperCoordinates have been populated correctly
        Field lowerCoordinatesField = DeviationRenderer.class.getDeclaredField("lowerCoordinates");
        lowerCoordinatesField.setAccessible(true);
        List<?> lowerCoordinates = (List<?>) lowerCoordinatesField.get(renderer);
        assertEquals(1, lowerCoordinates.size(), "There should be one lower coordinate");

        Field upperCoordinatesField = DeviationRenderer.class.getDeclaredField("upperCoordinates");
        upperCoordinatesField.setAccessible(true);
        List<?> upperCoordinates = (List<?>) upperCoordinatesField.get(renderer);
        assertEquals(1, upperCoordinates.size(), "There should be one upper coordinate");

        // Further assertions can be added to check the exact coordinates if needed
    }
}