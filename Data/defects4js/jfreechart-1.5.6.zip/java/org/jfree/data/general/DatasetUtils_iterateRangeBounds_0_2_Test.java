package org.jfree.data.general;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.Range;
import org.jfree.data.general.DatasetUtils;
import org.mockito.Mockito;

public class DatasetUtils_iterateRangeBounds_0_2_Test {

    @Test
    @DisplayName("includeInterval=true with IntervalXYDataset having multiple series and items with some NaN values")
    public void TC06_iterateRangeBounds_with_interval_xy_dataset_with_multiple_series_and_nan_values() {
        // Given
        IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
        
        // Series 0
        Mockito.when(dataset.getSeriesCount()).thenReturn(2);
        Mockito.when(dataset.getItemCount(0)).thenReturn(2);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(10.0);
        Mockito.when(dataset.getStartYValue(0, 0)).thenReturn(8.0);
        Mockito.when(dataset.getEndYValue(0, 0)).thenReturn(12.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        Mockito.when(dataset.getStartYValue(0, 1)).thenReturn(7.0);
        Mockito.when(dataset.getEndYValue(0, 1)).thenReturn(13.0);
        
        // Series 1
        Mockito.when(dataset.getItemCount(1)).thenReturn(2);
        Mockito.when(dataset.getYValue(1, 0)).thenReturn(15.0);
        Mockito.when(dataset.getStartYValue(1, 0)).thenReturn(Double.NaN);
        Mockito.when(dataset.getEndYValue(1, 0)).thenReturn(14.0);
        Mockito.when(dataset.getYValue(1, 1)).thenReturn(20.0);
        Mockito.when(dataset.getStartYValue(1, 1)).thenReturn(16.0);
        Mockito.when(dataset.getEndYValue(1, 1)).thenReturn(Double.NaN);
        
        boolean includeInterval = true;
        
        // When
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
        
        // Then
        assertNotNull(result, "Resulting Range should not be null");
        assertEquals(7.0, result.getLowerBound(), 0.0001, "Lower bound should be 7.0");
        assertEquals(20.0, result.getUpperBound(), 0.0001, "Upper bound should be 20.0");
    }

    @Test
    @DisplayName("includeInterval=true with OHLCDataset having one series and one item with non-NaN low and high values")
    public void TC07_iterateRangeBounds_with_ohlc_dataset_single_series_single_item() {
        // Given
        OHLCDataset dataset = Mockito.mock(OHLCDataset.class);
        Mockito.when(dataset.getSeriesCount()).thenReturn(1);
        Mockito.when(dataset.getItemCount(0)).thenReturn(1);
        Mockito.when(dataset.getLowValue(0, 0)).thenReturn(5.0);
        Mockito.when(dataset.getHighValue(0, 0)).thenReturn(15.0);
        
        boolean includeInterval = true;
        
        // When
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
        
        // Then
        assertNotNull(result, "Resulting Range should not be null");
        assertEquals(5.0, result.getLowerBound(), 0.0001, "Lower bound should be 5.0");
        assertEquals(15.0, result.getUpperBound(), 0.0001, "Upper bound should be 15.0");
    }

    @Test
    @DisplayName("includeInterval=true with OHLCDataset having multiple series and items with some NaN low or high values")
    public void TC08_iterateRangeBounds_with_ohlc_dataset_multiple_series_and_nan_values() {
        // Given
        OHLCDataset dataset = Mockito.mock(OHLCDataset.class);
        Mockito.when(dataset.getSeriesCount()).thenReturn(2);
        
        // Series 0
        Mockito.when(dataset.getItemCount(0)).thenReturn(2);
        Mockito.when(dataset.getLowValue(0, 0)).thenReturn(5.0);
        Mockito.when(dataset.getHighValue(0, 0)).thenReturn(15.0);
        Mockito.when(dataset.getLowValue(0, 1)).thenReturn(Double.NaN);
        Mockito.when(dataset.getHighValue(0, 1)).thenReturn(20.0);
        
        // Series 1
        Mockito.when(dataset.getItemCount(1)).thenReturn(2);
        Mockito.when(dataset.getLowValue(1, 0)).thenReturn(7.0);
        Mockito.when(dataset.getHighValue(1, 0)).thenReturn(Double.NaN);
        Mockito.when(dataset.getLowValue(1, 1)).thenReturn(10.0);
        Mockito.when(dataset.getHighValue(1, 1)).thenReturn(25.0);
        
        boolean includeInterval = true;
        
        // When
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
        
        // Then
        assertNotNull(result, "Resulting Range should not be null");
        assertEquals(5.0, result.getLowerBound(), 0.0001, "Lower bound should be 5.0");
        assertEquals(25.0, result.getUpperBound(), 0.0001, "Upper bound should be 25.0");
    }

    @Test
    @DisplayName("includeInterval=true with dataset not being IntervalXYDataset or OHLCDataset, expecting standard XYDataset processing")
    public void TC09_iterateRangeBounds_with_standard_xy_dataset_include_interval_true() {
        // Given
        XYDataset dataset = Mockito.mock(XYDataset.class);
        Mockito.when(dataset.getSeriesCount()).thenReturn(2);
        
        // Series 0
        Mockito.when(dataset.getItemCount(0)).thenReturn(2);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(5.0);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(15.0);
        
        // Series 1
        Mockito.when(dataset.getItemCount(1)).thenReturn(2);
        Mockito.when(dataset.getYValue(1, 0)).thenReturn(5.0);
        Mockito.when(dataset.getYValue(1, 1)).thenReturn(15.0);
        
        boolean includeInterval = true;
        
        // When
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
        
        // Then
        assertNotNull(result, "Resulting Range should not be null");
        assertEquals(5.0, result.getLowerBound(), 0.0001, "Lower bound should be 5.0");
        assertEquals(15.0, result.getUpperBound(), 0.0001, "Upper bound should be 15.0");
    }

    @Test
    @DisplayName("includeInterval=true with IntervalXYDataset having all Y, startY, endY values as NaN, expecting null return")
    public void TC10_iterateRangeBounds_with_interval_xy_dataset_all_nan_values() {
        // Given
        IntervalXYDataset dataset = Mockito.mock(IntervalXYDataset.class);
        Mockito.when(dataset.getSeriesCount()).thenReturn(1);
        Mockito.when(dataset.getItemCount(0)).thenReturn(2);
        Mockito.when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        Mockito.when(dataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
        Mockito.when(dataset.getEndYValue(0, 0)).thenReturn(Double.NaN);
        Mockito.when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        Mockito.when(dataset.getStartYValue(0, 1)).thenReturn(Double.NaN);
        Mockito.when(dataset.getEndYValue(0, 1)).thenReturn(Double.NaN);
        
        boolean includeInterval = true;
        
        // When
        Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
        
        // Then
        assertNull(result, "Resulting Range should be null when all values are NaN");
    }
}