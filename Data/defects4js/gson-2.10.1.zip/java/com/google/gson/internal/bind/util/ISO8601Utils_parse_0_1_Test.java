package com.google.gson.internal.bind.util;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ISO8601Utils_parse_0_1_Test {

    @Test
    @DisplayName("parse valid date without time component")
    void TC01_parseValidDateWithoutTimeComponent() throws ParseException {
        // GIVEN
        String date = "2023-10-05";
        ParsePosition pos = new ParsePosition(0);
        GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.set(2023, 9, 5, 0, 0, 0);
        calendar.set(GregorianCalendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        assertEquals(expectedDate, result, "The parsed date should match the expected date.");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be at the end of the string.");
    }

    @Test
    @DisplayName("parse valid date with UTC timezone")
    void TC02_parseValidDateWithUTCTimezone() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.set(2023, 9, 5, 14, 30, 0);
        calendar.set(GregorianCalendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        assertEquals(expectedDate, result, "The parsed date should match the expected date with UTC timezone.");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be at the end of the string.");
    }

    @Test
    @DisplayName("parse valid date with positive timezone offset")
    void TC03_parseValidDateWithPositiveTimezoneOffset() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00+02:00";
        ParsePosition pos = new ParsePosition(0);
        TimeZone tz = TimeZone.getTimeZone("GMT+02:00");
        GregorianCalendar calendar = new GregorianCalendar(tz);
        calendar.set(2023, 9, 5, 14, 30, 0);
        calendar.set(GregorianCalendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        assertEquals(expectedDate, result, "The parsed date should match the expected date with positive timezone offset.");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be at the end of the string.");
    }

    @Test
    @DisplayName("parse valid date with negative timezone offset")
    void TC04_parseValidDateWithNegativeTimezoneOffset() throws ParseException {
        // GIVEN
        String date = "2023-10-05T14:30:00-05:00";
        ParsePosition pos = new ParsePosition(0);
        TimeZone tz = TimeZone.getTimeZone("GMT-05:00");
        GregorianCalendar calendar = new GregorianCalendar(tz);
        calendar.set(2023, 9, 5, 14, 30, 0);
        calendar.set(GregorianCalendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();

        // WHEN
        Date result = ISO8601Utils.parse(date, pos);

        // THEN
        assertEquals(expectedDate, result, "The parsed date should match the expected date with negative timezone offset.");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be at the end of the string.");
    }

    @Test
    @DisplayName("parse date with missing day component")
    void TC05_parseDateWithMissingDayComponent() {
        // GIVEN
        String date = "2023-10";
        ParsePosition pos = new ParsePosition(0);

        // WHEN & THEN
        assertThrows(ParseException.class, () -> ISO8601Utils.parse(date, pos),
                "Parsing should throw ParseException due to missing day component.");
    }
}