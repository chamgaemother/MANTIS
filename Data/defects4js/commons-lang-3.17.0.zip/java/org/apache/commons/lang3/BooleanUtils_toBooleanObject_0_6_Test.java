package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.BooleanUtils;

public class BooleanUtils_toBooleanObject_0_6_Test {

    @Test
    @DisplayName("Input string is empty string, returns null")
    public void TC26_toBooleanObject_emptyString_returnsNull() {
        // GIVEN
        String input = "";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertNull(result, "Expected result to be null for empty string input");
    }

    @Test
    @DisplayName("Input string is single character 'T', returns Boolean.TRUE")
    public void TC27_toBooleanObject_singleT_returnsTrue() {
        // GIVEN
        String input = "T";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertEquals(Boolean.TRUE, result, "Expected result to be Boolean.TRUE for input 'T'");
    }

    @Test
    @DisplayName("Input string is two characters 'No', returns Boolean.FALSE")
    public void TC28_toBooleanObject_twoCharsNo_returnsFalse() {
        // GIVEN
        String input = "No";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertEquals(Boolean.FALSE, result, "Expected result to be Boolean.FALSE for input 'No'");
    }

    @Test
    @DisplayName("Input string is single character 'Y', returns Boolean.TRUE")
    public void TC29_toBooleanObject_singleY_returnsTrue() {
        // GIVEN
        String input = "Y";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertEquals(Boolean.TRUE, result, "Expected result to be Boolean.TRUE for input 'Y'");
    }

    @Test
    @DisplayName("Input string is single character 'F', returns Boolean.FALSE")
    public void TC30_toBooleanObject_singleF_returnsFalse() {
        // GIVEN
        String input = "F";
        
        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(input);
        
        // THEN
        assertEquals(Boolean.FALSE, result, "Expected result to be Boolean.FALSE for input 'F'");
    }
}