import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.needle.ArrowNeedle;
import org.jfree.chart.needle.LineNeedle;
import org.jfree.chart.plot.CompassPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;

class CompassPlotTest {

    private CompassPlot plot;
    private Graphics2D g2;
    private Rectangle2D area;
    private Point2D anchor;
    private PlotRenderingInfo info;

    @BeforeEach
    void setUp() {
        plot = new CompassPlot();
        g2 = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 200, 200);
        anchor = mock(Point2D.class);
        info = mock(PlotRenderingInfo.class);
    }

    @Test
    void testDrawWithInfoNotNullAndDrawBorderTrue() {
        plot.setDrawBorder(true);
        plot.draw(g2, area, anchor, null, info);
        verify(info).setPlotArea(area);
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithInfoNull() {
        plot.setDrawBorder(false);
        plot.draw(g2, area, anchor, null, null);
        verify(info, never()).setPlotArea(any());
    }

    @Test
    void testDrawWithDrawBorderTrue() {
        plot.setDrawBorder(true);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithDrawBorderFalse() {
        plot.setDrawBorder(false);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, never()).setPaint(Color.BLACK);
    }

    @Test
    void testDrawWithMidYLessThanMidX() {
        Rectangle2D smallArea = new Rectangle2D.Double(0, 0, 100, 50);
        plot.draw(g2, smallArea, anchor, null, info);
        // Further verification can be done by verifying calculations, skipped here
    }

    @Test
    void testDrawWithMidYGreaterThanMidX() {
        Rectangle2D tallArea = new Rectangle2D.Double(0, 0, 50, 100);
        plot.draw(g2, tallArea, anchor, null, info);
        // Further verification can be done by verifying calculations, skipped here
    }

    @Test
    void testDrawWithZeroWidthArea() {
        Rectangle2D zeroWidthArea = new Rectangle2D.Double(0, 0, 0, 100);
        plot.draw(g2, zeroWidthArea, anchor, null, info);
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithZeroHeightArea() {
        Rectangle2D zeroHeightArea = new Rectangle2D.Double(0, 0, 100, 0);
        plot.draw(g2, zeroHeightArea, anchor, null, info);
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithNullDataset() {
        plot = new CompassPlot(null);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithNonNullDatasetValueNotNull() {
        plot = new CompassPlot();
        plot.setSeriesNeedle(0, new ArrowNeedle(true));
        plot.draw(g2, area, anchor, null, info);
        verify(g2).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithNonNullDatasetValueNull() {
        plot = new CompassPlot();
        plot.getDatasets()[0].setValue(null);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, never()).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithMultipleDatasetsAllNonNull() {
        plot.addDataset(new org.jfree.data.general.DefaultValueDataset(90));
        plot.addDataset(new org.jfree.data.general.DefaultValueDataset(180));
        plot.setSeriesNeedle(0, new ArrowNeedle(true));
        plot.setSeriesNeedle(1, new LineNeedle());
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithMultipleDatasetsSomeNull() {
        plot.addDataset(null);
        plot.setSeriesNeedle(0, new ArrowNeedle(true));
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithRevolutionDistance360() {
        plot.setRevolutionDistance(360);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawLine(anyInt(), anyInt(), anyInt(), anyInt());
    }

    @Test
    void testDrawWithRevolutionDistance2Pi() {
        plot.setRevolutionDistance(2 * Math.PI);
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawLine(anyInt(), anyInt(), anyInt(), anyInt());
    }

    @Test
    void testDrawWithNegativeRevolutionDistance() {
        plot.setRevolutionDistance(-100);
        plot.draw(g2, area, anchor, null, info);
        // Assuming setRevolutionDistance does not set negative values
        assert(plot.getRevolutionDistance() == -100);
    }

    @Test
    void testDrawWithMinimalArea() {
        Rectangle2D minimalArea = new Rectangle2D.Double(0, 0, 1, 1);
        plot.draw(g2, minimalArea, anchor, null, info);
        verify(g2, atLeastOnce()).drawString(anyString(), anyInt(), anyInt());
    }

    @Test
    void testDrawWithMaximalArea() {
        Rectangle2D maximalArea = new Rectangle2D.Double(0, 0, 10000, 10000);
        plot.draw(g2, maximalArea, anchor, null, info);
        verify(g2, atLeastOnce()).drawOval(anyInt(), anyInt(), anyInt(), anyInt());
    }

    @Test
    void testDrawWithNullGraphics2D() {
        try {
            plot.draw(null, area, anchor, null, info);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    void testDrawWithNullArea() {
        try {
            plot.draw(g2, null, anchor, null, info);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    void testDrawWithNullAnchor() {
        plot.draw(g2, area, null, null, info);
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithNullParentState() {
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithCustomNeedle() {
        plot.setSeriesNeedle(0, new ArrowNeedle(false));
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
    }

    @Test
    void testDrawWithCustomFont() {
        plot.setLabelFont(new Font("Serif", Font.ITALIC, 12));
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).setFont(any(Font.class));
    }

    @Test
    void testDrawWithCustomPaints() {
        plot.setRosePaint(Color.GREEN);
        plot.setRoseCenterPaint(Color.BLUE);
        plot.setRoseHighlightPaint(Color.RED);
        plot.draw(g2, area, anchor, null, info);
        verify(g2).setPaint(Color.GREEN);
        verify(g2).setPaint(Color.BLUE);
        verify(g2).setPaint(Color.RED);
    }

    @Test
    void testDrawWithExtremeValues() {
        plot.addDataset(new org.jfree.data.general.DefaultValueDataset(Double.MAX_VALUE));
        plot.addDataset(new org.jfree.data.general.DefaultValueDataset(Double.MIN_VALUE));
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawLine(anyInt(), anyInt(), anyInt(), anyInt());
    }

    @Test
    void testDrawWithNegativeValues() {
        plot.addDataset(new org.jfree.data.general.DefaultValueDataset(-90));
        plot.draw(g2, area, anchor, null, info);
        verify(g2, atLeastOnce()).drawLine(anyInt(), anyInt(), anyInt(), anyInt());
    }
}