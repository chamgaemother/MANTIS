package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class Flat3Map_containsKey_0_3_Test {

    @Test
    @DisplayName("When delegateMap is null, key is not null, size>0, none of the hashes match")
    void TC11_containsKey_delegateMapNull_keyNotNull_sizeGreaterThan0_noHashMatch() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        
        // Using reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);
        
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object someKey1 = new Object();
        key1Field.set(map, someKey1);
        
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object someKey2 = new Object();
        key2Field.set(map, someKey2);
        
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object someKey3 = new Object();
        key3Field.set(map, someKey3);
        
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, someKey1.hashCode());
        
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, someKey2.hashCode());
        
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, someKey3.hashCode());
        
        Object uniqueKey = new Object();
        
        // WHEN
        boolean result = map.containsKey(uniqueKey);
        
        // THEN
        assertFalse(result, "Expected containsKey to return false");
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size>0, hash3 matches but key does not equal key3")
    void TC12_containsKey_delegateMapNull_keyNotNull_sizeGreaterThan0_hash3Match_keyNotEqualKey3() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        
        // Using reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);
        
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object someKey1 = new Object();
        key1Field.set(map, someKey1);
        
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object someKey2 = new Object();
        key2Field.set(map, someKey2);
        
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object anotherKey = new Object();
        key3Field.set(map, anotherKey);
        
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, someKey1.hashCode());
        
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, someKey2.hashCode());
        
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        Object targetKey = new Object();
        hash3Field.setInt(map, targetKey.hashCode());
        
        Object key = targetKey;
        
        // WHEN
        boolean result = map.containsKey(key);
        
        // THEN
        assertFalse(result, "Expected containsKey to return false when hash matches but keys are not equal");
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=0")
    void TC13_containsKey_delegateMapNull_keyNotNull_sizeZero() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();
        
        // Using reflection to set private fields
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);
        
        Object key = new Object();
        
        // WHEN
        boolean result = map.containsKey(key);
        
        // THEN
        assertFalse(result, "Expected containsKey to return false when size is 0");
    }
}