package org.apache.commons.lang3.math;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;

public class NumberUtils_createNumber_0_7_Test {

    @Test
    @DisplayName("Input string with decimal point and valid BigDecimal, should return BigDecimal")
    void TC31_createNumber_decimal_bigdecimal() throws Exception {
        // GIVEN
        String input = "123.4567890123456789";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof BigDecimal, "Result should be instance of BigDecimal");
        assertEquals(new BigDecimal("123.4567890123456789"), result, "BigDecimal value mismatch");
    }

    @Test
    @DisplayName("Input string with exponent resulting in Double infinity, should return BigDecimal")
    void TC32_createNumber_exponent_infinite_double() throws Exception {
        // GIVEN
        String input = "1e500";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof BigDecimal, "Result should be instance of BigDecimal");
        assertEquals(new BigDecimal("1e500"), result, "BigDecimal value mismatch");
    }

    @Test
    @DisplayName("Input string with hexadecimal prefix and exact 16 hex digits with firstSigDigit <= '7', should return Long")
    void TC33_createNumber_hex_16digits_long() throws Exception {
        // GIVEN
        String input = "0x7FFFFFFFFFFFFFFF";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof Long, "Result should be instance of Long");
        assertEquals(Long.MAX_VALUE, result.longValue(), "Long value mismatch");
    }

    @Test
    @DisplayName("Input string with hexadecimal prefix and exactly 8 hex digits with firstSigDigit > '7', should return Long")
    void TC34_createNumber_hex_8digits_long() throws Exception {
        // GIVEN
        String input = "#80000000";
        
        // WHEN
        Number result = NumberUtils.createNumber(input);
        
        // THEN
        assertTrue(result instanceof Long, "Result should be instance of Long");
        assertEquals(2147483648L, result.longValue(), "Long value mismatch");
    }

    @Test
    @DisplayName("Input string with decimal point and type suffix 'L', should throw NumberFormatException")
    void TC35_createNumber_decimal_suffix_L() throws Exception {
        // GIVEN
        String input = "123.45L";
        
        // WHEN & THEN
        NumberFormatException exception = assertThrows(NumberFormatException.class, () -> {
            NumberUtils.createNumber(input);
        }, "Expected NumberFormatException to be thrown");
        
        assertEquals("123.45L is not a valid number.", exception.getMessage(), "Exception message mismatch");
    }

}