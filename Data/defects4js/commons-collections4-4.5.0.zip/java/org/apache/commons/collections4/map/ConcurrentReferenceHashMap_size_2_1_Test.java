import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import java.lang.reflect.Field;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.collections4.map.ConcurrentReferenceHashMap;

public class ConcurrentReferenceHashMap_size_2_1_Test {

    @Test
    @DisplayName("Size computed correctly when some segments have zero counts and others have non-zero counts without concurrent modifications")
    public void TC17_size_with_mixed_segment_counts() throws Exception {
        // Initialize the ConcurrentReferenceHashMap with specified parameters
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.<Object, Object>builder()
            .setInitialCapacity(16)
            .setLoadFactor(0.75f)
            .setConcurrencyLevel(4)
            .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
            .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
            .get();

        // Access the 'segments' field via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Set the 'count' field of specific segments via reflection
        for (int i = 0; i < segments.length; i++) {
            Field countField = segments[i].getClass().getSuperclass().getDeclaredField("count");
            countField.setAccessible(true);
            if (i < 2) {
                countField.setInt(segments[i], 0);
            } else if (i == 2) {
                countField.setInt(segments[i], 50);
            } else if (i == 3) {
                countField.setInt(segments[i], 100);
            }
        }

        // Invoke the size method
        int size = map.size();

        // Assert that the size is as expected
        assertEquals(150, size, "The size should be the sum of non-zero segment counts.");
    }

    @Test
    @DisplayName("Size computation correctly caps the size at Integer.MAX_VALUE when total count equals Integer.MAX_VALUE")
    public void TC18_size_exactly_Integer_MAX_VALUE() throws Exception {
        // Initialize the ConcurrentReferenceHashMap with specified parameters
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.<Object, Object>builder()
            .setInitialCapacity(32)
            .setLoadFactor(0.75f)
            .setConcurrencyLevel(8)
            .setKeyReferenceType(ConcurrentReferenceHashMap.ReferenceType.WEAK)
            .setValueReferenceType(ConcurrentReferenceHashMap.ReferenceType.STRONG)
            .get();

        // Access the 'segments' field via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Calculate counts to sum exactly Integer.MAX_VALUE across all segments
        int segmentsCount = 8;
        long perSegmentCount = ((long) Integer.MAX_VALUE) / segmentsCount; // 268435455
        long remaining = Integer.MAX_VALUE - (perSegmentCount * segmentsCount); // 7

        // Set the 'count' field of each segment via reflection
        for (int i = 0; i < segments.length; i++) {
            Field countField = segments[i].getClass().getSuperclass().getDeclaredField("count");
            countField.setAccessible(true);
            if (i < segmentsCount - 1) {
                countField.setInt(segments[i], (int) perSegmentCount);
            } else {
                countField.setInt(segments[i], (int) (perSegmentCount + remaining));
            }
        }

        // Invoke the size method
        int size = map.size();

        // Assert that the size is capped at Integer.MAX_VALUE
        assertEquals(Integer.MAX_VALUE, size, "The size should be capped at Integer.MAX_VALUE.");
    }
}