import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import org.apache.commons.collections4.map.Flat3Map;

public class Flat3Map_get_1_1_Test {

    @Test
    @DisplayName("Throws IllegalStateException when delegateMap is null and size is greater than 3")
    void TC24() throws Exception {
        // Create a new Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Use reflection to set size to 4
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 4);

        // Expect IllegalStateException when get is called
        assertThrows(IllegalStateException.class, () -> map.get("anyKey"));
    }

    @Test
    @DisplayName("Throws IllegalStateException when delegateMap is null and size is negative")
    void TC25() throws Exception {
        // Create a new Flat3Map instance
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Use reflection to set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Use reflection to set size to -1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, -1);

        // Expect IllegalStateException when get is called
        assertThrows(IllegalStateException.class, () -> map.get("anyKey"));
    }
}