package org.apache.commons.jxpath.ri.model.dom;

import org.apache.commons.jxpath.util.TypeUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.w3c.dom.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DOMNodePointer_setValue_0_2_Test {

    @Test
    @DisplayName("setValue with non-text node and value as Document node appends cloned children")
    public void TC06_setValue_NonTextNode_WithDocumentAppendsClonedChildren() {
        MockedStatic<TypeUtils> mockedTypeUtils = Mockito.mockStatic(TypeUtils.class);
        
        // Mocking nodes and related objects
        Node node = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
        
        NodeList children = mock(NodeList.class);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(1);
        
        Node child1 = mock(Node.class);
        when(children.item(0)).thenReturn(child1);
        
        Document valueDocument = mock(Document.class);
        NodeList valueChildren = mock(NodeList.class);
        when(valueDocument.getChildNodes()).thenReturn(valueChildren);

        when(valueChildren.getLength()).thenReturn(1);
        
        Node valueChild1 = mock(Node.class);
        when(valueChildren.item(0)).thenReturn(valueChild1);
        
        mockedTypeUtils.when(() -> TypeUtils.convert(any(), eq(Document.class))).thenReturn(valueDocument);
        
        // Instantiate DOMNodePointer
        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);
        
        // Call setValue
        domNodePointer.setValue(valueDocument);

        // Verify interactions
        verify(node).removeChild(child1);
        verify(node).appendChild(valueChild1.cloneNode(true));

        mockedTypeUtils.close();
    }

    @Test
    @DisplayName("setValue with non-text node and value as non-Element/Document Node appends cloned node")
    public void TC07_setValue_NonTextNode_WithNonElementDocumentNodeAppendsClonedNode() {
        MockedStatic<TypeUtils> mockedTypeUtils = Mockito.mockStatic(TypeUtils.class);

        // Mocking nodes and related objects
        Node node = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);

        NodeList children = mock(NodeList.class);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(0);

        Node valueNode = mock(Node.class);

        // Instantiate DOMNodePointer
        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // Call setValue
        domNodePointer.setValue(valueNode);

        // Verify interactions
        verify(node).appendChild(valueNode.cloneNode(true));

        mockedTypeUtils.close();
    }

    @Test
    @DisplayName("setValue with non-text node and value as non-Node with non-empty string appends TextNode")
    public void TC08_setValue_NonTextNode_WithNonEmptyStringAppendsTextNode() {
        MockedStatic<TypeUtils> mockedTypeUtils = Mockito.mockStatic(TypeUtils.class);

        // Mocking nodes and related objects
        Node node = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);

        NodeList children = mock(NodeList.class);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(0);

        String nonNodeValue = "Appended Text";

        mockedTypeUtils.when(() -> TypeUtils.convert(nonNodeValue, String.class)).thenReturn(nonNodeValue);

        Document ownerDocument = mock(Document.class);
        when(node.getOwnerDocument()).thenReturn(ownerDocument);

        Text newText = mock(Text.class);
        when(ownerDocument.createTextNode(nonNodeValue)).thenReturn(newText);

        // Instantiate DOMNodePointer
        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // Call setValue
        domNodePointer.setValue(nonNodeValue);

        // Verify interactions
        verify(node).appendChild(newText);

        mockedTypeUtils.close();
    }

    @Test
    @DisplayName("setValue with non-text node and value as non-Node with null string does not append")
    public void TC09_setValue_NonTextNode_WithNullStringDoesNotAppend() {
        MockedStatic<TypeUtils> mockedTypeUtils = Mockito.mockStatic(TypeUtils.class);

        // Mocking nodes and related objects
        Node node = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);

        NodeList children = mock(NodeList.class);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(0);

        String nonNodeValue = null;

        mockedTypeUtils.when(() -> TypeUtils.convert(nonNodeValue, String.class)).thenReturn(nonNodeValue);

        // Instantiate DOMNodePointer
        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // Call setValue
        domNodePointer.setValue(nonNodeValue);

        // Verify no append operation
        verify(node, never()).appendChild(any());

        mockedTypeUtils.close();
    }

    @Test
    @DisplayName("setValue with non-text node and value as non-Node with empty string does not append")
    public void TC10_setValue_NonTextNode_WithEmptyStringDoesNotAppend() {
        MockedStatic<TypeUtils> mockedTypeUtils = Mockito.mockStatic(TypeUtils.class);

        // Mocking nodes and related objects
        Node node = mock(Node.class);
        when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);

        NodeList children = mock(NodeList.class);
        when(node.getChildNodes()).thenReturn(children);
        when(children.getLength()).thenReturn(0);

        String nonNodeValue = "";

        mockedTypeUtils.when(() -> TypeUtils.convert(nonNodeValue, String.class)).thenReturn(nonNodeValue);

        // Instantiate DOMNodePointer
        DOMNodePointer domNodePointer = new DOMNodePointer(node, null);

        // Call setValue
        domNodePointer.setValue(nonNodeValue);

        // Verify no append operation
        verify(node, never()).appendChild(any());

        mockedTypeUtils.close();
    }
}