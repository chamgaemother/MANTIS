package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.lang.reflect.Field;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.parser.Token;
import org.apache.commons.jxpath.ri.parser.XPathParser;

public class XPathParser_AxisName_0_1_Test {

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_SELF returns Compiler.AXIS_SELF")
    public void TC01() throws Exception {
        // Arrange
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = new Token();
        jjNtField.set(parser, jj_nt);
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_SELF);
        
        // Act
        int axis = parser.AxisName();
        
        // Assert
        assertEquals(Compiler.AXIS_SELF, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_CHILD returns Compiler.AXIS_CHILD")
    public void TC02() throws Exception {
        // Arrange
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = new Token();
        jjNtField.set(parser, jj_nt);
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_CHILD);
        
        // Act
        int axis = parser.AxisName();
        
        // Assert
        assertEquals(Compiler.AXIS_CHILD, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_PARENT returns Compiler.AXIS_PARENT")
    public void TC03() throws Exception {
        // Arrange
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = new Token();
        jjNtField.set(parser, jj_nt);
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_PARENT);
        
        // Act
        int axis = parser.AxisName();
        
        // Assert
        assertEquals(Compiler.AXIS_PARENT, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_ANCESTOR returns Compiler.AXIS_ANCESTOR")
    public void TC04() throws Exception {
        // Arrange
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = new Token();
        jjNtField.set(parser, jj_nt);
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_ANCESTOR);
        
        // Act
        int axis = parser.AxisName();
        
        // Assert
        assertEquals(Compiler.AXIS_ANCESTOR, axis);
    }

    @Test
    @DisplayName("AxisName with jj_nt.kind=AXIS_ATTRIBUTE returns Compiler.AXIS_ATTRIBUTE")
    public void TC05() throws Exception {
        // Arrange
        XPathParser parser = new XPathParser(new XPathParserTokenManager(null));
        Field jjNtField = XPathParser.class.getDeclaredField("jj_nt");
        jjNtField.setAccessible(true);
        Token jj_nt = new Token();
        jjNtField.set(parser, jj_nt);
        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.AXIS_ATTRIBUTE);
        
        // Act
        int axis = parser.AxisName();
        
        // Assert
        assertEquals(Compiler.AXIS_ATTRIBUTE, axis);
    }

}