package org.apache.commons.math3.analysis.solvers;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.analysis.UnivariateFunction;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class UnivariateSolverUtils_forceSide_0_3_Test {

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, step size is minimal and bracketing is successful without adjusting bounds")
    public void TC11_allowedSolutionNotANY_SIDE_MinimalStepSize_SuccessfulBracketing() throws Exception {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 4;
        UnivariateFunction f = x -> x - 2.0;
        BracketedUnivariateSolver bracketing = mock(BracketedUnivariateSolver.class);
        when(bracketing.solve(anyInt(), eq(f), anyDouble(), anyDouble(), anyDouble(), eq(allowedSolution))).thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 1.9999;
        double max = 2.0001;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        assertEquals(2.0, result);
        verify(bracketing).solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop requires maximum iterations without finding bracketing, throws NoBracketingException")
    public void TC12_allowedSolutionNotANY_SIDE_MaxIterations_NoBracketingException() throws Exception {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
        int maxEval = 6;
        UnivariateFunction f = x -> x - 2.0;
        BracketedUnivariateSolver bracketing = mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN & THEN
        assertThrows(NoBracketingException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        });
    }
}