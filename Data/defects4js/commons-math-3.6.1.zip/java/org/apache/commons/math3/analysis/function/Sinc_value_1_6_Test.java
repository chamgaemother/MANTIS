package org.apache.commons.math3.analysis.function;

import org.apache.commons.math3.util.FastMath;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Sinc_value_1_6_Test {

    @Test
    @DisplayName("value(0.0) with normalized=false evaluates the Taylor series branch")
    public void TC13_testValueAtZeroNormalizedFalse() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = 0.0;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double expected = 1.0;
        assertEquals(expected, result, 1e-10, "sinc(0.0) should return 1.0");
    }

    @Test
    @DisplayName("value(1e-4) with normalized=false and |x| < SHORTCUT evaluates the Taylor series branch")
    public void TC14_testValueAt1eMinus4NormalizedFalse() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = 1e-4;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double scaledX = x;
        double scaledX2 = scaledX * scaledX;
        double expected = ((scaledX2 - 20) * scaledX2 + 120) / 120;
        assertEquals(expected, result, 1e-10, "sinc(1e-4) should return the Taylor series approximation");
    }

    @Test
    @DisplayName("value(6.0e-3) with normalized=false and |x| equals SHORTCUT evaluates the Taylor series branch")
    public void TC15_testValueAt6eMinus3NormalizedFalse() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = 6.0e-3;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double scaledX = x;
        double scaledX2 = scaledX * scaledX;
        double expected = ((scaledX2 - 20) * scaledX2 + 120) / 120;
        assertEquals(expected, result, 1e-10, "sinc(6.0e-3) should return the Taylor series approximation at boundary");
    }

    @Test
    @DisplayName("value(1.0e-2) with normalized=false and |x| > SHORTCUT evaluates the sine definition expression branch")
    public void TC16_testValueAt1eMinus2NormalizedFalse() {
        // GIVEN
        Sinc sinc = new Sinc(false);
        double x = 1.0e-2;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double expected = FastMath.sin(x) / x;
        assertEquals(expected, result, 1e-10, "sinc(1.0e-2) should return FastMath.sin(x)/x");
    }

    @Test
    @DisplayName("value(0.0) with normalized=true evaluates the Taylor series branch")
    public void TC17_testValueAtZeroNormalizedTrue() {
        // GIVEN
        Sinc sinc = new Sinc(true);
        double x = 0.0;

        // WHEN
        double result = sinc.value(x);

        // THEN
        double expected = 1.0;
        assertEquals(expected, result, 1e-10, "sinc(0.0) with normalization should return 1.0");
    }
}