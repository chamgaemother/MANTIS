package com.fasterxml.jackson.databind.introspect;
import java.io.*;
import java.util.*;
import com.fasterxml.jackson.databind.PropertyName;

import com.fasterxml.jackson.databind.MapperFeature;
import java.lang.reflect.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class POJOPropertyBuilder_removeNonVisible_0_3_Test {

    @Test
    @DisplayName("removeNonVisible with inverse access enabled and access type READ_ONLY")
    public void TC11_removeNonVisible_with_inverse_access_enabled_and_READ_ONLY() throws Exception {
        // GIVEN
        boolean flag = true;
        // Create a mock POJOPropertiesCollector, even if not used, for dependency
        POJOPropertiesCollector collector = org.mockito.Mockito.mock(POJOPropertiesCollector.class);
        // Configure the mock MapperConfig
        MapperConfig<?> config = org.mockito.Mockito.mock(MapperConfig.class);
        org.mockito.Mockito.when(config.isEnabled(MapperFeature.INVERSE_READ_WRITE_ACCESS)).thenReturn(true);
        POJOPropertyBuilder builder = new POJOPropertyBuilder(config, null, true, new PropertyName("name"));
        builder.removeNonVisible(flag, collector);

        // THEN
        assertEquals(JsonProperty.Access.WRITE_ONLY, builder.findAccess(), "Access type should be WRITE_ONLY");

        // Verify that getters are removed (_getters is null)
        Field gettersField = POJOPropertyBuilder.class.getDeclaredField("_getters");
        gettersField.setAccessible(true);
        Object getters = gettersField.get(builder);
        assertNull(getters, "Getters should be removed and set to null.");

        // Verify that fields are set to null when forSerialization is true
        Field fieldsField = POJOPropertyBuilder.class.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        Object fields = fieldsField.get(builder);
        assertNull(fields, "Fields should be set to null when forSerialization is true.");
    }

    @Test
    @DisplayName("removeNonVisible with access type AUTO and inferMutators false with null mutators")
    public void TC12_removeNonVisible_Auto_with_inferMutators_false_and_getters_null() throws Exception {
        // GIVEN
        boolean flag = false;
        // Create a mock POJOPropertiesCollector to match the method signature
        POJOPropertiesCollector collector = org.mockito.Mockito.mock(POJOPropertiesCollector.class);
        // Configure MapperConfig
        MapperConfig<?> config = org.mockito.Mockito.mock(MapperConfig.class);
        POJOPropertyBuilder builder = new POJOPropertyBuilder(config, null, false, new PropertyName("name"));
        builder.removeNonVisible(flag, collector);

        // THEN
        assertEquals(JsonProperty.Access.AUTO, builder.findAccess(), "Access type should remain AUTO");

        // Verify that fields are processed based on visibility
        Field fieldsField = POJOPropertyBuilder.class.getDeclaredField("_fields");
        fieldsField.setAccessible(true);
        Object fields = fieldsField.get(builder);
        assertNull(fields, "Fields should still be set to null.");

        // Verify that setters are processed based on visibility
        Field settersField = POJOPropertyBuilder.class.getDeclaredField("_setters");
        settersField.setAccessible(true);
        Object setters = settersField.get(builder);
        assertNull(setters, "Setters should be set to null if not visible.");
    }
}