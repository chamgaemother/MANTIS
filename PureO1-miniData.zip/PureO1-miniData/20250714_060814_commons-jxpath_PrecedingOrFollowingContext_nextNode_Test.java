package org.apache.commons.jxpath.ri.axes;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Stack;

import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

class PrecedingOrFollowingContextTest {

    private EvalContext parentContext;
    private NodeTest nodeTest;
    private NodePointer currentNodePointer;
    private NodeIterator nodeIterator;
    private NodePointer parentNodePointer;
    private PrecedingOrFollowingContext context;

    @BeforeEach
    void setUp() {
        parentContext = mock(EvalContext.class);
        nodeTest = mock(NodeTest.class);
        currentNodePointer = mock(NodePointer.class);
        nodeIterator = mock(NodeIterator.class);
        parentNodePointer = mock(NodePointer.class);

        when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
        when(currentNodePointer.getParent()).thenReturn(parentNodePointer);
        when(parentNodePointer.childIterator(any(), anyBoolean(), any())).thenReturn(nodeIterator);

        context = new PrecedingOrFollowingContext(parentContext, nodeTest, false);
    }

    @Test
    void testNextNode_FirstCall_SuccessfulIteration() {
        when(currentNodePointer.getParent()).thenReturn(parentNodePointer);
        when(parentNodePointer.childIterator(null, false, currentNodePointer)).thenReturn(nodeIterator);
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(mock(NodePointer.class));
        when(nodeTest.matches(any())).thenReturn(true);

        boolean result = context.nextNode();
        assertTrue(result);
        assertEquals(1, context.getPosition());
    }

    @Test
    void testNextNode_FirstCall_NoParent() {
        when(parentContext.getCurrentNodePointer()).thenReturn(mock(NodePointer.class));
        when(currentNodePointer.getParent()).thenReturn(null);

        boolean result = context.nextNode();
        assertFalse(result);
    }

    @Test
    void testNextNode_NoMoreNodes() {
        when(nodeIterator.setPosition(anyInt())).thenReturn(false);

        boolean result = context.nextNode();
        assertFalse(result);
    }

    @Test
    void testNextNode_WithChildren_PushToStack() {
        NodePointer childPointer = mock(NodePointer.class);
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(childPointer);
        when(childPointer.isLeaf()).thenReturn(false);
        when(childPointer.childIterator(null, false, null)).thenReturn(mock(NodeIterator.class));
        when(nodeTest.matches(childPointer)).thenReturn(true);

        boolean result = context.nextNode();
        assertTrue(result);
        verify(nodeTest).matches(childPointer);
    }

    @Test
    void testNextNode_ReverseIteration() {
        context = new PrecedingOrFollowingContext(parentContext, nodeTest, true);
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(currentNodePointer.isLeaf()).thenReturn(true);
        when(nodeTest.matches(currentNodePointer)).thenReturn(true);

        boolean result = context.nextNode();
        assertTrue(result);
    }

    @Test
    void testNextNode_ReverseIteration_NoMatch_PopStack() {
        context = new PrecedingOrFollowingContext(parentContext, nodeTest, true);
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(currentNodePointer.isLeaf()).thenReturn(true);
        when(nodeTest.matches(currentNodePointer)).thenReturn(false);
        when(nodeIterator.setPosition(2)).thenReturn(false);

        boolean result = context.nextNode();
        assertFalse(result);
    }

    @Test
    void testNextNode_MultipleIterations() {
        NodePointer child1 = mock(NodePointer.class);
        NodePointer child2 = mock(NodePointer.class);
        NodeIterator iterator1 = mock(NodeIterator.class);
        NodeIterator iterator2 = mock(NodeIterator.class);

        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(child1);
        when(child1.isLeaf()).thenReturn(true);
        when(nodeTest.matches(child1)).thenReturn(true);

        boolean first = context.nextNode();
        assertTrue(first);
        assertEquals(1, context.getPosition());

        when(nodeIterator.setPosition(2)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(child2);
        when(child2.isLeaf()).thenReturn(true);
        when(nodeTest.matches(child2)).thenReturn(true);

        boolean second = context.nextNode();
        assertTrue(second);
        assertEquals(2, context.getPosition());
    }

    @Test
    void testNextNode_ResetAndSetPosition() {
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(nodeTest.matches(currentNodePointer)).thenReturn(true);

        assertTrue(context.nextNode());
        assertEquals(1, context.getPosition());

        context.reset();
        assertEquals(0, context.getPosition());

        assertTrue(context.nextNode());
        assertEquals(1, context.getPosition());
    }

    @Test
    void testNextNode_SetPositionBeyondLimit() {
        when(nodeIterator.setPosition(anyInt())).thenReturn(false);

        boolean result = context.setPosition(10);
        assertFalse(result);
        assertEquals(0, context.getPosition());
    }

    @Test
    void testNextNode_SetPositionWithinLimit() {
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(nodeTest.matches(currentNodePointer)).thenReturn(true);

        boolean result = context.setPosition(1);
        assertTrue(result);
        assertEquals(1, context.getPosition());
    }

    @Test
    void testGetCurrentNodePointer() {
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);
        when(nodeTest.matches(currentNodePointer)).thenReturn(true);
        context.nextNode();
        assertEquals(currentNodePointer, context.getCurrentNodePointer());
    }

    @Test
    void testGetDocumentOrder_Normal() {
        assertEquals(1, context.getDocumentOrder());
    }

    @Test
    void testGetDocumentOrder_Reverse() {
        context = new PrecedingOrFollowingContext(parentContext, nodeTest, true);
        assertEquals(-1, context.getDocumentOrder());
    }

    @Test
    void testNextNode_ParentIsRoot() {
        when(parentNodePointer.isRoot()).thenReturn(true);
        boolean result = context.nextNode();
        assertFalse(result);
    }

    @Test
    void testNextNode_CurrentNodeIsLeaf() {
        when(currentNodePointer.isLeaf()).thenReturn(true);
        when(nodeTest.matches(currentNodePointer)).thenReturn(true);
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(currentNodePointer);

        boolean result = context.nextNode();
        assertTrue(result);
    }

    @Test
    void testNextNode_CurrentNodeIsNotLeaf() {
        NodePointer child = mock(NodePointer.class);
        when(currentNodePointer.isLeaf()).thenReturn(false);
        when(nodeIterator.setPosition(1)).thenReturn(true);
        when(nodeIterator.getNodePointer()).thenReturn(child);
        when(child.isLeaf()).thenReturn(true);
        when(nodeTest.matches(child)).thenReturn(true;

        boolean result = context.nextNode();
        assertTrue(result);
    }
}