package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.jxpath.ri.parser.XPathParser;
import org.apache.commons.jxpath.ri.parser.Token;
import org.apache.commons.jxpath.ri.parser.ParseException;

import java.lang.reflect.Field;

public class XPathParser_NCName_0_3_Test {

    // Define constants for function kinds
    private static final int FUNCTION_POSITION = XPathParserConstants.FUNCTION_POSITION;
    private static final int FUNCTION_COUNT = XPathParserConstants.FUNCTION_COUNT;
    private static final int FUNCTION_ID = XPathParserConstants.FUNCTION_ID;
    private static final int FUNCTION_LOCAL_NAME = XPathParserConstants.FUNCTION_LOCAL_NAME;
    private static final int FUNCTION_NAMESPACE_URI = XPathParserConstants.FUNCTION_NAMESPACE_URI;

    @Test
    @DisplayName("NCName() processes kind FUNCTION_POSITION and returns token image")
    public void TC11() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Create token with FUNCTION_POSITION kind and image
        Token token = new Token();
        Class<?> tokenClass = token.getClass();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, FUNCTION_POSITION);

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "FUNCTION_POSITION_IMAGE");

        // Set parser's jj_nt to the token
        Class<?> parserClass = parser.getClass();
        Field jj_ntField = parserClass.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName
        String result = parser.NCName();

        // Assert
        assertEquals(token.image, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_COUNT and returns token image")
    public void TC12() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Create token with FUNCTION_COUNT kind and image
        Token token = new Token();
        Class<?> tokenClass = token.getClass();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, FUNCTION_COUNT);

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "FUNCTION_COUNT_IMAGE");

        // Set parser's jj_nt to the token
        Class<?> parserClass = parser.getClass();
        Field jj_ntField = parserClass.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName
        String result = parser.NCName();

        // Assert
        assertEquals(token.image, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_ID and returns token image")
    public void TC13() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Create token with FUNCTION_ID kind and image
        Token token = new Token();
        Class<?> tokenClass = token.getClass();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, FUNCTION_ID);

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "FUNCTION_ID_IMAGE");

        // Set parser's jj_nt to the token
        Class<?> parserClass = parser.getClass();
        Field jj_ntField = parserClass.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName
        String result = parser.NCName();

        // Assert
        assertEquals(token.image, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_LOCAL_NAME and returns token image")
    public void TC14() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Create token with FUNCTION_LOCAL_NAME kind and image
        Token token = new Token();
        Class<?> tokenClass = token.getClass();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, FUNCTION_LOCAL_NAME);

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "FUNCTION_LOCAL_NAME_IMAGE");

        // Set parser's jj_nt to the token
        Class<?> parserClass = parser.getClass();
        Field jj_ntField = parserClass.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName
        String result = parser.NCName();

        // Assert
        assertEquals(token.image, result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_NAMESPACE_URI and returns token image")
    public void TC15() throws Exception {
        // Initialize parser
        XPathParser parser = new XPathParser((XPathParserTokenManager) null);

        // Create token with FUNCTION_NAMESPACE_URI kind and image
        Token token = new Token();
        Class<?> tokenClass = token.getClass();

        Field kindField = tokenClass.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(token, FUNCTION_NAMESPACE_URI);

        Field imageField = tokenClass.getDeclaredField("image");
        imageField.setAccessible(true);
        imageField.set(token, "FUNCTION_NAMESPACE_URI_IMAGE");

        // Set parser's jj_nt to the token
        Class<?> parserClass = parser.getClass();
        Field jj_ntField = parserClass.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        jj_ntField.set(parser, token);

        // Call NCName
        String result = parser.NCName();

        // Assert
        assertEquals(token.image, result);
    }

}