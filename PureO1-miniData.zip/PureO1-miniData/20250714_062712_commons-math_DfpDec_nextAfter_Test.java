package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DfpDecTest {

    @Test
    void testNextAfter_NullInput() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field);
        assertThrows(NullPointerException.class, () -> dfp.nextAfter(null));
    }

    @Test
    void testNextAfter_DifferentRadixDigits() {
        DfpField field1 = new DfpField(10);
        DfpField field2 = new DfpField(12);
        DfpDec dfp = new DfpDec(field1);
        DfpDec x = new DfpDec(field2);
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.isNaN());
        assertEquals(Dfp.FIELD_INVALID, field1.getIEEEFlagsBits());
    }

    @Test
    void testNextAfter_EqualsInput() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "123.456");
        DfpDec x = new DfpDec(field, "123.456");
        Dfp result = dfp.nextAfter(x);
        assertEquals(x, result);
    }

    @Test
    void testNextAfter_ThisLessThanX_Positive() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "100.0");
        DfpDec x = new DfpDec(field, "200.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.greaterThan(dfp));
    }

    @Test
    void testNextAfter_ThisLessThanX_Zero() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "0.0");
        DfpDec x = new DfpDec(field, "1.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.greaterThan(dfp));
    }

    @Test
    void testNextAfter_ThisLessThanX_IncrementZero() {
        DfpField field = new DfpField(1); // Minimal precision to force inc=0
        DfpDec dfp = new DfpDec(field, "1.0");
        DfpDec x = new DfpDec(field, "2.0");
        Dfp result = dfp.nextAfter(x);
        assertEquals(dfp, result);
    }

    @Test
    void testNextAfter_ThisGreaterThanX_Positive() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "200.0");
        DfpDec x = new DfpDec(field, "100.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.lessThan(dfp));
    }

    @Test
    void testNextAfter_ThisGreaterThanX_Negative() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "-100.0");
        DfpDec x = new DfpDec(field, "-200.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.lessThan(dfp));
    }

    @Test
    void testNextAfter_ThisEqualsZero_XZero() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "0.0");
        DfpDec x = new DfpDec(field, "0.0");
        Dfp result = dfp.nextAfter(x);
        assertEquals(dfp, result);
    }

    @Test
    void testNextAfter_ResultInfinite() {
        DfpField field = new DfpField(1); // Low precision to cause overflow
        DfpDec dfp = new DfpDec(field, "1.0e308");
        DfpDec x = new DfpDec(field, "1.0e309"); // Assuming this causes infinity
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.isInfinite());
        assertTrue(field.getIEEEFlagsBits() & DfpField.FLAG_INEXACT);
    }

    @Test
    void testNextAfter_ResultZero_FromNonZero() {
        DfpField field = new DfpField(1000); // High precision
        DfpDec dfp = new DfpDec(field, "1.0e-4000"); // Subnormal number
        DfpDec x = new DfpDec(field, "0.0");
        Dfp result = dfp.nextAfter(x);
        assertEquals(0, result.compareTo(new DfpDec(field, "0.0")));
        assertTrue(field.getIEEEFlagsBits() & DfpField.FLAG_INEXACT);
    }

    @Test
    void testNextAfter_ThisNegativeUp() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "-100.0");
        DfpDec x = new DfpDec(field, "-50.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.greaterThan(dfp));
    }

    @Test
    void testNextAfter_ThisNegativeDown() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "-100.0");
        DfpDec x = new DfpDec(field, "-150.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.lessThan(dfp));
    }

    @Test
    void testNextAfter_ThisNegativeIncrementZero() {
        DfpField field = new DfpField(1); // Minimal precision to force inc=0
        DfpDec dfp = new DfpDec(field, "-1.0");
        DfpDec x = new DfpDec(field, "-2.0");
        Dfp result = dfp.nextAfter(x);
        assertEquals(dfp, result);
    }

    @Test
    void testNextAfter_XNaN() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "100.0");
        DfpDec x = new DfpDec(field, Double.NaN);
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.isNaN());
    }

    @Test
    void testNextAfter_XInfinite() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "100.0");
        DfpDec x = new DfpDec(field, Double.POSITIVE_INFINITY);
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.greaterThan(dfp));
    }

    @Test
    void testNextAfter_ThisInfinite() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, Double.POSITIVE_INFINITY);
        DfpDec x = new DfpDec(field, "100.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.lessThan(dfp));
        assertTrue(field.getIEEEFlagsBits() & DfpField.FLAG_INEXACT);
    }

    @Test
    void testNextAfter_ThisZeroUpPositive() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "0.0");
        DfpDec x = new DfpDec(field, "1.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.greaterThan(dfp));
    }

    @Test
    void testNextAfter_ThisZeroUpNegative() {
        DfpField field = new DfpField(10);
        DfpDec dfp = new DfpDec(field, "0.0");
        DfpDec x = new DfpDec(field, "-1.0");
        Dfp result = dfp.nextAfter(x);
        assertTrue(result.lessThan(dfp));
    }

    @Test
    void testNextAfter_RoundingHalfUp() {
        DfpField field = new DfpField(10);
        field.setRoundingMode(DfpField.ROUND_HALF_UP);
        DfpDec dfp = new DfpDec(field, "1.5000");
        DfpDec x = new DfpDec(field, "2.0");
        Dfp result = dfp.nextAfter(x);
        // Expect to round up to 2.0
        assertEquals(new DfpDec(field, "2.0"), result);
    }

    @Test
    void testNextAfter_RoundingHalfDown() {
        DfpField field = new DfpField(10);
        field.setRoundingMode(DfpField.ROUND_HALF_DOWN);
        DfpDec dfp = new DfpDec(field, "1.5000");
        DfpDec x = new DfpDec(field, "2.0");
        Dfp result = dfp.nextAfter(x);
        // Expect to round down to 1.0
        assertEquals(new DfpDec(field, "1.0"), result);
    }

    @Test
    void testNextAfter_RoundingCeil() {
        DfpField field = new DfpField(10);
        field.setRoundingMode(DfpField.ROUND_CEIL);
        DfpDec dfp = new DfpDec(field, "1.1");
        DfpDec x = new DfpDec(field, "2.0");
        Dfp result = dfp.nextAfter(x);
        // Expect to round up
        assertEquals(new DfpDec(field, "2.0"), result);
    }

    @Test
    void testNextAfter_RoundingFloor() {
        DfpField field = new DfpField(10);
        field.setRoundingMode(DfpField.ROUND_FLOOR);
        DfpDec dfp = new DfpDec(field, "-1.1");
        DfpDec x = new DfpDec(field, "-2.0");
        Dfp result = dfp.nextAfter(x);
        // Expect to round down
        assertEquals(new DfpDec(field, "-2.0"), result);
    }

    @Test
    void testNextAfter_RoundingHalfEven() {
        DfpField field = new DfpField(10);
        field.setRoundingMode(DfpField.ROUND_HALF_EVEN);
        DfpDec dfp = new DfpDec(field, "1.5000");
        DfpDec x = new DfpDec(field, "2.0");
        Dfp result = dfp.nextAfter(x);
        // 1.5 is odd, should round to 2.0
        assertEquals(new DfpDec(field, "2.0"), result);
        
        dfp = new DfpDec(field, "2.5000");
        result = dfp.nextAfter(x);
        // 2.5 is even, should round to 2.0
        assertEquals(new DfpDec(field, "2.0"), result);
    }

    @Test
    void testNextAfter_RoundingHalfOdd() {
        DfpField field = new DfpField(10);
        field.setRoundingMode(DfpField.ROUND_HALF_ODD);
        DfpDec dfp = new DfpDec(field, "1.5000");
        DfpDec x = new DfpDec(field, "2.0");
        Dfp result = dfp.nextAfter(x);
        // 1.5 is odd, should round to 2.0
        assertEquals(new DfpDec(field, "2.0"), result);
        
        dfp = new DfpDec(field, "2.5000");
        result = dfp.nextAfter(x);
        // 2.5 is even, should round to 3.0
        assertEquals(new DfpDec(field, "3.0"), result);
    }
}