
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

public class ClassUtils_isAssignable_1_2_Test {

    @Test
    @DisplayName("cls is wrapper (Integer) and toClass is primitive (int) with autoboxing=true")
    public void TC11() {
        // GIVEN
        Class<?> cls = Integer.class;
        Class<?> toClass = int.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Void) and toClass is primitive (boolean) with autoboxing=true")
    public void TC12() {
        // GIVEN
        Class<?> cls = Void.class;
        Class<?> toClass = boolean.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is wrapper (Integer) and toClass is primitive (int) with autoboxing=false")
    public void TC13() {
        // GIVEN
        Class<?> cls = Integer.class;
        Class<?> toClass = int.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is wrapper (Integer) and toClass is primitive (int) with autoboxing=true")
    public void TC14() {
        // GIVEN
        Class<?> cls = Integer.class;
        Class<?> toClass = int.class;
        boolean autoboxing = true;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is non-primitive (ArrayList) and toClass is superclass (List) with autoboxing=false")
    public void TC15() {
        // GIVEN
        Class<?> cls = ArrayList.class;
        Class<?> toClass = List.class;
        boolean autoboxing = false;

        // WHEN
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // THEN
        assertTrue(result);
    }

}