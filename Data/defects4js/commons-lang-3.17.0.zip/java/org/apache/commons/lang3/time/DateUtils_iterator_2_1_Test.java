package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Iterator;

public class DateUtils_iterator_2_1_Test {

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_WEEK_CENTER and calendar on Wednesday requiring start and end cutoff adjustments")
    public void testTC26_iteratorRangeWeekCenterOnWednesday() {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.SEPTEMBER, 20); // September 20, 2023 is a Wednesday
        int rangeStyle = DateUtils.RANGE_WEEK_CENTER;

        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // Then
        assertNotNull(iterator, "Iterator should not be null");
        assertTrue(iterator.hasNext(), "Iterator should have elements");

        Calendar first = iterator.next();
        assertEquals(18, first.get(Calendar.DAY_OF_MONTH), "First date should be Monday, September 18, 2023");

        Calendar last = first;
        while (iterator.hasNext()) {
            last = iterator.next();
        }
        assertEquals(24, last.get(Calendar.DAY_OF_MONTH), "Last date should be Sunday, September 24, 2023");
    }

    @Test
    @DisplayName("iterator with rangeStyle = RANGE_MONTH_MONDAY and calendar not on Monday requiring start cutoff adjustment")
    public void testTC27_iteratorRangeMonthMondayNotOnMonday() {
        // Given
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.OCTOBER, 4); // October 4, 2023 is a Wednesday
        int rangeStyle = DateUtils.RANGE_MONTH_MONDAY;

        // When
        Iterator<Calendar> iterator = DateUtils.iterator(calendar, rangeStyle);

        // Then
        assertNotNull(iterator, "Iterator should not be null");
        assertTrue(iterator.hasNext(), "Iterator should have elements");

        Calendar first = iterator.next();
        assertEquals(2, first.get(Calendar.DAY_OF_MONTH), "First date should be Monday, October 2, 2023");

        // Iterate to verify the last date is correct (Monday to Sunday of the month)
        Calendar last = first;
        while (iterator.hasNext()) {
            last = iterator.next();
        }
        assertEquals(29, last.get(Calendar.DAY_OF_MONTH), "Last date should be Sunday, October 29, 2023");
    }
}