
package org.apache.commons.csv;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CSVFormat_equals_2_1_Test {

    @Test
    @DisplayName("equals returns false when one CSVFormat has headers set and the other has headers null")
    public void TC26_equals_withOneHeadersSetAndOtherHeadersNull() {
        // Arrange
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeader("A", "B").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeader((String[])null).build();

        // Act
        boolean result = format1.equals(format2);

        // Assert
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns false when one CSVFormat has headerComments set and the other has headerComments null")
    public void TC27_equals_withOneHeaderCommentsSetAndOtherHeaderCommentsNull() {
        // Arrange
        CSVFormat format1 = CSVFormat.DEFAULT.builder().setHeaderComments("Comment1").build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder().setHeaderComments((String[])null).build();

        // Act
        boolean result = format1.equals(format2);

        // Assert
        assertFalse(result);
    }
}