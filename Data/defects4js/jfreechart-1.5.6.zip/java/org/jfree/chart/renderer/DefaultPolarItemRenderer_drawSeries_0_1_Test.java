package org.jfree.chart.renderer;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.axis.ValueAxis;

import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PolarPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.XYItemEntity;
import org.jfree.chart.util.ShapeUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.Composite;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D;

import static org.mockito.Mockito.*;

public class DefaultPolarItemRenderer_drawSeries_0_1_Test {

    @Test
    @DisplayName("drawSeries with zero data points should return early without drawing")
    void TC01_drawSeries_with_zero_data_points_should_return_early_without_drawing() throws Exception {
        // Given
        DefaultPolarItemRenderer renderer = new DefaultPolarItemRenderer();
        
        XYDataset dataset = mock(XYDataset.class);
        int seriesIndex = 0;
        when(dataset.getItemCount(seriesIndex)).thenReturn(0);
        
        PolarPlot plot = mock(PolarPlot.class);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        
        // When
        renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);
        
        // Then
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("drawSeries with one data point without connecting first and last point")
    void TC02_drawSeries_with_one_data_point_no_connect_no_fill_no_shapes() throws Exception {
        // Given
        DefaultPolarItemRenderer renderer = spy(DefaultPolarItemRenderer.class);
        
        XYDataset dataset = mock(XYDataset.class);
        int seriesIndex = 0;
        when(dataset.getItemCount(seriesIndex)).thenReturn(1);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        doReturn(false).when(renderer).getConnectFirstAndLastPoint();
        doReturn(false).when(renderer).isSeriesFilled(seriesIndex);
        doReturn(false).when(renderer).getShapesVisible();
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        
        // When
        renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);
        
        // Then
        verify(g2).draw(any(Shape.class));
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    @DisplayName("drawSeries with multiple data points and connecting first and last point")
    void TC03_drawSeries_with_multiple_data_points_connect_fill_draw_outline_shapes() throws Exception {
        // Given
        DefaultPolarItemRenderer renderer = spy(DefaultPolarItemRenderer.class);
        
        XYDataset dataset = mock(XYDataset.class);
        int seriesIndex = 0;
        when(dataset.getItemCount(seriesIndex)).thenReturn(3);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        doReturn(true).when(renderer).getConnectFirstAndLastPoint();
        doReturn(true).when(renderer).isSeriesFilled(seriesIndex);
        doReturn(true).when(renderer).getDrawOutlineWhenFilled();
        doReturn(true).when(renderer).getShapesVisible();
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        
        // When
        renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);
        
        // Then
        verify(g2).fill(any(Shape.class));
        verify(g2, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    @DisplayName("drawSeries with multiple data points without connecting first and last point")
    void TC04_drawSeries_with_multiple_data_points_no_connect_fill_draw_outline_no_shapes() throws Exception {
        // Given
        DefaultPolarItemRenderer renderer = spy(DefaultPolarItemRenderer.class);
        
        XYDataset dataset = mock(XYDataset.class);
        int seriesIndex = 0;
        when(dataset.getItemCount(seriesIndex)).thenReturn(4);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        doReturn(false).when(renderer).getConnectFirstAndLastPoint();
        doReturn(true).when(renderer).isSeriesFilled(seriesIndex);
        doReturn(true).when(renderer).getDrawOutlineWhenFilled();
        doReturn(false).when(renderer).getShapesVisible();
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        
        // When
        renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);
        
        // Then
        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
        verify(g2, never()).setPaint(any(Paint.class));
    }

    @Test
    @DisplayName("drawSeries with one data point and connecting first and last point")
    void TC05_drawSeries_with_one_data_point_connect_no_fill_no_shapes() throws Exception {
        // Given
        DefaultPolarItemRenderer renderer = spy(DefaultPolarItemRenderer.class);
        
        XYDataset dataset = mock(XYDataset.class);
        int seriesIndex = 0;
        when(dataset.getItemCount(seriesIndex)).thenReturn(1);
        
        PolarPlot plot = mock(PolarPlot.class);
        when(plot.indexOf(dataset)).thenReturn(0);
        ValueAxis axis = mock(ValueAxis.class);
        when(plot.getAxisForDataset(0)).thenReturn(axis);
        
        doReturn(true).when(renderer).getConnectFirstAndLastPoint();
        doReturn(false).when(renderer).isSeriesFilled(seriesIndex);
        doReturn(false).when(renderer).getShapesVisible();
        
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        
        // When
        renderer.drawSeries(g2, dataArea, info, plot, dataset, seriesIndex);
        
        // Then
        verify(g2).draw(any(Shape.class));
        verify(g2, never()).fill(any(Shape.class));
    }
}