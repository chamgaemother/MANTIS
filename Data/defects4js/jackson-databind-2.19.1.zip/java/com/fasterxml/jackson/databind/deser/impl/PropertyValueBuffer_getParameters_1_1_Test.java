package com.fasterxml.jackson.databind.deser.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.BitSet;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import com.fasterxml.jackson.databind.deser.SettableAnyProperty;
import com.fasterxml.jackson.databind.JsonMappingException;

public class PropertyValueBuffer_getParameters_1_1_Test {

    /**
     * Test TC12: getParameters with _paramsNeeded <= 0, _anyParamSetter is null,
     * FAIL_ON_NULL_CREATOR_PROPERTIES disabled, some creatorParameters are missing
     */
    @Test
    @DisplayName("getParameters with _paramsNeeded <= 0, _anyParamSetter is null, FAIL_ON_NULL_CREATOR_PROPERTIES disabled, some creatorParameters are missing")
    void TC12_getParameters_MissingCreatorParameters_NoException() throws Exception {
        // Mock dependencies
        JsonParser parser = mock(JsonParser.class);
        DeserializationContext context = mock(DeserializationContext.class);
        when(context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)).thenReturn(false);
        SettableBeanProperty[] props = new SettableBeanProperty[3];
        for (int i = 0; i < props.length; i++) {
            props[i] = mock(SettableBeanProperty.class);
            when(props[i].getCreatorIndex()).thenReturn(i);
            when(props[i].getName()).thenReturn("prop" + i);
        }
        
        // Initialize PropertyValueBuffer via reflection
        PropertyValueBuffer buffer = new PropertyValueBuffer(parser, context, 0, null, null);
        
        // Set _creatorParameters with some nulls via reflection
        Field creatorParametersField = PropertyValueBuffer.class.getDeclaredField("_creatorParameters");
        creatorParametersField.setAccessible(true);
        Object[] creatorParameters = new Object[] { "value1", null, "value3" };
        creatorParametersField.set(buffer, creatorParameters);
        
        // Invoke getParameters
        Method getParametersMethod = PropertyValueBuffer.class.getDeclaredMethod("getParameters", SettableBeanProperty[].class);
        getParametersMethod.setAccessible(true);
        Object[] result = (Object[]) getParametersMethod.invoke(buffer, (Object) props);
        
        // Assertions
        assertEquals("value1", result[0], "Creator parameter 0 should be 'value1'");
        assertNotNull(result[1], "Creator parameter 1 should not be null"); // Default or absent value assigned
        assertEquals("value3", result[2], "Creator parameter 2 should be 'value3'");
    }

    /**
     * Test TC13: getParameters with _paramsNeeded > 0, _paramsSeenBig is not null,
     * all creatorParameters are present
     */
    @Test
    @DisplayName("getParameters with _paramsNeeded > 0, _paramsSeenBig is not null, all creatorParameters are present")
    void TC13_getParameters_AllCreatorParametersPresent_NoException() throws Exception {
        // Mock dependencies
        JsonParser parser = mock(JsonParser.class);
        DeserializationContext context = mock(DeserializationContext.class);
        when(context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)).thenReturn(true);
        SettableBeanProperty[] props = new SettableBeanProperty[32];
        for (int i = 0; i < 32; i++) {
            props[i] = mock(SettableBeanProperty.class);
            when(props[i].getCreatorIndex()).thenReturn(i);
            when(props[i].getName()).thenReturn("prop" + i);
        }
        
        // Initialize PropertyValueBuffer via reflection with paramCount = 32 to set _paramsSeenBig
        SettableAnyProperty anyParamSetter = null;
        PropertyValueBuffer buffer = new PropertyValueBuffer(parser, context, 32, null, anyParamSetter);
        
        // Set _paramsSeenBig to all bits set via reflection
        Field paramsSeenBigField = PropertyValueBuffer.class.getDeclaredField("_paramsSeenBig");
        paramsSeenBigField.setAccessible(true);
        BitSet paramsSeenBig = new BitSet();
        paramsSeenBig.set(0, 32);
        paramsSeenBigField.set(buffer, paramsSeenBig);
        
        // Set _creatorParameters with non-null values via reflection
        Field creatorParametersField = PropertyValueBuffer.class.getDeclaredField("_creatorParameters");
        creatorParametersField.setAccessible(true);
        Object[] creatorParameters = new Object[32];
        for (int i = 0; i < 32; i++) {
            creatorParameters[i] = "value" + i;
        }
        creatorParametersField.set(buffer, creatorParameters);
        
        // Invoke getParameters
        Method getParametersMethod = PropertyValueBuffer.class.getDeclaredMethod("getParameters", SettableBeanProperty[].class);
        getParametersMethod.setAccessible(true);
        Object[] result = (Object[]) getParametersMethod.invoke(buffer, (Object) props);
        
        // Assertions
        for (int i = 0; i < 32; i++) {
            assertEquals("value" + i, result[i], "Creator parameter " + i + " should be 'value" + i + "'");
        }
    }
}