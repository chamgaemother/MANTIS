package org.jfree.chart;

import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseDragged_0_2_Test {

//     @Test
//     @DisplayName("mouseDragged handles panning when orientation is VERTICAL")
//     public void TC06_mouseDragged_handlesPanningWhenOrientationIsVERTICAL() throws Exception {
        // Arrange
//         JFreeChart chart = mock(JFreeChart.class);
//         Plot plot = mock(Plot.class);
//         when(chart.getPlot()).thenReturn(plot);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
        // Set private field 'panLast' via reflection
//         Field panLastField = ChartPanel.class.getDeclaredField("panLast");
//         panLastField.setAccessible(true);
//         panLastField.set(chartPanel, new Point(100, 100));
// 
        // Mock MouseEvent
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getX()).thenReturn(150);
//         when(e.getY()).thenReturn(150);
// 
        // Act
//         chartPanel.mouseDragged(e);
// 
        // Assert
//         verify(plot, times(1)).panDomainAxes(anyDouble(), any(), eq(new Point(100, 100)));
//         verify(plot, times(1)).panRangeAxes(anyDouble(), any(), eq(new Point(100, 100)));
//     }

//     @Test
//     @DisplayName("mouseDragged handles panning when orientation is HORIZONTAL")
//     public void TC07_mouseDragged_handlesPanningWhenOrientationIsHORIZONTAL() throws Exception {
        // Arrange
//         JFreeChart chart = mock(JFreeChart.class);
//         Plot plot = mock(Plot.class);
//         when(chart.getPlot()).thenReturn(plot);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
        // Set private field 'panLast' via reflection
//         Field panLastField = ChartPanel.class.getDeclaredField("panLast");
//         panLastField.setAccessible(true);
//         panLastField.set(chartPanel, new Point(200, 200));
// 
        // Mock MouseEvent
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getX()).thenReturn(250);
//         when(e.getY()).thenReturn(250);
// 
        // Act
//         chartPanel.mouseDragged(e);
// 
        // Assert
//         verify(plot, times(1)).panDomainAxes(anyDouble(), any(), eq(new Point(200, 200)));
//         verify(plot, times(1)).panRangeAxes(anyDouble(), any(), eq(new Point(200, 200)));
//     }

    @Test
    @DisplayName("mouseDragged returns early when zoomPoint is not set")
    public void TC08_mouseDragged_returnsEarlyWhenZoomPointIsNotSet() throws Exception {
        // Arrange
        JFreeChart chart = mock(JFreeChart.class);

        ChartPanel chartPanel = new ChartPanel(chart);

        // Set private fields 'panLast' and 'zoomPoint' to null via reflection
        Field panLastField = ChartPanel.class.getDeclaredField("panLast");
        panLastField.setAccessible(true);
        panLastField.set(chartPanel, null);

        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(chartPanel, null);

        // Mock MouseEvent
        MouseEvent e = mock(MouseEvent.class);

        // Spy on chartPanel to verify interactions
        ChartPanel spyChartPanel = Mockito.spy(chartPanel);

        // Act
        spyChartPanel.mouseDragged(e);

        // Assert
        // Verify that getGraphics is never called
        verify(spyChartPanel, never()).getGraphics();
    }

    @Test
    @DisplayName("mouseDragged performs zooming with buffer enabled")
    public void TC09_mouseDragged_performsZoomingWithBufferEnabled() throws Exception {
        // Arrange
        JFreeChart chart = mock(JFreeChart.class);

        ChartPanel chartPanel = new ChartPanel(chart);

        // Set private field 'zoomPoint' via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        zoomPointField.set(chartPanel, new Point2D.Double(100, 100));

        // Set private field 'useBuffer' to true via reflection
        Field useBufferField = ChartPanel.class.getDeclaredField("useBuffer");
        useBufferField.setAccessible(true);
        useBufferField.set(chartPanel, true);

        // Set private field 'orientation' to HORIZONTAL via reflection
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(chartPanel, PlotOrientation.HORIZONTAL);

        // Set private fields 'domainZoomable' and 'rangeZoomable' to true via reflection
        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.set(chartPanel, true);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.set(chartPanel, true);

        // Mock PlotRenderingInfo and getScreenDataArea
        PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
        Field infoField = ChartPanel.class.getDeclaredField("info");
        infoField.setAccessible(true);
        infoField.set(chartPanel, plotInfo);

        // Spy on chartPanel to mock getScreenDataArea
        ChartPanel spyChartPanel = Mockito.spy(chartPanel);
        when(spyChartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(new Rectangle2D.Double(0, 0, 400, 400));

        // Mock MouseEvent
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(150);
        when(e.getY()).thenReturn(150);

        // Act
        spyChartPanel.mouseDragged(e);

        // Assert
        verify(spyChartPanel, times(1)).repaint();
    }

//     @Test
//     @DisplayName("mouseDragged performs zooming without buffer using XOR mode")
//     public void TC10_mouseDragged_performsZoomingWithoutBufferUsingXORMode() throws Exception {
        // Arrange
//         JFreeChart chart = mock(JFreeChart.class);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
        // Set private field 'zoomPoint' via reflection
//         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
//         zoomPointField.setAccessible(true);
//         zoomPointField.set(chartPanel, new Point2D.Double(200, 200));
// 
        // Set private field 'useBuffer' to false via reflection
//         Field useBufferField = ChartPanel.class.getDeclaredField("useBuffer");
//         useBufferField.setAccessible(true);
//         useBufferField.set(chartPanel, false);
// 
        // Set private field 'orientation' to HORIZONTAL via reflection
//         Field orientationField = ChartPanel.class.getDeclaredField("orientation");
//         orientationField.setAccessible(true);
//         orientationField.set(chartPanel, PlotOrientation.HORIZONTAL);
// 
        // Set private fields 'domainZoomable' and 'rangeZoomable' to true via reflection
//         Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
//         domainZoomableField.setAccessible(true);
//         domainZoomableField.set(chartPanel, true);
// 
//         Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
//         rangeZoomableField.setAccessible(true);
//         rangeZoomableField.set(chartPanel, true);
// 
        // Mock PlotRenderingInfo and getScreenDataArea
//         PlotRenderingInfo plotInfo = mock(PlotRenderingInfo.class);
//         Field infoField = ChartPanel.class.getDeclaredField("info");
//         infoField.setAccessible(true);
//         infoField.set(chartPanel, plotInfo);
// 
        // Spy on chartPanel to mock getScreenDataArea and drawZoomRectangle
//         ChartPanel spyChartPanel = Mockito.spy(chartPanel);
//         when(spyChartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(new Rectangle2D.Double(0, 0, 400, 400));
// 
        // Mock MouseEvent
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getX()).thenReturn(250);
//         when(e.getY()).thenReturn(250);
// 
        // Mock Graphics2D
//         Graphics2D g2 = mock(Graphics2D.class);
//         when(spyChartPanel.getGraphics()).thenReturn(g2);
// 
        // Act
//         spyChartPanel.mouseDragged(e);
// 
        // Assert
//         verify(spyChartPanel, times(1)).drawZoomRectangle(g2, true);
//         verify(g2, times(1)).dispose();
//     }
}