import org.jfree.chart.block.BlockContainer;
import org.jfree.chart.block.BorderArrangement;
import org.jfree.chart.block.RectangleConstraint;
import org.jfree.chart.ui.Size2D;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.Range;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.Graphics2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BorderArrangementTest {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;
    private RectangleConstraint fixedConstraint;
    private RectangleConstraint noneConstraint;
    private RectangleConstraint rangeConstraint;

    @BeforeEach
    void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
        
        fixedConstraint = new RectangleConstraint(100.0, 200.0);
        noneConstraint = new RectangleConstraint(RectangleConstraint.NONE);
        rangeConstraint = new RectangleConstraint(new Range(50, 100), new Range(150, 200));
        
        when(container.toContentConstraint(any())).thenReturn(noneConstraint);
        when(container.calculateTotalWidth(anyDouble())).thenAnswer(invocation -> invocation.getArgument(0));
        when(container.calculateTotalHeight(anyDouble())).thenAnswer(invocation -> invocation.getArgument(0));
    }
    
    @Test
    void testArrangeNoConstraints() {
        when(container.toContentConstraint(any())).thenReturn(noneConstraint);
        Size2D size = arrangement.arrange(container, g2, noneConstraint);
        assertNotNull(size);
    }

    @Test
    void testArrangeFixedWidthNoneHeight() {
        when(container.toContentConstraint(any())).thenReturn(new RectangleConstraint(100.0, LengthConstraintType.FIXED, LengthConstraintType.NONE));
        arrangement.add(mock(Block.class), RectangleEdge.TOP);
        arrangement.add(mock(Block.class), RectangleEdge.LEFT);
        arrangement.add(mock(Block.class), RectangleEdge.RIGHT);
        arrangement.add(mock(Block.class), RectangleEdge.BOTTOM);
        arrangement.add(mock(Block.class), null);
        
        Size2D size = arrangement.arrange(container, g2, new RectangleConstraint(100.0, LengthConstraintType.FIXED, LengthConstraintType.NONE));
        assertNotNull(size);
    }

    @Test
    void testArrangeRRConstraints() {
        when(container.toContentConstraint(any())).thenReturn(new RectangleConstraint(new Range(0, 200), LengthConstraintType.RANGE, new Range(0, 300), LengthConstraintType.RANGE));
        arrangement.add(mock(Block.class), RectangleEdge.TOP);
        arrangement.add(mock(Block.class), RectangleEdge.LEFT);
        arrangement.add(mock(Block.class), RectangleEdge.RIGHT);
        arrangement.add(mock(Block.class), RectangleEdge.BOTTOM);
        arrangement.add(mock(Block.class), null);

        Size2D size = arrangement.arrange(container, g2, rangeConstraint);
        assertNotNull(size);
    }

    @Test
    void testArrangeNullKeyResultsInCenter() {
        Block centerBlock = mock(Block.class);
        arrangement.add(centerBlock, null);
        assertEquals(centerBlock, arrangement.centerBlock);
    }

    @Test
    void testArrangeFixedBothWidthAndHeight() {
        when(container.toContentConstraint(any())).thenReturn(new RectangleConstraint(100.0, LengthConstraintType.FIXED, 200.0, LengthConstraintType.FIXED));
        arrangement.add(mock(Block.class), RectangleEdge.TOP);
        arrangement.add(mock(Block.class), RectangleEdge.BOTTOM);
        arrangement.add(mock(Block.class), RectangleEdge.LEFT);
        arrangement.add(mock(Block.class), RectangleEdge.RIGHT);
        arrangement.add(mock(Block.class), null);
        
        Size2D size = arrangement.arrange(container, g2, fixedConstraint);
        assertNotNull(size);
        assertEquals(100.0, size.getWidth());
        assertEquals(200.0, size.getHeight());
    }

    @Test
    void testArrangeRangeFixedHeight() {
        arrangement.add(mock(Block.class), RectangleEdge.TOP);
        arrangement.add(mock(Block.class), RectangleEdge.BOTTOM);
        arrangement.add(mock(Block.class), RectangleEdge.LEFT);
        arrangement.add(mock(Block.class), RectangleEdge.RIGHT);
        arrangement.add(mock(Block.class), null);
        
        RectangleConstraint constraint = new RectangleConstraint(new Range(50, 100), 200.0, LengthConstraintType.FIXED);
        
        when(container.toContentConstraint(any())).thenReturn(constraint);
        assertThrows(RuntimeException.class, () -> arrangement.arrange(container, g2, constraint));
    }
}