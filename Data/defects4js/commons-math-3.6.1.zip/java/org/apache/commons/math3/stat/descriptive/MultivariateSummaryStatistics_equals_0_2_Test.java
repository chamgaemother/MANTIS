package org.apache.commons.math3.stat.descriptive;

import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.rank.Min;
import org.apache.commons.math3.stat.descriptive.summary.Sum;
import org.apache.commons.math3.stat.descriptive.summary.SumOfSquares;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class MultivariateSummaryStatistics_equals_0_2_Test {
    
    @Test
    @DisplayName("Equals returns false when means are not equal")
    void TC06_equalsWithDifferentMeans() {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
        stats1.setMeanImpl(new Mean[]{new Mean(), new Mean()});
        stats2.setMeanImpl(new Mean[]{new Mean(), new Mean()});
        stats1.addValue(new double[]{2.5, 3.5});
        stats2.addValue(new double[]{2.5, 4.0});

        // WHEN
        boolean result = stats1.equals(stats2);
        
        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Equals returns false when minimum values are not equal")
    void TC07_equalsWithDifferentMinimumValues() {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
        stats1.setMinImpl(new Min[]{new Min(), new Min()});
        stats2.setMinImpl(new Min[]{new Min(), new Min()});
        stats1.addValue(new double[]{0.5, 1.5});
        stats2.addValue(new double[]{0.5, 2.0});

        // WHEN
        boolean result = stats1.equals(stats2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Equals returns false when counts (N) are not equal")
    void TC08_equalsWithDifferentCounts() {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
        stats1.addValue(new double[]{1.0, 2.0});
        stats1.addValue(new double[]{1.0, 2.0});
        stats2.addValue(new double[]{1.0, 2.0});
        
        // WHEN
        boolean result = stats1.equals(stats2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Equals returns false when sums are not equal")
    void TC09_equalsWithDifferentSums() {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
        stats1.setSumImpl(new Sum[]{new Sum(), new Sum()});
        stats2.setSumImpl(new Sum[]{new Sum(), new Sum()});
        stats1.addValue(new double[]{50.0, 60.0});
        stats2.addValue(new double[]{50.0, 65.0});

        // WHEN
        boolean result = stats1.equals(stats2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("Equals returns false when sum of squares are not equal")
    void TC10_equalsWithDifferentSumOfSquares() {
        // GIVEN
        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
        stats1.setSumsqImpl(new SumOfSquares[]{new SumOfSquares(), new SumOfSquares()});
        stats2.setSumsqImpl(new SumOfSquares[]{new SumOfSquares(), new SumOfSquares()});
        stats1.addValue(new double[]{50.0, 60.0});
        stats2.addValue(new double[]{50.0, 65.0});

        // WHEN
        boolean result = stats1.equals(stats2);

        // THEN
        assertFalse(result);
    }
}