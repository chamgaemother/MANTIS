import static org.junit.jupiter.api.Assertions.*;

import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.w3c.dom.*;

public class DOMNodePointerTest {

    private DocumentBuilder builder;

    @BeforeEach
    public void setUp() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        builder = factory.newDocumentBuilder();
    }

    @Test
    public void setValue_OnTextNode_WithNonEmptyString_SetsNodeValue() throws Exception {
        Document doc = builder.newDocument();
        Text textNode = doc.createTextNode("Old Value");
        doc.appendChild(textNode);
        DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.getDefault());

        pointer.setValue("New Value");

        assertEquals("New Value", textNode.getNodeValue());
    }

    @Test
    public void setValue_OnTextNode_WithEmptyString_RemovesNode() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElement("parent");
        Text textNode = doc.createTextNode("Old Value");
        parent.appendChild(textNode);
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.getDefault());

        pointer.setValue("");

        assertFalse(parent.hasChildNodes());
    }

    @Test
    public void setValue_OnTextNode_WithNull_RemovesNode() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElement("parent");
        Text textNode = doc.createTextNode("Old Value");
        parent.appendChild(textNode);
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.getDefault());

        pointer.setValue(null);

        assertFalse(parent.hasChildNodes());
    }

    @Test
    public void setValue_OnTextNode_WithWhitespaceString_SetsTrimmedValue() throws Exception {
        Document doc = builder.newDocument();
        Text textNode = doc.createTextNode("   Old Value   ");
        doc.appendChild(textNode);
        DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.getDefault());

        pointer.setValue("   New Value   ");

        assertEquals("New Value", textNode.getNodeValue());
    }

    @Test
    public void setValue_OnElementNode_WithElement_AppendsClonedChildren() throws Exception {
        Document doc1 = builder.newDocument();
        Element element1 = doc1.createElement("child");
        element1.setTextContent("Content1");
        
        Document doc2 = builder.newDocument();
        Element parent = doc2.createElement("parent");
        parent.appendChild(doc2.createElement("existingChild"));
        doc2.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue(element1);

        NodeList children = parent.getChildNodes();
        assertEquals(1, children.getLength());
        Element clonedChild = (Element) children.item(0);
        assertEquals("child", clonedChild.getNodeName());
        assertEquals("Content1", clonedChild.getTextContent());
    }

    @Test
    public void setValue_OnElementNode_WithDocument_AppendsClonedChildren() throws Exception {
        Document sourceDoc = builder.newDocument();
        Element child1 = sourceDoc.createElement("child1");
        child1.setTextContent("Content1");
        Element child2 = sourceDoc.createElement("child2");
        child2.setTextContent("Content2");
        sourceDoc.appendChild(child1);
        sourceDoc.appendChild(child2);
        
        Document targetDoc = builder.newDocument();
        Element parent = targetDoc.createElement("parent");
        targetDoc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue(sourceDoc);

        NodeList children = parent.getChildNodes();
        assertEquals(2, children.getLength());
        Element clonedChild1 = (Element) children.item(0);
        Element clonedChild2 = (Element) children.item(1);
        assertEquals("child1", clonedChild1.getNodeName());
        assertEquals("Content1", clonedChild1.getTextContent());
        assertEquals("child2", clonedChild2.getNodeName());
        assertEquals("Content2", clonedChild2.getTextContent());
    }

    @Test
    public void setValue_OnElementNode_WithOtherNodeType_AppendsClonedNode() throws Exception {
        Document sourceDoc = builder.newDocument();
        Comment comment = sourceDoc.createComment("A comment");
        
        Document targetDoc = builder.newDocument();
        Element parent = targetDoc.createElement("parent");
        targetDoc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue(comment);

        NodeList children = parent.getChildNodes();
        assertEquals(1, children.getLength());
        Comment clonedComment = (Comment) children.item(0);
        assertEquals("A comment", clonedComment.getData());
    }

    @Test
    public void setValue_OnElementNode_WithNonNode_NonEmptyString_AppendsTextNode() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElement("parent");
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue("New Text");

        NodeList children = parent.getChildNodes();
        assertEquals(1, children.getLength());
        Text textNode = (Text) children.item(0);
        assertEquals("New Text", textNode.getNodeValue());
    }

    @Test
    public void setValue_OnElementNode_WithNonNode_EmptyString_DoesNotAppend() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElement("parent");
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue("");

        NodeList children = parent.getChildNodes();
        assertEquals(0, children.getLength());
    }

    @Test
    public void setValue_OnElementNode_RemovesExistingChildrenBeforeSettingNewValue() throws Exception {
        Document sourceDoc = builder.newDocument();
        Element existingChild = sourceDoc.createElement("existingChild");
        existingChild.setTextContent("Old Content");
        Document targetDoc = builder.newDocument();
        Element parent = targetDoc.createElement("parent");
        parent.appendChild(targetDoc.createElement("child1"));
        parent.appendChild(targetDoc.createElement("child2"));
        targetDoc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue(sourceDoc);

        NodeList children = parent.getChildNodes();
        assertEquals(0, children.getLength());
    }

    @Test
    public void setValue_OnElementNode_WithNonNode_NonEmptyConvertedString_AppendsTextNode() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElement("parent");
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue(12345);

        NodeList children = parent.getChildNodes();
        assertEquals(1, children.getLength());
        Text textNode = (Text) children.item(0);
        assertEquals("12345", textNode.getNodeValue());
    }

    @Test
    public void setValue_OnElementNode_WithNonNode_EmptyConvertedString_DoesNotAppend() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElement("parent");
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue("");

        NodeList children = parent.getChildNodes();
        assertEquals(0, children.getLength());
    }

    @Test
    public void setValue_OnElementNode_WithNullConvertedString_DoesNotAppend() throws Exception {
        Document doc = builder.newDocument();
        Element parent = doc.createElement("parent");
        doc.appendChild(parent);
        DOMNodePointer pointer = new DOMNodePointer(parent, Locale.getDefault());

        pointer.setValue(null);

        NodeList children = parent.getChildNodes();
        assertEquals(0, children.getLength());
    }
}