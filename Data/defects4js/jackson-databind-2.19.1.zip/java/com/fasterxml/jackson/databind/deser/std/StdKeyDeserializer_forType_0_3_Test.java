package com.fasterxml.jackson.databind.deser.std;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class StdKeyDeserializer_forType_0_3_Test {

    @Test
    @DisplayName("forType(Byte.class) returns StdKeyDeserializer with TYPE_BYTE")
    public void TC11() throws Exception {
        // GIVEN
        Class<?> raw = Byte.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access private fields via reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_BYTE, kind);
        assertEquals(Byte.class, rawValue);
    }

    @Test
    @DisplayName("forType(Character.class) returns StdKeyDeserializer with TYPE_CHAR")
    public void TC12() throws Exception {
        // GIVEN
        Class<?> raw = Character.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access private fields via reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_CHAR, kind);
        assertEquals(Character.class, rawValue);
    }

    @Test
    @DisplayName("forType(Short.class) returns StdKeyDeserializer with TYPE_SHORT")
    public void TC13() throws Exception {
        // GIVEN
        Class<?> raw = Short.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access private fields via reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_SHORT, kind);
        assertEquals(Short.class, rawValue);
    }

    @Test
    @DisplayName("forType(Float.class) returns StdKeyDeserializer with TYPE_FLOAT")
    public void TC14() throws Exception {
        // GIVEN
        Class<?> raw = Float.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access private fields via reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_FLOAT, kind);
        assertEquals(Float.class, rawValue);
    }

    @Test
    @DisplayName("forType(Double.class) returns StdKeyDeserializer with TYPE_DOUBLE")
    public void TC15() throws Exception {
        // GIVEN
        Class<?> raw = Double.class;

        // WHEN
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);

        // THEN
        // Access private fields via reflection
        Field kindField = StdKeyDeserializer.class.getDeclaredField("_kind");
        kindField.setAccessible(true);
        int kind = kindField.getInt(result);

        Field rawField = StdKeyDeserializer.class.getDeclaredField("_keyClass");
        rawField.setAccessible(true);
        Class<?> rawValue = (Class<?>) rawField.get(result);

        assertEquals(StdKeyDeserializer.TYPE_DOUBLE, kind);
        assertEquals(Double.class, rawValue);
    }
}