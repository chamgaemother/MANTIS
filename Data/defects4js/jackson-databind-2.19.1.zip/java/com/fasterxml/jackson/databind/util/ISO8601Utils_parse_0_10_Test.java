package com.fasterxml.jackson.databind.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601Utils_parse_0_10_Test {

    @Test
    @DisplayName("Parse successfully handles date with multiple timezone offset formats")
    void TC46_parseMultipleTimezoneOffsetFormats() throws ParseException {
        String[] dates = {
            "2023-10-05T14:30:00Z",
            "2023-10-05T14:30:00+02:00",
            "2023-10-05T14:30:00-0500"
        };
        TimeZone tzZ = TimeZone.getTimeZone("UTC");
        TimeZone tzPlus2 = TimeZone.getTimeZone("GMT+02:00");
        TimeZone tzMinus5 = TimeZone.getTimeZone("GMT-05:00");
        GregorianCalendar[] expectedCalendars = {
            new GregorianCalendar(tzZ),
            new GregorianCalendar(tzPlus2),
            new GregorianCalendar(tzMinus5)
        };
        for(int i = 0; i < dates.length; i++) {
            String date = dates[i];
            ParsePosition pos = new ParsePosition(0);
            Date result = ISO8601Utils.parse(date, pos);
            GregorianCalendar expectedCalendar = expectedCalendars[i];
            expectedCalendar.set(2023, 9, 5, 14, 30, 0); // Months are 0-based
            expectedCalendar.set(GregorianCalendar.MILLISECOND, 0);
            Date expectedDate = expectedCalendar.getTime();
            assertEquals(expectedDate, result, "Parsed date does not match expected date.");
            assertEquals(date.length(), pos.getIndex(), "ParsePosition index does not match date length.");
        }
    }

    @Test
    @DisplayName("Parse throws ParseException when ParsePosition index is beyond string length")
    void TC47_parseWithInvalidParsePositionIndex() {
        String date = "2023-10-05T14:30:00Z";
        ParsePosition pos = new ParsePosition(100);
        Exception exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("Failed to parse date"), "Exception message does not indicate parse failure.");
    }

    @Test
    @DisplayName("Parse successfully handles date string with no seconds")
    void TC48_parseWithoutSeconds() throws ParseException {
        String date = "2023-10-05T14:30Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(date, pos);
        GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.setLenient(false);
        calendar.set(2023, 9, 5, 14, 30, 0); // Months are 0-based
        calendar.set(GregorianCalendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();
        assertEquals(expectedDate, result, "Parsed date does not match expected date with seconds defaulted to 0.");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index does not match date length.");
    }

    @Test
    @DisplayName("Parse throws ParseException when time components are missing after 'T'")
    void TC49_parseWithMissingTimeComponentsAfterT() {
        String date = "2023-10-05T";
        ParsePosition pos = new ParsePosition(0);
        Exception exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertTrue(exception.getMessage().contains("Failed to parse date"), "Exception message does not indicate missing time components.");
    }

    @Test
    @DisplayName("Parse successfully handles date with only year, month, day, and timezone")
    void TC50_parseWithOnlyDateAndTimezone() throws ParseException {
        String date = "2023-10-05Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(date, pos);
        GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.setLenient(false);
        calendar.set(2023, 9, 5, 0, 0, 0); // Months are 0-based
        calendar.set(GregorianCalendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();
        assertEquals(expectedDate, result, "Parsed date does not match expected date with only year, month, day, and timezone.");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index does not match date length.");
    }
}