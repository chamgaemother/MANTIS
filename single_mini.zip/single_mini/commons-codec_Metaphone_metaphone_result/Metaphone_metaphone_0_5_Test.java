package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_0_5_Test {

    @Test
    @DisplayName("metaphone(\"LLOYD\") handles double 'L'")
    void TC21_metaphone_handles_double_L() {
        Metaphone metaphone = new Metaphone();
        String input = "LLoyd";
        String result = metaphone.metaphone(input);
        // Duplicate 'L's should result in single 'L'
        assertTrue(result.contains("L"));
    }

    @Test
    @DisplayName("metaphone(\"GHOST\") handles silent 'GH' followed by 'T'")
    void TC22_metaphone_handles_silent_GH() {
        Metaphone metaphone = new Metaphone();
        String input = "ghost";
        String result = metaphone.metaphone(input);
        // Silent 'GH' should be omitted
        assertFalse(result.contains("GH"));
    }

    @Test
    @DisplayName("metaphone(\"KNOW\") handles silent 'K'")
    void TC23_metaphone_handles_silent_K() {
        Metaphone metaphone = new Metaphone();
        String input = "know";
        String result = metaphone.metaphone(input);
        // Silent 'K' should be omitted
        assertFalse(result.contains("K"));
    }

    @Test
    @DisplayName("metaphone(\"QUEUE\") handles 'UEUE'")
    void TC24_metaphone_handles_UEUE() {
        Metaphone metaphone = new Metaphone();
        String input = "queue";
        String result = metaphone.metaphone(input);
        // 'UEUE' should be processed correctly
        assertTrue(result.contains("KW"));
    }

    @Test
    @DisplayName("metaphone(\"ZZZZ\") handles multiple 'Z's correctly")
    void TC25_metaphone_handles_multiple_Zs() {
        Metaphone metaphone = new Metaphone();
        String input = "zzzz";
        String result = metaphone.metaphone(input);
        // Multiple 'Z's should be condensed
        assertEquals("S", result);
    }
}