package com.fasterxml.jackson.databind.cfg;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.type.LogicalType;
import com.fasterxml.jackson.databind.cfg.CoercionAction;
import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
import com.fasterxml.jackson.databind.cfg.MutableCoercionConfig;

public class CoercionConfigs_findCoercion_2_1_Test {

//     @Test
//     @DisplayName("When _perClassCoercions is not null, targetClass is not null, and _perClassCoercions.get(targetClass) returns a valid action")
//     void TC27_perClassCoercions_action_found() throws Exception {
        // Given
//         CoercionConfigs coercionConfigs = new CoercionConfigs();
//         MutableCoercionConfig mutableConfig = new MutableCoercionConfig();
//         mutableConfig.setAction(CoercionInputShape.Integer, CoercionAction.TryConvert);
//         Map<Class<?>, MutableCoercionConfig> perClassCoercions = new HashMap<>();
//         perClassCoercions.put(String.class, mutableConfig);
// 
//         Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
//         perClassField.setAccessible(true);
//         perClassField.set(coercionConfigs, perClassCoercions);
// 
        // When
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         LogicalType targetType = LogicalType.String;
//         Class<?> targetClass = String.class;
//         CoercionInputShape inputShape = CoercionInputShape.Integer;
// 
//         CoercionAction result = coercionConfigs.findCoercion(config, targetType, targetClass, inputShape);
// 
        // Then
//         assertEquals(CoercionAction.TryConvert, result);
//     }

//     @Test
//     @DisplayName("When _perClassCoercions.get(targetClass) returns null and _perTypeCoercions.findAction(inputShape) returns null, proceeding to legacy handling for EmptyArray")
//     void TC28_legacy_EmptyArray_handling_with_ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT_enabled() throws Exception {
        // Given
//         CoercionConfigs coercionConfigs = new CoercionConfigs();
// 
        // Use reflection to set _perClassCoercions and _perTypeCoercions to null
//         Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
//         perClassField.setAccessible(true);
//         perClassField.set(coercionConfigs, null);
// 
//         Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
//         perTypeField.setAccessible(true);
//         perTypeField.set(coercionConfigs, null);
// 
        // Ensure _defaultCoercions.findAction(inputShape) returns null
//         MutableCoercionConfig defaultCoercions = coercionConfigs.defaultCoercions();
//         defaultCoercions.defineCoercion(CoercionInputShape.EmptyArray, null);
// 
        // When
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT)).thenReturn(true);
//         LogicalType targetType = LogicalType.Integer;
//         Class<?> targetClass = null;
//         CoercionInputShape inputShape = CoercionInputShape.EmptyArray;
// 
//         CoercionAction result = coercionConfigs.findCoercion(config, targetType, targetClass, inputShape);
// 
        // Then
//         assertEquals(CoercionAction.AsNull, result);
//     }

    @Test
    @DisplayName("When inputShape is Float, targetType is not Integer, and ALLOW_COERCION_OF_SCALARS is disabled")
    void TC29_Float_inputShape_with_non_Integer_targetType_and_coercion_disabled() throws Exception {
        // Given
        CoercionConfigs coercionConfigs = new CoercionConfigs();

        // Use reflection to set _perClassCoercions and _perTypeCoercions to null
        Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
        perClassField.setAccessible(true);
        perClassField.set(coercionConfigs, null);

        Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
        perTypeField.setAccessible(true);
        perTypeField.set(coercionConfigs, null);

        LogicalType targetType = LogicalType.Boolean;
        CoercionInputShape inputShape = CoercionInputShape.Float;

        // When
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)).thenReturn(false);

        CoercionAction result = coercionConfigs.findCoercion(config, targetType, null, inputShape);

        // Then
        assertEquals(CoercionAction.Fail, result);
    }

    @Test
    @DisplayName("When inputShape is Integer, targetType is Enum, and FAIL_ON_NUMBERS_FOR_ENUMS is disabled")
    void TC30_Integer_inputShape_with_Enum_targetType_and_FAIL_ON_NUMBERS_FOR_ENUMS_disabled() throws Exception {
        // Given
        CoercionConfigs coercionConfigs = new CoercionConfigs();

        // Use reflection to set _perClassCoercions and _perTypeCoercions to null
        Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
        perClassField.setAccessible(true);
        perClassField.set(coercionConfigs, null);

        Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
        perTypeField.setAccessible(true);
        perTypeField.set(coercionConfigs, null);

        LogicalType targetType = LogicalType.Enum;
        CoercionInputShape inputShape = CoercionInputShape.Integer;

        // When
        DeserializationConfig config = mock(DeserializationConfig.class);
        when(config.isEnabled(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS)).thenReturn(false);

        CoercionAction result = coercionConfigs.findCoercion(config, targetType, null, inputShape);

        // Then
        assertEquals(CoercionAction.TryConvert, result);
    }

//     @Test
//     @DisplayName("When inputShape is OtherShape and baseScalar is enabled with ALLOW_COERCION_OF_SCALARS enabled")
//     void TC31_OtherShape_inputShape_with_scalar_type_and_coercion_enabled() throws Exception {
        // Given
//         CoercionConfigs coercionConfigs = new CoercionConfigs();
// 
        // Use reflection to set _perClassCoercions and _perTypeCoercions to null
//         Field perClassField = CoercionConfigs.class.getDeclaredField("_perClassCoercions");
//         perClassField.setAccessible(true);
//         perClassField.set(coercionConfigs, null);
// 
//         Field perTypeField = CoercionConfigs.class.getDeclaredField("_perTypeCoercions");
//         perTypeField.setAccessible(true);
//         perTypeField.set(coercionConfigs, null);
// 
//         LogicalType targetType = LogicalType.Boolean;
//         CoercionInputShape inputShape = CoercionInputShape.OtherShape;
// 
        // When
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(config.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)).thenReturn(true);
// 
//         CoercionAction result = coercionConfigs.findCoercion(config, targetType, null, inputShape);
// 
        // Then
//         assertEquals(CoercionAction.TryConvert, result);
//     }
}