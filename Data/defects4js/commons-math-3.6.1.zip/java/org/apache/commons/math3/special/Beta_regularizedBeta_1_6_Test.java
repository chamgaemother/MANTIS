package org.apache.commons.math3.special;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Beta_regularizedBeta_1_6_Test {

    @Test
    @DisplayName("Input x exactly satisfies the recursive boundary condition, triggering recursive call")
    void TC17_RecursiveBoundaryCondition_ExactMatch() {
        // GIVEN
        double a = 3.0;
        double b = 4.0;
        double x = (a + 1) / (2 + a + b);
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        double expected = 1 - Beta.regularizedBeta(1 - x, b, a, epsilon, maxIterations);
        assertEquals(expected, result, "Result should be 1 minus the recursive regularizedBeta call");
    }

    @Test
    @DisplayName("Input a and b are exactly 10.0, testing logBeta boundary condition")
    void TC18_aAndBEqualTen_ContinuedFractionComputation() {
        // GIVEN
        double x = 0.5;
        double a = 10.0;
        double b = 10.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0");
    }

    @Test
    @DisplayName("Input a is just above 10.0 and b is just above 10.0, testing logBeta computation")
    void TC19_aAndBJustAboveTen_ContinuedFractionComputation() {
        // GIVEN
        double x = 0.7;
        double a = 10.1;
        double b = 10.1;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0");
    }

    @Test
    @DisplayName("Input a is exactly 1.0 and b is exactly 1.0, testing logBeta edge case")
    void TC20_aAndBEqualOne_ContinuedFractionComputation() {
        // GIVEN
        double x = 0.5;
        double a = 1.0;
        double b = 1.0;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertEquals(x, result, 1e-10, "When a and b are 1.0, regularizedBeta should return x");
    }

    @Test
    @DisplayName("Input a is less than 1.0 and b is greater than 10.0, testing logBeta path")
    void TC21_aLessThanOne_bGreaterThanTen_LogBetaPath() {
        // GIVEN
        double x = 0.4;
        double a = 0.5;
        double b = 10.5;
        double epsilon = 1e-8;
        int maxIterations = 1000;

        // WHEN
        double result = Beta.regularizedBeta(x, a, b, epsilon, maxIterations);

        // THEN
        assertTrue(result >= 0.0 && result <= 1.0, "Result should be between 0.0 and 1.0");
    }
}