package org.jfree.chart.util;

import java.awt.Shape;
import java.awt.geom.Arc2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SerialUtils_readShape_2_1_Test {

    @Test
    @DisplayName("readShape successfully reads and returns an Arc2D.PIE object")
    void TC23_readShape_readsArc2D_PIE_Object() throws Exception {
        // GIVEN
        Arc2D.Double arc = new Arc2D.Double(10.0, 20.0, 30.0, 40.0, 45.0, 90.0, Arc2D.PIE);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeBoolean(false); // isNull
            oos.writeObject(Arc2D.Double.class);
            oos.writeDouble(arc.getX());
            oos.writeDouble(arc.getY());
            oos.writeDouble(arc.getWidth());
            oos.writeDouble(arc.getHeight());
            oos.writeDouble(arc.getAngleStart());
            oos.writeDouble(arc.getAngleExtent());
            oos.writeInt(arc.getArcType());
        }
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bais);

        // WHEN
        Shape result = SerialUtils.readShape(ois);

        // THEN
        assertNotNull(result, "Resulting shape should not be null");
        assertTrue(result instanceof Arc2D, "Resulting shape should be an instance of Arc2D");
        Arc2D resultArc = (Arc2D) result;
        assertEquals(arc.getX(), resultArc.getX(), 0.0001, "X coordinate mismatch");
        assertEquals(arc.getY(), resultArc.getY(), 0.0001, "Y coordinate mismatch");
        assertEquals(arc.getWidth(), resultArc.getWidth(), 0.0001, "Width mismatch");
        assertEquals(arc.getHeight(), resultArc.getHeight(), 0.0001, "Height mismatch");
        assertEquals(arc.getAngleStart(), resultArc.getAngleStart(), 0.0001, "Angle Start mismatch");
        assertEquals(arc.getAngleExtent(), resultArc.getAngleExtent(), 0.0001, "Angle Extent mismatch");
        assertEquals(arc.getArcType(), resultArc.getArcType(), "Arc Type mismatch");
    }

    @Test
    @DisplayName("readShape throws ClassCastException when readObject returns a non-Shape object for an unknown class")
    void TC24_readShape_throwsClassCastException_forNonShapeUnknownClass() throws Exception {
        // GIVEN
        String nonShapeObject = "I am not a Shape";
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeBoolean(false); // isNull
            oos.writeObject(String.class); // Unknown class
            oos.writeObject(nonShapeObject); // Non-Shape object
        }
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bais);

        // WHEN & THEN
        assertThrows(ClassCastException.class, () -> {
            SerialUtils.readShape(ois);
        }, "Expected ClassCastException to be thrown");
    }

    @Test
    @DisplayName("readShape successfully reads and returns a GeneralPath with multiple path elements")
    void TC25_readShape_readsGeneralPathWithMultiplePathElements() throws Exception {
        // GIVEN
        GeneralPath path = new GeneralPath();
        path.moveTo(10.0f, 20.0f);
        path.lineTo(30.0f, 40.0f);
        path.curveTo(50.0f, 60.0f, 70.0f, 80.0f, 90.0f, 100.0f);
        path.closePath();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeBoolean(false); // isNull
            oos.writeObject(GeneralPath.class);
            // Manually writing the path iterator data
            PathIterator pi = path.getPathIterator(null);
            float[] coords = new float[6];
            oos.writeBoolean(pi.isDone());
            while (!pi.isDone()) {
                int type = pi.currentSegment(coords);
                oos.writeInt(type);
                for (int i = 0; i < 6; i++) {
                    oos.writeFloat(coords[i]);
                }
                oos.writeInt(pi.getWindingRule());
                pi.next();
                oos.writeBoolean(pi.isDone());
            }
        }
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bais);

        // WHEN
        Shape result = SerialUtils.readShape(ois);

        // THEN
        assertNotNull(result, "Resulting shape should not be null");
        assertTrue(result instanceof GeneralPath, "Resulting shape should be an instance of GeneralPath");
        GeneralPath resultPath = (GeneralPath) result;
        PathIterator pi = resultPath.getPathIterator(null);
        float[] coords = new float[6];
        // MoveTo
        assertEquals(PathIterator.SEG_MOVETO, pi.currentSegment(coords), "First segment should be MOVETO");
        assertEquals(10.0f, coords[0], 0.0001f, "MOVETO X mismatch");
        assertEquals(20.0f, coords[1], 0.0001f, "MOVETO Y mismatch");
        pi.next();
        // LineTo
        assertEquals(PathIterator.SEG_LINETO, pi.currentSegment(coords), "Second segment should be LINETO");
        assertEquals(30.0f, coords[0], 0.0001f, "LINETO X mismatch");
        assertEquals(40.0f, coords[1], 0.0001f, "LINETO Y mismatch");
        pi.next();
        // CurveTo
        assertEquals(PathIterator.SEG_CUBICTO, pi.currentSegment(coords), "Third segment should be CUBICTO");
        assertEquals(50.0f, coords[0], 0.0001f, "CUBICTO Control Point 1 X mismatch");
        assertEquals(60.0f, coords[1], 0.0001f, "CUBICTO Control Point 1 Y mismatch");
        assertEquals(70.0f, coords[2], 0.0001f, "CUBICTO Control Point 2 X mismatch");
        assertEquals(80.0f, coords[3], 0.0001f, "CUBICTO Control Point 2 Y mismatch");
        assertEquals(90.0f, coords[4], 0.0001f, "CUBICTO End Point X mismatch");
        assertEquals(100.0f, coords[5], 0.0001f, "CUBICTO End Point Y mismatch");
        pi.next();
        // ClosePath
        assertEquals(PathIterator.SEG_CLOSE, pi.currentSegment(coords), "Fourth segment should be CLOSE");
        pi.next();
        assertTrue(pi.isDone(), "PathIterator should be done");
    }

    @Test
    @DisplayName("readShape returns null when readObject returns null for a known class")
    void TC26_readShape_returnsNull_whenReadObjectReturnsNullForKnownClass() throws Exception {
        // GIVEN
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeBoolean(false); // isNull
            oos.writeObject(Rectangle2D.class); // Keep Rectangle2D class
            oos.writeObject(null); // Null object is serialized
        }
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bais);

        // WHEN
        Shape result = SerialUtils.readShape(ois);

        // THEN
        assertNull(result, "Resulting shape should be null when readObject returns null");
    }
}