package org.apache.commons.jxpath.ri.parser;

import org.apache.commons.jxpath.ri.parser.XPathParser;
import org.apache.commons.jxpath.ri.parser.XPathParserConstants;
import org.apache.commons.jxpath.ri.parser.ParseException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;

public class XPathParser_AxisName_2_1_Test implements XPathParserConstants {

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_SELF but token.kind=AXIS_CHILD")
    public void TC17_AxisName_AxisSelf_TokenChild() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));

        // Set parser.jj_nt.kind = AXIS_SELF
        parser.jj_nt.kind = AXIS_SELF;

        // Set parser.token.kind = AXIS_CHILD
        parser.token.kind = AXIS_CHILD;

        // Expect ParseException to be thrown
        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_SELF but token.kind=AXIS_PRECEDING")
    public void TC18_AxisName_AxisSelf_TokenPreceding() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));

        // Set parser.jj_nt.kind = AXIS_SELF
        parser.jj_nt.kind = AXIS_SELF;

        // Set parser.token.kind = AXIS_PRECEDING
        parser.token.kind = AXIS_PRECEDING;

        // Expect ParseException to be thrown
        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_CHILD but token.kind=AXIS_SELF")
    public void TC19_AxisName_AxisChild_TokenSelf() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));

        // Set parser.jj_nt.kind = AXIS_CHILD
        parser.jj_nt.kind = AXIS_CHILD;

        // Set parser.token.kind = AXIS_SELF
        parser.token.kind = AXIS_SELF;

        // Expect ParseException to be thrown
        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_CHILD but token.kind=AXIS_PRECEDING")
    public void TC20_AxisName_AxisChild_TokenPreceding() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));

        // Set parser.jj_nt.kind = AXIS_CHILD
        parser.jj_nt.kind = AXIS_CHILD;

        // Set parser.token.kind = AXIS_PRECEDING
        parser.token.kind = AXIS_PRECEDING;

        // Expect ParseException to be thrown
        assertThrows(ParseException.class, () -> parser.AxisName());
    }

    @Test
    @DisplayName("AxisName throws ParseException when jj_nt.kind=AXIS_PARENT but token.kind=AXIS_CHILD")
    public void TC21_AxisName_AxisParent_TokenChild() {
        XPathParser parser = new XPathParser(new ByteArrayInputStream(new byte[0]));

        // Set parser.jj_nt.kind = AXIS_PARENT
        parser.jj_nt.kind = AXIS_PARENT;

        // Set parser.token.kind = AXIS_CHILD
        parser.token.kind = AXIS_CHILD;

        // Expect ParseException to be thrown
        assertThrows(ParseException.class, () -> parser.AxisName());
    }
}