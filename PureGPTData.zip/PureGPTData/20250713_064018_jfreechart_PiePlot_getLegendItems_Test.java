import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.urls.StandardPieURLGenerator;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.chart.LegendItem;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PiePlotTest {

    private PiePlot<String> plot;
    private DefaultPieDataset<String> dataset;

    @BeforeEach
    public void setUp() {
        dataset = new DefaultPieDataset<>();
        plot = new PiePlot<>(dataset);
        plot.setLegendLabelGenerator(new StandardPieSectionLabelGenerator());
        plot.setLegendLabelURLGenerator(new StandardPieURLGenerator());
        plot.setSectionPaint("A", Color.RED);
        plot.setSectionPaint("B", Color.GREEN);
    }

    @Test
    void testLegendItemsNotNull() {
        LegendItemCollection items = plot.getLegendItems();
        assertNotNull(items);
    }

    @Test
    void testLegendItemsWithNullDataset() {
        plot.setDataset(null);
        LegendItemCollection items = plot.getLegendItems();
        assertTrue(items.isEmpty(), "Legend items should be empty if dataset is null.");
    }

    @Test
    void testLegendItemsWithEmptyDataset() {
        LegendItemCollection items = plot.getLegendItems();
        assertEquals(0, items.getItemCount(), "Legend items should be empty for empty dataset.");
    }

    @Test
    void testLegendItemsWithOneValue() {
        dataset.setValue("A", 1.0);
        LegendItemCollection items = plot.getLegendItems();
        assertEquals(1, items.getItemCount(), "Legend items should include one entry.");
        assertEquals("A", items.get(0).getLabel());
    }

    @Test
    void testLegendItemsWithMultipleValues() {
        dataset.setValue("A", 1.0);
        dataset.setValue("B", 2.0);
        LegendItemCollection items = plot.getLegendItems();
        assertEquals(2, items.getItemCount(), "Legend items should include two entries.");

        List<String> labels = Arrays.asList(items.get(0).getLabel(), items.get(1).getLabel());
        assertTrue(labels.contains("A"));
        assertTrue(labels.contains("B"));
    }

    @Test
    void testLegendItemsIgnoreZeroValues() {
        plot.setIgnoreZeroValues(true);
        dataset.setValue("A", 0.0);
        dataset.setValue("B", 2.0);
        LegendItemCollection items = plot.getLegendItems();
        assertEquals(1, items.getItemCount(), "Legend items should ignore zero values.");
        assertEquals("B", items.get(0).getLabel());
    }

    @Test
    void testLegendItemsIgnoreNullValues() {
        plot.setIgnoreNullValues(true);
        dataset.setValue("A", null);
        dataset.setValue("B", 2.0);
        LegendItemCollection items = plot.getLegendItems();
        assertEquals(1, items.getItemCount(), "Legend items should ignore null values.");
        assertEquals("B", items.get(0).getLabel());
    }

    @Test
    void testLegendItemsWithZeroValuesNotIgnored() {
        plot.setIgnoreZeroValues(false);
        dataset.setValue("A", 0.0);
        LegendItemCollection items = plot.getLegendItems();
        assertEquals(1, items.getItemCount(), "Legend items should include zero values when not ignored.");
    }

    @Test
    void testLegendItemsDefaultPaint() {
        dataset.setValue("A", 1.0);
        List<LegendItem> items = plot.getLegendItems().getItems();
        assertEquals(Color.RED, items.get(0).getFillPaint(), "Legend item color should match section paint.");
    }

    @Test
    void testLegendItemsToolTip() {
        plot.setLegendLabelToolTipGenerator(new StandardPieSectionLabelGenerator("{0}"));
        dataset.setValue("A", 1.0);
        LegendItem item = plot.getLegendItems().get(0);
        assertNotNull(item.getToolTipText(), "Legend item tooltip should not be null when generator is set.");
    }

    @Test
    void testLegendItemsURL() {
        plot.setLegendLabelURLGenerator(new StandardPieURLGenerator());
        dataset.setValue("A", 1.0);
        LegendItem item = plot.getLegendItems().get(0);
        assertNotNull(item.getURLText(), "Legend item URL should not be null when URL generator is set.");
    }
}