package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class DfpDec_nextAfter_0_2_Test {
//
//    @Test
//    @DisplayName("nextAfter results in INFINITE classification and original is finite")
//    void TC06() throws Exception {
//        DfpField fieldN = new DfpField(10);
//        DfpDec dfpDec = new DfpDec(fieldN, Double.MAX_VALUE); // Largest double value
//        Dfp x = new DfpDec(fieldN);
//
//        Dfp result = dfpDec.nextAfter(x);
//
//        assertEquals(Dfp.INFINITE, result.classify());
//
//        int FLAG_INEXACT = DfpField.FLAG_INEXACT;
//        assertTrue(fieldN.isFlagSet(FLAG_INEXACT));
//
//        Dfp expectedTrapResult = dfpDec.dotrap(FLAG_INEXACT, "nextAfter", x, result);
//        assertEquals(expectedTrapResult, result);
//    }
//
//    @Test
//    @DisplayName("nextAfter results in zero while original is non-zero")
//    void TC07() throws Exception {
//        DfpField fieldN = new DfpField(10);
//        DfpDec dfpDec = new DfpDec(fieldN, 1.0e-300); // Very small double value
//        Dfp x = new DfpDec(fieldN);
//
//        Dfp result = dfpDec.nextAfter(x);
//
//        Dfp zero = dfpDec.getZero();
//        assertEquals(zero, result);
//
//        int FLAG_INEXACT = DfpField.FLAG_INEXACT;
//        assertTrue(fieldN.isFlagSet(FLAG_INEXACT));
//
//        Dfp expectedTrapResult = dfpDec.dotrap(FLAG_INEXACT, "nextAfter", x, result);
//        assertEquals(expectedTrapResult, result);
//    }

    @Test
    @DisplayName("nextAfter called with zero and x is positive")
    void TC08() throws Exception {
        DfpField fieldN = new DfpField(10);
        DfpDec dfpDec = new DfpDec(fieldN, 0.0); // Zero
        Dfp x = new DfpDec(fieldN, 1.0); // Positive

        Dfp result = dfpDec.nextAfter(x);

        Dfp expected = dfpDec.copysign(dfpDec.getZero(), dfpDec);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("nextAfter called with zero and x is negative")
    void TC09() throws Exception {
        DfpField fieldN = new DfpField(10);
        DfpDec dfpDec = new DfpDec(fieldN, 0.0); // Zero
        Dfp x = new DfpDec(fieldN, -1.0); // Negative

        Dfp result = dfpDec.nextAfter(x);

        Dfp expected = dfpDec.copysign(dfpDec.getZero(), dfpDec);
        assertEquals(expected, result);
    }

    @Test
    @DisplayName("nextAfter called where inc equals zero")
    void TC10() throws Exception {
        DfpField fieldN = new DfpField(10);
        DfpDec dfpDec = new DfpDec(fieldN, 0.0); // Zero should not change
        Dfp x = new DfpDec(fieldN);

        Dfp inc = dfpDec.power10(0); // Zero increment when power10 is called with 0

        assertEquals(dfpDec.getZero(), inc);

        Dfp result = dfpDec.nextAfter(x);

        Dfp expected = dfpDec.copysign(dfpDec.getZero(), dfpDec);
        assertEquals(expected, result);
    }
}