package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Flat3MapTest {

    private Flat3Map<String, String> map;

    @BeforeEach
    public void setUp() {
        map = new Flat3Map<>();
    }

    @Test
    public void testPutWhenDelegateMapIsNotNull() {
        // Arrange
        Map<String, String> delegate = new HashMap<>();
        delegate.put("key1", "value1");
        Flat3Map<String, String> flatMap = new Flat3Map<String, String>() {
            @Override
            protected AbstractHashedMap<String, String> createDelegateMap() {
                return new HashedMap<>(delegate);
            }
        };
        flatMap.put("key1", "value1");
        flatMap.put("key2", "value2");
        // Manually set delegateMap to not null
        flatMap.delegateMap = new HashedMap<>();
        // Act
        String oldValue = flatMap.put("key1", "newValue1");
        // Assert
        assertNull(oldValue);
        assertEquals("newValue1", flatMap.get("key1"));
    }

    @Test
    public void testPutWithNullKeyWhenSize0() {
        // Act
        String result = map.put(null, "value1");
        // Assert
        assertNull(result);
        assertEquals(1, map.size());
        assertNull(map.key1);
        assertEquals("value1", map.value1);
    }

    @Test
    public void testPutWithNullKeyWhenSize1ExistingNullKey() {
        // Arrange
        map.put(null, "value1");
        // Act
        String oldValue = map.put(null, "value2");
        // Assert
        assertEquals("value1", oldValue);
        assertEquals(1, map.size());
        assertNull(map.key1);
        assertEquals("value2", map.value1);
    }

    @Test
    public void testPutWithNullKeyWhenSize2ExistingNullKey() {
        // Arrange
        map.put("key1", "value1");
        map.put(null, "value2");
        // Act
        String oldValue = map.put(null, "value3");
        // Assert
        assertEquals("value2", oldValue);
        assertEquals(2, map.size());
        assertNull(map.key2);
        assertEquals("value3", map.value2);
    }

    @Test
    public void testPutWithNullKeyWhenSize3ExistingNullKey() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put(null, "value3");
        // Act
        String oldValue = map.put(null, "value4");
        // Assert
        assertEquals("value3", oldValue);
        assertEquals(3, map.size());
        assertNull(map.key3);
        assertEquals("value4", map.value3);
    }

    @Test
    public void testPutWithNullKeyWhenNoExistingNullKey() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        // Act
        String result = map.put(null, "value3");
        // Assert
        assertNull(result);
        assertEquals(3, map.size());
        assertNull(map.key3);
        assertEquals("value3", map.value3);
    }

    @Test
    public void testPutWithNonNullKeyWhenSize0() {
        // Act
        String result = map.put("key1", "value1");
        // Assert
        assertNull(result);
        assertEquals(1, map.size());
        assertEquals("key1", map.key1);
        assertEquals("value1", map.value1);
    }

    @Test
    public void testPutWithExistingKeyWhenSize1() {
        // Arrange
        map.put("key1", "value1");
        // Act
        String oldValue = map.put("key1", "value2");
        // Assert
        assertEquals("value1", oldValue);
        assertEquals(1, map.size());
        assertEquals("value2", map.value1);
    }

    @Test
    public void testPutWithExistingKeyWhenSize3() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        // Act
        String oldValue = map.put("key2", "newValue2");
        // Assert
        assertEquals("value2", oldValue);
        assertEquals(3, map.size());
        assertEquals("newValue2", map.value2);
    }

    @Test
    public void testPutWithNewKeyWhenSize3TriggersConvertToMap() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        // Act
        String result = map.put("key4", "value4");
        // Assert
        assertNull(result);
        assertEquals(4, map.size());
        assertNotNull(map.delegateMap);
        assertEquals("value4", map.delegateMap.get("key4"));
    }

    @Test
    public void testPutWithNullKeyWhenSize3TriggersConvertToMap() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        // Act
        String result = map.put(null, "value4");
        // Assert
        assertNull(result);
        assertEquals(4, map.size());
        assertNotNull(map.delegateMap);
        assertEquals("value4", map.delegateMap.get(null));
    }

    @Test
    public void testPutWithNonNullKeyWhenSize2() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        // Act
        String result = map.put("key3", "value3");
        // Assert
        assertNull(result);
        assertEquals(3, map.size());
        assertEquals("key3", map.key3);
        assertEquals("value3", map.value3);
    }

    @Test
    public void testPutWithNullValue() {
        // Act
        String result = map.put("key1", null);
        // Assert
        assertNull(result);
        assertEquals(1, map.size());
        assertEquals(null, map.value1);
    }

    @Test
    public void testPutOverwriteNullValue() {
        // Arrange
        map.put("key1", null);
        // Act
        String oldValue = map.put("key1", "value1");
        // Assert
        assertNull(oldValue);
        assertEquals(1, map.size());
        assertEquals("value1", map.value1);
    }

    @Test
    public void testPutWithNonExistingKeyWhenSize3() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        // Act
        String result = map.put("key4", "value4");
        // Assert
        assertNull(result);
        assertEquals(4, map.size());
        assertNotNull(map.delegateMap);
        assertEquals("value4", map.delegateMap.get("key4"));
    }

    @Test
    public void testPutWithDuplicateKeyAfterConvertToMap() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4");
        // Act
        String oldValue = map.put("key2", "newValue2");
        // Assert
        assertEquals("value2", oldValue);
        assertEquals(4, map.size());
        assertEquals("newValue2", map.delegateMap.get("key2"));
    }

    @Test
    public void testPutWithNullKeyAfterConvertToMap() {
        // Arrange
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.put("key4", "value4");
        // Act
        String result = map.put(null, "value5");
        // Assert
        assertNull(result);
        assertEquals(5, map.size());
        assertEquals("value5", map.delegateMap.get(null));
    }

    @Test
    public void testPutWithExistingNullKeyAfterConvertToMap() {
        // Arrange
        map.put(null, "value1");
        map.put("key1", "value2");
        map.put("key2", "value3");
        // Act
        String oldValue = map.put(null, "value4");
        // Assert
        assertEquals("value1", oldValue);
        assertEquals(3, map.size());
        assertNull(map.key3);
        assertEquals("value4", map.value3);
    }

    @Test
    public void testPutWithNullKeyWhenAlreadyConvertedToMap() {
        // Arrange
        map.delegateMap = new HashedMap<>();
        map.delegateMap.put("key1", "value1");
        // Act
        String result = map.put(null, "value2");
        // Assert
        assertNull(result);
        assertEquals(2, map.size());
        assertEquals("value2", map.delegateMap.get(null));
    }

    @Test
    public void testPutWithNonNullKeyWhenAlreadyConvertedToMap() {
        // Arrange
        map.delegateMap = new HashedMap<>();
        map.delegateMap.put("key1", "value1");
        // Act
        String oldValue = map.put("key1", "newValue1");
        // Assert
        assertEquals("value1", oldValue);
        assertEquals("newValue1", map.delegateMap.get("key1"));
    }
}