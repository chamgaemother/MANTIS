import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
// package org.jfree.chart;
// // import org.jfree.chart.plot.PlotRenderingInfo;
// // import org.jfree.chart.plot.Zoomable;
// // import org.jfree.chart.plot.Plot;
// // 
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// // import javax.swing.*;
// // import java.awt.*;
// // import java.awt.event.MouseEvent;
// // import java.awt.geom.Point2D;
// // import java.lang.reflect.Field;
// // 
// // import static org.mockito.Mockito.*;
// // 
// public class ChartPanel_mouseDragged_1_2_Test {
// // 
// //     @Test
// //     @DisplayName("mouseDragged attempts to zoom on range axis only")
// //     void testMouseDragged_ZoomRangeNotTriggered() throws Exception {
//         // Arrange
//         // Create a mock JFreeChart and its Plot
// //         JFreeChart mockChart = mock(JFreeChart.class);
// //         Plot mockPlot = mock(Plot.class, withSettings().extraInterfaces(Zoomable.class));
// //         when(mockChart.getPlot()).thenReturn(mockPlot);
// // 
//         // Mock Zoomable properties
// //         when(((Zoomable) mockPlot).isDomainZoomable()).thenReturn(false);
// //         when(((Zoomable) mockPlot).isRangeZoomable()).thenReturn(true);
// //         when(((Zoomable) mockPlot).getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// // 
//         // Mock ChartRenderingInfo
// //         ChartRenderingInfo mockInfo = mock(ChartRenderingInfo.class);
// //         PlotRenderingInfo mockPlotInfo = mock(PlotRenderingInfo.class);
// //         when(mockInfo.getPlotInfo()).thenReturn(mockPlotInfo);
// // 
//         // Instantiate ChartPanel with the mock chart
// //         ChartPanel chartPanel = new ChartPanel(mockChart);
// // 
//         // Use reflection to set private fields
//         // Set popup to a mock that is not showing
// //         JPopupMenu mockPopup = mock(JPopupMenu.class);
// //         when(mockPopup.isShowing()).thenReturn(false);
// //         Field popupField = ChartPanel.class.getDeclaredField("popup");
// //         popupField.setAccessible(true);
// //         popupField.set(chartPanel, mockPopup);
// // 
//         // Set zoomPoint
// //         Point2D zoomPoint = new Point2D.Double(200, 200);
// //         Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
// //         zoomPointField.setAccessible(true);
// //         zoomPointField.set(chartPanel, zoomPoint);
// // 
//         // Spy on the chartPanel to verify drawZoomRectangle is called
// //         ChartPanel spyChartPanel = spy(chartPanel);
// // 
//         // Mock Graphics2D
// //         Graphics2D mockGraphics = mock(Graphics2D.class);
// //         doReturn(mockGraphics).when(spyChartPanel).getGraphics();
// // 
//         // Act
//         // Create a MouseEvent with minimal movement
// //         MouseEvent mouseEvent = new MouseEvent(spyChartPanel, MouseEvent.MOUSE_DRAGGED,
// //                 System.currentTimeMillis(), 0, 200, 200, 1, false, MouseEvent.BUTTON1);
// //         spyChartPanel.mouseDragged(mouseEvent);
// // 
//         // Assert
//         // Verify that drawZoomRectangle is called to erase the previous rectangle
// //         verify(spyChartPanel, times(1)).drawZoomRectangle(mockGraphics, true);
//         // Verify that repaint is called
// //         verify(spyChartPanel, times(1)).repaint();
//         // Verify that getGraphics is called
// //         verify(spyChartPanel, times(1)).getGraphics();
// //     }
// // }
// }