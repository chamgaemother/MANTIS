package org.apache.commons.compress.archivers.sevenz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class SevenZArchiveEntry_equals_0_1_Test {

    @Test
    @DisplayName("equals called with the same object reference returns true")
    public void TC01_equalsSameReference_returnsTrue() {
        // Given
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        entry.setName("entryName");
        entry.setHasStream(true);
        entry.setDirectory(false);
        entry.setAntiItem(false);
        entry.setHasCreationDate(true);
        entry.setHasLastModifiedDate(true);
        entry.setHasAccessDate(true);
        entry.setCreationTime(FileTime.from(Instant.now()));
        entry.setLastModifiedTime(FileTime.from(Instant.now()));
        entry.setAccessTime(FileTime.from(Instant.now()));
        entry.setHasWindowsAttributes(true);
        entry.setWindowsAttributes(123);
        entry.setHasCrc(true);
        entry.setCrcValue(456L);
        entry.setCompressedCrcValue(789L);
        entry.setSize(1024L);
        entry.setCompressedSize(512L);
        entry.setContentMethods(Collections.emptyList());

        Object obj = entry;

        // When
        boolean result = entry.equals(obj);

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("equals called with null object returns false")
    public void TC02_equalsWithNull_returnsFalse() {
        // Given
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        entry.setName("entryName");
        entry.setHasStream(true);
        entry.setDirectory(false);
        entry.setAntiItem(false);
        entry.setHasCreationDate(true);
        entry.setHasLastModifiedDate(true);
        entry.setHasAccessDate(true);
        entry.setCreationTime(FileTime.from(Instant.now()));
        entry.setLastModifiedTime(FileTime.from(Instant.now()));
        entry.setAccessTime(FileTime.from(Instant.now()));
        entry.setHasWindowsAttributes(true);
        entry.setWindowsAttributes(123);
        entry.setHasCrc(true);
        entry.setCrcValue(456L);
        entry.setCompressedCrcValue(789L);
        entry.setSize(1024L);
        entry.setCompressedSize(512L);
        entry.setContentMethods(Collections.emptyList());

        Object obj = null;

        // When
        boolean result = entry.equals(obj);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with object of different class returns false")
    public void TC03_equalsWithDifferentClass_returnsFalse() {
        // Given
        SevenZArchiveEntry entry = new SevenZArchiveEntry();
        entry.setName("entryName");
        entry.setHasStream(true);
        entry.setDirectory(false);
        entry.setAntiItem(false);
        entry.setHasCreationDate(true);
        entry.setHasLastModifiedDate(true);
        entry.setHasAccessDate(true);
        entry.setCreationTime(FileTime.from(Instant.now()));
        entry.setLastModifiedTime(FileTime.from(Instant.now()));
        entry.setAccessTime(FileTime.from(Instant.now()));
        entry.setHasWindowsAttributes(true);
        entry.setWindowsAttributes(123);
        entry.setHasCrc(true);
        entry.setCrcValue(456L);
        entry.setCompressedCrcValue(789L);
        entry.setSize(1024L);
        entry.setCompressedSize(512L);
        entry.setContentMethods(Collections.emptyList());

        Object obj = new Object();

        // When
        boolean result = entry.equals(obj);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with identical fields and equalSevenZMethods returns true")
    public void TC04_equalsIdenticalFieldsAndMethods_returnsTrue() {
        // Given
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName("entryName");
        entry1.setHasStream(true);
        entry1.setDirectory(false);
        entry1.setAntiItem(false);
        entry1.setHasCreationDate(true);
        entry1.setHasLastModifiedDate(true);
        entry1.setHasAccessDate(true);
        entry1.setCreationTime(FileTime.from(Instant.now()));
        entry1.setLastModifiedTime(FileTime.from(Instant.now()));
        entry1.setAccessTime(FileTime.from(Instant.now()));
        entry1.setHasWindowsAttributes(true);
        entry1.setWindowsAttributes(123);
        entry1.setHasCrc(true);
        entry1.setCrcValue(456L);
        entry1.setCompressedCrcValue(789L);
        entry1.setSize(1024L);
        entry1.setCompressedSize(512L);
        entry1.setContentMethods(Collections.emptyList());

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName("entryName");
        entry2.setHasStream(true);
        entry2.setDirectory(false);
        entry2.setAntiItem(false);
        entry2.setHasCreationDate(true);
        entry2.setHasLastModifiedDate(true);
        entry2.setHasAccessDate(true);
        entry2.setCreationTime(FileTime.from(Instant.now()));
        entry2.setLastModifiedTime(FileTime.from(Instant.now()));
        entry2.setAccessTime(FileTime.from(Instant.now()));
        entry2.setHasWindowsAttributes(true);
        entry2.setWindowsAttributes(123);
        entry2.setHasCrc(true);
        entry2.setCrcValue(456L);
        entry2.setCompressedCrcValue(789L);
        entry2.setSize(1024L);
        entry2.setCompressedSize(512L);
        entry2.setContentMethods(Collections.emptyList());

        // When
        boolean result = entry1.equals(entry2);

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("equals called with different name field returns false")
    public void TC05_equalsDifferentNameField_returnsFalse() {
        // Given
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        entry1.setName("name1");
        entry1.setHasStream(true);
        entry1.setDirectory(false);
        entry1.setAntiItem(false);
        entry1.setHasCreationDate(true);
        entry1.setHasLastModifiedDate(true);
        entry1.setHasAccessDate(true);
        entry1.setCreationTime(FileTime.from(Instant.now()));
        entry1.setLastModifiedTime(FileTime.from(Instant.now()));
        entry1.setAccessTime(FileTime.from(Instant.now()));
        entry1.setHasWindowsAttributes(true);
        entry1.setWindowsAttributes(123);
        entry1.setHasCrc(true);
        entry1.setCrcValue(456L);
        entry1.setCompressedCrcValue(789L);
        entry1.setSize(1024L);
        entry1.setCompressedSize(512L);
        entry1.setContentMethods(Collections.emptyList());

        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        entry2.setName("name2");
        entry2.setHasStream(true);
        entry2.setDirectory(false);
        entry2.setAntiItem(false);
        entry2.setHasCreationDate(true);
        entry2.setHasLastModifiedDate(true);
        entry2.setHasAccessDate(true);
        entry2.setCreationTime(FileTime.from(Instant.now()));
        entry2.setLastModifiedTime(FileTime.from(Instant.now()));
        entry2.setAccessTime(FileTime.from(Instant.now()));
        entry2.setHasWindowsAttributes(true);
        entry2.setWindowsAttributes(123);
        entry2.setHasCrc(true);
        entry2.setCrcValue(456L);
        entry2.setCompressedCrcValue(789L);
        entry2.setSize(1024L);
        entry2.setCompressedSize(512L);
        entry2.setContentMethods(Collections.emptyList());

        // When
        boolean result = entry1.equals(entry2);

        // Then
        assertFalse(result);
    }
}
