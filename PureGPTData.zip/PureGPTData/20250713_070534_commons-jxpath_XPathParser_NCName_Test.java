import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.apache.commons.jxpath.ri.parser.*;

import java.io.StringReader;

import static org.junit.jupiter.api.Assertions.*;

class XPathParserTest {
    
    private XPathParser parser;
    
    @BeforeEach
    void setup() {
        parser = new XPathParser(new StringReader(""));
    }
    
    @Test
    void testNCName_withValidNCName() throws ParseException {
        parser = new XPathParser(new StringReader("validNCName"));
        String result = parser.NCName();
        assertEquals("validNCName", result);
    }
    
    @Test
    void testNCName_withNodeReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("node"));
        String result = parser.NCName();
        assertEquals("node", result);
    }
    
    @Test
    void testNCName_withTextReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("text"));
        String result = parser.NCName();
        assertEquals("text", result);
    }
    
    @Test
    void testNCName_withCommentReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("comment"));
        String result = parser.NCName();
        assertEquals("comment", result);
    }
    
    @Test
    void testNCName_withPIReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("processing-instruction"));
        String result = parser.NCName();
        assertEquals("processing-instruction", result);
    }

    @Test
    void testNCName_withFunctionLastReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("last"));
        String result = parser.NCName();
        assertEquals("last", result);
    }
    
    @Test
    void testNCName_withFunctionPositionReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("position"));
        String result = parser.NCName();
        assertEquals("position", result);
    }
    
    @Test
    void testNCName_withFunctionCountReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("count"));
        String result = parser.NCName();
        assertEquals("count", result);
    }
    
    @Test
    void testNCName_withFunctionIDReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("id"));
        String result = parser.NCName();
        assertEquals("id", result);
    }
    
    @Test
    void testNCName_withFunctionLocalNameReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("local-name"));
        String result = parser.NCName();
        assertEquals("local-name", result);
    }

    @Test
    void testNCName_withFunctionNamespaceURIReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("namespace-uri"));
        String result = parser.NCName();
        assertEquals("namespace-uri", result);
    }

    @Test
    void testNCName_withFunctionNameReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("name"));
        String result = parser.NCName();
        assertEquals("name", result);
    }

    @Test
    void testNCName_withFunctionStringReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("string"));
        String result = parser.NCName();
        assertEquals("string", result);
    }
    
    @Test
    void testNCName_withFunctionConcatReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("concat"));
        String result = parser.NCName();
        assertEquals("concat", result);
    }

    @Test
    void testNCName_withFunctionStartsWithReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("starts-with"));
        String result = parser.NCName();
        assertEquals("starts-with", result);
    }
    
    @Test
    void testNCName_withFunctionEndsWithReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("ends-with"));
        String result = parser.NCName();
        assertEquals("ends-with", result);
    }

    @Test
    void testNCName_withFunctionContainsReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("contains"));
        String result = parser.NCName();
        assertEquals("contains", result);
    }
    
    @Test
    void testNCName_withFunctionSubstringBeforeReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("substring-before"));
        String result = parser.NCName();
        assertEquals("substring-before", result);
    }

    @Test
    void testNCName_withFunctionSubstringAfterReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("substring-after"));
        String result = parser.NCName();
        assertEquals("substring-after", result);
    }
    
    @Test
    void testNCName_withFunctionSubstringReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("substring"));
        String result = parser.NCName();
        assertEquals("substring", result);
    }
    
    @Test
    void testNCName_withFunctionStringLengthReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("string-length"));
        String result = parser.NCName();
        assertEquals("string-length", result);
    }
    
    @Test
    void testNCName_withFunctionNormalizeSpaceReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("normalize-space"));
        String result = parser.NCName();
        assertEquals("normalize-space", result);
    }
    
    @Test
    void testNCName_withFunctionTranslateReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("translate"));
        String result = parser.NCName();
        assertEquals("translate", result);
    }
    
    @Test
    void testNCName_withFunctionBooleanReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("boolean"));
        String result = parser.NCName();
        assertEquals("boolean", result);
    }
    
    @Test
    void testNCName_withFunctionNotReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("not"));
        String result = parser.NCName();
        assertEquals("not", result);
    }

    @Test
    void testNCName_withFunctionTrueReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("true"));
        String result = parser.NCName();
        assertEquals("true", result);
    }
    
    @Test
    void testNCName_withFunctionFalseReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("false"));
        String result = parser.NCName();
        assertEquals("false", result);
    }

    @Test
    void testNCName_withFunctionNullReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("null"));
        String result = parser.NCName();
        assertEquals("null", result);
    }

    @Test
    void testNCName_withFunctionLangReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("lang"));
        String result = parser.NCName();
        assertEquals("lang", result);
    }

    @Test
    void testNCName_withFunctionNumberReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("number"));
        String result = parser.NCName();
        assertEquals("number", result);
    }
    
    @Test
    void testNCName_withFunctionSumReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("sum"));
        String result = parser.NCName();
        assertEquals("sum", result);
    }
    
    @Test
    void testNCName_withFunctionFloorReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("floor"));
        String result = parser.NCName();
        assertEquals("floor", result);
    }
    
    @Test
    void testNCName_withFunctionCeilingReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("ceiling"));
        String result = parser.NCName();
        assertEquals("ceiling", result);
    }

    @Test
    void testNCName_withFunctionRoundReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("round"));
        String result = parser.NCName();
        assertEquals("round", result);
    }

    @Test
    void testNCName_withFunctionKeyReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("key"));
        String result = parser.NCName();
        assertEquals("key", result);
    }

    @Test
    void testNCName_withFunctionFormatNumberReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("format-number"));
        String result = parser.NCName();
        assertEquals("format-number", result);
    }
    
    @Test
    void testNCName_withOperatorReservedWord() throws ParseException {
        parser = new XPathParser(new StringReader("or"));
        String result = parser.NCName();
        assertEquals("or", result);

        parser = new XPathParser(new StringReader("and"));
        result = parser.NCName();
        assertEquals("and", result);

        parser = new XPathParser(new StringReader("mod"));
        result = parser.NCName();
        assertEquals("mod", result);

        parser = new XPathParser(new StringReader("div"));
        result = parser.NCName();
        assertEquals("div", result);
    }

    @Test
    void testNCName_withInvalidToken() {
        parser = new XPathParser(new StringReader("1invalidToken"));
        assertThrows(ParseException.class, () -> parser.NCName());
    }
}