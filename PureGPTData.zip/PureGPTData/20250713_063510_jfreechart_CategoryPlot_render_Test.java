import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryCrosshairState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.util.SortOrder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CategoryPlotTest {

    private CategoryPlot plot;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private int index;
    private PlotRenderingInfo info;
    private CategoryCrosshairState crosshairState;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryItemRenderer renderer;
    private DefaultCategoryDataset dataset;

    @BeforeEach
    void setUp() {
        plot = new CategoryPlot();
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        index = 0;
        info = new PlotRenderingInfo(null);
        crosshairState = new CategoryCrosshairState();
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        renderer = mock(CategoryItemRenderer.class);
        dataset = new DefaultCategoryDataset();
        dataset.addValue(1, "Row1", "Col1");

        plot.setDomainAxis(domainAxis);
        plot.setRangeAxis(rangeAxis);
        plot.setRenderer(renderer);
        plot.setDataset(dataset);
    }

    @Test
    void givenValidInputs_whenRender_thenFindData() {
        when(renderer.initialise(g2, dataArea, plot, index, info)).thenReturn(null);
        when(renderer.getPassCount()).thenReturn(1);

        plot.setColumnRenderingOrder(SortOrder.ASCENDING);
        plot.setRowRenderingOrder(SortOrder.ASCENDING);

        assertTrue(plot.render(g2, dataArea, index, info, crosshairState));
        verify(renderer, times(1)).drawItem(eq(g2), any(), eq(dataArea), eq(plot), eq(domainAxis), eq(rangeAxis), eq(dataset), eq(0), eq(0), eq(0));
    }

    @Test
    void givenNoDataInDataset_whenRender_thenNoData() {
        DefaultCategoryDataset emptyDataset = new DefaultCategoryDataset();
        plot.setDataset(emptyDataset);
        assertFalse(plot.render(g2, dataArea, index, info, crosshairState));
    }

    @Test
    void givenNullRenderer_whenRender_thenNoData() {
        plot.setRenderer(null);
        assertFalse(plot.render(g2, dataArea, index, info, crosshairState));
    }

    @Test
    void givenDescendingOrder_whenRender_thenRuns() {
        when(renderer.initialise(g2, dataArea, plot, index, info)).thenReturn(null);
        when(renderer.getPassCount()).thenReturn(1);

        plot.setColumnRenderingOrder(SortOrder.DESCENDING);
        plot.setRowRenderingOrder(SortOrder.DESCENDING);

        assertTrue(plot.render(g2, dataArea, index, info, crosshairState));
        verify(renderer, times(1)).drawItem(eq(g2), any(), eq(dataArea), eq(plot), eq(domainAxis), eq(rangeAxis), eq(dataset), eq(0), eq(0), eq(0));
    }
}