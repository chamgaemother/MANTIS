package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConcurrentReferenceHashMap_size_0_3_Test {

    @Test
    @DisplayName("size() handles rapidly changing segments by eventually locking and counting accurately")
    public void TC11_size_handles_rapidly_changing_segments_by_eventually_locking_and_counting_accurately() throws Exception {
        // Initialize the ConcurrentReferenceHashMap instance
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>(
                ConcurrentReferenceHashMap.DEFAULT_INITIAL_CAPACITY,
                ConcurrentReferenceHashMap.DEFAULT_LOAD_FACTOR,
                ConcurrentReferenceHashMap.DEFAULT_CONCURRENCY_LEVEL,
                ConcurrentReferenceHashMap.DEFAULT_KEY_TYPE,
                ConcurrentReferenceHashMap.DEFAULT_VALUE_TYPE,
                ConcurrentReferenceHashMap.DEFAULT_OPTIONS
        );

        // Populate the map with initial data
        for (int i = 0; i < 1000; i++) {
            map.put("key" + i, "value" + i);
        }

        // Set up a latch to synchronize threads
        CountDownLatch latch = new CountDownLatch(1);
        AtomicInteger expectedTotalCount = new AtomicInteger(1000);

        // Start a thread that modifies the map continuously
        Thread modifierThread = new Thread(() -> {
            try {
                latch.await();
                for (int i = 1000; i < 2000; i++) {
                    map.put("key" + i, "value" + i);
                    expectedTotalCount.incrementAndGet();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        modifierThread.start();

        // Start size computation
        latch.countDown(); // Let the modifier thread start modifying

        // Ensure size is computed during map modifications
        int result = map.size();

        // Wait for the modifier thread to finish
        modifierThread.join();

        // Assert the size is as expected
        assertEquals(expectedTotalCount.get(), result, "The size should reflect all elements after modifications.");
    }

    @Test
    @DisplayName("size() ensures thread safety by locking segments when necessary")
    public void TC12_size_ensures_thread_safety_by_locking_segments_when_necessary() throws Exception {
        // Initialize the ConcurrentReferenceHashMap instance
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>(
                ConcurrentReferenceHashMap.DEFAULT_INITIAL_CAPACITY,
                ConcurrentReferenceHashMap.DEFAULT_LOAD_FACTOR,
                ConcurrentReferenceHashMap.DEFAULT_CONCURRENCY_LEVEL,
                ConcurrentReferenceHashMap.DEFAULT_KEY_TYPE,
                ConcurrentReferenceHashMap.DEFAULT_VALUE_TYPE,
                ConcurrentReferenceHashMap.DEFAULT_OPTIONS
        );

        // Populate the map with initial data
        for (int i = 0; i < 1000; i++) {
            map.put("key" + i, "value" + i);
        }

        // Use reflection to access the segments field
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);

        @SuppressWarnings("unchecked")
        ConcurrentReferenceHashMap.Segment<Object, Object>[] segments =
                (ConcurrentReferenceHashMap.Segment<Object, Object>[]) segmentsField.get(map);

        // Lock all segments to simulate the locking mechanism
        for (ConcurrentReferenceHashMap.Segment<Object, Object> segment : segments) {
            segment.lock();
        }

        // Invoke the size method
        int result = map.size();

        // Unlock all segments
        for (ConcurrentReferenceHashMap.Segment<Object, Object> segment : segments) {
            segment.unlock();
        }

        // Assert the size is accurate
        assertEquals(1000, result, "The size should accurately reflect the number of elements while maintaining thread safety.");
    }

}