package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.Mockito;

import java.lang.reflect.Field;

public class Flat3Map_remove_0_1_Test {

    @Test
    @DisplayName("remove method delegates removal when delegateMap is not null")
    void TC01_removeMethodDelegatesRemoval_whenDelegateMapIsNotNull() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Object key = new Object();
        Object value = new Object();
        
        // Mock the delegateMap
        AbstractHashedMap<Object, Object> delegate = Mockito.mock(AbstractHashedMap.class);
        when(delegate.remove(key)).thenReturn(value);
        
        // Use reflection to set the delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);
        
        // When
        Object result = map.remove(key);
        
        // Then
        verify(delegate).remove(key);
        assertEquals(value, result);
    }

    @Test
    @DisplayName("remove method returns null when delegateMap is not null but key is absent")
    void TC02_removeMethodReturnsNull_whenDelegateMapNotContainsKey() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Object key = new Object();
        
        // Mock the delegateMap
        AbstractHashedMap<Object, Object> delegate = Mockito.mock(AbstractHashedMap.class);
        when(delegate.remove(key)).thenReturn(null);
        
        // Use reflection to set the delegateMap field
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, delegate);
        
        // When
        Object result = map.remove(key);
        
        // Then
        verify(delegate).remove(key);
        assertNull(result);
    }

    @Test
    @DisplayName("remove method returns null when delegateMap is null and size is 0")
    void TC03_removeReturnsNull_whenDelegateMapNullAndSizeZero() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Object key = new Object();
        
        // Use reflection to set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Use reflection to set size to 0
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 0);
        
        // When
        Object result = map.remove(key);
        
        // Then
        assertNull(result);
    }

    @Test
    @DisplayName("remove null key with size=3 and key3 is null")
    void TC04_removeNullKey_size3_key3Null() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Object key = null;
        Object value3 = new Object();
        
        // Use reflection to set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Use reflection to set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);
        
        // Use reflection to set key3 to null
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);
        
        // Use reflection to set value3
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        value3Field.set(map, value3);
        
        // When
        Object result = map.remove(key);
        
        // Then
        assertEquals(value3, result);
        assertEquals(2, sizeField.getInt(map));
        assertNull(key3Field.get(map));
    }

    @Test
    @DisplayName("remove null key with size=3, key3 not null and key2 is null")
    void TC05_removeNullKey_size3_key3NotNull_key2Null() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();
        Object key = null;
        Object key3 = new Object();
        Object value2 = new Object();
        
        // Use reflection to set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);
        
        // Use reflection to set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);
        
        // Use reflection to set key3
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, key3);
        
        // Use reflection to set key2 to null
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);
        
        // Use reflection to set value2
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        value2Field.set(map, value2);
        
        // When
        Object result = map.remove(key);
        
        // Then
        assertEquals(value2, result);
        assertEquals(2, sizeField.getInt(map));
        assertNull(key2Field.get(map));
    }
}