package org.apache.commons.math3.ode.nonstiff;

import org.apache.commons.math3.ode.ExpandableStatefulODE;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class AdamsMoultonIntegrator_integrate_0_4_Test {

    private AdamsMoultonIntegrator integrator;
    
    @BeforeEach
    void setUp() {
        integrator = new AdamsMoultonIntegrator(2, 1.0e-8, 1000.0, 1.0e-5, 1.0e-5);
    }

    @AfterEach
    void tearDown() {
        integrator = null;
    }

    @Test
    @DisplayName("Integration with maximum step size limit reached, expecting integration termination")
    void TC16_integrationMaxStepSizeLimitReached() throws Exception {
        // GIVEN
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyODE());
        double targetTime = 20.0;
        
        // WHEN
        integrator.integrate(equations, targetTime);
        
        // THEN
        Field isLastStepField = AdamsMoultonIntegrator.class.getSuperclass().getDeclaredField("isLastStep");
        isLastStepField.setAccessible(true);
        boolean isLastStep = isLastStepField.getBoolean(integrator);
        
        assertTrue(isLastStep, "Integration should terminate after reaching maximum step size limit");
    }

    @Test
    @DisplayName("Integration after resetOccurred with step size filtered to target")
    void TC17_integrationAfterResetOccurredStepSizeFiltered() throws Exception {
        // GIVEN
        ExpandableStatefulODE equations = new ExpandableStatefulODE(new DummyODE());
        double targetTime = 10.0;
        
        Field resetOccurredField = AdamsMoultonIntegrator.class.getSuperclass().getDeclaredField("resetOccurred");
        resetOccurredField.setAccessible(true);
        resetOccurredField.setBoolean(integrator, true);
        
        // WHEN
        integrator.integrate(equations, targetTime);
        
        // THEN
        Field stepSizeField = AdamsMoultonIntegrator.class.getSuperclass().getDeclaredField("stepSize");
        stepSizeField.setAccessible(true);
        double stepSize = stepSizeField.getDouble(integrator);
        
        assertEquals(targetTime, stepSize, 1.0e-6, "Step size should be adjusted to reach the target time after reset");
    }

    // Dummy ODE for testing purposes
    private static class DummyODE implements org.apache.commons.math3.ode.FirstOrderDifferentialEquations {
        @Override
        public int getDimension() {
            return 1;
        }

        @Override
        public void computeDerivatives(double t, double[] y, double[] yDot) {
            yDot[0] = 0.0;
        }
    }
}