package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class WordUtilsTest {

    @Test
    void testWrap_NullInput_ReturnsNull() {
        assertNull(WordUtils.wrap(null, 20, "\n", true, " "));
    }

    @Test
    void testWrap_EmptyString_ReturnsEmpty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", true, " "));
    }

    @Test
    void testWrap_NullNewLineStr_UsesSystemLineSeparator() {
        String input = "This is a test string for wrapping.";
        String expected = "This is a test\nstring for\nwrapping.";
        String actual = WordUtils.wrap(input, 15, null, true, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapLengthLessThanOne_TreatedAsOne() {
        String input = "abc";
        String expected = "a\nb\nc";
        String actual = WordUtils.wrap(input, 0, "\n", true, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_BlankWrapOn_UsesSpace() {
        String input = "This is a test string";
        String expected = "This\nis\na\ntest\nstring";
        String actual = WordUtils.wrap(input, 4, "\n", true, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapOnCustomDelimiter() {
        String input = "word1,word2,word3,word4";
        String expected = "word1,\nword2,\nword3,\nword4";
        String actual = WordUtils.wrap(input, 6, "\n", false, ",");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapLongWordsTrue_WrapsLongWords() {
        String input = "ThisIsAVeryLongWordThatExceedsWrapLength";
        String expected = "ThisIsAVer\nyLongWordT\nhatExceeds\nWrapLength";
        String actual = WordUtils.wrap(input, 10, "\n", true, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapLongWordsFalse_DoesNotWrapLongWords() {
        String input = "ThisIsAVeryLongWordThatExceedsWrapLength";
        String expected = "ThisIsAVeryLongWordThatExceedsWrapLength";
        String actual = WordUtils.wrap(input, 10, "\n", false, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_MatcherFindsAtStart_SkipsDelimiter() {
        String input = " word1 word2 word3";
        String expected = "word1 word2\nword3";
        String actual = WordUtils.wrap(input, 11, "\n", true, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_InputLineShorterThanWrapLength_NoWrap() {
        String input = "Short line";
        String expected = "Short line";
        String actual = WordUtils.wrap(input, 20, "\n", true, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_InputLineEqualToWrapLength_NoWrap() {
        String input = "ExactlyTwentyChar!";
        String expected = "ExactlyTwentyChar!";
        String actual = WordUtils.wrap(input, 20, "\n", true, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_NormalWrapping_CorrectlyWrapped() {
        String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        String expected = "Here is one line of\ntext that is going\nto be wrapped after\n20 columns.";
        String actual = WordUtils.wrap(input, 20, "\n", false, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapOnMultipleDelimiters() {
        String input = "flammable/inflammable";
        String expected = "flammable\ninflammable";
        String actual = WordUtils.wrap(input, 10, "\n", true, "/");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapOnDelimiterAtEnd() {
        String input = "word1 word2 word3 ";
        String expected = "word1 word2\nword3 ";
        String actual = WordUtils.wrap(input, 11, "\n", false, " ");
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapWithEmptyDelimiterArray_ReturnsOriginal() {
        String input = "This should not wrap";
        String expected = "This should not wrap";
        String actual = WordUtils.wrap(input, 5, "\n", true, new String[0]);
        assertEquals(expected, actual);
    }

    @Test
    void testWrap_WrapOnEmptyWrapOn_UsesSpace() {
        String input = "This is a test";
        String expected = "This is a\ntest";
        String actual = WordUtils.wrap(input, 10, "\n", true, "");
        assertEquals(expected, actual);
    }
}