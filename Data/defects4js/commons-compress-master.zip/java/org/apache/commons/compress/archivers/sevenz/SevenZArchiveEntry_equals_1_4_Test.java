package org.apache.commons.compress.archivers.sevenz;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import java.lang.reflect.Field;

public class SevenZArchiveEntry_equals_1_4_Test {

    @Test
    @DisplayName("equals(obj) returns false when windowsAttributes fields differ")
    void TC16_equals_different_windowsAttributes_returns_false() throws Exception {
        // Instantiate first entry
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        
        // Set windowsAttributes to 1234 using reflection
        Field windowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("windowsAttributes");
        windowsAttributesField.setAccessible(true);
        windowsAttributesField.setInt(entry1, 1234);

        // Instantiate second entry
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        
        // Set windowsAttributes to 5678 using reflection
        windowsAttributesField.setInt(entry2, 5678);

        // Invoke equals
        boolean result = entry1.equals(entry2);

        // Assert false
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when hasCrc fields differ")
    void TC17_equals_different_hasCrc_returns_false() throws Exception {
        // Instantiate first entry
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        
        // Set hasCrc to true using reflection
        Field hasCrcField = SevenZArchiveEntry.class.getDeclaredField("hasCrc");
        hasCrcField.setAccessible(true);
        hasCrcField.setBoolean(entry1, true);

        // Instantiate second entry
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        
        // Set hasCrc to false using reflection
        hasCrcField.setBoolean(entry2, false);

        // Invoke equals
        boolean result = entry1.equals(entry2);

        // Assert false
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when crc fields differ")
    void TC18_equals_different_crc_returns_false() throws Exception {
        // Instantiate first entry
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        
        // Set crc to 1000L using reflection
        Field crcField = SevenZArchiveEntry.class.getDeclaredField("crc");
        crcField.setAccessible(true);
        crcField.setLong(entry1, 1000L);

        // Instantiate second entry
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        
        // Set crc to 2000L using reflection
        crcField.setLong(entry2, 2000L);

        // Invoke equals
        boolean result = entry1.equals(entry2);

        // Assert false
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when compressedCrc fields differ")
    void TC19_equals_different_compressedCrc_returns_false() throws Exception {
        // Instantiate first entry
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        
        // Set compressedCrc to 3000L using reflection
        Field compressedCrcField = SevenZArchiveEntry.class.getDeclaredField("compressedCrc");
        compressedCrcField.setAccessible(true);
        compressedCrcField.setLong(entry1, 3000L);

        // Instantiate second entry
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        
        // Set compressedCrc to 4000L using reflection
        compressedCrcField.setLong(entry2, 4000L);

        // Invoke equals
        boolean result = entry1.equals(entry2);

        // Assert false
        assertFalse(result);
    }

    @Test
    @DisplayName("equals(obj) returns false when size fields differ")
    void TC20_equals_different_size_returns_false() throws Exception {
        // Instantiate first entry
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        
        // Set size to 5000L using reflection
        Field sizeField = SevenZArchiveEntry.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setLong(entry1, 5000L);

        // Instantiate second entry
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();
        
        // Set size to 6000L using reflection
        sizeField.setLong(entry2, 6000L);

        // Invoke equals
        boolean result = entry1.equals(entry2);

        // Assert false
        assertFalse(result);
    }
}