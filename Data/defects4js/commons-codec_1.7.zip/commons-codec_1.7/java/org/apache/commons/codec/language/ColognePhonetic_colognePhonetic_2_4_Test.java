package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_2_4_Test {

    @Test
    @DisplayName("Input with uppercase and lowercase mixed letters, should preprocess correctly")
    public void test_TC59() {
        // Given
        String input = "HelloWorld";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        String expected = phonetic.colognePhonetic("HELLOWORLD");
        assertEquals(expected, result, "Result should match encoding of uppercase converted input");
    }

    @Test
    @DisplayName("Input with 'C' at the end of the string, should assign code based on context")
    public void test_TC60() {
        // Given
        String input = "MagicC";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("8"), "Result should contain '8' for 'C' at the end based on context");
    }

    @Test
    @DisplayName("Input with 'X' after 'K', should assign code '4'")
    public void test_TC61() {
        // Given
        String input = "Kox";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("4"), "Result should contain '4' for 'X' after 'K'");
    }
}