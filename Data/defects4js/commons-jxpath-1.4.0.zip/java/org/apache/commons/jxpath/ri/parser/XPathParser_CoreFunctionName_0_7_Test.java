package org.apache.commons.jxpath.ri.parser;

import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.parser.Token;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class XPathParser_CoreFunctionName_0_7_Test {

    @Test
    @DisplayName("CoreFunctionName with jj_nt.kind FUNCTION_FORMAT_NUMBER returns Compiler.FUNCTION_FORMAT_NUMBER")
    void TC31_CoreFunctionName_FunctionFormatNumber_ReturnsExpected() throws Exception {
        // Instantiate XPathParser
        XPathParser xpathParser = createXPathParserInstance();

        // Use reflection to set the private field jj_nt.kind to FUNCTION_FORMAT_NUMBER
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(xpathParser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, Compiler.FUNCTION_FORMAT_NUMBER);

        // Invoke the method under test
        int result = xpathParser.CoreFunctionName();

        // Assert the expected result
        assertEquals(Compiler.FUNCTION_FORMAT_NUMBER, result, "The returned value should match Compiler.FUNCTION_FORMAT_NUMBER.");
    }

    @Test
    @DisplayName("CoreFunctionName with invalid jj_nt.kind throws ParseException")
    void TC32_CoreFunctionName_InvalidKind_ThrowsParseException() throws Exception {
        // Instantiate XPathParser
        XPathParser xpathParser = createXPathParserInstance();

        // Use reflection to set the private field jj_nt.kind to an invalid value, e.g., -1
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Token jj_nt = (Token) jj_ntField.get(xpathParser);

        Field kindField = Token.class.getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, -1); // Assuming -1 is invalid

        // Invoke the method under test and expect ParseException
        assertThrows(ParseException.class, () -> {
            xpathParser.CoreFunctionName();
        }, "CoreFunctionName should throw ParseException when jj_nt.kind is invalid.");
    }

    private XPathParser createXPathParserInstance() throws Exception {
        // Utilize a constructor that is compatible with your setup
        return new XPathParser(new java.io.StringReader(""));
    }
}
