package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_scalb_0_2_Test {

    @Test
    @DisplayName("scalb with d as NaN and any n")
    void TC06_scalb_d_is_NaN() {
        // GIVEN
        double d = Double.NaN;
        int n = 100;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        assertTrue(Double.isNaN(result), "Result should be NaN");
    }

    @Test
    @DisplayName("scalb with d as positive infinity and any n")
    void TC07_scalb_d_is_positive_infinity() {
        // GIVEN
        double d = Double.POSITIVE_INFINITY;
        int n = -50;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be positive infinity");
    }

    @Test
    @DisplayName("scalb with d as negative infinity and any n")
    void TC08_scalb_d_is_negative_infinity() {
        // GIVEN
        double d = Double.NEGATIVE_INFINITY;
        int n = 300;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        assertEquals(Double.NEGATIVE_INFINITY, result, "Result should be negative infinity");
    }

    @Test
    @DisplayName("scalb with d as positive zero and any n")
    void TC09_scalb_d_is_positive_zero() {
        // GIVEN
        double d = 0.0;
        int n = 1000;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        assertEquals(0.0, result, "Result should be positive zero");
    }

    @Test
    @DisplayName("scalb with d as negative zero and any n")
    void TC10_scalb_d_is_negative_zero() {
        // GIVEN
        double d = -0.0;
        int n = -1000;
        
        // WHEN
        double result = FastMath.scalb(d, n);
        
        // THEN
        assertEquals(Double.doubleToRawLongBits(-0.0), Double.doubleToRawLongBits(result), "Result should be negative zero");
    }
}