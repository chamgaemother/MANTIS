package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_atan2_0_3_Test {

    @Test
    @DisplayName("atan2(x=-Infinity, y=-1.0) returns -Math.PI when x is negative infinity and y is negative")
    public void TC11() {
        // GIVEN
        double x = Double.NEGATIVE_INFINITY;
        double y = -1.0;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(-Math.PI, result, "The result should be -Math.PI");
    }

    @Test
    @DisplayName("atan2(x=0.0, y=1.0) returns Math.PI/2 when y is positive and x is zero")
    public void TC12() {
        // GIVEN
        double x = 0.0;
        double y = 1.0;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(Math.PI / 2, result, "The result should be Math.PI/2");
    }

    @Test
    @DisplayName("atan2(x=0.0, y=-1.0) returns -Math.PI/2 when y is negative and x is zero")
    public void TC13() {
        // GIVEN
        double x = 0.0;
        double y = -1.0;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(-Math.PI / 2, result, "The result should be -Math.PI/2");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=1.0) returns correct angle in first quadrant for finite inputs")
    public void TC14() {
        // GIVEN
        double x = 1.0;
        double y = 1.0;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(Math.PI / 4, result, 1e-10, "The result should be approximately Math.PI/4");
    }

    @Test
    @DisplayName("atan2(x=1.0, y=-1.0) returns correct angle in fourth quadrant for finite inputs")
    public void TC15() {
        // GIVEN
        double x = 1.0;
        double y = -1.0;

        // WHEN
        double result = FastMath.atan2(x, y);

        // THEN
        assertEquals(-Math.PI / 4, result, 1e-10, "The result should be approximately -Math.PI/4");
    }
}