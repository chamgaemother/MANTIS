package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class TarArchiveOutputStream_putArchiveEntry_0_3_Test {

    @Test
    @DisplayName("putArchiveEntry when haveUnclosedEntry is true, expecting IOException on closeArchiveEntry")
    void TC11_putArchiveEntry_WithUnclosedEntry_ShouldThrowIOException() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
        TarArchiveEntry firstEntry = new TarArchiveEntry("firstEntry");
        outputStream.putArchiveEntry(firstEntry);

        // Use reflection to ensure haveUnclosedEntry is true
        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
        haveUnclosedEntryField.setAccessible(true);
        haveUnclosedEntryField.setBoolean(outputStream, true);

        // WHEN & THEN
        TarArchiveEntry secondEntry = new TarArchiveEntry("secondEntry");
        IOException exception = assertThrows(IOException.class, () -> {
            outputStream.putArchiveEntry(secondEntry);
        });
        assertEquals("This archive contains unclosed entries.", exception.getMessage());
    }

//     @Test
//     @DisplayName("putArchiveEntry with extra PAX headers provided")
//     void TC12_putArchiveEntry_WithExtraPaxHeaders_ShouldAddHeadersSuccessfully() throws Exception {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         Map<String, String> extraHeaders = new HashMap<>();
//         extraHeaders.put("user", "testUser");
//         TarArchiveEntry entry = new TarArchiveEntry("testEntry");
//         entry.setExtraPaxHeaders(extraHeaders);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         assertTrue(haveUnclosedEntryField.getBoolean(outputStream));
//     }

//     @Test
//     @DisplayName("putArchiveEntry with symbolic link and non-ASCII link path")
//     void TC14_putArchiveEntry_SymbolicLinkWithNonAsciiPath_ShouldAddPaxHeadersSuccessfully() throws Exception {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         Field addPaxHeadersForNonAsciiNamesField = TarArchiveOutputStream.class.getDeclaredField("addPaxHeadersForNonAsciiNames");
//         addPaxHeadersForNonAsciiNamesField.setAccessible(true);
//         addPaxHeadersForNonAsciiNamesField.setBoolean(outputStream, true);
// 
//         TarArchiveEntry entry = new TarArchiveEntry("nonAsciiEntry");
//         entry.setLinkName("\u00E3\u00A3\u00A4\u00A2\u00A2\u00AF\u00A3\u00A6\u00A3\u00A6\u00A3\u00B9\u00A3\u00AF\u00B9\u00A3\u00A9");
//         entry.setLink(true);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         assertTrue(haveUnclosedEntryField.getBoolean(outputStream));
//     }

//     @Test
//     @DisplayName("putArchiveEntry with bigNumberMode POSIX and entry fields exceeding limits")
//     void TC15_putArchiveEntry_BigNumberModePOSIX_ShouldAddPaxHeadersForBigNumbers() throws Exception {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         Field bigNumberModeField = TarArchiveOutputStream.class.getDeclaredField("bigNumberMode");
//         bigNumberModeField.setAccessible(true);
//         bigNumberModeField.setInt(outputStream, 2); // Assuming 2 represents BIGNUMBER_POSIX
// 
//         TarArchiveEntry entry = new TarArchiveEntry("bigNumberEntry");
//         entry.setSize((long) TarConstants.MAXSIZE + 100);
//         entry.setLongGroupId(TarConstants.MAXID + 10);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         assertTrue(haveUnclosedEntryField.getBoolean(outputStream));
//     }
}