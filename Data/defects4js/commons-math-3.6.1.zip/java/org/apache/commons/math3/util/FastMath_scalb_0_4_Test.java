package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_scalb_0_4_Test {

    @Test
    @DisplayName("scalb with d as a normal number and n causing scaledExponent to underflow to zero")
    public void TC16() {
        // GIVEN
        double d = -3.0;
        int n = -3000;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(Double.doubleToRawLongBits(-0.0), Double.doubleToRawLongBits(result), "The result should be negative zero");
    }

    @Test
    @DisplayName("scalb with n causing multiple iterations in normalization loop")
    public void TC17() {
        // GIVEN
        double d = Double.longBitsToDouble(0x0010000000000000L);
        int n = 1023;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(Double.MAX_VALUE, result, "The result should be Double.MAX_VALUE");
    }

}