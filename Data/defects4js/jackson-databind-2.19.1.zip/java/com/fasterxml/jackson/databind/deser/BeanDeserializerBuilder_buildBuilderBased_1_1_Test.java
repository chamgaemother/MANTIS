package com.fasterxml.jackson.databind.deser;
// import com.fasterxml.jackson.databind.deser.BuilderBasedDeserializer;
// 
// import com.fasterxml.jackson.databind.JsonDeserializer;
// import com.fasterxml.jackson.databind.JavaType;
// import com.fasterxml.jackson.databind.deser.impl.BuilderBasedDeserializer;
// import com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder;
// import com.fasterxml.jackson.databind.DeserializationConfig;
// import com.fasterxml.jackson.databind.DeserializationContext;
// import com.fasterxml.jackson.databind.BeanDescription;
// import com.fasterxml.jackson.databind.MapperFeature;
// import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
// import com.fasterxml.jackson.databind.PropertyName;
// 
// import java.lang.reflect.Field;
// import java.util.HashMap;
// import java.util.Map;
// import java.util.List;
// import java.util.Arrays;
// 
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.DisplayName;
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
public class BeanDeserializerBuilder_buildBuilderBased_1_1_Test {
// 
    // Dummy class for testing purposes
//     private static class SomeType {}
// 
//     @Test
//     @DisplayName("DEFAULT_VIEW_INCLUSION disabled and at least one property has views")
//     void TC15_viewInclusionDisabled_withPropertyViews() throws Exception {
        // GIVEN
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)).thenReturn(false);
// 
//         BeanDescription beanDesc = mock(BeanDescription.class);
//         DeserializationContext context = mock(DeserializationContext.class);
//         when(context.getConfig()).thenReturn(config);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, context);
// 
//         SettableBeanProperty propWithViews = mock(SettableBeanProperty.class);
//         when(propWithViews.hasViews()).thenReturn(true);
// 
//         Map<String, SettableBeanProperty> properties = new HashMap<>();
//         properties.put("propWithViews", propWithViews);
// 
        // Use reflection to set '_properties'
//         Field propertiesField = BeanDeserializerBuilder.class.getDeclaredField("_properties");
//         propertiesField.setAccessible(true);
//         propertiesField.set(builder, properties);
// 
        // WHEN
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//         assertTrue(deserializer instanceof BuilderBasedDeserializer);
// 
//         BuilderBasedDeserializer bdDeserializer = (BuilderBasedDeserializer) deserializer;
//         Field anyViewsField = BuilderBasedDeserializer.class.getDeclaredField("_anyViews");
//         anyViewsField.setAccessible(true);
//         boolean anyViews = anyViewsField.getBoolean(bdDeserializer);
//         assertTrue(anyViews);
//     }
// 
//     @Test
//     @DisplayName("DEFAULT_VIEW_INCLUSION disabled but no properties have views")
//     void TC16_viewInclusionDisabled_noPropertyViews() throws Exception {
        // GIVEN
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)).thenReturn(false);
// 
//         BeanDescription beanDesc = mock(BeanDescription.class);
//         DeserializationContext context = mock(DeserializationContext.class);
//         when(context.getConfig()).thenReturn(config);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, context);
// 
//         SettableBeanProperty prop = mock(SettableBeanProperty.class);
//         when(prop.hasViews()).thenReturn(false);
// 
//         Map<String, SettableBeanProperty> properties = new HashMap<>();
//         properties.put("prop", prop);
// 
        // Use reflection to set '_properties'
//         Field propertiesField = BeanDeserializerBuilder.class.getDeclaredField("_properties");
//         propertiesField.setAccessible(true);
//         propertiesField.set(builder, properties);
// 
        // WHEN
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//         assertTrue(deserializer instanceof BuilderBasedDeserializer);
// 
//         BuilderBasedDeserializer bdDeserializer = (BuilderBasedDeserializer) deserializer;
//         Field anyViewsField = BuilderBasedDeserializer.class.getDeclaredField("_anyViews");
//         anyViewsField.setAccessible(true);
//         boolean anyViews = anyViewsField.getBoolean(bdDeserializer);
//         assertFalse(anyViews);  // Changed to assertFalse since there are no property views
//     }
// 
//     @Test
//     @DisplayName("DEFAULT_VIEW_INCLUSION enabled, views are ignored")
//     void TC17_viewInclusionEnabled_viewsIgnored() throws Exception {
        // GIVEN
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)).thenReturn(true);
// 
//         BeanDescription beanDesc = mock(BeanDescription.class);
//         DeserializationContext context = mock(DeserializationContext.class);
//         when(context.getConfig()).thenReturn(config);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, context);
// 
//         SettableBeanProperty propWithViews = mock(SettableBeanProperty.class);
//         when(propWithViews.hasViews()).thenReturn(true);
// 
//         Map<String, SettableBeanProperty> properties = new HashMap<>();
//         properties.put("propWithViews", propWithViews);
// 
        // Use reflection to set '_properties'
//         Field propertiesField = BeanDeserializerBuilder.class.getDeclaredField("_properties");
//         propertiesField.setAccessible(true);
//         propertiesField.set(builder, properties);
// 
        // WHEN
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//         assertTrue(deserializer instanceof BuilderBasedDeserializer);
// 
//         BuilderBasedDeserializer bdDeserializer = (BuilderBasedDeserializer) deserializer;
//         Field anyViewsField = BuilderBasedDeserializer.class.getDeclaredField("_anyViews");
//         anyViewsField.setAccessible(true);
//         boolean anyViews = anyViewsField.getBoolean(bdDeserializer);
//         assertFalse(anyViews);
//     }
// 
//     @Test
//     @DisplayName("Properties have multiple aliases with case insensitivity enabled")
//     void TC18_multipleAliases_caseInsensitiveHandling() throws Exception {
        // GIVEN
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)).thenReturn(true);
// 
//         BeanDescription beanDesc = mock(BeanDescription.class);
//         DeserializationContext context = mock(DeserializationContext.class);
//         when(context.getConfig()).thenReturn(config);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, context);
// 
        // Mock _collectAliases to return multiple aliases
//         BeanDeserializerBuilder spyBuilder = spy(builder);
//         Map<String, java.util.List<PropertyName>> aliases = new HashMap<>();
//         aliases.put("name", Arrays.asList(new PropertyName("alias1"), new PropertyName("alias2")));
//         doReturn(aliases).when(spyBuilder)._collectAliases(any());
// 
        // Properties setup
//         SettableBeanProperty prop = mock(SettableBeanProperty.class);
//         when(prop.hasViews()).thenReturn(false);
// 
//         Map<String, SettableBeanProperty> properties = new HashMap<>();
//         properties.put("name", prop);
// 
        // Use reflection to set '_properties'
//         Field propertiesField = BeanDeserializerBuilder.class.getDeclaredField("_properties");
//         propertiesField.setAccessible(true);
//         propertiesField.set(builder, properties);
// 
        // WHEN
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
//         JsonDeserializer<?> deserializer = spyBuilder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//         assertTrue(deserializer instanceof BuilderBasedDeserializer);
// 
        // Additional assertions can be added to verify alias handling via reflection if needed
//     }
// 
//     @Test
//     @DisplayName("BuilderBasedDeserializer is created successfully with no properties")
//     void TC19_noProperties_successfulDeserialization() throws Exception {
        // GIVEN
//         DeserializationConfig config = mock(DeserializationConfig.class);
//         when(config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)).thenReturn(false);
// 
//         BeanDescription beanDesc = mock(BeanDescription.class);
//         DeserializationContext context = mock(DeserializationContext.class);
//         when(context.getConfig()).thenReturn(config);
// 
//         BeanDeserializerBuilder builder = new BeanDeserializerBuilder(beanDesc, context);
// 
        // No properties
//         Map<String, SettableBeanProperty> properties = new HashMap<>();
// 
        // Use reflection to set '_properties'
//         Field propertiesField = BeanDeserializerBuilder.class.getDeclaredField("_properties");
//         propertiesField.setAccessible(true);
//         propertiesField.set(builder, properties);
// 
        // WHEN
//         JavaType valueType = mock(JavaType.class);
//         when(valueType.getRawClass()).thenReturn(SomeType.class);
// 
//         JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, "build");
// 
        // THEN
//         assertNotNull(deserializer);
//         assertTrue(deserializer instanceof BuilderBasedDeserializer);
// 
        // Additional assertions can be added to verify property handling via reflection if needed
//     }
// }
}