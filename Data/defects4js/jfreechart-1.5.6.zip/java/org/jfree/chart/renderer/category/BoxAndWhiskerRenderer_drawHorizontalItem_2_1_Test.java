package org.jfree.chart.renderer.category;
// 
// import org.jfree.chart.ui.RectangleEdge;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.Paint;
// import java.awt.geom.Ellipse2D;
// import java.awt.geom.Line2D;
// import java.awt.geom.Rectangle2D;
// 
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.renderer.category.CategoryItemRendererState;
// import org.jfree.chart.renderer.MutablePaint;
// import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.ArgumentCaptor;
// 
public class BoxAndWhiskerRenderer_drawHorizontalItem_2_1_Test {
// 
//     private BoxAndWhiskerRenderer renderer;
//     private Graphics2D g2;
//     private CategoryItemRendererState state;
//     private Rectangle2D dataArea;
//     private CategoryPlot plot;
//     private CategoryAxis domainAxis;
//     private ValueAxis rangeAxis;
//     private BoxAndWhiskerCategoryDataset dataset;
// 
//     @BeforeEach
//     void setUp() {
//         renderer = new BoxAndWhiskerRenderer();
//         g2 = mock(Graphics2D.class);
//         state = mock(CategoryItemRendererState.class);
//         dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         plot = mock(CategoryPlot.class);
//         domainAxis = mock(CategoryAxis.class);
//         rangeAxis = mock(ValueAxis.class);
//         dataset = mock(BoxAndWhiskerCategoryDataset.class);
//     }
// 
//     @Test
//     @DisplayName("Handles meanVisible=true with a valid mean value within dataArea bounds")
//     void TC21_meanVisibleTrue_ValidMeanWithinBounds() throws Exception {
        // Arrange
//         renderer.setMeanVisible(true);
// 
//         int row = 0;
//         int column = 0;
// 
//         when(dataset.getQ1Value(row, column)).thenReturn(2.0);
//         when(dataset.getQ3Value(row, column)).thenReturn(6.0);
//         when(dataset.getMaxRegularValue(row, column)).thenReturn(8.0);
//         when(dataset.getMinRegularValue(row, column)).thenReturn(1.0);
//         when(dataset.getMeanValue(row, column)).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(10.0, dataArea, plot.getRangeAxisEdge())).thenReturn(50.0);
//         when(state.getBarWidth()).thenReturn(4.0);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxis()).thenReturn(domainAxis);
// 
        // Act
//         renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
// 
        // Assert
//         ArgumentCaptor<Ellipse2D.Double> ellipseCaptor = ArgumentCaptor.forClass(Ellipse2D.Double.class);
//         verify(g2).fill(ellipseCaptor.capture());
//         Ellipse2D.Double drawnEllipse = ellipseCaptor.getValue();
//         assertEquals(50.0 - (4.0 / 4), drawnEllipse.getX(), "Ellipse X position incorrect");
//         assertEquals(0 + (4.0 / 4), drawnEllipse.getY(), "Ellipse Y position incorrect");
//         assertEquals(2.0, drawnEllipse.getWidth(), "Ellipse width incorrect");
//         assertEquals(2.0, drawnEllipse.getHeight(), "Ellipse height incorrect");
// 
//         verify(g2).draw(drawnEllipse);
//     }
// 
//     @Test
//     @DisplayName("Handles meanVisible=true with a valid mean value outside dataArea bounds")
//     void TC22_meanVisibleTrue_InvalidMeanOutsideBounds() throws Exception {
        // Arrange
//         renderer.setMeanVisible(true);
// 
//         int row = 0;
//         int column = 0;
// 
//         when(dataset.getQ1Value(row, column)).thenReturn(2.0);
//         when(dataset.getQ3Value(row, column)).thenReturn(6.0);
//         when(dataset.getMaxRegularValue(row, column)).thenReturn(8.0);
//         when(dataset.getMinRegularValue(row, column)).thenReturn(1.0);
//         when(dataset.getMeanValue(row, column)).thenReturn(200.0);
//         when(rangeAxis.valueToJava2D(200.0, dataArea, plot.getRangeAxisEdge())).thenReturn(150.0);
//         when(state.getBarWidth()).thenReturn(4.0);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxis()).thenReturn(domainAxis);
// 
        // Act
//         renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
// 
        // Assert
//         verify(g2, never()).fill(any(Ellipse2D.Double.class));
//         verify(g2, never()).draw(any(Ellipse2D.Double.class));
//     }
// 
//     @Test
//     @DisplayName("Handles medianVisible=true with a valid median value")
//     void TC23_medianVisibleTrue_ValidMedian() throws Exception {
        // Arrange
//         renderer.setMedianVisible(true);
// 
//         int row = 0;
//         int column = 0;
// 
//         when(dataset.getQ1Value(row, column)).thenReturn(2.0);
//         when(dataset.getQ3Value(row, column)).thenReturn(6.0);
//         when(dataset.getMaxRegularValue(row, column)).thenReturn(8.0);
//         when(dataset.getMinRegularValue(row, column)).thenReturn(1.0);
//         when(dataset.getMedianValue(row, column)).thenReturn(7.5);
//         when(rangeAxis.valueToJava2D(7.5, dataArea, plot.getRangeAxisEdge())).thenReturn(35.0);
//         when(state.getBarWidth()).thenReturn(4.0);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxis()).thenReturn(domainAxis);
// 
        // Act
//         renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
// 
        // Assert
//         ArgumentCaptor<Line2D.Double> lineCaptor = ArgumentCaptor.forClass(Line2D.Double.class);
//         verify(g2).draw(lineCaptor.capture());
//         Line2D.Double drawnLine = lineCaptor.getValue();
//         assertEquals(35.0, drawnLine.getX1(), "Median line X1 incorrect");
//         assertEquals(0.0, drawnLine.getY1(), "Median line Y1 incorrect");
//         assertEquals(35.0, drawnLine.getX2(), "Median line X2 incorrect");
//         assertEquals(4.0, drawnLine.getY2(), "Median line Y2 incorrect");
//     }
// 
//     @Test
//     @DisplayName("Handles medianVisible=true with a null median value")
//     void TC24_medianVisibleTrue_NullMedian() throws Exception {
        // Arrange
//         renderer.setMedianVisible(true);
// 
//         int row = 0;
//         int column = 0;
// 
        // Ensuring getMedianValue returns null for this test case
//         when(dataset.getQ1Value(row, column)).thenReturn(2.0);
//         when(dataset.getQ3Value(row, column)).thenReturn(6.0);
//         when(dataset.getMaxRegularValue(row, column)).thenReturn(8.0);
//         when(dataset.getMinRegularValue(row, column)).thenReturn(1.0);
//         when(dataset.getMedianValue(row, column)).thenReturn(null);
//         when(state.getBarWidth()).thenReturn(4.0);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxis()).thenReturn(domainAxis);
// 
        // Act
//         renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
// 
        // Assert
//         verify(g2, never()).draw(any(Line2D.Double.class));
//     }
// 
//     @Test
//     @DisplayName("Handles useOutlinePaintForWhiskers=true ensuring outline paint is used for whiskers")
//     void TC25_useOutlinePaintForWhiskersTrue() throws Exception {
        // Arrange
//         renderer.setUseOutlinePaintForWhiskers(true);
// 
//         Paint outlinePaint = Color.RED;
// 
//         int row = 0;
//         int column = 0;
// 
//         when(dataset.getQ1Value(row, column)).thenReturn(2.0);
//         when(dataset.getQ3Value(row, column)).thenReturn(6.0);
//         when(dataset.getMaxRegularValue(row, column)).thenReturn(8.0);
//         when(dataset.getMinRegularValue(row, column)).thenReturn(1.0);
//         when(dataset.getMeanValue(row, column)).thenReturn(4.0);
//         when(dataset.getMedianValue(row, column)).thenReturn(4.5);
//         when(rangeAxis.valueToJava2D(2.0, dataArea, plot.getRangeAxisEdge())).thenReturn(20.0);
//         when(rangeAxis.valueToJava2D(6.0, dataArea, plot.getRangeAxisEdge())).thenReturn(60.0);
//         when(rangeAxis.valueToJava2D(8.0, dataArea, plot.getRangeAxisEdge())).thenReturn(80.0);
//         when(rangeAxis.valueToJava2D(1.0, dataArea, plot.getRangeAxisEdge())).thenReturn(10.0);
//         when(rangeAxis.valueToJava2D(4.0, dataArea, plot.getRangeAxisEdge())).thenReturn(40.0);
//         when(state.getBarWidth()).thenReturn(4.0);
        // Fixed to ensure correct outline paint is returned
//         when(renderer.getItemOutlinePaint(row, column)).thenReturn(outlinePaint);
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxis()).thenReturn(domainAxis);
// 
        // Act
//         renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
// 
        // Assert
        // Verify that the outline paint is used for whiskers
//         verify(g2).setPaint(outlinePaint);
        // Capture the lines drawn for the whiskers
//         ArgumentCaptor<Line2D.Double> lineCaptor = ArgumentCaptor.forClass(Line2D.Double.class);
//         verify(g2, times(4)).draw(lineCaptor.capture());
        // Note: Changed to check that the line is correctly set instead of the loop over g2 paints
//     }
// }
}