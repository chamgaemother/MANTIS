package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.io.IOContext;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ByteSourceJsonBootstrapper_detectEncoding_2_1_Test {

    @Test
    @DisplayName("detectEncoding without BOM detects UTF32_BE via checkUTF32 with bigEndian=true")
    public void TC23_detectEncoding_UTF32_BE() throws IOException {
        // GIVEN
        byte[] input = {0x00, 0x00, 0x00, 0x31}; // Represents '1' in UTF32_BE
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF32_BE, encoding);
    }

    @Test
    @DisplayName("detectEncoding without BOM detects UTF32_LE via checkUTF32 with bigEndian=false")
    public void TC24_detectEncoding_UTF32_LE() throws IOException {
        // GIVEN
        byte[] input = {0x31, 0x00, 0x00, 0x00}; // Represents '1' in UTF32_LE
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF32_LE, encoding);
    }

    @Test
    @DisplayName("detectEncoding without BOM detects UTF16_BE via checkUTF16 with bigEndian=true")
    public void TC25_detectEncoding_UTF16_BE() throws IOException {
        // GIVEN
        byte[] input = {(byte)0xFE, (byte)0xFF, 0x00, 0x31}; // Represents BOM and '1' in UTF16_BE
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF16_BE, encoding);
    }

    @Test
    @DisplayName("detectEncoding without BOM detects UTF16_LE via checkUTF16 with bigEndian=false")
    public void TC26_detectEncoding_UTF16_LE() throws IOException {
        // GIVEN
        byte[] input = {(byte)0xFF, (byte)0xFE, 0x31, 0x00}; // Represents BOM and '1' in UTF16_LE
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF16_LE, encoding);
    }

    @Test
    @DisplayName("detectEncoding without BOM defaults to UTF8 when handleBOM, checkUTF32, and checkUTF16 fail")
    public void TC27_detectEncoding_DefaultsTo_UTF8() throws IOException {
        // GIVEN
        byte[] input = {0x12, 0x34, 0x56, 0x78}; // Invalid BOM and encoding indicators
        IOContext context = new IOContext(null, new ByteArrayInputStream(input), false);
        ByteSourceJsonBootstrapper bootstrapper = new ByteSourceJsonBootstrapper(context, input, 0, input.length);

        // WHEN
        JsonEncoding encoding = bootstrapper.detectEncoding();

        // THEN
        assertEquals(JsonEncoding.UTF8, encoding);
    }
}