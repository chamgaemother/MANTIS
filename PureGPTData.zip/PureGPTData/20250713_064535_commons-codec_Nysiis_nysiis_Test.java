import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.apache.commons.codec.EncoderException;
import static org.junit.jupiter.api.Assertions.*;

public class NysiisTest {

    private final Nysiis nysiisStrict = new Nysiis(true);
    private final Nysiis nysiisNonStrict = new Nysiis(false);

    @Test
    public void testNullInput() {
        assertNull(nysiisStrict.nysiis(null), "Null input should return null");
    }
    
    @Test
    public void testEmptyString() {
        assertEquals("", nysiisStrict.nysiis(""), "Empty input should return an empty string");
    }

    @ParameterizedTest
    @CsvSource({
        "MACARTHUR, MCCR",
        "KNIGHT, NGT",
        "KNAPP, NAP",
        "KELLY, CLY",
        "PHONES, FANS",
        "PFISTER, FFSTR",
        "SCHMIDT, SST",
        "SCHLENK, SLSN"
    })
    public void testSpecialPrefixes(String input, String expected) {
        assertEquals(expected, nysiisStrict.nysiis(input), "Prefix transcoding should match expected");
    }

    @ParameterizedTest
    @CsvSource({
        "DEE, D",
        "PIE, PY",
        "HAND, HD",
        "RAND, RD",
        "AND, AD"
    })
    public void testSpecialSuffixes(String input, String expected) {
        assertEquals(expected, nysiisStrict.nysiis(input), "Suffix transcoding should match expected");
    }

    @ParameterizedTest
    @CsvSource({
        "HELLOWORLD, HLAWLD",
        "HARTHAVEN, HARTFN",
        "HOWARD, H",
        "WHEN, WN",
        "WOMAN, WMN"
    })
    public void testInternalRules(String input, String expected) {
        assertEquals(expected, nysiisStrict.nysiis(input), "Internal rules should match expected");
    }

    @Test
    public void testTrailingAY() {
        assertEquals("RY", nysiisStrict.nysiis("RAY"), "Trailing AY should be replaced with Y");
    }

    @Test
    public void testTrailingS() {
        assertEquals("MAR", nysiisStrict.nysiis("MARS"), "Trailing S should be removed");
    }

    @Test
    public void testTrailingA() {
        assertEquals("MAR", nysiisStrict.nysiis("MARA"), "Trailing A should be removed");
    }

    @Test
    public void testCollapseRepeats() {
        assertEquals("M", nysiisStrict.nysiis("MMMMMMM"), "Repeated characters should collapse");
    }

    @ParameterizedTest
    @CsvSource({
        "MAAAAAAAAA, MAC",
        "KNIGHT, NGT", 
        "SCHMOE, SMS"
    })
    public void testStrictMode(String input, String expected) {
        assertEquals(expected, nysiisStrict.nysiis(input), "Strict mode truncates to length 6");
        assertEquals(nysiisNonStrict.nysiis(input), nysiisNonStrict.nysiis(input), "Non-strict mode allows longer results");
    }
}