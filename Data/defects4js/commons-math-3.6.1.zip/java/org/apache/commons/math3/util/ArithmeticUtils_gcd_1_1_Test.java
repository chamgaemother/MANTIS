package org.apache.commons.math3.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.exception.MathArithmeticException;

public class ArithmeticUtils_gcd_1_1_Test {

    @Test
    @DisplayName("gcd(Integer.MIN_VALUE, Integer.MIN_VALUE) throws MathArithmeticException when both operands are Integer.MIN_VALUE")
    void TC17() {
        int p = Integer.MIN_VALUE;
        int q = Integer.MIN_VALUE;
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(p, q));
    }

    @Test
    @DisplayName("gcd(Integer.MIN_VALUE, 1) throws MathArithmeticException when first operand is Integer.MIN_VALUE and second is positive")
    void TC18() {
        int p = Integer.MIN_VALUE;
        int q = 1;
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(p, q));
    }

    @Test
    @DisplayName("gcd(Integer.MIN_VALUE, -1) throws MathArithmeticException when first operand is Integer.MIN_VALUE and second is -1")
    void TC19() {
        int p = Integer.MIN_VALUE;
        int q = -1;
        assertThrows(MathArithmeticException.class, () -> ArithmeticUtils.gcd(p, q));
    }

    @Test
    @DisplayName("gcd(17, 31) returns 1 when both operands are co-prime positive integers")
    void TC20() {
        int p = 17;
        int q = 31;
        int result = ArithmeticUtils.gcd(p, q);
        assertEquals(1, result);
    }

    @Test
    @DisplayName("gcd(-25, 75) returns 25 when first operand is negative and second is positive")
    void TC21() {
        int p = -25;
        int q = 75;
        int result = ArithmeticUtils.gcd(p, q);
        assertEquals(25, result);
    }
}