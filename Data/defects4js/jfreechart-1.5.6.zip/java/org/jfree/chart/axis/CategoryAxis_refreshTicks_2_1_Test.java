package org.jfree.chart.axis;

import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryTick;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.AxisState;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class CategoryAxis_refreshTicks_2_1_Test {

    @Test
    @DisplayName("refreshTicks handles proportional width type with LEFT edge, correctly calculating label widths based on dataArea width")
    public void test_TC24_refreshTicks_proportionalWidthType_LeftEdge() {
        // GIVEN
        CategoryAxis categoryAxis = new CategoryAxis();
        categoryAxis.setMaximumCategoryLabelWidthRatio(0.5f);
        categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.STANDARD);

        CategoryPlot plot = new CategoryPlot();
        plot.setOrientation(PlotOrientation.HORIZONTAL);
        plot.setDomainAxis(categoryAxis);
        // Correcting method usage here and making sure it is working as expected - we need to manually add CategoryPlot to the CategoryAxis
        categoryAxis.configure();

        // Note: Based on JFreeChart's API, we assume categories are set from data associated with the plot (not explicitly shown here and assumed by the sample code above)

        // Setup Graphics2D
        BufferedImage bi = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = bi.createGraphics();

        // Setup AxisState
        AxisState axisState = new AxisState();

        // Create dataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);

        // Set edge to LEFT
        RectangleEdge edge = RectangleEdge.LEFT;

        // WHEN
        List<CategoryTick> ticks = categoryAxis.refreshTicks(g2, axisState, dataArea, edge);

        // THEN
        assertEquals(3, ticks.size(), "Should have 3 ticks for 3 categories");
        for (int i = 0; i < ticks.size(); i++) {
            CategoryTick tick = ticks.get(i);
            assertEquals("Cat" + (i + 1), tick.getCategory(), "Tick category should match");
        }

        assertTrue(axisState.getMax() > 0, "AxisState max should be greater than 0");

        // Dispose Graphics2D
        g2.dispose();
    }

    @Test
    @DisplayName("refreshTicks handles proportional width type with TOP edge, correctly calculating label heights based on dataArea height")
    public void test_TC25_refreshTicks_proportionalWidthType_TopEdge() {
        // GIVEN
        CategoryAxis categoryAxis = new CategoryAxis();
        categoryAxis.setMaximumCategoryLabelWidthRatio(0.4f);
        categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.STANDARD);

        CategoryPlot plot = new CategoryPlot();
        plot.setOrientation(PlotOrientation.VERTICAL);
        plot.setDomainAxis(categoryAxis);
        // Correcting method usage here and making sure it is working as expected - we need to manually add CategoryPlot to the CategoryAxis
        categoryAxis.configure();

        // Note: The same assumption about categories applies here from the first case

        // Setup Graphics2D
        BufferedImage bi = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = bi.createGraphics();

        // Setup AxisState
        AxisState axisState = new AxisState();

        // Create dataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);

        // Set edge to TOP
        RectangleEdge edge = RectangleEdge.TOP;

        // WHEN
        List<CategoryTick> ticks = categoryAxis.refreshTicks(g2, axisState, dataArea, edge);

        // THEN
        assertEquals(3, ticks.size(), "Should have 3 ticks for 3 categories");
        for (int i = 0; i < ticks.size(); i++) {
            CategoryTick tick = ticks.get(i);
            assertEquals("Cat" + (char)('A' + i), tick.getCategory(), "Tick category should match");
        }

        assertTrue(axisState.getMax() > 0, "AxisState max should be greater than 0");

        // Dispose Graphics2D
        g2.dispose();
    }
}