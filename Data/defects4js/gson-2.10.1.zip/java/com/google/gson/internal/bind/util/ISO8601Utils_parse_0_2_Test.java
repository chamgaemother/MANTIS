package com.google.gson.internal.bind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParsePosition;
import java.text.ParseException;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601Utils_parse_0_2_Test {

    @Test
    @DisplayName("parse date with invalid separator")
    void test_TC06_parseDateWithInvalidSeparator() {
        String date = "2023/10/05";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("parse leap year date")
    void test_TC07_parseLeapYearDate() throws ParseException {
        String date = "2020-02-29";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(date, pos);

        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.setLenient(false);
        calendar.set(Calendar.YEAR, 2020);
        calendar.set(Calendar.MONTH, Calendar.FEBRUARY - 1); // 1
        calendar.set(Calendar.DAY_OF_MONTH, 29);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();

        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("parse non-leap year invalid date")
    void test_TC08_parseNonLeapYearInvalidDate() {
        String date = "2019-02-29";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("parse time with only hours component")
    void test_TC09_parseTimeWithOnlyHoursComponent() throws ParseException {
        String date = "2023-10-05T14Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(date, pos);

        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.setLenient(false);
        calendar.set(Calendar.YEAR, 2023);
        calendar.set(Calendar.MONTH, Calendar.OCTOBER - 1); // 9
        calendar.set(Calendar.DAY_OF_MONTH, 5);
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate = calendar.getTime();

        assertEquals(expectedDate, result);
        assertEquals(date.length(), pos.getIndex());
    }

    @Test
    @DisplayName("parse date missing timezone indicator")
    void test_TC10_parseDateMissingTimezoneIndicator() {
        String date = "2023-10-05T14:30:00";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(IllegalArgumentException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }
}