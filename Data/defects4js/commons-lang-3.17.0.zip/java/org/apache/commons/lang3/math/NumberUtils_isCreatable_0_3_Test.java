package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_isCreatable_0_3_Test {

    @Test
    @DisplayName("isCreatable(\"-0.0\") returns true for negative zero in decimal")
    void testTC11() {
        String input = "-0.0";
        boolean result = NumberUtils.isCreatable(input);
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"+1E-3\") returns true for positive scientific notation with negative exponent")
    void testTC12() {
        String input = "+1E-3";
        boolean result = NumberUtils.isCreatable(input);
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"1.0d\") returns true for decimal with type qualifier 'd'")
    void testTC13() {
        String input = "1.0d";
        boolean result = NumberUtils.isCreatable(input);
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"1.0f\") returns true for decimal with type qualifier 'f'")
    void testTC14() {
        String input = "1.0f";
        boolean result = NumberUtils.isCreatable(input);
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("isCreatable(\"1.0L\") returns false when 'L' is used with decimal")
    void testTC15() {
        String input = "1.0L";
        boolean result = NumberUtils.isCreatable(input);
        Assertions.assertFalse(result);
    }

}