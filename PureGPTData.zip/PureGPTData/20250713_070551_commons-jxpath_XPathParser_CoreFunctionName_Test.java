import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.ri.parser.*;
import org.junit.jupiter.api.Test;

public class XPathParserTest {

    @Test
    public void testCoreFunctionName_last() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_LAST);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_LAST, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_position() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_POSITION);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_POSITION, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_count() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_COUNT);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_COUNT, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_id() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_ID);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_ID, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_localName() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_LOCAL_NAME);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_LOCAL_NAME, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_namespaceURI() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_NAMESPACE_URI);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_NAMESPACE_URI, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_name() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_NAME);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_NAME, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_string() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_STRING);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_STRING, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_concat() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_CONCAT);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_CONCAT, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_startsWith() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_STARTS_WITH);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_STARTS_WITH, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_endsWith() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_ENDS_WITH);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_ENDS_WITH, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_contains() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_CONTAINS);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_CONTAINS, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_substringBefore() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_SUBSTRING_BEFORE);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_SUBSTRING_BEFORE, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_substringAfter() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_SUBSTRING_AFTER);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_SUBSTRING_AFTER, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_substring() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_SUBSTRING);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_SUBSTRING, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_stringLength() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_STRING_LENGTH);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_STRING_LENGTH, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_normalizeSpace() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_NORMALIZE_SPACE);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_NORMALIZE_SPACE, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_translate() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_TRANSLATE);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_TRANSLATE, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_boolean() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_BOOLEAN);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_BOOLEAN, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_not() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_NOT);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_NOT, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_true() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_TRUE);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_TRUE, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_false() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_FALSE);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_FALSE, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_null() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_NULL);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_NULL, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_lang() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_LANG);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_LANG, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_number() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_NUMBER);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_NUMBER, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_sum() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_SUM);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_SUM, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_floor() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_FLOOR);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_FLOOR, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_ceiling() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_CEILING);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_CEILING, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_round() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_ROUND);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_ROUND, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_key() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_KEY);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_KEY, parser.CoreFunctionName());
    }

    @Test
    public void testCoreFunctionName_formatNumber() {
        XPathParserTokenManager tm = new MockTokenManager(XPathParserConstants.FUNCTION_FORMAT_NUMBER);
        XPathParser parser = new XPathParser(tm);
        assertEquals(Compiler.FUNCTION_FORMAT_NUMBER, parser.CoreFunctionName());
    }

    private static class MockTokenManager extends XPathParserTokenManager {
        private final int tokenKind;

        public MockTokenManager(int tokenKind) {
            super(null);
            this.tokenKind = tokenKind;
        }

        @Override
        public Token getNextToken() {
            Token token = new Token();
            token.kind = this.tokenKind;
            return token;
        }
    }
}