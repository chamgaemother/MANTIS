package org.jsoup.internal;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

public class SimpleStreamReader_read_0_3_Test {

    @Test
    @DisplayName("read with bufferUp returning -1, expecting readFully to reset decoder and return -1")
    void TC11_ReadWithBufferUpReturningMinusOne() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;

        // Mock InputStream to have no available bytes
        InputStream mockInputStream = new InputStream() {
            @Override
            public int read(byte[] b, int off, int len) {
                return -1;
            }

            @Override
            public int read() {
                return -1;
            }
        };

        // Instantiate SimpleStreamReader
        SimpleStreamReader reader = new SimpleStreamReader(mockInputStream, Charset.defaultCharset());

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertEquals(-1, result, "Expected read to return -1");
    }

    @Test
    @DisplayName("read with bufferUp throwing IOException, expecting exception to propagate")
    void TC12_ReadWithBufferUpThrowingIOException() throws IOException {
        // GIVEN
        char[] buffer = new char[10];
        int off = 0;
        int len = 10;

        // Mock InputStream
        InputStream mockInputStream = new InputStream() {
            @Override
            public int read(byte[] b, int off, int len) throws IOException {
                throw new IOException("Mocked IOException from bufferUp");
            }

            @Override
            public int read() {
                return -1;
            }
        };

        // Instantiate SimpleStreamReader
        SimpleStreamReader reader = new SimpleStreamReader(mockInputStream, Charset.defaultCharset());

        // WHEN & THEN
        IOException thrown = assertThrows(IOException.class, () -> {
            reader.read(buffer, off, len);
        }, "Expected read to throw IOException");
        assertEquals("Mocked IOException from bufferUp", thrown.getMessage());
    }

    @Test
    @DisplayName("read with multiple underflow and bufferUp calls, ensuring partial reads")
    void TC13_ReadWithMultipleUnderflowAndBufferUpForPartialRead() throws IOException {
        // GIVEN
        char[] buffer = new char[20];
        int off = 0;
        int len = 20;

        // Mock InputStream to provide partial data
        InputStream mockInputStream = new InputStream() {
            private int readCalls = 0;

            @Override
            public int read(byte[] b, int off, int len) {
                readCalls++;
                if (readCalls == 1) {
                    b[off] = 'H';
                    b[off + 1] = 'i';
                    return 2; // Read two bytes
                } else {
                    return -1; // End of stream
                }
            }

            @Override
            public int read() {
                return -1;
            }
        };

        // Instantiate SimpleStreamReader
        SimpleStreamReader reader = new SimpleStreamReader(mockInputStream, Charset.defaultCharset());

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertTrue(result > 0 && result < len, "Expected partial number of characters read");
        assertEquals('H', buffer[0], "First character should be 'H'");
        assertEquals('i', buffer[1], "Second character should be 'i'");
    }

    @Test
    @DisplayName("read with byteBuf having remaining data, ensuring no additional bufferUp calls")
    void TC14_ReadWithByteBufHavingRemainingData() throws IOException {
        // GIVEN
        char[] buffer = new char[15];
        int off = 0;
        int len = 15;

        // Mock InputStream
        InputStream mockInputStream = new InputStream() {
            @Override
            public int read(byte[] b, int off, int len) {
                return -1; // No additional data
            }

            @Override
            public int read() {
                return -1;
            }
        };

        // Instantiate SimpleStreamReader
        SimpleStreamReader reader = new SimpleStreamReader(mockInputStream, Charset.defaultCharset());

        // Read once to consume some data
        char[] initialBuffer = new char[5];
        reader.read(initialBuffer, 0, 5);

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertEquals(-1, result, "Expected no additional characters to be read");
    }

    @Test
    @DisplayName("read resets decoder after readFully is true")
    void TC15_ReadResetsDecoderAfterReadFully() throws IOException {
        // GIVEN
        char[] buffer = new char[25];
        int off = 0;
        int len = 25;

        // Mock InputStream to provide exact data
        InputStream mockInputStream = new InputStream() {
            @Override
            public int read(byte[] b, int off, int len) {
                b[off] = 'J';
                b[off + 1] = 'S';
                b[off + 2] = 'O';
                b[off + 3] = 'U';
                b[off + 4] = 'P';
                return 5; // Read five bytes
            }

            @Override
            public int read() {
                return -1;
            }
        };

        // Instantiate SimpleStreamReader
        SimpleStreamReader reader = new SimpleStreamReader(mockInputStream, Charset.defaultCharset());

        // WHEN
        int result = reader.read(buffer, off, len);

        // THEN
        assertEquals(5, result, "Expected 5 characters to be read");
        assertEquals('J', buffer[0], "First character should be 'J'");
        assertEquals('S', buffer[1], "Second character should be 'S'");
        assertEquals('O', buffer[2], "Third character should be 'O'");
        assertEquals('U', buffer[3], "Fourth character should be 'U'");
        assertEquals('P', buffer[4], "Fifth character should be 'P'");
    }
}