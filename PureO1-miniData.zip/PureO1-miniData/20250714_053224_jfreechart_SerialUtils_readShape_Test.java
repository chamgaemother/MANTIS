package org.jfree.chart.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Shape;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.lang.ClassNotFoundException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class SerialUtilsTest {

    @Test
    @DisplayName("readShape should throw IllegalArgumentException when stream is null")
    void testReadShape_NullStream() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            SerialUtils.readShape(null);
        });
        assertEquals("Null 'stream' argument.", exception.getMessage());
    }

    @Test
    @DisplayName("readShape should return null when isNull is true")
    void testReadShape_IsNullTrue() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(true);

        Shape result = SerialUtils.readShape(mockStream);
        assertNull(result);
    }

    @Test
    @DisplayName("readShape should return Line2D when class is Line2D")
    void testReadShape_Line2D() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenReturn(Line2D.class);
        when(mockStream.readDouble()).thenReturn(1.0, 2.0, 3.0, 4.0);

        Shape result = SerialUtils.readShape(mockStream);
        assertTrue(result instanceof Line2D);
        Line2D line = (Line2D) result;
        assertEquals(1.0, line.getX1());
        assertEquals(2.0, line.getY1());
        assertEquals(3.0, line.getX2());
        assertEquals(4.0, line.getY2());
    }

    @Test
    @DisplayName("readShape should return Rectangle2D when class is Rectangle2D")
    void testReadShape_Rectangle2D() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenReturn(Rectangle2D.class);
        when(mockStream.readDouble()).thenReturn(5.0, 6.0, 7.0, 8.0);

        Shape result = SerialUtils.readShape(mockStream);
        assertTrue(result instanceof Rectangle2D);
        Rectangle2D rect = (Rectangle2D) result;
        assertEquals(5.0, rect.getX());
        assertEquals(6.0, rect.getY());
        assertEquals(7.0, rect.getWidth());
        assertEquals(8.0, rect.getHeight());
    }

    @Test
    @DisplayName("readShape should return Ellipse2D when class is Ellipse2D")
    void testReadShape_Ellipse2D() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenReturn(Ellipse2D.class);
        when(mockStream.readDouble()).thenReturn(9.0, 10.0, 11.0, 12.0);

        Shape result = SerialUtils.readShape(mockStream);
        assertTrue(result instanceof Ellipse2D);
        Ellipse2D ellipse = (Ellipse2D) result;
        assertEquals(9.0, ellipse.getX());
        assertEquals(10.0, ellipse.getY());
        assertEquals(11.0, ellipse.getWidth());
        assertEquals(12.0, ellipse.getHeight());
    }

    @Test
    @DisplayName("readShape should return Arc2D when class is Arc2D")
    void testReadShape_Arc2D() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenReturn(Arc2D.class);
        when(mockStream.readDouble()).thenReturn(13.0, 14.0, 15.0, 16.0, 17.0, 18.0);
        when(mockStream.readInt()).thenReturn(Arc2D.OPEN);

        Shape result = SerialUtils.readShape(mockStream);
        assertTrue(result instanceof Arc2D);
        Arc2D arc = (Arc2D) result;
        assertEquals(13.0, arc.getX());
        assertEquals(14.0, arc.getY());
        assertEquals(15.0, arc.getWidth());
        assertEquals(16.0, arc.getHeight());
        assertEquals(17.0, arc.getAngleStart());
        assertEquals(18.0, arc.getAngleExtent());
        assertEquals(Arc2D.OPEN, arc.getArcType());
    }

    @Test
    @DisplayName("readShape should return GeneralPath when class is GeneralPath")
    void testReadShape_GeneralPath() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        GeneralPath gp = new GeneralPath();

        when(mockStream.readBoolean()).thenReturn(false, false, true);
        when(mockStream.readObject()).thenReturn(GeneralPath.class);
        when(mockStream.readInt()).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_CLOSE);
        when(mockStream.readFloat()).thenReturn(1.0f, 2.0f, 
                                               0.0f, 0.0f, 0.0f, 0.0f);
        when(mockStream.readInt()).thenReturn(GeneralPath.WIND_NON_ZERO);

        Shape result = SerialUtils.readShape(mockStream);
        assertTrue(result instanceof GeneralPath);
        GeneralPath path = (GeneralPath) result;
        assertFalse(path.getPathIterator(null).isDone());
    }

    @Test
    @DisplayName("readShape should return Shape when class is other Serializable Shape")
    void testReadShape_OtherSerializableShape() throws IOException, ClassNotFoundException {
        Shape mockShape = mock(Shape.class, withSettings().extraInterfaces(Serializable.class));
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenReturn(mockShape);

        Shape result = SerialUtils.readShape(mockStream);
        assertSame(mockShape, result);
    }

    @Test
    @DisplayName("readShape should return Shape when class is non-specialized Shape")
    void testReadShape_NonSpecializedShape() throws IOException, ClassNotFoundException {
        Shape mockShape = mock(Shape.class);
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenReturn(mockShape.getClass());
        when(mockStream.readObject()).thenReturn(mockShape);

        Shape result = SerialUtils.readShape(mockStream);
        assertSame(mockShape, result);
    }

    @Test
    @DisplayName("readShape should throw RuntimeException on invalid PathIterator segment type")
    void testReadShape_GeneralPath_InvalidSegment() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false, false, true);
        when(mockStream.readObject()).thenReturn(GeneralPath.class);
        when(mockStream.readInt()).thenReturn(999); // Invalid segment type
        when(mockStream.readFloat()).thenReturn(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);

        when(mockStream.readInt()).thenReturn(GeneralPath.WIND_NON_ZERO);
        when(mockStream.readBoolean()).thenReturn(true);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            SerialUtils.readShape(mockStream);
        });
        assertEquals("JFreeChart - No path exists", exception.getMessage());
    }

    @Test
    @DisplayName("readShape should handle multiple segments in GeneralPath")
    void testReadShape_GeneralPath_MultipleSegments() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        // Initial isNull = false, class = GeneralPath
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenReturn(GeneralPath.class);
        // hasNext for while loop
        when(mockStream.readBoolean()).thenReturn(false, false, true);
        // First segment: SEG_MOVETO
        when(mockStream.readInt()).thenReturn(PathIterator.SEG_MOVETO);
        when(mockStream.readFloat()).thenReturn(10.0f, 20.0f, 0.0f, 0.0f, 0.0f, 0.0f);
        // Winding rule
        when(mockStream.readInt()).thenReturn(GeneralPath.WIND_EVEN_ODD);
        // Second segment: SEG_LINETO
        when(mockStream.readInt()).thenReturn(PathIterator.SEG_LINETO);
        when(mockStream.readFloat()).thenReturn(30.0f, 40.0f, 0.0f, 0.0f, 0.0f, 0.0f);
        // Winding rule
        when(mockStream.readInt()).thenReturn(GeneralPath.WIND_EVEN_ODD);
        // Next hasNext = true to end loop
        when(mockStream.readBoolean()).thenReturn(true);

        Shape result = SerialUtils.readShape(mockStream);
        assertTrue(result instanceof GeneralPath);
        GeneralPath path = (GeneralPath) result;
        path.moveTo(10.0f, 20.0f);
        path.lineTo(30.0f, 40.0f);
    }

    @Test
    @DisplayName("readShape should throw IOException when reading class fails")
    void testReadShape_ClassNotFound() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenReturn(false);
        when(mockStream.readObject()).thenThrow(new ClassNotFoundException("Class not found"));

        assertThrows(ClassNotFoundException.class, () -> {
            SerialUtils.readShape(mockStream);
        });
    }

    @Test
    @DisplayName("readShape should throw IOException when stream fails")
    void testReadShape_StreamIOException() throws IOException, ClassNotFoundException {
        ObjectInputStream mockStream = mock(ObjectInputStream.class);
        when(mockStream.readBoolean()).thenThrow(new IOException("Stream error"));

        assertThrows(IOException.class, () -> {
            SerialUtils.readShape(mockStream);
        });
    }
}