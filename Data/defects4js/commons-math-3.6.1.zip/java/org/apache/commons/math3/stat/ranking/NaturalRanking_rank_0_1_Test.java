package org.apache.commons.math3.stat.ranking;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.exception.NotANumberException;
import org.apache.commons.math3.exception.MathInternalError;

public class NaturalRanking_rank_0_1_Test {

    @Test
    @DisplayName("rank with empty array returns empty result")
    public void testTC01() {
        double[] data = new double[]{};
        NaturalRanking ranking = new NaturalRanking();
        double[] result = ranking.rank(data);
        assertEquals(0, result.length, "The result array should be empty");
    }

    @Test
    @DisplayName("rank with single element array returns rank 1")
    public void testTC02() {
        double[] data = new double[]{5.0};
        NaturalRanking ranking = new NaturalRanking();
        double[] result = ranking.rank(data);
        assertEquals(1, result.length, "The result array should contain one element");
        assertEquals(1.0, result[0], "The rank of the single element should be 1.0");
    }

    @Test
    @DisplayName("rank replaces NaNs with +Infinity using MAXIMAL strategy")
    public void testTC03() {
        double[] data = new double[]{3.0, Double.NaN, 1.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.MAXIMAL);
        double[] result = ranking.rank(data);
        assertTrue(Double.isInfinite(result[1]) && result[1] > 0, "The second element should be +Infinity");
    }

    @Test
    @DisplayName("rank replaces NaNs with -Infinity using MINIMAL strategy")
    public void testTC04() {
        double[] data = new double[]{Double.NaN, 2.0, 4.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.MINIMAL);
        double[] result = ranking.rank(data);
        assertTrue(Double.isInfinite(result[0]) && result[0] < 0, "The first element should be -Infinity");
    }

    @Test
    @DisplayName("rank removes NaNs using REMOVED strategy")
    public void testTC05() {
        double[] data = new double[]{1.0, Double.NaN, 3.0};
        NaturalRanking ranking = new NaturalRanking(NaNStrategy.REMOVED);
        double[] result = ranking.rank(data);
        assertEquals(2, result.length, "The result array should have two elements after removing NaNs");
        assertEquals(1.0, result[0], "The rank of the first element should be 1.0");
        assertEquals(2.0, result[1], "The rank of the third element should be 2.0");
    }

}