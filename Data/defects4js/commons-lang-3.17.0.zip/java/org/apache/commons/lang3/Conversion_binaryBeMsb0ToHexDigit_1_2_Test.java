package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Conversion_binaryBeMsb0ToHexDigit_1_2_Test {

    @Test
    @DisplayName("Returns '7' when pos >= 3, src[pos-3] is true, src[pos-2] is false, src[pos-1] is true, and src[pos] is false")
    public void TC18() {
        // GIVEN
        boolean[] src = {true, false, true, false};
        int srcPos = 0;

        // WHEN
        char result = Conversion.binaryBeMsb0ToHexDigit(src, srcPos);

        // THEN
        assertEquals('7', result);
    }
}