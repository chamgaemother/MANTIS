package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class StringUtils_getLevenshteinDistance_1_1_Test {

    @Test
    @DisplayName("getLevenshteinDistance(\"test\", \"test\", 0) returns 0 when threshold is zero and strings are identical")
    public void TC16() {
        // GIVEN
        CharSequence s = "test";
        CharSequence t = "test";
        int threshold = 0;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"test\", \"best\", 0) returns -1 when threshold is zero and strings differ")
    public void TC17() {
        // GIVEN
        CharSequence s = "test";
        CharSequence t = "best";
        int threshold = 0;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(-1, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"a\", \"b\", 1) returns 1 for single-character substitution within threshold")
    public void TC18() {
        // GIVEN
        CharSequence s = "a";
        CharSequence t = "b";
        int threshold = 1;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(1, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"abc\", \"xyz\", 3) returns 3 when distance equals threshold")
    public void TC19() {
        // GIVEN
        CharSequence s = "abc";
        CharSequence t = "xyz";
        int threshold = 3;

        // WHEN
        int result = StringUtils.getLevenshteinDistance(s, t, threshold);

        // THEN
        assertEquals(3, result);
    }

}