package com.fasterxml.jackson.core.json;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
import com.fasterxml.jackson.core.ObjectCodec;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.io.IOContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class ReaderBasedJsonParser_nextToken_0_3_Test {

    @Test
    @DisplayName("nextToken() returns START_ARRAY when encountering '[' outside of object")
    public void TC11_nextToken_StartArrayOutsideObject() throws Exception {
        // Initialize ReaderBasedJsonParser with '['
        JsonFactory factory = new JsonFactory();
        StringReader reader = new StringReader("[");

        // Use reflection to access the ReaderBasedJsonParser constructor
        Constructor<ReaderBasedJsonParser> constructor = ReaderBasedJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, StringReader.class, ObjectCodec.class, CharsToNameCanonicalizer.class);
        constructor.setAccessible(true);

        // Create IOContext instance
        IOContext ioContext = new IOContext(factory._getBufferRecycler(), reader, false);

        // Instantiate ReaderBasedJsonParser
        ReaderBasedJsonParser parser = constructor.newInstance(ioContext, 0, reader, null, 
                CharsToNameCanonicalizer.createRoot());

        // Invoke nextToken()
        JsonToken result = parser.nextToken();

        // Assert that the result is START_ARRAY
        assertEquals(JsonToken.START_ARRAY, result, "The token should be START_ARRAY");

        // Use reflection to verify that child array context is created
        Field parsingContextField = ReaderBasedJsonParser.class.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        JsonReadContext context = (JsonReadContext) parsingContextField.get(parser);

        assertTrue(context.inArray(), "Parsing context should be in array");
    }

    @Test
    @DisplayName("nextToken() returns START_OBJECT when encountering '{' outside of object")
    public void TC12_nextToken_StartObjectOutsideObject() throws Exception {
        // Initialize ReaderBasedJsonParser with '{'
        JsonFactory factory = new JsonFactory();
        StringReader reader = new StringReader("{");

        // Use reflection to access the ReaderBasedJsonParser constructor
        Constructor<ReaderBasedJsonParser> constructor = ReaderBasedJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, StringReader.class, ObjectCodec.class, CharsToNameCanonicalizer.class);
        constructor.setAccessible(true);

        // Create IOContext instance
        IOContext ioContext = new IOContext(factory._getBufferRecycler(), reader, false);

        // Instantiate ReaderBasedJsonParser
        ReaderBasedJsonParser parser = constructor.newInstance(ioContext, 0, reader, null, 
                CharsToNameCanonicalizer.createRoot());

        // Invoke nextToken()
        JsonToken result = parser.nextToken();

        // Assert that the result is START_OBJECT
        assertEquals(JsonToken.START_OBJECT, result, "The token should be START_OBJECT");

        // Use reflection to verify that child object context is created
        Field parsingContextField = ReaderBasedJsonParser.class.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        JsonReadContext context = (JsonReadContext) parsingContextField.get(parser);

        assertTrue(context.inObject(), "Parsing context should be in object");
    }

    @Test
    @DisplayName("nextToken() throws exception when encountering '}' unexpectedly")
    public void TC13_nextToken_UnexpectedClosingBrace() throws Exception {
        // Initialize ReaderBasedJsonParser with '}'
        JsonFactory factory = new JsonFactory();
        StringReader reader = new StringReader("}");

        // Use reflection to access the ReaderBasedJsonParser constructor
        Constructor<ReaderBasedJsonParser> constructor = ReaderBasedJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, StringReader.class, ObjectCodec.class, CharsToNameCanonicalizer.class);
        constructor.setAccessible(true);

        // Create IOContext instance
        IOContext ioContext = new IOContext(factory._getBufferRecycler(), reader, false);

        // Instantiate ReaderBasedJsonParser
        ReaderBasedJsonParser parser = constructor.newInstance(ioContext, 0, reader, null, 
                CharsToNameCanonicalizer.createRoot());

        // Invoke nextToken() and expect an exception
        Exception exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        });

        // Assert that the exception message contains expected text
        String expectedMessage = "expected a value";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage), "Exception message should contain 'expected a value'");
    }

    @Test
    @DisplayName("nextToken() returns VALUE_TRUE when encountering 'true'")
    public void TC14_nextToken_ValueTrue() throws Exception {
        // Initialize ReaderBasedJsonParser with 'true'
        JsonFactory factory = new JsonFactory();
        StringReader reader = new StringReader("true");

        // Use reflection to access the ReaderBasedJsonParser constructor
        Constructor<ReaderBasedJsonParser> constructor = ReaderBasedJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, StringReader.class, ObjectCodec.class, CharsToNameCanonicalizer.class);
        constructor.setAccessible(true);

        // Create IOContext instance
        IOContext ioContext = new IOContext(factory._getBufferRecycler(), reader, false);

        // Instantiate ReaderBasedJsonParser
        ReaderBasedJsonParser parser = constructor.newInstance(ioContext, 0, reader, null, 
                CharsToNameCanonicalizer.createRoot());

        // Invoke nextToken()
        JsonToken result = parser.nextToken();

        // Assert that the result is VALUE_TRUE
        assertEquals(JsonToken.VALUE_TRUE, result, "The token should be VALUE_TRUE");
    }

    @Test
    @DisplayName("nextToken() returns VALUE_FALSE when encountering 'false'")
    public void TC15_nextToken_ValueFalse() throws Exception {
        // Initialize ReaderBasedJsonParser with 'false'
        JsonFactory factory = new JsonFactory();
        StringReader reader = new StringReader("false");

        // Use reflection to access the ReaderBasedJsonParser constructor
        Constructor<ReaderBasedJsonParser> constructor = ReaderBasedJsonParser.class.getDeclaredConstructor(
                IOContext.class, int.class, StringReader.class, ObjectCodec.class, CharsToNameCanonicalizer.class);
        constructor.setAccessible(true);

        // Create IOContext instance
        IOContext ioContext = new IOContext(factory._getBufferRecycler(), reader, false);

        // Instantiate ReaderBasedJsonParser
        ReaderBasedJsonParser parser = constructor.newInstance(ioContext, 0, reader, null, 
                CharsToNameCanonicalizer.createRoot());

        // Invoke nextToken()
        JsonToken result = parser.nextToken();

        // Assert that the result is VALUE_FALSE
        assertEquals(JsonToken.VALUE_FALSE, result, "The token should be VALUE_FALSE");
    }
}
