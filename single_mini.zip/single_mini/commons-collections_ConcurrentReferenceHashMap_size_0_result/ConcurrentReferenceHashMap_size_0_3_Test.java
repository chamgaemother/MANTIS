package org.apache.commons.collections4.map;

import java.util.*;
import java.lang.reflect.Field;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.concurrent.ConcurrentModificationException;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConcurrentReferenceHashMap_size_0_3_Test {

    @Test
    @DisplayName("size() handles segments with varying counts and modCounts inconsistent on all retries, resorts to locking")
    public void TC11_sizeHandlesInconsistentModCountsResortsToLocking() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        // Initialize the map with entries to create varying counts
        for (int i = 0; i < 10; i++) {
            map.put(new Object(), new Object());
        }

        // Access the private 'segments' field via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Manipulate segments to have inconsistent modCounts
        for (Object segment : segments) {
            Field modCountField = segment.getClass().getDeclaredField("modCount");
            modCountField.setAccessible(true);
            modCountField.setInt(segment, modCountField.getInt(segment) + 1);
        }

        // WHEN
        int result = map.size();

        // THEN
        int expectedSum = 10;
        assertEquals(expectedSum, result);
    }

    @Test
    @DisplayName("size() handles concurrent modifications during size computation but ultimately returns correct sum")
    public void TC12_sizeHandlesConcurrentModifications() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        for (int i = 0; i < 10; i++) {
            map.put(new Object(), new Object());
        }

        // Start a thread that modifies the map during size() execution
        Thread modifier = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                map.put(new Object(), new Object());
                map.remove(new Object());
            }
        });
        modifier.start();

        // WHEN
        int result = map.size();

        // Ensure the modifier thread has finished
        modifier.join();

        // THEN
        int expectedSumAtLocking = 10;
        assertEquals(expectedSumAtLocking, result);
    }

    @Test
    @DisplayName("size() returns correct count when segments have maximum possible counts without exceeding Integer.MAX_VALUE")
    public void TC13_sizeReturnsMaxValueWhenSumExceedsIntegerMax() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        // Access the private 'segments' field via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Manipulate each segment's count to sum up to Integer.MAX_VALUE
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            // Assign maximum possible count per segment
            countField.setInt(segment, Integer.MAX_VALUE / segments.length);
        }

        // WHEN
        int result = map.size();

        // THEN
        assertEquals(Integer.MAX_VALUE, result);
    }

    @Test
    @DisplayName("size() correctly handles segments with negative counts (if applicable)")
    public void TC14_sizeHandlesNegativeSegmentCounts() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().build();
        // Access the private 'segments' field via reflection
        Field segmentsField = ConcurrentReferenceHashMap.class.getDeclaredField("segments");
        segmentsField.setAccessible(true);
        Object[] segments = (Object[]) segmentsField.get(map);

        // Manipulate segments to have negative counts
        for (Object segment : segments) {
            Field countField = segment.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.setInt(segment, -5);
        }

        // WHEN
        int result = map.size();

        // THEN
        int expectedNegativeSum = -5 * segments.length;
        assertEquals(expectedNegativeSum, result);
    }

    @Test
    @DisplayName("size() handles exceptionally large number of segments efficiently")
    public void TC15_sizeHandlesLargeNumberOfSegments() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder().setInitialCapacity(1000).build();
        for (int i = 0; i < 10000; i++) {
            map.put(new Object(), new Object());
        }

        // WHEN
        int result = map.size();

        // THEN
        int expectedCount = 10000;
        assertEquals(expectedCount, result);
    }
}