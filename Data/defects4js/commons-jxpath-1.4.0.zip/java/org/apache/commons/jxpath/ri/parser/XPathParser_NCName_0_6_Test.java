package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class XPathParser_NCName_0_6_Test {

    @Test
    @DisplayName("NCName() processes kind FUNCTION_NORMALIZE_SPACE and returns token image")
    void TC26() throws Exception {
        // Instantiate the XPathParser with a dummy token manager
        XPathParserTokenManager tokenManager = new XPathParserTokenManager(null);
        XPathParser parser = new XPathParser(tokenManager);

        // Use reflection to set private field 'jj_nt.kind' to FUNCTION_NORMALIZE_SPACE
        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_NORMALIZE_SPACE);

        // Set 'token.image' to a sample string
        // Note: Fixed from previous incorrect access. We need to set 'token' field in Parser
        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        token.image = "normalizeSpaceImage";

        // Invoke NCName()
        String result = parser.NCName();

        // Assert the result
        assertEquals("normalizeSpaceImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_TRANSLATE and returns token image")
    void TC27() throws Exception {
        XPathParserTokenManager tokenManager = new XPathParserTokenManager(null);
        XPathParser parser = new XPathParser(tokenManager);

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_TRANSLATE);

        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        token.image = "translateImage";

        String result = parser.NCName();

        assertEquals("translateImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_BOOLEAN and returns token image")
    void TC28() throws Exception {
        XPathParserTokenManager tokenManager = new XPathParserTokenManager(null);
        XPathParser parser = new XPathParser(tokenManager);

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_BOOLEAN);

        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        token.image = "booleanImage";

        String result = parser.NCName();

        assertEquals("booleanImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_NOT and returns token image")
    void TC29() throws Exception {
        XPathParserTokenManager tokenManager = new XPathParserTokenManager(null);
        XPathParser parser = new XPathParser(tokenManager);

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_NOT);

        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        token.image = "notImage";

        String result = parser.NCName();

        assertEquals("notImage", result);
    }

    @Test
    @DisplayName("NCName() processes kind FUNCTION_TRUE and returns token image")
    void TC30() throws Exception {
        XPathParserTokenManager tokenManager = new XPathParserTokenManager(null);
        XPathParser parser = new XPathParser(tokenManager);

        Field jj_ntField = XPathParser.class.getDeclaredField("jj_nt");
        jj_ntField.setAccessible(true);
        Object jj_nt = jj_ntField.get(parser);

        Field kindField = jj_nt.getClass().getDeclaredField("kind");
        kindField.setAccessible(true);
        kindField.setInt(jj_nt, XPathParser.FUNCTION_TRUE);

        Field tokenField = XPathParser.class.getDeclaredField("token");
        tokenField.setAccessible(true);
        Token token = (Token) tokenField.get(parser);
        token.image = "trueImage";

        String result = parser.NCName();

        assertEquals("trueImage", result);
    }
}
