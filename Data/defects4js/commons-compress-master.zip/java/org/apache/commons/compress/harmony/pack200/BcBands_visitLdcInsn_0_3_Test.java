package org.apache.commons.compress.harmony.pack200;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class BcBands_visitLdcInsn_0_3_Test {

    private BcBands bcBands;
    private Segment mockSegment;

    @BeforeEach
    void setup() throws Exception {
        mockSegment = Mockito.mock(Segment.class);
        bcBands = new BcBands(Mockito.mock(CpBands.class), mockSegment, 0);
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is false and constant is CPClass")
    void TC11() throws Exception {
        CPClass cpClassConstant = Mockito.mock(CPClass.class);
        Mockito.when(mockSegment.lastConstantHadWideIndex()).thenReturn(false);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = new ArrayList<>();
        bcCodesField.set(bcBands, bcCodes);

        Field bcClassRefField = BcBands.class.getDeclaredField("bcClassRef");
        bcClassRefField.setAccessible(true);
        List<CPClass> bcClassRef = new ArrayList<>();
        bcClassRefField.set(bcBands, bcClassRef);

        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        bcBands.visitLdcInsn(cpClassConstant);

        assertEquals(2, byteCodeOffsetField.getInt(bcBands), "byteCodeOffset incremented by 2");
        assertTrue(bcCodes.contains(233), "bcCodes contains 233");
        assertTrue(bcClassRef.contains(cpClassConstant), "bcClassRef contains the CPClass constant");
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is false and constant is CPLong")
    void TC12() throws Exception {
        CPLong cpLongConstant = Mockito.mock(CPLong.class);
        Mockito.when(mockSegment.lastConstantHadWideIndex()).thenReturn(false);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = new ArrayList<>();
        bcCodesField.set(bcBands, bcCodes);

        Field bcLongRefField = BcBands.class.getDeclaredField("bcLongRef");
        bcLongRefField.setAccessible(true);
        List<CPLong> bcLongRef = new ArrayList<>();
        bcLongRefField.set(bcBands, bcLongRef);

        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        bcBands.visitLdcInsn(cpLongConstant);

        assertEquals(3, byteCodeOffsetField.getInt(bcBands), "byteCodeOffset incremented by 3");
        assertTrue(bcCodes.contains(20), "bcCodes contains 20");
        assertTrue(bcLongRef.contains(cpLongConstant), "bcLongRef contains the CPLong constant");
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is false and constant is CPDouble")
    void TC13() throws Exception {
        CPDouble cpDoubleConstant = Mockito.mock(CPDouble.class);
        Mockito.when(mockSegment.lastConstantHadWideIndex()).thenReturn(false);

        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        List<Integer> bcCodes = new ArrayList<>();
        bcCodesField.set(bcBands, bcCodes);

        Field bcDoubleRefField = BcBands.class.getDeclaredField("bcDoubleRef");
        bcDoubleRefField.setAccessible(true);
        List<CPDouble> bcDoubleRef = new ArrayList<>();
        bcDoubleRefField.set(bcBands, bcDoubleRef);

        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        bcBands.visitLdcInsn(cpDoubleConstant);

        assertEquals(3, byteCodeOffsetField.getInt(bcBands), "byteCodeOffset incremented by 3");
        assertTrue(bcCodes.contains(239), "bcCodes contains 239");
        assertTrue(bcDoubleRef.contains(cpDoubleConstant), "bcDoubleRef contains the CPDouble constant");
    }

    @Test
    @DisplayName("segment.lastConstantHadWideIndex() is false and constant is of unknown type, expecting IllegalArgumentException")
    void TC14() throws Exception {
        Object unknownConstant = new Object();
        Mockito.when(mockSegment.lastConstantHadWideIndex()).thenReturn(false);

        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            bcBands.visitLdcInsn(unknownConstant);
        }, "Expected visitLdcInsn to throw, but it didn't");

        assertEquals("Constant should not be null", exception.getMessage(), "Exception message should match");
    }
}