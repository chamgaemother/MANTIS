package org.jfree.chart.renderer.xy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.List;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClusteredXYBarRenderer_drawItem_0_6_Test {

//     @Test
//     @DisplayName("drawItem handles entity addition with multiple visible series")
//     public void testTC26_drawItem_withMultipleVisibleSeriesAndEntityAddition() {
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(dataset.getSeriesCount()).thenReturn(3);
//         when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
//         when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(2.0);
//         when(dataset.getStartYValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(dataset.getEndYValue(anyInt(), anyInt())).thenReturn(20.0);
// 
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
//         doReturn(true).when(renderer).isSeriesVisible(anyInt());
//         doReturn(false).when(renderer).getUseYInterval();
//         doReturn(0.5).when(renderer).getBase();
//         doReturn(0.1).when(renderer).getMargin();
//         doReturn(mock(XYItemLabelGenerator.class)).when(renderer).getItemLabelGenerator(anyInt(), anyInt());
//         doReturn(false).when(renderer).isItemLabelVisible(anyInt(), anyInt());
// 
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(() -> entityCollection);
// 
//         for (int series = 0; series < 3; series++) {
//             for (int item = 0; item < 5; item++) {
//                 renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, 1);
//             }
//         }
// 
//         ArgumentCaptor<Rectangle2D> barCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
//         verify(entityCollection, times(15)).addEntity(barCaptor.capture(), eq(dataset), anyInt(), anyInt(), anyDouble(), anyDouble());
// 
//         List<Rectangle2D> capturedBars = barCaptor.getAllValues();
//         assertEquals(15, capturedBars.size(), "Expected 15 entities to be added for 3 series and 5 items each.");
//     }

//     @Test
//     @DisplayName("drawItem handles single series with single item")
//     public void testTC27_drawItem_withSingleSeriesAndSingleItem() {
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 50, 50);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         IntervalXYDataset dataset = mock(IntervalXYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         when(dataset.getSeriesCount()).thenReturn(1);
//         when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(5.0);
//         when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(10.0);
//         when(dataset.getYValue(anyInt(), anyInt())).thenReturn(15.0);
// 
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer());
//         doReturn(true).when(renderer).isSeriesVisible(anyInt());
//         doReturn(false).when(renderer).getUseYInterval();
//         doReturn(0.0).when(renderer).getBase();
//         doReturn(0.2).when(renderer).getMargin();
//         doReturn(mock(XYItemLabelGenerator.class)).when(renderer).getItemLabelGenerator(anyInt(), anyInt());
//         doReturn(false).when(renderer).isItemLabelVisible(anyInt(), anyInt());
// 
//         EntityCollection entityCollection = mock(EntityCollection.class);
//         when(info.getOwner()).thenReturn(() -> entityCollection);
// 
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
// 
//         verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(0), eq(0), any(Rectangle2D.class), eq(RectangleEdge.BOTTOM));
//     }

}