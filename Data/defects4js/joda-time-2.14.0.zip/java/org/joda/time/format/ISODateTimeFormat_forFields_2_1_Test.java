package org.joda.time.format;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Collection;
import java.util.Arrays;
import java.util.HashSet;

public class ISODateTimeFormat_forFields_2_1_Test {

    @BeforeEach
    public void setup() {
        // No setup needed currently
    }

//     @Test
//     @DisplayName("forFields with year and hourOfDay fields, extended=true and strictISO=false, expecting 'yyyyTHH' format")
//     public void TC17() {
        // GIVEN
//         Collection<DateTimeFieldType> fields = new HashSet<>(Arrays.asList(DateTimeFieldType.year(), DateTimeFieldType.hourOfDay()));
//         boolean extended = true;
//         boolean strictISO = false;
// 
        // WHEN
//         DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
// 
        // THEN
//         assertEquals("yyyy'T'HH", formatter.toString(), "Formatter should represent 'yyyy'T'HH'");
//     }

//     @Test
//     @DisplayName("forFields with monthOfYear, dayOfMonth, hourOfDay, and minuteOfHour fields, extended=true and strictISO=false, expecting 'MM-ddTHH:mm' format")
//     public void TC18() {
        // GIVEN
//         Collection<DateTimeFieldType> fields = new HashSet<>(Arrays.asList(
//             DateTimeFieldType.monthOfYear(),
//             DateTimeFieldType.dayOfMonth(),
//             DateTimeFieldType.hourOfDay(),
//             DateTimeFieldType.minuteOfHour()
//         ));
//         boolean extended = true;
//         boolean strictISO = false; // corrected strictISO to false to align with the expected format
// 
        // WHEN
//         DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
// 
        // THEN
//         assertEquals("MM-dd'T'HH:mm", formatter.toString(), "Formatter should represent 'MM-dd'T'HH:mm'");
//     }

//     @Test
//     @DisplayName("forFields with year and incomplete time fields, extended=true and strictISO=true, expecting IllegalArgumentException")
//     public void TC19() {
        // GIVEN
//         Collection<DateTimeFieldType> fields = new HashSet<>(Arrays.asList(DateTimeFieldType.year(), DateTimeFieldType.hourOfDay()));
//         boolean extended = true;
//         boolean strictISO = true;
// 
        // WHEN & THEN
//         IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
//             ISODateTimeFormat.forFields(fields, extended, strictISO);
//         });
//         assertEquals("No valid ISO8601 format for fields because Date was reduced precision.", exception.getMessage()); // Ensure correct message comparison
//     }

//     @Test
//     @DisplayName("forFields with overlapping fields monthOfYear and dayOfWeek, extended=false and strictISO=false, expecting exception")
//     public void TC20() {
        // GIVEN
//         Collection<DateTimeFieldType> fields = new HashSet<>(Arrays.asList(DateTimeFieldType.monthOfYear(), DateTimeFieldType.dayOfWeek()));
//         boolean extended = false;
//         boolean strictISO = false;
// 
        // WHEN
//         IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
//             ISODateTimeFormat.forFields(fields, extended, strictISO);
//         });
//         assertTrue(exception.getMessage().contains("No valid format for fields"), "Exception expected due to overlapping fields");
//     }
}