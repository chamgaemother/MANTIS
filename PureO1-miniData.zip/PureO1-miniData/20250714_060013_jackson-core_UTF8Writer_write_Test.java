import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.io.UTF8Writer;

class UTF8WriterTest {

    private UTF8Writer utf8Writer;
    private ByteArrayOutputStream outputStream;
    private MockIOContext ioContext;

    @BeforeEach
    void setUp() {
        outputStream = new ByteArrayOutputStream();
        ioContext = new MockIOContext();
        utf8Writer = new UTF8Writer(ioContext, outputStream);
    }

    @Test
    void write_NullString_ThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> utf8Writer.write(null, 0, 0));
    }

    @Test
    void write_EmptyString_NoAction() throws IOException {
        utf8Writer.write("", 0, 0);
        utf8Writer.flush();
        assertEquals(0, outputStream.size());
    }

    @Test
    void write_SingleAsciiChar() throws IOException {
        utf8Writer.write("A", 0, 1);
        utf8Writer.flush();
        assertArrayEquals(new byte[]{65}, outputStream.toByteArray());
    }

    @Test
    void write_SingleNonAsciiChar() throws IOException {
        utf8Writer.write("\u00A2", 0, 1); // ¢
        utf8Writer.flush();
        assertArrayEquals(new byte[]{(byte) 0xC2, (byte) 0xA2}, outputStream.toByteArray());
    }

    @Test
    void write_MultipleAsciiChars() throws IOException {
        utf8Writer.write("Hello, World!", 0, 13);
        utf8Writer.flush();
        assertArrayEquals("Hello, World!".getBytes("UTF-8"), outputStream.toByteArray());
    }

    @Test
    void write_MixedAsciiAndNonAsciiChars() throws IOException {
        utf8Writer.write("Hello, \u00A2 World!", 0, 14);
        utf8Writer.flush();
        byte[] expected = "Hello, ".getBytes("UTF-8");
        byte[] cent = {(byte) 0xC2, (byte) 0xA2};
        byte[] world = " World!".getBytes("UTF-8");
        byte[] result = new byte[expected.length + cent.length + world.length];
        System.arraycopy(expected, 0, result, 0, expected.length);
        System.arraycopy(cent, 0, result, expected.length, cent.length);
        System.arraycopy(world, 0, result, expected.length + cent.length, world.length);
        assertArrayEquals(result, outputStream.toByteArray());
    }

    @Test
    void write_ValidSurrogatePair() throws IOException {
        String str = "\uD83D\uDE00"; // 😀 U+1F600
        utf8Writer.write(str, 0, 2);
        utf8Writer.flush();
        byte[] expected = {(byte) 0xF0, (byte) 0x9F, (byte) 0x98, (byte) 0x80};
        assertArrayEquals(expected, outputStream.toByteArray());
    }

    @Test
    void write_UnmatchedLeadSurrogate_ThrowsIOExceptionOnClose() throws IOException {
        String str = "\uD83D";
        utf8Writer.write(str, 0, 1);
        IOException exception = assertThrows(IOException.class, () -> utf8Writer.close());
        assertTrue(exception.getMessage().contains("Unmatched first part of surrogate pair"));
    }

    @Test
    void write_UnmatchedTrailSurrogate_ThrowsIOException() throws IOException {
        String str = "\uDE00";
        IOException exception = assertThrows(IOException.class, () -> utf8Writer.write(str, 0, 1));
        assertTrue(exception.getMessage().contains("Unmatched second part of surrogate pair"));
    }

    @Test
    void write_InvalidSurrogatePair_ThrowsIOException() throws IOException {
        String str = "\uD83D\u0041"; // Invalid second part
        IOException exception = assertThrows(IOException.class, () -> utf8Writer.write(str, 0, 2));
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    @Test
    void write_CharactersAtBoundaryValues() throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append((char)0x7F); // Boundary ASCII
        sb.append((char)0x80); // Start of 2-byte
        sb.append((char)0x7FF); // End of 2-byte
        sb.append((char)0x800); // Start of 3-byte
        sb.append((char)0xFFFF); // End of 3-byte
        // Surrogate pair for 0x10000
        sb.append("\uD800\uDC00");
        // Surrogate pair for 0x10FFFF
        sb.append("\uDBFF\uDFFF");
        utf8Writer.write(sb.toString(), 0, sb.length());
        utf8Writer.flush();

        byte[] expected = new byte[]{
            0x7F,
            (byte)0xC2, (byte)0x80,
            (byte)0xDF, (byte)0xBF,
            (byte)0xE0, (byte)0xA0, (byte)0x80,
            (byte)0xEF, (byte)0xBF, (byte)0xBF,
            (byte)0xF0, (byte)0x90, (byte)0x80, (byte)0x80,
            (byte)0xF4, (byte)0x8F, (byte)0xBF, (byte)0xBF
        };
        assertArrayEquals(expected, outputStream.toByteArray());
    }

    @Test
    void write_InvalidCodePointAboveMax_ThrowsIOException() throws IOException {
        // Surrogate pair that results in code point > 0x10FFFF
        String str = "\uDBFF\uDFFF"; // This is actually the max valid surrogate pair (0x10FFFF)
        // To create an invalid one, add one to the code point
        // However, since Java chars are limited, we simulate by manipulating the surrogate
        String invalidStr = "\uDBFF\uE000"; // Invalid second surrogate
        IOException exception = assertThrows(IOException.class, () -> utf8Writer.write(invalidStr, 0, 2));
        assertTrue(exception.getMessage().contains("Broken surrogate pair"));
    }

    // Mock IOContext for testing purposes
    private static class MockIOContext extends IOContext {

        private byte[] buffer;

        protected MockIOContext() {
            super(null, null, false, null);
        }

        @Override
        public byte[] allocWriteEncodingBuffer() {
            buffer = new byte[1024];
            return buffer;
        }

        @Override
        public void releaseWriteEncodingBuffer(byte[] buffer) {
            // No action needed for mock
        }

        @Override
        public void close() {
            // No action needed for mock
        }

        @Override
        public Object getSourceRef() {
            return null;
        }

        @Override
        public boolean isResourceManaged() {
            return false;
        }

        @Override
        public boolean isResourceIOC() {
            return false;
        }

        @Override
        public void setEncoding(String enc) {
            // No action needed for mock
        }

        @Override
        public String getEncoding() {
            return "UTF-8";
        }
    }
}