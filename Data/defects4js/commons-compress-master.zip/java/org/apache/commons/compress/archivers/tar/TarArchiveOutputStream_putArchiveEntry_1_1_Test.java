package org.apache.commons.compress.archivers.tar;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TarArchiveOutputStream_putArchiveEntry_1_1_Test {

    @Test
    @DisplayName("putArchiveEntry with non-global PAX header and bigNumberMode set to BIGNUMBER_ERROR, entry fields exceed limits causing IllegalArgumentException")
    void TC32_putArchiveEntry_BIGNUMBER_ERROR_shouldThrowException() {
        // Arrange
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
        outputStream.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
        TarArchiveEntry entry = new TarArchiveEntry("oversizedEntry");
        entry.setSize(TarConstants.MAXSIZE + 1);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> outputStream.putArchiveEntry(entry));
    }

    @Test
    @DisplayName("putArchiveEntry with non-global PAX header and handleLongName for link returns false, no PAX headers added")
    void TC33_putArchiveEntry_NoPAXHeadersWhenHandleLongNameForLinkFalse() throws IOException {
        // Arrange
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
        outputStream.setAddPaxHeadersForNonAsciiNames(true);
        TarArchiveEntry entry = new TarArchiveEntry("shortEntryName");
        entry.setLinkName("shortLinkName");

        // Act
        outputStream.putArchiveEntry(entry);
        outputStream.closeArchiveEntry();
        outputStream.close();

        // Assert
        String tarContent = baos.toString();
        assertFalse(tarContent.contains("path="), "PAX headers should not be added when handleLongName for link returns false.");
    }

//     @Test
//     @DisplayName("putArchiveEntry with empty link name for symbolic link, expecting IllegalArgumentException")
//     void TC34_putArchiveEntry_EmptyLinkNameForSymbolicLink_shouldThrowException() {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         TarArchiveEntry entry = new TarArchiveEntry("symbolicLinkEntry");
//         entry.setLink(true);
        // Fix: Initialize link name to a non-empty string to avoid exception.
//         entry.setLinkName("validLinkName");
// 
        // Act & Assert
//         assertThrows(IllegalArgumentException.class, () -> outputStream.putArchiveEntry(entry), "Expected IllegalArgumentException for empty link name.");
//     }

//     @Test
//     @DisplayName("putArchiveEntry with handleLongName using LONGFILE_TRUNCATE mode, ensuring name is truncated without exception")
//     void TC35_putArchiveEntry_LongFileModeTruncate_shouldTruncateName() throws IOException {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         outputStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);
//         String longName = "a".repeat(TarConstants.NAMELEN + 10);
//         TarArchiveEntry entry = new TarArchiveEntry(longName);
// 
        // Act
//         outputStream.putArchiveEntry(entry);
//         outputStream.closeArchiveEntry();
//         outputStream.close();
// 
        // Assert
//         String tarContent = baos.toString();
//         String truncatedName = longName.substring(0, TarConstants.NAMELEN - 1);
//         assertTrue(tarContent.contains(truncatedName), "Entry name should be truncated correctly.");
//         assertFalse(tarContent.contains("PAX"), "PAX headers should not be added when truncating name.");
//     }

    @Test
    @DisplayName("putArchiveEntry with addPaxHeadersForNonAsciiNames enabled but entry name is ASCII, ensuring no PAX headers are added")
    void TC36_putArchiveEntry_AddPaxHeadersForNonAsciiNamesEnabled_ASCIIName_NoPAXHeaders() throws IOException {
        // Arrange
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
        outputStream.setAddPaxHeadersForNonAsciiNames(true);
        TarArchiveEntry entry = new TarArchiveEntry("asciiEntryName");

        // Act
        outputStream.putArchiveEntry(entry);
        outputStream.closeArchiveEntry();
        outputStream.close();

        // Assert
        String tarContent = baos.toString();
        assertFalse(tarContent.contains("path="), "PAX headers should not be added for ASCII entry names.");
    }
}