package org.apache.commons.compress.archivers.cpio;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;

import org.apache.commons.compress.utils.ArchiveUtils;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CpioArchiveInputStream_getNextCPIOEntry_0_2_Test {

    @Test
    @DisplayName("Read New CRC Format Entry, magic string matches MAGIC_NEW_CRC")
    void testReadNewCRCFormatEntry() throws IOException {
        // Given
        byte[] data = ArchiveUtils.fromAsciiString("0707020000000000000000000000000000000000000000000000000");
        InputStream inputStream = new ByteArrayInputStream(data);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(inputStream);

        // When
        CpioArchiveEntry entry = stream.getNextCPIOEntry();

        // Then
        assertNotNull(entry, "Entry should not be null");
        assertEquals(CpioArchiveEntry.FORMAT_NEW_CRC, entry.getFormat(), "Entry format should be FORMAT_NEW_CRC");
    }

    @Test
    @DisplayName("Read Old ASCII entry, magic string matches MAGIC_OLD_ASCII")
    void testReadOldASCIIEntry() throws IOException {
        // Given
        byte[] data = ArchiveUtils.fromAsciiString("070707000000000000000000000000000000000000000000000000");
        InputStream inputStream = new ByteArrayInputStream(data);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(inputStream);

        // When
        CpioArchiveEntry entry = stream.getNextCPIOEntry();

        // Then
        assertNotNull(entry, "Entry should not be null");
        assertEquals(CpioArchiveEntry.FORMAT_OLD_ASCII, entry.getFormat(), "Entry format should be FORMAT_OLD_ASCII");
    }

    @Test
    @DisplayName("Unknown magic string, throws IOException for unrecognized format")
    void testUnknownMagicThrowsIOException() {
        // Given
        byte[] data = ArchiveUtils.fromAsciiString("XXXXXX");
        InputStream inputStream = new ByteArrayInputStream(data);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(inputStream);

        // When & Then
        IOException exception = assertThrows(IOException.class, stream::getNextCPIOEntry);
        assertTrue(exception.getMessage().contains("Unknown magic"), "Exception message should contain 'Unknown magic'");
    }

    @Test
    @DisplayName("Encounter TRAILER!!! entry, triggers end-of-file processing")
    void testTrailerEntryTriggersEOFProcessing() throws IOException, NoSuchFieldException, IllegalAccessException {
        // Given
        byte[] data = ArchiveUtils.fromAsciiString("0707010000000000000000000000000000000000000000000000000");
        InputStream inputStream = new ByteArrayInputStream(data);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(inputStream);
        CpioArchiveEntry fakeEntry = new CpioArchiveEntry();
        fakeEntry.setName("TRAILER!!!");

        // Using reflection to set the private field 'entry' to simulate this scenario
        Field entryField = CpioArchiveInputStream.class.getDeclaredField("entry");
        entryField.setAccessible(true);
        entryField.set(stream, fakeEntry);

        // When
        CpioArchiveEntry entry = stream.getNextCPIOEntry();

        // Then
        assertNull(entry, "Entry should be null as TRAILER!!! was encountered");
        // Check if entryEOF is set to true after reaching TRAILER!!!
        Field entryEOFField = CpioArchiveInputStream.class.getDeclaredField("entryEOF");
        entryEOFField.setAccessible(true);
        assertTrue((boolean) entryEOFField.get(stream), "entryEOF should be true");
    }

    @Test
    @DisplayName("Read fully but not enough bytes available, triggers IOException")
    void testIncompleteReadTriggersEOFException() {
        // Given
        byte[] data = ArchiveUtils.fromAsciiString("070701");
        InputStream inputStream = new ByteArrayInputStream(data);
        CpioArchiveInputStream stream = new CpioArchiveInputStream(inputStream);

        // When & Then
        IOException exception = assertThrows(IOException.class, stream::getNextCPIOEntry);
        assertTrue(exception.getMessage().contains("EOF"), "An IOException should be thrown due to insufficient data");
    }
}
