package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;

public class IntList_add_0_1_Test {

    @Test
    @DisplayName("Add to middle of the list when internal array is full, causing growth and insertion at index 1")
    void testAddMiddleGrow() throws Exception {
        IntList intList = new IntList();
        // Assume that `array` and `firstIndex`, `lastIndex` are package-private or accessed via reflection
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);

        // Setup precondition: List is full
        int[] array = new int[10]; // Assuming an array of size 10
        for (int i = 0; i < 10; i++) {
            array[i] = i;
        }
        arrayField.set(intList, array);
        firstIndexField.setInt(intList, 0);
        lastIndexField.setInt(intList, 10);

        intList.add(1, 99); // Add at middle causing growth

        // Post-condition
        Object[] newArray = (Object[]) arrayField.get(intList);
        assertEquals(99, newArray[1], "Element should be inserted at index 1");
    }

    @Test
    @DisplayName("Add element at index 0 when firstIndex is 0, causing growth at front")
    void testAddFrontGrow() throws Exception {
        IntList intList = new IntList();
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);

        // Setup precondition: Array is not full, firstIndex is 0
        int[] array = {5, 6, 7, 0, 0};
        arrayField.set(intList, array);
        firstIndexField.setInt(intList, 0);
        lastIndexField.setInt(intList, 3);

        intList.add(0, 4); // Add at index 0, causing growth at front

        // Post-condition
        int[] newArray = (int[]) arrayField.get(intList);
        assertEquals(4, newArray[0], "Element should be added at the front");
    }

    @Test
    @DisplayName("Add element at list size index, expanding the list at the end")
    void testAddEndGrow() throws Exception {
        IntList intList = new IntList();
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);

        // Setup precondition: Array is full
        int[] array = {1, 2, 3};
        arrayField.set(intList, array);
        firstIndexField.setInt(intList, 0);
        lastIndexField.setInt(intList, 3);

        intList.add(3, 4); // Add at end, causing growth

        // Post-condition
        int[] newArray = (int[]) arrayField.get(intList);
        assertEquals(4, newArray[3], "Element should be added at the end");
    }

    @Test
    @DisplayName("Add an element when firstIndex and lastIndex fit in current array without growth")
    void testAddNoGrowth() throws Exception {
        IntList intList = new IntList();
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        firstIndexField.setAccessible(true);
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        lastIndexField.setAccessible(true);

        // Setup precondition: Enough space available in array
        int[] array = {0, 1, 2, 0, 0};
        arrayField.set(intList, array);
        firstIndexField.setInt(intList, 0);
        lastIndexField.setInt(intList, 3);

        intList.add(1, 4); // Add at index 1, no growth needed

        // Post-condition
        int[] newArray = (int[]) arrayField.get(intList);
        assertEquals(4, newArray[1], "Element should be inserted correctly");
    }

    @Test
    @DisplayName("Throw exception for negative location index")
    void testAddNegativeIndex() {
        IntList intList = new IntList();

        assertThrows(IndexOutOfBoundsException.class, () -> {
            intList.add(-1, 99);
        }, "IndexOutOfBoundsException should be thrown for negative index");
    }
}