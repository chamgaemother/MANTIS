import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.CandlestickRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.data.xy.OHLCDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class CandlestickRendererTest {

    private CandlestickRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private OHLCDataset dataset;
    private CrosshairState crosshairState;
    private int series;
    private int item;
    private EntityCollection entities;

    @BeforeEach
    void setUp() {
        renderer = new CandlestickRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(OHLCDataset.class);
        crosshairState = mock(CrosshairState.class);
        series = 0;
        item = 0;
        entities = mock(EntityCollection.class);

        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
    }

    @Test
    void testDrawItemVerticalOrientationPositiveCandleWidthDrawVolumeTrue() {
        renderer.setOrientation(PlotOrientation.VERTICAL);
        renderer.setCandleWidth(10.0);
        renderer.setDrawVolume(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);
        when(dataset.getVolumeValue(series, item)).thenReturn(100.0);

        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(renderer.getVolumePaint());
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(renderer.getItemPaint(series, item));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
        verify(entities).add(any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
    }

    @Test
    void testDrawItemHorizontalOrientationAutoWidthMethodAverage() {
        renderer.setOrientation(PlotOrientation.HORIZONTAL);
        renderer.setCandleWidth(-1.0);
        renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_AVERAGE);
        renderer.setAutoWidthFactor(0.5);
        when(dataset.getItemCount(series)).thenReturn(10);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);

        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);
        when(dataArea.getHeight()).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(renderer.getItemPaint(series, item));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemInvalidOrientation() {
        renderer.setOrientation(null);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItemUseOutlinePaintTrue() {
        renderer.setUseOutlinePaint(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);
        when(renderer.getItemOutlinePaint(series, item)).thenReturn(Paint.BLACK);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(Paint.BLACK);
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemUseOutlinePaintFalse() {
        renderer.setUseOutlinePaint(false);
        renderer.setUpPaint(Paint.GREEN);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(Paint.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(renderer.getItemPaint(series, item));
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemYCloseGreaterThanYOpen() {
        renderer.setUseOutlinePaint(false);
        renderer.setUpPaint(Paint.GREEN);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(Paint.GREEN);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemYCloseLessThanYOpen() {
        renderer.setUseOutlinePaint(false);
        renderer.setDownPaint(Paint.RED);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(4.0);
        when(dataset.getCloseValue(series, item)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(180.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(Paint.RED);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemYCloseEqualsYOpen() {
        renderer.setUseOutlinePaint(false);
        renderer.setDownPaint(Paint.RED);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(3.0);
        when(dataset.getCloseValue(series, item)).thenReturn(3.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(Paint.RED);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemDrawVolumeFalse() {
        renderer.setDrawVolume(false);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2, never()).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemVolumeZero() {
        renderer.setDrawVolume(true);
        when(dataset.getVolumeValue(series, item)).thenReturn(0.0);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);
        when(dataArea.getMinY()).thenReturn(0.0);
        when(dataArea.getMaxY()).thenReturn(300.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(renderer.getItemPaint(series, item));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
        verify(entities).add(any(), eq(dataset), eq(series), eq(item), eq(0.0), eq(0.0));
    }

    @Test
    void testDrawItemEntityCollectionNull() {
        when(info.getOwner().getEntityCollection()).thenReturn(null);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(entities, never()).add(any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble());
    }

    @Test
    void testDrawItemWidthMethodSmallest() {
        renderer.setCandleWidth(-1.0);
        renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_SMALLEST);
        renderer.setAutoWidthFactor(0.5);
        when(dataset.getItemCount(series)).thenReturn(5);
        for (int i = 0; i < 5; i++) {
            when(dataset.getXValue(series, i)).thenReturn((double) i);
        }
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(org.jfree.chart.ui.RectangleEdge.BOTTOM)))
                .thenReturn(50.0, 100.0, 150.0, 200.0, 250.0);
        when(dataArea.getWidth()).thenReturn(300.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, 2, crosshairState, 0);

        verify(g2).setPaint(renderer.getItemPaint(series, 2));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemWidthMethodIntervalData() {
        renderer.setCandleWidth(-1.0);
        renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_INTERVALDATA);
        renderer.setAutoWidthFactor(0.5);
        when(dataset.getXValue(series, item)).thenReturn(2.0);
        when(((OHLCDataset) dataset).getStartXValue(series, item)).thenReturn(1.0);
        when(((OHLCDataset) dataset).getEndXValue(series, item)).thenReturn(3.0);
        when(((OHLCDataset) dataset).getHighValue(series, item)).thenReturn(5.0);
        when(((OHLCDataset) dataset).getLowValue(series, item)).thenReturn(1.0);
        when(((OHLCDataset) dataset).getOpenValue(series, item)).thenReturn(2.0);
        when(((OHLCDataset) dataset).getCloseValue(series, item)).thenReturn(4.0);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(domainAxis.valueToJava2D(3.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(250.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(renderer.getItemPaint(series, item));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemMaxCandleWidthExceeded() {
        renderer.setCandleWidth(-1.0);
        renderer.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_AVERAGE);
        renderer.setAutoWidthFactor(1.0);
        renderer.setMaxCandleWidthInMilliseconds(1000.0);
        when(dataset.getItemCount(series)).thenReturn(1);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(org.jfree.chart.ui.RectangleEdge.BOTTOM)))
                .thenReturn(0.0, 1000.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(org.jfree.chart.ui.RectangleEdge.LEFT)))
                .thenReturn(100.0, 200.0, 300.0, 400.0, 500.0);
        when(dataArea.getWidth()).thenReturn(500.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, 0, crosshairState, 0);

        // Candle width should not exceed maxCandleWidth
        verify(g2).setPaint(renderer.getItemPaint(series, 0));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemNullVolumePaint() {
        renderer.setDrawVolume(true);
        renderer.setVolumePaint(null);
        when(dataset.getVolumeValue(series, item)).thenReturn(100.0);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);
        when(renderer.getVolumePaint()).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(null);
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemMaxVolumeCalculation() {
        renderer.setDrawVolume(true);
        when(dataset.getSeriesCount()).thenReturn(2);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getItemCount(1)).thenReturn(2);
        when(dataset.getVolumeValue(0, 0)).thenReturn(100.0);
        when(dataset.getVolumeValue(0, 1)).thenReturn(200.0);
        when(dataset.getVolumeValue(1, 0)).thenReturn(150.0);
        when(dataset.getVolumeValue(1, 1)).thenReturn(250.0);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getHighValue(anyInt(), anyInt())).thenReturn(5.0);
        when(dataset.getLowValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getOpenValue(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getCloseValue(anyInt(), anyInt())).thenReturn(4.0);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(org.jfree.chart.ui.RectangleEdge.BOTTOM)))
                .thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(org.jfree.chart.ui.RectangleEdge.LEFT)))
                .thenReturn(100.0, 200.0, 150.0, 250.0, 120.0, 220.0);
        when(dataArea.getMinY()).thenReturn(0.0);
        when(dataArea.getMaxY()).thenReturn(300.0);
        renderer.initialise(g2, dataArea, plot, dataset, info);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 1, 1, crosshairState, 0);

        verify(g2).setPaint(renderer.getVolumePaint());
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemNullDataset() {
        renderer.setDrawVolume(true);
        renderer.setOrientation(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                null, series, item, crosshairState, 0);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItemNegativeVolume() {
        renderer.setDrawVolume(true);
        when(dataset.getVolumeValue(series, item)).thenReturn(-100.0);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getRangeAxis()).thenReturn(rangeAxis);
        when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(4.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(120.0);
        when(dataArea.getMinY()).thenReturn(0.0);
        when(dataArea.getMaxY()).thenReturn(300.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);

        verify(g2).setPaint(renderer.getVolumePaint());
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemNullGraphics() {
        renderer.setDrawVolume(true);
        renderer.setOrientation(PlotOrientation.VERTICAL);
        renderer.drawItem(null, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);
        // Expect no exceptions
    }

    @Test
    void testDrawItemNullPlot() {
        renderer.setDrawVolume(true);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getHighValue(series, item)).thenReturn(5.0);
        when(dataset.getLowValue(series, item)).thenReturn(1.0);
        when(dataset.getOpenValue(series, item)).thenReturn(2.0);
        when(dataset.getCloseValue(series, item)).thenReturn(4.0);

        renderer.drawItem(g2, state, dataArea, info, null, domainAxis, rangeAxis,
                dataset, series, item, crosshairState, 0);
        verifyNoInteractions(g2);
    }
}