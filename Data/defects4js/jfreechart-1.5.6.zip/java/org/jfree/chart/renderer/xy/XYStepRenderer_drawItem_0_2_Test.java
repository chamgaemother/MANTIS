package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.entity.EntityCollection;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Method;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

/**
 * Test class for XYStepRenderer's drawItem method.
 */
public class XYStepRenderer_drawItem_0_2_Test {

    /**
     * Helper method to invoke the drawItem method via reflection.
     */
    private void invokeDrawItem(XYStepRenderer renderer, Graphics2D g2, XYItemRendererState state,
                                Rectangle2D dataArea, PlotRenderingInfo info, XYPlot plot,
                                ValueAxis domainAxis, ValueAxis rangeAxis, XYDataset dataset,
                                int series, int item, CrosshairState crosshairState, int pass) throws Exception {
        Method drawItemMethod = XYStepRenderer.class.getDeclaredMethod(
                "drawItem", Graphics2D.class, XYItemRendererState.class, Rectangle2D.class,
                PlotRenderingInfo.class, XYPlot.class, ValueAxis.class, ValueAxis.class,
                XYDataset.class, int.class, int.class, CrosshairState.class, int.class);
        drawItemMethod.setAccessible(true);
        drawItemMethod.invoke(renderer, g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                              dataset, series, item, crosshairState, pass);
    }

    @Test
    @DisplayName("Visible item with pass=0, item <= 0")
    public void TC06_drawItem_VisiblePass0_ItemLE0() throws Exception {
        // Arrange
        XYStepRenderer renderer = new XYStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 0;
        int item = 0;
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);
        when(plot.getDomainAxisEdge()).thenReturn(null);
        when(plot.getRangeAxisEdge()).thenReturn(null);

        // Act
        invokeDrawItem(renderer, g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                      dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that updateCrosshairValues was called without drawing lines
        verify(renderer, times(1)).updateCrosshairValues(crosshairState, 1.0, 2.0, series, 0.0, 0.0, PlotOrientation.VERTICAL);
        // Verify no lines were drawn
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    @DisplayName("Visible item with pass=1 and item label is visible")
    public void TC07_drawItem_VisiblePass1_LabelVisible() throws Exception {
        // Arrange
        XYStepRenderer renderer = new XYStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 1;
        int item = 1;
        int pass = 1;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(dataset.getXValue(series, item)).thenReturn(3.0);
        when(dataset.getYValue(series, item)).thenReturn(4.0);
        when(plot.getDomainAxisEdge()).thenReturn(null);
        when(plot.getRangeAxisEdge()).thenReturn(null);
        when(renderer.isItemLabelVisible(series, item)).thenReturn(true);

        // Act
        invokeDrawItem(renderer, g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                      dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that drawItemLabel was called
        verify(renderer, times(1)).drawItemLabel(g2, PlotOrientation.HORIZONTAL, dataset, series, item, 0.0, 0.0, false);
    }

    @Test
    @DisplayName("Visible item with pass=1 and item label is not visible")
    public void TC08_drawItem_VisiblePass1_LabelNotVisible() throws Exception {
        // Arrange
        XYStepRenderer renderer = new XYStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 2;
        int item = 2;
        int pass = 1;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(dataset.getXValue(series, item)).thenReturn(5.0);
        when(dataset.getYValue(series, item)).thenReturn(6.0);
        when(plot.getDomainAxisEdge()).thenReturn(null);
        when(plot.getRangeAxisEdge()).thenReturn(null);
        when(renderer.isItemLabelVisible(series, item)).thenReturn(false);

        // Act
        invokeDrawItem(renderer, g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                      dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that drawItemLabel was not called
        verify(renderer, never()).drawItemLabel(any(Graphics2D.class), any(PlotOrientation.class),
                                               any(XYDataset.class), anyInt(), anyInt(),
                                               anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("Item is visible, pass=0, item > 0, Y1 is NaN")
    public void TC09_drawItem_VisiblePass0_ItemGT0_Y1NaN() throws Exception {
        // Arrange
        XYStepRenderer renderer = spy(new XYStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        
        int series = 3;
        int item = 1;
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(dataset.getXValue(series, item)).thenReturn(7.0);
        when(dataset.getYValue(series, item)).thenReturn(Double.NaN);
        when(plot.getDomainAxisEdge()).thenReturn(null);
        when(plot.getRangeAxisEdge()).thenReturn(null);

        // Act
        invokeDrawItem(renderer, g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                      dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that no lines were drawn due to NaN Y1
        verify(g2, never()).draw(any(Line2D.class));
        // Verify that crosshair values were updated
        verify(renderer, times(1)).updateCrosshairValues(crosshairState, 7.0, Double.NaN, series, 0.0, 0.0, PlotOrientation.VERTICAL);
    }

    @Test
    @DisplayName("Visible item with non-null entity collection and pass=0")
    public void TC10_drawItem_VisibleNonNullEntityPass0() throws Exception {
        // Arrange
        XYStepRenderer renderer = spy(new XYStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        EntityCollection entities = mock(EntityCollection.class);
        
        int series = 4;
        int item = 3;
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(renderer.getItemPaint(series, item)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(series, item)).thenReturn(mock(Stroke.class));
        when(dataset.getXValue(series, item)).thenReturn(9.0);
        when(dataset.getYValue(series, item)).thenReturn(10.0);
        when(plot.getDomainAxisEdge()).thenReturn(null);
        when(plot.getRangeAxisEdge()).thenReturn(null);
        when(state.getEntityCollection()).thenReturn(entities);

        // Act
        invokeDrawItem(renderer, g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                      dataset, series, item, crosshairState, pass);

        // Assert
        // Verify that addEntity was called correctly
        verify(renderer, times(1)).addEntity(entities, null, dataset, series, item, 0.0, 0.0);
    }
}