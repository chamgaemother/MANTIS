// package org.jfree.chart.renderer.category;
// 
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// 
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// import java.lang.reflect.Field;
// 
// import org.jfree.chart.axis.CategoryAxis;
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.plot.CategoryPlot;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.ui.RectangleEdge;
// import org.jfree.data.KeyToGroupMap;
// import org.jfree.data.category.CategoryDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// public class StackedBarRenderer_drawItem_0_1_Test {
// 
//     @Test
//     @DisplayName("Early exit when dataset.getValue(row, column) is null")
//     void TC01_drawItem_nullValue_EarlyExit() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         int row = 0;
//         int column = 0;
//         int pass = 0;
// 
//         when(dataset.getValue(row, column)).thenReturn(null);
// 
//         StackedBarRenderer renderer = new StackedBarRenderer();
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
//         // Assert
//         verify(g2, never()).draw(any());
//     }
// 
// //     @Test
// //     @DisplayName("Draw item with positive value in HORIZONTAL orientation without inversion")
// //     void TC02_drawItem_positiveHorizontal_noInversion() throws Exception {
//         // Arrange
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = mock(Rectangle2D.class);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 0;
// //         int column = 0;
// //         int pass = 1;
// // 
// //         when(dataset.getValue(row, column)).thenReturn(10);
// //         when(dataset.getRowKey(row)).thenReturn("Series1");
// // 
//         // Setup seriesToGroupMap via reflection
// //         StackedBarRenderer renderer = new StackedBarRenderer();
// //         setSeriesToGroupMap(renderer, "Series1", "Group1");
// // 
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
// //         when(rangeAxis.isInverted()).thenReturn(false);
// //         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
// // 
//         // Act
// //         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// // 
//         // Assert
// //         verify(g2, atLeastOnce()).draw(any());
// //     }
// 
// //     @Test
// //     @DisplayName("Draw item with negative value in VERTICAL orientation with inversion")
// //     void TC03_drawItem_negativeVertical_inversion() throws Exception {
//         // Arrange
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = mock(Rectangle2D.class);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 1;
// //         int column = 0;
// //         int pass = 1;
// // 
// //         when(dataset.getValue(row, column)).thenReturn(-5);
// //         when(dataset.getRowKey(row)).thenReturn("Series2");
// // 
//         // Setup seriesToGroupMap via reflection
// //         StackedBarRenderer renderer = new StackedBarRenderer();
// //         setSeriesToGroupMap(renderer, "Series2", "Group2");
// // 
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// //         when(rangeAxis.isInverted()).thenReturn(true);
// //         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
// // 
//         // Act
// //         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// // 
//         // Assert
// //         verify(g2, atLeastOnce()).draw(any());
// //     }
// 
//     @Test
//     @DisplayName("Draw item with zero value, ensuring minimum bar length is applied")
//     void TC04_drawItem_zeroValue_minimumLength() throws Exception {
//         // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         int row = 2;
//         int column = 0;
//         int pass = 1;
// 
//         when(dataset.getValue(row, column)).thenReturn(0);
//         when(dataset.getRowKey(row)).thenReturn("Series3");
// 
//         // Setup seriesToGroupMap via reflection
//         StackedBarRenderer renderer = new StackedBarRenderer();
//         setSeriesToGroupMap(renderer, "Series3", "Group3");
// 
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.TOP);
// 
//         // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
//         // Assert
//         verify(g2, atLeastOnce()).draw(any());
//     }
// 
// //     @Test
// //     @DisplayName("Draw item when series group has multiple positive and negative contributions")
// //     void TC05_drawItem_multiplePositiveNegative_contributions() throws Exception {
//         // Arrange
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
// //         Rectangle2D dataArea = mock(Rectangle2D.class);
// //         CategoryPlot plot = mock(CategoryPlot.class);
// //         CategoryAxis domainAxis = mock(CategoryAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         CategoryDataset dataset = mock(CategoryDataset.class);
// //         int row = 3;
// //         int column = 0;
// //         int pass = 1;
// // 
// //         when(dataset.getValue(row, column)).thenReturn(15);
// //         when(dataset.getRowKey(row)).thenReturn("Series4");
// // 
//         // Setup seriesToGroupMap via reflection
// //         StackedBarRenderer renderer = new StackedBarRenderer();
// //         setSeriesToGroupMap(renderer, "Series4", "Group4");
// // 
//         // Add more contributions to group
// //         addContribution(renderer, dataset, column, "Series1", 10);
// //         addContribution(renderer, dataset, column, "Series2", -5);
// // 
// //         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
// //         when(rangeAxis.isInverted()).thenReturn(false);
// //         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.RIGHT);
// // 
//         // Act
// //         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// // 
//         // Assert
// //         verify(g2, atLeastOnce()).draw(any());
// //     }
// 
//     private void setSeriesToGroupMap(StackedBarRenderer renderer, String series, String group) throws Exception {
//         Field seriesToGroupMapField = renderer.getClass().getSuperclass().getDeclaredField("seriesToGroupMap");
//         seriesToGroupMapField.setAccessible(true);
//         KeyToGroupMap seriesToGroupMap = new KeyToGroupMap("MainGroup");
//         seriesToGroupMap.addGroup(series, group);
//         seriesToGroupMapField.set(renderer, seriesToGroupMap);
//     }
// 
//     private void addContribution(StackedBarRenderer renderer, CategoryDataset dataset, int column, String seriesKey, Number value) {
//         when(dataset.getValue(seriesKey, column)).thenReturn(value);
//     }
// }