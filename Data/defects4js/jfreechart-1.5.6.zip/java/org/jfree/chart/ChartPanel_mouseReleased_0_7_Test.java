package org.jfree.chart;

import java.lang.reflect.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.plot.PlotOrientation;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ChartPanel_mouseReleased_0_7_Test {

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, orientation VERTICAL, both zoom triggers false, ensuring zoomRectangle is erased")
    void TC31() throws Exception {
        // Arrange
        ChartPanel panel = spy(new ChartPanel(null));

        // Set zoomRectangle to non-null via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Set orientation to VERTICAL via reflection
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.VERTICAL);

        // Mock MouseEvent with x and y distances below zoomTriggerDistance
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(5);
        when(event.getY()).thenReturn(5);

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoom is not called
        verify(panel, never()).zoom(any(Rectangle2D.class));

        // Verify that zoomRectangle is erased (null)
        assertNull(zoomRectangleField.get(panel), "zoomRectangle should be null after mouseReleased");
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, getScreenDataArea returns partial area, ensuring zoomArea is correctly calculated")
    void TC32() throws Exception {
        // Arrange
        ChartPanel panel = spy(new ChartPanel(null));

        // Set zoomRectangle to non-null via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Mock getScreenDataArea to return partial area
        doReturn(new Rectangle2D.Double(0, 0, 200, 200)).when(panel).getScreenDataArea(anyInt(), anyInt());

        // Set orientation to HORIZONTAL via reflection
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        // Mock MouseEvent with x distance above zoomTriggerDistance
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn(15);
        when(event.getY()).thenReturn(15);

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoom is called with correctly calculated zoomArea
        ArgumentCaptor<Rectangle2D> zoomAreaCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(panel, times(1)).zoom(zoomAreaCaptor.capture());

        Rectangle2D expectedZoomArea = new Rectangle2D.Double(
            50, 0,
            Math.min(100, 200 - 50),
            200
        );
        assertEquals(expectedZoomArea.getX(), zoomAreaCaptor.getValue().getX(), 0.001);
        assertEquals(expectedZoomArea.getY(), zoomAreaCaptor.getValue().getY(), 0.001);
        assertEquals(expectedZoomArea.getWidth(), zoomAreaCaptor.getValue().getWidth(), 0.001);
        assertEquals(expectedZoomArea.getHeight(), zoomAreaCaptor.getValue().getHeight(), 0.001);
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, y-coordinate exactly at zoomTriggerDistance, testing boundary condition")
    void TC33() throws Exception {
        // Arrange
        ChartPanel panel = spy(new ChartPanel(null));

        // Set zoomRectangle to non-null via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        Point2D zoomPoint = new Point2D.Double(70, 70);
        zoomPointField.set(panel, zoomPoint);

        // Set orientation to VERTICAL via reflection
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.VERTICAL);

        // Mock MouseEvent with y distance exactly equal to zoomTriggerDistance
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn((int) zoomPoint.getX() + 6);
        when(event.getY()).thenReturn((int) zoomPoint.getY() + 10);

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoom is performed
        verify(panel, times(1)).zoom(any(Rectangle2D.class));

        // Verify that zoomPoint and zoomRectangle are null
        assertNull(zoomPointField.get(panel), "zoomPoint should be null after zoom");
        assertNull(zoomRectangleField.get(panel), "zoomRectangle should be null after zoom");
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, x-coordinate just below zoomTriggerDistance, ensuring no zoom triggered")
    void TC34() throws Exception {
        // Arrange
        ChartPanel panel = spy(new ChartPanel(null));

        // Set zoomRectangle to non-null via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        Point2D zoomPoint = new Point2D.Double(70, 70);
        zoomPointField.set(panel, zoomPoint);

        // Set orientation to HORIZONTAL via reflection
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        // Mock MouseEvent with x distance just below zoomTriggerDistance
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn((int) zoomPoint.getX() + 9);
        when(event.getY()).thenReturn((int) zoomPoint.getY() + 5);

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoom is not called
        verify(panel, never()).zoom(any(Rectangle2D.class));

        // Verify that zoomRectangle is erased (null)
        assertNull(zoomRectangleField.get(panel), "zoomRectangle should be null after mouseReleased");
    }

    @Test
    @DisplayName("mouseReleased with zoomRectangle present, x and y coordinates both exceed zoomTriggerDistance, multiple zoom triggers")
    void TC35() throws Exception {
        // Arrange
        ChartPanel panel = spy(new ChartPanel(null));

        // Set zoomRectangle to non-null via reflection
        Field zoomRectangleField = ChartPanel.class.getDeclaredField("zoomRectangle");
        zoomRectangleField.setAccessible(true);
        zoomRectangleField.set(panel, new Rectangle2D.Double(50, 50, 100, 100));

        // Set zoomPoint via reflection
        Field zoomPointField = ChartPanel.class.getDeclaredField("zoomPoint");
        zoomPointField.setAccessible(true);
        Point2D zoomPoint = new Point2D.Double(70, 70);
        zoomPointField.set(panel, zoomPoint);

        // Set orientation to HORIZONTAL via reflection
        Field orientationField = ChartPanel.class.getDeclaredField("orientation");
        orientationField.setAccessible(true);
        orientationField.set(panel, PlotOrientation.HORIZONTAL);

        // Set zoomZoomable flags via reflection
        Field domainZoomableField = ChartPanel.class.getDeclaredField("domainZoomable");
        domainZoomableField.setAccessible(true);
        domainZoomableField.setBoolean(panel, true);

        Field rangeZoomableField = ChartPanel.class.getDeclaredField("rangeZoomable");
        rangeZoomableField.setAccessible(true);
        rangeZoomableField.setBoolean(panel, true);

        // Mock MouseEvent with both x and y distances exceeding zoomTriggerDistance
        MouseEvent event = mock(MouseEvent.class);
        when(event.getX()).thenReturn((int) zoomPoint.getX() + 15);
        when(event.getY()).thenReturn((int) zoomPoint.getY() + 15);

        // Mock getScreenDataArea to return a valid area
        doReturn(new Rectangle2D.Double(0, 0, 300, 300)).when(panel).getScreenDataArea(anyInt(), anyInt());

        // Act
        panel.mouseReleased(event);

        // Assert
        // Verify that zoom is called once
        verify(panel, times(1)).zoom(any(Rectangle2D.class));

        // Verify that zoomPoint and zoomRectangle are null
        assertNull(zoomPointField.get(panel), "zoomPoint should be null after zoom");
        assertNull(zoomRectangleField.get(panel), "zoomRectangle should be null after zoom");
    }
}