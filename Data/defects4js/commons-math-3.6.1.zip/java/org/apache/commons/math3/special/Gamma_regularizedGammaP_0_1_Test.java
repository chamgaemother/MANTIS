package org.apache.commons.math3.special;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.special.Gamma;

public class Gamma_regularizedGammaP_0_1_Test {

    @Test
    @DisplayName("regularizedGammaP with a as NaN returns NaN")
    void testTC01() {
        double a = Double.NaN;
        double x = 5.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("regularizedGammaP with x as NaN returns NaN")
    void testTC02() {
        double a = 2.0;
        double x = Double.NaN;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("regularizedGammaP with a <= 0 returns NaN")
    void testTC03() {
        double a = 0.0;
        double x = 5.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("regularizedGammaP with x < 0 returns NaN")
    void testTC04() {
        double a = 2.0;
        double x = -1.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        assertTrue(Double.isNaN(result), "Expected result to be NaN");
    }

    @Test
    @DisplayName("regularizedGammaP with x == 0 returns 0.0")
    void testTC05() {
        double a = 2.0;
        double x = 0.0;
        double epsilon = 1e-10;
        int maxIterations = 1000;

        double result = Gamma.regularizedGammaP(a, x, epsilon, maxIterations);

        assertEquals(0.0, result, "Expected result to be 0.0");
    }
}