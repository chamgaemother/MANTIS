import org.jsoup.parser.TokenQueue;
import org.jsoup.internal.StringUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class TokenQueueTest {

    @Test
    public void testChompBalancedWithBalancedParentheses() {
        TokenQueue tq = new TokenQueue("(one (two) three) four");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("one (two) three", result);
    }

    @Test
    public void testChompBalancedWithUnbalancedParentheses() {
        TokenQueue tq = new TokenQueue("(one (two three) four");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tq.chompBalanced('(', ')');
        });
    }

    @Test
    public void testChompBalancedWithEscapeCharacters() {
        TokenQueue tq = new TokenQueue("(one \\(two\\) three) four");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("one \\(two\\) three", result);
    }

    @Test
    public void testChompBalancedWithQuotedStrings() {
        TokenQueue tq = new TokenQueue("(one 'two (three)' four) five");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("one 'two (three)' four", result);
    }

    @Test
    public void testChompBalancedWithEdgeQuotes() {
        TokenQueue tq = new TokenQueue("('one' (two) three) four");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("'one' (two) three", result);
    }

    @Test
    public void testChompBalancedWithInvertedQuotes() {
        TokenQueue tq = new TokenQueue("('one\"two') three)");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("'one\"two'", result);
    }

    @Test
    public void testChompBalancedWithRegexEscapes() {
        TokenQueue tq = new TokenQueue("(one \\Qtwo (three\\E) four) five");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("one \\Qtwo (three\\E) four", result);
    }

    @Test
    public void testChompBalancedWithEmptyQueue() {
        TokenQueue tq = new TokenQueue("");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("", result);
    }

    @Test
    public void testChompBalancedWithDirectClosure() {
        TokenQueue tq = new TokenQueue("() four");
        String result = tq.chompBalanced('(', ')');
        Assertions.assertEquals("", result);
    }

    @Test
    public void testChompBalancedWithEscapedOpener() {
        TokenQueue tq = new TokenQueue("\\(one (two) three) four");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tq.chompBalanced('(', ')');
        });
    }

    @Test
    public void testChompBalancedUnbalancedWithQuotes() {
        TokenQueue tq = new TokenQueue("(one 'two' (three four)");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tq.chompBalanced('(', ')');
        });
    }
}