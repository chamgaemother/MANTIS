package org.jfree.chart.renderer.xy;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.mockito.Mockito.*;

import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.entity.EntityCollection;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.Area;

public class StackedXYAreaRenderer_drawItem_0_1_Test {

    @Test
    @DisplayName("drawItem with y1 as NaN sets y1 to 0 and marks nullPoint true")
    public void TC01_drawItem_handles_NaN_y1() throws Exception {
        StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        StackedXYAreaRenderer.StackedXYAreaRendererState state = new StackedXYAreaRenderer.StackedXYAreaRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        TableXYDataset dataset = Mockito.mock(TableXYDataset.class);
        int series = 0;
        int item = 10;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        Mockito.when(dataset.getYValue(series, item)).thenReturn(Double.NaN);
        Mockito.when(dataset.getXValue(series, item)).thenReturn(50.0);
        Mockito.when(dataset.getItemCount()).thenReturn(11);

        Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        Mockito.when(rangeAxis.valueToJava2D(Mockito.anyDouble(), Mockito.eq(dataArea), Mockito.any()))
                .thenReturn(75.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        Mockito.verify(g2).fill(Mockito.any(Polygon.class));
    }

    @Test
    @DisplayName("drawItem with valid y1 and PlotOrientation.VERTICAL adds point to series area")
    public void TC02_drawItem_valid_y1_vertical_orientation() throws Exception {
        StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        StackedXYAreaRenderer.StackedXYAreaRendererState state = new StackedXYAreaRenderer.StackedXYAreaRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        TableXYDataset dataset = Mockito.mock(TableXYDataset.class);
        int series = 0;
        int item = 5;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        Mockito.when(dataset.getYValue(series, item)).thenReturn(25.0);
        Mockito.when(dataset.getXValue(series, item)).thenReturn(50.0);
        Mockito.when(dataset.getItemCount()).thenReturn(10);

        Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        Mockito.when(rangeAxis.valueToJava2D(Mockito.anyDouble(), Mockito.eq(dataArea), Mockito.any()))
                .thenReturn(75.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        Mockito.verify(g2, Mockito.never()).fill(Mockito.any(Polygon.class));
    }

    @Test
    @DisplayName("drawItem with PlotLines enabled renders lines between items")
    public void TC03_drawItem_plotLines_enabled() throws Exception {
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        StackedXYAreaRenderer.StackedXYAreaRendererState state = new StackedXYAreaRenderer.StackedXYAreaRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        TableXYDataset dataset = Mockito.mock(TableXYDataset.class);
        int series = 0;
        int item = 6;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        doReturn(true).when(renderer).getPlotLines();

        Mockito.when(dataset.getYValue(series, item)).thenReturn(30.0);
        Mockito.when(dataset.getXValue(series, item)).thenReturn(60.0);
        Mockito.when(dataset.getItemCount()).thenReturn(10);

        Mockito.when(dataset.getYValue(series, item - 1)).thenReturn(25.0);
        Mockito.when(dataset.getXValue(series, item - 1)).thenReturn(55.0);

        Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        Mockito.when(rangeAxis.valueToJava2D(Mockito.anyDouble(), Mockito.eq(dataArea), Mockito.any()))
                .thenReturn(75.0);

        Mockito.when(plot.indexOf(dataset)).thenReturn(0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        Mockito.verify(g2).draw(Mockito.any(Line2D.class));
    }

    @Test
    @DisplayName("drawItem on second pass renders shapes and collects entity information")
    public void TC04_drawItem_second_pass_shapes_entities() throws Exception {
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        StackedXYAreaRenderer.StackedXYAreaRendererState state = new StackedXYAreaRenderer.StackedXYAreaRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        TableXYDataset dataset = Mockito.mock(TableXYDataset.class);
        int series = 0;
        int item = 3;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 1;

        doReturn(true).when(renderer).getPlotShapes();

        Mockito.when(dataset.getYValue(series, item)).thenReturn(40.0);
        Mockito.when(dataset.getXValue(series, item)).thenReturn(70.0);
        Mockito.when(dataset.getItemCount()).thenReturn(5);

        Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        Mockito.when(rangeAxis.valueToJava2D(Mockito.anyDouble(), Mockito.eq(dataArea), Mockito.any()))
                .thenReturn(80.0);

        XYToolTipGenerator generator = Mockito.mock(XYToolTipGenerator.class);
        doReturn(generator).when(renderer).getToolTipGenerator(series, item);
        Mockito.when(generator.generateToolTip(dataset, series, item)).thenReturn("Tooltip");

        EntityCollection entities = Mockito.mock(EntityCollection.class);
        doReturn(entities).when(state).getEntityCollection();

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        Mockito.verify(g2).draw(Mockito.any(Shape.class));
        Mockito.verify(entities).add(Mockito.any());
    }

    @Test
    @DisplayName("drawItem without PlotArea and not last item skips area filling")
    public void TC05_drawItem_no_PlotArea_not_last_skips_filling() throws Exception {
        StackedXYAreaRenderer renderer = spy(new StackedXYAreaRenderer());
        Graphics2D g2 = Mockito.mock(Graphics2D.class);
        StackedXYAreaRenderer.StackedXYAreaRendererState state = new StackedXYAreaRenderer.StackedXYAreaRendererState(null);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = Mockito.mock(PlotRenderingInfo.class);
        XYPlot plot = Mockito.mock(XYPlot.class);
        ValueAxis domainAxis = Mockito.mock(ValueAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        TableXYDataset dataset = Mockito.mock(TableXYDataset.class);
        int series = 0;
        int item = 4;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        doReturn(false).when(renderer).getPlotArea();

        Mockito.when(dataset.getYValue(series, item)).thenReturn(35.0);
        Mockito.when(dataset.getXValue(series, item)).thenReturn(65.0);
        Mockito.when(dataset.getItemCount()).thenReturn(10);

        Mockito.when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        Mockito.when(rangeAxis.valueToJava2D(Mockito.anyDouble(), Mockito.eq(dataArea), Mockito.any()))
                .thenReturn(70.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        Mockito.verify(g2, Mockito.never()).fill(Mockito.any(Polygon.class));
    }
}