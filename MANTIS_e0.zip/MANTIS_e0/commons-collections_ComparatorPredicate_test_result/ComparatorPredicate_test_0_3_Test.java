package org.apache.commons.collections4.functors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.apache.commons.collections4.Predicate;

import java.util.Comparator;

public class ComparatorPredicate_test_0_3_Test {

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL with comparison equal to zero returns true")
    public void TC11() throws Exception {
        // Arrange
        Comparator<Object> comparator = (o1, o2) -> 0;
        Object target = new Object();
        Predicate<Object> predicate = ComparatorPredicate.comparatorPredicate(target, comparator, ComparatorPredicate.Criterion.LESS_OR_EQUAL);

        // Act
        boolean result = predicate.test(target);

        // Assert
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("Criterion LESS_OR_EQUAL with comparison greater than zero returns false")
    public void TC12() throws Exception {
        // Arrange
        Comparator<Object> comparator = (o1, o2) -> 1;
        Object target = new Object();
        Predicate<Object> predicate = ComparatorPredicate.comparatorPredicate(target, comparator, ComparatorPredicate.Criterion.LESS_OR_EQUAL);

        // Act
        boolean result = predicate.test(target);

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("Invalid criterion throws IllegalStateException")
    public void TC13() throws Exception {
        // Arrange
        Comparator<Object> comparator = (o1, o2) -> 0;
        Object target = new Object();

        // Act & Assert
        Assertions.assertThrows(NullPointerException.class, () -> {
            ComparatorPredicate.comparatorPredicate(target, comparator, null).test(target);
        });
    }
}
