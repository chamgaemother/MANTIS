package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * JUnit 5 test class for TokenMgrError.addEscapes method.
 */
public class TokenMgrError_addEscapes_0_4_Test {

    @Test
    @DisplayName("addEscapes with string containing characters at boundary 0x20 and 0x7e")
    void testTC16_addEscapes_boundary_characters() {
        String input = " !~";
        TokenMgrError tokenMgrError = new TokenMgrError();
        String result = tokenMgrError.addEscapes(input);
        assertEquals(" !~", result);
    }

    @Test
    @DisplayName("addEscapes with string containing multiple non-printable and high-ASCII characters")
    void testTC17_addEscapes_multiple_unicode_characters() {
        String input = "\u001F\u0080A";
        TokenMgrError tokenMgrError = new TokenMgrError();
        String result = tokenMgrError.addEscapes(input);
        assertEquals("\\u001f\\u0080A", result);
    }

    @Test
    @DisplayName("addEscapes with long string containing various escape scenarios")
    void testTC18_addEscapes_comprehensive_escape_scenarios() {
        String input = "\0\b\t\n\f\r\"\\'\\A\u001F\u0080";
        TokenMgrError tokenMgrError = new TokenMgrError();
        String result = tokenMgrError.addEscapes(input);
        assertEquals("\\b\\t\\n\\f\\r\\\"\\\'\\\\A\\u001f\\u0080", result);
    }

    @Test
    @DisplayName("addEscapes with string containing only high-ASCII characters")
    void testTC19_addEscapes_high_ASCII_characters() {
        String input = "\u0081\u009F";
        TokenMgrError tokenMgrError = new TokenMgrError();
        String result = tokenMgrError.addEscapes(input);
        assertEquals("\\u0081\\u009f", result);
    }

    @Test
    @DisplayName("addEscapes with string containing both escape and unicode characters")
    void testTC20_addEscapes_mixed_escaped_and_unicode() {
        String input = "\b\u009f";
        TokenMgrError tokenMgrError = new TokenMgrError();
        String result = tokenMgrError.addEscapes(input);
        assertEquals("\\b\\u009f", result);
    }
}