package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DurationFormatUtils_formatPeriod_0_2_Test {

    @Test
    @DisplayName("Duration without 'M' token, ensuring months are not included")
    void test_TC06() {
        long startMillis = 1609459200000L; // Jan 1, 2021
        long endMillis = 1612137600000L; // Feb 1, 2021
        String format = "y:d:H:m:s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        assertEquals("0:31:0:0:0:0", result);
    }

    @Test
    @DisplayName("Duration with 'M' token but without 'y' token")
    void test_TC07() {
        long startMillis = 1609459200000L; // Jan 1, 2021
        long endMillis = 1612137600000L; // Feb 1, 2021
        String format = "M:d:H:m:s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        assertEquals("1:0:0:0:0:0", result);
    }

    @Test
    @DisplayName("Duration with zero padding disabled")
    void test_TC08() {
        long startMillis = 1609459200000L;
        long endMillis = 1609462800000L; // +1 hour
        String format = "H:m:s";
        boolean padWithZeros = false;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        assertEquals("1:0:0", result);
    }

    @Test
    @DisplayName("Duration spanning multiple months without 'y' token")
    void test_TC09() {
        long startMillis = 1601510400000L; // Oct 1, 2020
        long endMillis = 1617235200000L; // Apr 1, 2021
        String format = "M:d:H:m:s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        assertEquals("6:0:0:0:0:0", result);
    }

    @Test
    @DisplayName("Duration with milliseconds rollover")
    void test_TC10() {
        long startMillis = 1609459200123L;
        long endMillis = 1609459201123L; // +1 second
        String format = "s:S";
        boolean padWithZeros = true;
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, format, padWithZeros, timezone);
        assertEquals("1:000", result);
    }
}