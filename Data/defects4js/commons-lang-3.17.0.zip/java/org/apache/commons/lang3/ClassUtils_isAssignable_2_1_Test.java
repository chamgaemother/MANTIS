package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_2_1_Test {

    @Test
    @DisplayName("cls is primitive (double), toClass is wrapper (Double) with autoboxing=true; expect true")
    void TC45_primitive_to_wrapper_autoboxing_true_assignable() {
        // Given
        Class<?> cls = double.class;
        Class<?> toClass = Double.class;
        boolean autoboxing = true;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is primitive (boolean), toClass is wrapper (Boolean) with autoboxing=true; expect true")
    void TC46_primitive_boolean_to_wrapper_autoboxing_true_assignable() {
        // Given
        Class<?> cls = boolean.class;
        Class<?> toClass = Boolean.class;
        boolean autoboxing = true;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Integer), toClass is superclass (Number) with autoboxing=false; expect true")
    void TC47_wrapper_Integer_to_superclass_Number_autoboxing_false_assignable() {
        // Given
        Class<?> cls = Integer.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = false;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertTrue(result);
    }

    @Test
    @DisplayName("cls is wrapper (Character), toClass is wrapper (Number) with autoboxing=true; expect false")
    void TC48_wrapper_Character_to_wrapper_Number_autoboxing_true_non_assignable() {
        // Given
        Class<?> cls = Character.class;
        Class<?> toClass = Number.class;
        boolean autoboxing = true;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is array class (Integer[]), toClass is assignable array class (Number[]) with autoboxing=true; expect true")
    void TC49_array_Integer_to_array_Number_autoboxing_true_assignable() {
        // Given
        Class<?> cls = Integer[].class;
        Class<?> toClass = Number[].class;
        boolean autoboxing = true;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertTrue(result);
    }

}