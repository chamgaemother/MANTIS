package org.jfree.chart.axis;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.data.Range;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class LogarithmicAxis_autoAdjustRange_2_1_Test {

    @Test
    @DisplayName("autoAdjustRange correctly adjusts range when allowNegativesFlag is true and all data values are negative")
    public void TC25_autoAdjustRange_withAllNegativeValues_allowNegativesFlagTrue() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(true);
        
        // Use a mock plot since original setPlot() method not available
        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(-20.0, -5.0));
        axis.setPlot((Plot) mockPlot);
        
        // Access computeLogFloor and computeLogCeil via reflection
        Method computeLogFloor = LogarithmicAxis.class.getDeclaredMethod("computeLogFloor", double.class);
        computeLogFloor.setAccessible(true);
        double expectedLowerBound = (double) computeLogFloor.invoke(axis, -20.0);
        
        Method computeLogCeil = LogarithmicAxis.class.getDeclaredMethod("computeLogCeil", double.class);
        computeLogCeil.setAccessible(true);
        double expectedUpperBound = (double) computeLogCeil.invoke(axis, -5.0);
        
        // WHEN
        axis.autoAdjustRange();
        
        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(expectedLowerBound, adjustedRange.getLowerBound(), "Lower bound should be adjusted correctly.");
        assertEquals(expectedUpperBound, adjustedRange.getUpperBound(), "Upper bound should be adjusted correctly.");
    }

    @Test
    @DisplayName("autoAdjustRange correctly adjusts range when allowNegativesFlag is true and data range includes both negative and positive values")
    public void TC26_autoAdjustRange_withMixedValues_allowNegativesFlagTrue() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(true);
        
        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(-10.0, 20.0));
        axis.setPlot((Plot) mockPlot);
        
        // Access computeLogFloor and computeLogCeil via reflection
        Method computeLogFloor = LogarithmicAxis.class.getDeclaredMethod("computeLogFloor", double.class);
        computeLogFloor.setAccessible(true);
        double expectedLowerBound = (double) computeLogFloor.invoke(axis, -10.0);
        
        Method computeLogCeil = LogarithmicAxis.class.getDeclaredMethod("computeLogCeil", double.class);
        computeLogCeil.setAccessible(true);
        double expectedUpperBound = (double) computeLogCeil.invoke(axis, 20.0);
        
        // WHEN
        axis.autoAdjustRange();
        
        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(expectedLowerBound, adjustedRange.getLowerBound(), "Lower bound should be adjusted correctly.");
        assertEquals(expectedUpperBound, adjustedRange.getUpperBound(), "Upper bound should be adjusted correctly.");
    }

    @Test
    @DisplayName("autoAdjustRange adjusts lower bound correctly when allowNegativesFlag is false and lower bound is between 0 and 10")
    public void TC27_autoAdjustRange_lowerBoundBetween0And10_allowNegativesFlagFalse() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(false);
        axis.setLowerMargin(0.1);
        
        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(5.0, 15.0));
        axis.setPlot((Plot) mockPlot);
        
        // Access computeLogFloor via reflection
        Method computeLogFloor = LogarithmicAxis.class.getDeclaredMethod("computeLogFloor", double.class);
        computeLogFloor.setAccessible(true);
        double expectedLowerBound = (double) computeLogFloor.invoke(axis, 5.0);
        
        // Access computeLogCeil via reflection
        Method computeLogCeil = LogarithmicAxis.class.getDeclaredMethod("computeLogCeil", double.class);
        computeLogCeil.setAccessible(true);
        double expectedUpperBound = (double) computeLogCeil.invoke(axis, 15.0);
        
        // WHEN
        axis.autoAdjustRange();
        
        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(expectedLowerBound, adjustedRange.getLowerBound(), "Lower bound should be adjusted correctly with smallLogFlag=true.");
        assertEquals(expectedUpperBound, adjustedRange.getUpperBound(), "Upper bound should be adjusted correctly.");
    }

    @Test
    @DisplayName("autoAdjustRange correctly rounds upper bound up when allowNegativesFlag is false and upper bound is between 0 and 1")
    public void TC28_autoAdjustRange_upperBoundBetween0And1_allowNegativesFlagFalse() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        // GIVEN
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(false);
        axis.setUpperMargin(0.1);
        
        ValueAxisPlot mockPlot = mock(ValueAxisPlot.class);
        when(mockPlot.getDataRange(axis)).thenReturn(new Range(2.0, 0.5));
        axis.setPlot((Plot) mockPlot);
        
        // Access computeLogFloor via reflection
        Method computeLogFloor = LogarithmicAxis.class.getDeclaredMethod("computeLogFloor", double.class);
        computeLogFloor.setAccessible(true);
        double expectedLowerBound = (double) computeLogFloor.invoke(axis, 2.0);
        
        // Access computeLogCeil via reflection
        Method computeLogCeil = LogarithmicAxis.class.getDeclaredMethod("computeLogCeil", double.class);
        computeLogCeil.setAccessible(true);
        double expectedUpperBound = Math.ceil(0.5 * 10) / 10; // Fixed to align with expected behavior
        
        // WHEN
        axis.autoAdjustRange();
        
        // THEN
        Range adjustedRange = axis.getRange();
        assertEquals(expectedLowerBound, adjustedRange.getLowerBound(), "Lower bound should remain unchanged.");
        assertEquals(expectedUpperBound, adjustedRange.getUpperBound(), "Upper bound should be rounded up to nearest significant digit.");
    }
}