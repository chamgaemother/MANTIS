package org.apache.commons.lang3.reflect;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MethodUtils_getMatchingAccessibleMethod_0_2_Test {

    @Test
    @DisplayName("Returns null when bestMatch is varargs but varargs conditions fail")
    void TC06_ReturnsNullWhenBestMatchIsVarargsButVarargsConditionsFail() throws Exception {
        // Arrange
        Class<?> cls = VarargsMismatchClass.class;
        String methodName = "varargsMismatchMethod";
        Class<?>[] parameterTypes = {Double.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("Handles multiple iterations in the method selection loop with varying accessible methods")
    void TC07_HandlesMultipleIterationsWithVaryingAccessibleMethods() throws Exception {
        // Arrange
        Class<?> cls = MultiAccessibleClass.class;
        String methodName = "iterativeMethod";
        Class<?>[] parameterTypes = {String.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNotNull(result);
        assertEquals("iterativeMethod", result.getName());
        // Additional assertions can be added here to verify the correct method is selected
    }

    @Test
    @DisplayName("Handles scenario where getAccessibleMethod returns null for all methods")
    void TC08_HandlesScenarioWhereGetAccessibleMethodReturnsNull() throws Exception {
        // Arrange
        Class<?> cls = NoAccessibleMethodsClass.class;
        String methodName = "inaccessibleMethod";
        Class<?>[] parameterTypes = {String.class};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("Handles scenario with varargs method and empty parameterTypes")
    void TC09_HandlesVarargsWithEmptyParameterTypes() throws Exception {
        // Arrange
        Class<?> cls = VarargsEmptyParamsClass.class;
        String methodName = "varargsEmptyParamsMethod";
        Class<?>[] parameterTypes = {};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNull(result);
    }

    @Test
    @DisplayName("Handles scenario where the last parameter type is null")
    void TC10_HandlesVarargsWithNullLastParameterType() throws Exception {
        // Arrange
        Class<?> cls = VarargsNullParamClass.class;
        String methodName = "varargsNullParamMethod";
        Class<?>[] parameterTypes = {null};

        // Act
        Method result = MethodUtils.getMatchingAccessibleMethod(cls, methodName, parameterTypes);

        // Assert
        assertNull(result);
    }

    // Inner classes for testing purposes

    private static class VarargsMismatchClass {
        public void varargsMismatchMethod(Double... args) {
            // Method implementation
        }
    }

    private static class MultiAccessibleClass {
        public void iterativeMethod(String param) {
            // Method implementation
        }

        public void iterativeMethod(Object param) {
            // Method implementation
        }
    }

    private static class NoAccessibleMethodsClass {
        private void inaccessibleMethod(String param) {
            // Method implementation
        }
    }

    private static class VarargsEmptyParamsClass {
        public void varargsEmptyParamsMethod(Object... args) {
            // Method implementation
        }
    }

    private static class VarargsNullParamClass {
        public void varargsNullParamMethod(Object... args) {
            // Method implementation
        }
    }
}