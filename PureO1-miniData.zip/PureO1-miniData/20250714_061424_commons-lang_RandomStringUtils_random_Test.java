package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class RandomStringUtilsTest {

    @Test
    @DisplayName("Test random with count = 0")
    void testRandomCountZero() {
        String result = RandomStringUtils.random(0, 0, 0, false, false, null, new Random());
        assertEquals("", result);
    }

    @ParameterizedTest
    @ValueSource(ints = {-1, -10, Integer.MIN_VALUE})
    @DisplayName("Test random with negative count")
    void testRandomNegativeCount(int count) {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, 0, 0, false, false, null, new Random());
        });
        assertTrue(exception.getMessage().contains("Requested random string length"));
    }

    @Test
    @DisplayName("Test random with empty chars array")
    void testRandomEmptyChars() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(5, 0, 0, false, false, new char[] {}, new Random());
        });
        assertEquals("The chars array must not be empty", exception.getMessage());
    }

    @Test
    @DisplayName("Test random with start and end as 0 and chars not null")
    void testRandomStartEndZeroWithChars() {
        char[] chars = {'a', 'b', 'c'};
        String result = RandomStringUtils.random(5, 0, 0, false, false, chars, new Random());
        assertNotNull(result);
        assertEquals(5, result.length());
        for (char c : result.toCharArray()) {
            assertTrue(new String(chars).indexOf(c) >= 0);
        }
    }

    @Test
    @DisplayName("Test random with start and end as 0, letters and numbers false")
    void testRandomStartEndZeroLettersNumbersFalse() {
        String result = RandomStringUtils.random(5, 0, 0, false, false, null, new Random());
        assertNotNull(result);
        assertEquals(5, result.length());
    }

    @Test
    @DisplayName("Test random with start and end as 0, letters or numbers true")
    void testRandomStartEndZeroLettersOrNumbersTrue() {
        String result = RandomStringUtils.random(5, 0, 0, true, false, null, new Random());
        assertNotNull(result);
        assertEquals(5, result.length());
    }

    @ParameterizedTest
    @ValueSource(ints = {10, 20, 100})
    @DisplayName("Test random with end <= start")
    void testRandomEndLessThanOrEqualStart(int count) {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, 10, 5, true, true, null, new Random());
        });
        assertTrue(exception.getMessage().contains("Parameter end"));
    }

    @ParameterizedTest
    @ValueSource(ints = {-1, -5, -100})
    @DisplayName("Test random with negative start")
    void testRandomNegativeStart(int start) {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(5, start, 10, true, true, null, new Random());
        });
        assertTrue(exception.getMessage().contains("Character positions MUST be >= 0"));
    }

    @ParameterizedTest
    @ValueSource(ints = {-1, -5, -100})
    @DisplayName("Test random with negative end")
    void testRandomNegativeEnd(int end) {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(5, 0, end, true, true, null, new Random());
        });
        assertTrue(exception.getMessage().contains("Character positions MUST be >= 0"));
    }

    @Test
    @DisplayName("Test random with end greater than Character.MAX_CODE_POINT")
    void testRandomEndExceedsMaxCodePoint() {
        String result = RandomStringUtils.random(5, 0, Character.MAX_CODE_POINT + 1000, false, false, null, new Random());
        assertNotNull(result);
        assertEquals(5, result.length());
    }

    @Test
    @DisplayName("Test random with chars null, letters and numbers true, start <= '0', end >= 'z' +1")
    void testRandomAlphanumericalCharsPath() {
        String result = RandomStringUtils.random(10, '0', 'z' + 1, true, true, null, new Random());
        assertNotNull(result);
        assertEquals(10, result.length());
    }

    @Test
    @DisplayName("Test random with valid chars array")
    void testRandomWithValidChars() {
        char[] chars = {'x', 'y', 'z'};
        String result = RandomStringUtils.random(5, 0, chars.length, false, false, chars, new Random());
        assertNotNull(result);
        assertEquals(5, result.length());
        for (char c : result.toCharArray()) {
            assertTrue(new String(chars).indexOf(c) >= 0);
        }
    }

    @Test
    @DisplayName("Test random with letters=true, numbers=false")
    void testRandomLettersOnly() {
        String result = RandomStringUtils.random(10, 0, 0, true, false, null, new Random());
        assertNotNull(result);
        assertEquals(10, result.length());
        assertTrue(result.chars().allMatch(Character::isLetter));
    }

    @Test
    @DisplayName("Test random with letters=false, numbers=true")
    void testRandomNumbersOnly() {
        String result = RandomStringUtils.random(10, 0, 0, false, true, null, new Random());
        assertNotNull(result);
        assertEquals(10, result.length());
        assertTrue(result.chars().allMatch(Character::isDigit));
    }

    @Test
    @DisplayName("Test random with letters=true, numbers=true")
    void testRandomLettersAndNumbers() {
        String result = RandomStringUtils.random(10, 0, 0, true, true, null, new Random());
        assertNotNull(result);
        assertEquals(10, result.length());
        assertTrue(result.chars().allMatch(c -> Character.isLetter(c) || Character.isDigit(c)));
    }

    @Test
    @DisplayName("Test random with letters=false, numbers=false")
    void testRandomAllCharacters() {
        String result = RandomStringUtils.random(10, 0, 0, false, false, null, new Random());
        assertNotNull(result);
        assertEquals(10, result.length());
    }

    @Test
    @DisplayName("Test random with chars null, letters=true, numbers=true, start > '0' and end < 'z'+1")
    void testRandomLettersNumbersWithRestrictedRange() {
        String result = RandomStringUtils.random(10, '1', 'y', true, true, null, new Random());
        assertNotNull(result);
        assertEquals(10, result.length());
    }

    @Test
    @DisplayName("Test random with chars null, letters=false, numbers=false, full range")
    void testRandomFullRange() {
        String result = RandomStringUtils.random(10, 0, 0, false, false, null, new Random());
        assertNotNull(result);
        assertEquals(10, result.length());
    }
}