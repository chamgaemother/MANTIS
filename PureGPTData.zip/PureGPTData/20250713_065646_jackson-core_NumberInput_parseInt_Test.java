import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NumberInputTest {

    @Test
    void testParseIntPositiveNumber() {
        char[] input = "12345".toCharArray();
        int result = NumberInput.parseInt(input, 0, 5);
        assertEquals(12345, result);
    }

    @Test
    void testParseIntPositiveNumberWithPlus() {
        char[] input = "+12345".toCharArray();
        int result = NumberInput.parseInt(input, 0, 6);
        assertEquals(12345, result);
    }

    @Test
    void testParseIntSingleDigit() {
        char[] input = "8".toCharArray();
        int result = NumberInput.parseInt(input, 0, 1);
        assertEquals(8, result);
    }

    @Test
    void testParseIntEdgeCaseLenTwo() {
        char[] input = "12".toCharArray();
        int result = NumberInput.parseInt(input, 0, 2);
        assertEquals(12, result);
    }

    @Test
    void testParseIntEdgeCaseLenThree() {
        char[] input = "123".toCharArray();
        int result = NumberInput.parseInt(input, 0, 3);
        assertEquals(123, result);
    }

    @Test
    void testParseIntEdgeCaseLenFour() {
        char[] input = "1234".toCharArray();
        int result = NumberInput.parseInt(input, 0, 4);
        assertEquals(1234, result);
    }

    @Test
    void testParseIntEdgeCaseLenFive() {
        char[] input = "12345".toCharArray();
        int result = NumberInput.parseInt(input, 0, 5);
        assertEquals(12345, result);
    }
    
    @Test
    void testParseIntEdgeCaseLenSix() {
        char[] input = "123456".toCharArray();
        int result = NumberInput.parseInt(input, 0, 6);
        assertEquals(123456, result);
    }

    @Test
    void testParseIntEdgeCaseLenSeven() {
        char[] input = "1234567".toCharArray();
        int result = NumberInput.parseInt(input, 0, 7);
        assertEquals(1234567, result);
    }

    @Test
    void testParseIntEdgeCaseLenEight() {
        char[] input = "12345678".toCharArray();
        int result = NumberInput.parseInt(input, 0, 8);
        assertEquals(12345678, result);
    }

    @Test
    void testParseIntEdgeCaseLenNine() {
        char[] input = "123456789".toCharArray();
        int result = NumberInput.parseInt(input, 0, 9);
        assertEquals(123456789, result);
    }

    @Test
    void testParseIntLargeNumberWithLeadingPlus() {
        char[] input = "+214748364".toCharArray();
        int result = NumberInput.parseInt(input, 0, 10);
        assertEquals(214748364, result);
    }

    @Test
    void testParseIntNegativeNumber() {
        char[] input = "-12345".toCharArray();
        int result = NumberInput.parseInt(input, 1, 5);
        assertEquals(12345, result); // Only parses digits, ignores sign
    }
}