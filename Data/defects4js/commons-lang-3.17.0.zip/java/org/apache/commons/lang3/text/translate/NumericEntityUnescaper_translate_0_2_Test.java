package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.io.StringWriter;
import java.io.Writer;
import org.junit.jupiter.api.Assertions;
import java.util.EnumSet;
import java.lang.reflect.Field;

public class NumericEntityUnescaper_translate_0_2_Test {

    @Test
    @DisplayName("Input starts with '&#x' followed by valid hexadecimal digits without ';', semiColonRequired not set")
    public void TC06() throws Exception {
        // Initialize NumericEntityUnescaper without semiColonRequired
        // Fixed by passing semiColonOptional during initialization
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        
        CharSequence input = "&#x41";
        int index = 0;
        Writer out = new StringWriter();
        
        int result = unescaper.translate(input, index, out);
        
        Assertions.assertEquals("A", out.toString());
        Assertions.assertEquals(4, result);
    }

    @Test
    @DisplayName("Input starts with '&#x' followed by valid hexadecimal digits without ';', semiColonRequired is set")
    public void TC07() throws Exception {
        // Initialize NumericEntityUnescaper and set semiColonRequired option via reflection
        // Fixed invalid reflection code, used proper type casting
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        
        // Use reflection to set the semiColonRequired option
        Field optionsField = NumericEntityUnescaper.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        EnumSet<NumericEntityUnescaper.OPTION> options = EnumSet.of(NumericEntityUnescaper.OPTION.semiColonRequired);
        optionsField.set(unescaper, options);
        
        CharSequence input = "&#x41";
        int index = 0;
        Writer out = new StringWriter();
        
        int result = unescaper.translate(input, index, out);
        
        Assertions.assertEquals(0, result);
        Assertions.assertEquals("", out.toString());
    }

    @Test
    @DisplayName("Input starts with '&#x' followed by invalid hexadecimal digits, returns 0")
    public void TC08() throws Exception {
        // Initialize NumericEntityUnescaper
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        
        CharSequence input = "&#xZZ;";
        int index = 0;
        Writer out = new StringWriter();
        
        int result = unescaper.translate(input, index, out);
        
        Assertions.assertEquals(0, result);
        Assertions.assertEquals("", out.toString());
    }

    @Test
    @DisplayName("Input starts with '&#' followed by valid decimal digits and ends with ';'")
    public void TC09() throws Exception {
        // Initialize NumericEntityUnescaper without semiColonRequired
        // Fixed by passing semiColonOptional to allow optional semicolon
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        
        CharSequence input = "&#65;";
        int index = 0;
        Writer out = new StringWriter();
        
        int result = unescaper.translate(input, index, out);
        
        Assertions.assertEquals("A", out.toString());
        Assertions.assertEquals(4, result);
    }

    @Test
    @DisplayName("Input starts with '&#' followed by valid decimal digits without ';', semiColonRequired not set")
    public void TC10() throws Exception {
        // Initialize NumericEntityUnescaper without semiColonRequired
        // Fixed by passing semiColonOptional
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        
        CharSequence input = "&#65";
        int index = 0;
        Writer out = new StringWriter();
        
        int result = unescaper.translate(input, index, out);
        
        Assertions.assertEquals("A", out.toString());
        Assertions.assertEquals(3, result);
    }
}