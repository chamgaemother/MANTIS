package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class MinMaxCategoryRenderer_drawItem_0_2_Test {

    @Test
    @DisplayName("TC06: drawItem resets min and max for a new category")
    public void TC06_drawItemResetsMinAndMaxForNewCategory() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        // Set private fields via reflection
        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
        lastCategoryField.setAccessible(true);
        lastCategoryField.set(renderer, 1); // differentColumn

        Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
        minField.setAccessible(true);
        minField.setDouble(renderer, 8.0);

        Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
        maxField.setAccessible(true);
        maxField.setDouble(renderer, 15.0);

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(12);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        double min = minField.getDouble(renderer);
        double max = maxField.getDouble(renderer);

        assertEquals(12.0, min, "Min should be reset to 12.0");
        assertEquals(12.0, max, "Max should be reset to 12.0");
    }

    @Test
    @DisplayName("TC07: drawItem draws connecting line when plotLines is true and previous value exists")
    public void TC07_drawItemDrawsConnectingLineWhenPlotLinesTrueAndPreviousValueExists() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        // Set private fields via reflection if needed

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(15);
        when(dataset.getValue(row, column - 1)).thenReturn(10);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Set plotLines to true via reflection
        Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
        plotLinesField.setAccessible(true);
        plotLinesField.setBoolean(renderer, true);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        // Verify that draw was called to draw the connecting line
        ArgumentCaptor<java.awt.Shape> lineCaptor = ArgumentCaptor.forClass(java.awt.Shape.class);
        verify(g2, atLeastOnce()).draw(lineCaptor.capture());

        // Further assertions can be made on the captured lines if needed
        assertFalse(lineCaptor.getAllValues().isEmpty(), "A connecting line should be drawn.");
    }

    @Test
    @DisplayName("TC08: drawItem does not draw connecting line when plotLines is false")
    public void TC08_drawItemDoesNotDrawConnectingLineWhenPlotLinesFalse() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(15);

        // Set plotLines to false via reflection
        Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
        plotLinesField.setAccessible(true);
        plotLinesField.setBoolean(renderer, false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        // Verify that draw was not called for connecting lines
        ArgumentCaptor<java.awt.Shape> lineCaptor = ArgumentCaptor.forClass(java.awt.Shape.class);
        verify(g2, never()).draw(lineCaptor.capture());
    }

    @Test
    @DisplayName("TC09: drawItem handles null previous dataset value gracefully")
    public void TC09_drawItemHandlesNullPreviousDatasetValueGracefully() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getValue(row, column)).thenReturn(15);
        when(dataset.getValue(row, column - 1)).thenReturn(null);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Set plotLines to true via reflection
        Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
        plotLinesField.setAccessible(true);
        plotLinesField.setBoolean(renderer, true);

        // Act & Assert
        assertDoesNotThrow(() -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        }, "drawItem should handle null previous dataset value without throwing exceptions.");

        // Verify that no connecting line is drawn
        ArgumentCaptor<java.awt.Shape> lineCaptor = ArgumentCaptor.forClass(java.awt.Shape.class);
        verify(g2, never()).draw(lineCaptor.capture());
    }

    @Test
    @DisplayName("TC10: drawItem adds item entity when entity collection is available")
    public void TC10_drawItemAddsItemEntityWhenEntityCollectionIsAvailable() throws Exception {
        // Arrange
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();

        // Mock dependencies
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        EntityCollection entities = mock(EntityCollection.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(state.getEntityCollection()).thenReturn(entities);
        when(dataset.getValue(row, column)).thenReturn(15);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        // Verify that addItemEntity was called with correct parameters
        verify(renderer, never()).addItemEntity(any(), any(), anyInt(), anyInt(), any());

        // Since addItemEntity is a protected method, we need to spy on the renderer
        MinMaxCategoryRenderer spyRenderer = Mockito.spy(renderer);
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(spyRenderer, times(1)).addItemEntity(eq(entities), eq(dataset), eq(row), eq(column), any());
    }
}