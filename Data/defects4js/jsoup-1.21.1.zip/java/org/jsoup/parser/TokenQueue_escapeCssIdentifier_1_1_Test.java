package org.jsoup.parser;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class TokenQueue_escapeCssIdentifier_1_1_Test {

    @Test
    @DisplayName("Input starts with a non-hyphen, non-digit character, appends character as is")
    void TC14_escapeCssIdentifier_non_hyphen_non_digit() {
        // GIVEN
        String input = "aExample";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("aExample", result);
    }

    @Test
    @DisplayName("Input contains character where isIdent(c4) is false, escapes the character")
    void TC15_escapeCssIdentifier_non_ident_char_escape() {
        // GIVEN
        String input = "abc@def";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("abc\\@def", result);
    }

    @Test
    @DisplayName("Input contains character where isIdent(c4) is true, appends character as is")
    void TC16_escapeCssIdentifier_ident_char_append() {
        // GIVEN
        String input = "abcDef123";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("abcDef123", result);
    }

    @Test
    @DisplayName("Input contains multiple non-identifier and identifier characters, correctly escapes and appends")
    void TC17_escapeCssIdentifier_mixed_characters() {
        // GIVEN
        String input = "ab@c#D";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("ab\\@c\\#D", result);
    }

    @Test
    @DisplayName("Input contains a hyphen followed by a non-digit, non-hyphen character")
    void TC18_escapeCssIdentifier_hyphen_followed_by_non_digit() {
        // GIVEN
        String input = "-a";
        // WHEN
        String result = TokenQueue.escapeCssIdentifier(input);
        // THEN
        assertEquals("-a", result);
    }

}