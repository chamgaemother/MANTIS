package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.DeviationRenderer.State;
import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class DeviationRendererTest {

    private DeviationRenderer renderer;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private IntervalXYDataset dataset;
    private int series;
    private int item;
    private CrosshairState crosshairState;
    private int pass;

    @BeforeEach
    void setUp() {
        renderer = new DeviationRenderer();
        g2 = mock(Graphics2D.class);
        dataArea = mock(Rectangle2D.class);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(IntervalXYDataset.class);
        series = 0;
        item = 0;
        crosshairState = mock(CrosshairState.class);
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(false);

        renderer.drawItem(g2, mock(XYItemRendererState.class), dataArea, info,
                plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, 0);

        verify(renderer, never()).getItemFillPaint(anyInt(), anyInt());
    }

    @Test
    void testDrawItem_Pass0_NotLastItem_VERTICAL() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getStartYValue(series, item)).thenReturn(2.0);
        when(dataset.getEndYValue(series, item)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(dataset.getItemCount(series)).thenReturn(2);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));

        State state = new State(info);
        state.lowerCoordinates = new ArrayList<>();
        state.upperCoordinates = new ArrayList<>();

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis,
                rangeAxis, dataset, series, item, crosshairState, 0);

        verify(dataset).getXValue(series, item);
        verify(dataset).getStartYValue(series, item);
        verify(dataset).getEndYValue(series, item);
    }

    @Test
    void testDrawItem_Pass0_LastItem_VERTICAL() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getStartYValue(series, item)).thenReturn(2.0);
        when(dataset.getEndYValue(series, item)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(dataset.getItemCount(series)).thenReturn(1);
        when(renderer.getItemFillPaint(series, item)).thenReturn(null);

        State state = new State(info);
        state.lowerCoordinates = new ArrayList<>();
        state.upperCoordinates = new ArrayList<>();
        state.lowerCoordinates.add(new double[] {200.0, 100.0});
        state.upperCoordinates.add(new double[] {150.0, 100.0});

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis,
                rangeAxis, dataset, series, item, crosshairState, 0);

        verify(g2).setComposite(any());
        verify(g2).setPaint(null);
        verify(g2).fill(any());
        verify(g2).setComposite(any());
    }

    @Test
    void testDrawItem_Pass0_NotLastItem_HORIZONTAL() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getStartYValue(series, item)).thenReturn(2.0);
        when(dataset.getEndYValue(series, item)).thenReturn(3.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(dataset.getItemCount(series)).thenReturn(2);

        State state = new State(info);
        state.lowerCoordinates = new ArrayList<>();
        state.upperCoordinates = new ArrayList<>();

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis,
                rangeAxis, dataset, series, item, crosshairState, 0);

        verify(dataset).getXValue(series, item);
        verify(dataset).getStartYValue(series, item);
        verify(dataset).getEndYValue(series, item);
    }

    @Test
    void testDrawItem_Pass1_DrawLine() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.getItemLineVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(dataset.getItemCount(series)).thenReturn(2);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getYValue(series, item)).thenReturn(2.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(renderer.isLinePass(1)).thenReturn(true);

        org.jfree.chart.renderer.xy.DeviationRenderer.State state = new org.jfree.chart.renderer.xy.DeviationRenderer.State(info);
        state.seriesPath = new java.awt.geom.GeneralPath();
        state.setProcessVisibleItemsOnly(false);
        state.setLastPointGood(false);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis,
                rangeAxis, dataset, series, item, crosshairState, 1);

        verify(renderer).drawPrimaryLineAsPath(state, g2, plot, dataset, 1, series, item, domainAxis, rangeAxis, dataArea);
    }

    @Test
    void testDrawItem_Pass2_DrawShape_WithEntities() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.isItemPass(2)).thenReturn(true);
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);

        renderer.drawItem(g2, mock(XYItemRendererState.class), dataArea, info,
                plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, 2);

        verify(renderer).drawSecondaryPass(g2, plot, dataset, 2, series, item, domainAxis, dataArea, rangeAxis, crosshairState, entities);
    }

    @Test
    void testDrawItem_Pass2_DrawShape_NoEntities() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(renderer.isItemPass(2)).thenReturn(true);
        when(info.getOwner()). .thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(null);

        renderer.drawItem(g2, mock(XYItemRendererState.class), dataArea, info,
                plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, 2);

        verify(renderer).drawSecondaryPass(g2, plot, dataset, 2, series, item, domainAxis, dataArea, rangeAxis, crosshairState, null);
    }

    @Test
    void testDrawItem_NullGraphics() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);

        renderer.drawItem(null, mock(XYItemRendererState.class), dataArea, info,
                plot, domainAxis, rangeAxis, dataset, series, item,
                crosshairState, 0);

        // Depending on implementation, it might throw NullPointerException
    }

    @Test
    void testDrawItem_LastItemEmptyDataset() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getItemCount(series)).thenReturn(1);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getStartYValue(series, item)).thenReturn(2.0);
        when(dataset.getEndYValue(series, item)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(renderer.getItemFillPaint(series, item)).thenReturn(null);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));

        State state = new State(info);
        state.lowerCoordinates = new ArrayList<>();
        state.upperCoordinates = new ArrayList<>();
        state.lowerCoordinates.add(new double[] {200.0, 100.0});
        state.upperCoordinates.add(new double[] {150.0, 100.0});

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis,
                rangeAxis, dataset, series, item, crosshairState, 0);

        verify(g2).fill(any());
    }

    @Test
    void testFindRangeBounds_NullDataset() {
        Range range = renderer.findRangeBounds(null);
        assert range == null;
    }

    @Test
    void testFindRangeBounds_EmptyDataset() {
        when(dataset.getItemCount(anyInt())).thenReturn(0);
        Range range = renderer.findRangeBounds(dataset);
        assert range == null;
    }

    @Test
    void testInitialize_StateInitialization() {
        when(renderer.initialise(g2, dataArea, plot, dataset, info)).thenCallRealMethod();
        XYItemRendererState state = renderer.initialise(g2, dataArea, plot, dataset, info);
        assert state instanceof State;
        State s = (State) state;
        assert s.lowerCoordinates != null;
        assert s.upperCoordinates != null;
        assert s.seriesPath != null;
        assert !s.getProcessVisibleItemsOnly();
    }

    @Test
    void testSetDrawSeriesLineAsPath_Ignored() {
        renderer.setDrawSeriesLineAsPath(false);
        // Since it's ignored, no effect. No exception means pass
    }

    @Test
    void testSetAlpha_Valid() {
        renderer.setAlpha(0.7f);
        assert renderer.getAlpha() == 0.7f;
    }

    @Test
    void testSetAlpha_InvalidLow() {
        try {
            renderer.setAlpha(-0.1f);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }
    }

    @Test
    void testSetAlpha_InvalidHigh() {
        try {
            renderer.setAlpha(1.1f);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }
    }

    @Test
    void testEquals_Symmetrical() {
        DeviationRenderer renderer2 = new DeviationRenderer();
        assert renderer.equals(renderer2);
        assert renderer2.equals(renderer);
    }

    @Test
    void testEquals_DifferentAlpha() {
        DeviationRenderer renderer2 = new DeviationRenderer();
        renderer2.setAlpha(0.6f);
        assert !renderer.equals(renderer2);
    }

    @Test
    void testGetPassCount() {
        assert renderer.getPassCount() == 3;
    }

    @Test
    void testIsItemPass() {
        assert renderer.isItemPass(2);
        assert !renderer.isItemPass(1);
        assert !renderer.isItemPass(0);
    }

    @Test
    void testIsLinePass() {
        assert renderer.isLinePass(1);
        assert !renderer.isLinePass(2);
        assert !renderer.isLinePass(0);
    }

    @Test
    void testDrawItem_Pass0_DrawWithAlpha() {
        renderer = spy(renderer);
        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(dataset.getItemCount(series)).thenReturn(1);
        when(dataset.getXValue(series, item)).thenReturn(1.0);
        when(dataset.getStartYValue(series, item)).thenReturn(2.0);
        when(dataset.getEndYValue(series, item)).thenReturn(3.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(rangeAxis.valueToJava2D(3.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(renderer.getItemFillPaint(series, item)).thenReturn(null);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));

        State state = new State(info);
        state.lowerCoordinates = new ArrayList<>();
        state.upperCoordinates = new ArrayList<>();
        state.lowerCoordinates.add(new double[] {200.0, 100.0});
        state.upperCoordinates.add(new double[] {150.0, 100.0});

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis,
                rangeAxis, dataset, series, item, crosshairState, 0);

        verify(g2).setComposite(any(AlphaComposite.class));
        verify(g2).setPaint(null);
        verify(g2).fill(any());
        verify(g2).setComposite(any());
    }
}