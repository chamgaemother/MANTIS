import static org.junit.jupiter.api.Assertions.*;
import org.jfree.data.statistics.Regression;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

public class RegressionTest {

    @Test
    public void testPolynomialRegressionWithNullDataset() {
        assertThrows(IllegalArgumentException.class, () -> {
            Regression.getPolynomialRegression(null, 0, 1);
        });
    }

    @Test
    public void testPolynomialRegressionWithNotEnoughData() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(1); // Less data than order + 1
        assertThrows(IllegalArgumentException.class, () -> {
            Regression.getPolynomialRegression(dataset, 0, 1);
        });
    }

    @Test
    public void testPolynomialRegressionWithNaNData() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(3.0);

        assertThrows(IllegalArgumentException.class, () -> {
            Regression.getPolynomialRegression(dataset, 0, 1);
        });
    }

    @Test
    public void testPolynomialRegressionWithValidData() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(3);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(2.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(3.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(5.0);

        double[] parameters = Regression.getPolynomialRegression(dataset, 0, 2);
        assertNotNull(parameters);
        assertTrue(parameters.length > 0);
    }

    @Test
    public void testPolynomialRegressionWithZeroPivot() {
        XYDataset dataset = mock(XYDataset.class);
        when(dataset.getItemCount(0)).thenReturn(4);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(4.0);
        when(dataset.getXValue(0, 2)).thenReturn(3.0);
        when(dataset.getYValue(0, 2)).thenReturn(9.0);
        when(dataset.getXValue(0, 3)).thenReturn(4.0);
        when(dataset.getYValue(0, 3)).thenReturn(16.0);

        double[] parameters = Regression.getPolynomialRegression(dataset, 0, 2);
        assertNotNull(parameters);
        assertTrue(parameters.length > 0);
    }
}