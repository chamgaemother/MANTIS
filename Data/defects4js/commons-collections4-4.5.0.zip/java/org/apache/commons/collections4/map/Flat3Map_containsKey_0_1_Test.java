package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_containsKey_0_1_Test {

    @Test
    @DisplayName("When delegateMap is not null and contains the key")
    public void TC01_containsKey_delegateMapContainsKey() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Access and set 'delegateMap' via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        Map<Object, Object> realDelegateMapWithKey = new HashMap<>();
        Object existingKey = new Object();
        realDelegateMapWithKey.put(existingKey, new Object());
        delegateMapField.set(map, realDelegateMapWithKey);

        Object key = existingKey;

        // WHEN
        boolean result = map.containsKey(key);

        // THEN
        assertTrue(result, "Expected containsKey to return true when delegateMap contains the key");
    }

    @Test
    @DisplayName("When delegateMap is not null and does not contain the key")
    public void TC02_containsKey_delegateMapDoesNotContainKey() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Access and set 'delegateMap' via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        Map<Object, Object> realDelegateMapWithoutKey = new HashMap<>();
        Object nonExistingKey = new Object();
        // Do not put the key in the map
        delegateMapField.set(map, realDelegateMapWithoutKey);

        Object key = nonExistingKey;

        // WHEN
        boolean result = map.containsKey(key);

        // THEN
        assertFalse(result, "Expected containsKey to return false when delegateMap does not contain the key");
    }

    @Test
    @DisplayName("When delegateMap is null and key is null with size=3 and key3 is null")
    public void TC03_containsKey_delegateMapNull_keyNull_size3_key3Null() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Access and set 'delegateMap' via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set 'size' to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set 'key3' to null
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);

        Object key = null;

        // WHEN
        boolean result = map.containsKey(key);

        // THEN
        assertTrue(result, "Expected containsKey to return true when delegateMap is null, key is null, size=3, and key3 is null");
    }

    @Test
    @DisplayName("When delegateMap is null, key is null, size=3, key3 not null, and key2 is null")
    public void TC04_containsKey_delegateMapNull_keyNull_size3_key3NotNull_key2Null() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Access and set 'delegateMap' via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set 'size' to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set 'key3' to a non-null value
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object someKey = new Object();
        key3Field.set(map, someKey);

        // Set 'key2' to null
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        Object key = null;

        // WHEN
        boolean result = map.containsKey(key);

        // THEN
        assertTrue(result, "Expected containsKey to return true when delegateMap is null, key is null, size=3, key3 is not null, and key2 is null");
    }

    @Test
    @DisplayName("When delegateMap is null, key is null, size=3, key3 and key2 not null, and key1 is null")
    public void TC05_containsKey_delegateMapNull_keyNull_size3_key3Key2NotNull_key1Null() throws Exception {
        // GIVEN
        Flat3Map map = new Flat3Map();

        // Access and set 'delegateMap' via reflection
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set 'size' to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set 'key3' to a non-null value
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object someKey3 = new Object();
        key3Field.set(map, someKey3);

        // Set 'key2' to a non-null value
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object someKey2 = new Object();
        key2Field.set(map, someKey2);

        // Set 'key1' to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        Object key = null;

        // WHEN
        boolean result = map.containsKey(key);

        // THEN
        assertTrue(result, "Expected containsKey to return true when delegateMap is null, key is null, size=3, key3 and key2 are not null, and key1 is null");
    }
}