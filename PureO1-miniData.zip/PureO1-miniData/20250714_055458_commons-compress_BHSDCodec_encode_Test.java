package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.compress.harmony.pack200.BHSDCodec;
import org.apache.commons.compress.harmony.pack200.Pack200Exception;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class BHSDCodecTest {

    @Nested
    @DisplayName("Encode Method Tests")
    class EncodeTests {

        @Test
        @DisplayName("Encode should throw Pack200Exception when value is not encodable")
        void testEncodeValueNotEncodable() {
            BHSDCodec codec = new BHSDCodec(1, 256);
            int value = 257; // For (1,256), max encodable is 255
            assertThrows(Pack200Exception.class, () -> codec.encode(value, 0));
        }

        @ParameterizedTest(name = "Encode unsigned, non-delta: value={0}")
        @CsvSource({
            "0",
            "1",
            "255"
        })
        void testEncodeUnsignedNonDelta(int value) throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(1, 256, 0, 0);
            byte[] expected = new byte[] { (byte) value };
            assertArrayEquals(expected, codec.encode(value, 0));
        }

        @Test
        @DisplayName("Encode unsigned, delta: value - last within range")
        void testEncodeUnsignedDelta() throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(2, 100, 0, 1);
            int value = 150;
            int last = 100;
            byte[] encoded = codec.encode(value, last);
            // Expected delta = 50, encoded as [50]
            assertArrayEquals(new byte[] { 50 }, Arrays.copyOf(encoded, 1));
        }

        @ParameterizedTest(name = "Encode signed S=1, positive value={0}")
        @CsvSource({
            "0",
            "1",
            "1234"
        })
        void testEncodeSignedS1Positive(int value) throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(2, 100, 1, 0);
            byte[] encoded = codec.encode(value, 0);
            assertNotNull(encoded);
            assertTrue(encoded.length <= 2);
        }

        @ParameterizedTest(name = "Encode signed S=1, negative value={0}")
        @CsvSource({
            "-1",
            "-1234"
        })
        void testEncodeSignedS1Negative(int value) throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(2, 100, 1, 0);
            byte[] encoded = codec.encode(value, 0);
            assertNotNull(encoded);
            assertTrue(encoded.length <= 2);
        }

        @ParameterizedTest(name = "Encode signed S=2, positive value={0}")
        @CsvSource({
            "0",
            "1",
            "1234"
        })
        void testEncodeSignedS2Positive(int value) throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(2, 100, 2, 0);
            byte[] encoded = codec.encode(value, 0);
            assertNotNull(encoded);
            assertTrue(encoded.length <= 2);
        }

        @ParameterizedTest(name = "Encode signed S=2, negative value={0}")
        @CsvSource({
            "-1",
            "-1234"
        })
        void testEncodeSignedS2Negative(int value) throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(2, 100, 2, 0);
            byte[] encoded = codec.encode(value, 0);
            assertNotNull(encoded);
            assertTrue(encoded.length <= 2);
        }

        @Test
        @DisplayName("Encode unsigned with negative z should throw Pack200Exception")
        void testEncodeUnsignedNegativeZ() {
            BHSDCodec codec = new BHSDCodec(2, 100, 0, 0);
            int value = -1;
            assertThrows(Pack200Exception.class, () -> codec.encode(value, 0));
        }

        @Test
        @DisplayName("Encode signed, z < Integer.MIN_VALUE")
        void testEncodeSignedZLessThanIntegerMin() throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(3, 10, 1, 0);
            int value = Integer.MIN_VALUE;
            byte[] encoded = codec.encode(value, 0);
            assertNotNull(encoded);
            assertTrue(encoded.length <= 3);
        }

        @Test
        @DisplayName("Encode signed, z > Integer.MAX_VALUE")
        void testEncodeSignedZGreaterThanIntegerMax() throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(3, 10, 1, 0);
            int value = Integer.MAX_VALUE;
            byte[] encoded = codec.encode(value, 0);
            assertNotNull(encoded);
            assertTrue(encoded.length <= 3);
        }

        @Test
        @DisplayName("Encode results in negative z after processing")
        void testEncodeFinalZNegative() {
            BHSDCodec codec = new BHSDCodec(2, 100, 1, 0) {
                @Override
                public boolean encodes(long value) {
                    return true;
                }
            };
            int value = Integer.MIN_VALUE;
            int last = 0;
            assertThrows(Pack200Exception.class, () -> codec.encode(value, last));
        }

        @ParameterizedTest(name = "Encode loop with z < l: b={0}, h={1}, s={2}, d={3}, value={4}")
        @CsvSource({
            "2, 100, 0, 0, 50",
            "3, 10, 1, 0, 5"
        })
        void testEncodeLoopZLessThanL(int b, int h, int s, int d, int value) throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(b, h, s, d);
            byte[] encoded = codec.encode(value, 0);
            assertEquals(1, encoded.length);
            assertEquals((byte) value, encoded[0]);
        }

        @ParameterizedTest(name = "Encode loop with z >= l: b={0}, h={1}, s={2}, d={3}, value={4}")
        @CsvSource({
            "2, 100, 0, 0, 150",
            "3, 10, 1, 0, 15"
        })
        void testEncodeLoopZGreaterThanOrEqualL(int b, int h, int s, int d, int value) throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(b, h, s, d);
            byte[] encoded = codec.encode(value, 0);
            assertTrue(encoded.length > 1);
        }

        @Test
        @DisplayName("Encode with maximum B=5 and various H")
        void testEncodeMaxB() throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(5, 10, 0, 0);
            int value = 99999;
            byte[] encoded = codec.encode(value, 0);
            assertNotNull(encoded);
            assertTrue(encoded.length <= 5);
        }

        @Test
        @DisplayName("Encode with minimum B=1 and H=256")
        void testEncodeMinB() throws Pack200Exception {
            BHSDCodec codec = new BHSDCodec(1, 256, 0, 0);
            int value = 255;
            byte[] encoded = codec.encode(value, 0);
            assertArrayEquals(new byte[] { (byte) 255 }, encoded);
        }
    }

}