package org.apache.commons.math3.stat.correlation;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class KendallsCorrelation_correlation_1_1_Test {

    @Test
    @DisplayName("correlation correctly computes negative correlation when yArray is in strictly decreasing order relative to ascending xArray")
    void TC16_negativePerfectCorrelation() {
        // GIVEN
        double[] xArray = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] yArray = {5.0, 4.0, 3.0, 2.0, 1.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertEquals(-1.0, result, 1e-10, "Correlation should be -1.0 indicating perfect negative correlation");
    }

    @Test
    @DisplayName("correlation returns NaN when all pairs in xArray and yArray are identical")
    void TC17_allIdenticalPairs() {
        // GIVEN
        double[] xArray = {2.0, 2.0, 2.0};
        double[] yArray = {3.0, 3.0, 3.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertTrue(Double.isNaN(result), "Correlation should be NaN due to division by zero in denominator");
    }

    @Test
    @DisplayName("correlation correctly computes correlation with multiple tied groups in xArray and yArray")
    void TC18_multipleTiedGroups() {
        // GIVEN
        double[] xArray = {1.0, 1.0, 2.0, 2.0, 3.0, 3.0};
        double[] yArray = {1.0, 2.0, 2.0, 3.0, 3.0, 4.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertEquals(1.0, result, 1e-10, "Correlation should account for multiple tied groups");
    }

    @Test
    @DisplayName("correlation correctly computes correlation with exactly two elements causing minimal iterations in loops")
    void TC19_twoElementMinimalIterations() {
        // GIVEN
        double[] xArray = {1.0, 2.0};
        double[] yArray = {2.0, 1.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertEquals(-1.0, result, 1e-10, "Correlation should be -1.0 for perfectly discordant two-element arrays");
    }

    @Test
    @DisplayName("correlation correctly handles arrays with multiple duplicates in yArray but unique xArray")
    void TC20_multipleYDuplicates() {
        // GIVEN
        double[] xArray = {1.0, 2.0, 3.0, 4.0};
        double[] yArray = {2.0, 2.0, 3.0, 3.0};

        // WHEN
        KendallsCorrelation kc = new KendallsCorrelation();
        double result = kc.correlation(xArray, yArray);

        // THEN
        assertEquals(0.3333333333333333, result, 1e-10, "Correlation should account for multiple y duplicates");
    }
}