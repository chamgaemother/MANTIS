package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Random;

public class RandomStringUtils_random_0_8_Test {

    @Test
    @DisplayName("random(count, start=0, end=0, letters=false, numbers=false, chars=someChars, random) generates string from provided chars array")
    public void TC36() {
        // Given
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = new char[]{'x', 'y', 'z'};
        Random random = new Random();

        // When
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // Then
        assertEquals(5, result.length(), "Result length should be equal to count");
        for (char c : result.toCharArray()) {
            assertTrue(c == 'x' || c == 'y' || c == 'z', "Character " + c + " is not in the allowed chars array");
        }
    }
}