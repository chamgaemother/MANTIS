package org.jfree.chart.renderer.xy;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/**
 * Test class for {@link XYShapeRenderer#drawItem}.
 */
public class XYShapeRenderer_drawItem_2_1_Test {

//     @Test
//     @DisplayName("drawItem with pass=1, guideLinesVisible=false, orientation is HORIZONTAL, and shape intersects dataArea")
//     void TC06_drawItem_pass1_guideLinesFalse_orientationHorizontal_shapeIntersectsDataArea() {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
//         renderer.setGuideLinesVisible(false);
//         
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(10.0);
//         when(dataset.getYValue(0, 0)).thenReturn(20.0);
//         
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         
//         Graphics2D g2 = mock(Graphics2D.class);
//         
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(plot);
//         
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         
        // Act
//         renderer.drawItem(g2, null, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
//         
        // Assert
        // Correct assertion for pass=1, no guide lines, should fill shape
//         verify(g2, times(1)).fill(any(Shape.class));
//         verify(g2, atLeastOnce()).draw(any(Shape.class));
//     }

//     @Test
//     @DisplayName("drawItem with pass=1, guideLinesVisible=false, orientation is VERTICAL, and shape intersects dataArea")
//     void TC07_drawItem_pass1_guideLinesFalse_orientationVertical_shapeIntersectsDataArea() {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
//         renderer.setGuideLinesVisible(false);
//         
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getXValue(1, 1)).thenReturn(15.0);
//         when(dataset.getYValue(1, 1)).thenReturn(25.0);
//         
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         
//         Graphics2D g2 = mock(Graphics2D.class);
//         
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(plot);
//         
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         
        // Act
//         renderer.drawItem(g2, null, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, 1);
//         
        // Assert
        // Correct assertion for pass=1, no guide lines, should fill shape
//         verify(g2, times(1)).fill(any(Shape.class));
//         verify(g2, atLeastOnce()).draw(any(Shape.class));
//     }

//     @Test
//     @DisplayName("drawItem with pass=1, guideLinesVisible=true, orientation is HORIZONTAL, method returns without drawing guide lines")
//     void TC08_drawItem_pass1_guideLinesTrue_orientationHorizontal_noGuideLinesDrawn() {
        // Arrange
//         XYShapeRenderer renderer = new XYShapeRenderer();
//         renderer.setGuideLinesVisible(true);
//         
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(20.0);
//         when(dataset.getYValue(0, 0)).thenReturn(30.0);
//         
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         
//         Graphics2D g2 = mock(Graphics2D.class);
//         
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(plot);
//         
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         
        // Act
//         renderer.drawItem(g2, null, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
//         
        // Assert
//         verify(g2, never()).draw(any(Line2D.class));  // No guide lines drawn
//         verify(g2, times(1)).fill(any(Shape.class));        // Shape is filled
//     }

//     @Test
//     @DisplayName("drawItem with pass=1, guideLinesVisible=false, shape does not intersect dataArea, no drawing occurs")
//     void TC09_drawItem_pass1_guideLinesFalse_shapeDoesNotIntersectDataArea_noDrawingOccurs() {
        // Arrange
//         XYShapeRenderer renderer = spy(new XYShapeRenderer());
//         renderer.setGuideLinesVisible(false);
//         
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
//         
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         
//         XYDataset dataset = mock(XYDataset.class);
//         when(dataset.getXValue(2, 2)).thenReturn(25.0);
//         when(dataset.getYValue(2, 2)).thenReturn(35.0);
//         
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         
//         Graphics2D g2 = mock(Graphics2D.class);
//         
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(plot);
//         
//         CrosshairState crosshairState = mock(CrosshairState.class);
//         
        // Use spy to stub getItemShape and return a predictable shape
//         Shape shape = new Rectangle2D.Double(200, 200, 10, 10);  // Real shape, does not intersect dataArea
//         doReturn(shape).when(renderer).getItemShape(2, 2);
//         
        // Act
//         renderer.drawItem(g2, null, dataArea, info, plot, domainAxis, rangeAxis, dataset, 2, 2, crosshairState, 1);
//         
        // Assert
//         verify(g2, never()).fill(any(Shape.class));
//         verify(g2, never()).draw(any(Shape.class));  // No drawing occurs
//     }
}