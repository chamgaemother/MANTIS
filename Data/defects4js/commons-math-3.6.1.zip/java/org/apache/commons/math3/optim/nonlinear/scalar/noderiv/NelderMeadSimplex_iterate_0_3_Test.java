package org.apache.commons.math3.optim.nonlinear.scalar.noderiv;

import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optim.PointValuePair;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.Mockito;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class NelderMeadSimplex_iterate_0_3_Test {

    @Test
    @DisplayName("iterate when replaceWorstPoint throws exception")
    void TC11_iterate_replaceWorstPoint_throws_exception() throws Exception {
        // Initialize NelderMeadSimplex with valid points using reflection
        NelderMeadSimplex simplex = new NelderMeadSimplex(new double[] {1.0, 1.0});

        // Mock MultivariateFunction and Comparator
        MultivariateFunction function = mock(MultivariateFunction.class);
        Comparator<PointValuePair> comparator = mock(Comparator.class);

        // Use reflection to mock replaceWorstPoint to throw an exception
        Method replaceWorstPointMethod = NelderMeadSimplex.class.getDeclaredMethod("replaceWorstPoint", PointValuePair.class, Comparator.class);
        replaceWorstPointMethod.setAccessible(true);

        NelderMeadSimplex simplexSpy = Mockito.spy(simplex);
        doThrow(new RuntimeException("Mocked exception"))
                .when(simplexSpy).replaceWorstPoint(any(PointValuePair.class), any(Comparator.class));

        // Execute and assert exception is propagated
        Executable executable = () -> simplexSpy.iterate(function, comparator);
        RuntimeException thrown = assertThrows(RuntimeException.class, executable);
        assertEquals("Mocked exception", thrown.getMessage());
    }

    @Test
    @DisplayName("iterate with null MultivariateFunction throws NullPointerException")
    void TC12_iterate_null_MultivariateFunction_throws_NPE() throws Exception {
        // Initialize NelderMeadSimplex with valid points using reflection
        NelderMeadSimplex simplex = new NelderMeadSimplex(new double[] {1.0, 1.0});

        // Set MultivariateFunction to null
        MultivariateFunction function = null;
        Comparator<PointValuePair> comparator = mock(Comparator.class);

        // Execute and assert NullPointerException is thrown
        Executable executable = () -> simplex.iterate(function, comparator);
        assertThrows(NullPointerException.class, executable);
    }

    @Test
    @DisplayName("iterate with null Comparator throws NullPointerException")
    void TC13_iterate_null_Comparator_throws_NPE() throws Exception {
        // Initialize NelderMeadSimplex with valid points using reflection
        NelderMeadSimplex simplex = new NelderMeadSimplex(new double[] {1.0, 1.0});

        // Set Comparator to null
        MultivariateFunction function = mock(MultivariateFunction.class);
        Comparator<PointValuePair> comparator = null;

        // Execute and assert NullPointerException is thrown
        Executable executable = () -> simplex.iterate(function, comparator);
        assertThrows(NullPointerException.class, executable);
    }

    @Test
    @DisplayName("iterate with evaluationFunction returning NaN throws IllegalArgumentException")
    void TC14_iterate_evaluationFunction_returns_NaN_throws_IAE() throws Exception {
        // Initialize NelderMeadSimplex with valid points using reflection
        NelderMeadSimplex simplex = new NelderMeadSimplex(new double[] {1.0, 1.0});

        // Mock MultivariateFunction to return NaN
        MultivariateFunction function = coordinates -> Double.NaN;
        Comparator<PointValuePair> comparator = mock(Comparator.class);

        // Execute and assert IllegalArgumentException is thrown
        Executable executable = () -> simplex.iterate(function, comparator);
        assertThrows(IllegalArgumentException.class, executable);
    }

    @Test
    @DisplayName("iterate with all simplex points being identical triggers shrink")
    void TC15_iterate_all_points_identical_triggers_shrink() throws Exception {
        // Initialize NelderMeadSimplex with all points identical
        double[] initialPoint = {1.0, 1.0};
        NelderMeadSimplex simplex = new NelderMeadSimplex(initialPoint);

        // Use reflection to set all points identical
        Method setPointMethod = NelderMeadSimplex.class.getDeclaredMethod("setPoint", int.class, PointValuePair.class);
        setPointMethod.setAccessible(true);
        for (int i = 0; i <= simplex.getDimension(); i++) {
            setPointMethod.invoke(simplex, i, new PointValuePair(initialPoint, 0.0, false));
        }

        // Mock MultivariateFunction and Comparator
        MultivariateFunction function = mock(MultivariateFunction.class);
        Comparator<PointValuePair> comparator = mock(Comparator.class);
        when(comparator.compare(any(PointValuePair.class), any(PointValuePair.class))).thenReturn(0);
        when(function.value(any(double[].class))).thenReturn(0.0);

        // Execute the iterate method
        simplex.iterate(function, comparator);

        // Assert shrink operation by verifying setPoint was called appropriately
        for (int i = 1; i <= simplex.getDimension(); i++) {
            PointValuePair point = simplex.getPoint(i);
            assertArrayEquals(initialPoint, point.getPointRef(), "Point should be shrunk towards the smallest point");
        }
    }
}