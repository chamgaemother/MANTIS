// package org.apache.commons.math3.geometry.euclidean.threed;
// import java.lang.reflect.*;
// import static org.mockito.Mockito.*;
// import java.io.*;
// import java.util.*;
// 
// import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
// import org.apache.commons.math3.RealFieldElement;
// import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
// import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
// import org.apache.commons.math3.field.Binary64;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.junit.jupiter.api.Assertions.assertThrows;
// 
// public class FieldRotation_getAngles_2_6_Test {
// 
//     @Test
//     @DisplayName("getAngles called with RotationOrder.ZYZ and RotationConvention.FRAME_TRANSFORM, expecting CardanEulerSingularityException")
//     public void TC31_getAngles_ZYZ_FRAME_TRANSFORM_throwsException() {
//         // Initialize FieldRotation with parameters causing getV2().getZ() to be out of bounds
//         FieldRotation<Binary64> rotation = new FieldRotation<>(
//                 new Binary64(0.0),  // Ensure the quaternion is normalized
//                 new Binary64(1.0),
//                 new Binary64(0.0),
//                 new Binary64(0.0),
//                 false);
// 
//         RotationOrder order = RotationOrder.ZYZ;
//         RotationConvention convention = RotationConvention.FRAME_TRANSFORM;
// 
//         // Assert that CardanEulerSingularityException is thrown
//         assertThrows(CardanEulerSingularityException.class, () -> {
//             rotation.getAngles(order, convention);
//         });
//     }
// }