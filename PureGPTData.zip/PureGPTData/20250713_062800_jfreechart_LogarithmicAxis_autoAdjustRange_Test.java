import static org.junit.jupiter.api.Assertions.assertThrows;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.data.Range;
import org.jfree.chart.plot.ValueAxisPlot;
import org.jfree.chart.plot.Plot;
import org.junit.jupiter.api.Test;

class LogarithmicAxisTest {

    private class TestValueAxisPlot implements ValueAxisPlot {
        private final Range range;

        public TestValueAxisPlot(Range range) {
            this.range = range;
        }

        @Override
        public Range getDataRange(LogarithmicAxis axis) {
            return this.range;
        }

        // No other implementations are needed for testing LogarithmicAxis
    }

    @Test
    void testAutoAdjustRangeNoPlot() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.autoAdjustRange();
        // No exceptions thrown and no effect as plot is null
    }

    @Test
    void testAutoAdjustRangeNullRange() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setPlot(new Plot() {
            @Override
            public String getPlotType() {
                return "Test Plot";
            }
        });

        axis.autoAdjustRange();
        assertThrows(RuntimeException.class, () -> axis.autoAdjustRange());
    }
    
    @Test
    void testAutoAdjustRangeWithData() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setPlot(new TestValueAxisPlot(new Range(1.0, 100.0)));
        axis.autoAdjustRange();
        // Axis should now be adjusted within the data range
    }

    @Test
    void testAutoAdjustRangeWithNegativeValuesNotAllowed() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setPlot(new TestValueAxisPlot(new Range(-10.0, 10.0)));
        assertThrows(RuntimeException.class, axis::autoAdjustRange);
    }
    
    @Test
    void testAutoAdjustRangeWithNegativeValuesAllowed() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(true);
        axis.setPlot(new TestValueAxisPlot(new Range(-10.0, 100.0)));
        axis.autoAdjustRange();
        // Should not throw an exception
    }

    @Test
    void testAutoAdjustRangeWithZeroData() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setPlot(new TestValueAxisPlot(new Range(0, 0)));
        assertThrows(RuntimeException.class, axis::autoAdjustRange);
    }
    
    @Test
    void testAllowNegativesFlagTrueWithSmallValues() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAllowNegativesFlag(true);
        axis.setPlot(new TestValueAxisPlot(new Range(0.1, 1.0)));
        axis.autoAdjustRange();
        // Should adjust the range within given limits and not throw any exception
    }

    @Test
    void testAutoRangeNextLogFlag() {
        LogarithmicAxis axis = new LogarithmicAxis("Test Axis");
        axis.setAutoRangeNextLogFlag(true);
        axis.setPlot(new TestValueAxisPlot(new Range(15.0, 55.0)));
        axis.autoAdjustRange();
        // Axis should adjust such that it begins at a 10^n value due to autoRangeNextLogFlag being true
    }
}