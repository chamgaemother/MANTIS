package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringUtilsTest {

    @Test
    void testIndexOfDifference_NullArray() {
        int result = StringUtils.indexOfDifference((CharSequence[]) null);
        assertEquals(-1, result);
    }

    @Test
    void testIndexOfDifference_EmptyArray() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{});
        assertEquals(-1, result);
    }

    @Test
    void testIndexOfDifference_SingleElement() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc"});
        assertEquals(-1, result);
    }

    @Test
    void testIndexOfDifference_AllNullStrings() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{null, null});
        assertEquals(-1, result);
    }

    @Test
    void testIndexOfDifference_AllEmptyStrings() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"", ""});
        assertEquals(-1, result);
    }

    @Test
    void testIndexOfDifference_SomeNullStrings() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", null, "abc"});
        assertEquals(0, result);
    }

    @Test
    void testIndexOfDifference_ShortestStrLenZero() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"", "abc"});
        assertEquals(0, result);
    }

    @Test
    void testIndexOfDifference_FirstDifferenceAt0() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", "xbc"});
        assertEquals(0, result);
    }

    @Test
    void testIndexOfDifference_FirstDifferenceAtMid() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abXc", "abYc"});
        assertEquals(2, result);
    }

    @Test
    void testIndexOfDifference_FirstDifferenceAtEnd() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", "abd"});
        assertEquals(2, result);
    }

    @Test
    void testIndexOfDifference_NoDifferenceSameLengths() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", "abc"});
        assertEquals(-1, result);
    }

    @Test
    void testIndexOfDifference_NoDifferenceDifferentLengths() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", "abcdef"});
        assertEquals(3, result);
    }

    @Test
    void testIndexOfDifference_MultipleStringsFirstDifference() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abcdef", "abcXef", "abcYef"});
        assertEquals(3, result);
    }

    @Test
    void testIndexOfDifference_MultipleStringsAllSameUpToShortest() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", "abcd", "abcX"});
        assertEquals(3, result);
    }

    @Test
    void testIndexOfDifference_MultipleStringsWithImmediateDifference() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", "axc", "aBc"});
        assertEquals(1, result);
    }

    @Test
    void testIndexOfDifference_MultipleStringsWithNoDifferenceAndSameLength() {
        int result = StringUtils.indexOfDifference(new CharSequence[]{"abc", "abc", "abc"});
        assertEquals(-1, result);
    }
}