import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Flat3MapTest {

    private Flat3Map<String, Integer> map;

    @BeforeEach
    void setUp() {
        map = new Flat3Map<>();
    }

    @Test
    void testRemoveFromEmptyMap() {
        assertNull(map.remove(null), "Removing from an empty map should return null.");
        assertNull(map.remove("key"), "Removing a non-existent key from an empty map should return null.");
    }

    @Test
    void testRemoveNullKey() {
        map.put(null, 1);
        assertEquals(1, map.remove(null), "Should return the value associated with the null key.");
        assertNull(map.remove(null), "Removing again should return null as the key was removed.");
    }

    @Test
    void testRemoveExistingKey() {
        map.put("key1", 10);
        map.put("key2", 20);
        assertEquals(20, map.remove("key2"), "Should return the value associated with 'key2'.");
        assertNull(map.get("key2"), "After removal, 'key2' should not exist.");
        assertEquals(10, map.get("key1"), "'key1' should still exist with its value.");
    }

    @Test
    void testRemoveNonExistentKey() {
        map.put("key1", 10);
        map.put("key2", 20);
        assertNull(map.remove("key3"), "Removing a non-existent key should return null.");
    }

    @Test
    void testRemoveSwitchOrder() {
        map.put("key1", 10);
        map.put("key2", 20);
        map.put("key3", 30);

        assertEquals(30, map.remove("key3"), "Removing 'key3' should return its value.");
        assertEquals(2, map.size(), "Size should decrease to 2 after removal.");
        
        assertEquals(20, map.remove("key2"), "Removing 'key2' should return its value.");
        assertEquals(1, map.size(), "Size should decrease to 1 after removal.");
        
        assertEquals(10, map.remove("key1"), "Removing 'key1' should return its value.");
        assertEquals(0, map.size(), "Size should decrease to 0 after all are removed.");
    }

    @Test
    void testComplexRemoveOrder() {
        map.put("key1", 10);
        map.put("key2", 20);
        map.put("key3", 30);

        // Remove the first key inserted
        assertEquals(10, map.remove("key1"), "Removing 'key1' should return 10.");
        // Check if reordering happened correctly
        assertEquals(30, map.get("key3"), "The value for 'key3' should be preserved.");
        assertEquals(20, map.get("key2"), "The value for 'key2' should be preserved.");
        
        // Remove the remaining keys
        assertEquals(30, map.remove("key3"), "Removing 'key3' should return 30.");
        assertEquals(20, map.remove("key2"), "Removing 'key2' should return 20.");
        assertEquals(0, map.size(), "Size should be 0 after all entries are removed.");
    }
    
    @Test
    void testRemoveInDelegationMode() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, i);
        }

        assertEquals(3, map.remove("key3"), "Removing 'key3' in delegate mode should return its value.");
        assertEquals(4, map.remove("key4"), "Removing 'key4' should still work as expected.");
        assertEquals(2, map.size(), "Size should be 2 after two removals in delegation mode.");
    }
}