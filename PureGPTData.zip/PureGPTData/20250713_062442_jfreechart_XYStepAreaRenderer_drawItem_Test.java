import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.XYStepAreaRenderer;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class XYStepAreaRendererTest {

    private XYStepAreaRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new XYStepAreaRenderer(XYStepAreaRenderer.AREA_AND_SHAPES);
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0.0, 0.0, 800.0, 600.0);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = mock(CrosshairState.class);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                .thenAnswer(invocation -> (Double) invocation.getArgument(0));
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                .thenAnswer(invocation -> 600.0 - (Double) invocation.getArgument(0));
    }

    @Test
    public void testDrawItem_NullYValue() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getXValue(0, 1)).thenReturn(200.0);
        when(dataset.getYValue(0, 1)).thenReturn(200.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 1);

        verify(g2, never()).draw(any());
    }

    @Test
    public void testDrawItem_LastItemInSeries() {
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 1)).thenReturn(200.0);
        when(dataset.getYValue(0, 1)).thenReturn(200.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 1);

        verify(g2).fill(any());
    }

    @Test
    public void testDrawItem_WithShapesVisible() {
        renderer.setShapesVisible(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(100.0);
        when(dataset.getYValue(0, 0)).thenReturn(100.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 0, crosshairState, 0);

        verify(g2).fill(any());
    }

    @Test
    public void testDrawItem_WithOutline() {
        renderer.setOutline(true);
        renderer.setPlotArea(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 1)).thenReturn(200.0);
        when(dataset.getYValue(0, 1)).thenReturn(200.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 1);

        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    public void testDrawItem_DifferentPlotOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 1)).thenReturn(200.0);
        when(dataset.getYValue(0, 1)).thenReturn(200.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 1);

        verify(g2).fill(any());
    }

    @Test
    public void testDrawItem_WithInvalidStepPoint() {
        renderer.setStepPoint(0.5);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 1)).thenReturn(200.0);
        when(dataset.getYValue(0, 1)).thenReturn(200.0);

        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis,
                dataset, 0, 1, crosshairState, 1);

        verify(g2).fill(any());
    }
}