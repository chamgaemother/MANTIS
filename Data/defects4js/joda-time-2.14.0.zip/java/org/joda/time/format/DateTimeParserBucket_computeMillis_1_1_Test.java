package org.joda.time.format;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Locale;

import org.joda.time.Chronology;
import org.joda.time.DateTimeZone;
import org.joda.time.IllegalInstantException;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.DateTimeFieldType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DateTimeParserBucket_computeMillis_1_1_Test {

    @Test
    @DisplayName("computeMillis with iSavedFieldsCount=10 triggers insertion sort in sort method")
    void TC15_computeMillis_InsertionSort() throws Exception {
        // GIVEN
        Chronology chrono = ISOChronology.getInstance();
        Locale locale = Locale.getDefault();
        long initialMillis = 1609459200000L; // 2021-01-01T00:00:00Z
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, 2000);

        // Save 10 dayOfMonth fields
        for (int i = 0; i < 10; i++) {
            bucket.saveField(DateTimeFieldType.dayOfMonth(), i + 1);
        }

        // Use reflection to set iSavedFieldsCount = 10 and iSavedFieldsShared = false
        Field savedFieldsCountField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
        savedFieldsCountField.setAccessible(true);
        savedFieldsCountField.setInt(bucket, 10);

        Field savedFieldsSharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
        savedFieldsSharedField.setAccessible(true);
        savedFieldsSharedField.setBoolean(bucket, false);

        // WHEN
        long millis = bucket.computeMillis(false, null);

        // THEN
        long expectedMillis = 1610236800000L; // 2021-01-10T00:00:00Z
        assertEquals(expectedMillis, millis, "Millis should be correctly computed using insertion sort");
    }

    @Test
    @DisplayName("computeMillis with iSavedFieldsCount=11 triggers Arrays.sort in sort method")
    void TC16_computeMillis_ArraysSort() throws Exception {
        // GIVEN
        Chronology chrono = ISOChronology.getInstance();
        Locale locale = Locale.getDefault();
        long initialMillis = 1609459200000L; // 2021-01-01T00:00:00Z
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, 2000);

        // Save 11 dayOfMonth fields
        for (int i = 0; i < 11; i++) {
            bucket.saveField(DateTimeFieldType.dayOfMonth(), i + 1);
        }

        // Use reflection to set iSavedFieldsCount = 11 and iSavedFieldsShared = false
        Field savedFieldsCountField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
        savedFieldsCountField.setAccessible(true);
        savedFieldsCountField.setInt(bucket, 11);

        Field savedFieldsSharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
        savedFieldsSharedField.setAccessible(true);
        savedFieldsSharedField.setBoolean(bucket, false);

        // WHEN
        long millis = bucket.computeMillis(false, null);

        // THEN
        long expectedMillis = 1610323200000L; // 2021-01-11T00:00:00Z
        assertEquals(expectedMillis, millis, "Millis should be correctly computed using Arrays.sort");
    }

    @Test
    @DisplayName("computeMillis with both iOffset and iZone set leads to IllegalInstantException")
    void TC17_computeMillis_ConflictingOffsetAndZone() throws Exception {
        // GIVEN
        Chronology chrono = ISOChronology.getInstance();
        Locale locale = Locale.getDefault();
        long initialMillis = 1615680000000L; // 2021-03-14T00:00:00Z
        DateTimeParserBucket bucket = new DateTimeParserBucket(initialMillis, chrono, locale, null, 2000);

        // Use reflection to set iOffset to 3600000 (1 hour) and iZone to a conflicting zone (UTC)
        Field offsetField = DateTimeParserBucket.class.getDeclaredField("iOffset");
        offsetField.setAccessible(true);
        offsetField.set(bucket, 3600000); // +1 hour in milliseconds

        Field zoneField = DateTimeParserBucket.class.getDeclaredField("iZone");
        zoneField.setAccessible(true);
        zoneField.set(bucket, DateTimeZone.forOffsetMillis(0)); // UTC, which conflicts with iOffset

        // WHEN & THEN
        IllegalInstantException exception = assertThrows(IllegalInstantException.class, () -> {
            bucket.computeMillis(false, "2021-03-14");
        }, "Expected computeMillis to throw IllegalInstantException due to conflicting iOffset and iZone");

        assertTrue(exception.getMessage().contains("Illegal instant due to time zone offset transition"), "Exception message should indicate illegal instant due to time zone offset transition");
    }
}