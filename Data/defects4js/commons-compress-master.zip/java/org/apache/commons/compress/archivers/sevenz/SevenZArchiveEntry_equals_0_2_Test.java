package org.apache.commons.compress.archivers.sevenz;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
;

public class SevenZArchiveEntry_equals_0_2_Test {

    @Test
    @DisplayName("equals called with different hasStream field returns false")
    public void TC06() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Set 'name' field
        Field nameField = SevenZArchiveEntry.class.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(entry1, "testName");
        nameField.set(entry2, "testName");

        // Set 'hasStream' field (different)
        Field hasStreamField = SevenZArchiveEntry.class.getDeclaredField("hasStream");
        hasStreamField.setAccessible(true);
        hasStreamField.set(entry1, true);
        hasStreamField.set(entry2, false);

        // Set 'isDirectory' field
        Field isDirectoryField = SevenZArchiveEntry.class.getDeclaredField("isDirectory");
        isDirectoryField.setAccessible(true);
        isDirectoryField.set(entry1, false);
        isDirectoryField.set(entry2, false);

        // Set 'isAntiItem' field
        Field isAntiItemField = SevenZArchiveEntry.class.getDeclaredField("isAntiItem");
        isAntiItemField.setAccessible(true);
        isAntiItemField.set(entry1, false);
        isAntiItemField.set(entry2, false);

        // Set 'hasCreationDate' field
        Field hasCreationDateField = SevenZArchiveEntry.class.getDeclaredField("hasCreationDate");
        hasCreationDateField.setAccessible(true);
        hasCreationDateField.set(entry1, false);
        hasCreationDateField.set(entry2, false);

        // Set 'hasLastModifiedDate' field
        Field hasLastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate");
        hasLastModifiedDateField.setAccessible(true);
        hasLastModifiedDateField.set(entry1, false);
        hasLastModifiedDateField.set(entry2, false);

        // Set 'hasAccessDate' field
        Field hasAccessDateField = SevenZArchiveEntry.class.getDeclaredField("hasAccessDate");
        hasAccessDateField.setAccessible(true);
        hasAccessDateField.set(entry1, false);
        hasAccessDateField.set(entry2, false);

        // Set 'creationDate' field
        Field creationDateField = SevenZArchiveEntry.class.getDeclaredField("creationDate");
        creationDateField.setAccessible(true);
        FileTime creationDate = FileTime.fromMillis(1000);
        creationDateField.set(entry1, creationDate);
        creationDateField.set(entry2, creationDate);

        // Set 'lastModifiedDate' field
        Field lastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("lastModifiedDate");
        lastModifiedDateField.setAccessible(true);
        FileTime lastModifiedDate = FileTime.fromMillis(1000);
        lastModifiedDateField.set(entry1, lastModifiedDate);
        lastModifiedDateField.set(entry2, lastModifiedDate);

        // Set 'accessDate' field
        Field accessDateField = SevenZArchiveEntry.class.getDeclaredField("accessDate");
        accessDateField.setAccessible(true);
        FileTime accessDate = FileTime.fromMillis(1000);
        accessDateField.set(entry1, accessDate);
        accessDateField.set(entry2, accessDate);

        // Set 'hasWindowsAttributes' field
        Field hasWindowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("hasWindowsAttributes");
        hasWindowsAttributesField.setAccessible(true);
        hasWindowsAttributesField.set(entry1, false);
        hasWindowsAttributesField.set(entry2, false);

        // Set 'windowsAttributes' field
        Field windowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("windowsAttributes");
        windowsAttributesField.setAccessible(true);
        windowsAttributesField.set(entry1, 0);
        windowsAttributesField.set(entry2, 0);

        // Set 'hasCrc' field
        Field hasCrcField = SevenZArchiveEntry.class.getDeclaredField("hasCrc");
        hasCrcField.setAccessible(true);
        hasCrcField.set(entry1, false);
        hasCrcField.set(entry2, false);

        // Set 'crc' field
        Field crcField = SevenZArchiveEntry.class.getDeclaredField("crc");
        crcField.setAccessible(true);
        crcField.setLong(entry1, 0L);
        crcField.setLong(entry2, 0L);

        // Set 'compressedCrc' field
        Field compressedCrcField = SevenZArchiveEntry.class.getDeclaredField("compressedCrc");
        compressedCrcField.setAccessible(true);
        compressedCrcField.setLong(entry1, 0L);
        compressedCrcField.setLong(entry2, 0L);

        // Set 'size' field
        Field sizeField = SevenZArchiveEntry.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setLong(entry1, 100L);
        sizeField.setLong(entry2, 100L);

        // Set 'compressedSize' field
        Field compressedSizeField = SevenZArchiveEntry.class.getDeclaredField("compressedSize");
        compressedSizeField.setAccessible(true);
        compressedSizeField.setLong(entry1, 50L);
        compressedSizeField.setLong(entry2, 50L);

        // Set 'contentMethods' field
        Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
        contentMethodsField.setAccessible(true);
        List<SevenZMethodConfiguration> contentMethods = new ArrayList<>();
        contentMethodsField.set(entry1, contentMethods);
        contentMethodsField.set(entry2, contentMethods);

        // Invoke equals and assert
        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different isDirectory field returns false")
    public void TC07() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Set 'name' field
        Field nameField = SevenZArchiveEntry.class.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(entry1, "testName");
        nameField.set(entry2, "testName");

        // Set 'hasStream' field
        Field hasStreamField = SevenZArchiveEntry.class.getDeclaredField("hasStream");
        hasStreamField.setAccessible(true);
        hasStreamField.set(entry1, true);
        hasStreamField.set(entry2, true);

        // Set 'isDirectory' field (different)
        Field isDirectoryField = SevenZArchiveEntry.class.getDeclaredField("isDirectory");
        isDirectoryField.setAccessible(true);
        isDirectoryField.set(entry1, true);
        isDirectoryField.set(entry2, false);

        // Set 'isAntiItem' field
        Field isAntiItemField = SevenZArchiveEntry.class.getDeclaredField("isAntiItem");
        isAntiItemField.setAccessible(true);
        isAntiItemField.set(entry1, false);
        isAntiItemField.set(entry2, false);

        // Set remaining fields the same
        // ... (similar to TC06)
        
        // Set 'hasCreationDate' field
        Field hasCreationDateField = SevenZArchiveEntry.class.getDeclaredField("hasCreationDate");
        hasCreationDateField.setAccessible(true);
        hasCreationDateField.set(entry1, false);
        hasCreationDateField.set(entry2, false);

        // Set 'hasLastModifiedDate' field
        Field hasLastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate");
        hasLastModifiedDateField.setAccessible(true);
        hasLastModifiedDateField.set(entry1, false);
        hasLastModifiedDateField.set(entry2, false);

        // Set 'hasAccessDate' field
        Field hasAccessDateField = SevenZArchiveEntry.class.getDeclaredField("hasAccessDate");
        hasAccessDateField.setAccessible(true);
        hasAccessDateField.set(entry1, false);
        hasAccessDateField.set(entry2, false);

        // Set 'creationDate' field
        Field creationDateField = SevenZArchiveEntry.class.getDeclaredField("creationDate");
        creationDateField.setAccessible(true);
        FileTime creationDate = FileTime.fromMillis(1000);
        creationDateField.set(entry1, creationDate);
        creationDateField.set(entry2, creationDate);

        // Set 'lastModifiedDate' field
        Field lastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("lastModifiedDate");
        lastModifiedDateField.setAccessible(true);
        FileTime lastModifiedDate = FileTime.fromMillis(1000);
        lastModifiedDateField.set(entry1, lastModifiedDate);
        lastModifiedDateField.set(entry2, lastModifiedDate);

        // Set 'accessDate' field
        Field accessDateField = SevenZArchiveEntry.class.getDeclaredField("accessDate");
        accessDateField.setAccessible(true);
        FileTime accessDate = FileTime.fromMillis(1000);
        accessDateField.set(entry1, accessDate);
        accessDateField.set(entry2, accessDate);

        // Set 'hasWindowsAttributes' field
        Field hasWindowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("hasWindowsAttributes");
        hasWindowsAttributesField.setAccessible(true);
        hasWindowsAttributesField.set(entry1, false);
        hasWindowsAttributesField.set(entry2, false);

        // Set 'windowsAttributes' field
        Field windowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("windowsAttributes");
        windowsAttributesField.setAccessible(true);
        windowsAttributesField.set(entry1, 0);
        windowsAttributesField.set(entry2, 0);

        // Set 'hasCrc' field
        Field hasCrcField = SevenZArchiveEntry.class.getDeclaredField("hasCrc");
        hasCrcField.setAccessible(true);
        hasCrcField.set(entry1, false);
        hasCrcField.set(entry2, false);

        // Set 'crc' field
        Field crcField = SevenZArchiveEntry.class.getDeclaredField("crc");
        crcField.setAccessible(true);
        crcField.setLong(entry1, 0L);
        crcField.setLong(entry2, 0L);

        // Set 'compressedCrc' field
        Field compressedCrcField = SevenZArchiveEntry.class.getDeclaredField("compressedCrc");
        compressedCrcField.setAccessible(true);
        compressedCrcField.setLong(entry1, 0L);
        compressedCrcField.setLong(entry2, 0L);

        // Set 'size' field
        Field sizeField = SevenZArchiveEntry.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setLong(entry1, 100L);
        sizeField.setLong(entry2, 100L);

        // Set 'compressedSize' field
        Field compressedSizeField = SevenZArchiveEntry.class.getDeclaredField("compressedSize");
        compressedSizeField.setAccessible(true);
        compressedSizeField.setLong(entry1, 50L);
        compressedSizeField.setLong(entry2, 50L);

        // Set 'contentMethods' field
        Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
        contentMethodsField.setAccessible(true);
        List<SevenZMethodConfiguration> contentMethods = new ArrayList<>();
        contentMethodsField.set(entry1, contentMethods);
        contentMethodsField.set(entry2, contentMethods);

        // Invoke equals and assert
        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different isAntiItem field returns false")
    public void TC08() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Set 'name' field
        Field nameField = SevenZArchiveEntry.class.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(entry1, "testName");
        nameField.set(entry2, "testName");

        // Set 'hasStream' field
        Field hasStreamField = SevenZArchiveEntry.class.getDeclaredField("hasStream");
        hasStreamField.setAccessible(true);
        hasStreamField.set(entry1, true);
        hasStreamField.set(entry2, true);

        // Set 'isDirectory' field
        Field isDirectoryField = SevenZArchiveEntry.class.getDeclaredField("isDirectory");
        isDirectoryField.setAccessible(true);
        isDirectoryField.set(entry1, false);
        isDirectoryField.set(entry2, false);

        // Set 'isAntiItem' field (different)
        Field isAntiItemField = SevenZArchiveEntry.class.getDeclaredField("isAntiItem");
        isAntiItemField.setAccessible(true);
        isAntiItemField.set(entry1, true);
        isAntiItemField.set(entry2, false);

        // Set remaining fields the same
        // ... (similar to TC06)
        
        // Set 'hasCreationDate' field
        Field hasCreationDateField = SevenZArchiveEntry.class.getDeclaredField("hasCreationDate");
        hasCreationDateField.setAccessible(true);
        hasCreationDateField.set(entry1, false);
        hasCreationDateField.set(entry2, false);

        // Set 'hasLastModifiedDate' field
        Field hasLastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate");
        hasLastModifiedDateField.setAccessible(true);
        hasLastModifiedDateField.set(entry1, false);
        hasLastModifiedDateField.set(entry2, false);

        // Set 'hasAccessDate' field
        Field hasAccessDateField = SevenZArchiveEntry.class.getDeclaredField("hasAccessDate");
        hasAccessDateField.setAccessible(true);
        hasAccessDateField.set(entry1, false);
        hasAccessDateField.set(entry2, false);

        // Set 'creationDate' field
        Field creationDateField = SevenZArchiveEntry.class.getDeclaredField("creationDate");
        creationDateField.setAccessible(true);
        FileTime creationDate = FileTime.fromMillis(1000);
        creationDateField.set(entry1, creationDate);
        creationDateField.set(entry2, creationDate);

        // Set 'lastModifiedDate' field
        Field lastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("lastModifiedDate");
        lastModifiedDateField.setAccessible(true);
        FileTime lastModifiedDate = FileTime.fromMillis(1000);
        lastModifiedDateField.set(entry1, lastModifiedDate);
        lastModifiedDateField.set(entry2, lastModifiedDate);

        // Set 'accessDate' field
        Field accessDateField = SevenZArchiveEntry.class.getDeclaredField("accessDate");
        accessDateField.setAccessible(true);
        FileTime accessDate = FileTime.fromMillis(1000);
        accessDateField.set(entry1, accessDate);
        accessDateField.set(entry2, accessDate);

        // Set 'hasWindowsAttributes' field
        Field hasWindowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("hasWindowsAttributes");
        hasWindowsAttributesField.setAccessible(true);
        hasWindowsAttributesField.set(entry1, false);
        hasWindowsAttributesField.set(entry2, false);

        // Set 'windowsAttributes' field
        Field windowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("windowsAttributes");
        windowsAttributesField.setAccessible(true);
        windowsAttributesField.set(entry1, 0);
        windowsAttributesField.set(entry2, 0);

        // Set 'hasCrc' field
        Field hasCrcField = SevenZArchiveEntry.class.getDeclaredField("hasCrc");
        hasCrcField.setAccessible(true);
        hasCrcField.set(entry1, false);
        hasCrcField.set(entry2, false);

        // Set 'crc' field
        Field crcField = SevenZArchiveEntry.class.getDeclaredField("crc");
        crcField.setAccessible(true);
        crcField.setLong(entry1, 0L);
        crcField.setLong(entry2, 0L);

        // Set 'compressedCrc' field
        Field compressedCrcField = SevenZArchiveEntry.class.getDeclaredField("compressedCrc");
        compressedCrcField.setAccessible(true);
        compressedCrcField.setLong(entry1, 0L);
        compressedCrcField.setLong(entry2, 0L);

        // Set 'size' field
        Field sizeField = SevenZArchiveEntry.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setLong(entry1, 100L);
        sizeField.setLong(entry2, 100L);

        // Set 'compressedSize' field
        Field compressedSizeField = SevenZArchiveEntry.class.getDeclaredField("compressedSize");
        compressedSizeField.setAccessible(true);
        compressedSizeField.setLong(entry1, 50L);
        compressedSizeField.setLong(entry2, 50L);

        // Set 'contentMethods' field
        Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
        contentMethodsField.setAccessible(true);
        List<SevenZMethodConfiguration> contentMethods = new ArrayList<>();
        contentMethodsField.set(entry1, contentMethods);
        contentMethodsField.set(entry2, contentMethods);

        // Invoke equals and assert
        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different hasCreationDate field returns false")
    public void TC09() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Set 'name' field
        Field nameField = SevenZArchiveEntry.class.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(entry1, "testName");
        nameField.set(entry2, "testName");

        // Set 'hasStream' field
        Field hasStreamField = SevenZArchiveEntry.class.getDeclaredField("hasStream");
        hasStreamField.setAccessible(true);
        hasStreamField.set(entry1, true);
        hasStreamField.set(entry2, true);

        // Set 'isDirectory' field
        Field isDirectoryField = SevenZArchiveEntry.class.getDeclaredField("isDirectory");
        isDirectoryField.setAccessible(true);
        isDirectoryField.set(entry1, false);
        isDirectoryField.set(entry2, false);

        // Set 'isAntiItem' field
        Field isAntiItemField = SevenZArchiveEntry.class.getDeclaredField("isAntiItem");
        isAntiItemField.setAccessible(true);
        isAntiItemField.set(entry1, false);
        isAntiItemField.set(entry2, false);

        // Set 'hasCreationDate' field (different)
        Field hasCreationDateField = SevenZArchiveEntry.class.getDeclaredField("hasCreationDate");
        hasCreationDateField.setAccessible(true);
        hasCreationDateField.set(entry1, true);
        hasCreationDateField.set(entry2, false);

        // Set remaining fields the same
        // ... (similar to TC06)
        
        // Set 'hasLastModifiedDate' field
        Field hasLastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate");
        hasLastModifiedDateField.setAccessible(true);
        hasLastModifiedDateField.set(entry1, false);
        hasLastModifiedDateField.set(entry2, false);

        // Set 'hasAccessDate' field
        Field hasAccessDateField = SevenZArchiveEntry.class.getDeclaredField("hasAccessDate");
        hasAccessDateField.setAccessible(true);
        hasAccessDateField.set(entry1, false);
        hasAccessDateField.set(entry2, false);

        // Set 'creationDate' field (different)
        Field creationDateField = SevenZArchiveEntry.class.getDeclaredField("creationDate");
        creationDateField.setAccessible(true);
        FileTime creationDate1 = FileTime.fromMillis(1000);
        FileTime creationDate2 = FileTime.fromMillis(2000);
        creationDateField.set(entry1, creationDate1);
        creationDateField.set(entry2, creationDate2);

        // Set 'lastModifiedDate' field
        Field lastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("lastModifiedDate");
        lastModifiedDateField.setAccessible(true);
        FileTime lastModifiedDate = FileTime.fromMillis(1000);
        lastModifiedDateField.set(entry1, lastModifiedDate);
        lastModifiedDateField.set(entry2, lastModifiedDate);

        // Set 'accessDate' field
        Field accessDateField = SevenZArchiveEntry.class.getDeclaredField("accessDate");
        accessDateField.setAccessible(true);
        FileTime accessDate = FileTime.fromMillis(1000);
        accessDateField.set(entry1, accessDate);
        accessDateField.set(entry2, accessDate);

        // Set 'hasWindowsAttributes' field
        Field hasWindowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("hasWindowsAttributes");
        hasWindowsAttributesField.setAccessible(true);
        hasWindowsAttributesField.set(entry1, false);
        hasWindowsAttributesField.set(entry2, false);

        // Set 'windowsAttributes' field
        Field windowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("windowsAttributes");
        windowsAttributesField.setAccessible(true);
        windowsAttributesField.set(entry1, 0);
        windowsAttributesField.set(entry2, 0);

        // Set 'hasCrc' field
        Field hasCrcField = SevenZArchiveEntry.class.getDeclaredField("hasCrc");
        hasCrcField.setAccessible(true);
        hasCrcField.set(entry1, false);
        hasCrcField.set(entry2, false);

        // Set 'crc' field
        Field crcField = SevenZArchiveEntry.class.getDeclaredField("crc");
        crcField.setAccessible(true);
        crcField.setLong(entry1, 0L);
        crcField.setLong(entry2, 0L);

        // Set 'compressedCrc' field
        Field compressedCrcField = SevenZArchiveEntry.class.getDeclaredField("compressedCrc");
        compressedCrcField.setAccessible(true);
        compressedCrcField.setLong(entry1, 0L);
        compressedCrcField.setLong(entry2, 0L);

        // Set 'size' field
        Field sizeField = SevenZArchiveEntry.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setLong(entry1, 100L);
        sizeField.setLong(entry2, 100L);

        // Set 'compressedSize' field
        Field compressedSizeField = SevenZArchiveEntry.class.getDeclaredField("compressedSize");
        compressedSizeField.setAccessible(true);
        compressedSizeField.setLong(entry1, 50L);
        compressedSizeField.setLong(entry2, 50L);

        // Set 'contentMethods' field
        Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
        contentMethodsField.setAccessible(true);
        List<SevenZMethodConfiguration> contentMethods = new ArrayList<>();
        contentMethodsField.set(entry1, contentMethods);
        contentMethodsField.set(entry2, contentMethods);

        // Invoke equals and assert
        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals called with different creationDate returns false")
    public void TC10() throws Exception {
        SevenZArchiveEntry entry1 = new SevenZArchiveEntry();
        SevenZArchiveEntry entry2 = new SevenZArchiveEntry();

        // Set 'name' field
        Field nameField = SevenZArchiveEntry.class.getDeclaredField("name");
        nameField.setAccessible(true);
        nameField.set(entry1, "testName");
        nameField.set(entry2, "testName");

        // Set 'hasStream' field
        Field hasStreamField = SevenZArchiveEntry.class.getDeclaredField("hasStream");
        hasStreamField.setAccessible(true);
        hasStreamField.set(entry1, true);
        hasStreamField.set(entry2, true);

        // Set 'isDirectory' field
        Field isDirectoryField = SevenZArchiveEntry.class.getDeclaredField("isDirectory");
        isDirectoryField.setAccessible(true);
        isDirectoryField.set(entry1, false);
        isDirectoryField.set(entry2, false);

        // Set 'isAntiItem' field
        Field isAntiItemField = SevenZArchiveEntry.class.getDeclaredField("isAntiItem");
        isAntiItemField.setAccessible(true);
        isAntiItemField.set(entry1, false);
        isAntiItemField.set(entry2, false);

        // Set 'hasCreationDate' field
        Field hasCreationDateField = SevenZArchiveEntry.class.getDeclaredField("hasCreationDate");
        hasCreationDateField.setAccessible(true);
        hasCreationDateField.set(entry1, true);
        hasCreationDateField.set(entry2, true);

        // Set remaining fields the same except 'creationDate'
        // ... (similar to TC06)
        
        // Set 'hasLastModifiedDate' field
        Field hasLastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("hasLastModifiedDate");
        hasLastModifiedDateField.setAccessible(true);
        hasLastModifiedDateField.set(entry1, false);
        hasLastModifiedDateField.set(entry2, false);

        // Set 'hasAccessDate' field
        Field hasAccessDateField = SevenZArchiveEntry.class.getDeclaredField("hasAccessDate");
        hasAccessDateField.setAccessible(true);
        hasAccessDateField.set(entry1, false);
        hasAccessDateField.set(entry2, false);

        // Set 'creationDate' field (different)
        Field creationDateField = SevenZArchiveEntry.class.getDeclaredField("creationDate");
        creationDateField.setAccessible(true);
        FileTime creationDate1 = FileTime.fromMillis(1000);
        FileTime creationDate2 = FileTime.fromMillis(2000);
        creationDateField.set(entry1, creationDate1);
        creationDateField.set(entry2, creationDate2);

        // Set 'lastModifiedDate' field
        Field lastModifiedDateField = SevenZArchiveEntry.class.getDeclaredField("lastModifiedDate");
        lastModifiedDateField.setAccessible(true);
        FileTime lastModifiedDate = FileTime.fromMillis(1000);
        lastModifiedDateField.set(entry1, lastModifiedDate);
        lastModifiedDateField.set(entry2, lastModifiedDate);

        // Set 'accessDate' field
        Field accessDateField = SevenZArchiveEntry.class.getDeclaredField("accessDate");
        accessDateField.setAccessible(true);
        FileTime accessDate = FileTime.fromMillis(1000);
        accessDateField.set(entry1, accessDate);
        accessDateField.set(entry2, accessDate);

        // Set 'hasWindowsAttributes' field
        Field hasWindowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("hasWindowsAttributes");
        hasWindowsAttributesField.setAccessible(true);
        hasWindowsAttributesField.set(entry1, false);
        hasWindowsAttributesField.set(entry2, false);

        // Set 'windowsAttributes' field
        Field windowsAttributesField = SevenZArchiveEntry.class.getDeclaredField("windowsAttributes");
        windowsAttributesField.setAccessible(true);
        windowsAttributesField.set(entry1, 0);
        windowsAttributesField.set(entry2, 0);

        // Set 'hasCrc' field
        Field hasCrcField = SevenZArchiveEntry.class.getDeclaredField("hasCrc");
        hasCrcField.setAccessible(true);
        hasCrcField.set(entry1, false);
        hasCrcField.set(entry2, false);

        // Set 'crc' field
        Field crcField = SevenZArchiveEntry.class.getDeclaredField("crc");
        crcField.setAccessible(true);
        crcField.setLong(entry1, 0L);
        crcField.setLong(entry2, 0L);

        // Set 'compressedCrc' field
        Field compressedCrcField = SevenZArchiveEntry.class.getDeclaredField("compressedCrc");
        compressedCrcField.setAccessible(true);
        compressedCrcField.setLong(entry1, 0L);
        compressedCrcField.setLong(entry2, 0L);

        // Set 'size' field
        Field sizeField = SevenZArchiveEntry.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setLong(entry1, 100L);
        sizeField.setLong(entry2, 100L);

        // Set 'compressedSize' field
        Field compressedSizeField = SevenZArchiveEntry.class.getDeclaredField("compressedSize");
        compressedSizeField.setAccessible(true);
        compressedSizeField.setLong(entry1, 50L);
        compressedSizeField.setLong(entry2, 50L);

        // Set 'contentMethods' field
        Field contentMethodsField = SevenZArchiveEntry.class.getDeclaredField("contentMethods");
        contentMethodsField.setAccessible(true);
        List<SevenZMethodConfiguration> contentMethods = new ArrayList<>();
        contentMethodsField.set(entry1, contentMethods);
        contentMethodsField.set(entry2, contentMethods);

        // Invoke equals and assert
        boolean result = entry1.equals(entry2);
        assertFalse(result);
    }
}