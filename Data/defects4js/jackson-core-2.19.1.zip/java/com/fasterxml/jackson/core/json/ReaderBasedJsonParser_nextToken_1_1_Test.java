package com.fasterxml.jackson.core.json;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;

import java.io.StringReader;
import java.io.Reader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReaderBasedJsonParser_nextToken_1_1_Test {

    @Test
    @DisplayName("TC41: nextToken() correctly processes the closing array bracket ']' and updates the parsing context")
    public void TC41_nextToken_closingArrayBracket() throws Exception {
        Class<?> ioContextClass = Class.forName("com.fasterxml.jackson.core.io.IOContext");
        Constructor<?> ioContextConstructor = ioContextClass.getDeclaredConstructor(Object.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        Object ioContext = ioContextConstructor.newInstance(null, false);

        Class<?> canonicalizerClass = Class.forName("com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer");
        Method createRootMethod = canonicalizerClass.getDeclaredMethod("createRoot");
        createRootMethod.setAccessible(true);
        Object canonicalizer = createRootMethod.invoke(null);

        Reader reader = new StringReader("[1,2,3]");

        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> parserConstructor = parserClass.getDeclaredConstructor(ioContextClass, int.class, Reader.class, ObjectCodec.class, canonicalizerClass);
        parserConstructor.setAccessible(true);
        ReaderBasedJsonParser parser = (ReaderBasedJsonParser) parserConstructor.newInstance(ioContext, 0, reader, null, canonicalizer);

        parser.nextToken(); // START_ARRAY
        parser.nextToken(); // VALUE_NUMBER_INT
        parser.nextToken(); // VALUE_NUMBER_INT
        parser.nextToken(); // VALUE_NUMBER_INT
        JsonToken token = parser.nextToken(); // END_ARRAY

        assertEquals(JsonToken.END_ARRAY, token, "The token should be END_ARRAY");

        Field parsingContextField = parserClass.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        Object parsingContext = parsingContextField.get(parser);

        Method inArrayMethod = parsingContext.getClass().getDeclaredMethod("inArray");
        inArrayMethod.setAccessible(true);
        boolean isInArray = (boolean) inArrayMethod.invoke(parsingContext);
        assertFalse(isInArray, "Parsing context should be updated to parent");
    }

    @Test
    @DisplayName("TC42: nextToken() returns JsonToken.END_ARRAY after processing all array elements")
    public void TC42_nextToken_returnsEndArrayAfterAllElements() throws Exception {
        Class<?> ioContextClass = Class.forName("com.fasterxml.jackson.core.io.IOContext");
        Constructor<?> ioContextConstructor = ioContextClass.getDeclaredConstructor(Object.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        Object ioContext = ioContextConstructor.newInstance(null, false);

        Class<?> canonicalizerClass = Class.forName("com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer");
        Method createRootMethod = canonicalizerClass.getDeclaredMethod("createRoot");
        createRootMethod.setAccessible(true);
        Object canonicalizer = createRootMethod.invoke(null);

        Reader reader = new StringReader("[\"value1\", \"value2\"]");

        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> parserConstructor = parserClass.getDeclaredConstructor(ioContextClass, int.class, Reader.class, ObjectCodec.class, canonicalizerClass);
        parserConstructor.setAccessible(true);
        ReaderBasedJsonParser parser = (ReaderBasedJsonParser) parserConstructor.newInstance(ioContext, 0, reader, null, canonicalizer);

        parser.nextToken(); // START_ARRAY
        parser.nextToken(); // VALUE_STRING
        parser.nextToken(); // VALUE_STRING
        JsonToken token = parser.nextToken(); // END_ARRAY

        assertEquals(JsonToken.END_ARRAY, token, "The token should be END_ARRAY");

        Field parsingContextField = parserClass.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        Object parsingContext = parsingContextField.get(parser);

        Method inArrayMethod = parsingContext.getClass().getDeclaredMethod("inArray");
        inArrayMethod.setAccessible(true);
        boolean isInArray = (boolean) inArrayMethod.invoke(parsingContext);
        assertFalse(isInArray, "Parser should exit array context");
    }

    @Test
    @DisplayName("TC43: nextToken() parses multiple elements within an array correctly")
    public void TC43_nextToken_parsesMultipleArrayElements() throws Exception {
        Class<?> ioContextClass = Class.forName("com.fasterxml.jackson.core.io.IOContext");
        Constructor<?> ioContextConstructor = ioContextClass.getDeclaredConstructor(Object.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        Object ioContext = ioContextConstructor.newInstance(null, false);

        Class<?> canonicalizerClass = Class.forName("com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer");
        Method createRootMethod = canonicalizerClass.getDeclaredMethod("createRoot");
        createRootMethod.setAccessible(true);
        Object canonicalizer = createRootMethod.invoke(null);

        Reader reader = new StringReader("[1, \"two\", true, null]");

        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> parserConstructor = parserClass.getDeclaredConstructor(ioContextClass, int.class, Reader.class, ObjectCodec.class, canonicalizerClass);
        parserConstructor.setAccessible(true);
        ReaderBasedJsonParser parser = (ReaderBasedJsonParser) parserConstructor.newInstance(ioContext, 0, reader, null, canonicalizer);

        JsonToken token1 = parser.nextToken(); // START_ARRAY
        JsonToken token2 = parser.nextToken(); // VALUE_NUMBER_INT
        JsonToken token3 = parser.nextToken(); // VALUE_STRING
        JsonToken token4 = parser.nextToken(); // VALUE_TRUE
        JsonToken token5 = parser.nextToken(); // VALUE_NULL
        JsonToken result = parser.nextToken(); // END_ARRAY

        assertEquals(JsonToken.VALUE_NUMBER_INT, token2, "First element should be VALUE_NUMBER_INT");
        assertEquals(JsonToken.VALUE_STRING, token3, "Second element should be VALUE_STRING");
        assertEquals(JsonToken.VALUE_TRUE, token4, "Third element should be VALUE_TRUE");
        assertEquals(JsonToken.VALUE_NULL, token5, "Fourth element should be VALUE_NULL");
        assertEquals(JsonToken.END_ARRAY, result, "The token should be END_ARRAY");

        Field parsingContextField = parserClass.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        Object parsingContext = parsingContextField.get(parser);

        Method inArrayMethod = parsingContext.getClass().getDeclaredMethod("inArray");
        inArrayMethod.setAccessible(true);
        boolean isInArray = (boolean) inArrayMethod.invoke(parsingContext);
        assertFalse(isInArray, "Parser should exit array context");
    }

    @Test
    @DisplayName("TC44: nextToken() handles trailing comma in array when FEAT_MASK_TRAILING_COMMA is enabled")
    public void TC44_nextToken_handlesTrailingCommaWithFeatureEnabled() throws Exception {
        Class<?> ioContextClass = Class.forName("com.fasterxml.jackson.core.io.IOContext");
        Constructor<?> ioContextConstructor = ioContextClass.getDeclaredConstructor(Object.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        Object ioContext = ioContextConstructor.newInstance(null, false);

        Class<?> canonicalizerClass = Class.forName("com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer");
        Method createRootMethod = canonicalizerClass.getDeclaredMethod("createRoot");
        createRootMethod.setAccessible(true);
        Object canonicalizer = createRootMethod.invoke(null);

        Reader reader = new StringReader("[1, 2, 3,]");

        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> parserConstructor = parserClass.getDeclaredConstructor(ioContextClass, int.class, Reader.class, ObjectCodec.class, canonicalizerClass);
        parserConstructor.setAccessible(true);
        ReaderBasedJsonParser parser = (ReaderBasedJsonParser) parserConstructor.newInstance(ioContext, 4, reader, null, canonicalizer); // Assuming FEAT_MASK_TRAILING_COMMA is 4

        parser.nextToken(); // START_ARRAY
        parser.nextToken(); // VALUE_NUMBER_INT
        parser.nextToken(); // VALUE_NUMBER_INT
        parser.nextToken(); // VALUE_NUMBER_INT
        JsonToken result = parser.nextToken(); // END_ARRAY

        assertEquals(JsonToken.END_ARRAY, result, "The token should be END_ARRAY");

        Field parsingContextField = parserClass.getDeclaredField("_parsingContext");
        parsingContextField.setAccessible(true);
        Object parsingContext = parsingContextField.get(parser);

        Method inArrayMethod = parsingContext.getClass().getDeclaredMethod("inArray");
        inArrayMethod.setAccessible(true);
        boolean isInArray = (boolean) inArrayMethod.invoke(parsingContext);
        assertFalse(isInArray, "Parser should exit array context");
    }

    @Test
    @DisplayName("TC45: nextToken() throws exception on trailing comma in array when FEAT_MASK_TRAILING_COMMA is disabled")
    public void TC45_nextToken_throwsExceptionOnTrailingCommaWithFeatureDisabled() throws Exception {
        Class<?> ioContextClass = Class.forName("com.fasterxml.jackson.core.io.IOContext");
        Constructor<?> ioContextConstructor = ioContextClass.getDeclaredConstructor(Object.class, boolean.class);
        ioContextConstructor.setAccessible(true);
        Object ioContext = ioContextConstructor.newInstance(null, false);

        Class<?> canonicalizerClass = Class.forName("com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer");
        Method createRootMethod = canonicalizerClass.getDeclaredMethod("createRoot");
        createRootMethod.setAccessible(true);
        Object canonicalizer = createRootMethod.invoke(null);

        Reader reader = new StringReader("[1, 2, 3,]");

        Class<?> parserClass = Class.forName("com.fasterxml.jackson.core.json.ReaderBasedJsonParser");
        Constructor<?> parserConstructor = parserClass.getDeclaredConstructor(ioContextClass, int.class, Reader.class, ObjectCodec.class, canonicalizerClass);
        parserConstructor.setAccessible(true);
        ReaderBasedJsonParser parser = (ReaderBasedJsonParser) parserConstructor.newInstance(ioContext, 0, reader, null, canonicalizer); // FEAT_MASK_TRAILING_COMMA disabled

        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken(); // START_ARRAY
            parser.nextToken(); // VALUE_NUMBER_INT
            parser.nextToken(); // VALUE_NUMBER_INT
            parser.nextToken(); // VALUE_NUMBER_INT
            parser.nextToken(); // Attempt to parse trailing comma
        }, "Expected JsonParseException due to trailing comma");

        assertTrue(exception.getMessage().contains("trailing comma"), "Exception message should indicate trailing comma");
    }
}