// package com.fasterxml.jackson.dataformat.xml.ser;
// import java.lang.reflect.*;
// import java.io.*;
// import java.util.*;
//
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.Mockito.mock;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;
//
// import java.lang.reflect.Field;
//
// import javax.xml.namespace.QName;
//
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
//
// import com.fasterxml.jackson.core.JsonGenerator;
// import com.fasterxml.jackson.databind.SerializerProvider;
// import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
// import com.fasterxml.jackson.databind.ser.PropertySerializerMap;
// import com.fasterxml.jackson.databind.ser.std.StdSerializer;
//
// public class XmlBeanPropertyWriter_serializeAsField_2_1_Test {
//
//     @Test
//     @DisplayName("serializeAsField with non-null value and _suppressableValue is null, expecting field to be written")
//     public void TC15() throws Exception {
//         // Arrange
//         Object bean = createBeanWithNonNullProperty();
//         JsonGenerator jgen = mock(JsonGenerator.class);
//         SerializerProvider prov = mock(SerializerProvider.class);
//         BeanPropertyWriter wrappedWriter = mock(BeanPropertyWriter.class);
//         when(wrappedWriter.get(bean)).thenReturn(bean);
//
//         XmlBeanPropertyWriter writer = new XmlBeanPropertyWriter(wrappedWriter, PropertyName.construct("wrapper"), PropertyName.construct("wrapped"), null);
//
//         // Ensure _suppressableValue is null using reflection
//         Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
//         suppressableValueField.setAccessible(true);
//         suppressableValueField.set(writer, null);
//
//         // Act
//         writer.serializeAsField(bean, jgen, prov);
//
//         // Assert
//         verify(jgen).writeFieldName(any());
//         verify(jgen).writeFieldName(eq(((BeanPropertyWriter) writer)._name));
//         verify(writer, never()).serializeWithType(any(), any(), any(), any());
//     }
//
//     @Test
//     @DisplayName("serializeAsField with non-null value and serializer.isEmpty returns true, expecting field to be suppressed")
//     public void TC16() throws Exception {
//         // Arrange
//         Object bean = createBeanWithNonNullProperty();
//         JsonGenerator jgen = mock(JsonGenerator.class);
//         SerializerProvider prov = mock(SerializerProvider.class);
//
//         @SuppressWarnings("unchecked")
//         JsonSerializer<Object> serializer = mock(JsonSerializer.class);
//         when(serializer.isEmpty(prov, bean)).thenReturn(true);
//
//         BeanPropertyWriter wrappedWriter = mock(BeanPropertyWriter.class);
//         when(wrappedWriter.get(bean)).thenReturn(bean);
//
//         XmlBeanPropertyWriter writer = new XmlBeanPropertyWriter(wrappedWriter, PropertyName.construct("wrapper"), PropertyName.construct("wrapped"), serializer);
//
//         // Set _suppressableValue to MARKER_FOR_EMPTY using reflection
//         Field suppressableValueField = BeanPropertyWriter.class.getDeclaredField("_suppressableValue");
//         suppressableValueField.setAccessible(true);
//         suppressableValueField.set(writer, BeanPropertyWriter.MARKER_FOR_EMPTY);
//
//         // Act
//         writer.serializeAsField(bean, jgen, prov);
//
//         // Assert
//         verify(serializer).isEmpty(prov, bean);
//         verify(jgen, never()).writeFieldName(any());
//     }
//
//     // Helper method to create a bean with a non-null property
//     private Object createBeanWithNonNullProperty() {
//         // Implementation depends on the actual bean structure
//         return new Object();
//     }
// }