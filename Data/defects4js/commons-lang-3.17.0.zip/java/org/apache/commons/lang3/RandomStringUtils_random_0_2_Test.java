package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

public class RandomStringUtils_random_0_2_Test {

    @Test
    @DisplayName("random(count, start, end, letters=true, numbers=true, chars=null, random) throws IllegalArgumentException when start and end parameters are invalid")
    void TC06_random_invalid_start_and_end() {
        // GIVEN
        int count = 10;
        int start = 100;
        int end = 50;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
    }

    @Test
    @DisplayName("random(count, start=-1, end=100, letters, numbers, chars, random) throws IllegalArgumentException for negative start")
    void TC07_random_negative_start() {
        // GIVEN
        int count = 10;
        int start = -1;
        int end = 100;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
    }

    @Test
    @DisplayName("random(count, start=10, end=10000000, letters, numbers, chars=null, random) sets end to Character.MAX_CODE_POINT when end exceeds maximum")
    void TC08_random_end_exceeds_max_code_point() {
        // GIVEN
        int count = 20;
        int start = 10;
        int end = 2000000;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(20, result.length(), "The generated string should have length 20");
        for (char c : result.toCharArray()) {
            assertTrue(c >= start && c <= Character.MAX_CODE_POINT, "Character " + c + " is out of range");
        }
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=null, random) optimizes for alphanumerical characters")
    void TC09_random_optimizes_alphanumerical() {
        // GIVEN
        int count = 12;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        // WHEN
        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        // THEN
        assertEquals(12, result.length(), "The generated string should have length 12");
        assertTrue(result.matches("^[a-zA-Z0-9]{12}$"), "The string should contain only alphanumerical characters");
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=false, chars=null, random) optimizes for letters only")
    void TC10_random_optimizes_letters_only() {
        // GIVEN
        int count = 8;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        // WHEN & THEN
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RandomStringUtils.random(count, start, end, letters, numbers, chars, random);
        });
        String message = exception.getMessage();
        assertTrue(message.contains("Parameter end"), "Exception message should mention 'Parameter end'");
    }
}