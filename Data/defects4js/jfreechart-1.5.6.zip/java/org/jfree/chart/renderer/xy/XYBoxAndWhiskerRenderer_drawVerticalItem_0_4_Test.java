package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_0_4_Test {

    @Test
    @DisplayName("drawVerticalItem with high far out outlier")
    public void TC16_drawVerticalItem_with_high_far_out_outlier() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        when(info.getOwner().getEntityCollection()).thenReturn(mock(EntityCollection.class));

        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset.getX(0, 0)).thenReturn(30.0);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(30.0));
        when(domainAxis.valueToJava2D(30.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);

        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
        verify(g2, times(2)).draw(shapeCaptor.capture());

        boolean highFarOutDrawn = shapeCaptor.getAllValues().stream().anyMatch(shape -> shape.toString().contains("Line2D.Double"));
        assertTrue(highFarOutDrawn, "High far out marker should be drawn.");
    }

    @Test
    @DisplayName("drawVerticalItem with low far out outlier")
    public void TC17_drawVerticalItem_with_low_far_out_outlier() throws Exception {
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        when(info.getOwner().getEntityCollection()).thenReturn(mock(EntityCollection.class));

        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        when(dataset.getX(0, 0)).thenReturn(-10.0);
        when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(-10.0));
        when(domainAxis.valueToJava2D(-10.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);

        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);

        ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
        verify(g2, times(2)).draw(shapeCaptor.capture());

        boolean lowFarOutDrawn = shapeCaptor.getAllValues().stream().anyMatch(shape -> shape.toString().contains("Line2D.Double"));
        assertTrue(lowFarOutDrawn, "Low far out marker should be drawn.");
    }

//     @Test
//     @DisplayName("drawVerticalItem with both high and low far out outliers")
//     public void TC18_drawVerticalItem_with_both_high_and_low_far_out_outliers() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         when(info.getOwner().getEntityCollection()).thenReturn(mock(EntityCollection.class));
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(dataset.getOutliers(0, 0)).thenReturn(Arrays.asList(30.0, -10.0));
//         when(domainAxis.valueToJava2D(30.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);
// 
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
//         ArgumentCaptor<Shape> shapeCaptor = ArgumentCaptor.forClass(Shape.class);
//         verify(g2, atLeast(4)).draw(shapeCaptor.capture());
// 
//         boolean bothFarOutDrawn = shapeCaptor.getAllValues().stream().anyMatch(shape -> shape.toString().contains("Line2D.Double"));
//         assertTrue(bothFarOutDrawn, "Both high and low far out markers should be drawn.");
//     }

//     @Test
//     @DisplayName("drawVerticalItem with box intersecting dataArea")
//     public void TC19_drawVerticalItem_with_box_intersecting_dataArea() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);
//         when(dataArea.intersects(any(Rectangle2D.class))).thenReturn(true);
// 
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
//         verify(entities, times(1)).add(any(), any(), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble());
//     }

//     @Test
//     @DisplayName("drawVerticalItem with box not intersecting dataArea")
//     public void TC20_drawVerticalItem_with_box_not_intersecting_dataArea() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         when(info.getOwner().getEntityCollection()).thenReturn(entities);
// 
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
// 
//         BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
//         when(dataset.getX(0, 0)).thenReturn(10.0);
//         when(domainAxis.valueToJava2D(10.0, dataArea, plot.getDomainAxisEdge())).thenReturn(100.0);
//         when(dataArea.intersects(any(Rectangle2D.class))).thenReturn(false);
// 
//         XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
//         renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 0);
// 
//         verify(entities, times(0)).add(any(), any(), eq(dataset), eq(0), eq(0), anyDouble(), anyDouble());
//     }
}