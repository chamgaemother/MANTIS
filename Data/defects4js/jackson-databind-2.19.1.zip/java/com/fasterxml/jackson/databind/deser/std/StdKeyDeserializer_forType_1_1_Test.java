package com.fasterxml.jackson.databind.deser.std;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class StdKeyDeserializer_forType_1_1_Test {

    @Test
    @DisplayName("forType(int.class) returns null for unsupported primitive type")
    void testForTypeWithUnsupportedPrimitiveType() {
        Class<?> raw = int.class;
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);
        assertNull(result, "Expected null for unsupported primitive type int.class");
    }

    @Test
    @DisplayName("forType(Enum.class) returns null for unsupported Enum type")
    void testForTypeWithUnsupportedEnumType() {
        Class<?> raw = Enum.class;
        StdKeyDeserializer result = StdKeyDeserializer.forType(raw);
        assertNull(result, "Expected null for unsupported Enum type Enum.class");
    }
}