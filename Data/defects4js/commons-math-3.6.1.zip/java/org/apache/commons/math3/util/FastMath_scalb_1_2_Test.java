package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_scalb_1_2_Test {

    @Test
    @DisplayName("scalb with d as a normal number and n causing scaledExponent to reach exactly Double.MAX_EXPONENT")
    void TC23_scalb_NormalToInfinity() {
        // GIVEN
        double d = 1.0;
        int n = 2047; // n set to make scaledExponent exactly Double.MAX_EXPONENT

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result, "Result should be Double.POSITIVE_INFINITY when scaledExponent reaches max.");
    }

    @Test
    @DisplayName("scalb with d as a subnormal number and n set to normalize it")
    void TC24_scalb_SubnormalToNormal() {
        // GIVEN
        double d = Double.longBitsToDouble(0x0008000000000000L); // Smallest subnormal positive double
        int n = 53; // n set to scale it to a normalized number

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "Result should be a finite normalized number.");
        assertTrue(Double.doubleToRawLongBits(result) >= Double.MIN_NORMAL, "Result should be a normalized number.");
        assertEquals(0, FastMath.getExponent(result), "The scaled exponent should be 0.");
    }

    @Test
    @DisplayName("scalb with d as a negative normal number and n causing scaledExponent to underflow to subnormal")
    void TC25_scalb_NegativeNormalToSubnormal() {
        // GIVEN
        double d = -1.0; // Negative normal double
        int n = -54; // n set to scaleExponent to -54

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "Result should be a finite subnormal number.");
        assertTrue(Double.doubleToRawLongBits(result) < Double.MIN_NORMAL, "Result should be a subnormal number.");
        assertEquals(-54, FastMath.getExponent(result), "The scaled exponent should be -54.");
    }

    @Test
    @DisplayName("scalb with n causing scaledExponent to reach exactly Double.MIN_EXPONENT +1")
    void TC26_scalb_NormalToBoundary() {
        // GIVEN
        double d = 1.0;
        int n = -1022; // n set to make scaledExponent exactly Double.MIN_EXPONENT +1 (-1022)

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "Result should be a finite normalized number.");
        assertTrue(Double.doubleToRawLongBits(result) >= Double.MIN_NORMAL, "Result should be a normalized number.");
        assertEquals(-1022, FastMath.getExponent(result), "The scaled exponent should be -1022.");
    }
}