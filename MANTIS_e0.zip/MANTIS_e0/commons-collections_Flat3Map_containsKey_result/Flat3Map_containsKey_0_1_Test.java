package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class Flat3Map_containsKey_0_1_Test {

    @Test
    @DisplayName("containsKey delegates to delegateMap when delegateMap is not null")
    void TC01_containsKey_delegatesToDelegateMapWhenNotNull() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        AbstractHashedMap<Object, Object> mockDelegateMap = Mockito.mock(AbstractHashedMap.class);

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, mockDelegateMap);

        Object key = "testKey";
        when(mockDelegateMap.containsKey(key)).thenReturn(true);

        // WHEN
        boolean result = map.containsKey(key);

        // THEN
        assertTrue(result);
        verify(mockDelegateMap, times(1)).containsKey(key);
    }

    @Test
    @DisplayName("containsKey delegates to delegateMap when delegateMap is not null and does not contain the key")
    void TC02_containsKey_delegatesToDelegateMapWhenNotContains() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        AbstractHashedMap<Object, Object> mockDelegateMap = Mockito.mock(AbstractHashedMap.class);

        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, mockDelegateMap);

        Object key = "nonExistingKey";
        when(mockDelegateMap.containsKey(key)).thenReturn(false);

        // WHEN
        boolean result = map.containsKey(key);

        // THEN
        assertFalse(result);
        verify(mockDelegateMap, times(1)).containsKey(key);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is null, and key3 is null (size=3)")
    void TC03_containsKey_returnsTrueWhenKey3IsNull() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 3);

        // Set key3 to null
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        key3Field.set(map, null);

        // WHEN
        boolean result = map.containsKey(null);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is null, and key2 is null (size=2)")
    void TC04_containsKey_returnsTrueWhenKey2IsNull() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        // Set key2 to null
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, null);

        // WHEN
        boolean result = map.containsKey(null);

        // THEN
        assertTrue(result);
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is null, and key1 is null (size=1)")
    void TC05_containsKey_returnsTrueWhenKey1IsNull() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 1);

        // Set key1 to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // WHEN
        boolean result = map.containsKey(null);

        // THEN
        assertTrue(result);
    }
}