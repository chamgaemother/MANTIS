import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.json.UTF8DataInputJsonParser;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.io.IOContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UTF8DataInputJsonParserTest {

    private IOContext ioContext;
    private ObjectCodec codec;
    private ByteQuadsCanonicalizer sym;

    @BeforeEach
    public void setup() {
        ioContext = Mockito.mock(IOContext.class);
        codec = Mockito.mock(ObjectCodec.class);
        sym = ByteQuadsCanonicalizer.createRoot();
    }

    private UTF8DataInputJsonParser createParser(String json, int firstByte) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(json.getBytes("UTF-8"));
        DataInputStream dis = new DataInputStream(bais);
        return new UTF8DataInputJsonParser(ioContext, 0, dis, codec, sym, firstByte);
    }

    @Test
    public void testNextFieldNameWhenCurrentTokenIsFieldName() throws IOException {
        String json = "{\"field1\":\"value1\",\"field2\":\"value2\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        parser.nextFieldName(); // field1
        parser.nextFieldName(); // field2
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameWhenTokenIncomplete() throws IOException {
        String json = "{\"field\":\"value\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        parser.nextFieldName(); // field
        parser.finishToken();
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameWhenClosingScope() throws IOException {
        String json = "{}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameExpectingCommaAndCommaFound() throws IOException {
        String json = "{\"field1\":\"value1\",\"field2\":\"value2\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("field1", parser.nextFieldName());
        assertEquals("field2", parser.nextFieldName());
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameExpectingCommaAndCommaNotFound() throws IOException {
        String json = "{\"field1\":\"value1\"\"field2\":\"value2\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("field1", parser.nextFieldName());
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextFieldName);
        assertTrue(exception.getMessage().contains("was expecting comma"));
    }

    @Test
    public void testNextFieldNameWithTrailingCommaAllowed() throws IOException {
        String json = "{\"field1\":\"value1\",}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("field1", parser.nextFieldName());
        parser._features |= 0x1; // Enable FEAT_MASK_TRAILING_COMMA
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameWithTrailingCommaNotAllowed() throws IOException {
        String json = "{\"field1\":\"value1\",}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("field1", parser.nextFieldName());
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextFieldName);
        assertTrue(exception.getMessage().contains("was expecting colon"));
    }

    @Test
    public void testNextFieldNameNotInObject() throws IOException {
        String json = "[\"value1\", \"value2\"]";
        UTF8DataInputJsonParser parser = createParser(json, '[');
        parser.nextToken(); // START_ARRAY
        assertNull(parser.nextFieldName());
    }

    @Test
    public void testNextFieldNameWithStringValue() throws IOException {
        String json = "{\"field1\":\"value1\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("field1", fieldName);
        assertEquals("value1", parser.getText());
    }

    @Test
    public void testNextFieldNameWithNumberValue() throws IOException {
        String json = "{\"field1\":123}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("field1", fieldName);
        assertEquals(123, parser.getIntValue());
    }

    @Test
    public void testNextFieldNameWithBooleanValue() throws IOException {
        String json = "{\"field1\":true}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("field1", fieldName);
        assertTrue(parser.getBooleanValue());
    }

    @Test
    public void testNextFieldNameWithNullValue() throws IOException {
        String json = "{\"field1\":null}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("field1", fieldName);
        assertTrue(parser.getCurrentToken() == JsonToken.VALUE_NULL);
    }

    @Test
    public void testNextFieldNameWithNestedObject() throws IOException {
        String json = "{\"field1\":{\"nested\":\"value\"}}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("field1", fieldName);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
    }

    @Test
    public void testNextFieldNameWithInvalidValue() throws IOException {
        String json = "{\"field1\":invalid}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        parser.nextFieldName();
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(exception.getMessage().contains("Unrecognized token"));
    }

    @Test
    public void testNextFieldNameWithSingleQuotesAllowed() throws IOException {
        String json = "{'field1':'value1'}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser._features |= 0x2; // Enable FEAT_MASK_ALLOW_SINGLE_QUOTES
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("field1", fieldName);
    }

    @Test
    public void testNextFieldNameWithSingleQuotesNotAllowed() throws IOException {
        String json = "{'field1':'value1'}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken(); // START_OBJECT
            parser.nextFieldName();
        });
        assertTrue(exception.getMessage().contains("was expecting double-quote"));
    }

    @Test
    public void testNextFieldNameWithLeadingPlusSignAllowed() throws IOException {
        String json = "{\"field1\":+123}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser._features |= 0x4; // Enable FEAT_MASK_ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS
        parser.nextToken(); // START_OBJECT
        String fieldName = parser.nextFieldName();
        assertEquals("field1", fieldName);
        assertEquals(123, parser.getIntValue());
    }

    @Test
    public void testNextFieldNameWithLeadingPlusSignNotAllowed() throws IOException {
        String json = "{\"field1\":+123}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        JsonParseException exception = assertThrows(JsonParseException.class, () -> {
            parser.nextToken(); // START_OBJECT
            parser.nextFieldName();
            parser.nextToken();
        });
        assertTrue(exception.getMessage().contains("expected digit"));
    }

    @Test
    public void testNextFieldNameWithWhitespaceHandling() throws IOException {
        String json = "{\n  \"field1\"  :  \"value1\" \t , \n \"field2\" :  \"value2\" \n}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        String field1 = parser.nextFieldName();
        assertEquals("field1", field1);
        String value1 = parser.getText();
        parser.nextFieldName();
        assertEquals("field2", parser.getCurrentName());
        String value2 = parser.getText();
        assertEquals("value1", value1);
        assertEquals("value2", value2);
    }

    @Test
    public void testNextFieldNameWithEmptyObject() throws IOException {
        String json = "{}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameWithMultipleFields() throws IOException {
        String json = "{\"f1\":\"v1\",\"f2\":2,\"f3\":true,\"f4\":null}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("f1", parser.nextFieldName());
        assertEquals("f2", parser.nextFieldName());
        assertEquals("f3", parser.nextFieldName());
        assertEquals("f4", parser.nextFieldName());
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameWithNestedArrays() throws IOException {
        String json = "{\"field1\":[1,2,3],\"field2\":[\"a\",\"b\"]}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("field1", parser.nextFieldName());
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        parser.skipChildren();
        assertEquals("field2", parser.nextFieldName());
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
        parser.skipChildren();
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameWithUnicodeCharacters() throws IOException {
        String json = "{\"emoji\":\"😊\",\"café\":\"value\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("emoji", parser.nextFieldName());
        parser.nextToken();
        assertEquals("café", parser.nextFieldName());
        parser.nextToken();
        assertNull(parser.nextFieldName()); // END_OBJECT
    }

    @Test
    public void testNextFieldNameWithInvalidEscapeInName() throws IOException {
        String json = "{\"field\\uZZZZ1\":\"value\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextFieldName);
        assertTrue(exception.getMessage().contains("expected a hex-digit"));
    }

    @Test
    public void testNextFieldNameWithMissingColon() throws IOException {
        String json = "{\"field1\" \"value1\"}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextFieldName);
        assertTrue(exception.getMessage().contains("was expecting a colon"));
    }

    @Test
    public void testNextFieldNameWithExtraComma() throws IOException {
        String json = "{\"field1\":\"value1\",,}";
        UTF8DataInputJsonParser parser = createParser(json, '{');
        parser.nextToken(); // START_OBJECT
        assertEquals("field1", parser.nextFieldName());
        JsonParseException exception = assertThrows(JsonParseException.class, parser::nextFieldName);
        assertTrue(exception.getMessage().contains("was expecting comma"));
    }
}