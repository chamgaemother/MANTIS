import org.apache.commons.lang3.ClassUtils;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClassUtilsTest {

    @Test
    void testIsAssignableWithSameClasses() {
        assertTrue(ClassUtils.isAssignable(Integer.class, Integer.class, true));
    }

    @Test
    void testIsAssignableWithPrimitiveToWrapperAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class, true));
    }

    @Test
    void testIsAssignableWithWrapperToPrimitiveAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
    }

    @Test
    void testIsAssignableWithoutAutoboxingPrimitiveToWrapper() {
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    void testIsAssignableWithoutAutoboxingWrapperToPrimitive() {
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
    }

    @Test
    void testIsAssignablePrimitiveToPrimitive() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class, true));
    }

    @Test
    void testIsAssignableWrapperToWrapper() {
        assertFalse(ClassUtils.isAssignable(Integer.class, Long.class, true));
    }

    @Test
    void testIsAssignableFromNullClassToNonPrimitive() {
        assertTrue(ClassUtils.isAssignable(null, Integer.class, true));
    }

    @Test
    void testIsAssignableFromNullClassToPrimitive() {
        assertFalse(ClassUtils.isAssignable(null, int.class, true));
    }

    @Test
    void testIsAssignableFromPrimitiveToNullClass() {
        assertFalse(ClassUtils.isAssignable(int.class, null, true));
    }

    @Test
    void testIsAssignableWithNonRelatedClasses() {
        assertFalse(ClassUtils.isAssignable(Integer.class, String.class, true));
    }

    @Test
    void testIsAssignableWithSubclass() {
        assertTrue(ClassUtils.isAssignable(Number.class, Object.class, true));
    }

    @Test
    void testIsAssignablePrimitiveBoxingFail() {
        assertFalse(ClassUtils.isAssignable(boolean.class, Boolean.class, false));
    }
    
    @Test
    void testIsAssignableFailurePrimitiveToPrimitive() {
        assertFalse(ClassUtils.isAssignable(double.class, int.class, true));
    }

    @Test
    void testIsAssignableToSamePrimitiveType() {
        assertTrue(ClassUtils.isAssignable(int.class, int.class, true));
    }

    @Test
    void testIsAssignableWithNonAssignablePrimitiveTypes() {
        assertFalse(ClassUtils.isAssignable(char.class, int.class, true));
    }
}