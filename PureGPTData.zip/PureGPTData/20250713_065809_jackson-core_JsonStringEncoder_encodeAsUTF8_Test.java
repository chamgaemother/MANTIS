import com.fasterxml.jackson.core.io.JsonStringEncoder;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class JsonStringEncoderTest {

    private final JsonStringEncoder encoder = JsonStringEncoder.getInstance();

    @Test
    void testEncodeAsUTF8_EmptyString() {
        byte[] result = encoder.encodeAsUTF8("");
        assertArrayEquals(new byte[0], result);
    }

    @Test
    void testEncodeAsUTF8_SimpleASCII() {
        byte[] result = encoder.encodeAsUTF8("Hello, World!");
        assertArrayEquals("Hello, World!".getBytes(), result);
    }

    @Test
    void testEncodeAsUTF8_NullCharacterSequence() {
        byte[] result = encoder.encodeAsUTF8((CharSequence) null);
        assertArrayEquals(new byte[0], result);
    }

    @Test
    void testEncodeAsUTF8_SingleHighSurrogateEdgeCase() {
        // First high surrogate without a corresponding low surrogate
        CharSequence input = "\uD800";
        assertThrows(IllegalArgumentException.class, () -> encoder.encodeAsUTF8(input));
    }

    @Test
    void testEncodeAsUTF8_SurrogatePair() {
        // Valid surrogate pair
        CharSequence input = "\uD834\uDD1E"; // U+1D11E, Musical Symbol G Clef
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(new byte[] {(byte)0xF0, (byte)0x9D, (byte)0x84, (byte)0x9E}, result);
    }

    @Test
    void testEncodeAsUTF8_InvalidSurrogatePair() {
        // Low surrogate without a preceding high surrogate
        assertThrows(IllegalArgumentException.class, () -> encoder.encodeAsUTF8("\uDD1E"));
    }

    @Test
    void testEncodeAsUTF8_MultiByteCharacters() {
        CharSequence input = "© € α"; // Includes 2-byte, 3-byte, and 2-byte UTF-8 characters
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(new byte[] {(byte)0xC2, (byte)0xA9, (byte)0x20, (byte)0xE2, (byte)0x82, (byte)0xAC, (byte)0x20, (byte)0xCE, (byte)0xB1}, result);
    }

    @Test
    void testEncodeAsUTF8_Emoji() {
        CharSequence input = "😀"; // Emoji, 4-byte UTF-8 character
        byte[] result = encoder.encodeAsUTF8(input);
        assertArrayEquals(new byte[] {(byte)0xF0, (byte)0x9F, (byte)0x98, (byte)0x80}, result);
    }
}