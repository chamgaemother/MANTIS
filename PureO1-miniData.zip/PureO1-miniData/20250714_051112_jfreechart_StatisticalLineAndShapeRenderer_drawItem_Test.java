import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class StatisticalLineAndShapeRendererTest {

    private StatisticalLineAndShapeRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;
    private StatisticalCategoryDataset statDataset;
    private int row;
    private int column;
    private int pass;

    @BeforeEach
    void setUp() {
        renderer = new StatisticalLineAndShapeRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);
        statDataset = mock(StatisticalCategoryDataset.class);
        row = 0;
        column = 0;
        pass = 0;

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(state.getVisibleSeriesIndex(row)).thenReturn(row);
        when(state.getVisibleSeriesCount()).thenReturn(1);
        when(state.getEntityCollection()).thenReturn(mock(EntityCollection.class));
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        when(renderer.getItemVisible(row, column)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_DatasetNotStatistical() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_VisibleRowNegative() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        renderer = spy(new StatisticalLineAndShapeRenderer());
        doReturn(-1).when(state).getVisibleSeriesIndex(row);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_MeanValueNull() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_VerticalOrientation_Pass0_WithPrevious() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(statDataset.getValue(row, column - 1)).thenReturn(5.0);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), anyInt(), anyInt(), anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 0);
        verify(g2).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_VerticalOrientation_Pass1_WithStdDev() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(statDataset.getStdDevValue(row, column)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(rangeAxis.valueToJava2D(12.0, dataArea, RectangleEdge.LEFT)).thenReturn(120.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, RectangleEdge.LEFT)).thenReturn(80.0);
        when(renderer.getItemPaint(row, column)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(mock(Stroke.class));

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_HorizontalOrientation_Pass1_WithStdDev() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(statDataset.getStdDevValue(row, column)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(rangeAxis.valueToJava2D(12.0, dataArea, RectangleEdge.LEFT)).thenReturn(120.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, RectangleEdge.LEFT)).thenReturn(80.0);
        when(renderer.getItemPaint(row, column)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(mock(Stroke.class));

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verify(g2, atLeastOnce()).draw(any(Line2D.class));
    }

    @Test
    void testDrawItem_ShapeVisible_Pass1() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getItemShapeVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(row, column)).thenReturn(shape);
        when(renderer.getItemFillPaint(row, column)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(mock(Stroke.class));
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_ShapeNotVisible_Pass1() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getItemShapeVisible(row, column)).thenReturn(false);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_ItemShapeFilled_Pass1() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getItemShapeVisible(row, column)).thenReturn(true);
        when(renderer.getItemShapeFilled(row, column)).thenReturn(true);
        when(renderer.getUseFillPaint()).thenReturn(true);
        when(renderer.getItemFillPaint(row, column)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(mock(Stroke.class));
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(row, column)).thenReturn(shape);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(false);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_ItemLabelVisible_Pass1() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getItemShapeVisible(row, column)).thenReturn(true);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(row, column)).thenReturn(shape);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        // Assuming drawItemLabel calls Graphics2D methods, verify interactions if possible
    }

    @Test
    void testDrawItem_ErrorIndicatorPaintAndStrokeNull() {
        renderer.setErrorIndicatorPaint(null);
        renderer.setErrorIndicatorStroke(null);
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(statDataset.getStdDevValue(row, column)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(rangeAxis.valueToJava2D(12.0, dataArea, RectangleEdge.LEFT)).thenReturn(120.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, RectangleEdge.LEFT)).thenReturn(80.0);
        Stroke stroke = mock(Stroke.class);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(stroke);
        Paint paint = mock(Paint.class);
        when(renderer.getItemPaint(row, column)).thenReturn(paint);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verify(g2).setPaint(eq(paint));
        verify(g2).setStroke(eq(stroke));
    }

    @Test
    void testDrawItem_ErrorIndicatorPaintAndStrokeSet() {
        Paint errorPaint = mock(Paint.class);
        Stroke errorStroke = mock(Stroke.class);
        renderer.setErrorIndicatorPaint(errorPaint);
        renderer.setErrorIndicatorStroke(errorStroke);
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(statDataset.getStdDevValue(row, column)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.getRange()).thenReturn(new org.jfree.data.Range(0.0, 20.0));
        when(rangeAxis.valueToJava2D(12.0, dataArea, RectangleEdge.LEFT)).thenReturn(120.0);
        when(rangeAxis.valueToJava2D(8.0, dataArea, RectangleEdge.LEFT)).thenReturn(80.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verify(g2).setPaint(eq(errorPaint));
        verify(g2).setStroke(eq(errorStroke));
    }

    @Test
    void testDrawItem_UseSeriesOffsetTrue() {
        renderer.setUseSeriesOffset(true);
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(15.0);
        when(domainAxis.getCategorySeriesMiddle(eq(column), anyInt(), eq(row), anyInt(), anyDouble(), eq(dataArea), any(RectangleEdge.class))).thenReturn(75.0);
        when(rangeAxis.valueToJava2D(15.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        when(statDataset.getStdDevValue(row, column)).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        // Since stdDev is null, only shape should be drawn
        verify(g2, atLeastOnce()).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_UseSeriesOffsetFalse() {
        renderer.setUseSeriesOffset(false);
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(20.0);
        when(domainAxis.getCategoryMiddle(eq(column), anyInt(), eq(dataArea), any(RectangleEdge.class))).thenReturn(100.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.LEFT)).thenReturn(200.0);
        when(statDataset.getStdDevValue(row, column)).thenReturn(null);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        // Since stdDev is null, only shape should be drawn
        verify(g2, atLeastOnce()).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_NullDataset() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_NullGraphics() {
        renderer.setItemVisible(row, column, true);
        renderer.drawItem(null, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, pass);
        // Should handle gracefully, no exception
    }

    @Test
    void testDrawItem_PassOutOfRange() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 2);
        // No specific behavior for pass=2, ensure no interactions
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_EntityCollectionNull() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(state.getEntityCollection()).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawItem_ItemLabelHorizontal() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getItemShapeVisible(row, column)).thenReturn(true);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(row, column)).thenReturn(shape);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        // Verify that drawItemLabel is called, potentially by verifying interactions
    }

    @Test
    void testDrawItem_ItemLabelNegativeValue() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getItemShapeVisible(row, column)).thenReturn(true);
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        when(dataset instanceof StatisticalCategoryDataset).thenReturn(true);
        when(statDataset.getMeanValue(row, column)).thenReturn(-5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.valueToJava2D(-5.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(row, column)).thenReturn(shape);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, statDataset, row, column, 1);
        // Verify that drawItemLabel is called with negative flag
    }
}