package org.jfree.chart.renderer.category;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BoxAndWhiskerRenderer_drawHorizontalItem_0_1_Test {

    @Mock
    private Graphics2D g2;

    @Mock
    private org.jfree.chart.renderer.category.CategoryItemRendererState state;

    @Mock
    private Rectangle2D dataArea;

    @Mock
    private CategoryPlot plot;

    @Mock
    private CategoryAxis domainAxis;

    @Mock
    private ValueAxis rangeAxis;

    // Change to BoxAndWhiskerCategoryDataset to match the expectations of drawHorizontalItem method
    @Mock
    private BoxAndWhiskerCategoryDataset dataset;

    @InjectMocks
    private BoxAndWhiskerRenderer renderer;

    @Test
    @DisplayName("Handles single series with one row and one column without filling the box")
    public void TC01_HandleSingleSeriesSingleCategoryNoFill() {
        // GIVEN
        when(dataset.getQ1Value(0, 0)).thenReturn(1.0);
        when(dataset.getQ3Value(0, 0)).thenReturn(3.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(-1.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(2.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(2.5);

        when(domainAxis.getCategoryEnd(0, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(domainAxis.getCategoryStart(0, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(state.getBarWidth()).thenReturn(2.0);

        when(renderer.getItemPaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 0)).thenReturn(mock(Stroke.class));
        when(renderer.getItemOutlinePaint(0, 0)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(0, 0)).thenReturn(mock(Stroke.class));

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // THEN
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, never()).fill(any(Shape.class)); // No fill expected
        verify(g2).draw(any(Shape.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).draw(any(Ellipse2D.class));
        verify(renderer).addItemEntity(any(EntityCollection.class), any(BoxAndWhiskerCategoryDataset.class), eq(0), eq(0), any(Shape.class));
    }

    @Test
    @DisplayName("Handles multiple series with offset calculations")
    public void TC02_HandleMultipleSeriesOffsetCalculation() {
        // GIVEN
        when(dataset.getQ1Value(1, 1)).thenReturn(2.0);
        when(dataset.getQ3Value(1, 1)).thenReturn(4.0);
        when(dataset.getMaxRegularValue(1, 1)).thenReturn(6.0);
        when(dataset.getMinRegularValue(1, 1)).thenReturn(0.0);
        when(dataset.getMeanValue(1, 1)).thenReturn(3.0);
        when(dataset.getMedianValue(1, 1)).thenReturn(3.5);

        when(domainAxis.getCategoryEnd(1, 2, dataArea, plot.getDomainAxisEdge())).thenReturn(20.0);
        when(domainAxis.getCategoryStart(1, 2, dataArea, plot.getDomainAxisEdge())).thenReturn(5.0);
        when(renderer.getRowCount()).thenReturn(2);
        when(renderer.getColumnCount()).thenReturn(2);
        when(state.getBarWidth()).thenReturn(2.0);

        when(renderer.getItemPaint(1, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(1, 1)).thenReturn(mock(Stroke.class));
        when(renderer.getItemOutlinePaint(1, 1)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(1, 1)).thenReturn(mock(Stroke.class));

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);

        // THEN
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).draw(any(Ellipse2D.class));
        verify(renderer).addItemEntity(any(EntityCollection.class), any(BoxAndWhiskerCategoryDataset.class), eq(1), eq(1), any(Shape.class));
    }

    @Test
    @DisplayName("Handles seriesCount <= 1 with box width offset")
    public void TC03_HandleSingleSeriesBoxOffset() {
        // GIVEN
        when(dataset.getQ1Value(0, 2)).thenReturn(1.5);
        when(dataset.getQ3Value(0, 2)).thenReturn(3.5);
        when(dataset.getMaxRegularValue(0, 2)).thenReturn(5.5);
        when(dataset.getMinRegularValue(0, 2)).thenReturn(-0.5);
        when(dataset.getMeanValue(0, 2)).thenReturn(2.5);
        when(dataset.getMedianValue(0, 2)).thenReturn(2.75);

        when(domainAxis.getCategoryEnd(2, 3, dataArea, plot.getDomainAxisEdge())).thenReturn(15.0);
        when(domainAxis.getCategoryStart(2, 3, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(3);
        when(state.getBarWidth()).thenReturn(2.0);

        when(renderer.getItemPaint(0, 2)).thenReturn(mock(Paint.class));
        when(renderer.getItemStroke(0, 2)).thenReturn(mock(Stroke.class));
        when(renderer.getItemOutlinePaint(0, 2)).thenReturn(mock(Paint.class));
        when(renderer.getItemOutlineStroke(0, 2)).thenReturn(mock(Stroke.class));

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2);

        // THEN
        verify(g2).setPaint(any(Paint.class));
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(Shape.class));
        verify(g2).draw(any(Shape.class));
        verify(g2).setPaint(any(Paint.class));
        verify(g2, atLeastOnce()).draw(any(Ellipse2D.class));
        verify(renderer).addItemEntity(any(EntityCollection.class), any(BoxAndWhiskerCategoryDataset.class), eq(0), eq(2), any(Shape.class));
    }

    @Test
    @DisplayName("Handles null Q1 value leading to early exit without drawing box")
    public void TC04_HandleNullQ1Value() {
        // GIVEN
        when(dataset.getQ1Value(0, 0)).thenReturn(null);
        when(dataset.getQ3Value(0, 0)).thenReturn(3.0);
        when(dataset.getMaxRegularValue(0, 0)).thenReturn(5.0);
        when(dataset.getMinRegularValue(0, 0)).thenReturn(-1.0);
        when(dataset.getMeanValue(0, 0)).thenReturn(2.0);
        when(dataset.getMedianValue(0, 0)).thenReturn(2.5);

        when(domainAxis.getCategoryEnd(0, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(10.0);
        when(domainAxis.getCategoryStart(0, 1, dataArea, plot.getDomainAxisEdge())).thenReturn(0.0);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(state.getBarWidth()).thenReturn(2.0);

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);

        // THEN
        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(renderer, never()).addItemEntity(any(EntityCollection.class), any(BoxAndWhiskerCategoryDataset.class), anyInt(), anyInt(), any(Shape.class));
    }

    @Test
    @DisplayName("Handles null Q3 value leading to early exit without drawing box")
    public void TC05_HandleNullQ3Value() {
        // GIVEN
        when(dataset.getQ1Value(0, 1)).thenReturn(1.0);
        when(dataset.getQ3Value(0, 1)).thenReturn(null);
        when(dataset.getMaxRegularValue(0, 1)).thenReturn(5.0);
        when(dataset.getMinRegularValue(0, 1)).thenReturn(-1.0);
        when(dataset.getMeanValue(0, 1)).thenReturn(2.0);
        when(dataset.getMedianValue(0, 1)).thenReturn(2.5);

        when(domainAxis.getCategoryEnd(1, 2, dataArea, plot.getDomainAxisEdge())).thenReturn(15.0);
        when(domainAxis.getCategoryStart(1, 2, dataArea, plot.getDomainAxisEdge())).thenReturn(5.0);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(2);
        when(state.getBarWidth()).thenReturn(2.0);

        // WHEN
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1);

        // THEN
        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(renderer, never()).addItemEntity(any(EntityCollection.class), any(BoxAndWhiskerCategoryDataset.class), anyInt(), anyInt(), any(Shape.class));
    }

}