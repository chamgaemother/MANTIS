package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;

public class IntList_add_0_1_Test {
    
    @Test
    @DisplayName("Add at location within bounds without needing to grow array")
    void TC01_addWithinBoundsWithoutGrow() throws Exception {
        // Initialize IntList instance
        IntList list = new IntList();
        
        // Set private fields via reflection
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        Field arrayField = IntList.class.getDeclaredField("array");
        firstIndexField.setAccessible(true);
        lastIndexField.setAccessible(true);
        arrayField.setAccessible(true);
        
        firstIndexField.setInt(list, 2);
        lastIndexField.setInt(list, 5);
        arrayField.set(list, new int[10]);
        
        // Parameters
        int location = 2;
        int object = 100;
        
        // Perform add operation
        list.add(location, object);
        
        // Assertions
        int[] array = (int[]) arrayField.get(list);
        assertEquals(100, array[4], "Object was not added at the specified location, expected at index 4");
    }
    
    @Test
    @DisplayName("Add at middle location requiring growForInsert")
    void TC02_addMiddleRequiringGrowForInsert() throws Exception {
        // Initialize IntList instance
        IntList list = new IntList();
        
        // Set private fields via reflection
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        Field arrayField = IntList.class.getDeclaredField("array");
        firstIndexField.setAccessible(true);
        lastIndexField.setAccessible(true);
        arrayField.setAccessible(true);
        
        firstIndexField.setInt(list, 0);
        lastIndexField.setInt(list, 10);
        arrayField.set(list, new int[10]);
        
        // Parameters
        int location = 5;
        int object = 200;
        
        // Perform add operation
        list.add(location, object);
        
        // Assertions
        int[] array = (int[]) arrayField.get(list);
        assertTrue(list.size() > 10, "Array was not grown for insertion");
        assertEquals(200, array[5], "Object was not added at the specified location");
    }
    
    @Test
    @DisplayName("Add at front when firstIndex > 0 without needing to grow")
    void TC03_addAtFrontWithoutGrow() throws Exception {
        // Initialize IntList instance
        IntList list = new IntList();
        
        // Set private fields via reflection
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        Field arrayField = IntList.class.getDeclaredField("array");
        firstIndexField.setAccessible(true);
        lastIndexField.setAccessible(true);
        arrayField.setAccessible(true);
        
        firstIndexField.setInt(list, 1);
        lastIndexField.setInt(list, 5);
        arrayField.set(list, new int[10]);
        
        // Parameters
        int location = 0;
        int object = 300;
        
        // Perform add operation
        list.add(location, object);
        
        // Assertions
        int firstIndex = firstIndexField.getInt(list);
        int[] array = (int[]) arrayField.get(list);
        assertEquals(0, firstIndex, "firstIndex was not updated correctly");
        assertEquals(300, array[firstIndex], "Object was not added at the front");
    }
    
    @Test
    @DisplayName("Add at front requiring growAtFront")
    void TC04_addAtFrontRequiringGrowAtFront() throws Exception {
        // Initialize IntList instance
        IntList list = new IntList();
        
        // Set private fields via reflection
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        Field arrayField = IntList.class.getDeclaredField("array");
        firstIndexField.setAccessible(true);
        lastIndexField.setAccessible(true);
        arrayField.setAccessible(true);
        
        firstIndexField.setInt(list, 0);
        lastIndexField.setInt(list, 5);
        arrayField.set(list, new int[6]);
        
        // Parameters
        int location = 0;
        int object = 400;
        
        // Perform add operation
        list.add(location, object);
        
        // Assertions
        int firstIndex = firstIndexField.getInt(list);
        int[] array = (int[]) arrayField.get(list);
        assertTrue(list.size() > 5, "firstIndex was not updated correctly");
        assertEquals(400, array[firstIndex], "Object was not added at the front after growing");
    }
    
    @Test
    @DisplayName("Add at end where lastIndex < array length without needing to grow")
    void TC05_addAtEndWithoutGrow() throws Exception {
        // Initialize IntList instance
        IntList list = new IntList();
        
        // Set private fields via reflection
        Field firstIndexField = IntList.class.getDeclaredField("firstIndex");
        Field lastIndexField = IntList.class.getDeclaredField("lastIndex");
        Field arrayField = IntList.class.getDeclaredField("array");
        firstIndexField.setAccessible(true);
        lastIndexField.setAccessible(true);
        arrayField.setAccessible(true);
        
        firstIndexField.setInt(list, 0);
        lastIndexField.setInt(list, 5);
        arrayField.set(list, new int[10]);
        
        // Parameters
        int location = 5;
        int object = 500;
        
        // Perform add operation
        list.add(location, object);
        
        // Assertions
        int[] array = (int[]) arrayField.get(list);
        assertEquals(500, array[5], "Object was not added at the end");
    }
}