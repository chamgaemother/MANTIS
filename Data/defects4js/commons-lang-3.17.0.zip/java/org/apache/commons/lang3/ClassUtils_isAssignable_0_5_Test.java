package org.apache.commons.lang3;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class ClassUtils_isAssignable_0_5_Test {

    @Test
    @DisplayName("cls is primitive, autoboxing is false, and toClass is not primitive; expect false")
    void test_TC21_cls_primitive_autoboxing_false_toClass_nonPrimitive() {
        // Given
        Class<?> cls = double.class;
        Class<?> toClass = String.class;
        boolean autoboxing = false;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("cls is non-primitive, toClass is one of the specific equals classes; expect based on equality")
    void test_TC22_cls_nonPrimitive_toClass_specific_equals() {
        // Given
        Class<?> cls = CustomClass.class;
        Class<?> toClass = AnotherCustomClass.class;
        boolean autoboxing = false;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertEquals(toClass.equals(CustomWrapper.class), result);
    }

    @Test
    @DisplayName("cls is primitive, autoboxing is true, and toClass is Double; expect based on specific primitive toDouble assignment")
    void test_TC23_cls_primitive_autoboxing_true_toClass_Double() {
        // Given
        Class<?> cls = int.class;
        Class<?> toClass = Double.class;
        boolean autoboxing = true;

        // When
        boolean result = ClassUtils.isAssignable(cls, toClass, autoboxing);

        // Then
        assertTrue(result);
    }

    // Define Custom Classes for testing
    static class CustomClass { }
    static class AnotherCustomClass { }
    static class CustomWrapper { }
}