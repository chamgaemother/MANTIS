package org.apache.commons.jxpath.util;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.apache.commons.jxpath.JXPathTypeConversionException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.NodeSet;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class BasicTypeConverterTest {

    private BasicTypeConverter converter;

    @BeforeEach
    void setUp() {
        converter = new BasicTypeConverter();
    }

    @Test
    @DisplayName("canConvert should return true when object is null and toType is non-primitive")
    void testCanConvert_NullObject_NonPrimitive() {
        assertTrue(converter.canConvert(null, String.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is null and toType is primitive")
    void testCanConvert_NullObject_Primitive() {
        assertTrue(converter.canConvert(null, int.class));
    }

    @Test
    @DisplayName("canConvert should return true when toType is assignable from object type")
    void testCanConvert_Assignable() {
        Integer obj = 5;
        assertTrue(converter.canConvert(obj, Number.class));
        assertTrue(converter.canConvert(obj, Object.class));
        assertTrue(converter.canConvert(obj, Integer.class));
    }

    @Test
    @DisplayName("canConvert should return false when toType is not assignable and not handled")
    void testCanConvert_NotAssignable() {
        Object obj = new Object();
        assertFalse(converter.canConvert(obj, Integer.class));
    }

    @Test
    @DisplayName("canConvert should return true when toType is String")
    void testCanConvert_ToString() {
        Object obj = new Object();
        assertTrue(converter.canConvert(obj, String.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is Boolean and toType is Number")
    void testCanConvert_BooleanToNumber() {
        Boolean obj = true;
        assertTrue(converter.canConvert(obj, Integer.class));
        assertTrue(converter.canConvert(obj, BigDecimal.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is Boolean and toType is AtomicBoolean")
    void testCanConvert_BooleanToAtomicBoolean() {
        Boolean obj = false;
        assertTrue(converter.canConvert(obj, java.util.concurrent.atomic.AtomicBoolean.class));
    }

    @Test
    @DisplayName("canConvert should return false when object is Boolean and toType is unsupported")
    void testCanConvert_BooleanToUnsupported() {
        Boolean obj = true;
        assertFalse(converter.canConvert(obj, java.util.concurrent.atomic.AtomicInteger.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is Number and toType is Number")
    void testCanConvert_NumberToNumber() {
        Integer obj = 10;
        assertTrue(converter.canConvert(obj, Double.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is Number and toType is Boolean")
    void testCanConvert_NumberToBoolean() {
        Integer obj = 0;
        assertTrue(converter.canConvert(obj, Boolean.class));
        obj = 5;
        assertTrue(converter.canConvert(obj, Boolean.class));
    }

    @Test
    @DisplayName("canConvert should return false when object is Number and toType is unsupported")
    void testCanConvert_NumberToUnsupported() {
        Double obj = 10.5;
        assertFalse(converter.canConvert(obj, Character.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is String and toType is primitive wrapper")
    void testCanConvert_StringToPrimitiveWrapper() {
        String obj = "123";
        assertTrue(converter.canConvert(obj, Integer.class));
        assertTrue(converter.canConvert(obj, Boolean.class));
        assertTrue(converter.canConvert(obj, Character.class));
    }

    @Test
    @DisplayName("canConvert should return false when object is String and toType is unsupported")
    void testCanConvert_StringToUnsupported() {
        String obj = "test";
        assertFalse(converter.canConvert(obj, Object.class)); // Already handled earlier, should be true
    }

    @Test
    @DisplayName("canConvert should return true for array to array conversion when component types are convertible")
    void testCanConvert_ArrayToArray_Convertible() {
        Integer[] obj = {1, 2, 3};
        assertTrue(converter.canConvert(obj, Number[].class));
    }

    @Test
    @DisplayName("canConvert should return false for array to array conversion when component types are not convertible")
    void testCanConvert_ArrayToArray_NotConvertible() {
        Integer[] obj = {1, 2, 3};
        assertFalse(converter.canConvert(obj, String[].class));
    }

    @Test
    @DisplayName("canConvert should return true for array to collection conversion when collection can be created")
    void testCanConvert_ArrayToCollection_CanCreate() {
        Integer[] obj = {1, 2, 3};
        assertTrue(converter.canConvert(obj, List.class));
        assertTrue(converter.canConvert(obj, Set.class));
    }

    @Test
    @DisplayName("canConvert should return false for array to collection conversion when collection cannot be created")
    void testCanConvert_ArrayToCollection_CannotCreate() {
        Integer[] obj = {1, 2, 3};
        assertFalse(converter.canConvert(obj, SortedSet.class));
    }

    @Test
    @DisplayName("canConvert should return true for array to single element conversion")
    void testCanConvert_ArrayToSingleElement_Convertible() {
        Integer[] obj = {10};
        assertTrue(converter.canConvert(obj, Integer.class));
        assertTrue(converter.canConvert(obj, Number.class));
    }

    @Test
    @DisplayName("canConvert should return false for array to single element conversion when not convertible")
    void testCanConvert_ArrayToSingleElement_NotConvertible() {
        Integer[] obj = {10};
        assertFalse(converter.canConvert(obj, String.class));
    }

    @Test
    @DisplayName("canConvert should handle empty array for single element conversion")
    void testCanConvert_ArrayToSingleElement_EmptyArray() {
        Integer[] obj = {};
        assertTrue(converter.canConvert(obj, Integer.class));
        assertTrue(converter.canConvert(obj, Boolean.class));
        assertFalse(converter.canConvert(obj, Object.class));
    }

    @Test
    @DisplayName("canConvert should return true for Collection to array conversion when elements are convertible")
    void testCanConvert_CollectionToArray_Convertible() {
        Collection<Integer> obj = new ArrayList<>();
        obj.add(1);
        obj.add(2);
        assertTrue(converter.canConvert(obj, Number[].class));
    }

    @Test
    @DisplayName("canConvert should return false for Collection to array conversion when elements are not convertible")
    void testCanConvert_CollectionToArray_NotConvertible() {
        Collection<Integer> obj = new ArrayList<>();
        obj.add(1);
        obj.add(2);
        assertFalse(converter.canConvert(obj, String[].class));
    }

    @Test
    @DisplayName("canConvert should return true for Collection to collection conversion when collection can be created")
    void testCanConvert_CollectionToCollection_CanCreate() {
        Collection<Integer> obj = new ArrayList<>();
        obj.add(1);
        obj.add(2);
        assertTrue(converter.canConvert(obj, List.class));
        assertTrue(converter.canConvert(obj, Set.class));
    }

    @Test
    @DisplayName("canConvert should return false for Collection to collection conversion when collection cannot be created")
    void testCanConvert_CollectionToCollection_CannotCreate() {
        Collection<Integer> obj = new HashSet<>();
        assertFalse(converter.canConvert(obj, SortedSet.class));
    }

    @Test
    @DisplayName("canConvert should return true for non-empty Collection to single element conversion")
    void testCanConvert_CollectionToSingleElement_Convertible() {
        List<Integer> obj = new ArrayList<>();
        obj.add(5);
        assertTrue(converter.canConvert(obj, Integer.class));
        assertTrue(converter.canConvert(obj, Number.class));
    }

    @Test
    @DisplayName("canConvert should return false for non-empty Collection to single element conversion when not convertible")
    void testCanConvert_CollectionToSingleElement_NotConvertible() {
        List<Integer> obj = new ArrayList<>();
        obj.add(5);
        assertFalse(converter.canConvert(obj, String.class));
    }

    @Test
    @DisplayName("canConvert should handle empty Collection for single element conversion")
    void testCanConvert_CollectionToSingleElement_EmptyCollection() {
        List<Integer> obj = new ArrayList<>();
        assertTrue(converter.canConvert(obj, Integer.class));
        assertTrue(converter.canConvert(obj, Boolean.class));
        assertFalse(converter.canConvert(obj, Object.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is NodeSet and values are convertible")
    void testCanConvert_NodeSet_Convertible() {
        NodeSet nodeSet = Mockito.mock(NodeSet.class);
        List<Object> values = new ArrayList<>();
        values.add(1);
        Mockito.when(nodeSet.getValues()).thenReturn(values);
        assertTrue(converter.canConvert(nodeSet, Number.class));
    }

    @Test
    @DisplayName("canConvert should return false when object is NodeSet and values are not convertible")
    void testCanConvert_NodeSet_NotConvertible() {
        NodeSet nodeSet = Mockito.mock(NodeSet.class);
        List<Object> values = new ArrayList<>();
        values.add(new Object());
        Mockito.when(nodeSet.getValues()).thenReturn(values);
        assertFalse(converter.canConvert(nodeSet, Integer.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is Pointer and value is convertible")
    void testCanConvert_Pointer_Convertible() {
        Pointer pointer = Mockito.mock(Pointer.class);
        Mockito.when(pointer.getValue()).thenReturn(10);
        assertTrue(converter.canConvert(pointer, Number.class));
    }

    @Test
    @DisplayName("canConvert should return false when object is Pointer and value is not convertible")
    void testCanConvert_Pointer_NotConvertible() {
        Pointer pointer = Mockito.mock(Pointer.class);
        Mockito.when(pointer.getValue()).thenReturn(new Object());
        assertFalse(converter.canConvert(pointer, Integer.class));
    }

    @Test
    @DisplayName("canConvert should return true when ConvertUtils has a converter for the toType")
    void testCanConvert_ConvertUtils_HasConverter() {
        Object obj = new Object();
        assertTrue(converter.canConvert(obj, BigInteger.class));
    }

    @Test
    @DisplayName("canConvert should return false when ConvertUtils does not have a converter for the toType")
    void testCanConvert_ConvertUtils_NoConverter() {
        Object obj = new Object();
        assertFalse(converter.canConvert(obj, UnconvertibleClass.class));
    }

    @Test
    @DisplayName("canConvert should handle AtomicInteger conversion correctly")
    void testCanConvert_ToAtomicInteger() {
        Integer obj = 10;
        assertTrue(converter.canConvert(obj, java.util.concurrent.atomic.AtomicInteger.class));
    }

    @Test
    @DisplayName("canConvert should return false when object type is array but toType is incompatible")
    void testCanConvert_ArrayToIncompatibleType() {
        Integer[] obj = {1, 2, 3};
        assertFalse(converter.canConvert(obj, String.class));
    }

    @Test
    @DisplayName("canConvert should return true when object is empty array and toType is convertible")
    void testCanConvert_EmptyArray_Convertible() {
        Integer[] obj = {};
        assertTrue(converter.canConvert(obj, List.class));
    }

    @Test
    @DisplayName("canConvert should return false when object is empty array and toType is not convertible")
    void testCanConvert_EmptyArray_NotConvertible() {
        Integer[] obj = {};
        assertFalse(converter.canConvert(obj, Object.class));
    }

    // Helper class to represent an unconvertible type
    static class UnconvertibleClass {
    }
}