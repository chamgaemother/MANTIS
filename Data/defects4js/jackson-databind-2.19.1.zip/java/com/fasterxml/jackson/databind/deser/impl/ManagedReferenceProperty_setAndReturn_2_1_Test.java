package com.fasterxml.jackson.databind.deser.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;

import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ManagedReferenceProperty_setAndReturn_2_1_Test {

    @Test
    @DisplayName("Exception is thrown by _backProperty.set during processing of a non-null element in Object[]")
    void test_TC17_setAndReturn_backPropertySetThrowsIOException_inObjectArray() throws Exception {
        // GIVEN
        Object element = new Object();
        Object[] value = new Object[] { element };
        Object instance = new Object();
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        doThrow(new IOException("Back property set failed")).when(backProperty).set(element, instance);
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, true);

        // WHEN & THEN
        IOException exception = assertThrows(IOException.class, () -> {
            property.setAndReturn(instance, value);
        });
        assertEquals("Back property set failed", exception.getMessage());
        verify(backProperty, times(1)).set(element, instance);
        verify(delegate, never()).setAndReturn(any(), any());
    }

    @Test
    @DisplayName("Exception is thrown by delegate.setAndReturn when setting a non-container value")
    void test_TC18_setAndReturn_delegateSetAndReturnThrowsIOException_nonContainer() throws Exception {
        // GIVEN
        Object value = new Object();
        Object instance = new Object();
        SettableBeanProperty backProperty = mock(SettableBeanProperty.class);
        SettableBeanProperty delegate = mock(SettableBeanProperty.class);
        when(delegate.setAndReturn(instance, value)).thenThrow(new IOException("Delegate set failed"));
        ManagedReferenceProperty property = new ManagedReferenceProperty(delegate, "refName", backProperty, false);

        // WHEN & THEN
        IOException exception = assertThrows(IOException.class, () -> {
            property.setAndReturn(instance, value);
        });
        assertEquals("Delegate set failed", exception.getMessage());
        verify(backProperty, never()).set(any(), any());
        verify(delegate, times(1)).setAndReturn(instance, value);
    }
}
