package org.apache.commons.math3.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class FastMath_pow_2_1_Test {

    @Test
    @DisplayName("pow(x, y) returns NaN when x is 1.0 and y is NaN")
    void TC06_pow_x_one_y_nan_returns_nan() {
        // Given
        double x = 1.0;
        double y = Double.NaN;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertTrue(Double.isNaN(result), "pow(1.0, NaN) should return NaN");
    }

    @Test
    @DisplayName("pow(x, y) returns 1.0 when x is NaN and y is +0.0")
    void TC07_pow_x_nan_y_positive_zero_returns_one() {
        // Given
        double x = Double.NaN;
        double y = +0.0;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertEquals(1.0, result, "pow(NaN, +0.0) should return 1.0");
    }

    @Test
    @DisplayName("pow(x, y) returns NaN when x is negative infinity and y is non-integer")
    void TC08_pow_negative_infty_y_non_integer_returns_nan() {
        // Given
        double x = Double.NEGATIVE_INFINITY;
        double y = 2.5;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertTrue(Double.isNaN(result), "pow(-Infinity, non-integer y) should return NaN");
    }

    @Test
    @DisplayName("pow(x, y) returns NaN when x is negative infinity and y is non-integer negative")
    void TC09_pow_negative_infty_y_non_integer_negative_returns_nan() {
        // Given
        double x = Double.NEGATIVE_INFINITY;
        double y = -3.7;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertTrue(Double.isNaN(result), "pow(-Infinity, non-integer negative y) should return NaN");
    }

    @Test
    @DisplayName("pow(x, y) returns Double.POSITIVE_INFINITY when x > 1 and y is a large positive integer within range")
    void TC10_pow_large_x_large_positive_integer_y_returns_infty() {
        // Given
        double x = 2.0;
        double y = 1e308;

        // When
        double result = FastMath.pow(x, y);

        // Then
        assertEquals(Double.POSITIVE_INFINITY, result, "pow(x > 1, large positive y) should return Infinity");
    }

}