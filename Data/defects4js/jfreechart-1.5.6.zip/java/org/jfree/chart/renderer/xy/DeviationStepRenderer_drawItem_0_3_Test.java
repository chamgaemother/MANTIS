package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class DeviationStepRenderer_drawItem_0_3_Test {

    @Test
    @DisplayName("drawItem processes second pass with isLinePass=true")
    void TC11_drawItem_second_pass_isLinePass_true() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 1;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isLinePass(pass)).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer).drawPrimaryLineAsPath(eq(state), eq(g2), eq(plot), eq(dataset), eq(pass), eq(series), eq(item), eq(domainAxis), eq(rangeAxis), eq(dataArea));
    }

    @Test
    @DisplayName("drawItem processes second pass with isItemPass=true")
    void TC12_drawItem_second_pass_isItemPass_true() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 1;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isItemPass(pass)).thenReturn(true);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer).drawSecondaryPass(eq(g2), eq(plot), eq(dataset), eq(pass), eq(series), eq(item), eq(domainAxis), eq(dataArea), eq(rangeAxis), eq(crosshairState), isNull());
    }

    @Test
    @DisplayName("drawItem does not draw primary line when isLinePass=false and itemLineVisible=false")
    void TC13_drawItem_no_primary_line_when_line_not_visible() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        int series = 0;
        int item = 1;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 1;

        when(renderer.getItemVisible(series, item)).thenReturn(true);
        when(renderer.isLinePass(pass)).thenReturn(false);
        when(renderer.getItemLineVisible(series, item)).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(renderer, never()).drawPrimaryLineAsPath(eq(state), eq(g2), eq(plot), eq(dataset), eq(pass), eq(series), eq(item), eq(domainAxis), eq(rangeAxis), eq(dataArea));
    }

    @Test
    @DisplayName("drawItem throws exception when dataset is not IntervalXYDataset and pass=0")
    void TC14_drawItem_throws_exception_invalid_dataset_type() {
        // Arrange
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class); // Not an IntervalXYDataset
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = new CrosshairState();
        int pass = 0;

        when(renderer.getItemVisible(series, item)).thenReturn(true);

        // Act & Assert
        assertThrows(ClassCastException.class, () -> renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass));
    }

    @Test
    @DisplayName("drawItem processes multiple iterations in pass=0")
    void TC15_drawItem_pass0_multiple_iterations() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = spy(new DeviationStepRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int pass = 0;
        CrosshairState crosshairState = new CrosshairState();

        int itemCount = 5;
        when(dataset.getItemCount(series)).thenReturn(itemCount);
        for (int item = 0; item < itemCount; item++) {
            when(dataset.getXValue(series, item)).thenReturn((double) item);
            when(dataset.getStartYValue(series, item)).thenReturn((double) (item * 10));
            when(dataset.getEndYValue(series, item)).thenReturn((double) (item * 20));
        }

        when(renderer.getItemVisible(series, 0)).thenReturn(true);

        // Act
        for (int item = 0; item < itemCount; item++) {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        }

        // Assert
        verify(g2, atLeastOnce()).fill(any(Shape.class));
    }

}