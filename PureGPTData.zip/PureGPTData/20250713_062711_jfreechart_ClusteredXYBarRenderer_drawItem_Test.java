import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYIntervalSeries;
import org.jfree.data.xy.XYIntervalSeriesCollection;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.renderer.xy.ClusteredXYBarRenderer;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClusteredXYBarRendererTest {

    private ClusteredXYBarRenderer renderer;
    private XYPlot plot;
    private Graphics2D g2;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYItemRendererState state;
    private CrosshairState crosshairState;
    private XYDataset dataset;

    @BeforeEach
    void setUp() {
        renderer = new ClusteredXYBarRenderer(0.1, false);
        plot = mock(XYPlot.class);
        g2 = mock(Graphics2D.class);
        dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        info = mock(PlotRenderingInfo.class);
        domainAxis = new NumberAxis();
        rangeAxis = new NumberAxis();
        state = mock(XYItemRendererState.class);
        crosshairState = mock(CrosshairState.class);
        dataset = createDataset();
    }

    private IntervalXYDataset createDataset() {
        XYIntervalSeries series1 = new XYIntervalSeries("Series1");
        series1.add(1.0, 0.8, 1.2, 5.0, 4.0, 5.5);
        series1.add(2.0, 1.8, 2.2, 8.0, 7.0, 9.0);
        XYIntervalSeries series2 = new XYIntervalSeries("Series2");
        series2.add(1.0, 0.8, 1.2, 7.0, 6.0, 8.0);
        series2.add(2.0, 1.8, 2.2, 9.0, 8.5, 10.0);
        XYIntervalSeriesCollection dataset = new XYIntervalSeriesCollection();
        dataset.addSeries(series1);
        dataset.addSeries(series2);
        return dataset;
    }

    @Test
    void testDrawItemWithPositiveValues() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        
        verify(g2).setPaint(any());
    }

    @Test
    void testDrawItemWithNegativeValues() {
        IntervalXYDataset negativeDataset = new XYIntervalSeriesCollection();
        XYIntervalSeries series = new XYIntervalSeries("Series1");
        series.add(1.0, 0.8, 1.2, -5.0, -6.0, -4.5);
        ((XYIntervalSeriesCollection) negativeDataset).addSeries(series);

        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, negativeDataset, 0, 0, crosshairState, 1);
        
        verify(g2).setPaint(any());
    }

    @Test
    void testDrawItemNotVisible() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.setSeriesVisible(0, false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2, never()).setPaint(any());
    }

    @Test
    void testDrawItemHorizontalOrientation() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);
        
        verify(g2).setPaint(any());
    }

    @Test
    void testDrawItemWithCenterBarAtStartValue() {
        renderer = new ClusteredXYBarRenderer(0.0, true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2).setPaint(any());
    }

    @Test
    void testDrawItemPassZeroWithShadows() {
        renderer.setShadowVisible(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);

        // Since shadows are on, expect paintBarShadow to be called
        verify(g2, atLeastOnce()).setPaint(any());
    }

    @Test
    void testDrawItemWithNullInfo() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, null, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 1);

        verify(g2).setPaint(any());
    }

    @Test
    void testDrawItemWithNullCrosshairState() {
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, null, 1);

        verify(g2).setPaint(any());
    }
}