package org.jfree.chart.title;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.renderer.PaintScale;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class PaintScaleLegend_draw_0_3_Test {

    @Test
    @DisplayName("draw method with multiple subdivisions, multiple strips drawn")
    void TC11_drawWithMultipleSubdivisions() throws Exception {
        // GIVEN
        PaintScale scale = mock(PaintScale.class);
        ValueAxis axis = mock(ValueAxis.class, RETURNS_DEEP_STUBS); // Fix: Needed deep stubs for nested method calls
        PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
        legend.setPosition(RectangleEdge.TOP);
        legend.setSubdivisionCount(3);
        legend.setBackgroundPaint(null);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 50);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        verify(g2, times(3)).fill(any(Rectangle2D.class)); // Verify three strips are drawn
    }

    @Test
    @DisplayName("draw method with axis at Left and backgroundPaint")
    void TC12_drawWithAxisAtLeft() throws Exception {
        // GIVEN
        PaintScale scale = mock(PaintScale.class);
        ValueAxis axis = mock(ValueAxis.class, RETURNS_DEEP_STUBS); // Fix: Needed deep stubs for nested method calls
        PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
        Paint background = Color.GREEN;
        legend.setPosition(RectangleEdge.LEFT);
        legend.setBackgroundPaint(background);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 50);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        verify(g2).setPaint(background); // Verify background paint is set
        verify(g2).fill(area); // Verify area is filled with background paint
    }

    @Test
    @DisplayName("draw method with axis at Right and backgroundPaint")
    void TC13_drawWithAxisAtRight() throws Exception {
        // GIVEN
        PaintScale scale = mock(PaintScale.class);
        ValueAxis axis = mock(ValueAxis.class, RETURNS_DEEP_STUBS); // Fix: Needed deep stubs for nested method calls
        PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
        Paint background = Color.RED;
        legend.setPosition(RectangleEdge.RIGHT);
        legend.setBackgroundPaint(background);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 50);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        verify(g2).setPaint(background); // Verify background paint is set
        verify(g2).fill(area); // Verify area is filled with background paint
    }

    @Test
    @DisplayName("draw method with stripWidth set at Top")
    void TC14_drawWithStripWidthAtTop() throws Exception {
        // GIVEN
        PaintScale scale = mock(PaintScale.class);
        ValueAxis axis = mock(ValueAxis.class, RETURNS_DEEP_STUBS); // Fix: Needed deep stubs for nested method calls
        PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
        legend.setPosition(RectangleEdge.TOP);
        legend.setStripWidth(5.0);
        legend.setSubdivisionCount(2);
        legend.setBackgroundPaint(null);
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, 50);
        Object param = new Object();

        // WHEN
        Object result = legend.draw(g2, area, param);

        // THEN
        assertNull(result);
        verify(g2, times(2)).fill(any(Rectangle2D.class)); // Verify two strips with width 5 are drawn
    }

    @Test
    @DisplayName("draw method throws exception when Graphics2D is null")
    void TC15_drawWithNullGraphics2D() {
        // GIVEN
        PaintScale scale = mock(PaintScale.class);
        ValueAxis axis = mock(ValueAxis.class, RETURNS_DEEP_STUBS); // Fix: Needed deep stubs for nested method calls
        PaintScaleLegend legend = new PaintScaleLegend(scale, axis);
        Rectangle2D area = new Rectangle2D.Double();
        Object param = new Object();

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            legend.draw(null, area, param);
        });
    }
}
