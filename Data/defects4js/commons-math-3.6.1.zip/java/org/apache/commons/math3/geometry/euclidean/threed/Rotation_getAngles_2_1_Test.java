package org.apache.commons.math3.geometry.euclidean.threed;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Rotation_getAngles_2_1_Test {

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and XYZ order where v2.getZ() is within bounds")
    public void TC11() {
        Rotation rotation = new Rotation(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM, 0.3, 0.4, 0.5);
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        double[] expected = {0.3, 0.4, 0.5};
        assertArrayEquals(expected, angles, 1e-10, "Angles should match the input values");
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and XYZ order where v2.getZ() exceeds upper boundary, throwing exception")
    public void TC12() {
        Rotation rotation = new Rotation(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM, Math.PI / 2 + 1e-10, 0.0, 0.0);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        }, "Expected CardanEulerSingularityException to be thrown");
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and XZY order where v2.getY() is within bounds")
    public void TC13() {
        Rotation rotation = new Rotation(RotationOrder.XZY, RotationConvention.FRAME_TRANSFORM, 0.25, 0.35, 0.45);
        double[] angles = rotation.getAngles(RotationOrder.XZY, RotationConvention.FRAME_TRANSFORM);
        double[] expected = {0.25, 0.35, 0.45};
        assertArrayEquals(expected, angles, 1e-10, "Angles should match the input values");
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and XZY order where v2.getY() exceeds upper boundary, throwing exception")
    public void TC14() {
        Rotation rotation = new Rotation(RotationOrder.XZY, RotationConvention.FRAME_TRANSFORM, Math.PI / 2 + 1e-10, 0.0, 0.0);
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XZY, RotationConvention.FRAME_TRANSFORM);
        }, "Expected CardanEulerSingularityException to be thrown");
    }

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and YXZ order where v2.getZ() is within bounds")
    public void TC15() {
        Rotation rotation = new Rotation(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM, 0.2, 0.3, 0.4);
        double[] angles = rotation.getAngles(RotationOrder.YXZ, RotationConvention.FRAME_TRANSFORM);
        double[] expected = {0.2, 0.3, 0.4};
        assertArrayEquals(expected, angles, 1e-10, "Angles should match the input values");
    }

}