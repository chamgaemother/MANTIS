package com.fasterxml.jackson.databind.module;

import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.databind.jsontype.NamedType;

import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.LinkedHashSet;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class SimpleModule_setupModule_1_1_Test {

    // Dummy classes for mixin testing
    static class TargetClass {}
    static class MixinClass {}

    @Test
    @DisplayName("Only _subtypes is not null and empty; registerSubtypes is called with an empty array")
    void TC16_setupModule_withEmptySubtypes() throws Exception {
        // Arrange
        SimpleModule module = new SimpleModule();

        // Use reflection to set _subtypes to an empty LinkedHashSet
        Field subtypesField = SimpleModule.class.getDeclaredField("_subtypes");
        subtypesField.setAccessible(true);
        subtypesField.set(module, new LinkedHashSet<NamedType>());

        // Create mock SetupContext
        Module.SetupContext context = mock(Module.SetupContext.class);

        // Act
        module.setupModule(context);

        // Assert
        verify(context).registerSubtypes(new NamedType[0]);
    }

    @Test
    @DisplayName("Only _subtypes is not null and empty with additional mixins; registerSubtypes is called with an empty array and mix-in annotations are processed")
    void TC17_setupModule_withEmptySubtypesAndMixins() throws Exception {
        // Arrange
        SimpleModule module = new SimpleModule();

        // Use reflection to set _subtypes to an empty LinkedHashSet
        Field subtypesField = SimpleModule.class.getDeclaredField("_subtypes");
        subtypesField.setAccessible(true);
        subtypesField.set(module, new LinkedHashSet<NamedType>());

        // Use reflection to set _mixins to a non-empty HashMap
        Field mixinsField = SimpleModule.class.getDeclaredField("_mixins");
        mixinsField.setAccessible(true);
        HashMap<Class<?>, Class<?>> mixins = new HashMap<>();
        mixins.put(TargetClass.class, MixinClass.class);
        mixinsField.set(module, mixins);

        // Create mock SetupContext
        Module.SetupContext context = mock(Module.SetupContext.class);

        // Act
        module.setupModule(context);

        // Assert
        verify(context).registerSubtypes(new NamedType[0]);
        verify(context).setMixInAnnotations(TargetClass.class, MixinClass.class);
    }
}
