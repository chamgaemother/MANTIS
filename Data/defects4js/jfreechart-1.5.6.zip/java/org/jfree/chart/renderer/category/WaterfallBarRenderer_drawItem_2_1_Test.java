package org.jfree.chart.renderer.category;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.WaterfallBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.ui.GradientPaintTransformer;
import org.jfree.chart.ui.StandardGradientPaintTransformer;
import org.jfree.chart.ui.GradientPaintTransformType;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class WaterfallBarRenderer_drawItem_2_1_Test {
    
    @Test
    @DisplayName("TC21: drawItem with valDiff equal to 0.0 uses positiveBarPaint")
    public void TC21_drawItem_valDiffZero_usesPositiveBarPaint() throws Exception {
        // Arrange
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        Method setPositiveBarPaint = WaterfallBarRenderer.class.getMethod("setPositiveBarPaint", Paint.class);
        Paint positivePaint = new Color(0, 255, 0);
        setPositiveBarPaint.invoke(renderer, positivePaint);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Method setSeriesRunningTotal = CategoryItemRendererState.class.getDeclaredMethod("setSeriesRunningTotal", double.class);
        setSeriesRunningTotal.setAccessible(true);
        setSeriesRunningTotal.invoke(state, 100.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(row, column)).thenReturn(0);

        RectangleEdge edge = RectangleEdge.LEFT;

        when(plot.getRangeAxisEdge()).thenReturn(edge);
        when(rangeAxis.valueToJava2D(100.0, dataArea, edge)).thenReturn(50.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2).setPaint(positivePaint);

        Method getSeriesRunningTotal = CategoryItemRendererState.class.getDeclaredMethod("getSeriesRunningTotal");
        getSeriesRunningTotal.setAccessible(true);
        double runningTotal = (double) getSeriesRunningTotal.invoke(state);
        assertEquals(100.0, runningTotal, "Series running total should remain unchanged when valDiff is zero.");
    }

    @Test
    @DisplayName("TC22: drawItem with j2dy1 less than j2dy0, leading to swapping y0 and y1 and using appropriate paint")
    public void TC22_drawItem_j2dy1LessThan_j2dy0_swapsYAndUsesNegativeBarPaint() throws Exception {
        // Arrange
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        Method setNegativeBarPaint = WaterfallBarRenderer.class.getMethod("setNegativeBarPaint", Paint.class);
        Paint negativePaint = new Color(255, 0, 0);
        setNegativeBarPaint.invoke(renderer, negativePaint);

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Method setSeriesRunningTotal = CategoryItemRendererState.class.getDeclaredMethod("setSeriesRunningTotal", double.class);
        setSeriesRunningTotal.setAccessible(true);
        setSeriesRunningTotal.invoke(state, 100.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(row, column)).thenReturn(-150);

        RectangleEdge edge = RectangleEdge.LEFT;

        when(plot.getRangeAxisEdge()).thenReturn(edge);
        when(rangeAxis.valueToJava2D(100.0, dataArea, edge)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(-50.0, dataArea, edge)).thenReturn(30.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2).setPaint(negativePaint);

        ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(g2).fill(rectCaptor.capture());
        Rectangle2D rect = rectCaptor.getValue();
        assertEquals(30.0, rect.getY(), 0.001, "y0 should be set to j2dy1 after swapping.");
        assertEquals(20.0, rect.getHeight(), 0.001, "Height should be the difference when swapped.");

        Method getSeriesRunningTotal = CategoryItemRendererState.class.getDeclaredMethod("getSeriesRunningTotal");
        getSeriesRunningTotal.setAccessible(true);
        double runningTotal = (double) getSeriesRunningTotal.invoke(state);
        assertEquals(-50.0, runningTotal, "Series running total should be updated correctly after drawing the item.");
    }

    @Test
    @DisplayName("TC23: drawItem with gradientPaintTransformer present and seriesPaint is GradientPaint")
    public void TC23_drawItem_withGradientPaintTransformer_andGradientPaint() throws Exception {
        // Arrange
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        Method setFirstBarPaint = WaterfallBarRenderer.class.getMethod("setFirstBarPaint", Paint.class);
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.BLUE, 0f, 0f, Color.CYAN);
        setFirstBarPaint.invoke(renderer, gradientPaint);

        renderer.setGradientPaintTransformer(new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_VERTICAL));

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Method setSeriesRunningTotal = CategoryItemRendererState.class.getDeclaredMethod("setSeriesRunningTotal", double.class);
        setSeriesRunningTotal.setAccessible(true);
        setSeriesRunningTotal.invoke(state, 0.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(row, column)).thenReturn(100);

        RectangleEdge edge = RectangleEdge.LEFT;

        when(plot.getRangeAxisEdge()).thenReturn(edge);
        when(rangeAxis.valueToJava2D(0.0, dataArea, edge)).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(100.0, dataArea, edge)).thenReturn(100.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2).setPaint(any(Paint.class));

        ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(g2).fill(rectCaptor.capture());
        Rectangle2D rect = rectCaptor.getValue();
        assertNotNull(rect, "Bar should be filled with transformed GradientPaint.");
    }

    @Test
    @DisplayName("TC24: drawItem with gradientPaintTransformer present but seriesPaint is not GradientPaint")
    public void TC24_drawItem_withGradientPaintTransformer_butNonGradientPaint() throws Exception {
        // Arrange
        WaterfallBarRenderer renderer = new WaterfallBarRenderer();
        Method setPositiveBarPaint = WaterfallBarRenderer.class.getMethod("setPositiveBarPaint", Paint.class);
        Paint positivePaint = Color.GREEN;
        setPositiveBarPaint.invoke(renderer, positivePaint);

        renderer.setGradientPaintTransformer(new StandardGradientPaintTransformer(GradientPaintTransformType.CENTER_VERTICAL));

        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = new CategoryItemRendererState(null);
        Method setSeriesRunningTotal = CategoryItemRendererState.class.getDeclaredMethod("setSeriesRunningTotal", double.class);
        setSeriesRunningTotal.setAccessible(true);
        setSeriesRunningTotal.invoke(state, 0.0);

        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 1;
        int pass = 0;

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(row, column)).thenReturn(50);

        RectangleEdge edge = RectangleEdge.LEFT;

        when(plot.getRangeAxisEdge()).thenReturn(edge);
        when(rangeAxis.valueToJava2D(0.0, dataArea, edge)).thenReturn(0.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, edge)).thenReturn(50.0);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(g2).setPaint(positivePaint);

        ArgumentCaptor<Rectangle2D> rectCaptor = ArgumentCaptor.forClass(Rectangle2D.class);
        verify(g2).fill(rectCaptor.capture());
        Rectangle2D rect = rectCaptor.getValue();
        assertNotNull(rect, "Bar should be filled with positiveBarPaint without transformation.");
    }

//     @Test
//     @DisplayName("TC25: drawItem with entityCollection present but addItemEntity throws exception")
//     public void TC25_drawItem_addItemEntityThrowsException() throws Exception {
        // Arrange
//         WaterfallBarRenderer renderer = new WaterfallBarRenderer();
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = new CategoryItemRendererState(null);
//         Method setSeriesRunningTotal = CategoryItemRendererState.class.getDeclaredMethod("setSeriesRunningTotal", double.class);
//         setSeriesRunningTotal.setAccessible(true);
//         setSeriesRunningTotal.invoke(state, 0.0);
// 
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entities = mock(EntityCollection.class);
//         
//         state.setEntityCollection(entities);
// 
//         int row = 0;
//         int column = 1;
//         int pass = 0;
// 
//         RectangleEdge edge = RectangleEdge.LEFT;
// 
//         when(plot.getRangeAxisEdge()).thenReturn(edge);
//         when(dataset.getColumnCount()).thenReturn(3);
//         when(dataset.getValue(row, column)).thenReturn(50);
// 
//         when(rangeAxis.valueToJava2D(0.0, dataArea, edge)).thenReturn(0.0);
//         when(rangeAxis.valueToJava2D(50.0, dataArea, edge)).thenReturn(50.0);
// 
//         WaterfallBarRenderer spyRenderer = Mockito.spy(renderer);
//         doThrow(new RuntimeException("addItemEntity exception")).when(spyRenderer).addItemEntity(any(EntityCollection.class), any(CategoryDataset.class), eq(row), eq(column), any(Rectangle2D.class));
// 
        // Act & Assert
//         RuntimeException exception = assertThrows(RuntimeException.class, () -> {
//             spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
//         }, "Expected drawItem to throw RuntimeException when addItemEntity throws exception");
// 
//         assertEquals("addItemEntity exception", exception.getMessage(), "Exception message should match.");
//     }
}