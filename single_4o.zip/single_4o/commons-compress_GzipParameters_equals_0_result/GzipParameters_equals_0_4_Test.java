package org.apache.commons.compress.compressors.gzip;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

public class GzipParameters_equals_0_4_Test {

    @Test
    @DisplayName("All matching field values yield true.")
    void testAllMatchingFieldsYieldTrue() {
        // Given
        GzipParameters params1 = new GzipParameters();
        params1.setBufferSize(4096);
        params1.setComment("test");
        params1.setCompressionLevel(5);
        params1.setDeflateStrategy(0);
        params1.setExtraField(new BasicExtraField()); // Directly use BasicExtraField
        params1.setFileName("file.gz");
        params1.setFileNameCharset(StandardCharsets.US_ASCII);
        params1.setHeaderCrc(true);
        params1.setModificationInstant(Instant.now());
        params1.setOperatingSystem(GzipParameters.OS.UNIX);
        params1.setTrailerCrc(12345);
        params1.setTrailerISize(100);

        GzipParameters params2 = new GzipParameters();
        params2.setBufferSize(4096);
        params2.setComment("test");
        params2.setCompressionLevel(5);
        params2.setDeflateStrategy(0);
        params2.setExtraField(new BasicExtraField()); // Directly use BasicExtraField
        params2.setFileName("file.gz");
        params2.setFileNameCharset(StandardCharsets.US_ASCII);
        params2.setHeaderCrc(true);
        params2.setModificationInstant(params1.getModificationInstant());
        params2.setOperatingSystem(GzipParameters.OS.UNIX);
        params2.setTrailerCrc(12345);
        params2.setTrailerISize(100);

        // When
        boolean result = params1.equals(params2);

        // Then
        assertTrue(result, "Expected params1 to equal params2 when all fields match.");
    }

    // BasicExtraField Replacement for Mock
    private static class BasicExtraField {
        // Implement necessary methods if needed or leave empty if not required
    }
}
