import static org.junit.jupiter.api.Assertions.*;
import org.jfree.chart.util.DirectionalGradientPaintTransformer;
import org.jfree.chart.ui.GradientPaintTransformer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.awt.*;
import java.awt.geom.Rectangle2D;

public class DirectionalGradientPaintTransformerTest {

    @Test
    public void testTransformWithNullPaint() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        Shape target = new Rectangle2D.Double(0, 0, 10, 10);
        assertThrows(NullPointerException.class, () -> {
            transformer.transform(null, target);
        });
    }

    @Test
    public void testTransformWithNullTarget() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 1, 1, Color.BLUE);
        assertThrows(NullPointerException.class, () -> {
            transformer.transform(paint, null);
        });
    }

    @ParameterizedTest
    @CsvSource({
            "0, 0, 0, 10, 0, 10, 5, 10, false",  // Vertical
            "0, 0, 10, 0, 10, 0, 10, 0, false",  // Horizontal
            "0, 0, 10, 10, 10, 10, 10, 10, false",  // Diagonal upper-left to lower-right
            "5, 5, 15, 15, 5, 20, 15, 15, false",  // Diagonal lower-left to upper-right
            "0, 0, 0, 10, 0, 10, 2.5, 10, true",  // Vertical cyclic
            "0, 0, 10, 0, 10, 0, 5, 0, true",  // Horizontal cyclic
            "0, 0, 10, 10, 5, 5, 10, 10, true",  // Diagonal upper-left to lower-right cyclic
            "5, 5, 15, 15, 5, 20, 10, 12.5, true"  // Diagonal lower-left to upper-right cyclic
    })
    public void testTransform(int px1, int py1, int px2, int py2, int bx, int by, int xResult, int yResult, boolean cyclic) {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(px1, py1, Color.RED, px2, py2, Color.BLUE, cyclic);
        Shape target = new Rectangle2D.Double(bx, by, 10.0, 10.0);
        GradientPaint transformedPaint = transformer.transform(paint, target);
        assertEquals(new GradientPaint(xResult, yResult, Color.RED, transformedPaint.getPoint2().getX(), transformedPaint.getPoint2().getY(), Color.BLUE, cyclic), transformedPaint);
    }
}