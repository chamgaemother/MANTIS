package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.IntervalXYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DeviationStepRenderer_drawItem_0_9_Test {

    @Test
    @DisplayName("drawItem handles extremely large coordinate values")
    public void TC41_drawItem_extremelyLargeCoordinates() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        DeviationRenderer.State state = new DeviationRenderer.State(null);
        state.lowerCoordinates = new ArrayList<>();
        state.upperCoordinates = new ArrayList<>();
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;
        
        // Set up Dataset with extremely large values
        when(dataset.getXValue(series, item)).thenReturn(Double.MAX_VALUE);
        when(dataset.getStartYValue(series, item)).thenReturn(Double.MAX_VALUE);
        when(dataset.getEndYValue(series, item)).thenReturn(Double.MAX_VALUE);
        
        // Plot setup
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        // Set up Axis transformations to handle large values without overflow
        when(domainAxis.valueToJava2D(Double.MAX_VALUE, dataArea, RectangleEdge.BOTTOM)).thenReturn(Double.MAX_VALUE / 2);
        when(rangeAxis.valueToJava2D(Double.MAX_VALUE, dataArea, RectangleEdge.LEFT)).thenReturn(Double.MAX_VALUE / 2);

        // Act
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(g2, times(1)).setComposite(any());
    }
    
    @Test
    @DisplayName("drawItem handles rapid consecutive calls without state corruption")
    public void TC42_drawItem_rapidConsecutiveCalls() throws Exception {
        // Arrange
        DeviationStepRenderer renderer = new DeviationStepRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        DeviationRenderer.State state = new DeviationRenderer.State(null);
        state.lowerCoordinates = new ArrayList<>();
        state.upperCoordinates = new ArrayList<>();
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 800, 600);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);

        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);

        // Set up Dataset
        when(dataset.getXValue(series, item)).thenReturn(100.0);
        when(dataset.getStartYValue(series, item)).thenReturn(50.0);
        when(dataset.getEndYValue(series, item)).thenReturn(150.0);

        // Plot setup
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);

        // Set up Axis transformations
        when(domainAxis.valueToJava2D(100.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(400.0);
        when(rangeAxis.valueToJava2D(50.0, dataArea, RectangleEdge.LEFT)).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(150.0, dataArea, RectangleEdge.LEFT)).thenReturn(100.0);

        // Act
        for (int pass = 0; pass < 2; pass++) {
            renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
        }

        // Assert
        assertNotNull(state.lowerCoordinates);
        assertNotNull(state.upperCoordinates);
        verify(state.lowerCoordinates, times(2));
        verify(state.upperCoordinates, times(2));
    }

}