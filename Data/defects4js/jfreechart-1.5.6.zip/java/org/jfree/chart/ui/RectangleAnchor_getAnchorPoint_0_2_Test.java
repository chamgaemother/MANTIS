package org.jfree.chart.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

public class RectangleAnchor_getAnchorPoint_0_2_Test {

    @Test
    @DisplayName("Returns top-left point when anchor is TOP_LEFT")
    public void TC06_ReturnsTopLeftPointWhenAnchorIsTopLeft() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.TOP_LEFT;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(0.0, point.getX(), "X coordinate should be 0.0");
        assertEquals(0.0, point.getY(), "Y coordinate should be 0.0");
    }

    @Test
    @DisplayName("Returns top-right point when anchor is TOP_RIGHT")
    public void TC07_ReturnsTopRightPointWhenAnchorIsTopRight() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.TOP_RIGHT;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(10.0, point.getX(), "X coordinate should be 10.0");
        assertEquals(0.0, point.getY(), "Y coordinate should be 0.0");
    }

    @Test
    @DisplayName("Returns bottom-left point when anchor is BOTTOM_LEFT")
    public void TC08_ReturnsBottomLeftPointWhenAnchorIsBottomLeft() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.BOTTOM_LEFT;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(0.0, point.getX(), "X coordinate should be 0.0");
        assertEquals(10.0, point.getY(), "Y coordinate should be 10.0");
    }

    @Test
    @DisplayName("Returns bottom-right point when anchor is BOTTOM_RIGHT")
    public void TC09_ReturnsBottomRightPointWhenAnchorIsBottomRight() {
        // GIVEN
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
        RectangleAnchor anchor = RectangleAnchor.BOTTOM_RIGHT;

        // WHEN
        Point2D point = anchor.getAnchorPoint(rect);

        // THEN
        assertEquals(10.0, point.getX(), "X coordinate should be 10.0");
        assertEquals(10.0, point.getY(), "Y coordinate should be 10.0");
    }

    @Test
    @DisplayName("Throws exception when rectangle is null")
    public void TC10_ThrowsExceptionWhenRectangleIsNull() {
        // GIVEN
        Rectangle2D rect = null;
        RectangleAnchor anchor = RectangleAnchor.CENTER;

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            anchor.getAnchorPoint(rect);
        }, "Expected getAnchorPoint(null) to throw, but it didn't");
        assertTrue(exception.getMessage().contains("rectangle"), "Exception message should contain 'rectangle'");
    }
}