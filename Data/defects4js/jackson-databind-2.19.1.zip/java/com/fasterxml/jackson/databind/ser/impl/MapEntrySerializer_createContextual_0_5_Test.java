package com.fasterxml.jackson.databind.ser.impl;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MapEntrySerializer_createContextual_0_5_Test {

    private SerializerProvider provider;
    private BeanProperty property;
    private MapEntrySerializer serializer;

    @BeforeEach
    void setUp() throws Exception {
        provider = mock(SerializerProvider.class);
        property = mock(BeanProperty.class);
        when(provider.getAnnotationIntrospector()).thenReturn(mock(com.fasterxml.jackson.databind.AnnotationIntrospector.class));
        JavaType entryType = mock(JavaType.class);
        JavaType keyType = mock(JavaType.class);
        JavaType valueType = mock(JavaType.class);
        serializer = new MapEntrySerializer(entryType, keyType, valueType, true, null, property);
    }

    @Test
    @DisplayName("When valueToSuppress default is an array, sets valueToSuppress to ArrayComparator")
    void testTC21() throws Exception {
        // GIVEN
        String[] defaultArray = {"default1", "default2"};
        when(property.findPropertyInclusion(any(), isNull())).thenReturn(JsonInclude.Value.construct(JsonInclude.Include.NON_DEFAULT, JsonInclude.Include.ALWAYS));
        when(provider.includeFilterInstance(any(), any())).thenReturn(null);
        when(provider.includeFilterSuppressNulls(any())).thenReturn(true);
        // Manually mock the expected default value behavior
        JavaType valueType = serializer.getContentType();
        when(valueType.hasGenericTypes()).thenReturn(true);

        // WHEN
        JsonSerializer<?> result = serializer.createContextual(provider, property);

        // THEN
        // Access private fields using reflection
        Field valueToSuppressField = MapEntrySerializer.class.getDeclaredField("_suppressableValue");
        valueToSuppressField.setAccessible(true);
        Object valueToSuppress = valueToSuppressField.get(result);

        Field suppressNullsField = MapEntrySerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        boolean suppressNulls = suppressNullsField.getBoolean(result);

        // Assert valueToSuppress is ArrayComparator of defaultArray and suppressNulls is true
        assertNotNull(valueToSuppress, "valueToSuppress should not be null");
        assertTrue(suppressNulls, "suppressNulls should be true");
    }

    @Test
    @DisplayName("When value type is not a reference type and content inclusion is NON_ABSENT")
    void testTC22() throws Exception {
        // GIVEN
        when(property.getMember()).thenReturn(mock(AnnotatedMember.class));
        JavaType valueType = (JavaType) serializer.getContentType();
        when(valueType.isJavaLangObject()).thenReturn(false);
        when(valueType.isReferenceType()).thenReturn(false);
        when(property.findPropertyInclusion(any(), isNull())).thenReturn(JsonInclude.Value.construct(JsonInclude.Include.NON_ABSENT, JsonInclude.Include.ALWAYS));

        // WHEN
        JsonSerializer<?> result = serializer.createContextual(provider, property);

        // Access private fields using reflection
        Field valueToSuppressField = MapEntrySerializer.class.getDeclaredField("_suppressableValue");
        valueToSuppressField.setAccessible(true);
        Object valueToSuppress = valueToSuppressField.get(result);

        Field suppressNullsField = MapEntrySerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        boolean suppressNulls = suppressNullsField.getBoolean(result);

        // THEN
        // Assert valueToSuppress is null and suppressNulls is true
        assertNull(valueToSuppress, "valueToSuppress should be null");
        assertTrue(suppressNulls, "suppressNulls should be true");
    }

    @Test
    @DisplayName("When includeFilterInstance returns non-null, sets valueToSuppress and suppressNulls accordingly")
    void testTC23() throws Exception {
        // GIVEN
        Object customFilterInstance = new Object();
        when(property.getMember()).thenReturn(mock(AnnotatedMember.class));
        when(provider.includeFilterInstance(any(), any())).thenReturn(customFilterInstance);
        when(provider.includeFilterSuppressNulls(any())).thenReturn(true);

        // WHEN
        JsonSerializer<?> result = serializer.createContextual(provider, property);

        // THEN
        // Access private fields using reflection
        Field valueToSuppressField = MapEntrySerializer.class.getDeclaredField("_suppressableValue");
        valueToSuppressField.setAccessible(true);
        Object valueToSuppress = valueToSuppressField.get(result);

        Field suppressNullsField = MapEntrySerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        boolean suppressNulls = suppressNullsField.getBoolean(result);

        // Assert valueToSuppress is customFilterInstance and suppressNulls is true
        assertEquals(customFilterInstance, valueToSuppress, "valueToSuppress should be customFilterInstance");
        assertTrue(suppressNulls, "suppressNulls should be true");
    }

    @Test
    @DisplayName("When includeFilterInstance returns null, sets suppressNulls based on includeFilterSuppressNulls")
    void testTC24() throws Exception {
        // GIVEN
        when(property.getMember()).thenReturn(mock(AnnotatedMember.class));
        when(provider.includeFilterInstance(any(), any())).thenReturn(null);
        when(provider.includeFilterSuppressNulls(isNull())).thenReturn(true);

        // WHEN
        JsonSerializer<?> result = serializer.createContextual(provider, property);

        // THEN
        // Access private fields using reflection
        Field suppressNullsField = MapEntrySerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        boolean suppressNulls = suppressNullsField.getBoolean(result);

        // Assert suppressNulls is true
        assertTrue(suppressNulls, "suppressNulls should be true");
    }

    @Test
    @DisplayName("When includeFilterSuppressNulls returns false, suppressNulls is set to false")
    void testTC25() throws Exception {
        // GIVEN
        when(property.getMember()).thenReturn(mock(AnnotatedMember.class));
        when(provider.includeFilterInstance(any(), any())).thenReturn(null);
        when(provider.includeFilterSuppressNulls(any())).thenReturn(false);

        // WHEN
        JsonSerializer<?> result = serializer.createContextual(provider, property);

        // THEN
        // Access private fields using reflection
        Field suppressNullsField = MapEntrySerializer.class.getDeclaredField("_suppressNulls");
        suppressNullsField.setAccessible(true);
        boolean suppressNulls = suppressNullsField.getBoolean(result);

        // Assert suppressNulls is false
        assertFalse(suppressNulls, "suppressNulls should be false");
    }
}