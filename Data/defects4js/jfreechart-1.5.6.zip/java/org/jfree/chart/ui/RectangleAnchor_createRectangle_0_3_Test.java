package org.jfree.chart.ui;

import java.awt.geom.Rectangle2D;
import org.jfree.chart.ui.Size2D;
import org.jfree.chart.ui.RectangleAnchor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class RectangleAnchor_createRectangle_0_3_Test {

    @Test
    @DisplayName("createRectangle with null RectangleAnchor returns null")
    void TC11_createRectangle_with_null_RectangleAnchor_returns_null() {
        // Given
        Size2D dimensions = new Size2D(100.0, 200.0);
        double anchorX = 150.0;
        double anchorY = 250.0;
        RectangleAnchor anchor = null;

        // When
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // Then
        assertNull(result, "Expected result to be null when anchor is null");
    }

    @Test
    @DisplayName("createRectangle with invalid RectangleAnchor returns null")
    void TC12_createRectangle_with_invalid_RectangleAnchor_returns_null() {
        // Given
        Size2D dimensions = new Size2D(150.0, 250.0);
        double anchorX = 200.0;
        double anchorY = 300.0;
        // RectangleAnchor does not support invalid values, so we use null to simulate an invalid anchor
        RectangleAnchor anchor = null;

        // When
        Rectangle2D result = RectangleAnchor.createRectangle(dimensions, anchorX, anchorY, anchor);

        // Then
        assertNull(result, "Expected result to be null when anchor is invalid");
    }

}