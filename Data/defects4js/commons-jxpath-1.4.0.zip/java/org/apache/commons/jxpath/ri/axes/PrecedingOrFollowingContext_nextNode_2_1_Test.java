package org.apache.commons.jxpath.ri.axes;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Stack;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PrecedingOrFollowingContext_nextNode_2_1_Test {

    @Test
    @DisplayName("nextNode() returns false when setStarted=true, stack is empty, and currentRootLocation is root")
    void TC23_nextNode_stack_empty_and_root_returns_false() throws Exception {
        // Arrange
        EvalContext parentContext = mock(EvalContext.class);
        NodeTest nodeTest = mock(NodeTest.class);
        boolean reverse = false;

        PrecedingOrFollowingContext context = new PrecedingOrFollowingContext(parentContext, nodeTest, reverse);

        // Use reflection to set private fields
        Field setStartedField = PrecedingOrFollowingContext.class.getDeclaredField("setStarted");
        setStartedField.setAccessible(true);
        setStartedField.set(context, true);

        Field stackField = PrecedingOrFollowingContext.class.getDeclaredField("stack");
        stackField.setAccessible(true);
        stackField.set(context, new Stack<>());

        NodePointer rootNodePointer = mock(NodePointer.class);
        when(rootNodePointer.isRoot()).thenReturn(true);
        when(parentContext.getCurrentNodePointer()).thenReturn(rootNodePointer);

        Field currentRootLocationField = PrecedingOrFollowingContext.class.getDeclaredField("currentRootLocation");
        currentRootLocationField.setAccessible(true);
        currentRootLocationField.set(context, rootNodePointer);

        // Act
        boolean result = context.nextNode();

        // Assert
        assertFalse(result, "nextNode() should return false when stack is empty and currentRootLocation is root");
    }

    @Test
    @DisplayName("nextNode() returns true when reverse=true and nodeTest matches on a nested child iterator")
    void TC24_nextNode_reverse_true_nodeTest_matches_nested_child() throws Exception {
        // Arrange
        EvalContext parentContext = mock(EvalContext.class);
        NodeTest nodeTest = mock(NodeTest.class);
        boolean reverse = true;

        PrecedingOrFollowingContext context = new PrecedingOrFollowingContext(parentContext, nodeTest, reverse);

        // Use reflection to set private fields
        Field setStartedField = PrecedingOrFollowingContext.class.getDeclaredField("setStarted");
        setStartedField.setAccessible(true);
        setStartedField.set(context, true);

        Stack<NodeIterator> stack = new Stack<>();
        NodeIterator childIterator = mock(NodeIterator.class);
        when(childIterator.setPosition(anyInt())).thenReturn(true);
        NodePointer childNodePointer = mock(NodePointer.class);
        when(childNodePointer.isLeaf()).thenReturn(false);
        when(childNodePointer.testNode(nodeTest)).thenReturn(true);
        when(childIterator.getNodePointer()).thenReturn(childNodePointer);
        stack.push(childIterator);

        Field stackField = PrecedingOrFollowingContext.class.getDeclaredField("stack");
        stackField.setAccessible(true);
        stackField.set(context, stack);

        NodePointer currentNodePointer = mock(NodePointer.class);
        when(childIterator.getNodePointer()).thenReturn(currentNodePointer);

        Field currentRootLocationField = PrecedingOrFollowingContext.class.getDeclaredField("currentRootLocation");
        currentRootLocationField.setAccessible(true);
        NodePointer rootNodePointer = mock(NodePointer.class);
        when(parentContext.getCurrentNodePointer()).thenReturn(rootNodePointer);
        currentRootLocationField.set(context, rootNodePointer);

        // Act
        boolean result = context.nextNode();

        // Assert
        assertTrue(result, "nextNode() should return true when reverse is true and nodeTest matches on a nested child iterator");
    }

    @Test
    @DisplayName("nextNode() iterates with setStarted=true, reverse=false, and nodeTest never matches, eventually returns false")
    void TC25_nextNode_iteration_no_matches_returns_false() throws Exception {
        // Arrange
        EvalContext parentContext = mock(EvalContext.class);
        NodeTest nodeTest = mock(NodeTest.class);
        boolean reverse = false;

        PrecedingOrFollowingContext context = new PrecedingOrFollowingContext(parentContext, nodeTest, reverse);

        // Use reflection to set private fields
        Field setStartedField = PrecedingOrFollowingContext.class.getDeclaredField("setStarted");
        setStartedField.setAccessible(true);
        setStartedField.set(context, true);

        Stack<NodeIterator> stack = new Stack<>();
        NodeIterator iterator1 = mock(NodeIterator.class);
        when(iterator1.setPosition(anyInt())).thenReturn(false);
        NodeIterator iterator2 = mock(NodeIterator.class);
        when(iterator2.setPosition(anyInt())).thenReturn(false);
        stack.push(iterator1);
        stack.push(iterator2);

        Field stackField = PrecedingOrFollowingContext.class.getDeclaredField("stack");
        stackField.setAccessible(true);
        stackField.set(context, stack);

        NodePointer currentRootPointer = mock(NodePointer.class);
        when(currentRootPointer.getParent()).thenReturn(null);
        when(currentRootPointer.isRoot()).thenReturn(false);
        when(parentContext.getCurrentNodePointer()).thenReturn(currentRootPointer);

        Field currentRootLocationField = PrecedingOrFollowingContext.class.getDeclaredField("currentRootLocation");
        currentRootLocationField.setAccessible(true);
        currentRootLocationField.set(context, currentRootPointer);

        // Act
        boolean result = context.nextNode();

        // Assert
        assertFalse(result, "nextNode() should return false when nodeTest never matches during iteration");
    }

    @Test
    @DisplayName("nextNode() handles multiple iterations with reverse=true and nodeTest matches on the last iterator")
    void TC26_nextNode_reverse_true_nodeTest_matches_last_iterator() throws Exception {
        // Arrange
        EvalContext parentContext = mock(EvalContext.class);
        NodeTest nodeTest = mock(NodeTest.class);
        boolean reverse = true;

        PrecedingOrFollowingContext context = new PrecedingOrFollowingContext(parentContext, nodeTest, reverse);

        // Use reflection to set private fields
        Field setStartedField = PrecedingOrFollowingContext.class.getDeclaredField("setStarted");
        setStartedField.setAccessible(true);
        setStartedField.set(context, true);

        Stack<NodeIterator> stack = new Stack<>();
        NodeIterator iterator1 = mock(NodeIterator.class);
        when(iterator1.setPosition(anyInt())).thenReturn(true);
        NodePointer nodePointer1 = mock(NodePointer.class);
        when(nodePointer1.isLeaf()).thenReturn(false);
        when(nodePointer1.testNode(nodeTest)).thenReturn(false);
        when(iterator1.getNodePointer()).thenReturn(nodePointer1);

        NodeIterator iterator2 = mock(NodeIterator.class);
        when(iterator2.setPosition(anyInt())).thenReturn(true);
        NodePointer nodePointer2 = mock(NodePointer.class);
        when(nodePointer2.isLeaf()).thenReturn(true);
        when(nodePointer2.testNode(nodeTest)).thenReturn(true);
        when(iterator2.getNodePointer()).thenReturn(nodePointer2);

        stack.push(iterator1);
        stack.push(iterator2);

        Field stackField = PrecedingOrFollowingContext.class.getDeclaredField("stack");
        stackField.setAccessible(true);
        stackField.set(context, stack);

        NodePointer currentRootPointer = mock(NodePointer.class);
        when(parentContext.getCurrentNodePointer()).thenReturn(currentRootPointer);
        when(currentRootPointer.getParent()).thenReturn(mock(NodePointer.class));

        Field currentRootLocationField = PrecedingOrFollowingContext.class.getDeclaredField("currentRootLocation");
        currentRootLocationField.setAccessible(true);
        currentRootLocationField.set(context, currentRootPointer);

        // Act
        boolean result = context.nextNode();

        // Assert
        assertTrue(result, "nextNode() should return true when nodeTest matches on the last iterator during reverse iteration");
    }
}