import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import org.apache.commons.collections4.iterators.PermutationIterator;

public class PermutationIterator_next_1_1_Test {

    @Test
    @DisplayName("next() returns a new permutation when the largest mobile integer is identified and swapped")
    public void TC15_nextReturnsNewPermutationAfterSwap() throws Exception {
        // Initialize PermutationIterator with a collection of three distinct elements
        List<String> elements = Arrays.asList("A", "B", "C");
        PermutationIterator<String> iterator = new PermutationIterator<>(elements);
        iterator.next(); // Initialize first permutation

        // Call next()
        List<String> result = iterator.next();

        // Assert the next permutation is correct
        assertEquals(Arrays.asList("A", "C", "B"), result, "The next permutation should be [A, C, B]");

        // Assert directions are updated correctly
        // Access the private 'direction' field via reflection
        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        boolean[] direction = (boolean[]) directionField.get(iterator);

        // Expected direction after swap: [false, false, false]
        assertArrayEquals(new boolean[]{false, false, false}, direction, "Directions should be updated correctly.");
    }

    @Test
    @DisplayName("next() returns the last permutation and sets nextPermutation to null when no mobile integer is present")
    public void TC16_nextReturnsLastPermutationAndHandlesEnd() throws Exception {
        // Initialize PermutationIterator with a collection of two elements
        List<String> elements = Arrays.asList("A", "B");
        PermutationIterator<String> iterator = new PermutationIterator<>(elements);
        iterator.next(); // First permutation ["A", "B"]
        iterator.next(); // Last permutation ["B", "A"]

        // Call next() again, which should set nextPermutation to null
        List<String> lastPermutation = iterator.next();

        // Assert the last permutation is correct
        assertEquals(Arrays.asList("B", "A"), lastPermutation, "The last permutation should be [B, A]");

        // Access the private 'nextPermutation' field via reflection and assert it's null
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        Object nextPermutation = nextPermutationField.get(iterator);
        assertNull(nextPermutation, "nextPermutation should be set to null after the last permutation.");

        // Further calls to next() should throw NoSuchElementException
        assertThrows(NoSuchElementException.class, () -> iterator.next(), "Calling next() after all permutations should throw NoSuchElementException.");
    }
}