package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

public class ValueUtils_getValue_0_2_Test {

    @Test
    @DisplayName("getValue returns null when collection is a List and index is negative")
    void testTC06() {
        List<String> collection = Arrays.asList("a", "b", "c");
        int index = -2;
        Object result = ValueUtils.getValue(collection, index);
        assertNull(result);
    }

    @Test
    @DisplayName("getValue returns null when collection is a List and index is out of bounds")
    void testTC07() {
        List<String> collection = Arrays.asList("a", "b", "c");
        int index = 5;
        Object result = ValueUtils.getValue(collection, index);
        assertNull(result);
    }

    @Test
    @DisplayName("getValue returns element at index from Collection when collection is a Collection and index is within bounds")
    void testTC08() {
        Collection<String> collection = new ArrayList<>(Arrays.asList("x", "y", "z"));
        int index = 1;
        Object result = ValueUtils.getValue(collection, index);
        assertEquals("y", result);
    }

    @Test
    @DisplayName("getValue returns null when collection is a Collection and index is negative")
    void testTC09() {
        Collection<String> collection = new ArrayList<>(Arrays.asList("x", "y", "z"));
        int index = -1;
        Object result = ValueUtils.getValue(collection, index);
        assertNull(result);
    }

    @Test
    @DisplayName("getValue returns null when collection is a Collection and index is out of bounds")
    void testTC10() {
        Collection<String> collection = new ArrayList<>(Arrays.asList("x", "y", "z"));
        int index = 5;
        Object result = ValueUtils.getValue(collection, index);
        assertNull(result);
    }
}