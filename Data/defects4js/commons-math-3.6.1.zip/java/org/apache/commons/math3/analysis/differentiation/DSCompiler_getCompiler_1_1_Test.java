package org.apache.commons.math3.analysis.differentiation;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicReference;

public class DSCompiler_getCompiler_1_1_Test {

    @Test
    @DisplayName("getCompiler initializes a new DSCompiler when cache is null and parameters=0 with order=2")
    public void TC21_getCompiler_initializesNewDSCompiler_whenCacheIsNull_parameters0_order2() throws Exception {
        // Arrange: Ensure the compilers cache is null
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, new AtomicReference<DSCompiler[][]>(null));

        // Act: Call getCompiler
        DSCompiler compiler = DSCompiler.getCompiler(0, 2);

        // Assert: Verify that a new DSCompiler is created with correct parameters and order
        assertNotNull(compiler, "Compiler should not be null");
        assertEquals(0, compiler.getFreeParameters(), "Free parameters should be 0");
        assertEquals(2, compiler.getOrder(), "Order should be 2");
    }

    @Test
    @DisplayName("getCompiler creates and caches a new DSCompiler when existing cache entry is null for parameters=2 and order=2")
    public void TC22_getCompiler_createsAndCachesNewDSCompiler_whenCacheEntryIsNull_parameters2_order2() throws Exception {
        // Arrange: Initialize the compilers cache with entry [2][2] as null
        DSCompiler[][] cache = new DSCompiler[3][3];
        cache[2][2] = null;
        AtomicReference<DSCompiler[][]> compilers = new AtomicReference<>(cache);

        // Reflectively set the private compilers field
        Field compilersField = DSCompiler.class.getDeclaredField("compilers");
        compilersField.setAccessible(true);
        compilersField.set(null, compilers);

        // Act: Call getCompiler
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);

        // Assert: Verify that a new DSCompiler is created and cached
        assertNotNull(compiler, "Compiler should not be null");
        assertEquals(2, compiler.getFreeParameters(), "Free parameters should be 2");
        assertEquals(2, compiler.getOrder(), "Order should be 2");
        assertSame(compiler, cache[2][2], "Compiler should be cached at [2][2]");
    }

}