package com.fasterxml.jackson.databind.deser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.deser.SettableAnyProperty;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ThrowableDeserializer_deserializeFromObject_0_4_Test {

    @Test
    @DisplayName("Deserialize with _anySetter handling additional properties")
    public void TC16_deserialize_with_anySetter_handling_additional_properties() throws Exception {
        // Initialize mocks
        JsonParser jsonParser = mock(JsonParser.class);
        DeserializationContext deserializationContext = mock(DeserializationContext.class);

        // Initialize the class under test
        ThrowableDeserializer deserializer = new ThrowableDeserializer(mock(com.fasterxml.jackson.databind.deser.BeanDeserializer.class));

        // Use reflection to set the _anySetter field
        Field anySetterField = ThrowableDeserializer.class.getDeclaredField("_anySetter");
        anySetterField.setAccessible(true);
        SettableAnyProperty anySetterMock = mock(SettableAnyProperty.class);
        anySetterField.set(deserializer, anySetterMock);

        // Setup the JsonParser mock to return the desired JSON tokens
        // For this scenario, JSON contains "additionalProp": "value"
        when(jsonParser.hasToken(JsonToken.END_OBJECT)).thenReturn(false, true);
        when(jsonParser.nextToken()).thenReturn(JsonToken.FIELD_NAME, JsonToken.VALUE_STRING, JsonToken.END_OBJECT);
        when(jsonParser.currentName()).thenReturn("additionalProp");
        when(jsonParser.getValueAsString()).thenReturn("value");

        // Call method under test
        Object result = deserializer.deserializeFromObject(jsonParser, deserializationContext);

        // Verify that _anySetter.deserializeAndSet was called with "additionalProp" and "value"
        verify(anySetterMock).deserializeAndSet(eq(jsonParser), eq(deserializationContext), any(Throwable.class), eq("additionalProp"));
    }

    @Test
    @DisplayName("Deserialize with 'suppressed' property set to null")
    public void TC17_deserialize_with_suppressed_property_as_null() throws Exception {
        // Initialize mocks
        JsonParser jsonParser = mock(JsonParser.class);
        DeserializationContext deserializationContext = mock(DeserializationContext.class);

        // Initialize the class under test
        ThrowableDeserializer deserializer = new ThrowableDeserializer(mock(com.fasterxml.jackson.databind.deser.BeanDeserializer.class));

        // Setup the JsonParser mock to return the desired JSON tokens
        // For this scenario, JSON contains "suppressed": null
        when(jsonParser.hasToken(JsonToken.END_OBJECT)).thenReturn(false, true);
        when(jsonParser.nextToken()).thenReturn(JsonToken.FIELD_NAME, JsonToken.VALUE_NULL, JsonToken.END_OBJECT);
        when(jsonParser.currentName()).thenReturn("suppressed");

        // Call method under test
        Object result = deserializer.deserializeFromObject(jsonParser, deserializationContext);

        // Assert that result's getSuppressed() is empty since null should be handled as empty
        assertTrue(result instanceof Throwable, "Result is not an instance of Throwable");
        Throwable throwable = (Throwable) result;
        assertEquals(0, throwable.getSuppressed().length, "Suppressed exceptions should be empty");
    }

    @Test
    @DisplayName("Deserialize with multiple suppressed exceptions")
    public void TC18_deserialize_with_multiple_suppressed_exceptions() throws Exception {
        // Initialize mocks
        JsonParser jsonParser = mock(JsonParser.class);
        DeserializationContext deserializationContext = mock(DeserializationContext.class);

        // Initialize the class under test
        ThrowableDeserializer deserializer = new ThrowableDeserializer(mock(com.fasterxml.jackson.databind.deser.BeanDeserializer.class));

        // Setup the JsonParser mock to return the desired JSON tokens
        // For this scenario, JSON contains "suppressed": [ { "message": "Suppressed 1" }, { "message": "Suppressed 2" } ]
        
        // Mocking successive calls of the parser to simulate the dollar represented scenario
        when(jsonParser.hasToken(JsonToken.END_OBJECT)).thenReturn(false, true);
        when(jsonParser.nextToken()).thenReturn(
                JsonToken.FIELD_NAME,
                JsonToken.START_ARRAY,
                JsonToken.START_OBJECT,
                JsonToken.FIELD_NAME,
                JsonToken.VALUE_STRING,
                JsonToken.END_OBJECT,
                JsonToken.START_OBJECT,
                JsonToken.FIELD_NAME,
                JsonToken.VALUE_STRING,
                JsonToken.END_OBJECT,
                JsonToken.END_ARRAY,
                JsonToken.END_OBJECT
        );
        when(jsonParser.currentName()).thenReturn("suppressed", "message", "message");
        when(jsonParser.getValueAsString()).thenReturn("Suppressed 1", "Suppressed 2");

        // Mock the DeserializationContext to deserialize Throwable objects
        JsonDeserializer<Object> throwableDeserializer = mock(JsonDeserializer.class);
        when(deserializationContext.constructType(Throwable[].class)).thenReturn(mock(com.fasterxml.jackson.databind.JavaType.class));
        when(deserializationContext.findRootValueDeserializer(any())).thenReturn(throwableDeserializer);
        when(throwableDeserializer.deserialize(jsonParser, deserializationContext)).thenReturn(
                new Throwable("Suppressed 1"),
                new Throwable("Suppressed 2")
        );

        // Call method under test
        Object result = deserializer.deserializeFromObject(jsonParser, deserializationContext);

        // Assert that suppressed exceptions are correctly set
        assertTrue(result instanceof Throwable, "Result is not an instance of Throwable");
        Throwable throwable = (Throwable) result;
        Throwable[] suppressed = throwable.getSuppressed();
        assertNotNull(suppressed, "Suppressed exceptions should not be null");
        assertEquals(2, suppressed.length, "There should be 2 suppressed exceptions");
        assertEquals("Suppressed 1", suppressed[0].getMessage(), "First suppressed exception message mismatch");
        assertEquals("Suppressed 2", suppressed[1].getMessage(), "Second suppressed exception message mismatch");
    }

    @Test
    @DisplayName("Deserialize with suppressed exceptions containing nulls")
    public void TC19_deserialize_with_suppressed_exceptions_containing_nulls() throws Exception {
        // Initialize mocks
        JsonParser jsonParser = mock(JsonParser.class);
        DeserializationContext deserializationContext = mock(DeserializationContext.class);

        // Initialize the class under test
        ThrowableDeserializer deserializer = new ThrowableDeserializer(mock(com.fasterxml.jackson.databind.deser.BeanDeserializer.class));

        // Setup the JsonParser mock to return the desired JSON tokens
        // For this scenario, JSON contains "suppressed": [ null, { "message": "Suppressed 1" }, null ]
        when(jsonParser.hasToken(JsonToken.END_OBJECT)).thenReturn(false, true);
        when(jsonParser.nextToken()).thenReturn(
                JsonToken.FIELD_NAME,
                JsonToken.START_ARRAY,
                JsonToken.VALUE_NULL,
                JsonToken.START_OBJECT,
                JsonToken.FIELD_NAME,
                JsonToken.VALUE_STRING,
                JsonToken.END_OBJECT,
                JsonToken.VALUE_NULL,
                JsonToken.END_ARRAY,
                JsonToken.END_OBJECT
        );
        when(jsonParser.currentName()).thenReturn("suppressed", "message");
        when(jsonParser.getValueAsString()).thenReturn("Suppressed 1");

        // Mock the DeserializationContext to deserialize Throwable objects
        JsonDeserializer<Object> throwableDeserializer = mock(JsonDeserializer.class);
        when(deserializationContext.constructType(Throwable[].class)).thenReturn(mock(com.fasterxml.jackson.databind.JavaType.class));
        when(deserializationContext.findRootValueDeserializer(any())).thenReturn(throwableDeserializer);
        when(throwableDeserializer.deserialize(jsonParser, deserializationContext)).thenReturn(
                new Throwable("Suppressed 1")
        );

        // Call method under test
        Object result = deserializer.deserializeFromObject(jsonParser, deserializationContext);

        // Assert that suppressed exceptions are correctly set, ignoring nulls
        assertTrue(result instanceof Throwable, "Result is not an instance of Throwable");
        Throwable throwable = (Throwable) result;
        Throwable[] suppressed = throwable.getSuppressed();
        assertNotNull(suppressed, "Suppressed exceptions should not be null");
        assertEquals(1, suppressed.length, "There should be 1 suppressed exception");
        assertEquals("Suppressed 1", suppressed[0].getMessage(), "Suppressed exception message mismatch");
    }

    @Test
    @DisplayName("Deserialize with unknown property and anySetter")
    public void TC20_deserialize_with_unknown_property_and_anySetter() throws Exception {
        // Initialize mocks
        JsonParser jsonParser = mock(JsonParser.class);
        DeserializationContext deserializationContext = mock(DeserializationContext.class);

        // Initialize the class under test
        ThrowableDeserializer deserializer = new ThrowableDeserializer(mock(com.fasterxml.jackson.databind.deser.BeanDeserializer.class));

        // Use reflection to set the _anySetter field
        Field anySetterField = ThrowableDeserializer.class.getDeclaredField("_anySetter");
        anySetterField.setAccessible(true);
        SettableAnyProperty anySetterMock = mock(SettableAnyProperty.class);
        anySetterField.set(deserializer, anySetterMock);

        // Setup the JsonParser mock to return the desired JSON tokens
        // For this scenario, JSON contains "unknownProp": "value"
        when(jsonParser.hasToken(JsonToken.END_OBJECT)).thenReturn(false, true);
        when(jsonParser.nextToken()).thenReturn(JsonToken.FIELD_NAME, JsonToken.VALUE_STRING, JsonToken.END_OBJECT);
        when(jsonParser.currentName()).thenReturn("unknownProp");
        when(jsonParser.getValueAsString()).thenReturn("value");

        // Call method under test
        Object result = deserializer.deserializeFromObject(jsonParser, deserializationContext);

        // Verify that _anySetter.deserializeAndSet was called with "unknownProp" and "value"
        verify(anySetterMock).deserializeAndSet(eq(jsonParser), eq(deserializationContext), any(Throwable.class), eq("unknownProp"));
    }
}