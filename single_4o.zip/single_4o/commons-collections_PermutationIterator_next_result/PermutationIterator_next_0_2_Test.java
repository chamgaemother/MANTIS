package org.apache.commons.collections4.iterators;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.*;
import java.lang.reflect.*;
import org.apache.commons.collections4.iterators.PermutationIterator;

public class PermutationIterator_next_0_2_Test {

    @Test
    @DisplayName("next() correctly handles the empty list case")
    void testNextEmptyList() {
        List<Integer> initialList = Collections.emptyList();
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);
        assertThrows(NoSuchElementException.class, iterator::next);
    }

    @Test
    @DisplayName("next() produces correct next permutation for already sorted list")
    void testNextSorted() throws Exception {
        List<Integer> initialList = Arrays.asList(1, 2, 3, 4);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);
        List<Integer> result = iterator.next();
        assertEquals(Arrays.asList(1, 2, 3, 4), result);

        // Access nextPermutation using reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = (List<Integer>) nextPermutationField.get(iterator);
        assertEquals(Arrays.asList(1, 2, 4, 3), nextPermutation);
    }

    @Test
    @DisplayName("next() correctly resets direction where necessary")
    void testNextResetsDirection() throws Exception {
        List<Integer> initialList = Arrays.asList(3, 2, 1);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);
        List<Integer> result = iterator.next();
        assertEquals(Arrays.asList(3, 2, 1), result);

        // Access nextPermutation using reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = (List<Integer>) nextPermutationField.get(iterator);
        assertNull(nextPermutation);
    }

    @Test
    @DisplayName("next() produces next permutation and reverses directions of elements greater than mobile integer")
    void testNextReversesDirections() throws Exception {
        List<Integer> initialList = Arrays.asList(4, 1, 3, 2);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);
        List<Integer> result = iterator.next();
        assertEquals(Arrays.asList(4, 1, 3, 2), result);

        // Access nextPermutation using reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = (List<Integer>) nextPermutationField.get(iterator);
        assertEquals(Arrays.asList(4, 1, 2, 3), nextPermutation);
    }

    @Test
    @DisplayName("next() handles edge case of all equal elements in permutation")
    void testNextIdenticalElements() throws Exception {
        List<Integer> initialList = Arrays.asList(5, 5, 5);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);
        List<Integer> result = iterator.next();
        assertEquals(Arrays.asList(5, 5, 5), result);

        // Access nextPermutation using reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        List<Integer> nextPermutation = (List<Integer>) nextPermutationField.get(iterator);
        assertNull(nextPermutation);
    }
}