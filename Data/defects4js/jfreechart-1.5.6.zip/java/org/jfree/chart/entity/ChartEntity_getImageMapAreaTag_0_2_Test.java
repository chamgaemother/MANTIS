package org.jfree.chart.entity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.imagemap.ToolTipTagFragmentGenerator;
import org.jfree.chart.imagemap.URLTagFragmentGenerator;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;

public class ChartEntity_getImageMapAreaTag_0_2_Test {

    @Test
    @DisplayName("When urlText is null and toolTipText is non-null and not empty, generate area tag with ToolTip and nohref")
    public void TC06() {
        // GIVEN
        String urlText = null;
        String toolTipText = "Tooltip text";
        Shape area = new Rectangle2D.Double();
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String text) {
                return " tooltip='" + text + "'";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String url) {
                return " url='" + url + "'";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        Assertions.assertTrue(result.contains("shape="));
        Assertions.assertTrue(result.contains("coords="));
        Assertions.assertTrue(result.contains("tooltip='Tooltip text'"));
        Assertions.assertTrue(result.contains("nohref="));
        Assertions.assertFalse(result.contains("alt="));
    }

    @Test
    @DisplayName("When urlText is null and toolTipText is non-null but empty, generate area tag with nohref and alt attribute")
    public void TC07() {
        // GIVEN
        String urlText = null;
        String toolTipText = "";
        Shape area = new Rectangle2D.Double();
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String text) {
                return " tooltip='" + text + "'";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String url) {
                return " url='" + url + "'";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        Assertions.assertTrue(result.contains("shape="));
        Assertions.assertTrue(result.contains("coords="));
        Assertions.assertTrue(result.contains("nohref="));
        Assertions.assertTrue(result.contains("alt="));
        Assertions.assertFalse(result.contains("tooltip='"));
    }

    @Test
    @DisplayName("When urlText is non-null and not empty, and toolTipText is non-null but empty, generate area tag with URL and alt attribute")
    public void TC08() {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = "";
        Shape area = new Rectangle2D.Double();
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String text) {
                return " tooltip='" + text + "'";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String url) {
                return "href='" + url + "'";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        Assertions.assertTrue(result.contains("shape="));
        Assertions.assertTrue(result.contains("coords="));
        Assertions.assertTrue(result.contains("href='http://example.com'"));
        Assertions.assertTrue(result.contains("alt="));
        Assertions.assertFalse(result.contains("tooltip="));
        Assertions.assertFalse(result.contains("nohref="));
    }

    @Test
    @DisplayName("When both urlText and toolTipText are non-null but empty, no image map area tag is generated")
    public void TC09() {
        // GIVEN
        String urlText = "";
        String toolTipText = "";
        Shape area = new Rectangle2D.Double();
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String text) {
                return " tooltip='" + text + "'";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String url) {
                return " url='" + url + "'";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        Assertions.assertEquals("", result);
    }

    @Test
    @DisplayName("When area is Rectangle2D, urlText and toolTipText are non-null and not empty, generate area tag with shape=\"rect\"")
    public void TC10() {
        // GIVEN
        String urlText = "http://example.com";
        String toolTipText = "Tooltip text";
        Shape area = new Rectangle2D.Double();
        ChartEntity chartEntity = new ChartEntity(area, toolTipText, urlText);

        ToolTipTagFragmentGenerator toolTipTagFragmentGenerator = new ToolTipTagFragmentGenerator() {
            @Override
            public String generateToolTipFragment(String text) {
                return " tooltip='" + text + "'";
            }
        };

        URLTagFragmentGenerator urlTagFragmentGenerator = new URLTagFragmentGenerator() {
            @Override
            public String generateURLFragment(String url) {
                return "href='" + url + "'";
            }
        };

        // WHEN
        String result = chartEntity.getImageMapAreaTag(toolTipTagFragmentGenerator, urlTagFragmentGenerator);

        // THEN
        Assertions.assertTrue(result.contains("shape=\"rect\""));
        Assertions.assertTrue(result.contains("coords="));
        Assertions.assertTrue(result.contains("tooltip='Tooltip text'"));
        Assertions.assertTrue(result.contains("href='http://example.com'"));
        Assertions.assertFalse(result.contains("alt="));
    }
}