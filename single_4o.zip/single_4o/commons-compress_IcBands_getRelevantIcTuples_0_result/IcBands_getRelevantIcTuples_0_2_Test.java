package org.apache.commons.compress.harmony.unpack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.compress.harmony.unpack200.bytecode.ClassConstantPool;
import org.apache.commons.compress.harmony.unpack200.IcTuple;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class IcBands_getRelevantIcTuples_0_2_Test {

    // Due to the lack of access to implementations of Segment and BandSet,
    // Assume that default constructor for Segment and valid mock are allowed
    @Test
    @DisplayName("Outer class is anonymous check preventing adding of relevant tuple")
    void testAnonymousOuterClass() {
        // Setup
        IcBands icBands = createMockIcBands();
        String className = "AnonymousClass";

        IcTuple anonymousTuple = new IcTuple("AnonymousClass$", 0, "", "", -1, -1, -1, 0);
        setOuterClassToTuples(icBands, className, Collections.singletonList(anonymousTuple));

        // Assume a valid, empty ClassConstantPool
        ClassConstantPool cp = new ClassConstantPool(Collections.emptyList());

        // Act
        IcTuple[] relevantTuples = icBands.getRelevantIcTuples(className, cp);

        // Assert
        assertEquals(0, relevantTuples.length, "Anonymous outer class should not be added");
    }


    @Test
    @DisplayName("Test with many relevant candidates spanning multiple list additions")
    void testManyRelevantCandidates() {
        // Setup
        IcBands icBands = createMockIcBands();
        String className = "MultipleCandidatesClass";

        List<IcTuple> candidateTuples = Arrays.asList(
                new IcTuple("ClassA", 0, "", "", -1, -1, -1, 0),
                new IcTuple("ClassB", 1, "", "", -1, -1, -1, 1)
        );
        setOuterClassToTuples(icBands, className, candidateTuples);

        ClassConstantPool cp = new ClassConstantPool(Collections.emptyList());

        // Act
        IcTuple[] relevantTuples = icBands.getRelevantIcTuples(className, cp);

        // Assert
        assertEquals(candidateTuples.size(), relevantTuples.length, "Interrelated IcTuples should accumulate correctly");
    }

    @Test
    @DisplayName("No entry in thisClassToTuple results in no addition from entries list")
    void testNoEntryInThisClassToTuple() {
        // Setup
        IcBands icBands = createMockIcBands();
        String className = "NoEntryClass";

        List<IcTuple> initialRelevantTuples = Collections.singletonList(
                new IcTuple("InitialTuple", 0, "", "", -1, -1, -1, 0)
        );
        setOuterClassToTuples(icBands, className, initialRelevantTuples);

        ClassConstantPool cp = new ClassConstantPool(Collections.emptyList());

        // Act
        IcTuple[] relevantTuples = icBands.getRelevantIcTuples(className, cp);

        // Assert
        assertArrayEquals(initialRelevantTuples.toArray(new IcTuple[0]), relevantTuples, "Should return only the initially relevant tuples");
    }

    @Test
    @DisplayName("Add tuple only when it is a valid, not anonymous outer class")
    void testValidNotAnonymousOuterClass() {
        // Setup
        IcBands icBands = createMockIcBands();
        String className = "ValidOuterClass";

        List<IcTuple> candidateTuples = Collections.singletonList(
                new IcTuple("Outer", 0, "", "", -1, -1, -1, 0)
        );
        setOuterClassToTuples(icBands, className, candidateTuples);

        ClassConstantPool cp = new ClassConstantPool(Collections.emptyList());

        // Act
        IcTuple[] relevantTuples = icBands.getRelevantIcTuples(className, cp);

        // Assert
        assertEquals(candidateTuples.size(), relevantTuples.length, "Valid non-anonymous tuples should be added");
    }

    @Test
    @DisplayName("IcTuples sorted correctly by index at method conclusion")
    void testTuplesSortedByIndex() {
        // Setup
        IcBands icBands = createMockIcBands();

        List<IcTuple> initialTuples = Arrays.asList(
                new IcTuple("Class3", 2, "", "", -1, -1, -1, 2),
                new IcTuple("Class1", 0, "", "", -1, -1, -1, 0),
                new IcTuple("Class2", 1, "", "", -1, -1, -1, 1)
        );
        initialTuples.sort(Comparator.comparingInt(IcTuple::getTupleIndex));

        setRelevantTuples(icBands, initialTuples);

        // Act
        IcTuple[] result = icBands.getRelevantIcTuples("irrelevant", new ClassConstantPool(Collections.emptyList()));

        // Assert
        assertArrayEquals(initialTuples.toArray(new IcTuple[0]), result, "Should be sorted by tuple index");
    }

    private IcBands createMockIcBands() {
        Segment mockSegment = new Segment();  // Creating a dummy Segment object as a stub
        return new IcBands(mockSegment);
    }

    private void setOuterClassToTuples(IcBands icBands, String className, List<IcTuple> tuples) {
        try {
            Field outerClassToTuplesField = IcBands.class.getDeclaredField("outerClassToTuples");
            outerClassToTuplesField.setAccessible(true);
            Map<String, List<IcTuple>> outerClassToTuples = new HashMap<>();
            outerClassToTuples.put(className, tuples);
            outerClassToTuplesField.set(icBands, outerClassToTuples);
        } catch (Exception e) {
            fail("Reflection setup failed for outerClassToTuples");
        }
    }

    private void setRelevantTuples(IcBands icBands, List<IcTuple> tuples) {
        try {
            Field relevantTuplesField = IcBands.class.getDeclaredField("icAll");
            relevantTuplesField.setAccessible(true);
            relevantTuplesField.set(icBands, tuples.toArray(new IcTuple[0]));
        } catch (Exception e) {
            fail("Reflection setup failed for relevantTuples");
        }
    }
}
