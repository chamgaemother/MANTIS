package org.apache.commons.math3.geometry.euclidean.threed;

import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import java.lang.reflect.Field;

public class Rotation_getAngles_0_5_Test {

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZXZ order where v2.getZ() is within bounds")
    public void TC21_getAngles_VECTOR_OPERATOR_ZXZ_within_bounds() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        
        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.ZXZ, RotationConvention.VECTOR_OPERATOR);
        
        // THEN
        Assertions.assertNotNull(angles, "Angles array should not be null");
        Assertions.assertEquals(3, angles.length, "Angles array should have length 3");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZXZ order where v2.getZ() exceeds upper boundary, throwing exception")
    public void TC22_getAngles_VECTOR_OPERATOR_ZXZ_exceeds_upper_boundary() throws Exception {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        
        // Using reflection to modify internal state to simulate the singularity condition
        setQuaternionValues(rotation, 0.0, 0.0, 1.0);
        
        // WHEN & THEN
        Assertions.assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZXZ, RotationConvention.VECTOR_OPERATOR);
        }, "Expected CardanEulerSingularityException when v2.getZ() exceeds upper boundary");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZYZ order where v2.getZ() is within bounds")
    public void TC23_getAngles_VECTOR_OPERATOR_ZYZ_within_bounds() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        
        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.ZYZ, RotationConvention.VECTOR_OPERATOR);
        
        // THEN
        Assertions.assertNotNull(angles, "Angles array should not be null");
        Assertions.assertEquals(3, angles.length, "Angles array should have length 3");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and ZYZ order where v2.getZ() exceeds upper boundary, throwing exception")
    public void TC24_getAngles_VECTOR_OPERATOR_ZYZ_exceeds_upper_boundary() throws Exception {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        
        // Using reflection to modify internal state to simulate the singularity condition
        setQuaternionValues(rotation, 0.0, 0.0, 1.0);
        
        // WHEN & THEN
        Assertions.assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.ZYZ, RotationConvention.VECTOR_OPERATOR);
        }, "Expected CardanEulerSingularityException when v2.getZ() exceeds upper boundary");
    }

    @Test
    @DisplayName("getAngles with NON-VECTOR_OPERATOR convention and XYZ order where v2.getZ() is within bounds")
    public void TC25_getAngles_NON_VECTOR_OPERATOR_XYZ_within_bounds() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
        
        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.FRAME_TRANSFORM);
        
        // THEN
        Assertions.assertNotNull(angles, "Angles array should not be null");
        Assertions.assertEquals(3, angles.length, "Angles array should have length 3");
    }

    /**
     * Utility method to set quaternion values for testing boundary conditions.
     * This method uses reflection to set private fields related to quaternion values.
     */
    private void setQuaternionValues(Rotation rotation, double q1Value, double q2Value, double q3Value) throws Exception {
        Field q0Field = Rotation.class.getDeclaredField("q0");
        Field q1Field = Rotation.class.getDeclaredField("q1");
        Field q2Field = Rotation.class.getDeclaredField("q2");
        Field q3Field = Rotation.class.getDeclaredField("q3");
        q0Field.setAccessible(true);
        q1Field.setAccessible(true);
        q2Field.setAccessible(true);
        q3Field.setAccessible(true);
        q0Field.set(rotation, 0.0);
        q1Field.set(rotation, q1Value);
        q2Field.set(rotation, q2Value);
        q3Field.set(rotation, q3Value);
    }

}