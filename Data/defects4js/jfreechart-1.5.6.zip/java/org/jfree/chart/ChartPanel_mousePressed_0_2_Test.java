package org.jfree.chart;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import org.jfree.chart.plot.Pannable;
import org.jfree.chart.plot.Plot;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ChartPanel_mousePressed_0_2_Test {

    // Utility methods for reflection
    private <T> T getFieldValue(Object obj, String fieldName, Class<T> fieldType) throws Exception {
        java.lang.reflect.Field field = ChartPanel.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return fieldType.cast(field.get(obj));
    }

    private void setFieldValue(Object obj, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field field = ChartPanel.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(obj, value);
    }

//     @Test
//     @DisplayName("mousePressed initializes panning when screen data area contains the mouse point")
//     public void TC06_mousePressed_initializesPanning() throws Exception {
        // GIVEN
//         JFreeChart chart = mock(JFreeChart.class);
//         Pannable plot = mock(Pannable.class);
//         when(chart.getPlot()).thenReturn(plot);
//         when(plot.isDomainPannable()).thenReturn(true);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         int panMask = getFieldValue(chartPanel, "panMask", int.class);
//         when(e.getModifiersEx()).thenReturn(panMask);
//         when(e.getX()).thenReturn(150);
//         when(e.getY()).thenReturn(150);
//         Point mousePoint = new Point(150, 150);
//         when(e.getPoint()).thenReturn(mousePoint);
// 
//         Rectangle2D screenArea = new Rectangle2D.Double(100, 100, 200, 200);
// 
//         ChartPanel spyChartPanel = spy(chartPanel);
//         doReturn(screenArea).when(spyChartPanel).getScreenDataArea(150, 150);
// 
        // WHEN
//         spyChartPanel.mousePressed(e);
// 
        // THEN
//         double panW = getFieldValue(spyChartPanel, "panW", double.class);
//         double panH = getFieldValue(spyChartPanel, "panH", double.class);
//         Point panLast = getFieldValue(spyChartPanel, "panLast", Point.class);
// 
//         Cursor cursor = spyChartPanel.getCursor();
// 
//         assertEquals(200.0, panW, "panW should be set to screenArea width");
//         assertEquals(200.0, panH, "panH should be set to screenArea height");
//         assertEquals(mousePoint, panLast, "panLast should be set to mouse point");
//         assertEquals(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR), cursor, "Cursor should be set to MOVE_CURSOR");
//     }

//     @Test
//     @DisplayName("mousePressed does not initiate panning when screen data area does not contain the mouse point")
//     public void TC07_mousePressed_panningPointOutside() throws Exception {
        // GIVEN
//         JFreeChart chart = mock(JFreeChart.class);
//         Pannable plot = mock(Pannable.class);
//         when(chart.getPlot()).thenReturn(plot);
//         when(plot.isDomainPannable()).thenReturn(true);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         int panMask = getFieldValue(chartPanel, "panMask", int.class);
//         when(e.getModifiersEx()).thenReturn(panMask);
//         when(e.getX()).thenReturn(50);
//         when(e.getY()).thenReturn(50);
//         Point mousePoint = new Point(50, 50);
//         when(e.getPoint()).thenReturn(mousePoint);
// 
//         Rectangle2D screenArea = new Rectangle2D.Double(100, 100, 200, 200);
//         ChartPanel spyChartPanel = spy(chartPanel);
//         doReturn(screenArea).when(spyChartPanel).getScreenDataArea(50, 50);
// 
        // WHEN
//         spyChartPanel.mousePressed(e);
// 
        // THEN
//         Double panW = getFieldValue(spyChartPanel, "panW", double.class);
//         Double panH = getFieldValue(spyChartPanel, "panH", double.class);
//         Point panLast = getFieldValue(spyChartPanel, "panLast", Point.class);
//         Cursor cursor = spyChartPanel.getCursor();
// 
//         assertNull(panW, "panW should not be set");
//         assertNull(panH, "panH should not be set");
//         assertNull(panLast, "panLast should not be set");
//         assertNotEquals(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR), cursor, "Cursor should remain unchanged");
//     }

//     @Test
//     @DisplayName("mousePressed initializes zoomPoint when zoomRectangle is null and screen data area is not null")
//     public void TC08_mousePressed_initializesZoomPoint() throws Exception {
        // GIVEN
//         JFreeChart chart = mock(JFreeChart.class);
//         Plot plot = mock(Plot.class);
//         when(chart.getPlot()).thenReturn(plot);
// 
//         ChartPanel chartPanel = new ChartPanel(chart);
//         setFieldValue(chartPanel, "zoomRectangle", null);
// 
//         MouseEvent e = mock(MouseEvent.class);
//         when(e.getModifiers()).thenReturn(0);
//         when(e.getX()).thenReturn(200);
//         when(e.getY()).thenReturn(200);
// 
//         Rectangle2D screenArea = new Rectangle2D.Double(150, 150, 300, 300);
//         ChartPanel spyChartPanel = spy(chartPanel);
//         doReturn(screenArea).when(spyChartPanel).getScreenDataArea(200, 200);
// 
//         Point2D point = new Point2D.Double(200, 200);
//         doReturn(point).when(spyChartPanel).getPointInRectangle(200, 200, screenArea);
// 
        // WHEN
//         spyChartPanel.mousePressed(e);
// 
        // THEN
//         Point2D zoomPoint = getFieldValue(spyChartPanel, "zoomPoint", Point2D.class);
//         assertEquals(point, zoomPoint, "zoomPoint should be set correctly");
//     }

    @Test
    @DisplayName("mousePressed sets zoomPoint to null when zoomRectangle is null and screen data area is null")
    public void TC09_mousePressed_zoomPointNull() throws Exception {
        // GIVEN
        JFreeChart chart = mock(JFreeChart.class);
        Plot plot = mock(Plot.class);
        when(chart.getPlot()).thenReturn(plot);

        ChartPanel chartPanel = new ChartPanel(chart);
        setFieldValue(chartPanel, "zoomRectangle", null);

        MouseEvent e = mock(MouseEvent.class);
        when(e.getModifiers()).thenReturn(0);
        when(e.getX()).thenReturn(400);
        when(e.getY()).thenReturn(400);
        ChartPanel spyChartPanel = spy(chartPanel);
        doReturn(null).when(spyChartPanel).getScreenDataArea(400, 400);

        // WHEN
        spyChartPanel.mousePressed(e);

        // THEN
        Point2D zoomPoint = getFieldValue(spyChartPanel, "zoomPoint", Point2D.class);
        assertNull(zoomPoint, "zoomPoint should be set to null");
    }

    @Test
    @DisplayName("mousePressed shows popup menu when popup trigger is true and popup is not null")
    public void TC10_mousePressed_showsPopupMenu() throws Exception {
        // GIVEN
        JPopupMenu popup = mock(JPopupMenu.class);
        JFreeChart chart = mock(JFreeChart.class);
        Plot plot = mock(Plot.class);
        when(chart.getPlot()).thenReturn(plot);

        ChartPanel chartPanel = new ChartPanel(chart);
        setFieldValue(chartPanel, "popup", popup);

        MouseEvent e = mock(MouseEvent.class);
        when(e.getModifiers()).thenReturn(0);
        when(e.getX()).thenReturn(250);
        when(e.getY()).thenReturn(250);
        when(e.isPopupTrigger()).thenReturn(true);

        ChartPanel spyChartPanel = spy(chartPanel);

        // WHEN
        spyChartPanel.mousePressed(e);

        // THEN
        verify(popup).show(spyChartPanel, 250, 250);
    }

}