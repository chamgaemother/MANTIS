package org.apache.commons.math3.random;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.Arrays;

public class MersenneTwister_setSeed_0_3_Test {

    @Test
    @DisplayName("setSeed with seed array triggering conditional branches (i53 == false and $i24 >= 0)")
    void TC11_setSeed_WithConditionalBranches() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        Arrays.fill(seed, 1);

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Access the private 'mt' field using reflection
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] mtArray = (int[]) mtField.get(mt);
        
        // Verify that all elements in mt array are initialized based on seed values
        for (int value : mtArray) {
            assertEquals(1, value, "mt array value should be initialized to 1");
        }
    }

    @Test
    @DisplayName("setSeed with seed array causing multiple loop iterations and subsequent branch coverage")
    void TC12_setSeed_WithComplexSeedArray() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        for(int i = 0; i < 624; i++) {
            seed[i] = (i % 2 == 0) ? i : -i;
        }

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Access the private 'mt' field using reflection
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] mtArray = (int[]) mtField.get(mt);

        // Verify that multiple iterations are handled correctly
        for(int i = 0; i < 624; i++) {
            if(i % 2 == 0) {
                assertTrue(mtArray[i] >= 0, "mt array element at even index should be non-negative");
            } else {
                assertTrue(mtArray[i] < 0, "mt array element at odd index should be negative");
            }
        }
    }

    @Test
    @DisplayName("setSeed throws NullPointerException when seed array is null")
    void TC13_setSeed_NullSeed_ThrowsException() {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = null;

        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> mt.setSeed(seed), "setSeed should throw NullPointerException when seed is null");
    }

    @Test
    @DisplayName("setSeed with seed array containing zero initializes mt array correctly")
    void TC14_setSeed_WithZeroValues() throws Exception {
        // GIVEN
        MersenneTwister mt = new MersenneTwister();
        int[] seed = new int[624];
        Arrays.fill(seed, 0);

        // WHEN
        mt.setSeed(seed);

        // THEN
        // Access the private 'mt' field using reflection
        Field mtField = MersenneTwister.class.getDeclaredField("mt");
        mtField.setAccessible(true);
        int[] mtArray = (int[]) mtField.get(mt);

        // Verify that all elements in mt array are initialized to zero
        for (int value : mtArray) {
            assertEquals(0, value, "mt array value should be initialized to 0");
        }
    }
}