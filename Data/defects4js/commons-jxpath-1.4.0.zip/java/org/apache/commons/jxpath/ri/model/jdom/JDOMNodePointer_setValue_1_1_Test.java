package org.apache.commons.jxpath.ri.model.jdom;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer;
import org.jdom.Comment;
import org.jdom.Text;

/**
 * JUnit 5 test class for JDOMNodePointer#setValue method.
 */
public class JDOMNodePointer_setValue_1_1_Test {

    @Test
    @DisplayName("node is Comment and setValue throws ClassCastException")
    void TC14_setValue_withCommentNode_throwsClassCastException() {
        // Arrange
        Comment comment = new Comment("Sample Comment");
        JDOMNodePointer pointer = new JDOMNodePointer(comment, null);
        Object newValue = "New Value";

        // Act & Assert
        assertThrows(ClassCastException.class, () -> pointer.setValue(newValue),
            "Expected setValue to throw ClassCastException when node is a Comment");
    }

    @Test
    @DisplayName("node is Text, converted string is null, and node has no parent, throws NullPointerException")
    void TC15_setValue_withTextNodeNoParent_throwsNullPointerException() {
        // Arrange
        Text text = new Text("Old Value");
        JDOMNodePointer pointer = new JDOMNodePointer(text, null);
        Object newValue = null;

        // Act & Assert
        assertThrows(NullPointerException.class, () -> pointer.setValue(newValue),
            "Expected setValue to throw NullPointerException when node is Text with no parent and value is null");
    }
}