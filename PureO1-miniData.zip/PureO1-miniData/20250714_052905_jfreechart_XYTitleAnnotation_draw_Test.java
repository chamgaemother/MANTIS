import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.title.Title;
import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.annotations.XYTitleAnnotation;
import org.jfree.chart.util.XYCoordinateType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class XYTitleAnnotationTest {

    private Graphics2D mockGraphics2D;
    private XYPlot mockPlot;
    private Rectangle2D mockDataArea;
    private ValueAxis mockDomainAxis;
    private ValueAxis mockRangeAxis;
    private Title mockTitle;
    private PlotRenderingInfo mockRenderInfo;

    @BeforeEach
    void setUp() {
        mockGraphics2D = mock(Graphics2D.class);
        mockPlot = mock(XYPlot.class);
        mockDataArea = mock(Rectangle2D.class);
        mockDomainAxis = mock(ValueAxis.class);
        mockRangeAxis = mock(ValueAxis.class);
        mockTitle = mock(Title.class);
        mockRenderInfo = mock(PlotRenderingInfo.class);
    }

    @Test
    void testDrawRelativeCoordinateVerticalOrientationInfoNull() {
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(mock(Range.class));
        when(mockRangeAxis.getRange()).thenReturn(mock(Range.class));
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(100, 50));

        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, mockTitle, RectangleAnchor.CENTER);
        annotation.setMaxWidth(0.0);
        annotation.setMaxHeight(0.0);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 0, null));
    }

    @Test
    void testDrawDataCoordinateHorizontalOrientationWithMaxDimensions() {
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 200));
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(400.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(300.0);
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(150, 75));

        XYTitleAnnotation annotation = new XYTitleAnnotation(50.0, 100.0, mockTitle, RectangleAnchor.TOP_LEFT);
        annotation.setMaxWidth(200.0);
        annotation.setMaxHeight(150.0);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 1, mockRenderInfo));
    }

    @Test
    void testDrawRelativeCoordinateHorizontalOrientationInfoWithEntities() {
        PlotRenderingInfo.Owner mockOwner = mock(PlotRenderingInfo.Owner.class);
        when(mockRenderInfo.getOwner()).thenReturn(mockOwner);
        when(mockOwner.getEntityCollection()).thenReturn(mock(org.jfree.chart.entity.EntityCollection.class));
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 1));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 1));
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight())...thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(100, 50));
        when(mockTitle.draw(any(Graphics2D.class), any(Rectangle2D.class), any())).thenReturn(mock(org.jfree.chart.block.EntityBlockResult.class));

        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, mockTitle, RectangleAnchor.BOTTOM_RIGHT);
        annotation.setMaxWidth(0.5);
        annotation.setMaxHeight(0.5);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 2, mockRenderInfo));
    }

    @Test
    void testDrawDataCoordinateVerticalOrientationInfoWithNullEntityCollection() {
        when(mockRenderInfo.getOwner()).thenReturn(null);
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(500.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(500.0);
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(120, 60));
        when(mockTitle.draw(any(Graphics2D.class), any(Rectangle2D.class), any())).thenReturn(null);

        XYTitleAnnotation annotation = new XYTitleAnnotation(25.0, 75.0, mockTitle, RectangleAnchor.BOTTOM_LEFT);
        annotation.setMaxWidth(150.0);
        annotation.setMaxHeight(150.0);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 3, mockRenderInfo));
    }

    @Test
    void testDrawRelativeCoordinateVerticalOrientationWithToolTipAndURL() {
        org.jfree.chart.entity.EntityCollection mockEntityCollection = mock(org.jfree.chart.entity.EntityCollection.class);
        when(mockRenderInfo.getOwner()).thenReturn(mock(PlotRenderingInfo.Owner.class));
        when(mockRenderInfo.getOwner().getEntityCollection()).thenReturn(mockEntityCollection);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(200, 100));
        when(mockTitle.draw(any(Graphics2D.class), any(Rectangle2D.class), any())).thenReturn(null);

        XYTitleAnnotation annotation = new XYTitleAnnotation(0.3, 0.7, mockTitle, RectangleAnchor.CENTER);
        annotation.setToolTipText("Sample Tooltip");
        annotation.setURL("http://example.com");

        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 1));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 1));
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(240.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(420.0);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 4, mockRenderInfo));

        verify(mockEntityCollection).addAll(any());
        verify(mockEntityCollection).addEntity(any(), any(), any());
    }

    @Test
    void testDrawCoordinateTypeDataWithZeroMaxWidthMaxHeight() {
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(50.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(50.0);
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(100, 50));

        XYTitleAnnotation annotation = new XYTitleAnnotation(25.0, 75.0, mockTitle, RectangleAnchor.TOP_RIGHT);
        annotation.setMaxWidth(0.0);
        annotation.setMaxHeight(0.0);
        // Manually set coordinateType to DATA
        annotation = spy(annotation);
        doReturn(XYCoordinateType.DATA).when(annotation).getCoordinateType();

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 5, mockRenderInfo));
    }

    @Test
    void testDrawWithNullTitle() {
        assertThrows(NullPointerException.class, () -> new XYTitleAnnotation(0, 0, null));
    }

    @Test
    void testDrawWithNullAnchor() {
        assertThrows(NullPointerException.class, () -> new XYTitleAnnotation(0, 0, mockTitle, null));
    }

    @Test
    void testDrawOrientationNotHandled() {
        when(mockPlot.getOrientation()).thenReturn(null);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(400.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(300.0);
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(100, 50));

        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, mockTitle, RectangleAnchor.CENTER);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 6, mockRenderInfo));
    }

    @Test
    void testDrawResultNotEntityBlockResult() {
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(400.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(300.0);
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(100, 50));
        when(mockTitle.draw(any(Graphics2D.class), any(Rectangle2D.class), any())).thenReturn(new Object());

        XYTitleAnnotation annotation = new XYTitleAnnotation(50.0, 50.0, mockTitle, RectangleAnchor.CENTER);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 7, mockRenderInfo));
    }

    @Test
    void testDrawWithNegativeMaxWidthMaxHeight() {
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockDomainAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockRangeAxis.getRange()).thenReturn(new Range(0, 100));
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(100.0);
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(80, 40));

        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, mockTitle, RectangleAnchor.CENTER);
        annotation.setMaxWidth(-10.0);
        annotation.setMaxHeight(-20.0);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 8, mockRenderInfo));
    }

    @Test
    void testDrawWithZeroMaxWidthMaxHeightRelative() {
        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockPlot.getDomainAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        when(mockPlot.getRangeAxisLocation()).thenReturn(ValueAxis.DEFAULT_LOCATION);
        Range mockXRange = new Range(0, 200);
        Range mockYRange = new Range(0, 100);
        when(mockDomainAxis.getRange()).thenReturn(mockXRange);
        when(mockRangeAxis.getRange()).thenReturn(mockYRange);
        when(mockTitle.arrange(any(Graphics2D.class), any())).thenReturn(new org.jfree.chart.ui.Size2D(100, 50));

        XYTitleAnnotation annotation = new XYTitleAnnotation(0.5, 0.5, mockTitle, RectangleAnchor.CENTER);
        annotation.setMaxWidth(0.0);
        annotation.setMaxHeight(0.0);

        when(mockPlot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(mockDomainAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(400.0);
        when(mockRangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(300.0);
        when(mockDataArea.getWidth()).thenReturn(800.0);
        when(mockDataArea.getHeight()).thenReturn(600.0);

        assertDoesNotThrow(() -> annotation.draw(mockGraphics2D, mockPlot, mockDataArea, mockDomainAxis, mockRangeAxis, 9, mockRenderInfo));
    }
}