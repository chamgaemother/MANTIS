package org.apache.commons.math3.stat.inference;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class KolmogorovSmirnovTest_pelzGood_1_1_Test {

    @Test
    @DisplayName("pelzGood with d=0.5 and n=10 to test intermediate boundary condition")
    public void testTC19_pelzGood_intermediate_boundary_condition() {
        // GIVEN
        double d = 0.5;
        int n = 10;

        // WHEN
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "pelzGood should return a finite double value");
    }

    @Test
    @DisplayName("pelzGood with d=Double.POSITIVE_INFINITY and n=10 to test handling of infinite distance")
    public void testTC20_pelzGood_infinite_distance_handling() {
        // GIVEN
        double d = Double.POSITIVE_INFINITY;
        int n = 10;

        // WHEN
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(d, n);

        // THEN
        assertEquals(Double.POSITIVE_INFINITY, result, "pelzGood should return Double.POSITIVE_INFINITY for infinite d");
    }

    @Test
    @DisplayName("pelzGood with d=NaN and n=10 to verify behavior with undefined distance")
    public void testTC21_pelzGood_undefined_distance_handling() {
        // GIVEN
        double d = Double.NaN;
        int n = 10;

        // WHEN
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(d, n);

        // THEN
        assertTrue(Double.isNaN(result), "pelzGood should return NaN when d is NaN");
    }

    @Test
    @DisplayName("pelzGood with d=1e-10 and n=10 to test precision with minimal positive d")
    public void testTC22_pelzGood_minimal_positive_d_precision() {
        // GIVEN
        double d = 1e-10;
        int n = 10;

        // WHEN
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "pelzGood should return a finite, precise double value for minimal positive d");
    }

    @Test
    @DisplayName("pelzGood with d=1.0 and n=1 to test behavior with minimum sample size")
    public void testTC23_pelzGood_minimal_sample_size() {
        // GIVEN
        double d = 1.0;
        int n = 1;

        // WHEN
        KolmogorovSmirnovTest ksTest = new KolmogorovSmirnovTest();
        double result = ksTest.pelzGood(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "pelzGood should return a finite double value for minimal sample size");
    }
}