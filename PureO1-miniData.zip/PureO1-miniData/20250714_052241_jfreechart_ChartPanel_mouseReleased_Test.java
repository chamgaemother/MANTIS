package org.jfree.chart;

import static org.mockito.Mockito.*;

import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

import javax.swing.JPopupMenu;

import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.Pannable;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.Zoomable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class ChartPanelTest {

    private ChartPanel chartPanel;

    @Mock
    private JFreeChart chart;
    
    @Mock
    private Plot plot;
    
    @Mock
    private Zoomable zoomablePlot;
    
    @Mock
    private Pannable pannablePlot;
    
    @Mock
    private JPopupMenu popupMenu;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        chartPanel = new ChartPanel(chart);
        when(chart.getPlot()).thenReturn(plot);
    }

    @Test
    void testMouseReleased_PanningActive() {
        // Setup panning
        chartPanel.panLast = new java.awt.Point(100, 100);
        chartPanel.setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
        
        // Create mouse event
        MouseEvent e = mock(MouseEvent.class);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify panning reset
        assert(chartPanel.panLast == null);
        verify(chartPanel).setCursor(Cursor.getDefaultCursor());
    }
    
    @Test
    void testMouseReleased_ZoomRectangleActive_ZoomTriggerBoth() {
        // Setup zoom rectangle
        chartPanel.zoomRectangle = new Rectangle2D.Double(50, 50, 200, 200);
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        chartPanel.zoomTriggerDistance = 10;
        
        // Setup plot as Zoomable
        when(plot instanceof Zoomable).thenReturn(true);
        when(plot.isNotify()).thenReturn(true);
        when(plot instanceof Zoomable).thenReturn(true);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        Zoomable zoomable = mock(Zoomable.class);
        when(plot instanceof Zoomable).thenReturn(true);
        when(((Zoomable) plot).isDomainZoomable()).thenReturn(true);
        when(((Zoomable) plot).isRangeZoomable()).thenReturn(true);
        when(((Zoomable) plot).getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        chartPanel.setChart(chart);
        
        // Mock getScreenDataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 300, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();
        chartPanel.info.setPlotInfo(new org.jfree.chart.plot.PlotRenderingInfo(info));
        when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(dataArea);
        
        // Create mouse event with zoom triggers
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(150);
        when(e.getY()).thenReturn(150);
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify zoom was called
        verify((Zoomable) plot).zoomDomainAxes(anyDouble(), any(), any());
        verify((Zoomable) plot).zoomRangeAxes(anyDouble(), any(), any());
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle == null);
    }
    
    @Test
    void testMouseReleased_ZoomRectangleActive_ZoomTriggerNone() {
        // Setup zoom rectangle
        chartPanel.zoomRectangle = new Rectangle2D.Double(50, 50, 5, 5);
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        chartPanel.zoomTriggerDistance = 10;
        
        // Create mouse event without zoom triggers
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(102);
        when(e.getY()).thenReturn(102);
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify zoom was not called and zoomPoint and zoomRectangle reset
        verifyNoInteractions(plot);
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle == null);
    }
    
    @Test
    void testMouseReleased_ZoomRectangleActive_RestoreAutoBounds() {
        // Setup zoom rectangle
        chartPanel.zoomRectangle = new Rectangle2D.Double(50, 50, 200, 200);
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        chartPanel.zoomTriggerDistance = 10;
        
        // Setup plot as Zoomable
        when(plot instanceof Zoomable).thenReturn(true);
        Zoomable zoomable = mock(Zoomable.class);
        when(((Zoomable) plot).isDomainZoomable()).thenReturn(true);
        when(((Zoomable) plot).isRangeZoomable()).thenReturn(true);
        when(((Zoomable) plot).getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        chartPanel.setChart(chart);
        
        // Setup getScreenDataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 300, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();
        chartPanel.info.setPlotInfo(new org.jfree.chart.plot.PlotRenderingInfo(info));
        when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(dataArea);
        
        // Create mouse event with zoom triggers and condition to restore auto bounds
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(90); // less than zoomPoint.x
        when(e.getY()).thenReturn(90); // less than zoomPoint.y
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify restoreAutoBounds was called
        verify(plot, times(1)).setNotify(false);
        verify(zoomable, times(1)).zoomDomainAxes(anyDouble(), any(), any());
        verify(zoomable, times(1)).zoomRangeAxes(anyDouble(), any(), any());
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle == null);
    }
    
    @Test
    void testMouseReleased_NoPanning_NoZoomRectangle_PopupTrigger_PopupExists() {
        // Setup no panning and no zoom rectangle
        chartPanel.panLast = null;
        chartPanel.zoomRectangle = null;
        chartPanel.popup = popupMenu;
        
        // Create mouse event with popup trigger
        MouseEvent e = mock(MouseEvent.class);
        when(e.isPopupTrigger()).thenReturn(true);
        when(e.getX()).thenReturn(150);
        when(e.getY()).thenReturn(150);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify popup is displayed
        verify(popupMenu, times(1)).show(chartPanel, 150, 150);
    }
    
    @Test
    void testMouseReleased_NoPanning_NoZoomRectangle_PopupTrigger_PopupNull() {
        // Setup no panning and no zoom rectangle
        chartPanel.panLast = null;
        chartPanel.zoomRectangle = null;
        chartPanel.popup = null;
        
        // Create mouse event with popup trigger
        MouseEvent e = mock(MouseEvent.class);
        when(e.isPopupTrigger()).thenReturn(true);
        when(e.getX()).thenReturn(150);
        when(e.getY()).thenReturn(150);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify popup is not displayed
        verifyNoInteractions(popupMenu);
    }
    
    @Test
    void testMouseReleased_NoPanning_NoZoomRectangle_NoPopupTrigger() {
        // Setup no panning and no zoom rectangle
        chartPanel.panLast = null;
        chartPanel.zoomRectangle = null;
        chartPanel.popup = popupMenu;
        
        // Create mouse event without popup trigger
        MouseEvent e = mock(MouseEvent.class);
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify popup is not displayed
        verifyNoInteractions(popupMenu);
    }
    
    @Test
    void testMouseReleased_NullMouseEvent() {
        // Setup panning to be null and zoomRectangle null
        chartPanel.panLast = null;
        chartPanel.zoomRectangle = null;
        chartPanel.popup = null;
        
        // Invoke mouseReleased with null
        try {
            chartPanel.mouseReleased(null);
            assert(false); // Should not reach here
        } catch (NullPointerException ex) {
            assert(true); // Expected
        }
    }
    
    @Test
    void testMouseReleased_ZoomRectangleActive_HorizontalOrientation_HZoom() {
        // Setup zoom rectangle
        chartPanel.zoomRectangle = new Rectangle2D.Double(50, 50, 150, 150);
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        chartPanel.zoomTriggerDistance = 10;
        
        // Setup plot as Zoomable with horizontal orientation
        when(plot instanceof Zoomable).thenReturn(true);
        Zoomable zoomable = mock(Zoomable.class);
        when(((Zoomable) plot).isDomainZoomable()).thenReturn(false);
        when(((Zoomable) plot).isRangeZoomable()).thenReturn(true);
        when(((Zoomable) plot).getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        chartPanel.setChart(chart);
        
        // Mock getScreenDataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 300, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();
        chartPanel.info.setPlotInfo(new org.jfree.chart.plot.PlotRenderingInfo(info));
        when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(dataArea);
        
        // Create mouse event with hZoom trigger
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(120); // abs(120-100)=20 >= 10
        when(e.getY()).thenReturn(100);
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify zoomOutRange was called
        verify(zoomable, times(1)).zoomRangeAxes(anyDouble(), any(), any());
        verify(zoomable, never()).zoomDomainAxes(anyDouble(), any(), any());
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle == null);
    }
    
    @Test
    void testMouseReleased_ZoomRectangleActive_VerticalOrientation_VZoom() {
        // Setup zoom rectangle
        chartPanel.zoomRectangle = new Rectangle2D.Double(50, 50, 150, 150);
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        chartPanel.zoomTriggerDistance = 10;
        
        // Setup plot as Zoomable with vertical orientation
        when(plot instanceof Zoomable).thenReturn(true);
        Zoomable zoomable = mock(Zoomable.class);
        when(((Zoomable) plot).isDomainZoomable()).thenReturn(true);
        when(((Zoomable) plot).isRangeZoomable()).thenReturn(false);
        when(((Zoomable) plot).getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        chartPanel.setChart(chart);
        
        // Mock getScreenDataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 300, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();
        chartPanel.info.setPlotInfo(new org.jfree.chart.plot.PlotRenderingInfo(info));
        when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(dataArea);
        
        // Create mouse event with vZoom trigger
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(100);
        when(e.getY()).thenReturn(130); // abs(130-100)=30 >= 10
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify zoomInDomain was called
        verify(zoomable, times(1)).zoomDomainAxes(anyDouble(), any(), any());
        verify(zoomable, never()).zoomRangeAxes(anyDouble(), any(), any());
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle == null);
    }
    
    @Test
    void testMouseReleased_ZoomRectangleActive_OrientationMismatch_NoZoom() {
        // Setup zoom rectangle
        chartPanel.zoomRectangle = new Rectangle2D.Double(50, 50, 5, 5);
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        chartPanel.zoomTriggerDistance = 10;
        
        // Setup plot as Zoomable with vertical orientation and zoomTrigger not met
        when(plot instanceof Zoomable).thenReturn(true);
        Zoomable zoomable = mock(Zoomable.class);
        when(((Zoomable) plot).isDomainZoomable()).thenReturn(true);
        when(((Zoomable) plot).isRangeZoomable()).thenReturn(true);
        when(((Zoomable) plot).getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        chartPanel.setChart(chart);
        
        // Mock getScreenDataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 300, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();
        chartPanel.info.setPlotInfo(new org.jfree.chart.plot.PlotRenderingInfo(info));
        when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(dataArea);
        
        // Create mouse event with x < zoomPoint.x and y < zoomPoint.y
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(90); // < zoomPoint.x
        when(e.getY()).thenReturn(90); // < zoomPoint.y
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify restoreAutoBounds was called
        verify(zoomable, times(1)).zoomDomainAxes(anyDouble(), any(), any());
        verify(zoomable, times(1)).zoomRangeAxes(anyDouble(), any(), any());
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle == null);
    }
    
    @Test
    void testMouseReleased_ZoomRectangleActive_ScalingEdge() {
        // Setup zoom rectangle
        chartPanel.zoomRectangle = new Rectangle2D.Double(50, 50, 10, 10);
        chartPanel.zoomPoint = new java.awt.geom.Point2D.Double(100, 100);
        chartPanel.zoomTriggerDistance = 10;
        
        // Setup plot as Zoomable
        when(plot instanceof Zoomable).thenReturn(true);
        Zoomable zoomable = mock(Zoomable.class);
        when(((Zoomable) plot).isDomainZoomable()).thenReturn(true);
        when(((Zoomable) plot).isRangeZoomable()).thenReturn(true);
        when(((Zoomable) plot).getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        chartPanel.setChart(chart);
        
        // Mock getScreenDataArea
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 300, 300);
        ChartRenderingInfo info = new ChartRenderingInfo();
        chartPanel.info.setPlotInfo(new org.jfree.chart.plot.PlotRenderingInfo(info));
        when(chartPanel.getScreenDataArea(anyInt(), anyInt())).thenReturn(dataArea);
        
        // Create mouse event with zoomTrigger exactly met
        MouseEvent e = mock(MouseEvent.class);
        when(e.getX()).thenReturn(110); // abs(110-100)=10 == zoomTriggerDistance
        when(e.getY()).thenReturn(100);
        when(e.isPopupTrigger()).thenReturn(false);
        
        // Invoke mouseReleased
        chartPanel.mouseReleased(e);
        
        // Verify zoom was called
        verify(zoomable, times(1)).zoomDomainAxes(anyDouble(), any(), any());
        verify(zoomable, times(1)).zoomRangeAxes(anyDouble(), any(), any());
        assert(chartPanel.zoomPoint == null);
        assert(chartPanel.zoomRectangle == null);
    }
}