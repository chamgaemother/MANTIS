package com.fasterxml.jackson.core.json;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.BufferRecycler;

public class UTF8StreamJsonParser_nextToken_1_3_Test {

    @Test
    @DisplayName("nextToken correctly parses a boolean value 'true'")
    void TC16_nextToken_parses_true() throws Exception {
        // Initialize test input
        String json = "true";
        InputStream input = new ByteArrayInputStream(json.getBytes("UTF-8"));

        // Instantiate IOContext
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Access the constructor via reflection
        Constructor<UTF8StreamJsonParser> constructor = UTF8StreamJsonParser.class.getConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class,
                byte[].class, int.class, int.class, int.class, boolean.class);
        constructor.setAccessible(true);

        // Create an instance of UTF8StreamJsonParser
        UTF8StreamJsonParser parser = constructor.newInstance(
                ctxt, 0, input, null, sym, new byte[512], 0, json.length(), 0, true);

        // Invoke nextToken()
        JsonToken token = parser.nextToken();

        // Assert the token is VALUE_TRUE
        assertEquals(JsonToken.VALUE_TRUE, token);
    }

    @Test
    @DisplayName("nextToken correctly parses a boolean value 'false'")
    void TC17_nextToken_parses_false() throws Exception {
        // Initialize test input
        String json = "false";
        InputStream input = new ByteArrayInputStream(json.getBytes("UTF-8"));

        // Instantiate IOContext
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Access the constructor via reflection
        Constructor<UTF8StreamJsonParser> constructor = UTF8StreamJsonParser.class.getConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class,
                byte[].class, int.class, int.class, int.class, boolean.class);
        constructor.setAccessible(true);

        // Create an instance of UTF8StreamJsonParser
        UTF8StreamJsonParser parser = constructor.newInstance(
                ctxt, 0, input, null, sym, new byte[512], 0, json.length(), 0, true);

        // Invoke nextToken()
        JsonToken token = parser.nextToken();

        // Assert the token is VALUE_FALSE
        assertEquals(JsonToken.VALUE_FALSE, token);
    }

    @Test
    @DisplayName("nextToken correctly parses a string with newline escape sequence")
    void TC18_nextToken_parses_string_with_newline() throws Exception {
        // Initialize test input
        String json = "\"value\\n\""; // "value\n"
        InputStream input = new ByteArrayInputStream(json.getBytes("UTF-8"));

        // Instantiate IOContext
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Access the constructor via reflection
        Constructor<UTF8StreamJsonParser> constructor = UTF8StreamJsonParser.class.getConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class,
                byte[].class, int.class, int.class, int.class, boolean.class);
        constructor.setAccessible(true);

        // Create an instance of UTF8StreamJsonParser
        UTF8StreamJsonParser parser = constructor.newInstance(
                ctxt, 0, input, null, sym, new byte[512], 0, json.length(), 0, true);

        // Invoke nextToken()
        JsonToken token = parser.nextToken();

        // Assert the token is VALUE_STRING and contains a newline
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals("value\n", parser.getText());
    }

    @Test
    @DisplayName("nextToken correctly parses a string with tab escape sequence")
    void TC19_nextToken_parses_string_with_tab() throws Exception {
        // Initialize test input
        String json = "\"value\\t\""; // "value\t"
        InputStream input = new ByteArrayInputStream(json.getBytes("UTF-8"));

        // Instantiate IOContext
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Access the constructor via reflection
        Constructor<UTF8StreamJsonParser> constructor = UTF8StreamJsonParser.class.getConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class,
                byte[].class, int.class, int.class, int.class, boolean.class);
        constructor.setAccessible(true);

        // Create an instance of UTF8StreamJsonParser
        UTF8StreamJsonParser parser = constructor.newInstance(
                ctxt, 0, input, null, sym, new byte[512], 0, json.length(), 0, true);

        // Invoke nextToken()
        JsonToken token = parser.nextToken();

        // Assert the token is VALUE_STRING and contains a tab
        assertEquals(JsonToken.VALUE_STRING, token);
        assertEquals("value\t", parser.getText());
    }

    @Test
    @DisplayName("nextToken throws exception on string with invalid escape sequence '\\q'")
    void TC20_nextToken_throws_exception_on_invalid_escape() throws Exception {
        // Initialize test input
        String json = "\"value\\q\""; // "value\q"
        InputStream input = new ByteArrayInputStream(json.getBytes("UTF-8"));

        // Instantiate IOContext
        IOContext ctxt = new IOContext(new BufferRecycler(), input, false);

        // Instantiate ByteQuadsCanonicalizer
        ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();

        // Access the constructor via reflection
        Constructor<UTF8StreamJsonParser> constructor = UTF8StreamJsonParser.class.getConstructor(
                IOContext.class, int.class, InputStream.class, ObjectCodec.class, ByteQuadsCanonicalizer.class,
                byte[].class, int.class, int.class, int.class, boolean.class);
        constructor.setAccessible(true);

        // Create an instance of UTF8StreamJsonParser
        UTF8StreamJsonParser parser = constructor.newInstance(
                ctxt, 0, input, null, sym, new byte[512], 0, json.length(), 0, true);

        // Assert that JsonParseException is thrown when nextToken() is called
        assertThrows(JsonParseException.class, () -> {
            parser.nextToken();
        });
    }
}
