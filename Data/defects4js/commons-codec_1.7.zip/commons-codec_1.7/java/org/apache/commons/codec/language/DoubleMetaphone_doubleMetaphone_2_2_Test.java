package org.apache.commons.codec.language;

import org.apache.commons.codec.language.DoubleMetaphone;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_2_2_Test {

    @Test
    @DisplayName("doubleMetaphone(\"QUICK\", false) handles 'Q' followed by 'U'")
    void TC56_doubleMetaphone_QUICK_false_handlesQ_followedByU() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "QUICK";
        String result = encoder.doubleMetaphone(input, false);
        assertEquals("KK", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"SCHMUCK\", false) handles 'SCH' combination")
    void TC57_doubleMetaphone_SCHMUCK_false_handlesSCH_combination() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "SCHMUCK";
        String result = encoder.doubleMetaphone(input, false);
        assertEquals("SKMK", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"MIDDLE\", false) handles 'DD' with vowel following")
    void TC58_doubleMetaphone_MIDDLE_false_handlesDD_with_vowel_following() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "MIDDLE";
        String result = encoder.doubleMetaphone(input, false);
        assertEquals("MDL", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"PHRASER\", false) handles 'PH' followed by 'R'")
    void TC59_doubleMetaphone_PHRASER_false_handlesPH_followedByR() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "PHRASER";
        String result = encoder.doubleMetaphone(input, false);
        assertEquals("FRSR", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"XERXES\", false) handles multiple 'X's in the string")
    void TC60_doubleMetaphone_XERXES_false_handles_multiple_Xs() {
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "XERXES";
        String result = encoder.doubleMetaphone(input, false);
        assertEquals("SRSKS", result);
    }
}