package org.apache.commons.collections4.functors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

public class ComparatorPredicate_test_0_1_Test {

    @Test
    @DisplayName("Criterion EQUAL with comparison equal to zero returns true")
    public void TC01() throws Exception {
        // GIVEN
        Comparator<Object> comparator = (first, second) -> 0;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.EQUAL);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        assertTrue(result, "Expected result to be true");
    }

    @Test
    @DisplayName("Criterion EQUAL with comparison not equal to zero returns false")
    public void TC02() throws Exception {
        // GIVEN
        Comparator<Object> comparator = (first, second) -> 1;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.EQUAL);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        assertFalse(result, "Expected result to be false");
    }

    @Test
    @DisplayName("Criterion GREATER with comparison greater than zero returns true")
    public void TC03() throws Exception {
        // GIVEN
        Comparator<Object> comparator = (first, second) -> 1;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.GREATER);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        assertTrue(result, "Expected result to be true");
    }

    @Test
    @DisplayName("Criterion GREATER with comparison not greater than zero returns false")
    public void TC04() throws Exception {
        // GIVEN
        Comparator<Object> comparator = (first, second) -> 0;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.GREATER);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        assertFalse(result, "Expected result to be false");
    }

    @Test
    @DisplayName("Criterion LESS with comparison less than zero returns true")
    public void TC05() throws Exception {
        // GIVEN
        Comparator<Object> comparator = (first, second) -> -1;
        Object target = new Object();
        ComparatorPredicate<Object> predicate = new ComparatorPredicate<>(target, comparator, ComparatorPredicate.Criterion.LESS);
        Object object = new Object();

        // WHEN
        boolean result = predicate.test(object);

        // THEN
        assertTrue(result, "Expected result to be true");
    }
}
