package org.joda.time.format;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.StringWriter;
import java.io.Writer;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FormatUtils_writePaddedInteger_0_3_Test {

    @Test
    @DisplayName("writePaddedInteger with positive value >=10000 and size equals calculated digits (no padding)")
    public void TC11_writePaddedInteger_positive_five_digits_no_padding() throws Exception {
        // GIVEN
        Writer writer = new StringWriter();
        int value = 12345;
        int size = 5;

        // WHEN
        FormatUtils.writePaddedInteger(writer, value, size);

        // THEN
        assertEquals("12345", writer.toString());
    }
}