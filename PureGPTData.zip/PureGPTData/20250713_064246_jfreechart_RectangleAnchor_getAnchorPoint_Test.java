import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.ui.RectangleAnchor;
import org.jfree.chart.util.Args;
import org.junit.jupiter.api.Test;

class RectangleAnchorTest {

    @Test
    void testGetAnchorPointCenter() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.CENTER.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(50, 50), point);
    }

    @Test
    void testGetAnchorPointTop() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.TOP.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(50, 0), point);
    }

    @Test
    void testGetAnchorPointBottom() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.BOTTOM.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(50, 100), point);
    }

    @Test
    void testGetAnchorPointLeft() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.LEFT.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(0, 50), point);
    }

    @Test
    void testGetAnchorPointRight() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.RIGHT.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(100, 50), point);
    }

    @Test
    void testGetAnchorPointTopLeft() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.TOP_LEFT.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(0, 0), point);
    }

    @Test
    void testGetAnchorPointTopRight() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.TOP_RIGHT.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(100, 0), point);
    }

    @Test
    void testGetAnchorPointBottomLeft() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.BOTTOM_LEFT.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(0, 100), point);
    }

    @Test
    void testGetAnchorPointBottomRight() {
        Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
        Point2D point = RectangleAnchor.BOTTOM_RIGHT.getAnchorPoint(rect);
        assertEquals(new Point2D.Double(100, 100), point);
    }

    @Test
    void testGetAnchorPointNullRectangle() {
        assertThrows(IllegalArgumentException.class, () -> {
            RectangleAnchor.CENTER.getAnchorPoint(null);
        });
    }
}