package com.fasterxml.jackson.dataformat.xml.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class StaxUtil_sanitizeXmlTypeName_0_2_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName with disallowed character '#' is replaced with '_'")
    void TC06() {
        // GIVEN
        String name = "User#Name";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("User_Name", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with non-ASCII character is left unchanged")
    void TC07() {
        // GIVEN
        String name = "CafÃ©";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("CafÃ©", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with empty string returns 's' after appending")
    void TC08() {
        // GIVEN
        String name = "";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("s", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with name containing '.' and '-' but no changes needed")
    void TC09() {
        // GIVEN
        String name = "Version-1.0";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("Version-1.0", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with multiple disallowed characters are replaced appropriately")
    void TC10() {
        // GIVEN
        String name = "User$Name#1";

        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);

        // THEN
        assertEquals("User.Name_1", result);
    }
}