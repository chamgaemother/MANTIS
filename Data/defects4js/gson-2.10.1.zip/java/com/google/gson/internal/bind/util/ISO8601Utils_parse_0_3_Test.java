package com.google.gson.internal.bind.util;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ISO8601Utils_parse_0_3_Test {

    @Test
    @DisplayName("parse date with invalid timezone indicator character")
    void TC11_parseDateWithInvalidTimezoneIndicatorCharacter() {
        String date = "2023-10-05T14:30:00X";
        ParsePosition pos = new ParsePosition(0);

        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });

        assertEquals("Invalid time zone indicator 'X'", exception.getMessage());
    }

    @Test
    @DisplayName("parse date with leap second, truncated to 59")
    void TC12_parseDateWithLeapSecond_TruncatedTo59() throws ParseException {
        String date = "2023-10-05T14:30:60Z";
        ParsePosition pos = new ParsePosition(0);

        Date result = ISO8601Utils.parse(date, pos);

        // Verify that seconds are truncated to 59
        // Note: Date's getSeconds() is deprecated, but used here per scenario requirements
        assertEquals(59, result.getSeconds(), "Seconds should be truncated to 59");
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should match date length");
    }

    @Test
    @DisplayName("parse empty input string")
    void TC13_parseEmptyInputString() {
        String date = "";
        ParsePosition pos = new ParsePosition(0);

        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("parse null input string")
    void TC14_parseNullInputString() {
        String date = null;
        ParsePosition pos = new ParsePosition(0);

        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("parse date with non-digit character in day")
    void TC15_parseDateWithNonDigitCharacterInDay() {
        String date = "2023-10-0X";
        ParsePosition pos = new ParsePosition(0);

        assertThrows(NumberFormatException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }
}