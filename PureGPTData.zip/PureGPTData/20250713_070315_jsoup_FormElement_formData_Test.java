import org.jsoup.Connection;
import org.jsoup.helper.HttpConnection;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.FormElement;
import org.jsoup.nodes.Tag;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FormElementTest {
    private FormElement form;

    @BeforeEach
    void setUp() {
        String html = "<form id='myForm' action='/submit' method='POST'>" +
                "<input type='text' name='username' value='jsoupTesting'>" +
                "<input type='password' name='password' value='secret'>" +
                "<input type='checkbox' name='subscribe' checked>" +
                "<input type='checkbox' name='newsletter'>" +
                "<select name='country'><option value='US' selected>United States</option><option value='CA'>Canada</option></select>" +
                "<input type='hidden' name='hiddenField' value='hiddenValue'>" +
                "<input type='radio' name='gender' value='female' checked>" +
                "<input type='radio' name='gender' value='male'>" +
                "<button type='submit'>Submit</button>" +
                "</form>";
        Document doc = Parser.parse(html, "http://example.com/");
        form = (FormElement) doc.getElementById("myForm");
    }

    @Test
    void testFormDataIncludesAllSubmittableInputs() {
        List<Connection.KeyVal> data = form.formData();

        assertEquals(6, data.size());
        assertTrue(data.contains(HttpConnection.KeyVal.create("username", "jsoupTesting")));
        assertTrue(data.contains(HttpConnection.KeyVal.create("password", "secret")));
        assertTrue(data.contains(HttpConnection.KeyVal.create("subscribe", "on")));
        assertTrue(data.contains(HttpConnection.KeyVal.create("country", "US")));
        assertTrue(data.contains(HttpConnection.KeyVal.create("hiddenField", "hiddenValue")));
        assertTrue(data.contains(HttpConnection.KeyVal.create("gender", "female")));
    }

    @Test
    void testFormDataExcludesNonSubmittableInputs() {
        form.appendElement("input").attr("name", "ignoreMe").attr("type", "button");

        List<Connection.KeyVal> data = form.formData();

        assertEquals(6, data.size()); // previous test already ensures the included data
    }

    @Test
    void testFormDataExcludesDisabledInputs() {
        form.appendElement("input").attr("name", "disabledField").attr("type", "text")
                .attr("value", "shouldNotBeIncluded").attr("disabled", "disabled");

        List<Connection.KeyVal> data = form.formData();

        assertEquals(6, data.size()); // previous test already ensures the included data
    }

    @Test
    void testFormDataSelectsDefaultOptionIfNoSelectedOption() {
        form.appendElement("select").attr("name", "colors")
                .appendElement("option").attr("value", "red")
                .parent().appendElement("option").attr("value", "blue").attr("selected", "selected");

        List<Connection.KeyVal> data = form.formData();

        assertTrue(data.contains(HttpConnection.KeyVal.create("colors", "blue")));
    }

    @Test
    void testCheckboxUnchecked() {
        form.select("input[name=newsletter]").first().attr("checked", "checked");
        List<Connection.KeyVal> data = form.formData();

        assertTrue(data.contains(HttpConnection.KeyVal.create("newsletter", "on")));
    }

    @Test
    void testRadioUnselected() {
        form.select("input[name=gender]").forEach(el -> el.removeAttr("checked"));
        List<Connection.KeyVal> data = form.formData();

        data.forEach(kv -> assertTrue(!kv.key().equals("gender")));
    }
}