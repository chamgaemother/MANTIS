package org.apache.commons.math3.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class FastMath_scalb_1_1_Test {

    @Test
    @DisplayName("scalb with n causing scaledExponent exactly -53, resulting in a subnormal number")
    public void TC18_scalb_scaledExponentMinus53_subnormal() {
        // GIVEN
        double d = 1.0;
        int n = -53;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "Result should be a finite subnormal number.");
        assertTrue(Double.doubleToRawLongBits(result) < Double.MIN_NORMAL, "Result should be a subnormal number.");
        assertEquals(-53, FastMath.getExponent(result), "The scaled exponent should be -53.");
    }

    @Test
    @DisplayName("scalb with n causing scaledExponent exactly -54, ensuring correct subnormal scaling")
    public void TC19_scalb_scaledExponentMinus54_subnormal() {
        // GIVEN
        double d = 1.0;
        int n = -54;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertTrue(Double.isFinite(result), "Result should be a finite subnormal number.");
        assertTrue(Double.doubleToRawLongBits(result) < Double.MIN_NORMAL, "Result should be a subnormal number.");
        assertEquals(-54, FastMath.getExponent(result), "The scaled exponent should be -54.");
    }

    @Test
    @DisplayName("scalb with n=0, ensuring the result is unchanged")
    public void TC20_scalb_nZero_resultUnchanged() {
        // GIVEN
        double d = 5.0;
        int n = 0;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(d, result, "Result should be unchanged when n=0.");
    }

    @Test
    @DisplayName("scalb with n causing scaledExponent exactly 0, resulting in a normalized number")
    public void TC21_scalb_scaledExponentZero_normalized() {
        // GIVEN
        double d = 2.0;
        int n = -1;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(1.0, result, "Result should be normalized to 1.0 when scaledExponent is 0.");
        assertEquals(0, FastMath.getExponent(result), "The scaled exponent should be 0.");
    }

    @Test
    @DisplayName("scalb with d as a normal number and n=1, ensuring scaledExponent increments correctly")
    public void TC22_scalb_nOne_scaledExponentIncrements() {
        // GIVEN
        double d = 3.0;
        int n = 1;

        // WHEN
        double result = FastMath.scalb(d, n);

        // THEN
        assertEquals(6.0, result, "Result should be d multiplied by 2.");
        assertEquals(1, FastMath.getExponent(result), "The scaled exponent should be 1.");
    }

}