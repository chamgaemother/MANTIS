package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Random;

public class RandomStringUtils_random_0_3_Test {

    @Test
    @DisplayName("random(count, start=0, end=0, letters=false, numbers=true, chars=null, random) optimizes for numbers only")
    void TC11() {
        int count = 5;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        assertNotNull(result, "Result should not be null");
        assertEquals(count, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> Character.isDigit(c)), "All characters should be digits");
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=true, numbers=true, chars=null, random) adjusts range correctly when letters and numbers are true")
    void TC12() {
        int count = 7;
        int start = 0;
        int end = 0;
        boolean letters = true;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        assertNotNull(result, "Result should not be null");
        assertEquals(count, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> Character.isLetterOrDigit(c)), "All characters should be letters or digits");
    }

    @Test
    @DisplayName("random(count, start=0, end=0, letters=false, numbers=false, chars=null, random) sets range to full Unicode when letters and numbers are false")
    void TC13() {
        int count = 10;
        int start = 0;
        int end = 0;
        boolean letters = false;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        assertNotNull(result, "Result should not be null");
        assertEquals(count, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> c >= 0 && c <= Character.MAX_CODE_POINT), "All characters should be within the full Unicode range");
    }

    @Test
    @DisplayName("random(count, start=50, end=100, letters=true, numbers=false, chars=null, random) generates string with only letters")
    void TC14() {
        int count = 6;
        int start = 50;
        int end = 100;
        boolean letters = true;
        boolean numbers = false;
        char[] chars = null;
        Random random = new Random();

        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        assertNotNull(result, "Result should not be null");
        assertEquals(count, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> Character.isLetter(c) && c >= 50 && c < 100), "All characters should be letters within the specified range");
    }

    @Test
    @DisplayName("random(count, start=48, end=58, letters=false, numbers=true, chars=null, random) generates string with only digits")
    void TC15() {
        int count = 4;
        int start = 48;
        int end = 58;
        boolean letters = false;
        boolean numbers = true;
        char[] chars = null;
        Random random = new Random();

        String result = RandomStringUtils.random(count, start, end, letters, numbers, chars, random);

        assertNotNull(result, "Result should not be null");
        assertEquals(count, result.length(), "Result length should be equal to count");
        assertTrue(result.chars().allMatch(c -> Character.isDigit(c) && c >= 48 && c < 58), "All characters should be digits within the specified range");
    }
}