package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_2_3_Test {

    @Test
    @DisplayName("Input with 'D' before 'X', should assign code '2'")
    public void TC54() {
        // GIVEN
        String input = "Dax";
        ColognePhonetic phonetic = new ColognePhonetic();

        // WHEN
        String result = phonetic.colognePhonetic(input);

        // THEN
        assertTrue(result.contains("2"), "Result should contain '2' for 'D' before 'X'");
    }

    @Test
    @DisplayName("Input with multiple iterations, testing loop behavior with large input")
    public void TC55() {
        // GIVEN
        StringBuilder inputBuilder = new StringBuilder();
        for(int i = 0; i < 1000; i++) {
            inputBuilder.append("Success");
        }
        String input = inputBuilder.toString();
        ColognePhonetic phonetic = new ColognePhonetic();

        // WHEN
        String result = phonetic.colognePhonetic(input);

        // THEN
        assertNotNull(result, "Result should not be null for large input");
        // Additional assertions can be added to verify correctness
    }

    @Test
    @DisplayName("Input with single 'X' not after 'C', should assign code '4' and add 'S'")
    public void TC56() {
        // GIVEN
        String input = "Ax";
        ColognePhonetic phonetic = new ColognePhonetic();

        // WHEN
        String result = phonetic.colognePhonetic(input);

        // THEN
        assertTrue(result.contains("4S"), "Result should contain '4S' for single 'X' not after 'C'");
    }

    @Test
    @DisplayName("Input with multiple 'H's, should handle multiple '-' correctly")
    public void TC57() {
        // GIVEN
        String input = "Hannah";
        ColognePhonetic phonetic = new ColognePhonetic();

        // WHEN
        String result = phonetic.colognePhonetic(input);

        // THEN
        assertFalse(result.contains("--"), "Result should not contain consecutive '-' for multiple 'H's");
    }

    @Test
    @DisplayName("Input with non-specified characters following 'C', should assign code '8'")
    public void TC58() {
        // GIVEN
        String input = "Chelsey";
        ColognePhonetic phonetic = new ColognePhonetic();

        // WHEN
        String result = phonetic.colognePhonetic(input);

        // THEN
        assertTrue(result.contains("8"), "Result should contain '8' for 'C' followed by non-specified letters");
    }
}