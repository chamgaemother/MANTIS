package org.apache.commons.math3.distribution.fitting;

import org.apache.commons.math3.distribution.MixtureMultivariateNormalDistribution;
import org.apache.commons.math3.distribution.MultivariateNormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.util.Pair;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MultivariateNormalMixtureExpectationMaximization_fit_0_2_Test {

    @Test
    @DisplayName("fit executes multiple iterations and converges successfully")
    void TC06_fitConvergesSuccessfully() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createValidInitialMixture();
        int maxIterations = 100;
        double threshold = 1e-6;
        double[][] data = createMultipleDataPoints();

        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN
        em.fit(initialMixture, maxIterations, threshold);

        // THEN
        // Access private field 'fittedModel' via reflection
        Field fittedModelField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(em);

        assertNotNull(fittedModel, "Fitted model should not be null after convergence.");
        // Additional assertions can be added here to verify the fitted model's parameters
    }

    @Test
    @DisplayName("fit exceeds maxIterations without convergence and throws ConvergenceException")
    void TC07_fitThrowsConvergenceException() {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createNonConvergingInitialMixture();
        int maxIterations = 5;
        double threshold = 1e-12;
        double[][] data = createDataPoints();

        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN & THEN
        assertThrows(ConvergenceException.class, () -> em.fit(initialMixture, maxIterations, threshold),
                "Expected fit to throw ConvergenceException when maxIterations are exceeded.");
    }

    @Test
    @DisplayName("fit with zero data points processes correctly without iterations")
    void TC08_fitWithZeroDataPoints() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createValidInitialMixture();
        int maxIterations = 10;
        double threshold = 1e-6;
        double[][] data = new double[][] {{}}; // Adjusted to be non-null with zero length

        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN
        em.fit(initialMixture, maxIterations, threshold);

        // THEN
        // Access private field 'fittedModel' via reflection
        Field fittedModelField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(em);

        assertEquals(initialMixture, fittedModel, "Fitted model should remain unchanged when data is empty.");
    }

    @Test
    @DisplayName("fit with one data point processes correctly")
    void TC09_fitWithOneDataPoint() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createValidInitialMixture();
        int maxIterations = 10;
        double threshold = 1e-6;
        double[][] data = { {1.0, 2.0, 3.0} }; // Example single data point

        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN
        em.fit(initialMixture, maxIterations, threshold);

        // THEN
        // Access private field 'fittedModel' via reflection
        Field fittedModelField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(em);

        assertNotNull(fittedModel, "Fitted model should not be null after processing one data point.");
        // Additional assertions can be added here to verify the fitted model's parameters
    }

    @Test
    @DisplayName("fit with multiple data points processes correctly")
    void TC10_fitWithMultipleDataPoints() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createValidInitialMixture();
        int maxIterations = 50;
        double threshold = 1e-6;
        double[][] data = createMultipleDataPoints();

        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);

        // WHEN
        em.fit(initialMixture, maxIterations, threshold);

        // THEN
        // Access private field 'fittedModel' via reflection
        Field fittedModelField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(em);

        assertNotNull(fittedModel, "Fitted model should not be null after processing multiple data points.");
        // Additional assertions can be added here to verify the fitted model's parameters
    }

    // Helper methods to create initial mixtures and data points
    private MixtureMultivariateNormalDistribution createValidInitialMixture() {
        // Implement creation of a valid initial mixture requiring multiple iterations to converge
        // Here we create a dummy object; replace it with actual implementation
        List<Pair<Double, MultivariateNormalDistribution>> components = new ArrayList<>();
        return new MixtureMultivariateNormalDistribution(components);
    }

    private MixtureMultivariateNormalDistribution createNonConvergingInitialMixture() {
        // Implement creation of an initial mixture that does not converge within maxIterations
        // Here we create a dummy object; replace it with actual implementation
        List<Pair<Double, MultivariateNormalDistribution>> components = new ArrayList<>();
        return new MixtureMultivariateNormalDistribution(components);
    }

    private double[][] createMultipleDataPoints() {
        // Implement creation of multiple data points
        return new double[][] {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0},
            {7.0, 8.0, 9.0}
        };
    }

    private double[][] createDataPoints() {
        // Implement creation of data points for non-converging scenario
        return new double[][] {
            {1.0, 2.0, 3.0},
            {4.0, 5.0, 6.0}
        };
    }
}