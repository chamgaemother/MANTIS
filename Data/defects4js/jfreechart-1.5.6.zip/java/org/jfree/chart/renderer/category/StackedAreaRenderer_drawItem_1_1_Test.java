package org.jfree.chart.renderer.category;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.mockito.Mockito.*;
import org.mockito.ArgumentCaptor;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.renderer.category.StackedAreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.ui.RectangleEdge;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.GeneralPath;

public class StackedAreaRenderer_drawItem_1_1_Test {

    @Test
    @DisplayName("Draw item with pass=1 to trigger label drawing")
    public void TC27_drawItem_Pass1_LabelDrawing() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setRenderAsPercentages(false);
        renderer.setSeriesVisible(0, true);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getValue(0, 0)).thenReturn(10);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
        
        // Creating a spy to verify drawItemLabel method
        StackedAreaRenderer spyRenderer = spy(renderer);
        
        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 1);

        // THEN
        verify(spyRenderer).drawItemLabel(eq(g2), any(), eq(dataset), eq(0), eq(0), anyDouble(), anyFloat(), anyBoolean());
    }

    @Test
    @DisplayName("Draw item with pass=2 to handle invalid pass value gracefully")
    public void TC28_drawItem_InvalidPass_NoActionOrException() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setRenderAsPercentages(false);
        renderer.setSeriesVisible(0, true);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getValue(0, 0)).thenReturn(10);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
        
        // Creating a spy to verify no unintended actions
        StackedAreaRenderer spyRenderer = spy(renderer);
        
        // WHEN
        spyRenderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 2);

        // THEN
        // Verify that no painting methods are called and no exceptions are thrown
        verify(g2, never()).setPaint(any(Paint.class));
        verify(g2, never()).fill(any(Shape.class));
        verify(spyRenderer, never()).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyFloat(), anyBoolean());
    }

    @Test
    @DisplayName("Draw item at maximum column index to test boundary condition")
    public void TC29_drawItem_MaxColumnIndex_BoundaryCondition() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setRenderAsPercentages(false);
        renderer.setSeriesVisible(0, true);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        int maxColumn = 4;
        when(dataset.getValue(0, maxColumn)).thenReturn(15);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMiddle(eq(maxColumn), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(250.0);
        when(domainAxis.getCategoryStart(eq(maxColumn), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(200.0);
        when(domainAxis.getCategoryEnd(eq(maxColumn), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(300.0);
        when(dataset.getColumnCount()).thenReturn(maxColumn + 1);
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, maxColumn, 0);

        // THEN
        // Verify that fill is called for both left and right paths
        verify(g2, times(2)).fill(any(Shape.class));
    }

    @Test
    @DisplayName("Draw item with dataset.getValue(row, column) returning NaN")
    public void TC30_drawItem_NaNValue_HandledGracefully() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setRenderAsPercentages(false);
        renderer.setSeriesVisible(0, true);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getValue(0, 0)).thenReturn(Double.NaN);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // THEN
        // Verify that fill is not called due to NaN value
        verify(g2, never()).fill(any(Shape.class));
    }

    @Test
    @DisplayName("Draw item with dataset.getValue(row, column) returning Infinity")
    public void TC31_drawItem_InfinityValue_HandledGracefully() throws Exception {
        // GIVEN
        StackedAreaRenderer renderer = new StackedAreaRenderer();
        renderer.setRenderAsPercentages(false);
        renderer.setSeriesVisible(0, true);
        
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        when(dataset.getValue(0, 0)).thenReturn(Double.POSITIVE_INFINITY);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class))).thenReturn(50.0);
        
        // WHEN
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);

        // THEN
        // Verify that fill is called appropriately despite Infinity value
        verify(g2, atLeastOnce()).fill(any(Shape.class));
    }
}