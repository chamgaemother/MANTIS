package org.apache.commons.compress.archivers.zip;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

public class ZipArchiveEntry_equals_0_1_Test {

    @Test
    @DisplayName("Verify equality when comparing the object to itself")
    void testSelfComparison() {
        // GIVEN ZipArchiveEntry entry initialized with default properties
        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");

        // WHEN equals is called with entry itself
        boolean result = entry.equals(entry);

        // THEN result should be true
        assertTrue(result);
    }

    @Test
    @DisplayName("Verify that comparing with null returns false")
    void testNullComparison() {
        // GIVEN ZipArchiveEntry entry initialized
        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");

        // WHEN equals is called with null
        boolean result = entry.equals(null);

        // THEN result should be false
        assertFalse(result);
    }

    @Test
    @DisplayName("Verify comparison with a different class object returns false")
    void testDifferentClassComparison() {
        // GIVEN ZipArchiveEntry entry initialized
        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");

        // WHEN equals is called with object of different class
        boolean result = entry.equals("not a zip entry");

        // THEN result should be false
        assertFalse(result);
    }

    @Test
    @DisplayName("Verify equality when names are different")
    void testDifferentNames() {
        // GIVEN Two ZipArchiveEntry instances with different names
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry1");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry2");

        // WHEN equals is called
        boolean result = entry1.equals(entry2);

        // THEN result should be false
        assertFalse(result);
    }

    @Test
    @DisplayName("Verify equality with both non-null and equal comments")
    void testEqualComments() {
        // GIVEN Two ZipArchiveEntry instances with equal non-null comments
        ZipArchiveEntry entry1 = new ZipArchiveEntry("entry");
        ZipArchiveEntry entry2 = new ZipArchiveEntry("entry");

        try {
            Field commentField = ZipArchiveEntry.class.getDeclaredField("comment");
            commentField.setAccessible(true);
            commentField.set(entry1, "same comment");
            commentField.set(entry2, "same comment");

        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection setup for comment fields failed", e);
        }

        // WHEN equals is called
        boolean result = entry1.equals(entry2);

        // THEN result should be true
        assertTrue(result);
    }
}