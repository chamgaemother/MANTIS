// package org.jfree.chart.renderer.xy;
// // 
// // import static org.junit.jupiter.api.Assertions.*;
// // import static org.mockito.ArgumentMatchers.any;
// // import static org.mockito.Mockito.*;
// // 
// // import java.awt.Graphics2D;
// // import java.awt.Paint;
// // import java.awt.Point;
// // import java.awt.Polygon;
// // import java.awt.geom.Rectangle2D;
// // import java.lang.reflect.Field;
// // import java.lang.reflect.Method;
// // import org.jfree.chart.axis.ValueAxis;
// // import org.jfree.chart.plot.CrosshairState;
// // import org.jfree.chart.plot.PlotOrientation;
// // import org.jfree.chart.plot.PlotRenderingInfo;
// // import org.jfree.chart.plot.XYPlot;
// // import org.jfree.chart.renderer.xy.StackedXYAreaRenderer.StackedXYAreaRendererState;
// // import org.jfree.data.xy.XYDataset;
// // import org.junit.jupiter.api.DisplayName;
// // import org.junit.jupiter.api.Test;
// // 
// public class StackedXYAreaRenderer_drawItem_2_1_Test {
// // 
// //     @Test
// //     @DisplayName("TC06: drawItem with y1 as positive value and PlotOrientation.HORIZONTAL adds points correctly to series area")
// //     void TC06() throws Exception {
// //         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
// //         renderer.setUseFillPaint(true);
// // 
// //         XYDataset dataset = mock(XYDataset.class);
// //         when(dataset.getXValue(0, 0)).thenReturn(5.0);
// //         when(dataset.getYValue(0, 0)).thenReturn(10.0);
// // 
// //         PlotOrientation orientation = PlotOrientation.HORIZONTAL;
// // 
// //         XYPlot plot = mock(XYPlot.class);
// //         when(plot.getOrientation()).thenReturn(orientation);
// // 
// //         ValueAxis domainAxis = mock(ValueAxis.class);
// //         when(domainAxis.valueToJava2D(eq(5.0), any(Rectangle2D.class), any())).thenReturn(50.0);
// // 
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         when(rangeAxis.valueToJava2D(eq(10.0), any(Rectangle2D.class), any())).thenReturn(100.0);
// // 
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double();
// //         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// //         CrosshairState crosshairState = mock(CrosshairState.class);
// // 
//         // Initialize renderer state via reflection
// //         Method initialiseMethod = StackedXYAreaRenderer.class.getMethod("initialise", Graphics2D.class, Rectangle2D.class, XYPlot.class, XYDataset.class, PlotRenderingInfo.class);
// //         StackedXYAreaRendererState state = (StackedXYAreaRendererState) initialiseMethod.invoke(renderer, g2, dataArea, plot, dataset, info);
// // 
//         // WHEN
// //         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// // 
//         // THEN
// //         Field seriesAreaField = StackedXYAreaRendererState.class.getDeclaredField("seriesArea");
// //         seriesAreaField.setAccessible(true);
// //         Polygon seriesArea = (Polygon) seriesAreaField.get(state);
// // 
// //         assertNotNull(seriesArea, "Series area should not be null");
// //         assertEquals(2, seriesArea.npoints, "Series area should contain two points for horizontal orientation");
// // 
// //         assertEquals(50, seriesArea.xpoints[0], "First point X coordinate mismatch");
// //         assertEquals(0, seriesArea.ypoints[0], "First point Y coordinate mismatch (base)");
// //         assertEquals(100, seriesArea.xpoints[1], "Second point X coordinate mismatch");
// //         assertEquals(50, seriesArea.ypoints[1], "Second point Y coordinate mismatch (y1)");
// //     }
// // 
// //     @Test
// //     @DisplayName("TC07: drawItem with negative y1 value correctly handles stacking and area plotting")
// //     void TC07() throws Exception {
// //         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
// //         renderer.setUseFillPaint(true);
// // 
// //         XYDataset dataset = mock(XYDataset.class);
// //         when(dataset.getXValue(1, 2)).thenReturn(3.0);
// //         when(dataset.getYValue(1, 2)).thenReturn(-5.0);
// // 
// //         PlotOrientation orientation = PlotOrientation.VERTICAL;
// // 
// //         XYPlot plot = mock(XYPlot.class);
// //         when(plot.getOrientation()).thenReturn(orientation);
// // 
// //         ValueAxis domainAxis = mock(ValueAxis.class);
// //         when(domainAxis.valueToJava2D(eq(3.0), any(Rectangle2D.class), any())).thenReturn(30.0);
// // 
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         when(rangeAxis.valueToJava2D(eq(-5.0), any(Rectangle2D.class), any())).thenReturn(-50.0);
// // 
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double();
// //         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// //         CrosshairState crosshairState = mock(CrosshairState.class);
// // 
// //         Method initialiseMethod = StackedXYAreaRenderer.class.getMethod("initialise", Graphics2D.class, Rectangle2D.class, XYPlot.class, XYDataset.class, PlotRenderingInfo.class);
// //         StackedXYAreaRendererState state = (StackedXYAreaRendererState) initialiseMethod.invoke(renderer, g2, dataArea, plot, dataset, info);
// // 
// //         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 2, crosshairState, 0);
// // 
// //         Field seriesAreaField = StackedXYAreaRendererState.class.getDeclaredField("seriesArea");
// //         seriesAreaField.setAccessible(true);
// //         Polygon seriesArea = (Polygon) seriesAreaField.get(state);
// // 
// //         assertNotNull(seriesArea, "Series area should not be null");
// //         assertTrue(seriesArea.npoints > 0, "Series area should contain points for negative y1 handling");
// //     }
// //     
// //     @Test
// //     @DisplayName("TC08: drawItem with getUseFillPaint set to false uses itemPaint for fill")
// //     void TC08() throws Exception {
// //         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
// //         renderer.setUseFillPaint(false);
// // 
// //         XYDataset dataset = mock(XYDataset.class);
// //         when(dataset.getXValue(0, 1)).thenReturn(10.0);
// //         when(dataset.getYValue(0, 1)).thenReturn(20.0);
// // 
// //         PlotOrientation orientation = PlotOrientation.VERTICAL;
// // 
// //         XYPlot plot = mock(XYPlot.class);
// //         when(plot.getOrientation()).thenReturn(orientation);
// // 
// //         ValueAxis domainAxis = mock(ValueAxis.class);
// //         when(domainAxis.valueToJava2D(eq(10.0), any(Rectangle2D.class), any())).thenReturn(100.0);
// // 
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         when(rangeAxis.valueToJava2D(eq(20.0), any(Rectangle2D.class), any())).thenReturn(200.0);
// // 
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double();
// //         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// //         CrosshairState crosshairState = mock(CrosshairState.class);
// // 
// //         Paint itemPaint = mock(Paint.class);
// //         Field itemPaintField = StackedXYAreaRenderer.class.getDeclaredField("shapePaint");
// //         itemPaintField.setAccessible(true);
// //         itemPaintField.set(renderer, itemPaint);
// // 
// //         Method initialiseMethod = StackedXYAreaRenderer.class.getMethod("initialise", Graphics2D.class, Rectangle2D.class, XYPlot.class, XYDataset.class, PlotRenderingInfo.class);
// //         StackedXYAreaRendererState state = (StackedXYAreaRendererState) initialiseMethod.invoke(renderer, g2, dataArea, plot, dataset, info);
// // 
// //         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
// // 
// //         verify(g2).setPaint(itemPaint);
// //     }
// // 
// //     @Test
// //     @DisplayName("TC09: drawItem with series index greater than 0 handles lastSeriesPoints correctly")
// //     void TC09() throws Exception {
// //         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
// //         renderer.setUseFillPaint(true);
// // 
// //         XYDataset dataset = mock(XYDataset.class);
// //         when(dataset.getXValue(1, 5)).thenReturn(15.0);
// //         when(dataset.getYValue(1, 5)).thenReturn(25.0);
// // 
// //         PlotOrientation orientation = PlotOrientation.VERTICAL;
// // 
// //         XYPlot plot = mock(XYPlot.class);
// //         when(plot.getOrientation()).thenReturn(orientation);
// // 
// //         ValueAxis domainAxis = mock(ValueAxis.class);
// //         when(domainAxis.valueToJava2D(eq(15.0), any(Rectangle2D.class), any())).thenReturn(150.0);
// // 
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         when(rangeAxis.valueToJava2D(eq(25.0), any(Rectangle2D.class), any())).thenReturn(250.0);
// // 
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double();
// //         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// //         CrosshairState crosshairState = mock(CrosshairState.class);
// // 
// //         Method initialiseMethod = StackedXYAreaRenderer.class.getMethod("initialise", Graphics2D.class, Rectangle2D.class, XYPlot.class, XYDataset.class, PlotRenderingInfo.class);
// //         StackedXYAreaRendererState state = (StackedXYAreaRendererState) initialiseMethod.invoke(renderer, g2, dataArea, plot, dataset, info);
// // 
// //         Field lastSeriesPointsField = StackedXYAreaRendererState.class.getDeclaredField("lastSeriesPoints");
// //         lastSeriesPointsField.setAccessible(true);
// //         Stack<Point> lastSeriesPoints = new Stack<>();
// //         lastSeriesPoints.push(new Point(100, 200));
// //         lastSeriesPointsField.set(state, lastSeriesPoints);
// // 
// //         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 5, crosshairState, 0);
// // 
// //         Field seriesAreaField = StackedXYAreaRendererState.class.getDeclaredField("seriesArea");
// //         seriesAreaField.setAccessible(true);
// //         Polygon seriesArea = (Polygon) seriesAreaField.get(state);
// // 
// //         assertNotNull(seriesArea, "Series area should not be null");
// //         assertTrue(seriesArea.npoints > 0, "Series area should contain points for multiple series handling");
// //     }
// // 
// //     @Test
// //     @DisplayName("TC10: drawItem with class cast exception when state is not StackedXYAreaRendererState")
// //     void TC10() throws Exception {
// //         StackedXYAreaRenderer renderer = new StackedXYAreaRenderer();
// // 
// //         XYDataset dataset = mock(XYDataset.class);
// //         XYPlot plot = mock(XYPlot.class);
// //         ValueAxis domainAxis = mock(ValueAxis.class);
// //         ValueAxis rangeAxis = mock(ValueAxis.class);
// //         Graphics2D g2 = mock(Graphics2D.class);
// //         Rectangle2D dataArea = new Rectangle2D.Double();
// //         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// //         CrosshairState crosshairState = mock(CrosshairState.class);
// // 
// //         Object invalidState = new Object();
// // 
// //         assertThrows(ClassCastException.class, () -> {
// //             renderer.drawItem(g2, invalidState, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// //         }, "Expected drawItem to throw ClassCastException when state is invalid");
// //     }
// // }
// }