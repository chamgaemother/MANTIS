package org.apache.commons.compress.harmony.pack200;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class BcBands_visitLdcInsn_0_2_Test {

    @Test
    @DisplayName("Visits CPClass constant with wide index when lastConstantHadWideIndex is true")
    void TC06() throws Exception {
        // Arrange
        CpBands cpBands = mock(CpBands.class);
        Segment segment = mock(Segment.class);
        BcBands bcBands = Mockito.spy(new BcBands(cpBands, segment, 0));
        CPClass cpClass = mock(CPClass.class);

        when(cpBands.getConstant(any())).thenReturn(cpClass);
        when(segment.lastConstantHadWideIndex()).thenReturn(true);

        int originalByteCodeOffset = getByteCodeOffset(bcBands);

        // Act
        bcBands.visitLdcInsn(cpClass);

        // Assert
        assertEquals(originalByteCodeOffset + 3, getByteCodeOffset(bcBands));
        List<Integer> bcCodes = getBcCodes(bcBands);
        assertTrue(bcCodes.contains(236));
        List<CPClass> bcClassRef = getBcClassRef(bcBands);
        assertTrue(bcClassRef.contains(cpClass));
        verify(bcBands).updateRenumbering();
    }

    @Test
    @DisplayName("Throws IllegalArgumentException when constant is null with wide index")
    void TC07() throws Exception {
        // Arrange
        CpBands cpBands = mock(CpBands.class);
        Segment segment = mock(Segment.class);
        BcBands bcBands = Mockito.spy(new BcBands(cpBands, segment, 0));

        when(cpBands.getConstant(any())).thenReturn(null);
        when(segment.lastConstantHadWideIndex()).thenReturn(true);

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            bcBands.visitLdcInsn(null);
        });
        assertEquals("Constant should not be null", exception.getMessage());
    }

    @Test
    @DisplayName("Visits CPInt constant without wide index when lastConstantHadWideIndex is false")
    void TC08() throws Exception {
        // Arrange
        CpBands cpBands = mock(CpBands.class);
        Segment segment = mock(Segment.class);
        BcBands bcBands = Mockito.spy(new BcBands(cpBands, segment, 0));
        CPInt cpInt = mock(CPInt.class);

        when(cpBands.getConstant(any())).thenReturn(cpInt);
        when(segment.lastConstantHadWideIndex()).thenReturn(false);

        int originalByteCodeOffset = getByteCodeOffset(bcBands);

        // Act
        bcBands.visitLdcInsn(cpInt);

        // Assert
        assertEquals(originalByteCodeOffset + 2, getByteCodeOffset(bcBands));
        List<Integer> bcCodes = getBcCodes(bcBands);
        assertTrue(bcCodes.contains(234));
        List<CPInt> bcIntRef = getBcIntRef(bcBands);
        assertTrue(bcIntRef.contains(cpInt));
        verify(bcBands).updateRenumbering();
    }

    @Test
    @DisplayName("Visits CPFloat constant without wide index when lastConstantHadWideIndex is false")
    void TC09() throws Exception {
        // Arrange
        CpBands cpBands = mock(CpBands.class);
        Segment segment = mock(Segment.class);
        BcBands bcBands = Mockito.spy(new BcBands(cpBands, segment, 0));
        CPFloat cpFloat = mock(CPFloat.class);

        when(cpBands.getConstant(any())).thenReturn(cpFloat);
        when(segment.lastConstantHadWideIndex()).thenReturn(false);

        int originalByteCodeOffset = getByteCodeOffset(bcBands);

        // Act
        bcBands.visitLdcInsn(cpFloat);

        // Assert
        assertEquals(originalByteCodeOffset + 2, getByteCodeOffset(bcBands));
        List<Integer> bcCodes = getBcCodes(bcBands);
        assertTrue(bcCodes.contains(235));
        List<CPFloat> bcFloatRef = getBcFloatRef(bcBands);
        assertTrue(bcFloatRef.contains(cpFloat));
        verify(bcBands).updateRenumbering();
    }

    @Test
    @DisplayName("Visits CPString constant without wide index when lastConstantHadWideIndex is false")
    void TC10() throws Exception {
        // Arrange
        CpBands cpBands = mock(CpBands.class);
        Segment segment = mock(Segment.class);
        BcBands bcBands = Mockito.spy(new BcBands(cpBands, segment, 0));
        CPString cpString = mock(CPString.class);

        when(cpBands.getConstant(any())).thenReturn(cpString);
        when(segment.lastConstantHadWideIndex()).thenReturn(false);

        int originalByteCodeOffset = getByteCodeOffset(bcBands);

        // Act
        bcBands.visitLdcInsn(cpString);

        // Assert
        assertEquals(originalByteCodeOffset + 2, getByteCodeOffset(bcBands));
        List<Integer> bcCodes = getBcCodes(bcBands);
        assertTrue(bcCodes.contains(18));
        List<CPString> bcStringRef = getBcStringRef(bcBands);
        assertTrue(bcStringRef.contains(cpString));
        verify(bcBands).updateRenumbering();
    }

    // Helper methods to access private fields via reflection
    private int getByteCodeOffset(BcBands bcBands) throws Exception {
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        return byteCodeOffsetField.getInt(bcBands);
    }

    @SuppressWarnings("unchecked")
    private List<Integer> getBcCodes(BcBands bcBands) throws Exception {
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        // Convert int[] to List<Integer>
        return Arrays.stream(bcCodes.toArray()).boxed().collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    private List<CPClass> getBcClassRef(BcBands bcBands) throws Exception {
        Field bcClassRefField = BcBands.class.getDeclaredField("bcClassRef");
        bcClassRefField.setAccessible(true);
        return (List<CPClass>) bcClassRefField.get(bcBands);
    }

    @SuppressWarnings("unchecked")
    private List<CPInt> getBcIntRef(BcBands bcBands) throws Exception {
        Field bcIntRefField = BcBands.class.getDeclaredField("bcIntref");
        bcIntRefField.setAccessible(true);
        return (List<CPInt>) bcIntRefField.get(bcBands);
    }

    @SuppressWarnings("unchecked")
    private List<CPFloat> getBcFloatRef(BcBands bcBands) throws Exception {
        Field bcFloatRefField = BcBands.class.getDeclaredField("bcFloatRef");
        bcFloatRefField.setAccessible(true);
        return (List<CPFloat>) bcFloatRefField.get(bcBands);
    }

    @SuppressWarnings("unchecked")
    private List<CPString> getBcStringRef(BcBands bcBands) throws Exception {
        Field bcStringRefField = BcBands.class.getDeclaredField("bcStringRef");
        bcStringRefField.setAccessible(true);
        return (List<CPString>) bcStringRefField.get(bcBands);
    }
}