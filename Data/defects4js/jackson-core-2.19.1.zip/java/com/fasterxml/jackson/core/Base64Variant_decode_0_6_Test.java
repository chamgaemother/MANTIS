package com.fasterxml.jackson.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import java.util.Arrays;

public class Base64Variant_decode_0_6_Test {

    @Test
    @DisplayName("decode with hidden control characters in input throws IllegalArgumentException")
    void TC26() {
        // GIVEN
        String str = "TW\u0000Vu";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN & THEN
        Base64Variant variant = Base64Variants.MIME;
        assertThrows(IllegalArgumentException.class, () -> variant.decode(str, builder));
    }

    @Test
    @DisplayName("decode with mixed padding and non-padding characters appends correctly")
    void TC27() {
        // GIVEN
        String str = "TWFuTWE=";
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN
        Base64Variant variant = Base64Variants.MIME;
        variant.decode(str, builder);

        // THEN
        byte[] expected = "ManMa".getBytes();
        assertArrayEquals(expected, builder.toByteArray());
    }

//     @Test
//     @DisplayName("decode with builder already containing data appends new decoded bytes")
//     void TC28() {
        // GIVEN
//         String str = "TWFu";
//         ByteArrayBuilder builder = new ByteArrayBuilder();
//         builder.append(new byte[]{100, 101, 102}); // "def"
// 
        // WHEN
//         Base64Variant variant = Base64Variants.MIME;
//         variant.decode(str, builder);
// 
        // THEN
//         byte[] expected = "defMan".getBytes();
//         assertArrayEquals(expected, builder.toByteArray());
//     }

//     @Test
//     @DisplayName("decode with builder reached maximum capacity appends bytes until capacity")
//     void TC29() {
        // GIVEN
//         String str = "TWFu";
//         int maxCapacity = 10;
//         ByteArrayBuilder builder = new ByteArrayBuilder(maxCapacity);
//         builder.append(new byte[maxCapacity - 3]); // prepopulate to maxCapacity -3
// 
        // WHEN
//         Base64Variant variant = Base64Variants.MIME;
//         variant.decode(str, builder);
// 
        // THEN
//         assertEquals(maxCapacity, builder.toByteArray().length);
//     }

    @Test
    @DisplayName("decode with null input string throws NullPointerException")
    void TC30() {
        // GIVEN
        String str = null;
        ByteArrayBuilder builder = new ByteArrayBuilder();

        // WHEN & THEN
        Base64Variant variant = Base64Variants.MIME;
        assertThrows(NullPointerException.class, () -> variant.decode(str, builder));
    }
}