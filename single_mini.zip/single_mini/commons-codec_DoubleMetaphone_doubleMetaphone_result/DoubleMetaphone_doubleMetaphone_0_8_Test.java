package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_8_Test {

    @Test
    @DisplayName("doubleMetaphone handles 'EWSKI' suffix in 'KEVIEWSKI'")
    public void TC36() throws Exception {
        // GIVEN
        String value = "KEVIEWSKI";
        
        // WHEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, true);
        
        // THEN
        assertTrue(result.endsWith("F"), "Encoded suffix should end with 'F'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'SCH' at beginning in 'SCHMIDT'")
    public void TC37() throws Exception {
        // GIVEN
        String value = "SCHMIDT";
        
        // WHEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("SK") || result.contains("X"), "Encoded 'SCH' should be as 'SK' or 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'X' not at beginning in 'BOX'")
    public void TC38() throws Exception {
        // GIVEN
        String value = "BOX";
        
        // WHEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("KS"), "Encoded 'X' should be as 'KS'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'Z' followed by 'O' in 'ZOPA'")
    public void TC39() throws Exception {
        // GIVEN
        String value = "ZOPA";
        
        // WHEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("TS"), "Encoded 'Z' followed by 'O' should be as 'TS'");
    }

    @Test
    @DisplayName("doubleMetaphone handles multiple iterations with 'ABABABA'")
    public void TC40() throws Exception {
        // GIVEN
        String value = "ABABABA";
        
        // WHEN
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.length() <= 4, "Encoded string should have length <= 4");
    }
}