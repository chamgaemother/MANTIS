// package org.jfree.chart.renderer.xy;
// 
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyDouble;
// import static org.mockito.Mockito.mock;
// import static org.mockito.Mockito.never;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;
// 
// import java.awt.Color;
// import java.awt.Graphics2D;
// import java.awt.geom.Rectangle2D;
// import java.awt.geom.Line2D;
// 
// import org.jfree.chart.axis.ValueAxis;
// import org.jfree.chart.entity.EntityCollection;
// import org.jfree.chart.plot.CrosshairState;
// import org.jfree.chart.plot.PlotOrientation;
// import org.jfree.chart.plot.PlotRenderingInfo;
// import org.jfree.chart.plot.XYPlot;
// import org.jfree.chart.renderer.xy.XYItemRendererState;
// import org.jfree.chart.util.SerialUtils;
// import org.jfree.data.Range;
// import org.jfree.data.xy.OHLCDataset;
// import org.jfree.data.xy.XYDataset;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mockito;
// 
// public class HighLowRenderer_drawItem_2_1_Test {
//     
//     @Test
//     @DisplayName("drawCloseTicks is enabled but yClose is NaN, ensuring close ticks are not drawn")
//     public void TC21_drawCloseTicksEnabledWithNaNyClose() {
//         // GIVEN
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawCloseTicks(true);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(15.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(25.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(15.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(Double.NaN);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(150.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // WHEN
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// 
//         // THEN
//         verify(g2, never()).draw(any(Line2D.class));
//         verify(g2, never()).setPaint(any());
//     }
// 
//     @Test
//     @DisplayName("drawCloseTicks is enabled and yClose is valid, ensuring close ticks are drawn")
//     public void TC22_drawCloseTicksEnabledWithValidyClose() {
//         // GIVEN
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawCloseTicks(true);
//         renderer.setCloseTickPaint(Color.BLUE);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(15.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(25.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(15.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(22.0);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(22.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(220.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // WHEN
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// 
//         // THEN
//         verify(g2).setPaint(Color.BLUE);
//         verify(g2).draw(any(Line2D.class));
//     }
// 
//     @Test
//     @DisplayName("Both drawOpenTicks and drawCloseTicks are enabled, yOpen is NaN and yClose is valid")
//     public void TC23_bothDrawOpenAndCloseTicksEnabled_yOpenNaNyCloseValid() {
//         // GIVEN
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawOpenTicks(true);
//         renderer.setDrawCloseTicks(true);
//         renderer.setCloseTickPaint(Color.BLUE);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(15.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(25.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(15.0);
//         when(dataset.getOpenValue(0, 0)).thenReturn(Double.NaN);
//         when(dataset.getCloseValue(0, 0)).thenReturn(22.0);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(22.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(220.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // WHEN
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// 
//         // THEN
//         verify(g2, never()).setPaint(Mockito.eq(Color.RED)); // Open tick paint should not be set
//         verify(g2).setPaint(Color.BLUE); // Close tick paint is set
//         verify(g2).draw(any(Line2D.class)); // Only close tick is drawn
//     }
// 
//     @Test
//     @DisplayName("Both drawOpenTicks and drawCloseTicks are enabled with both yOpen and yClose valid")
//     public void TC24_bothDrawOpenAndCloseTicksEnabled_yOpenAndyCloseValid() {
//         // GIVEN
//         HighLowRenderer renderer = new HighLowRenderer();
//         renderer.setDrawOpenTicks(true);
//         renderer.setDrawCloseTicks(true);
//         renderer.setOpenTickPaint(Color.RED);
//         renderer.setCloseTickPaint(Color.BLUE);
// 
//         OHLCDataset dataset = mock(OHLCDataset.class);
//         when(dataset.getXValue(0, 0)).thenReturn(15.0);
//         when(dataset.getHighValue(0, 0)).thenReturn(25.0);
//         when(dataset.getLowValue(0, 0)).thenReturn(15.0);
//         when(dataset.getOpenValue(0, 0)).thenReturn(18.0);
//         when(dataset.getCloseValue(0, 0)).thenReturn(22.0);
// 
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         when(domainAxis.getRange()).thenReturn(new Range(10, 20));
// 
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         when(rangeAxis.valueToJava2D(18.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(180.0);
//         when(rangeAxis.valueToJava2D(22.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT)).thenReturn(220.0);
// 
//         Graphics2D g2 = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
// 
//         XYPlot plot = mock(XYPlot.class);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
// 
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         // WHEN
//         renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
// 
//         // THEN
//         verify(g2).setPaint(Color.RED);
//         verify(g2).draw(any(Line2D.class)); // Open tick drawn
//         verify(g2).setPaint(Color.BLUE);
//         verify(g2).draw(any(Line2D.class)); // Close tick drawn
//     }
// }