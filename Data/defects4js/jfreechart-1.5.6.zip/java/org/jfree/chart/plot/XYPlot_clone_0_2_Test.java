package org.jfree.chart.plot;

import java.util.*;
import org.jfree.chart.axis.ValueAxis;
import java.lang.reflect.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.axis.NumberAxis;


public class XYPlot_clone_0_2_Test {

    @Test
    @DisplayName("Cloning with multiple subplots and domainAxis is not null")
    public void test_TC06_cloneWithMultipleSubplotsAndDomainAxisNotNull() throws CloneNotSupportedException {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        
        Plot subplot1 = new XYPlot();
        Plot subplot2 = new XYPlot();
        Plot subplot3 = new XYPlot();
        List<Plot> subplots = Arrays.asList(subplot1, subplot2, subplot3);

        // Use reflection to access and set the private 'subplots' field
        Class<?> clazz = CombinedDomainXYPlot.class;
        try {
            Field field = clazz.getDeclaredField("subplots");
            field.setAccessible(true);
            field.set(plot, subplots);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection failed");
        }
        
        TestValueAxis axis = new TestValueAxis();
        plot.setDomainAxis(axis);
        
        // WHEN
        CombinedDomainXYPlot clonedPlot = (CombinedDomainXYPlot) plot.clone();
        
        // THEN
        assertNotSame(clonedPlot, plot, "Cloned plot should not be the same instance as the original");
        assertEquals(3, clonedPlot.getSubplots().size(), "Cloned plot should have three subplots");
        for (int i = 0; i < 3; i++) {
            Plot clonedSubplot = clonedPlot.getSubplots().get(i);
            assertNotSame(clonedSubplot, plot.getSubplots().get(i), "Cloned subplot should not be the same instance");
            assertEquals(clonedPlot, clonedSubplot.getParent(), "Cloned subplot's parent should be the cloned plot");
        }
        assertNotNull(clonedPlot.getDomainAxis(), "Cloned plot's domainAxis should not be null");
        
        assertTrue(((TestValueAxis) clonedPlot.getDomainAxis()).isConfigured(), "DomainAxis.configure() should have been called");
    }

    @Test
    @DisplayName("Cloning when super.clone() throws CloneNotSupportedException")
    public void test_TC07_cloneWhenSuperCloneThrowsCloneNotSupportedException() {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot() {
            @Override
            public Object clone() throws CloneNotSupportedException {
                throw new CloneNotSupportedException();
            }
        };
        
        // WHEN & THEN
        assertThrows(CloneNotSupportedException.class, () -> {
            plot.clone();
        });
    }

//     @Test
//     @DisplayName("Cloning when ObjectUtils.deepClone() throws CloneNotSupportedException")
//     public void test_TC08_cloneWhenObjectUtilsDeepCloneThrowsCloneNotSupportedException() {
        // GIVEN
//         CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
//         List<Plot> subplots = Arrays.asList(new Plot() {
//             @Override
//             public Object clone() throws CloneNotSupportedException {
//                 throw new CloneNotSupportedException();
//             }
//         });
// 
        // Use reflection to access and set the private 'subplots' field
//         Class<?> clazz = CombinedDomainXYPlot.class;
//         try {
//             Field field = clazz.getDeclaredField("subplots");
//             field.setAccessible(true);
//             field.set(plot, subplots);
//         } catch (NoSuchFieldException | IllegalAccessException e) {
//             fail("Reflection failed");
//         }
//         
        // WHEN & THEN
//         assertThrows(CloneNotSupportedException.class, () -> {
//             plot.clone();
//         });
//     }

    @Test
    @DisplayName("Cloning when setParent() throws RuntimeException")
    public void test_TC09_cloneWhenSetParentThrowsRuntimeException() {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        Plot faultySubplot = new XYPlot() {
            @Override
            public void setParent(Plot parent) {
                throw new RuntimeException("Failed to set parent");
            }
        };

        // Use reflection to access and set the private 'subplots' field
        Class<?> clazz = CombinedDomainXYPlot.class;
        try {
            Field field = clazz.getDeclaredField("subplots");
            field.setAccessible(true);
            field.set(plot, Arrays.asList(faultySubplot));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection failed");
        }
        
        // WHEN & THEN
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            plot.clone();
        });
        assertEquals("Failed to set parent", exception.getMessage());
    }

    @Test
    @DisplayName("Cloning when domainAxis.configure() throws RuntimeException")
    public void test_TC10_cloneWhenDomainAxisConfigureThrowsRuntimeException() {
        // GIVEN
        CombinedDomainXYPlot plot = new CombinedDomainXYPlot();
        ValueAxis faultyAxis = new TestValueAxis() {
            @Override
            public void configure() {
                throw new RuntimeException("Failed to configure axis");
            }
        };
        plot.setDomainAxis(faultyAxis);

        // Use reflection to access and set the private 'subplots' field
        Class<?> clazz = CombinedDomainXYPlot.class;
        try {
            Field field = clazz.getDeclaredField("subplots");
            field.setAccessible(true);
            field.set(plot, Arrays.asList());
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection failed");
        }
        
        // WHEN & THEN
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            plot.clone();
        });
        assertEquals("Failed to configure axis", exception.getMessage());
    }
    
    // Helper class to track configure() calls
    private static class TestValueAxis extends NumberAxis {
        private boolean configured = false;
        
        @Override
        public void configure() {
            configured = true;
            super.configure();
        }
        
        public boolean isConfigured() {
            return configured;
        }
    }
}