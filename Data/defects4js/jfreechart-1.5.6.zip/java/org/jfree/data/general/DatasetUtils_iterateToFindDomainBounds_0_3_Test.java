
package org.jfree.data.general;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DatasetUtils_iterateToFindDomainBounds_0_3_Test {

    @Test
    @DisplayName("Returns null when includeInterval is true and all x, l, u values are NaN")
    public void TC11() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Comparable seriesKey = "Series1";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey);
        when(dataset.indexOf(seriesKey)).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getStartXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getEndXValue(0, 0)).thenReturn(Double.NaN);
        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertNull(result);
    }

    @Test
    @DisplayName("Handles multiple iterations with includeInterval true and multiple series")
    public void TC12() {
        // GIVEN
        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
        Comparable seriesKey1 = "Series1";
        Comparable seriesKey2 = "Series2";
        List<Comparable> visibleSeriesKeys = Arrays.asList(seriesKey1, seriesKey2);

        // Series 1
        when(dataset.indexOf(seriesKey1)).thenReturn(0);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(dataset.getStartXValue(0, 0)).thenReturn(8.0);
        when(dataset.getEndXValue(0, 0)).thenReturn(12.0);
        when(dataset.getXValue(0, 1)).thenReturn(20.0);
        when(dataset.getStartXValue(0, 1)).thenReturn(18.0);
        when(dataset.getEndXValue(0, 1)).thenReturn(22.0);

        // Series 2
        when(dataset.indexOf(seriesKey2)).thenReturn(1);
        when(dataset.getItemCount(1)).thenReturn(2);
        when(dataset.getXValue(1, 0)).thenReturn(5.0);
        when(dataset.getStartXValue(1, 0)).thenReturn(3.0);
        when(dataset.getEndXValue(1, 0)).thenReturn(7.0);
        when(dataset.getXValue(1, 1)).thenReturn(25.0);
        when(dataset.getStartXValue(1, 1)).thenReturn(23.0);
        when(dataset.getEndXValue(1, 1)).thenReturn(27.0);

        boolean includeInterval = true;

        // WHEN
        Range result = DatasetUtils.iterateToFindDomainBounds(dataset, visibleSeriesKeys, includeInterval);

        // THEN
        assertEquals(new Range(3.0, 27.0), result);
    }
}