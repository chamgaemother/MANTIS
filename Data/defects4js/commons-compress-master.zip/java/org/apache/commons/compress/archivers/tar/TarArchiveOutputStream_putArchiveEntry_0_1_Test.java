package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class TarArchiveOutputStream_putArchiveEntry_0_1_Test {

//     @Test
//     @DisplayName("putArchiveEntry with a global PAX header and bigNumberMode set to BIGNUMBER_STAR")
//     void TC01_putArchiveEntry_GlobalPAXHeader_BignumberStar() throws Exception {
        // GIVEN
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         TarArchiveEntry entry = new TarArchiveEntry("dummy");
//         entry.setGlobalPaxHeader(true);
// 
        // Using reflection to set bigNumberMode to BIGNUMBER_STAR (assuming it's an integer constant)
//         Field bigNumberModeField = TarArchiveOutputStream.class.getDeclaredField("bigNumberMode");
//         bigNumberModeField.setAccessible(true);
//         bigNumberModeField.setInt(outputStream, TarArchiveOutputStream.BIGNUMBER_STAR); // Correct constant assignment
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
        // Verify that haveUnclosedEntry is true
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(outputStream);
//         assertTrue(haveUnclosedEntry, "haveUnclosedEntry should be true after putting an archive entry.");
// 
        // Verify that bigNumberMode is set to BIGNUMBER_STAR
//         int bigNumberMode = bigNumberModeField.getInt(outputStream);
//         assertEquals(TarArchiveOutputStream.BIGNUMBER_STAR, bigNumberMode, "bigNumberMode should be set to BIGNUMBER_STAR.");
//     }

//     @Test
//     @DisplayName("putArchiveEntry with a global PAX header and bigNumberMode not equal to BIGNUMBER_STAR")
//     void TC02_putArchiveEntry_GlobalPAXHeader_BignumberNonStar() throws Exception {
        // GIVEN
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         TarArchiveEntry entry = new TarArchiveEntry("dummy");
//         entry.setGlobalPaxHeader(true);
// 
        // Using reflection to set bigNumberMode to a value other than BIGNUMBER_STAR
//         Field bigNumberModeField = TarArchiveOutputStream.class.getDeclaredField("bigNumberMode");
//         bigNumberModeField.setAccessible(true);
//         bigNumberModeField.setInt(outputStream, TarArchiveOutputStream.BIGNUMBER_POSIX); // Use valid constant
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
        // Verify that haveUnclosedEntry is true
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(outputStream);
//         assertTrue(haveUnclosedEntry, "haveUnclosedEntry should be true after putting an archive entry.");
// 
        // Verify that bigNumberMode is not set to BIGNUMBER_STAR
//         int bigNumberMode = bigNumberModeField.getInt(outputStream);
//         assertNotEquals(TarArchiveOutputStream.BIGNUMBER_STAR, bigNumberMode, "bigNumberMode should not be set to BIGNUMBER_STAR.");
//     }

//     @Test
//     @DisplayName("putArchiveEntry with non-global PAX header and handleLongName for path returns true")
//     void TC03_putArchiveEntry_NonGlobalPAXHeader_HandleLongNamePathTrue() throws Exception {
        // GIVEN
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         TarArchiveEntry entry = new TarArchiveEntry("long_filename_exceeding_limit");
//         entry.setGlobalPaxHeader(false);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
        // Verify that current name is set correctly
//         Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
//         currNameField.setAccessible(true);
//         String currName = (String) currNameField.get(outputStream);
//         assertEquals("long_filename_exceeding_limit", currName, "Current name should be set correctly.");
// 
        // Additionally, verify that haveUnclosedEntry is true
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(outputStream);
//         assertTrue(haveUnclosedEntry, "haveUnclosedEntry should be true after putting an archive entry.");
//     }

//     @Test
//     @DisplayName("putArchiveEntry with non-global PAX header and handleLongName for path returns false")
//     void TC04_putArchiveEntry_NonGlobalPAXHeader_HandleLongNamePathFalse() throws Exception {
        // GIVEN
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         TarArchiveEntry entry = new TarArchiveEntry("short_filename");
//         entry.setGlobalPaxHeader(false);
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
        // Verify that current name is set correctly without PAX headers
//         Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
//         currNameField.setAccessible(true);
//         String currName = (String) currNameField.get(outputStream);
//         assertEquals("short_filename", currName, "Current name should be set correctly without PAX headers.");
// 
        // Additionally, verify that haveUnclosedEntry is true
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(outputStream);
//         assertTrue(haveUnclosedEntry, "haveUnclosedEntry should be true after putting an archive entry.");
//     }

//     @Test
//     @DisplayName("putArchiveEntry with non-global PAX header and handleLongName for link returns true")
//     void TC05_putArchiveEntry_NonGlobalPAXHeader_HandleLongNameLinkTrue() throws Exception {
        // GIVEN
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream outputStream = new TarArchiveOutputStream(baos);
//         TarArchiveEntry entry = new TarArchiveEntry("dummy");
//         entry.setGlobalPaxHeader(false);
//         entry.setLinkName("long_linkname_exceeding_limit");
// 
        // WHEN
//         outputStream.putArchiveEntry(entry);
// 
        // THEN
        // Verify that current name is set correctly
//         Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
//         currNameField.setAccessible(true);
//         String currName = (String) currNameField.get(outputStream);
//         assertEquals("dummy", currName, "Current name should be set correctly.");
// 
        // Additionally, verify that haveUnclosedEntry is true
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(outputStream);
//         assertTrue(haveUnclosedEntry, "haveUnclosedEntry should be true after putting an archive entry.");
//     }
}