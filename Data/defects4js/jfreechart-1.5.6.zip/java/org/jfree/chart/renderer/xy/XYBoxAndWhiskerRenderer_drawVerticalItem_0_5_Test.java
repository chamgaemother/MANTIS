package org.jfree.chart.renderer.xy;

import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.ArrayList;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class XYBoxAndWhiskerRenderer_drawVerticalItem_0_5_Test {

    @Test
    @DisplayName("drawVerticalItem with multiple outlier iterations")
    public void TC21() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset.getOutliers(series, item)).thenReturn(
                Arrays.asList(15.0, 20.0, 25.0, -10.0, -15.0)
        );
        when(dataset.getX(series, item)).thenReturn(10);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25);
        when(dataset.getMinRegularValue(series, item)).thenReturn(-15);
        when(dataset.getMedianValue(series, item)).thenReturn(5);
        when(dataset.getMeanValue(series, item)).thenReturn(7);
        when(dataset.getQ1Value(series, item)).thenReturn(3);
        when(dataset.getQ3Value(series, item)).thenReturn(8);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(dataset, times(1)).getOutliers(series, item);
    }

    @Test
    @DisplayName("drawVerticalItem with zero outlier iterations")
    public void TC22() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset.getOutliers(series, item)).thenReturn(
                new ArrayList<>()
        );
        when(dataset.getX(series, item)).thenReturn(10);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25);
        when(dataset.getMinRegularValue(series, item)).thenReturn(-15);
        when(dataset.getMedianValue(series, item)).thenReturn(5);
        when(dataset.getMeanValue(series, item)).thenReturn(7);
        when(dataset.getQ1Value(series, item)).thenReturn(3);
        when(dataset.getQ3Value(series, item)).thenReturn(8);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(dataset, times(1)).getOutliers(series, item);
    }

    @Test
    @DisplayName("drawVerticalItem with one outlier iteration")
    public void TC23() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset.getOutliers(series, item)).thenReturn(
                Arrays.asList(15.0)
        );
        when(dataset.getX(series, item)).thenReturn(10);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25);
        when(dataset.getMinRegularValue(series, item)).thenReturn(-15);
        when(dataset.getMedianValue(series, item)).thenReturn(5);
        when(dataset.getMeanValue(series, item)).thenReturn(7);
        when(dataset.getQ1Value(series, item)).thenReturn(3);
        when(dataset.getQ3Value(series, item)).thenReturn(8);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(dataset, times(1)).getOutliers(series, item);
    }

    @Test
    @DisplayName("drawVerticalItem with multiple far out flags set")
    public void TC24() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset.getOutliers(series, item)).thenReturn(
                Arrays.asList(30.0, -10.0)
        );
        when(dataset.getMaxOutlier(series, item)).thenReturn(25.0);
        when(dataset.getMinOutlier(series, item)).thenReturn(-5.0);
        when(dataset.getX(series, item)).thenReturn(10);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25);
        when(dataset.getMinRegularValue(series, item)).thenReturn(-15);
        when(dataset.getMedianValue(series, item)).thenReturn(5);
        when(dataset.getMeanValue(series, item)).thenReturn(7);
        when(dataset.getQ1Value(series, item)).thenReturn(3);
        when(dataset.getQ3Value(series, item)).thenReturn(8);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(dataset, times(1)).getOutliers(series, item);
    }

    @Test
    @DisplayName("drawVerticalItem with multiple ellipse drawing paths")
    public void TC25() throws Exception {
        // Arrange
        XYBoxAndWhiskerRenderer renderer = new XYBoxAndWhiskerRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        BoxAndWhiskerXYDataset dataset = mock(BoxAndWhiskerXYDataset.class);
        int series = 0;
        int item = 0;
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(dataset.getOutliers(series, item)).thenReturn(
                Arrays.asList(15.0, 20.0, 25.0)
        );
        when(dataset.getX(series, item)).thenReturn(10);
        when(dataset.getMaxRegularValue(series, item)).thenReturn(25);
        when(dataset.getMinRegularValue(series, item)).thenReturn(-15);
        when(dataset.getMedianValue(series, item)).thenReturn(5);
        when(dataset.getMeanValue(series, item)).thenReturn(7);
        when(dataset.getQ1Value(series, item)).thenReturn(3);
        when(dataset.getQ3Value(series, item)).thenReturn(8);

        // Act
        renderer.drawVerticalItem(g2, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);

        // Assert
        verify(dataset, times(1)).getOutliers(series, item);
    }

}