import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Flat3MapTest {

    private Flat3Map<String, String> map;

    @BeforeEach
    public void setUp() {
        map = new Flat3Map<>();
    }

    @Test
    public void testPutWhenEmptyMap() {
        assertNull(map.put("key1", "value1"));
        assertEquals("value1", map.get("key1"));
        assertEquals(1, map.size());
    }

    @Test
    public void testPutWhenUpdatingExistingKey() {
        map.put("key1", "value1");
        assertEquals("value1", map.put("key1", "value2"));
        assertEquals("value2", map.get("key1"));
    }

    @Test
    public void testPutWhenNullKey() {
        assertNull(map.put(null, "value1"));
        assertEquals("value1", map.get(null));
        assertEquals(1, map.size());
    }

    @Test
    public void testPutWhenMapReachesCapacityAndSwitchesToDelegate() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        assertNull(map.put("key4", "value4"));
        assertEquals("value4", map.get("key4"));
        assertEquals(4, map.size());
    }

    @Test
    public void testPutWhenReplacingNullKey() {
        map.put(null, "value1");
        assertEquals("value1", map.put(null, "value2"));
        assertEquals("value2", map.get(null));
    }

    @Test
    public void testPutWhenCapacityNotExceeded() {
        map.put("key1", "value1");
        map.put("key2", "value2");
        assertNull(map.put("key3", "value3"));
        assertEquals("value3", map.get("key3"));
        assertEquals(3, map.size());
    }

    @Test
    public void testPutWithNullValue() {
        map.put("key1", null);
        assertNull(map.get("key1"));
        map.put("key1", "value1");
        assertEquals("value1", map.get("key1"));
    }

    @Test
    public void testPutWhenUpdatingNullKeyWithNonNullValue() {
        map.put(null, null);
        assertNull(map.put(null, "value"));
        assertEquals("value", map.get(null));
    }
}