package com.google.gson.internal.bind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.TimeZone;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class ISO8601Utils_parse_1_2_Test {

    @Test
    @DisplayName("parse date with multiple 'T' characters leading to invalid format")
    public void TC31() {
        String date = "2023-10-05TT14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        ParseException exception = assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertEquals(11, pos.getErrorIndex(), "ParsePosition error index should be set at error position");
    }

    @Test
    @DisplayName("parse date with two-digit timezone offset without minutes (e.g., '+02')")
    public void TC32() {
        String date = "2023-10-05T14:30:00+02";
        ParsePosition pos = new ParsePosition(0);
        try {
            Date result = ISO8601Utils.parse(date, pos);
            assertNotNull(result, "Parsed date should not be null");
            // Construct expected Date in UTC
            Calendar expectedCal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
            expectedCal.set(Calendar.YEAR, 2023);
            expectedCal.set(Calendar.MONTH, Calendar.OCTOBER); // Months are 0-based
            expectedCal.set(Calendar.DAY_OF_MONTH, 5);
            expectedCal.set(Calendar.HOUR_OF_DAY, 12);
            expectedCal.set(Calendar.MINUTE, 30);
            expectedCal.set(Calendar.SECOND, 0);
            expectedCal.set(Calendar.MILLISECOND, 0);
            Date expectedDate = expectedCal.getTime();
            assertEquals(expectedDate, result, "Parsed date should match expected UTC time");
            assertEquals(date.length(), pos.getIndex(), "ParsePosition index should be at the end of the date string");
        } catch (ParseException e) {
            fail("ParseException was thrown: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("parse date with incomplete timezone information")
    public void TC33() {
        String date = "2023-10-05T14:30:00+02:";
        ParsePosition pos = new ParsePosition(0);
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
        assertEquals(date.length(), pos.getIndex(), "ParsePosition index should remain at the end of the date string");
    }
}