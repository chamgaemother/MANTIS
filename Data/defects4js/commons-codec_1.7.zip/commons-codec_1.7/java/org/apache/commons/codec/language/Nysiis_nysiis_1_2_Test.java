package org.apache.commons.codec.language;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.codec.language.Nysiis;

public class Nysiis_nysiis_1_2_Test {

    @Test
    @DisplayName("nysiis(\"SWAN\") retains W when not following a vowel")
    public void TC28() {
        Nysiis encoder = new Nysiis();
        String input = "SWAN";
        String result = encoder.nysiis(input);
        assertTrue(result.contains("W"), "W should be retained when not following a vowel");
    }

    @Test
    @DisplayName("nysiis(\"AEIOU\") replaces all vowels with 'A'")
    public void TC29() {
        Nysiis encoder = new Nysiis();
        String input = "AEIOU";
        String result = encoder.nysiis(input);
        assertEquals("AAAAA", result, "All vowels should be replaced with 'A'");
    }

    @Test
    @DisplayName("nysiis(\"EAIO\") replaces all vowels with 'A'")
    public void TC30() {
        Nysiis encoder = new Nysiis();
        String input = "EAIO";
        String result = encoder.nysiis(input);
        assertEquals("AAAA", result, "All vowels should be replaced with 'A'");
    }

}