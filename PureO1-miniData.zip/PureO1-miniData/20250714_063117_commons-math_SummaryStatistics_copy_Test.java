package org.apache.commons.math3.stat.descriptive;

import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math3.stat.descriptive.moment.Variance;
import org.apache.commons.math3.stat.descriptive.rank.Max;
import org.apache.commons.math3.stat.descriptive.rank.Min;
import org.apache.commons.math3.stat.descriptive.summary.Sum;
import org.apache.commons.math3.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math3.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math3.util.MathUtils;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SummaryStatisticsTest {

    @Test
    void testCopy_NullSource_ThrowsException() {
        SummaryStatistics dest = new SummaryStatistics();
        assertThrows(NullArgumentException.class, () -> {
            SummaryStatistics.copy(null, dest);
        });
    }
    
    @Test
    void testCopy_NullDest_ThrowsException() {
        SummaryStatistics source = new SummaryStatistics();
        assertThrows(NullArgumentException.class, () -> {
            SummaryStatistics.copy(source, null);
        });
    }

    @Test
    void testCopy_BothNull_ThrowsException() {
        assertThrows(NullArgumentException.class, () -> {
            SummaryStatistics.copy(null, null);
        });
    }

    @Test
    void testCopy_DefaultImplementations() {
        SummaryStatistics source = new SummaryStatistics();
        source.addValue(1.0);
        source.addValue(2.0);
        source.addValue(3.0);
        
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        
        assertEquals(source.getN(), dest.getN(), "Number of entries should be equal");
        assertEquals(source.getSum(), dest.getSum(), "Sum should be equal");
        assertEquals(source.getMean(), dest.getMean(), "Mean should be equal");
        assertEquals(source.getVariance(), dest.getVariance(), "Variance should be equal");
        assertEquals(source.getMin(), dest.getMin(), "Min should be equal");
        assertEquals(source.getMax(), dest.getMax(), "Max should be equal");
        assertEquals(source.getSumOfLogs(), dest.getSumOfLogs(), "Sum of logs should be equal");
        assertEquals(source.getGeometricMean(), dest.getGeometricMean(), "Geometric mean should be equal");
        assertEquals(source.getSumsq(), dest.getSumsq(), "Sum of squares should be equal");
        assertEquals(source.getSecondMoment(), dest.getSecondMoment(), "Second moment should be equal");
        
        assertSame(source.getSumImpl().getClass(), dest.getSumImpl().getClass(), "Sum implementation should be the same");
        assertSame(source.getSumsqImpl().getClass(), dest.getSumsqImpl().getClass(), "SumSq implementation should be the same");
        assertSame(source.getMinImpl().getClass(), dest.getMinImpl().getClass(), "Min implementation should be the same");
        assertSame(source.getMaxImpl().getClass(), dest.getMaxImpl().getClass(), "Max implementation should be the same");
        assertSame(source.getSumLogImpl().getClass(), dest.getSumLogImpl().getClass(), "SumLog implementation should be the same");
        assertSame(source.getGeoMeanImpl().getClass(), dest.getGeoMeanImpl().getClass(), "GeometricMean implementation should be the same");
        assertSame(source.getMeanImpl().getClass(), dest.getMeanImpl().getClass(), "Mean implementation should be the same");
        assertSame(source.getVarianceImpl().getClass(), dest.getVarianceImpl().getClass(), "Variance implementation should be the same");
    }

    @Test
    void testCopy_CustomVarianceImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setVarianceImpl(new SecondMoment());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertTrue(dest.getVarianceImpl() instanceof SecondMoment, "VarianceImpl should be instance of SecondMoment");
    }
    
    @Test
    void testCopy_CustomMeanImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setMeanImpl(new Sum());
        SummaryStatistics.dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertTrue(dest.getMeanImpl() instanceof Sum, "MeanImpl should be instance of Sum");
    }
    
    @Test
    void testCopy_CustomGeoMeanImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setGeoMeanImpl(new SumOfLogs());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertTrue(dest.getGeoMeanImpl() instanceof SumOfLogs, "GeoMeanImpl should be instance of SumOfLogs");
    }
    
    @Test
    void testCopy_GeoMeanEqualsGeoMeanImpl() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertSame(dest.geoMean, dest.getGeoMeanImpl(), "geoMean should be the same as geoMeanImpl");
    }
    
    @Test
    void testCopy_GeoMeanNotEqualsGeoMeanImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setGeoMeanImpl(new SumOfLogs());
        source.addValue(1.0);
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertNotSame(dest.geoMean, dest.getGeoMeanImpl(), "geoMean should not be the same as geoMeanImpl");
    }
    
    @Test
    void testCopy_MaxEqualsMaxImpl() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertSame(dest.max, dest.getMaxImpl(), "max should be the same as maxImpl");
    }
    
    @Test
    void testCopy_MaxNotEqualsMaxImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setMaxImpl(new Sum());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertNotSame(dest.max, dest.getMaxImpl(), "max should not be the same as maxImpl");
    }
    
    @Test
    void testCopy_MinEqualsMinImpl() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertSame(dest.min, dest.getMinImpl(), "min should be the same as minImpl");
    }
    
    @Test
    void testCopy_MinNotEqualsMinImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setMinImpl(new Sum());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertNotSame(dest.min, dest.getMinImpl(), "min should not be the same as minImpl");
    }
    
    @Test
    void testCopy_SumEqualsSumImpl() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertSame(dest.sum, dest.getSumImpl(), "sum should be the same as sumImpl");
    }
    
    @Test
    void testCopy_SumNotEqualsSumImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setSumImpl(new SumOfSquares());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertNotSame(dest.sum, dest.getSumImpl(), "sum should not be the same as sumImpl");
    }
    
    @Test
    void testCopy_VarianceEqualsVarianceImpl() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertSame(dest.variance, dest.getVarianceImpl(), "variance should be the same as varianceImpl");
    }
    
    @Test
    void testCopy_VarianceNotEqualsVarianceImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setVarianceImpl(new SumOfSquares());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertNotSame(dest.variance, dest.getVarianceImpl(), "variance should not be the same as varianceImpl");
    }
    
    @Test
    void testCopy_SumLogEqualsSumLogImpl() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertSame(dest.sumLog, dest.getSumLogImpl(), "sumLog should be the same as sumLogImpl");
    }
    
    @Test
    void testCopy_SumLogNotEqualsSumLogImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setSumLogImpl(new Sum());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertNotSame(dest.sumLog, dest.getSumLogImpl(), "sumLog should not be the same as sumLogImpl");
    }
    
    @Test
    void testCopy_SumSqEqualsSumSqImpl() {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertSame(dest.sumsq, dest.getSumsqImpl(), "sumsq should be the same as sumsqImpl");
    }
    
    @Test
    void testCopy_SumSqNotEqualsSumSqImpl() {
        SummaryStatistics source = new SummaryStatistics();
        source.setSumsqImpl(new Sum());
        SummaryStatistics dest = new SummaryStatistics();
        SummaryStatistics.copy(source, dest);
        assertNotSame(dest.sumsq, dest.getSumsqImpl(), "sumsq should not be the same as sumsqImpl");
    }
}