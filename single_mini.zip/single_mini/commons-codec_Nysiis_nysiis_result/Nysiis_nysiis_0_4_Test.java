package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_0_4_Test {

    @Test
    @DisplayName("nysiis replaces trailing 'AY' with 'Y'")
    public void TC16() {
        // Arrange
        Nysiis encoder = new Nysiis();
        String input = "PLAY";

        // Act
        String result = encoder.encode(input);

        // Assert
        assertEquals("PLY", result);
    }

    @Test
    @DisplayName("nysiis removes trailing 'A' from the encoded string")
    public void TC17() {
        // Arrange
        Nysiis encoder = new Nysiis();
        String input = "KARA";

        // Act
        String result = encoder.encode(input);

        // Assert
        assertEquals("KAR", result);
    }

    @Test
    @DisplayName("nysiis collapses repeated characters in the encoded string")
    public void TC18() {
        // Arrange
        Nysiis encoder = new Nysiis();
        String input = "BALLOON";

        // Act
        String result = encoder.encode(input);

        // Assert
        assertEquals("BALON", result);
    }

    @Test
    @DisplayName("nysiis enforces strict mode by truncating the result to 6 characters")
    public void TC19() {
        // Arrange
        Nysiis encoder = new Nysiis(true);
        String input = "ENCODINGLONG";

        // Act
        String result = encoder.encode(input);

        // Assert
        assertTrue(result.length() <= 6, "Result should be truncated to a maximum of 6 characters");
    }

    @Test
    @DisplayName("nysiis does not truncate the result when strict mode is disabled")
    public void TC20() {
        // Arrange
        Nysiis encoder = new Nysiis(false);
        String input = "ENCODINGLONGSTRING";

        // Act
        String result = encoder.encode(input);

        // Assert
        assertEquals("ENCODINGLONGSTRING", input.length(), "Result should retain its full length without truncation");
    }

}