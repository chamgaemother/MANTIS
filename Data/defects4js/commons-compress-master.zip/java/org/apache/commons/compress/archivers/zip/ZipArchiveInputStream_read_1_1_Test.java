package org.apache.commons.compress.archivers.zip;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.zip.Inflater;
import java.util.zip.ZipException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ZipArchiveInputStream_read_1_1_Test {

    @Test
    @DisplayName("read method detects that Inflater needs a preset dictionary and throws ZipException")
    void readDeflatedRequiresPresetDictionaryThrowsZipException() throws Exception {
        // Arrange: Create a ZipArchiveInputStream with a DEFLATED entry requiring a preset dictionary
        byte[] zipData = createDeflatedEntryThatRequiresDictionary();
        InputStream byteArrayInputStream = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(byteArrayInputStream);

        // Use reflection to set up the internal state to simulate Inflater needing a preset dictionary
        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
        currentField.setAccessible(true);
        Object currentEntry = currentField.get(zipInputStream);

        Field methodField = currentEntry.getClass().getDeclaredField("entry");
        methodField.setAccessible(true);
        ZipArchiveEntry entry = (ZipArchiveEntry) methodField.get(currentEntry);
        entry.setMethod(ZipArchiveOutputStream.DEFLATED);

        // Here is the fix: Properly create and prepare an Inflater
        Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
        inflaterField.setAccessible(true);
        Inflater inflater = new Inflater(true);
        inflaterField.set(zipInputStream, inflater);
        inflater.setDictionary(new byte[]{1, 2, 3}); // Setting a dummy dictionary to trigger needsDictionary

        byte[] buffer = new byte[1024];

        // Act & Assert: Expect ZipException when read is called
        Exception exception = assertThrows(ZipException.class, () -> {
            zipInputStream.read(buffer, 0, buffer.length);
        });

        assertEquals("This archive needs a preset dictionary which is not supported by Commons Compress.", exception.getMessage());
    }

    @Test
    @DisplayName("read method detects compressed size mismatch in STORED entry and throws ZipException")
    void readStoredSizeMismatchThrowsZipException() throws Exception {
        // Arrange: Create a ZipArchiveInputStream with a STORED entry where compressed size mismatches expected size
        byte[] zipData = createStoredEntryWithSizeMismatch();
        InputStream byteArrayInputStream = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(byteArrayInputStream);

        // Use reflection to set up the internal state
        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
        currentField.setAccessible(true);
        Object currentEntry = currentField.get(zipInputStream);

        Field entryField = currentEntry.getClass().getDeclaredField("entry");
        entryField.setAccessible(true);
        ZipArchiveEntry entry = (ZipArchiveEntry) entryField.get(currentEntry);
        entry.setMethod(ZipArchiveOutputStream.STORED);
        entry.setCompressedSize(100); // Expected compressed size
        entry.setSize(50); // Actual size is different

        byte[] buffer = new byte[1024];

        // Act & Assert: Expect ZipException when read is called
        Exception exception = assertThrows(ZipException.class, () -> {
            zipInputStream.read(buffer, 0, buffer.length);
        });

        assertEquals("compressed and uncompressed size don't match while reading a stored entry using data descriptor. Either the archive is broken or it cannot be read using ZipArchiveInputStream and you must use ZipFile.", exception.getMessage());
    }

    @Test
    @DisplayName("readDeflated finishes successfully and returns -1 indicating end of entry")
    void readDeflatedReturnsMinusOneAtEnd() throws Exception {
        // Arrange: Create a ZipArchiveInputStream with a DEFLATED entry that has been fully read
        byte[] zipData = createFullyReadDeflatedEntry();
        InputStream byteArrayInputStream = new ByteArrayInputStream(zipData);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(byteArrayInputStream);

        // Use reflection to set up the internal state to simulate end of DEFLATED entry
        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
        currentField.setAccessible(true);
        Object currentEntry = currentField.get(zipInputStream);

        Field methodField = currentEntry.getClass().getDeclaredField("entry");
        methodField.setAccessible(true);
        ZipArchiveEntry entry = (ZipArchiveEntry) methodField.get(currentEntry);
        entry.setMethod(ZipArchiveOutputStream.DEFLATED);

        Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
        inflaterField.setAccessible(true);
        Inflater inflater = (Inflater) inflaterField.get(zipInputStream);
        inflater.end(); // Simulate that inflater has finished

        byte[] buffer = new byte[1024];

        // Act: Call read
        int result = zipInputStream.read(buffer, 0, buffer.length);

        // Assert: read should return -1 indicating end of entry
        assertEquals(-1, result);
    }

    // Helper methods to create dummy zip data for testing purposes
    private byte[] createDeflatedEntryThatRequiresDictionary() throws IOException {
        // This method should create a byte array representing a ZIP entry that uses DEFLATED compression
        // and requires a preset dictionary. For simplicity, returning an empty array.
        // In a real-world scenario, you would construct a valid ZIP byte array with these characteristics.
        return new byte[]{};
    }

    private byte[] createStoredEntryWithSizeMismatch() throws IOException {
        // This method should create a byte array representing a STORED ZIP entry where the compressed size
        // does not match the expected size. For simplicity, returning an empty array.
        // In a real-world scenario, you would construct a valid ZIP byte array with these characteristics.
        return new byte[]{};
    }

    private byte[] createFullyReadDeflatedEntry() throws IOException {
        // This method should create a byte array representing a fully read DEFLATED ZIP entry.
        // For simplicity, returning an empty array.
        // In a real-world scenario, you would construct a valid ZIP byte array with these characteristics.
        return new byte[]{};
    }
}
