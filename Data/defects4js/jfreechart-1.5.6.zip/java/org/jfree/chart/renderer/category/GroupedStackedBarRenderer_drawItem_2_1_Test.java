package org.jfree.chart.renderer.category;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.GroupedStackedBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.chart.renderer.category.BarPainter;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class GroupedStackedBarRenderer_drawItem_2_1_Test {
    
    @Test
    @DisplayName("drawItem handles dataset with both positive and negative accumulated values, verifying correct accumulation")
    void TC26_drawItem_PositiveAndNegativeAccumulation() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 500, 400);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        int row = 2;
        int column = 1;
        int pass = 0;

        // Setup dataset with both positive and negative values
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(dataset.getRowKey(0)).thenReturn("Series1");
        when(dataset.getRowKey(1)).thenReturn("Series2");
        when(dataset.getValue(0, column)).thenReturn(5.0);
        when(dataset.getValue(1, column)).thenReturn(-3.0);

        GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());
        BarPainter mockBarPainter = mock(BarPainter.class);
        doReturn(mockBarPainter).when(renderer).getBarPainter();
        when(renderer.getItemLabelGenerator(anyInt(), anyInt())).thenReturn(null);
        when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class));
    }

//     @Test
//     @DisplayName("drawItem sets bar length to minimumBarLength when calculated length is below minimum")
//     void TC27_drawItem_BarLength_BelowMinimum() throws Exception {
        // Arrange
//         Graphics2D g2 = mock(Graphics2D.class);
//         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
//         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 500, 400);
//         CategoryPlot plot = mock(CategoryPlot.class);
//         CategoryAxis domainAxis = mock(CategoryAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         CategoryDataset dataset = mock(CategoryDataset.class);
//         EntityCollection entities = mock(EntityCollection.class);
// 
//         int row = 1;
//         int column = 1;
//         int pass = 0;
// 
        // Setup dataset with a value that results in bar length below minimum
//         when(dataset.getValue(row, column)).thenReturn(2.0);
//         when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
//         when(rangeAxis.isInverted()).thenReturn(false);
//         when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), eq(RectangleEdge.BOTTOM)))
//             .thenReturn(0.0, 2.0);
// 
//         GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());
//         doReturn(5.0).when(renderer).getMinimumBarLength();
//         BarPainter mockBarPainter = mock(BarPainter.class);
//         doReturn(mockBarPainter).when(renderer).getBarPainter();
//         when(renderer.getItemLabelGenerator(anyInt(), anyInt())).thenReturn(null);
//         when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(false);
// 
        // Act
//         renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
// 
        // Assert
//         ArgumentCaptor<Rectangle2D> captor = ArgumentCaptor.forClass(Rectangle2D.class);
//         verify(renderer.getBarPainter()).paintBar(eq(g2), eq(renderer), eq(row), eq(column), captor.capture(), any(RectangleEdge.class));
//         Rectangle2D capturedBar = captor.getValue();
//         if (plot.getOrientation() == PlotOrientation.HORIZONTAL) {
//             assertTrue(capturedBar.getWidth() >= 5.0, "Bar length should be at least the minimumBarLength");
//         } else {
//             assertTrue(capturedBar.getHeight() >= 5.0, "Bar length should be at least the minimumBarLength");
//         }
//     }

    @Test
    @DisplayName("drawItem handles EntityCollection being present when state.getInfo() is not null")
    void TC28_drawItem_EntityCollection_Present() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 500, 400);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        EntityCollection entities = mock(EntityCollection.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        // Setup dataset with a valid value
        when(dataset.getValue(row, column)).thenReturn(10.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(state.getInfo()).thenReturn(new org.jfree.chart.plot.PlotRenderingInfo(null));
        when(state.getEntityCollection()).thenReturn(entities);

        GroupedStackedBarRenderer renderer = new GroupedStackedBarRenderer();
        BarPainter mockBarPainter = mock(BarPainter.class);
        doReturn(mockBarPainter).when(renderer).getBarPainter();
        when(renderer.getItemLabelGenerator(anyInt(), anyInt())).thenReturn(null);
        when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(renderer).addItemEntity(eq(entities), eq(dataset), eq(row), eq(column), any(Rectangle2D.class));
    }

    @Test
    @DisplayName("drawItem handles dataset with all series having null values leading to no bar painting")
    void TC29_drawItem_AllSeriesNullValues() throws Exception {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 500, 400);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        int row = 0;
        int column = 0;
        int pass = 0;

        // Setup dataset with all null values
        when(dataset.getValue(row, column)).thenReturn(null);

        GroupedStackedBarRenderer renderer = Mockito.spy(new GroupedStackedBarRenderer());
        BarPainter mockBarPainter = mock(BarPainter.class);
        doReturn(mockBarPainter).when(renderer).getBarPainter();
        when(renderer.getItemLabelGenerator(anyInt(), anyInt())).thenReturn(null);
        when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(false);

        // Act
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);

        // Assert
        verify(renderer.getBarPainter(), Mockito.never()).paintBar(any(), any(), anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class));
    }
}
