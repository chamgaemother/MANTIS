package org.jfree.chart.renderer.xy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.ui.RectangleEdge;
import static org.mockito.Mockito.*;
import org.jfree.chart.renderer.xy.GradientXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import java.awt.geom.RectangularShape;

public class GradientXYBarPainter_paintBar_2_1_Test {

    @Test
    @DisplayName("paintBar with non-Color/non-GradientPaint paint, alpha !=0, base LEFT, and outline drawn")
    public void TC15() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        Paint customPaint = Color.RED; // Non-null Paint
        when(renderer.getItemPaint(1, 1)).thenReturn(customPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        Stroke outlineStroke = mock(Stroke.class);
        Paint outlinePaint = Color.BLACK;
        when(renderer.getItemOutlineStroke(1, 1)).thenReturn(outlineStroke);
        when(renderer.getItemOutlinePaint(1, 1)).thenReturn(outlinePaint);
        int row = 1;
        int column = 1;
        RectangularShape bar = new Rectangle2D.Double(20, 20, 40, 40);
        RectangleEdge base = RectangleEdge.LEFT;
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2).setStroke(outlineStroke);
        verify(g2).setPaint(outlinePaint);
        verify(g2).draw(bar);
    }

    @Test
    @DisplayName("paintBar with non-Color/non-GradientPaint paint, alpha !=0, base RIGHT, and outline not drawn due to null stroke")
    public void TC16() {
        // Arrange
        Graphics2D g2 = mock(Graphics2D.class);
        XYBarRenderer renderer = mock(XYBarRenderer.class);
        Paint customPaint = Color.YELLOW; // Non-null Paint
        when(renderer.getItemPaint(2, 2)).thenReturn(customPaint);
        when(renderer.isDrawBarOutline()).thenReturn(true);
        Stroke outlineStroke = null;
        Paint outlinePaint = Color.GRAY;
        when(renderer.getItemOutlineStroke(2, 2)).thenReturn(outlineStroke);
        when(renderer.getItemOutlinePaint(2, 2)).thenReturn(outlinePaint);
        int row = 2;
        int column = 2;
        RectangularShape bar = new Rectangle2D.Double(30, 30, 60, 60);
        RectangleEdge base = RectangleEdge.RIGHT;
        GradientXYBarPainter painter = new GradientXYBarPainter();

        // Act
        painter.paintBar(g2, renderer, row, column, bar, base);

        // Assert
        verify(g2, times(4)).setPaint(any(GradientPaint.class));
        verify(g2, times(4)).fill(any(Rectangle2D.class));
        verify(g2, never()).setStroke(any(Stroke.class));
        verify(g2, never()).draw(any(Rectangle2D.class));
    }
}
