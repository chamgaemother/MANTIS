package com.google.gson.internal.bind.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;

public class ISO8601Utils_parse_2_1_Test {

    @Test
    @DisplayName("parse date string without '-' separators between year, month, and day")
    void TC34() {
        String date = "20231005T14:30:00Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("parse date string with lowercase 'z' timezone indicator leading to IndexOutOfBoundsException")
    void TC35() {
        String date = "2023-10-05T14:30:00z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(IndexOutOfBoundsException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

    @Test
    @DisplayName("parse date string with '.' but no digits in milliseconds leading to ParseException")
    void TC36() {
        String date = "2023-10-05T14:30:00.Z";
        ParsePosition pos = new ParsePosition(0);
        assertThrows(ParseException.class, () -> {
            ISO8601Utils.parse(date, pos);
        });
    }

}