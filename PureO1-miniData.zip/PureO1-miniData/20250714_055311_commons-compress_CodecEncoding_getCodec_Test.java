package org.apache.commons.compress.harmony.pack200;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class CodecEncodingTest {

    @Test
    void getCodec_ValueLessThanZero_ShouldThrowIllegalArgumentException() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            CodecEncoding.getCodec(-1, new ByteArrayInputStream(new byte[] {}), Codec.BYTE1);
        });
        assertEquals("Encoding cannot be less than zero", exception.getMessage());
    }

    @Test
    void getCodec_ValueZero_ShouldReturnDefaultCodec() throws IOException, Pack200Exception {
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(0, new ByteArrayInputStream(new byte[] {}), defaultCodec);
        assertSame(defaultCodec, result);
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 115})
    void getCodec_ValueWithinCanonicalRange_ShouldReturnCanonicalCodec(int value) throws IOException, Pack200Exception {
        Codec result = CodecEncoding.getCodec(value, new ByteArrayInputStream(new byte[] {}), Codec.BYTE1);
        assertNotNull(result);
        assertEquals(CodecEncoding.getCanonicalCodec(value), result);
    }

    @Test
    void getCodec_Value116_NormalCase_ShouldReturnBHSDCodec() throws IOException, Pack200Exception {
        byte[] input = { (byte) 0b00011010, (byte) 0x05 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(116, in, defaultCodec);
        assertTrue(result instanceof BHSDCodec);
        BHSDCodec codec = (BHSDCodec) result;
        assertEquals(1, codec.getB());
        assertEquals(6, codec.getH());
        assertEquals(2, codec.getS());
        assertEquals(0, codec.isDelta() ? 1 : 0);
    }

    @Test
    void getCodec_Value116_FirstReadEOF_ShouldThrowEOFException() {
        InputStream in = new ByteArrayInputStream(new byte[] {});
        Codec defaultCodec = Codec.BYTE1;
        assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(116, in, defaultCodec);
        });
    }

    @Test
    void getCodec_Value116_SecondReadEOF_ShouldThrowEOFException() {
        byte[] input = { (byte) 0b00011010 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(116, in, defaultCodec);
        });
    }

    @ParameterizedTest
    @ValueSource(ints = {117, 140})
    void getCodec_ValueRunCodec_ShouldReturnRunCodec(int value) throws IOException, Pack200Exception {
        byte[] input = { 0x03, 0x04 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        if (value >= 117 && value <= 140) {
            Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
            assertTrue(result instanceof RunCodec);
        }
    }

    @Test
    void getCodec_ValueRunCodec_AdefAndBdefBothTrue_ShouldThrowPack200Exception() {
        // To set adef and bdef both true, offset needs to have bits 3 and 4 set
        int value = 117 + 0 + 4 + 8; // example value within 117-140
        byte[] input = {};
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("ADef and BDef should never both be true", exception.getMessage());
    }

    @Test
    void getCodec_ValueRunCodec_KbFlagTrue_ShouldReadKb() throws IOException, Pack200Exception {
        int value = 117; // example value with kbflag
        byte[] input = { 0x02, 0x01, 0x02 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof RunCodec);
    }

    @Test
    void getCodec_ValueRunCodec_AdefFalseBdefFalse_ShouldReadAandBCodecs() throws IOException, Pack200Exception {
        int value = 117; // adef and bdef false
        byte[] input = { 0x02, 0x03, 0x04 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof RunCodec);
    }

    @Test
    void getCodec_ValueBetween141And188_TdefTrue_ShouldReturnPopulationCodecWithTdef() throws IOException, Pack200Exception {
        int value = 141;
        byte[] input = { 0x05, 0x06 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof PopulationCodec);
    }

    @Test
    void getCodec_ValueBetween141And188_TdefFalse_ShouldReturnPopulationCodecWithoutTdef() throws IOException, Pack200Exception {
        int value = 141 + 4; // ensure tdefl = 1, but adjust to make tdef false
        byte[] input = { 0x05, 0x06, 0x07 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof PopulationCodec);
    }

    @Test
    void getCodec_ValueInvalid_ShouldThrowPack200Exception() {
        int value = 189;
        byte[] input = {};
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Pack200Exception exception = assertThrows(Pack200Exception.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
        assertEquals("Invalid codec encoding byte (" + value + ") found", exception.getMessage());
    }

    @Test
    void getCodec_NullInputStream_ShouldThrowNullPointerException() {
        int value = 116;
        Codec defaultCodec = Codec.BYTE1;
        assertThrows(NullPointerException.class, () -> {
            CodecEncoding.getCodec(value, null, defaultCodec);
        });
    }

    @Test
    void getCodec_DefaultCodecNull_ValueZero_ShouldReturnNull() throws IOException, Pack200Exception {
        Codec result = CodecEncoding.getCodec(0, new ByteArrayInputStream(new byte[] {}), null);
        assertNull(result);
    }

    @Test
    void getCodec_DefaultCodecNull_ValueWithinCanonicalRange_ShouldReturnCanonicalCodec() throws IOException, Pack200Exception {
        Codec result = CodecEncoding.getCodec(1, new ByteArrayInputStream(new byte[] {}), null);
        assertNotNull(result);
    }

    @Test
    void getCodec_ValueRunCodec_WithDefaultCodec_ShouldUseDefaultWhenAdefOrBdef() throws IOException, Pack200Exception {
        int value = 117; // adef false, bdef false
        byte[] input = { 0x02, 0x00, 0x01 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof RunCodec);
    }

    @Test
    void getCodec_Value141_TdefTrue_WithDefaultCodec_ShouldUseDefaultCodecs() throws IOException, Pack200Exception {
        int value = 141;
        byte[] input = {};
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
    }

    @Test
    void getCodec_Value141_TdefFalse_WithDefaultCodec_ShouldUseDefaultAndReadCodecs() throws IOException, Pack200Exception {
        int value = 142;
        byte[] input = { 0x01, 0x02, 0x03 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof PopulationCodec);
    }

    @Test
    void getCodec_Value117_RunCodec_WithAdefTrue_ShouldUseDefaultAcodec() throws IOException, Pack200Exception {
        int value = 117; // assuming adef=true
        byte[] input = { 0x03, 0x04 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        // Modify value to set adef=true and bdef=false
        // adef is bit 3, bdef is bit4
        int modifiedValue = 117 + 8; // set adef=true
        Codec result = CodecEncoding.getCodec(modifiedValue, in, defaultCodec);
        assertTrue(result instanceof RunCodec);
    }

    @Test
    void getCodec_Value117_RunCodec_WithBdefTrue_ShouldUseDefaultBcodec() throws IOException, Pack200Exception {
        int value = 117; // assuming bdef=true
        byte[] input = { 0x03, 0x04 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        // Modify value to set bdef=true
        int modifiedValue = 117 + 16; // set bdef=true
        Codec result = CodecEncoding.getCodec(modifiedValue, in, defaultCodec);
        assertTrue(result instanceof RunCodec);
    }

    @Test
    void getCodec_Value141_PopulationCodec_TdefTrue_ShouldHandlePopulationCodec() throws IOException, Pack200Exception {
        int value = 141;
        byte[] input = { 0x01, 0x02 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        // This should attempt to read two codecs
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof PopulationCodec);
    }

    @Test
    void getCodec_Value141_PopulationCodec_TdefFalse_ShouldHandlePopulationCodec() throws IOException, Pack200Exception {
        int value = 141 + 4; // tdef=false
        byte[] input = { 0x01, 0x02, 0x03 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec result = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(result instanceof PopulationCodec);
    }

    @Test
    void getCodec_Value116_WithValidBytes_ShouldCreateBHSDCodec() throws IOException, Pack200Exception {
        byte[] input = { (byte) 0b00011010, (byte) 0x05 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec codec = CodecEncoding.getCodec(116, in, defaultCodec);
        assertTrue(codec instanceof BHSDCodec);
        BHSDCodec bhsd = (BHSDCodec) codec;
        assertEquals(1, bhsd.getB());
        assertEquals(6, bhsd.getH());
        assertEquals(2, bhsd.getS());
        assertFalse(bhsd.isDelta());
    }

    @Test
    void getCodec_Value141_WithFavouredCodec_ShouldCreatePopulationCodec() throws IOException, Pack200Exception {
        int value = 141;
        byte[] input = { 0x02, 0x03 };
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        Codec codec = CodecEncoding.getCodec(value, in, defaultCodec);
        assertTrue(codec instanceof PopulationCodec);
    }

    @Test
    void getCodec_Value141_PopulationCodec_WithTdef_ShouldThrowEOFExceptionIfInsufficientData() {
        int value = 141;
        byte[] input = { 0x01 }; // insufficient data
        InputStream in = new ByteArrayInputStream(input);
        Codec defaultCodec = Codec.BYTE1;
        assertThrows(EOFException.class, () -> {
            CodecEncoding.getCodec(value, in, defaultCodec);
        });
    }
}