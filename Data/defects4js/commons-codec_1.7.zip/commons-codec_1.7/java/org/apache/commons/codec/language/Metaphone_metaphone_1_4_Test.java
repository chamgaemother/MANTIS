package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Metaphone_metaphone_1_4_Test {

    @Test
    @DisplayName("metaphone word with 'V' converts to 'F'")
    void testTC46() {
        // GIVEN
        String txt = "vase";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("FS", result, "'V' should be converted to 'F'");
    }
    
    @Test
    @DisplayName("metaphone word with 'P' not followed by 'H' converts to 'P'")
    void testTC47() {
        // GIVEN
        String txt = "park";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("PRK", result, "'P' should be retained when not followed by 'H'");
    }
    
    @Test
    @DisplayName("metaphone word with 'PH' sequence converts to 'F'")
    void testTC48() {
        // GIVEN
        String txt = "phone";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("FN", result, "'PH' should be converted to 'F'");
    }
    
    @Test
    @DisplayName("metaphone word with 'Q' converts to 'K'")
    void testTC49() {
        // GIVEN
        String txt = "quick";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("KK", result, "'Q' should be converted to 'K'");
    }
    
    @Test
    @DisplayName("metaphone word with 'Z' converts to 'S'")
    void testTC50() {
        // GIVEN
        String txt = "zebra";
        Metaphone metaphone = new Metaphone();
        
        // WHEN
        String result = metaphone.metaphone(txt);
        
        // THEN
        assertEquals("SMBRA", result, "'Z' should be converted to 'S'");
    }
}