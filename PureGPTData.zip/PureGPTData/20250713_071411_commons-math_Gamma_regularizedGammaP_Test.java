import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.special.Gamma;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GammaTest {

    @Test
    public void testRegularizedGammaP_NaNInputs() {
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(Double.NaN, 1.0, 0.0, 1)));
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(1.0, Double.NaN, 0.0, 1)));
    }

    @Test
    public void testRegularizedGammaP_NonPositiveA() {
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(0.0, 1.0, 0.0, 1)));
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(-1.0, 1.0, 0.0, 1)));
    }

    @Test
    public void testRegularizedGammaP_NegativeX() {
        assertTrue(Double.isNaN(Gamma.regularizedGammaP(1.0, -1.0, 0.0, 1)));
    }

    @Test
    public void testRegularizedGammaP_ZeroX() {
        assertEquals(0.0, Gamma.regularizedGammaP(1.0, 0.0, 1e-15, 10000), 1e-15);
    }

    @Test
    public void testRegularizedGammaP_XGreaterThanA() { // this will call regularizedGammaQ
        double result = Gamma.regularizedGammaP(2.0, 3.0, 1e-15, 10000);
        assertTrue(result >= 0 && result <= 1);
    }

    @Test
    public void testRegularizedGammaP_ValidInput() {
        double result = Gamma.regularizedGammaP(1.0, 0.5, 1e-15, 10000);
        assertTrue(result >= 0 && result <= 1);
    }
    
    @Test
    public void testRegularizedGammaP_ConvergenceFailure() {
        MaxCountExceededException thrown = assertThrows(MaxCountExceededException.class, () ->
                Gamma.regularizedGammaP(1.0, 0.5, 1e-15, 1));
        assertTrue(thrown.getMessage().contains("Maximal count (1) exceeded"));
    }
}