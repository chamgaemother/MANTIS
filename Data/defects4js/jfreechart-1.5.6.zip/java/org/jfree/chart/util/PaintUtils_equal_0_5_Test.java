package org.jfree.chart.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.awt.Color;
import java.awt.MultipleGradientPaint;
import java.awt.RadialGradientPaint;
import java.awt.LinearGradientPaint;
import java.awt.GradientPaint;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.color.ColorSpace;

import static org.junit.jupiter.api.Assertions.*;

public class PaintUtils_equal_0_5_Test {

    @Test
    @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different cycle methods, expect false")
    public void TC21() {
        // GIVEN
        Point2D center = new Point2D.Float(0, 0);
        float radius = 50.0f;
        Point2D focus = new Point2D.Float(25, 25);
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.RED, Color.BLUE};
        RadialGradientPaint rgp1 = new RadialGradientPaint(center, radius, focus, fractions, colors, MultipleGradientPaint.CycleMethod.NO_CYCLE);
        RadialGradientPaint rgp2 = new RadialGradientPaint(center, radius, focus, fractions, colors, MultipleGradientPaint.CycleMethod.REFLECT);

        // WHEN
        boolean result = PaintUtils.equal(rgp1, rgp2);

        // THEN
        assertFalse(result);
    }

//     @Test
//     @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different color spaces, expect false")
//     public void TC22() {
        // GIVEN
//         Point2D center = new Point2D.Float(10, 10);
//         float radius = 75.0f;
//         Point2D focus = new Point2D.Float(35, 35);
//         float[] fractions = {0.0f, 1.0f};
//         Color[] colors = {Color.GREEN, Color.YELLOW};
//         RadialGradientPaint rgp1 = new RadialGradientPaint(
//                 center,
//                 radius,
//                 focus,
//                 fractions,
//                 colors,
//                 MultipleGradientPaint.CycleMethod.NO_CYCLE,
//                 ColorSpace.getInstance(ColorSpace.CS_sRGB),
//                 new AffineTransform()
//         );
//         RadialGradientPaint rgp2 = new RadialGradientPaint(
//                 center,
//                 radius,
//                 focus,
//                 fractions,
//                 colors,
//                 MultipleGradientPaint.CycleMethod.NO_CYCLE,
//                 ColorSpace.getInstance(ColorSpace.CS_LINEAR_RGB),
//                 new AffineTransform()
//         );
// 
        // WHEN
//         boolean result = PaintUtils.equal(rgp1, rgp2);
// 
        // THEN
//         assertFalse(result);
//     }

//     @Test
//     @DisplayName("Both p1 and p2 are RadialGradientPaint instances with different transforms, expect false")
//     public void TC23() {
        // GIVEN
//         AffineTransform at1 = new AffineTransform();
//         AffineTransform at2 = new AffineTransform();
//         at2.scale(2, 2);
//         Point2D center = new Point2D.Float(20, 20);
//         float radius = 100.0f;
//         Point2D focus = new Point2D.Float(50, 50);
//         float[] fractions = {0.0f, 1.0f};
//         Color[] colors = {Color.CYAN, Color.MAGENTA};
//         RadialGradientPaint rgp1 = new RadialGradientPaint(
//                 center,
//                 radius,
//                 focus,
//                 fractions,
//                 colors,
//                 MultipleGradientPaint.CycleMethod.REPEAT,
//                 ColorSpace.getInstance(ColorSpace.CS_sRGB),
//                 at1
//         );
//         RadialGradientPaint rgp2 = new RadialGradientPaint(
//                 center,
//                 radius,
//                 focus,
//                 fractions,
//                 colors,
//                 MultipleGradientPaint.CycleMethod.REPEAT,
//                 ColorSpace.getInstance(ColorSpace.CS_sRGB),
//                 at2
//         );
// 
        // WHEN
//         boolean result = PaintUtils.equal(rgp1, rgp2);
// 
        // THEN
//         assertFalse(result);
//     }

    @Test
    @DisplayName("Both p1 and p2 are LinearGradientPaint instances with different end points, expect false")
    public void TC24() {
        // GIVEN
        Point2D start1 = new Point2D.Float(0, 0);
        Point2D end1 = new Point2D.Float(1, 1);
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.BLACK, Color.WHITE};
        LinearGradientPaint lgp1 = new LinearGradientPaint(start1, end1, fractions, colors, MultipleGradientPaint.CycleMethod.REFLECT);
        
        Point2D start2 = new Point2D.Float(0, 0);
        Point2D end2 = new Point2D.Float(2, 2);
        LinearGradientPaint lgp2 = new LinearGradientPaint(start2, end2, fractions, colors, MultipleGradientPaint.CycleMethod.REFLECT);

        // WHEN
        boolean result = PaintUtils.equal(lgp1, lgp2);

        // THEN
        assertFalse(result);
    }

    @Test
    @DisplayName("p1 is GradientPaint and p2 is LinearGradientPaint, expect false")
    public void TC25() {
        // GIVEN
        GradientPaint gp = new GradientPaint(0f, 0f, Color.BLUE, 1f, 1f, Color.RED);
        Point2D start = new Point2D.Float(0, 0);
        Point2D end = new Point2D.Float(1, 1);
        float[] fractions = {0.0f, 1.0f};
        Color[] colors = {Color.BLUE, Color.RED};
        LinearGradientPaint lgp = new LinearGradientPaint(start, end, fractions, colors, MultipleGradientPaint.CycleMethod.NO_CYCLE);

        // WHEN
        boolean result = PaintUtils.equal(gp, lgp);

        // THEN
        assertFalse(result);
    }
}