package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class Nysiis_nysiis_1_1_Test {

    @Test
    @DisplayName("nysiis(\"AHA\") keeps H when surrounded by vowels")
    public void TC23_nysiis_keeps_H_when_surrounded_by_vowels() {
        // GIVEN
        Nysiis encoder = new Nysiis();
        String input = "AHA";

        // WHEN
        String result = encoder.nysiis(input);

        // THEN
        assertTrue(result.contains("H"), "H should be retained when surrounded by vowels");
    }

    @Test
    @DisplayName("nysiis(\"HAH\") keeps H when surrounded by vowels")
    public void TC24_nysiis_keeps_H_when_surrounded_by_vowels_at_start_and_end() {
        // GIVEN
        Nysiis encoder = new Nysiis();
        String input = "HAH";

        // WHEN
        String result = encoder.nysiis(input);

        // THEN
        assertTrue(result.contains("H"), "H should be retained when surrounded by vowels");
    }

    @Test
    @DisplayName("nysiis(\"AHB\") keeps H when not surrounded by vowels")
    public void TC25_nysiis_keeps_H_when_not_surrounded_by_vowels() {
        // GIVEN
        Nysiis encoder = new Nysiis();
        String input = "AHB";

        // WHEN
        String result = encoder.nysiis(input);

        // THEN
        assertTrue(result.contains("H"), "H should be retained when not surrounded by vowels");
    }

    @Test
    @DisplayName("nysiis(\"BACHA\") retains H when preceded by a consonant and followed by a vowel")
    public void TC26_nysiis_retains_H_between_consonant_and_vowel() {
        // GIVEN
        Nysiis encoder = new Nysiis();
        String input = "BACHA";

        // WHEN
        String result = encoder.nysiis(input);

        // THEN
        assertTrue(result.contains("H"), "H should be retained when preceded by a consonant and followed by a vowel");
    }

    @Test
    @DisplayName("nysiis(\"NEW\") retains W when not following a vowel")
    public void TC27_nysiis_retains_W_when_not_following_a_vowel() {
        // GIVEN
        Nysiis encoder = new Nysiis();
        String input = "NEW";

        // WHEN
        String result = encoder.nysiis(input);

        // THEN
        assertTrue(result.contains("W"), "W should be retained when not following a vowel");
    }
}