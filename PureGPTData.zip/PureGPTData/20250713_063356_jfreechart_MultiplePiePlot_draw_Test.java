import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.ui.RectangleInsets;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DatasetUtils;
import org.jfree.data.general.PieDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MultiplePiePlotTest {

    private MultiplePiePlot plot;
    private Graphics2D graphics2D;
    private Rectangle2D area;
    private PlotRenderingInfo plotRenderingInfo;

    @BeforeEach
    void setUp() {
        plot = new MultiplePiePlot();
        graphics2D = mock(Graphics2D.class);
        area = new Rectangle2D.Double(0, 0, 100, 100);
        plotRenderingInfo = new PlotRenderingInfo(new ChartRenderingInfo());
    }

    @Test
    void testDrawWithNullDataset() {
        plot.draw(graphics2D, area, null, null, plotRenderingInfo);
        verify(graphics2D, times(1)).drawString(anyString(), anyFloat(), anyFloat());
    }

    @Test
    void testDrawWithNonEmptyDatasetByRow() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1, "Row1", "Column1");
        dataset.addValue(2, "Row2", "Column2");
        plot.setDataset(dataset);
        plot.setDataExtractOrder(TableOrder.BY_ROW);
        plot.draw(graphics2D, area, null, null, plotRenderingInfo);
        verify(graphics2D, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    void testDrawWithNonEmptyDatasetByColumn() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1, "Row1", "Column1");
        dataset.addValue(2, "Row2", "Column2");
        plot.setDataset(dataset);
        plot.setDataExtractOrder(TableOrder.BY_COLUMN);
        plot.draw(graphics2D, area, null, null, plotRenderingInfo);
        verify(graphics2D, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    void testDrawWithDifferentAreaDimensions() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1, "Row1", "Column1");
        plot.setDataset(dataset);
        area = new Rectangle2D.Double(0, 0, 200, 50);
        plot.draw(graphics2D, area, null, null, plotRenderingInfo);
        verify(graphics2D, atLeastOnce()).draw(any(Shape.class));
    }
    
    @Test
    void testDrawWithAggregatedItems() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i = 0; i < 10; i++) {
            dataset.addValue(0.1, "Row" + i, "Column1");
        }
        plot.setDataset(dataset);
        plot.setLimit(0.1);
        plot.draw(graphics2D, area, null, null, plotRenderingInfo);
        verify(graphics2D, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    void testDrawWithInvertedRowsAndColumns() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i = 0; i < 3; i++) {
            dataset.addValue(1.0, "Row" + i, "Column1");
        }
        plot.setDataset(dataset);
        area = new Rectangle2D.Double(0, 0, 50, 200);
        plot.draw(graphics2D, area, null, null, plotRenderingInfo);
        verify(graphics2D, atLeastOnce()).draw(any(Shape.class));
    }

    @Test
    void testDrawWithoutPlotRenderingInfo() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1, "Row1", "Column1");
        plot.setDataset(dataset);
        plot.draw(graphics2D, area, null, null, null);
        verify(graphics2D, atLeastOnce()).draw(any(Shape.class));
    }
}