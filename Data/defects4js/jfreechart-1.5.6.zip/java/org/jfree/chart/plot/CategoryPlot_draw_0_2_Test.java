package org.jfree.chart.plot;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Arrays;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.util.ShapeUtils;
import org.jfree.chart.util.ShadowGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

public class CategoryPlot_draw_0_2_Test {

//     @Test
//     @DisplayName("Draw background using default when renderer is null")
//     void TC06_drawWithRendererNull() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 300, 300);
//         Point2D anchor = new Point2D.Double(150, 150);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo(new JFreeChart(new CategoryPlot()));
// 
//         CategoryPlot categoryPlot = spy(new CategoryPlot());
//         doReturn(null).when(categoryPlot).getRenderer();
// 
//         categoryPlot.draw(g2, area, anchor, state, info);
// 
        // Ensure that drawBackground is called even if renderer is null
//         verify(categoryPlot).drawBackground(g2, area);
//     }

//     @Test
//     @DisplayName("Draw method handles null anchor by retaining it")
//     void TC07_drawWithNullAnchor() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 300, 300);
//         Point2D anchor = null;
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo(new JFreeChart(new CategoryPlot()));
// 
//         CategoryPlot categoryPlot = spy(new CategoryPlot());
// 
//         categoryPlot.draw(g2, area, anchor, state, info);
// 
        // Ensure that no methods get called if anchor is null
//         verify(g2, times(0)).clip(any(Rectangle2D.class));
//         verify(g2, times(0)).draw(any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("Draw method adjusts anchor point when outside data area")
//     void TC08_drawWithAnchorOutsideDataArea() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 300, 300);
//         Point2D anchor = new Point2D.Double(400, 400);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo(new JFreeChart(new CategoryPlot()));
// 
//         CategoryPlot categoryPlot = spy(new CategoryPlot());
// 
//         categoryPlot.draw(g2, area, anchor, state, info);
// 
//         verify(categoryPlot, times(1)).drawBackground(any(Graphics2D.class), any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("Draw method handles multiple dataset rendering orders")
//     void TC09_drawWithMultipleDatasetRenderingOrders() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 400, 400);
//         Point2D anchor = new Point2D.Double(200, 200);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo(new JFreeChart(new CategoryPlot()));
// 
//         DatasetRenderingOrder order = DatasetRenderingOrder.REVERSE;
// 
//         CategoryPlot categoryPlot = spy(new CategoryPlot());
//         doReturn(order).when(categoryPlot).getDatasetRenderingOrder();
//         doReturn(Arrays.asList(2, 1, 0)).when(categoryPlot).getDatasetIndices(order);
// 
//         CategoryItemRenderer renderer0 = mock(CategoryItemRenderer.class);
//         CategoryItemRenderer renderer1 = mock(CategoryItemRenderer.class);
//         CategoryItemRenderer renderer2 = mock(CategoryItemRenderer.class);
// 
//         categoryPlot.setRenderer(0, renderer0);
//         categoryPlot.setRenderer(1, renderer1);
//         categoryPlot.setRenderer(2, renderer2);
// 
//         categoryPlot.draw(g2, area, anchor, state, info);
// 
        // Verify the rendering order
//         InOrder inOrder = inOrder(renderer2, renderer1, renderer0);
//         inOrder.verify(renderer2).drawBackground(any(Graphics2D.class), any(CategoryPlot.class), any(Rectangle2D.class));
//         inOrder.verify(renderer1).drawBackground(any(Graphics2D.class), any(CategoryPlot.class), any(Rectangle2D.class));
//         inOrder.verify(renderer0).drawBackground(any(Graphics2D.class), any(CategoryPlot.class), any(Rectangle2D.class));
//     }

//     @Test
//     @DisplayName("Draw method handles shadow generation when shadowGenerator is present and not suppressed")
//     void TC10_drawWithShadowGeneration() throws Exception {
//         Graphics2D g2 = mock(Graphics2D.class);
//         Rectangle2D area = new Rectangle2D.Double(0, 0, 500, 500);
//         Point2D anchor = new Point2D.Double(250, 250);
//         PlotState state = new PlotState();
//         PlotRenderingInfo info = new PlotRenderingInfo(new JFreeChart(new CategoryPlot()));
// 
//         ShadowGenerator shadowGenerator = mock(ShadowGenerator.class);
//         BufferedImage shadowImage = mock(BufferedImage.class);
//         when(shadowGenerator.createDropShadow(any(BufferedImage.class))).thenReturn(shadowImage);
// 
//         CategoryPlot categoryPlot = spy(new CategoryPlot());
//         doReturn(shadowGenerator).when(categoryPlot).getShadowGenerator();
//         when(g2.getRenderingHint(JFreeChart.KEY_SUPPRESS_SHADOW_GENERATION)).thenReturn(false);
// 
//         categoryPlot.draw(g2, area, anchor, state, info);
// 
        // Verify shadow generation
//         verify(shadowGenerator).createDropShadow(any(BufferedImage.class));
//         verify(g2).drawImage(shadowImage, anyInt(), anyInt(), any());
//         verify(g2).drawImage(any(BufferedImage.class), anyInt(), anyInt(), any());
//     }
}