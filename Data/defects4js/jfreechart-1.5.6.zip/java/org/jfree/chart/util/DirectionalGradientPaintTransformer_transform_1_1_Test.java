package org.jfree.chart.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;

public class DirectionalGradientPaintTransformer_transform_1_1_Test {

    @Test
    @DisplayName("Transform with null GradientPaint should throw NullPointerException")
    void transform_null_paint_throws_exception() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        Shape target = new Rectangle2D.Float(0, 0, 10, 10);
        assertThrows(NullPointerException.class, () -> transformer.transform(null, target));
    }

    @Test
    @DisplayName("Transform with null Shape should throw NullPointerException")
    void transform_null_target_throws_exception() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 10, 10, Color.BLUE, false);
        assertThrows(NullPointerException.class, () -> transformer.transform(paint, null));
    }

    @Test
    @DisplayName("Transform with target bounds having zero width should create GradientPaint with zero width")
    void transform_zero_width_target() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 10, 10, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(5, 5, 0, 10);
        GradientPaint result = transformer.transform(paint, target);
        assertEquals(5f, result.getPoint2().getX(), "rx2 should be equal to bx when width is zero");
    }

    @Test
    @DisplayName("Transform with target bounds having zero height should create GradientPaint with zero height")
    void transform_zero_height_target() {
        DirectionalGradientPaintTransformer transformer = new DirectionalGradientPaintTransformer();
        GradientPaint paint = new GradientPaint(0, 0, Color.RED, 10, 10, Color.BLUE, false);
        Shape target = new Rectangle2D.Float(5, 5, 10, 0);
        GradientPaint result = transformer.transform(paint, target);
        assertEquals(5f, result.getPoint2().getY(), "ry2 should be equal to by when height is zero");
    }
}