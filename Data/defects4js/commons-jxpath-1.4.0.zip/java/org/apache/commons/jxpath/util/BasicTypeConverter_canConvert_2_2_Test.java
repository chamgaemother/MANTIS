package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.commons.jxpath.util.BasicTypeConverter;
import org.apache.commons.jxpath.Pointer;

import java.util.Arrays;
import java.util.Collection;

public class BasicTypeConverter_canConvert_2_2_Test {

    @Test
    @DisplayName("object is String with empty value and useType is Character, should return true")
    public void testTC39() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object object = "";
        Class<?> toType = Character.class;

        // WHEN
        boolean result = converter.canConvert(object, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true when converting empty String to Character");
    }

    @Test
    @DisplayName("object is Collection with first element non-convertible and useType is Boolean, should return false")
    public void testTC40() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Collection<Object> collection = Arrays.asList("notaboolean", "true");
        Class<?> toType = Boolean.class;

        // WHEN
        boolean result = converter.canConvert(collection, toType);

        // THEN
        assertFalse(result, "Expected canConvert to return false when first element in Collection is non-convertible to Boolean");
    }

    @Test
    @DisplayName("object is array with one element convertible to useType array, should return true")
    public void testTC41() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object object = new Integer[]{5};
        Class<?> toType = Number[].class;

        // WHEN
        boolean result = converter.canConvert(object, toType);

        // THEN
        assertTrue(result, "Expected canConvert to return true when array has one convertible element");
    }

    @Test
    @DisplayName("object is String and useType is non-supported type, should return false")
    public void testTC42() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object object = "unsupported";
        Class<?> toType = CustomType.class;

        // WHEN
        boolean result = converter.canConvert(object, toType);

        // THEN
        assertFalse(result, "Expected canConvert to return false when converting String to unsupported type");
    }

    @Test
    @DisplayName("object is Pointer with non-convertible value and useType is Integer, should return false")
    public void testTC43() throws Exception {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        // Instantiate Pointer via reflection
        Pointer pointer = (Pointer) Class.forName("org.apache.commons.jxpath.util.BasicTypeConverter$ValuePointer")
                .getConstructor(Object.class)
                .newInstance(new Object());
        Class<?> toType = Integer.class;

        // WHEN
        boolean result = converter.canConvert(pointer, toType);

        // THEN
        assertFalse(result, "Expected canConvert to return false when Pointer value is non-convertible to Integer");
    }

    // Define CustomType as a dummy class
    static class CustomType {
        // empty
    }
}