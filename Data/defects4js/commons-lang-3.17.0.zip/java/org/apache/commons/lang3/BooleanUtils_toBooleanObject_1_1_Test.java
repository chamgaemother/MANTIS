package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.apache.commons.lang3.BooleanUtils;

public class BooleanUtils_toBooleanObject_1_1_Test {

    @Test
    @DisplayName("Input value is 0, returns Boolean.FALSE")
    void TC40_toBooleanObject_with_value_0_returns_False() {
        // GIVEN
        int value = 0;

        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(value);

        // THEN
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input value is 0 via expression, returns Boolean.FALSE")
    void TC41_toBooleanObject_with_calculation_equals_0_returns_False() {
        // GIVEN
        int value = -1 + 1;

        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(value);

        // THEN
        assertEquals(Boolean.FALSE, result);
    }

    @Test
    @DisplayName("Input value is 1, returns Boolean.TRUE")
    void TC42_toBooleanObject_with_value_1_returns_True() {
        // GIVEN
        int value = 1;

        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(value);

        // THEN
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    @DisplayName("Input value is Integer.MAX_VALUE, returns Boolean.TRUE")
    void TC43_toBooleanObject_with_value_Integer_MAX_VALUE_returns_True() {
        // GIVEN
        int value = Integer.MAX_VALUE;

        // WHEN
        Boolean result = BooleanUtils.toBooleanObject(value);

        // THEN
        assertEquals(Boolean.TRUE, result);
    }
}