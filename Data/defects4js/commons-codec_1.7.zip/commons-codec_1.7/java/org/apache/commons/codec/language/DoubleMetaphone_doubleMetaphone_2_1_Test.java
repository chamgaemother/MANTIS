package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.apache.commons.codec.language.DoubleMetaphone;

/**
 * JUnit 5 test class for DoubleMetaphone.doubleMetaphone method based on enhanced scenarios.
 */
public class DoubleMetaphone_doubleMetaphone_2_1_Test {

    @Test
    @DisplayName("doubleMetaphone(\"ACCIENT\", false) handles 'CC' followed by 'I'")
    public void TC51_doubleMetaphone_ACCIENT_CC_I() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "ACCIENT";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        assertEquals("AXSNT", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"BACHER\", false) handles 'CH' after 'B'")
    public void TC52_doubleMetaphone_BACHER_CH_After_B() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "BACHER";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        assertEquals("BKSR", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"EDGE\", false) handles 'DG' followed by 'E'")
    public void TC53_doubleMetaphone_EDGE_DG_E() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "EDGE";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        assertEquals("DJ", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"GHASTLY\", false) handles 'GH' after a consonant'")
    public void TC54_doubleMetaphone_GHASTLY_GH_After_Consonant() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "GHASTLY";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        assertEquals("KASTL", result);
    }

    @Test
    @DisplayName("doubleMetaphone(\"CIVIL\", false) handles 'CI' followed by 'V'")
    public void TC55_doubleMetaphone_CIVIL_CI_V() throws Exception {
        // GIVEN
        DoubleMetaphone encoder = new DoubleMetaphone();
        String input = "CIVIL";
        
        // WHEN
        String result = encoder.doubleMetaphone(input, false);
        
        // THEN
        assertEquals("SFL", result);
    }
}