package org.apache.commons.math3.optim.nonlinear.scalar.noderiv;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;
import java.util.Arrays;

import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.optim.PointValuePair;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.function.Executable;

class NelderMeadSimplexTest {

    private NelderMeadSimplex simplex;
    private MultivariateFunction evaluationFunction;
    private Comparator<PointValuePair> comparator;

    @BeforeEach
    void setUp() {
        simplex = new NelderMeadSimplex(2);
        evaluationFunction = point -> Arrays.stream(point).sum();
        comparator = Comparator.comparingDouble(PointValuePair::getValue);
    }

    @Test
    void testIterate_NullEvaluationFunction() {
        assertThrows(NullPointerException.class, () -> {
            simplex.iterate(null, comparator);
        });
    }

    @Test
    void testIterate_NullComparator() {
        assertThrows(NullPointerException.class, () -> {
            simplex.iterate(evaluationFunction, null);
        });
    }

    @Test
    void testIterate_ReflectAccepted() {
        comparator = new Comparator<PointValuePair>() {
            @Override
            public int compare(PointValuePair o1, PointValuePair o2) {
                return Double.compare(o1.getValue(), o2.getValue());
            }
        };
        simplex.iterate(evaluationFunction, comparator);
        // Verify that the worst point is replaced
        PointValuePair worst = simplex.getPoint(simplex.getSize() - 1);
        assertNotNull(worst.getValue());
    }

    @Test
    void testIterate_ExpandAccepted() {
        comparator = new Comparator<PointValuePair>() {
            @Override
            public int compare(PointValuePair o1, PointValuePair o2) {
                if (o1 == reflectedPair) return -1;
                if (o1 == expandedPair) return -1;
                return Double.compare(o1.getValue(), o2.getValue());
            }

            PointValuePair reflectedPair = new PointValuePair(new double[]{2, 2}, 1.5, false);
            PointValuePair expandedPair = new PointValuePair(new double[]{3, 3}, 1.0, false);
        };
        simplex.iterate(evaluationFunction, comparator);
        // Verify that the expansion point is accepted
        PointValuePair best = simplex.getPoint(0);
        assertEquals(1.0, best.getValue());
    }

    @Test
    void testIterate_ReflectRejected_ExpandRejected_AcceptReflected() {
        comparator = new Comparator<PointValuePair>() {
            @Override
            public int compare(PointValuePair o1, PointValuePair o2) {
                // Define comparison logic to reject expansion and accept reflection
                if (o1.getValue() < 0) return -1;
                return Double.compare(o1.getValue(), o2.getValue());
            }
        };
        simplex.iterate(evaluationFunction, comparator);
        // Verify that reflected point is accepted
        PointValuePair worst = simplex.getPoint(simplex.getSize() - 1);
        assertTrue(worst.getValue() >= 0);
    }

    @Test
    void testIterate_OutsideContractionAccepted() {
        comparator = new Comparator<PointValuePair>() {
            @Override
            public int compare(PointValuePair o1, PointValuePair o2) {
                if (o1.getValue() < 2) return -1;
                return Double.compare(o1.getValue(), o2.getValue());
            }
        };
        simplex.iterate(evaluationFunction, comparator);
        // Verify that contraction point is accepted
        PointValuePair worst = simplex.getPoint(simplex.getSize() - 1);
        assertTrue(worst.getValue() < 2);
    }

    @Test
    void testIterate_InsideContractionAccepted() {
        comparator = new Comparator<PointValuePair>() {
            @Override
            public int compare(PointValuePair o1, PointValuePair o2) {
                if (o1.getValue() < 1) return -1;
                return Double.compare(o1.getValue(), o2.getValue());
            }
        };
        simplex.iterate(evaluationFunction, comparator);
        // Verify that contraction point is accepted
        PointValuePair worst = simplex.getPoint(simplex.getSize() - 1);
        assertTrue(worst.getValue() < 1);
    }

    @Test
    void testIterate_ShrinkPerformed() {
        comparator = new Comparator<PointValuePair>() {
            @Override
            public int compare(PointValuePair o1, PointValuePair o2) {
                return 1; // Always reject reflection, expansion, and contraction
            }
        };
        simplex.iterate(evaluationFunction, comparator);
        // Verify that shrink was performed
        PointValuePair secondPoint = simplex.getPoint(1);
        PointValuePair firstPoint = simplex.getPoint(0);
        assertEquals(firstPoint.getPoint(), secondPoint.getPoint());
    }

    @Test
    void testIterate_BoundaryCondition_ReflectionEqualToBest() {
        comparator = new Comparator<PointValuePair>() {
            @Override
            public int compare(PointValuePair o1, PointValuePair o2) {
                // Reflection equals best
                if (o1 == o2) return 0;
                return Double.compare(o1.getValue(), o2.getValue());
            }
        };
        simplex.iterate(evaluationFunction, comparator);
        // Verify that reflection is accepted
        PointValuePair worst = simplex.getPoint(simplex.getSize() - 1);
        assertNotNull(worst.getValue());
    }

    @Test
    void testIterate_SimplexDimensionOne() {
        simplex = new NelderMeadSimplex(1);
        simplex.iterate(evaluationFunction, comparator);
        // Verify that simplex still has correct size
        assertEquals(2, simplex.getSize());
    }

    @Test
    void testIterate_SinglePointSimplex() {
        simplex = new NelderMeadSimplex(new double[]{1.0, 1.0});
        assertThrows(org.apache.commons.math3.exception.DimensionMismatchException.class, () -> {
            simplex.iterate(evaluationFunction, comparator);
        });
    }

    @Test
    void testIterate_ZeroStepsInSimplex() {
        assertThrows(IllegalArgumentException.class, () -> {
            new NelderMeadSimplex(new double[]{0.0, 1.0});
        });
    }

    @Test
    void testIterate_ComparatorThrowsException() {
        comparator = (o1, o2) -> {
            throw new RuntimeException("Comparator error");
        };
        assertThrows(RuntimeException.class, () -> {
            simplex.iterate(evaluationFunction, comparator);
        });
    }

    @Test
    void testIterate_EvaluationFunctionThrowsException() {
        evaluationFunction = point -> {
            throw new RuntimeException("Evaluation error");
        };
        assertThrows(RuntimeException.class, () -> {
            simplex.iterate(evaluationFunction, comparator);
        });
    }

    @Test
    void testIterate_AllPathsCovered() {
        // This test is to ensure all branches are covered through multiple iterations
        for (int i = 0; i < 10; i++) {
            simplex.iterate(evaluationFunction, comparator);
        }
        // No assertions, just ensuring no exceptions and all paths are executed
    }
}