package org.apache.commons.compress.archivers.tar;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

public class TarArchiveOutputStream_putArchiveEntry_2_1_Test {

//     @Test
//     @DisplayName("Adding an entry with non-ASCII name when addPaxHeadersForNonAsciiNames is disabled, expecting no PAX headers")
//     public void TC40_AddingEntryWithNonASCIIName_PaxHeadersDisabled() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setAddPaxHeadersForNonAsciiNames(false);
//         TarArchiveEntry entry = new TarArchiveEntry("nÃÂ¤me", 0L); // The size must be specified
// 
        // Act
//         tarOut.putArchiveEntry(entry);
//         tarOut.closeArchiveEntry();
//         tarOut.close();
// 
        // Assert
//         ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
//         TarArchiveInputStream tarIn = new TarArchiveInputStream(bais);
//         TarArchiveEntry readEntry1 = tarIn.getNextTarEntry();
//         assertNotNull(readEntry1, "First entry should be the main entry");
//         assertEquals("nÃÂ¤me", readEntry1.getName(), "Entry name should match");
//         TarArchiveEntry readEntry2 = tarIn.getNextTarEntry();
//         assertNull(readEntry2, "No PAX headers should be present");
//     }

//     @Test
//     @DisplayName("Adding an entry with non-ASCII name when addPaxHeadersForNonAsciiNames is enabled, expecting PAX headers")
//     public void TC41_AddingEntryWithNonASCIIName_PaxHeadersEnabled() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setAddPaxHeadersForNonAsciiNames(true);
//         TarArchiveEntry entry = new TarArchiveEntry("nÃÂ¤me", 0L); // The size must be specified
// 
        // Act
//         tarOut.putArchiveEntry(entry);
//         tarOut.closeArchiveEntry();
//         tarOut.close();
// 
        // Assert
//         ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
//         TarArchiveInputStream tarIn = new TarArchiveInputStream(bais);
//         TarArchiveEntry paxHeader = tarIn.getNextTarEntry();
//         assertNotNull(paxHeader, "First entry should be the PAX header");
        // Check if the first entry is correctly identified as a PAX header
//         assertEquals("./PaxHeaders.X/nÃÂ¤me", paxHeader.getName(), "PAX header should be for the non-ASCII entry");
//         TarArchiveEntry readEntry = tarIn.getNextTarEntry();
//         assertNotNull(readEntry, "Second entry should be the main entry");
//         assertEquals("nÃÂ¤me", readEntry.getName(), "Entry name should match");
//         TarArchiveEntry noFurtherEntry = tarIn.getNextTarEntry();
//         assertNull(noFurtherEntry, "No additional entries should be present");
//     }

//     @Test
//     @DisplayName("Adding an entry with a long name when longFileMode is set to LONGFILE_POSIX, expecting PAX headers")
//     public void TC42_AddingEntryWithLongName_LongFileModePOSIX() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);
//         StringBuilder longNameBuilder = new StringBuilder();
//         for(int i = 0; i < 300; i++) {
//             longNameBuilder.append("a");
//         }
//         String longName = longNameBuilder.toString();
//         TarArchiveEntry entry = new TarArchiveEntry(longName, 0L); // The size must be specified
// 
        // Act
//         tarOut.putArchiveEntry(entry);
//         tarOut.closeArchiveEntry();
//         tarOut.close();
// 
        // Assert
//         ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
//         TarArchiveInputStream tarIn = new TarArchiveInputStream(bais);
//         TarArchiveEntry paxHeader = tarIn.getNextTarEntry();
//         assertNotNull(paxHeader, "First entry should be the PAX header");
        // Check if the first entry is correctly identified as a PAX header
//         assertEquals("./PaxHeaders.X/" + longName, paxHeader.getName(), "PAX header should be for the long entry");
//         TarArchiveEntry readEntry = tarIn.getNextTarEntry();
//         assertNotNull(readEntry, "Second entry should be the main entry");
//         assertEquals(longName, readEntry.getName(), "Entry name should match the long name");
//         TarArchiveEntry noFurtherEntry = tarIn.getNextTarEntry();
//         assertNull(noFurtherEntry, "No additional entries should be present");
//     }

//     @Test
//     @DisplayName("Adding an entry with a long name when longFileMode is set to LONGFILE_GNU, expecting GNU longlink entry")
//     public void TC43_AddingEntryWithLongName_LongFileModeGNU() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
//         StringBuilder longNameBuilder = new StringBuilder();
//         for(int i = 0; i < 300; i++) {
//             longNameBuilder.append("b");
//         }
//         String longName = longNameBuilder.toString();
//         TarArchiveEntry entry = new TarArchiveEntry(longName, 0L); // The size must be specified
// 
        // Act
//         tarOut.putArchiveEntry(entry);
//         tarOut.closeArchiveEntry();
//         tarOut.close();
// 
        // Assert
//         ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
//         TarArchiveInputStream tarIn = new TarArchiveInputStream(bais);
//         TarArchiveEntry gnuLongLink = tarIn.getNextTarEntry();
//         assertNotNull(gnuLongLink, "First entry should be the GNU longlink entry");
//         assertEquals(TarConstants.GNU_LONGLINK, gnuLongLink.getName(), "First entry should be the GNU longlink entry");
//         TarArchiveEntry readEntry = tarIn.getNextTarEntry();
//         assertNotNull(readEntry, "Second entry should be the main entry");
//         assertEquals(longName, readEntry.getName(), "Entry name should match the long name");
//         TarArchiveEntry noFurtherEntry = tarIn.getNextTarEntry();
//         assertNull(noFurtherEntry, "No additional entries should be present");
//     }

//     @Test
//     @DisplayName("Adding an entry with a long name when longFileMode is set to LONGFILE_TRUNCATE, expecting the name is truncated without exception")
//     public void TC44_AddingEntryWithLongName_LongFileModeTruncate() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);
//         StringBuilder longNameBuilder = new StringBuilder();
//         for(int i = 0; i < 300; i++) {
//             longNameBuilder.append("c");
//         }
//         String longName = longNameBuilder.toString();
//         TarArchiveEntry entry = new TarArchiveEntry(longName, 0L); // The size must be specified
// 
        // Act
//         tarOut.putArchiveEntry(entry);
//         tarOut.closeArchiveEntry();
//         tarOut.close();
// 
        // Assert
//         ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
//         TarArchiveInputStream tarIn = new TarArchiveInputStream(bais);
//         TarArchiveEntry readEntry = tarIn.getNextTarEntry();
//         assertNotNull(readEntry, "Entry should be present in the archive");
//         String truncatedName = longName.substring(0, Math.min(longName.length(), TarConstants.NAMELEN));
//         assertEquals(truncatedName, readEntry.getName(), "Entry name should be truncated correctly");
//         TarArchiveEntry noFurtherEntry = tarIn.getNextTarEntry();
//         assertNull(noFurtherEntry, "No additional entries should be present");
//     }

}