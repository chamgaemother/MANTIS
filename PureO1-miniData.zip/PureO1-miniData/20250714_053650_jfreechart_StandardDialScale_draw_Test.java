import static org.mockito.Mockito.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class StandardDialScaleTest {

    private StandardDialScale scale;
    private Graphics2D g2;
    private DialPlot plot;
    private Rectangle2D frame;
    private Rectangle2D view;

    @BeforeEach
    void setUp() {
        scale = new StandardDialScale(0.0, 100.0, 175.0, -170.0, 10.0, 4);
        g2 = mock(Graphics2D.class);
        plot = mock(DialPlot.class);
        frame = new Rectangle2D.Double(0, 0, 200, 200);
        view = new Rectangle2D.Double(0, 0, 200, 200);
    }

    @Test
    void testDraw_TickLabelsVisible_FirstTickLabelVisible() {
        scale.setTickLabelsVisible(true);
        scale.setFirstTickLabelVisible(true);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeastOnce()).draw(any());
        verify(g2, atLeastOnce()).setPaint(any(Color.class));
        verify(g2, atLeastOnce()).setFont(any(Font.class));
    }

    @Test
    void testDraw_TickLabelsVisible_FirstTickLabelNotVisible() {
        scale.setTickLabelsVisible(true);
        scale.setFirstTickLabelVisible(false);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeastOnce()).draw(any());
        verify(g2, atLeastOnce()).setPaint(any(Color.class));
        verify(g2, atLeastOnce()).setFont(any(Font.class));
    }

    @Test
    void testDraw_TickLabelsNotVisible() {
        scale.setTickLabelsVisible(false);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeastOnce()).draw(any());
        verify(g2, never()).setFont(any(Font.class));
        verify(g2, never()).setPaint(any(Color.class));
    }

    @Test
    void testDraw_MinorTicksEnabled() {
        scale.setMinorTickCount(3);
        scale.setMinorTickLength(0.02);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeast(2)).draw(any());
    }

    @Test
    void testDraw_MinorTicksDisabled_MinorTickCountZero() {
        scale.setMinorTickCount(0);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeastOnce()).draw(any());
        // Ensure minor ticks are not drawn
        verify(g2, atMost(scale.getMajorTickIncrement() > 0 ? 10 : 0)).draw(any());
    }

    @Test
    void testDraw_MinorTicksDisabled_MinorTickLengthZero() {
        scale.setMinorTickCount(4);
        scale.setMinorTickLength(0.0);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeastOnce()).draw(any());
        // Ensure minor ticks are not drawn
        verify(g2, atMost(scale.getMajorTickIncrement() > 0 ? 10 : 0)).draw(any());
    }

    @Test
    void testDraw_V_ValueEqualsUpperBound() {
        scale = new StandardDialScale(0.0, 100.0, 0.0, 360.0, 25.0, 0);
        scale.draw(g2, plot, frame, view);
        // Expecting 4 major ticks: 0,25,50,75,100
        verify(g2, atLeast(5)).draw(any());
    }

    @Test
    void testDraw_V_ValueGreaterThanUpperBound() {
        scale = new StandardDialScale(0.0, 100.0, 0.0, 360.0, 30.0, 2);
        scale.draw(g2, plot, frame, view);
        // Ticks at 0,30,60,90
        verify(g2, atLeast(4)).draw(any());
    }

    @Test
    void testDraw_NoMajorTicks() {
        scale = new StandardDialScale(50.0, 50.0, 0.0, 360.0, 10.0, 0);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeastOnce()).draw(any());
    }

    @Test
    void testDraw_NullGraphics() {
        try {
            scale.draw(null, plot, frame, view);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    void testDraw_NullDialPlot() {
        try {
            scale.draw(g2, null, frame, view);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    void testDraw_NullFrame() {
        try {
            scale.draw(g2, plot, null, view);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    void testDraw_NullView() {
        try {
            scale.draw(g2, plot, frame, null);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    void testDraw_MinorTickBreakWhenVvGreaterThanUpperBound() {
        scale = new StandardDialScale(0.0, 10.0, 0.0, 360.0, 5.0, 2);
        scale.draw(g2, plot, frame, view);
        // Minor ticks for v=0: vv= 0 + 5/3 ≈1.666, 0 + 10/3≈3.333
        // For v=5: vv= 5 + 5/3≈6.666, 5 +10/3≈8.333
        // For v=10: vv=10 +5/3=11.666 >=10, should break
        verify(g2, atLeast(4)).draw(any());
    }

    @Test
    void testDraw_AllBranches() {
        scale.setTickLabelsVisible(true);
        scale.setFirstTickLabelVisible(false);
        scale.setMinorTickCount(2);
        scale.setMinorTickLength(0.02);
        scale.draw(g2, plot, frame, view);
        verify(g2, atLeastOnce()).draw(any());
        verify(g2, atLeastOnce()).setPaint(any());
        verify(g2, atLeastOnce()).setStroke(any(Stroke.class));
    }
}