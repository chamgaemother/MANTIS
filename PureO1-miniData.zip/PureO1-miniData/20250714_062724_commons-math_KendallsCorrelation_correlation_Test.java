package org.apache.commons.math3.stat.correlation;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.MethodSource;

import static org.junit.jupiter.api.Assertions.*;

class KendallsCorrelationTest {

    @Test
    void correlation_NullXArray_ThrowsNullPointerException() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] y = {1.0, 2.0};
        assertThrows(NullPointerException.class, () -> kc.correlation(null, y));
    }

    @Test
    void correlation_NullYArray_ThrowsNullPointerException() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 2.0};
        assertThrows(NullPointerException.class, () -> kc.correlation(x, null));
    }

    @Test
    void correlation_DifferentLengths_ThrowsDimensionMismatchException() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 2.0, 3.0};
        double[] y = {1.0, 2.0};
        assertThrows(DimensionMismatchException.class, () -> kc.correlation(x, y));
    }

    @Test
    void correlation_EmptyArrays_ReturnNaN() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {};
        double[] y = {};
        double result = kc.correlation(x, y);
        assertTrue(Double.isNaN(result));
    }

    @Test
    void correlation_SingleElementArrays_ReturnNaN() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0};
        double[] y = {2.0};
        double result = kc.correlation(x, y);
        assertTrue(Double.isNaN(result));
    }

    @Test
    void correlation_AllTies_ReturnNaN() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 1.0, 1.0};
        double[] y = {2.0, 2.0, 2.0};
        double result = kc.correlation(x, y);
        assertTrue(Double.isNaN(result));
    }

    @Test
    void correlation_AllConcordant_ReturnOne() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 2.0, 3.0, 4.0};
        double[] y = {2.0, 3.0, 4.0, 5.0};
        double result = kc.correlation(x, y);
        assertEquals(1.0, result, 1e-10);
    }

    @Test
    void correlation_AllDiscordant_ReturnMinusOne() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {4.0, 3.0, 2.0, 1.0};
        double[] y = {5.0, 4.0, 3.0, 2.0};
        double result = kc.correlation(x, y);
        assertEquals(-1.0, result, 1e-10);
    }

    @Test
    void correlation_WithTiesInX_CorrectCorrelation() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 1.0, 2.0, 3.0};
        double[] y = {1.0, 2.0, 3.0, 4.0};
        double result = kc.correlation(x, y);
        assertEquals(0.8, result, 1e-10);
    }

    @Test
    void correlation_WithTiesInY_CorrectCorrelation() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 2.0, 3.0, 4.0};
        double[] y = {2.0, 2.0, 3.0, 4.0};
        double result = kc.correlation(x, y);
        assertEquals(0.8, result, 1e-10);
    }

    @Test
    void correlation_WithTiesInBothXAndY_CorrectCorrelation() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 1.0, 2.0, 2.0};
        double[] y = {1.0, 2.0, 1.0, 2.0};
        double result = kc.correlation(x, y);
        assertEquals(0.0, result, 1e-10);
    }

    @Test
    void correlation_NormalCase_PositiveCorrelation() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {12, 2, 1, 12, 2};
        double[] y = {1, 4, 7, 1, 0};
        double result = kc.correlation(x, y);
        assertEquals(0.0, result, 1e-10);
    }

    @Test
    void correlation_NormalCase_MixedCorrelation() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {43, 21, 25, 42, 57, 59};
        double[] y = {99, 65, 79, 75, 87, 81};
        double result = kc.correlation(x, y);
        assertEquals(0.5298, result, 1e-4);
    }

    @Test
    void correlation_LargeDataset_CorrectCorrelation() {
        KendallsCorrelation kc = new KendallsCorrelation();
        int size = 1000;
        double[] x = new double[size];
        double[] y = new double[size];
        for (int i = 0; i < size; i++) {
            x[i] = i;
            y[i] = size - i;
        }
        double result = kc.correlation(x, y);
        assertEquals(-1.0, result, 1e-10);
    }

    @Test
    void correlation_WithDuplicatePairs_CorrectCorrelation() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1.0, 1.0, 2.0, 2.0};
        double[] y = {1.0, 1.0, 2.0, 2.0};
        double result = kc.correlation(x, y);
        assertTrue(Double.isNaN(result));
    }

    @Test
    void correlation_WithAllPossibleCases() {
        KendallsCorrelation kc = new KendallsCorrelation();
        double[] x = {1, 2, 2, 3, 4};
        double[] y = {5, 6, 6, 7, 8};
        double result = kc.correlation(x, y);
        assertEquals(1.0, result, 1e-10);
    }
}