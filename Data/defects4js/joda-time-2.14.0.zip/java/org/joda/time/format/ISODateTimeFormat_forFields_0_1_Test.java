package org.joda.time.format;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.DateTimeFieldType;

import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;

public class ISODateTimeFormat_forFields_0_1_Test {

    @Test
    @DisplayName("Test when fields parameter is null (r0 == null), expecting IllegalArgumentException")
    void TC01_nullFieldsThrowsIllegalArgumentException() {
        Collection<DateTimeFieldType> fields = null;
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            ISODateTimeFormat.forFields(fields, true, true);
        }, "The fields must not be null or empty");
    }

    @Test
    @DisplayName("Test when fields collection is empty (fields.size() == 0), expecting IllegalArgumentException")
    void TC02_emptyFieldsThrowsIllegalArgumentException() {
        Collection<DateTimeFieldType> fields = new ArrayList<>();
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            ISODateTimeFormat.forFields(fields, true, true);
        }, "The fields must not be null or empty");
    }

    @Test
    @DisplayName("Test with fields containing monthOfYear and year (workingFields.contains(monthOfYear) == true), expecting YYYY-MM format")
    void TC03_fieldsMonthOfYearYearReturnsYYYYMM() {
        Collection<DateTimeFieldType> fields = Arrays.asList(
            DateTimeFieldType.monthOfYear(),
            DateTimeFieldType.year()
        );
        boolean extended = true;
        boolean strictISO = true;
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        Assertions.assertEquals("YYYY-MM", formatter.toString());
    }

    @Test
    @DisplayName("Test with fields containing dayOfYear and year (workingFields.contains(dayOfYear) == true), expecting YYYY-DDD format")
    void TC04_fieldsDayOfYearYearReturnsYYYYDDD() {
        Collection<DateTimeFieldType> fields = Arrays.asList(
            DateTimeFieldType.dayOfYear(),
            DateTimeFieldType.year()
        );
        boolean extended = true;
        boolean strictISO = true;
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        Assertions.assertEquals("YYYY-DDD", formatter.toString());
    }

    @Test
    @DisplayName("Test with fields containing weekOfWeekyear, weekyear, and dayOfWeek (workingFields.contains(weekOfWeekyear) == true), expecting YYYY-WWW-D format")
    void TC05_fieldsWeekOfWeekyearWeekyearDayOfWeekReturnsYYYYWWWD() {
        Collection<DateTimeFieldType> fields = Arrays.asList(
            DateTimeFieldType.weekOfWeekyear(),
            DateTimeFieldType.weekyear(),
            DateTimeFieldType.dayOfWeek()
        );
        boolean extended = true;
        boolean strictISO = true;
        DateTimeFormatter formatter = ISODateTimeFormat.forFields(fields, extended, strictISO);
        Assertions.assertEquals("YYYY-WWW-D", formatter.toString());
    }
}