package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class IntList_add_2_1_Test {

    @Test
    @DisplayName("Add an object when the internal array has available space without triggering a growth")
    public void testAddWithSpace() throws Exception {
        // Initialize IntList with capacity 10 and add 5 elements
        IntList list = new IntList(10);
        for(int i = 0; i < 5; i++) {
            list.add(i);
        }

        // Perform the add operation
        boolean result = list.add(100);

        // Assertions
        assertTrue(result, "Method should return true");
        assertEquals(6, list.size(), "Size should be 6 after addition");
        assertEquals(100, list.get(5), "Element at index 5 should be 100");
    }

    @Test
    @DisplayName("Add an object when the internal array is full, triggering growAtEnd")
    public void testAddWithArrayFull() throws Exception {
        // Initialize IntList with capacity 5 and add 5 elements
        IntList list = new IntList(5);
        for(int i = 0; i < 5; i++) {
            list.add(i);
        }

        // Capture original array length via reflection
        Field arrayField = IntList.class.getDeclaredField("array");
        arrayField.setAccessible(true);
        int[] originalArray = (int[]) arrayField.get(list);
        int originalLength = originalArray.length;

        // Perform the add operation
        boolean result = list.add(200);

        // Capture new array length via reflection
        int[] newArray = (int[]) arrayField.get(list);
        int newLength = newArray.length;

        // Assertions
        assertTrue(result, "Method should return true");
        assertEquals(6, list.size(), "Size should be 6 after addition");
        assertEquals(200, list.get(5), "Element at index 5 should be 200");
        assertTrue(newLength > originalLength, "Internal array should have grown");
    }
}