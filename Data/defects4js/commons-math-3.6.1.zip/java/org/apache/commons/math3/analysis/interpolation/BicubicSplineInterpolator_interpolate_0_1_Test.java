package org.apache.commons.math3.analysis.interpolation;

import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolator;
import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class BicubicSplineInterpolator_interpolate_0_1_Test {

    @Test
    @DisplayName("Interpolate with valid non-empty xval, yval, and fval arrays of matching lengths")
    public void TC01() {
        // Given
        double[] xval = {1.0, 2.0, 3.0};
        double[] yval = {4.0, 5.0, 6.0};
        double[][] fval = {
            {7.0, 8.0, 9.0},
            {10.0, 11.0, 12.0},
            {13.0, 14.0, 15.0}
        };

        // When
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        BicubicSplineInterpolatingFunction result = interpolator.interpolate(xval, yval, fval);

        // Then
        assertNotNull(result, "The result should not be null");
    }

    @Test
    @DisplayName("Interpolate with empty xval array, expecting NoDataException")
    public void TC02() {
        // Given
        double[] xval = {};
        double[] yval = {1.0};
        double[][] fval = {{2.0}};

        // When & Then
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        }, "Expected NoDataException to be thrown");
    }

    @Test
    @DisplayName("Interpolate with empty yval array, expecting NoDataException")
    public void TC03() {
        // Given
        double[] xval = {1.0};
        double[] yval = {};
        double[][] fval = {{2.0}};

        // When & Then
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        }, "Expected NoDataException to be thrown");
    }

    @Test
    @DisplayName("Interpolate with empty fval array, expecting NoDataException")
    public void TC04() {
        // Given
        double[] xval = {1.0};
        double[] yval = {2.0};
        double[][] fval = {};

        // When & Then
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        }, "Expected NoDataException to be thrown");
    }

    @Test
    @DisplayName("Interpolate with xval and fval lengths mismatch, expecting DimensionMismatchException")
    public void TC05() {
        // Given
        double[] xval = {1.0, 2.0};
        double[] yval = {3.0};
        double[][] fval = {{4.0}};

        // When & Then
        BicubicSplineInterpolator interpolator = new BicubicSplineInterpolator();
        assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        }, "Expected DimensionMismatchException to be thrown");
    }
}