package org.joda.time.format;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.io.IOException;
import org.joda.time.format.FormatUtils;

public class FormatUtils_appendPaddedInteger_0_1_Test {

    @Test
    @DisplayName("Append single-digit positive integer with size equal to 1, expecting no padding")
    void TC01() throws IOException {
        Appendable appendable = new StringBuilder();
        int value = 5;
        int size = 1;
        FormatUtils.appendPaddedInteger(appendable, value, size);
        assertEquals("5", appendable.toString());
    }

    @Test
    @DisplayName("Append single-digit positive integer with size greater than 1, expecting leading zeros")
    void TC02() throws IOException {
        Appendable appendable = new StringBuilder();
        int value = 7;
        int size = 3;
        FormatUtils.appendPaddedInteger(appendable, value, size);
        assertEquals("007", appendable.toString());
    }

    @Test
    @DisplayName("Append two-digit positive integer with size equal to 2, expecting no padding")
    void TC03() throws IOException {
        Appendable appendable = new StringBuilder();
        int value = 42;
        int size = 2;
        FormatUtils.appendPaddedInteger(appendable, value, size);
        assertEquals("42", appendable.toString());
    }

    @Test
    @DisplayName("Append two-digit positive integer with size greater than 2, expecting leading zeros")
    void TC04() throws IOException {
        Appendable appendable = new StringBuilder();
        int value = 85;
        int size = 4;
        FormatUtils.appendPaddedInteger(appendable, value, size);
        assertEquals("0085", appendable.toString());
    }

    @Test
    @DisplayName("Append three-digit positive integer with size equal to 3, expecting no padding")
    void TC05() throws IOException {
        Appendable appendable = new StringBuilder();
        int value = 256;
        int size = 3;
        FormatUtils.appendPaddedInteger(appendable, value, size);
        assertEquals("256", appendable.toString());
    }

}