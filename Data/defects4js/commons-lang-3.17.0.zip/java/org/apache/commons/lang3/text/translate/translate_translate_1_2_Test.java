package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

public class translate_translate_1_2_Test {

    @Test
    @DisplayName("translate method returns different consumed values when single translator returns non-zero")
    void TC06_translate_singleTranslator_variedOutput() throws IOException {
        // GIVEN
        CharSequenceTranslator stubTranslator = mock(CharSequenceTranslator.class);
        when(stubTranslator.translate(any(), anyInt(), any())).thenReturn(3);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator);
        CharSequence input = "Another translatable input";
        int index = 2;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(3, result);
    }

    @Test
    @DisplayName("translate method returns 0 when multiple translators all return 0")
    void TC07_translate_multipleTranslators_allZero() throws IOException {
        // GIVEN
        CharSequenceTranslator stubTranslator1 = mock(CharSequenceTranslator.class);
        CharSequenceTranslator stubTranslator2 = mock(CharSequenceTranslator.class);
        when(stubTranslator1.translate(any(), anyInt(), any())).thenReturn(0);
        when(stubTranslator2.translate(any(), anyInt(), any())).thenReturn(0);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator1, stubTranslator2);
        CharSequence input = "No translation needed";
        int index = 1;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("translate method returns consumed value when second translator returns non-zero after first returns 0")
    void TC08_translate_secondTranslator_nonZero_after_firstZero() throws IOException {
        // GIVEN
        CharSequenceTranslator stubTranslator1 = mock(CharSequenceTranslator.class);
        CharSequenceTranslator stubTranslator2 = mock(CharSequenceTranslator.class);
        when(stubTranslator1.translate(any(), anyInt(), any())).thenReturn(0);
        when(stubTranslator2.translate(any(), anyInt(), any())).thenReturn(4);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator1, stubTranslator2);
        CharSequence input = "Partial translation needed";
        int index = 3;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(4, result);
    }

    @Test
    @DisplayName("translate method returns consumed value when first translator returns non-zero in multiple translators")
    void TC09_translate_firstTranslator_nonZero_in_multipleTranslators() throws IOException {
        // GIVEN
        CharSequenceTranslator stubTranslator1 = mock(CharSequenceTranslator.class);
        CharSequenceTranslator stubTranslator2 = mock(CharSequenceTranslator.class);
        when(stubTranslator1.translate(any(), anyInt(), any())).thenReturn(6);
        when(stubTranslator2.translate(any(), anyInt(), any())).thenReturn(0);
        AggregateTranslator translator = new AggregateTranslator(stubTranslator1, stubTranslator2);
        CharSequence input = "Immediate translation needed";
        int index = 4;
        Writer out = new StringWriter();

        // WHEN
        int result = translator.translate(input, index, out);

        // THEN
        assertEquals(6, result);
    }
}