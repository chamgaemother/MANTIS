import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.renderer.category.BoxAndWhiskerCategoryDataset;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.*;

class BoxAndWhiskerRendererTest {

    private BoxAndWhiskerRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private BoxAndWhiskerCategoryDataset dataset;
    private int row;
    private int column;

    @BeforeEach
    void setUp() {
        renderer = new BoxAndWhiskerRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(BoxAndWhiskerCategoryDataset.class);
        row = 0;
        column = 0;

        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.BOTTOM);
        when(plot.getDomainAxis()).thenReturn(domainAxis);
        when(plot.getDataset()).thenReturn(dataset);
        when(state.getBarWidth()).thenReturn(10.0);
        when(state.getInfo()).thenReturn(null);
    }

    @Test
    void testDrawHorizontalItem_ItemNotVisible() {
        when(renderer.getItemVisible(row, column)).thenReturn(false);
        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
        verifyNoInteractions(g2);
    }

    @Test
    void testDrawHorizontalItem_InvalidDataset() {
        CategoryDataset invalidDataset = mock(CategoryDataset.class);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, invalidDataset, row, column);
        });
        assertTrue(exception.getMessage().contains("BoxAndWhiskerRenderer.drawItem()"));
    }

    @Test
    void testDrawHorizontalItem_SeriesCountGreaterThanOne_FillBoxAndUseOutlinePaintForWhiskers() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(2);
        when(renderer.getColumnCount()).thenReturn(2);
        when(renderer.getItemMargin()).thenReturn(0.2);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(renderer.isFillBox()).thenReturn(true);
        when(renderer.isUseOutlinePaintForWhiskers()).thenReturn(true);
        when(renderer.getItemPaint(row, column)).thenReturn(Color.BLUE);
        when(renderer.getItemStroke(row, column)).thenReturn(new java.awt.BasicStroke());
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(Color.RED);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(new java.awt.BasicStroke());

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2).setPaint(Color.BLUE);
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(Color.RED);
        verify(g2, times(5)).draw(any());
    }

    @Test
    void testDrawHorizontalItem_SeriesCountEqualOne_DoNotFillBoxAndDoNotUseOutlinePaintForWhiskers() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(2);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(renderer.isFillBox()).thenReturn(false);
        when(renderer.isUseOutlinePaintForWhiskers()).thenReturn(false);
        when(renderer.getItemPaint(row, column)).thenReturn(Color.GREEN);
        when(renderer.getItemStroke(row, column)).thenReturn(new java.awt.BasicStroke());
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(Color.ORANGE);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(new java.awt.BasicStroke());

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2).setPaint(Color.GREEN);
        verify(g2).setStroke(any(Stroke.class));
        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Line2D.class));
        verify(g2, never()).setPaint(Color.ORANGE);
    }

    @Test
    void testDrawHorizontalItem_FillBoxFalse() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(renderer.isFillBox()).thenReturn(false);
        when(renderer.isUseOutlinePaintForWhiskers()).thenReturn(false);
        when(renderer.getItemPaint(row, column)).thenReturn(Color.BLACK);
        when(renderer.getItemStroke(row, column)).thenReturn(new java.awt.BasicStroke());
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(Color.GRAY);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(new java.awt.BasicStroke());

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2, never()).fill(any(Rectangle2D.class));
        verify(g2).draw(any(Line2D.class));
    }

    @Test
    void testDrawHorizontalItem_BoxValuesNull() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(null);
        when(dataset.getQ3Value(row, column)).thenReturn(null);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(null);
        when(dataset.getMinRegularValue(row, column)).thenReturn(null);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawHorizontalItem_MeanVisible_MeanNull() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(renderer.isMeanVisible()).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(false);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(dataset.getMeanValue(row, column)).thenReturn(null);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawHorizontalItem_MeanVisible_MeanVisible() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(renderer.isMeanVisible()).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(false);
        when(renderer.getArtifactPaint()).thenReturn(Color.MAGENTA);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(dataset.getMeanValue(row, column)).thenReturn(70.0);
        when(dataArea.getMinX()).thenReturn(0.0);
        when(dataArea.getMaxX()).thenReturn(200.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2).setPaint(Color.MAGENTA);
        verify(g2).fill(any());
        verify(g2).draw(any());
    }

    @Test
    void testDrawHorizontalItem_MeanVisible_MeanNotInDataArea() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(renderer.isMeanVisible()).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(false);
        when(renderer.getArtifactPaint()).thenReturn(Color.MAGENTA);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(dataset.getMeanValue(row, column)).thenReturn(250.0);
        when(dataArea.getMinX()).thenReturn(0.0);
        when(dataArea.getMaxX()).thenReturn(200.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawHorizontalItem_MedianVisible_MedianNull() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(true);
        when(renderer.isMeanVisible()).thenReturn(false);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(dataset.getMedianValue(row, column)).thenReturn(null);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2, never()).draw(any(Line2D.class));
    }

    @Test
    void testDrawHorizontalItem_MedianVisible_MedianVisible() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(true);
        when(renderer.isMeanVisible()).thenReturn(false);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);
        when(dataset.getMedianValue(row, column)).thenReturn(70.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2).draw(any(Line2D.class));
    }

    @Test
    void testDrawHorizontalItem_EntityCollectionNull() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(false);
        when(renderer.isMeanVisible()).thenReturn(false);
        when(state.getInfo()).thenReturn(new org.jfree.chart.plot.PlotRenderingInfo(null));
        when(state.getEntityCollection()).thenReturn(null);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(renderer, never()).addItemEntity(any(), any(), anyInt(), anyInt(), any());
    }

    @Test
    void testDrawHorizontalItem_EntityCollectionVisible() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(false);
        when(renderer.isMeanVisible()).thenReturn(false);
        EntityCollection entities = mock(EntityCollection.class);
        org.jfree.chart.plot.PlotRenderingInfo info = mock(org.jfree.chart.plot.PlotRenderingInfo.class);
        when(info.getOwner()).thenReturn(null);
        when(state.getInfo()).thenReturn(info);
        when(state.getEntityCollection()).thenReturn(entities);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(entities).add(any());
    }

    @Test
    void testDrawHorizontalItem_AllBoxValuesAndMeanAndMedianVisible() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.isFillBox()).thenReturn(true);
        when(renderer.isUseOutlinePaintForWhiskers()).thenReturn(true);
        when(renderer.isMeanVisible()).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(true);
        when(renderer.getItemPaint(row, column)).thenReturn(Color.YELLOW);
        when(renderer.getItemStroke(row, column)).thenReturn(new java.awt.BasicStroke());
        when(renderer.getItemOutlinePaint(row, column)).thenReturn(Color.BLACK);
        when(renderer.getItemOutlineStroke(row, column)).thenReturn(new java.awt.BasicStroke());
        when(renderer.getRowCount()).thenReturn(3);
        when(renderer.getColumnCount()).thenReturn(2);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(200.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        double seriesGap = 0.2 * 150 / (2 * (3 -1));
        double usedWidth = (10.0 * 3) + (seriesGap * (3 -1));
        double offset = (100.0 - usedWidth) / 2;
        double expectedY = 100.0 + offset + (row * (10.0 + seriesGap));

        when(dataset.getQ1Value(row, column)).thenReturn(120.0);
        when(dataset.getQ3Value(row, column)).thenReturn(160.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(180.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(80.0);
        when(dataset.getMeanValue(row, column)).thenReturn(150.0);
        when(dataset.getMedianValue(row, column)).thenReturn(140.0);
        when(dataArea.getMinX()).thenReturn(0.0);
        when(dataArea.getMaxX()).thenReturn(300.0);
        when(rangeAxis.valueToJava2D(eq(120.0), eq(dataArea), any()))
                .thenReturn(130.0);
        when(rangeAxis.valueToJava2D(eq(160.0), eq(dataArea), any()))
                .thenReturn(170.0);
        when(rangeAxis.valueToJava2D(eq(180.0), eq(dataArea), any()))
                .thenReturn(190.0);
        when(rangeAxis.valueToJava2D(eq(80.0), eq(dataArea), any()))
                .thenReturn(90.0);
        when(rangeAxis.valueToJava2D(eq(150.0), eq(dataArea), any()))
                .thenReturn(160.0);
        when(rangeAxis.valueToJava2D(eq(140.0), eq(dataArea), any()))
                .thenReturn(150.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2).setPaint(Color.YELLOW);
        verify(g2).setStroke(any(Stroke.class));
        verify(g2).fill(any(Rectangle2D.class));
        verify(g2).setPaint(Color.BLACK);
        verify(g2, times(5)).draw(any());
        verify(g2).setPaint(renderer.getArtifactPaint());
        verify(g2).fill(any(Ellipse2D.Double.class));
        verify(g2).draw(any(Ellipse2D.Double.class));
        verify(g2).draw(any(Line2D.Double.class));
    }

    @Test
    void testDrawHorizontalItem_StateInfoNull_BoxNotNull() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(false);
        when(renderer.isMeanVisible()).thenReturn(false);
        when(state.getInfo()).thenReturn(null);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(60.0);
        when(dataset.getQ3Value(row, column)).thenReturn(80.0);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(90.0);
        when(dataset.getMinRegularValue(row, column)).thenReturn(40.0);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(renderer, never()).addItemEntity(any(), any(), anyInt(), anyInt(), any());
    }

    @Test
    void testDrawHorizontalItem_AllNullValues() {
        when(renderer.getItemVisible(row, column)).thenReturn(true);
        when(renderer.isMedianVisible()).thenReturn(true);
        when(renderer.isMeanVisible()).thenReturn(true);
        when(renderer.getRowCount()).thenReturn(1);
        when(renderer.getColumnCount()).thenReturn(1);
        when(domainAxis.getCategoryEnd(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(100.0);
        when(domainAxis.getCategoryStart(eq(column), anyInt(), eq(dataArea), any()))
                .thenReturn(50.0);
        when(dataset.getQ1Value(row, column)).thenReturn(null);
        when(dataset.getQ3Value(row, column)).thenReturn(null);
        when(dataset.getMaxRegularValue(row, column)).thenReturn(null);
        when(dataset.getMinRegularValue(row, column)).thenReturn(null);
        when(dataset.getMeanValue(row, column)).thenReturn(null);
        when(dataset.getMedianValue(row, column)).thenReturn(null);

        renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);

        verify(g2, never()).fill(any());
        verify(g2, never()).draw(any());
    }

    @Test
    void testDrawHorizontalItem_NullDataArea() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, state, null, plot, domainAxis, rangeAxis, dataset, row, column);
        });
        assertNotNull(exception);
    }

    @Test
    void testDrawHorizontalItem_NullPlot() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, state, dataArea, null, domainAxis, rangeAxis, dataset, row, column);
        });
        assertNotNull(exception);
    }

    @Test
    void testDrawHorizontalItem_NullDomainAxis() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, null, rangeAxis, dataset, row, column);
        });
        assertNotNull(exception);
    }

    @Test
    void testDrawHorizontalItem_NullRangeAxis() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, null, dataset, row, column);
        });
        assertNotNull(exception);
    }

    @Test
    void testDrawHorizontalItem_NullDataset() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            renderer.drawHorizontalItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, row, column);
        });
        assertNotNull(exception);
    }

}