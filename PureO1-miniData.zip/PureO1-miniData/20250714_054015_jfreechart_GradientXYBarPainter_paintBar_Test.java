import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.ui.RectangleEdge;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class GradientXYBarPainterTest {

    private GradientXYBarPainter painter;
    private Graphics2D mockGraphics;
    private XYBarRenderer mockRenderer;
    private RectangularShape mockBar;

    @BeforeEach
    void setUp() {
        painter = new GradientXYBarPainter();
        mockGraphics = mock(Graphics2D.class);
        mockRenderer = mock(XYBarRenderer.class);
        mockBar = mock(Rectangle2D.class);
    }

    @Test
    void paintBar_ItemPaintIsColor_AlphaNotZero_BaseTop_DrawOutlineFalse() {
        Color color = new Color(100, 150, 200, 255);
        when(mockRenderer.getItemPaint(0, 0)).thenReturn(color);
        when(mockRenderer.isDrawBarOutline()).thenReturn(false);

        when(mockBar.getMinX()).thenReturn(10.0);
        when(mockBar.getMaxX()).thenReturn(110.0);
        when(mockBar.getMinY()).thenReturn(20.0);
        when(mockBar.getMaxY()).thenReturn(220.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        painter.paintBar(mockGraphics, mockRenderer, 0, 0, mockBar, RectangleEdge.TOP);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsColor_AlphaZero() {
        Color color = new Color(100, 150, 200, 0);
        when(mockRenderer.getItemPaint(0, 0)).thenReturn(color);

        painter.paintBar(mockGraphics, mockRenderer, 0, 0, mockBar, RectangleEdge.BOTTOM);

        verify(mockGraphics, never()).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsGradientPaint_BaseLeft_DrawOutlineTrue() {
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, Color.RED, 1f, 1f, Color.GREEN);
        when(mockRenderer.getItemPaint(1, 1)).thenReturn(gradientPaint);
        when(mockRenderer.isDrawBarOutline()).thenReturn(true);

        when(mockBar.getMinX()).thenReturn(50.0);
        when(mockBar.getMaxX()).thenReturn(150.0);
        when(mockBar.getMinY()).thenReturn(60.0);
        when(mockBar.getMaxY()).thenReturn(260.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        when(mockRenderer.getItemOutlineStroke(1, 1)).thenReturn(null);
        when(mockRenderer.getItemOutlinePaint(1, 1)).thenReturn(null);

        painter.paintBar(mockGraphics, mockRenderer, 1, 1, mockBar, RectangleEdge.LEFT);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsOtherType_BaseRight_DrawOutlineTrue() {
        Paint otherPaint = mock(Paint.class);
        when(mockRenderer.getItemPaint(2, 2)).thenReturn(otherPaint);
        when(mockRenderer.isDrawBarOutline()).thenReturn(true);

        when(mockBar.getMinX()).thenReturn(30.0);
        when(mockBar.getMaxX()).thenReturn(130.0);
        when(mockBar.getMinY()).thenReturn(40.0);
        when(mockBar.getMaxY()).thenReturn(240.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        Stroke mockStroke = mock(Stroke.class);
        Paint mockOutlinePaint = mock(Paint.class);
        when(mockRenderer.getItemOutlineStroke(2, 2)).thenReturn(mockStroke);
        when(mockRenderer.getItemOutlinePaint(2, 2)).thenReturn(mockOutlinePaint);

        painter.paintBar(mockGraphics, mockRenderer, 2, 2, mockBar, RectangleEdge.RIGHT);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics).setStroke(mockStroke);
        verify(mockGraphics).setPaint(mockOutlinePaint);
        verify(mockGraphics).draw(mockBar);
    }

    @Test
    void paintBar_BaseBottom_DrawOutlineFalse() {
        Color color = Color.BLUE;
        when(mockRenderer.getItemPaint(3, 3)).thenReturn(color);
        when(mockRenderer.isDrawBarOutline()).thenReturn(false);

        when(mockBar.getMinX()).thenReturn(0.0);
        when(mockBar.getMaxX()).thenReturn(50.0);
        when(mockBar.getMinY()).thenReturn(0.0);
        when(mockBar.getMaxY()).thenReturn(100.0);
        when(mockBar.getWidth()).thenReturn(50.0);
        when(mockBar.getHeight()).thenReturn(100.0);

        painter.paintBar(mockGraphics, mockRenderer, 3, 3, mockBar, RectangleEdge.BOTTOM);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_NullGraphics() {
        Color color = Color.RED;
        when(mockRenderer.getItemPaint(4, 4)).thenReturn(color);

        assertThrows(NullPointerException.class, () -> {
            painter.paintBar(null, mockRenderer, 4, 4, mockBar, RectangleEdge.TOP);
        });
    }

    @Test
    void paintBar_NullRenderer() {
        assertThrows(NullPointerException.class, () -> {
            painter.paintBar(mockGraphics, null, 5, 5, mockBar, RectangleEdge.TOP);
        });
    }

    @Test
    void paintBar_NullBar() {
        Color color = Color.GREEN;
        when(mockRenderer.getItemPaint(6, 6)).thenReturn(color);

        assertThrows(NullPointerException.class, () -> {
            painter.paintBar(mockGraphics, mockRenderer, 6, 6, null, RectangleEdge.TOP);
        });
    }

    @Test
    void paintBar_NullBase() {
        Color color = Color.YELLOW;
        when(mockRenderer.getItemPaint(7, 7)).thenReturn(color);
        when(mockRenderer.isDrawBarOutline()).thenReturn(false);

        when(mockBar.getMinX()).thenReturn(10.0);
        when(mockBar.getMaxX()).thenReturn(110.0);
        when(mockBar.getMinY()).thenReturn(20.0);
        when(mockBar.getMaxY()).thenReturn(220.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        assertDoesNotThrow(() -> {
            painter.paintBar(mockGraphics, mockRenderer, 7, 7, mockBar, null);
        });

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_BaseNotTopBottomLeftRight() {
        Color color = Color.MAGENTA;
        when(mockRenderer.getItemPaint(8, 8)).thenReturn(color);
        when(mockRenderer.isDrawBarOutline()).thenReturn(false);

        when(mockBar.getMinX()).thenReturn(5.0);
        when(mockBar.getMaxX()).thenReturn(105.0);
        when(mockBar.getMinY()).thenReturn(15.0);
        when(mockBar.getMaxY()).thenReturn(215.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        RectangleEdge invalidEdge = RectangleEdge.forSide(null);

        painter.paintBar(mockGraphics, mockRenderer, 8, 8, mockBar, invalidEdge);

        verify(mockGraphics, never()).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsColor_DrawOutlineTrue_NonNullStrokeAndPaint() {
        Color color = Color.ORANGE;
        when(mockRenderer.getItemPaint(9, 9)).thenReturn(color);
        when(mockRenderer.isDrawBarOutline()).thenReturn(true);

        when(mockBar.getMinX()).thenReturn(25.0);
        when(mockBar.getMaxX()).thenReturn(125.0);
        when(mockBar.getMinY()).thenReturn(35.0);
        when(mockBar.getMaxY()).thenReturn(235.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        Stroke mockStroke = mock(Stroke.class);
        Paint mockOutlinePaint = mock(Paint.class);
        when(mockRenderer.getItemOutlineStroke(9, 9)).thenReturn(mockStroke);
        when(mockRenderer.getItemOutlinePaint(9, 9)).thenReturn(mockOutlinePaint);

        painter.paintBar(mockGraphics, mockRenderer, 9, 9, mockBar, RectangleEdge.BOTTOM);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics).setStroke(mockStroke);
        verify(mockGraphics).setPaint(mockOutlinePaint);
        verify(mockGraphics).draw(mockBar);
    }

    @Test
    void paintBar_ItemPaintIsColor_DrawOutlineTrue_NullStroke() {
        Color color = Color.CYAN;
        when(mockRenderer.getItemPaint(10, 10)).thenReturn(color);
        when(mockRenderer.isDrawBarOutline()).thenReturn(true);

        when(mockBar.getMinX()).thenReturn(60.0);
        when(mockBar.getMaxX()).thenReturn(160.0);
        when(mockBar.getMinY()).thenReturn(80.0);
        when(mockBar.getMaxY()).thenReturn(280.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        when(mockRenderer.getItemOutlineStroke(10, 10)).thenReturn(null);
        when(mockRenderer.getItemOutlinePaint(10, 10)).thenReturn(mock(Paint.class));

        painter.paintBar(mockGraphics, mockRenderer, 10, 10, mockBar, RectangleEdge.TOP);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).setStroke(any());
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsColor_DrawOutlineTrue_NullPaint() {
        Color color = Color.PINK;
        when(mockRenderer.getItemPaint(11, 11)).thenReturn(color);
        when(mockRenderer.isDrawBarOutline()).thenReturn(true);

        when(mockBar.getMinX()).thenReturn(70.0);
        when(mockBar.getMaxX()).thenReturn(170.0);
        when(mockBar.getMinY()).thenReturn(90.0);
        when(mockBar.getMaxY()).thenReturn(290.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        when(mockRenderer.getItemOutlineStroke(11, 11)).thenReturn(mock(Stroke.class));
        when(mockRenderer.getItemOutlinePaint(11, 11)).thenReturn(null);

        painter.paintBar(mockGraphics, mockRenderer, 11, 11, mockBar, RectangleEdge.LEFT);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).setPaint(any());
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsGradientPaint_WithAlphaNotZero() {
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, new Color(50, 100, 150, 200),
                1f, 1f, new Color(150, 200, 250, 200));
        when(mockRenderer.getItemPaint(12, 12)).thenReturn(gradientPaint);
        when(mockRenderer.isDrawBarOutline()).thenReturn(false);

        when(mockBar.getMinX()).thenReturn(15.0);
        when(mockBar.getMaxX()).thenReturn(115.0);
        when(mockBar.getMinY()).thenReturn(25.0);
        when(mockBar.getMaxY()).thenReturn(225.0);
        when(mockBar.getWidth()).thenReturn(100.0);
        when(mockBar.getHeight()).thenReturn(200.0);

        painter.paintBar(mockGraphics, mockRenderer, 12, 12, mockBar, RectangleEdge.RIGHT);

        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsGradientPaint_WithAlphaZero() {
        Color transparentColor = new Color(0, 0, 0, 0);
        GradientPaint gradientPaint = new GradientPaint(0f, 0f, transparentColor,
                1f, 1f, new Color(255, 255, 255, 0));
        when(mockRenderer.getItemPaint(13, 13)).thenReturn(gradientPaint);

        painter.paintBar(mockGraphics, mockRenderer, 13, 13, mockBar, RectangleEdge.LEFT);

        verify(mockGraphics, never()).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }

    @Test
    void paintBar_ItemPaintIsNull() {
        when(mockRenderer.getItemPaint(14, 14)).thenReturn(null);
        when(mockRenderer.isDrawBarOutline()).thenReturn(false);

        painter.paintBar(mockGraphics, mockRenderer, 14, 14, mockBar, RectangleEdge.BOTTOM);

        // Defaults to Color.BLUE with alpha 255
        verify(mockGraphics, times(4)).fill(any(Rectangle2D.class));
        verify(mockGraphics, never()).draw(any(Rectangle2D.class));
    }
}