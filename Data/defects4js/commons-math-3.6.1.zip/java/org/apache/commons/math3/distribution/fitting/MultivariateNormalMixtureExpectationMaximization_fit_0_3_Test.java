package org.apache.commons.math3.distribution.fitting;

import org.apache.commons.math3.distribution.MixtureMultivariateNormalDistribution;
import org.apache.commons.math3.distribution.MultivariateNormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Pair;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MultivariateNormalMixtureExpectationMaximization_fit_0_3_Test {

    @Test
    @DisplayName("fit with initial mixture having one component processes correctly")
    public void TC11_fit_with_single_component_updates_correctly() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createSingleComponentMixture();
        int maxIterations = 20;
        double threshold = 1e-6;
        double[][] data = {
            {1.0, 2.0},
            {1.5, 1.8},
            {2.0, 2.2}
        };
        
        // Instantiate the class under test with the data parameter in the constructor
        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);
        
        // WHEN
        em.fit(initialMixture, maxIterations, threshold);
        
        // THEN
        // Use reflection to get the private 'fittedModel' field
        Field fittedModelField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(em);
        
        assertNotNull(fittedModel, "Fitted model should not be null");
        assertEquals(1, fittedModel.getComponents().size(), "There should be one component in the fitted model");
        // Additional assertions can be added here to verify the component's parameters
    }

    @Test
    @DisplayName("fit with initial mixture having multiple components processes correctly")
    public void TC12_fit_with_multiple_components_updates_correctly() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createMultipleComponentMixture();
        int maxIterations = 100;
        double threshold = 1e-6;
        double[][] data = {
            {1.0, 2.0},
            {1.5, 1.8},
            {2.0, 2.2},
            {3.0, 3.5},
            {3.5, 3.8},
            {4.0, 4.2}
        };
        
        // Instantiate the class under test with the data parameter in the constructor
        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);
        
        // WHEN
        em.fit(initialMixture, maxIterations, threshold);
        
        // THEN
        // Use reflection to get the private 'fittedModel' field
        Field fittedModelField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(em);
        
        assertNotNull(fittedModel, "Fitted model should not be null");
        assertEquals(initialMixture.getComponents().size(), fittedModel.getComponents().size(), "Number of components should match the initial mixture");
        // Additional assertions can be added here to verify each component's parameters
    }

    @Test
    @DisplayName("fit where logLikelihood equals previousLogLikelihood on first iteration causes immediate convergence")
    public void TC13_fit_throws_ConvergenceException_when_logLikelihood_does_not_improve() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createNonImprovingMixture();
        int maxIterations = 10;
        double threshold = 1e-6;
        double[][] data = {
            {1.0, 2.0},
            {1.0, 2.0},
            {1.0, 2.0}
        };
        
        // Instantiate the class under test with the data parameter in the constructor
        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);
        
        // WHEN & THEN
        assertThrows(ConvergenceException.class, () -> {
            em.fit(initialMixture, maxIterations, threshold);
        }, "Expected ConvergenceException when logLikelihood does not improve");
    }

    @Test
    @DisplayName("fit where logLikelihood changes within threshold on the last iteration")
    public void TC14_fit_converges_within_threshold_on_last_iteration() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createGradualImprovementMixture();
        int maxIterations = 50;
        double threshold = 1e-6;
        double[][] data = {
            {1.0, 2.0},
            {1.1, 2.1},
            {1.2, 2.2},
            {1.3, 2.3},
            {1.4, 2.4}
        };
        
        // Instantiate the class under test with the data parameter in the constructor
        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);
        
        // WHEN
        em.fit(initialMixture, maxIterations, threshold);
        
        // THEN
        // Use reflection to get the private 'logLikelihood' field
        Field logLikelihoodField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("logLikelihood");
        logLikelihoodField.setAccessible(true);
        double logLikelihood = logLikelihoodField.getDouble(em);
        
        assertTrue(logLikelihood > Double.MIN_VALUE, "Log likelihood should be updated and within threshold");
        
        // Additionally, verify the fitted model's parameters if necessary
    }

    @Test
    @DisplayName("fit with extremely high maxIterations ensures termination")
    public void TC15_fit_with_extremely_high_maxIterations_terminates_correctly() throws Exception {
        // GIVEN
        MixtureMultivariateNormalDistribution initialMixture = createValidMixture();
        int maxIterations = 1000;
        double threshold = 1e-6;
        double[][] data = {
            {1.0, 2.0},
            {1.5, 1.8},
            {2.0, 2.2},
            {2.5, 2.4},
            {3.0, 3.0},
            {3.5, 3.5},
            {4.0, 4.0}
        };
        
        // Instantiate the class under test with the data parameter in the constructor
        MultivariateNormalMixtureExpectationMaximization em = new MultivariateNormalMixtureExpectationMaximization(data);
        
        // WHEN
        assertDoesNotThrow(() -> {
            em.fit(initialMixture, maxIterations, threshold);
        }, "Fit should terminate successfully or throw ConvergenceException after maxIterations");
        
        // THEN
        // Use reflection to get the private 'fittedModel' field and verify if needed
        Field fittedModelField = MultivariateNormalMixtureExpectationMaximization.class.getDeclaredField("fittedModel");
        fittedModelField.setAccessible(true);
        MixtureMultivariateNormalDistribution fittedModel = (MixtureMultivariateNormalDistribution) fittedModelField.get(em);
        
        assertNotNull(fittedModel, "Fitted model should not be null");
        // Additional assertions can be added here to verify the fitted model after high iterations
    }

    // Helper methods to create initial mixtures
    private MixtureMultivariateNormalDistribution createSingleComponentMixture() {
        List<Pair<Double, MultivariateNormalDistribution>> components = new ArrayList<>();
        double[] means = {0.0, 0.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution mnd = new MultivariateNormalDistribution(means, covariances);
        components.add(new Pair<>(1.0, mnd));
        return new MixtureMultivariateNormalDistribution(components);
    }

    private MixtureMultivariateNormalDistribution createMultipleComponentMixture() {
        List<Pair<Double, MultivariateNormalDistribution>> components = new ArrayList<>();
        double[] means1 = {0.0, 0.0};
        double[][] covariances1 = {{1.0, 0.0}, {0.0, 1.0}};
        MultivariateNormalDistribution mnd1 = new MultivariateNormalDistribution(means1, covariances1);
        components.add(new Pair<>(0.5, mnd1));
        
        double[] means2 = {5.0, 5.0};
        double[][] covariances2 = {{1.5, 0.0}, {0.0, 1.5}};
        MultivariateNormalDistribution mnd2 = new MultivariateNormalDistribution(means2, covariances2);
        components.add(new Pair<>(0.5, mnd2));
        
        return new MixtureMultivariateNormalDistribution(components);
    }

    private MixtureMultivariateNormalDistribution createNonImprovingMixture() {
        // Create a mixture that does not improve logLikelihood
        return createSingleComponentMixture();
    }

    private MixtureMultivariateNormalDistribution createGradualImprovementMixture() {
        // Create a mixture that gradually improves logLikelihood
        return createMultipleComponentMixture();
    }

    private MixtureMultivariateNormalDistribution createValidMixture() {
        // Create a valid mixture for testing
        return createMultipleComponentMixture();
    }
}
