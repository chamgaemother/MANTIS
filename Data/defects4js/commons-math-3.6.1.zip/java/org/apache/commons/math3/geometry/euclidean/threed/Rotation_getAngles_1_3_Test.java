package org.apache.commons.math3.geometry.euclidean.threed;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Rotation_getAngles_1_3_Test {

    @Test
    @DisplayName("getAngles with FRAME_TRANSFORM convention and ZYZ order with angles resulting in Ï/2 rotation")
    void testTC14_getAngles_FRAME_TRANSFORM_ZYZ_pi_over_2_rotation() {
        // Arrange
        Rotation rotation = new Rotation(RotationOrder.ZYZ, RotationConvention.FRAME_TRANSFORM, Math.PI / 2, Math.PI / 2, Math.PI / 2);

        // Act
        double[] angles = rotation.getAngles(RotationOrder.ZYZ, RotationConvention.FRAME_TRANSFORM);

        // Assert
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should have three elements");
        double delta = 1e-10;
        assertEquals(Math.PI / 2, angles[0], delta, "First angle should be Ï/2");
        assertEquals(Math.PI / 2, angles[1], delta, "Second angle should be Ï/2");
        assertEquals(Math.PI / 2, angles[2], delta, "Third angle should be Ï/2");
    }

}