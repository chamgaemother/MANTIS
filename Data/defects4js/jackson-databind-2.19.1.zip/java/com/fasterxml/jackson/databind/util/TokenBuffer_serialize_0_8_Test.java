package com.fasterxml.jackson.databind.util;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.core.JsonGenerator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class TokenBuffer_serialize_0_8_Test {
    
    @Test
    @DisplayName("serialize with both object ID and type ID present in a token")
    public void TC36_serialize_with_both_object_id_and_type_id() throws Exception {
        // GIVEN
        TokenBuffer buffer = new TokenBuffer(null, true);
        buffer.writeStartObject();
        buffer.writeObjectId("obj-5678");
        buffer.writeTypeId("type-abc");
        buffer.writeEndObject();
        
        JsonGenerator gen = mock(JsonGenerator.class);
        
        // WHEN
        buffer.serialize(gen);
        
        // THEN
        verify(gen).writeObjectId("obj-5678");
        verify(gen).writeTypeId("type-abc");
        verify(gen).writeStartObject();
        verify(gen).writeEndObject();
    }
}