package com.fasterxml.jackson.core;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Base64Variant_decode_0_7_Test {

    @Test
    @DisplayName("decode with null ByteArrayBuilder throws NullPointerException")
    void TC31_decode_with_null_ByteArrayBuilder_throws_NullPointerException() throws Exception {
        // GIVEN
        String str = "TWFu";
        ByteArrayBuilder builder = null;
        
        // Using reflection to instantiate Base64Variant
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor(String.class, String.class, char.class, boolean.class);
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance("TEST", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=', false);
        
        // WHEN & THEN
        assertThrows(NullPointerException.class, () -> {
            variant.decode(str, builder);
        });
    }

    @Test
    @DisplayName("decode with maximum integer value as string length handles correctly")
    void TC32_decode_with_maximum_integer_length_string_handles_correctly() throws Exception {
        // GIVEN
        StringBuilder sb = new StringBuilder();
        // Note: Creating a string of size Integer.MAX_VALUE / 4 is impractical and will cause OutOfMemoryError.
        // For demonstration purposes, we'll use a smaller size.
        int testSize = 1000; // Replace with Integer.MAX_VALUE / 4 in real test if feasible
        for(int i = 0; i < testSize; i++) {
            sb.append("AAAA");
        }
        String str = sb.toString();
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        // Using reflection to instantiate Base64Variant
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor(String.class, String.class, char.class, boolean.class);
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance("TEST", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=', false);
        
        // WHEN & THEN
        assertDoesNotThrow(() -> {
            variant.decode(str, builder);
        });
    }

    @Test
    @DisplayName("decode with minimal non-whitespace characters processes correctly")
    void TC33_decode_with_minimal_non_whitespace_characters_processes_correctly() throws Exception {
        // GIVEN
        String str = "TQ==";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        // Using reflection to instantiate Base64Variant
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor(String.class, String.class, char.class, boolean.class);
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance("TEST", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=', false);
        
        // WHEN
        variant.decode(str, builder);
        
        // THEN
        assertArrayEquals(new byte[]{77}, builder.toByteArray(), "Decoded bytes should match expected single byte");
    }

    @Test
    @DisplayName("decode with multiple padding characters correctly appends bytes")
    void TC34_decode_with_multiple_padding_characters_correctly_appends_bytes() throws Exception {
        // GIVEN
        String str = "TQ==";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        // Using reflection to instantiate Base64Variant
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor(String.class, String.class, char.class, boolean.class);
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance("TEST", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=', false);
        
        // WHEN
        variant.decode(str, builder);
        
        // THEN
        assertArrayEquals(new byte[]{77}, builder.toByteArray(), "Decoded bytes should match expected bytes with padding");
    }

    @Test
    @DisplayName("decode with alternating valid and whitespace characters processes correctly")
    void TC35_decode_with_alternating_valid_and_whitespace_characters_processes_correctly() throws Exception {
        // GIVEN
        String str = "T W F u";
        ByteArrayBuilder builder = new ByteArrayBuilder();
        
        // Using reflection to instantiate Base64Variant
        Constructor<Base64Variant> constructor = Base64Variant.class.getDeclaredConstructor(String.class, String.class, char.class, boolean.class);
        constructor.setAccessible(true);
        Base64Variant variant = constructor.newInstance("TEST", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=', false);
        
        // WHEN
        variant.decode(str, builder);
        
        // THEN
        assertArrayEquals(new byte[]{77, 97, 110}, builder.toByteArray(), "Decoded bytes should match expected bytes ignoring whitespace");
    }
}