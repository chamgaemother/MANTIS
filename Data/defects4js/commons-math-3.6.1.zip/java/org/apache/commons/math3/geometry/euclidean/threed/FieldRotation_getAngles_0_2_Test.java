package org.apache.commons.math3.geometry.euclidean.threed;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.geometry.euclidean.threed.CardanEulerSingularityException;
import org.apache.commons.math3.geometry.euclidean.threed.FieldRotation;
import org.apache.commons.math3.geometry.euclidean.threed.RotationConvention;
import org.apache.commons.math3.geometry.euclidean.threed.RotationOrder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class FieldRotation_getAngles_0_2_Test {
//
//    @Test
//    @DisplayName("getAngles called with RotationOrder.YXZ and RotationConvention.VECTOR_OPERATOR, v2.getZ() out of bounds triggering exception")
//    void TC06_getAngles_YXZ_VECTOR_OPERATOR_Singularity() {
//        // Arrange
//        RotationOrder order = RotationOrder.YXZ;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Create FieldRotation instance for testing
//        FieldRotation<RealFieldElement<DoubleRealFieldElement>> rotation = new FieldRotation<>(
//                new DoubleRealFieldElement(0), // Mock value, replace with actual RealFieldElement instance
//                new DoubleRealFieldElement(0),
//                new DoubleRealFieldElement(0),
//                new DoubleRealFieldElement(0),
//                false);
//
//        // Act & Assert
//        assertThrows(CardanEulerSingularityException.class, () -> {
//            rotation.getAngles(order, convention);
//        });
//    }
//
//    @Test
//    @DisplayName("getAngles called with RotationOrder.YZX and RotationConvention.VECTOR_OPERATOR, v2.getX() within bounds")
//    void TC07_getAngles_YZX_VECTOR_OPERATOR_WithinBounds() {
//        // Arrange
//        RotationOrder order = RotationOrder.YZX;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Create FieldRotation instance for testing
//        FieldRotation<RealFieldElement<DoubleRealFieldElement>> rotation = new FieldRotation<>(
//                new DoubleRealFieldElement(0.1), // Example values, replace as needed
//                new DoubleRealFieldElement(0.1),
//                new DoubleRealFieldElement(0.1),
//                new DoubleRealFieldElement(0.9),
//                false);
//
//        // Act
//        RealFieldElement<DoubleRealFieldElement>[] result = rotation.getAngles(order, convention);
//
//        // Assert
//        assertAll("angles",
//            () -> assertEquals(3, result.length),
//            () -> assertEquals(new DoubleRealFieldElement(0.1), result[0]),
//            () -> assertEquals(new DoubleRealFieldElement(0.1), result[1]),
//            () -> assertEquals(new DoubleRealFieldElement(0.1), result[2])
//        );
//    }
//
//    @Test
//    @DisplayName("getAngles called with RotationOrder.YZX and RotationConvention.VECTOR_OPERATOR, v2.getX() out of bounds triggering exception")
//    void TC08_getAngles_YZX_VECTOR_OPERATOR_Singularity() {
//        // Arrange
//        RotationOrder order = RotationOrder.YZX;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Create FieldRotation instance for testing
//        FieldRotation<RealFieldElement<DoubleRealFieldElement>> rotation = new FieldRotation<>(
//                new DoubleRealFieldElement(0), // Mock values for simplified test
//                new DoubleRealFieldElement(0),
//                new DoubleRealFieldElement(0),
//                new DoubleRealFieldElement(0),
//                false);
//
//        // Act & Assert
//        assertThrows(CardanEulerSingularityException.class, () -> {
//            rotation.getAngles(order, convention);
//        });
//    }
//
//    @Test
//    @DisplayName("getAngles called with RotationOrder.ZXY and RotationConvention.VECTOR_OPERATOR, v2.getY() within bounds")
//    void TC09_getAngles_ZXY_VECTOR_OPERATOR_WithinBounds() {
//        // Arrange
//        RotationOrder order = RotationOrder.ZXY;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Create FieldRotation instance for testing
//        FieldRotation<RealFieldElement<DoubleRealFieldElement>> rotation = new FieldRotation<>(
//                new DoubleRealFieldElement(0.5), // Example values
//                new DoubleRealFieldElement(0.5),
//                new DoubleRealFieldElement(0.5),
//                new DoubleRealFieldElement(0.5),
//                false);
//
//        // Act
//        RealFieldElement<DoubleRealFieldElement>[] result = rotation.getAngles(order, convention);
//
//        // Assert
//        assertAll("angles",
//            () -> assertEquals(3, result.length),
//            () -> assertEquals(new DoubleRealFieldElement(0.5), result[0]),
//            () -> assertEquals(new DoubleRealFieldElement(0.5), result[1]),
//            () -> assertEquals(new DoubleRealFieldElement(0.5), result[2])
//        );
//    }
//
//    @Test
//    @DisplayName("getAngles called with RotationOrder.ZXY and RotationConvention.VECTOR_OPERATOR, v2.getY() out of bounds triggering exception")
//    void TC10_getAngles_ZXY_VECTOR_OPERATOR_Singularity() {
//        // Arrange
//        RotationOrder order = RotationOrder.ZXY;
//        RotationConvention convention = RotationConvention.VECTOR_OPERATOR;
//
//        // Create FieldRotation instance for testing
//        FieldRotation<RealFieldElement<DoubleRealFieldElement>> rotation = new FieldRotation<>(
//                new DoubleRealFieldElement(0),
//                new DoubleRealFieldElement(0),
//                new DoubleRealFieldElement(0),
//                new DoubleRealFieldElement(0),
//                false);
//
//        // Act & Assert
//        assertThrows(CardanEulerSingularityException.class, () -> {
//            rotation.getAngles(order, convention);
//        });
//    }
//
//    // Adding a simple RealFieldElement mock class to be used for testing purposes
//    class DoubleRealFieldElement implements RealFieldElement<DoubleRealFieldElement> {
//        private final double value;
//
//        DoubleRealFieldElement(double value) {
//            this.value = value;
//        }
//
//        @Override
//        public double getReal() {
//            return value;
//        }
//
//        // Simplified implementations for mock
//        @Override
//        public DoubleRealFieldElement add(DoubleRealFieldElement a) {
//            return new DoubleRealFieldElement(this.value + a.value);
//        }
//
//        @Override
//        public DoubleRealFieldElement subtract(DoubleRealFieldElement a) {
//            return new DoubleRealFieldElement(this.value - a.value);
//        }
//
//        @Override
//        public DoubleRealFieldElement negate() {
//            return new DoubleRealFieldElement(-this.value);
//        }
//
//        @Override
//        public DoubleRealFieldElement divide(DoubleRealFieldElement a) {
//            return new DoubleRealFieldElement(this.value / a.value);
//        }
//
//        @Override
//        public DoubleRealFieldElement multiply(DoubleRealFieldElement a) {
//            return new DoubleRealFieldElement(this.value * a.value);
//        }
//
//        @Override
//        public DoubleRealFieldElement reciprocal() {
//            return new DoubleRealFieldElement(1.0 / this.value);
//        }
//
//        @Override
//        public DoubleRealFieldElement sqrt() {
//            return new DoubleRealFieldElement(Math.sqrt(this.value));
//        }
//
//        @Override
//        public boolean equals(Object o) {
//            if (this == o) return true;
//            if (o == null || getClass() != o.getClass()) return false;
//            DoubleRealFieldElement that = (DoubleRealFieldElement) o;
//            return Double.compare(that.value, value) == 0;
//        }
//
//        @Override
//        public int hashCode() {
//            return Objects.hash(value);
//        }
//    }

}
