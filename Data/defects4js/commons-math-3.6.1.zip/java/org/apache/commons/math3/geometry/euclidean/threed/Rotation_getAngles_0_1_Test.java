package org.apache.commons.math3.geometry.euclidean.threed;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Rotation_getAngles_0_1_Test {

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and XYZ order where v2.getZ() is within bounds")
    public void test_Angles_VECTOR_OPERATOR_XYZ_WithinBounds() {
        // GIVEN
        Rotation rotation = new Rotation(0.0, 0.0, 1.0, 0.0, false);

        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);

        // THEN
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should contain three elements");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and XYZ order where v2.getZ() exceeds upper boundary, throwing exception")
    public void test_Angles_VECTOR_OPERATOR_XYZ_ExceedsUpperZBoundary() {
        // GIVEN
        Rotation rotation = createRotationWithV2Z(1.0); // v2.getZ() > 0.9999999999

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XYZ, RotationConvention.VECTOR_OPERATOR);
        }, "Expected CardanEulerSingularityException to be thrown");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and XZY order where v2.getY() is within bounds")
    public void test_Angles_VECTOR_OPERATOR_XZY_WithinBounds() {
        // GIVEN
        Rotation rotation = new Rotation(0.0, 1.0, 0.0, 0.0, false);

        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.XZY, RotationConvention.VECTOR_OPERATOR);

        // THEN
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should contain three elements");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and XZY order where v2.getY() exceeds upper boundary, throwing exception")
    public void test_Angles_VECTOR_OPERATOR_XZY_ExceedsUpperYBoundary() {
        // GIVEN
        Rotation rotation = createRotationWithV2Y(1.0); // v2.getY() > 0.9999999999

        // WHEN & THEN
        assertThrows(CardanEulerSingularityException.class, () -> {
            rotation.getAngles(RotationOrder.XZY, RotationConvention.VECTOR_OPERATOR);
        }, "Expected CardanEulerSingularityException to be thrown");
    }

    @Test
    @DisplayName("getAngles with VECTOR_OPERATOR convention and YXZ order where v2.getZ() is within bounds")
    public void test_Angles_VECTOR_OPERATOR_YXZ_WithinBounds() {
        // GIVEN
        Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);

        // WHEN
        double[] angles = rotation.getAngles(RotationOrder.YXZ, RotationConvention.VECTOR_OPERATOR);

        // THEN
        assertNotNull(angles, "Angles array should not be null");
        assertEquals(3, angles.length, "Angles array should contain three elements");
    }

    // Helper method to create a Rotation object that causes v2.getZ() to exceed upper boundary.
    private Rotation createRotationWithV2Z(double zValue) {
        // Ensure vector length is normalized
        double normFactor = Math.sqrt(zValue * zValue + 1e-10);
        zValue /= normFactor;
        return new Rotation(0.0, 0.0, 0.0, zValue, false);
    }

    // Helper method to create a Rotation object that causes v2.getY() to exceed upper boundary.
    private Rotation createRotationWithV2Y(double yValue) {
        // Ensure vector length is normalized
        double normFactor = Math.sqrt(yValue * yValue + 1e-10);
        yValue /= normFactor;
        return new Rotation(0.0, 0.0, yValue, 0.0, false);
    }

}