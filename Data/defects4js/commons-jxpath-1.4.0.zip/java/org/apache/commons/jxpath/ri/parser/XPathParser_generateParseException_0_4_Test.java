package org.apache.commons.jxpath.ri.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class XPathParser_generateParseException_0_4_Test {

    @Test
    @DisplayName("jj_expentries contains duplicate jj_expentry arrays")
    public void TC16_jj_expentries_contains_duplicate_jj_expentry_arrays() throws Exception {
        // Use an appropriate stream input here; using a ByteArrayInputStream is more fitting than System.in
        XPathParser parser = new XPathParser(new java.io.ByteArrayInputStream(new byte[0]));

        // Access and modify the private jj_expentries field to add duplicate entries
        Field jjExpentriesField = XPathParser.class.getDeclaredField("jj_expentries");
        jjExpentriesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Vector<int[]> jjExpentries = (Vector<int[]>) jjExpentriesField.get(parser);

        // Clear the default entries
        jjExpentries.clear();

        // Add duplicate jj_expentry arrays
        int[] duplicateEntry = new int[]{1, 2, 3};
        jjExpentries.addElement(duplicateEntry);
        jjExpentries.addElement(duplicateEntry.clone()); // Duplicate of the above array

        // Call generateParseException
        ParseException exception = parser.generateParseException();

        // Assert that the exception is not null
        assertNotNull(exception, "ParseException should not be null");

        // Access the exptokseq field of ParseException
        Field exptokseqField = ParseException.class.getDeclaredField("exptokseq");
        exptokseqField.setAccessible(true);
        int[][] exptokseq = (int[][]) exptokseqField.get(exception);

        // Verify that exptokseq does not contain duplicate arrays
        Set<String> uniqueEntries = new HashSet<>();
        for (int[] seq : exptokseq) {
            uniqueEntries.add(Arrays.toString(seq));
        }

        assertEquals(uniqueEntries.size(), exptokseq.length, "jj_expentries should not contain duplicate arrays");
    }
}