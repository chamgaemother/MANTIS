package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.LegendItem;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class StandardXYItemRendererTest {

    private StandardXYItemRenderer renderer;
    private Graphics2D g2;
    private XYItemRendererState state;
    private Rectangle2D dataArea;
    private PlotRenderingInfo info;
    private XYPlot plot;
    private ValueAxis domainAxis;
    private ValueAxis rangeAxis;
    private XYDataset dataset;
    private CrosshairState crosshairState;

    @BeforeEach
    void setUp() {
        renderer = new StandardXYItemRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(XYItemRendererState.class);
        dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        info = mock(PlotRenderingInfo.class);
        plot = mock(XYPlot.class);
        domainAxis = mock(ValueAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(XYDataset.class);
        crosshairState = new CrosshairState();
    }

    @Test
    void testDrawItem_ItemNotVisible() {
        when(renderer.getItemVisible(0, 0)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).setPaint(any(Paint.class));
    }

    @Test
    void testDrawItem_NaNValues() {
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotLines_DrawSeriesLineAsPath_LastItem() {
        renderer.setPlotLines(true);
        renderer.setDrawSeriesLineAsPath(true);
        StandardXYItemRenderer.State rendererState = new StandardXYItemRenderer.State(info);
        when(state).thenReturn(rendererState);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(dataset.getItemCount(0)).thenReturn(1);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotLines_DrawLine_DiscontinuousFalse() {
        renderer.setPlotLines(true);
        renderer.setPlotDiscontinuous(false);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(40.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotLines_DiscontinuousTrue_WithinThreshold() {
        renderer.setPlotLines(true);
        renderer.setPlotDiscontinuous(true);
        renderer.setGapThresholdType(StandardXYItemRenderer.UnitType.RELATIVE);
        renderer.setGapThreshold(0.5);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(1.4); // within threshold
        when(dataset.getYValue(0, 1)).thenReturn(1.4);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(1.4, dataArea, RectangleEdge.BOTTOM)).thenReturn(14.0);
        when(rangeAxis.valueToJava2D(1.4, dataArea, RectangleEdge.LEFT)).thenReturn(28.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotLines_DiscontinuousTrue_ExceedsThreshold() {
        renderer.setPlotLines(true);
        renderer.setPlotDiscontinuous(true);
        renderer.setGapThresholdType(StandardXYItemRenderer.UnitType.RELATIVE);
        renderer.setGapThreshold(0.5);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0); // exceeds threshold
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(40.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_BaseShapesVisible_Filled() {
        renderer.setBaseShapesVisible(true);
        renderer.setBaseShapesFilled(true);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_BaseShapesVisible_NotFilled() {
        renderer.setBaseShapesVisible(true);
        renderer.setBaseShapesFilled(false);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_PlotImages_True_WithImage() {
        renderer.setPlotImages(true);
        Image image = mock(Image.class);
        when(renderer.getImage(any(), anyInt(), anyInt(), anyDouble(), anyDouble())).thenReturn(image);
        when(renderer.getImageHotspot(any(), anyInt(), anyInt(), anyDouble(), anyDouble(), any())).thenReturn(new java.awt.Point(5, 5));
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2).drawImage(eq(image), eq(45), eq(45), eq((java.awt.image.ImageObserver) null));
    }

    @Test
    void testDrawItem_PlotImages_True_NoImage() {
        renderer.setPlotImages(true);
        when(renderer.getImage(any(), anyInt(), anyInt(), anyDouble(), anyDouble())).thenReturn(null);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).drawImage(any(), anyInt(), anyInt(), any());
    }

    @Test
    void testDrawItem_PlotImages_False() {
        renderer.setPlotImages(false);
        renderer.setPlotLines(false);
        renderer.setBaseShapesVisible(false);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
        verify(g2, never()).drawImage(any(), anyInt(), anyInt(), any());
    }

    @Test
    void testDrawItem_ItemLabelVisible() {
        renderer.setBaseShapesVisible(false);
        when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        // Unable to verify drawItemLabel without further mocking
    }

    @Test
    void testDrawItem_EntityCollection_NotNull_PointInDataArea() {
        EntityCollection entities = mock(EntityCollection.class);
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(entities);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        Shape shape = new Rectangle2D.Double(40, 40, 10, 10);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(entities).add(any(), eq(dataset), eq(0), eq(0), eq(50.0), eq(50.0));
    }

    @Test
    void testDrawItem_EntityCollection_Null() {
        when(info.getOwner()).thenReturn(mock(org.jfree.chart.ChartRenderingInfo.class));
        when(info.getOwner().getEntityCollection()).thenReturn(null);
        renderer.setPlotImages(false);
        renderer.setBaseShapesVisible(false);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        // No exception means pass
    }

    @Test
    void testDrawItem_ShapeDoesNotIntersectDataArea() {
        renderer.setBaseShapesVisible(true);
        Shape shape = mock(Shape.class);
        when(shape.intersects(anyDouble(), anyDouble(), anyDouble(), anyDouble())).thenReturn(false);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getItemShapeFilled(0, 0)).thenReturn(true);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(200.0);
        when(dataset.getYValue(0, 0)).thenReturn(200.0);
        when(domainAxis.valueToJava2D(200.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(150.0);
        when(rangeAxis.valueToJava2D(200.0, dataArea, RectangleEdge.LEFT)).thenReturn(150.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_DrawNothingWhenAllFeaturesDisabled() {
        renderer.setBaseShapesVisible(false);
        renderer.setPlotLines(false);
        renderer.setPlotImages(false);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(50.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2, never()).fill(any(Shape.class));
        verify(g2, never()).draw(any(Shape.class));
        verify(g2, never()).drawImage(any(), anyInt(), anyInt(), any());
    }

    @Test
    void testDrawItem_NullValues() {
        assertDoesNotThrow(() -> renderer.drawItem(null, null, null, null, null, null, null, null, 0, 0, null, 0));
    }

    @Test
    void testDrawItem_HorizontalOrientation() {
        renderer.setPlotLines(false);
        renderer.setBaseShapesVisible(true);
        Shape shape = mock(Shape.class);
        when(renderer.getItemShape(0, 0)).thenReturn(shape);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(10.0);
        when(dataset.getYValue(0, 0)).thenReturn(20.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.HORIZONTAL);
        when(domainAxis.valueToJava2D(10.0, dataArea, RectangleEdge.LEFT)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(20.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(40.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        verify(g2).fill(any(Shape.class));
    }

    @Test
    void testDrawItem_LastItemNotDrawSeriesPath() {
        renderer.setPlotLines(true);
        renderer.setDrawSeriesLineAsPath(true);
        StandardXYItemRenderer.State rendererState = new StandardXYItemRenderer.State(info);
        when(state).thenReturn(rendererState);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(renderer.getItemVisible(0, 0)).thenReturn(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(20.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(30.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(40.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_DiagonalLineIntersectsDataArea() {
        renderer.setPlotLines(true);
        when(renderer.getItemVisible(0, 1)).thenReturn(true);
        when(dataset.getItemCount(0)).thenReturn(2);
        when(dataset.getXValue(0, 0)).thenReturn(1.0);
        when(dataset.getYValue(0, 0)).thenReturn(1.0);
        when(dataset.getXValue(0, 1)).thenReturn(2.0);
        when(dataset.getYValue(0, 1)).thenReturn(2.0);
        when(plot.getOrientation()).thenReturn(org.jfree.chart.plot.PlotOrientation.VERTICAL);
        when(domainAxis.valueToJava2D(1.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(10.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, RectangleEdge.LEFT)).thenReturn(10.0);
        when(domainAxis.valueToJava2D(2.0, dataArea, RectangleEdge.BOTTOM)).thenReturn(90.0);
        when(rangeAxis.valueToJava2D(2.0, dataArea, RectangleEdge.LEFT)).thenReturn(90.0);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 1, crosshairState, 0);
        verify(g2).draw(any(Shape.class));
    }

    @Test
    void testDrawItem_SeriesPathResetOnNewSeries() {
        renderer.setPlotLines(true);
        renderer.setDrawSeriesLineAsPath(true);
        StandardXYItemRenderer.State state = new StandardXYItemRenderer.State(info);
        rendererState = state;
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, 0);
        assertEquals(-1, state.getSeriesIndex());
        // Further implementation would require more detailed state tracking
    }
}