import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;

import org.jfree.chart.block.Block;
import org.jfree.chart.block.BlockContainer;
import org.jfree.chart.block.RectangleConstraint;
import org.jfree.chart.ui.LengthConstraintType;
import org.jfree.chart.ui.Range;
import org.jfree.chart.ui.Size2D;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BorderArrangementTest {

    private BorderArrangement arrangement;
    private BlockContainer container;
    private Graphics2D g2;
    private RectangleConstraint constraint;

    @BeforeEach
    void setUp() {
        arrangement = new BorderArrangement();
        container = mock(BlockContainer.class);
        g2 = mock(Graphics2D.class);
    }

    @Test
    void testArrange_NN() {
        constraint = new RectangleConstraint();
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(container.calculateTotalWidth(anyDouble())).thenReturn(100.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(100.0);

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertNotNull(size);
    }

    @Test
    void testArrange_N_FIXEDHeight_ThrowsException() {
        constraint = new RectangleConstraint(
                LengthConstraintType.NONE, LengthConstraintType.FIXED);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        assertThrows(RuntimeException.class, () -> {
            arrangement.arrange(container, g2, constraint);
        });
    }

    @Test
    void testArrange_N_RANGEHeight_ThrowsException() {
        constraint = new RectangleConstraint(
                LengthConstraintType.NONE, LengthConstraintType.RANGE);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        assertThrows(RuntimeException.class, () -> {
            arrangement.arrange(container, g2, constraint);
        });
    }

    @Test
    void testArrange_FIXEDWidth_NONEHeight() {
        constraint = new RectangleConstraint();
        constraint = new RectangleConstraint(100.0, null, LengthConstraintType.FIXED,
                null, null, LengthConstraintType.NONE);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(container.calculateTotalWidth(anyDouble())).thenReturn(100.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(100.0);

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertNotNull(size);
    }

    @Test
    void testArrange_FIXEDWidth_FIXEDHeight() {
        constraint = new RectangleConstraint(100.0, 200.0, 
                LengthConstraintType.FIXED, LengthConstraintType.FIXED);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(container.calculateTotalWidth(anyDouble())).thenReturn(100.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(200.0);

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertNotNull(size);
    }

    @Test
    void testArrange_FIXEDWidth_RANGEHeight() {
        constraint = new RectangleConstraint(100.0, new Range(150.0, 250.0), 
                LengthConstraintType.FIXED, LengthConstraintType.RANGE);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(container.calculateTotalWidth(anyDouble())).thenReturn(100.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(200.0);

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertNotNull(size);
    }

    @Test
    void testArrange_RANGEWidth_NONEHeight_ThrowsException() {
        constraint = new RectangleConstraint(new Range(50.0, 150.0), null, 
                LengthConstraintType.RANGE, LengthConstraintType.NONE);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        assertThrows(RuntimeException.class, () -> {
            arrangement.arrange(container, g2, constraint);
        });
    }

    @Test
    void testArrange_RANGEWidth_FIXEDHeight_ThrowsException() {
        constraint = new RectangleConstraint(new Range(50.0, 150.0), 200.0, 
                LengthConstraintType.RANGE, LengthConstraintType.FIXED);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        assertThrows(RuntimeException.class, () -> {
            arrangement.arrange(container, g2, constraint);
        });
    }

    @Test
    void testArrange_RANGEWidth_RANGEHeight() {
        constraint = new RectangleConstraint(new Range(50.0, 150.0), new Range(100.0, 200.0), 
                LengthConstraintType.RANGE, LengthConstraintType.RANGE);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(container.calculateTotalWidth(anyDouble())).thenReturn(150.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(200.0);

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertNotNull(size);
    }

    @Test
    void testArrange_NullContainer_ThrowsException() {
        constraint = new RectangleConstraint();
        assertThrows(NullPointerException.class, () -> {
            arrangement.arrange(null, g2, constraint);
        });
    }

    @Test
    void testArrange_NullGraphics2D_ThrowsException() {
        constraint = new RectangleConstraint();
        when(container.toContentConstraint(any())).thenReturn(constraint);
        assertThrows(NullPointerException.class, () -> {
            arrangement.arrange(container, null, constraint);
        });
    }

    @Test
    void testArrange_NullRectangleConstraint() {
        when(container.toContentConstraint(any())).thenThrow(NullPointerException.class);
        assertThrows(NullPointerException.class, () -> {
            arrangement.arrange(container, g2, null);
        });
    }

    @Test
    void testArrange_AllBlocksNull() {
        constraint = new RectangleConstraint();
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(container.calculateTotalWidth(anyDouble())).thenReturn(0.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(0.0);

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertEquals(0.0, size.width);
        assertEquals(0.0, size.height);
    }

    @Test
    void testArrange_WithTopBlock() {
        Block topBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);
        constraint = new RectangleConstraint();
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(topBlock.arrange(any(), any())).thenReturn(new Size2D(100.0, 20.0));
        when(container.calculateTotalWidth(anyDouble())).thenReturn(100.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(20.0);

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertEquals(100.0, size.width);
        assertEquals(20.0, size.height);
    }

    @Test
    void testArrange_WithAllBlocks() {
        Block topBlock = mock(Block.class);
        Block bottomBlock = mock(Block.class);
        Block leftBlock = mock(Block.class);
        Block rightBlock = mock(Block.class);
        Block centerBlock = mock(Block.class);
        arrangement.add(topBlock, RectangleEdge.TOP);
        arrangement.add(bottomBlock, RectangleEdge.BOTTOM);
        arrangement.add(leftBlock, RectangleEdge.LEFT);
        arrangement.add(rightBlock, RectangleEdge.RIGHT);
        arrangement.add(centerBlock, null);

        constraint = new RectangleConstraint(300.0, 400.0, 
                LengthConstraintType.FIXED, LengthConstraintType.FIXED);
        when(container.toContentConstraint(any())).thenReturn(constraint);
        when(container.calculateTotalWidth(anyDouble())).thenReturn(300.0);
        when(container.calculateTotalHeight(anyDouble())).thenReturn(400.0);
        when(topBlock.arrange(any(), any())).thenReturn(new Size2D(300.0, 50.0));
        when(bottomBlock.arrange(any(), any())).thenReturn(new Size2D(300.0, 50.0));
        when(leftBlock.arrange(any(), any())).thenReturn(new Size2D(50.0, 300.0));
        when(rightBlock.arrange(any(), any())).thenReturn(new Size2D(50.0, 300.0));
        when(centerBlock.arrange(any(), any())).thenReturn(new Size2D(200.0, 300.0));

        Size2D size = arrangement.arrange(container, g2, constraint);
        assertEquals(300.0, size.width);
        assertEquals(400.0, size.height);
    }
}