package org.apache.commons.lang3.text.translate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.EnumSet;
import java.util.Set;

public class NumericEntityUnescaper_translate_0_3_Test {

    @Test
    @DisplayName("Input starts with '&&#' followed by valid decimal digits without ';', semiColonRequired is set")
    public void TC11() throws Exception {
        // GIVEN
        CharSequence input = "&&#65";
        int index = 0;
        Writer out = new StringWriter();

        // Instantiate NumericEntityUnescaper
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // Set OPTION.errorIfNoSemiColon via reflection
        Field optionsField = NumericEntityUnescaper.class.getDeclaredField("options");
        optionsField.setAccessible(true);

        // Get the OPTION enum type
        Class<?> optionEnum = Class.forName("org.apache.commons.lang3.text.translate.NumericEntityUnescaper$OPTION");

        // Get the errorIfNoSemiColon enum constant
        Object errorIfNoSemiColon = Enum.valueOf((Class<Enum>) optionEnum, "errorIfNoSemiColon");

        // Create a set with errorIfNoSemiColon
        @SuppressWarnings("unchecked")
        Set<Object> options = EnumSet.of((Enum) errorIfNoSemiColon);

        // Set the options field
        optionsField.set(unescaper, options);

        // WHEN & THEN
        assertThrows(IllegalArgumentException.class, () -> {
            unescaper.translate(input, index, out);
        });
    }

    @Test
    @DisplayName("Input starts with '&#' followed by invalid decimal digits, returns 0")
    public void TC12() throws Exception {
        // GIVEN
        CharSequence input = "&#abc;";
        int index = 0;
        Writer out = new StringWriter();

        // Instantiate NumericEntityUnescaper
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals(0, result);
    }

    @Test
    @DisplayName("Hex entity value exceeds 0xFFFF, writes surrogate pair and returns correct offset")
    public void TC13() throws Exception {
        // GIVEN
        CharSequence input = "&#x1F600;";
        int index = 0;
        Writer out = new StringWriter();

        // Instantiate NumericEntityUnescaper
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals("\uD83D\uDE00", out.toString());
        assertEquals(8, result);
    }

    @Test
    @DisplayName("Decimal entity value exceeds 0xFFFF, writes surrogate pair and returns correct offset")
    public void TC14() throws Exception {
        // GIVEN
        CharSequence input = "&#128512;";
        int index = 0;
        Writer out = new StringWriter();

        // Instantiate NumericEntityUnescaper
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals("\uD83D\uDE00", out.toString());
        assertEquals(7, result);
    }

    @Test
    @DisplayName("Hex entity value exactly 0xFFFF, writes single character and returns correct offset")
    public void TC15() throws Exception {
        // GIVEN
        CharSequence input = "&xFFFF;";
        int index = 0;
        Writer out = new StringWriter();

        // Instantiate NumericEntityUnescaper
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();

        // WHEN
        int result = unescaper.translate(input, index, out);

        // THEN
        assertEquals("\uFFFF", out.toString());
        assertEquals(7, result);
    }
}