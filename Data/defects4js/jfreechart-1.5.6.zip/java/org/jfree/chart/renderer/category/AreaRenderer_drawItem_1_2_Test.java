package org.jfree.chart.renderer.category;
import static org.mockito.Mockito.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.AreaRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AreaRenderer_drawItem_1_2_Test {

    @Test
    @DisplayName("drawItem throws NullPointerException when plot is null")
    void TC31_drawItem_ShouldThrowNullPointerException_WhenPlotIsNull() {
        // Given
        AreaRenderer renderer = new AreaRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = null;
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        int row = 0;
        int column = 0;
        int pass = 0;
        
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        });
    }
}