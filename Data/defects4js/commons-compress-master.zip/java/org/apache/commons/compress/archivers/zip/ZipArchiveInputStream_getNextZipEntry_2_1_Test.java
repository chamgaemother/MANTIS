package org.apache.commons.compress.archivers.zip;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.junit.jupiter.api.function.Executable;

public class ZipArchiveInputStream_getNextZipEntry_2_1_Test {

    @Test
    @DisplayName("Handles entries that use data descriptor by correctly reading and processing the data descriptor")
    public void TC04_handle_entry_with_data_descriptor() throws Exception {
        // GIVEN
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        ZipEntry entry = new ZipEntry("testDataDescriptor.txt");
        entry.setSize(11);
        entry.setMethod(ZipEntry.DEFLATED);
        entry.setCrc(0); // CRC will be set by ZipOutputStream
        zos.putNextEntry(entry);
        byte[] data = "Hello World".getBytes();
        zos.write(data);
        zos.closeEntry();
        zos.close();
        byte[] zipBytes = baos.toByteArray();

        // WHEN
        InputStream inputStream = new ByteArrayInputStream(zipBytes);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, "UTF-8", true);
        ZipArchiveEntry readEntry = null;

        try {
            readEntry = zipInputStream.getNextZipEntry();
        } finally {
            zipInputStream.close();
        }

        // THEN
        assertNotNull(readEntry, "ZipArchiveEntry should not be null");
        assertEquals("testDataDescriptor.txt", readEntry.getName(), "Entry name should match");
        assertEquals(11, readEntry.getSize(), "Entry size should match");
        CRC32 crc = new CRC32();
        crc.update(data);
        assertEquals(crc.getValue(), readEntry.getCrc(), "CRC should match");
    }

    @Test
    @DisplayName("Processes entries with Zip64 extra fields and correctly sets large sizes")
    public void TC05_process_zip64_extra_fields() throws Exception {
        // GIVEN
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        ZipEntry entry = new ZipEntry("largeFile.dat");
        long largeSize = (long) Integer.MAX_VALUE + 1;
        entry.setSize(largeSize);
        entry.setCompressedSize(largeSize);
        entry.setMethod(ZipEntry.STORED);
        byte[] zip64Extra = createZip64ExtraFields(largeSize, largeSize);
        entry.setExtra(zip64Extra);
        zos.putNextEntry(entry);
        byte[] data = new byte[1024];
        zos.write(data);
        zos.closeEntry();
        zos.close();
        byte[] zipBytes = baos.toByteArray();

        // WHEN
        InputStream inputStream = new ByteArrayInputStream(zipBytes);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, "UTF-8", true, true);
        ZipArchiveEntry readEntry = null;

        try {
            readEntry = zipInputStream.getNextZipEntry();
        } finally {
            zipInputStream.close();
        }

        // THEN
        assertNotNull(readEntry, "ZipArchiveEntry should not be null");
        assertEquals("largeFile.dat", readEntry.getName(), "Entry name should match");
        assertEquals(largeSize, readEntry.getSize(), "Entry size should match large size");
        assertEquals(largeSize, readEntry.getCompressedSize(), "Compressed size should match large size");
    }

    @Test
    @DisplayName("Handles stored entries that use data descriptor by reading data without decompressing")
    public void TC06_handle_stored_entry_with_data_descriptor() throws Exception {
        // GIVEN
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        ZipEntry entry = new ZipEntry("storedDataDescriptor.txt");
        entry.setMethod(ZipEntry.STORED);
        String content = "Stored Data";
        byte[] data = content.getBytes();
        entry.setSize(data.length);
        entry.setCompressedSize(data.length);
        CRC32 crc = new CRC32();
        crc.update(data);
        entry.setCrc(crc.getValue());
        zos.putNextEntry(entry);
        zos.write(data);
        zos.closeEntry();
        zos.close();
        byte[] zipBytes = baos.toByteArray();

        // WHEN
        InputStream inputStream = new ByteArrayInputStream(zipBytes);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, "UTF-8", true, true);
        ZipArchiveEntry readEntry = null;

        try {
            readEntry = zipInputStream.getNextZipEntry();
        } finally {
            zipInputStream.close();
        }

        // THEN
        assertNotNull(readEntry, "ZipArchiveEntry should not be null");
        assertEquals("storedDataDescriptor.txt", readEntry.getName(), "Entry name should match");
        assertEquals(data.length, readEntry.getSize(), "Entry size should match");
        assertEquals(crc.getValue(), readEntry.getCrc(), "CRC should match");
    }

//     @Test
//     @DisplayName("Throws ZipException when Zip64 extra fields are corrupted")
//     public void TC07_corrupted_zip64_extra_fields_throws_exception() throws Exception {
        // GIVEN
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         ZipOutputStream zos = new ZipOutputStream(baos);
//         ZipEntry entry = new ZipEntry("corruptedZip64.dat");
//         long largeSize = (long) Integer.MAX_VALUE + 1;
//         entry.setSize(largeSize);
//         entry.setCompressedSize(largeSize);
//         entry.setMethod(ZipEntry.STORED);
//         byte[] corruptedZip64Extra = new byte[] { 0x1D, (byte) 0xC7, 0x00, 0x00 }; // Invalid data
//         entry.setExtra(corruptedZip64Extra);
//         zos.putNextEntry(entry);
//         byte[] data = new byte[1024];
//         zos.write(data);
//         zos.closeEntry();
//         zos.close();
//         byte[] zipBytes = baos.toByteArray();
// 
        // WHEN & THEN
//         InputStream inputStream = new ByteArrayInputStream(zipBytes);
//         ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, "UTF-8", true, true);
// 
//         ZipException exception = assertThrows(ZipException.class, zipInputStream::getNextZipEntry, "Expected ZipException due to corrupted Zip64 extra fields");
// 
//         assertTrue(exception.getMessage().contains("corrupted zip64 extra field"), "Exception message should indicate corrupted Zip64 extra fields");
//     }

    @Test
    @DisplayName("Processes multiple entries with mixed compression methods and data descriptors to ensure correct iteration")
    public void TC08_multiple_entries_mixed_compression_and_data_descriptors() throws Exception {
        // GIVEN
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);

        // Entry 1: DEFLATED with data descriptor
        ZipEntry entry1 = new ZipEntry("deflatedEntry.txt");
        entry1.setMethod(ZipEntry.DEFLATED);
        String content1 = "Deflated Content";
        byte[] data1 = content1.getBytes();
        zos.putNextEntry(entry1);
        zos.write(data1);
        zos.closeEntry();

        // Entry 2: STORED with data descriptor
        ZipEntry entry2 = new ZipEntry("storedEntry.txt");
        entry2.setMethod(ZipEntry.STORED);
        String content2 = "Stored Content";
        byte[] data2 = content2.getBytes();
        CRC32 crc2 = new CRC32();
        crc2.update(data2);
        entry2.setSize(data2.length);
        entry2.setCompressedSize(data2.length);
        entry2.setCrc(crc2.getValue());
        zos.putNextEntry(entry2);
        zos.write(data2);
        zos.closeEntry();

        // Entry 3: Deflate
        ZipEntry entry3 = new ZipEntry("deflateEntry.bz2");
        entry3.setMethod(ZipEntry.DEFLATED);
        byte[] data3 = "BZip2 Content".getBytes();
        zos.putNextEntry(entry3);
        zos.write(data3);
        zos.closeEntry();

        zos.close();
        byte[] zipBytes = baos.toByteArray();

        // WHEN
        InputStream inputStream = new ByteArrayInputStream(zipBytes);
        ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(inputStream, "UTF-8", true, true);

        try {
            // THEN
            // Entry 1
            ZipArchiveEntry readEntry1 = zipInputStream.getNextZipEntry();
            assertNotNull(readEntry1, "First entry should not be null");
            assertEquals("deflatedEntry.txt", readEntry1.getName(), "First entry name should match");
            assertEquals(ZipEntry.DEFLATED, readEntry1.getMethod(), "First entry method should be DEFLATED");
            // Read entry1 data
            byte[] buffer1 = new byte[data1.length];
            int bytesRead1 = zipInputStream.read(buffer1);
            assertEquals(data1.length, bytesRead1, "First entry data length should match");
            assertArrayEquals(data1, buffer1, "First entry data should match");

            // Entry 2
            ZipArchiveEntry readEntry2 = zipInputStream.getNextZipEntry();
            assertNotNull(readEntry2, "Second entry should not be null");
            assertEquals("storedEntry.txt", readEntry2.getName(), "Second entry name should match");
            assertEquals(ZipEntry.STORED, readEntry2.getMethod(), "Second entry method should be STORED");
            assertEquals(data2.length, readEntry2.getSize(), "Second entry size should match");
            assertEquals(crc2.getValue(), readEntry2.getCrc(), "Second entry CRC should match");

            // Read entry2 data
            byte[] buffer2 = new byte[data2.length];
            int bytesRead2 = zipInputStream.read(buffer2);
            assertEquals(data2.length, bytesRead2, "Second entry data length should match");
            assertArrayEquals(data2, buffer2, "Second entry data should match");

            // Entry 3
            ZipArchiveEntry readEntry3 = zipInputStream.getNextZipEntry();
            assertNotNull(readEntry3, "Third entry should not be null");
            assertEquals("deflateEntry.bz2", readEntry3.getName(), "Third entry name should match");
            assertEquals(ZipEntry.DEFLATED, readEntry3.getMethod(), "Third entry method should be DEFLATED");

            // Read entry3 data
            byte[] buffer3 = new byte[data3.length];
            int bytesRead3 = zipInputStream.read(buffer3);
            assertEquals(data3.length, bytesRead3, "Third entry data length should match");
            assertArrayEquals(data3, buffer3, "Third entry data should match");
        } finally {
            zipInputStream.close();
        }

        // No more entries
        ZipArchiveEntry readEntry4 = zipInputStream.getNextZipEntry();
        assertNull(readEntry4, "There should be no more entries");
    }

    // Helper method to create Zip64 extra fields for large sizes
    private byte[] createZip64ExtraFields(long size, long compressedSize) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos.write(0x1D);
        baos.write(0x0B);
        baos.write(new byte[] {0x10, 0x00});
        baos.write(longToLittleEndian(size));
        baos.write(longToLittleEndian(compressedSize));
        return baos.toByteArray();
    }

    // Helper method to convert long to little endian byte array
    private byte[] longToLittleEndian(long value) {
        byte[] bytes = new byte[8];
        for (int i = 0; i < 8; i++) {
            bytes[i] = (byte) (value >>> (i * 8));
        }
        return bytes;
    }
}