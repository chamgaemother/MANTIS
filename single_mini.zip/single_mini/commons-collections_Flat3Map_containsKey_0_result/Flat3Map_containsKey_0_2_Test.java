package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.AbstractMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_containsKey_0_2_Test {

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is null, size is 2, and key2 is not null")
    void TC06_containsKey_delegateMapNull_keyNull_size2_key2NotNull() throws Exception {
        // Initialize Flat3Map with delegateMap as null, set size to 2, and key2 to a non-null value
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to set private fields
        Class<?> clazz = Flat3Map.class;

        // Set delegateMap to null
        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 2
        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 2);

        // Set key2 to a non-null value
        Field key2Field = clazz.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object nonNullKey2 = new Object();
        key2Field.set(flat3Map, nonNullKey2);

        // Set hash2 (assuming it's needed based on the method logic)
        Field hash2Field = clazz.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(flat3Map, nonNullKey2.hashCode());

        Object key = null;

        // Invoke containsKey using reflection
        Method containsKeyMethod = clazz.getDeclaredMethod("containsKey", Object.class);
        containsKeyMethod.setAccessible(true);
        boolean result = (boolean) containsKeyMethod.invoke(flat3Map, key);

        // Assert the result is false
        assertFalse(result, "Expected containsKey to return false");
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is null, size is 1, and key1 is null")
    void TC07_containsKey_delegateMapNull_keyNull_size1_key1Null() throws Exception {
        // Initialize Flat3Map with delegateMap as null, set size to 1, and key1 to null
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to set private fields
        Class<?> clazz = Flat3Map.class;

        // Set delegateMap to null
        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 1
        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 1);

        // Set key1 to null
        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(flat3Map, null);

        Object key = null;

        // Invoke containsKey using reflection
        Method containsKeyMethod = clazz.getDeclaredMethod("containsKey", Object.class);
        containsKeyMethod.setAccessible(true);
        boolean result = (boolean) containsKeyMethod.invoke(flat3Map, key);

        // Assert the result is true
        assertTrue(result, "Expected containsKey to return true");
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is null, size is 1, and key1 is not null")
    void TC08_containsKey_delegateMapNull_keyNull_size1_key1NotNull() throws Exception {
        // Initialize Flat3Map with delegateMap as null, set size to 1, and key1 to a non-null value
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to set private fields
        Class<?> clazz = Flat3Map.class;

        // Set delegateMap to null
        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 1
        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 1);

        // Set key1 to a non-null value
        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object nonNullKey1 = new Object();
        key1Field.set(flat3Map, nonNullKey1);

        // Set hash1 (assuming it's needed based on the method logic)
        Field hash1Field = clazz.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(flat3Map, nonNullKey1.hashCode());

        Object key = null;

        // Invoke containsKey using reflection
        Method containsKeyMethod = clazz.getDeclaredMethod("containsKey", Object.class);
        containsKeyMethod.setAccessible(true);
        boolean result = (boolean) containsKeyMethod.invoke(flat3Map, key);

        // Assert the result is false
        assertFalse(result, "Expected containsKey to return false");
    }

    @Test
    @DisplayName("containsKey returns false when delegateMap is null, key is not null, and size is 0")
    void TC09_containsKey_delegateMapNull_keyNotNull_size0() throws Exception {
        // Initialize Flat3Map with delegateMap as null and set size to 0
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Using reflection to set private fields
        Class<?> clazz = Flat3Map.class;

        // Set delegateMap to null
        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 0
        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 0);

        // Define a non-null key
        Object key = new Object();

        // Invoke containsKey using reflection
        Method containsKeyMethod = clazz.getDeclaredMethod("containsKey", Object.class);
        containsKeyMethod.setAccessible(true);
        boolean result = (boolean) containsKeyMethod.invoke(flat3Map, key);

        // Assert the result is false
        assertFalse(result, "Expected containsKey to return false");
    }

    @Test
    @DisplayName("containsKey returns true when delegateMap is null, key is not null, size is 1, hash matches, and key equals key1")
    void TC10_containsKey_delegateMapNull_keyNotNull_size1_hashMatch_keyEquals() throws Exception {
        // Initialize Flat3Map with delegateMap as null, set size to 1, set hash1 to key.hashCode(), and set key1 to a key equal to the specified key
        Flat3Map<Object, Object> flat3Map = new Flat3Map<>();

        // Define the specific key
        Object specificKey = "testKey"; // Example key, can be any object
        int specificHash = specificKey.hashCode();

        // Using reflection to set private fields
        Class<?> clazz = Flat3Map.class;

        // Set delegateMap to null
        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(flat3Map, null);

        // Set size to 1
        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(flat3Map, 1);

        // Set key1 to the specific key
        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(flat3Map, specificKey);

        // Set hash1 to key.hashCode()
        Field hash1Field = clazz.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(flat3Map, specificHash);

        Object key = specificKey;

        // Invoke containsKey using reflection
        Method containsKeyMethod = clazz.getDeclaredMethod("containsKey", Object.class);
        containsKeyMethod.setAccessible(true);
        boolean result = (boolean) containsKeyMethod.invoke(flat3Map, key);

        // Assert the result is true
        assertTrue(result, "Expected containsKey to return true");
    }
}