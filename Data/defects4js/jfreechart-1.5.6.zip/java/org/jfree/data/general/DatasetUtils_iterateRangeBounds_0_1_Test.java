package org.jfree.data.general;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import org.jfree.data.Range;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.general.DatasetUtils;

public class DatasetUtils_iterateRangeBounds_0_1_Test {

//     @Test
//     @DisplayName("includeInterval=false with standard XYDataset having no series, expecting null return")
//     public void TC01() {
//         XYDataset dataset = new XYDataset() {
//             @Override
//             public int getSeriesCount() {
//                 return 0;
//             }
// 
//             @Override
//             public Comparable getSeriesKey(int series) {
//                 return null;
//             }
// 
//             @Override
//             public int getItemCount(int series) {
//                 return 0;
//             }
// 
//             @Override
//             public Number getX(int series, int item) {
//                 return null;
//             }
// 
//             @Override
//             public Number getY(int series, int item) {
//                 return null;
//             }
//         };
// 
//         boolean includeInterval = false;
//         Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
//         Assertions.assertNull(result);
//     }

//     @Test
//     @DisplayName("includeInterval=false with standard XYDataset having one series and one non-NaN item")
//     public void TC02() {
//         XYDataset dataset = new XYDataset() {
//             @Override
//             public int getSeriesCount() {
//                 return 1;
//             }
// 
//             @Override
//             public Comparable getSeriesKey(int series) {
//                 return "Series1";
//             }
// 
//             @Override
//             public int getItemCount(int series) {
//                 return 1;
//             }
// 
//             @Override
//             public Number getX(int series, int item) {
//                 return 0;
//             }
// 
//             @Override
//             public Number getY(int series, int item) {
//                 return 10.5;
//             }
//         };
// 
//         boolean includeInterval = false;
//         Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
//         Assertions.assertNotNull(result);
//         Assertions.assertEquals(10.5, result.getLowerBound(), 0.0001);
//         Assertions.assertEquals(10.5, result.getUpperBound(), 0.0001);
//     }

//     @Test
//     @DisplayName("includeInterval=false with standard XYDataset having multiple series and multiple items")
//     public void TC03() {
//         XYDataset dataset = new XYDataset() {
//             @Override
//             public int getSeriesCount() {
//                 return 2;
//             }
// 
//             @Override
//             public Comparable getSeriesKey(int series) {
//                 return "Series" + (series + 1);
//             }
// 
//             @Override
//             public int getItemCount(int series) {
//                 return 2;
//             }
// 
//             @Override
//             public Number getX(int series, int item) {
//                 return 0;
//             }
// 
//             @Override
//             public Number getY(int series, int item) {
//                 if (series == 0) {
//                     return (item == 0) ? 5.0 : 15.0;
//                 } else {
//                     return (item == 0) ? 5.0 : 15.0;
//                 }
//             }
//         };
// 
//         boolean includeInterval = false;
//         Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
//         Assertions.assertNotNull(result);
//         Assertions.assertEquals(5.0, result.getLowerBound(), 0.0001);
//         Assertions.assertEquals(15.0, result.getUpperBound(), 0.0001);
//     }

//     @Test
//     @DisplayName("includeInterval=true with IntervalXYDataset having no series, expecting null return")
//     public void TC04() {
//         IntervalXYDataset dataset = new IntervalXYDataset() {
//             @Override
//             public int getSeriesCount() {
//                 return 0;
//             }
// 
//             @Override
//             public Comparable getSeriesKey(int series) {
//                 return null;
//             }
// 
//             @Override
//             public int getItemCount(int series) {
//                 return 0;
//             }
// 
//             @Override
//             public Number getX(int series, int item) {
//                 return null;
//             }
// 
//             @Override
//             public Number getY(int series, int item) {
//                 return null;
//             }
// 
//             @Override
//             public Number getStartX(int series, int item) {
//                 return null;
//             }
// 
//             @Override
//             public Number getEndX(int series, int item) {
//                 return null;
//             }
// 
//             @Override
//             public Number getStartY(int series, int item) {
//                 return null;
//             }
// 
//             @Override
//             public Number getEndY(int series, int item) {
//                 return null;
//             }
//         };
// 
//         boolean includeInterval = true;
//         Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
//         Assertions.assertNull(result);
//     }

//     @Test
//     @DisplayName("includeInterval=true with IntervalXYDataset having one series and one item with non-NaN values")
//     public void TC05() {
//         IntervalXYDataset dataset = new IntervalXYDataset() {
//             @Override
//             public int getSeriesCount() {
//                 return 1;
//             }
// 
//             @Override
//             public Comparable getSeriesKey(int series) {
//                 return "Series1";
//             }
// 
//             @Override
//             public int getItemCount(int series) {
//                 return 1;
//             }
// 
//             @Override
//             public Number getX(int series, int item) {
//                 return 0;
//             }
// 
//             @Override
//             public Number getY(int series, int item) {
//                 return 10.0;
//             }
// 
//             @Override
//             public Number getStartX(int series, int item) {
//                 return 0;
//             }
// 
//             @Override
//             public Number getEndX(int series, int item) {
//                 return 0;
//             }
// 
//             @Override
//             public Number getStartY(int series, int item) {
//                 return 8.0;
//             }
// 
//             @Override
//             public Number getEndY(int series, int item) {
//                 return 12.0;
//             }
//         };
// 
//         boolean includeInterval = true;
//         Range result = DatasetUtils.iterateRangeBounds(dataset, includeInterval);
//         Assertions.assertNotNull(result);
//         Assertions.assertEquals(8.0, result.getLowerBound(), 0.0001);
//         Assertions.assertEquals(12.0, result.getUpperBound(), 0.0001);
//     }
}