package org.apache.commons.math3.stat.descriptive;

import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Precision;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class MultivariateSummaryStatistics_equals_0_1_Test {
//
//    @Test
//    @DisplayName("Equals returns true when the object is the same instance as this")
//    void TC01_equals_SameInstance() throws Exception {
//        // GIVEN
//        MultivariateSummaryStatistics stats = new MultivariateSummaryStatistics(2, true);
//        Object obj = stats;
//
//        // WHEN
//        boolean result = stats.equals(obj);
//
//        // THEN
//        assertTrue(result, "Expected equals to return true for the same instance");
//    }
//
//    @Test
//    @DisplayName("Equals returns false when the object is not an instance of MultivariateSummaryStatistics")
//    void TC02_equals_DifferentObjectType() throws Exception {
//        // GIVEN
//        MultivariateSummaryStatistics stats = new MultivariateSummaryStatistics(2, true);
//        Object obj = new Object();
//
//        // WHEN
//        boolean result = stats.equals(obj);
//
//        // THEN
//        assertFalse(result, "Expected equals to return false for different object types");
//    }
//
//    @Test
//    @DisplayName("Equals returns true when all statistical summaries are equal")
//    void TC03_equals_AllSummariesEqual() throws Exception {
//        // GIVEN
//        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
//        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
//
//        // Using reflection to set identical statistical summaries
//        setPrivateField(stats1, "geoMeanImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats2, "geoMeanImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats1, "maxImpl", newStorelessArray(5.0, 6.0));
//        setPrivateField(stats2, "maxImpl", newStorelessArray(5.0, 6.0));
//        setPrivateField(stats1, "meanImpl", newStorelessArray(3.0, 4.0));
//        setPrivateField(stats2, "meanImpl", newStorelessArray(3.0, 4.0));
//        setPrivateField(stats1, "minImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats2, "minImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats1, "n", 100L);
//        setPrivateField(stats2, "n", 100L);
//        setPrivateField(stats1, "sumImpl", newStorelessArray(300.0, 400.0));
//        setPrivateField(stats2, "sumImpl", newStorelessArray(300.0, 400.0));
//        setPrivateField(stats1, "sumSqImpl", newStorelessArray(900.0, 1600.0));
//        setPrivateField(stats2, "sumSqImpl", newStorelessArray(900.0, 1600.0));
//        setPrivateField(stats1, "sumLogImpl", newStorelessArray(10.0, 20.0));
//        setPrivateField(stats2, "sumLogImpl", newStorelessArray(10.0, 20.0));
//        setPrivateField(stats1, "covarianceImpl", new MultivariateStatisticDummy());
//        setPrivateField(stats2, "covarianceImpl", new MultivariateStatisticDummy());
//
//        // WHEN
//        boolean result = stats1.equals(stats2);
//
//        // THEN
//        assertTrue(result, "Expected equals to return true when all summaries are equal");
//    }
//
//    @Test
//    @DisplayName("Equals returns false when geometric means are not equal")
//    void TC04_equals_DifferentGeometricMeans() throws Exception {
//        // GIVEN
//        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
//        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
//
//        // Using reflection to set different geometric means
//        setPrivateField(stats1, "geoMeanImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats2, "geoMeanImpl", newStorelessArray(1.0, 3.0));
//        // Set other summaries to be equal
//        setPrivateField(stats1, "maxImpl", newStorelessArray(5.0, 6.0));
//        setPrivateField(stats2, "maxImpl", newStorelessArray(5.0, 6.0));
//        setPrivateField(stats1, "meanImpl", newStorelessArray(3.0, 4.0));
//        setPrivateField(stats2, "meanImpl", newStorelessArray(3.0, 4.0));
//        setPrivateField(stats1, "minImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats2, "minImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats1, "n", 100L);
//        setPrivateField(stats2, "n", 100L);
//        setPrivateField(stats1, "sumImpl", newStorelessArray(300.0, 400.0));
//        setPrivateField(stats2, "sumImpl", newStorelessArray(300.0, 400.0));
//        setPrivateField(stats1, "sumSqImpl", newStorelessArray(900.0, 1600.0));
//        setPrivateField(stats2, "sumSqImpl", newStorelessArray(900.0, 1600.0));
//        setPrivateField(stats1, "sumLogImpl", newStorelessArray(10.0, 20.0));
//        setPrivateField(stats2, "sumLogImpl", newStorelessArray(10.0, 20.0));
//        setPrivateField(stats1, "covarianceImpl", new MultivariateStatisticDummy());
//        setPrivateField(stats2, "covarianceImpl", new MultivariateStatisticDummy());
//
//        // WHEN
//        boolean result = stats1.equals(stats2);
//
//        // THEN
//        assertFalse(result, "Expected equals to return false when geometric means differ");
//    }
//
//    @Test
//    @DisplayName("Equals returns false when maximum values are not equal")
//    void TC05_equals_DifferentMaxValues() throws Exception {
//        // GIVEN
//        MultivariateSummaryStatistics stats1 = new MultivariateSummaryStatistics(2, true);
//        MultivariateSummaryStatistics stats2 = new MultivariateSummaryStatistics(2, true);
//
//        // Using reflection to set different max values
//        setPrivateField(stats1, "maxImpl", newStorelessArray(5.0, 6.0));
//        setPrivateField(stats2, "maxImpl", newStorelessArray(5.0, 7.0));
//        // Set other summaries to be equal
//        setPrivateField(stats1, "geoMeanImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats2, "geoMeanImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats1, "meanImpl", newStorelessArray(3.0, 4.0));
//        setPrivateField(stats2, "meanImpl", newStorelessArray(3.0, 4.0));
//        setPrivateField(stats1, "minImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats2, "minImpl", newStorelessArray(1.0, 2.0));
//        setPrivateField(stats1, "n", 100L);
//        setPrivateField(stats2, "n", 100L);
//        setPrivateField(stats1, "sumImpl", newStorelessArray(300.0, 400.0));
//        setPrivateField(stats2, "sumImpl", newStorelessArray(300.0, 400.0));
//        setPrivateField(stats1, "sumSqImpl", newStorelessArray(900.0, 1600.0));
//        setPrivateField(stats2, "sumSqImpl", newStorelessArray(900.0, 1600.0));
//        setPrivateField(stats1, "sumLogImpl", newStorelessArray(10.0, 20.0));
//        setPrivateField(stats2, "sumLogImpl", newStorelessArray(10.0, 20.0));
//        setPrivateField(stats1, "covarianceImpl", new MultivariateStatisticDummy());
//        setPrivateField(stats2, "covarianceImpl", new MultivariateStatisticDummy());
//
//        // WHEN
//        boolean result = stats1.equals(stats2);
//
//        // THEN
//        assertFalse(result, "Expected equals to return false when maximum values differ");
//    }
//
//    // Helper method to set private fields using reflection
//    private void setPrivateField(MultivariateSummaryStatistics stats, String fieldName, Object value) throws Exception {
//        Field field = MultivariateSummaryStatistics.class.getDeclaredField(fieldName);
//        field.setAccessible(true);
//        field.set(stats, value);
//    }
//
//    // Helper method to create an array of StorelessUnivariateStatistic with predefined values
//    private StorelessUnivariateStatistic[] newStorelessArray(double... values) {
//        StorelessUnivariateStatistic[] array = new StorelessUnivariateStatistic[values.length];
//        for (int i = 0; i < values.length; i++) {
//            StorelessUnivariateStatistic stat = mock(StorelessUnivariateStatistic.class);
//            when(stat.getResult()).thenReturn(values[i]);
//            array[i] = stat;
//        }
//        return array;
//    }
//
//    // Dummy class to represent covariance implementation
//    private static class MultivariateStatisticDummy {
//        @Override
//        public boolean equals(Object obj) {
//            return obj != null && obj.getClass() == this.getClass();
//        }
//    }
}
