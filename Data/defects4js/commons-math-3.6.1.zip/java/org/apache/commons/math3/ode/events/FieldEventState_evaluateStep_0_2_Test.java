package org.apache.commons.math3.ode.events;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

import org.apache.commons.math3.RealFieldElement;
import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;
import org.apache.commons.math3.analysis.solvers.AllowedSolution;
import org.apache.commons.math3.analysis.solvers.BracketedRealFieldUnivariateSolver;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.ode.FieldODEStateAndDerivative;
import org.apache.commons.math3.ode.sampling.FieldStepInterpolator;
import org.apache.commons.math3.util.Decimal64;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class FieldEventState_evaluateStep_0_2_Test {

    @Test
    @DisplayName("Evaluate step with sign change near previous event time within convergence")
    public void TC06_evaluateStep_signChangeNearPreviousEventTimeWithinConvergence() throws Exception {
        // Arrange
        FieldStepInterpolator<Decimal64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Decimal64> currentState = mock(FieldODEStateAndDerivative.class);
        when(interpolator.getCurrentState()).thenReturn(currentState);
        when(currentState.getTime()).thenReturn(new Decimal64(1.0));

        // Mocking handler and solver
        FieldEventHandler<Decimal64> handler = mock(FieldEventHandler.class);
        when(handler.g(any())).thenReturn(new Decimal64(0.0));

        BracketedRealFieldUnivariateSolver<Decimal64> solver = mock(BracketedRealFieldUnivariateSolver.class);
        when(solver.solve(anyInt(), any(RealFieldUnivariateFunction.class), any(Decimal64.class), any(Decimal64.class), eq(AllowedSolution.RIGHT_SIDE))).thenReturn(new Decimal64(1.0));

        // Instantiate FieldEventState
        FieldEventState<Decimal64> eventState = new FieldEventState<>(handler, 1.0, new Decimal64(1.0), 100, solver);

        // Set previousEventTime to be near the root
        Field previousEventTimeField = FieldEventState.class.getDeclaredField("previousEventTime");
        previousEventTimeField.setAccessible(true);
        previousEventTimeField.set(eventState, new Decimal64(1.0 - 1e-11));

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertTrue(result, "Expected evaluateStep to return true");

        // Verify pendingEventTime is set
        Field pendingEventTimeField = FieldEventState.class.getDeclaredField("pendingEventTime");
        pendingEventTimeField.setAccessible(true);
        Decimal64 pendingEventTime = (Decimal64) pendingEventTimeField.get(eventState);
        assertNotNull(pendingEventTime, "Expected pendingEventTime to be set");
    }

    @Test
    @DisplayName("Evaluate step with multiple sign changes leading to multiple events")
    public void TC07_evaluateStep_multipleSignChangesMultipleEvents() throws Exception {
        // Arrange
        FieldStepInterpolator<Decimal64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Decimal64> currentState = mock(FieldODEStateAndDerivative.class);
        when(interpolator.getCurrentState()).thenReturn(currentState);
        when(currentState.getTime()).thenReturn(new Decimal64(2.0));

        // Mocking handler and solver
        FieldEventHandler<Decimal64> handler = mock(FieldEventHandler.class);
        when(handler.g(any())).thenReturn(new Decimal64(-1.0), new Decimal64(1.0), new Decimal64(-1.0));

        BracketedRealFieldUnivariateSolver<Decimal64> solver = mock(BracketedRealFieldUnivariateSolver.class);
        when(solver.solve(anyInt(), any(RealFieldUnivariateFunction.class), any(Decimal64.class), any(Decimal64.class), eq(AllowedSolution.RIGHT_SIDE))).thenReturn(new Decimal64(1.0));

        // Instantiate FieldEventState
        FieldEventState<Decimal64> eventState = new FieldEventState<>(handler, 1.0, new Decimal64(2.0), 100, solver);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertTrue(result, "Expected evaluateStep to return true on first event detection");

        // Verify pendingEvent is handled
        Field pendingEventField = FieldEventState.class.getDeclaredField("pendingEvent");
        pendingEventField.setAccessible(true);
        Boolean pendingEvent = (Boolean) pendingEventField.get(eventState);
        assertTrue(pendingEvent, "Expected pendingEvent to be true");
    }

    @Test
    @DisplayName("Evaluate step with solver finding root on RIGHT_SIDE")
    public void TC08_evaluateStep_solverFindsRootOnRightSide() throws Exception {
        // Arrange
        FieldStepInterpolator<Decimal64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(true);

        FieldODEStateAndDerivative<Decimal64> currentState = mock(FieldODEStateAndDerivative.class);
        when(interpolator.getCurrentState()).thenReturn(currentState);
        when(currentState.getTime()).thenReturn(new Decimal64(3.0));

        // Mocking handler and solver
        FieldEventHandler<Decimal64> handler = mock(FieldEventHandler.class);
        when(handler.g(any())).thenReturn(new Decimal64(-1.0), new Decimal64(1.0));

        BracketedRealFieldUnivariateSolver<Decimal64> solver = mock(BracketedRealFieldUnivariateSolver.class);
        when(solver.solve(anyInt(), any(RealFieldUnivariateFunction.class), any(Decimal64.class), any(Decimal64.class), eq(AllowedSolution.RIGHT_SIDE))).thenReturn(new Decimal64(2.5));

        // Instantiate FieldEventState
        FieldEventState<Decimal64> eventState = new FieldEventState<>(handler, 1.0, new Decimal64(3.0), 100, solver);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertTrue(result, "Expected evaluateStep to return true when root is found on RIGHT_SIDE");

        // Verify root is found on right side
        Field pendingEventTimeField = FieldEventState.class.getDeclaredField("pendingEventTime");
        pendingEventTimeField.setAccessible(true);
        Decimal64 pendingEventTime = (Decimal64) pendingEventTimeField.get(eventState);
        assertEquals(new Decimal64(2.5), pendingEventTime, "Expected root to be found on RIGHT_SIDE at time 2.5");
    }

    @Test
    @DisplayName("Evaluate step with solver finding root on LEFT_SIDE")
    public void TC09_evaluateStep_solverFindsRootOnLeftSide() throws Exception {
        // Arrange
        FieldStepInterpolator<Decimal64> interpolator = mock(FieldStepInterpolator.class);
        when(interpolator.isForward()).thenReturn(false);

        FieldODEStateAndDerivative<Decimal64> currentState = mock(FieldODEStateAndDerivative.class);
        when(interpolator.getCurrentState()).thenReturn(currentState);
        when(currentState.getTime()).thenReturn(new Decimal64(4.0));

        // Mocking handler and solver
        FieldEventHandler<Decimal64> handler = mock(FieldEventHandler.class);
        when(handler.g(any())).thenReturn(new Decimal64(1.0), new Decimal64(-1.0));

        BracketedRealFieldUnivariateSolver<Decimal64> solver = mock(BracketedRealFieldUnivariateSolver.class);
        when(solver.solve(anyInt(), any(RealFieldUnivariateFunction.class), any(Decimal64.class), any(Decimal64.class), eq(AllowedSolution.LEFT_SIDE))).thenReturn(new Decimal64(3.5));

        // Instantiate FieldEventState
        FieldEventState<Decimal64> eventState = new FieldEventState<>(handler, 1.0, new Decimal64(4.0), 100, solver);

        // Act
        boolean result = eventState.evaluateStep(interpolator);

        // Assert
        assertTrue(result, "Expected evaluateStep to return true when root is found on LEFT_SIDE");

        // Verify root is found on left side
        Field pendingEventTimeField = FieldEventState.class.getDeclaredField("pendingEventTime");
        pendingEventTimeField.setAccessible(true);
        Decimal64 pendingEventTime = (Decimal64) pendingEventTimeField.get(eventState);
        assertEquals(new Decimal64(3.5), pendingEventTime, "Expected root to be found on LEFT_SIDE at time 3.5");
    }

//    @Test
//    @DisplayName("Evaluate step with solver unable to find root within max iterations")
//    public void TC10_evaluateStep_solverFailsToFindRootWithinMaxIterations() throws Exception {
//        // Arrange
//        FieldStepInterpolator<Decimal64> interpolator = mock(FieldStepInterpolator.class);
//        when(interpolator.isForward()).thenReturn(true);
//
//        FieldODEStateAndDerivative<Decimal64> currentState = mock(FieldODEStateAndDerivative.class);
//        when(interpolator.getCurrentState()).thenReturn(currentState);
//        when(currentState.getTime()).thenReturn(new Decimal64(5.0));
//
//        // Mocking handler and solver
//        FieldEventHandler<Decimal64> handler = mock(FieldEventHandler.class);
//        when(handler.g(any())).thenReturn(new Decimal64(0.0));
//
//        BracketedRealFieldUnivariateSolver<Decimal64> solver = mock(BracketedRealFieldUnivariateSolver.class);
//        when(solver.solve(anyInt(), any(RealFieldUnivariateFunction.class), any(Decimal64.class), any(Decimal64.class), any(AllowedSolution.class)))
//            .thenThrow(new MathIllegalArgumentException("Max iterations exceeded"));
//
//        // Instantiate FieldEventState
//        FieldEventState<Decimal64> eventState = new FieldEventState<>(handler, 1.0, new Decimal64(5.0), 10, solver);
//
//        // Act
//        boolean result = eventState.evaluateStep(interpolator);
//
//        // Assert
//        assertFalse(result, "Expected evaluateStep to return false when solver fails to find root");
//
//        // Verify no event is triggered
//        Field pendingEventField = FieldEventState.class.getDeclaredField("pendingEvent");
//        pendingEventField.setAccessible(true);
//        Boolean pendingEvent = (Boolean) pendingEventField.get(eventState);
//        assertFalse(pendingEvent, "Expected no pendingEvent to be set");
//    }
}
