import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DfpTest {
    
    private DfpField field;

    @BeforeEach
    void setUp() {
        field = new DfpField(20);
    }

    @Test
    void testDivideByZero() {
        Dfp a = new Dfp(field, 1.0);
        Dfp zero = new Dfp(field, 0.0);
        Dfp result = a.divide(zero);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    void testDivideNaNDividend() {
        Dfp a = field.newDfp((byte) 1, Dfp.QNAN);
        Dfp b = new Dfp(field, 1.0);
        Dfp result = a.divide(b);
        assertSame(a, result);
    }

    @Test
    void testDivideNaNDivisor() {
        Dfp a = new Dfp(field, 1.0);
        Dfp b = field.newDfp((byte) 1, Dfp.QNAN);
        Dfp result = a.divide(b);
        assertSame(b, result);
    }

    @Test
    void testDivideBothInfinitySameSign() {
        Dfp a = field.newDfp((byte) 1, Dfp.INFINITE);
        Dfp b = field.newDfp((byte) 1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    void testDivideBothInfinityDifferentSign() {
        Dfp a = field.newDfp((byte) 1, Dfp.INFINITE);
        Dfp b = field.newDfp((byte) -1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }

    @Test
    void testDivideInfinityByFinite() {
        Dfp a = field.newDfp((byte) 1, Dfp.INFINITE);
        Dfp b = new Dfp(field, 1.0);
        Dfp result = a.divide(b);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    void testDivideFiniteByInfinity() {
        Dfp a = new Dfp(field, 1.0);
        Dfp b = field.newDfp((byte) 1, Dfp.INFINITE);
        Dfp result = a.divide(b);
        assertTrue(result.isZero());
    }

    @Test
    void testDivideNormalCases() {
        Dfp a = new Dfp(field, 8.0);
        Dfp b = new Dfp(field, 2.0);
        Dfp result = a.divide(b);
        assertEquals(new Dfp(field, 4.0), result);
    }

    @Test
    void testDivideWithZeroNumerator() {
        Dfp a = new Dfp(field, 0.0);
        Dfp b = new Dfp(field, 1.0);
        Dfp result = a.divide(b);
        assertTrue(result.isZero());
    }
    
    @Test
    void testDivideDifferentPrecision() {
        Dfp a = new Dfp(field, 8.0);
        DfpField differentField = new DfpField(10);
        Dfp b = new Dfp(differentField, 2.0);
        Dfp result = a.divide(b);
        assertTrue(result.isNaN());
    }
}