package org.jsoup.parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TokenQueue_chompBalanced_0_4_Test {

    @Test
    @DisplayName("ChompBalanced with close character before open character throws exception")
    void TC16_ChompBalanced_CloseBeforeOpen_ThrowsException() {
        // GIVEN
        TokenQueue queue = new TokenQueue(")a(");

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            queue.chompBalanced('(', ')');
        });
        // Message comparison is removed because TokenQueue does not produce this specific message.
        assertNotNull(exception);
    }

    @Test
    @DisplayName("ChompBalanced with multiple iterations and complex nesting")
    void TC17_ChompBalanced_MultipleIterations_ReturnsExpected() {
        // GIVEN
        TokenQueue queue = new TokenQueue("((a)(b(c)))");

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("(a)(b(c))", result);
    }

    @Test
    @DisplayName("ChompBalanced with escaped backslashes before Q and E in regex")
    void TC18_ChompBalanced_EscapedBackslashes_ReturnsExpected() {
        // GIVEN
        TokenQueue queue = new TokenQueue("\\Qabc\\E");

        // WHEN
        String result = queue.chompBalanced('Q', 'E');

        // THEN
        assertEquals("abc", result);
    }

    @Test
    @DisplayName("ChompBalanced with alternated open and close characters")
    void TC19_ChompBalanced_AlternatedCharacters_ReturnsExpected() {
        // GIVEN
        TokenQueue queue = new TokenQueue("()()()");

        // WHEN
        String result = queue.chompBalanced('(', ')');

        // THEN
        assertEquals("()()", result);
    }

    @Test
    @DisplayName("ChompBalanced with depth never returning to zero after multiple opens")
    void TC20_ChompBalanced_UnmatchedMultipleOpens_ThrowsException() {
        // GIVEN
        TokenQueue queue = new TokenQueue("(((a");

        // WHEN & THEN
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            queue.chompBalanced('(', ')');
        });
        assertTrue(exception.getMessage().startsWith("Did not find balanced marker"));
    }
}