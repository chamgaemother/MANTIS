import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TimeSeriesTest {

    private TimeSeries series;

    @BeforeEach
    public void setUp() {
        series = new TimeSeries("Test Series");
    }

    @Test
    public void testAddOrUpdateNullItemThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> series.addOrUpdate((TimeSeriesDataItem) null));
    }

    @Test
    public void testAddOrUpdateNullPeriodThrowsException() {
        TimeSeriesDataItem item = new TimeSeriesDataItem(null, 5.0);
        assertThrows(IllegalArgumentException.class, () -> series.addOrUpdate(item));
    }

    @Test
    public void testAddOrUpdateEmptySeriesAddsNewItem() {
        TimeSeriesDataItem item = new TimeSeriesDataItem(new Day(1, 1, 2023), 5.0);
        TimeSeriesDataItem result = series.addOrUpdate(item);
        assertNull(result);
        assertEquals(1, series.getItemCount());
    }

    @Test
    public void testAddOrUpdateDifferentTypeThrowsException() {
        RegularTimePeriod period1 = new Day(1, 1, 2023);
        RegularTimePeriod period2 = new Month(1, 2023);
        series.add(new TimeSeriesDataItem(period1, 10.0));
        assertThrows(SeriesException.class, () -> series.addOrUpdate(new TimeSeriesDataItem(period2, 20.0)));
    }

    @Test
    public void testAddOrUpdateUpdatesExistingItem() {
        TimeSeriesDataItem item = new TimeSeriesDataItem(new Day(1, 1, 2023), 5.0);
        series.add(item);
        TimeSeriesDataItem updatedItem = new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0);
        TimeSeriesDataItem overwritten = series.addOrUpdate(updatedItem);
        assertNotNull(overwritten);
        assertEquals(5.0, overwritten.getValue());
        assertEquals(10.0, series.getValue(new Day(1, 1, 2023)).doubleValue());
    }

    @Test
    public void testAddOrUpdateHandlesNaNValues() {
        TimeSeriesDataItem item = new TimeSeriesDataItem(new Day(1, 1, 2023), Double.NaN);
        series.add(item);
        TimeSeriesDataItem updatedItem = new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0);
        series.addOrUpdate(updatedItem);
        assertEquals(10.0, series.getValue(new Day(1, 1, 2023)).doubleValue());
        assertFalse(Double.isNaN(series.getMinY()));
        assertFalse(Double.isNaN(series.getMaxY()));
    }

    @Test
    public void testAddOrUpdateRetainsMinMaxValues() {
        series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
        series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 15.0));
        series.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 5.0));
        TimeSeriesDataItem updatedItem = new TimeSeriesDataItem(new Day(3, 1, 2023), 20.0);
        series.addOrUpdate(updatedItem);
        assertEquals(10.0, series.getMinY());
        assertEquals(20.0, series.getMaxY());
    }

    @ParameterizedTest
    @ValueSource(doubles = {Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY})
    public void testAddOrUpdateWithSpecialValues(double specialValue) {
        series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 5.0));
        TimeSeriesDataItem updatedItem = new TimeSeriesDataItem(new Day(1, 1, 2023), specialValue);
        series.addOrUpdate(updatedItem);
        assertEquals(specialValue, series.getValue(new Day(1, 1, 2023)).doubleValue());
        if (Double.isNaN(specialValue)) {
            assertEquals(5.0, series.getMinY());
        } else {
            assertEquals(specialValue, series.getMaxY());
        }
    }

    @Test
    public void testAddOrUpdateExceedingMaxItemCount() {
        series.setMaximumItemCount(2);
        series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
        series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 15.0));
        TimeSeriesDataItem item = new TimeSeriesDataItem(new Day(3, 1, 2023), 5.0);
        TimeSeriesDataItem overwritten = series.addOrUpdate(item);
        assertNull(overwritten);
        assertEquals(2, series.getItemCount());
        assertNull(series.getValue(new Day(1, 1, 2023)));
    }

    @Test
    public void testAddOrUpdateExceedingMaxItemAge() {
        series.setMaximumItemAge(1);
        series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
        series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 15.0));
        TimeSeriesDataItem item = new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0);
        series.addOrUpdate(item);
        series.removeAgedItems(true);
        assertEquals(1, series.getItemCount());
        assertNull(series.getValue(new Day(1, 1, 2023)));
    }
}