package org.apache.commons.collections4.iterators;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

public class PermutationIterator_next_0_1_Test {

    @Test
    @DisplayName("Throws NoSuchElementException when hasNext() returns false")
    public void TC01() throws Exception {
        // Initialize PermutationIterator instance with an empty collection
        PermutationIterator<Integer> iterator = new PermutationIterator<>(new ArrayList<>());

        // Set nextPermutation to null using reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, null);

        // Assert that NoSuchElementException is thrown when next() is called
        Assertions.assertThrows(NoSuchElementException.class, () -> {
            iterator.next();
        });
    }

    @Test
    @DisplayName("Returns nextPermutation when no mobile integer is found")
    public void TC02() throws Exception {
        // Initialize PermutationIterator instance with a specific collection
        List<Integer> initialList = new ArrayList<>();
        initialList.add(1);
        initialList.add(2);
        initialList.add(3);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);

        // Prepare nextPermutation list
        List<Integer> nextPerm = new ArrayList<>();
        nextPerm.add(1);
        nextPerm.add(2);
        nextPerm.add(3);

        // Set nextPermutation using reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, nextPerm);

        // Mock keys and direction to have no mobile integer
        int[] keys = {3, 2, 1};
        boolean[] direction = {false, false, false};

        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, keys);

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, direction);

        // Invoke next() and verify the result
        List<Integer> result = iterator.next();
        Assertions.assertEquals(nextPerm, result);

        // Verify that nextPermutation is set to null
        Object updatedNextPerm = nextPermutationField.get(iterator);
        Assertions.assertNull(updatedNextPerm);
    }

    @Test
    @DisplayName("Finds and swaps the largest mobile integer moving right")
    public void TC03() throws Exception {
        // Initialize PermutationIterator instance with a specific collection
        List<Integer> initialList = new ArrayList<>();
        initialList.add(1);
        initialList.add(3);
        initialList.add(2);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);

        // Mock keys and direction with a mobile integer moving right
        int[] keys = {1, 3, 2};
        boolean[] direction = {true, true, true};

        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, keys);

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, direction);

        // Mock objectMap
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        objectMapField.set(iterator, objectMap);

        // Invoke next()
        List<Integer> result = iterator.next();

        // Expected nextPermutation after swapping 3 and 2
        List<Integer> expected = new ArrayList<>();
        expected.add(1);
        expected.add(2);
        expected.add(3);

        Assertions.assertEquals(expected, result);

        // Verify that nextPermutation is updated correctly
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        Object updatedNextPerm = nextPermutationField.get(iterator);
        Assertions.assertNull(updatedNextPerm);

        // Verify that directions are updated
        boolean[] updatedDirection = (boolean[]) directionField.get(iterator);
        Assertions.assertArrayEquals(new boolean[]{false, false, false}, updatedDirection);
    }

    @Test
    @DisplayName("Finds and swaps the largest mobile integer moving left")
    public void TC04() throws Exception {
        // Initialize PermutationIterator instance with a specific collection
        List<Integer> initialList = new ArrayList<>();
        initialList.add(3);
        initialList.add(1);
        initialList.add(2);
        PermutationIterator<Integer> iterator = new PermutationIterator<>(initialList);

        // Mock keys and direction with a mobile integer moving left
        int[] keys = {3, 1, 2};
        boolean[] direction = {false, false, false};

        Field keysField = PermutationIterator.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(iterator, keys);

        Field directionField = PermutationIterator.class.getDeclaredField("direction");
        directionField.setAccessible(true);
        directionField.set(iterator, direction);

        // Mock objectMap
        Map<Integer, Integer> objectMap = new HashMap<>();
        objectMap.put(1, 1);
        objectMap.put(2, 2);
        objectMap.put(3, 3);

        Field objectMapField = PermutationIterator.class.getDeclaredField("objectMap");
        objectMapField.setAccessible(true);
        objectMapField.set(iterator, objectMap);

        // Invoke next()
        List<Integer> result = iterator.next();

        // Expected nextPermutation after swapping 3 and 1
        List<Integer> expected = new ArrayList<>();
        expected.add(1);
        expected.add(3);
        expected.add(2);

        Assertions.assertEquals(expected, result);

        // Verify that nextPermutation is updated correctly
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        Object updatedNextPerm = nextPermutationField.get(iterator);
        Assertions.assertNull(updatedNextPerm);

        // Verify that directions are updated
        boolean[] updatedDirection = (boolean[]) directionField.get(iterator);
        Assertions.assertArrayEquals(new boolean[]{false, false, false}, updatedDirection);
    }

    @Test
    @DisplayName("Throws NoSuchElementException when next is called after all permutations")
    public void TC05() throws Exception {
        // Initialize PermutationIterator instance with an empty collection
        PermutationIterator<Integer> iterator = new PermutationIterator<>(new ArrayList<>());

        // Set nextPermutation to null using reflection
        Field nextPermutationField = PermutationIterator.class.getDeclaredField("nextPermutation");
        nextPermutationField.setAccessible(true);
        nextPermutationField.set(iterator, null);

        // Assert that NoSuchElementException is thrown when next() is called
        Assertions.assertThrows(NoSuchElementException.class, () -> {
            iterator.next();
        });
    }
}