package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FastMath_pow_1_1_Test {

    @Test
    @DisplayName("pow(x, y) returns x when y is 1.0")
    void testPowReturnsXWhenYIsOne() {
        double x = 2.5;
        double y = 1.0;
        double expected = x;
        double actual = FastMath.pow(x, y);
        assertEquals(expected, actual, 1e-15, "pow(x, 1.0) should return x");
    }

    @Test
    @DisplayName("pow(x, y) returns 1/x when y is -1.0")
    void testPowReturnsInverseWhenYIsNegativeOne() {
        double x = 4.0;
        double y = -1.0;
        double expected = 1.0 / x;
        double actual = FastMath.pow(x, y);
        assertEquals(expected, actual, 1e-15, "pow(x, -1.0) should return 1/x");
    }

    @Test
    @DisplayName("pow(1.0, y) returns 1.0 when y is +Infinity")
    void testPowOneReturnsOneWhenYIsPositiveInfinity() {
        double x = 1.0;
        double y = Double.POSITIVE_INFINITY;
        double expected = 1.0;
        double actual = FastMath.pow(x, y);
        assertEquals(expected, actual, 0.0, "pow(1.0, +Infinity) should return 1.0");
    }

    @Test
    @DisplayName("pow(1.0, y) returns 1.0 when y is -Infinity")
    void testPowOneReturnsOneWhenYIsNegativeInfinity() {
        double x = 1.0;
        double y = Double.NEGATIVE_INFINITY;
        double expected = 1.0;
        double actual = FastMath.pow(x, y);
        assertEquals(expected, actual, 0.0, "pow(1.0, -Infinity) should return 1.0");
    }

}