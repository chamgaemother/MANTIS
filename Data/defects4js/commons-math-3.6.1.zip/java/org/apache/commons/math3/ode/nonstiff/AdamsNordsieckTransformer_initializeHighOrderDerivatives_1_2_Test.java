package org.apache.commons.math3.ode.nonstiff;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;

public class AdamsNordsieckTransformer_initializeHighOrderDerivatives_1_2_Test {

    @Test
    @DisplayName("Initialize with inconsistent lengths of y and yDot arrays, expecting ArrayIndexOutOfBoundsException")
    void TC21_initializeWithInconsistentLengths_expectException() {
        // GIVEN
        double h = 0.1;
        double[] t = {0.0, 0.1};
        double[][] y = { {1.0, 2.0} };
        double[][] yDot = { {0.5, 1.0}, {0.55, 1.05} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(2);

        // WHEN & THEN
        assertThrows(ArrayIndexOutOfBoundsException.class, () ->
            transformer.initializeHighOrderDerivatives(h, t, y, yDot)
        );
    }

    @Test
    @DisplayName("Initialize with extremely large step size, verifying behavior with large h values")
    void TC22_initializeWithLargeStepSize_verifyBehavior() {
        // GIVEN
        double h = 1e6;
        double[] t = {0.0, 1e6};
        double[][] y = { {1.0, 2.0} };
        double[][] yDot = { {0.5, 1.0} };
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(1);

        // WHEN
        Array2DRowRealMatrix result = transformer.initializeHighOrderDerivatives(h, t, y, yDot);

        // THEN
        assertNotNull(result, "Nordsieck vector should be initialized correctly with large h.");
        // Additional assertions to verify scaled derivatives are correctly calculated with large h
    }

    @Test
    @DisplayName("Initialize with empty yDot array while y.length > 0, expecting ArrayIndexOutOfBoundsException")
    void TC23_initializeWithEmptyyDot_expectException() {
        // GIVEN
        double h = 0.1;
        double[] t = {0.0, 0.1};
        double[][] y = { {1.0, 2.0} };
        double[][] yDot = {};
        AdamsNordsieckTransformer transformer = AdamsNordsieckTransformer.getInstance(1);

        // WHEN & THEN
        assertThrows(ArrayIndexOutOfBoundsException.class, () ->
            transformer.initializeHighOrderDerivatives(h, t, y, yDot)
        );
    }
}