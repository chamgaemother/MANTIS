import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

public class IntListTest {

    private IntList intList;

    @BeforeEach
    public void setUp() {
        intList = new IntList(5); // Start with a small capacity to trigger growth.
    }

    @Test
    public void testAddAtLocationInMiddle() {
        intList.add(0);
        intList.add(1);
        intList.add(2);
        intList.add(3);
        intList.add(4); // Fill the list to the initial capacity
        intList.add(1, 99); // Insert in the middle
        assertEquals(99, intList.get(1));
        assertEquals(6, intList.size());
    }

    @Test
    public void testAddAtLocationStart() {
        intList.add(0);
        intList.add(1);
        intList.add(2);
        intList.add(0, 99); // Insert at the start
        assertEquals(99, intList.get(0));
        assertEquals(4, intList.size());
    }

    @Test
    public void testAddAtLocationEnd() {
        intList.add(0);
        intList.add(1);
        intList.add(2);
        intList.add(3, 99); // Insert at the end (same as add())
        assertEquals(99, intList.get(3));
        assertEquals(4, intList.size());
    }

    @Test
    public void testAddAtLocationOutOfBounds() {
        intList.add(0);
        intList.add(1);
        intList.add(2);

        assertThrows(IndexOutOfBoundsException.class, () -> intList.add(-1, 99));
        assertThrows(IndexOutOfBoundsException.class, () -> intList.add(4, 99));
    }

    @Test
    public void testGrowAtFront() {
        intList.add(0);
        intList.add(1);
        intList.add(2);
        intList.add(3);
        intList.add(4); // Fill the list

        intList.add(0, 99); // Causes a growAtFront
        assertEquals(99, intList.get(0));
        assertEquals(6, intList.size());
    }
    
    @Test
    public void testGrowAtEndAndInsertMiddle() {
        intList.add(0);
        intList.add(1);
        intList.add(2);
        intList.add(3);
        intList.add(4); // Fill the list

        intList.add(2, 99); // Causes a growForInsert
        assertEquals(99, intList.get(2));
        assertEquals(6, intList.size());
    }

}