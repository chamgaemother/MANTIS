package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class NumberUtils_isCreatable_1_2_Test {

    @Test
    @DisplayName("isCreatable(\"09\") returns false for invalid octal digit '9'")
    public void test_TC33_isCreatable_invalid_octal_digit() {
        // GIVEN
        String input = "09";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertFalse(result, "Expected isCreatable(\"09\") to return false for invalid octal digit '9'");
    }

    @Test
    @DisplayName("isCreatable(\"123L\") returns true for a valid integer with type qualifier 'L'")
    public void test_TC34_isCreatable_valid_integer_with_L_qualifier() {
        // GIVEN
        String input = "123L";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"123L\") to return true for a valid integer with type qualifier 'L'");
    }

    @Test
    @DisplayName("isCreatable(\"1.0L\") returns false for invalid type qualifier 'L' with decimal")
    public void test_TC35_isCreatable_invalid_type_qualifier_L_with_decimal() {
        // GIVEN
        String input = "1.0L";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertFalse(result, "Expected isCreatable(\"1.0L\") to return false for invalid type qualifier 'L' with decimal");
    }

    @Test
    @DisplayName("isCreatable(\"1.23E3f\") returns true for valid float type qualifier with exponent")
    public void test_TC36_isCreatable_valid_float_with_exponent_and_f_qualifier() {
        // GIVEN
        String input = "1.23E3f";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertTrue(result, "Expected isCreatable(\"1.23E3f\") to return true for valid float type qualifier with exponent");
    }

    @Test
    @DisplayName("isCreatable(\"1e10x\") returns false for invalid type qualifier 'x'")
    public void test_TC37_isCreatable_invalid_type_qualifier_x() {
        // GIVEN
        String input = "1e10x";
        // WHEN
        boolean result = NumberUtils.isCreatable(input);
        // THEN
        assertFalse(result, "Expected isCreatable(\"1e10x\") to return false for invalid type qualifier 'x'");
    }
}