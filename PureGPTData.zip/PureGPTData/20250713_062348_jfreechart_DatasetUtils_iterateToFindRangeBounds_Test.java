import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;

import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.junit.jupiter.api.Test;

class DatasetUtilsTest {

    @Test
    void testNullDataset() {
        assertThrows(IllegalArgumentException.class, () -> 
            DatasetUtils.iterateToFindRangeBounds(null, Collections.emptyList(), false)
        );
    }

    @Test
    void testNullVisibleSeriesKeys() {
        CategoryDataset mockDataset = mock(CategoryDataset.class);
        assertThrows(IllegalArgumentException.class, () ->
            DatasetUtils.iterateToFindRangeBounds(mockDataset, null, false)
        );
    }

    @Test
    void testEmptyVisibleSeriesKeys() {
        CategoryDataset mockDataset = mock(CategoryDataset.class);
        when(mockDataset.getColumnCount()).thenReturn(0);
        assertNull(DatasetUtils.iterateToFindRangeBounds(mockDataset, Collections.emptyList(), false));
    }

    @Test
    void testBoxAndWhiskerCategoryDatasetWithIncludeInterval() {
        BoxAndWhiskerCategoryDataset mockDataset = mock(BoxAndWhiskerCategoryDataset.class);
        when(mockDataset.getColumnCount()).thenReturn(1);
        when(mockDataset.getRowIndex(any())).thenReturn(0);
        when(mockDataset.getMinRegularValue(0, 0)).thenReturn(1.0);
        when(mockDataset.getMaxRegularValue(0, 0)).thenReturn(3.0);

        Range range = DatasetUtils.iterateToFindRangeBounds(mockDataset, Arrays.asList("Series1"), true);
        assertEquals(1.0, range.getLowerBound());
        assertEquals(3.0, range.getUpperBound());
    }

    @Test
    void testIntervalCategoryDatasetWithIncludeInterval() {
        IntervalCategoryDataset mockDataset = mock(IntervalCategoryDataset.class);
        when(mockDataset.getColumnCount()).thenReturn(1);
        when(mockDataset.getRowIndex(any())).thenReturn(0);
        when(mockDataset.getStartValue(0, 0)).thenReturn(2.0);
        when(mockDataset.getEndValue(0, 0)).thenReturn(4.0);

        Range range = DatasetUtils.iterateToFindRangeBounds(mockDataset, Arrays.asList("Series1"), true);
        assertEquals(2.0, range.getLowerBound());
        assertEquals(4.0, range.getUpperBound());
    }

    @Test
    void testMultiValueCategoryDatasetWithIncludeInterval() {
        MultiValueCategoryDataset mockDataset = mock(MultiValueCategoryDataset.class);
        when(mockDataset.getColumnCount()).thenReturn(1);
        when(mockDataset.getRowIndex(any())).thenReturn(0);
        when(mockDataset.getValues(0, 0)).thenReturn(Arrays.asList(5.0, 6.0));

        Range range = DatasetUtils.iterateToFindRangeBounds(mockDataset, Arrays.asList("Series1"), true);
        assertEquals(5.0, range.getLowerBound());
        assertEquals(6.0, range.getUpperBound());
    }

    @Test
    void testStatisticalCategoryDatasetWithIncludeInterval() {
        StatisticalCategoryDataset mockDataset = mock(StatisticalCategoryDataset.class);
        when(mockDataset.getColumnCount()).thenReturn(1);
        when(mockDataset.getRowIndex(any())).thenReturn(0);
        when(mockDataset.getMeanValue(0, 0)).thenReturn(10.0);
        when(mockDataset.getStdDevValue(0, 0)).thenReturn(2.0);

        Range range = DatasetUtils.iterateToFindRangeBounds(mockDataset, Arrays.asList("Series1"), true);
        assertEquals(8.0, range.getLowerBound());
        assertEquals(12.0, range.getUpperBound());
    }

    @Test
    void testStandardCategoryDatasetWithoutIncludeInterval() {
        CategoryDataset mockDataset = mock(CategoryDataset.class);
        when(mockDataset.getColumnCount()).thenReturn(1);
        when(mockDataset.getRowIndex(any())).thenReturn(0);
        when(mockDataset.getValue(0, 0)).thenReturn(7.0);

        Range range = DatasetUtils.iterateToFindRangeBounds(mockDataset, Arrays.asList("Series1"), false);
        assertEquals(7.0, range.getLowerBound());
        assertEquals(7.0, range.getUpperBound());
    }

    @Test
    void testStandardCategoryDatasetWithNullValues() {
        CategoryDataset mockDataset = mock(CategoryDataset.class);
        when(mockDataset.getColumnCount()).thenReturn(1);
        when(mockDataset.getRowIndex(any())).thenReturn(0);
        when(mockDataset.getValue(0, 0)).thenReturn(null);

        Range range = DatasetUtils.iterateToFindRangeBounds(mockDataset, Arrays.asList("Series1"), false);
        assertNull(range);
    }
}