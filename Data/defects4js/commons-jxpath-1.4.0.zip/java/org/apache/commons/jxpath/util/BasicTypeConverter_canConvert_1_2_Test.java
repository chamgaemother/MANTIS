
package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class BasicTypeConverter_canConvert_1_2_Test {

    @Test
    @DisplayName("object is array with all elements null and useType is array of Object")
    public void TC39_canConvert_withArrayOfNullElements_toObjectArray() {
        // GIVEN
        BasicTypeConverter converter = new BasicTypeConverter();
        Object[] objectArray = {null, null, null};
        Class<?> toType = Object[].class;

        // WHEN
        boolean result = converter.canConvert(objectArray, toType);

        // THEN
        assertTrue(result);
    }
}