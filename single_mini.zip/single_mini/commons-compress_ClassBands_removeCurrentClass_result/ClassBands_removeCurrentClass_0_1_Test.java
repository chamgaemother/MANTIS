package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

public class ClassBands_removeCurrentClass_0_1_Test {

    // Mock classes to simulate CPClass and CPUTF8
    static class CPClass {
        private final String name;

        public CPClass(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    static class CPUTF8 {
        private final String value;

        public CPUTF8(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    // Mock Segment and CPBands since they are dependencies for ClassBands
    static class Segment {
        public CPBands getCpBands() {
            return new CPBands();
        }

        public SegmentHeader getSegmentHeader() {
            return new SegmentHeader();
        }
    }

    static class CPBands {
        public CPClass getCPClass(String name) {
            return new CPClass(name);
        }

        public CPUTF8 getCPUtf8(String value) {
            return new CPUTF8(value);
        }

        public CPSignature getCPSignature(String signature) {
            return new CPSignature(signature);
        }

        public CPNameAndType getCPNameAndType(String name, String desc) {
            return new CPNameAndType(name, desc);
        }

        public CPConstant<?> getConstant(Object value) {
            return new CPConstant<>(value);
        }

        public CPUTF8 addCPUtf8(String value) {
            return getCPUtf8(value);
        }
    }

    static class CPSignature {}
    static class CPNameAndType {}
    static class CPConstant<T> {}
    static class SegmentHeader {
        public boolean have_class_flags_hi() { return false; }
        public boolean have_method_flags_hi() { return false; }
        public boolean have_field_flags_hi() { return false; }
        public boolean have_code_flags_hi() { return false; }
    }

    @Test
    @DisplayName("Removes the last element from classSourceFile when class_flags[index] has bit 17 set")
    void TC01() throws Exception {
        // Initialize mocks
        Segment segment = mock(Segment.class);
        CPBands cpBands = segment.getCpBands();
        
        // Initialize ClassBands instance with required parameters
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Use reflection to access and modify private fields
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] class_flags = new long[]{0L};
        class_flags[0] |= (1L << 17); // Set bit 17
        classFlagsField.set(classBands, class_flags);

        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        Field classSourceFileField = ClassBands.class.getDeclaredField("classSourceFile");
        classSourceFileField.setAccessible(true);
        List<CPUTF8> classSourceFile = new ArrayList<>();
        classSourceFile.add(cpBands.getCPUtf8("SourceFile1"));
        classSourceFile.add(cpBands.getCPUtf8("SourceFile2"));
        classSourceFileField.set(classBands, classSourceFile);
    
        // Invoke the method under test
        classBands.removeCurrentClass();
    
        // Assert that the last element was removed
        assertEquals(1, classSourceFile.size(), "classSourceFile size should be decreased by one");
    }

    @Test
    @DisplayName("Does not remove from classSourceFile when class_flags[index] has bit 17 not set")
    void TC02() throws Exception {
        // Initialize mocks
        Segment segment = mock(Segment.class);
        CPBands cpBands = segment.getCpBands();

        // Initialize ClassBands instance with required parameters
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Use reflection to access and modify private fields
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] class_flags = new long[]{0L};
        // Bit 17 not set
        classFlagsField.set(classBands, class_flags);

        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        Field classSourceFileField = ClassBands.class.getDeclaredField("classSourceFile");
        classSourceFileField.setAccessible(true);
        List<CPUTF8> classSourceFile = new ArrayList<>();
        classSourceFile.add(cpBands.getCPUtf8("SourceFile1"));
        classSourceFile.add(cpBands.getCPUtf8("SourceFile2"));
        classSourceFileField.set(classBands, classSourceFile);
    
        // Invoke the method under test
        classBands.removeCurrentClass();
    
        // Assert that the classSourceFile remains unchanged
        assertEquals(2, classSourceFile.size(), "classSourceFile size should remain the same");
    }

    @Test
    @DisplayName("Removes the last elements from classEnclosingMethodClass and classEnclosingMethodDesc when class_flags[index] has bit 18 set")
    void TC03() throws Exception {
        // Initialize mocks
        Segment segment = mock(Segment.class);
        CPBands cpBands = segment.getCpBands();

        // Initialize ClassBands instance with required parameters
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Set bit 18
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] class_flags = new long[]{0L};
        class_flags[0] |= (1L << 18);
        classFlagsField.set(classBands, class_flags);

        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        Field classEnclosingMethodClassField = ClassBands.class.getDeclaredField("classEnclosingMethodClass");
        classEnclosingMethodClassField.setAccessible(true);
        List<CPClass> classEnclosingMethodClass = new ArrayList<>();
        classEnclosingMethodClass.add(cpBands.getCPClass("EnclosingMethodClass1"));
        classEnclosingMethodClass.add(cpBands.getCPClass("EnclosingMethodClass2"));
        classEnclosingMethodClassField.set(classBands, classEnclosingMethodClass);

        Field classEnclosingMethodDescField = ClassBands.class.getDeclaredField("classEnclosingMethodDesc");
        classEnclosingMethodDescField.setAccessible(true);
        List<CPNameAndType> classEnclosingMethodDesc = new ArrayList<>();
        classEnclosingMethodDesc.add(cpBands.getCPNameAndType("MethodDesc1", "Desc1"));
        classEnclosingMethodDesc.add(cpBands.getCPNameAndType("MethodDesc2", "Desc2"));
        classEnclosingMethodDescField.set(classBands, classEnclosingMethodDesc);

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that the last elements were removed
        assertEquals(1, classEnclosingMethodClass.size(), "classEnclosingMethodClass size should be decreased by one");
        assertEquals(1, classEnclosingMethodDesc.size(), "classEnclosingMethodDesc size should be decreased by one");
    }

    @Test
    @DisplayName("Does not remove from classEnclosingMethodClass and classEnclosingMethodDesc when class_flags[index] has bit 18 not set")
    void TC04() throws Exception {
        // Initialize mocks
        Segment segment = mock(Segment.class);
        CPBands cpBands = segment.getCpBands();

        // Initialize ClassBands instance with required parameters
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Ensure bit 18 is not set
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] class_flags = new long[]{0L};
        // Bit 18 not set
        classFlagsField.set(classBands, class_flags);

        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        Field classEnclosingMethodClassField = ClassBands.class.getDeclaredField("classEnclosingMethodClass");
        classEnclosingMethodClassField.setAccessible(true);
        List<CPClass> classEnclosingMethodClass = new ArrayList<>();
        classEnclosingMethodClass.add(cpBands.getCPClass("EnclosingMethodClass1"));
        classEnclosingMethodClassField.set(classBands, classEnclosingMethodClass);

        Field classEnclosingMethodDescField = ClassBands.class.getDeclaredField("classEnclosingMethodDesc");
        classEnclosingMethodDescField.setAccessible(true);
        List<CPNameAndType> classEnclosingMethodDesc = new ArrayList<>();
        classEnclosingMethodDesc.add(cpBands.getCPNameAndType("MethodDesc1", "Desc1"));
        classEnclosingMethodDescField.set(classBands, classEnclosingMethodDesc);

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that the lists remain unchanged
        assertEquals(1, classEnclosingMethodClass.size(), "classEnclosingMethodClass size should remain the same");
        assertEquals(1, classEnclosingMethodDesc.size(), "classEnclosingMethodDesc size should remain the same");
    }

    @Test
    @DisplayName("Removes the last element from classSignature when class_flags[index] has bit 19 set")
    void TC05() throws Exception {
        // Initialize mocks
        Segment segment = mock(Segment.class);
        CPBands cpBands = segment.getCpBands();

        // Initialize ClassBands instance with required parameters
        ClassBands classBands = new ClassBands(segment, 1, 1, false);

        // Set bit 19
        Field classFlagsField = ClassBands.class.getDeclaredField("class_flags");
        classFlagsField.setAccessible(true);
        long[] class_flags = new long[]{0L};
        class_flags[0] |= (1L << 19);
        classFlagsField.set(classBands, class_flags);

        Field indexField = ClassBands.class.getDeclaredField("index");
        indexField.setAccessible(true);
        indexField.setInt(classBands, 0);

        Field classSignatureField = ClassBands.class.getDeclaredField("classSignature");
        classSignatureField.setAccessible(true);
        List<CPSignature> classSignature = new ArrayList<>();
        classSignature.add(cpBands.getCPSignature("Signature1"));
        classSignature.add(cpBands.getCPSignature("Signature2"));
        classSignatureField.set(classBands, classSignature);

        // Invoke the method under test
        classBands.removeCurrentClass();

        // Assert that the last element was removed
        assertEquals(1, classSignature.size(), "classSignature size should be decreased by one");
    }
}
