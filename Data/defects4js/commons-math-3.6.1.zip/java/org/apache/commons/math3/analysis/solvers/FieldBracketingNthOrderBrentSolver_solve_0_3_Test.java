// package org.apache.commons.math3.analysis.solvers;
// import org.apache.commons.math3.Field;
// import org.apache.commons.math3.RealFieldElement;
// 
// import org.apache.commons.math3.exception.MathInternalError;
// import org.apache.commons.math3.exception.NoBracketingException;
// import org.apache.commons.math3.field.Binary64;
// import org.apache.commons.math3.field.Binary64Field;
// import org.apache.commons.math3.analysis.RealFieldUnivariateFunction;
// import org.apache.commons.math3.field.RealFieldElement;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// public class FieldBracketingNthOrderBrentSolver_solve_0_3_Test {
// 
// //     @Test
// //     @DisplayName("solve handles guessX returning NaN and falls back to bisection")
// //     void TC11_solve_handles_guessX_returning_NaN_and_fallback_to_bisection() throws Exception {
// //         int maxEval = 100;
// //         Field<Binary64> field = Binary64Field.getInstance();
// //         RealFieldUnivariateFunction f = new RealFieldUnivariateFunction() {
// //             @Override
// //             public Binary64 value(Binary64 x) {
// //                 return x.add(Double.NaN);
// //             }
// //         };
// //         RealFieldElement<Binary64> min = field.getZero();
// //         RealFieldElement<Binary64> max = field.getOne();
// //         RealFieldElement<Binary64> startValue = field.getOne().divide(2);
// //         AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
// //         RealFieldElement<Binary64> relativeAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> absoluteAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> functionValueAccuracy = field.getZero().add(1e-12);
// //         FieldBracketingNthOrderBrentSolver<Binary64> solver = new FieldBracketingNthOrderBrentSolver<>(
// //                 relativeAccuracy, absoluteAccuracy, functionValueAccuracy, 5);
// // 
// //         RealFieldElement<Binary64> result = null;
// //         try {
// //             result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// //         } catch (NoBracketingException e) {
// //             fail("NoBracketingException was thrown unexpectedly.");
// //         }
// // 
// //         RealFieldElement<Binary64> expected = min.add(max).divide(2);
// //         assertEquals(expected.getReal(), result.getReal(), 1e-8, "Solver did not use bisection as expected.");
// //     }
// 
// //     @Test
// //     @DisplayName("solve throws MathInternalError on unexpected allowedSolution")
// //     void TC12_solve_throws_MathInternalError_on_unexpected_allowedSolution() {
// //         int maxEval = 100;
// //         Field<Binary64> field = Binary64Field.getInstance();
// //         RealFieldUnivariateFunction f = new RealFieldUnivariateFunction() {
// //             @Override
// //             public Binary64 value(Binary64 x) {
// //                 return x;
// //             }
// //         };
// //         RealFieldElement<Binary64> min = field.getZero();
// //         RealFieldElement<Binary64> max = field.getOne();
// //         RealFieldElement<Binary64> startValue = field.getOne().divide(2);
// //         AllowedSolution allowedSolution = null;
// //         RealFieldElement<Binary64> relativeAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> absoluteAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> functionValueAccuracy = field.getZero().add(1e-12);
// //         FieldBracketingNthOrderBrentSolver<Binary64> solver = new FieldBracketingNthOrderBrentSolver<>(
// //                 relativeAccuracy, absoluteAccuracy, functionValueAccuracy, 5);
// // 
// //         assertThrows(MathInternalError.class, () -> {
// //             solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// //         }, "MathInternalError was expected due to invalid AllowedSolution.");
// //     }
// 
// //     @Test
// //     @DisplayName("solve correctly handles aging leading to targetY adjustment")
// //     void TC13_solve_correctly_handles_aging_leading_to_targetY_adjustment() throws Exception {
// //         int maxEval = 100;
// //         Field<Binary64> field = Binary64Field.getInstance();
// //         RealFieldUnivariateFunction f = new RealFieldUnivariateFunction() {
// //             @Override
// //             public Binary64 value(Binary64 x) {
// //                 return field.getOne();
// //             }
// //         };
// //         RealFieldElement<Binary64> min = field.getZero();
// //         RealFieldElement<Binary64> max = field.getOne();
// //         RealFieldElement<Binary64> startValue = field.getOne().divide(2);
// //         AllowedSolution allowedSolution = AllowedSolution.ANY_SIDE;
// //         RealFieldElement<Binary64> relativeAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> absoluteAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> functionValueAccuracy = field.getZero().add(1e-12);
// //         FieldBracketingNthOrderBrentSolver<Binary64> solver = new FieldBracketingNthOrderBrentSolver<>(
// //                 relativeAccuracy, absoluteAccuracy, functionValueAccuracy, 5);
// // 
// //         assertThrows(NoBracketingException.class, () -> {
// //             solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// //         }, "NoBracketingException was expected due to aging triggering targetY adjustment.");
// //     }
// 
// //     @Test
// //     @DisplayName("solve returns xA based on AllowedSolution.LEFT_SIDE")
// //     void TC14_solve_returns_xA_based_on_AllowedSolution_LEFT_SIDE() throws Exception {
// //         int maxEval = 100;
// //         Field<Binary64> field = Binary64Field.getInstance();
// //         RealFieldUnivariateFunction f = new RealFieldUnivariateFunction() {
// //             @Override
// //             public Binary64 value(Binary64 x) {
// //                 return x.equals(field.getZero()) ? x : field.getOne();
// //             }
// //         };
// //         RealFieldElement<Binary64> min = field.getZero();
// //         RealFieldElement<Binary64> max = field.getOne();
// //         RealFieldElement<Binary64> startValue = field.getOne().divide(2);
// //         AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
// //         RealFieldElement<Binary64> relativeAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> absoluteAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> functionValueAccuracy = field.getZero().add(1e-12);
// //         FieldBracketingNthOrderBrentSolver<Binary64> solver = new FieldBracketingNthOrderBrentSolver<>(
// //                 relativeAccuracy, absoluteAccuracy, functionValueAccuracy, 5);
// // 
// //         RealFieldElement<Binary64> result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// // 
// //         assertEquals(min.getReal(), result.getReal(), 1e-8, "Solver did not return xA as expected based on AllowedSolution.LEFT_SIDE.");
// //     }
// 
// //     @Test
// //     @DisplayName("solve returns xB based on AllowedSolution.RIGHT_SIDE")
// //     void TC15_solve_returns_xB_based_on_AllowedSolution_RIGHT_SIDE() throws Exception {
// //         int maxEval = 100;
// //         Field<Binary64> field = Binary64Field.getInstance();
// //         RealFieldUnivariateFunction f = new RealFieldUnivariateFunction() {
// //             @Override
// //             public Binary64 value(Binary64 x) {
// //                 return x.equals(field.getOne()) ? x : field.getOne();
// //             }
// //         };
// //         RealFieldElement<Binary64> min = field.getZero();
// //         RealFieldElement<Binary64> max = field.getOne();
// //         RealFieldElement<Binary64> startValue = field.getOne().divide(2);
// //         AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
// //         RealFieldElement<Binary64> relativeAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> absoluteAccuracy = field.getZero().add(1e-8);
// //         RealFieldElement<Binary64> functionValueAccuracy = field.getZero().add(1e-12);
// //         FieldBracketingNthOrderBrentSolver<Binary64> solver = new FieldBracketingNthOrderBrentSolver<>(
// //                 relativeAccuracy, absoluteAccuracy, functionValueAccuracy, 5);
// // 
// //         RealFieldElement<Binary64> result = solver.solve(maxEval, f, min, max, startValue, allowedSolution);
// // 
// //         assertEquals(max.getReal(), result.getReal(), 1e-8, "Solver did not return xB as expected based on AllowedSolution.RIGHT_SIDE.");
// //     }
// }