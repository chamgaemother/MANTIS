// package org.joda.time.format;
// 
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.joda.time.IllegalFieldValueException;
// import org.joda.time.IllegalInstantException;
// import org.joda.time.DateTimeZone;
// import org.joda.time.DurationFieldType;
// import org.joda.time.chrono.ISOChronology;
// 
// import java.lang.reflect.Field;
// 
// import static org.junit.jupiter.api.Assertions.*;
// 
// public class DateTimeParserBucket_computeMillis_0_2_Test {
// 
// //     @Test
// //     @DisplayName("Loop in setting millis with iSavedFieldsCount > 1")
// //     void TC06() throws Exception {
//         // Initialize DateTimeParserBucket instance
// //         DateTimeParserBucket bucket = new DateTimeParserBucket(1609459200000L, ISOChronology.getInstance(), null);
// // 
//         // Set iSavedFieldsCount = 5
// //         Field iSavedFieldsCountField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
// //         iSavedFieldsCountField.setAccessible(true);
// //         iSavedFieldsCountField.setInt(bucket, 5);
// // 
//         // Initialize iSavedFields array with 5 SavedField instances
// //         Field iSavedFieldsField = DateTimeParserBucket.class.getDeclaredField("iSavedFields");
// //         iSavedFieldsField.setAccessible(true);
// //         DateTimeParserBucket.SavedField[] savedFields = new DateTimeParserBucket.SavedField[5];
// //         for (int i = 0; i < 5; i++) {
// //             savedFields[i] = bucket.new SavedField(); // Use the instance to create inner class
// //             savedFields[i].init(DurationFieldType.days().getField(ISOChronology.getInstance()), 1000 * (i + 1));
// //         }
// //         iSavedFieldsField.set(bucket, savedFields);
// // 
//         // Set iSavedFieldsShared to false to avoid cloning
// //         Field iSavedFieldsSharedField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsShared");
// //         iSavedFieldsSharedField.setAccessible(true);
// //         iSavedFieldsSharedField.setBoolean(bucket, false);
// // 
//         // Set iMillis to a known value
// //         Field iMillisField = DateTimeParserBucket.class.getDeclaredField("iMillis");
// //         iMillisField.setAccessible(true);
// //         iMillisField.setLong(bucket, 1609459200000L); // Example: Jan 1, 2021
// // 
//         // Invoke computeMillis
// //         long millis = bucket.computeMillis(false, null);
// // 
//         // Assert the millis is set correctly after multiple iterations
// //         long expectedMillis = 1609459200000L + (5 * 1000L);
// //         assertEquals(expectedMillis, millis, "millis should be correctly set after multiple iterations");
// //     }
// 
// //     @Test
// //     @DisplayName("ResetFields is true, and fields are lenient and non-lenient")
// //     void TC07() throws Exception {
//         // Initialize DateTimeParserBucket instance
// //         DateTimeParserBucket bucket = new DateTimeParserBucket(1609459200000L, ISOChronology.getInstance(), null);
// // 
//         // Set iSavedFieldsCount
// //         Field iSavedFieldsCountField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
// //         iSavedFieldsCountField.setAccessible(true);
// //         iSavedFieldsCountField.setInt(bucket, 3);
// // 
//         // Initialize iSavedFields array with mixed leniency
// //         Field iSavedFieldsField = DateTimeParserBucket.class.getDeclaredField("iSavedFields");
// //         iSavedFieldsField.setAccessible(true);
// //         DateTimeParserBucket.SavedField[] savedFields = new DateTimeParserBucket.SavedField[3];
// //         for (int i = 0; i < 3; i++) {
// //             savedFields[i] = bucket.new SavedField(); // Use the instance to create inner class
// //             savedFields[i].init(DurationFieldType.days().getField(ISOChronology.getInstance()), 1000);
// //         }
// //         iSavedFieldsField.set(bucket, savedFields);
// // 
//         // Set iMillis to a known value
// //         Field iMillisField = DateTimeParserBucket.class.getDeclaredField("iMillis");
// //         iMillisField.setAccessible(true);
// //         iMillisField.setLong(bucket, 1609459200000L);
// // 
//         // Invoke computeMillis
// //         long millis = bucket.computeMillis(true, null);
// // 
//         // Assert millis is reset correctly for non-lenient fields
// //         long expectedMillis = 1609459200000L;
// //         assertEquals(expectedMillis, millis, "millis should be reset correctly for non-lenient fields");
// //     }
// 
// //     @Test
// //     @DisplayName("IllegalFieldValueException is thrown with non-null text")
// //     void TC08() {
//         // Initialize DateTimeParserBucket instance
// //         DateTimeParserBucket bucket = new DateTimeParserBucket(1609459200000L, ISOChronology.getInstance(), null);
// // 
//         // Setup with invalid field value
// //         Field iSavedFieldsCountField = DateTimeParserBucket.class.getDeclaredField("iSavedFieldsCount");
// //         iSavedFieldsCountField.setAccessible(true);
// //         iSavedFieldsCountField.setInt(bucket, 1);
// // 
// //         Field iSavedFieldsField = DateTimeParserBucket.class.getDeclaredField("iSavedFields");
// //         iSavedFieldsField.setAccessible(true);
// //         DateTimeParserBucket.SavedField[] savedFields = new DateTimeParserBucket.SavedField[1];
// //         savedFields[0] = bucket.new SavedField(); // Use the instance to create inner class
// //         savedFields[0].init(DurationFieldType.days().getField(ISOChronology.getInstance()), -1); // Invalid value
// //         iSavedFieldsField.set(bucket, savedFields);
// // 
//         // Invoke computeMillis and expect exception
// //         IllegalFieldValueException thrown = assertThrows(
// //             IllegalFieldValueException.class,
// //             () -> bucket.computeMillis(false, "invalid"),
// //             "Expected computeMillis to throw IllegalFieldValueException"
// //         );
// // 
// //         assertTrue(thrown.getMessage().contains("Cannot parse \"invalid\""), "Exception message should be prepended correctly");
// //     }
// 
//     @Test
//     @DisplayName("IllegalInstantException is thrown due to time zone offset transition with non-null text")
//     void TC09() {
//         // Initialize DateTimeParserBucket instance
//         DateTimeParserBucket bucket = new DateTimeParserBucket(1615708800000L, ISOChronology.getInstance(), null);
// 
//         // Set iZone to a zone that causes offset transition
//         Field iZoneField = DateTimeParserBucket.class.getDeclaredField("iZone");
//         iZoneField.setAccessible(true);
//         DateTimeZone zone = DateTimeZone.forID("America/New_York"); // Example zone with DST
//         iZoneField.set(bucket, zone);
// 
//         // Set iMillis to a time that falls in a transition
//         Field iMillisField = DateTimeParserBucket.class.getDeclaredField("iMillis");
//         iMillisField.setAccessible(true);
//         iMillisField.setLong(bucket, 1615708800000L); // March 14, 2021 02:00:00 GMT-05:00
// 
//         // Invoke computeMillis and expect IllegalInstantException
//         IllegalInstantException thrown = assertThrows(
//             IllegalInstantException.class,
//             () -> bucket.computeMillis(false, "2021-03-14"),
//             "Expected computeMillis to throw IllegalInstantException"
//         );
// 
//         assertTrue(thrown.getMessage().contains("Illegal instant due to time zone offset transition"), "Exception message should indicate time zone transition");
//     }
// 
//     @Test
//     @DisplayName("iOffset is not null, millis is adjusted by iOffset")
//     void TC10() throws Exception {
//         // Initialize DateTimeParserBucket instance
//         DateTimeParserBucket bucket = new DateTimeParserBucket(1609459200000L, ISOChronology.getInstance(), null);
// 
//         // Set iOffset to 3600000 (1 hour)
//         Field iOffsetField = DateTimeParserBucket.class.getDeclaredField("iOffset");
//         iOffsetField.setAccessible(true);
//         Integer offset = 3600000;
//         iOffsetField.set(bucket, offset);
// 
//         // Set iZone to null
//         Field iZoneField = DateTimeParserBucket.class.getDeclaredField("iZone");
//         iZoneField.setAccessible(true);
//         iZoneField.set(bucket, null);
// 
//         // Set iMillis to a known value
//         Field iMillisField = DateTimeParserBucket.class.getDeclaredField("iMillis");
//         iMillisField.setAccessible(true);
//         long originalMillis = 1609459200000L; // Jan 1, 2021
//         iMillisField.setLong(bucket, originalMillis);
// 
//         // Invoke computeMillis
//         long millis = bucket.computeMillis(false, null);
// 
//         // Assert millis is correctly adjusted by iOffset
//         long expectedMillis = originalMillis - offset;
//         assertEquals(expectedMillis, millis, "millis should be correctly adjusted by iOffset");
//     }
// }