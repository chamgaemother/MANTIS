package org.apache.commons.compress.harmony.pack200;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Set;

@ExtendWith(MockitoExtension.class)
public class CpBands_getCPSignature_0_2_Test {

    @Mock
    private Segment mockSegment;
    @Mock
    private SegmentHeader mockSegmentHeader;

    private CpBands cpBands;

    @BeforeEach
    void setUp() {
        when(mockSegment.getSegmentHeader()).thenReturn(mockSegmentHeader);
        cpBands = new CpBands(mockSegment, 1);
    }

    @Test
    @DisplayName("GetCPSignature with multiple iterations in parsing loop")
    void testMultipleIterationsParsingLoop() {
        // GIVEN
        String signature = "Lmy/Class;Lanother/Class;Lfinal/Class;";

        // WHEN
        CPSignature result = cpBands.getCPSignature(signature);

        // THEN
        assertEquals(3, result.getClasses().size(), "Expected 3 class names to be parsed");
    }

    @Test
    @DisplayName("When no characters can be added to class name, should add empty class")
    void testEmptyClassNames() {
        // GIVEN
        String signature = "L;/";

        // WHEN
        CPSignature result = cpBands.getCPSignature(signature);

        // THEN
        assertEquals(0, result.getClasses().size(), "Expected no class names to be parsed");
    }

    @Test
    @DisplayName("Handle case when signature does not initially exist under 'stringsToCpSignature'")
    void testSignatureAdditionToCache() throws Exception {
        // GIVEN
        String signature = "Lsome/NewClass;";

        // WHEN
        CPSignature result = cpBands.getCPSignature(signature);

        // THEN
        Field stringsToCpSignatureField = CpBands.class.getDeclaredField("stringsToCpSignature");
        stringsToCpSignatureField.setAccessible(true);
        
        
        Map<String, CPSignature> stringsToCpSignature = (Map<String, CPSignature>) stringsToCpSignatureField.get(cpBands);

        assertTrue(stringsToCpSignature.containsKey(signature), "Expected signature to be added to cache");
    }

    @Test
    @DisplayName("Handle signatures with illegal characters after 'L'")
    void testIllegalCharacterHandling() {
        // GIVEN
        String signature = "Lclass;L1La;Ly;L!@#;";

        // WHEN
        CPSignature result = cpBands.getCPSignature(signature);

        // THEN
        assertEquals(2, result.getClasses().size(), "Expected 2 valid class names to be parsed");
    }

    @Test
    @DisplayName("When no class names exist, expect empty class list in signature")
    void testNoClassNames() {
        // GIVEN
        String signature = "A";

        // WHEN
        CPSignature result = cpBands.getCPSignature(signature);

        // THEN
        assertTrue(result.getClasses().isEmpty(), "Expected empty class list in signature");
    }

}