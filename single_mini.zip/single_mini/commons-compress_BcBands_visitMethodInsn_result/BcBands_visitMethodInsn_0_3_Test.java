package org.apache.commons.compress.harmony.pack200;

import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BcBands_visitMethodInsn_0_3_Test {

    @Mock
    private Segment mockSegment;

    @Mock
    private CpBands mockCpBands;

    @Mock
    private CPMethodOrField mockCPMethodOrField;

    private BcBands bcBands;

    @BeforeEach
    public void setUp() {
        bcBands = new BcBands(mockCpBands, mockSegment, 0);
    }

    @Test
    @DisplayName("Handle opcode 182 (invokevirtual) with owner equals currentClass and name equals <init>")
    public void testTC11() throws Exception {
        // Set currentClass and superClass
        bcBands.setCurrentClass("currentClass", "superClass");

        // Mock getCPMethod to return a mock CPMethodOrField
        when(mockCpBands.getCPMethod("currentClass", "<init>", "()V")).thenReturn(mockCPMethodOrField);

        // Access and set byteCodeOffset to initial value
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        // Access and initialize bcCodes with ALOAD_0 (assuming ALOAD_0 is represented by 42)
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        bcCodes.add(42); // ALOAD_0

        // Call the method under test
        bcBands.visitMethodInsn(182, "currentClass", "<init>", "()V");

        // Assertions
        // Check byteCodeOffset (should be incremented by 3)
        int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
        Assertions.assertEquals(3, byteCodeOffset, "byteCodeOffset should be incremented by 3");

        // Check bcInitRef
        Field bcInitRefField = BcBands.class.getDeclaredField("bcInitRef");
        bcInitRefField.setAccessible(true);
        List<CPMethodOrField> bcInitRef = (List<CPMethodOrField>) bcInitRefField.get(bcBands);
        Assertions.assertEquals(1, bcInitRef.size(), "bcInitRef should have one CPMethodOrField added");
        Assertions.assertEquals(mockCPMethodOrField, bcInitRef.get(0), "bcInitRef should contain the mocked CPMethodOrField");

        // Check bcCodes (should contain opcode 206 after adding 24 to 182)
        Assertions.assertEquals(List.of(206), bcCodes.toList(), "bcCodes should contain only opcode 206");
    }

    @Test
    @DisplayName("Handle opcode not matching any case, leading directly to updateRenumbering")
    public void testTC12() throws Exception {
        // Set currentClass and superClass to unknown values
        bcBands.setCurrentClass("unknownOwner", "unknownSuperClass");

        // Access and set byteCodeOffset to initial value
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        // Access and initialize bcCodes with an unsupported opcode
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        bcCodes.add(999);

        // Call the method under test with an unsupported opcode
        bcBands.visitMethodInsn(999, "unknownOwner", "unknownMethod", "()V");

        // Assertions
        // Check byteCodeOffset (should be incremented by 3)
        int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
        Assertions.assertEquals(3, byteCodeOffset, "byteCodeOffset should be incremented by 3");

        // Check bcCodes (should contain opcode 999 and 999)
        Assertions.assertEquals(List.of(999, 999), bcCodes.toList(), "bcCodes should contain opcode 999 twice");

        // Check renumberedOffset
        Field renumberedOffsetField = BcBands.class.getDeclaredField("renumberedOffset");
        renumberedOffsetField.setAccessible(true);
        int renumberedOffset = renumberedOffsetField.getInt(bcBands);
        Assertions.assertEquals(1, renumberedOffset, "renumberedOffset should be incremented by 1");

        // Check bciRenumbering
        Field bciRenumberingField = BcBands.class.getDeclaredField("bciRenumbering");
        bciRenumberingField.setAccessible(true);
        IntList bciRenumbering = (IntList) bciRenumberingField.get(bcBands);
        Assertions.assertEquals(List.of(0, 1), bciRenumbering.toList(), "bciRenumbering should have two entries: 0 and 1");
    }

    @Test
    @DisplayName("Handle opcode 183 (invokespecial) with owner equals superClass and name not <init>")
    public void testTC13() throws Exception {
        // Set currentClass and superClass
        bcBands.setCurrentClass("currentClass", "superClass");

        // Access and set byteCodeOffset to initial value
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        // Access and ensure bcCodes is empty
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        bcCodes.clear();

        // Initialize currentNewClass via reflection
        Field currentNewClassField = BcBands.class.getDeclaredField("currentNewClass");
        currentNewClassField.setAccessible(true);
        currentNewClassField.set(bcBands, "currentNewClass");

        // Mock getCPMethod to return a mock CPMethodOrField
        when(mockCpBands.getCPMethod("superClass", "superExecute", "()V")).thenReturn(mockCPMethodOrField);

        // Call the method under test
        bcBands.visitMethodInsn(183, "superClass", "superExecute", "()V");

        // Assertions
        // Check byteCodeOffset (should be incremented by 3)
        int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
        Assertions.assertEquals(3, byteCodeOffset, "byteCodeOffset should be incremented by 3");

        // Check bcSuperMethod
        Field bcSuperMethodField = BcBands.class.getDeclaredField("bcSuperMethod");
        bcSuperMethodField.setAccessible(true);
        List<CPMethodOrField> bcSuperMethod = (List<CPMethodOrField>) bcSuperMethodField.get(bcBands);
        Assertions.assertEquals(1, bcSuperMethod.size(), "bcSuperMethod should have one CPMethodOrField added");
        Assertions.assertEquals(mockCPMethodOrField, bcSuperMethod.get(0), "bcSuperMethod should contain the mocked CPMethodOrField");

        // Check bcCodes (should contain opcode 207)
        Assertions.assertEquals(List.of(207), bcCodes.toList(), "bcCodes should contain opcode 207");
    }

    @Test
    @DisplayName("Handle opcode 184 (invokestatic) with owner not currentClass or superClass and name not <init>")
    public void testTC14() throws Exception {
        // Set currentClass and superClass
        bcBands.setCurrentClass("currentClass", "superClass");

        // Access and set byteCodeOffset to initial value
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        // Access and ensure bcCodes is empty
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        bcCodes.clear();

        // Initialize currentNewClass via reflection
        Field currentNewClassField = BcBands.class.getDeclaredField("currentNewClass");
        currentNewClassField.setAccessible(true);
        currentNewClassField.set(bcBands, "currentNewClass");

        // Mock getCPMethod to return a mock CPMethodOrField
        when(mockCpBands.getCPMethod("otherClass", "performAction", "()V")).thenReturn(mockCPMethodOrField);

        // Call the method under test
        bcBands.visitMethodInsn(184, "otherClass", "performAction", "()V");

        // Assertions
        // Check byteCodeOffset (should be incremented by 3)
        int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
        Assertions.assertEquals(3, byteCodeOffset, "byteCodeOffset should be incremented by 3");

        // Check bcMethodRef
        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        List<CPMethodOrField> bcMethodRef = (List<CPMethodOrField>) bcMethodRefField.get(bcBands);
        Assertions.assertEquals(1, bcMethodRef.size(), "bcMethodRef should have one CPMethodOrField added");
        Assertions.assertEquals(mockCPMethodOrField, bcMethodRef.get(0), "bcMethodRef should contain the mocked CPMethodOrField");

        // Check bcCodes (should contain opcode 184)
        Assertions.assertEquals(List.of(184), bcCodes.toList(), "bcCodes should contain opcode 184");

        // Check renumberedOffset
        Field renumberedOffsetField = BcBands.class.getDeclaredField("renumberedOffset");
        renumberedOffsetField.setAccessible(true);
        int renumberedOffset = renumberedOffsetField.getInt(bcBands);
        Assertions.assertEquals(1, renumberedOffset, "renumberedOffset should be incremented by 1");

        // Check bciRenumbering
        Field bciRenumberingField = BcBands.class.getDeclaredField("bciRenumbering");
        bciRenumberingField.setAccessible(true);
        IntList bciRenumbering = (IntList) bciRenumberingField.get(bcBands);
        Assertions.assertEquals(List.of(0, 1), bciRenumbering.toList(), "bciRenumbering should have two entries: 0 and 1");
    }

    @Test
    @DisplayName("Handle opcode 183 (invokespecial) with owner equals currentNewClass and name not <init>")
    public void testTC15() throws Exception {
        // Set currentClass and superClass
        bcBands.setCurrentClass("currentClass", "superClass");

        // Access and set byteCodeOffset to initial value
        Field byteCodeOffsetField = BcBands.class.getDeclaredField("byteCodeOffset");
        byteCodeOffsetField.setAccessible(true);
        byteCodeOffsetField.setInt(bcBands, 0);

        // Access and ensure bcCodes is empty
        Field bcCodesField = BcBands.class.getDeclaredField("bcCodes");
        bcCodesField.setAccessible(true);
        IntList bcCodes = (IntList) bcCodesField.get(bcBands);
        bcCodes.clear();

        // Initialize currentNewClass via reflection
        Field currentNewClassField = BcBands.class.getDeclaredField("currentNewClass");
        currentNewClassField.setAccessible(true);
        currentNewClassField.set(bcBands, "currentNewClass");

        // Mock getCPMethod to return a mock CPMethodOrField
        when(mockCpBands.getCPMethod("currentNewClass", "newExecute", "()V")).thenReturn(mockCPMethodOrField);

        // Call the method under test with invokespecial on currentNewClass
        bcBands.visitMethodInsn(183, "currentNewClass", "newExecute", "()V");

        // Assertions
        // Check byteCodeOffset (should be incremented by 3)
        int byteCodeOffset = byteCodeOffsetField.getInt(bcBands);
        Assertions.assertEquals(3, byteCodeOffset, "byteCodeOffset should be incremented by 3");

        // Check bcMethodRef
        Field bcMethodRefField = BcBands.class.getDeclaredField("bcMethodRef");
        bcMethodRefField.setAccessible(true);
        List<CPMethodOrField> bcMethodRef = (List<CPMethodOrField>) bcMethodRefField.get(bcBands);
        Assertions.assertEquals(1, bcMethodRef.size(), "bcMethodRef should have one CPMethodOrField added");
        Assertions.assertEquals(mockCPMethodOrField, bcMethodRef.get(0), "bcMethodRef should contain the mocked CPMethodOrField");

        // Check bcCodes (should contain opcode 207)
        Assertions.assertEquals(List.of(207), bcCodes.toList(), "bcCodes should contain opcode 207");
    }
}