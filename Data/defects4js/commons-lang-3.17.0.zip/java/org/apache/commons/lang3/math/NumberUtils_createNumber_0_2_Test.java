package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigInteger;

public class NumberUtils_createNumber_0_2_Test {

    @Test
    @DisplayName("Hexadecimal input without prefix, should treat as decimal and return Integer")
    void TC06_hexadecimalInputWithoutPrefix_ShouldTreatAsDecimalAndReturnInteger() {
        String input = "12345";
        Number result = NumberUtils.createNumber(input);
        assertInstanceOf(Integer.class, result);
    }

    @Test
    @DisplayName("Input string with leading '+' sign and valid Integer, should return Integer")
    void TC07_inputStringWithLeadingPlusSignAndValidInteger_ShouldReturnInteger() {
        String input = "+12345";
        Number result = NumberUtils.createNumber(input);
        assertInstanceOf(Integer.class, result);
        assertEquals(12345, result.intValue());
    }

    @Test
    @DisplayName("Input string with leading '-' sign and valid Long, should return Long")
    void TC08_inputStringWithLeadingMinusSignAndValidLong_ShouldReturnLong() {
        String input = "-123456789";
        Number result = NumberUtils.createNumber(input);
        assertInstanceOf(Long.class, result);
        assertEquals(-123456789L, result.longValue());
    }

    @Test
    @DisplayName("Input string with type suffix 'L', valid Long, should return Long")
    void TC09_inputStringWithTypeSuffixL_ValidLong_ShouldReturnLong() {
        String input = "123456789L";
        Number result = NumberUtils.createNumber(input);
        assertInstanceOf(Long.class, result);
        assertEquals(123456789L, result.longValue());
    }

    @Test
    @DisplayName("Input string with type suffix 'L', invalid Long, should return BigInteger")
    void TC10_inputStringWithTypeSuffixL_InvalidLong_ShouldReturnBigInteger() {
        String input = "9223372036854775808L";
        Number result = NumberUtils.createNumber(input);
        assertInstanceOf(BigInteger.class, result);
        assertEquals(new BigInteger("9223372036854775808"), result);
    }
}