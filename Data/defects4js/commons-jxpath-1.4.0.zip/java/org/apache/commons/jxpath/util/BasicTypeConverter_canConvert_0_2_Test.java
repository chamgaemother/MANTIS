package org.apache.commons.jxpath.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class BasicTypeConverter_canConvert_0_2_Test {

    private BasicTypeConverter converter = new BasicTypeConverter();

    @Test
    @DisplayName("object is Boolean and useType is non-Number and non-AtomicBoolean, should return false")
    public void TC06() {
        // Given
        Object object = Boolean.TRUE;
        Class<?> toType = Character.class;
        
        // When
        boolean result = converter.canConvert(object, toType);
        
        // Then
        assertEquals(false, result);
    }

    @Test
    @DisplayName("object is Number and useType is Number, should return true")
    public void TC07() {
        // Given
        Object object = Integer.valueOf(10);
        Class<?> toType = Double.class;
        
        // When
        boolean result = converter.canConvert(object, toType);
        
        // Then
        assertEquals(true, result);
    }

    @Test
    @DisplayName("object is Number and useType is Boolean, should return true")
    public void TC08() {
        // Given
        Object object = Double.valueOf(5.5);
        Class<?> toType = Boolean.class;
        
        // When
        boolean result = converter.canConvert(object, toType);
        
        // Then
        assertEquals(true, result);
    }

    @Test
    @DisplayName("object is Number and useType is non-Number and non-Boolean, should return false")
    public void TC09() {
        // Given
        Object object = Float.valueOf(3.14f);
        Class<?> toType = Character.class;
        
        // When
        boolean result = converter.canConvert(object, toType);
        
        // Then
        assertEquals(false, result);
    }

    @Test
    @DisplayName("object is String and useType is Boolean, should return true")
    public void TC10() {
        // Given
        Object object = "true";
        Class<?> toType = Boolean.class;
        
        // When
        boolean result = converter.canConvert(object, toType);
        
        // Then
        assertEquals(true, result);
    }

}