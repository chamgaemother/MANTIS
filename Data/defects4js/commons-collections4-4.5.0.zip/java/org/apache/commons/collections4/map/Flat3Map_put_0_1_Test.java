package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.HashMap;

public class Flat3Map_put_0_1_Test {

    @Test
    @DisplayName("put(key, value) delegates to delegateMap when delegateMap is not null")
    public void TC01() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set delegateMap
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        HashMap<Object, Object> delegate = new HashMap<>();
        delegateMapField.set(map, delegate);

        Object key = "key1";
        Object value = "value1";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        assertEquals("value1", delegate.get(key), "delegateMap should contain the new key-value pair");
        assertNull(result, "Previous value should be null since the key was not present");
    }

    @Test
    @DisplayName("put with null key and size less than 3 adds new null key")
    public void TC02() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        // Using reflection to set size to 0
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 0);

        Object key = null;
        Object value = "value1";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        // Verify key1 is set to null and value1 is updated
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        key1Field.setAccessible(true);
        value1Field.setAccessible(true);

        assertNull(key1Field.get(map), "key1 should be null");
        assertEquals(value, value1Field.get(map), "value1 should be updated with the new value");
        assertNull(result, "put should return null when adding a new key");
    }

    @Test
    @DisplayName("put with existing null key updates value1")
    public void TC03() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        // Using reflection to set size, key1, and value1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        sizeField.setAccessible(true);
        key1Field.setAccessible(true);
        value1Field.setAccessible(true);
        sizeField.setInt(map, 1);
        key1Field.set(map, null);
        value1Field.set(map, "oldValue");

        Object key = null;
        Object value = "newValue";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        assertEquals("newValue", value1Field.get(map), "value1 should be updated with the new value");
        assertEquals("oldValue", result, "put should return the old value that was replaced");
    }

    @Test
    @DisplayName("put with non-null key when size is less than 3 adds new key")
    public void TC04() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        // Using reflection to set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        sizeField.setAccessible(true);
        key3Field.setAccessible(true);
        value3Field.setAccessible(true);
        sizeField.setInt(map, 2);

        Object key = "key3";
        Object value = "value3";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        assertEquals(key, key3Field.get(map), "key3 should be set to the new key");
        assertEquals(value, value3Field.get(map), "value3 should be set to the new value");
        assertNull(result, "put should return null when adding a new key");
    }

    @Test
    @DisplayName("put with existing key3 updates value3")
    public void TC05() throws Exception {
        // GIVEN
        Flat3Map<Object, Object> map = new Flat3Map<>();
        // Using reflection to set size, key3, and value3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        sizeField.setAccessible(true);
        key3Field.setAccessible(true);
        value3Field.setAccessible(true);
        sizeField.setInt(map, 3);
        key3Field.set(map, "key3");
        value3Field.set(map, "oldValue3");

        Object key = "key3";
        Object value = "newValue3";

        // WHEN
        Object result = map.put(key, value);

        // THEN
        assertEquals("newValue3", value3Field.get(map), "value3 should be updated with the new value");
        assertEquals("oldValue3", result, "put should return the old value that was replaced");
    }
}