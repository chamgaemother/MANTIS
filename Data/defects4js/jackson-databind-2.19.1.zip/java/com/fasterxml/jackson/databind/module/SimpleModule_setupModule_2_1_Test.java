package com.fasterxml.jackson.databind.module;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;

import com.fasterxml.jackson.databind.Module.SetupContext;
import com.fasterxml.jackson.databind.jsontype.NamedType;

public class SimpleModule_setupModule_2_1_Test {

    @Test
    @DisplayName("setupModule throws NullPointerException when SetupContext is null")
    void testSetupModule_NullContext_ThrowsNullPointerException(){
        SimpleModule module = new SimpleModule();
        assertThrows(NullPointerException.class, () -> module.setupModule(null));
    }

    @Test
    @DisplayName("setupModule registers multiple subtypes when _subtypes is populated")
    void testSetupModule_MultipleSubtypesAndMixins() {
        SimpleModule module = new SimpleModule();

        // Register subtypes
        module.registerSubtypes(new NamedType(SubType1.class), new NamedType(SubType2.class));

        // Register mixins
        module.setMixInAnnotation(TargetClass1.class, MixinClass1.class);
        module.setMixInAnnotation(TargetClass2.class, MixinClass2.class);

        // Create mock SetupContext
        SetupContext context = Mockito.mock(SetupContext.class);

        // Call setupModule
        module.setupModule(context);

        // Verify that registerSubtypes was called with the named types
        Mockito.verify(context).registerSubtypes(new NamedType[] {
            new NamedType(SubType1.class),
            new NamedType(SubType2.class)
        });

        // Verify mixins
        Mockito.verify(context).setMixInAnnotations(TargetClass1.class, MixinClass1.class);
        Mockito.verify(context).setMixInAnnotations(TargetClass2.class, MixinClass2.class);
    }

    // Dummy classes for testing
    static class SubType1 {}
    static class SubType2 {}
    static class TargetClass1 {}
    static class TargetClass2 {}
    static class MixinClass1 {}
    static class MixinClass2 {}
}