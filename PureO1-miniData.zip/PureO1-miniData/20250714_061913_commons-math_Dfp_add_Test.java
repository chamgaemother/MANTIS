import org.apache.commons.math3.dfp.Dfp;
import org.apache.commons.math3.dfp.DfpField;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

import static org.junit.jupiter.api.Assertions.*;

class DfpTest {

    private DfpField field4 = new DfpField(4);
    private DfpField field5 = new DfpField(5);

    @Test
    void testAddBothFiniteSameSign() {
        Dfp a = field4.getOne();
        Dfp b = field4.getOne();
        Dfp result = a.add(b);
        assertEquals(2, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddBothFiniteDifferentSign() {
        Dfp a = field4.getOne();
        Dfp b = field4.newInstance(-1);
        Dfp result = a.add(b);
        assertEquals(0, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddZeroAndFinite() {
        Dfp zero = field4.getZero();
        Dfp one = field4.getOne();
        Dfp result = zero.add(one);
        assertEquals(1, result.intValue());
        assertTrue(result.isFinite());

        result = one.add(zero);
        assertEquals(1, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddInfinitiesSameSign() {
        Dfp inf = field4.newInstance((byte)1, Dfp.INFINITE);
        Dfp a = inf;
        Dfp b = inf;
        Dfp result = a.add(b);
        assertTrue(result.isInfinite());
        assertEquals(inf.sign, result.sign);
    }

    @Test
    void testAddInfinitiesDifferentSign() {
        Dfp posInf = field4.newInstance((byte)1, Dfp.INFINITE);
        Dfp negInf = field4.newInstance((byte)-1, Dfp.INFINITE);
        Dfp result = posInf.add(negInf);
        assertTrue(result.isNaN());
    }

    @Test
    void testAddInfiniteAndFinite() {
        Dfp posInf = field4.newInstance((byte)1, Dfp.INFINITE);
        Dfp finite = field4.getOne();
        Dfp result = posInf.add(finite);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);

        Dfp negInf = field4.newInstance((byte)-1, Dfp.INFINITE);
        result = negInf.add(finite);
        assertTrue(result.isInfinite());
        assertEquals(-1, result.sign);
    }

    @Test
    void testAddNaNAndFinite() {
        Dfp nan = field4.newInstance((byte)1, Dfp.QNAN);
        Dfp finite = field4.getOne();
        Dfp result = nan.add(finite);
        assertTrue(result.isNaN());

        result = finite.add(nan);
        assertTrue(result.isNaN());
    }

    @Test
    void testAddNaNAndInfinite() {
        Dfp nan = field4.newInstance((byte)1, Dfp.QNAN);
        Dfp posInf = field4.newInstance((byte)1, Dfp.INFINITE);
        Dfp negInf = field4.newInstance((byte)-1, Dfp.INFINITE);
        Dfp result = nan.add(posInf);
        assertTrue(result.isNaN());

        result = nan.add(negInf);
        assertTrue(result.isNaN());

        result = posInf.add(nan);
        assertTrue(result.isNaN());

        result = negInf.add(nan);
        assertTrue(result.isNaN());
    }

    @Test
    void testAddNaNAndNaN() {
        Dfp nan1 = field4.newInstance((byte)1, Dfp.QNAN);
        Dfp nan2 = field4.newInstance((byte)-1, Dfp.QNAN);
        Dfp result = nan1.add(nan2);
        assertTrue(result.isNaN());
    }

    @Test
    void testAddDifferentRadixDigits() {
        Dfp a = field4.getOne();
        Dfp b = field5.getOne();
        Dfp result = a.add(b);
        assertTrue(result.isNaN());
    }

    @Test
    void testAddWithRoundingOverflow() {
        Dfp max = field4.newInstance(9999);
        Dfp one = field4.getOne();
        Dfp result = max.add(one);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    void testAddWithRoundingUnderflow() {
        Dfp small1 = field4.newInstance(1);
        small1.exp = Dfp.MIN_EXP - field4.getRadixDigits();
        Dfp small2 = field4.newInstance(1);
        small2.exp = Dfp.MIN_EXP - field4.getRadixDigits();
        Dfp result = small1.add(small2);
        assertTrue(result.isZero());
    }

    @Test
    void testAddNegativeNumbers() {
        Dfp a = field4.newInstance(-2);
        Dfp b = field4.newInstance(-3);
        Dfp result = a.add(b);
        assertEquals(-5, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddWithDifferentExponents() {
        Dfp a = field4.newInstance(1000);
        a.exp = 2;
        Dfp b = field4.newInstance(1);
        b.exp = -1;
        Dfp result = a.add(b);
        assertEquals(1001, result.toDouble(), 1e-10);
        assertTrue(result.isFinite());
    }

    @Test
    void testAddZeroAndNegativeNumber() {
        Dfp zero = field4.getZero();
        Dfp neg = field4.newInstance(-5);
        Dfp result = zero.add(neg);
        assertEquals(-5, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddSameNumberMultipleTimes() {
        Dfp a = field4.getOne();
        Dfp result = a.add(a).add(a).add(a);
        assertEquals(4, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddLeadingZeros() {
        Dfp a = field4.newInstance("0001");
        Dfp b = field4.newInstance("0002");
        Dfp result = a.add(b);
        assertEquals(3, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddWithDifferentSignsAndExponents() {
        Dfp a = field4.newInstance(5000);
        a.exp = 1;
        Dfp b = field4.newInstance(-2000);
        b.exp = 0;
        Dfp result = a.add(b);
        assertEquals(3000, result.intValue());
        assertTrue(result.isFinite());
    }

    @ParameterizedTest
    @CsvSource({
        "1000, 2000, 3000",
        "-1000, -2000, -3000",
        "1000, -1000, 0",
        "5000, 5000, 10000",
        "9999, 1, Infinity"
    })
    void testAddParameterized(int aVal, int bVal, String expected) {
        Dfp a = field4.newInstance(aVal);
        Dfp b = field4.newInstance(bVal);
        Dfp result = a.add(b);
        if ("Infinity".equals(expected)) {
            assertTrue(result.isInfinite());
            assertEquals(1, result.sign);
        } else {
            assertEquals(Integer.parseInt(expected), result.intValue());
            assertTrue(result.isFinite());
        }
    }

    @Test
    void testAddNullInput() {
        Dfp a = field4.getOne();
        assertThrows(NullPointerException.class, () -> a.add(null));
    }

    @Test
    void testAddWithSubNormalNumbers() {
        Dfp a = field4.newInstance(1);
        a.exp = Dfp.MIN_EXP - field4.getRadixDigits() + 1;
        Dfp b = field4.newInstance(1);
        b.exp = Dfp.MIN_EXP - field4.getRadixDigits() + 1;
        Dfp result = a.add(b);
        assertTrue(result.isZero());
    }

    @Test
    void testAddWithOneNegativeOneFinite() {
        Dfp a = field4.newInstance(-1);
        Dfp b = field4.getOne();
        Dfp result = a.add(b);
        assertEquals(0, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddWithMaxAndMinValues() {
        Dfp max = field4.newInstance(9999);
        max.exp = Dfp.MAX_EXP;
        Dfp min = field4.newInstance(1);
        min.exp = Dfp.MIN_EXP;
        Dfp result = max.add(min);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    void testAddWithSameExponent() {
        Dfp a = field4.newInstance(3000);
        a.exp = 2;
        Dfp b = field4.newInstance(2000);
        b.exp = 2;
        Dfp result = a.add(b);
        assertEquals(5000, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddWithRoundingHalfEven() {
        Dfp a = field4.newInstance(2500);
        Dfp b = field4.newInstance(2500);
        Dfp result = a.add(b);
        // Expected: 5000 rounded to even, which is 5000
        assertEquals(5000, result.intValue());
    }

    @Test
    void testAddWithRoundingHalfUp() {
        DfpField field = new DfpField(4);
        field.setRoundingMode(DfpField.RoundingMode.ROUND_HALF_UP);
        Dfp a = field.newDfp(2500);
        Dfp b = field.newDfp(2501);
        Dfp result = a.add(b);
        // 2500 + 2501 = 5001, which rounds to 5001
        assertEquals(5001, result.intValue());
    }

    @Test
    void testAddWithRoundingHalfDown() {
        DfpField field = new DfpField(4);
        field.setRoundingMode(DfpField.RoundingMode.ROUND_HALF_DOWN);
        Dfp a = field.newDfp(2500);
        Dfp b = field.newDfp(2500);
        Dfp result = a.add(b);
        // 2500 + 2500 = 5000, exactly half, round to even (5000)
        assertEquals(5000, result.intValue());
    }

    @Test
    void testAddWithDifferentSignsAndSameMagnitude() {
        Dfp a = field4.newInstance(5000);
        Dfp b = field4.newInstance(-5000);
        Dfp result = a.add(b);
        assertEquals(0, result.intValue());
        assertTrue(result.isFinite());
    }

    @Test
    void testAddWithDifferentSignsAndDifferentMagnitude() {
        Dfp a = field4.newInstance(7000);
        Dfp b = field4.newInstance(-3000);
        Dfp result = a.add(b);
        assertEquals(4000, result.intValue());
        assertTrue(result.isFinite());

        Dfp c = field4.newInstance(3000);
        Dfp d = field4.newInstance(-7000);
        Dfp result2 = c.add(d);
        assertEquals(-4000, result2.intValue());
        assertTrue(result2.isFinite());
    }

    @Test
    void testAddLargeExponentDifference() {
        Dfp a = field4.newInstance(1);
        a.exp = 10;
        Dfp b = field4.newInstance(1);
        b.exp = -10;
        Dfp result = a.add(b);
        assertEquals(1, result.intValue());
        assertEquals(10, result.exp);
        assertTrue(result.isFinite());
    }

    @Test
    void testAddOverflowExponent() {
        Dfp a = field4.newInstance(5000);
        a.exp = Dfp.MAX_EXP;
        Dfp b = field4.newInstance(5000);
        b.exp = Dfp.MAX_EXP;
        Dfp result = a.add(b);
        assertTrue(result.isInfinite());
        assertEquals(1, result.sign);
    }

    @Test
    void testAddUnderflowExponent() {
        Dfp a = field4.newInstance(1);
        a.exp = Dfp.MIN_EXP;
        Dfp b = field4.newInstance(1);
        b.exp = Dfp.MIN_EXP;
        Dfp result = a.add(b);
        assertTrue(result.isZero());
    }

}