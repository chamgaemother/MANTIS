package org.apache.commons.collections4.map;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.apache.commons.collections4.map.Flat3Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

public class Flat3Map_containsKey_1_1_Test {

    @Test
    @DisplayName("When delegateMap is null, key is null, size=2, key2 is not null, and key1 is null")
    void TC14_containsKey_delegateMap_null_key_null_size_2_key2_not_null_key1_null() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Using reflection to set private fields
        Class<?> clazz = Flat3Map.class;

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        Field key2Field = clazz.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object key2 = new Object();
        key2Field.set(map, key2);

        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // When
        boolean result = map.containsKey(null);

        // Then
        assertTrue(result, "Expected containsKey to return true");
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=2, hash2 matches and key equals key2")
    void TC15_containsKey_delegateMap_null_key_not_null_size_2_hash2_matches_key_equals_key2() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = Flat3Map.class;
        Object key = new Object();
        int keyHash = key.hashCode();

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        Field key2Field = clazz.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, key);

        Field hash2Field = clazz.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, keyHash);

        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // When
        boolean result = map.containsKey(key);

        // Then
        assertTrue(result, "Expected containsKey to return true");
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=2, hash2 matches but key does not equal key2")
    void TC16_containsKey_delegateMap_null_key_not_null_size_2_hash2_matches_key_not_equals_key2() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = Flat3Map.class;
        Object key = new Object();
        Object differentKey2 = new Object();
        int keyHash = key.hashCode();

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        Field key2Field = clazz.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, differentKey2);

        Field hash2Field = clazz.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, keyHash);

        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // When
        boolean result = map.containsKey(key);

        // Then
        assertFalse(result, "Expected containsKey to return false");
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=2, hash2 does not match, hash1 matches and key equals key1")
    void TC17_containsKey_delegateMap_null_key_not_null_size_2_hash2_not_match_hash1_matches_key_equals_key1() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = Flat3Map.class;
        Object key = new Object();
        int keyHash = key.hashCode();
        int differentHash2 = keyHash + 1;

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field hash1Field = clazz.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, keyHash);

        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, key);

        Field hash2Field = clazz.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, differentHash2);

        Field key2Field = clazz.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, new Object());

        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // When
        boolean result = map.containsKey(key);

        // Then
        assertTrue(result, "Expected containsKey to return true");
    }

    @Test
    @DisplayName("When delegateMap is null, key is not null, size=2, hash2 does not match, hash1 matches but key does not equal key1")
    void TC18_containsKey_delegateMap_null_key_not_null_size_2_hash2_not_match_hash1_matches_key_not_equals_key1() throws Exception {
        // Given
        Flat3Map<Object, Object> map = new Flat3Map<>();

        Class<?> clazz = Flat3Map.class;
        Object key = new Object();
        Object differentKey1 = new Object();
        int keyHash = key.hashCode();
        int differentHash2 = keyHash + 1;

        Field sizeField = clazz.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.setInt(map, 2);

        Field hash1Field = clazz.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, keyHash);

        Field key1Field = clazz.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, differentKey1);

        Field hash2Field = clazz.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, differentHash2);

        Field key2Field = clazz.getDeclaredField("key2");
        key2Field.setAccessible(true);
        key2Field.set(map, new Object());

        Field delegateMapField = clazz.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // When
        boolean result = map.containsKey(key);

        // Then
        assertFalse(result, "Expected containsKey to return false");
    }
}