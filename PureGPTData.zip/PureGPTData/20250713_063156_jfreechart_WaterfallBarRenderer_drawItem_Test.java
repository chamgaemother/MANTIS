import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.ui.RectangleEdge;
import org.jfree.data.category.CategoryDataset;
import org.jfree.chart.renderer.category.WaterfallBarRenderer;
import org.jfree.chart.util.PaintUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

public class WaterfallBarRendererTest {

    private WaterfallBarRenderer renderer;
    private Graphics2D g2;

    @BeforeEach
    void setUp() {
        renderer = new WaterfallBarRenderer();
        g2 = Mockito.mock(Graphics2D.class);
    }
    
    @Test
    void testDrawItemWithNullDataset() {
        CategoryItemRendererState state = Mockito.mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = Mockito.mock(CategoryPlot.class);
        CategoryAxis domainAxis = Mockito.mock(CategoryAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, 0, 0, 0);
        verify(g2, never()).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawItemWithNullDataValue() {
        CategoryItemRendererState state = Mockito.mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = Mockito.mock(CategoryPlot.class);
        CategoryAxis domainAxis = Mockito.mock(CategoryAxis.class);
        ValueAxis rangeAxis = Mockito.mock(ValueAxis.class);
        CategoryDataset dataset = Mockito.mock(CategoryDataset.class);
        
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getValue(0, 0)).thenReturn(null);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        verify(g2, never()).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawFirstBar() {
        PlotOrientation[] orientations = PlotOrientation.values();
        
        for (PlotOrientation orientation : orientations) {
            CategoryItemRendererState state = mock(CategoryItemRendererState.class);
            Rectangle2D dataArea = new Rectangle2D.Double(0.0, 0.0, 100.0, 100.0);
            CategoryPlot plot = mock(CategoryPlot.class);
            CategoryAxis domainAxis = mock(CategoryAxis.class);
            ValueAxis rangeAxis = mock(ValueAxis.class);
            CategoryDataset dataset = mock(CategoryDataset.class);

            when(plot.getOrientation()).thenReturn(orientation);
            when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
            when(dataset.getColumnCount()).thenReturn(2);
            when(dataset.getValue(0, 0)).thenReturn(5);
            when(domainAxis.getCategorySeriesMiddle(any(), any(), eq(dataset), anyDouble(), any(), any())).thenReturn(50.0);
            when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(25.0);
            when(state.getBarWidth()).thenReturn(5.0);
            when(state.getSeriesRunningTotal()).thenReturn(0.0);

            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
            
            verify(g2).setPaint(PaintUtils.equal(renderer.getFirstBarPaint(), renderer.getFirstBarPaint()));
            verify(g2).fill(any(Rectangle2D.class));
        }
    }

    @Test
    void testDrawLastBar() {
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getColumnCount()).thenReturn(2);
        when(dataset.getValue(0, 1)).thenReturn(10);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getSeriesRunningTotal()).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategorySeriesMiddle(any(), any(), eq(dataset), anyDouble(), any(), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(25.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(PaintUtils.equal(renderer.getLastBarPaint(), renderer.getLastBarPaint()));
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawPositiveValueBar() {
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(10);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getSeriesRunningTotal()).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategorySeriesMiddle(any(), any(), eq(dataset), anyDouble(), any(), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(15.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(PaintUtils.equal(renderer.getPositiveBarPaint(), renderer.getPositiveBarPaint()));
        verify(g2).fill(any(Rectangle2D.class));
    }

    @Test
    void testDrawNegativeValueBar() {
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double();
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = mock(CategoryDataset.class);

        when(dataset.getColumnCount()).thenReturn(3);
        when(dataset.getValue(0, 1)).thenReturn(-10);
        when(state.getBarWidth()).thenReturn(5.0);
        when(state.getSeriesRunningTotal()).thenReturn(5.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        when(domainAxis.getCategorySeriesMiddle(any(), any(), eq(dataset), anyDouble(), any(), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(25.0);
        when(rangeAxis.valueToJava2D(5.0, dataArea, RectangleEdge.LEFT)).thenReturn(15.0);

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).setPaint(PaintUtils.equal(renderer.getNegativeBarPaint(), renderer.getNegativeBarPaint()));
        verify(g2).fill(any(Rectangle2D.class));
    }
}