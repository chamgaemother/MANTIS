package org.apache.commons.collections4.map;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Flat3MapTest {

    private Flat3Map<String, String> map;

    @BeforeEach
    void setUp() {
        map = new Flat3Map<>();
    }

    @Test
    void remove_FromEmptyMap_ShouldReturnNull() {
        assertNull(map.remove("key"));
    }

    @Test
    void remove_NullKey_NotPresent_ShouldReturnNull() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        assertNull(map.remove(null));
    }

    @Test
    void remove_NullKey_PresentAtSize1_ShouldRemoveAndReturnValue() {
        map.put(null, "NullValue");
        assertEquals("NullValue", map.remove(null));
        assertEquals(0, map.size());
    }

    @Test
    void remove_NullKey_PresentAtSize2_ShouldRemoveKey2() {
        map.put("a", "A");
        map.put(null, "NullValue");
        assertEquals("NullValue", map.remove(null));
        assertEquals(1, map.size());
        assertTrue(map.containsKey("a"));
    }

    @Test
    void remove_NullKey_PresentAtSize3_ShouldRemoveKey3() {
        map.put("a", "A");
        map.put("b", "B");
        map.put(null, "NullValue");
        assertEquals("NullValue", map.remove(null));
        assertEquals(2, map.size());
        assertTrue(map.containsKey("a"));
        assertTrue(map.containsKey("b"));
    }

    @Test
    void remove_NullKey_SwitchesFieldsAfterRemoval() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        map.put(null, "NullValue"); // Delegate mode
        assertEquals("NullValue", map.remove(null));
        assertEquals(3, map.size());
        assertTrue(map.containsKey("a"));
        assertTrue(map.containsKey("b"));
        assertTrue(map.containsKey("c"));
    }

    @Test
    void remove_NonNullKey_NotPresent_ShouldReturnNull() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        assertNull(map.remove("d"));
    }

    @Test
    void remove_NonNullKey_PresentAtSize1_ShouldRemoveAndReturnValue() {
        map.put("a", "A");
        assertEquals("A", map.remove("a"));
        assertEquals(0, map.size());
    }

    @Test
    void remove_NonNullKey_PresentAtSize2_ShouldRemoveKey2() {
        map.put("a", "A");
        map.put("b", "B");
        assertEquals("B", map.remove("b"));
        assertEquals(1, map.size());
        assertTrue(map.containsKey("a"));
    }

    @Test
    void remove_NonNullKey_PresentAtSize3_ShouldRemoveKey3() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        assertEquals("C", map.remove("c"));
        assertEquals(2, map.size());
        assertTrue(map.containsKey("a"));
        assertTrue(map.containsKey("b"));
    }

    @Test
    void remove_NonNullKey_SwitchesToDelegateMap() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        map.put("d", "D"); // Delegate mode
        assertEquals("D", map.remove("d"));
        assertEquals(3, map.size());
        assertTrue(map.containsKey("a"));
        assertTrue(map.containsKey("b"));
        assertTrue(map.containsKey("c"));
    }

    @Test
    void remove_NonNullKey_WithSameHashCode_ShouldRemoveCorrectly() {
        String key1 = "FB"; // hashCode 2236
        String key2 = "Ea"; // hashCode 2236
        map.put(key1, "Value1");
        map.put(key2, "Value2");
        assertEquals("Value1", map.remove(key1));
        assertEquals(1, map.size());
        assertTrue(map.containsKey(key2));
    }

    @Test
    void remove_NonNullKey_WithDifferentHashCode_ShouldNotRemove() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        assertNull(map.remove("d")); // Different hashCode
    }

    @Test
    void remove_WithDelegateMap_ShouldDelegateRemoval() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, "Value" + i);
        }
        assertEquals("Value4", map.remove("key4"));
        assertEquals(3, map.size());
        assertFalse(map.containsKey("key4"));
    }

    @Test
    void remove_AllKeys_ShouldMaintainIntegrity() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        assertEquals("C", map.remove("c"));
        assertEquals("B", map.remove("b"));
        assertEquals("A", map.remove("a"));
        assertTrue(map.isEmpty());
    }

    @Test
    void remove_KeyAfterDelegateMap_ShouldReflectDelegateMapState() {
        for (int i = 1; i <= 5; i++) {
            map.put("key" + i, "Value" + i);
        }
        assertEquals("Value5", map.remove("key5"));
        assertEquals(4, map.size());
        assertFalse(map.containsKey("key5"));
        assertTrue(map.containsKey("key1"));
    }

    @Test
    void remove_NullKey_WhenDelegateMapUsed_ShouldDelegateRemoval() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, "Value" + i);
        }
        map.put(null, "NullValue");
        assertEquals("NullValue", map.remove(null));
        assertEquals(4, map.size());
        assertFalse(map.containsKey(null));
    }

    @Test
    void remove_NonExistingKey_WithSameHashCode_ShouldReturnNull() {
        String key1 = "FB"; // hashCode 2236
        String key2 = "Ea"; // hashCode 2236
        map.put(key1, "Value1");
        assertNull(map.remove(key2));
    }

    @Test
    void remove_NonNullKey_CaseSensitive_ShouldRemoveCorrectly() {
        map.put("Key", "Value1");
        map.put("key", "Value2");
        assertEquals("Value1", map.remove("Key"));
        assertEquals(1, map.size());
        assertTrue(map.containsKey("key"));
    }

    @Test
    void remove_RemoveAllKeys_OneByOneInDelegateMode() {
        for (int i = 1; i <= 5; i++) {
            map.put("key" + i, "Value" + i);
        }
        assertEquals("Value5", map.remove("key5"));
        assertEquals("Value4", map.remove("key4"));
        assertEquals("Value3", map.remove("key3"));
        assertEquals("Value2", map.remove("key2"));
        assertEquals("Value1", map.remove("key1"));
        assertTrue(map.isEmpty());
    }

    @Test
    void remove_NullKey_WhenNotPresent_ShouldReturnNull() {
        map.put("a", "A");
        map.put("b", "B");
        assertNull(map.remove(null));
    }

    @Test
    void remove_NullKey_WithMultipleNulls_ShouldHandleSingleNull() {
        map.put(null, "Null1");
        map.put(null, "Null2"); // Overwrite
        assertEquals("Null2", map.remove(null));
        assertFalse(map.containsKey(null));
    }

    @Test
    void remove_RemoveWithNullKeyInDelegateMap() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, "Value" + i);
        }
        map.put(null, "NullValue");
        assertEquals("NullValue", map.remove(null));
        assertEquals(4, map.size());
        assertFalse(map.containsKey(null));
    }

    @Test
    void remove_NonNullKey_WithNullValue_ShouldRemoveCorrectly() {
        map.put("a", null);
        assertNull(map.remove("a"));
        assertFalse(map.containsKey("a"));
        assertEquals(0, map.size());
    }

    @Test
    void remove_NonNullKey_WithNullValue_InDelegateMap_ShouldRemoveCorrectly() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, null);
        }
        assertNull(map.remove("key4"));
        assertEquals(3, map.size());
        assertFalse(map.containsKey("key4"));
    }

    @Test
    void remove_SameKeyMultipleTimes_ShouldHandleSubsequentRemovals() {
        map.put("a", "A");
        assertEquals("A", map.remove("a"));
        assertNull(map.remove("a"));
    }

    @Test
    void remove_DifferentKeys_ShouldMaintainOtherEntries() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        map.remove("a");
        assertTrue(map.containsKey("b"));
        assertTrue(map.containsKey("c"));
        assertEquals(2, map.size());
    }

    @Test
    void remove_RemoveAllKeys_NoDelegateMap() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        assertEquals("A", map.remove("a"));
        assertEquals("B", map.remove("b"));
        assertEquals("C", map.remove("c"));
        assertTrue(map.isEmpty());
    }

    @Test
    void remove_RemoveAllKeys_WithDelegateMap() {
        for (int i = 1; i <= 6; i++) {
            map.put("key" + i, "Value" + i);
        }
        for (int i = 6; i >= 1; i--) {
            assertEquals("Value" + i, map.remove("key" + i));
        }
        assertTrue(map.isEmpty());
    }

    @Test
    void remove_RemoveKeyCausesSizeDecreaseProperly() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        assertEquals("B", map.remove("b"));
        assertEquals(2, map.size());
        assertFalse(map.containsKey("b"));
        assertTrue(map.containsKey("a"));
        assertTrue(map.containsKey("c"));
    }

    @Test
    void remove_RemoveKey_ReturnsCorrectValue() {
        map.put("a", "A");
        map.put("b", "B");
        assertEquals("A", map.remove("a"));
        assertEquals("B", map.remove("b"));
    }

    @Test
    void remove_RemoveFromDelegateMap_WithExistingKey_ShouldReturnValue() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, "Value" + i);
        }
        assertEquals("Value2", map.remove("key2"));
        assertEquals(3, map.size());
        assertFalse(map.containsKey("key2"));
    }

    @Test
    void remove_RemoveFromDelegateMap_WithNonExistingKey_ShouldReturnNull() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, "Value" + i);
        }
        assertNull(map.remove("key5"));
        assertEquals(4, map.size());
    }

    @Test
    void remove_RemoveNullKey_WhenDelegateMapNotUsed_ShouldHandleCorrectly() {
        map.put("a", "A");
        map.put("b", "B");
        map.put(null, "NullValue");
        assertEquals("NullValue", map.remove(null));
        assertEquals(2, map.size());
        assertFalse(map.containsKey(null));
    }

    @Test
    void remove_RemoveNullKey_FromEmptyMap_ShouldReturnNull() {
        assertNull(map.remove(null));
    }

    @Test
    void remove_RemoveNullKey_FromMapWithOnlyNull_ShouldReturnValueAndEmpty() {
        map.put(null, "NullValue");
        assertEquals("NullValue", map.remove(null));
        assertTrue(map.isEmpty());
    }

    @Test
    void remove_RemoveLastKey_ShouldSwitchBackToFlatMode() {
        for (int i = 1; i <= 4; i++) {
            map.put("key" + i, "Value" + i);
        }
        map.remove("key4");
        map.remove("key3");
        map.remove("key2");
        assertEquals(1, map.size());
        assertTrue(map.containsKey("key1"));
    }

    @Test
    void remove_MultipleRemovals_ShouldMaintainMapIntegrity() {
        map.put("a", "A");
        map.put("b", "B");
        map.put("c", "C");
        map.put("d", "D");
        map.put("e", "E");
        assertEquals("C", map.remove("c"));
        assertEquals("E", map.remove("e"));
        assertEquals(3, map.size());
        assertFalse(map.containsKey("c"));
        assertFalse(map.containsKey("e"));
        assertTrue(map.containsKey("a"));
        assertTrue(map.containsKey("b"));
        assertTrue(map.containsKey("d"));
    }
}