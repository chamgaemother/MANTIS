package org.jfree.chart.renderer.category;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

class StackedBarRendererTest {

    private StackedBarRenderer renderer;
    private Graphics2D g2;
    private CategoryItemRendererState state;
    private Rectangle2D dataArea;
    private CategoryPlot plot;
    private CategoryAxis domainAxis;
    private ValueAxis rangeAxis;
    private CategoryDataset dataset;
    private int row;
    private int column;
    private int pass;

    @BeforeEach
    void setUp() {
        renderer = new StackedBarRenderer();
        g2 = mock(Graphics2D.class);
        state = mock(CategoryItemRendererState.class);
        dataArea = mock(Rectangle2D.class);
        plot = mock(CategoryPlot.class);
        domainAxis = mock(CategoryAxis.class);
        rangeAxis = mock(ValueAxis.class);
        dataset = mock(CategoryDataset.class);
        row = 0;
        column = 0;
        pass = 0;

        when(plot.getDomainAxisForDataset(anyInt())).thenReturn(domainAxis);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.ui.RectangleEdge.LEFT);
        when(state.getBarWidth()).thenReturn(10.0);
    }

    @Test
    void drawItem_SeriesNotVisible_ShouldReturn() {
        when(renderer.isSeriesVisible(row)).thenReturn(false);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_DataValueNull_ShouldReturn() {
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(null);
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_RenderAsPercentages_True_PositiveValue_Vertical_NotInverted_Pass1() {
        renderer.setRenderAsPercentages(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(50);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(50.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                .thenReturn(100.0);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        pass = 1;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2).draw(any());
    }

    @Test
    void drawItem_RenderAsPercentages_False_NegativeValue_Horizontal_Inverted_Pass0_ShadowVisible() {
        renderer.setRenderAsPercentages(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(-30);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(renderer.getShadowsVisible()).thenReturn(true);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(40.0);
        pass = 0;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2).draw(any());
    }

    @Test
    void drawItem_RenderAsPercentages_True_NegativeValue_Vertical_Inverted_Pass2_ItemLabelVisible() {
        renderer.setRenderAsPercentages(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(-20);
        when(rangeAxis.isInverted()).thenReturn(true);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(30.0);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(mock(
                org.jfree.chart.labels.CategoryItemLabelGenerator.class));
        when(renderer.isItemLabelVisible(row, column)).thenReturn(true);
        pass = 2;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2).draw(any());
    }

    @Test
    void drawItem_RenderAsPercentages_True_SeriesInvisibleIntermediate_ShouldCalculateBasesCorrectly() {
        renderer.setRenderAsPercentages(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(25);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0,1});
        when(dataset.getRowCount()).thenReturn(2);
        when(dataset.getValue(1, column)).thenReturn(25);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(50.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                .thenReturn(50.0, 100.0);
        pass = 1;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2).draw(any());
    }

    @Test
    void drawItem_RenderAsPercentages_False_NoShadows_Pass0_ShouldNotDrawShadow() {
        renderer.setRenderAsPercentages(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(40);
        when(renderer.getShadowsVisible()).thenReturn(false);
        pass = 0;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_RenderAsPercentages_False_PositiveValue_Vertical_NotInverted_Pass1_WithEntity() {
        renderer.setRenderAsPercentages(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(60);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(60.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        EntityCollection entities = mock(EntityCollection.class);
        when(state.getEntityCollection()).thenReturn(entities);
        pass = 1;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(entities).add(any());
    }

    @Test
    void drawItem_RenderAsPercentages_True_TotalZero_ShouldHandleDivisionByZero() {
        renderer.setRenderAsPercentages(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(10);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        when(dataset.getRowCount()).thenReturn(1);
        when(dataset.getValue(0, column)).thenReturn(0);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(20.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        pass = 1;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        // Expect no exception, verify some call
        verify(g2, atLeast(0)).draw(any());
    }

    @Test
    void drawItem_RenderAsPercentages_True_SingleSeries_ShouldStackCorrectly() {
        renderer.setRenderAsPercentages(true);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(100);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(70.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(0.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT))
                .thenReturn(0.0);
        when(rangeAxis.valueToJava2D(1.0, dataArea, org.jfree.chart.ui.RectangleEdge.LEFT))
                .thenReturn(100.0);
        pass = 1;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2).draw(any());
    }

    @Test
    void drawItem_RenderAsPercentages_False_Pass2_NoItemLabel_ShouldNotDrawLabel() {
        renderer.setRenderAsPercentages(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(50);
        when(renderer.getItemLabelGenerator(row, column)).thenReturn(null);
        pass = 2;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verifyNoInteractions(g2);
    }

    @Test
    void drawItem_RenderAsPercentages_False_PositiveValue_Vertical_NotInverted_Pass1_WithMinimumBarLength() {
        renderer.setRenderAsPercentages(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(1);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(10.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                .thenReturn(0.0, 5.0);
        when(state.getVisibleSeriesArray()).thenReturn(new int[]{0});
        pass = 1;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2).draw(any());
    }

    @Test
    void drawItem_RenderAsPercentages_False_Vertical_PositiveBaseEqualsGetBase_ShouldPegShadow() {
        renderer.setRenderAsPercentages(false);
        when(renderer.isSeriesVisible(row)).thenReturn(true);
        when(dataset.getValue(row, column)).thenReturn(20);
        when(renderer.getShadowsVisible()).thenReturn(true);
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                .thenReturn(25.0);
        when(rangeAxis.isInverted()).thenReturn(false);
        pass = 0;

        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, pass);
        verify(g2).draw(any());
    }
}