package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import org.apache.commons.lang3.math.NumberUtils;

public class NumberUtils_isCreatable_0_6_Test {

    @Test
    @DisplayName("isCreatable(\"0758\") returns false due to invalid octal digit '8'")
    void TC26() {
        // Given
        String input = "0758";
        
        // When
        boolean result = NumberUtils.isCreatable(input);
        
        // Then
        assertFalse(result);
    }

    @Test
    @DisplayName("isCreatable(\"123e+5\") returns true for valid scientific notation with '+' sign")
    void TC27() {
        // Given
        String input = "123e+5";
        
        // When
        boolean result = NumberUtils.isCreatable(input);
        
        // Then
        assertTrue(result);
    }
}