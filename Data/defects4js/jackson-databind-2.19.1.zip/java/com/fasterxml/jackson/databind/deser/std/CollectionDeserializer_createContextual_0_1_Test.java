package com.fasterxml.jackson.databind.deser.std;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.deser.ValueInstantiator;
import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CollectionDeserializer_createContextual_0_1_Test {

    @Test
    @DisplayName("When _valueInstantiator is null, createContextual returns this without modifications")
    void TC01() throws Exception {
        // Arrange
        JavaType collectionType = mock(JavaType.class);
        CollectionDeserializer deserializer = new CollectionDeserializer(
                collectionType, null, null, null    
        );
        DeserializationContext context = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);

        // Act
        CollectionDeserializer result = deserializer.createContextual(context, property);

        // Assert
        assertSame(deserializer, result);
    }

    @Test
    @DisplayName("_valueInstantiator.canCreateUsingDelegate() returns true and delegateType is not null")
    void TC02() throws Exception {
        // Arrange
        ValueInstantiator valueInstantiator = mock(ValueInstantiator.class);
        when(valueInstantiator.canCreateUsingDelegate()).thenReturn(true);

        JavaType delegateType = mock(JavaType.class);
        when(valueInstantiator.getDelegateType(any())).thenReturn(delegateType);

        JavaType collectionType = mock(JavaType.class);
        CollectionDeserializer deserializer = new CollectionDeserializer(
                collectionType, null, null, valueInstantiator
        );

        DeserializationContext context = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);

        when(context.getConfig()).thenReturn(mock(com.fasterxml.jackson.databind.DeserializationConfig.class));
        JsonDeserializer<Object> mockDeserializer = mock(JsonDeserializer.class);
        Mockito.doReturn(mockDeserializer).when(deserializer).findDeserializer(context, delegateType, property);

        // Act
        CollectionDeserializer result = deserializer.createContextual(context, property);

        // Assert
        assertNotSame(deserializer, result);
    }

    @Test
    @DisplayName("_valueInstantiator.canCreateUsingDelegate() returns true but delegateType is null, expecting InvalidDefinitionException")
    void TC03() throws Exception {
        // Arrange
        ValueInstantiator valueInstantiator = mock(ValueInstantiator.class);
        when(valueInstantiator.canCreateUsingDelegate()).thenReturn(true);
        when(valueInstantiator.getDelegateType(any())).thenReturn(null);

        JavaType collectionType = mock(JavaType.class);
        CollectionDeserializer deserializer = new CollectionDeserializer(
                collectionType, null, null, valueInstantiator
        );

        DeserializationContext context = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);

        when(context.getConfig()).thenReturn(mock(com.fasterxml.jackson.databind.DeserializationConfig.class));

        // Act & Assert
        assertThrows(InvalidDefinitionException.class, () -> {
            deserializer.createContextual(context, property);
        });
    }

    @Test
    @DisplayName("_valueInstantiator.canCreateUsingArrayDelegate() returns true and arrayDelegateType is not null")
    void TC04() throws Exception {
        // Arrange
        ValueInstantiator valueInstantiator = mock(ValueInstantiator.class);
        when(valueInstantiator.canCreateUsingDelegate()).thenReturn(false);
        when(valueInstantiator.canCreateUsingArrayDelegate()).thenReturn(true);

        JavaType arrayDelegateType = mock(JavaType.class);
        when(valueInstantiator.getArrayDelegateType(any())).thenReturn(arrayDelegateType);

        JavaType collectionType = mock(JavaType.class);
        CollectionDeserializer deserializer = new CollectionDeserializer(
                collectionType, null, null, valueInstantiator
        );

        DeserializationContext context = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);

        when(context.getConfig()).thenReturn(mock(com.fasterxml.jackson.databind.DeserializationConfig.class));
        JsonDeserializer<Object> mockDeserializer = mock(JsonDeserializer.class);
        Mockito.doReturn(mockDeserializer).when(deserializer).findDeserializer(context, arrayDelegateType, property);

        // Act
        CollectionDeserializer result = deserializer.createContextual(context, property);

        // Assert
        assertNotSame(deserializer, result);
    }

    @Test
    @DisplayName("_valueInstantiator.canCreateUsingArrayDelegate() returns true but arrayDelegateType is null, expecting InvalidDefinitionException")
    void TC05() throws Exception {
        // Arrange
        ValueInstantiator valueInstantiator = mock(ValueInstantiator.class);
        when(valueInstantiator.canCreateUsingDelegate()).thenReturn(false);
        when(valueInstantiator.canCreateUsingArrayDelegate()).thenReturn(true);
        when(valueInstantiator.getArrayDelegateType(any())).thenReturn(null);

        JavaType collectionType = mock(JavaType.class);
        CollectionDeserializer deserializer = new CollectionDeserializer(
                collectionType, null, null, valueInstantiator
        );

        DeserializationContext context = mock(DeserializationContext.class);
        BeanProperty property = mock(BeanProperty.class);

        when(context.getConfig()).thenReturn(mock(com.fasterxml.jackson.databind.DeserializationConfig.class));

        // Act & Assert
        assertThrows(InvalidDefinitionException.class, () -> {
            deserializer.createContextual(context, property);
        });
    }
}