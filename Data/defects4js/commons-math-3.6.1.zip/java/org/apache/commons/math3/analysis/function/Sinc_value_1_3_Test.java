package org.apache.commons.math3.analysis.function;

import org.apache.commons.math3.analysis.function.Sinc;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

public class Sinc_value_1_3_Test {

    @Test
    @DisplayName("value(NaN) with normalized=true handles NaN input gracefully")
    void TC23() {
        // Given
        Sinc sinc = new Sinc(true);

        // When
        double result = sinc.value(Double.NaN);

        // Then
        assertTrue(Double.isNaN(result), "Expected result to be NaN when input is NaN with normalization");
    }

    @Test
    @DisplayName("value(Infinity) with normalized=true handles Infinity input gracefully")
    void TC24() {
        // Given
        Sinc sinc = new Sinc(true);

        // When
        double result = sinc.value(Double.POSITIVE_INFINITY);

        // Then
        assertTrue(Double.isNaN(result), "Expected result to be NaN when input is Infinity with normalization");
    }
}