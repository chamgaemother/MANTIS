package com.fasterxml.jackson.core.io;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class JsonStringEncoderTest {

    private final JsonStringEncoder encoder = JsonStringEncoder.getInstance();

    @Test
    public void testQuoteAsUTF8_NullInput() {
        assertThrows(NullPointerException.class, () -> {
            encoder.quoteAsUTF8((String) null);
        });
    }

    @Test
    public void testQuoteAsUTF8_EmptyString() {
        byte[] result = encoder.quoteAsUTF8("");
        assertArrayEquals(new byte[0], result);
    }

    @Test
    public void testQuoteAsUTF8_NoEscapes() {
        String input = "Hello World!";
        byte[] expected = "Hello World!".getBytes();
        byte[] result = encoder.quoteAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testQuoteAsUTF8_SimpleEscapes() {
        String input = "Line1\nLine2\tTabbed\\Backslash\"Quote";
        byte[] expected = "\"Line1\\nLine2\\tTabbed\\\\Backslash\\\"Quote\"".getBytes();
        byte[] result = encoder.quoteAsUTF8(input);
        
        // Manually construct expected byte array with escapes
        String expectedEscaped = "Line1\\nLine2\\tTabbed\\\\Backslash\\\"Quote";
        byte[] expectedBytes = expectedEscaped.getBytes();
        assertArrayEquals(expectedBytes, result);
    }

    @Test
    public void testQuoteAsUTF8_ControlCharacters() {
        StringBuilder sb = new StringBuilder();
        for (char c = 0; c <= 0x1F; c++) {
            sb.append(c);
        }
        String input = sb.toString();
        byte[] result = encoder.quoteAsUTF8(input);

        // Each control character should be escaped as \u00XX
        StringBuilder expectedBuilder = new StringBuilder();
        for (char c = 0; c <= 0x1F; c++) {
            expectedBuilder.append("\\u00");
            String hex = Integer.toHexString(c).toUpperCase();
            if (hex.length() == 1) {
                expectedBuilder.append('0');
            }
            expectedBuilder.append(hex);
        }
        byte[] expected = expectedBuilder.toString().getBytes();
        assertArrayEquals(expected, result);
    }

    @Test
    public void testQuoteAsUTF8_NonASCIICharacters() {
        String input = "こんにちは世界"; // "Hello World" in Japanese
        byte[] expected = input.getBytes();
        byte[] result = encoder.quoteAsUTF8(input);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testQuoteAsUTF8_SurrogatePair_Valid() {
        // Emoji 😀 U+1F600 represented as surrogate pair in UTF-16
        String input = "Smile 😀";
        byte[] result = encoder.quoteAsUTF8(input);
        
        // Manually construct expected UTF-8 bytes with emoji
        String escaped = "Smile \uD83D\uDE00";
        byte[] expected = escaped.getBytes();
        assertArrayEquals(expected, result);
    }

    @Test
    public void testQuoteAsUTF8_SurrogatePair_Invalid_LoneHighSurrogate() {
        String input = "Invalid \uD83D Smile";
        assertThrows(IllegalArgumentException.class, () -> {
            encoder.quoteAsUTF8(input);
        });
    }

    @Test
    public void testQuoteAsUTF8_SurrogatePair_Invalid_LoneLowSurrogate() {
        String input = "Invalid \uDE00 Smile";
        assertThrows(IllegalArgumentException.class, () -> {
            encoder.quoteAsUTF8(input);
        });
    }

    @Test
    public void testQuoteAsUTF8_MaxBoundary() {
        // Create a string that just reaches MAX_BYTE_BUFFER_SIZE when encoded
        StringBuilder sb = new StringBuilder();
        int maxSize = 32000;
        for (int i = 0; i < maxSize / 2; i++) {
            sb.append("aa");
        }
        String input = sb.toString();
        byte[] result = encoder.quoteAsUTF8(input);
        assertEquals(maxSize, result.length);
    }

    @Test
    public void testQuoteAsUTF8_BufferExpansion() {
        // Create a string that requires buffer to expand
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            sb.append("\\u1234"); // Each escape adds 6 bytes
        }
        String input = sb.toString();
        byte[] result = encoder.quoteAsUTF8(input);
        assertEquals(6 * 10000, result.length);
    }

    @Test
    public void testQuoteAsUTF8_MixedContent() {
        String input = "Text with \"quotes\", newlines\n, tabs\t, and emoji 😀.";
        byte[] result = encoder.quoteAsUTF8(input);
        
        String expectedEscaped = "Text with \\\"quotes\\\", newlines\\n, tabs\\t, and emoji \\uD83D\\uDE00.";
        byte[] expected = expectedEscaped.getBytes();
        assertArrayEquals(expected, result);
    }

    @Test
    public void testQuoteAsUTF8_AllEscapes() {
        StringBuilder sb = new StringBuilder();
        sb.append('"').append('\\').append('\b').append('\f').append('\n').append('\r').append('\t');
        String input = sb.toString();
        byte[] result = encoder.quoteAsUTF8(input);
        
        String expectedEscaped = "\\\"\\\\\\b\\f\\n\\r\\t";
        byte[] expected = expectedEscaped.getBytes();
        assertArrayEquals(expected, result);
    }

}