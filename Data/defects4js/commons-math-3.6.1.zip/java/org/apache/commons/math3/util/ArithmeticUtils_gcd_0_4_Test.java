package org.apache.commons.math3.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ArithmeticUtils_gcd_0_4_Test {

    @Test
    @DisplayName("gcd(270, 192) returns 6 with multiple iterations in main GCD loop")
    void testTC16() {
        // Given
        long p = 270L;
        long q = 192L;

        // When
        long result = ArithmeticUtils.gcd(p, q);

        // Then
        assertEquals(6L, result, "The GCD of 270 and 192 should be 6");
    }
}