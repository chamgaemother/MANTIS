package org.apache.commons.collections4.map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;

public class Flat3Map_remove_0_2_Test {

    @Test
    @DisplayName("remove null key with size=3, key3 and key2 not null, key1 is null")
    void test_TC06_removeNullKey_size3_key3_key2NotNull_key1Null() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set key3 to someKey3
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object someKey3 = "key3";
        key3Field.set(map, someKey3);

        // Set value3 to value3
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object value3 = "value3";
        value3Field.set(map, value3);

        // Set key2 to someKey2
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object someKey2 = "key2";
        key2Field.set(map, someKey2);

        // Set value2 to value2
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = "value2";
        value2Field.set(map, value2);

        // Set key1 to null
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        key1Field.set(map, null);

        // Set value1 to value1
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = "value1";
        value1Field.set(map, value1);

        // Act
        Object result = map.remove(null);

        // Assert
        assertEquals(value1, result, "Expected value1 to be removed and returned");

        // Check size is now 2
        int size = sizeField.getInt(map);
        assertEquals(2, size, "Size should be decremented to 2");

        // Check key1 is null
        Object key1Value = key1Field.get(map);
        assertNull(key1Value, "key1 should be null");
    }

    @Test
    @DisplayName("remove non-null key with size=3 and key3 matches key")
    void test_TC07_removeNonNullKey_size3_key3Matches() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set key3 to targetKey
        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object targetKey = "targetKey";
        key3Field.set(map, targetKey);

        // Set hash3 to targetKey.hashCode()
        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, targetKey.hashCode());

        // Set value3 to value3
        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object value3 = "value3";
        value3Field.set(map, value3);

        // Act
        Object result = map.remove(targetKey);

        // Assert
        assertEquals(value3, result, "Expected value3 to be removed and returned");

        // Check size is now 2
        int size = sizeField.getInt(map);
        assertEquals(2, size, "Size should be decremented to 2");

        // Check key3 is null
        Object key3Value = key3Field.get(map);
        assertNull(key3Value, "key3 should be null");
    }

    @Test
    @DisplayName("remove non-null key with size=2 and key2 matches key")
    void test_TC08_removeNonNullKey_size2_key2Matches() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 2
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 2);

        // Set key2 to targetKey
        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object targetKey = "targetKey";
        key2Field.set(map, targetKey);

        // Set hash2 to targetKey.hashCode()
        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, targetKey.hashCode());

        // Set value2 to value2
        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = "value2";
        value2Field.set(map, value2);

        // Act
        Object result = map.remove(targetKey);

        // Assert
        assertEquals(value2, result, "Expected value2 to be removed and returned");

        // Check size is now 1
        int size = sizeField.getInt(map);
        assertEquals(1, size, "Size should be decremented to 1");

        // Check key2 is null
        Object key2Value = key2Field.get(map);
        assertNull(key2Value, "key2 should be null");
    }

    @Test
    @DisplayName("remove non-null key with size=1 and key1 matches key")
    void test_TC09_removeNonNullKey_size1_key1Matches() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 1
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 1);

        // Set key1 to targetKey
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object targetKey = "targetKey";
        key1Field.set(map, targetKey);

        // Set hash1 to targetKey.hashCode()
        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, targetKey.hashCode());

        // Set value1 to value1
        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = "value1";
        value1Field.set(map, value1);

        // Act
        Object result = map.remove(targetKey);

        // Assert
        assertEquals(value1, result, "Expected value1 to be removed and returned");

        // Check size is now 0
        int size = sizeField.getInt(map);
        assertEquals(0, size, "Size should be decremented to 0");

        // Check key1 is null
        Object key1Value = key1Field.get(map);
        assertNull(key1Value, "key1 should be null");
    }

    @Test
    @DisplayName("remove non-null key with size=3 and key does not match any key")
    void test_TC10_removeNonNullKey_size3_noMatch() throws Exception {
        // Arrange
        Flat3Map<Object, Object> map = new Flat3Map<>();

        // Set delegateMap to null
        Field delegateMapField = Flat3Map.class.getDeclaredField("delegateMap");
        delegateMapField.setAccessible(true);
        delegateMapField.set(map, null);

        // Set size to 3
        Field sizeField = Flat3Map.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        sizeField.set(map, 3);

        // Set key1, key2, key3 to non-matching keys
        Field key1Field = Flat3Map.class.getDeclaredField("key1");
        key1Field.setAccessible(true);
        Object key1 = "key1";
        key1Field.set(map, key1);

        Field hash1Field = Flat3Map.class.getDeclaredField("hash1");
        hash1Field.setAccessible(true);
        hash1Field.setInt(map, key1.hashCode());

        Field value1Field = Flat3Map.class.getDeclaredField("value1");
        value1Field.setAccessible(true);
        Object value1 = "value1";
        value1Field.set(map, value1);

        Field key2Field = Flat3Map.class.getDeclaredField("key2");
        key2Field.setAccessible(true);
        Object key2 = "key2";
        key2Field.set(map, key2);

        Field hash2Field = Flat3Map.class.getDeclaredField("hash2");
        hash2Field.setAccessible(true);
        hash2Field.setInt(map, key2.hashCode());

        Field value2Field = Flat3Map.class.getDeclaredField("value2");
        value2Field.setAccessible(true);
        Object value2 = "value2";
        value2Field.set(map, value2);

        Field key3Field = Flat3Map.class.getDeclaredField("key3");
        key3Field.setAccessible(true);
        Object key3 = "key3";
        key3Field.set(map, key3);

        Field hash3Field = Flat3Map.class.getDeclaredField("hash3");
        hash3Field.setAccessible(true);
        hash3Field.setInt(map, key3.hashCode());

        Field value3Field = Flat3Map.class.getDeclaredField("value3");
        value3Field.setAccessible(true);
        Object value3 = "value3";
        value3Field.set(map, value3);

        // Define a non-matching key
        Object nonMatchingKey = "nonMatchingKey"; // This key does not match key1, key2, key3

        // Act
        Object result = map.remove(nonMatchingKey);

        // Assert
        assertNull(result, "Expected remove to return null when no matching key is found");

        // Check size remains 3
        int size = sizeField.getInt(map);
        assertEquals(3, size, "Size should remain unchanged as no key was removed");
    }
}