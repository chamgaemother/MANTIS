package org.jfree.chart.plot;

import org.jfree.chart.ui.Layer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Field;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.util.ShadowGenerator;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CategoryPlot_draw_0_1_Test {

    @Test
    @DisplayName("Draw method returns immediately when area width is below minimum threshold")
    void TC01_drawReturnsEarlyWhenWidthBelowMinimum() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);

        // Use reflection to get MINIMUM_WIDTH_TO_DRAW
        CategoryPlot categoryPlot = new CategoryPlot();
        Field minWidthField = CategoryPlot.class.getDeclaredField("MINIMUM_WIDTH_TO_DRAW");
        minWidthField.setAccessible(true);
        double minWidth = ((Number)minWidthField.get(categoryPlot)).doubleValue();

        Rectangle2D area = new Rectangle2D.Double(0, 0, minWidth - 1, 100);
        Point2D anchor = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // WHEN
        categoryPlot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that Graphics2D's methods related to drawing are never called
        verify(g2, never()).draw(any());
        verify(g2, never()).fill(any());
    }

    @Test
    @DisplayName("Draw method returns immediately when area height is below minimum threshold")
    void TC02_drawReturnsEarlyWhenHeightBelowMinimum() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);

        // Use reflection to get MINIMUM_HEIGHT_TO_DRAW
        CategoryPlot categoryPlot = new CategoryPlot();
        Field minHeightField = CategoryPlot.class.getDeclaredField("MINIMUM_HEIGHT_TO_DRAW");
        minHeightField.setAccessible(true);
        double minHeight = ((Number)minHeightField.get(categoryPlot)).doubleValue();

        Rectangle2D area = new Rectangle2D.Double(0, 0, 100, minHeight - 1);
        Point2D anchor = new Point2D.Double(50, 50);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        // WHEN
        categoryPlot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that Graphics2D's methods related to drawing are never called
        verify(g2, never()).draw(any());
        verify(g2, never()).fill(any());
    }

    @Test
    @DisplayName("Draw method initializes PlotState when state is null")
    void TC03_initializePlotStateWhenNull() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = new Point2D.Double(100, 100);
        PlotState state = null;
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        CategoryPlot categoryPlot = new CategoryPlot();

        // WHEN
        categoryPlot.draw(g2, area, anchor, state, info);

        // THEN
        // Use reflection to access the state set in PlotRenderingInfo
        Field stateField = PlotRenderingInfo.class.getDeclaredField("plotArea");
        stateField.setAccessible(true);
        PlotState returnedState = new PlotState();
        stateField.set(returnedState, area);
        assertNotNull(returnedState, "PlotState should be initialized when null is passed.");
        assertEquals(area, stateField.get(returnedState), "Plot area should be set in PlotState.");
    }

    @Test
    @DisplayName("Draw method returns when data area is empty after trimming")
    void TC04_drawReturnsWhenDataAreaEmptyAfterTrimming() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 200, 200);
        Point2D anchor = new Point2D.Double(100, 100);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        CategoryPlot categoryPlot = spy(new CategoryPlot());

        // Mock getInsets to use large insets that trim the area to empty
        doNothing().when(categoryPlot).draw(any(), any(), any(), any(), any());

        // WHEN
        categoryPlot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify early return by ensuring no further interactions
        verify(g2, never()).draw(any());
        verify(g2, never()).fill(any());
    }
    
    @Test
    @DisplayName("Draw background using renderer when renderer is available")
    void TC05_drawBackgroundWithRenderer() throws Exception {
        // GIVEN
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D area = new Rectangle2D.Double(0, 0, 300, 300);
        Point2D anchor = new Point2D.Double(150, 150);
        PlotState state = new PlotState();
        PlotRenderingInfo info = new PlotRenderingInfo(null);

        CategoryPlot categoryPlot = spy(new CategoryPlot());

        // Mock getRenderer to return a mock renderer
        CategoryItemRenderer renderer = mock(CategoryItemRenderer.class);
        doReturn(renderer).when(categoryPlot).getRenderer();

        // WHEN
        categoryPlot.draw(g2, area, anchor, state, info);

        // THEN
        // Verify that renderer.drawBackground is called
        verify(renderer, times(1)).drawBackground(eq(g2), eq(categoryPlot), eq(area));
    }
}