package org.apache.commons.compress.archivers.tar;

import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TarArchiveOutputStream_putArchiveEntry_2_2_Test {

//     @Test
//     @DisplayName("Handles multiple iterations of handleLongName by adding entries with varying name lengths")
//     void TC45_HandleMultipleLongNames() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
//         tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);
// 
//         TarArchiveEntry entry1 = new TarArchiveEntry("normalEntry1.txt");
//         TarArchiveEntry entry2 = new TarArchiveEntry("long_filename_exceeding_limit_" + "a".repeat(100));
//         TarArchiveEntry entry3 = new TarArchiveEntry("name_with_non_ASCII.txt"); // Ensure entry with non-ASCII characters
//         TarArchiveEntry entry4 = new TarArchiveEntry("symbolicLinkEntry");
//         entry4.setLinkName("long_link_name_exceeding_limit_" + "b".repeat(100));
// 
        // Act
//         tarOut.putArchiveEntry(entry1);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.putArchiveEntry(entry2);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.putArchiveEntry(entry3);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.putArchiveEntry(entry4);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.close();
// 
        // Assert
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(tarOut);
//         assertFalse(haveUnclosedEntry, "All entries should be closed.");
//     }

//     @Test
//     @DisplayName("Throws IllegalArgumentException when entry link name exceeds limit in BIGNUMBER_ERROR mode")
//     void TC46_OversizedLinkNameInErrorMode() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_ERROR);
// 
//         String longLinkName = "long_link_name_exceeding_limit_" + "c".repeat(100);
//         TarArchiveEntry entry = new TarArchiveEntry("dummy");
//         entry.setLinkName(longLinkName);
// 
        // Act & Assert
//         Exception exception = assertThrows(IllegalArgumentException.class, () -> {
//             tarOut.putArchiveEntry(entry);
//         });
// 
//         String actualMessage = exception.getMessage().toLowerCase();
//         assertTrue(actualMessage.contains("too long"), "Exception message should indicate the link name is too long.");
//     }

//     @Test
//     @DisplayName("Adding symbolic link with valid link name in bigNumberMode POSIX, expecting PAX headers for link")
//     void TC47_SymbolicLinkWithPAXHeaders() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
// 
//         TarArchiveEntry entry = new TarArchiveEntry("symbolicLinkEntry");
//         entry.setLinkName("valid_link_name.txt");
// 
        // Act
//         tarOut.putArchiveEntry(entry);
//         tarOut.closeArchiveEntry();
//         tarOut.close();
// 
        // Assert
//         byte[] tarBytes = baos.toByteArray();
//         String tarContent = new String(tarBytes, UTF_8);
//         assertTrue(tarContent.contains("PAXHeaders.X"), "PAX headers should be present for the symbolic link.");
//     }

//     @Test
//     @DisplayName("Adding symbolic link with valid link name in BIGNUMBER_STAR mode, expecting GNU longlink")
//     void TC48_SymbolicLinkWithGNULonglink() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR);
// 
//         String longLinkName = "long_link_name_exceeding_limit_" + "d".repeat(100);
//         TarArchiveEntry entry = new TarArchiveEntry("symbolicLinkEntry");
//         entry.setLinkName(longLinkName);
// 
        // Act
//         tarOut.putArchiveEntry(entry);
//         tarOut.closeArchiveEntry();
//         tarOut.close();
// 
        // Assert
//         byte[] tarBytes = baos.toByteArray();
//         String tarContent = new String(tarBytes, UTF_8);
//         assertTrue(tarContent.contains("GNU_LONGLINK"), "GNU longlink entry should be present for the symbolic link.");
//     }

//     @Test
//     @DisplayName("Adding multiple entries with varying configurations to cover branching in putArchiveEntry")
//     void TC49_MultipleEntriesVaryingConfigurations() throws Exception {
        // Arrange
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
//         tarOut.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
//         tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);
// 
//         TarArchiveEntry entry1 = new TarArchiveEntry("normalEntry1.txt");
//         TarArchiveEntry entry2 = new TarArchiveEntry("long_filename_exceeding_limit_" + "e".repeat(100));
//         TarArchiveEntry entry3 = new TarArchiveEntry("name_with_non_ASCII.txt"); // Ensure entry with non-ASCII characters
//         TarArchiveEntry entry4 = new TarArchiveEntry("symbolicLinkEntry");
//         entry4.setLinkName("long_link_name_exceeding_limit_" + "f".repeat(100));
// 
        // Act
//         tarOut.putArchiveEntry(entry1);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.putArchiveEntry(entry2);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.putArchiveEntry(entry3);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.putArchiveEntry(entry4);
//         tarOut.closeArchiveEntry();
// 
//         tarOut.close();
// 
        // Assert
//         Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
//         haveUnclosedEntryField.setAccessible(true);
//         boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(tarOut);
//         assertFalse(haveUnclosedEntry, "All entries should be closed.");
// 
//         byte[] tarBytes = baos.toByteArray();
//         String tarContent = new String(tarBytes, UTF_8);
//         assertTrue(tarContent.contains("PAXHeaders.X") || tarContent.contains("GNU_LONGLINK"), "Appropriate headers should be present based on configurations.");
//     }

}