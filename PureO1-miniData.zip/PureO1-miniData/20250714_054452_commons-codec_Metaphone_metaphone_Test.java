import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.language.Metaphone;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MetaphoneTest {

    private Metaphone metaphone;

    @BeforeEach
    void setUp() {
        metaphone = new Metaphone();
    }

    @Test
    void testNullInput() {
        assertEquals("", metaphone.metaphone(null));
    }

    @Test
    void testEmptyString() {
        assertEquals("", metaphone.metaphone(""));
    }

    @Test
    void testSingleVowel() {
        assertEquals("A", metaphone.metaphone("a"));
        assertEquals("E", metaphone.metaphone("E"));
        assertEquals("I", metaphone.metaphone("i"));
        assertEquals("O", metaphone.metaphone("O"));
        assertEquals("U", metaphone.metaphone("u"));
    }

    @Test
    void testSingleConsonant() {
        assertEquals("B", metaphone.metaphone("b"));
        assertEquals("C", metaphone.metaphone("C"));
        assertEquals("D", metaphone.metaphone("d"));
        assertEquals("F", metaphone.metaphone("F"));
        assertEquals("G", metaphone.metaphone("g"));
        assertEquals("H", metaphone.metaphone("H"));
        assertEquals("J", metaphone.metaphone("j"));
        assertEquals("K", metaphone.metaphone("K"));
        assertEquals("L", metaphone.metaphone("l"));
        assertEquals("M", metaphone.metaphone("M"));
        assertEquals("N", metaphone.metaphone("n"));
        assertEquals("P", metaphone.metaphone("P"));
        assertEquals("Q", metaphone.metaphone("q"));
        assertEquals("R", metaphone.metaphone("R"));
        assertEquals("S", metaphone.metaphone("s"));
        assertEquals("T", metaphone.metaphone("T"));
        assertEquals("V", metaphone.metaphone("v"));
        assertEquals("W", metaphone.metaphone("w"));
        assertEquals("Y", metaphone.metaphone("y"));
        assertEquals("Z", metaphone.metaphone("z"));
    }

    @Test
    void testInitialKN() {
        assertEquals("N", metaphone.metaphone("knight"));
        assertEquals("N", metaphone.metaphone("knock"));
    }

    @Test
    void testInitialGN() {
        assertEquals("N", metaphone.metaphone("gnome"));
        assertEquals("N", metaphone.metaphone("gnaw"));
    }

    @Test
    void testInitialPN() {
        assertEquals("N", metaphone.metaphone("pnemonic"));
        assertEquals("N", metaphone.metaphone("pneumonia"));
    }

    @Test
    void testInitialAE() {
        assertEquals("E", metaphone.metaphone("aerate"));
        assertEquals("E", metaphone.metaphone("aesthetic"));
    }

    @Test
    void testInitialWR() {
        assertEquals("R", metaphone.metaphone("write"));
        assertEquals("R", metaphone.metaphone("wrist"));
    }

    @Test
    void testInitialWH() {
        assertEquals("W", metaphone.metaphone("whistle"));
        assertEquals("W", metaphone.metaphone("whale"));
    }

    @Test
    void testInitialWWithoutH() {
        assertEquals("WTR", metaphone.metaphone("water"));
        assertEquals("WNT", metaphone.metaphone("want"));
    }

    @Test
    void testInitialX() {
        assertEquals("S", metaphone.metaphone("xenon"));
        assertEquals("S", metaphone.metaphone("xylophone"));
    }

    @Test
    void testDuplicateLetters() {
        assertEquals("K", metaphone.metaphone("bookkeeper"));
        assertEquals("SK", metaphone.metaphone("ssk"));
        assertEquals("MTP", metaphone.metaphone("mmptp"));
    }

    @Test
    void testVowelsAtStart() {
        assertEquals("A", metaphone.metaphone("apple"));
        assertEquals("E", metaphone.metaphone("egg"));
        assertEquals("I", metaphone.metaphone("ice"));
        assertEquals("O", metaphone.metaphone("owl"));
        assertEquals("U", metaphone.metaphone("umbrella"));
    }

    @Test
    void testSilentBAfterM() {
        assertEquals("M", metaphone.metaphone("thumb"));
        assertEquals("M", metaphone.metaphone("bomb"));
    }

    @Test
    void testC_SpecialCases_SCI_SCE_SCY() {
        assertEquals("S", metaphone.metaphone("science"));
        assertEquals("S", metaphone.metaphone("schedule"));
        assertEquals("S", metaphone.metaphone("sclerosis"));
    }

    @Test
    void testC_CIA() {
        assertEquals("X", metaphone.metaphone("ciao"));
        assertEquals("X", metaphone.metaphone("cialis"));
    }

    @Test
    void testC_FrontVowels() {
        assertEquals("S", metaphone.metaphone("cycle"));
        assertEquals("S", metaphone.metaphone("cyle"));
        assertEquals("S", metaphone.metaphone("cyst"));
    }

    @Test
    void testC_SCH() {
        assertEquals("K", metaphone.metaphone("school"));
        assertEquals("K", metaphone.metaphone("scholar"));
    }

    @Test
    void testC_CH() {
        assertEquals("X", metaphone.metaphone("choke"));
        assertEquals("K", metaphone.metaphone("christ"));
    }

    @Test
    void testD_G() {
        assertEquals("J", metaphone.metaphone("edge"));
        assertEquals("J", metaphone.metaphone("judge"));
        assertEquals("T", metaphone.metaphone("dog"));
        assertEquals("T", metaphone.metaphone("dad"));
    }

    @Test
    void testGH_SilentAtEndOrBeforeConsonant() {
        assertEquals("K", metaphone.metaphone("laugh"));
        assertEquals("K", metaphone.metaphone("cough"));
    }

    @Test
    void testGH_NotSilent() {
        assertEquals("KH", metaphone.metaphone("ghost"));
        assertEquals("KH", metaphone.metaphone("ghoul"));
    }

    @Test
    void testSilentGIn_GN_GNED() {
        assertEquals("N", metaphone.metaphone("gnash"));
        assertEquals("N", metaphone.metaphone("gnawed"));
    }

    @Test
    void testTerminalH() {
        assertEquals("", metaphone.metaphone("h"));
        assertEquals("AH", metaphone.metaphone("ah"));
    }

    @Test
    void testH_Previous_VARSON() {
        assertEquals("K", metaphone.metaphone("bach"));
        assertEquals("L", metaphone.metaphone("lhama"));
    }

    @Test
    void testH_FollowedByVowel() {
        assertEquals("AH", metaphone.metaphone("aho"));
        assertEquals("AH", metaphone.metaphone("hello"));
    }

    @Test
    void testK_PrecededByC() {
        assertEquals("K", metaphone.metaphone("back"));
        assertEquals("AC", metaphone.metaphone("cackle"));
    }

    @Test
    void testP_PH() {
        assertEquals("F", metaphone.metaphone("phone"));
        assertEquals("F", metaphone.metaphone("pharmacy"));
    }

    @Test
    void testQ() {
        assertEquals("K", metaphone.metaphone("queen"));
        assertEquals("K", metaphone.metaphone("quick"));
    }

    @Test
    void testS_SH_SIO_SIA() {
        assertEquals("X", metaphone.metaphone("she"));
        assertEquals("X", metaphone.metaphone("sion"));
        assertEquals("X", metaphone.metaphone("sial"));
    }

    @Test
    void testT_TIA_TIO_TCH_TH() {
        assertEquals("X", metaphone.metaphone("nation"));
        assertEquals("X", metaphone.metaphone("ratio"));
        assertEquals("KT", metaphone.metaphone("tchotchke"));
        assertEquals("0", metaphone.metaphone("thing"));
        assertEquals("0", metaphone.metaphone("theta"));
    }

    @Test
    void testV() {
        assertEquals("F", metaphone.metaphone("victor"));
        assertEquals("F", metaphone.metaphone("value"));
    }

    @Test
    void testW_Y_FollowedByVowel() {
        assertEquals("W", metaphone.metaphone("water"));
        assertEquals("Y", metaphone.metaphone("yonder"));
        assertEquals("W", metaphone.metaphone("wrap"));
        assertEquals("Y", metaphone.metaphone("yoga"));
    }

    @Test
    void testW_Y_NotFollowedByVowel() {
        assertEquals("", metaphone.metaphone("w"));
        assertEquals("", metaphone.metaphone("y"));
        assertEquals("W", metaphone.metaphone("wh"));
        assertEquals("Y", metaphone.metaphone("y4"));
    }

    @Test
    void testX() {
        assertEquals("KS", metaphone.metaphone("xylophone"));
        assertEquals("KS", metaphone.metaphone("example"));
    }

    @Test
    void testZ() {
        assertEquals("S", metaphone.metaphone("zebra"));
        assertEquals("S", metaphone.metaphone("buzz"));
    }

    @Test
    void testMaxCodeLength() {
        metaphone.setMaxCodeLen(3);
        assertEquals("WTR", metaphone.metaphone("water"));
        metaphone.setMaxCodeLen(4);
        assertEquals("WATR", metaphone.metaphone("water"));
    }

    @Test
    void testIsMetaphoneEqual() {
        assertTrue(metaphone.isMetaphoneEqual("phone", "fone"));
        assertFalse(metaphone.isMetaphoneEqual("phone", "phoenix"));
    }

    @Test
    void testEncodeObjectWithString() throws EncoderException {
        assertEquals("FN", metaphone.encode("phone"));
    }

    @Test
    void testEncodeObjectWithNonString() {
        assertThrows(EncoderException.class, () -> metaphone.encode(123));
    }

    @Test
    void testEncodeString() {
        assertEquals("FN", metaphone.encode("phone"));
    }

}