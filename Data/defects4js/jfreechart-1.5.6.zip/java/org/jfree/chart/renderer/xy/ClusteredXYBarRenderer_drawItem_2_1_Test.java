package org.jfree.chart.renderer.xy;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.*;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.labels.XYItemLabelGenerator;
import org.jfree.chart.renderer.category.BarPainter;
import org.jfree.chart.renderer.xy.XYItemRendererState;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class ClusteredXYBarRenderer_drawItem_2_1_Test {

    @Test
    @DisplayName("drawItem returns immediately when both y0 and y1 are NaN")
    public void TC26_drawItemReturnsWhenY0AndY1AreNaN() throws Exception {
        // GIVEN
        ClusteredXYBarRenderer renderer = new ClusteredXYBarRenderer();
        Graphics2D graphics = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);

        int pass = 0;
        int series = 0;
        int item = 0;

        // Mocking behavior for IntervalXYDataset as it is not possible to cast XYDataset directly
        IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
        when(intervalDataset.getStartYValue(series, item)).thenReturn(Double.NaN);
        when(intervalDataset.getEndYValue(series, item)).thenReturn(Double.NaN);

        // WHEN
        renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, intervalDataset, series, item, crosshairState, pass);

        // THEN
        verify(graphics, never()).draw(any());
        verifyNoInteractions(info);
    }

//     @Test
//     @DisplayName("drawItem paints bar and item label when pass is 1, shadows are visible, and item label is visible")
//     public void TC27_drawItemPaintsBarAndLabel() throws Exception {
        // GIVEN
//         ClusteredXYBarRenderer renderer = spy(new ClusteredXYBarRenderer()); // Use spy to allow partial mocking
//         Graphics2D graphics = mock(Graphics2D.class);
//         XYItemRendererState state = mock(XYItemRendererState.class);
//         Rectangle2D dataArea = mock(Rectangle2D.class);
//         PlotRenderingInfo info = mock(PlotRenderingInfo.class);
//         XYPlot plot = mock(XYPlot.class);
//         ValueAxis domainAxis = mock(ValueAxis.class);
//         ValueAxis rangeAxis = mock(ValueAxis.class);
//         XYDataset dataset = mock(XYDataset.class);
//         CrosshairState crosshairState = mock(CrosshairState.class);
// 
//         int pass = 1;
//         int series = 0;
//         int item = 0;
// 
        // Mocking behavior for IntervalXYDataset as it is not possible to cast XYDataset directly
//         IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
//         when(intervalDataset.getStartYValue(series, item)).thenReturn(10.0);
//         when(intervalDataset.getEndYValue(series, item)).thenReturn(20.0);
// 
        // Mock BarPainter using reflection as the method being private
//         BarPainter mockBarPainter = mock(BarPainter.class);
//         doReturn(mockBarPainter).when(renderer).getBarPainter();
// 
        // Mock isItemLabelVisible
//         doReturn(true).when(renderer).isItemLabelVisible(series, item);
//         XYItemLabelGenerator labelGenerator = mock(XYItemLabelGenerator.class);
//         doReturn(labelGenerator).when(renderer).getItemLabelGenerator(series, item);
// 
        // Mocking Plot and EntityCollection
//         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
//         EntityCollection entities = mock(EntityCollection.class);
//         PlotRenderingInfo ownerInfo = mock(PlotRenderingInfo.class);
//         when(info.getOwner()).thenReturn(ownerInfo);
//         when(ownerInfo.getEntityCollection()).thenReturn(entities);
// 
        // WHEN
//         renderer.drawItem(graphics, state, dataArea, info, plot, domainAxis, rangeAxis, intervalDataset, series, item, crosshairState, pass);
// 
        // THEN
//         verify(renderer.getBarPainter()).paintBar(eq(graphics), eq(renderer), eq(series), eq(item), any(Rectangle2D.class), any());
//         verify(labelGenerator).generateLabel(eq(dataset), eq(series), eq(item));
//         verify(renderer).addEntity(any(), eq(dataset), eq(series), eq(item), anyDouble(), anyDouble());
//     }
}