import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import com.fasterxml.jackson.core.JsonPointer;
import com.fasterxml.jackson.core.JsonStreamContext;

public class JsonPointerTest {

    // A mock class to simulate JsonStreamContext behavior
    private static class MockJsonStreamContext extends JsonStreamContext {
        private final Type type;
        private final String currentName;
        private final int currentIndex;
        private final boolean hasPathSegment;
        private final MockJsonStreamContext parent;

        public MockJsonStreamContext(Type type, String currentName, int currentIndex, boolean hasPathSegment, MockJsonStreamContext parent) {
            this.type = type;
            this.currentName = currentName;
            this.currentIndex = currentIndex;
            this.hasPathSegment = hasPathSegment;
            this.parent = parent;
        }

        @Override
        public JsonStreamContext getParent() {
            return parent;
        }

        @Override
        public String getCurrentName() {
            return currentName;
        }

        @Override
        public int getCurrentIndex() {
            return currentIndex;
        }

        @Override
        protected Type getType() {
            return type;
        }

        @Override
        public boolean hasPathSegment() {
            return hasPathSegment;
        }

        @Override
        public boolean inRoot() {
            return type == Type.ROOT;
        }
    }

    @Test
    public void testNullContextReturnsEmpty() {
        JsonPointer result = JsonPointer.forPath(null, true);
        assertEquals(JsonPointer.empty(), result, "Null context should return an empty JsonPointer");
    }

    @Test
    public void testEmptyRootSegmentIncluded() {
        MockJsonStreamContext context = new MockJsonStreamContext(JsonStreamContext.Type.ROOT, null, 0, false, null);
        JsonPointer result = JsonPointer.forPath(context, true);
        assertEquals(JsonPointer.compile("/0"), result, "Root inclusion should lead to '/0'");
    }

    @Test
    public void testEmptyRootSegmentNotIncluded() {
        MockJsonStreamContext context = new MockJsonStreamContext(JsonStreamContext.Type.ROOT, null, 0, false, null);
        JsonPointer result = JsonPointer.forPath(context, false);
        assertEquals(JsonPointer.empty(), result, "Root non-inclusion should lead to an empty JsonPointer");
    }

    @Test
    public void testObjectPathBuilding() {
        MockJsonStreamContext parent = new MockJsonStreamContext(JsonStreamContext.Type.OBJECT, "folder", -1, true, null);
        MockJsonStreamContext child = new MockJsonStreamContext(JsonStreamContext.Type.OBJECT, "file", -1, true, parent);

        JsonPointer result = JsonPointer.forPath(child, false);
        assertEquals(JsonPointer.compile("/folder/file"), result, "Path should resolve to '/folder/file'");
    }

    @Test
    public void testArrayPathBuilding() {
        MockJsonStreamContext parent = new MockJsonStreamContext(JsonStreamContext.Type.ARRAY, null, 3, true, null);
        MockJsonStreamContext child = new MockJsonStreamContext(JsonStreamContext.Type.ARRAY, null, 5, true, parent);

        JsonPointer result = JsonPointer.forPath(child, false);
        assertEquals(JsonPointer.compile("/3/5"), result, "Path should resolve to '/3/5'");
    }

    @ParameterizedTest
    @CsvSource({
        ", false, ''",
        ", true, ''",
        "ROOT, , ''",
    })
    public void testRootWithoutIndexFails(String typeStr, Boolean includeRoot, String expected) {
        JsonStreamContext.Type type = (typeStr != null) ? JsonStreamContext.Type.valueOf(typeStr) : null;
        MockJsonStreamContext context = new MockJsonStreamContext(type, null, -1, false, null);

        JsonPointer result = JsonPointer.forPath(context, includeRoot);
        assertEquals(JsonPointer.compile(expected), result, "Root without index should yield an empty path");
    }

    @Test
    public void testEmptyContextWithNoPath() {
        MockJsonStreamContext context = new MockJsonStreamContext(JsonStreamContext.Type.OBJECT, null, -1, false, null);

        JsonPointer result = JsonPointer.forPath(context, false);
        assertEquals(JsonPointer.empty(), result, "Empty context with no path should return an empty JsonPointer");
    }
}