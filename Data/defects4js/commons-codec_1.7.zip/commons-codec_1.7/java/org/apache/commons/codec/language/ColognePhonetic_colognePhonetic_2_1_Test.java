package org.apache.commons.codec.language;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ColognePhonetic_colognePhonetic_2_1_Test {

    @Test
    @DisplayName("Input with consecutive 'C's not after 'S' or 'Z', should assign code '8'")
    void testTC44() {
        // Given
        String input = "Accidental";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("8"), "Result should contain '8' for each 'C' not after 'S' or 'Z'");
    }

    @Test
    @DisplayName("Input with 'C' after 'S', should assign code '8'")
    void testTC45() {
        // Given
        String input = "Success";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("8"), "Result should contain '8' for 'C' after 'S'");
    }

    @Test
    @DisplayName("Input with 'C' after 'Z', should assign code '8'")
    void testTC46() {
        // Given
        String input = "ZacC";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("8"), "Result should contain '8' for 'C' after 'Z'");
    }

    @Test
    @DisplayName("Input with 'C' before 'L', should assign code '4'")
    void testTC47() {
        // Given
        String input = "Climb";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("4"), "Result should contain '4' for 'C' before 'L'");
    }

    @Test
    @DisplayName("Input with 'C' before 'A' and 'C' before 'H', testing multiple contexts")
    void testTC48() {
        // Given
        String input = "Catch";

        // When
        ColognePhonetic phonetic = new ColognePhonetic();
        String result = phonetic.colognePhonetic(input);

        // Then
        assertTrue(result.contains("4"), "Result should contain '4' for 'C' before 'A'");
        assertTrue(result.contains("8"), "Result should contain '8' for 'C' before 'H'");
    }

}