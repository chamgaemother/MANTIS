package org.apache.commons.lang3;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StringUtils_getLevenshteinDistance_0_1_Test {

    @Test
    @DisplayName("getLevenshteinDistance(null, \"test\", 5) throws IllegalArgumentException when first string is null")
    void TC01_null_first_string_exception() {
        CharSequence s = null;
        CharSequence t = "test";
        int threshold = 5;

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            StringUtils.getLevenshteinDistance(s, t, threshold);
        });
        assertEquals("Strings must not be null", exception.getMessage());
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"test\", null, 5) throws IllegalArgumentException when second string is null")
    void TC02_null_second_string_exception() {
        CharSequence s = "test";
        CharSequence t = null;
        int threshold = 5;

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            StringUtils.getLevenshteinDistance(s, t, threshold);
        });
        assertEquals("Strings must not be null", exception.getMessage());
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"test\", \"test\", -1) throws IllegalArgumentException for negative threshold")
    void TC03_negative_threshold_exception() {
        CharSequence s = "test";
        CharSequence t = "test";
        int threshold = -1;

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            StringUtils.getLevenshteinDistance(s, t, threshold);
        });
        assertEquals("Threshold must not be negative", exception.getMessage());
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"\", \"\", 0) returns 0 when both strings are empty and threshold is zero")
    void TC04_both_strings_empty_zero_threshold() {
        CharSequence s = "";
        CharSequence t = "";
        int threshold = 0;

        int result = StringUtils.getLevenshteinDistance(s, t, threshold);
        assertEquals(0, result);
    }

    @Test
    @DisplayName("getLevenshteinDistance(\"hello\", \"hello\", 5) returns 0 when both strings are identical within threshold")
    void TC05_identical_strings_within_threshold() {
        CharSequence s = "hello";
        CharSequence t = "hello";
        int threshold = 5;

        int result = StringUtils.getLevenshteinDistance(s, t, threshold);
        assertEquals(0, result);
    }
}