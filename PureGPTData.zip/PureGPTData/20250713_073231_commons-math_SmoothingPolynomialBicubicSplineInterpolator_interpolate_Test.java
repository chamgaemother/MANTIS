import org.apache.commons.math3.analysis.interpolation.BicubicSplineInterpolatingFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SmoothingPolynomialBicubicSplineInterpolatorTest {

    @Test
    public void testInterpolateWithValidInputs() {
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator(3);

        double[] xval = {0, 1, 2, 3};
        double[] yval = {0, 1, 2, 3};
        double[][] fval = {
                {0, 1, 4, 9},
                {0, 1, 4, 9},
                {0, 1, 4, 9},
                {0, 1, 4, 9}
        };

        assertDoesNotThrow(() -> {
            BicubicSplineInterpolatingFunction f = interpolator.interpolate(xval, yval, fval);
            assertNotNull(f);
        });
    }

    @Test
    public void testInterpolateWithEmptyArrays() {
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator(3);

        double[] xval = {};
        double[] yval = {};
        double[][] fval = {};

        assertThrows(NoDataException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

    @Test
    public void testInterpolateWithNullInputs() {
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator(3);

        assertThrows(NullArgumentException.class, () -> {
            interpolator.interpolate(null, null, null);
        });
    }

    @Test
    public void testInterpolateWithDimensionMismatch() {
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator(3);

        double[] xval = {0, 1, 2};
        double[] yval = {0, 1};
        double[][] fval = {
                {0, 1},
                {0, 1},
                {0, 1, 4}
        };

        assertThrows(DimensionMismatchException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

    @Test
    public void testInterpolateWithNonMonotonicSequence() {
        SmoothingPolynomialBicubicSplineInterpolator interpolator = new SmoothingPolynomialBicubicSplineInterpolator(3);

        double[] xval = {0, 2, 1}; // Non-monotonic
        double[] yval = {0, 1, 2};
        double[][] fval = {
                {0, 1, 4},
                {0, 1, 4},
                {0, 1, 4}
        };

        assertThrows(NonMonotonicSequenceException.class, () -> {
            interpolator.interpolate(xval, yval, fval);
        });
    }

    @Test
    public void testConstructorNegativeDegreeX() {
        assertThrows(NotPositiveException.class, () -> {
            new SmoothingPolynomialBicubicSplineInterpolator(-1, 3);
        });
    }

    @Test
    public void testConstructorNegativeDegreeY() {
        assertThrows(NotPositiveException.class, () -> {
            new SmoothingPolynomialBicubicSplineInterpolator(3, -1);
        });
    }
}