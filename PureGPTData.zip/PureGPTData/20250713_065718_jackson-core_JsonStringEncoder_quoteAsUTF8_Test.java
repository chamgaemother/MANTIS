import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class JsonStringEncoderTest {

    @Test
    public void testQuoteAsUTF8WithAsciiCharacters() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "Normal string";
        byte[] result = encoder.quoteAsUTF8(input);
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testQuoteAsUTF8WithSpecialAsciiCharacters() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "\b\f\n\r\t\"\\";
        byte[] result = encoder.quoteAsUTF8(input);
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testQuoteAsUTF8WithUnicodeCharacters() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "Unicode \u00A9";
        byte[] result = encoder.quoteAsUTF8(input);
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testQuoteAsUTF8WithSurrogatePair() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "Surrogate \uD834\uDD1E";
        byte[] result = encoder.quoteAsUTF8(input);
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testQuoteAsUTF8WithMalformedSurrogatePair() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "\uD834X";
        assertThrows(IllegalArgumentException.class, () -> encoder.quoteAsUTF8(input));
    }

    @Test
    public void testQuoteAsUTF8WithUnmatchedSurrogate() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "\uDD1E";
        assertThrows(IllegalArgumentException.class, () -> encoder.quoteAsUTF8(input));
    }

    @Test
    public void testQuoteAsUTF8WithNullInput() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        assertThrows(NullPointerException.class, () -> encoder.quoteAsUTF8(null));
    }

    @Test
    public void testQuoteAsUTF8WithEmptyString() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "";
        byte[] result = encoder.quoteAsUTF8(input);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testQuoteAsUTF8WithNonAsciiCharacters() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "Non-Ascii ©";
        byte[] result = encoder.quoteAsUTF8(input);
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    public void testQuoteAsUTF8WithInvalidSurrogatePairLow() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "\uD834\u0041";
        assertThrows(IllegalArgumentException.class, () -> encoder.quoteAsUTF8(input));
    }

    @Test
    public void testQuoteAsUTF8WithHighValueSurrogate() {
        JsonStringEncoder encoder = new JsonStringEncoder();
        String input = "\uDBFF\uDFFF";
        byte[] result = encoder.quoteAsUTF8(input);
        assertNotNull(result);
    }
}