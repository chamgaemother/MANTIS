package org.apache.commons.math3.analysis.solvers;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.analysis.UnivariateFunction;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;

public class UnivariateSolverUtils_forceSide_0_2_Test {

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop iterates multiple times and successfully brackets")
    void TC06_allowedSolution_not_ANY_SIDE_multiple_iterations_successfully_brackets() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 8;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver bracketing = Mockito.mock(BracketedUnivariateSolver.class);
        Mockito.when(bracketing.solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(2.0), eq(allowedSolution)))
               .thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        Assertions.assertEquals(2.0, result);
        Mockito.verify(bracketing).solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop adjusts xLo only to bracket")
    void TC07_allowedSolution_not_ANY_SIDE_loop_adjusts_xLo_only_to_bracket() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 4;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver bracketing = Mockito.mock(BracketedUnivariateSolver.class);
        Mockito.when(bracketing.solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(2.0), eq(allowedSolution)))
               .thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        Assertions.assertEquals(2.0, result);
        Mockito.verify(bracketing).solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop adjusts xHi only to bracket")
    void TC08_allowedSolution_not_ANY_SIDE_loop_adjusts_xHi_only_to_bracket() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
        int maxEval = 4;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver bracketing = Mockito.mock(BracketedUnivariateSolver.class);
        Mockito.when(bracketing.solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(2.0), eq(allowedSolution)))
               .thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        Assertions.assertEquals(2.0, result);
        Mockito.verify(bracketing).solve(anyInt(), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop adjusts both xLo and xHi without finding bracketing, throws NoBracketingException")
    void TC09_allowedSolution_not_ANY_SIDE_loop_adjusts_both_without_bracketing_throws_exception() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.LEFT_SIDE;
        int maxEval = 6;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver bracketing = Mockito.mock(BracketedUnivariateSolver.class);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN & THEN
        Assertions.assertThrows(NoBracketingException.class, () -> {
            UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);
        });
    }

    @Test
    @DisplayName("allowedSolution is not ANY_SIDE, loop finds bracketing on the last allowed iteration")
    void TC10_allowedSolution_not_ANY_SIDE_loop_finds_bracketing_on_last_iteration() {
        // GIVEN
        AllowedSolution allowedSolution = AllowedSolution.RIGHT_SIDE;
        int maxEval = 4;
        UnivariateFunction f = x -> x - 2;
        BracketedUnivariateSolver bracketing = Mockito.mock(BracketedUnivariateSolver.class);
        Mockito.when(bracketing.solve(eq(2), eq(f), anyDouble(), anyDouble(), eq(2.0), eq(allowedSolution)))
               .thenReturn(2.0);
        double baseRoot = 2.0;
        double min = 0.0;
        double max = 4.0;

        // WHEN
        double result = UnivariateSolverUtils.forceSide(maxEval, f, bracketing, baseRoot, min, max, allowedSolution);

        // THEN
        Assertions.assertEquals(2.0, result);
        Mockito.verify(bracketing).solve(eq(2), eq(f), anyDouble(), anyDouble(), eq(baseRoot), eq(allowedSolution));
    }
}