package com.fasterxml.jackson.dataformat.xml.util;
import java.lang.reflect.*;
import static org.mockito.Mockito.*;
import java.io.*;
import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import com.fasterxml.jackson.dataformat.xml.util.StaxUtil;

public class StaxUtil_sanitizeXmlTypeName_0_4_Test {

    @Test
    @DisplayName("sanitizeXmlTypeName with name requiring replacements and suffix appending")
    public void TC16() {
        // GIVEN
        String name = "Item$Category[]";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);
        
        // THEN
        assertEquals("Item.Categorys", result);
    }

    @Test
    @DisplayName("sanitizeXmlTypeName with name having no changes after removing '[]'")
    public void TC17() {
        // GIVEN
        String name = "Item[]";
        
        // WHEN
        String result = StaxUtil.sanitizeXmlTypeName(name);
        
        // THEN
        assertEquals("Items", result);
    }
}