import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.renderer.category.MinMaxCategoryRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.CategoryDataset;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static org.mockito.Mockito.*;

public class MinMaxCategoryRendererTest {

    @Test
    public void testDrawItemWithValueNull() {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        CategoryPlot plot = new CategoryPlot();
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        CategoryDataset dataset = new DefaultCategoryDataset();
        
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
        
        verifyNoInteractions(g2, state, domainAxis, rangeAxis);
    }

    @Test
    public void testDrawItemWithPlotOrientationVerticalAndLineBetweenPoints() {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "R1", "C1");
        dataset.addValue(2.0, "R1", "C2");
        
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(50.0, 75.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(20.0, 30.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
        
        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        renderer.setDrawLines(true);
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2).draw(any(Line2D.class));
    }

    @Test
    public void testDrawItemWithPlotOrientationHorizontalAndLastCategory() {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(2.0, "R1", "C1");
        dataset.addValue(1.0, "R1", "C2");
        
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        
        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(50.0, 75.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(30.0, 20.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);

        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        renderer.lastCategory = 1;
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);

        verify(g2, atLeastOnce()).draw(any(Line2D.class));
    }

    @Test
    public void testDrawItemHandlesNullDataset() {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);

        CategoryPlot plot = new CategoryPlot();
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, null, 0, 0, 0);

        verifyNoInteractions(g2, state, domainAxis, rangeAxis);
    }

    @Test
    public void testDrawItemWithMixedValuesAndMinMaxIcons() {
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(3.0, "R1", "C1");
        dataset.addValue(1.0, "R1", "C1");
        dataset.addValue(5.0, "R1", "C1");

        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);

        when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(Rectangle2D.class), any())).thenReturn(50.0);
        when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenReturn(10.0, 5.0, 15.0);
        when(plot.getOrientation()).thenReturn(PlotOrientation.VERTICAL);

        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
        
        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 2);

        verify(g2, atLeastOnce()).draw(any(Line2D.class));
    }
}