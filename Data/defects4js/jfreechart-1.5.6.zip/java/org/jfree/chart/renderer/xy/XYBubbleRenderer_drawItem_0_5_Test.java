package org.jfree.chart.renderer.xy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYZDataset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

public class XYBubbleRenderer_drawItem_0_5_Test {

    @Test
    @DisplayName("drawItem handles multiple passes without state interference")
    void TC21_drawItem_handles_multiple_passes_without_state_interference() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYDataset dataset = mock(XYDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Configure dataset for multiple items
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0, 2.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(3.0, 4.0);
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        // Spy does not work with 'when', using doReturn instead
        doReturn(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS).when(renderer).getScaleType();
        doReturn(false).when(renderer).isItemLabelVisible(anyInt(), anyInt());

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 1, 1, crosshairState, pass);

        // THEN
        // Verify that draw methods are called for both items without interference
        verify(renderer, times(2)).getItemPaint(anyInt(), anyInt());
        verify(renderer, times(2)).getItemOutlineStroke(anyInt(), anyInt());
        verify(renderer, times(2)).getItemOutlinePaint(anyInt(), anyInt());
    }

    @Test
    @DisplayName("drawItem handles NaN z values gracefully")
    void TC22_drawItem_handles_NaN_z_values_gracefully() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(Double.NaN);

        // WHEN
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);

        // THEN
        // Verify that no drawing methods are called since z is NaN
        verify(g2, never()).fill(any(Ellipse2D.class));
        verify(g2, never()).draw(any(Ellipse2D.class));
    }

    @Test
    @DisplayName("drawItem handles null PlotRenderingInfo gracefully")
    void TC23_drawItem_handles_null_PlotRenderingInfo_gracefully() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = new XYBubbleRenderer();
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(3.0);
        doReturn(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS).when(renderer).getScaleType();
        doReturn(false).when(renderer).isItemLabelVisible(anyInt(), anyInt());

        // WHEN
        renderer.drawItem(g2, state, dataArea, null, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);

        // THEN
        // Verify that setPaint is called since info is null, but addEntity is not
        verify(g2, atLeastOnce()).setPaint(any(Paint.class));
    }

    @Test
    @DisplayName("drawItem handles item label visibility toggle correctly")
    void TC24_drawItem_handles_item_label_visibility_toggle_correctly() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(2.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(3.0);
        doReturn(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS).when(renderer).getScaleType();
        doReturn(false).doReturn(true).when(renderer).isItemLabelVisible(anyInt(), anyInt());

        // WHEN
        // First call with label visibility false
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);
        // Toggle label visibility to true
        renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, 0, 0, crosshairState, pass);

        // THEN
        // Verify that drawItemLabel is called only in the second call
        verify(renderer, times(1)).drawItemLabel(any(), any(), any(), anyInt(), anyInt(), anyDouble(), anyDouble(), anyBoolean());
    }

    @Test
    @DisplayName("drawItem handles multiple series correctly")
    void TC25_drawItem_handles_multiple_series_correctly() throws Exception {
        // GIVEN
        XYBubbleRenderer renderer = spy(new XYBubbleRenderer());
        Graphics2D g2 = mock(Graphics2D.class);
        XYItemRendererState state = mock(XYItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        XYPlot plot = mock(XYPlot.class);
        ValueAxis domainAxis = mock(ValueAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        XYZDataset dataset = mock(XYZDataset.class);
        CrosshairState crosshairState = mock(CrosshairState.class);
        int pass = 0;

        // Configure dataset with multiple series
        when(renderer.getItemVisible(anyInt(), anyInt())).thenReturn(true, false, true);
        when(dataset.getXValue(anyInt(), anyInt())).thenReturn(1.0, 2.0, 3.0);
        when(dataset.getYValue(anyInt(), anyInt())).thenReturn(4.0, 5.0, 6.0);
        when(dataset.getZValue(anyInt(), anyInt())).thenReturn(7.0, 8.0, 9.0);
        doReturn(XYBubbleRenderer.SCALE_ON_DOMAIN_AXIS).when(renderer).getScaleType();
        doReturn(true).when(renderer).isItemLabelVisible(anyInt(), anyInt());

        // WHEN
        // Render multiple series
        for (int series = 0; series < 3; series++) {
            for (int item = 0; item < 2; item++) {
                renderer.drawItem(g2, state, dataArea, info, plot, domainAxis, rangeAxis, dataset, series, item, crosshairState, pass);
            }
        }

        // THEN
        // Verify that only visible series are drawn
        verify(renderer, times(4)).getItemPaint(anyInt(), anyInt()); // 2 items per visible series
        verify(renderer, times(4)).getItemOutlineStroke(anyInt(), anyInt());
        verify(renderer, times(4)).getItemOutlinePaint(anyInt(), anyInt());
    }
}
