package org.apache.commons.codec.language;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DoubleMetaphone_doubleMetaphone_0_5_Test {

    @Test
    @DisplayName("doubleMetaphone handles 'SC' followed by 'H' in 'SCHOOL'")
    public void TC21_doubleMetaphone_SCH_sequence_SCHOOL() throws Exception {
        // GIVEN
        String value = "SCHOOL";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("X"), "Expected encoded 'SCH' as 'X' for Germanic origin");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'TCH' sequence in 'MATCH'")
    public void TC22_doubleMetaphone_TCH_sequence_MATCH() throws Exception {
        // GIVEN
        String value = "MATCH";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("X"), "Expected encoded 'TCH' as 'X'");
    }

    @Test
    @DisplayName("doubleMetaphone processes 'WH' at the beginning in 'WHAT'")
    public void TC23_doubleMetaphone_WH_sequence_WHAT() throws Exception {
        // GIVEN
        String value = "WHAT";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("F") || result.contains("A"), "Expected encoded 'WH' as 'F' or 'A'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'WICZ' sequence in 'FILIPOWICZ'")
    public void TC24_doubleMetaphone_WICZ_sequence_FILIPOWICZ() throws Exception {
        // GIVEN
        String value = "FILIPOWICZ";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("TS") || result.contains("FX"), "Expected encoded 'WICZ' as 'TS' or 'FX'");
    }

    @Test
    @DisplayName("doubleMetaphone handles 'TZ' sequence in 'BITZ'")
    public void TC25_doubleMetaphone_TZ_sequence_BITZ() throws Exception {
        // GIVEN
        String value = "BITZ";
        DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
        
        // WHEN
        String result = doubleMetaphone.doubleMetaphone(value, false);
        
        // THEN
        assertTrue(result.contains("TS"), "Expected encoded 'TZ' as 'TS'");
    }
}