package org.apache.commons.math3.stat.descriptive.rank;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

public class PSquarePercentile_equals_1_2_Test {

    @Test
    @DisplayName("equals returns false when both objects have non-null, different markers")
    public void TC06_equalsDifferentMarkers_ReturnsFalse() throws Exception {
        // Create two PSquarePercentile instances with the same quantile
        PSquarePercentile obj1 = new PSquarePercentile(50.0);
        PSquarePercentile obj2 = new PSquarePercentile(50.0);

        // Access the 'markers' field via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);

        // Create different marker instances for obj1 and obj2
        Class<?> markersClass = Class.forName("org.apache.commons.math3.stat.descriptive.rank.PSquarePercentile$Markers");
        Constructor<?> markersConstructor = markersClass.getDeclaredConstructor(List.class, double.class);
        markersConstructor.setAccessible(true);

        // Initialize markers with different initialFive lists
        List<Double> initialFive1 = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        Object markers1 = markersConstructor.newInstance(initialFive1, 0.5);

        List<Double> initialFive2 = Arrays.asList(6.0, 7.0, 8.0, 9.0, 10.0);
        Object markers2 = markersConstructor.newInstance(initialFive2, 0.5);

        // Set different markers to obj1 and obj2
        markersField.set(obj1, markers1);
        markersField.set(obj2, markers2);

        // Assert that equals returns false
        boolean result = obj1.equals(obj2);
        assertFalse(result);
    }

    @Test
    @DisplayName("equals returns true when both objects have null markers and equal observation counts")
    public void TC07_equalsBothMarkersNullEqualCounts_ReturnsTrue() throws Exception {
        // Create two PSquarePercentile instances with the same quantile
        PSquarePercentile obj1 = new PSquarePercentile(50.0);
        PSquarePercentile obj2 = new PSquarePercentile(50.0);

        // Access the 'markers' and 'countOfObservations' fields via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(obj1, null);
        markersField.set(obj2, null);

        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(obj1, 15L);
        countField.setLong(obj2, 15L);

        // Assert that equals returns true
        boolean result = obj1.equals(obj2);
        assertTrue(result);
    }

    @Test
    @DisplayName("equals returns false when both objects have null markers but different observation counts")
    public void TC08_equalsBothMarkersNullDifferentCounts_ReturnsFalse() throws Exception {
        // Create two PSquarePercentile instances with the same quantile
        PSquarePercentile obj1 = new PSquarePercentile(50.0);
        PSquarePercentile obj2 = new PSquarePercentile(50.0);

        // Access the 'markers' and 'countOfObservations' fields via reflection
        Field markersField = PSquarePercentile.class.getDeclaredField("markers");
        markersField.setAccessible(true);
        markersField.set(obj1, null);
        markersField.set(obj2, null);

        Field countField = PSquarePercentile.class.getDeclaredField("countOfObservations");
        countField.setAccessible(true);
        countField.setLong(obj1, 10L);
        countField.setLong(obj2, 20L);

        // Assert that equals returns false
        boolean result = obj1.equals(obj2);
        assertFalse(result);
    }
}