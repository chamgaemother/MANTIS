import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.StreamReadFeature;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import static org.junit.jupiter.api.Assertions.*;

class ReaderBasedJsonParserTest {

    private IOContext ioContext;
    private CharsToNameCanonicalizer canonicalizer;
    private ObjectCodec codec;

    @BeforeEach
    void setUp() {
        ioContext = new IOContext(null, null, false);
        canonicalizer = CharsToNameCanonicalizer.createRoot();
    }

    @Test
    void testNextTokenEndOfInput() throws IOException {
        Reader reader = new StringReader("");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertNull(parser.nextToken());
    }

    @Test
    void testNextTokenStartObject() throws IOException {
        Reader reader = new StringReader("{ }");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
    }

    @Test
    void testNextTokenUnexpectedCharacter() {
        Reader reader = new StringReader("[]");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        JsonParseException thrown = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(thrown.getMessage().contains("expected a value"));
    }

    @Test
    void testNextTokenUnexpectedEndArray() {
        Reader reader = new StringReader("{]");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        JsonParseException thrown = assertThrows(JsonParseException.class, parser::nextToken);
        assertTrue(thrown.getMessage().contains("expected a value"));
    }

    @Test
    void testNextTokenValueString() throws IOException {
        Reader reader = new StringReader("\"value\"");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertEquals(JsonToken.VALUE_STRING, parser.nextToken());
    }

    @Test
    void testNextTokenNumber() throws IOException {
        Reader reader = new StringReader("123");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertEquals(JsonToken.VALUE_NUMBER_INT, parser.nextToken());
    }

    @Test
    void testNextTokenTrue() throws IOException {
        Reader reader = new StringReader("true");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertEquals(JsonToken.VALUE_TRUE, parser.nextToken());
    }

    @Test
    void testNextTokenFalse() throws IOException {
        Reader reader = new StringReader("false");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertEquals(JsonToken.VALUE_FALSE, parser.nextToken());
    }

    @Test
    void testNextTokenNull() throws IOException {
        Reader reader = new StringReader("null");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertEquals(JsonToken.VALUE_NULL, parser.nextToken());
    }

    @Test
    void testNextTokenStartArray() throws IOException {
        Reader reader = new StringReader("[");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        assertEquals(JsonToken.START_ARRAY, parser.nextToken());
    }

    @Test
    void testNextTokenSingleQuoteName() throws IOException {
        int features = StreamReadFeature.allowSingleQuotesForKeys().getMask();
        Reader reader = new StringReader("{'key": 1}");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, features, reader, codec, canonicalizer);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken());
    }

    @Test
    void testNextTokenColonAfterName() throws IOException {
        Reader reader = new StringReader("{\"key\": \"value\"}");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, JsonParser.Feature.collectDefaults(), reader, codec, canonicalizer);
        parser.nextToken(); // {
        assertEquals(JsonToken.FIELD_NAME, parser.nextToken()); // "key"
    }

    @Test
    void testNextTokenCommentSkipped() throws IOException {
        int features = StreamReadFeature.allowJavaComments().getMask();
        Reader reader = new StringReader("{/*comment*/ \"key\": \"value\"}");
        ReaderBasedJsonParser parser = new ReaderBasedJsonParser(ioContext, features, reader, codec, canonicalizer);
        assertEquals(JsonToken.START_OBJECT, parser.nextToken());
    }
}