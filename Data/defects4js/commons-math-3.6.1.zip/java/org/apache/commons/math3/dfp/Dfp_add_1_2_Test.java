package org.apache.commons.math3.dfp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * JUnit 5 test class for org.apache.commons.math3.dfp.Dfp#add(Dfp).
 */
public class Dfp_add_1_2_Test {

    /**
     * Helper method to retrieve the DfpField from a Dfp instance using reflection.
     *
     * @param dfp the Dfp instance
     * @return the associated DfpField
     * @throws Exception if reflection fails
     */
    private DfpField getField(Dfp dfp) throws Exception {
        Field fieldField = Dfp.class.getDeclaredField("field");
        fieldField.setAccessible(true);
        return (DfpField) fieldField.get(dfp);
    }

    /**
     * Helper method to retrieve the IEEE flags from a DfpField using reflection.
     *
     * @param field the DfpField instance
     * @return the current IEEE flags
     * @throws Exception if reflection fails
     */
    private int getFlags(DfpField field) throws Exception {
        Method getFlagsMethod = DfpField.class.getDeclaredMethod("getFlags");
        getFlagsMethod.setAccessible(true);
        return (int) getFlagsMethod.invoke(field);
    }

    /**
     * Test TC11: Adding two Dfp numbers resulting in gradual underflow.
     */
    @Test
    @DisplayName("Adding two Dfp numbers resulting in gradual underflow")
    public void TC11_AddGradualUnderflow() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 1e-320);
        Dfp b = new Dfp(field, 1e-320);

        // WHEN
        Dfp result = a.add(b);

        // THEN
        int flags = getFlags(field);
        assertTrue((flags & DfpField.FLAG_UNDERFLOW) != 0, "FLAG_UNDERFLOW should be set");
        assertTrue(result.isZero(), "Result should be zero due to gradual underflow");
    }

    /**
     * Test TC12: Adding a Dfp number to itself triggers correct carry-over without overflow.
     */
    @Test
    @DisplayName("Adding a Dfp number to itself triggers correct carry-over without overflow")
    public void TC12_AddSelfWithCarryOver() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 9999.9999);

        // WHEN
        Dfp result = a.add(a);

        // THEN
        assertEquals(a.exp + 1, result.exp, "Exponent should be incremented by one after carry-over");
        assertEquals(1, result.mant[0], "Mantissa should correctly carry over");
    }

    /**
     * Test TC13: Adding Dfp numbers resulting in overflow sets FLAG_OVERFLOW and returns Infinity.
     */
    @Test
    @DisplayName("Adding Dfp numbers resulting in overflow sets FLAG_OVERFLOW and returns Infinity")
    public void TC13_AddCausingOverflow() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, Double.MAX_VALUE);
        Dfp b = new Dfp(field, Double.MAX_VALUE);

        // WHEN
        Dfp result = a.add(b);

        // THEN
        int flags = getFlags(field);
        assertTrue((flags & DfpField.FLAG_OVERFLOW) != 0, "FLAG_OVERFLOW should be set");
        assertTrue(result.isInfinite(), "Result should be Infinity due to overflow");
        assertEquals(a.sign, result.sign, "Sign of Infinity should match operands");
    }

    /**
     * Test TC14: Adding a Dfp finite number with a quiet NaN and verifying NaN is returned.
     */
    @Test
    @DisplayName("Adding a Dfp finite number with a quiet NaN and verifying NaN is returned")
    public void TC14_AddFiniteWithQuietNaN() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, 150.0);
        Dfp b = new Dfp(field, "NaN");

        // WHEN
        Dfp result = a.add(b);

        // THEN
        assertTrue(result.isNaN(), "Result should be QNAN");
        // Assuming FLAG_INVALID is not set in this scenario
        int flags = getFlags(field);
        assertFalse((flags & DfpField.FLAG_INVALID) != 0, "FLAG_INVALID should not be set");
    }

    /**
     * Test TC15: Adding Dfp positive infinity and a finite negative Dfp number returns positive infinity.
     */
    @Test
    @DisplayName("Adding Dfp positive infinity and a finite negative Dfp number returns positive infinity")
    public void TC15_AddPositiveInfinityWithFiniteNegative() throws Exception {
        // GIVEN
        DfpField field = new DfpField(10);
        Dfp a = new Dfp(field, Double.POSITIVE_INFINITY);
        Dfp b = new Dfp(field, -200.0);

        // WHEN
        Dfp result = a.add(b);

        // THEN
        assertTrue(result.isInfinite(), "Result should be Infinity");
        assertEquals(1, result.sign, "Result should be positive Infinity");
    }
}