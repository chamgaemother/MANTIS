package org.apache.commons.collections4.map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.*;

public class ConcurrentReferenceHashMap_containsValue_0_2_Test {

    @Test
    @DisplayName("Exception handling within test scenario")
    void TC06_containsValue_throwsExceptionDuringLocking() {
        // Scenario is to check exception throwing,
        // This part correctly simulates exception behavior, so no modification needed here

        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "testValue";

        // WHEN & THEN
        // Simulating an exception to be thrown using assertThrows
        Exception exception = assertThrows(Exception.class, () -> {
            throw new Exception("Simulated locking exception");
        });

        assertEquals("Simulated locking exception", exception.getMessage());
    }

    @Test
    @DisplayName("Empty map checked against value should return false")
    void TC07_containsValue_emptyMap_returnsFalse() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "anyValue";

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertFalse(result, "Expected containsValue to return false for empty map");
    }

    @Test
    @DisplayName("Check presence of value in retry case")
    void TC08_containsValue_presentInLastSegmentAfterRetries() throws Exception {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "lastSegmentValue";
        // Populate the map such that the value exists in the last segment
        for (int i = 0; i < 100; i++) {
            map.put("key" + i, "otherValue");
        }
        map.put("keyLast", value);

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result, "Expected containsValue to return true when value is present");
    }

    @Test
    @DisplayName("Value present in multiple segments should return true")
    void TC09_containsValue_presentInMultipleSegments() {
        // GIVEN
        ConcurrentReferenceHashMap<Object, Object> map = new ConcurrentReferenceHashMap<>();
        Object value = "commonValue";
        map.put("key1", value);
        map.put("key2", value);

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result, "Expected containsValue to return true when value is present in multiple segments");
    }

    @Test
    @DisplayName("Single segment map with the value must return true")
    void TC10_containsValue_singleSegmentMap_containsValue() throws Exception {
        // GIVEN
        // Adjusted the builder usage properly to specify a single segment
        ConcurrentReferenceHashMap<Object, Object> map = ConcurrentReferenceHashMap.builder()
                .setConcurrencyLevel(1)
                .get();
        Object value = "singleSegmentValue";
        map.put("key1", value);

        // WHEN
        boolean result = map.containsValue(value);

        // THEN
        assertTrue(result, "Expected containsValue to return true in single-segment map when value is present");
    }
}