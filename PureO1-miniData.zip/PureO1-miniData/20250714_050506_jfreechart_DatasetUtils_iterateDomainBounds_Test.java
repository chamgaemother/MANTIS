import static org.junit.jupiter.api.Assertions.*;

import org.jfree.data.Range;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.junit.jupiter.api.Test;

public class DatasetUtilsTest {

    @Test
    void testIterateDomainBounds_NullDataset() {
        assertThrows(IllegalArgumentException.class, () -> {
            DatasetUtils.iterateDomainBounds(null, true);
        });
    }

    @Test
    void testIterateDomainBounds_EmptyDataset_IncludeIntervalTrue_NotIntervalXYDataset() {
        XYDataset dataset = new SimpleXYDataset();
        Range range = DatasetUtils.iterateDomainBounds(dataset, true);
        assertNull(range);
    }

    @Test
    void testIterateDomainBounds_EmptyDataset_IncludeIntervalFalse() {
        XYDataset dataset = new SimpleXYDataset();
        Range range = DatasetUtils.iterateDomainBounds(dataset, false);
        assertNull(range);
    }

    @Test
    void testIterateDomainBounds_SingleSeries_NoNaN_IncludeIntervalFalse() {
        XYDataset dataset = new SimpleXYDataset(new double[][]{{1.0, 2.0, 3.0}});
        Range range = DatasetUtils.iterateDomainBounds(dataset, false);
        assertEquals(new Range(1.0, 3.0), range);
    }

    @Test
    void testIterateDomainBounds_SingleSeries_AllNaN_IncludeIntervalFalse() {
        XYDataset dataset = new SimpleXYDataset(new double[][]{{Double.NaN, Double.NaN}});
        Range range = DatasetUtils.iterateDomainBounds(dataset, false);
        assertNull(range);
    }

    @Test
    void testIterateDomainBounds_MultipleSeries_NoNaN_IncludeIntervalFalse() {
        XYDataset dataset = new SimpleXYDataset(new double[][]{
                {1.0, 4.0, 5.0},
                {2.0, 3.0, 6.0}
        });
        Range range = DatasetUtils.iterateDomainBounds(dataset, false);
        assertEquals(new Range(1.0, 6.0), range);
    }

    @Test
    void testIterateDomainBounds_MultipleSeries_WithNaN_IncludeIntervalFalse() {
        XYDataset dataset = new SimpleXYDataset(new double[][]{
                {1.0, Double.NaN, 5.0},
                {Double.NaN, 3.0, 6.0}
        });
        Range range = DatasetUtils.iterateDomainBounds(dataset, false);
        assertEquals(new Range(1.0, 6.0), range);
    }

    @Test
    void testIterateDomainBounds_IncludeIntervalTrue_NotIntervalXYDataset() {
        XYDataset dataset = new SimpleXYDataset(new double[][]{
                {1.0, 2.0},
                {3.0, 4.0}
        });
        Range range = DatasetUtils.iterateDomainBounds(dataset, true);
        assertEquals(new Range(1.0, 4.0), range);
    }

    @Test
    void testIterateDomainBounds_IncludeIntervalTrue_IntervalXYDataset_AllValid() {
        IntervalXYDataset dataset = new SimpleIntervalXYDataset(new double[][]{
                {1.0, 2.0, 3.0},
                {4.0, 5.0, 6.0}
        }, new double[][]{
                {0.5, 1.5, 2.5},
                {3.5, 4.5, 5.5}
        }, new double[][]{
                {1.5, 2.5, 3.5},
                {4.5, 5.5, 6.5}
        });
        Range range = DatasetUtils.iterateDomainBounds(dataset, true);
        assertEquals(new Range(0.5, 6.5), range);
    }

    @Test
    void testIterateDomainBounds_IncludeIntervalTrue_IntervalXYDataset_WithNaN() {
        IntervalXYDataset dataset = new SimpleIntervalXYDataset(new double[][]{
                {Double.NaN, 2.0},
                {4.0, 5.0}
        }, new double[][]{
                {Double.NaN, 1.5},
                {3.5, 4.5}
        }, new double[][]{
                {Double.NaN, 2.5},
                {4.5, 5.5}
        });
        Range range = DatasetUtils.iterateDomainBounds(dataset, true);
        assertEquals(new Range(1.5, 5.5), range);
    }

    @Test
    void testIterateDomainBounds_IncludeIntervalTrue_IntervalXYDataset_AllNaN() {
        IntervalXYDataset dataset = new SimpleIntervalXYDataset(new double[][]{
                {Double.NaN, Double.NaN},
                {Double.NaN, Double.NaN}
        }, new double[][]{
                {Double.NaN, Double.NaN},
                {Double.NaN, Double.NaN}
        }, new double[][]{
                {Double.NaN, Double.NaN},
                {Double.NaN, Double.NaN}
        });
        Range range = DatasetUtils.iterateDomainBounds(dataset, true);
        assertNull(range);
    }

    @Test
    void testIterateDomainBounds_MaximumLessThanMinimum() {
        XYDataset dataset = new SimpleXYDataset(new double[][]{});
        Range range = DatasetUtils.iterateDomainBounds(dataset, false);
        assertNull(range);
    }

    // Helper classes for testing

    private static class SimpleXYDataset implements XYDataset {
        private final double[][] data;

        SimpleXYDataset() {
            this.data = new double[0][0];
        }

        SimpleXYDataset(double[][] data) {
            this.data = data;
        }

        @Override
        public int getSeriesCount() {
            return data.length;
        }

        @Override
        public Comparable getSeriesKey(int series) {
            return "Series " + series;
        }

        @Override
        public int indexOf(Comparable seriesKey) {
            for (int i = 0; i < getSeriesCount(); i++) {
                if (getSeriesKey(i).equals(seriesKey)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public int getItemCount(int series) {
            return data[series].length;
        }

        @Override
        public Number getX(int series, int item) {
            return data[series][item];
        }

        @Override
        public double getXValue(int series, int item) {
            return data[series][item];
        }

        @Override
        public Number getY(int series, int item) {
            return null;
        }

        @Override
        public double getYValue(int series, int item) {
            return 0;
        }

        @Override
        public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {}

        @Override
        public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {}
    }

    private static class SimpleIntervalXYDataset implements IntervalXYDataset {
        private final double[][] xValues;
        private final double[][] startXValues;
        private final double[][] endXValues;

        SimpleIntervalXYDataset(double[][] xValues, double[][] startXValues, double[][] endXValues) {
            this.xValues = xValues;
            this.startXValues = startXValues;
            this.endXValues = endXValues;
        }

        @Override
        public int getSeriesCount() {
            return xValues.length;
        }

        @Override
        public Comparable getSeriesKey(int series) {
            return "Series " + series;
        }

        @Override
        public int indexOf(Comparable seriesKey) {
            for (int i = 0; i < getSeriesCount(); i++) {
                if (getSeriesKey(i).equals(seriesKey)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public int getItemCount(int series) {
            return xValues[series].length;
        }

        @Override
        public Number getX(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public double getXValue(int series, int item) {
            return xValues[series][item];
        }

        @Override
        public Number getStartX(int series, int item) {
            return startXValues[series][item];
        }

        @Override
        public double getStartXValue(int series, int item) {
            return startXValues[series][item];
        }

        @Override
        public Number getEndX(int series, int item) {
            return endXValues[series][item];
        }

        @Override
        public double getEndXValue(int series, int item) {
            return endXValues[series][item];
        }

        @Override
        public Number getY(int series, int item) {
            return null;
        }

        @Override
        public double getYValue(int series, int item) {
            return 0;
        }

        @Override
        public Number getStartY(int series, int item) {
            return null;
        }

        @Override
        public double getStartYValue(int series, int item) {
            return Double.NaN;
        }

        @Override
        public Number getEndY(int series, int item) {
            return null;
        }

        @Override
        public double getEndYValue(int series, int item) {
            return Double.NaN;
        }

        @Override
        public void addChangeListener(org.jfree.data.general.DatasetChangeListener listener) {}

        @Override
        public void removeChangeListener(org.jfree.data.general.DatasetChangeListener listener) {}
    }
}